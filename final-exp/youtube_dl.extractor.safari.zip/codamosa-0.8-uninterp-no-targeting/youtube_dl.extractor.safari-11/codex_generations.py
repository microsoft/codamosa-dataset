

# Generated at 2022-06-22 08:08:27.671047
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('http://techbus.safaribookonline.com/9780134426365');
    ie = SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838');
    ie = SafariCourseIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json');
    ie = SafariCourseIE('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314');
    ie = SafariCourseIE('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838');

# Generated at 2022-06-22 08:08:34.456242
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Test constructor of class SafariIE."""
    # Test when 'safaribooksonline.com' available in netrc.
    ie = SafariIE()
    assert ie.user == "testuser"
    assert ie.password == "testpass"

    # Test when 'safaribooksonline.com' available in netrc.
    ie = SafariIE()
    ie.password = ie.user = None
    assert ie.user == "testuser"
    assert ie.password == "testpass"

# Generated at 2022-06-22 08:08:36.909263
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Test constructor of class SafariApiIE"""
    try:
        assert(SafariApiIE.ie_key() == 'SafariApi')
        assert(SafariApiIE.ie_key() != 'Safari')
    except AssertionError:
        print("Test Failed: assert(SafariApiIE.ie_key() == 'SafariApi')")

# Generated at 2022-06-22 08:08:42.813727
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE(SafariBaseIE._downloader,
                  'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert ie.__class__ is SafariIE


# Generated at 2022-06-22 08:08:54.611922
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import datetime
    a = SafariApiIE()
    d = datetime.datetime.now()
    a.day = d.day
    a.hour = d.hour
    a.month = d.month
    a.year = d.year
    a.minute = d.minute
    if a.month < 10:
        a.month = '0' + str(a.month)
    if a.day < 10:
        a.day = '0' + str(a.day)
    if a.hour < 10:
        a.hour = '0' + str(a.hour)
    if a.minute < 10:
        a.minute = '0' + str(a.minute)

# Generated at 2022-06-22 08:09:05.545536
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from ..utils import get_testcases
    from . import npo

    testcases = get_testcases(npo, {
        'url': 'https://www.nposupport.com/library/view/python-essential-reference-4th/9780132216407/',
        'info_dict': {
            'id': '9780132216407',
            'title': 'Python Essential Reference',
        },
        'playlist_count': 12,
    })
    testcases.extend(get_testcases(npo, {
        'url': 'https://www.nposupport.com/api/v1/book/9781593276034/?override_format=json',
        'only_matching': True,
    }))

# Generated at 2022-06-22 08:09:09.620377
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    # This tests that SafariCourseIE constructor loads SafariIE
    assert safari_course_ie.IE_NAME == 'safari'


# Generated at 2022-06-22 08:09:21.139623
# Unit test for constructor of class SafariIE
def test_SafariIE():
  """Test for constructor of class SafariIE"""
  # Test for broken input
  ie = SafariIE(None)
  assert(ie.ie_key() == 'Safari')
  assert(SafariIE.suitable(None) == False)
  assert(SafariIE.can_handle_url("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html") == True)
  assert(SafariIE.can_handle_url("https://techbus.safaribooksonline.com/") == False)

# Generated at 2022-06-22 08:09:24.827209
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('http://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    assert ie.ie_key() == 'Safari'

# Generated at 2022-06-22 08:09:26.485447
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.__class__.__name__ == 'SafariIE'

# Generated at 2022-06-22 08:09:51.643399
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Constructor has multiple initialization paths depending on the parameters
    # and composition of the urls. This unit test is mainly to ensure that
    # SafariCourseIE is constructed in the absence of login credentials.
    # In fact, this is the only known use-case for the class that does not
    # require login credentials.
    #
    # The url parameter has to be a url of a course listing on the safari
    # booksonline website. It can be any url that matches the regex
    # `_VALID_URL` and contains a safari id of the form
    # `(?:978|\d{7})[\dX]{10}`
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'

# Generated at 2022-06-22 08:09:55.761866
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.ie_key() == 'Safari'
    assert ie.ie_name() == 'Safari'
    assert ie.ie_description() == 'safaribooksonline.com online video'

# Generated at 2022-06-22 08:09:57.724069
# Unit test for constructor of class SafariIE
def test_SafariIE():
    s = SafariIE()
    assert s.IE_NAME == 'safari'
    assert s.LOGGED_IN == False


# Generated at 2022-06-22 08:09:59.588121
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariBaseIE.ie_key()
    assert safari == 'Safari'



# Generated at 2022-06-22 08:10:01.766209
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    instance = SafariApiIE()
    print('instance =', instance)

# Test for method real_extract of class SafariApiIE

# Generated at 2022-06-22 08:10:06.254711
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course = SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')
    assert(safari_course.IE_NAME == 'safari:course')

# Generated at 2022-06-22 08:10:18.882830
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie_test = SafariApiIE()
    assert(ie_test.ie_key() == 'safari:api')
    assert(ie_test.ie_name() == 'safaribooksonline.com online video')
    assert(ie_test._VALID_URL.find('https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'))
    assert(ie_test.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == True)

# Generated at 2022-06-22 08:10:21.512458
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    with open('test/data/test_safari.html', 'rb') as webPage:
        webpage = webPage.read()

    mobj = re.search(SafariApiIE._VALID_URL, webpage)
    try:
        safari_api_ie = SafariApiIE(mobj)
    except Exception as e:
        raise e


# Generated at 2022-06-22 08:10:31.300635
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import sys
    try:
        import httpretty
    except ImportError:
        sys.exit('Please install httpretty to run this test')

    httpretty.enable()

    class MockExtractor(SafariBaseIE):
        @property
        def username(self):
            return 'test_user'

        @property
        def password(self):
            return 'test_password'

    extractor = MockExtractor(None)
    extractor._download_json = lambda *args, **kwargs: {'logged_in': True}
    extractor._download_webpage_handle = lambda *args, **kwargs: (
        {}, {
            'geturl': lambda: 'https://learning.oreilly.com/home/'
        })


# Generated at 2022-06-22 08:10:43.038661
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SUBSCRIBER_EMAIL = 'icecream@scoops.com'
    SUBSCRIBER_PASSWORD = 'ice_cream'
    SUBSCRIBER_LOGIN_INFO = (SUBSCRIBER_EMAIL, SUBSCRIBER_PASSWORD)

    # Initialize the class to be tested
    safarie = SafariBaseIE()

    # Ensure that safarie._login() raises ExtractorError if email is None
    safarie.SUBSCRIBER_EMAIL = None
    safarie.SUBSCRIBER_PASSWORD = SUBSCRIBER_PASSWORD
    with pytest.raises(ExtractorError, match='Username is missing') as exc:
        safarie._login()

    # Ensure that safarie._login() raises ExtractorError if password is None

# Generated at 2022-06-22 08:11:01.153280
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari._API_FORMAT == 'json'
    assert safari.LOGGED_IN == False

# Generated at 2022-06-22 08:11:13.510918
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..utils import get_testcases
    from ..test_utils import TestCase

    def case_generator(test_cases):
        for case in test_cases:
            url = case['url']
            mobj = re.match(SafariApiIE._VALID_URL, url)
            id = mobj.group('id')
            title = '%s/%s' % (id, mobj.group('part'))
            yield TestCase(url, title, None, None, None, None)

    testcases = case_generator(
        get_testcases(SafariApiIE._TESTS, SafariApiIE._VALID_URL))

# Generated at 2022-06-22 08:11:25.473432
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Use in-memory io for responses
    import io
    import http.client

    # Mock http.client class to return in-memory io
    def return_io_response(status, content_type, body):
        io_response = io.BytesIO(b"""HTTP/1.1 '%s' Message
Content-Type: '%s'

%s""" % (status.encode('utf-8'), content_type.encode('utf-8'), body.encode('utf-8')))
        io_response.readline = io_response.readline
        return io_response

    http.client.HTTPResponse = return_io_response
    # Check SafariBaseIE.__init__()

# Generated at 2022-06-22 08:11:29.999615
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Test constructor of SafariApiIE"""

    course_id = "9780134661926"
    mobj = re.match(SafariApiIE._VALID_URL, "https://www.safaribooksonline.com/api/v1/book/%s/chapter/part00.html" % course_id)
    assert(mobj and mobj.group('course_id') == course_id)

# Generated at 2022-06-22 08:11:33.380216
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """ Unit test for constructor of class SafariCourseIE """
    safariCourseIE = SafariCourseIE()
    assert safariCourseIE.name == 'safari:course'

# Generated at 2022-06-22 08:11:42.184292
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # when unit test directly, do not know what the value of IE_NAME is
    # from youtube_dl.extractor.common import InfoExtractor
    if hasattr(InfoExtractor, 'IE_NAME'):
        InfoExtractor.IE_NAME = 'safari'

    safari_api_ie = SafariApiIE()
    safari_api_ie._real_initialize()

    # unit test safariApiIE._real_extract()
    safari_api_ie._real_extract(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')

# Generated at 2022-06-22 08:11:47.127979
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE("Kaltura", "Safari", "safari")
    return safariIE

# Generated at 2022-06-22 08:11:49.349970
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # This test only runs if you have credentials in your .netrc
    _, _, username, password = SafariBaseIE._get_login_info()
    assert username and password

# Generated at 2022-06-22 08:11:53.526388
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # test SafariApiIE
    instance = SafariApiIE()
    assert isinstance(instance, SafariBaseIE)

# Generated at 2022-06-22 08:12:03.272170
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    i = SafariCourseIE("http://techbus.safaribooksonline.com/9780134426365")
    assert i.suitable("http://techbus.safaribooksonline.com/9780134426365") == True
    assert i.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/") == False
    assert i.suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json") == False
    assert i.suitable("https://www.safaribooksonline.com/videos/python-programming-language/9780134217314") == False

# Generated at 2022-06-22 08:12:52.084664
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-22 08:12:59.010148
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test constructor.
    safari_ie = SafariIE()
    assert safari_ie._VALID_URL == SafariIE._VALID_URL
    assert safari_ie._downloader == None
    assert safari_ie._downloader_params == {
        'username': None, 'password': None,
        'video_password': None}
    assert safari_ie._WORKING == True
    assert safari_ie.ie_key() == 'Safari'



# Generated at 2022-06-22 08:13:02.917688
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_safari import _test_generic_course
    _test_generic_course(SafariCourseIE, course_id='9780133392838', course_title='Hadoop Fundamentals LiveLessons')



# Generated at 2022-06-22 08:13:10.893704
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        _VALID_URL = ''

    t = TestSafariBaseIE()
    assert hasattr(t, '_LOGIN_URL')
    assert hasattr(t, '_NETRC_MACHINE')
    assert hasattr(t, '_API_BASE')
    assert hasattr(t, '_API_FORMAT')
    assert hasattr(t, 'LOGGED_IN')


# Generated at 2022-06-22 08:13:14.863390
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(SafariBaseIE.ie_key(), {'url': 'https://www.safaribooksonline.com/'})

    assert ie.params == {
        'username': 'user',
        'password': 'pass'
    }
    assert ie.LOGGED_IN == False



# Generated at 2022-06-22 08:13:22.405402
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Unit test for constructor of class SafariCourseIE.
    """
    # url_test: url tested
    # url_expected: url expected
    # safari_course_ie_expected: expected class
    # safari_course_ie: class to test
    url_test = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    url_expected = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    safari_course_ie_expected = SafariCourseIE
    safari_course_ie = SafariCourseIE.suitable(url_test)
    assert safari_course_ie == safari_course_ie_expected
    assert url_

# Generated at 2022-06-22 08:13:25.002512
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    pass

# Generated at 2022-06-22 08:13:29.477202
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course = SafariCourseIE()
    course._real_extract(url)

# Generated at 2022-06-22 08:13:32.011063
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course = SafariCourseIE()
    assert safari_course.ie_key() == 'Safari:Course'

# Generated at 2022-06-22 08:13:38.066682
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    extractor = SafariBaseIE()
    assert extractor.LOGGED_IN is False
    assert extractor._NETRC_MACHINE == 'safari'
    assert extractor._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert extractor._API_FORMAT == 'json'
    assert extractor._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-22 08:14:37.276709
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    print(SafariBaseIE())

# Generated at 2022-06-22 08:14:37.889864
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-22 08:14:45.182038
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest

    class StubSafariApiTest(unittest.TestCase):
        def test_constructor(self):
            safari_api = SafariApiIE()
            self.assertIn('safari:api', safari_api.ie_key())

    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    suite.addTest(loader.loadTestsFromTestCase(StubSafariApiTest))
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-22 08:14:50.637404
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('Safari', None)
    assert safari_ie.ie_name() == 'Safari'
    assert safari_ie.ie_key() == 'Kaltura'
    assert safari_ie.suitable(None)
    assert safari_ie.LOGGED_IN is False

# Generated at 2022-06-22 08:14:53.992958
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    instance = SafariApiIE()
    assert instance. IE_NAME == 'safari:api'

# Generated at 2022-06-22 08:15:05.151798
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    courseid_from_url = '9780133392838'
    safariCourse = SafariCourseIE()

    assert safariCourse._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''
    assert safariCourse._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-22 08:15:12.178149
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    dl = SafariBaseIE()
    dl._LOGIN_URL = 'http://localhost/accounts/login/'
    dl._NETRC_MACHINE = 'website'

    dl.to_screen = lambda message: None
    dl.report_warning = lambda message: None

    def test_success_download(*args, **kargs):
        class A:
            status_code = 200
            content = b'{"logged_in": true, "redirect_uri": "referer"}'
        return A(), None

    def test_login_required_download(*args, **kargs):
        class A:
            status_code = 302
            url = 'http://accounts.example.com/login/?next=referer'
        return A(), None


# Generated at 2022-06-22 08:15:21.854061
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():

    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'

    # No account is required to get a SafariCourseIE object
    test_course_ie_obj = SafariCourseIE()

    # Obtain an extractor object by calling method 'suitable'
    test_extractor = test_course_ie_obj.suitable(test_url)

    # Unit test checks to see if a SafariCourseIE object was initialized for
    # the test_url
    assert isinstance(test_extractor, SafariCourseIE)

# Generated at 2022-06-22 08:15:32.228775
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test.
    # This test is not run by default.
    # To run this test, run:
    #   $ python test.py SafariCourseIE
    # or
    #   $ python test.py SafariCourseIE::test_SafariCourseIE

    # Discover safaribooksonline courses.
    # Log in safaribooksonline account to discover all courses.
    # If you are not logged in, only public courses are discovered.
    ie = SafariCourseIE()
    ie.username = 'YOUR ACCOUNT USERNAME'
    ie.password = 'YOUR ACCOUNT PASSWORD'
    ie.debug = True
    results = ie.extract_entries_from_url('https://www.safaribooksonline.com')

    # Display the result.

# Generated at 2022-06-22 08:15:33.174470
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    info_extractor = SafariBaseIE()
    assert info_extractor.IE_NAME == 'SafariBaseIE'