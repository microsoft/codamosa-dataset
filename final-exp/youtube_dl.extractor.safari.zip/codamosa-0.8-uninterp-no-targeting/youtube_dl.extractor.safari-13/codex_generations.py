

# Generated at 2022-06-22 08:08:29.924918
# Unit test for constructor of class SafariIE
def test_SafariIE():
    temp_test_SafariIE = SafariIE('http://learning.oreilly.com')
    assert temp_test_SafariIE != None

# Generated at 2022-06-22 08:08:31.237683
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('test', 'test', _netrc_required=True)

# Generated at 2022-06-22 08:08:34.751150
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    # method _real_initialize
    assert callable(instance._real_initialize)
    # method _login
    assert callable(instance._login)
    # attribute LOGGED_IN
    assert instance.LOGGED_IN == False

# Generated at 2022-06-22 08:08:46.197259
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_url = 'https://www.techbus.safaribooksonline.com/9781617291705'
    course_id = '9781617291705'

    # test _initialize()
    ie = SafariBaseIE()
    ie._initialize()
    # _initialize() calls login() and _login() sets global variable LOGGED_IN to True
    # or False depending on if login attempt was successful or not.
    assert not ie.LOGGED_IN

    # test _real_extract()
    # _real_extract() calls _real_initialize()
    # which in turn calls _login()
    entries = ie._real_extract(test_url)
    assert 'Unable to log in' in entries[0].get('description')

    # test _login()
    import netrc


# Generated at 2022-06-22 08:08:47.651688
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()


# Generated at 2022-06-22 08:08:48.162258
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-22 08:09:00.282653
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..compat import unittest
    from .. import compat_urllib_request
    from ..utils import fake_http_headers

    fake_request = compat_urllib_request.Request
    fake_request.add_header = lambda x, y: (None, None)

    SafariApiIE.__dict__['_download_json'] = lambda *args, **kwargs: {}

    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    assert SafariApiIE.suitable(url)

    expected = SafariApiIE.__dict__['_VALID_URL']
    assert '%s' % SafariApiIE.__dict__['_VALID_URL'] == expected

    Safari

# Generated at 2022-06-22 08:09:11.543716
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
	from .common import fake_urlopen, compat_urllib_response

	def urlopen_mock(request):
		url = request.get_full_url()
		if url == 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json':
			return compat_urllib_response(
				b'{"chapters": ["https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/ch01.html", "https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/ch02.html"],"title": "Building Applications with React and Redux in ES6"}',
				200)

# Generated at 2022-06-22 08:09:17.312275
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_url = 'https://www.safaribooksonline.com/library/view/python-crash-course/9781593276034/'
    safari_course_instance = SafariCourseIE()
    assert safari_course_instance.suitable(test_url) is True
    assert safari_course_instance.IE_NAME == 'safari:course'
    assert safari_course_instance.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-22 08:09:26.788316
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/part00.html'
    my_SafariApiIE = SafariApiIE()
    my_SafariApiIE._download_webpage = lambda *args: ('', None)
    my_SafariApiIE._download_webpage_handle = lambda *args: ('', None)
    my_SafariApiIE._download_json = lambda *args: ({'web_url': url}, None)
    my_SafariApiIE._real_extract(url)

# Generated at 2022-06-22 08:09:41.423617
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('safari:course')

# Generated at 2022-06-22 08:09:53.541853
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/python-cookbook/9781449340377/'
    course_id = '9781449340377'
    course_title = 'Python Cookbook'

    # test class constructor
    safari_course = SafariCourseIE()

    assert safari_course._match_id(url) == course_id

    # test _real_extract without login
    course_json = '{"id": "9781449340377", "title": "Python Cookbook", "chapters": ["https://www.safaribooksonline.com/api/v1/book/9781449340377/chapter/01_0001.html"]}'
    safari_course.to_screen = lambda *a, **kw: None

# Generated at 2022-06-22 08:09:58.324659
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert SafariBaseIE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert SafariBaseIE._NETRC_MACHINE == 'safari'

# Generated at 2022-06-22 08:10:06.567710
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import datetime
    info = {
        'id': '0_qbqx90ic',
        'ext': 'mp4',
        'title': 'Introduction to Hadoop Fundamentals LiveLessons',
        'timestamp': 1437758058,
        'upload_date': '20150724',
        'uploader_id': 'stork'
    }
    # Test conversion
    assert SafariIE._timeconvert(datetime.datetime(1337, 1, 1, 0, 0)) == 1338560000

# Generated at 2022-06-22 08:10:16.255489
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    api_ie = SafariApiIE()
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part01.html'

    assert api_ie.suitable(test_url) == True
    assert api_ie._real_extract(test_url) == api_ie.url_result(
        'https://www.safaribooksonline.com/library/view/learning-python-3rd/9781449396459/part01.html',
        'Safari')


# Generated at 2022-06-22 08:10:17.378018
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()._real_initialize()

# Generated at 2022-06-22 08:10:18.077475
# Unit test for constructor of class SafariIE
def test_SafariIE():
    pass

# Generated at 2022-06-22 08:10:19.731517
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    instance = SafariCourseIE()
    assert instance.IE_NAME == 'safari:course'

# Generated at 2022-06-22 08:10:23.068859
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert course.suitable(course.url)

# Generated at 2022-06-22 08:10:33.177824
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import requests

    class ConfigSafariBaseIE(SafariBaseIE):
        @property
        def _login_url(self):
            return "https://www.safaribooksonline.com/accounts/login/"

        @property
        def _login_data(self):
            return {
                'login': 'SafariBot',
                'password': 'Y4l4n4m4t4t4',
                'next': '/api/v1'
            }

    conf = {
        'username': 'SafariBot',
        'password': 'Y4l4n4m4t4t4',
        'logintoken': '1234567890xwz',
        'csrftoken': '1234567890xwz',
    }

    cookiejar = requests.utils.cookiejar

# Generated at 2022-06-22 08:11:13.778406
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # A SafariApiIE takes a safaribooksonline.com URL
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    ie = SafariApiIE(url)
    assert ie.ie_key() == 'SafariApi'
    assert ie.url == url


# Generated at 2022-06-22 08:11:15.698558
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-22 08:11:17.935890
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('library/view/[^/]+/([^/]+)/.*')

# Generated at 2022-06-22 08:11:20.401040
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False
    ie = SafariIE(username = "a", password = "b")

# Generated at 2022-06-22 08:11:23.167221
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-22 08:11:27.462653
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert obj.IE_NAME == 'safari'
    assert obj.IE_DESC == 'safaribooksonline.com online video'
    assert obj.LOGGED_IN == False

# Generated at 2022-06-22 08:11:34.278330
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Without login
    ie = SafariBaseIE('SafariBaseIE', {'username': None, 'password': None})
    assert not ie.LOGGED_IN
    # With login
    ie = SafariBaseIE('SafariBaseIE', {'username': 'user', 'password': 'pass'})
    assert ie.LOGGED_IN

# Generated at 2022-06-22 08:11:34.910410
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-22 08:11:39.871654
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    result = SafariCourseIE()._real_extract(url)
    assert result['id'] == '9780133392838'
    assert len(result['entries']) == 22

# Generated at 2022-06-22 08:11:40.960796
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    b = SafariBaseIE()
    b._login()

# Generated at 2022-06-22 08:12:57.856730
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('safari:api')

# Generated at 2022-06-22 08:13:02.918614
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'http://techbus.safaribooksonline.com/9780134426365'
    assert(SafariCourseIE._VALID_URL == SafariCourseIE._TESTS[1]['url'])
    assert(SafariCourseIE._TESTS[1]['url'] == SafariCourseIE.suitable(url))

# Generated at 2022-06-22 08:13:04.680904
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert_raises(AttributeError, SafariIE, None)

# Generated at 2022-06-22 08:13:07.609529
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE(SafariBaseIE.ie_key())
    assert safari_api_ie.IE_NAME == 'safari:api'

# Generated at 2022-06-22 08:13:17.251527
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        import http.cookiejar
        FileCookieJar = http.cookiejar.FileCookieJar
    except ImportError:
        import cookielib
        FileCookieJar = cookielib.FileCookieJar

    import os
    import tempfile
    cookie_file = tempfile.NamedTemporaryFile(delete=False)
    cookie_file.write(b"#LWP-Cookies-2.0\n")
    cookie_file.close()

    cookie_jar = FileCookieJar(cookie_file.name)
    try:
        SafariIE("", cookie_jar)
    finally:
        os.remove(cookie_file.name)

# Generated at 2022-06-22 08:13:20.202498
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    Unit test for SafariBaseIE() class constructor
    """

    safari_base_ie = SafariBaseIE()
    if not isinstance(safari_base_ie, object):
        raise AssertionError('SafariBaseIE() class instance is not an object')

# Generated at 2022-06-22 08:13:21.165593
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()

# Generated at 2022-06-22 08:13:27.513055
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import InstanceTest

    InstanceTest(SafariCourseIE).run('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/', {
        'skip': 'Requires safaribooksonline account credentials'
    })

# Generated at 2022-06-22 08:13:33.181688
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE.IE_DESC is not None
    assert SafariBaseIE.IE_NAME is not None
    assert hasattr(SafariBaseIE, '_VALID_URL')
    assert hasattr(SafariBaseIE, '_NETRC_MACHINE')

# Generated at 2022-06-22 08:13:43.408701
# Unit test for constructor of class SafariIE

# Generated at 2022-06-22 08:16:08.947836
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class safari_ie:
        def __init__(self, url):
            self.url = url
            self.smuggled_data = {}

    # Test case 1: Valid url
    url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro'
    sie = SafariIE()
    sie.url = url
    if not sie._VALID_URL.match(url):
        print("Test case 1: Valid url failed: Not a valid URL")
    if sie.info_dict.get('id') != '9780133392838-00_SeriesIntro':
        print("Test case 1: Valid url failed: Wrong video ID")

# Generated at 2022-06-22 08:16:09.921695
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert (SafariApiIE(SafariApiIE.ie_key(), None).is_enabled() == True)

# Generated at 2022-06-22 08:16:12.328654
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # This test just checks if SafariApiIE constructor fails
    # with non-empty, non-string URL
    SafariApiIE(None)



# Generated at 2022-06-22 08:16:21.274114
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    assert ie.IE_NAME == 'safari:api'
    assert ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-22 08:16:29.851750
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from youtube_dl.utils import SearchInfoExtractor

    class DummySafariCourseIE(SafariCourseIE):
        def _real_extract(self, url):
            return

    se = SearchInfoExtractor(
        search_key='id',
        search_title='title',
        search_thumbnail='thumbnail',
        search_q='q',
        ie_key=SafariIE.ie_key(),
        ie=DummySafariCourseIE(),
    )
    se.suitable('http://foo.com')

# Generated at 2022-06-22 08:16:34.266401
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    t_url = 'https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html'
    i_e = SafariApiIE()
    assert(i_e.suitable(t_url))
    assert(i_e.IE_NAME == 'safari:api')
    assert(i_e.IE_DESC == 'safaribooksonline.com online courses')

# Generated at 2022-06-22 08:16:36.047663
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE._VALID_URL == SafariBaseIE._VALID_URL

# Generated at 2022-06-22 08:16:47.511028
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    course_id_test = '9780134664057'
    course_part_test = 'RHCE_Introduction'
    reference_id_test = '9780134664057-RHCE_Introduction'
    login_url = ie._LOGIN_URL
    api_base = ie._API_BASE
    api_format = ie._API_FORMAT

    expected_url = 'https://www.safaribooksonline.com/api/v1/book/' + course_id_test + '/chapter/' + course_part_test + '.' + api_format

    assert ie.suitable(login_url) is False
    assert ie.suitable(api_base) is False
    assert ie.suitable(api_format) is False

# Generated at 2022-06-22 08:16:48.918616
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert "safaribooksonline.com" in SafariIE()._VALID_URL

# Generated at 2022-06-22 08:16:53.228306
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_utils import SearchInfoExtractorTestCase
    # Exercise SafariBaseIE.__init__
    testcase = SearchInfoExtractorTestCase(IE_NAME='safari')
    ie = testcase.ie
    ie._login()
    print('LOGGED_IN: {}'.format(ie.LOGGED_IN))