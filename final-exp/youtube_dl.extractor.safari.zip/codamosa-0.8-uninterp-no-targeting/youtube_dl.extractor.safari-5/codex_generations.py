

# Generated at 2022-06-22 08:08:25.250396
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safaricourse_ie = SafariCourseIE()

# Generated at 2022-06-22 08:08:36.155370
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .common import FakeLoginIE

    # Test case for constructor of class SafariIE
    # Test case if LOGGED_IN is True
    test_ie = SafariIE()
    assert test_ie.LOGGED_IN

    website_url = 'http://www.safaribooksonline.com'
    # Test case if LOGGED_IN is False
    test_ie_fake = FakeLoginIE(website_url)
    test_ie = SafariIE()
    assert not test_ie.LOGGED_IN

    # Test case for login function of class SafariIE
    test_ie = SafariIE()
    login_error = False
    try:
        test_ie._login()
    except Exception:
        login_error = True
    assert not login_error

# Generated at 2022-06-22 08:08:38.253095
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert hasattr(SafariBaseIE, '_login')


# Generated at 2022-06-22 08:08:40.426685
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE().ie_key() == 'Kaltura'

# Generated at 2022-06-22 08:08:52.383590
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE()
    assert obj.IE_NAME == 'safari:course'
    assert obj.LOGGED_IN == False
    assert obj.IE_DESC == 'safaribooksonline.com online courses'
    assert obj._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert obj._API_FORMAT == 'json'
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    assert obj._NETRC_MACHINE == 'safari'
    assert obj._TESTS

# Generated at 2022-06-22 08:09:03.252918
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import sys
    if sys.version_info[0] >= 3:
        raise Exception("Test not implemented on Python 3")

    with open('test/data/test.safariebooksonline.com.login', 'rb') as f:
        data = f.read()
    class TestSafariBaseIE(SafariBaseIE):
        def report_login(self):
            return data

    course = TestSafariBaseIE(SafariCourseIE)._real_extract(
            'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert course
    assert course['_type'] == 'playlist'
    assert course['id'] == '9780133392838'

# Generated at 2022-06-22 08:09:13.796218
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # get an instance of SafariCourseIE
    ie = SafariCourseIE()

    # get the url.
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'

    course_id = ie._match_id(url)

    course_json = ie._download_json(
        '%s/book/%s/?override_format=%s' % (ie._API_BASE, course_id, ie._API_FORMAT),
        course_id, 'Downloading course JSON')

    if 'chapters' not in course_json:
        raise ExtractorError(
            'No chapters found for course %s' % course_id, expected=True)


# Generated at 2022-06-22 08:09:20.090907
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_instance = SafariApiIE('SafariApiIE')
    assert test_instance._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert test_instance._API_FORMAT == 'json'
    assert test_instance._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-22 08:09:26.530336
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()

    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'

    # testing SafariApiIE
    res = ydl.extract_info(url, download=False)
    assert 'webpage_url' in res

# Generated at 2022-06-22 08:09:37.763825
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import xml.etree.ElementTree as ET
    url = 'https://learning.oreilly.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html'
    ie = SafariIE()
    ie.extract(url)

    ie = SafariIE()
    # test xml
    # set the xml that we want to parse
    root = ET.fromstring(
        '<entry><media:group><media:content url="http://www.example.com/video.flv" duration="60"/></media:group></entry>')
    ele = root.find('{http://search.yahoo.com/mrss/}group')
    # convert the xml element to a dictionary
    # this is the format that the helper deal with
    data = {}

# Generated at 2022-06-22 08:10:01.453233
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    def _test_SafariBaseIE(in_sbl_username, in_sbl_password,
                           in_invalid_sbl_username, in_invalid_sbl_password):
        safari = SafariBaseIE()
        safari.to_screen('Testing SafariBaseIE.suitable and _real_initialize')
        safari_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
        if SafariIE.suitable(safari_url):
            safari.to_screen('Extracting with SafariIE')
            safari_result = safari.url_result(safari_url)
            safari.extract(safari_result.url)
        else:
            safari.to

# Generated at 2022-06-22 08:10:04.393087
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    base = SafariBaseIE()
    assert isinstance(base, InfoExtractor)

# Generated at 2022-06-22 08:10:06.633353
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        SafariApiIE(SafariApiIE.ie_key())
    except Exception:
        assert False, 'Unable to construct SafariApiIE object'
    assert True

# Generated at 2022-06-22 08:10:09.065601
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie
    assert not safari_course_ie.LOGGED_IN

# Generated at 2022-06-22 08:10:17.002911
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    a = SafariBaseIE()
    assert a.LOGGED_IN == False
    assert a._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert a._API_FORMAT == 'json'
    assert a._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert a._NETRC_MACHINE == 'safari'
    assert a._VALID_URL == None

# Generated at 2022-06-22 08:10:21.541434
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Create class SafariIE() object
    # It outputs string: 'Create object of type SafariIE'
    v = SafariIE()
    # If SafariIE() object is created successfully
    # Then class SafariIE() has attribute '_VALID_URL'
    assert v._VALID_URL




# Generated at 2022-06-22 08:10:26.167801
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    instance_IE = SafariApiIE()
    print(instance_IE)

# Generated at 2022-06-22 08:10:28.583373
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api = SafariApiIE()
    assert safari_api.ie_key() == 'Safari:api'

# Generated at 2022-06-22 08:10:32.058041
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    extractor = SafariCourseIE()
    assert extractor._match_id(url) == '9781449396459'

# Generated at 2022-06-22 08:10:35.982476
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie.set_username('username')
    ie.set_password('password')
    ie.set_login_info(ie._NETRC_MACHINE, 'username', 'password')

# Generated at 2022-06-22 08:10:57.543975
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False

# Generated at 2022-06-22 08:11:02.958223
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_utils import make_test_IE
    test_IE = make_test_IE('SafariIE')

    def test_login():
        test_IE._login()
        ok = test_IE.LOGGED_IN
        if ok:
            msg = 'Safari login successful'
        else:
            msg = ('Safari login failed, make sure your '
                   '{0} machine has valid credentials'.format(test_IE._NETRC_MACHINE))
        return ok, msg

    assert test_login()[0]

# Generated at 2022-06-22 08:11:04.709047
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('safari:course')

# Generated at 2022-06-22 08:11:09.221711
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_SafariApiIE.SafariApiIE = SafariApiIE
    assert isinstance(SafariApiIE, type)
    assert issubclass(SafariApiIE, InfoExtractor)
    assert issubclass(SafariApiIE, SafariBaseIE)
    test_SafariApiIE.__class__ = type
    return SafariApiIE


# Generated at 2022-06-22 08:11:16.906120
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Testing SafariIE._real_initialize()
    # Test 1: Test case where the login is successful
    ie = SafariIE()
    ie._real_initialize()
    assert ie.LOGGED_IN == True

    # Test 2: Test case where the login is not successful
    ie = SafariIE()
    #ie._login = lambda: ie.to_screen("Error in login")
    ie._real_initialize()
    assert ie.LOGGED_IN is False

# Generated at 2022-06-22 08:11:27.561282
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert inst.suitable('http://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html')
    assert inst.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/ch01.html')
    assert inst.suitable('http://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html')
    assert not inst.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-22 08:11:36.878381
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert hasattr(SafariBaseIE, 'IE_NAME')
    assert hasattr(SafariBaseIE, '_VALID_URL')
    assert hasattr(SafariBaseIE, '_API_BASE')
    assert hasattr(SafariBaseIE, '_API_FORMAT')
    assert hasattr(SafariBaseIE, '_LOGIN_URL')
    assert hasattr(SafariBaseIE, '_NETRC_MACHINE')



# Generated at 2022-06-22 08:11:47.140488
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    # Test construction of class object
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert ie._TESTS[0]['url'] == 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'

# Generated at 2022-06-22 08:11:48.963810
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE("https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html")

# Generated at 2022-06-22 08:11:55.223670
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari = SafariCourseIE(url)
    safari.extract()

# Generated at 2022-06-22 08:12:47.169865
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_urls = [
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json',
        'http://techbus.safaribooksonline.com/9780134426365',
        'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314'
        ]
    for url in test_urls:
        ie = SafariApiIE(url)
        assert ie.IE_NAME == 'safari:api'

# Generated at 2022-06-22 08:12:48.403598
# Unit test for constructor of class SafariIE
def test_SafariIE():
    print(SafariIE.ie_key())


# Generated at 2022-06-22 08:12:49.001314
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE({})

# Generated at 2022-06-22 08:12:50.726937
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    assert isinstance(instance, SafariBaseIE)

# Unit tests for test_SafariCourseIE

# Generated at 2022-06-22 08:12:54.278728
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE._PARTNER_ID == '1926081'
    assert SafariIE._UICONF_ID == '29375172'

# Generated at 2022-06-22 08:12:57.555405
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .kaltura import KalturaIE

    assert issubclass(SafariIE, KalturaIE)
    # TODO check KalturaIE with safaribooksonline account credentials

# Generated at 2022-06-22 08:13:00.162615
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    instance = SafariApiIE()
    expected_IE_NAME = 'safari:api'
    assert instance.IE_NAME == expected_IE_NAME



# Generated at 2022-06-22 08:13:09.923271
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE('SafariBaseIE')
    assert safari_base_ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_base_ie._NETRC_MACHINE == 'safari'

    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base_ie._API_FORMAT == 'json'

    assert safari_base_ie.LOGGED_IN == False

# Generated at 2022-06-22 08:13:11.974369
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert not hasattr(SafariBaseIE(), 'url')

# Generated at 2022-06-22 08:13:20.756639
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .common import video_info
    from .test_kaltura import KalturaIE_test
    safari = KalturaIE_test('Kaltura', SafariIE)
    assert(safari._VALID_URL == r'https?://cdnapisec\.kaltura\.com/html5/html5lib/v2\.37\.1/mwEmbedFrame\.php')
    # Unit test for constructor of class SafariApiIE
    safaria = SafariApiIE('SafariApi', SafariApiIE)

# Generated at 2022-06-22 08:14:30.690812
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'
    instance = SafariApiIE()
    if type(instance) == type:
        instance = instance(url)
    assert(isinstance(instance, SafariApiIE))
    assert(instance.suitable(url))
    assert(not instance.suitable('http://invalid'))
    assert(instance._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\\.html')

# Generated at 2022-06-22 08:14:31.724768
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari.__class__.__name__ == 'SafariBaseIE'

# Generated at 2022-06-22 08:14:36.911368
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ies = [SafariCourseIE()]
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    course_id = '9781449396459'
    test_id = '{0}'.format(course_id)
    assert SafariCourseIE.suitable(url)
    assert ies[0]._match_id(url) == course_id
    assert ies[0]._real_extract(url).playlist_title == 'Learning Python, 5th Edition'


# Generated at 2022-06-22 08:14:38.974820
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_extractor import TestExtractor
    TestExtractor(SafariIE).run(False)


# Generated at 2022-06-22 08:14:45.451697
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(SafariCourseIE.ie_key())
    assert isinstance(ie, SafariBaseIE)
    assert isinstance(hasattr(ie, '_LOGIN_URL'), bool)
    assert isinstance(hasattr(ie, '_NETRC_MACHINE'), bool)
    assert isinstance(hasattr(ie, '_API_BASE'), bool)
    assert isinstance(hasattr(ie, '_API_FORMAT'), bool)

# Generated at 2022-06-22 08:14:54.622247
# Unit test for constructor of class SafariIE
def test_SafariIE():
    mocker, safari_ie = _prepare_test_for_safari_ie(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
        '0_qbqx90ic')

    safari_ie._download_webpage_handle(
        'https://learning.oreilly.com/accounts/login-check/', None,
        'Downloading login page')
    mocker.patch('os.path.exists', return_value=False)

# Generated at 2022-06-22 08:15:05.637503
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..utils import (
        url_basename,
    )
    # Example URL
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part01.html'
    # Obtain course id and part from URL
    mobj = re.match(r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            api/v1/book/
                            (?P<course_id>[^/]+)/
                            chapter/
                            (?P<part>[^/?#&]+)
                        ''', url)
    course_id = mobj.group('course_id')
    part = mobj.group('part')


# Generated at 2022-06-22 08:15:07.565503
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        import cryptography
    except ImportError:
        return

    e = SafariApiIE()
    assert e.IE_NAME == 'safari:api'
    assert e.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-22 08:15:08.189619
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('safaribooksonline')

# Generated at 2022-06-22 08:15:12.113094
# Unit test for constructor of class SafariIE
def test_SafariIE():
    tester = safari = SafariIE()
    assert not safari._LOGIN_URL == ''
    assert not safari._NETRC_MACHINE == ''
    assert not safari._API_BASE == ''

# Generated at 2022-06-22 08:17:56.950002
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie is not None

# Generated at 2022-06-22 08:18:04.426275
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if not SafariBaseIE(None)._login_available():
        return
    # Provided credentials should be invalid
    test_module = type(str('TestModule'), (SafariBaseIE,), {
        '_LOGIN_EMAIL': 'invalid@invalid.com', '_LOGIN_PASSWORD': 'invalid'})
    with test_module.create_ie() as ie:
        assert not ie.LOGGED_IN
        with ie.build_opener() as opener:
            assert not ie._is_logged(opener)