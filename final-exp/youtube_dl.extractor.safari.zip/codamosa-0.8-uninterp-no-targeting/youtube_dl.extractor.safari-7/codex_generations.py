

# Generated at 2022-06-22 08:08:26.942670
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    SafariCourseIE.suitable(url)

# Generated at 2022-06-22 08:08:35.174582
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    def run_test(url, course_id, course_title):
        course = SafariCourseIE(SafariCourseIE.suitable)
        course.initialize()
        course.extract(url)
        assert course_id == course._course_id
        assert course_title == course._course_title

    run_test(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/',
        '9780133392838',
        'Hadoop Fundamentals LiveLessons'
    )

# Generated at 2022-06-22 08:08:36.289421
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert obj._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-22 08:08:38.361177
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    temp = SafariBaseIE('The user', 'The pass')
    temp._login()

# Generated at 2022-06-22 08:08:40.531382
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert hasattr(SafariApiIE(), '_login')

# Generated at 2022-06-22 08:08:44.619189
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    SafariIE.suitable(url)
    SafariIE().extract(url)


# Generated at 2022-06-22 08:08:46.885427
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Tests constructor of SafariIE
    test_obj = SafariIE()
    assert isinstance(test_obj, SafariIE)

# Generated at 2022-06-22 08:08:57.173298
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert(safari.IE_NAME == 'safari')
    assert(safari.IE_DESC == 'safaribooksonline.com online video')
    assert(safari._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    ''')

# Generated at 2022-06-22 08:09:07.430020
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        SafariIE('http://www.safaribooksonline.com/library/view/javascript-web-applications/9781449340194/part00.html')
    except:
        assert True
    else:
        assert False
    try:
        SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    except:
        assert False
    else:
        assert True
    try:
        SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-22 08:09:09.841195
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    assert SafariCourseIE.suitable(url) == True

# Generated at 2022-06-22 08:09:32.194958
# Unit test for constructor of class SafariIE
def test_SafariIE():

    web_content = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    webpage, urlh = test_SafariIE._download_webpage_handle(web_content, None,
        'Downloading login page')

    web_content = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    m = re.match(SafariIE._VALID_URL, web_content)
    video_id = '%s-%s' % (m.group('course_id'), m.group('part'))
    webpage, urlh = test_SafariIE._download_web

# Generated at 2022-06-22 08:09:35.320856
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE("https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html").extract()

# Generated at 2022-06-22 08:09:42.014797
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_inputs = ['https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838']
    expected_outputs = [{
        'id': '9780133392838',
        'title': 'Hadoop Fundamentals LiveLessons'
    }]
    for test_input, expected_output in zip(test_inputs, expected_outputs):
        real_output = SafariIE._real_extract(SafariIE(), test_input)
        assert real_output['id'] == expected_output['id']
        assert real_output['title'] == expected_output['title']

# Generated at 2022-06-22 08:09:44.760847
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_class = SafariApiIE
    safari_class_instance = safari_class()
    assert(safari_class_instance.ie_key() == 'Safari')

# Generated at 2022-06-22 08:09:50.733887
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test the constructor of SafariBaseIE
    #
    # @todo #583:30min Test all methods of SafariBaseIE
    safari_base_ie = SafariBaseIE()

    # Test the method validate_url
    url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
    assert safari_base_ie._VALID_URL == SafariBaseIE._VALID_URL
    assert re.match(SafariBaseIE._VALID_URL, url)
    assert re.match(SafariBaseIE._VALID_URL, url)

# Generated at 2022-06-22 08:09:54.239997
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # pylint: disable=no-value-for-parameter
    safari = SafariApiIE()
    # pylint: enable=no-value-for-parameter
test_SafariApiIE()

# Generated at 2022-06-22 08:10:01.879922
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')

# Generated at 2022-06-22 08:10:05.307854
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('safari:api')
    assert ie.SUFFIX == '.html'

# Generated at 2022-06-22 08:10:10.613300
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    d = {'username': 'foo', 'password': 'bar', 'mssso': 'true'}
    url = 'https://learning.oreilly.com/accounts/login/'
    assert(ie.get_form_hidden_inputs(url, d) == {'username': 'foo', 'password': 'bar', 'mssso': 'true'})

# Generated at 2022-06-22 08:10:19.164183
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    assert SafariApiIE._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-22 08:10:43.332324
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # No credentials specified
    ie = SafariIE()
    assert ie.LOGGED_IN is False
    # Credentials are specified
    ie = SafariIE(username='user', password='pass')
    assert ie.LOGGED_IN is True

# Generated at 2022-06-22 08:10:52.421922
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # test for correct class name
    safari_ie = SafariApiIE('Safari IE')
    assert(safari_ie.__class__.__name__ == 'SafariApiIE')
    assert(isinstance(safari_ie, SafariBaseIE))
    assert(isinstance(safari_ie, InfoExtractor))
    # test for correct id
    assert(safari_ie._VALID_URL == SafariApiIE._VALID_URL)
    # test for correct _LOGIN_URL
    assert(safari_ie._LOGIN_URL == SafariApiIE._LOGIN_URL)

# Generated at 2022-06-22 08:10:53.703353
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Kaltura')

# Generated at 2022-06-22 08:10:58.241189
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safaribooks import _PASSWORD, _USERNAME
    from ..test import get_testcases

    ie = SafariApiIE(get_testcases(_USERNAME, _PASSWORD))

    assert ie.username == _USERNAME
    assert ie.password == _PASSWORD
    assert ie.LOGGED_IN == True

# Generated at 2022-06-22 08:11:00.443380
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    try:
        instance.logged_in
    except:
        pass
    try:
        instance.login()
    except:
        pass

# Generated at 2022-06-22 08:11:04.451925
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('Safari')._login()

# Generated at 2022-06-22 08:11:12.966883
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses' 
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie.LOGGED_IN == False

# Generated at 2022-06-22 08:11:17.127837
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('SafariApiIE', 'http://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html')

# Generated at 2022-06-22 08:11:20.055258
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        SafariBaseIE()
    except TypeError as e:
        assert e.args[0] == '__init__() takes at least 3 arguments (2 given)'



# Generated at 2022-06-22 08:11:21.953452
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_utils import TestSafariCourseIE
    TestSafariCourseIE('SafariCourseIE').test()

# Generated at 2022-06-22 08:11:44.326482
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html/')
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False
    assert ie._PARTNER_ID == '1926081'
    assert ie._UICONF_ID == '29375172'

# Generated at 2022-06-22 08:11:52.466448
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    course_id = '9780133392838'
    course_part = 'part00.html'
    course_url_json = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s' % (course_id, course_part)
    course_json = ie._download_json(course_url_json, '%s/%s' % (course_id, course_part), 'Downloading part JSON')
    assert course_json['web_url'] == 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

# Generated at 2022-06-22 08:12:00.303231
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    url_result = SafariCourseIE()._real_extract(url)
    assert url_result.get("id") == "9781449396459"
    assert url_result.get("entries") == [SafariCourseIE().url_result("https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html", "safari")]

# Generated at 2022-06-22 08:12:05.287315
# Unit test for constructor of class SafariIE
def test_SafariIE():
    '''
    Test case for constructor of class SafariIE
    '''
    SafariIE("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html")

# Generated at 2022-06-22 08:12:06.510791
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-22 08:12:12.110912
# Unit test for constructor of class SafariIE
def test_SafariIE():
    if (__name__ == '__main__') :
        course_json = '{"chapters": [{"url": "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"}]}'
        course_json = json.loads(course_json)
        course_json = json.dumps(course_json)
        print(course_json.find('chapters'))
        print(Json_loading(course_json))
        print(type(Json_loading(course_json)))
        print(type(Json_loading(course_json)['chapters']))
        print(type(Json_loading(course_json)['chapters'][0]))

# Generated at 2022-06-22 08:12:13.985212
# Unit test for constructor of class SafariIE
def test_SafariIE():

    s = SafariIE()
    #assert isinstance(s, SafariIE)


if __name__ == "__main__":
    test_SafariIE()

# Generated at 2022-06-22 08:12:21.025882
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._VALID_URL == SafariIE._VALID_URL
    assert ie._NETRC_MACHINE == SafariIE._NETRC_MACHINE
    assert ie._LOGIN_URL == SafariIE._LOGIN_URL
    assert ie.IE_NAME == SafariIE.IE_NAME
    assert ie.IE_DESC == SafariIE.IE_DESC
    assert ie._TESTS == SafariIE._TESTS
    assert ie._PARTNER_ID == SafariIE._PARTNER_ID
    assert ie._UICONF_ID == SafariIE._UICONF_ID


# Generated at 2022-06-22 08:12:23.620576
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE('SafariIE', 'safari')
    assert obj.name == 'SafariIE'
    assert obj.ie_key() == 'SafariIE'

# Generated at 2022-06-22 08:12:31.653029
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE("SafariIE")
    assert safari_ie._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-22 08:13:13.761086
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test login with dummy input
    # This is not a real test since it doesn't return any error
    # but it is better than doing nothing
    safari = SafariBaseIE(None)
    safari.username = 'test'
    safari.password = 'test'
    safari._real_initialize()

# Generated at 2022-06-22 08:13:20.874334
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    safaribooksonline_ie = SafariApiIE(SafariApiIE._downloader, url)

    assert safaribooksonline_ie.IE_NAME == 'safari:api'
    assert safaribooksonline_ie.IE_DESC == 'safaribooksonline.com online videos'
    assert safaribooksonline_ie._VALID_URL == '.*?/api/v1/book/(?P<course_id>[^/]+)'


# Generated at 2022-06-22 08:13:32.172160
# Unit test for constructor of class SafariIE

# Generated at 2022-06-22 08:13:38.598826
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Tests in SafariCourseIE constructor."""
    instance = SafariCourseIE('SafariCourseIE', 'safaribooksonline.com', 'http://test.com')
    assert instance.ie_key() == 'SafariCourseIE'
    assert instance.ie_desc == 'safaribooksonline.com online courses'
    assert instance._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert instance._API_FORMAT == 'json'

# Generated at 2022-06-22 08:13:43.110992
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'


# Generated at 2022-06-22 08:13:50.412948
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365') and \
        not SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

# Generated at 2022-06-22 08:14:01.526585
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    with open('test/data/safari-login') as infile:
        json_data = json.load(infile)
    safari_base_ie = SafariBaseIE()

    def _download_json_handle(url, video_id, note, fatal, query={}, data='', headers={}, expected_status=None):
        query = query.encode() if query else query
        url = url + '?' + query
        if url == 'https://learning.oreilly.com/accounts/login-check/':
            return json_data, None
        return None, None

    safari_base_ie._download_json_handle = _download_json_handle
    safari_base_ie._real_initialize()

    assert safari_base_ie.LOGGED_IN == True

# Generated at 2022-06-22 08:14:12.001715
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # test for safaribooksonline
    api_base = 'https://learning.oreilly.com/api/v1'
    valid_url = 'https://www.safaribooksonline.com/library/view/title/9780133392838/part00.html'

    obj = SafariBaseIE()
    mobj = re.match(obj._VALID_URL, valid_url)
    course_id = mobj.group('course_id')
    part = mobj.group('part')
    video_id = '%s-%s' % (course_id, part)

    obj._download_webpage = lambda *args, **kwargs: args[1]

# Generated at 2022-06-22 08:14:13.425290
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert(SafariCourseIE)

# Generated at 2022-06-22 08:14:23.852601
# Unit test for constructor of class SafariIE
def test_SafariIE():
    inst = SafariIE("id", "http://url")
    assert inst.name == "safari"
    assert inst.description == "safaribooksonline.com online video"
    assert inst.valid_url_regex == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?#&]+).html|videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?#&]+))'
    assert inst.valid_url_regex == inst.ie_key()

# Generated at 2022-06-22 08:15:03.200652
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    with open('test/testdata/safaribooksonline.com/login', 'rb') as f:
        login_page = f.read()

    with open('test/testdata/safaribooksonline.com/kaltura_session', 'rb') as f:
        kaltura_session = f.read()

    with open('test/testdata/safaribooksonline.com/library', 'rb') as f:
        library_page = f.read()

    login_mock = mocker.Mocker()
    login_mock.get(SafariBaseIE._LOGIN_URL, login_page)
    login_mock.post('https://api.oreilly.com/member/auth/login/', kaltura_session)

# Generated at 2022-06-22 08:15:11.335713
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-22 08:15:14.465607
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert inst is not None
    assert inst.IE_NAME == 'safari:api'
    assert inst._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'


# Generated at 2022-06-22 08:15:16.319685
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    print("Testing SafariApiIE()")
    ie = SafariApiIE()
    assert(isinstance(ie, SafariApiIE))
    assert(isinstance(ie, SafariBaseIE))
    print("Successfully tested SafariApiIE()")


# Generated at 2022-06-22 08:15:19.236750
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    s = SafariCourseIE()
    
    assert (not s.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'))
    assert (not s.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/RHCE_Introduction.html'))

# Generated at 2022-06-22 08:15:20.332917
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()



# Generated at 2022-06-22 08:15:31.287311
# Unit test for constructor of class SafariIE

# Generated at 2022-06-22 08:15:34.912597
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # SafariBaseIE needs a url to work with but none of the existing IEs match
    # the url we pick
    SafariBaseIE._download_webpage_handle(
        'http://techbus.safaribooksonline.com/9780134426365', None,
        'Downloading login page')

# Generated at 2022-06-22 08:15:36.607714
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Test that the SafariBaseIE constructor raises an error if no credentials were found."""
    try:
        SafariBaseIE()
    except ExtractorError:
        pass
    else:
        raise Exception('Expected an error due to missing credentials')

# Generated at 2022-06-22 08:15:41.520357
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    c = SafariCourseIE([url])
    assert isinstance(c, SafariCourseIE)

# Generated at 2022-06-22 08:17:20.100507
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    The SafariCourseIE constructor will raise an exception if the
    python3 `json` module is not available.
    """
    # pylint: disable=W0612
    # Access to a protected member of a client class
    try:
        import json
        # pylint: disable=W0212
        # Access to a protected member of a client class
        safari = SafariCourseIE._SafariCourseIE()
        assert(safari is not None)
    except ImportError as e:
        assert(str(e) == "No module named 'json'")
    # pylint: enable=W0612

# Generated at 2022-06-22 08:17:23.979120
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    username = 'foousername'
    password = 'foopassword'
    ie = SafariBaseIE(username=username, password=password)
    assert ie.username == username
    assert ie.password == password

# Generated at 2022-06-22 08:17:33.932225
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    IE = SafariBaseIE()
    assert IE.LOGGED_IN == False
    assert IE._NETRC_MACHINE == 'safari'
    assert IE._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert IE._API_FORMAT == 'json'
    assert IE.IE_NAME == 'SafariBase'
    assert IE.IE_DESC == 'safaribooksonline.com video'
    assert IE._VALID_URL == None
    assert IE._TESTS == None
    assert IE._PARTNER_ID == None
    assert IE._UICONF_ID == None

# Generated at 2022-06-22 08:17:44.635492
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test case 1
    #############
    # No username and password
    # The constructor will neither authenticate nor verify.
    # Real IEs do not raise an exception.
    safari_api_IE = SafariApiIE(None)

    # Unit test for login of class SafariApiIE with no username and password
    ########################################################################
    # The logged_in attribute must be false
    assert not safari_api_IE.LOGGED_IN

    # Test case 2
    #############
    # Username is set but password is empty
    # The constructor will neither authenticate nor verify.
    # Real IEs do not raise an exception.
    safari_api_IE = SafariApiIE(None, None, None, None, 'username')

    # Unit test for login of class SafariApiIE with username but empty password
   

# Generated at 2022-06-22 08:17:52.166032
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    import xml.etree.ElementTree as ElementTree

    safari_ie = SafariIE()
    assert(safari_ie is not None)

    def test_safari_ie_get_instance():
        assert(SafariIE() is not None)

    ##@unittest.skip("Skipping tests for SafariIE")
    class TestSafariIE(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            unittest.TestCase.__init__(self, *args, **kwargs)
            self.credentials = None

# Generated at 2022-06-22 08:17:53.128776
# Unit test for constructor of class SafariIE
def test_SafariIE():
    pass

# Generated at 2022-06-22 08:17:56.650198
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False
    safari_ie._login()
    assert safari_ie.LOGGED_IN == True

# Generated at 2022-06-22 08:18:01.462308
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    ie = SafariApiIE()
    assert ie.suitable(url)
    assert ie.suitable(url.replace('api/v1/book', 'videos/python-programming-language'))
