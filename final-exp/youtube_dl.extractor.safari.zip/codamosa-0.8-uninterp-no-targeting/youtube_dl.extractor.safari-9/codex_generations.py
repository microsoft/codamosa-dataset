

# Generated at 2022-06-22 08:08:23.557150
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-22 08:08:32.641935
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import BaseTestSafari

    class TestSafariApiIE(BaseTestSafari, object):
        IE = SafariApiIE

        def _test_playlist_result(self, entries, playlist_id, playlist_title):
            self.assertEqual(playlist_id, '9780133392838')
            self.assertEqual(playlist_title, 'Hadoop Fundamentals LiveLessons')
            self.assertEqual(len(entries), 22)

    return [
        TestSafariApiIE(),
    ]

# Generated at 2022-06-22 08:08:38.415881
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariApiIE = SafariApiIE()
    assert safariApiIE._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    

# Generated at 2022-06-22 08:08:42.821169
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from . import _get_testcases_for_extractor
    from .common import _TESTCASES, ClientForm

    # Unit test for login
    test_cases = _get_testcases_for_extractor(SafariBaseIE)
    for test_case in test_cases:
        # If a testcase doesn't have IE_NAME, it is not implemented yet
        if hasattr(test_case, 'IE_NAME'):
            if test_case.IE_NAME != 'safari':
                continue

            safari = test_case()
            safari.IE_NAME = 'safari'
            safari.IE_DESC = 'safaribooksonline.com online video'
            safari._LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
            safari._NET

# Generated at 2022-06-22 08:08:45.445120
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        SafariApiIE(SafariBaseIE)
    except Exception:
        pass

# Generated at 2022-06-22 08:08:47.371007
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE(), SafariBaseIE)

# Generated at 2022-06-22 08:08:51.546610
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .. import safari

    safari.SafariBaseIE._login = lambda x: None
    safari.SafariBaseIE.LOGGED_IN = True

    assert('SafariApi' in globals())

# Generated at 2022-06-22 08:08:55.978080
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url_quality = 'https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html'
    course = SafariIE()
    safari = course.extract(url_quality)
    print(safari)


# Generated at 2022-06-22 08:09:00.989429
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()

    # Neither of the following functions returns True
    #  assert SafariIE.suitable(url)
    #  assert SafariApiIE.suitable(url)

    assert False if SafariIE.suitable(url) or SafariApiIE.suitable(url) else True

# Generated at 2022-06-22 08:09:12.206210
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
  course_id = '9780133392838'
  part_id = 'part00'
  reference_id = '9780133392838-00_SeriesIntro'
  url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/%s/%s.html' % (course_id, part_id)
  safari_ie = SafariIE()
  info = safari_ie._real_extract(url)
  assert('kaltura.com' in info['url'])
  assert(info['id'] == '%s-%s' % (reference_id, '0_qbqx90ic'))
  assert(info['title'] == 'Introduction to Hadoop Fundamentals LiveLessons')

# Generated at 2022-06-22 08:09:36.953802
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    _safari_course_ie_init_re = re.compile(r'^url: https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:api/v1/book|videos?|library/view)/[^/]+$')

    import inspect
    import sys
    import unittest

    class SafariCourseIETests(unittest.TestCase):
        IE = SafariCourseIE

        class ConstructorTest(unittest.TestCase):
            def test_has_safari_course_ie_init(self):
                self.assertTrue(_safari_course_ie_init_re.match(inspect.getsource(self.IE.__init__)))

# Generated at 2022-06-22 08:09:42.739402
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-22 08:09:46.297540
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Check that SafariCourseIE can be instantiated."""
    SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-22 08:09:50.294004
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():

    i = SafariApiIE("https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html")
    i.LOGGED_IN = True
    assert i._real_extract("https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html")

# Generated at 2022-06-22 08:09:51.595697
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    #TODO: Remove this once we are able to instantiate SafariBaseIE
    pass

# Generated at 2022-06-22 08:09:57.038925
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # type: () -> None
    """Test constructor of class SafariCourseIE"""
    import pytest

    with pytest.raises(Exception):
        SafariCourseIE('INVALID_URL')

    SafariCourseIE('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')



# Generated at 2022-06-22 08:09:57.778136
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-22 08:10:02.355731
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE

    # safari:course url is not matched
    assert safari.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838') == False

    # safari:api url is not matched
    assert safari.suitable('https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html') == False

    # safari url is not matched
    assert safari.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html') == False

    # common url is matched

# Generated at 2022-06-22 08:10:05.215232
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE._NETRC_MACHINE == 'safari'

# Generated at 2022-06-22 08:10:17.532584
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-22 08:10:48.879406
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import urllib
    import unittest
    
    class TestSafariCourseIE(unittest.TestCase):
        
        def test_constructor_existing_urls(self):
            url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
            extracted_url = SafariCourseIE.extract_url(url)
            self.assertEqual(extracted_url, url)

        def test_constructor_non_existing_urls(self):
            url = 'http://techbus.safaribooksonline.com/9780134426365'
            extracted_url = SafariCourseIE.extract_url(url)
            self.assertEqual(extracted_url, url)

    unittest.main()

# Generated at 2022-06-22 08:10:51.577112
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # This test is needed to ensure SafariBaseIE class is created without errors
    ydl = SafariBaseIE()

# Generated at 2022-06-22 08:10:54.892828
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # should not raise any exceptions
    SafariCourseIE("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/")

# Generated at 2022-06-22 08:10:55.957350
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE()


# Generated at 2022-06-22 08:11:07.073483
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    oe = SafariBaseIE('')
    assert oe.IE_NAME == 'safari'
    assert oe.IE_DESC == 'safaribooksonline.com online video'
    assert oe.LOGGED_IN == False
    assert oe._NETRC_MACHINE == 'safari'

# Generated at 2022-06-22 08:11:12.587668
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    sbie = SafariBaseIE()
    sbie._LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
    sbie._NETRC_MACHINE = 'safari'
    sbie._API_BASE = 'https://learning.oreilly.com/api/v1'
    sbie._API_FORMAT = 'json'

# Generated at 2022-06-22 08:11:15.775627
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Test the constructor of class SafariApiIE."""

    # Simply call the constructor of class SafariApiIE
    SafariApiIE()

# Generated at 2022-06-22 08:11:17.511733
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    b = SafariApiIE
    assert b  # silence warning

# Generated at 2022-06-22 08:11:21.195457
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class ConcreteClass(SafariBaseIE):
        pass

    # no exception should be raised
    ConcreteClass()

# Generated at 2022-06-22 08:11:22.979024
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    game = SafariBaseIE('', {'username': 'jsmith', 'password': 'secret'})
    game._login()

# Generated at 2022-06-22 08:11:59.417050
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = SafariCourseIE._VALID_URL
    m = re.match(url, 'https://learning.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert m.group('id') == '9780133392838'
    m = re.match(url, 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert m.group('id') == '9781449396459'

# Generated at 2022-06-22 08:12:06.682833
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part01.html?override_format=json'
    result = SafariApiIE._build_url_result(url)
    assert result.url == 'https://www.safaribooksonline.com/library/view/reading-json-data/9781449396459/part01.html'

# Generated at 2022-06-22 08:12:12.041855
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test for constructor of class SafariCourseIE"""
    course_id = SafariCourseIE._match_id('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert(course_id == '9781449396459')
    course_json = SafariCourseIE._download_json('https://www.safaribooksonline.com/api/v1/book/' + course_id + '/?override_format=json', course_id, 'Downloading course JSON', 'Unable to download course JSON')
    assert(course_json['title'] == 'Database Design for Mere Mortals: A Hands-On Guide to Relational Database Design')
    assert(len(course_json['chapters']) == 21)

# Generated at 2022-06-22 08:12:19.886850
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course_id = SafariCourseIE._match_id(url)
    course_json = SafariCourseIE._download_json(
            '%s/book/%s/?override_format=%s' % (SafariCourseIE._API_BASE, course_id, SafariCourseIE._API_FORMAT),
        course_id, 'Downloading course JSON')
    SafariCourseIE._real_extract(url)

# Generated at 2022-06-22 08:12:24.951906
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # We can't really test against safaribooksonline.com
    # unless we have a premium subscription
    # so this test is a bit bogus
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    ie = SafariCourseIE()
    result = ie.suitable(url)
    assert result == True
    ie = SafariCourseIE()
    ie.extract(url)



# Generated at 2022-06-22 08:12:30.343516
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        from .test_safariapp import SafariAppTestCase
    except ImportError as e:
        raise ImportError('To run safariapp unittests, you have to install pycryptodome.') from e

    class DummySafariApiIE(SafariApiIE):
        @staticmethod
        def _test_suite():
            return True

    dummy_safariapi_ie = DummySafariApiIE()
    SafariAppTestCase.safariapp_test_not(dummy_safariapi_ie)

# Generated at 2022-06-22 08:12:32.992282
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    instance = ie.get_info_extractor('Unknown URL')
    assert isinstance(instance, SafariIE)

# Generated at 2022-06-22 08:12:35.430914
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE()._login_info() == (None, None)

# Generated at 2022-06-22 08:12:36.809687
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Smoke test for SafariApiIE
    safari_api_ie = SafariApiIE()

# Generated at 2022-06-22 08:12:47.973537
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from ..test.test_extractors import run_test
    url, ie = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/', \
         SafariCourseIE()
    assert ie is not None, 'SafariCourseIE is broken'
    assert ie._VALID_URL == SafariCourseIE._VALID_URL, 'SafariCourseIE._VALID_URL is broken'
    assert ie.IE_NAME == SafariCourseIE.IE_NAME, 'SafariCourseIE.IE_NAME is broken'
    assert ie.IE_DESC == SafariCourseIE.IE_DESC, 'SafariCourseIE.IE_DESC is broken'

# Generated at 2022-06-22 08:14:05.257733
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('fake-user', 'fake-password')

# Generated at 2022-06-22 08:14:07.215174
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari._NETRC_MACHINE == 'safari'

# Generated at 2022-06-22 08:14:16.274726
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'

    # Create the IE
    ie = SafariCourseIE(test_url)

    # Test the match()
    if not ie.suitable(test_url):
        raise ValueError('URL %s does not match SafariCourseIE' % test_url)

    # Test the extract()
    entries = ie.extract(test_url, True)

    # Get all the urls
    entry_urls = [e['url'] for e in entries]
    if len(entry_urls) < 1:
        raise ValueError('There must be at least 1 url')

# Generated at 2022-06-22 08:14:22.564160
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
    courseIE = SafariCourseIE(TestSafariBaseIE())
    courseIE.ie_key()
    courseIE._match_id(url)
    courseIE._real_extract(url)

# Generated at 2022-06-22 08:14:25.393089
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test for constructor of class SafariCourseIE
    """
    course = SafariCourseIE()
    assert course is not None

# Generated at 2022-06-22 08:14:33.005666
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    d = {
        'type': 'url',
        'url': 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html',
        'ie_key': 'Safari',
        'id': '9781449396459/part00.html',
    }

    s = SafariApiIE() # construct object of class SafariApiIE

    assert(s.suitable(d['url'])) # test method suitable of class SafariApiIE
    assert(s._VALID_URL and s._TESTS)

# Generated at 2022-06-22 08:14:38.760168
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import InfoExtractor
    from .test_common_test import _TEST_TESTS
    from .utils import ExtractorError
    from .compat import _DBUS_AVAILABLE


    # Does not load the whole test suite to avoid unnecessary requests
    _TEST_TESTS = _TEST_TESTS[:1]
    try:
        del InfoExtractor._ALL_CLASSES['SafariCourseIE']
    except KeyError:
        pass
    InfoExtractor._ALL_CLASSES['SafariCourseIE'] = SafariCourseIE

    # Tests that require display

# Generated at 2022-06-22 08:14:49.035667
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url_test = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    ie = SafariApiIE()
    assert ie._match_id(url_test) == '9781449396459'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-22 08:14:49.930438
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()

# Generated at 2022-06-22 08:15:02.627191
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..utils import parse_duration
    from .brigade import BrigadeBaseIE

    class DummySafariBaseIE(SafariBaseIE):
        def _real_initialize(self):
            self.to_screen('Downloading webpage')

    class DummyExtractor(DummySafariBaseIE):
        IE_NAME = 'Dummy'
        IE_DESC = 'Dummy test'
        _VALID_URL = r'https?://test\.com/test/(?P<id>[^/]+)/(?P<part>[^/?#&]+)\.html'