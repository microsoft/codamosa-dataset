

# Generated at 2022-06-22 08:08:36.118210
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import HEADRequest
    from .kaltura import KalturaIE
    # Test for the ability to extract playable SafariApiIE urls
    # from a Safari website
    safari_api_url = (SafariApiIE._VALID_URL.replace(
        'https?:\\/\\/', 'https://').replace(
        '\\/', '/').replace('?', '\\?'))
    webpage = '<html><head></head><body><a href="{0}"></a></body></html>'.format(safari_api_url)
    url_obj = compat_urlparse.urlparse(safari_api_url)
    url_request = HEADRequest(url_obj.geturl(), None, None)
    course_id = '9781137534343'
    part = 'part00.html'

# Generated at 2022-06-22 08:08:40.888158
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_url = 'http://techbus.safaribooksonline.com/9780134426365'
    test_obj = SafariCourseIE(test_url, {})
    assert test_obj.IE_NAME == 'safari:course'

# Generated at 2022-06-22 08:08:47.756460
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_SafariIE = SafariIE('SafariIE', 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838')

    assert test_SafariIE.partner_code == '1926081'
    assert test_SafariIE.ui_conf_id == '29375172'

# Generated at 2022-06-22 08:08:48.940933
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE("SafariBaseIE")

# Generated at 2022-06-22 08:08:55.553041
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    i = SafariApiIE()
    assert re.match(r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/[^/]+/chapter(?:-content)?/[^/?#&]+\.html', i._VALID_URL)
    assert i.IE_NAME == 'safari:api'
    assert i.IE_DESC

# Generated at 2022-06-22 08:08:58.324124
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN == False

# Generated at 2022-06-22 08:09:00.431419
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()  # Constructor test

# vim:ts=4:sw=4:et:

# Generated at 2022-06-22 08:09:11.331280
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    instance = SafariApiIE()
    for case in ['https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json', 
    'http://techbus.safaribooksonline.com/9780134426365', 'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314', 
    'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838', 'https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/']:
        assert instance.suitable(case)


# Generated at 2022-06-22 08:09:12.390270
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('username', 'password')

# Generated at 2022-06-22 08:09:13.301378
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE()

# Generated at 2022-06-22 08:09:41.267916
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if not _LOGIN_API_KEY:
        raise Exception('Missing OPI key')

    safari_base_ie = SafariBaseIE(None)

    # Login to account
    safari_base_ie._login()

    assert safari_base_ie.LOGGED_IN == True

# Setup test fixtures
test_SafariBaseIE()

# Generated at 2022-06-22 08:09:42.738438
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE(True, None)
    ie.suitable(None)

# Generated at 2022-06-22 08:09:44.665782
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        SafariCourseIE('SafariCourseIE')
    except Exception as ex:
        raise ex

# Generated at 2022-06-22 08:09:52.174797
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Successful login
    SafariBaseIE._download_webpage = lambda ie, url, video_id, note, errnote: (
        # login page
        '<form class="form-signin"',

        # redirect page
        'https://learning.oreilly.com/accounts/login-check/?next=%2Fhome%2F')

# Generated at 2022-06-22 08:10:02.755492
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert(SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'))
    assert(SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'))
    assert(SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365'))
    assert(SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314'))

# Generated at 2022-06-22 08:10:10.123600
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE("http://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html")
    ie2 = SafariIE("http://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html", "username", "password")
    if ie2:
        print("success")
    else:
        print("fail")


# Generated at 2022-06-22 08:10:12.207250
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Be sure that the constructor does not raise an exception
    obj = SafariApiIE()

# Generated at 2022-06-22 08:10:16.307468
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Unit test for constructor of class SafariIE"""
    SafariIE("https://www.safaribooksonline.com/library/view/mastering-puppet-3rd/9781783984024/part00.html")

# Generated at 2022-06-22 08:10:17.755633
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE(None)
    assert ie.name == 'safari:course'
    assert ie.description == 'safaribooksonline.com online courses'

# Generated at 2022-06-22 08:10:20.229738
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test.test_safe_ie import test_SafariCourseIE
    test_SafariCourseIE('safari:course')

# Generated at 2022-06-22 08:10:58.124211
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()


# Generated at 2022-06-22 08:11:05.029295
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_common import src

    import json
    import shutil
    import tempfile
    import os

    try:
        # Create a temp directory
        tdir = tempfile.mkdtemp(prefix='youtubedl-')

        # Get json containing URLs
        json_dir = os.path.join(os.path.split(src)[0],"_test_data/safaribooksonline/json")

        # Copy json to temporary directory
        shutil.copy(json_dir, tdir)

    except Exception as err:
        print("ERROR: "+str(err))

    finally:
        pass

    # Extract URLs from json
    with open(tdir, 'r') as fp:
        json_data = json.load(fp)

    for item in json_data['chapters']:
        url = item

# Generated at 2022-06-22 08:11:07.641069
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('safari:course')
    assert course.IE_NAME == 'safari:course'
    assert course.ie_key() == 'SafariCourse'


# Generated at 2022-06-22 08:11:08.392368
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-22 08:11:19.167051
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_api import TestApi
    t = TestApi()

    # Test valid url
    url = "https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html"
    t.test_url(url, SafariApiIE.suitable(url))

    #Test invalid url
    url = url + "?foo=bar"
    assert not SafariApiIE.suitable(url)

    # Test valid url
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    assert SafariApiIE.suitable(url)

# Generated at 2022-06-22 08:11:29.231182
# Unit test for constructor of class SafariIE
def test_SafariIE():
    if __name__ == '__main__':
        print(SafariIE()._VALID_URL)
    else:
        print(SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'))
        print(SafariIE.suitable('https://techbus.safaribooksonline.com/9780134426365'))
        print(SafariIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314'))

# Generated at 2022-06-22 08:11:41.790406
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    course_id = '9780133392838'
    hidden_course_id = '9781491931953'

    parser = SafariBaseIE._create_parser()
    (options, args) = parser.parse_args()

    ie = SafariCourseIE(parser=parser)
    ie.to_screen('Starting test SafariCourseIE')

    def test_safari_api_course(login):
        ie.login = login
        entries = ie.extract('%s/api/v1/book/%s/?override_format=json' % (SafariBaseIE._API_BASE, course_id))
        return entries

    entries = test_safari_api_course(False)

# Generated at 2022-06-22 08:11:46.910281
# Unit test for constructor of class SafariIE
def test_SafariIE():
    info_extractor = SafariIE()
    print(info_extractor.IE_DESC)

# Generated at 2022-06-22 08:11:48.220436
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._real_initialize()

# Generated at 2022-06-22 08:11:54.420307
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    '''
    If we need to test the constructor of the class SafariApiIE, we can
    directly test it because it isn't private in the old code.
    '''
    assert SafariApiIE('url_result') == SafariApiIE('url_result')


# Generated at 2022-06-22 08:13:14.108069
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    assert ie._VALID_URL == 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-22 08:13:16.123360
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE(None)

    assert 'username' in obj
    assert 'password' in obj


# Generated at 2022-06-22 08:13:18.336119
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    # Test the constructor for the SafariIE object.
    # The constructor should not execute any code.
    assert(safari_ie is not None)

# Generated at 2022-06-22 08:13:24.327592
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test: fail to extract course_id from URL (by providing invalid URL)
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.htm'
    with pytest.raises(RegexNotFoundError):
        SafariIE(url=url)

    # Test: fail to extract course_id from URL (by providing bad course_id value)
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838-e4e4/part00.html'
    with pytest.raises(RegexNotFoundError):
        SafariIE(url=url)

    # Test: fail to extract course_id from URL (

# Generated at 2022-06-22 08:13:26.624648
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    shared = SafariBaseIE()
    assert shared is not None

# Generated at 2022-06-22 08:13:34.471942
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        IE_NAME = 'safari:test:base'
        _VALID_URL = r'TestSafariBaseIE'
        _LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
        _NETRC_MACHINE = 'safari'
    ie = TestSafariBaseIE()
    ie._real_initialize()

# Generated at 2022-06-22 08:13:35.099113
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass

# Generated at 2022-06-22 08:13:36.528330
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE(SafariApiIE.ie_key())

# Generated at 2022-06-22 08:13:38.740163
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE({})
    assert obj.IE_DESC is not None, 'Must be an instance of InfoExtractor'

# Generated at 2022-06-22 08:13:42.898710
# Unit test for constructor of class SafariIE
def test_SafariIE():
	assert('SafariIE' == SafariIE.__name__)
	assert('SafariBaseIE' == SafariIE.__bases__[0].__name__)
	assert(True == isinstance(SafariIE('SafariIE'), SafariBaseIE))

test_SafariIE()


# Generated at 2022-06-22 08:14:44.116845
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # It should not raise an exception
    try:
        SafariIE({})
    except:
        raise AssertionError('SafariIE constructor should not raise an exception')

# Generated at 2022-06-22 08:14:46.359512
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariapi_ie = SafariApiIE()
    assert safariapi_ie.LOGGED_IN is False


# Generated at 2022-06-22 08:14:49.726123
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    inst = SafariCourseIE('SafariCourse','SafariCourse','SafariCourse')
    # constructor must be initialized with valid arguments
    assert inst.ie_key == 'SafariCourse'
    assert inst.ie_desc == 'SafariCourse'

# Generated at 2022-06-22 08:14:54.543553
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie.login()
    assert ie.LOGGED_IN == True

if __name__ == '__main__':
    test_SafariBaseIE()

# Generated at 2022-06-22 08:14:59.203188
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert issubclass(SafariBaseIE, InfoExtractor)
    ie = SafariBaseIE(None, False)
    assert ie.ie_key() == 'SafariBase'
    assert ie.server_title() == 'safari'
    assert ie.LOGGED_IN == False


# Generated at 2022-06-22 08:15:04.997579
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert type(SafariCourseIE) == type(InfoExtractor)
    return

# Generated at 2022-06-22 08:15:11.701134
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    SafariIE._download_webpage = lambda x, y, z, **kwargs: (b'', None)
    ie = SafariIE(True)
    ie._real_initialize(url)
    print(ie.LOGGED_IN)
    ie._real_initialize(url)
    print(ie.LOGGED_IN)

# Generated at 2022-06-22 08:15:15.288247
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    s = SafariCourseIE()
    assert s.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/")

# Generated at 2022-06-22 08:15:16.314050
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-22 08:15:19.759598
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.ie_key() == 'Kaltura'
    assert safari_ie.LOGGED_IN is False


# Generated at 2022-06-22 08:18:01.233314
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE('SafariBaseIE')
    assert safari.LOGGED_IN

# Generated at 2022-06-22 08:18:03.244081
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if not len(SafariBaseIE.ie_key()) == 1:
        raise Exception('Expected SafariBaseIE.ie_key() to return one item')

# Generated at 2022-06-22 08:18:11.018887
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # _VALID_URL should match URLs in SafariBaseIE.
    o = SafariBaseIE('filename', 'format_id', 'extractor_key')

    try:
        # urlsplit('<URL>') should return a 3 or 6 element tuple
        o._VALID_URL
    except IndexError:
        # try urlsplit('<URL>') once again, to get an error message
        o._VALID_URL
        # shouldn't get here
        assert False