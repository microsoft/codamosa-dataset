

# Generated at 2022-06-22 08:08:32.067434
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_utils import FakeYDL
    from . import SafaribooksonlineIE
    from .compat import compat_str

    ydl = FakeYDL()
    ie = SafariApiIE(ydl)
    ie.add_info_extractor(SafaribooksonlineIE)
    ydl.add_default_info_extractors()
    ie.extract_info(compat_str('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'), download=False)

# Generated at 2022-06-22 08:08:35.767339
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/ch05lev1sec1.html'
    safari_api_ie = SafariBaseIE()
    safari_api_ie._real_extract(url)

# Generated at 2022-06-22 08:08:36.309892
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-22 08:08:40.268499
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        # Testing use of _login method
        safari_base = SafariBaseIE()
        safari_base._login()
    except:
        pass

# Generated at 2022-06-22 08:08:45.993484
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import TestSafariBaseIE
    TestSafariCourseIE = type('TestSafariCourseIE', (TestSafariBaseIE,), {
        '_VALID_URL': SafariCourseIE._VALID_URL, 'ie_key': SafariCourseIE.ie_key})
    tester = TestSafariCourseIE('safari:course')
    assert tester.ie is SafariCourseIE



# Generated at 2022-06-22 08:08:52.065902
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        IE_NAME = 'test_safari'
        _VALID_URL = r'test:(?P<course_id>[^/]+)'
        _API_BASE = 'test_api'

    TestSafariBaseIE('test:cid')._real_initialize()

# Generated at 2022-06-22 08:08:57.553784
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariapi = SafariApiIE()
    course_id = "9780134664057"
    url = "https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html"
    safariapi.url = url
    safariapi.video_id = course_id
    safariapi._real_extract(url)

# Generated at 2022-06-22 08:09:03.516655
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    obj = SafariApiIE()
    assert obj._VALID_URL == SafariApiIE._VALID_URL
    assert obj._TESTS == SafariApiIE._TESTS
    assert obj._real_extract(url)

# Generated at 2022-06-22 08:09:13.867558
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():

    # Test the following function:
    #     SafariCourseIE._real_extract(self,url)

    # Test1: URL's course has no chapters

    # Arrange
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    courseIE = SafariCourseIE()

    def mock_download_json(url, course_id, note, error_note, fatal, headers):
        print("Entered mock_download_json")
        raise ExtractorError(
            'No chapters found for course %s' % course_id, expected=True)
    courseIE._download_json = mock_download_json
    # Act
    with pytest.raises(ExtractorError):
        info = courseIE._real_extract(url)
   

# Generated at 2022-06-22 08:09:17.853346
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    ie._download_json('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json',
                      '9781449396459', 'test', {'test': 'test'})

# Generated at 2022-06-22 08:09:41.999994
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('')

# Generated at 2022-06-22 08:09:46.765023
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # The following url should not be an instance of SafariApiIE
    assert not isinstance(
        SafariApiIE()._real_extract('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'),
        SafariApiIE)

# Generated at 2022-06-22 08:09:48.241448
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariCourseIE = SafariCourseIE()
    assert safariCourseIE.IE_NAME == 'safari:course'

# Generated at 2022-06-22 08:09:50.779535
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert isinstance(safari, SafariIE)

# Generated at 2022-06-22 08:09:55.707664
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/00_SeriesIntro.html'
    SafariBaseIE.suitable(url)
    SafariBaseIE(SafariBaseIE.ie_key())

# Generated at 2022-06-22 08:09:57.303326
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    e = SafariApiIE().IE_NAME
    assert e == 'safari:api'

# Generated at 2022-06-22 08:10:08.188666
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    def test_safari_api_ie_not_suitable_for_url_from_safari_course_ie(self):
        url='https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
        self.assertFalse(SafariApiIE.suitable(url),msg='SafariApiIE does not support courses, only videos')
        self.assertTrue(SafariCourseIE.suitable(url),msg='SafariCourseIE supports courses')
    unittest.TestCase.__str__ = lambda x: "test_safari_api_ie_not_suitable_for_url_from_safari_course_ie"

# Generated at 2022-06-22 08:10:10.399150
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie._VALID_URL.startswith('(?x)')

# Generated at 2022-06-22 08:10:22.677177
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..utils import search_dict
    from ..compat import compat_b64decode

    # Default (empty) constructor does not initialise any attibutes
    ies = [SafariApiIE(None), SafariApiIE()]
    for ie in ies:
        assert ie._API_BASE is None
        assert ie._API_FORMAT is None
        assert ie._LOGIN_URL is None
        assert ie._NETRC_MACHINE is None
        assert ie._VALID_URL is None
        assert ie.IE_DESC is None
        assert ie.IE_NAME is None
        assert ie.LOGGED_IN is None
        assert ie.REAL_URL is None
        assert ie.TEMPLATE_URL is None
        assert ie.TESTS is None
        assert ie.TEST is None

# Generated at 2022-06-22 08:10:27.748083
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('id', 'url', 'title')
    assert (ie.id == 'id') and \
           (ie.url == 'url') and \
           (ie.title == 'title')

# Generated at 2022-06-22 08:11:11.430865
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import common_webpage, common_urls
    from .test_common import test_webpage_content, test_wikipedia_extraction, expected_warnings, expected_failure

    # SafariApiIE is a subclass of SafariBaseIE.
    # If SafariApiIE is not working, we need to check if SafariBaseIE is also broken.
    # For this, we need to test the constructor of class SafariBaseIE.
    # This constructor internally calls the _real_initialize() and _login() methods of
    # SafariBaseIE, which are not tested in test_SafariBaseIE.
    # Since test_safari_baseie.py is not imported as a module, we cannot call the constructor
    # of class SafariBaseIE from there.
    # Hence, test for SafariBaseIE is done here.

    # _real_initial

# Generated at 2022-06-22 08:11:13.439118
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(None)
    assert(ie.LOGGED_IN == False)

# Generated at 2022-06-22 08:11:16.787599
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.ie_key() == 'safari:api'

# Generated at 2022-06-22 08:11:27.474206
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    This test verifies that the local login cookie can be correctly set
    by the constructor of class SafariIE.
    """
    import os.path
    import tempfile

    class MockSafariIE(SafariIE):
        def _download_webpage(self, url, video_id, note=None, errnote=None):
            return json.dumps({
                'logged_in': 'false',
                'redirect_uri': url,
            }), 200, ''

        def _download_json(self, url, video_id, note=None, errnote=None, fatal=True, headers=None):
            return {
                'credentials': '',
                'logged_in': True,
                'redirect_uri': url,
            }


# Generated at 2022-06-22 08:11:40.316899
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    if not os.path.isfile(os.path.join(os.getcwd(), 'test.json')):
        print("File test.json not found, this file is needed for unit test, please download and place it in the same directory")
        return
    course_json = json.load(open("test.json", "r"))
    if 'chapters' not in course_json:
        print("No chapters in test.json")
    assert "chapters" in course_json

    entries = [
        SafariApiIE.url_result(chapter, SafariApiIE.ie_key())
        for chapter in course_json['chapters']]
    course_id = course_json['asin']
    course_title = course_json['title']
    course_json = {}

    if len(entries) == 0:
        print

# Generated at 2022-06-22 08:11:42.624851
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import unittest
    class TestSafariIE(unittest.TestCase):
        def test_constructor(self):
            SafariIE

# Generated at 2022-06-22 08:11:43.693729
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE("www.safari.com")

# Generated at 2022-06-22 08:11:47.439724
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    constructor_test(SafariApiIE.SafariBaseIE, SafariApiIE)

# Generated at 2022-06-22 08:11:52.626345
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert(SafariBaseIE._API_BASE == 'https://learning.oreilly.com/api/v1')
    assert(SafariBaseIE._API_FORMAT == 'json')
    assert(SafariBaseIE.IE_NAME == 'safari')
    assert(SafariBaseIE.IE_DESC == 'safaribooksonline.com online video')
    assert(SafariBaseIE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/')
    assert(SafariBaseIE._NETRC_MACHINE == 'safari')


# Generated at 2022-06-22 08:12:02.632349
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .helper import _extract_f4m_formats
    from compat import compat_urllib_error
    from compat import compat_urllib_parse_urlparse
    from compat import compat_urllib_request

    def test_SafariApiIE_response(query, req_headers=None, body=None, status=200):
        class FakeRequest(compat_urllib_request.Request):
            class FakeResponse(object):
                def getcode(self):
                    return status
            response = FakeResponse()
            def get_header(self, name, default=None):
                if name == 'Set-Cookie':
                    return 'groot_sessionid=this-is-a-faketoken'
                return default

# Generated at 2022-06-22 08:12:52.025286
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Unit test for constructor of class SafariBaseIE"""
    assert TestSafariBaseIE.test_instance.ie_name == TestSafariBaseIE.test_ie_name
    assert TestSafariBaseIE.test_instance.ie_key() == TestSafariBaseIE.test_ie_key
    assert TestSafariBaseIE.test_instance.IE_DESC == TestSafariBaseIE.test_ie_desc
    assert TestSafariBaseIE.test_instance._NETRC_MACHINE == TestSafariBaseIE.test_netrc_machine


# Generated at 2022-06-22 08:12:54.729595
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # test presence of debug fields in SafariBaseIE
    from .debug import DebugIE
    assert issubclass(SafariBaseIE, DebugIE)

# Generated at 2022-06-22 08:12:57.143586
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        import keyring
    except ImportError:
        keyring = None
    IE = SafariBaseIE(keyring)

# Generated at 2022-06-22 08:13:00.957184
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    course_id = ie._match_id('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert course_id == '9781449396459'

# Generated at 2022-06-22 08:13:02.309278
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert(SafariBaseIE._NETRC_MACHINE == SafariCourseIE._NETRC_MACHINE)

# Generated at 2022-06-22 08:13:02.975033
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-22 08:13:12.774751
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import unittest

    class TestSafariCourseIE(unittest.TestCase):
        def setUp(self):
            self.ie = SafariCourseIE()

        def test_suitable(self):
            def test(input_url, expected_is_suitable):
                self.assertEqual(
                    self.ie.suitable(input_url), expected_is_suitable)

            test(
                url='https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/',
                expected_is_suitable=True)

    unittest.main()

# Generated at 2022-06-22 08:13:17.995873
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url_for_title_assertion = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    actual_title = SafariIE()._build_title(url_for_title_assertion, 'foo')
    expected_title = 'Introduction to Hadoop Fundamentals LiveLessons'
    assert actual_title == expected_title

# Generated at 2022-06-22 08:13:24.142735
# Unit test for constructor of class SafariIE

# Generated at 2022-06-22 08:13:26.582897
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    info_extractor = SafariBaseIE()

# Generated at 2022-06-22 08:14:36.656790
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('SafariCourseIE', 'safaribooksonline.com', 'Safari Course')

# Generated at 2022-06-22 08:14:37.645981
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert 'from safari import SafariCourseIE'

# Generated at 2022-06-22 08:14:48.516158
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import re
    from urllib.parse import parse_qs, urlparse
    from safari import SafariCourseIE

    # Test Test Test
    ################
    # test SafariCourseIE Constructor
    ie = SafariCourseIE()
    id = "9781449396459"
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/"

    # Test Test Test
    ################
    # test SafariCourseIE._real_extract
    test_course_json = ie._download_json(
        url + "?override_format=" + ie._API_FORMAT, id, 'Downloading course JSON')
    # test SafariCourseIE.url_result
    test_chapter_list = test_course_json['chapters']

# Generated at 2022-06-22 08:14:50.156351
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()

# Generated at 2022-06-22 08:14:51.223100
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-22 08:14:54.151587
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE()._VALID_URL == SafariBaseIE._VALID_URL

# Generated at 2022-06-22 08:14:55.410295
# Unit test for constructor of class SafariIE
def test_SafariIE():
    sie = SafariIE()
    assert sie

# Generated at 2022-06-22 08:15:06.249027
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Instantiate SafariIE class to test its methods
    inst = SafariIE()
    # Test if instantiation of class works
    assert isinstance(inst, SafariIE)
    # Test if _real_extract method is available
    assert hasattr(inst, '_real_extract')
    # Test if _download_webpage method is available
    assert hasattr(inst, '_download_webpage')
    # Test if _download_json method is available
    assert hasattr(inst, '_download_json')
    # Test if _api_request method is available
    assert hasattr(inst, '_api_request')
    # Test if _login method is available
    assert hasattr(inst, '_login')
    # Test if _real_initialize method is available
    assert hasattr(inst, '_real_initialize')
   

# Generated at 2022-06-22 08:15:07.557569
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-22 08:15:09.737818
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE('safari:api')
    assert safari_api_ie._VALID_URL == SafariApiIE._VALID_URL

# Generated at 2022-06-22 08:18:05.414468
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Positive case when user is logged in
    safari = SafariIE('safari', 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')