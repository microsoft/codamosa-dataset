

# Generated at 2022-06-22 08:08:25.092567
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_class = SafariBaseIE()
    assert test_class._NETRC_MACHINE == 'safari'

# Generated at 2022-06-22 08:08:28.893804
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE(SafariApiIE._create_ie_instance())._login()

# Generated at 2022-06-22 08:08:32.597775
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_ie = SafariBaseIE()
    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie.LOGGED_IN == False

# Generated at 2022-06-22 08:08:34.347180
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():

    safari_ie = SafariApiIE()

    assert safari_ie.IE_NAME == 'safari:api'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'
    
if __name__ == '__main__':
    test_SafariApiIE()

# Generated at 2022-06-22 08:08:38.361124
# Unit test for constructor of class SafariIE
def test_SafariIE():
    args = {
        'username': 'test',
        'password': 'test',
    }
    safari = SafariBaseIE(test_SafariIE, test_SafariIE.__name__, **args)
    assert safari.LOGGED_IN == False

# Generated at 2022-06-22 08:08:42.303053
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    inst = SafariCourseIE(count())
    class_name = ins.__class__.__name__
    assert class_name == 'SafariCourseIE', "Unit test for SafariCourseIE failed"


# Generated at 2022-06-22 08:08:50.404109
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()

    # Get sample URL
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    # Get info necessary to extract video
    mobj = re.match(obj._VALID_URL, url)

    # Run the extract method
    # NOTE: This method is expecting mobj (match object) and url as arguments
    print('Extracting url: ' + url)
    obj._real_extract(mobj, url)

# Generated at 2022-06-22 08:08:52.276171
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE(): 
    # test an instance of SafariBaseIE
    safariBaseIE = SafariBaseIE()

# test SafariCourseIE

# Generated at 2022-06-22 08:08:56.557145
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        import netrc
    except ImportError:
        return

    IE = SafariBaseIE()

    with netrc.netrc() as n:
        login, account, password = n.authenticators(IE._NETRC_MACHINE)
    assert login is None, 'Netrc authentication is not supported.'

# Generated at 2022-06-22 08:08:59.402790
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from ..constructor import ie_key_map
    assert SafariCourseIE(ie_key_map)

# Generated at 2022-06-22 08:09:33.956363
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    IE = SafariCourseIE()
    ie = IE.get_info_extractor(SafariCourseIE._VALID_URL)
    assert isinstance(ie, SafariCourseIE)
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'
    IE = SafariCourseIE()
    ie = IE.get_info_extractor('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert isinstance(ie, SafariCourseIE)
# End - Unit test for constructor of class SafariCourseIE


# Generated at 2022-06-22 08:09:45.656689
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test a working example
    ie = SafariIE()
    course_json = ie._download_json(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json',
        '9781449396459', 'Downloading course JSON')

    # Test a case where an error is returned from safari
    url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
    course_json = ie._download_json(
        'https://www.safaribooksonline.com/api/v1/book/9780133392838/?override_format=json',
        '9780133392838', 'Downloading course JSON')

# Generated at 2022-06-22 08:09:51.261865
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    instance.set_login_info('user', 'pass')
    instance.initialize()
    instance.extract('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

# Generated at 2022-06-22 08:09:54.760835
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    base = SafariBaseIE()
    assert base.IE_NAME == 'safari'
    assert base.IE_DESC == 'safaribooksonline.com online video'


# Generated at 2022-06-22 08:09:57.732331
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Unit test for constructor of class SafariApiIE"""
    safari_api_ie = SafariApiIE()
    assert isinstance(safari_api_ie, SafariApiIE)

# Generated at 2022-06-22 08:10:08.397777
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import os
    import tempfile
    from youtube_dl.compat import PY3
    from youtube_dl.utils import encode_data_uri

    if PY3:
        return

    login_page = (
        b'<input type="hidden" name="csrfmiddlewaretoken" value="'
        b'e4da3b7fbbce2345d7772b0674a318d5">'
        b'<input type="submit" value="Log in">'
    )

    def auth_exception(data, headers):
        raise ExtractorError('', expected=True)

    def entry_list(data, headers):
        return json.dumps({'items': []}).encode('utf-8')


# Generated at 2022-06-22 08:10:19.372633
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_cases = [
        "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/",
        "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json",
        "http://techbus.safaribooksonline.com/9780134426365",
    ]
    for url in test_cases:
        print('SafariCourseIE: Testing constructor for url=%s' % url)
        ie = SafariCourseIE(test_cases[0])
        test_cases.remove(test_cases[0])

# Generated at 2022-06-22 08:10:20.838879
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    module = __import__('youtube_dl.extractor.safari')
    klass = getattr(module, 'SafariCourseIE')
    obj = klass()
    return obj

# Generated at 2022-06-22 08:10:29.230444
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie._API_URL == ie._API_BASE + '/?format=' + ie._API_FORMAT

    ie = SafariApiIE(json)
    assert ie._API_URL == ie._API_BASE + '/?format=' + ie._API_FORMAT

    ie = SafariApiIE(json=False)
    assert ie._API_URL == ie._API_BASE + '/'

    invalid_json_url = "http://google.com/?format=json"
    ie = SafariApiIE(invalid_json_url)
    assert ie._API_URL == invalid_json_url

# Generated at 2022-06-22 08:10:31.610758
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    sbi = SafariBaseIE()
    assert sbi.IE_NAME == 'safari'
    assert sbi.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-22 08:11:03.538714
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie_class = SafariBaseIE()

# Generated at 2022-06-22 08:11:09.312244
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test for non-login case
    extractor = SafariBaseIE(SafariIE.ie_key())
    assert not extractor.LOGGED_IN

    # Test for login case
    extractor = SafariBaseIE(SafariIE.ie_key())
    extractor._login()
    assert extractor.LOGGED_IN

# Generated at 2022-06-22 08:11:09.988186
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-22 08:11:14.896462
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safariIE = SafariBaseIE()
    safariIE._real_initialize()

# Generated at 2022-06-22 08:11:16.345552
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_IE = SafariIE()
    assert safari_IE.ie_key() == 'Safari'

# Generated at 2022-06-22 08:11:17.622922
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()
    return

# Generated at 2022-06-22 08:11:21.807908
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    mobj = re.match(SafariCourseIE._VALID_URL, url)
    SafariCourseIE(mobj)

# Generated at 2022-06-22 08:11:30.594419
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Test SafariIE class constructor."""
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'
    assert ie._VALID_URL == r'''(?x)
                                https?://
                                    (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                                    (?:
                                        library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                        videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                                    )
                                '''



# Generated at 2022-06-22 08:11:32.416873
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE('', '')


# Generated at 2022-06-22 08:11:34.280339
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test = SafariCourseIE()
    test._login()
    assert(test.LOGGED_IN)

# Generated at 2022-06-22 08:12:05.326405
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert isinstance(SafariIE().__class__, type)


# Generated at 2022-06-22 08:12:09.025673
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'http://techbus.safaribooksonline.com/9780134426365'
    assert SafariIE.suitable(url)
    assert SafariApiIE.suitable(url)

# Generated at 2022-06-22 08:12:10.063420
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safaricourseIE = SafariCourseIE()
    assert safaricourseIE.IE_NAME == 'safari:course'

# Generated at 2022-06-22 08:12:18.886325
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # assertEqual(first, second)
    assertEqual(
        SafariIE()._LOGIN_URL,
        'https://learning.oreilly.com/accounts/login/'
    )
    assertEqual(
        SafariIE()._NETRC_MACHINE,
        'safari'
    )
    assertEqual(
        SafariIE()._API_BASE,
        'https://learning.oreilly.com/api/v1'
    )
    assertEqual(
        SafariIE()._API_FORMAT,
        'json'
    )
    assertFalse(
        SafariIE().LOGGED_IN
    )

# Generated at 2022-06-22 08:12:19.966182
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'

# Generated at 2022-06-22 08:12:22.220495
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-22 08:12:23.619299
# Unit test for constructor of class SafariIE
def test_SafariIE():
    return SafariIE(None)._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-22 08:12:31.653932
# Unit test for constructor of class SafariIE

# Generated at 2022-06-22 08:12:40.627989
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/"
    try:
        course_info = SafariCourseIE()
    except Exception as e:
        print(e)
    else:
        assert course_info._VALID_URL == r'(?x)https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.(?:com|org)/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)(?:/|\?|\#|$)'
        assert len(course_info._TESTS) == 6
        assert course_info.suitable(url) == True
       

# Generated at 2022-06-22 08:12:43.806489
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()

# Generated at 2022-06-22 08:13:23.995281
# Unit test for constructor of class SafariIE
def test_SafariIE():
    def get_expected_result(safari_instance, non_digits_in_course_id=True):
        course_id = '9780133392838' if non_digits_in_course_id else '100000006A0210'

# Generated at 2022-06-22 08:13:35.745694
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """ Unit test for constructor of class SafariIE """
    import os
    import tempfile
    import unittest

    # create a temporary file to store the netrc token
    fd, path = tempfile.mkstemp()
    os.close(fd)
    os.remove(path)

    class TestSafariIE(unittest.TestCase):
        def test_SafariIE_not_logged_in(self):
            """ This test checks for an error in case of no logged in user """
            # call the method without setting a custom token
            self.assertRaises(ExtractorError, SafariIE._login)
            # delete the token file
            os.remove('safaribooksonline.tkn')

    unittest.main()
    os.remove(path)

# Generated at 2022-06-22 08:13:41.140670
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    info_extractor = SafariBaseIE()
    assert info_extractor._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert info_extractor.LOGGED_IN is False
    assert info_extractor._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert info_extractor._NETRC_MACHINE == 'safari'

# Generated at 2022-06-22 08:13:43.995428
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBase = SafariBaseIE()
    print(safariBase._API_BASE)
    print(safariBase._API_FORMAT)


# Generated at 2022-06-22 08:13:54.231085
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test how the SafariBaseIE constructor works
    # with different login states
    from ..test.test_login import MockLoginReturningModuleTestCase

    class TestSafariBaseIE(SafariBaseIE):
        IE_NAME = 'safari:base'
        _VALID_URL = r'https?://.*'
        _API_BASE = 'http://api'

        def _real_extract(self, url):
            return {}

    # SafariBaseIE returns None in case of a non-logged in state,
    # and an instance in case of being logged in
    class TestSafariBaseIENotLoggedIn(
            MockLoginReturningModuleTestCase,
            ExtractorError, ExtractorError):
        IE = TestSafariBaseIE
        IE_DESC = 'SafariBaseIE'
       

# Generated at 2022-06-22 08:13:59.251272
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Login to safari to download real videos
    safari = SafariCourseIE()
    assert safari.IE_NAME == 'safari:course'
    assert safari.LOGGED_IN == False
    safari._real_initialize()
    assert safari.LOGGED_IN == True

    # Get chapters' urls of a course
    course = safari.extract('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
    assert course.get('_type') == 'playlist'
    assert course.get('id') == '9780133392838'
    assert course.get('title') == 'Hadoop Fundamentals LiveLessons'
    assert len(course.get('entries')) == 22

# Generated at 2022-06-22 08:14:02.035174
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')

# Generated at 2022-06-22 08:14:06.491199
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('SafariCourse', 'safaribooksonline')
    assert course._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert course._API_FORMAT == 'json'



# Generated at 2022-06-22 08:14:07.660726
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    app = SafariCourseIE()

# Generated at 2022-06-22 08:14:12.762218
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('http://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert ie is not None
    assert ie.IE_NAME == 'safari'


# Generated at 2022-06-22 08:14:56.019836
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # these parameters are taken from the real HTML that
    # `_download_webpage_handle` gets after login
    course_id = '9780133392838'
    part = 'part00'
    url = 'https://www.safaribooksonline.com/library/view/%s/%s.html' % (course_id, part)
    urlh = compat_urllib_request.Request(url, method='GET')
    urlh.code = 200
    urlh.set_data('')
    # these parameters are taken from the real JSON that `_download_json_handle` gets
    # after login and server's response after unsuccessful login

# Generated at 2022-06-22 08:15:00.704843
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .common import expected_warnings
    from .generic_kaltura import kaltura_sample_url
    with expected_warnings(['unable to find kaltura session']):
        SafariIE()._real_initialize()
    with expected_warnings([
            'unable to find kaltura session',
            'unable to retrieve player_id',
            'unable to retrieve ui_conf_id',
            'unable to extract kaltura entry id',
            'unable to extract media url',
    ]):
        SafariIE()._real_extract(kaltura_sample_url)

# Generated at 2022-06-22 08:15:02.722519
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert not SafariIE.suitable('https://techbus.safaribooksonline.com/')

# Generated at 2022-06-22 08:15:12.361792
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import requests
    import unittest
    import warnings
    import pickle
    import os
    import sys

    if sys.version_info[0] > 2:
        warnings.filterwarnings('ignore', category=DeprecationWarning)
    else:
        from requests.packages import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    class TestSafariIE(unittest.TestCase):
        '''Unit tests for the SafariIE class.
        '''
        def setUp(self):
            self.session = requests.Session()
            self.ie = SafariIE(self.session)
            self.assertEqual(self.ie.IE_NAME, 'safari')

# Generated at 2022-06-22 08:15:13.651296
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():

    # Simply run the constructor of the class
    SafariCourseIE()


# Generated at 2022-06-22 08:15:16.259795
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert isinstance(ie, SafariBaseIE)

# Generated at 2022-06-22 08:15:20.164190
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    wget_ie = YoutubeDL({}).get_info_extractor('SafariApiIE')
    assert not wget_ie._downloader.params.get('noplaylist')

# Generated at 2022-06-22 08:15:20.785112
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-22 08:15:24.439847
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance = SafariIE({})
    instance.suitable('https://www.safaribooksonline.com/library/view/introduction-to-machine/9781788295758/part00.html')



# Generated at 2022-06-22 08:15:34.298363
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        import kaltura_common as kaltura_common
    except ImportError:
        kaltura_common = None
    try:
        import kaltura_client as kaltura_client
    except ImportError:
        kaltura_client = None
    try:
        import kaltura_session as kaltura_session
    except ImportError:
        kaltura_session = None
    try:
        import kaltura_client_plugins as kaltura_client_plugins
    except ImportError:
        kaltura_client_plugins = None
    try:
        import kaltura_client_generator as kaltura_client_generator
    except ImportError:
        kaltura_client_generator = None

    if not kaltura_common or not kaltura_client:
        return

# Generated at 2022-06-22 08:17:15.521595
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')
    assert isinstance(ie, SafariCourseIE)
    assert ie.IE_NAME == 'safari:course'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-22 08:17:21.867882
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    account_data = {}

    def _get_login_info():
        if not account_data:
            return '', ''
        return account_data['login'], account_data['password']

    # List of all methods of class InfoExtractor
    methods = [method_name for method_name in dir(InfoExtractor)
        if callable(getattr(InfoExtractor, method_name))]

    for constructor_name in ('SafariIE', 'SafariApiIE', 'SafariCourseIE'):
        safari_class = globals()[constructor_name]

        # Check that class has the same methods as class InfoExtractor
        safari_methods = [method_name for method_name in dir(safari_class)
            if callable(getattr(safari_class, method_name))]


# Generated at 2022-06-22 08:17:23.445589
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie_safari = SafariIE()
    assert isinstance(ie_safari, SafariIE)

# Generated at 2022-06-22 08:17:25.410790
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if __name__ == '__main__':
        from compat import execfile
        from utils import get_testdata_files_path
        execfile(get_testdata_files_path() + '/test_safari.py')

# Generated at 2022-06-22 08:17:33.536636
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False



# Generated at 2022-06-22 08:17:44.221502
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_utils import make_mock_extractor
    from .test_utils import make_mock_url_result, make_mock_playlist_result

    class _SafariApiIE(SafariApiIE):
        def __init__(self, *args, **kwargs):
            super(_SafariApiIE, self).__init__(*args, **kwargs)
            self.n_constructions += 1
            self.initialized = True

    def _make_mock_extractor(entries=None, n_constructions=0, *args, **kwargs):
        return make_mock_extractor(
            'test', _SafariApiIE, entries, n_constructions, *args, **kwargs)

    mock_url_result = make_mock_url_result

# Generated at 2022-06-22 08:17:45.228830
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()

# Generated at 2022-06-22 08:17:48.749864
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # test unlogged-in SafariBaseIE
    safari_base_ie = SafariBaseIE()
    assert not safari_base_ie.LOGGED_IN

    # test logged-in SafariBaseIE
    safari_base_ie = SafariBaseIE(username='username', password='password')
    assert safari_base_ie.LOGGED_IN

# Generated at 2022-06-22 08:17:55.506870
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Just test whether SafariCourseIE can be constructed and whether it is
       a safari video extractor.
    """
    assert (
        'safari' in
        [e.IE_NAME for e in InfoExtractor.gen_extractors() if e.suitable(None)]
    )
    assert SafariCourseIE.suitable(None)
    course_ie = SafariCourseIE()
    assert SafariCourseIE.IE_NAME == course_ie.IE_NAME
    assert 'extractor.safari:course' == course_ie.ie_key()


# Generated at 2022-06-22 08:18:02.231086
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert not SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')