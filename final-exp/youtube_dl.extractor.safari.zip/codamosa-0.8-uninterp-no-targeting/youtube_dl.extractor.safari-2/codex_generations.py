

# Generated at 2022-06-22 08:08:36.001378
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ctor = SafariApiIE.construct
    # ctor(url, ie_key)
    # ctor(url, ie_key(), ie=None, video_id=None, video_title=None)
    # ctor(url, ie_key(), ie=None, video_id=None, video_title=None, ie_key()...)
    # ie_key() is a callable fullname of another ie

    # No SafariApiIE is constructed
    assert isinstance(ctor('http://google.com/', SafariIE.ie_key()), SafariIE)

    # SafariApiIE is constructed

# Generated at 2022-06-22 08:08:40.735793
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class SubclassIE(SafariBaseIE):
        _API_BASE = 'http://example.com/api'

    ie = SubclassIE()
    ie._real_initialize()
    assert len(ie._login_info) != 0

# Generated at 2022-06-22 08:08:45.719007
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # For some reason the call to the constructor triggers a logout
    class SafariIE(safari.SafariIE):
        _NETRC_MACHINE = 'safari'

    safari.SafariIE.test_module()

# Generated at 2022-06-22 08:08:49.079028
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE.IE_NAME == 'safari:base'
    test_SafariBaseIE.__doc__ = ''
    del test_SafariBaseIE

# Generated at 2022-06-22 08:08:54.509050
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('safari')
    assert ie.LOGGED_IN is False
    assert ie._API_FORMAT == 'json'
    assert ie._PARTNER_ID is None
    assert ie._UICONF_ID is None
    assert ie._VALID_URL is None
    assert ie.login_failed is False

# Generated at 2022-06-22 08:09:03.319367
# Unit test for constructor of class SafariIE
def test_SafariIE():
    e = SafariIE()

    assert e.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html') == True
    assert e.suitable('https://techbus.safaribooksonline.com/9780134426365') == False
    assert e.suitable('https://www.safaribooksonline.com/library/view/100-greatest-overlooked/9780134217383/part00.html') == False


# Generated at 2022-06-22 08:09:08.104337
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = "https://www.safaribooksonline.com/library/view/python-in-a/9781484200776/9781484200776-PYE_00_00.xhtml"
    safariIE = SafariIE()

# Generated at 2022-06-22 08:09:11.009504
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        raise KeyError
    except KeyError as e:
        try:
            raise ExtractorError('msg', cause=e)
        except ExtractorError as e2:
            if e2.cause != e:
                raise RuntimeError('cause not the same')

# Generated at 2022-06-22 08:09:11.659273
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-22 08:09:15.424957
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        safari = SafariCourseIE()
    except AttributeError as e:
        print(e)
        assert False


# Generated at 2022-06-22 08:09:32.365468
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class FakeSafariBaseIE(SafariBaseIE):
        IE_DESC = ''
        _VALID_URL = ''
        _NETRC_MACHINE = ''

    ie = FakeSafariBaseIE()
    assert ie.username is None
    assert ie.password is None

# Generated at 2022-06-22 08:09:34.637121
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Unit test of SafariIE constructor. Ensure it doesn't crash
    """
    a = SafariIE()

# Generated at 2022-06-22 08:09:39.519114
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # This only tests if the constructor doesn't crash.
    # Please write a better test if you can.
    safaribase = SafariBaseIE()

# Generated at 2022-06-22 08:09:42.737489
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_safari import _TEST_COURSE_ID
    ie = SafariIE(SafariIE.ie_key())
    ie.extract(_TEST_COURSE_ID)

# Generated at 2022-06-22 08:09:46.296917
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safarie = SafariIE()
    assert safarie._NETRC_MACHINE == 'safari'
    assert safarie.IE_DESC == 'safaribooksonline.com online video'
    assert safarie.IE_NAME == 'safari'

# Generated at 2022-06-22 08:09:53.659132
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

    # test constructors for SafariIE
    # url does't specify a Safari course
    ie = SafariIE()
    try:
        ie.suitable(url)
        assert False
    except AttributeError:
        pass

    # course specified, but not a real Safari course
    course_id = '100000006A0210'
    ie = SafariIE(course_id)
    try:
        ie.suitable(url)
        assert False
    except AttributeError:
        pass

# Generated at 2022-06-22 08:09:59.636450
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    # check argument name
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'



# Generated at 2022-06-22 08:10:06.707217
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        # FIXME: test_SafariIE() needs to be enabled if
        #        the SafariIE() is enabled
        assert SafariIE()
    except Exception as e:
        print('FAILED: in SafariIE()', e)
    else:
        print('SUCCESS: instantiated successfully')

if __name__ == '__main__':
    # execute test_SafariIE()
    test_SafariIE()

# Generated at 2022-06-22 08:10:08.756605
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_ie = SafariBaseIE(None)
    assert not safari_ie.LOGGED_IN

# Generated at 2022-06-22 08:10:11.927578
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_playlist import test_playlist_count
    test_playlist_count(SafariCourseIE, ['9780133392838'])

# Generated at 2022-06-22 08:11:01.636451
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    course_id = '9780133392838'
    part = 'part00'
    input = 'https://www.safaribooksonline.com/library/view/{}/{}.html'.format(course_id, part)

# Generated at 2022-06-22 08:11:03.192211
# Unit test for constructor of class SafariIE
def test_SafariIE():
    a = SafariIE()
    assert a is not None

# Generated at 2022-06-22 08:11:15.714771
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-22 08:11:17.511528
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # An instance of SafariCourseIE class is created
    obj = SafariCourseIE()
    assert isinstance(obj, SafariCourseIE)

# Generated at 2022-06-22 08:11:26.946848
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/part00.html')

# Generated at 2022-06-22 08:11:28.595081
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE()
    assert isinstance(obj,InfoExtractor)


# Generated at 2022-06-22 08:11:29.465157
# Unit test for constructor of class SafariIE
def test_SafariIE():
    return SafariIE

# Generated at 2022-06-22 08:11:31.311339
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE(None)._login()

# Generated at 2022-06-22 08:11:32.569079
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()

# Generated at 2022-06-22 08:11:34.019730
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN is False

# Generated at 2022-06-22 08:12:49.362386
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from . import SafariCourseIE
    assert SafariCourseIE

# Generated at 2022-06-22 08:12:50.801015
# Unit test for constructor of class SafariIE
def test_SafariIE():
    i = SafariIE()
    assert str(i.__class__) == 'SafariIE'

# Generated at 2022-06-22 08:12:58.125709
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE('SafariBaseIE', 'safaribooksonline.com').ie_key() == 'SafariBaseIE'
    assert SafariBaseIE('SafariBaseIE', 'safaribooksonline.com').ie_key(url='https://www.safaribooksonline.com/videos/python-programming-language/9780134217314').ie_key() == 'SafariBaseIE'

# Generated at 2022-06-22 08:12:59.536063
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE(InfoExtractor())._real_initialize()

# Generated at 2022-06-22 08:13:05.081529
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html'
    safari = SafariApiIE(SafariBaseIE())
    assert safari.suitable(url)



# Generated at 2022-06-22 08:13:05.771195
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-22 08:13:09.422943
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert(
        isinstance(
            SafariCourseIE(
                'safari'),
            SafariCourseIE))

# Generated at 2022-06-22 08:13:15.177821
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from youtube_dl.utils import ExtractorError
    from .test_safari import MockSafariCourseTestCase
    import unittest

    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    test_case = MockSafariCourseTestCase(
        url, SafariCourseIE.IE_NAME,
        'Downloading course JSON', '[^/]+')
    test_case.run(unittest.TestCase)

# Generated at 2022-06-22 08:13:16.648562
# Unit test for constructor of class SafariIE
def test_SafariIE():
    i = SafariIE()
    assert i
    assert i.LOGGED_IN == False


# Generated at 2022-06-22 08:13:27.837007
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-22 08:15:54.063246
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert(SafariBaseIE().LOGGED_IN == False)

# Generated at 2022-06-22 08:15:56.018224
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    s = SafariBaseIE()
    assert(s.LOGGED_IN == False)

# Generated at 2022-06-22 08:16:00.955893
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    assert obj.IE_NAME == "safari:api"


# Generated at 2022-06-22 08:16:02.091184
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    x = SafariCourseIE()

# Generated at 2022-06-22 08:16:10.011005
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    result = SafariBaseIE('Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36',
                          'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
    assert result.ie_key() == 'SafariBaseIE'
    assert result.ie_desc == 'safaribooksonline.com base video downloader.'
    assert result._NETRC_MACHINE == 'safari'

# Generated at 2022-06-22 08:16:11.336543
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base = SafariBaseIE()
    safari_base._real_initialize()

# Generated at 2022-06-22 08:16:20.878925
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    s = SafariCourseIE()
    assert(s.IE_NAME == "safari:course")
    s.IE_NAME = "safari:course-updated"
    assert(s.IE_NAME == "safari:course-updated")
    assert(SafariCourseIE.IE_NAME == "safari:course")
    assert(s.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/") == True)
    assert(s.suitable("https://www.safaribooksonline.com/videos/python-programming-language/9780134217314") == True)
    assert(SafariCourseIE.IE_DESC == 'safaribooksonline.com online courses')

# Generated at 2022-06-22 08:16:23.893403
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie._NETRC_MACHINE == 'safari'

# Generated at 2022-06-22 08:16:26.057107
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.LOGGED_IN

# Generated at 2022-06-22 08:16:34.187719
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()

    assert ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert not ie.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert not ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not ie.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')