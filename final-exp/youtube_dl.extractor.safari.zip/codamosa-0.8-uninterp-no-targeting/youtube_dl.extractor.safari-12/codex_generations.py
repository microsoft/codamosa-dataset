

# Generated at 2022-06-22 08:08:29.167143
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'http://www.safaribooksonline.com/library/view/9780980576892/part-vii.html'
    safari_ie = SafariIE(compat_urllib_request.Request(url))
    assert(safari_ie.LOGGED_IN == False)

# Generated at 2022-06-22 08:08:31.977223
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert ie.__class__ == SafariApiIE

# Generated at 2022-06-22 08:08:43.109916
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    course_id = '9780133392838'

    safari = SafariBaseIE()
    safari.logger = lambda *args, **kwargs: None

    url = 'https://www.safaribooksonline.com/library/view/' + course_id + '/'
    assert safari.suitable(url)

    url = 'https://www.safaribooksonline.com/api/v1/book/' + course_id + '/'
    assert safari.suitable(url)

    url = 'https://techbus.safaribooksonline.com/' + course_id + '/'
    assert safari.suitable(url)

    url = 'https://www.safaribooksonline.com/videos/python-programming-language/' + course_id + '/'
   

# Generated at 2022-06-22 08:08:49.343815
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert SafariBaseIE._NETRC_MACHINE == 'safari'

    assert SafariBaseIE._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert SafariBaseIE._API_FORMAT == 'json'

    assert not SafariBaseIE.LOGGED_IN

# Generated at 2022-06-22 08:09:01.357515
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..compat import json
    from ..utils import compat_urllib_request

    # Fake credentials
    def _fake_download_webpage(url_or_reques, *args, **kwargs):
        query = compat_parse_qs(compat_urlparse.urlparse(url_or_reques.get_full_url()).query)
        email = query['email'][0]
        password = query['password'][0]

        if 'test_safari_login' == email:
            real_url = query['redirect_uri'][0]
            real_qs = compat_urlparse.parse_qsl(compat_urlparse.urlsplit(real_url).query)

# Generated at 2022-06-22 08:09:05.326133
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://learning.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    inst = SafariCourseIE(url)
    assert inst.suitable(url)
    inst.initialize()
    inst.extract(url)

# Generated at 2022-06-22 08:09:09.979109
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE()
    assert safariBaseIE._API_BASE == 'https://learning.oreilly.com/api/v1';
    assert safariBaseIE._API_FORMAT == 'json';
    assert safariBaseIE.LOGGED_IN == False;

# Generated at 2022-06-22 08:09:14.992892
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        SafariCourseIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    except ExtractorError as e:
        # Requires safaribooksonline account credentials
        pass

test_SafariCourseIE()

# Generated at 2022-06-22 08:09:26.528586
# Unit test for constructor of class SafariIE

# Generated at 2022-06-22 08:09:29.678317
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # test that the constructor does not raise an error
    ie = SafariIE({})
    assert joeq.version_info.major >= 2
    assert joeq.version_info.major >= 3

# Generated at 2022-06-22 08:09:44.803332
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        SafariBaseIE()._login()
    except ExtractorError:
        pass

# Generated at 2022-06-22 08:09:52.288932
# Unit test for constructor of class SafariIE

# Generated at 2022-06-22 08:09:58.485290
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # constructor is called directly in this test only
    # because SafariApiIE is not suitable for this url
    # pylint: disable=W0212
    safariapiie = SafariApiIE(SafariApiIE._create_ie())
    safariapiie._initialize_geo_restricted()
    assert safariapiie.IE_NAME == 'safari:api'


# Generated at 2022-06-22 08:10:00.315868
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        SafariIE('', '', '')
    except Exception as e:
        print (e)

# Generated at 2022-06-22 08:10:07.759618
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    s = SafariCourseIE('SafariCourseIE', 'http://techbus.safaribooksonline.com/9780134426365')
    assert s.name == 'SafariCourseIE'
    assert s.ie_key() == 'SafariCourse'
    assert s.url == 'http://techbus.safaribooksonline.com/9780134426365'
    assert s.suitable('http://techbus.safaribooksonline.com/9780134426365')

# Generated at 2022-06-22 08:10:08.856291
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()

# Generated at 2022-06-22 08:10:21.492142
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .common import fake_urlopen_password_mock
    try:
        import http.cookiejar

        cookiejar = http.cookiejar
    except ImportError:
        import cookielib

        cookiejar = cookielib

    safari = SafariBaseIE({})
    safari._downloader.cache.remove_dir(safari.temp_dir)

    username = 'username'
    password = 'password'

    url = 'https://learning.oreilly.com/accounts/login-check/'
    wrong_url = 'https://learning.oreilly.com/accounts/login/'

    # no login info
    safari._download_webpage_handle = fake_urlopen_password_mock({
        url: TypeError
    }, cookiejar.CookieJar())

# Generated at 2022-06-22 08:10:26.092985
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Test method constructor of class SafariBaseIE"""
    ic = SafariBaseIE()
    assert ic is not None
    assert ic.LOGGED_IN == False
    assert ic._downloader.params['username'] == ''
    assert ic._downloader.params['password'] == ''
    assert ic._NETRC_MACHINE == 'safari'

# Generated at 2022-06-22 08:10:29.339458
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    object = SafariCourseIE()
    object.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-22 08:10:31.867494
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test for the constructor of SafariCourseIE"""
    ie = SafariCourseIE()
    ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    ie.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')

# Generated at 2022-06-22 08:11:06.885220
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    _SafariApiIE = SafariApiIE()
    assert _SafariApiIE.SafariApiIE

# Generated at 2022-06-22 08:11:19.242179
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # test if login works
    SafariIE._download_webpage = lambda self, url, video_id: ('', None)
    SafariIE._download_json = lambda self, url, video_id, msg, error_msg=None, fatal=True, headers=None: None
    SafariIE._apply_first_set_cookie_header = lambda self, urlh, cookie: None

    # test if login fails with wrong password
    SafariIE._download_json_handle = lambda self, *args, **kwargs: ({'logged_in': False}, None)
    assert not SafariIE(
        {'username': 'test', 'password': 'wrong'})._login()

    # test if login succeeds

# Generated at 2022-06-22 08:11:29.272458
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.IE_NAME == 'safari:api'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+).html'
    assert ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-22 08:11:41.788292
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    s = SafariApiIE('safari:api')
    assert s.IE_NAME == 'safari:api'
    assert s.IE_DESC == None
    assert s._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-22 08:11:43.916494
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # This tests if SafariIE object is constructed properly.
    test_instance = SafariIE()
    assert test_instance.ie_key() == 'Safari'

test_SafariIE()

# Generated at 2022-06-22 08:11:49.809175
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import os

    # Test this code path with credentials and without.
    for use_credentials in [True, False]:
        # Dummy class instance to store methods
        class DummySafariInstance(SafariBaseIE):
            def _download_json_handle(
                    self, *args, **kwargs):  # pylint: disable=unused-argument
                return (None, None)

            _LOGGED_IN = False
            _download_webpage_handle = _download_json_handle

        # Get an instance of the class and set a cookie
        dummy_safari_instance = DummySafariInstance()
        dummy_safari_instance._set_cookie('safe_cookie')
        # Make sure the class instance has a cookie to start with

# Generated at 2022-06-22 08:11:56.756475
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    css = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    a = SafariCourseIE(css)
    assert a.IE_NAME == 'safari:api' 
    assert a.IE_DESC == 'safaribooksonline.com online courses'



# Generated at 2022-06-22 08:12:05.287388
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_info_extractor = SafariCourseIE()
    assert safari_course_info_extractor.IE_NAME == 'safari:course'
    assert safari_course_info_extractor.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_course_info_extractor._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-22 08:12:09.022212
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()

    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False



# Generated at 2022-06-22 08:12:11.068350
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.LOGGED_IN is False

# Generated at 2022-06-22 08:13:32.014287
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    i = SafariBaseIE()
    print(repr(i))

# Generated at 2022-06-22 08:13:35.700854
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import InfoExtractor
    from ..compat import unittest

    class TestSafariApiIE(unittest.TestCase):
        def test_SafariApiIE(self):
            ie = InfoExtractor.get_info_extractor(SafariApiIE.ie_key())
            self.assertEqual(type(ie), SafariApiIE)

# Generated at 2022-06-22 08:13:45.281284
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from selenium import webdriver
    from selenium.webdriver.common.keys import Keys

    from .test_utils import _set_mock_browser

    test_url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/_SeriesIntro.html'
    test_webpage, urlh = download_webpage_handle(test_url, test_url)

    # We need to mock the selenium webdriver
    def create_mock_webdriver():
        driver = webdriver.Firefox()
        driver.get(test_url)
        return driver

    login_form = {
        'username': 'test_username',
        'password': 'test_password',
    }


# Generated at 2022-06-22 08:13:49.658590
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Constructor test
   """
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.ie_key() == 'SafariApiIE'

# Generated at 2022-06-22 08:14:01.165147
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import itertools
    for ie_class in itertools.chain(SafariCourseIE.__bases__, (SafariCourseIE,)):
        for x in [SafariBaseIE, SafariIE, SafariApiIE, SafariCourseIE]:
            assert issubclass(x, ie_class)
        for x in ['SafariBaseIE', 'SafariIE', 'SafariApiIE', 'SafariCourseIE']:
            assert x not in ie_class.__name__
        assert ie_class.__name__ == ie_class.__name__.rstrip('IE')
        assert ie_class.__name__ != 'SafariBaseIE'
        assert ie_class.__name__ != 'SafariIE'
        assert ie_class.__name__ != 'SafariApiIE'

# Generated at 2022-06-22 08:14:07.316207
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    ie._download_json = lambda *args, **kwargs: {}
    ie.url_result = lambda url: url
    ie.playlist_result = lambda urls, playlist_id, playlist_title: urls
    # ExtractorError expected
    with pytest.raises(ExtractorError) as e_info:
        print(ie.extract(
            'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'))
    assert 'No chapters found' in str(e_info.value)

# Generated at 2022-06-22 08:14:09.853598
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()  # Create an instance of SafariIE
    assert safari_ie is not None, 'Failed to create an instance of SafariIE'

# Generated at 2022-06-22 08:14:13.929921
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Exceptions
    ie = SafariBaseIE('http://techbus.safaribooksonline.com/9780134426365')
    assert ie._NETRC_MACHINE is None


# Generated at 2022-06-22 08:14:17.239677
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # TODO: Add unit tests for SafariCourseIE
    pass

# Generated at 2022-06-22 08:14:23.068453
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import platform

    test = (
        ('darwin', False),
        ('Windows', False),
        ('linux', True),
        ('Linux', True),
        ('linux2', True),
        ('Linux2', True),
    )

    for os_name, is_expected in test:
        with platform.mocked(os_name):
            safari = SafariBaseIE()
            assert safari.is_logged() == is_expected

# Generated at 2022-06-22 08:17:08.514627
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # pylint: disable=protected-access
    assert SafariBaseIE(SafariBaseIE._downloader)._downloader is not None
    assert SafariBaseIE(SafariBaseIE._downloader, 'test')._downloader is not None
    assert SafariBaseIE(SafariBaseIE._downloader, ie='test')._downloader is not None

# Generated at 2022-06-22 08:17:11.780779
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE(SafariBaseIE.ie_key(), SafariBaseIE.ie_key(),
                        SafariBaseIE.ie_key(), '')
    # Test if init of class executed without failure
    assert ie is not None

# Generated at 2022-06-22 08:17:18.402784
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    mobj = re.match(SafariApiIE._VALID_URL,
            'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/intro.html')
    assert mobj is not None
    for name in ['course_id', 'part']:
        assert mobj.group(name) is not None


# Generated at 2022-06-22 08:17:29.740574
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import unittest
    class MockModule(unittest.TestCase):
        class Suitable(unittest.TestCase):
            def _match_id(self, url):
                return '9780134664057'
            def _real_extract(self, url):
                assert url == 'https://www.safaribooksonline.com/api/v1/book/9780134664057/?override_format=json'
                return 'test successful'
    safari_course_ie = SafariCourseIE()
    ie_test_class = MockModule.__dict__['Suitable']
    safari_course_ie.__class__ = ie_test_class
    ie_test_class.__module__ = 'SafariCourseIE'

# Generated at 2022-06-22 08:17:39.659271
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # test SafariCourseIE as a class
    # make sure it can be constructed
    # and its method suitable is also working
    course_ie = SafariCourseIE()
    assert hasattr(course_ie, 'suitable')
    assert callable(course_ie.suitable)
    assert isinstance(course_ie.suitable('http://techbus.safaribooksonline.com/9780134426365'), bool)
    assert isinstance(course_ie.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314'), bool)
    assert isinstance(course_ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'), bool)

# Generated at 2022-06-22 08:17:45.362979
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    class_ = SafariCourseIE
    assert hasattr(class_, 'ie_key')
    assert hasattr(class_, '_VALID_URL')
    #assert hasattr(class_, '_TESTS')
    assert callable(class_.ie_key)
    assert callable(class_.suitable)
    assert callable(class_._real_extract)

# Generated at 2022-06-22 08:17:46.945125
# Unit test for constructor of class SafariIE
def test_SafariIE():
    '''
    Test to assert that the SafariIE constructor is instantiated.
    '''
    safari = SafariIE()
    safari = None

# Generated at 2022-06-22 08:17:55.884434
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test the SafariCourseIE constructor
    """
    obj = SafariCourseIE()
    assert obj.suitable('http://techbus.safaribooksonline.com/9781491959771') is True
    assert obj.suitable('https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/') is True
    assert obj.suitable('https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html') is False
    assert obj.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html') is False

    obj = SafariCourseIE()

# Generated at 2022-06-22 08:18:06.893621
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import os.path
    from .utils import user_agent
    from .extractor import extractors
    from .exceptions import UnsupportedError
    from .compat import compat_urllib_request, compat_cookielib, compat_HTTPError, compat_urlopen

    USER, PASS = os.path.join('test', 'safari_credentials')
    if os.path.isfile(USER):
        # Read username/password from files
        with open(USER, 'r') as f:
            username = f.readline().rstrip()
        with open(PASS, 'r') as f:
            password = f.readline().rstrip()
    else:
        # Ask user to provide username/password
        username = input('Please provide an username for safaribooksonline: ')