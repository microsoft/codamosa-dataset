

# Generated at 2022-06-22 08:08:23.931232
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie_obj = SafariIE()
    assert safari_ie_obj.LOGGED_IN == False

# Generated at 2022-06-22 08:08:29.614598
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/'
    safari_course_ie = SafariCourseIE().suitable(url)
    # FIXME: It always return None
    assert safari_course_ie == False

# Generated at 2022-06-22 08:08:32.554483
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()._real_extract(
        "https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html")

# Generated at 2022-06-22 08:08:36.482176
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    test_instance = SafariIE()
    test_result = test_instance.suitable(test_url)
    assert test_result == True

# Generated at 2022-06-22 08:08:38.055081
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariBaseIE._login()

# Generated at 2022-06-22 08:08:40.634734
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # SafariCourseIE is a subclass of SafariBaseIE
    assert isinstance(SafariCourseIE(), SafariBaseIE)

# Generated at 2022-06-22 08:08:52.592759
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import getpass

    course_id = input('Course ID: ')
    parts_json = input('Parts JSON URL: ')

    safari = SafariApiIE(None)
    safari.course_id = course_id
    safari._login_info = (
        input('Safari username: '),
        getpass.getpass('Safari password: '))

    parts = json.load(SafariApiIE._request_webpage(
        parts_json, None, note='Downloading parts JSON', errnote='Unable to download parts JSON'))['chapters']
    for num, part in enumerate(parts):
        id = part['id']
        webpage = SafariApiIE._download_webpage(
            part['web_url'], id, 'Downloading part %s JSON' % id)
       

# Generated at 2022-06-22 08:08:55.215674
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariBaseIE is not None

# Generated at 2022-06-22 08:08:56.692465
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Instantiate an instance of SafariCourseIE."""
    safari = SafariCourseIE()
    assert( isinstance( safari, SafariCourseIE ) )

# Generated at 2022-06-22 08:09:07.191506
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == True
    SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == True
    SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314') == True
    SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html') == False

# Generated at 2022-06-22 08:09:22.440674
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api = SafariBaseIE()
    class_SafariApiIE = SafariApiIE(safari_api)
    assert isinstance(class_SafariApiIE, SafariApiIE)
    return class_SafariApiIE


# Generated at 2022-06-22 08:09:27.964878
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        ie = SafariIE(None)
        ie._api_base = 'http://localhost/'
        ie._api_format = 'json'
        ie._login()
    except IOError as e:
        print(e)
        print('SafariIE unit test failed. The error could be caused by damage of your internet connection.')
    else:
        print('SafariIE unit test passed.')

# Generated at 2022-06-22 08:09:38.631144
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    r = SafariCourseIE._json_to_extractors('9780133392838')
    assert len(r) == 1
    assert r[0][0] == SafariApiIE
    assert r[0][1] == '9780133392838'

    r = SafariCourseIE._json_to_extractors([['9780133392838']])
    assert len(r) == 1
    assert r[0][0] == SafariApiIE
    assert r[0][1] == '9780133392838'

    r = SafariCourseIE._json_to_extractors([{'isbn': '9780133392838'}])
    assert len(r) == 1
    assert r[0][0] == SafariApiIE

# Generated at 2022-06-22 08:09:39.316376
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-22 08:09:40.411304
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('')

# Generated at 2022-06-22 08:09:46.094818
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie.LOGGED_IN is False
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-22 08:09:48.852369
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class FakeSafariBaseIE(SafariBaseIE):
        # Only usable for testing
        pass

    FakeSafariBaseIE('SafariBaseIE', {}, {'username': 'test', 'password': 'test'})

# Generated at 2022-06-22 08:09:52.362494
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # pylint: disable=protected-access
    mgr = SafariCourseIE._build_browser({})
    assert isinstance(mgr, SafariCourseIE)

# Generated at 2022-06-22 08:09:54.935222
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE()._API_BASE == 'https://www.safaribooksonline.com/api/v1'

# Generated at 2022-06-22 08:09:55.659374
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    return SafariCourseIE

# Generated at 2022-06-22 08:10:41.735053
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html?override_format=json'
    downloader = SafariApiIE(SafariBaseIE)
    res = downloader.extract(url)
    print(res)

# Generated at 2022-06-22 08:10:44.320142
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    instance = SafariApiIE()
    assert isinstance(instance, SafariBaseIE)
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-22 08:10:45.363202
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('safari')

# Generated at 2022-06-22 08:10:57.071155
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-22 08:10:59.286075
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE(None)
    assert ie.IE_NAME == 'safari:api'

# Generated at 2022-06-22 08:11:04.628854
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE('username', 'password')

# Generated at 2022-06-22 08:11:08.674293
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..test.test_safari import get_testcases_1

    # test successful login
    for (url, username, password) in get_testcases_1():
        try:
            SafariBaseIE(url, username, password)
        except ExtractorError as ee:
            # this exception is ok because we wanted to check login
            assert 'Unable to log in' in ee.message

    # test unsuccessful login
    for (url, username, password) in get_testcases_1():
        password = 'wrongpassword'
        try:
            SafariBaseIE(url, username, password)
        except ExtractorError as ee:
            # this exception is ok because we wanted to check login
            assert 'Unable to log in' in ee.message

# Generated at 2022-06-22 08:11:10.610327
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.__class__.__name__ == 'SafariApiIE'

# Generated at 2022-06-22 08:11:15.510917
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import FakeHttpServer

    with FakeHttpServer(lambda x: httplib.HTTP_OK):
        SafariCourseIE()._real_extract('https://www.safaribooksonline.com/library/view/python-programming-language/9780134217314/')

# Generated at 2022-06-22 08:11:16.787438
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()

# Generated at 2022-06-22 08:12:15.680631
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safaribooksonline = SafariApiIE()
    result = safaribooksonline._real_extract(r'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    assert result == None

# Generated at 2022-06-22 08:12:21.177120
# Unit test for constructor of class SafariIE
def test_SafariIE():
    course_id = '9781449396459'
    """Test for __init__"""
    safari = SafariCourseIE()
    course_json = safari._download_json(
        '%s/book/%s/?override_format=%s' % (safari._API_BASE, course_id, safari._API_FORMAT),
        course_id, 'Downloading course JSON')
    course_title = course_json['title']
    assert course_title == 'Learning Python', 'Course title is not correct'

# Generated at 2022-06-22 08:12:22.579697
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert callable(SafariIE)



# Generated at 2022-06-22 08:12:26.325001
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # The following url is one of valid urls extracted in test cases
    url = 'https://www.safaribooksonline.com/library/view/create-a-nodejs/100000006A0210/part00.html'
    # Create an empty object of class SafariApiIE
    obj = SafariApiIE()
    # Test _real_extract function of class SafariApiIE
    obj._real_extract(url)

# Generated at 2022-06-22 08:12:27.390911
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert hasattr(SafariCourseIE, 'suitable')

# Generated at 2022-06-22 08:12:29.293354
# Unit test for constructor of class SafariIE
def test_SafariIE():
    x = SafariIE()
    x.initialize('username', 'password')
    assert len(x._language) == 2
    assert x.LOGGED_IN

# Generated at 2022-06-22 08:12:40.070282
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # To test a class that requires a safaribooksonline account,
    # we create a fresh instance of SafariCourseIE.
    safaribooksonline_ie = SafariCourseIE()
    safaribooksonline_ie._download_webpage = lambda *args, **kwargs: {
        'webpage': None,
        'id': None,
        'url': None,
        'headers': {},
        'status': None,
        'msg': None,
    }
    safaribooksonline_ie.report_download_webpage = lambda *args: None
    safaribooksonline_ie.to_screen = lambda *args: None
    safaribooksonline_ie._set_cookie = lambda cookie: None
    safaribooksonline_ie._get_cookies = lambda: None
   

# Generated at 2022-06-22 08:12:51.639836
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-22 08:13:03.208909
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    example_netrc_file = """
machine safari
login user@example.com
password secret_password
"""
    from tempfile import NamedTemporaryFile
    from ..test_utils import fake_http_server_handler

    ie = SafariBaseIE()
    ie._NETRC_MACHINE = 'safari'

# Generated at 2022-06-22 08:13:14.623821
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    ie = SafariIE()
    assert ie == SafariIE()
    assert ie != SafariCourseIE()
    assert ie != SafariApiIE()

    assert ie.LOGGED_IN == False
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

    video_id = '9780133392838-part00'
    webpage, urlh = ie._download_

# Generated at 2022-06-22 08:15:27.470088
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    This test is designed to check if the constructor of SafariCourseIE works
    properly or not
    """
    course_obj = SafariCourseIE()
    assert course_obj._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert course_obj._API_FORMAT == 'json'

# Generated at 2022-06-22 08:15:36.659386
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'

    safari_course_ie = SafariCourseIE(SafariCourseIE, url)

    assert re.match(
        '^https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\\.html$', safari_course_ie._VALID_URL)
    assert safari_course_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_course_ie._API_

# Generated at 2022-06-22 08:15:42.041874
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base = SafariBaseIE()
    assert safari_base._NETRC_MACHINE == 'safari'
    assert safari_base._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_base._API_FORMAT == 'json'

# Generated at 2022-06-22 08:15:52.993327
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    with open('tests/test_data/safari-book-9781449396459.json', 'rb') as test_file:
        course_json = test_file.read().decode('utf-8')
    ie = SafariCourseIE()
    ie.to_screen = lambda *args: None
    entries = ie._real_extract(test_url)
    assert entries[0]['url'] == 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'

# Generated at 2022-06-22 08:15:56.874213
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariBaseIE()
    assert not safari.LOGGED_IN
    assert SafariBaseIE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert SafariBaseIE._NETRC_MACHINE == 'safari'

# Generated at 2022-06-22 08:15:58.162405
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('Safari', 'safaribooksonline')

# Generated at 2022-06-22 08:16:03.611813
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        def _download_webpage_handle(self, *args, **kwargs):
            pass

        def _apply_first_set_cookie_header(self, *args, **kwargs):
            pass

        def _download_json_handle(self, *args, **kwargs):
            pass

        def _get_login_info(self):
            return ['user', 'pass']

    TestSafariBaseIE()

# Generated at 2022-06-22 08:16:10.234674
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # test for valid url
    SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

    # test for invalid url
    SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html.invalid')

# Generated at 2022-06-22 08:16:15.666565
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-22 08:16:25.999139
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = SafariBaseIE._VALID_URL
    assert url[0] == url[-1] == '/'
    assert url.count('(') == url.count(')') == 3
    assert url.count('?') == 1
    assert 'http' in url
    assert 'https' in url
    assert 'safaribooksonline' in url
    assert 'oreilly' in url
    assert 'learning' in url
    assert 'videos' in url
    assert 'library' in url
    assert 'view' in url
    assert 'book' in url
    assert 'chapter' in url
    assert 'part' in url
    assert not 'api' in url
    assert not 'techbus' in url