

# Generated at 2022-06-26 12:31:36.997147
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:31:38.458683
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:31:39.693402
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_3 = SafariCourseIE()

# Generated at 2022-06-26 12:31:40.577719
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:31:43.141177
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Declare output of constructor for class SafariBaseIE
    safari_base_i_e_0 = SafariBaseIE()
    # Assert equality between the declared output and the expected output
    assert safari_base_i_e_0 == SafariBaseIE()


# Generated at 2022-06-26 12:31:44.393572
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()


# Generated at 2022-06-26 12:31:47.012195
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    # Test function re.match()
    result = obj._VALID_URL
    if result:
        pass

# Generated at 2022-06-26 12:31:54.860060
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test for '_API_BASE' is already tested in test_SafariApiIE
    safari_base_i_e = SafariBaseIE()
    assert safari_base_i_e._API_BASE == 'https://learning.oreilly.com/api/v1'
    # Test for '_API_FORMAT' is already tested in test_SafariApiIE
    assert safari_base_i_e._API_FORMAT == 'json'
    assert safari_base_i_e.IE_NAME == 'safari'
    assert safari_base_i_e.IE_DESC == 'safaribooksonline.com online video'


# Generated at 2022-06-26 12:32:03.152971
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert_equals(SafariIE()._VALID_URL, 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/library/view/[^/]+/[^/]+/(?P<part>[^/?#&]+)\\.html')

# Generated at 2022-06-26 12:32:04.484850
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie.LOGGED_IN == False


# Generated at 2022-06-26 12:32:39.811474
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()

# Generated at 2022-06-26 12:32:43.897289
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:32:45.535898
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:32:47.598562
# Unit test for constructor of class SafariIE
def test_SafariIE():
    print("Constructor of class SafariIE", end=':')
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:32:48.875172
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()


# Generated at 2022-06-26 12:32:49.836664
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()
    assert safari_i_e is not None


# Generated at 2022-06-26 12:32:50.672049
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass



# Generated at 2022-06-26 12:32:51.525711
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_case_0()


# Generated at 2022-06-26 12:32:53.011752
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:32:53.656264
# Unit test for constructor of class SafariIE
def test_SafariIE():
    print('Test for class SafariIE')
    test_case_0()


# Generated at 2022-06-26 12:33:43.974625
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    ie._login()

# Generated at 2022-06-26 12:33:46.533247
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url="https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    obj = SafariApiIE()
    assert True == obj.suitable(url)

# Generated at 2022-06-26 12:33:48.208909
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_SafariBaseIE = SafariBaseIE()
# Test for method _login

# Generated at 2022-06-26 12:33:49.885458
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert 'safari:api' == SafariApiIE().ie_key()


# Generated at 2022-06-26 12:33:50.612933
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()

# Generated at 2022-06-26 12:33:54.366501
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    info_extractor = SafariBaseIE()
    assert info_extractor._API_BASE is 'https://learning.oreilly.com/api/v1'
    assert info_extractor._API_FORMAT is 'json'
    assert info_extractor.LOGGED_IN is False
    assert info_extractor._NETRC_MACHINE is 'safari'
    assert info_extractor._VALID_URL is None

# Generated at 2022-06-26 12:33:56.324815
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE(SafariCourseIE.IE_NAME, SafariCourseIE.IE_DESC)

# Generated at 2022-06-26 12:34:00.283751
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    extractor = SafariApiIE()
    assert extractor._VALID_URL == \
        'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\\.html'



# Generated at 2022-06-26 12:34:10.115754
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_course_id = '9780134664057'
    test_chapter_title = 'RHCE_Introduction'
    url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html' % (test_course_id, test_chapter_title)

    # Create an instance of class SafariApiIE, download the page corresponding to the course_id, and extract the chapter JSON
    safari_api_ie = SafariApiIE()
    part = safari_api_ie._download_json(url, '%s/%s' % (test_course_id, test_chapter_title), 'Downloading part JSON')

    # Assert that the course title in the JSON matches the expected title

# Generated at 2022-06-26 12:34:12.765056
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()._real_extract('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')

# Generated at 2022-06-26 12:35:41.255903
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_safari import t
    from .test_safari import f
    # just for coverage of assert_login()
    SafariApiIE._download_json = t
    SafariApiIE._download_webpage_handle = t
    SafariApiIE._apply_first_set_cookie_header = t
    SafariApiIE._get_login_info = lambda self: (None, None)
    SafariApiIE()._login()

    SafariApiIE._download_json = f
    SafariApiIE._download_webpage_handle = f
    SafariApiIE._apply_first_set_cookie_header = f
    SafariApiIE._get_login_info = lambda self: (None, None)
    with t(SafariApiIE):
        SafariApiIE()._login()

# Generated at 2022-06-26 12:35:42.181169
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('Safari')

# Generated at 2022-06-26 12:35:44.202153
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'

# Generated at 2022-06-26 12:35:52.128638
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert not SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert not SafariIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')

# Generated at 2022-06-26 12:35:59.740455
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import json
    from .common import fake_urlopen, fake_urlretrieve, fake_os
    from .common import USER_AGENT
    from .common import mock
    from ..compat import compat_urllib_parse_urlparse

    # Create a fake response
    response_url = 'https://learning.oreilly.com/accounts/login-check/'

    data_url = (
            b'{"logged_in": false, "credentials": null, '
            b'"redirect_uri": '
            b'"https://learning.oreilly.com/accounts/login/?next=/home/"}'
        )


# Generated at 2022-06-26 12:36:06.118668
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..utils import UNKNOWN_COUNTRY
    from .common import GeoblockingTestCase

    # No credentials.
    SafariBaseIE._login()

    # Wrong credentials.
    test_error_credentials_message(GeoblockingTestCase, SafariBaseIE)

    # Login using credentials.
    country_code = UNKNOWN_COUNTRY
    username, password = GeoblockingTestCase.get_test_credentials(country_code)
    SafariBaseIE.username = username
    SafariBaseIE.password = password
    SafariBaseIE._login()

    # Logged in.
    assert SafariBaseIE.LOGGED_IN

# Generated at 2022-06-26 12:36:09.298338
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class ClassSafari(SafariBaseIE):
        _VALID_URL = r'http://www.sample.com'

    obj = ClassSafari(ClassSafari.ie_key())

# Generated at 2022-06-26 12:36:11.911356
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # For testing purposes only.
    assert(SafariBaseIE._API_BASE == 'https://learning.oreilly.com/api/v1')
    assert(SafariBaseIE._API_FORMAT == 'json')

# Generated at 2022-06-26 12:36:20.914845
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..test import (
        get_testdata_file_path,
        shell_exec,
        make_tempdir,
        run_async,
    )
    temp_dir = make_tempdir()
    netrc_path = get_testdata_file_path('netrc')


# Generated at 2022-06-26 12:36:23.767914
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class TestExtractor(SafariApiIE):
        _API_BASE = 'http://localhost:8080/api/v1'

    TestExtractor(None)._real_initialize()

# Generated at 2022-06-26 12:39:22.853005
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # login is not required
    SafariBaseIE()

    # login is required
    SafariBaseIE(params={'username': 'foo', 'password': 'bar'})

# Generated at 2022-06-26 12:39:25.711973
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE(SafariCourseIE.__name__), SafariCourseIE)


# Generated at 2022-06-26 12:39:29.650292
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari = SafariCourseIE()
    url = 'https://www.safaribooksonline.com/library/view/go-in-action/9781617291784/'
    course_id = safari._match_id(url)
    assert course_id == '9781617291784'
    return

# Generated at 2022-06-26 12:39:30.524518
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-26 12:39:34.366043
# Unit test for constructor of class SafariIE
def test_SafariIE():
    a = SafariIE()
    assert(a.ie_key() == 'Safari')


# Generated at 2022-06-26 12:39:39.556652
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    assert SafariIE.suitable(url)
    assert SafariIE().suitable(url)


# Generated at 2022-06-26 12:39:44.093198
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import sys
    sys.argv[1] = '--username=safari --password=password --no-check-certificate'
    SafariBaseIE()._real_initialize()

# Generated at 2022-06-26 12:39:44.952152
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    checkConstructor()

# Generated at 2022-06-26 12:39:47.572529
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE(SafariBaseIE)

    assert ie is not None

# Generated at 2022-06-26 12:39:55.082428
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Success case - create an object of the SafariApiIE class.
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html"
    safari_api_ie = SafariApiIE(SafariBaseIE)
    safari_api_ie.suitable(url) # pylint: disable=no-value-for-parameter

    # Failure case - create an object of the SafariApiIE class.
    url = "http://techbus.safaribooksonline.com/9780134426365"
    safari_api_ie = SafariApiIE(SafariBaseIE)
    safari_api_ie.suitable(url) # pylint: disable=no-value-for-parameter