

# Generated at 2022-06-26 12:31:39.187919
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass
# test_SafariBaseIE()


# Generated at 2022-06-26 12:31:40.045968
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()


# Generated at 2022-06-26 12:31:41.138045
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert test_case_0() is None


# Generated at 2022-06-26 12:31:42.378351
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert_raises(TypeError, SafariIE, None)
#test_SafariIE()


# Generated at 2022-06-26 12:31:43.103252
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()

# Generated at 2022-06-26 12:31:46.738210
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Verify that constructor is able to access private variable _PARTNER_ID.
    # Verify that constructor is able to access private variable _UICONF_ID.
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:31:47.848868
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    Safaribaseie = SafariBaseIE()


# Generated at 2022-06-26 12:31:56.640430
# Unit test for constructor of class SafariIE
def test_SafariIE():
    with pytest.raises(re.error):
        with pytest.raises(AttributeError):
            with pytest.raises(AssertionError):
                safari_i_e = SafariIE()
                assert safari_i_e.IE_NAME == 'safari'
                assert safari_i_e.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-26 12:31:57.190150
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-26 12:31:58.174862
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:32:26.175320
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    i = SafariCourseIE()
    print('object name is: %s' % i.ie_key())


# Generated at 2022-06-26 12:32:31.556297
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        _PARTNER_ID = '1926081'
        _UICONF_ID = '29375172'

        def _real_initialize(self):
            pass

    TestSafariBaseIE('cookie')._login()

# Generated at 2022-06-26 12:32:31.972423
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE

# Generated at 2022-06-26 12:32:34.418494
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        _LOGIN_URL = 'http://learning.oreilly.com/accounts/login/'

    ie = TestSafariBaseIE()
    assert ie._LOGIN_URL =='http://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-26 12:32:41.896328
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    def _try(cls, url_ok, url_fail=None):
        assert cls.suitable(url_ok)
        if url_fail:
            assert not cls.suitable(url_fail)
        return cls.ie_key(url_ok)
    assert _try(SafariCourseIE, 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838') == 'SafariApi'
    assert _try(SafariCourseIE, 'http://techbus.safaribooksonline.com/9780134426365') == 'SafariApi'
    assert _try(SafariCourseIE, 'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')

# Generated at 2022-06-26 12:32:45.722262
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Test the constructor of class SafariCourseIE
    """
    SafariCourseIE("http://techbus.safaribooksonline.com/9780134426365")

# Generated at 2022-06-26 12:32:49.423559
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert SafariCourseIE is safari_course_ie.__class__
    assert SafariCourseIE.IE_NAME == safari_course_ie.IE_NAME
    assert SafariCourseIE.IE_DESC == safari_course_ie.IE_DESC
    assert SafariCourseIE._VALID_URL == safari_course_ie._VALID_URL
    assert SafariCourseIE._TESTS == safari_course_ie._TESTS
    assert SafariCourseIE.suitable(SafariCourseIE._TESTS[0].get('url'))
    assert not SafariCourseIE.suitable('Invalid URL')

# Generated at 2022-06-26 12:32:50.255878
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    instance = SafariApiIE()

# Generated at 2022-06-26 12:32:50.798578
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-26 12:32:58.557324
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Tested page: https://www.safaribooksonline.com/api/v1/book/9781449396459/part00.html
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/part00.html'
    course_id = '9781449396459'
    part = 'part00'
    course = {}
    course['title'] = 'Python Cookbook'
    course['author'] = 'Alex Martelli'
    course['web_url'] ='https://www.safaribooksonline.com/library/view/python-cookbook-2nd/9781449396459/part00.html'
    course['_id'] = '9781449396459/part00'

# Generated at 2022-06-26 12:33:49.516729
# Unit test for constructor of class SafariIE
def test_SafariIE():

    # Test 1: No Arguments provided
    # Expected Output: None
    assert not SafariIE()

    # Test 2: Constructor called with Test URL
    # Expected Output: Object of type 'class SafariIE'
    assert SafariIE('http://www.youtube.com/watch?v=BaW_jenozKc')


# Generated at 2022-06-26 12:33:57.085891
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Try to login with username and password
    Class = SafariBaseIE.__bases__[0]
    safari_info_extractor = Class(SafariBaseIE)
    safari_info_extractor._real_initialize()

    # Try to login with username and password using safari credentials
    Class = SafariBaseIE.__bases__[0]
    safari_info_extractor = Class(SafariBaseIE)
    safari_info_extractor._real_initialize()

    # Try to login with wrong username and password
    Class = SafariBaseIE.__bases__[0]
    safari_info_extractor = Class(SafariBaseIE)
    safari_info_extractor._real_initialize()

# Generated at 2022-06-26 12:34:07.083474
# Unit test for constructor of class SafariIE

# Generated at 2022-06-26 12:34:08.389742
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari.__class__.__bases__ == (InfoExtractor, )

# Generated at 2022-06-26 12:34:09.333484
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Open a file for writing
    safari_ie = SafariIE()

# Generated at 2022-06-26 12:34:10.305798
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariie = SafariIE()
    assert isinstance(safariie, SafariIE)

# Generated at 2022-06-26 12:34:22.857882
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # when not logged in
    safari_base_ie = SafariBaseIE('not-logged-in-username', 'not-logged-in-password')
    assert safari_base_ie.LOGGED_IN == False
    assert safari_base_ie.account_username == 'not-logged-in-username'
    assert safari_base_ie.account_password == 'not-logged-in-password'
    assert safari_base_ie.IE_NAME == 'safari'
    assert safari_base_ie.IE_DESC == 'safaribooksonline.com online video'
    assert safari_base_ie._NETRC_MACHINE == 'safari'
    assert safari_base_ie._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-26 12:34:34.221209
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9780133392838'
    part = 'part00'
    url = 'https://www.safaribooksonline.com/api/v1/book/%s/chapter/%s.html' % (course_id, part)
    expected_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

    # html5lib 2.5.1 doesn't support refreshing cookies in player session
    # without these cookies safaribooksonline will return JS player with
    # 'Access Denied' error
    http_session = requests.Session()
    http_session.cookies.set('orm-jwt', '{}', domain='.safaribooksonline.com')

# Generated at 2022-06-26 12:34:37.553928
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie.url = 'https://learning.oreilly.com/learn/JavaScript-and-JSON-Essentials'
    ie.username = 'test_user'
    ie.password = 'test_password'
    ie._real_initialize()

# Generated at 2022-06-26 12:34:40.461888
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    inst = SafariCourseIE()
    assert inst.suitable(url)

# Generated at 2022-06-26 12:36:04.305030
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/javascript-cookbook/9781449399022/ch01s06.html'
    test_SafariIE = SafariIE()
    test_SafariIE.suitable(url)

# Generated at 2022-06-26 12:36:07.185064
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE('safariapi:abc')
    safari_api_ie._real_extract('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')

# Generated at 2022-06-26 12:36:13.708021
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..test import get_testcases
    from ..utils import merge_dicts
    from .common import InfoExtractor
    from .kaltura import KalturaIE

    SAFARI_TESTS_TEMPLATE = {
        'add_ie': [SafariIE, SafariApiIE, SafariCourseIE],
        'expected_warnings': ['Failed to login'],
        'skip': 'Requires safaribooksonline account credentials',
    }


# Generated at 2022-06-26 12:36:19.145618
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url_ok = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    url_not_ok = 'https://www.safaribooksonline.com/library/view/kubernetes-cookbook/9781786462999/'
    ie = SafariApiIE()
    assert ie.suitable(url_ok)
    assert not ie.suitable(url_not_ok)

# Generated at 2022-06-26 12:36:27.833344
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE.suitable(SafariIE._VALID_URL)
    assert not SafariIE.suitable(SafariCourseIE._VALID_URL)
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/dont_exists/9999/part00.html')
    assert SafariIE.suitable('https://techbus.safaribooksonline.com/9780134664057/RHCE_Introduction.html')
    assert SafariIE.suitable('https://www.oreilly.com/library/view/dont_exists/9999/part00.html')
    assert SafariIE.suitable('https://learning.oreilly.com/videos/dont_exists/9999/9780134664057-00_SeriesIntro')
    assert SafariIE.suitable

# Generated at 2022-06-26 12:36:28.921584
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE(None)

# Generated at 2022-06-26 12:36:36.427403
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Note that arbitrary incorrect Usernames and Passwords are used for testing
    # Here we are testing that the constructor of SafariIE is called as expected with given credentials
    from .common import FakeLogin, FakeLoginReturningHtml
    SafariIE._login = FakeLogin('testuser', 'testpass')
    SafariIE.__init__(SafariIE)
    # The following code is expected to be executed in the constructor of SafariIE
    # The __init__ of SafariIE calls _real_initialize and this in turn calls _login
    # The _login function is overridden here by a FakeLogin function which in turn calls _download_webpage and _call_rpc
    # The _download_webpage is overridden by FakeLoginReturningHtml
    # The FakeLoginReturningHtml returns an HTML page with redirect url and urls ending with "/accounts/login

# Generated at 2022-06-26 12:36:40.588497
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie._VALID_URL == SafariApiIE._VALID_URL
    # test _real_initialize
    try:
        ie._real_initialize()
    except ExtractorError as e:
        assert str(e).startswith('Unable to download kaltura session JSON')
    # test _real_extract
    try:
        ie._real_extract('http://www.url.com')
    except ExtractorError as e:
        assert str(e).startswith('Invalid URL')



# Generated at 2022-06-26 12:36:42.763198
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_instance = SafariCourseIE()
    assert test_instance._API_FORMAT == 'json'
    assert test_instance._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-26 12:36:46.378190
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(None)._real_initialize()
    SafariIE(None)._real_extract('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

# Generated at 2022-06-26 12:39:48.279337
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    course_id = '9780133392838'
    mobile_url = (
        'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/'
        + course_id)

    safari_base_ie = SafariBaseIE()
    safari_base_ie._login()

    safari_base_ie._real_extract(mobile_url)

    safari_base_ie.download(['https://learning.oreilly.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html'])

# Generated at 2022-06-26 12:39:56.741435
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    assert safari.LOGGED_IN == False
    assert safari._IE_NAME == 'safari'
    assert safari._API_FORMAT == 'json'
    assert safari._NETRC_MACHINE == 'safari'
    assert safari._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-26 12:40:02.731419
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE(None)
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False
    assert ie._login() == None
    assert ie.LOGGED_IN == True
    assert ie._login() == None
    assert ie.LOGGED_IN == True


# Generated at 2022-06-26 12:40:13.568342
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class FakeSafariBaseIE(SafariBaseIE):
        IE_NAME = 'test_safari'

        _TEST = {
            'url': 'http://www.safaribooksonline.com/foo/bar',
            'info_dict': {
                'id': 'foo/bar',
            },
            'playlist': [
                {
                    'info_dict': {
                        'id': 'foo/bar/ch1',
                    },
                },
                {
                    'info_dict': {
                        'id': 'foo/bar/ch2',
                    },
                },
            ]
        }


# Generated at 2022-06-26 12:40:17.287960
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    sa = SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')
    print(sa)

# Generated at 2022-06-26 12:40:28.062296
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    inp1 = {
        'username': 'user',
        'password': 'pass'
    }
    inp2 = {
        'username': 'user',
        'password': 'pass'
    }
    inp3 = {
        'username': 'user',
        'password': 'pass'
    }
    inp4 = {
    }
    inp5 = {
        'username': 'user'
    }
    inp6 = {
        'password': 'pass'
    }
    inp7 = {
        'username': 'user',
        'password': 'pass'
    }
    inp8 = {
        'username': 'user',
        'password': 'pass'
    }

# Generated at 2022-06-26 12:40:32.672033
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import unittest
    import tests.test_utils
    suite = unittest.TestLoader().loadTestsFromTestCase(
        tests.test_utils.TestSafariApiIE)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-26 12:40:37.006167
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        a = SafariBaseIE()
        b = SafariApiIE()
        assert False  # It should not reach here
    except:
        pass

# Generated at 2022-06-26 12:40:42.827451
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_downloads import _run_downloader

    _run_downloader(SafariApiIE, [
        ('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part01.html', {
            'skip': 'Requires safaribooksonline account credentials'
        })
    ])

# Generated at 2022-06-26 12:40:48.526457
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_DESC == 'safaribooksonline.com online video'