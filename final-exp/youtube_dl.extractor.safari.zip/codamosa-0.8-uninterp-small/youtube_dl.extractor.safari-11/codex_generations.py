

# Generated at 2022-06-26 12:31:33.115223
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:31:34.922366
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e = SafariBaseIE()
    safari_base_i_e._real_initialize()
    safari_base_i_e._login()

# Generated at 2022-06-26 12:31:36.129710
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e = SafariBaseIE()

# Generated at 2022-06-26 12:31:38.332064
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()

# Basic test for constructor of class SafariCourseIE

# Generated at 2022-06-26 12:31:39.570890
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:31:40.697798
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e = SafariBaseIE()

# Generated at 2022-06-26 12:31:41.763097
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()


# Generated at 2022-06-26 12:31:42.721623
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()


# Generated at 2022-06-26 12:31:44.272512
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:31:46.530279
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        test_case_0()
    except Exception as ex:
        print(str(ex))

# Generated at 2022-06-26 12:32:25.628621
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()


# Generated at 2022-06-26 12:32:27.884319
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_case_0()


# Generated at 2022-06-26 12:32:35.894356
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert(SafariBaseIE.IE_NAME == 'SafariBase')
    assert(SafariBaseIE.IE_DESC == 'safaribooksonline.com base extractor')
    assert(SafariBaseIE._VALID_URL == None)
    assert(SafariBaseIE._NETRC_MACHINE == 'safari')
    assert(SafariBaseIE.LOGGED_IN == False)
    assert(SafariBaseIE._API_BASE == 'https://learning.oreilly.com/api/v1')
    assert(SafariBaseIE._API_FORMAT == 'json')


# Generated at 2022-06-26 12:32:36.727460
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE.__doc__ == None

# Generated at 2022-06-26 12:32:38.736778
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()
    return


# Generated at 2022-06-26 12:32:46.321480
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    safari_ie = SafariIE(downloader=None, download_config=None, params=None)
    assert safari_ie.suitable(test_url) == True


# Generated at 2022-06-26 12:32:54.970520
# Unit test for constructor of class SafariIE
def test_SafariIE():
    name = "safari"
    description = "safaribooksonline.com online video"
    valid_url = r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    '''

# Generated at 2022-06-26 12:33:01.280902
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    class_ = SafariCourseIE
    arg0 = 'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314'
    x1 = class_(arg0, {'some': 'context'})
    assert(x1.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') == True)
    assert(x1.suitable('https://www.safaribooksonline.com/library/view/essentials-of-statistics/9780134043001/') == True)

# Generated at 2022-06-26 12:33:04.337790
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    example_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    safari_api_i_e_1 = SafariApiIE()
    safari_api_i_e_0 = SafariApiIE(example_url)


# Generated at 2022-06-26 12:33:06.055378
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Unit test for the constructor of class SafariApiIE

    safari_api_i_e = SafariApiIE()
    # Verify that the object was constructed successfully.
    assert safari_api_i_e is not None



# Generated at 2022-06-26 12:33:51.855975
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    constructor_test(SafariApiIE, [
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part01.html'
    ])

# Generated at 2022-06-26 12:33:53.357628
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE(SafariBaseIE, 'Safari').safari()
    assert isinstance(obj, SafariApiIE)

# Generated at 2022-06-26 12:34:03.521116
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/javascript-the-definitive/9781449391414/Video15_1.html'
    # A course id of length 23 but contain non-digit characters
    non_digit_course_id_url = 'https://www.safaribooksonline.com/library/view/create-a-nodejs/100000006A0210/Video1_1.html'
    # A course id of length 23 but contain non-digit characters
    digit_course_id_url = 'https://www.safaribooksonline.com/library/view/nodejs-the-right/9781785283351/Video1_1.html'

    # Get course id with non-digit characters from URL

# Generated at 2022-06-26 12:34:07.015273
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari = SafariBaseIE()
    # TODO: assert safari.IE_NAME 
    assert safari.IE_DESC == 'safaribooksonline.com online video'
    # TODO: assert safari._VALID_URL 
    assert safari.LOGGED_IN == False



# Generated at 2022-06-26 12:34:08.214922
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE()
    assert isinstance(safariBaseIE, InfoExtractor)

# Generated at 2022-06-26 12:34:09.176916
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert safari is not None

# Generated at 2022-06-26 12:34:10.767293
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safariapi = SafariApiIE('SafariApiIE')
    assert safariapi.LOGGED_IN == False

# Generated at 2022-06-26 12:34:11.600625
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE()

# Generated at 2022-06-26 12:34:13.364092
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    c = SafariCourseIE()
    c.suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")

# Generated at 2022-06-26 12:34:22.361591
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .. import get_testcases
    from ..testcases import conditional_extractor
    from ..testcases import YoutubeIE
    testcases = get_testcases()
    for t in testcases:
        if isinstance(t, conditional_extractor):
            for tc in t.testcases:
                if isinstance(tc, YoutubeIE):
                    input_url = tc.url
                    safari_course_ie = SafariCourseIE(testcases)
                    assert input_url != safari_course_ie._VALID_URL

# Generated at 2022-06-26 12:35:48.499242
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''

# Generated at 2022-06-26 12:35:52.500991
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('SafariCourseIE', 'safaribooksonline.com')
    SafariCourseIE('SafariCourseIE', 'learning.oreilly.com')
    SafariCourseIE('SafariCourseIE', 'techbus.safaribooksonline.com')

# Generated at 2022-06-26 12:36:00.120921
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    IE = SafariApiIE()
    # testing multiple inheritance of SafariApiIE with SafariBaseIE
    assert(hasattr(IE, '_NETRC_MACHINE'))
    assert(hasattr(IE, '_LOGIN_URL'))
    assert(hasattr(IE, 'LOGGED_IN'))
    assert(IE._NETRC_MACHINE == 'safari')
    assert(IE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/')
    assert(IE.LOGGED_IN == False)
    assert(IE.IE_NAME == 'safari:api')
    assert(IE.IE_DESC == 'safaribooksonline.com online video')
    # testing multiple inheritance of SafariBaseIE with InfoExtractor

# Generated at 2022-06-26 12:36:08.984276
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import os
    import unittest
    try:
        from urllib.parse import urlparse
    except ImportError:
        from urlparse import urlparse
    import tempfile

    from youtube_dl import YoutubeDL
    from youtube_dl.utils import (
        compat_http_client,
        compat_kwargs,
    )

    from .test_common import get_testdata_file

    # Create a dummy cookie jar
    cookie_jf = tempfile.NamedTemporaryFile(mode='w', delete=False)
    cookie_jf.close()
    cookie_jf_name = cookie_jf.name

    # Create a dummy netrc file
    netrc_f = tempfile.NamedTemporaryFile(mode='w', delete=False)

# Generated at 2022-06-26 12:36:14.131475
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course_id = '9780133392838'
    course_json = json.loads(SafariCourseIE._download_webpage(course_url, course_id, 'Downloading course JSON'))
    assert 'chapters' in course_json
    assert 'title' in course_json

# Generated at 2022-06-26 12:36:18.334479
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")
    assert obj.suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")

# Generated at 2022-06-26 12:36:22.495621
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safari = SafariIE()
    result = safari._real_extract(test_url)
    assert('mwEmbedFrame.php' in result['url'])

# Generated at 2022-06-26 12:36:27.232322
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Testing if SafariCourseIE constructor throw Exception if url is not safaribooksonline.com url.
    url = "www.udemy.com"
    try:
        SafariCourseIE(url)
        assert False, 'SafariCourseIE constructor should throw Exception if some other url is passed to it. '
    except Exception:
        pass
    else:
        assert False, 'SafariCourseIE constructor should throw Exception if some other url is passed to it. '

# Generated at 2022-06-26 12:36:34.352033
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    if __name__ == '__main__':
        from .test_html import get_urls_and_descriptions

        urls = []
        descriptions = []
        for chapter in get_urls_and_descriptions(
                ["http://www.safaribooksonline.com/library/view/python-cookbook-3rd/9781449357337/"]):
            if "part" in chapter[0]:
                urls.append(chapter[0])
                descriptions.append(chapter[1])
        for url, description in zip(urls, descriptions):
            SafariApiIE()._real_extract(url)

# Generated at 2022-06-26 12:36:37.699823
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariBaseIE._login = lambda x: None
    stringToTest = '''https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'''
    a = SafariIE()
    a.extract(stringToTest)

# Generated at 2022-06-26 12:39:18.201728
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-26 12:39:24.079380
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_c = SafariCourseIE()
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    assert safari_c.suitable(url)

# Generated at 2022-06-26 12:39:27.996586
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert isinstance(safari_course_ie, SafariBaseIE)
    assert isinstance(safari_course_ie, InfoExtractor)

# Generated at 2022-06-26 12:39:39.118710
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('safari', 'safaribooksonline.com')
    # Test the constructor of SafariApiIE
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False

# Generated at 2022-06-26 12:39:42.128881
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ..utils import TestFailureException
    test = SafariApiIE()
    assert isinstance(test, SafariApiIE)

# Generated at 2022-06-26 12:39:52.352310
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.suitable('http://techbus.safaribooksonline.com/9780134426365')
    assert safari_course_ie.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314')
    assert safari_course_ie.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
    assert safari_course_ie.suitable('https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')


# Generated at 2022-06-26 12:39:53.752973
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()

# Generated at 2022-06-26 12:40:03.554697
# Unit test for constructor of class SafariIE
def test_SafariIE():
    mocker, safari_ie = (mocker, SafariIE())

    # Test if session download is skipped if already logged in
    mocker.patch.object(safari_ie, 'LOGGED_IN', True)
    safari_ie._login()
    safari_ie._download_json.assert_not_called()
    safari_ie._apply_first_set_cookie_header.assert_not_called()
    safari_ie._download_webpage.assert_not_called()

    # Test if session downloading skips and log in fails if
    # urlh.geturl() is not logged in url
    mocker.patch.object(safari_ie, 'LOGGED_IN', False)

# Generated at 2022-06-26 12:40:06.177601
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('safari:api')
    assert ie.IE_NAME == 'safari:api'

# Generated at 2022-06-26 12:40:10.616347
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Test the constructor of the class SafariCourseIE"""
    e = SafariCourseIE()
    assert isinstance(e, SafariCourseIE)
    assert isinstance(e, SafariBaseIE)
    assert isinstance(e, InfoExtractor)