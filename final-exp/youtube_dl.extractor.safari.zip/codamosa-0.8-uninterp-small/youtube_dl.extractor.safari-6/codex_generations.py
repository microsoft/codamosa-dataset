

# Generated at 2022-06-26 12:31:34.563367
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_base_i_e_1 = SafariBaseIE()
    safari_api_i_e_0 = SafariApiIE()
    safari_api_i_e_1 = SafariApiIE(safari_base_i_e_1)

# Generated at 2022-06-26 12:31:35.698780
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:31:36.952002
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    constructor = SafariApiIE()


# Generated at 2022-06-26 12:31:38.417773
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
	safari_course_i_e_0 = SafariCourseIE()


# Generated at 2022-06-26 12:31:39.313040
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()


# Generated at 2022-06-26 12:31:45.310420
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test_course_id = '9781449396459'
    test_part = 'part01'
    test_url = 'https://www.safaribooksonline.com/api/v1/book/' + test_course_id + '/chapter/' + test_part + '.html'
    safari_api_i_e_0 = SafariApiIE()
    assert safari_api_i_e_0._real_initialize() == None
    assert safari_api_i_e_0._real_extract(test_url) == 'https://www.safaribooksonline.com/library/view/' + test_course_id + '/' + test_part + '.html'

# Generated at 2022-06-26 12:31:50.133796
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        # Test the url_result before instantiating SafariCourseIE
        test_case_0()
        test_case_0()
    except Exception as e:
        print(e)
    else:
        print('success')
    # Test the constructor of SafariCourseIE
    safari_course_i_e_0 = SafariCourseIE()

test_SafariCourseIE()

# Generated at 2022-06-26 12:31:51.977558
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test case where no valid URL is passed
    safari_i_e = SafariIE()

# Generated at 2022-06-26 12:31:53.251481
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()


# Generated at 2022-06-26 12:31:54.258623
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_SafariCourseIE_0 = SafariCourseIE()


# Generated at 2022-06-26 12:32:17.655119
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE()
    assert obj.LOGGED_IN == False


# Generated at 2022-06-26 12:32:19.738993
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    SafariApiIE(url)


# Generated at 2022-06-26 12:32:20.696903
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:32:25.665625
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert len(str(SafariApiIE()))>0

# Generated at 2022-06-26 12:32:30.718166
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()
    safari_i_e_1 = SafariIE()
    safari_i_e_2 = SafariIE()
    safari_i_e_3 = SafariIE()


# Generated at 2022-06-26 12:32:32.437876
# Unit test for constructor of class SafariIE
def test_SafariIE():
    i_e = SafariIE()
    assert isinstance(i_e, SafariIE) == True


# Generated at 2022-06-26 12:32:35.139803
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert callable(SafariCourseIE)
    assert callable(SafariCourseIE.suitable)
    assert callable(SafariCourseIE._real_extract)


# Generated at 2022-06-26 12:32:42.317572
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()
    assert safari_i_e_0.LOGGED_IN is False
    assert safari_i_e_0._API_FORMAT == 'json'
    assert safari_i_e_0._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_i_e_0._PARTNER_ID == '1926081'
    assert safari_i_e_0._UICONF_ID == '29375172'
    assert safari_i_e_0._NETRC_MACHINE == 'safari'
    assert safari_i_e_0._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'


# Generated at 2022-06-26 12:32:48.428682
# Unit test for constructor of class SafariIE
def test_SafariIE():
    video_url = 'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00'
    safari_i_e = SafariIE()
    assert isinstance(safari_i_e, InfoExtractor) and isinstance(safari_i_e, SafariBaseIE)


# Generated at 2022-06-26 12:32:50.623773
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Construct instance of class SafariCourseIE
    safari_course_i_e_0 = SafariCourseIE()
    assert(safari_course_i_e_0.IE_DESC == "safaribooksonline.com online courses")
    assert(safari_course_i_e_0.IE_NAME == "safari:course")
    return

# Generated at 2022-06-26 12:33:30.885437
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e = SafariBaseIE()


# Generated at 2022-06-26 12:33:32.258102
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from pytube import SafariApiIE
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:33:33.117504
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:33:35.572702
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert safari_base_i_e_0.LOGGED_IN == False


# Generated at 2022-06-26 12:33:36.522126
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:33:38.726431
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()

# Generated at 2022-06-26 12:33:40.234494
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:33:41.397655
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE(SafariBaseIE())


# Generated at 2022-06-26 12:33:44.294436
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_1 = SafariBaseIE()
    assert isinstance(safari_base_i_e_1, SafariBaseIE)

# Generated at 2022-06-26 12:33:46.059371
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test case for subclass of InfoExtractor
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:34:21.738673
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'

    safari_course_ie = SafariCourseIE()
    info_dict = safari_course_ie.extract(url)

    assert safari_course_ie._match_id(url) == '9781449396459'
    assert info_dict['id'] == '9781449396459'

# Generated at 2022-06-26 12:34:24.379839
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url_to_test = 'http://techbus.safaribooksonline.com/9780134426365'
    assert SafariCourseIE.suitable(url_to_test)

# Generated at 2022-06-26 12:34:28.109374
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    extractor = SafariCourseIE()
    instance = extractor._real_extract("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/")
    return instance['entries']

# Generated at 2022-06-26 12:34:34.022167
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    construct_SafariBaseIE = SafariBaseIE("SafariBaseIE", "safaribooksonline.com")
    assert str(construct_SafariBaseIE) == """<class 'youtube_dl.extractor.safari.SafariBaseIE'>('SafariBaseIE', 'safaribooksonline.com')"""

# Generated at 2022-06-26 12:34:37.466133
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')

# Generated at 2022-06-26 12:34:45.441553
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_cases = (
        (
            {'username': 'foo', 'password': 'bar'},
            {'username': 'foo', 'password': 'bar'}
        ),
        (
            {'username': '', 'password': ''},
            {'password': '', 'username': ''}
        ),
        (
            {'username': None, 'password': None},
            {'password': None, 'username': None}
        ),
    )

    for case in test_cases:
        safari_base_ie = SafariBaseIE(**case[0])
        assert safari_base_ie.login_info == case[1]

# Generated at 2022-06-26 12:34:47.360333
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE()
    safariBaseIE._real_initialize()
    assert safariBaseIE.LOGGED_IN is False

# Generated at 2022-06-26 12:34:51.635368
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from ..test_utils import uniq
    from ..compat import compat_str
    from ..utils import TestDownloader

    # Constructor of class TestDownloader doesn't require any parameter.
    td = TestDownloader()


# Generated at 2022-06-26 12:34:57.937576
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class TestSafariApiIE(SafariApiIE):
        # Unit test for _download_webpage_handle
        def _download_webpage_handle(self, url_or_request, video_id,
                note='Testing _download_webpage_handle', errnote='test failed', *args, **kwargs):
            return (None, {
                'url': url_or_request,
                'handle': None,
            })

        # Unit test for _download_json
        def _download_json(self, url_or_request, video_id,
                note='Testing _download_json', errnote='test failed',
                fatal=True, headers=None, query=None, data=None, *args, **kwargs):
            return {
                'web_url': url_or_request,
            }



# Generated at 2022-06-26 12:34:58.554518
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-26 12:36:19.516144
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert isinstance(ie, SafariBaseIE)

# Generated at 2022-06-26 12:36:28.611094
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    expected_url = 'https://www.safaribooksonline.com/library/view/learning-javascript/9781449391414/ch00.html'

    safari_api_ie = SafariApiIE()
    mobj = re.match(SafariApiIE._VALID_URL, url)
    safari_api_ie._real_initialize()

    part = safari_api_ie._download_json(
        url, '%s/%s' % ('9781449396459', 'ch00'),
        'Downloading part JSON')

# Generated at 2022-06-26 12:36:36.270665
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        n = SafariBaseIE._download_webpage
    except AttributeError:
        raise AttributeError('SafariBaseIE._download_webpage not exist')
    if not 'safaribooksonline' in n.__module__:
        raise TypeError('SafariBaseIE._download_webpage not in safaribooksonline')
    try:
        n = SafariBaseIE.set_cookies
    except AttributeError:
        raise AttributeError('SafariBaseIE.set_cookies not exist')
    if not 'safaribooksonline' in n.__module__:
        raise TypeError('SafariBaseIE.set_cookies not in safaribooksonline')
    try:
        n = SafariBaseIE.logged_in
    except AttributeError:
        raise

# Generated at 2022-06-26 12:36:44.813616
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_utils import fake_urlopen


# Generated at 2022-06-26 12:36:52.706855
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..test import get_testdata_file_path

    # Check SafariBaseIE.__init__()
    with open(get_testdata_file_path('safari_config.json')) as f:
        safari_config = json.load(f)

    ie = SafariBaseIE(None)
    assert ie.LOGGED_IN is False

    with open(get_testdata_file_path('safari_config_logged_in.json')) as f:
        safari_config_logged_in = json.load(f)

    ie = SafariBaseIE(None, safari_config_logged_in)
    assert ie.LOGGED_IN is True

    # Check SafariBaseIE._login()
    #
    # The procedure is:
    # 0) Check if user is logged in or not


# Generated at 2022-06-26 12:36:56.767000
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE()
    print(obj.IE_NAME)
    print(obj.IE_DESC)
    print(obj._VALID_URL)
    print(obj._TESTS)
    print(obj.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'))

# Generated at 2022-06-26 12:36:58.466768
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'


# Generated at 2022-06-26 12:36:59.337433
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # test some edge cases of constructor
    assert SafariCourseIE(None)

# Generated at 2022-06-26 12:37:00.533921
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # test the constructor for SafariBaseIE
    x = SafariBaseIE()
    assert not x.LOGGED_IN

# Generated at 2022-06-26 12:37:02.536837
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class_ = globals()['SafariApiIE']
    constructor = class_._real_initialize
    constructor()



# Generated at 2022-06-26 12:39:47.502418
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # try:
        safariIE = SafariIE()
        # safariIE.download_webpage(safariIE._LOGIN_URL, None)
        safariIE._login()
    # except Exception as e:
    #     print(e)


# Generated at 2022-06-26 12:39:48.901529
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('safari')

# Generated at 2022-06-26 12:39:54.528166
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Script to test unittest for SafariCourseIE class"""
    import sys
    import os.path
    import pprint
    from .common import post_video_info_to_server
    try:
        url = sys.argv[1]
    except:
        url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/'
    safari_course_ie = SafariCourseIE()
    result = safari_course_ie._real_extract(url)
    pprint.pprint(result)
    post_video_info_to_server(result)

# Generated at 2022-06-26 12:40:03.870899
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # we must regenerate the expected result because the timestamp of the video
    # is not stored in the source file
    ie = SafariApiIE()
    course_title = 'Introduction to Hadoop Fundamentals LiveLessons'
    course_id = '0_qbqx90ic'
    extracted = ie._real_extract(
        'https://learning.oreilly.com/api/v1/book/9780133392838/chapter/part00.html', '', '', '')
    expected = ie._real_extract(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
        course_id, course_title, True)
    assert extracted == expected

# Generated at 2022-06-26 12:40:08.796070
# Unit test for constructor of class SafariIE
def test_SafariIE():
    import sys
    assert sys.argv[0] == 'test_safari'
    from . import _test_i18n
    _test_i18n.test_IE_class(SafariIE)
    return 0


# Generated at 2022-06-26 12:40:15.368898
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-26 12:40:21.709815
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariCourseIE = SafariCourseIE()
    assert(safariCourseIE._API_BASE == 'https://learning.oreilly.com/api/v1')
    assert(safariCourseIE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/')
    assert(safariCourseIE._NETRC_MACHINE == 'safari')

# Generated at 2022-06-26 12:40:28.905421
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if SafariBaseIE.IE_NAME is None or SafariBaseIE.IE_NAME == 'safari':
        # safari doesn't require login, ignore it
        return
    ie = SafariBaseIE(SafariBaseIE.ie_key())
    ie.extract('http://safaribooksonline/')

# Generated at 2022-06-26 12:40:36.868538
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Test without login
    """
    ie = SafariIE()

    course_id = "9780134217314"
    reference_id = "9780134217314-PYMC_03_00"

    query = {
        "wid": '_' + ie._PARTNER_ID,
        "uiconf_id": ie._UICONF_ID,
        "flashvars[referenceId]": reference_id,
    }

    result_url = update_url_query('https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php', query)


# Generated at 2022-06-26 12:40:40.695074
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_safari import SafariCourseIE as cls
    from .test_safari import _test_descriptor
    _test_descriptor(cls)