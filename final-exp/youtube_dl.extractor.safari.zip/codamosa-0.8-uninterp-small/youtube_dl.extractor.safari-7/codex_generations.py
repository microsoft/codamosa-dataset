

# Generated at 2022-06-26 12:31:31.502556
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()

# Generated at 2022-06-26 12:31:40.810554
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    print("==== Unit test for gamepedia constructor ====")
    safari_base_i_e = SafariBaseIE()
    assert safari_base_i_e.IE_NAME == 'safari'
    assert safari_base_i_e.IE_DESC == 'safaribooksonline.com online video'
    assert safari_base_i_e._VALID_URL == r'(?x)https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html'

# Generated at 2022-06-26 12:31:41.603223
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()


# Generated at 2022-06-26 12:31:44.035037
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'url'
    safari_course_i_e_0 = SafariCourseIE(url)
    assert safari_course_i_e_0.name == 'safari:course'

# Generated at 2022-06-26 12:31:45.992815
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()


# Generated at 2022-06-26 12:31:47.169799
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:31:50.869241
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE.ie_key()
    safari_i_e_1 = SafariIE.ie_key()
    assert safari_i_e_0 == 'Kaltura'

test_SafariIE()



# Generated at 2022-06-26 12:31:52.053666
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_base_ie_0 = SafariCourseIE()

# Generated at 2022-06-26 12:31:55.354953
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert safari_api_i_e_0.IE_NAME == 'safari:api'
    assert safari_api_i_e_0.IE_DESC == 'safaribooksonline.com online video'
    assert safari_api_i_e_0.IE_VERSION == '0.0.2'

# Generated at 2022-06-26 12:32:03.616154
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-26 12:32:27.987066
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    raise NotImplementedError(
        'Constructor for class SafariCourseIE not found')

# Generated at 2022-06-26 12:32:29.870909
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Construct the instance of class SafariBaseIE
    SafariBaseIE()

# Generated at 2022-06-26 12:32:38.276162
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_SafariIE import SafariIE
    assert SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')
    assert not SafariApiIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/part00.html')
    assert SafariApiIE.ie_key() == 'safari:api'
    assert SafariApiIE('safari:api').suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html')

# Generated at 2022-06-26 12:32:50.441986
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    When SafariIE gets a URL, it should check to see if that URL is a valid Safari URL
    and if it is, create a SafariIE instance.
    """

    # If SafariIE gets a non-Safari URL, it should return None.
    url = ('http://www.youtube.com/watch?v=TzB2qY3q3_M')
    ie = SafariIE(url)
    assert ie is None

    # If SafariIE gets a Safari URL, it should return a SafariIE instance.
    url = ('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro.html')
    ie = SafariIE(url)
    assert isinstance(ie, SafariIE)

    # If SafariIE

# Generated at 2022-06-26 12:32:53.841885
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE.from_url('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert ie.title == 'Hadoop Fundamentals LiveLessons'

# Generated at 2022-06-26 12:32:57.521261
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert(SafariBaseIE.suitable("https://techbus.safaribooksonline.com/9780134426365") == True)
    assert(SafariBaseIE.suitable("https://techbus.safaribooksonline.com/9780134426365/9780134426365_ch01_00") == False)
    return



# Generated at 2022-06-26 12:32:59.868753
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # This is not a real test, but instead of a type check
    try:
        SafariCourseIE("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json")
    except:
        assert False

# Generated at 2022-06-26 12:33:00.550829
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()



# Generated at 2022-06-26 12:33:05.696635
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_input_URL = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    test_output_ID = '9780133392838'
    test_output_title = 'Hadoop Fundamentals LiveLessons'
    test_output_playlist_count = 22

    parsed_url = compat_urlparse.urlparse(test_input_URL)

    safari_course_IE_test = SafariCourseIE(test_input_URL)

    assert safari_course_IE_test._match_id(test_input_URL) == test_output_ID
    assert safari_course_IE_test._VALID_URL == SafariCourseIE._VALID_URL
    assert safari_course_IE_test._download

# Generated at 2022-06-26 12:33:07.585257
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    sai = SafariApiIE()
    sai._real_initialize()


# Generated at 2022-06-26 12:33:58.180004
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie._initialize()
    assert ie.LOGGED_IN == False

    class MockLogin(SafariBaseIE):
        _LOGIN_URL = 'https://learning.oreilly.com/accounts/login/'
        _NETRC_MACHINE = 'safari'

        def _real_initialize(self):
            pass

        def _download_webpage_handle(self, *args, **kwargs):
            return None, None

        def _apply_first_set_cookie_header(self, *args, **kwargs):
            pass

        def _download_json_handle(self, *args, **kwargs):
            return None, None


# Generated at 2022-06-26 12:34:00.226502
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribase = SafariBaseIE()
    assert safaribase.IE_NAME == 'safari'
    assert safaribase.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-26 12:34:03.790260
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    IE = SafariApiIE()
    assert isinstance(IE, SafariBaseIE)

# Generated at 2022-06-26 12:34:04.455466
# Unit test for constructor of class SafariIE
def test_SafariIE():
    print(SafariIE(None))


# Generated at 2022-06-26 12:34:09.208279
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """
    Simple unit test for SafariCourseIE
    """
    sample_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    instance = SafariCourseIE(sample_url)
    assert instance.suitable(sample_url)
    assert instance.extract()['title'] == 'Hadoop Fundamentals LiveLessons'
    assert instance._VALID_URL == instance.VALID_URL

# Generated at 2022-06-26 12:34:09.708505
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-26 12:34:10.462696
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE()._VALID_URL is not None

# Generated at 2022-06-26 12:34:23.243229
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .common import fake_options
    from .common import FakeYDL
    import sys
    import json

    sys.stdin.buffer = sys.stdin
    sys.stdin._saved_attrs = ('encoding',)
    sys.stdin.encoding = 'utf8'
    with open('test/test_safari.json', 'r') as test_file:
        test = json.loads(test_file.read())

    def test_safari(test):
        class TestSafari(SafariBaseIE):
            _TEST = test
            _API_BASE = 'http://test'
            _LOGIN_URL = 'http://test'

            def _real_initialize(self):
                pass


# Generated at 2022-06-26 12:34:30.038379
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # the following test case was taken from the website of safaribooksonline.com
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html?override_format=json'
    try:
        # It should not be an error
        SafariApiIE()._real_extract(url)
    except Exception as e:
        # In the case the above line raises an exception, here should be an error
        assert False, 'The url %s should be valid' % url

# Generated at 2022-06-26 12:34:38.834129
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html'

# Generated at 2022-06-26 12:36:06.500755
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    extractor_test(SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'), 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-26 12:36:13.307418
# Unit test for constructor of class SafariIE
def test_SafariIE():
    input_url = 'https://learning.oreilly.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00'
    expected_result = {
        'partner_id': '1926081',
        'video_id': '9780134217314-PYMC_13_00',
        'reference_id': '9780134217314-PYMC_13_00',
        'ui_id': '29375172'
    }
    safari_ie = SafariIE()

# Generated at 2022-06-26 12:36:21.959781
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import unittest
    import yaml
    yaml_path = os.path.join(
        os.path.dirname(__file__),
        "../../", "test", "data", "safari", "course.yml")
    expected_results = yaml.load(open(yaml_path))

    class TestSafariCourseIE(unittest.TestCase):
        def test_safari_course(self):
            for expected_result in expected_results:
                url = expected_result['url']
                ie = SafariCourseIE(url)
                self.assertEqual(ie._real_extract(url), expected_result['result'])

    unittest.main(argv=['first-arg-is-ignored'], exit=False)

# Generated at 2022-06-26 12:36:23.997341
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = "http://techbus.safaribooksonline.com/9780134426365"
    SafariCourseIE(url)

# Generated at 2022-06-26 12:36:31.743793
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    import os
    import yaml

    safe = 'SAFE'
    url = 'http://www.safaribooksonline.com/'
    expected_output = {
        'login': 'safari_login',
        'password': 'safari_password'
    }

    password_manager, output = \
        SafariBaseIE._get_netrc_auth(url, safe)

    with open(os.path.join('test', 'netrc'), 'r') as f:
        netrc_data = yaml.safe_load(f)
    netrc_data.update(expected_output)

    assert list(password_manager.passwords) == [netrc_data]
    assert output == expected_output

# Generated at 2022-06-26 12:36:32.963998
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
   assert SafariApiIE().ie_key() == 'Safari:api'

# Generated at 2022-06-26 12:36:35.438302
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314'
    inst = SafariCourseIE(url)

    assert inst.ie_key() == 'Safari'

# Generated at 2022-06-26 12:36:36.921486
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_IE = SafariCourseIE()
    assert safari_course_IE


# Generated at 2022-06-26 12:36:39.511875
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # This test ensures that the code to be executed in constructor of
    # class SafariIE is syntactically correct.
    #
    # It doesn't test the correctness of the code.
    assert SafariIE(None).LOGGED_IN == False

# Generated at 2022-06-26 12:36:48.229088
# Unit test for constructor of class SafariIE
def test_SafariIE():
    kwargs = dict(
        username='',
        password='',
        partner_id='',
        uiconf_id='',
        ie=SafariIE,
        safari=SafariIE
    )
    import json
    kwargs['login'] = kwargs['username'] is not '' and kwargs['password'] is not ''
    kwargs['api_base'] = 'https://learning.oreilly.com/api/v1'
    kwargs['api_format'] = 'json'
    kwargs['logged_in'] = False
    kwargs['_downloader'] = 'temp'
    kwargs['_password_manager'] = 'temp'
    kwargs['_filename_cleaned'] = 'temp'
    kwargs['_video_password'] = 'temp'

# Generated at 2022-06-26 12:39:42.659573
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Test case for constructor of SafariIE class.
    """

    ie = SafariIE()

    assert ie._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?#&]+)\.html'
    assert ie._TESTS == [
        {
            'url': 'https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html',
            'only_matching': True,
        }
    ]
    assert ie._PARTNER_ID == '1926081'

# Generated at 2022-06-26 12:39:49.852763
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_id = '9780134664057'
    url = 'https://www.safaribooksonline.com/library/view/{}/'.format(course_id)
    course = SafariCourseIE(SafariCourseIE.IE_NAME, url)

    assert course.course_id == course_id
    assert course.course_title is None
    assert course.chapters == []



# Generated at 2022-06-26 12:40:02.380091
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from youtube_dl.compat import unittest
    from . import YoutubeDL
    class FakeSafariIE(SafariIE):
        def _download_webpage_handle(self, *args, **kwargs):
            return 'crap', None
        def _download_json_handle(self, *args, **kwargs):
            return {}, None

    fake_ydl = YoutubeDL()
    fake_ydl.add_info_extractor(FakeSafariIE)

# Generated at 2022-06-26 12:40:05.750380
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """Instantiate a SafariBaseIE object."""
    safari_base_ie = SafariBaseIE()

# Generated at 2022-06-26 12:40:12.767486
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .netrc import _NETRC_MACHINE
    from ..compat import USER_AGENT
    from ..utils import _make_minimal_extractor

    downloader = _make_minimal_extractor(SafariBaseIE)()

    # _NETRC_MACHINE is explicitly passed to login() to test internal _NETRC_MACHINE instead of SafariBaseIE._NETRC_MACHINE
    downloader.login(user_agent=USER_AGENT, netrc_machine=_NETRC_MACHINE)

# Generated at 2022-06-26 12:40:18.999516
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        SafariApiIE()._download_json('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json', '9781449396459', 'Downloading part JSON')
    except:
        pass

# Generated at 2022-06-26 12:40:23.492808
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import unittest
    try:
        url = 'http://techbus.safaribooksonline.com/9780134426365'
        ii = SafariCourseIE(unittest.TestCase())
        ii.suitable(url)
        ii.extract(url)
    except Exception as e:
        print(e)
        assert False
    finally:
        print('test_SafariCourseIE end\n')



# Generated at 2022-06-26 12:40:34.670339
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..testcases import FakeLogin
    from ..utils import LoadSafariCookieJar

    login = FakeLogin()
    login.add_username('safari', 'safari.test')
    login.add_password('safari', 'safari.test')
    login.add_cookiejar('safari')

    # Test SafariBaseIE.__init__()
    driver = SafariBaseIE(login)
    assert isinstance(driver, SafariBaseIE)
    assert driver.get_username() == 'safari.test'
    assert driver.get_password() == 'safari.test'

    # Test SafariBaseIE._login()
    driver._login()
    assert driver.LOGGED_IN

    # Test SafariBaseIE.get_cookies()
    cookies = driver.get_cookies()
    assert cookies

# Generated at 2022-06-26 12:40:44.898137
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE("http://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro/hadoop-fundamentals-livelessons-9780133392838-00_seriesintro")
    assert ie.name == 'safari'
    assert ie.url == 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_1926081&uiconf_id=29375172&flashvars[referenceId]=9780133392838-00_SeriesIntro'
    assert ie.video_id == '9780133392838-00_SeriesIntro'

# Generated at 2022-06-26 12:40:49.601719
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE(SafariIE(), 'http://techbus.safaribooksonline.com/9780132149832')
    assert ie.name == 'safari:api'