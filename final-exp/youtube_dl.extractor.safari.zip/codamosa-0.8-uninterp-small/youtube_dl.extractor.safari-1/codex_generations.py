

# Generated at 2022-06-26 12:31:37.167605
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():

    safari_base_ie = SafariBaseIE()
    assert safari_base_ie is not None
    assert isinstance(safari_base_ie, InfoExtractor)


# Generated at 2022-06-26 12:31:39.653608
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()

if __name__ == '__main__':
    test_case_0()
    test_SafariCourseIE()

# Generated at 2022-06-26 12:31:41.065363
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    return SafariApiIE()._real_initialize()


# Generated at 2022-06-26 12:31:42.315781
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert 'SafariBaseIE' == SafariBaseIE.__name__, 'Class name should be SafariBaseIE'


# Generated at 2022-06-26 12:31:43.802926
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()
    assert safari_base_i_e_0.LOGGED_IN == False


# Generated at 2022-06-26 12:31:46.412375
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Unit test for constructor of class SafariApiIE
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:31:47.847059
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()
    pass

# Generated at 2022-06-26 12:31:49.586326
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    global safari_course_ie_1
    safari_course_ie_1 = SafariCourseIE()

# Generated at 2022-06-26 12:31:50.908862
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:31:52.412016
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()


# Generated at 2022-06-26 12:32:15.317830
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass

# Generated at 2022-06-26 12:32:22.625444
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():

    class FakeSafariBaseIE(SafariBaseIE):
        """
        Mock subclass with setable LOGGED_IN attribute.
        """
        def __init__(self, logged_in):
            self.LOGGED_IN = logged_in

    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

    # test when logged in
    temp_fake_safari = FakeSafariBaseIE(True)
    temp_fake_safari._initialize_geo_bypass({'countries': []})
    info_dict_1 = temp_fake_safari._real_extract(url)

# Generated at 2022-06-26 12:32:24.465868
# Unit test for constructor of class SafariIE
def test_SafariIE():
    try:
        SafariIE()
    except Exception:
        pass

# Generated at 2022-06-26 12:32:31.280856
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    class MockIE(SafariCourseIE):
        @classmethod
        def _build_ie(cls, *args):
            return cls()
    ie = MockIE._build_ie('http://techbus.safaribooksonline.com/9780134426365')
    assert ie._VALID_URL

# Generated at 2022-06-26 12:32:36.935136
# Unit test for constructor of class SafariIE
def test_SafariIE():
    def raise_value_error(x):
        raise ValueError(x)

    def raise_io_error(x):
        raise IOError(x)

    # testing key error while getting safari_username
    original_get_username = SafariBaseIE._get_username
    original_get_password = SafariBaseIE._get_password
    SafariBaseIE._get_username = lambda self: raise_value_error('safari_username')
    SafariBaseIE._get_password = lambda self: raise_io_error('safari_password')
    SafariBaseIE(None)._login()
    SafariBaseIE._get_username = original_get_username
    SafariBaseIE._get_password = original_get_password

    # testing key error while getting safari_password
    original_get_username = SafariBaseIE._get_username
    original_

# Generated at 2022-06-26 12:32:39.753279
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    print('Testing SafariApiIE constructor ...')
    try:
        ie = SafariApiIE()
    except Exception as e:
        print('Error: %s' % e.message)
    return



# Generated at 2022-06-26 12:32:45.263046
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test for constructor of class SafariCourseIE"""
    safari_course_ie = SafariCourseIE()
    assert isinstance(safari_course_ie, SafariBaseIE)

# Generated at 2022-06-26 12:32:47.993827
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.suitable('http://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-26 12:32:49.837443
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .common import InfoExtractor

    ie = InfoExtractor('SafariIE', 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert ie is not None

# Generated at 2022-06-26 12:32:51.639036
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE('SafariCourseIE', 'safaribooksonline.com', 'url', {})
    # Required public methods for InfoExtractor
    assert obj.suitable('url') == True
    assert obj.extract('url') == 'results'
    assert obj.result_type() == 'url'

# Generated at 2022-06-26 12:33:35.301688
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('safari:course', False)

# Generated at 2022-06-26 12:33:36.972234
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-26 12:33:37.480025
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-26 12:33:40.090390
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    safari_base_ie._real_initialize()
    # _real_initialize return None
    assert safari_base_ie._real_initialize() is None

# Generated at 2022-06-26 12:33:45.264961
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE._download_webpage = lambda _,__,___: (None, None)

# Generated at 2022-06-26 12:33:47.905941
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    aI = SafariBaseIE()
    assert aI._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert aI._NETRC_MACHINE == 'safari'

# Generated at 2022-06-26 12:33:49.989051
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE('www.safaribooksonline.com')
    assert obj._NETRC_MACHINE == "safari"

# Generated at 2022-06-26 12:33:52.298227
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert ie.ie_key() == 'SafariApi'
    assert ie.IE_NAME == 'safari:api'
    assert ie.ie_key() in globals()

# Generated at 2022-06-26 12:33:53.295823
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance = SafariIE()
    assert isinstance(instance, SafariBaseIE)

# Generated at 2022-06-26 12:34:03.055109
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class BaseSubclass(SafariBaseIE):
        _VALID_URL = r'(.+)'

        def _real_extract(self, url):
            pass

    # Use temporary class because it's hard to test if login was successful
    Tempclass = type(
        'Tempclass', (BaseSubclass, object),
        {'_TEST': {'ld': {'url': 'https://safe.url', 'md5': 'md5.'}}}
    )

    instance = Tempclass()
    # Force login and get md5 from first downloaded page
    md5 = instance._download_webpage(
        'https://safe.url', 'dummy_id',
        'https://learning.oreilly.com/accounts/login/')['md5']

    # Check correct login

# Generated at 2022-06-26 12:35:14.743202
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # pylint: disable=unused-variable,unused-argument,protected-access
    from .test_utils import TestSafariBaseIE

    class TestSafariCourseIE(TestSafariBaseIE):
        IE = SafariCourseIE

        def _test_course_entry(self, url, info_dict, playlist_count=None, expected_warning=False, expected_regex=None):
            super(TestSafariCourseIE, self)._test_course_entry(
                url, info_dict, playlist_count, expected_warning, expected_regex)
            self._test_course_entry(url, info_dict, playlist_count, expected_warning, expected_regex)

    return TestSafariCourseIE

# Generated at 2022-06-26 12:35:17.053373
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    url = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838'
    SafariBaseIE(url)._real_extract(url)

# Generated at 2022-06-26 12:35:19.384698
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    # test _login
    ie.LOGGED_IN = False
    ie._login()
    assert(ie.LOGGED_IN)

# Generated at 2022-06-26 12:35:22.705506
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Just check if SafariIE and SafariApiIE are in IE_DESC
    # Low-level detail is tested in test_*IE() functions
    assert SafariIE.IE_NAME in SafariCourseIE.IE_DESC
    assert SafariApiIE.IE_NAME in SafariCourseIE.IE_DESC


# Generated at 2022-06-26 12:35:24.169596
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE(lambda url: {})
    ie._real_initialize()
    assert ie.LOGGED_IN is True

# Generated at 2022-06-26 12:35:25.824241
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj = SafariBaseIE()
    assert obj._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert obj._API_FORMAT == 'json'

# Generated at 2022-06-26 12:35:26.249212
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-26 12:35:28.003278
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    IE = SafariBaseIE(False)
    assert not IE.LOGGED_IN
    del IE

    IE = SafariBaseIE(True)
    assert IE.LOGGED_IN
    del IE

# Generated at 2022-06-26 12:35:33.398930
# Unit test for constructor of class SafariIE
def test_SafariIE():
    n = SafariBaseIE()
    # Without credentials, only a couple of methods should return True
    assert n.LOGGED_IN is False
    assert n._login_available() is True
    assert n._login() is False

    # With credentials, everything should return True
    n = SafariBaseIE(username='someusername', password='somepassword')
    assert n._login_available() is True
    assert n._login() is True
    assert n.LOGGED_IN is True

# Generated at 2022-06-26 12:35:37.491440
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from unit.test_utils import MockYDL

    assert not hasattr(YoutubeDL, 'safari_ie')

    with MockYDL() as ydl:
        ydl.add_default_info_extractors()
    assert hasattr(YoutubeDL, 'safari_ie')
    assert hasattr(ydl.safari_ie, '_download_json')

# Generated at 2022-06-26 12:38:18.968282
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    return SafariBaseIE('SafariBaseIE', 'safaribooksonline')

# Generated at 2022-06-26 12:38:22.571518
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    def test_SafariApiIE_init(self):
        # intentionally leave self undefined
        safari_api_ie = SafariApiIE()

    test_SafariApiIE_init(None)

# Generated at 2022-06-26 12:38:34.390431
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # test if SafariIE is initialized correctly
    ie = SafariIE()
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie.LOGGED_IN == False
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC == 'safaribooksonline.com online video'

# Generated at 2022-06-26 12:38:37.183628
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    i = SafariBaseIE(None)
    assert i.LOGGED_IN

# Generated at 2022-06-26 12:38:47.028855
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # test log in, logged in, and not logged in
    from .test_login import (
        _fake_post_webpage_handle,
        _fake_download_json_handle,
        _fake_download_webpage_handle,
    )
    ie = SafariBaseIE()

    ie._login = lambda: None
    ie._download_webpage = _fake_download_webpage_handle
    ie._download_json = _fake_download_json_handle
    ie._post_webpage = _fake_post_webpage_handle

    # test logged in
    urlh = type('FakeUrlHandle', (object,), {
        'geturl': lambda self: 'https://learning.oreilly.com/home/'})()
    ie.LOGGED_IN = True

# Generated at 2022-06-26 12:38:57.758526
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from youtube_dl.utils import DateRange

    ie = SafariCourseIE()
    ie.LOGGED_IN = True
    course = '9781119052021'  # title='Effective DevOps with AWS'
    # Get course data
    course_json = ie._download_json(
        '%s/book/%s/?override_format=%s' % (ie._API_BASE, course, ie._API_FORMAT),
        course, 'Downloading course JSON')
    # Test course_info extraction
    course_info = ie._extract_course_info(course_json)
    assert course_info == {
        'title': 'Effective DevOps with AWS',
        'id': course,
    }
    # Test course info extraction with data issues
    course_json.pop('title')
    assert ie._ext

# Generated at 2022-06-26 12:38:58.483159
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    global SafariApiIE
    SafariApiIE('safari:api')

# Generated at 2022-06-26 12:39:09.150575
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE.suitable("https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro")
    SafariIE.suitable("https://learning.oreilly.com/videos/9780134664057/9780134664057-RHCE_Introduction")
    SafariIE.suitable("https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00")
    SafariIE.suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html")

# Generated at 2022-06-26 12:39:13.700563
# Unit test for constructor of class SafariIE
def test_SafariIE():
    '''
    Test constructor of class SafariIE
    '''
    SafariIE('Safari', 'safaribooksonline.com online video')

# Generated at 2022-06-26 12:39:18.785345
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    course_id = '9780133392838'
    url = 'http://techbus.safaribooksonline.com/{0}'.format(course_id)

    safari_base_ie = SafariBaseIE._build_request(url)

    assert safari_base_ie._downloader.cache.has(url)