

# Generated at 2022-06-26 12:31:38.940090
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()
    assert safari_course_i_e.ie_name == 'safari:course'

# Generated at 2022-06-26 12:31:40.125650
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()


# Generated at 2022-06-26 12:31:41.002502
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e = SafariBaseIE()


# Generated at 2022-06-26 12:31:42.006382
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()


# Generated at 2022-06-26 12:31:42.960668
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:31:43.560811
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-26 12:31:46.248504
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # no parameter
    _ = SafariIE()
    # full parameter
    _ = SafariIE(params=dict())


# Generated at 2022-06-26 12:31:47.408203
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()


# Generated at 2022-06-26 12:31:50.005639
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test = safari_base_i_e_0._real_initialize()
    assert test.__name__ == SafariBaseIE._real_initialize().__name__


# Generated at 2022-06-26 12:31:51.233268
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:32:30.629053
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:32:39.753102
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()

    assert safari_i_e.IE_NAME == 'safari' # Test for assigning correct value to _VALID_URL.

    assert safari_i_e._VALID_URL == r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    ''' # Test for assigning correct value to _TESTS.

# Generated at 2022-06-26 12:32:49.146935
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()
    safari_course_i_e_0.suitable('')
    safari_course_i_e_0.IE_NAME
    safari_course_i_e_0.IE_DESC
    safari_course_i_e_0._VALID_URL
    safari_course_i_e_0._TESTS

if __name__ == '__main__':
    test_case_0()
    test_SafariCourseIE()

# Generated at 2022-06-26 12:32:50.296497
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:32:51.448789
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()


# Generated at 2022-06-26 12:32:52.929401
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie_0 = SafariApiIE()


# Generated at 2022-06-26 12:32:56.526764
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e__0 = SafariBaseIE() #instance of SafariBaseIE
    safari_base_i_e__0._real_initialize()
    safari_base_i_e__1 = SafariBaseIE() #instance of SafariBaseIE
    safari_base_i_e__1._real_initialize()

# Generated at 2022-06-26 12:33:02.441091
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()
    safari_api_i_e_1 = SafariApiIE()
    # Unit test for constructor with parameter url
    safari_api_i_e_2 = SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    # Unit test for constructor with parameter ie_key
    safari_api_i_e_3 = SafariApiIE(ie_key=SafariApiIE.ie_key())
    # Unit test for constructor with parameter ie_key and url

# Generated at 2022-06-26 12:33:04.310962
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert callable(SafariBaseIE._download_json_handle)
    assert callable(SafariBaseIE._apply_first_set_cookie_header)

# Generated at 2022-06-26 12:33:05.003157
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_case_0()


# Generated at 2022-06-26 12:34:20.283428
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE(SafariBaseIE())


# Generated at 2022-06-26 12:34:21.194339
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-26 12:34:31.967306
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    safari_course_i_e_1 = SafariCourseIE()
    # SafariCourseIE
    # DONE: Test with url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
#     assert safari_course_i_e_1.suitable(url) == False
    # assert re.match(SafariCourseIE._VALID_URL, url) is not None
#     assert SafariCourseIE._VALID_URL == r'''(?x)
#                     https?://
#                         (?:
#                             (?:www\.)?(?:safaribooksonline

# Generated at 2022-06-26 12:34:35.245564
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()

    # Run the constructor of SafariApiIE as a test
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:34:37.157817
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:34:38.702021
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()


# Generated at 2022-06-26 12:34:39.695417
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()


# Generated at 2022-06-26 12:34:47.321381
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_json = {
        'chapters': ['chapter1', 'chapter2']
    }
    course_id = 'id'
    course_title = 'title'
    expected_result = [
            {
                'url': 'chapter1',
                'ie_key': 'SafariApi'
            },
            {
                'url': 'chapter2',
                'ie_key': 'SafariApi'
            }
        ]
    actual_result = SafariCourseIE().playlist_result(course_json['chapters'], course_id, course_title)
    assert actual_result == expected_result

# Generated at 2022-06-26 12:34:48.638269
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:34:51.441809
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e = SafariBaseIE()
    safari_base_i_e.initialize()
    safari_base_i_e.LOGGED_IN
    #safari_base_i_e.url_result()


# Generated at 2022-06-26 12:36:22.279976
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')
    assert ie._match_id('http://techbus.safaribooksonline.com/9780134426365') == '9780134426365'

# Generated at 2022-06-26 12:36:24.294634
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Unit test for SafariIE"""
    safari_ie = SafariIE()

    # test safariie instance created successfully
    assert safari_ie is not None

# Generated at 2022-06-26 12:36:24.803376
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-26 12:36:25.718900
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE(None)

# Generated at 2022-06-26 12:36:29.821966
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # The constructor of SafariBaseIE may need access to a kaltura session
    # and might raise an exception
    try:
        # pylint: disable=unused-variable
        api_ie = SafariApiIE(SafariBaseIE._downloader)
    except ExtractorError:
        pass

# Generated at 2022-06-26 12:36:32.532783
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()._real_extract('https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/bluetooth-low-energy-in-ios-with-swift.html')

# Generated at 2022-06-26 12:36:38.017298
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')
    assert course.suitable('http://techbus.safaribooksonline.com/9780134426365') is True
    assert course.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00') is False
    assert course.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json') is False


# Generated at 2022-06-26 12:36:39.723491
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import test_class_constructor
    test_class_constructor("SafariCourseIE", ['SafariCourseIE', 'SafariApiIE', 'SafariIE'])

# Generated at 2022-06-26 12:36:48.294255
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # this extractor requires login
    if not SafariBaseIE.LOGGED_IN:
        return

    COURSE_ID = '9780133392838'
    PART_ID = 'part00'
    REFERENCE_ID = '9780133392838-0_qbqx90ic'
    PARTNER_ID = '1926081'
    UICONF_ID = '29375172'

    expected_query = {
        'wid': '_%s' % PARTNER_ID,
        'uiconf_id': UICONF_ID,
        'flashvars[referenceId]': REFERENCE_ID,
    }

    # api and website urls for the same video id

# Generated at 2022-06-26 12:36:50.547506
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()._real_extract(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

# Generated at 2022-06-26 12:40:00.909308
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test an instance with a protected property defined in class SafariBaseIE
    with open('test/testdata/safari/test_SafariBaseIE_LOGGED_IN_false', 'r') as f:
        SafariBaseIE(None).__dict__ = json.loads(f.read())
    # Test an instance with a protected property defined in class SafariBaseIE
    with open('test/testdata/safari/test_SafariBaseIE_LOGGED_IN_true', 'r') as f:
        SafariBaseIE(None).__dict__ = json.loads(f.read())

# Generated at 2022-06-26 12:40:07.613663
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # tests only constructor by (ab)using _call_rpc
    safari = SafariBaseIE({})
    assert safari is not None, 'Failed to construct class SafariBaseIE'
    assert safari._call_rpc('test', {}) is None, 'Wrong constructor'

# Generated at 2022-06-26 12:40:13.253543
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = '9780133392838'
    part = 'part00'
    valid_url = 'https://www.safaribooksonline.com/api/v1/book/' + course_id  + '/chapter/' + part + '.html'
    se = SafariApiIE()
    assert se.suitable(valid_url) == True
    assert se._match_id(valid_url) == course_id
    assert se._real_extract(valid_url) == True

# Generated at 2022-06-26 12:40:15.483147
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie.ie_key() == 'Safari'

# Generated at 2022-06-26 12:40:17.213349
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE



# Generated at 2022-06-26 12:40:20.831200
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """try to assert safari course ie is constructed"""
    # pylint: disable=line-too-long, unused-argument
    assert SafariCourseIE(None)

# Generated at 2022-06-26 12:40:26.901456
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    _SafariBaseIE = SafariBaseIE(None)

    assert _SafariBaseIE._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert _SafariBaseIE._API_FORMAT == 'json'

# Generated at 2022-06-26 12:40:33.801560
# Unit test for constructor of class SafariIE
def test_SafariIE():
    saf = SafariIE()
    saf._download_webpage = lambda url, video_id: ('', True)
    saf._download_json = lambda url, video_id: {'session': '123'}
    saf._download_json_handle = lambda url, video_id, query, data: ({'redirect_uri': 'https://api.oreilly.com/', 'credentials': '123'}, True)
    saf._real_initialize()
    assert saf.LOGGED_IN

# Generated at 2022-06-26 12:40:37.006524
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(InfoExtractor)._initialize_geo_bypass({})

# Generated at 2022-06-26 12:40:40.838099
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    c = SafariApiIE(None)
    assert c is not None
    assert c.IE_DESC == 'safaribooksonline.com online video'