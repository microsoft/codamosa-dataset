

# Generated at 2022-06-26 12:31:36.003208
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_case_0_0 = SafariBaseIE()


# Generated at 2022-06-26 12:31:39.852632
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()
    safari_base_i_e_1 = SafariBaseIE()
    safari_base_i_e_0.initialize()
    safari_base_i_e_1.initialize()



# Generated at 2022-06-26 12:31:41.242085
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:31:42.960994
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()
    assert safari_course_i_e.ie_key() == 'safari:course'


# Generated at 2022-06-26 12:31:44.587358
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    instance = SafariCourseIE()
    assert isinstance(instance, SafariCourseIE)


# Generated at 2022-06-26 12:31:46.855348
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert hasattr(SafariBaseIE, '_download_webpage_handle')


# Generated at 2022-06-26 12:31:47.923142
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert test_case_0() == None

# Generated at 2022-06-26 12:31:49.666450
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariCourseIE_0 = SafariCourseIE()
    safariCourseIE_0 = SafariCourseIE()


# Generated at 2022-06-26 12:31:51.895496
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_dummy = SafariIE()
    safari_i_e_dummy._real_extract("")


# Generated at 2022-06-26 12:31:53.053381
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()


# Generated at 2022-06-26 12:32:31.558271
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    test_case_0()


# Generated at 2022-06-26 12:32:33.598372
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():

    url = 'https://www.safaribooksonline.co...'
    safari_course_i_e = SafariCourseIE(url)


# Generated at 2022-06-26 12:32:34.927476
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:32:36.133237
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()


# Generated at 2022-06-26 12:32:38.500669
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()
    assert safari_course_i_e is not None


# Generated at 2022-06-26 12:32:40.027276
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    print("Just a test for the class")


test_SafariBaseIE()

# Generated at 2022-06-26 12:32:44.036365
# Unit test for constructor of class SafariIE
def test_SafariIE():
    s = SafariIE()._real_initialize()

    pass

# Generated at 2022-06-26 12:32:53.205418
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Assert that state of the class matches default state
    assert isinstance(SafariBaseIE._LOGIN_URL, str)
    assert isinstance(SafariBaseIE._NETRC_MACHINE, str)
    assert isinstance(SafariBaseIE._API_BASE, str)
    assert isinstance(SafariBaseIE._API_FORMAT, str)
    assert isinstance(SafariBaseIE.LOGGED_IN, bool)

    # Assert that state of the instance matches default state (state is reset after each test)
    safari_base_i_e_0 = SafariBaseIE()
    assert isinstance(safari_base_i_e_0._LOGIN_URL, str)
    assert isinstance(safari_base_i_e_0._NETRC_MACHINE, str)


# Generated at 2022-06-26 12:32:53.586585
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass

# Generated at 2022-06-26 12:32:54.774616
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:33:46.231974
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    def test_input(kwargs):
        return '\n'.join(('%s: %s' % (key, value) for key, value in kwargs.items()))

    def test_output(kwargs):
        return '\n'.join(('\t%s: %s' % (key, value) for key, value in kwargs.items()))

    def get_kwargs(r):
        return {
            'args': r.args,
            'kwargs': r.kwargs,
            'url': r.url,
            'ie': r.ie,
            'video_id': r.video_id,
            'ie_key': r.ie_key(),
            'ie_key_original': r.ie_key_original(),
        }

    # No input parameters
    r = SafariA

# Generated at 2022-06-26 12:33:47.624875
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE(None).LOGGED_IN is False

# Generated at 2022-06-26 12:33:49.347554
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-26 12:33:56.216077
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Failing login
    try:
        SafariBaseIE()._login()
    except ExtractorError as e:
        assert 'Unable to log in' in str(e)
    else:
        raise Exception('Expected login failure')

    # Successful login
    safari_base_ie = SafariBaseIE({'username': 'foo', 'password': 'bar'})
    safari_base_ie._login()
    assert safari_base_ie.LOGGED_IN

    # Skipping login
    safari_base_ie = SafariBaseIE(skip_login=True)
    safari_base_ie._login()
    assert not safari_base_ie.LOGGED_IN

# Generated at 2022-06-26 12:34:00.713680
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api = SafariApiIE({})
    safari_api.IE_NAME
    safari_api.IE_DESC
    safari_api.ie_key()
    safari_api.url_result(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
        'Safari')


# Generated at 2022-06-26 12:34:08.522731
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """ Unit test for constructor of class SafariApiIE. """
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    safari_api_ie = SafariApiIE()
    safari_api_ie._download_webpage = lambda *args: ''
    safari_api_ie._REAL_INITIALIZED = False
    safari_api_ie._login = lambda: None
    safari_api_ie._real_extract(url)

# Generated at 2022-06-26 12:34:10.579208
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .common import FakeLoginIE

    class FakeSafari(FakeLoginIE, SafariBaseIE):
        pass

    fake_safari = FakeSafari()
    fake_safari._real_initialize()

# Generated at 2022-06-26 12:34:12.616891
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base = SafariBaseIE('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838')
    assert safari_base.LOGGED_IN is False

# Generated at 2022-06-26 12:34:25.016821
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import fake_urlopen
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    import io

    downloader = FileDownloader()
    downloader.urlopen = fake_urlopen
    url = 'https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'

    ie = InfoExtractor(downloader=downloader)
    assert ie.suitable(url)
    ie = ie.suitable(url)()

    ie._login()

    webpage = ie._download_webpage(url, '9780133392838')

    course_id = re.match(ie._VALID_URL, url).group('id')


# Generated at 2022-06-26 12:34:27.705650
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE()
    course_id = obj._VALID_URL
    course_title = 'Course'
    obj.playlist_result(course_id, course_title)

# Generated at 2022-06-26 12:35:52.236119
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import json

    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/06.html?override_format=json'
    ie = SafariApiIE()
    res = json.loads(ie._download_webpage(url, video_id='123', note='Downloading part JSON', errnote='Downloading part JSON', fatal=False))
    assert res['web_url'] == 'https://www.safaribooksonline.com/library/view/python-crash-course/9781491912279/06.xhtml'

# Generated at 2022-06-26 12:35:53.163078
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test constructor
    SafariBaseIE('', {}, {})

# Generated at 2022-06-26 12:35:55.783580
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == 'safari'
    assert safari_ie.IE_DESC == 'safaribooksonline.com online video'


# Generated at 2022-06-26 12:35:57.110668
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE('foobar')
    assert ie.ie_key() == 'SafariApi'

# Generated at 2022-06-26 12:35:58.793034
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE(None)
    assert safari_base_ie is not None

# Generated at 2022-06-26 12:35:59.616380
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()

# Generated at 2022-06-26 12:36:00.099682
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-26 12:36:08.950582
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class FakeModule(object):
        class LoginIE(InfoExtractor):
            def __init__(self, *args):
                pass

    class FakeModule2(object):
        class KalturaIE(InfoExtractor):
            def __init__(self, *args):
                pass

    class FakeModule3(object):
        class SafariApiIE(InfoExtractor):
            def __init__(self, *args):
                pass

    class FakeModule4(object):
        class SafariIE(InfoExtractor):
            def __init__(self, *args):
                pass

    safari_course_ie = SafariCourseIE(FakeModule(), FakeModule2(), FakeModule3(), FakeModule4())

# Generated at 2022-06-26 12:36:10.981959
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE('SafariBaseIE')
    safari_base_ie._real_initialize() # pylint: disable=protected-access

# Generated at 2022-06-26 12:36:12.314733
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert isinstance(safari_base_ie, InfoExtractor)

# Generated at 2022-06-26 12:39:10.164324
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-26 12:39:16.911196
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    # SafariAPI requires a username and password.
    if not ie._downloader.params.get('username') or not ie._downloader.params.get('password'):
        return
    ie.initialize()


# Generated at 2022-06-26 12:39:27.734806
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE("SafariCourseIE", "SafariCourseIE.ie_key()", {}, {})
    assert obj.IE_NAME == 'safari:course'
    assert obj._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-26 12:39:30.469539
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    expected_partner_id = '1926081'
    expected_ui_id = '29375172'

    safari_ie = SafariBaseIE()
    assert (expected_partner_id == safari_ie._PARTNER_ID and expected_ui_id == safari_ie._UICONF_ID)

# Generated at 2022-06-26 12:39:41.825164
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_utils import _get_testdata_subfolder
    from .test_common import FakeYDL
    ydl = FakeYDL()
    course_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course_ie = SafariCourseIE()
    course_ie.extract(course_url)
    course_json = ydl.cached_result['https://www.safaribooksonline.com/api/v1/book/9780133392838/?override_format=json']
    assert course_json['id'] == '9780133392838'
    assert course_json['title'] == "Hadoop Fundamentals LiveLessons"

# Generated at 2022-06-26 12:39:44.801906
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._VALID_URL == SafariIE._VALID_URL

# Generated at 2022-06-26 12:39:46.853744
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()
    print(safariIE)


# Generated at 2022-06-26 12:39:54.814073
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert ie.ie_key() == 'Safari'
    assert ie.LOGGED_IN == False
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'
    assert ie._PARTNER_ID == '1926081'
    assert ie._UICONF_ID == '29375172'

# Generated at 2022-06-26 12:39:56.309682
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE('--username', '--password')

# Generated at 2022-06-26 12:39:58.869240
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN == False