

# Generated at 2022-06-26 12:31:31.401218
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:31:33.043255
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()

# Generated at 2022-06-26 12:31:33.776641
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass # Nothing to test


# Generated at 2022-06-26 12:31:42.440620
# Unit test for constructor of class SafariIE

# Generated at 2022-06-26 12:31:52.720320
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'http://techbus.safaribooksonline.com/9780134426365'
    safari_course_i_e = SafariCourseIE()
    assert safari_course_i_e.suitable(url) == True
    assert safari_course_i_e._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'

# Generated at 2022-06-26 12:31:53.906228
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()


# Generated at 2022-06-26 12:31:54.892834
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()

# Generated at 2022-06-26 12:31:57.053301
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        assert test_case_0() == 'Assertion Error'
    except AssertionError as e:
        print(e)

# Generated at 2022-06-26 12:32:04.513582
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_cases_safari_api import test_case_0
    from .test_cases_safari_api import test_case_1
    from .test_cases_safari_api import test_case_2
    from .test_cases_safari_api import test_case_3
    from .test_cases_safari_api import test_case_4
    from .test_cases_safari_api import test_case_5
    from .test_cases_safari_api import test_case_6
    from .test_cases_safari_api import test_case_7
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()

# Generated at 2022-06-26 12:32:05.112197
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert True


# Generated at 2022-06-26 12:32:36.642962
# Unit test for constructor of class SafariIE
def test_SafariIE():
    course_id = '9780134426365'
    course_title = 'Python Cookbook'
    chapter_title = 'Preparing to Use Python'
    chapter_id = '9780134426365-CH00'

    # create course
    course = SafariCourseIE()
    course.IE_NAME = 'safari:course'
    course.IE_DESC = 'safaribooksonline.com online courses'
    course._VALID_URL = r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/.+/(?P<id>[^/]+)'

# Generated at 2022-06-26 12:32:38.969881
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    print("Constructor of SafariCourseIE class")
    safari = SafariCourseIE("safari")
    assert(safari.IE_NAME == "safari")

# Generated at 2022-06-26 12:32:44.181600
# Unit test for constructor of class SafariIE
def test_SafariIE():
    info_extractor = SafariIE()
    assert info_extractor.__class__.__name__ == 'SafariIE'

# Generated at 2022-06-26 12:32:48.302694
# Unit test for constructor of class SafariIE
def test_SafariIE():
    obj = SafariIE('id', {})
    assert obj._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert obj._API_FORMAT == 'json'
    assert obj.IE_NAME == 'safari'
    assert obj.LOGGED_IN is False

# Generated at 2022-06-26 12:32:52.619490
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie_name = ie._get_IE_name()
    assert ie_name == 'safari', 'Expect safari'
    assert ie.LOGGED_IN == False
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-26 12:32:59.455444
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    mobj = re.match(SafariApiIE._VALID_URL, url)
    part = '%s-%s' % (mobj.group('course_id'), mobj.group('part'))
    ie = SafariApiIE()
    ie.add_headers = {'Accept': 'application/json'}
    urlh = ie._request_webpage(url, part, 'Downloading part JSON')
    body = urlh.read()
    print("urlh.code: %s" % urlh.code)
    print("body: %s" % body)


# Generated at 2022-06-26 12:33:03.038737
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():

    def test_SafariCourseIE_constructor():
        # test empty url
        assert SafariCourseIE() # will not work with IE_DESC

        # Not-empty url
        assert SafariCourseIE(url = "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/") != None

    # test_SafariCourseIE_constructor()
    test_SafariCourseIE_constructor()


# Generated at 2022-06-26 12:33:08.349227
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE.__bases__ == (InfoExtractor,)
    assert SafariBaseIE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert SafariBaseIE._NETRC_MACHINE == 'safari'
    assert SafariBaseIE._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert SafariBaseIE._API_FORMAT == 'json'
    assert SafariBaseIE.LOGGED_IN == False


# Generated at 2022-06-26 12:33:12.856345
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    try:
        SafariCourseIE._real_extract(None, url)
    except ExtractorError as e:
        if e.exc_info[1].code != 400:
            raise

# Generated at 2022-06-26 12:33:13.952815
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE(SafariIE.ie_key())

# Generated at 2022-06-26 12:33:56.634398
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    return not (SafariBaseIE() is None)

# Generated at 2022-06-26 12:33:58.711399
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-26 12:34:01.072978
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        SafariApiIE()
    except Exception as e:
        assert False, "exception of type {0} occured in constructor of class SafariApiIE(): {1}".format(type(e).__name__, str(e))


# Generated at 2022-06-26 12:34:07.288048
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from youtube_dl.utils import match_str
    assert match_str(SafariCourseIE.__name__, 'SafariCourseIE') == ''
    assert match_str(SafariCourseIE.ie_key(), 'SafariCourse') == ''
    assert match_str(SafariCourseIE.IE_NAME, 'safari:course') == ''


# Generated at 2022-06-26 12:34:13.472430
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # URL which only exists on SafariApiIE
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    # Check if url is suitable for SafariApiIE
    assert SafariApiIE.suitable(url) == True
    # Initialize a instance of SafariApiIE
    Safari_Api_IE = SafariApiIE()
    # Check if instance is initialised properly
    assert Safari_Api_IE._VALID_URL == SafariApiIE._VALID_URL
    # Check if the instance is an instance of InfoExtractor (Parent Class)
    assert isinstance(Safari_Api_IE, InfoExtractor)
    # Check if the instance is an instance of SafariApiIE

# Generated at 2022-06-26 12:34:25.865277
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class TestClass(object):
        def __init__(self, url, *args, **kwargs):
            self.url = url

        def url_result(self, url, ie_key):
            return url

    test = SafariIE(TestClass('http://www.oreilly.com/library/view/Microsoft-Azure-Essentials/9780134166569/part00.html'))


# Generated at 2022-06-26 12:34:26.701430
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()
    assert safari.IE_NAME == 'safari:api'

# Generated at 2022-06-26 12:34:32.016425
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE('http://techbus.safaribooksonline.com/9780134426365')
    print (ie.ie_name)
    print (ie.ie_description)
    print (ie._VALID_URL)
    print (ie._TESTS)
    print (ie.LOGGED_IN)

# Generated at 2022-06-26 12:34:35.810535
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    instance = SafariCourseIE()
    result = instance.suitable(url)
    assert isinstance(result, bool)

# Generated at 2022-06-26 12:34:38.667733
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE.ie_key(), type(SafariApiIE.ie_key()))

# Generated at 2022-06-26 12:36:03.557248
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE('SafariBaseIE') == SafariBaseIE

# Generated at 2022-06-26 12:36:08.463403
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE(None)
    assert ie.suitable(None) is False
    assert ie.suitable('') is False
    assert ie.suitable('http://techbus.safaribooksonline.com/9780134426365') is True
    return 0

if __name__ == '__main__':
    test_SafariCourseIE()

# Generated at 2022-06-26 12:36:13.902873
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/sec_whats_new_in_python2.html?format=json'
    ie = SafariApiIE(url)

# Generated at 2022-06-26 12:36:20.323490
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    courseIE = SafariCourseIE('SafariIE', 'Safari Bookshelf online video')
    assert courseIE._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert courseIE.IE_NAME == 'safari:course'
    assert courseIE.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-26 12:36:21.481825
# Unit test for constructor of class SafariIE
def test_SafariIE():
    a = SafariIE();
    assert a.IE_NAME == 'safari';

# Generated at 2022-06-26 12:36:23.998115
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-26 12:36:32.750056
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_cases = [
        {
            'input_string': '123456-abcdef',
            'expected_output': '123456-abcdef'
        },
        {
            'input_string': '123456_abcdef',
            'expected_output': '123456_abcdef'
        },
        {
            'input_string': '12345678-abcdef-test',
            'expected_output': '12345678-abcdef-test'
        },
        {
            'input_string': '12345678-abcdef-test-',
            'expected_output': '12345678-abcdef-test'
        },
    ]
    for test_case in test_cases:
        actual_output = SafariIE._reference_id_re.search(test_case['input_string']).group('mid')

# Generated at 2022-06-26 12:36:34.654982
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    instance = SafariCourseIE()
    assert instance.IE_NAME == 'safari:course'
    assert instance.IE_DESC == 'safaribooksonline.com online courses'

# Generated at 2022-06-26 12:36:36.520018
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    class TestSafariBaseIE(SafariBaseIE):
        _TEST = {}
        IE_NAME = 'test'
    TestSafariBaseIE('test')

# Generated at 2022-06-26 12:36:37.900398
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_Safari import test_SafariBaseIE
    test_SafariBaseIE(SafariCourseIE)

# Generated at 2022-06-26 12:39:29.555173
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    info_extractor = SafariApiIE()
    assert info_extractor._api_base == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-26 12:39:31.601447
# Unit test for constructor of class SafariIE
def test_SafariIE():
    return SafariIE('Kaltura', 'http://kaltura.com')

# Generated at 2022-06-26 12:39:42.341570
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()
    url_1 = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter-content/safari001.html'
    expected_title = 'Hadoop Fundamentals LiveLessons  Introduction'
    mobj = re.match(safari._VALID_URL, url_1)
    url_2 = safari._real_extract(url_1)
    assert url_2 == 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    return (mobj.group('id'), expected_title)


# Generated at 2022-06-26 12:39:43.877370
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safarie = SafariIE()

# Generated at 2022-06-26 12:39:45.290262
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE(SafariBaseIE())

# Generated at 2022-06-26 12:39:54.202578
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .common import ParserTestCase

    parser = ParserTestCase.ParserTestCase()

    def create_object(url):
        return SafariApiIE(parser.get_object(url))


# Generated at 2022-06-26 12:39:55.052123
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    pass

# Generated at 2022-06-26 12:39:59.359279
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    testing_class = SafariCourseIE()
    assert testing_class.IE_NAME == "safari:course"
    assert testing_class.IE_DESC == "safaribooksonline.com online courses"

# Generated at 2022-06-26 12:40:04.883094
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():

    #Variables used to test the constructor of the class SafariCourseIE
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    course_ie = SafariCourseIE(SafariCourseIE())
    assert course_ie._VALID_URL == "https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)"
    assert re.match(course_ie._VALID_URL,url) != None

# Generated at 2022-06-26 12:40:06.890612
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE.suitable(SafariIE._VALID_URL)