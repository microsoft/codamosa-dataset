

# Generated at 2022-06-26 12:31:33.566213
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()

# Generated at 2022-06-26 12:31:34.303365
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    swf = SafariCourseIE()

# Generated at 2022-06-26 12:31:35.054257
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    s = SafariCourseIE()


# Generated at 2022-06-26 12:31:36.303445
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:31:37.474701
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    return test_case_0()



# Generated at 2022-06-26 12:31:38.939121
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()

# Generated at 2022-06-26 12:31:41.039420
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e = SafariBaseIE()
    assert safari_base_i_e.LOGGED_IN == False



# Generated at 2022-06-26 12:31:42.528833
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e = SafariBaseIE()
    return safari_base_i_e is not None


# Generated at 2022-06-26 12:31:44.155494
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:31:53.970427
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import re
    
    safari_course_i_e_0 = SafariCourseIE()
    safari_course_i_e_1 = SafariCourseIE()
    safari_course_i_e_2 = SafariCourseIE()
    
    assert safari_course_i_e_0.get_entries() is None
    assert safari_course_i_e_0.sanitized_Request(REQUEST) == "GET /v1/book/9781449396459/?override_format=json HTTP/1.1"

# Generated at 2022-06-26 12:32:30.808706
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()


# Generated at 2022-06-26 12:32:33.598777
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE(SafariBaseIE.SafariBaseIE('SafariBaseIE')).LOGGED_IN == False, 'LOGGED_IN == False'



# Generated at 2022-06-26 12:32:34.884044
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_api_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:32:36.089379
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()


# Generated at 2022-06-26 12:32:36.736595
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()

# Generated at 2022-06-26 12:32:38.452573
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_i_e_0 = SafariCourseIE()


# Generated at 2022-06-26 12:32:42.551924
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    print("Test Constructor of SafaricourseIE")
    safari_course_i_e_0 = SafariCourseIE()



# Generated at 2022-06-26 12:32:45.442170
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert isinstance(SafariIE()._VALID_URL, str)


# Generated at 2022-06-26 12:32:46.766374
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()

# Generated at 2022-06-26 12:32:47.685430
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()

# Generated at 2022-06-26 12:34:00.225976
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()


# Generated at 2022-06-26 12:34:04.468130
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Test cases that are expected to fail
    # safari_i_e_1 = SafariIE()
    pass


# Generated at 2022-06-26 12:34:04.951375
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()

# Generated at 2022-06-26 12:34:06.933573
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = safari.SafariCourseIE(
        'http://techbus.safaribooksonline.com/9780134426365')
    # Test
    assert obj.suitable(
        'http://techbus.safaribooksonline.com/9780134426365') == True



# Generated at 2022-06-26 12:34:10.688090
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_api_i_e_0 = SafariApiIE()
    safari_base_i_e_0 = SafariBaseIE()
    safari_i_e_0 = SafariIE()
    safari_course_i_e_0 = SafariCourseIE()
    safari_course_i_e_0.ie_key()
    assert safari_course_i_e_0._downloader


# Generated at 2022-06-26 12:34:13.437526
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    obj1 = SafariBaseIE()
    assert(obj1.LOGGED_IN == False)
    assert(obj1._NETRC_MACHINE == 'safari')


# Generated at 2022-06-26 12:34:25.823564
# Unit test for constructor of class SafariIE

# Generated at 2022-06-26 12:34:27.410203
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:34:28.672557
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()


# Generated at 2022-06-26 12:34:30.486346
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e =SafariIE()

# Test for instance of class SafariIE

# Generated at 2022-06-26 12:35:52.060192
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie.IE_NAME == 'safari:api'

# Generated at 2022-06-26 12:35:53.069511
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    s = SafariApiIE()
    assert s is not None


# Generated at 2022-06-26 12:35:54.926902
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(None)
    assert hasattr(ie, '_LOGIN_URL')
    assert hasattr(ie, '_NETRC_MACHINE')

# Generated at 2022-06-26 12:36:02.293528
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    def test_SafariApiIE(self, test_name, course_id, part, expected_url):
        assert course_id
        assert part
        assert expected_url

        result = SafariApiIE._build_url(course_id, part)
        assert result == expected_url
    test_SafariApiIE(None, 'test_SafariApiIE', '9780134664057', 'RHCE_Introduction', 'https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html')

# Generated at 2022-06-26 12:36:03.556755
# Unit test for constructor of class SafariIE
def test_SafariIE():
    test_instance = SafariIE()
    assert test_instance is not None

# Generated at 2022-06-26 12:36:04.240766
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-26 12:36:07.138448
# Unit test for constructor of class SafariIE
def test_SafariIE():
    mdx = SafariIE()
    assert mdx.LOGGED_IN is False
    assert mdx._NETRC_MACHINE == 'safari'
    assert mdx.IE_DESC == 'safaribooksonline.com online video'


# Generated at 2022-06-26 12:36:08.915623
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()

# Generated at 2022-06-26 12:36:12.718024
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable(None) == (False)
    assert SafariCourseIE.suitable('http://techbus.safaribooksonline.com/9780134426365') == (True)
    assert SafariCourseIE.suitable('https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838') == (False)

# Generated at 2022-06-26 12:36:15.014362
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE('%s/%s/' % (SafariBaseIE._LOGIN_URL, SafariBaseIE._NETRC_MACHINE))

# Generated at 2022-06-26 12:39:06.449884
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'


# Generated at 2022-06-26 12:39:08.467393
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert isinstance(SafariIE().initialize(), SafariIE)

# Generated at 2022-06-26 12:39:17.521144
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    # Test whether this URL is supported by the class
    assert SafariCourseIE.suitable(url)
    # Test whether the constructor returns an object
    assert isinstance(SafariCourseIE(url), SafariCourseIE)



# Generated at 2022-06-26 12:39:22.922289
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari = SafariApiIE()

    # safaribooksonline.com serves .webm video when no referrer is set
    safari._initialize_geo_bypass({'countries': ['US']})

# Generated at 2022-06-26 12:39:23.752476
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-26 12:39:27.812888
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    if ie.LOGGED_IN:
        print("Logged in session is true")
    else:
        print("Logged in session is false")

# Generated at 2022-06-26 12:39:29.889202
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # An empty URL shouldn't raise an error
    stderr = sys.stderr
    try:
        safari_course_ie = SafariCourseIE()
    finally:
        sys.stderr = stderr

# Generated at 2022-06-26 12:39:35.421498
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    SafariCourseIE().suitable(url)

# Generated at 2022-06-26 12:39:43.639807
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..compat import mock
    from ..utils import fake_urlopen

    class DummySafariBaseIE(SafariBaseIE):
        def _real_initialize(self):
            return

        def _login(self):
            return

    username = 'user@example.com'
    password = 'you will never guess me'

    with mock.patch('%s.SafariBaseIE._download_webpage' % __name__,
                    side_effect=fake_urlopen) as download_webpage_:
        course = DummySafariBaseIE(username, password)
        course._login()

# Generated at 2022-06-26 12:39:50.317812
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # in order to test the constructor, we set the _api_base variable to a dummy path
    SafariCourseIE._API_BASE = 'http://dummy/path'
    i = SafariCourseIE('http://dummy/path')
    # should not raise any error
    # testing the _api_base variable
    assert i._API_BASE == 'http://dummy/path'
    # should not raise any error