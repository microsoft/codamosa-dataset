

# Generated at 2022-06-26 12:31:33.598249
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    target = SafariBaseIE()
    assert target._NETRC_MACHINE == 'safari'


# Generated at 2022-06-26 12:31:34.594964
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:31:35.699745
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:31:37.305261
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:31:39.598753
# Unit test for constructor of class SafariIE
def test_SafariIE():
    #assert_raises is undefined in pydoc
    #assert_raises(RegexNotFoundError, SafariIE, None, 'http://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')
    assert True 


# Generated at 2022-06-26 12:31:42.085262
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    # print(SafariCourseIE.suitable(url))
    safari_course_i_e_0 = SafariCourseIE()


# Generated at 2022-06-26 12:31:43.432306
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()

# Generated at 2022-06-26 12:31:50.580926
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    current_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safari_base_i_e_0 = SafariBaseIE()
    safari_base_i_e_1 = SafariBaseIE()._real_extract(safari_base_i_e_0, current_url)
    assert isinstance(safari_base_i_e_1, tuple)
# unit test for constructor of class SafariIE

# Generated at 2022-06-26 12:31:52.055835
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:31:53.324183
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e = SafariBaseIE()


# Generated at 2022-06-26 12:32:16.874114
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()

# Generated at 2022-06-26 12:32:20.785286
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """ Unit test for constructor of class SafariIE """
    safari_ie = SafariIE()
    assert safari_ie.LOGGED_IN is False
    # class SafariIE inherits from class SafariBaseIE. In class SafariBaseIE variable LOGGED_IN is evaluated
    # to True via method _login(). We should repeat this procedure in unit test.
    safari_ie._login()
    assert safari_ie.LOGGED_IN is True

# Generated at 2022-06-26 12:32:21.446299
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    return SafariApiIE()


# Generated at 2022-06-26 12:32:25.422194
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('test')

# Generated at 2022-06-26 12:32:29.208928
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert isinstance(SafariCourseIE() ,SafariBaseIE)

#test for suitable method of class SafariCourseIE

# Generated at 2022-06-26 12:32:35.225893
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/library/view/[^/]+/[^/?#&]+\.html'
    assert SafariIE._TESTS[0]['url'] == 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'

# Generated at 2022-06-26 12:32:35.678496
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-26 12:32:36.737038
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Unit tests for SafariIE
    """
    S_I_E = SafariIE()

# Generated at 2022-06-26 12:32:37.392786
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-26 12:32:48.993890
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE('SafariBaseIE', 'safaribooksonline.com online video')
    safari_base_ie._download_json_handle
    safari_base_ie._download_json(
        'https://learning.oreilly.com/api/v1/player/kaltura_session/?reference_id=10000000222651',
        '9780134217314-PYMC_13_00', 'Downloading kaltura session JSON',
        'Unable to download kaltura session JSON', '9780134217314-PYMC_13_00', 'Downloading kaltura session JSON')

# Generated at 2022-06-26 12:33:35.333645
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    TestCase = type('TestCase', (unittest.TestCase,), {
        'assertRegexpMatches': getattr(unittest.TestCase, 'assertRegex', unittest.TestCase.assertRegexpMatches),
    })

# Generated at 2022-06-26 12:33:37.032453
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    #test for running constructor of class SafariCourseIE without error
    safari_course_IE_test = SafariCourseIE()
    assert safari_course_IE_test

# Generated at 2022-06-26 12:33:39.818560
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Test that SafariApiIE constructor doesn't inject ',' into header."""
    obj = SafariApiIE(None)
    assert obj._API_BASE == 'https://learning.oreilly.com/api/v1'



# Generated at 2022-06-26 12:33:44.858159
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariie = SafariIE('YXJ0aWNsZTo1NDFkODFjOC1mOWFmLTRkMDQtOThlYS0yYWE3MjI3ZmE1ZWE=')
    assert safariie.course_id == '541d81c8-f9af-4d04-98ea-2aa7227fa5ea'
    assert safariie.part == 'article'

# Generated at 2022-06-26 12:33:46.566181
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # If a program can run without error, this is a successful test
    SafariCourseIE().url_result(course_json['chapters'][0])

# Generated at 2022-06-26 12:33:49.480616
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class_name = 'safari.SafariApiIE'
    safariApi = __import__(class_name, globals(), locals(), [''], 0)
    assert safariApi

# Generated at 2022-06-26 12:33:57.640393
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import sys
    import tempfile

    # setup dummy python path for testing
    # sys.path.insert(0, '/path/to/pycharm-debug.egg')

    # setup pydev remote debugger
    try:
        import pydevd
    except ImportError:
        pass
    else:
        pydevd.settrace('localhost', port=51416, stdoutToServer=True, stderrToServer=True)

    # Safaribookonline requires account credentials, so we need to set it up
    # Create temporary directory for netrc file
    os_tmpdir = tempfile.gettempdir()
    temp_dir = tempfile.mkdtemp(dir=os_tmpdir)
    netrc_path = temp_dir + '/.netrc'


# Generated at 2022-06-26 12:33:59.091764
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()
    print(safariIE._PARTNER_ID)
    print(safariIE._UICONF_ID)

# Generated at 2022-06-26 12:34:03.174361
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Simple construction test
    ie = SafariBaseIE()
    # Asserts for class SafariBaseIE,
    # test for assert not None and assert equal
    assert ie is not None
    assert ie._VALID_URL is None
    assert ie.LOGGED_IN is False
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_FORMAT == 'json'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'


# Generated at 2022-06-26 12:34:05.755152
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-26 12:35:08.681269
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert hasattr(ie, '_LOGIN_URL')
    assert hasattr(ie, '_NETRC_MACHINE')
    assert hasattr(ie, '_API_BASE')
    assert hasattr(ie, '_API_FORMAT')
    assert hasattr(ie, 'LOGGED_IN')
    assert hasattr(ie, '_real_initialize')
    assert hasattr(ie, '_login')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, 'suitable')
    return

# Generated at 2022-06-26 12:35:17.573346
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_cases = [
        # just a link: doesn't match any class
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
        # matches SafariCourseIE and SafariIE: the latter is chosen
        'https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00',
    ]

    for test_case in test_cases:
        ie = SafariBaseIE._extract_ie(test_case)
        assert ie

        assert ie.__name__.lower() in ('safarie', 'safariie', 'safaricourseie')

# Generated at 2022-06-26 12:35:20.687960
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Unit test for constructor of class SafariIE.
    """
    # Initialize an instance of class SafariIE
    test_safari_ie = SafariIE()
    # Unit test for class SafariIE
    assert "SafariIE" == type(test_safari_ie).__name__

# Generated at 2022-06-26 12:35:27.196552
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # When IE for SafariCourseIE is not constructed
    # SafariApiIE should be invoked
    SafariApiIE().suitable(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    # When IE for SafariCourseIE is constructed should skip SafariApiIE
    SafariCourseIE().suitable(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    # When IE for SafariApiIE is constructed should invoke SafariApiIE
    SafariApiIE().suitable(
        'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    # When IE for

# Generated at 2022-06-26 12:35:29.177879
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """Test the constructor of SafariApiIE"""
    try:
        SafariApiIE()
    except:
        print('test_SafariApiIE failed')
        return False

    return True

# Generated at 2022-06-26 12:35:31.451617
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    try:
        SafariApiIE(None)
    except TypeError:
        assert 0

# Generated at 2022-06-26 12:35:33.995472
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariIE = SafariBaseIE()
    username, password = safariIE._get_login_info()
    if username is None:
        return
    safariIE._download_webpage(safariIE._LOGIN_URL, None, None)
    safariIE._login()

# Generated at 2022-06-26 12:35:35.802697
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE(SafariApiIE.ie_key()).ie_key() == SafariApiIE.ie_key()

# Generated at 2022-06-26 12:35:37.040866
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE("http://techbus.safaribooksonline.com/9780134426365")

# Generated at 2022-06-26 12:35:39.579285
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()

    assert(not safari_base_ie.LOGGED_IN)
    safari_base_ie._real_initialize()
    assert(safari_base_ie.LOGGED_IN)

# Generated at 2022-06-26 12:38:24.487201
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..extractor.common import InfoExtractor
    from ..compat import json

    course_id = '9780133392838'
    course_title = 'Hadoop Fundamentals LiveLessons'

    # Dummy empty initializer
    def _real_initialize(self):
        pass

    # Creating object of class SafariBaseIE
    safari_base_obj = SafariBaseIE()

    # Overriding _real_initialize() method
    safari_base_obj.__class__._real_initialize = _real_initialize

    # Calling _real_initialize() method
    safari_base_obj._real_initialize()

    # Calling suitable method of InfoExtractor class

# Generated at 2022-06-26 12:38:35.028716
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html')

# Generated at 2022-06-26 12:38:40.574387
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838'
    ie = SafariApiIE()
    assert ie.suitable(url)

# Generated at 2022-06-26 12:38:43.429685
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # verify constructor SafariApiIE(SafariBaseIE)
    assert issubclass(SafariApiIE, SafariBaseIE)

# Generated at 2022-06-26 12:38:48.156491
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE().suitable('http://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')

# Generated at 2022-06-26 12:38:50.835915
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert 'safaribooksonline.com' in SafariCourseIE._VALID_URL

# Generated at 2022-06-26 12:38:52.421794
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE(None)
    assert isinstance(ie, ie)
    ie = SafariCourseIE(None)
    assert isinstance(ie, ie)
    ie = SafariCourseIE(None)
    assert isinstance(ie, ie)

# Generated at 2022-06-26 12:38:54.358298
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # Just test that SafariIE can be properly initialized
    pass

# Generated at 2022-06-26 12:38:59.074297
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():

    def construct_SafariBaseIE(ie_key, ie_name, ie_desc, valid_url, tests, LOGGED_IN=False):
        class SafariBaseTesterIE(SafariBaseIE):
            IE_NAME = ie_name
            IE_DESC = ie_desc
            _VALID_URL = valid_url
            _TESTS = tests
        safari_base_tester_ie = SafariBaseTesterIE(ie_key)
        safari_base_tester_ie.LOGGED_IN = LOGGED_IN
        return safari_base_tester_ie


# Generated at 2022-06-26 12:39:05.546789
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Basic test for SafariIE.
    """
    constructor_test(SafariIE(), [
        ('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314',
         'a2rcfzg84_ak')])