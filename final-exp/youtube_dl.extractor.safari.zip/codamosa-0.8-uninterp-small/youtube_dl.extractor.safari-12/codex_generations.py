

# Generated at 2022-06-26 12:31:37.265250
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()

# Generated at 2022-06-26 12:31:43.235660
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    safari_course_i_e_0 = SafariCourseIE()
    _x, i_e_info = safari_course_i_e_0.extract(url)
    assert i_e_info['id'] == '9780133392838'
    assert i_e_info['title'] == 'Hadoop Fundamentals LiveLessons'
# TEST


# Generated at 2022-06-26 12:31:44.520845
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:31:50.868134
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()
    assert isinstance(safari_base_i_e_0.login, object)
    assert isinstance(safari_base_i_e_0._API_BASE, object)
    assert isinstance(safari_base_i_e_0._API_FORMAT, object)
    assert isinstance(safari_base_i_e_0.LOGGED_IN, object)


# Generated at 2022-06-26 12:31:52.371070
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:31:53.601779
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:31:54.573736
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:31:55.507131
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
	safari_api_i_e = SafariApiIE();


# Generated at 2022-06-26 12:31:57.648332
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert safari_base_i_e_0
    assert isinstance(safari_base_i_e_0, SafariBaseIE)


# Generated at 2022-06-26 12:32:05.017155
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    IE_CLS = eval('SafariApiIE')
    instance1 = IE_CLS()
    assert(instance1.IE_NAME == 'safari:api')
    assert(instance1.IE_DESC is None)
    assert(instance1._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html')
    assert(instance1.LOGGED_IN == False)
    assert(instance1._NETRC_MACHINE == 'safari')

# Generated at 2022-06-26 12:32:27.885345
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:32:32.261351
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    mobj = re.match(SafariIE._VALID_URL, url)

    video_id = mobj.group('reference_id')
    if video_id:
        video_id = video_id
        partner_id = SafariIE._PARTNER_ID
        ui_id = SafariIE._UICONF_ID
    else:
        video_id = '%s-%s' % (mobj.group('course_id'), mobj.group('part'))

        webpage, urlh = SafariIE()._download_webpage_handle(url, video_id)


# Generated at 2022-06-26 12:32:37.668353
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert hasattr(SafariBaseIE, '_NETRC_MACHINE')
    assert hasattr(SafariBaseIE, '_API_FORMAT')
    assert hasattr(SafariBaseIE, '_VALID_URL')
    assert hasattr(SafariBaseIE, '_TESTS')
    assert hasattr(SafariBaseIE, '_download_webpage_handle')
    assert hasattr(SafariBaseIE, '_download_json_handle')
    assert hasattr(SafariBaseIE, '_apply_first_set_cookie_header')
    assert hasattr(SafariBaseIE, '_download_json')
    assert hasattr(SafariBaseIE, '_search_regex')
    assert hasattr(SafariBaseIE, 'url_result')
    assert has

# Generated at 2022-06-26 12:32:38.523087
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()

# Generated at 2022-06-26 12:32:40.027332
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:32:47.951727
# Unit test for constructor of class SafariIE
def test_SafariIE():
    video_id = '9780133392838-part00'
    url = 'https://www.safaribooksonline.com/api/v1/book/%s/?override_format=json' % video_id
    safari_i_e_0 = SafariIE()
    assert safari_i_e_0._call_api(url, video_id)


# Generated at 2022-06-26 12:32:49.182700
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()


# Generated at 2022-06-26 12:32:50.335029
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:32:51.485819
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:32:52.970442
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:33:35.483209
# Unit test for constructor of class SafariIE
def test_SafariIE():
    pass


# Generated at 2022-06-26 12:33:36.188374
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    test_case_0()

# Generated at 2022-06-26 12:33:37.120653
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:33:38.846509
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert safari_base_i_e_0._real_initialize() == None
    assert safari_base_i_e_0._login() == None


# Generated at 2022-06-26 12:33:47.988841
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-26 12:33:49.989092
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()
    assert safari_base_i_e_0.LOGGED_IN == False

# Generated at 2022-06-26 12:33:51.118352
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:33:52.198258
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:33:53.175413
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:33:54.690166
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()
    assert safari_course_i_e is not None


# Generated at 2022-06-26 12:34:24.294721
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test initializer of class SafariBaseIE
    ie = SafariBaseIE()
    assert ie.IE_NAME == 'safari'
    assert ie.IE_DESC is None

# Generated at 2022-06-26 12:34:35.316638
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE(SafariBaseIE.ie_key())
    assert ie.ie_key() == 'SafariCourse'
    assert ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/') == True
    assert ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html') == False

# Generated at 2022-06-26 12:34:45.544793
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = "https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro"
    api_base = "https://learning.oreilly.com/api/v1"
    api_format = "json"
    partner_id = "1926081"
    ui_conf_id = "29375172"
    kaltura_url = "https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php"
    safari = SafariIE()
    safari._download_json = lambda url, video_id, note, err_note, fatal, headers, data: "session"

# Generated at 2022-06-26 12:34:49.834698
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    if not (2, 7, 0) <= sys.version_info < (3, 0):
        raise unittest.SkipTest('The tests are only designed to run on Python 2')

    class _FakeLogin(SafariBaseIE):
        def __init__(self, url):
            SafariBaseIE.__init__(self, url)
        def _login(self):
            # Do not call SafariBaseIE._login()
            # Because it may call self._download_webpage()
            self.LOGGED_IN = True
        def _real_initialize(self):
            pass
        def _real_extract(self, url):
            pass

    _FakeLogin('https://www.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-26 12:34:56.558928
# Unit test for constructor of class SafariApiIE

# Generated at 2022-06-26 12:34:57.858480
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariIE('foo', 'bar')
    ie = SafariCourseIE('foo', 'bar')
    ie = SafariApiIE('foo', 'bar')

# Generated at 2022-06-26 12:35:03.148394
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_baseIE = SafariBaseIE()
    assert safari_baseIE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert safari_baseIE._NETRC_MACHINE == 'safari'
    assert safari_baseIE._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_baseIE._API_FORMAT == 'json'
    assert safari_baseIE.LOGGED_IN == False


# Generated at 2022-06-26 12:35:07.629895
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    import sys
    import unittest
    import xmlrunner
    import tempfile

    sys.argv[1:] = [
        '--cache-dir', tempfile.gettempdir(),
        '--xml', os.path.join(tempfile.gettempdir(), 'report.xml'),
        '--verbose'
    ]

    class UserAgentTest(unittest.TestCase):
        def setUp(self):
            self.ie = SafariCourseIE()

        def test_valid_url(self):
            self.assertTrue(self.ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'))

# Generated at 2022-06-26 12:35:09.230142
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    return SafariBaseIE('safari', 'safaribooksonline.com online video')

# Generated at 2022-06-26 12:35:18.356850
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    import urllib.request, json
    with urllib.request.urlopen("http://techbus.safaribooksonline.com/9780134217314") as response:
        html = response.read().decode("utf8")

    # prints the playlist
    # print(json.dumps(json.loads(html), sort_keys=True, indent=4, separators=(',', ': ')))

    # prints the first video
    first_video = json.loads(html)["chapters"][0]["web_url"]

    # print(first_video)

    # prints the HTML of the first video
    with urllib.request.urlopen(first_video) as response:
        html_video = response.read().decode("utf8")

    #print(html_video)

# Generated at 2022-06-26 12:36:32.358652
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # test creation of SafariIE with SafariBaseIE's constructor
    ie = SafariBaseIE('safari')
    assert ie.IE_NAME == 'safari'

# Generated at 2022-06-26 12:36:33.729890
# Unit test for constructor of class SafariIE
def test_SafariIE():
	from .common import list_categories
	list_categories(SafariIE._LOGIN_URL)

# Generated at 2022-06-26 12:36:34.093714
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass

# Generated at 2022-06-26 12:36:41.591726
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    _SafariCourseIE = SafariCourseIE("SafariCourseIE")
    assert _SafariCourseIE.IE_NAME == "safari:course"
    assert _SafariCourseIE.IE_DESC == "safaribooksonline.com online courses"
    assert _SafariCourseIE._VALID_URL == _SafariCourseIE.VALID_URL
    assert _SafariCourseIE.VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert _SafariCourseIE.LOGGED_IN == False
    assert _SafariCourseIE

# Generated at 2022-06-26 12:36:49.033425
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE('safari')
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

    # test for overwritten class attributes
    ie = SafariCourseIE('safari')
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == 'json'

# Generated at 2022-06-26 12:36:50.321661
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    obj = SafariApiIE()
    assert obj.IE_NAME == 'safari:api'


# Generated at 2022-06-26 12:36:51.838005
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safaribooksonline = SafariBaseIE()
    safaribooksonline._login()

# Generated at 2022-06-26 12:36:59.149221
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    my_obj = SafariApiIE()
    my_obj._download_json(
        'https://learning.oreilly.com/api/v1/book/9780134664057/?override_format=json',
        '9780134664057', 'Downloading course JSON')
    my_obj = SafariApiIE()
    my_obj._download_json(
        'https://learning.oreilly.com/api/v1/book/9780134664057/?override_format=json',
        '9780134664057', 'Downloading course JSON')
    my_obj = SafariApiIE()

# Generated at 2022-06-26 12:37:02.122909
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    print(SafariCourseIE.suitable.__doc__)
    assert SafariCourseIE.suitable.__doc__ != 'This is a dummy method, implemented to be able to run unit tests'

if __name__ == '__main__':
    test_SafariCourseIE()

# Generated at 2022-06-26 12:37:03.319079
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert safari_base_ie is not None



# Generated at 2022-06-26 12:39:47.272884
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test valid URL
    safari = SafariBaseIE('test', 'https://learning.oreilly.com/accounts/login/')
    result = safari._LOGIN_URL
    expected = 'https://learning.oreilly.com/accounts/login/'
    assert result == expected

# Generated at 2022-06-26 12:39:50.105537
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('SafariCourseIE', {}, {}, None, None)

from .common import *
from .compat import *
from .extractor import *
from .utils import *

# Generated at 2022-06-26 12:40:02.408653
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Not using the fixtures in order to avoid network requests
    # Setting up an API response in the usual way would require
    # constructing a request URL and mocking the response, which
    # feels like an overkill for just checking that that SafariBaseIE
    # does not explode in its constructor.
    dummy_response = b'{}\n'
    t = SafariBaseIE()
    with t._downloader.cache.file_cache(t._downloader, '', dummy_response) as cache:
        with cache('a') as cache_path:
            # We don't care about the actual return value, just want
            # to check that nothing explodes in a call to _login.
            t.extractor.process_video_result(
                t._real_extract(
                    'https://learning.oreilly.com/home/'))

# Generated at 2022-06-26 12:40:08.650888
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    expected = 'SafariCourseIE'
    assert class_for_url(url).__name__ == expected

# Generated at 2022-06-26 12:40:09.582768
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE({})

# Generated at 2022-06-26 12:40:13.335535
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE(None)

    assert ie.LOGGED_IN == False
    assert ie._API_FORMAT == 'json'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert ie._NETRC_MACHINE == 'safari'
    assert ie._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-26 12:40:18.914505
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    check_internet(False)
    test_class = SafariCourseIE()
    assert test_class.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-26 12:40:21.805880
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance = SafariIE('username', 'password')

    # This is just a smoke test, so we can make sure the constructor
    # doesn't raise any exception.
    assert isinstance(instance, SafariIE)

# Generated at 2022-06-26 12:40:24.758475
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('SafariCourse', {'id': 1})

# Generated at 2022-06-26 12:40:35.016266
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariie = SafariIE()