

# Generated at 2022-06-26 12:31:41.494071
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():

    # testings "if not isinstance(cls, type) :
    # cls = super(type, cls)
    # cls.__name__ = #cls.__name_"
    assert_equal(type(SafariCourseIE.__name__), str)


    # testing "def _match_id(cls, url) :
    # return cls._VALID_URL_RE.match(url).group('id')"
    assert_equal(SafariCourseIE._match_id('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'), '9781449396459')


    # testing "def ie_key(self) :
    # return self.IE_NAME"

# Generated at 2022-06-26 12:31:42.346129
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:31:43.192373
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance = SafariIE()

# Generated at 2022-06-26 12:31:47.130195
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()
    safari_i_e_0._real_initialize()
    safari_i_e_0._real_initialize()
    safari_i_e_0._real_initialize()


# Generated at 2022-06-26 12:31:48.535145
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:31:50.049313
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:31:51.274182
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:31:53.323559
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()
    assert(safari_i_e.LOGGED_IN == False)


# Generated at 2022-06-26 12:31:54.828878
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()
    assert safari_i_e_0.LOGGED_IN == False


# Generated at 2022-06-26 12:32:03.122947
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    print("Testing constructor for class SafariBaseIE")

    # Create a new object of class SafariBaseIE
    safari_base_i_e_0 = SafariBaseIE()

    # Check if this object is initialized correctly
    if (not(safari_base_i_e_0._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/')):
        raise Exception('Failed to initialize _LOGIN_URL of class SafariBaseIE')
    if (not(isinstance(safari_base_i_e_0._NETRC_MACHINE, str))):
        raise Exception('Failed to initialize _NETRC_MACHINE of class SafariBaseIE')

# Generated at 2022-06-26 12:32:27.563605
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass


# Generated at 2022-06-26 12:32:28.784098
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    pass


# Generated at 2022-06-26 12:32:30.287212
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
        from .common import InfoExtractor
        from ..utils import (
            ExtractorError,
            update_url_query,
        )

        testing_instance = SafariBaseIE()
        testing_instance.initialize()

# Generated at 2022-06-26 12:32:31.280702
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert 1 == 0


# Generated at 2022-06-26 12:32:32.154203
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()


# Generated at 2022-06-26 12:32:34.184732
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()

    safari_base_i_e_0.initialize()


# Generated at 2022-06-26 12:32:35.024277
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:32:36.087043
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Shouldn't raise exception
    safari_base_i_e = SafariBaseIE()


# Generated at 2022-06-26 12:32:37.336444
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()


# Generated at 2022-06-26 12:32:38.934399
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:32:54.587840
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('SafariCourseIE', 'safaribooksonline.com', '9780133392838')

# Generated at 2022-06-26 12:32:58.759301
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    IE = SafariApiIE()
    assert IE.IE_DESC == 'safaribooksonline.com online courses'
    assert IE._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-26 12:32:59.425391
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE()

# Generated at 2022-06-26 12:32:59.879208
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-26 12:33:06.335742
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    u0 = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    u1 = 'https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html'
    assert SafariBaseIE._VALID_URL == SafariIE._VALID_URL, '_VALID_URL should be updated'
    assert SafariCourseIE.suitable(u0) and not SafariCourseIE.suitable(u1), 'suitable(url) should return True for a course url and False for a chapter url'
    se = SafariCourseIE()
    assert se.IE_NAME == 'safari:course', 'IE_NAME should be set correctly'
    r = se._real

# Generated at 2022-06-26 12:33:15.255267
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_utils import fake_urlopen

    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    course_id = '9780133392838'
    content = b'''
        <script type="application/json" id="__NEXT_DATA__" class="nqrVc">
            {"props":{"initialProp":{"courseId":"%s","chapters":[],"hasEndorsed":false}}}
        </script>
    ''' % course_id.encode('utf-8')
    content_type = 'text/html; charset=utf-8'

    with fake_urlopen(content, content_type) as mock_urlopen:
        assert SafariCourseIE()._real_initialize()

# Generated at 2022-06-26 12:33:17.029934
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # verify login
    ie = SafariBaseIE()
    ie.login()
    ie.logged_in
    ie.logout()
    ie.logged_in

# Generated at 2022-06-26 12:33:19.396290
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    c = SafariCourseIE()
    c.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')

# Generated at 2022-06-26 12:33:24.485493
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+|
                                api/v1/book|
                                videos/[^/]+
                            )|
                            techbus\.safaribooksonline\.com
                        )
                        /(?P<id>[^/]+)
                    '''

test_SafariCourseIE()

# Generated at 2022-06-26 12:33:25.250972
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()



# Generated at 2022-06-26 12:34:07.448973
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Extractor.__init__ takes a single argument, and calls
    # InfoExtractor.__init__(self, ie_key)
    with SafariApiIE(ie_key=None) as safari_api_ie:
        assert isinstance(safari_api_ie, SafariApiIE)

# Generated at 2022-06-26 12:34:12.501908
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    sbi = SafariBaseIE()
    assert(sbi._TESTS == [])
    assert(sbi._PARTNER_ID == '1926081')
    assert(sbi._UICONF_ID == '29375172')
    assert(sbi.IE_DESC == 'safaribooksonline.com online video')
    assert(sbi.IE_NAME == 'safari')
    assert(sbi.LOGGED_IN == False)
    assert(sbi._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/')
    assert(sbi._NETRC_MACHINE == 'safari')

# Generated at 2022-06-26 12:34:15.988606
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    mobj = re.match(SafariBaseIE._VALID_URL, url)
    assert mobj.group('course_id') == '9781449396459'
    assert mobj.group('part') == 'part00'
    safari_api_ie = SafariApiIE()
    safari_api_ie._real_extract(url)

# Generated at 2022-06-26 12:34:20.594676
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # https://youtu.be/GVzDxjyX0l0?t=1
    # can't use vimeo here since it uses opus, which is not in our ffmpeg
    url = 'https://cdnapisec.kaltura.com/html5/html5lib/v2.37.1/mwEmbedFrame.php?wid=_1926081&uiconf_id=29375172&flashvars%5BreferenceId%5D=e8f076a9-9b36-4c80-b62b-fab40be7c2d2'
    ie = SafariApiIE()
    ie.extract(url)
    assert(len(ie.content_creator_ids) > 0)

# Generated at 2022-06-26 12:34:21.577102
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Tests that it's possible to create SafariApiIE without raising
    # ExtractorError or AssertionError
    SafariApiIE()

# Generated at 2022-06-26 12:34:22.934261
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    Test_SafariCourseIE = SafariCourseIE("http://techbus.safaribooksonline.com/9780134426365")
    print(Test_SafariCourseIE)

# Generated at 2022-06-26 12:34:26.576916
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    assert(safari_base_ie.IE_NAME == '')
    assert(safari_base_ie.IE_DESC == '')
    assert(safari_base_ie.LOGGED_IN == False)

# Generated at 2022-06-26 12:34:30.883703
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie_obj = SafariApiIE('safari:api')
    for key in ('SafariBaseIE', 'SafariApiIE'):
        assert ie_obj.__class__.__name__ == key
        ie_obj = ie_obj.__class__.__bases__[0](key)

# Generated at 2022-06-26 12:34:37.432515
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test safari_base.py a bit
    ie = SafariBaseIE('https://www.safaribooksonline.com/library/view/python-in-easy/9781782174597/')
    assert ie._LOGIN_URL == r'https://learning.oreilly.com/accounts/login/'
    assert ie._NETRC_MACHINE == r'safari'
    assert ie._API_BASE == r'https://learning.oreilly.com/api/v1'
    assert ie._API_FORMAT == r'json'

# Generated at 2022-06-26 12:34:44.833418
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # TODO: The following test fails (see the bug #1072).
    # When fixed, this test should be put to the unittests.
    # (All the safari extractors should be tested properly.)
    #
    # assert user_login('safaribooksonline', 'SafariBooksonlineAccount')
    # video_id = '100000006A0210-part00'
    # ie = SafariIE(url='http://techbus.safaribooksonline.com/%s' % video_id)
    # assert ie.LOGGED_IN
    pass

# Generated at 2022-06-26 12:36:13.353763
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert(safari_api_ie.__class__.__name__ == SafariApiIE.__name__)
    assert(safari_api_ie.ie_key() == SafariApiIE.ie_key())
    assert(safari_api_ie._VALID_URL == SafariApiIE._VALID_URL)
    assert(safari_api_ie.IE_NAME == SafariApiIE.IE_NAME)
    assert(safari_api_ie.IE_DESC == SafariApiIE.IE_DESC)


# Generated at 2022-06-26 12:36:22.279299
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert SafariApiIE.__name__ == 'SafariApiIE'
    assert inst.IE_NAME == 'safari:api'
    assert inst.IE_DESC == 'safaribooksonline.com online courses'
    assert inst._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    #assert inst.supported_ie == [SafariIE.ie_key()]
    #assert inst.supported_ie == ['Safari']

# Generated at 2022-06-26 12:36:23.366715
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari = SafariCourseIE()

# Generated at 2022-06-26 12:36:31.704763
# Unit test for constructor of class SafariIE
def test_SafariIE():
    # utility function to check object equality
    def assert_equal(actual_obj, expected_obj):
        assert actual_obj.__dict__ == expected_obj.__dict__
    # test with valid url
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safari_ie = SafariIE(url)
    assert_equal(safari_ie, SafariIE(url))
    # test with invalid url
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.htm'
    assert not SafariIE.suitable(url)

# Generated at 2022-06-26 12:36:34.072964
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from inspect import isclass, ismethod
    assert isclass(SafariCourseIE)
    assert ismethod(SafariCourseIE.suitable)
    assert ismethod(SafariCourseIE._real_extract)

# Generated at 2022-06-26 12:36:35.935165
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert inst._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert inst._API_FORMAT == 'json'

# Generated at 2022-06-26 12:36:40.588440
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    ie = SafariApiIE('safari', 'safaribooksonline.com online video')
    course_id = '9780134664057'
    part = 'RHCE_Introduction.html'
    url = 'https://www.safaribooksonline.com/api/v1/book/' + course_id \
        + '/chapter/' + part
    expected_url = 'https://www.safaribooksonline.com/library/view/' + course_id \
        + '/part00.html'
    extracted_url = ie._real_extract(url)['url']
    assert extracted_url == expected_url

# Generated at 2022-06-26 12:36:42.343659
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    obj = SafariApiIE()
    assert obj.suitable(test) == True

# Generated at 2022-06-26 12:36:51.118913
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from . import pack_testcases
    from .test_common import make_mocked_progress_hook, get_testcases_1, HEADRequest
    from .test_generic_common import GenericTestMocker
    # site: SafariApiIE
    # example: https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json
    # use first example to test safari.py
    test_urls = get_testcases_1('SafariApiIE', 0)
    mocker = GenericTestMocker(SafariApiIE.suitable, SafariApiIE)
    for test_url in test_urls:
        pack_testcases(mocker, test_url, SafariApiIE)
    # example use first example https://www.safarib

# Generated at 2022-06-26 12:36:52.268709
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance = SafariIE()
    assert isinstance(instance, SafariBaseIE)

# Generated at 2022-06-26 12:39:54.110607
# Unit test for constructor of class SafariIE
def test_SafariIE():
    print('Testing constructor of class SafariIE')
    from unittest import TestCase
    class TestSafariIE(TestCase):
        def setUp(self):
            self.test_obj = SafariIE()
        def tearDown(self):
            del self.test_obj
        def test_constructor(self):
            self.assertEqual(self.test_obj._VALID_URL, 'https?://(?:www\\.)?(?:safaribooksonline|(?:learning\\.)?oreilly)\\.com/library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?#&]+)\\.html')
            self.assertEqual(self.test_obj._PARTNER_ID, '1926081')

# Generated at 2022-06-26 12:39:57.795183
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')

# Generated at 2022-06-26 12:40:01.471898
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test Safaribooksonline object creation
    url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    return SafariApiIE()._real_extract(url)

# Generated at 2022-06-26 12:40:05.607085
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_test = SafariApiIE()
    assert safari_api_test.IE_NAME == 'safari:api'


# Generated at 2022-06-26 12:40:07.030147
# Unit test for constructor of class SafariIE
def test_SafariIE():
    instance = SafariIE()
    assert instance is not None

# Generated at 2022-06-26 12:40:11.322678
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    sbi_ie = SafariBaseIE(SafariBaseIE._downloader)
    assert isinstance(sbi_ie, SafariBaseIE) == True
    assert sbi_ie._downloader == SafariBaseIE._downloader
    assert sbi_ie._login() == None


# Generated at 2022-06-26 12:40:23.252737
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('', {}, None, None)
    assert (safari_ie.IE_NAME == 'safari')
    assert (safari_ie.IE_DESC == 'safaribooksonline.com online video')

# Generated at 2022-06-26 12:40:26.308729
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_ie = SafariBaseIE()
    safari_base_ie.get_real_name()

# Generated at 2022-06-26 12:40:27.852839
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie_SafariCourseIE = SafariCourseIE()

# Generated at 2022-06-26 12:40:29.812615
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('Safari', 'safaribooksonline.com')