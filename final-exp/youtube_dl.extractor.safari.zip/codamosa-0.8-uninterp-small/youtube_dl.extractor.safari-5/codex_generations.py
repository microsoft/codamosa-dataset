

# Generated at 2022-06-26 12:31:34.237856
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_a_i_e = SafariApiIE()


# Generated at 2022-06-26 12:31:35.254655
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:31:37.604928
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()
    safari_base_i_e_1 = SafariBaseIE()


# Generated at 2022-06-26 12:31:39.106274
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert_raises(TestFailure, test_case_0)

# Generated at 2022-06-26 12:31:41.137898
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e = SafariBaseIE()
    assert safari_base_i_e.LOGGED_IN == False


# Generated at 2022-06-26 12:31:43.582558
# Unit test for constructor of class SafariIE
def test_SafariIE():
  safari_i_e = SafariIE()
  assert isinstance(safari_i_e, InfoExtractor)

if __name__ == '__main__':
    test_case_0()
    test_SafariIE()

# Generated at 2022-06-26 12:31:44.244844
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-26 12:31:46.202555
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_b_i_e = SafariBaseIE()


# Generated at 2022-06-26 12:31:47.364979
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:31:48.722849
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()


# Generated at 2022-06-26 12:32:11.255577
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    instance = SafariCourseIE('safari', 'safaribooksonline.com online courses')
    assert instance.ie_name() == 'safari.course'
    assert instance.ie_key() == 'SafariCourse'

# Generated at 2022-06-26 12:32:18.628131
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from ..utils import random_user_agent
    # test SafariBaseIE
    headers = {
        'User-Agent': random_user_agent(),
    }
    safari_base_ie = SafariBaseIE()
    safari_base_ie._download_webpage(
        'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html',
        None, 'Downloading login page', headers=headers)

# Generated at 2022-06-26 12:32:19.378353
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-26 12:32:25.462022
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .common import ExtractorError
    from . import SafariCourseIE
    from . import SafariBaseIE
    from . import _SafariBaseIE
    from . import SafariIE
    from . import _SafariIE

    SafCourseIE = SafariCourseIE()
    SafBaseIE = SafariBaseIE()
    SafCourseIE.username = 'my_username'
    SafCourseIE.password = 'my_password'

    SafBaseIE.username = SafCourseIE.username
    SafBaseIE.password = SafCourseIE.password

    _SafBaseIE = _SafariBaseIE()
    _SafBaseIE.username = SafBaseIE.username
    _SafBaseIE.password = SafBaseIE.password

    SafIE = SafariIE()
    SafIE.username = SafCourseIE.username
    SafIE.password = SafCourseIE

# Generated at 2022-06-26 12:32:27.301303
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    from .test_common import ConstructorTestCase

    ConstructorTestCase.setUpTestCase()

    ConstructorTestCase.test_constructor(SafariCourseIE)
    ConstructorTestCase.tearDownTestCase()

# Generated at 2022-06-26 12:32:27.897094
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE()

# Generated at 2022-06-26 12:32:30.158502
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    inst = SafariBaseIE()
    assert inst.LOGGED_IN is False
    assert inst._login() is None

# Generated at 2022-06-26 12:32:34.081905
# Unit test for constructor of class SafariIE
def test_SafariIE():
    from .test_html import get_testcases
    from .test_kaltura import KalturaIE
    for testcase in get_testcases(KalturaIE.ie_key()):
        if ('safaribooksonline.com'
                not in testcase.get('url')
                or 'part01' in testcase.get('url')):
            continue
        print('testing safari on %s ...' % testcase.get('url'))
        SafariIE._real_extract(SafariIE(), testcase.get('url'))

# Generated at 2022-06-26 12:32:35.746504
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base = SafariBaseIE("SafariBaseIE")
    assert safari_base.IE_NAME == "SafariBaseIE"
    assert safari_base.LOGGED_IN == False

# Generated at 2022-06-26 12:32:37.180928
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari = SafariIE()
    assert not safari.LOGGED_IN
    safari._login()
    assert safari.LOGGED_IN


# Generated at 2022-06-26 12:33:09.325559
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_ie = SafariApiIE()
    assert safari_api_ie

# Generated at 2022-06-26 12:33:13.343950
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit tests for the SafariCourseInfoExtractor class."""
    url = "http://techbus.safaribooksonline.com/9780134426365"
    # we're not expecting this test to fail as there are no assertions made per se.
    # we're just testing that there aren't any exceptions thrown
    SafariCourseIE().suitable(url)

# Generated at 2022-06-26 12:33:14.308338
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert('safaribooksonline' in SafariBaseIE._NETRC_MACHINE)

# Generated at 2022-06-26 12:33:21.783327
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Make sure that an exception is thrown if the page is opened
    # using an older version of Safari.
    logging.debug('Opening Page using old version of Safari')
    page = webdriver.Firefox()
    page.get('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert 'You\'re using an older version of Safari' in page.page_source
    page.close()

    # Make sure that the constructor of SafariApiIE does not throw an
    # exception if the page is opened using a newer version of Safari.
    logging.debug('Opening Page using new version of Safari')
    page = webdriver.Firefox()

# Generated at 2022-06-26 12:33:25.386367
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():

    class UnitTestSafariBaseIE(SafariBaseIE):
        _TEST = {
            'url': 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838',
            'example_count': 1,
            'info_dict': {'id': '9780133392838'},
        }

    UnitTestSafariBaseIE()._login()

# Generated at 2022-06-26 12:33:25.938920
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE('Safari')

# Generated at 2022-06-26 12:33:28.401446
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # test SafariBaseIE doesn't blow up when given an empty url
    url = ''
    expectedError = 'URL doesn\'t match any supported patterns!'
    try:
        SafariBaseIE(url)
    except ExtractorError as e:
        assert str(e) == expectedError
    else:
        assert False, 'expected ExtractorError'

# Generated at 2022-06-26 12:33:36.583705
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Try to log in without username and password
    SafariBaseIE._download_webpage_handle = lambda *a, **kw: (None, None)
    SafariBaseIE._download_json_handle = lambda *a, **kw: (None, None)
    SafariBaseIE._apply_first_set_cookie_header = lambda *a, **kw: None
    SafariBaseIE('', '')
    # Try to log in with username and password
    SafariBaseIE._download_webpage_handle = lambda *a, **kw: (None, None)
    SafariBaseIE._download_json_handle = lambda *a, **kw: (None, None)
    SafariBaseIE._apply_first_set_cookie_header = lambda *a, **kw: None
    SafariBaseIE('test', 'test')

# Generated at 2022-06-26 12:33:44.923145
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    expected_id = '9780133392838'
    expected_title = 'Hadoop Fundamentals LiveLessons'

    course_id = SafariCourseIE._match_id('https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json')
    assert course_id == '9781449396459'

    # in the _real_extract method of SafariCourseIE, the result of _match_id will be used to download a JSON file
    # and to extract the course_id and course_title
    course_id, course_title = SafariCourseIE._real_extract(
        SafariCourseIE(), 'https://www.safaribooksonline.com/api/v1/book/%s/?override_format=json' % expected_id)
   

# Generated at 2022-06-26 12:33:47.467380
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    obj = SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')
    return 'test.json' in obj.__dict__.get('_downloader')

# Generated at 2022-06-26 12:34:48.408590
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert inst.LOGGED_IN == False
    inst._login()

# Generated at 2022-06-26 12:34:49.013688
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE

# Generated at 2022-06-26 12:34:55.856265
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safariIE = SafariIE()
    assert safariIE._VALID_URL == re.compile(r'''(?x)
                        https?://
                            (?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/
                            (?:
                                library/view/[^/]+/(?P<course_id>[^/]+)/(?P<part>[^/?\#&]+)\.html|
                                videos/[^/]+/[^/]+/(?P<reference_id>[^-]+-[^/?\#&]+)
                            )
                    ''')
    
    assert safariIE._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safariIE._API_FORMAT == 'json'
   

# Generated at 2022-06-26 12:34:57.235411
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test login
    safari = SafariBaseIE()
    safari._login()
    assert safari.LOGGED_IN


# Generated at 2022-06-26 12:34:58.513524
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    instance = SafariCourseIE()
    assert isinstance(instance, SafariCourseIE)
    assert isinstance(instance, SafariBaseIE)

# Generated at 2022-06-26 12:35:00.263073
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    ie = SafariBaseIE()
    ie.LOGGED_IN = True
    assert ie._API_FORMAT == 'json'
    assert ie._API_BASE == 'https://learning.oreilly.com/api/v1'

# Generated at 2022-06-26 12:35:09.872819
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = 'https://www.safaribooksonline.com/api/v1/book/9780132173637/chapter/part00.html'
    unit_test_SafariApiIE = SafariApiIE()

    class test_SafariApiIE:
        def _download_json_handle(self, *args, **kwargs):
            return {}

    unit_test_SafariApiIE_local = test_SafariApiIE()
    unit_test_SafariApiIE.report_login = False
    unit_test_SafariApiIE.LOGGED_IN = True
    unit_test_SafariApiIE.url_result = lambda x, y: y

# Generated at 2022-06-26 12:35:18.155021
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from .test_common import make_url_result, make_url_result_1
    from .test_common import make_single_result

    tests = [
        (make_url_result_1('https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html'),
         make_single_result('0_qbqx90ic', 'Kaltura'),
         None),
    ]

    test_urls = [
        (make_url_result(t[0][0], t[0][1]), t[1], t[2])
        for t in tests]

    ie = SafariApiIE()
    ie.test(test_urls)



# Generated at 2022-06-26 12:35:25.517758
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-26 12:35:26.636097
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert hasattr(SafariBaseIE(None), "LOGGED_IN")

# Generated at 2022-06-26 12:38:07.557160
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test constructor of class SafariCourseIE
    IE = SafariCourseIE()

# Generated at 2022-06-26 12:38:14.672534
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from nose.tools import nottest
    
    @nottest
    def test_SafariApiIE_constructor():
        return SafariApiIE()

    # Before real initialization it should not raise any exception
    test_SafariApiIE_constructor()

    # Then it should succeed to initialize (with dummy parameters)
    test_SafariApiIE_constructor()._real_initialize()

    # Then it should succeed to initialize (with real parameters)
    test_SafariApiIE_constructor()._real_initialize(
            username='test', password='test')


# Generated at 2022-06-26 12:38:18.955714
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE()
    assert safari_ie.IE_NAME == "safari"
    assert safari_ie.LOGGED_IN == False


# Generated at 2022-06-26 12:38:20.766858
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()
    assert isinstance(instance, SafariBaseIE)

# Generated at 2022-06-26 12:38:27.105488
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Test valid URL
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'
    assert SafariApiIE._VALID_URL == SafariApiIE.VALID_URL, 'VALID_URL value should be equal to the hardcoded input'
    assert SafariApiIE.suitable(test_url), 'VALID_URL should be suitable for input'

    # Test invalid URL
    test_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part0f00.html'
    assert not SafariApiIE.suitable(test_url), 'VALID_URL should not be suitable for input'

# Generated at 2022-06-26 12:38:30.422732
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    x = SafariBaseIE(SafariIE.ie_key())
    assert x.LOGGED_IN == False
    return x

# Generated at 2022-06-26 12:38:34.464562
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Test for SafariBaseIE._real_initialize
    SafariBaseIE._real_initialize()
    assert isinstance(SafariBaseIE._download_json(None, None, None, None, None, None), dict)
    # Test for SafariBaseIE._download_webpage_handle
    assert SafariBaseIE._download_webpage_handle(None, None, None) is not None

# Generated at 2022-06-26 12:38:38.251419
# Unit test for constructor of class SafariIE
def test_SafariIE():
    Test = SafariIE._TESTS
    test = Test[0]
    SafariIE(test['url'])

# Generated at 2022-06-26 12:38:42.286715
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # the test has been created when SafariApiIE was
    # inheriting from SafariBaseIE
    assert issubclass(SafariApiIE, InfoExtractor)

# Generated at 2022-06-26 12:38:43.534028
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    _ = SafariApiIE('Safari', 'Safari Online Courses')