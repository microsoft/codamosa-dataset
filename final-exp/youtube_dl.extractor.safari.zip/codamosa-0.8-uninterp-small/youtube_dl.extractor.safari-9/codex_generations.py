

# Generated at 2022-06-26 12:31:34.237445
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()

# Generated at 2022-06-26 12:31:35.291935
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:31:37.265635
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()
    pass


# Generated at 2022-06-26 12:31:38.726985
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()



# Generated at 2022-06-26 12:31:39.935349
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:31:41.319688
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:31:42.161818
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert_equal(type(safari_course_i_e_0), SafariCourseIE)

# Generated at 2022-06-26 12:31:46.333087
# Unit test for constructor of class SafariIE
def test_SafariIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    safari_i_e_0 = SafariIE()



# Generated at 2022-06-26 12:31:55.119182
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()
    assert safari_i_e.i_e_name == 'safari'
    assert safari_i_e.i_e_desc == 'safaribooksonline.com online video'

# Generated at 2022-06-26 12:31:57.020721
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # test_case_0
    safari_course_i_e_0 = SafariCourseIE()

# Generated at 2022-06-26 12:32:34.320273
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # url = url
    url = 'https://www.safaribooksonline.com/api/v1/book/9780134344357/chapter/part01.html'
    SafariApiIE(url=url)



# Generated at 2022-06-26 12:32:35.563772
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:32:36.419745
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e_0 = SafariApiIE()


# Generated at 2022-06-26 12:32:37.381672
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE()


# Generated at 2022-06-26 12:32:39.526610
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0=SafariIE()
    assert_raises(Exception, safari_i_e_0._real_initialize)

# Generated at 2022-06-26 12:32:43.085131
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert not isinstance(test_case_0, SafariCourseIE)


# Generated at 2022-06-26 12:32:47.527987
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert(SafariCourseIE.suitable(None))
    assert(SafariCourseIE.suitable(True))
    safari_course_i_e_0 = SafariCourseIE()
    assert(isinstance(safari_course_i_e_0, SafariCourseIE))
    assert(isinstance(safari_course_i_e_0, SafariBaseIE))
    assert(isinstance(safari_course_i_e_0, InfoExtractor))
    assert(hasattr(safari_course_i_e_0, '_WORKING'))
    assert(hasattr(safari_course_i_e_0, '_downloader'))
    assert(hasattr(safari_course_i_e_0, '_download_webpage_handle'))

# Generated at 2022-06-26 12:32:48.844701
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:32:49.985065
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e = SafariCourseIE()


# Generated at 2022-06-26 12:32:51.448078
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # constructor of class SafariCourseIE
    safari_course_i_e = SafariCourseIE()



# Generated at 2022-06-26 12:34:04.676662
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e = SafariIE()

# Generated at 2022-06-26 12:34:05.982334
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert safari_course_i_e_0.suitable('http://techbus.safaribooksonline.com/9780134426365') == True


# Generated at 2022-06-26 12:34:07.089790
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()


# Generated at 2022-06-26 12:34:07.893018
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    SafariApiIE()


# Generated at 2022-06-26 12:34:17.940052
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert(SafariBaseIE._VALID_URL is None)
    assert(SafariBaseIE._TESTS is None)
    assert(SafariBaseIE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/')
    assert(SafariBaseIE._NETRC_MACHINE == 'safari')
    assert(SafariBaseIE._API_BASE == 'https://learning.oreilly.com/api/v1')
    assert(SafariBaseIE._API_FORMAT == 'json')
    assert(SafariBaseIE.LOGGED_IN is False)
    assert(SafariBaseIE._partner_id is None)
    assert(SafariBaseIE._uiconf_id is None)

# Generated at 2022-06-26 12:34:21.975133
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safariBaseIE = SafariBaseIE()
    assert(safariBaseIE._valid_url('any_url'))
    assert(safariBaseIE.suitable('any_url'))


# Generated at 2022-06-26 12:34:23.517168
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()

# Generated at 2022-06-26 12:34:25.821911
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e = SafariBaseIE()

if __name__ == "__main__":
    test_case_0()
    test_SafariBaseIE()

# Generated at 2022-06-26 12:34:34.143185
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_i_e_0 = SafariCourseIE()
    assert safari_course_i_e_0.suitable(SafariCourseIE.suitable)
    assert safari_course_i_e_0.suitable(SafariCourseIE._VALID_URL)
    assert safari_course_i_e_0.IE_NAME == 'safari:course'
    assert safari_course_i_e_0.IE_DESC == 'safaribooksonline.com online courses'


# Generated at 2022-06-26 12:34:40.375765
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert (SafariCourseIE().suitable("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/") == True)
    assert (SafariCourseIE().suitable("https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json") == True)
    assert (SafariCourseIE().suitable("http://techbus.safaribooksonline.com/9780134426365") == True)
    assert (SafariCourseIE().suitable("https://www.safaribooksonline.com/videos/python-programming-language/9780134217314") == True)

# Generated at 2022-06-26 12:36:06.772073
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    """Unit test for constructor of class SafariCourseIE"""
    IE_OBJ = SafariCourseIE('http://www.safaribooksonline.com/api/v1/book/9781449396459')
    assert IE_OBJ._API_BASE == 'https://www.safaribooksonline.com/api/v1'
    assert IE_OBJ._API_FORMAT == 'xml'

# Generated at 2022-06-26 12:36:10.474753
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course = SafariCourseIE('https://learning.oreilly.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert isinstance(course, SafariCourseIE)
    assert not (isinstance(course, InfoExtractor))


# Generated at 2022-06-26 12:36:11.152546
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE()

# Generated at 2022-06-26 12:36:15.304618
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    with open('test/testdata/safari/safaribooksonline_accounts_login_check.json','r') as f:
        webpage = f.read()
    # Return a response object
    safari_base_ie = SafariBaseIE()
    # Get the title
    safari_base_ie.get_title()

# Generated at 2022-06-26 12:36:23.609479
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Input args
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    # Expected output
    expected_response = ExtractorError(
                'No chapters found for course 9781449396459', expected=True)
    # Actual output
    expected_output = SafariCourseIE()
    try:
        actual_output = expected_output.suitable(url)
        actual_response = expected_output._real_extract(url)
    except AssertionError as e:
        actual_response = e
    # Assertion
    assert not actual_output
    assert str(actual_response) == str(expected_response)



# Generated at 2022-06-26 12:36:27.135816
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """Test constructor of class SafariIE"""
    test_url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    obj = SafariIE()
    assert_equal(test_url, obj._VALID_URL)

# Generated at 2022-06-26 12:36:28.727619
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # Do nothing.
    return

# Generated at 2022-06-26 12:36:36.334352
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    test = SafariApiIE(object)
    assert test.IE_NAME == 'safari:api', "%r != 'safari:api'" % test.IE_NAME
    assert test.IE_DESC == 'safaribooksonline.com online api service', "%r != 'safaribooksonline.com online api service'" % test.IE_DESC
    test._VALID_URL = r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'

# Generated at 2022-06-26 12:36:40.390487
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class_constr = getattr(SafariIE, '__init__')
    def_constr = getattr(InfoExtractor, '__init__')
    class_constr(SafariIE("safariIE", "safaribooksonline.com online video"))
    def_constr(SafariIE("safariIE", "safaribooksonline.com online video"))

# Generated at 2022-06-26 12:36:46.822325
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    class Called(object):
        def __init__(self):
            self._called = False
        def __call__(self, url):
            self._called = True
            return True

    course_ie = SafariCourseIE()

    check_suitable = Called()

    course_ie.ie_key = lambda: IE_NAME
    course_ie.ie = lambda: check_suitable

    course_ie.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838')

    assert check_suitable._called == False

# Generated at 2022-06-26 12:39:27.624393
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE('safari')

# Generated at 2022-06-26 12:39:30.180627
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = "https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json"
    ie = SafariApiIE()
    result = ie.suitable(url)
    assert result == True

# Generated at 2022-06-26 12:39:33.305624
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    SafariCourseIE('http://techbus.safaribooksonline.com/9780134426365')

# Generated at 2022-06-26 12:39:33.962614
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    SafariBaseIE(SafariApiIE)

# Generated at 2022-06-26 12:39:36.590250
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    assert SafariBaseIE._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'

# Generated at 2022-06-26 12:39:40.272228
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    a = SafariCourseIE("https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/")
    assert a._API_BASE == "https://learning.oreilly.com/api/v1"

# Generated at 2022-06-26 12:39:45.847522
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    t = SafariCourseIE()
    assert t._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert t._API_FORMAT == 'json'
    assert t.LOGGED_IN == False

# Generated at 2022-06-26 12:39:54.441957
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # >>> form = cgi.FieldStorage()
    # >>> print('\\n'.join('%s = %r' % (key, form[key].value) for key in form))
    # submitted = True
    # username = 'somemember@yahoo.com'
    # password = 'somepassword'
    # token = 'some token'
    # origin = 'https://sso.safaribooksonline.com'
    # next = '/accounts/login/'

    username = 'somemember@yahoo.com'
    password = 'somepassword'
    next_uri = '/accounts/login/'
    next_url = 'https://learning.oreilly.com%s' % next_uri


# Generated at 2022-06-26 12:40:01.237428
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE()._VALID_URL == r'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    #assert SafariApiIE().IE_NAME == r'safari:api'

# Generated at 2022-06-26 12:40:12.336677
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safari_course_ie = SafariCourseIE()
    assert safari_course_ie.IE_NAME == 'safari:course'
    assert safari_course_ie.IE_DESC == 'safaribooksonline.com online courses'
    assert safari_course_ie._VALID_URL == r'(?x)https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/(?:library/view/[^/]+|api/v1/book|videos/[^/]+)/(?P<id>[^/]+)'
    assert safari_course_ie.LOGGED_IN == False