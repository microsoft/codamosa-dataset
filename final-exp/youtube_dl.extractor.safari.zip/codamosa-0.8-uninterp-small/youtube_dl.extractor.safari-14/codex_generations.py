

# Generated at 2022-06-26 12:31:35.485436
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    safari_api_i_e = SafariApiIE()
    assert safari_api_i_e.IE_NAME == 'safari:api'


# Generated at 2022-06-26 12:31:43.385219
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    with open('./test_data/test_case_1.json', 'r') as expected_json_file:
        expected_json = json.load(expected_json_file)
    with open('./test_data/test_case_1.out', 'r') as expected_out_file:
        expected_out = expected_out_file.read()
    with open('./test_data/test_case_1.json', 'r') as actual_json_file:
        actual_json = json.load(actual_json_file)
    if expected_json == actual_json:
        print(expected_out)
    else:
        raise Exception('Expected json and actual json are not equal!')


# Generated at 2022-06-26 12:31:44.686545
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e = SafariBaseIE()


# Generated at 2022-06-26 12:31:46.333411
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_i_e_0 = SafariIE()

# Generated at 2022-06-26 12:31:47.771252
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()



# Generated at 2022-06-26 12:31:48.610293
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    instance = SafariBaseIE()


# Generated at 2022-06-26 12:31:49.736136
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass


# Generated at 2022-06-26 12:31:50.989233
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e_0 = SafariBaseIE()


# Generated at 2022-06-26 12:31:58.967076
# Unit test for constructor of class SafariBaseIE

# Generated at 2022-06-26 12:31:59.709575
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    safari_base_i_e = SafariBaseIE()

# Generated at 2022-06-26 12:32:24.543724
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    inst = SafariApiIE()
    assert inst.name == 'safari:api'
    assert inst._VALID_URL == 'https?://(?:www\.)?(?:safaribooksonline|(?:learning\.)?oreilly)\.com/api/v1/book/(?P<course_id>[^/]+)/chapter(?:-content)?/(?P<part>[^/?#&]+)\.html'
    assert inst._NETRC_MACHINE == 'safari'

# Generated at 2022-06-26 12:32:28.120542
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE.suitable(SafariCourseIE._VALID_URL)

# Generated at 2022-06-26 12:32:34.754467
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/'
    player = SafariCourseIE()
    result = player._real_extract(url)
    assert result['_type'] == 'playlist'
    assert result['title'] == 'Hadoop Fundamentals LiveLessons'
    assert result['id'] == '9780133392838'
    assert result['entries'] is not None


# Generated at 2022-06-26 12:32:36.004059
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    assert ie._VALID_URL == SafariIE._VALID_URL
    assert ie._TESTS == SafariIE._TESTS

# Generated at 2022-06-26 12:32:37.050897
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    ie = SafariCourseIE()
    assert "SafariCourseIE" == ie.ie_key()

# Generated at 2022-06-26 12:32:42.249266
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    from .test_utils import FakeLoginIE
    # Default arguments
    safariie = SafariBaseIE()
    assert isinstance(safariie.username, str)
    assert isinstance(safariie.password, str)
    assert safariie.LOGGED_IN == False

    # Change arguments
    safariie = SafariBaseIE('username', 'password')

    # Check if the login works
    FakeLoginIE._fake_login()
    safariie.username = (FakeLoginIE.USERNAME, PasswordIE.PASSWORD)
    safariie._login()
    assert safariie.LOGGED_IN is True

# Generated at 2022-06-26 12:32:52.413412
# Unit test for constructor of class SafariCourseIE

# Generated at 2022-06-26 12:32:53.964339
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    if not SafariBaseIE.LOGGED_IN:
        raise Exception("Unable to login to Safari and extract JSON")

# Generated at 2022-06-26 12:32:55.406756
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    # import pdb; pdb.set_trace()
    safariBaseIE = SafariBaseIE()

# Generated at 2022-06-26 12:32:56.219426
# Unit test for constructor of class SafariIE
def test_SafariIE():
    s = SafariIE()
    assert(isinstance(s,InfoExtractor))


# Generated at 2022-06-26 12:33:43.150708
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    try:
        SafariBaseIE(None)
    except Exception as e:
        assert e.__str__() == 'ERROR: Cannot instantiate directly'

# Generated at 2022-06-26 12:33:51.645184
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    course_id = "9780134664057"
    part_id = "RHCE_Introduction"
    url = "https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html"

    expected_web_url = "https://learning.oreilly.com/videos/red-hat-certified/9780134664057-RHCE_Introduction"
    expected_part_id = '9780134664057-RHCE_Introduction'
    expected_id = '%s/%s' % (course_id, part_id)

    # Create the object
    api_ie = SafariApiIE()

    # Test _real_extract
    part = api_ie._real_extract(url)

    # Test the result

# Generated at 2022-06-26 12:33:53.174251
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Returns a valid SafariIE object with LOGGED_IN = True
    """
    safari_ie = SafariIE()
    return safari_ie

# Generated at 2022-06-26 12:33:56.705687
# Unit test for constructor of class SafariIE
def test_SafariIE():
    """
    Constructor test cases for SafariIE
    """
    safarie = SafariIE()
    assert(safarie.LOGGED_IN == False)
    assert(safarie._UICONF_ID == '29375172')
    assert(safarie._PARTNER_ID == '1926081')

# Generated at 2022-06-26 12:34:06.907094
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_id = '9781449396459'
    course_url = '%s/book/%s/?override_format=%s' % (SafariBaseIE._API_BASE, course_id, SafariBaseIE._API_FORMAT)
    course_json = {
        'chapters': ['https://www.safaribooksonline.com/api/v1/book/9781449396459/chapter/part00.html'],
        'title': 'test_SafariCourseIE',
    }
    course_title = course_json['title']

    # Uncomment to bypass unit test and update the expected values.
    # from .common import update_json
    # update_json(course_url, course_json)

    ie = SafariCourseIE()

# Generated at 2022-06-26 12:34:11.592277
# Unit test for constructor of class SafariIE
def test_SafariIE():
    safari_ie = SafariIE('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')

    assert safari_ie._API_BASE == 'https://learning.oreilly.com/api/v1'
    assert safari_ie._API_FORMAT == 'json'
    assert safari_ie._PARTNER_ID == '1926081'
    assert safari_ie._UICONF_ID == '29375172'


# Generated at 2022-06-26 12:34:12.302798
# Unit test for constructor of class SafariIE
def test_SafariIE():
    SafariIE("testing")

# Generated at 2022-06-26 12:34:13.312619
# Unit test for constructor of class SafariIE
def test_SafariIE():
    pass



# Generated at 2022-06-26 12:34:25.016510
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    _ref_date = dict(
        year=2019,
        month=3,
        day=14,
        hour=15,
        minute=29,
        second=24,
    )
    _ref_info = dict(
        id='9780134217314',
        title='Python Programming Language',
    )
    _ref = dict(
        date = _ref_date,
        info = _ref_info,
        url = 'https://www.safaribooksonline.com/library/view/python-programming-language/9780134217314/',
    )
    safari_api_ie = SafariApiIE(_ref_date, _ref_info, _ref)
    return safari_api_ie

# Generated at 2022-06-26 12:34:26.449499
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    info_extractor = SafariBaseIE('safari', {})

# Generated at 2022-06-26 12:35:51.916728
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    url = SafariApiIE._VALID_URL
    match = re.match(SafariApiIE._VALID_URL, url)
    content = json.dumps({
        'web_url': "https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html"
    })
    SafariApiIE(
        match,
        MockYoutubeDL({
            'extractor': 'SafariApiIE',
            'downloader': 'SafariApiIE',
            'params': {'test': True}
        }),
        {'webpage_url': url, 'webpage_content': content}
    )

# Generated at 2022-06-26 12:35:58.922787
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    class TestSafariApiIE(SafariApiIE):
        def _download_json(self, url, video_id, note, errnote, transform_source=lambda s: s, fatal=True, headers=None):
            return '{"web_url": "https://...", "_source": {...}}'
    inst = TestSafariApiIE()
    inst.url_result = lambda url, ie: ie
    inst.suitable = lambda url: False
    inst.add_ie = lambda ie: None
    inst._real_initialize()
    inst._real_extract('https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html')

# Generated at 2022-06-26 12:36:01.289875
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    tester = SafariApiIE()
    tester._login()
    assert tester.LOGGED_IN == (tester._username != '')

    from math import isnan
    assert isnan(tester._request_signature('test'))

# Generated at 2022-06-26 12:36:05.308919
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    # Dummy URL
    url = 'https://www.safaribooksonline.com/api/v1/book/9780134664057/chapter/RHCE_Introduction.html'

    # Check existence of instance
    assert SafariApiIE(SafariApiIE.ie_key())({'url': url})

# Generated at 2022-06-26 12:36:11.232739
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    """
    Class `SafariBaseIE` is an abstract class that should not be instantiated.
    """
    instance = SafariBaseIE()
    if not isinstance(instance, InfoExtractor):
        raise RuntimeError('SafariBaseIE is not an instance of InfoExtractor')

    try:
        instance = SafariBaseIE('x', 'y', 'z')
    except TypeError as e:
        if str(e) != 'Can\'t instantiate abstract class SafariBaseIE with abstract methods _login':
            raise RuntimeError('TypeError exception not correctly caught')
    except:
        raise RuntimeError('TypeError exception not correctly caught')

# Generated at 2022-06-26 12:36:15.760738
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    """
    Test the constructor of class SafariApiIE
    """
    if not __name__ == "__main__":
        pytest.skip()

    ie = SafariApiIE()
    assert(ie.ie_key() == 'SafariApi')
    assert(ie.ie_name == 'safaribooksonline.com online video')


# Generated at 2022-06-26 12:36:24.587293
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    course_id = '9780133392838'
    url = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/'+course_id+'/'
    course_json = """
    {
        "chapters": [
            "https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part00.html",
            "https://www.safaribooksonline.com/api/v1/book/9780133392838/chapter/part01.html"
        ]
    }
    """
    course_json = compat_str(course_json)

    json_data = json.loads(course_json)

    inst = SafariCourseIE()


# Generated at 2022-06-26 12:36:26.084803
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    assert SafariApiIE(SafariBaseIE())._VALID_URL == SafariApiIE._VALID_URL

# Generated at 2022-06-26 12:36:29.302293
# Unit test for constructor of class SafariIE
def test_SafariIE():
    ie = SafariIE()
    rv = repr(ie)
    assert rv
    assert rv.startswith('SafariIE(')
    assert rv.endswith(')')

# Generated at 2022-06-26 12:36:29.831971
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-26 12:39:21.765366
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    assert SafariCourseIE._VALID_URL == SafariCourseIE._TESTS[0]['url']

# Generated at 2022-06-26 12:39:23.266951
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    return SafariCourseIE('safari:course')


# Generated at 2022-06-26 12:39:24.090503
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    pass

# Generated at 2022-06-26 12:39:32.175588
# Unit test for constructor of class SafariIE
def test_SafariIE():
    class UnitTestSafariIE(SafariIE):
        def _download_webpage_handle(self, url, video_id, note=None, errnote=None, fatal=True, data=None, headers={}):
            return True, None

        def _download_json_handle(self, url, video_id, note=None, errnote=None, fatal=True, data=None, headers={}, query={}):
            return True, None

        def _apply_first_set_cookie_header(self, urlh, cookie):
            return True

        def _download_json(self, url, video_id, note=None, errnote=None, fatal=True, query={}, data=None, headers={}):
            return True

    UnitTestSafariIE()._real_initialize()
# End of unit test



# Generated at 2022-06-26 12:39:38.263959
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Invalid url returns None
    url = 'https://www.safaribooksonline.com/library/view/test/test/test.html'
    result = SafariCourseIE.suitable(url)
    assert result == False

# Generated at 2022-06-26 12:39:44.521147
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    safariCourseIE = SafariCourseIE()
    try:
        assert(safariCourseIE != None)
    except AssertionError as e:
        print("AssertionError raised", e)
        assert(False)
    print("test_SafariCourseIE successful")


# Generated at 2022-06-26 12:39:48.278745
# Unit test for constructor of class SafariBaseIE
def test_SafariBaseIE():
    a = SafariBaseIE()
    assert a._LOGIN_URL == 'https://learning.oreilly.com/accounts/login/'
    assert a.LOGGED_IN == False

# Generated at 2022-06-26 12:39:55.332372
# Unit test for constructor of class SafariIE
def test_SafariIE():
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/create-a-nodejs/100000006A0210/part00.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/library/view/learning-path-red/9780134664057/RHCE_Introduction.html')
    assert SafariIE.suitable('https://www.safaribooksonline.com/videos/python-programming-language/9780134217314/9780134217314-PYMC_13_00')
    assert SafariIE.suitable

# Generated at 2022-06-26 12:40:04.145886
# Unit test for constructor of class SafariApiIE
def test_SafariApiIE():
    from ...compat import unittest

    from .test_youtube import TestYoutubeIE

    sample_url = 'https://www.safaribooksonline.com/api/v1/book/9781449396459/?override_format=json'
    sample_url_2 = 'https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html'
    sample_url_3 = 'https://learning.oreilly.com/videos/hadoop-fundamentals-livelessons/9780133392838/9780133392838-00_SeriesIntro'

# Generated at 2022-06-26 12:40:13.066255
# Unit test for constructor of class SafariCourseIE
def test_SafariCourseIE():
    # Test extracting the course id from the URL
    course_id = SafariCourseIE._match_id('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/')
    assert course_id == '9780133392838'

    # Test extracting the course id from the URL of a chapter
    course_id = SafariCourseIE._match_id('https://www.safaribooksonline.com/library/view/hadoop-fundamentals-livelessons/9780133392838/part00.html')
    assert course_id == '9780133392838'