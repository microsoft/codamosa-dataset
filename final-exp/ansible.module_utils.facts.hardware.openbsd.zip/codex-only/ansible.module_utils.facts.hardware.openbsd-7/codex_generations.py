

# Generated at 2022-06-22 23:25:07.939007
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    class OpenBSDHardwareMock(OpenBSDHardware):
        """Mocked OpenBSDHardware class"""
        def __init__(self, module):
            self.sysctl = {'hw.usermem': 1048576000}

        @timeout.timeout()
        def get_mount_facts(self):
            pass

        def run_command(self, command):
            return (
                0,
                """
procs    memory       page                    disks    traps          cpu
r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id
0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99
""",
                ''
            )

    module_mock = type

# Generated at 2022-06-22 23:25:10.024589
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    o = OpenBSDHardware()
    assert o.platform == 'OpenBSD'

# Generated at 2022-06-22 23:25:20.016979
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    testmodule = type('module', (object,), {
        'run_command': lambda *args, **kwargs: (0, '8\n', ''),
        'get_bin_path': lambda *args: '/bin/sysctl',
    })
    testmodule.sysctl = {}
    testmodule.sysctl['hw.ncpuonline'] = '4'
    testmodule.sysctl['hw.model'] = 'Intel(R) Core(TM) i7-3517U CPU @ 1.90GHz'
    hardware = OpenBSDHardware(module=testmodule)


# Generated at 2022-06-22 23:25:32.477216
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    m_module = MockModule()
    m_module.run_command = Mock(return_value=(0, '', ''))

    m_OpenBSDHardware = OpenBSDHardware(m_module)
    m_OpenBSDHardware.sysctl = {
        'hw.product': 'MacBookPro9,1',
        'hw.version': '1.0',
        'hw.uuid': 'A8AD839C-9D58-52BC-9B61-0F7F82E73E28',
        'hw.serialno': 'C02F0F6PJG0J',
        'hw.vendor': 'Apple Inc.',
    }


# Generated at 2022-06-22 23:25:34.744572
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, '1449902471', ''))

    hardware = OpenBSDHardware(module)
    uptime = hardware.get_uptime_facts()

    assert uptime['uptime_seconds'] == int(time.time()) - 1449902471

# Generated at 2022-06-22 23:25:39.616346
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    """Test popularity of given package"""
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = get_sysctl(module, ['hw'])
    return hardware.get_processor_facts() == {'processor': [u'Intel(R) Xeon(R) CPU E3-1220 V2 @ 3.10GHz'], 'processor_count': u'2', 'processor_cores': u'2'}


# Generated at 2022-06-22 23:25:45.196145
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware_facts = OpenBSDHardware(module).get_memory_facts()
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0


# Generated at 2022-06-22 23:25:54.455012
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import timeout
    import platform
    import pytest

    hardware = OpenBSDHardware()

    hardware.sysctl = {
        'hw.product': 'my_product_name',
        'hw.version': 'my_product_version',
        'hw.uuid': 'my_product_uuid',
        'hw.serialno': 'my_product_serial',
        'hw.vendor': 'my_system_vendor',
    }

    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['product_name'] == 'my_product_name'
    assert dmi_facts['product_version'] == 'my_product_version'
    assert dmi_facts['product_uuid']

# Generated at 2022-06-22 23:25:58.578104
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    openbsd = OpenBSDHardware(dict(ANSIBLE_MODULE_ARGS={}))
    assert openbsd is not None

# Generated at 2022-06-22 23:26:08.499927
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = FakeAnsibleModule()

    hardware = OpenBSDHardware(module)
    # test product_name facts
    hardware.sysctl['hw.product'] = 'MyProduct'
    assert hardware.get_dmi_facts() == {'product_name': 'MyProduct'}
    # test product_version facts
    hardware.sysctl['hw.version'] = 'MyVersion'
    assert hardware.get_dmi_facts() == {'product_name': 'MyProduct',
                                        'product_version': 'MyVersion'}
    # test product_uuid facts
    hardware.sysctl['hw.uuid'] = 'MyUUID'

# Generated at 2022-06-22 23:26:14.298351
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = MockModule()
    OpenBSDHardware.sysctl = {'hw.disknames': 'sd0'}
    facts = OpenBSDHardware(module)
    assert facts.get_device_facts() == {'devices': ['sd0']}

# Unit tests for method get_dmi_facts of class OpenBSDHardware

# Generated at 2022-06-22 23:26:22.585303
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeCommand

    hardware_obj = OpenBSDHardware(module)
    hardware_obj.sysctl = {'hw.usermem': '134217728'}

    hardware_obj.get_memory_facts()
    assert hardware_obj.facts['memfree_mb'] == 27
    assert hardware_obj.facts['memtotal_mb'] == 128
    assert hardware_obj.facts['swapfree_mb'] == 997
    assert hardware_obj.facts['swaptotal_mb'] == 1000



# Generated at 2022-06-22 23:26:27.358762
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    raw_facts = {'hw.disknames': 'sd0 sd1'}
    ah = OpenBSDHardware(dict(), raw_facts)
    expected = {'devices': ['sd0', 'sd1']}
    ah.sysctl = raw_facts
    assert ah.get_device_facts() == expected


# Generated at 2022-06-22 23:26:28.122974
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd = OpenBSDHardwareCollector()
    assert openbsd.platform == 'OpenBSD'

# Generated at 2022-06-22 23:26:32.926753
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_instance = OpenBSDHardware(module)
    facts = hardware_instance.populate()
    assert facts['uptime_seconds'] >= 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['processor_cores'] >= 1
    assert facts['processor_count'] >= 1
    assert facts['processor_speed'] >= 0

# Generated at 2022-06-22 23:26:44.609575
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = OpenBSDHardware(module)

    # Replace the module's run_command method with one that returns a canned
    # response
    def run_command(command, check_rc=True):
        return (0, """kern.boottime: { sec = 1514785955, usec = 748949 }	{ /* this is a comment */ Wed Jan  3 11:05:55 2018 } """, None)

    hardware.module.run_command = run_command
    hardware.populate()

    assert hardware.uptime_seconds == 17072


# unit test for method get_mount_facts of class OpenBSDHardware

# Generated at 2022-06-22 23:26:47.016077
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    hardware = OpenBSDHardware()
    assert hardware


# Generated at 2022-06-22 23:26:56.699880
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    from unittest import mock

    module_mock = mock.MagicMock()
    module_mock.run_command.return_value = (0, '', '')

    class MockOpenBSDHardware:
        def __init__(self):
            self.module = module_mock

    hardware_collector = MockOpenBSDHardware()
    hardware_collector.get_mount_facts = mock.MagicMock(return_value={})
    hardware_collector.get_dmi_facts = mock.MagicMock(return_value={})
    hardware_collector.get_processor_facts = mock.MagicMock(return_value={})
    hardware_collector.get_memory_facts = mock.MagicMock(return_value={})

# Generated at 2022-06-22 23:26:58.208817
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    h = OpenBSDHardware({})
    assert h.platform == 'OpenBSD'

# Generated at 2022-06-22 23:27:01.793991
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    """Unit test for constructor of class OpenBSDHardwareCollector"""

    assert OpenBSDHardwareCollector._platform == 'OpenBSD'
    assert OpenBSDHardwareCollector._fact_class == OpenBSDHardware

# Generated at 2022-06-22 23:27:11.840965
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module=module)
    collected_facts = hardware.populate()

# Generated at 2022-06-22 23:27:19.281944
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "foo,bar", None)
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {
        'hw.disknames': 'foo,bar',
    }

    assert hardware.get_device_facts() == {'devices': ['foo', 'bar']}

# Generated at 2022-06-22 23:27:29.539151
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = FakeModule()
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i5-7500 CPU @ 3.40GHz',
                       'hw.ncpu': '2'}
    result = hardware.get_processor_facts()
    assert result == {'processor': ['Intel(R) Core(TM) i5-7500 CPU @ 3.40GHz',
                                    'Intel(R) Core(TM) i5-7500 CPU @ 3.40GHz'],
                      'processor_count': '2', 'processor_cores': '2'}


# Generated at 2022-06-22 23:27:31.301831
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    module = AnsibleModule({})
    hardware = OpenBSDHardware(module)
    assert hardware


# Generated at 2022-06-22 23:27:38.178319
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    """Test function for OpenBSDHardware.get_uptime_facts()."""
    kern_boottime = 100
    m0 = {'get_bin_path._ansible_no_log': True,
          'run_command._ansible_no_log': True}
    m1 = {'run_command.return_value': (0, kern_boottime, '')}
    m = dict(m0, **m1)

    # Expected result.
    r_expected = {'uptime_seconds': int(time.time()) - kern_boottime}

    # Run test.
    h = OpenBSDHardware()
    h.module = mock_module_helper(m)
    r = h.get_uptime_facts()
    assert r == r_expected

# Generated at 2022-06-22 23:27:49.968633
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    class Module():
        def __init__(self, sysctl):
            self.sysctl = sysctl

        def run_command(self, command):
            return 0, '', ''

        def get_bin_path(self, bin):
            return bin

    class Facts():
        def __init__(self):
            self.collector = 'generic'

    module = Module(sysctl={
        'hw.product': 'OpenBSD',
        'hw.version': '6.2',
        'hw.uuid': 'e3d1c4f1-f31c-4b04-ae20-55b24615506a',
        'hw.serialno': '000',
        'hw.vendor': 'OpenBSD Foundation'})
    facts = Facts()
    hardware_facts = OpenBSDHardware(module, facts)



# Generated at 2022-06-22 23:28:00.411221
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    hardware = OpenBSDHardware({'module': object()})
    sysctl = {
        'hw.product': 'APPRO',
        'hw.version': '1.0',
        'hw.uuid': '00000000-0000-0000-0000-000000000000',
        'hw.serialno': '0123456789abcdef',
        'hw.vendor': 'ACME',
    }
    hardware._get_sysctl = lambda: sysctl

    assert hardware._get_dmi_facts() == {
        'product_name': 'APPRO',
        'product_version': '1.0',
        'product_uuid': '00000000-0000-0000-0000-000000000000',
        'product_serial': '0123456789abcdef',
        'system_vendor': 'ACME',
    }

# Generated at 2022-06-22 23:28:08.477677
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    '''Unit test to test constructor of class OpenBSDHardwareCollector'''
    obj = OpenBSDHardwareCollector('test_module')
    assert isinstance(obj, OpenBSDHardwareCollector)
    assert isinstance(obj._platform, str)
    assert isinstance(obj._fact_class, OpenBSDHardware)
    assert obj.platform == 'OpenBSD'
    assert obj.collect() == dict()

# Generated at 2022-06-22 23:28:18.817992
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    # Test with a good value
    sysctl_path = '/usr/bin/sysctl'
    sysctl_command = [sysctl_path, "-n", 'hw.disknames']

    m = OpenBSDHardware()
    m.module = MagicMock()
    m.module.run_command.return_value = (0, 'sd0,sd1', '')
    m.sysctl = {'hw.disknames': 'sd0,sd1'}

    # Test with a good value
    assert m.get_device_facts() == {'devices': ['sd0', 'sd1']}

    # Test with a bad value
    m.sysctl = {}
    assert m.get_device_facts() == {}

# Generated at 2022-06-22 23:28:24.476628
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModuleMock({})
    facts = OpenBSDHardware(module)
    msg = facts.get_processor_facts()
    assert msg['processor'] is not None
    assert msg['processor_count'] is not None
    assert msg['processor_cores'] is not None


# Generated at 2022-06-22 23:28:26.052415
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    OpenBSDHardwareCollector()

# Generated at 2022-06-22 23:28:29.784754
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    mod_args = {}
    with_timeout_value = 1000
    mod = OpenBSDHardwareCollector(module=None, timeout=with_timeout_value)
    assert mod.timeout == with_timeout_value

# Generated at 2022-06-22 23:28:30.752728
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert OpenBSDHardwareCollector()

# Generated at 2022-06-22 23:28:38.807606
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    module = AnsibleModuleMock()
    module.run_command = Mock(return_value=(0, 'vmstat_out', ''))
    module.get_file_content = Mock(return_value='fstab_content')
    module.get_mount_size = Mock(return_value={})
    open_bsd_hw = OpenBSDHardware(module)

    assert 'OpenBSD' == open_bsd_hw.platform
    assert 'OpenBSD' == open_bsd_hw.sys_vendor
    assert {} == open_bsd_hw.facts
    assert {} == open_bsd_hw.sysctl


# Generated at 2022-06-22 23:28:43.661265
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    module.params['gather_subset'] = ["!all", "+processor"]
    hardware_object = OpenBSDHardware(module=module)
    expected_result = {
        'processor': ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'],
        'processor_count': '12',
        'processor_cores': '12',
    }
    hardware_object.get_processor_facts()
    assert expected_result == hardware_object.fact


# Generated at 2022-06-22 23:28:45.572686
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    hardware = OpenBSDHardware('/dev/null')


# Generated at 2022-06-22 23:28:58.367098
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={
        "gather_subset": dict(default=['all'], type='list'),
        "filter": dict(default="*", type='list')
    })

    result = OpenBSDHardware(module).populate()
    assert result["uptime_seconds"] > 0
    assert result["memtotal_mb"] > 0
    assert result["memfree_mb"] >= 0
    assert result["swaptotal_mb"] > 0
    assert result["swapfree_mb"] >= 0
    assert len(result["processor"]) == result["processor_count"]
    assert result["processor_cores"] >= 0
    assert result["processor_count"] > 0
    assert result["mounts"] != []
    assert result["devices"] != []
    assert result["system_vendor"] != ""

# Generated at 2022-06-22 23:29:08.184567
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    hw = OpenBSDHardware(dict(module=dict(run_command=lambda *a, **kw: (0, '', ''))))
    hw.sysctl = {
        'hw.product': 'My Laptop',
        'hw.version': 'v1.0',
        'hw.uuid': '00000000-0000-0000-0000-000000000000',
        'hw.serialno': 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',
        'hw.vendor': 'My Vendor',
    }
    dmi_facts = hw.get_dmi_facts()
    assert dmi_facts['product_name'] == 'My Laptop'
    assert dmi_facts['product_version'] == 'v1.0'

# Generated at 2022-06-22 23:29:19.566014
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    # Necessary to initialize the class correctly
    OpenBSDHardware.__init__ = lambda x: None
    OpenBSDHardware._module = lambda x: None
    OpenBSDHardware.sysctl = {'hw.product': 'product_name',
                              'hw.version': 'product_version',
                              'hw.uuid': 'product_uuid',
                              'hw.serialno': 'product_serial',
                              'hw.vendor': 'system_vendor'
                              }
    hardware = OpenBSDHardware()
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'product_name'
    assert dmi_facts['product_version'] == 'product_version'
    assert dmi_facts['product_uuid'] == 'product_uuid'
   

# Generated at 2022-06-22 23:29:30.035474
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class OpenBSDHardware
    """
    module = OpenBSDHardware()
    options = {'hw.usermem': 67108864, 'hw.physmem': 1073741824}
    module.sysctl = options

    # Get free memory
    rc, out, err = module.module.run_command("/usr/bin/vmstat")
    if rc == 0:
        options['memfree_mb'] = int(out.splitlines()[1].split()[4]) // 1024
        options['memtotal_mb'] = int(options['hw.usermem']) // 1024 // 1024

    # Get swapctl info
    rc, out, err = module.module.run_command("/sbin/swapctl -sk")

# Generated at 2022-06-22 23:29:33.588687
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = FakeModule()
    hardware = OpenBSDHardware(module)
    processor = hardware.get_processor_facts()['processor']
    assert processor == ['Intel(R) Celeron(R) CPU G3900 @ 2.80GHz']


# Generated at 2022-06-22 23:29:46.188254
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    import sys
    import unittest

    sys.path.append('/tmp')

    dummy_sysctl = {
        'hw.model': 'Genuine Intel(R) CPU @ 2.40GHz',
        'hw.ncpuonline': '2',
        'hw.disknames': '',
        'hw.usermem': '18253635584',
        'hw.product': 'C7H170-M',
        'hw.version': 'Version 0405',
        'hw.uuid': 'E6FAA940-64AF-11E7-B55C-A76A1D1F8C26',
        'hw.serialno': 'MS7C815909',
        'hw.vendor': 'ASUSTeK COMPUTER INC.'
    }


# Generated at 2022-06-22 23:29:47.140445
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    fact_class = OpenBSDHardwareCollector()
    assert fact_class.collect() is None

# Generated at 2022-06-22 23:29:49.549969
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hc = OpenBSDHardwareCollector()
    assert hc.platform == 'OpenBSD'


# Generated at 2022-06-22 23:29:50.655325
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    oh = OpenBSDHardware()
    assert oh.collect() is not None

# Generated at 2022-06-22 23:29:56.229535
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor'][0] == 'OpenBSD'
    assert hardware_facts['system_vendor'] == 'OpenBSD'
    assert hardware_facts['memtotal_mb'] == hardware_facts['memory_mb']['total']
    assert hardware_facts['memfree_mb'] == hardware_facts['memory_mb']['free']
    assert hardware_facts['swaptotal_mb'] == hardware_facts['memory_mb']['swaptotal']
    assert hardware_facts['swapfree_mb'] == hardware_facts['memory_mb']['swapfree']



# Generated at 2022-06-22 23:30:07.993961
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = type('os', (object,), {
        'run_command': lambda *args, **kwargs: (0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available\n', ''),
        'get_bin_path': lambda *args, **kwargs: '/usr/bin/sysctl'
    })()
    hardware = OpenBSDHardware(module)

    facts = hardware.populate()

    assert facts['swapfree_mb'] == 68
    assert facts['swaptotal_mb'] == 68
    assert facts['uptime_seconds'] == int(time.time())
    assert facts['devices'] == []
    assert facts['processor_count'] == 1
    assert facts['processor_cores'] == 1

# Generated at 2022-06-22 23:30:19.593256
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    facts = {
        'hw.product': 'Foo',
        'hw.vendor': 'Bar',
        'hw.version': '7.2',
        'hw.uuid': 'c589d742-4a4f-4b9e-9612-86e33c32e01f',
        'hw.serialno': '0123456789'
    }

    expected_facts = {
        'product_name': 'Foo',
        'product_version': '7.2',
        'product_uuid': 'c589d742-4a4f-4b9e-9612-86e33c32e01f',
        'product_serial': '0123456789',
        'system_vendor': 'Bar'
    }


# Generated at 2022-06-22 23:30:30.432160
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    facts_module = OpenBSDHardware()
    dmi_facts = facts_module.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'OpenBSD'
    assert dmi_facts['product_name'] == 'OpenBSD'
    assert dmi_facts['product_version'] == '5.8'
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert dmi_facts['product_serial'] == ' to Be Filled By O.E.M. '

# Generated at 2022-06-22 23:30:42.555316
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    hardware = OpenBSDHardware(module)
    hardware.populate()

    #
    # Test processor related facts
    #
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4850HQ CPU @ 2.30GHz']
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor_count'] == 1

    #
    # Test memory related facts
    #
    assert hardware.facts['memtotal_mb'] == 6573

    #
    # Test device related facts
    #
    assert 'em0' in hardware.facts['devices']
    assert 'memory' in hardware.facts['devices']

    #
    # Test dmi related facts
    #

# Generated at 2022-06-22 23:30:44.469485
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    test = OpenBSDHardware(dict())
    assert test.sysctl['hw.usermem']


# Generated at 2022-06-22 23:30:54.997796
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Create an instance of OpenBSDHardware class
    openbsd_facts = OpenBSDHardware()

    # Create an instance of the OpenBSDHardwareCollector class
    openbsd_collector = OpenBSDHardwareCollector()

    # Run the populate method of OpenBSDHardware class
    openbsd_facts.populate()

    # Create an instance of the OpenBSDHardware class with
    # the module_utils/facts/hardware/base.py and run the populate method
    # This is done to initialize the dictionary
    collected_facts = openbsd_collector.collect()
    new_openbsd_facts = OpenBSDHardware(collected_facts)
    new_openbsd_facts.populate()

    # Compare the results of the two instances
    assert openbsd_facts.all_facts == new_openbsd_facts.all_facts

# Generated at 2022-06-22 23:31:02.435992
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    def run_command(module, cmd):
        return (0, '1444444444', '')
    module = FakeModule(run_command=run_command)
    ohw = OpenBSDHardware(module)
    uptime_facts = ohw.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == int(time.time() - 1444444444)


# Generated at 2022-06-22 23:31:07.108622
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = FakeAnsibleModule()
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert isinstance(uptime_facts['uptime_seconds'], int)
    assert uptime_facts['uptime_seconds'] > 0


# Generated at 2022-06-22 23:31:11.771119
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    hardware = OpenBSDHardware(dict(module=None))
    hardware.sysctl = dict(hw=dict(disknames='sd0,sd1,sd2'))
    assert hardware.get_device_facts() == dict(devices=['sd0', 'sd1', 'sd2'])


# Generated at 2022-06-22 23:31:24.074247
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    """
    Unit test for method get_processor_facts of class OpenBSDHardware
    """

    def _fake_read_file(filename):
        sample_file = """
        hw.machine=amd64
        hw.model=Intel(R) Xeon(R) CPU E5-2620 0 @ 2.00GHz
        hw.ncpu=2
        hw.ncpuonline=2
        hw.byteorder=1234
        """

        if filename == '/dev/null':
            return ''
        else:
            return sample_file


# Generated at 2022-06-22 23:31:30.275312
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    from collections import namedtuple

    class FakeAnsibleModule:
        def __init__(self):
            self.sysctl = {}

        def get_bin_path(self, *args):
            return 'FAKE_BINARY'

        def run_command(self, cmd):
            return 0, 'OUT', 'ERR'

    class FakeAnsibleModuleFactory:
        def __call__(self, *args, **kwargs):
            self.module = FakeAnsibleModule()
            return self.module

    class FakeOpenBSDHardware(OpenBSDHardware):
        def __init__(self, module):
            self.module = module
            self.sysctl = {}
            self.hw_facts = {}


# Generated at 2022-06-22 23:31:32.795318
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():

    class FakeModule(object):
        def run_command(self, cmd):
            return 0, "4389.62", ""

        def get_bin_path(self, cmd, required=False, opt_dirs=[]):
            return cmd

    UP_TIME = time.time() - 4389.62
    hardware = OpenBSDHardware(FakeModule())
    assert hardware.get_uptime_facts()['uptime_seconds'] == UP_TIME

# Generated at 2022-06-22 23:31:34.215678
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    openbsd_hardware = OpenBSDHardware()



# Generated at 2022-06-22 23:31:46.770042
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    # Basic test
    test_class = OpenBSDHardware({'path': '/sbin:/usr/sbin'})
    test_class.sysctl = {'hw.model': 'Intel CORE i7', 'hw.ncpuonline': 4}
    assert test_class.get_processor_facts() == {
        'processor': ['Intel CORE i7', 'Intel CORE i7', 'Intel CORE i7', 'Intel CORE i7'],
        'processor_count': '4',
        'processor_cores': '4',
    }

    # Test with 1 CPU
    test_class = OpenBSDHardware({'path': '/sbin:/usr/sbin'})
    test_class.sysctl = {'hw.model': 'Intel CORE i7', 'hw.ncpuonline': 1}

# Generated at 2022-06-22 23:31:54.263513
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    MEMORY_FACT_CATEGORIES = ['memfree_mb', 'memtotal_mb', 'swapfree_mb', 'swaptotal_mb']
    cmd = '/usr/bin/vmstat; /sbin/swapctl -sk'
    rc = 0

# Generated at 2022-06-22 23:32:04.266333
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # Test the case of the method called with no 'uptime' fact
    fake_module = AnsibleFakeModule()
    fake_module.run_command = AnsibleFakeModule.run_command_fake

    hardware = OpenBSDHardware(fake_module)
    assert hardware.get_uptime_facts() == {}

    # Test the case of the method called with a filled uptime fact
    AnsibleFakeModule.set_command_response('sysctl -n kern.boottime', '1500000000')
    hardware = OpenBSDHardware(fake_module)
    assert hardware.get_uptime_facts() == {'uptime_seconds': 200}

    # Test the case of the method called with an empty uptime fact
    AnsibleFakeModule.set_command_response('sysctl -n kern.boottime', '')

# Generated at 2022-06-22 23:32:06.367396
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = None
    OpenBSDHardware.get_uptime_facts(module)

# Generated at 2022-06-22 23:32:12.461601
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    module = MagicMock()
    hw = OpenBSDHardware(module)
    hw.populate()
    assert hw.module == module
    assert hw.platform == 'OpenBSD'

    module.get_bin_path.assert_has_calls([
        call('sysctl'),
        call('vmstat'),
        call('swapctl')
    ])


# Generated at 2022-06-22 23:32:13.966703
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    hardware = OpenBSDHardware()
    assert hardware.populate()

# Generated at 2022-06-22 23:32:26.563803
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = type('test_module', (), {})
    setattr(module, 'run_command', fake_run_command)
    setattr(module.run_command, '__doc__', 'AnsibleModule.run_command() fake')
    setattr(module, 'get_bin_path', fake_get_bin_path)
    setattr(module, 'timeout', timeout)
    setattr(module, 'fail_json', fail_json)
    setattr(module, 'exit_json', exit_json)

    sysctl_hw = {}
    sysctl_hw['hw.ncpuonline'] = 4
    sysctl_hw['hw.model'] = 'Intel(R) Core(TM) i3-3120M CPU @ 2.50GHz'
    openbsd_hardware = OpenBSDHardware(module)
    open

# Generated at 2022-06-22 23:32:32.595705
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    hardware_facts = OpenBSDHardwareCollector.collect()
    assert len(hardware_facts['devices']) > 0
    assert re.fullmatch(r'OpenBSD.+', hardware_facts['os_version'])
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['product_vendor'] == 'OpenBSD'

# Generated at 2022-06-22 23:32:38.880360
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = DummyModule(params={})
    hardware = OpenBSDHardware(module)

    expected_results = {'processor': ['Intel(R) Xeon(R) CPU E5-2630 v4 @ 2.20GHz'],
                        'processor_count': "8",
                        'processor_cores': "8",
                        }
    results = hardware.get_processor_facts()
    assert results == expected_results


# Generated at 2022-06-22 23:32:44.185349
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    set_module_args(dict(gather_subset='!all,!min'))
    OpenBSDHardwareCollector.fetch_facts(module._name, module)
    collected_facts = module.exit_json['ansible_facts']
    hardware = collected_facts['ansible_hardware']

    assert 'memfree_mb' in hardware
    assert 'memtotal_mb' in hardware
    assert 'swapfree_mb' in hardware
    assert 'swaptotal_mb' in hardware
    assert 'mounts' not in hardware



# Generated at 2022-06-22 23:32:56.336143
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(command_definitions=dict(
            module_defaults=dict(
                executable=dict(type='path', default='/bin/true'),
            )
        ),
        argument_spec=dict(
            filter=dict(default=dict())
        ),
    )
    # Simulate an older openbsd version with a timestamp ending with a zero.
    setattr(module, 'run_command', mock_run_command(rc=0, out=b'entry(kern.boottime): 1480000000'))
    openbsd_hw = OpenBSDHardware(module)
    uptime_facts = openbsd_hw.get_uptime_facts()
    assert uptime_facts == {'uptime_seconds': 148}
    # Simulate a recent openbsd version with a timestamp ending with a nine.
   

# Generated at 2022-06-22 23:33:05.937730
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = MagicMock()
    sysctl = {
        'hw.ncpuonline': '1',
        'hw.model': 'amd64',
    }
    module.get_bin_path.return_value = '/sbin/sysctl'
    module.run_command.return_value = 0, 'hw.ncpuonline=1\nhw.model=amd64', ''
    openbsd_hardware = OpenBSDHardware(module)
    openbsd_hardware.sysctl = sysctl
    processor_facts = openbsd_hardware.get_processor_facts()
    assert processor_facts == {
        'processor_cores': '1',
        'processor': ['amd64'],
        'processor_count': '1'
    }

# Generated at 2022-06-22 23:33:08.249952
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    collector = OpenBSDHardwareCollector()
    assert collector.platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDHardware

# Generated at 2022-06-22 23:33:14.505626
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    module = AnsibleModuleMock({'gather_subset': ['all'],
                                'gather_timeout': 10})
    hw = OpenBSDHardware(module)
    assert hw.sysctl['hw.ncpuonline'] > 0
    assert hw.sysctl['hw.usermem'] > 0



# Generated at 2022-06-22 23:33:21.285412
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    hardware = OpenBSDHardware({'module_setup': True})
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,wd0'}
    devices = hardware.get_device_facts()['devices']
    assert devices == ['sd0', 'sd1', 'wd0'], \
        'Expected device name list to contain sd0,sd1,wd0, but got %s' % devices


# Generated at 2022-06-22 23:33:23.829729
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    hardware = OpenBSDHardware()
    # The constructor should always return an instance of OpenBSDHardware
    assert hardware is not None


# Generated at 2022-06-22 23:33:36.234325
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    hardware = OpenBSDHardware()
    assert hardware.get_up_devices() == []
    assert hardware.get_memory_facts() == dict(
        memfree_mb={},
        memtotal_mb={},
        swapfree_mb={},
        swaptotal_mb={},
        swapcached_mb={},
    )
    assert hardware.get_processor_facts() == dict(
        processor=[],
        processor_cores={},
        processor_count={},
        processor_speed={},
    )
    assert hardware.get_device_facts() == dict(devices=[])
    assert hardware.get_dmi_facts() == dict(
        product_name={},
        product_version={},
        product_uuid={},
        product_serial={},
        system_vendor={},
    )

# Generated at 2022-06-22 23:33:48.714336
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():  # pylint: disable=R0914
    module = MockModule()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/dmesg')

    module.file_exists = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value='freebsd11\n')

    module.sysctl = MagicMock()

# Generated at 2022-06-22 23:33:57.375837
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Initialize an module object
    module = AnsibleModule(argument_spec={})

    # Initialize a Hardware object
    hardware_obj = OpenBSDHardware(module)

    # Run method populate with pre-defined input and check if it fails or not
    hardware_obj.populate()

    # If no exception thrown, then test case was successful
    assert(hardware_obj.facts['uptime_seconds'] >= 0)


if __name__ == '__main__':
    from unit.ansible_module_utils import AnsibleModule
    from ansible.module_utils.facts import timeout
    timeout.DEFAULT_TIMEOUT = 1
    # Initialize an module object
    module = AnsibleModule(argument_spec={})

    # Initialize a Hardware object
    hardware_obj = OpenBSDHardware(module)

    # Run method populate with pre

# Generated at 2022-06-22 23:34:08.502919
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    """Test for method get_processor_facts of class OpenBSDHardware"""
    mem_facts = OpenBSDHardware({}, {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'})
    cpu_facts = mem_facts.get_processor_facts()
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2


# Generated at 2022-06-22 23:34:18.250570
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    class SysctlModule:
        def __init__(self):
            self.sysctl = {
                'hw.model': 'Intel(R) Xeon(R) CPU E5-2620 v3 @ 2.40GHz',
                'hw.ncpuonline': 32
            }

    class Module:
        def __init__(self):
            self.sysctl_module = SysctlModule()

        def get_bin_path(self, *args, **kwargs):
            pass

        def run_command(self, args, **kwargs):
            return 0, '', ''

        def fail_json(self, **kwargs):
            pass

        @property
        def sysctl(self):
            return self.sysctl_module.sysctl

    cpu_facts = OpenBSDHardware(Module()).get_processor_facts()


# Generated at 2022-06-22 23:34:29.983188
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    facts_mock = {
        'hw.product': 'MyProduct',
        'hw.version': '1.0',
        'hw.uuid': '00000000-0000-0000-0000-000000000000',
        'hw.serialno': 'MySerial',
        'hw.vendor': 'MyVendor',
    }

    h = OpenBSDHardware({}, [{}], [], facts_mock)
    dmi_facts = h.get_dmi_facts()

    assert 'product_name' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'system_vendor' in dmi_facts

    assert dmi_facts['product_name'] == 'MyProduct'


# Generated at 2022-06-22 23:34:42.044038
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    import sys
    if sys.version_info[0] >= 3:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware

    module = MagicMock()
    hardware = OpenBSDHardware(module)

    module.run_command.return_value = (0, '1538715879', '')
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1538715879)

    module.run_command.return_value = (1, '', '')
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts == {}


# Generated at 2022-06-22 23:34:50.567638
# Unit test for method populate of class OpenBSDHardware

# Generated at 2022-06-22 23:35:01.146974
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    openbsd_hw = OpenBSDHardware(module=module)
    openbsd_hw.sysctl = {'hw.disknames': 'wd0,wd1,sd0,sd1'}
    device_facts = openbsd_hw.get_device_facts()

    assert 'devices' in device_facts
    assert device_facts['devices'] == ['wd0', 'wd1', 'sd0', 'sd1']
