

# Generated at 2022-06-22 23:25:04.236204
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    """
    Unit test to test constructor of class OpenBSDHardware
    """
    openbsd_hardware_obj = OpenBSDHardware()

    assert openbsd_hardware_obj._platform == 'OpenBSD'
    assert isinstance(openbsd_hardware_obj, Hardware)


# Generated at 2022-06-22 23:25:16.827279
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_file_content = MagicMock(return_value='')
    module.get_bin_path = MagicMock(return_value='/bin/sysctl')
    openbsd_hw = OpenBSDHardware(module)


# Generated at 2022-06-22 23:25:24.327389
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Create a class instance of OpenBSDHardware
    hardware_obj = OpenBSDHardware()

    # Create an empty dictionary. This will be used to collect the results
    collected_facts = {}

    # Call method populate on that class instance
    hardware_obj.populate(collected_facts)

    # All the results collected by the populate method should be present in the
    # dict collected_facts
    assert collected_facts['processor']
    assert collected_facts['processor_cores']
    assert collected_facts['processor_count']
    assert collected_facts['memtotal_mb']
    assert collected_facts['memfree_mb']
    assert collected_facts['swaptotal_mb']
    assert collected_facts['swapfree_mb']
    assert collected_facts['system_vendor']
    assert collected_facts['product_name']
    assert collected

# Generated at 2022-06-22 23:25:35.078193
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    # Creating a OpenBSDHardware object
    test_OpenBSDHardware = OpenBSDHardware()

    # Opening a file containing OpenBSD systemctl data
    with open('./unit/ansible_collections/ansible/community/tests/unit/module_utils/facts/files/OpenBSD_systemctl_data.txt') as f:
        test_OpenBSDHardware.sysctl = f.read()

    # Calling get_dmi_facts to parse OpenBSD systemctl data
    OpenBSD_get_dmi_facts = test_OpenBSDHardware.get_dmi_facts()

    assert OpenBSD_get_dmi_facts['system_vendor'] == 'vendor'
    assert OpenBSD_get_dmi_facts['product_name'] == 'OpenBSD'

# Generated at 2022-06-22 23:25:47.720178
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    hardware = OpenBSDHardware(module)

    # Case 1: success, kern.boottime is set
    setattr(module, 'run_command', lambda *args: (0, '1560390601', ''))
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1560390601)

    # Case 2: success, kern.boottime is set to zero
    setattr(module, 'run_command', lambda *args: (0, '0', ''))
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time())

    # Case 3: kern.boottime is not set
    set

# Generated at 2022-06-22 23:25:53.786869
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    """
    Unit test to validate method get_memory_facts of class OpenBSDHardware

    :return:
    """
    module = MockModule()
    hardware = OpenBSDHardware(module)
    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memfree_mb'] == 10
    assert memory_facts['memtotal_mb'] == 20
    assert memory_facts['swapfree_mb'] == 10
    assert memory_facts['swaptotal_mb'] == 20



# Generated at 2022-06-22 23:26:06.080306
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = FakeAnsibleModule()
    sysctl_cmd = module.get_bin_path('sysctl')
    mock_sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz'}

    def mock_get_sysctl(module, *_, **__):
        return mock_sysctl

    cpu_facts = OpenBSDHardware(module).get_processor_facts()
    assert cpu_facts['processor'] == ['Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz',
                                      'Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz']
    assert cpu_facts['processor_count'] == 2

# Generated at 2022-06-22 23:26:18.821672
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    """
    Method populate of class OpenBSDHardware does return a dictionary containing
    a common set of hardware facts.

    Method is executed in the context of the following mock environment:
    - function get_file_content returns the content of the file if the file
      exists and None if the file does not exist
    - function run_command returns the commands output if command is valid and
      None if command is invalid
    - function get_mount_size returns a dictionary containing the size of the
      filesystem if the path exists and None if the path does not exist

    :returns: dictionary containing common set of hardware facts
    :rtype: dict
    """
    module = AnsibleModuleMock()

    # mock method get_file_content
    module.get_file_content.side_effect = get_file_content_mock
    # mock method run_command
    module

# Generated at 2022-06-22 23:26:26.960266
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    openbsd_hardware_ins = OpenBSDHardware(module)
    cpu_info = openbsd_hardware_ins.get_processor_facts()
    # Assert that the cpu_info contains the processor_count and processor_cores
    assert cpu_info['processor_count'] == '2'
    assert cpu_info['processor_cores'] == '2'



# Generated at 2022-06-22 23:26:33.624629
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    m = OpenBSDHardware({})
    d = {'hw.usermem': '134217728'}
    m.sysctl = d

    m.module.run_command = lambda *args, **kwargs: (0, 'procs    memory       page                    disks    traps          cpu\n 0 0 0  47512 28160 51 0 0 0 0 0 1 0 116 89 17 0 1 99\n', '')

    memory_facts = m.get_memory_facts()
    assert memory_facts['memfree_mb'] == 26
    assert memory_facts['memtotal_mb'] == 128

    m.module.run_command = lambda *args, **kwargs: (0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available\n', '')

    memory_facts = m.get_memory_facts()

# Generated at 2022-06-22 23:26:44.530280
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    result = {}
    result['uptime_seconds'] = 100

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    class MockOpenBSDHardware(OpenBSDHardware):
        def __init__(self):
            super(OpenBSDHardware, self).__init__()
            self.module = module

        def get_sysctl(self, mib):
            return {'kern.boottime': str(int(time.time()) - result['uptime_seconds'])}

    m = MockOpenBSDHardware()

    assert m.get_uptime_facts() == result



# Generated at 2022-06-22 23:26:56.193299
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    test_module = type('test_module', (object,), {'run_command': lambda x: (0, None, None)})
    test_class = OpenBSDHardware(module=test_module)

    test_class.sysctl = {'hw.model': 'Intel(R) Core(TM) i7-7500U CPU @ 2.70GHz',
                         'hw.ncpuonline': '4'}
    actual_processor_facts = test_class.get_processor_facts()

    assert actual_processor_facts['processor_count'] == '4'
    assert actual_processor_facts['processor_cores'] == '4'
    assert actual_processor_facts['processor'][0] == 'Intel(R) Core(TM) i7-7500U CPU @ 2.70GHz'

# Generated at 2022-06-22 23:27:08.514075
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    class MockModule(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

        def run_command(self, cmd, check_rc=True, close_fds=False):
            if cmd.endswith('hw.ncpuonline'):
                return 0, '3', ''
            elif cmd.endswith('hw.model'):
                return 0, 'Intel(R) Core(TM) i3 CPU M 380  @ 2.53GHz', ''
            else:
                return 0, '', ''

    dmesg = open('test_OpenBSDHardware_get_processor_facts.dmesg', 'r')

# Generated at 2022-06-22 23:27:11.907021
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware = OpenBSDHardwareCollector()
    assert openbsd_hardware._platform == 'OpenBSD'

# Generated at 2022-06-22 23:27:19.338542
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    openbsd_hardware = OpenBSDHardware(module)

    dmi_facts = openbsd_hardware.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'OpenBSD'
    assert dmi_facts['product_name'] == 'OpenBSD'

# Generated at 2022-06-22 23:27:23.155299
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector.openbsd import OpenBSDHardware
    module = OpenBSDHardware({})
    uptime_facts = module.get_uptime_facts()

    assert 'uptime_seconds' in uptime_facts

# Generated at 2022-06-22 23:27:34.128647
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = MockModule()
    # Mock sysctl output
    sysctl = {
        'hw.model': 'Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz',
        'hw.ncpuonline': '8',
    }
    module.get_bin_path.side_effect = lambda _: '/sbin/sysctl'

    hardware = OpenBSDHardware(module)
    hardware.sysctl = sysctl

    cpu_facts = hardware.get_processor_facts()

    module.run_command.assert_not_called()
    assert len(cpu_facts) == 4
    assert cpu_facts['processor'] == sysctl['hw.model'] * int(sysctl['hw.ncpuonline'])
    assert cpu_facts['processor_count'] == sysctl['hw.ncpuonline']

# Generated at 2022-06-22 23:27:41.180039
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    result = dict(
        changed=False,
        devices=["wd0", "wd1", "wd2"]
    )

    instance = OpenBSDHardware(module)
    instance.sysctl = {
        'hw.disknames': "wd0,wd1,wd2"
    }

    assert instance.get_device_facts() == result

# Generated at 2022-06-22 23:27:52.209210
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    """ Verifying the output of get_uptime_facts method """

    # Defining all necessary inputs to get_uptime_facts
    module = AnsibleModule(argument_spec=dict())
    # Defining a fake uptime for testing purposes
    fake_sysctl = dict()
    fake_sysctl['kern.boottime'] = int(time.time() - 86400)
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value='/usr/bin/sysctl')
    # Defining a fake uptime output for testing purposes
    sysctl_kern_boottime = """{ "kern.boottime": { "seconds": 1530725231, "microseconds": 0 } }\n"""

# Generated at 2022-06-22 23:27:57.781530
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
  module_mock = Mock()
  openbsd_hw_col = OpenBSDHardwareCollector(module_mock)

  # Test all the class variables
  assert openbsd_hw_col._fact_class == OpenBSDHardware
  assert openbsd_hw_col._platform == 'OpenBSD'
  assert openbsd_hw_col._collector_class == 'OpenBSDHardwareCollector'

# Generated at 2022-06-22 23:28:03.081151
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    from ansible.module_utils import basic

    M_STATS = """
  procs    memory       page                    disks    traps          cpu
  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id
  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99
"""
    S_STATS = """
total: 69268 1K-blocks allocated, 0 used, 69268 available
"""
    m = basic.AnsibleModule(
        argument_spec={},
    )

    m.run_command = lambda *args, **kwargs: (0, M_STATS, '')

# Generated at 2022-06-22 23:28:08.690010
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    obj = OpenBSDHardware(None)
    obj.module.run_command = lambda x: (0, "1597993600", "")
    obj.get_uptime_facts() == {'uptime_seconds': 1597993600}

# Generated at 2022-06-22 23:28:20.903828
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = MockModule()
    hardware = OpenBSDHardware(module)

    module.run_command.return_value = (0, """    procs    memory       page                    disks    traps          cpu
    r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id
    0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99""", '')
    hardware.sysctl = {"hw.usermem": "1073741824"}
    facts = hardware.get_memory_facts()
    assert facts['memfree_mb'] == 27
    assert facts['memtotal_mb'] == 1024


# Generated at 2022-06-22 23:28:26.375702
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    m = OpenBSDHardware(dict(), None)
    d = {'hw.disknames': 'wd0,wd1,cd0,cd1,vk0'}
    m.sysctl = d
    r = m.get_device_facts()
    assert r['devices'] == d['hw.disknames'].split(',')


# Generated at 2022-06-22 23:28:31.741041
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware_facts = OpenBSDHardware(module)
    sysctl = get_sysctl(module, ['hw'])
    devices = []
    devices.extend(sysctl['hw.disknames'].split(','))
    result = OpenBSDHardware._get_device_facts({})
    assert result['devices'] == devices


# Generated at 2022-06-22 23:28:41.145828
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import StringIO

    dmesg = get_file_content('/var/run/dmesg.boot')

    for line in dmesg.splitlines():
        if line.startswith('wd0 at'):
            wd0 = line.split()[0]
            break
    else:
        raise Exception('Test fails: could not find a disk device in dmesg.boot')

    # We need to mock the sysctl(8) command to provide controlled output.
    # Create a fake sysctl command that returns the output of hw.disknames.


# Generated at 2022-06-22 23:28:53.234411
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = FakeModule({})
    obj = OpenBSDHardware(module)
    dmi_facts = obj.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'OpenBSD', dmi_facts['system_vendor']
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000', dmi_facts['product_uuid']
    assert dmi_facts['product_version'] == 'OpenBSD', dmi_facts['product_version']
    assert dmi_facts['product_name'] == 'OpenBSD', dmi_facts['product_name']
    assert dmi_facts['product_serial'] == '', dmi_facts['product_serial']



# Generated at 2022-06-22 23:29:00.600174
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(
        argument_spec={
            "gather_subset": dict(type='list', required=False,
                                  choices=['all', 'min']),
            "filter": dict(required=False, default=None)
        },
        supports_check_mode=False
    )
    harware = OpenBSDHardware(module)
    raw_facts = harware.populate()
    assert raw_facts['uptime_seconds'] > 0



# Generated at 2022-06-22 23:29:04.598816
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    """
    Test OpenBSDHardware.populate
    """
    collected_facts = {}
    hardware = OpenBSDHardware(module=None)
    hardware.populate(collected_facts)
    assert hardware.populate() == collected_facts



# Generated at 2022-06-22 23:29:11.914518
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    hardware = OpenBSDHardware()
    hardware.module = MockModule()
    hardware.module.run_command.return_value = [0, "sd0 sd1 sd2 sd3 sd4 sd5 sd6 sd7 wd0", ""]

    dev_facts = hardware.get_device_facts()

    assert dev_facts['devices'] == ["sd0", "sd1", "sd2", "sd3", "sd4", "sd5", "sd6", "sd7", "wd0"]


# Generated at 2022-06-22 23:29:13.428646
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    o = OpenBSDHardware({})
    assert o.module is not None


# Generated at 2022-06-22 23:29:17.521135
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    testobj = OpenBSDHardware(dict(), dict())
    testobj.sysctl = {'hw.disknames': 'sd0,sd1'}
    assert testobj.get_device_facts() == {'devices': ['sd0', 'sd1']}


# Generated at 2022-06-22 23:29:29.957694
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = MockModule()
    hardware = OpenBSDHardware(module)
    hardware.populate()
    assert hardware.memory['memfree_mb'] == 15995
    assert hardware.memory['memtotal_mb'] == 16319
    assert hardware.memory['swapfree_mb'] == 800
    assert hardware.memory['swaptotal_mb'] == 817
    assert hardware.cpu['processor'] == ['Intel(R) Core(TM)2 Duo CPU     E8500  @ 3.16GHz']
    assert hardware.cpu['processor_cores'] == 2
    assert hardware.cpu['processor_count'] == 2
    for dev in hardware.devices:
        assert dev in ['acd0', 'acd1', 'acd2', 'cd0', 'vnd0', 'vnd1', 'vnd2']
    assert hardware.dmi

# Generated at 2022-06-22 23:29:38.585975
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
   module = FakeModule()
   expected_values = {'product_uuid': '0d07a5f8-2883-bd0a-a5f5-5e8b99a96f6c',
                      'system_vendor': 'iXsystems',
                      'product_name': 'TS-1635AX',
                      'product_version': '3.29',
                      'product_serial': '0011e4000001'}

   sysctl_cmd = module.get_bin_path('sysctl')
   rc, out, err = module.run_command([sysctl_cmd, '-a'])

   if rc != 0:
       assert False

   OpenBSDHardware.sysctl = {}
   for line in out.splitlines():
       fields = line.split(':', 1)

# Generated at 2022-06-22 23:29:51.189995
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    facts_dict = {'hw_ncpu': '2', 'hw_model': 'Intel(R) Core(TM) i7-3682QM CPU @ 2.20GHz'}
    fake_module = type("AnsibleModule", (), {})()
    fake_module.run_command = lambda x: (0, "", "")
    fake_module.get_bin_path = lambda x: x
    ohw = OpenBSDHardware(fake_module, facts_dict)
    processor_facts = ohw.get_processor_facts()

# Generated at 2022-06-22 23:30:04.605399
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    from ansible.module_utils.facts.collector.openbsd import OpenBSDHardware
    from ansible.module_utils.facts.sysctl import get_sysctl
    mock_module = MockModule({
        'grep': '',
        'dmesg': '',
        'hw.ncpuonline': 2,
        'hw.model': 'foo',
    })
    mock_module.run_command = Mock()

    openbsd_hardware = OpenBSDHardware(mock_module)
    openbsd_hardware.sysctl = get_sysctl(mock_module, ['hw', 'hw.ncpuonline'])

    processor_facts = openbsd_hardware.get_processor_facts()
    assert processor_facts['processor_count'] == 2
    assert processor_facts['processor_cores'] == 2

# Generated at 2022-06-22 23:30:17.159264
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModuleMock()
    hardware = OpenBSDHardware()
    hardware.sysctl = {'hw.ncpuonline': 3, 'hw.model': 'Intel(R) Core(TM) i5-4690 CPU @ 3.50GHz'}

    result = hardware.get_processor_facts()

    expected_result = {'processor': ['Intel(R) Core(TM) i5-4690 CPU @ 3.50GHz', 'Intel(R) Core(TM) i5-4690 CPU @ 3.50GHz', 'Intel(R) Core(TM) i5-4690 CPU @ 3.50GHz'],
                       'processor_count': 3,
                       'processor_cores': 3,
                       'processor_speed': None}

# Generated at 2022-06-22 23:30:24.058599
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # Fixtures
    mem_output = ('  procs    memory       page                    disks    traps          cpu\n'
                  '   r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n'
                  '   0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n')
    hw_usermem = '8392037376'
    # Mock run_command
    m_run_command = mocker.patch.object(OpenBSDHardware, 'run_command')
    m_run_command.return_value = (0, mem_output, '')
    # Mock get_sysctl
    m_get_sysctl = mocker

# Generated at 2022-06-22 23:30:30.849486
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardwareCollector(module=module).collect()[0]
    result = hardware.get_processor_facts()
    assert(result['processor'] == ['Genuine Intel(R) CPU U7300 @ 1.30GHz'])
    assert(result['processor_cores'] == '2')
    assert(result['processor_count'] == '2')

# Generated at 2022-06-22 23:30:37.744952
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = FakeAnsibleModule()
    openbsd_hardware = OpenBSDHardware(module)

    rc, out, err = module.run_command("/usr/bin/vmstat")
    openbsd_hardware.sysctl = {'hw.usermem': int(out.splitlines()[-1].split()[4])*1024*1024}
    rc, out, err = module.run_command("/sbin/swapctl -sk")
    swaptrans = {ord(u'k'): None,
                 ord(u'm'): None,
                 ord(u'g'): None}
    data = to_text(out, errors='surrogate_or_strict').split()

# Generated at 2022-06-22 23:30:43.948832
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    module = MockModule()
    hardware = OpenBSDHardware(module)
    module.run_command.return_value = (0, '1529991199', '')

    result = hardware.get_uptime_facts()
    assert result['uptime_seconds'] == 2821


# Generated at 2022-06-22 23:30:54.617304
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    mock_module = MockOpenBSDModule()
    hardware_collector = OpenBSDHardwareCollector(mock_module)
    hardware_collector.populate()
    facts = hardware_collector.get_facts()
    assert facts['sysctl']['hw.uuid'] == 'MOCK_HW_UUID'
    assert facts['sysctl']['hw.ncpuonline'] == '2'
    assert facts['products'][0]['product_name'] == 'MOCK_HW_PRODUCT'
    assert facts['products'][0]['product_serial'] == 'MOCK_HW_SERIAL'
    assert facts['products'][0]['product_version'] == 'MOCK_HW_VERSION'

# Generated at 2022-06-22 23:31:04.349202
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # Input data
    module = type('DummyModule', (object,), {'run_command': lambda *_: (0, '', '')})
    sysctl = {'hw.usermem': '4742048', 'hw.ncpuonline': '1'}

    # Expected output
    result = {'memfree_mb': 28, 'memtotal_mb': 461}

    # Test
    hw = OpenBSDHardware(module)
    hw.sysctl = sysctl
    result_test = hw.get_memory_facts()
    assert result == result_test

# Generated at 2022-06-22 23:31:08.040675
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, '1719.62', ''))
    obj = OpenBSDHardware(module)
    fact = obj.get_uptime_facts()
    assert fact == {'uptime_seconds': 1719}

# Generated at 2022-06-22 23:31:15.052677
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # Test assumptions
    time_now = time.time()
    time_start = time_now - 10
    expected_uptime = 10

    # Mock module
    module = type('OpenBSDHardwareMock', (object,), {
        'run_command': lambda self, arg: (0, str(time_start), ''),
        'get_bin_path': lambda self, arg: arg,
    })

    # Mock module an instance
    openbsd_module_instance = module()

    # Create OpenBSDHardware instance
    openbsd_hw_instance = OpenBSDHardware(module=openbsd_module_instance)

    # Assert that we get the expected uptime
    assert openbsd_hw_instance.get_uptime_facts() == { 'uptime_seconds': expected_uptime }

# Generated at 2022-06-22 23:31:25.743386
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    oh = OpenBSDHardware()
    oh.sysctl = {
        'hw.product': 'OpenBSD',
        'hw.version': 'generic',
        'hw.uuid': '7a9b4a4e-4b4b-4b4b-4b4b-7a9b4a4e4b4b',
        'hw.serialno': '4b4b4b4b4b4b4b4b4b4b4b4b4b4b4b4b4b4b4b',
        'hw.vendor': 'OpenBSD Foundation',
    }
    obsd_dmi_facts = oh.get_dmi_facts()

    assert obsd_dmi_facts['system_vendor'] == 'OpenBSD Foundation'
    assert 'system_manufacturer' not in obs

# Generated at 2022-06-22 23:31:28.819942
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    o = OpenBSDHardwareCollector()
    assert o.platform == 'OpenBSD'
    assert o.fact_class == OpenBSDHardware

# Generated at 2022-06-22 23:31:37.045047
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module_mock = AnsibleModuleMock()
    module_mock.run_command = Mock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\n 0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))

    hw = OpenBSDHardware(module_mock)
    memory_facts = hw.get_memory_facts()

    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 47512 // 1024


# Generated at 2022-06-22 23:31:48.646961
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = type('test_OpenBSDHardware_get_dmi_facts', (object,),
            {
                'run_command': lambda self, cmd, check_rc=True: (0, '', ''),
                'get_bin_path': lambda self, name, opt_dirs=[] : '/sbin/sysctl',
                'params': {}
            })()
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.product': 'test-product',
                       'hw.version': 'test-version',
                       'hw.uuid': 'test-uuid',
                       'hw.serialno': 'test-serialno',
                       'hw.vendor': 'test-vendor'}
    actual_dmi_facts = hardware.get_dmi_facts()

# Generated at 2022-06-22 23:31:51.918296
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    obj = OpenBSDHardwareCollector()
    assert obj.platform == 'OpenBSD'
    assert obj._fact_class == OpenBSDHardware

# Generated at 2022-06-22 23:32:01.589513
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    class MockModule:
        def run_command(self, comm):
            if comm == '/usr/bin/vmstat':
                return 0, '''procs    memory       page                    disks    traps          cpu
  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id
  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99''', ''
            elif comm == '/sbin/swapctl -sk':
                return 0, '''total: 69268 1K-blocks allocated, 0 used, 69268 available''', ''
            else:
                return 1, '', ''
    # Create an object of the OpenBSDHardware class
    obj = OpenBSD

# Generated at 2022-06-22 23:32:14.835699
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    import sys
    import subprocess
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware

    sys.modules['ansible'] = type('ansible', (), {})
    sys.modules['ansible.module_utils'] = type('ansible.module_utils', (), {})
    sys.modules['ansible.module_utils.facts'] = type('ansible.module_utils.facts', (), {})
    sys.modules['ansible.module_utils.facts.hardware'] = type('ansible.module_utils.facts.hardware', (), {})
    sys.modules['ansible.module_utils.facts.hardware.openbsd'] = OpenBSDHardware


# Generated at 2022-06-22 23:32:18.947875
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    hardware = OpenBSDHardware()
    hardware.sysctl = {
        'hw.product': 'iBook',
        'hw.version': '1.0',
        'hw.uuid': '0xEDFEF11F',
        'hw.serialno': '0123456789',
        'hw.vendor': 'Apple'
    }
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'iBook'
    assert dmi_facts['product_version'] == '1.0'
    assert dmi_facts['product_uuid'] == '0xEDFEF11F'
    assert dmi_facts['product_serial'] == '0123456789'
    assert dmi_facts['system_vendor'] == 'Apple'

# Unit

# Generated at 2022-06-22 23:32:27.700511
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # initialize class
    openbsd_facts = OpenBSDHardware({})
    openbsd_facts.populate()
    assert(openbsd_facts.facts['memfree_mb'] != 0)
    assert(openbsd_facts.facts['memtotal_mb'] != 0)
    assert(openbsd_facts.facts['swapfree_mb'] != 0)
    assert(openbsd_facts.facts['swaptotal_mb'] != 0)
    assert(openbsd_facts.facts['uptime_seconds'] != 0)
    assert(openbsd_facts.facts['devices'] != 0)

# Generated at 2022-06-22 23:32:36.389364
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    hardware = OpenBSDHardware({}, {})
    hardware.sysctl = {
        'hw.usermem': 10000000,
    }
    hardware.module.run_command = lambda *args: (0, '', '')

    memory_facts = hardware.get_memory_facts()

    assert(memory_facts['memfree_mb'] == 0)
    assert(memory_facts['memtotal_mb'] == 0)
    assert(memory_facts['swapfree_mb'] == 0)
    assert(memory_facts['swaptotal_mb'] == 0)

# Generated at 2022-06-22 23:32:40.696208
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    oh = OpenBSDHardware()
    oh.sysctl = {'kern.boottime': '1579681511'}
    expected_result = {
        'uptime_seconds': int(time.time() - 1579681511),
    }
    result = oh.get_uptime_facts()
    assert result == expected_result

# Generated at 2022-06-22 23:32:50.231139
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    sysctl = {'hw.ncpuonline': '1', 'hw.model': 'Intel(R) Core(TM) i5-3570 CPU @ 3.40GHz'}
    setattr(OpenBSDHardware, 'sysctl', sysctl)
    expected_results = {'processor': ['Intel(R) Core(TM) i5-3570 CPU @ 3.40GHz'],
                        'processor_count': '1',
                        'processor_cores': '1'}
    processor_facts = OpenBSDHardware(None).get_processor_facts()

    assert processor_facts == expected_results

# Generated at 2022-06-22 23:33:00.769664
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():

    class MockModule(object):
        def __init__(self, sysctl):
            self.sysctl = sysctl
            self.params = {}

        def run_command(self, cmd):
            return 0, '', ''

    module = MockModule(dict(hw_product="foo", hw_version="1.0", hw_uuid="", hw_serialno="123456789", hw_vendor="bar"))

    hw = OpenBSDHardware(module)

    assert hw.get_dmi_facts() == dict(product_name="foo", product_version="1.0", product_uuid="", product_serial="123456789", system_vendor="bar")

# Generated at 2022-06-22 23:33:01.543749
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert issubclass(OpenBSDHardwareCollector, HardwareCollector)


# Generated at 2022-06-22 23:33:09.482151
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    test_class = OpenBSDHardware()

    # test 1
    test_class.sysctl = {
            'hw.model': 'Genuine Intel(R) CPU U7300  @ 1.30GHz',
            'hw.ncpuonline': '2',
            }
    result = test_class.get_processor_facts()
    assert result == {'processor': ['Genuine Intel(R) CPU U7300  @ 1.30GHz',
                                    'Genuine Intel(R) CPU U7300  @ 1.30GHz'],
                      'processor_cores': '2',
                      'processor_count': '2',
                      'processor_speed': '',
                      }

# Generated at 2022-06-22 23:33:22.068057
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = OpenBSDHardware(module)
    hw.populate()
    assert hw.sysctl['hw.machine'] == 'amd64'
    assert hw.sysctl['hw.model'] == 'Intel(R) Core(TM) i7-8650U CPU @ 1.90GHz'

if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    from pytest import raises
    from ansible.module_utils._text import to_bytes
    import sys

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )

    if module._name == '__main__':
        sys.argv.pop(0)
        test_OpenBSDHardware_populate

# Generated at 2022-06-22 23:33:24.400466
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector is not None

# Generated at 2022-06-22 23:33:32.247579
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    sysctl = {'hw.disknames': 'sd0,sd1,sd2,sd3,sd4,sd5,sd6,sd7,sd8'}
    hardware_facts = OpenBSDHardwareCollector(module).populate()
    assert hardware_facts['devices'] == ['sd0', 'sd1', 'sd2', 'sd3', 'sd4', 'sd5', 'sd6', 'sd7', 'sd8']

# Generated at 2022-06-22 23:33:41.767682
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():

    class MockedModule:
        run_command_sum = 0
        sysctl = {'hw.product': 'OpenBSD',
                  'hw.serialno': '',
                  'hw.uuid': '',
                  'hw.version': '',
                  'hw.vendor': ''}

        def run_command(self, cmd, check_rc=False):
            return (0, '', '')

    mocked_module = MockedModule()
    hardware_instance = OpenBSDHardware()
    hardware_instance.module = mocked_module
    actual_facts = hardware_instance.get_dmi_facts()
    expected_facts = {'product_name': 'OpenBSD',
                      'system_vendor': '',
                      'product_version': '',
                      'product_serial': '',
                      'product_uuid': ''}


# Generated at 2022-06-22 23:33:45.515681
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    p = OpenBSDHardwareCollector()
    assert hasattr(p, '_fact_class') and hasattr(p, '_platform')

# Generated at 2022-06-22 23:33:52.436966
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = None
    hardware = OpenBSDHardware(module)
    hardware.populate()
    openbsd_processor_facts = hardware.get_processor_facts()
    expected_processor_facts = {'processor': ['AMD-Opteron_6274_MP_32-Core_Processor'],
                                'processor_cores': 2,
                                'processor_count': 2}
    assert openbsd_processor_facts == expected_processor_facts


# Generated at 2022-06-22 23:34:05.040011
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    # Arrange
    m = OpenBSDHardware()
    m.sysctl = {'hw.product': 'Bochs',
                'hw.version': '1.0',
                'hw.uuid': '00000000-0000-0000-0000-000000000000',
                'hw.serialno': 'MISSING',
                'hw.vendor': 'Bochs',
                'hw.ncpuonline': '0'}
    expected = {'product_name': 'Bochs',
                'product_version': '1.0',
                'product_uuid': '00000000-0000-0000-0000-000000000000',
                'product_serial': 'MISSING',
                'system_vendor': 'Bochs'}

    # Act
    result = m.get_dmi_facts()

    # Assert

# Generated at 2022-06-22 23:34:14.688337
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    class TestModule:
        def run_command(self, cmd):
            return 0, "sda,sdb", ""

    class TestOpenBSDHardware(OpenBSDHardware):
        def __init__(self, module):
            self.module = module

        def get_sysctl(self, sysctl):
            values = {'hw.disknames': "sda,sdb"}
            if sysctl not in values:
                raise KeyError
            return values[sysctl]

    module = TestModule()
    hardware = TestOpenBSDHardware(module)
    devices = hardware.get_device_facts()['devices']
    assert ['sda', 'sdb'] == devices



# Generated at 2022-06-22 23:34:28.483635
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    """OpenBSDHardware - class - populate method"""
    import re
    import time
    import datetime
    import json

    module = MockModule()

    # Empty class to hold the hardware facts
    hardware_facts = {}

    # Create a new instance of OpenBSDHardware class
    hardware = OpenBSDHardware(module)

    # Populate method of OpenBSDHardware class returns a dictionary
    populate_return = hardware.populate()

    # Class variable of OpenBSDHardware class is assigned the value of return
    # of method populate
    hardware_facts = populate_return

    # A sample output of hw.machine sysctl is amd64
    cpu_hardware = get_sysctl(module, ['hw'])['hw.machine']

    # A sample output of df command is:
    # Filesystem  Size Used Avail Use% Mounted on
    # /

# Generated at 2022-06-22 23:34:33.677805
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # Create test object
    x = OpenBSDHardware()
    # Set values of sysctl
    x.sysctl = {'hw.usermem': '25769803776'}

    # Execute method
    facts = x.get_memory_facts()

    # Check if facts are what we expect
    assert facts['memtotal_mb'] == 24576

# Generated at 2022-06-22 23:34:40.234405
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    openbsd_hardware = OpenBSDHardware(module)
    module.run_command = MagicMock(return_value=(0, 'hw.product=Apple iMac 21.5"', ''))
    assert openbsd_hardware.get_dmi_facts()['product_name']=='Apple iMac 21.5"'


# Generated at 2022-06-22 23:34:51.365602
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = MockModule()
    module.run_command.return_value = (0, 'procs    memory       page                    disks    traps          cpu\n 0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', '')
    module.get_bin_path.return_value = '/usr/bin/sysctl'
    module.params = {'gather_subset': ['!all', '!min', '!virtual']}
    get_sysctl_mock = Mock()
    get_sysctl_mock.return_value = {
        'hw.usermem': '1669079040'
    }

    openbsd = OpenBSDHardware(module)
    openbsd.sysctl = get_sysctl_mock
   

# Generated at 2022-06-22 23:35:03.961489
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    module = get_module_mock()
    sysctl = {'hw.product': 'OpenBSD',
              'hw.version': '6.7',
              'hw.uuid': '9b6f2b6a-e6a5-11e5-bdc5-525400065e17',
              'hw.serialno': 'a1:b2:c3:d4:e5:f6',
              'hw.vendor': 'The OpenBSD Project'}
    module.get_bin_path.return_value = '/sbin/dmidecode'
    module.run_command.return_value = (0, '', '')