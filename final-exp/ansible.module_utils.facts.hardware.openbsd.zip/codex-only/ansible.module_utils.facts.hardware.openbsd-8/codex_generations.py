

# Generated at 2022-06-22 23:25:02.281122
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    openbsd_hardware = OpenBSDHardware()

    result = openbsd_hardware.get_processor_facts()

    assert result is not None
    assert result['processor_count']
    assert result['processor_cores']
    assert result['processor'] is not None


# Generated at 2022-06-22 23:25:13.564523
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    hardware = OpenBSDHardware()
    hardware.sysctl = {'hw.usermem': '5076096', 'hw.ncpu': '2'}
    hardware.module = OpenBSDHardwareCollector.get_fake_module()
    hardware.module.run_command = OpenBSDHardwareCollector.get_fake_run_command(output="""procs    memory       page                    disks    traps          cpu
  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id
  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99""")
    facts = hardware.populate()
    assert facts['memfree_mb'] == 28

# Generated at 2022-06-22 23:25:22.251299
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    myHardware = OpenBSDHardware({'ANSIBLE_MODULE_ARGS': {'gather_subset': ['all']}})
    myHardware.sysctl = {'hw.product': 'MacBookPro9,1', 'hw.version': '1.0', 'hw.uuid': '0xABCDEF0123456789', 'hw.serialno': 'SerialNumberABCDEF0123456789', 'hw.vendor': 'Apple Inc.'}

    expected_dmi_facts = {
        'product_name': 'MacBookPro9,1',
        'product_version': '1.0',
        'product_uuid': '0xABCDEF0123456789',
        'product_serial': 'SerialNumberABCDEF0123456789',
        'system_vendor': 'Apple Inc.'}

    assert my

# Generated at 2022-06-22 23:25:34.322544
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    sysctl = {
        'hw.product': 'VirtualBox',
        'hw.version': '1.2-RELEASE',
        'hw.uuid': '12345678-9A0B-CDE1-2F34-56789A0BCDEF',
        'hw.serialno': '0123456789',
        'hw.vendor': 'ACME, Inc'
    }
    hardware_obj.sysctl = sysctl
    dmi_facts = hardware_obj.get_dmi_facts()

# Generated at 2022-06-22 23:25:36.225032
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    platform_facts = OpenBSDHardwareCollector()
    assert platform_facts.platform == 'OpenBSD'
    assert platform_facts.fact_class == OpenBSDHardware


# Generated at 2022-06-22 23:25:45.092769
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    hardware = OpenBSDHardware()
    facts = {}
    facts['ansible_system'] = 'OpenBSD'
    hardware._collect_platform_facts.return_value = facts
    hardware.populate()
    # Check sysctl
    hardware._get_sysctl.assert_called_with(['hw'])
    # Check system uptime
    hardware._exec_cmd.assert_called_with(['/usr/bin/uptime', '-n'])


# Generated at 2022-06-22 23:25:47.211215
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    hardware_facts = OpenBSDHardware()
    devices = hardware_facts.get_device_facts()
    assert 'devices' in devices

# Generated at 2022-06-22 23:25:56.065055
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    # List of dictionaries containing all the args that should return a
    # 'changed' state from the constructor (and corresponding expected result)
    input_output = [({'processor': ['a']}, {'processor': set(['a'])}),
                    ({'processor': ['a', 'b']}, {'processor': set(['a', 'b'])}),
                    ({'processor': ['a', 'a', 'a']}, {'processor': set(['a'])})]
    # Input is a list of one or more dictionaries
    for test_input in input_output:
        openbsd_hardware = OpenBSDHardware(test_input[0])
        output = openbsd_hardware.get_facts()

# Generated at 2022-06-22 23:26:07.615213
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware_files_mock = HardwareFilesMock({
        '/etc/fstab': '# /etc/fstab:\n/dev/wd0p3 / ffs rw,softdep,noatime 1 1\ndevfs /dev devfs rw 0 0\n',
    })

    # Test without timeout
    collector = OpenBSDHardwareCollector(module=module)
    collector.sysctl = {'hw.usermem': '4327782912',
                        'hw.disknames': 'wd1,wd0',
                        'hw.model': 'Intel(R) Xeon(R) CPU E31220L @ 2.10GHz',
                        'hw.ncpuonline': '8'}

# Generated at 2022-06-22 23:26:20.324577
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware

    hardware = OpenBSDHardware('module')
    hardware.sysctl = {'hw.usermem': '209715200',
                       'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz'}
    rc = 0
    out = 'procs    memory  page  disks  traps      cpu\n' \
          ' r b w    avm   fre  flt  re pi po fr sr wd0 fd0  int   sys   cs us sy id\n' \
          ' 0 0 0    47512 28160   51   0  0  0  0  0   1   0  116    89   17  0  1 99'
   

# Generated at 2022-06-22 23:26:29.195478
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    hw = OpenBSDHardware({})
    hw.sysctl = {
        'hw.product': 'ThinkPad X220',
        'hw.version': 'Not Available',
        'hw.uuid': 'D7FC8E1E-2BAA-11E6-9440-8EBEAE78FFC1',
        'hw.serialno': 'R9021724',
        'hw.vendor': 'LENOVO',
        'hw.ncpuonline': '1',
    }
    dmi_facts = hw.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'LENOVO'
    assert dmi_facts['product_name'] == 'ThinkPad X220'
    assert dmi_facts['product_version'] == 'Not Available'

# Generated at 2022-06-22 23:26:38.781173
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = {}
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'GenuineIntel'}
    facts = hardware.get_processor_facts()
    assert 'processor' in facts
    assert len(facts['processor']) == 2
    for processor in facts['processor']:
        assert processor == 'GenuineIntel'

    assert 'processor_count' in facts
    assert facts['processor_count'] == 2
    assert 'processor_cores' in facts
    assert facts['processor_cores'] == 2


# Generated at 2022-06-22 23:26:48.456800
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    hardware = OpenBSDHardware()
    hardware.module = MagicMock()
    hardware.sysctl = {'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i7-6650U CPU @ 2.20GHz'}


    # Testing processor facts
    hardware.module.run_command.return_value = (0, '', '')
    result = hardware.get_processor_facts()
    assert len(result['processor']) == 2
    assert 'Intel(R) Core(TM) i7-6650U CPU @ 2.20GHz' in result['processor']
    assert result['processor_count'] == '2'
    assert result['processor_cores'] == '2'



# Generated at 2022-06-22 23:26:56.632703
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    mock_module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, executable: '/bin/sysctl',
        'run_command': lambda self, args, **kwargs: (0, 'hw.disknames: sd0, sd1', '')
    })
    mock_module = mock_module()
    hardware = OpenBSDHardware(mock_module)

    results = hardware.get_device_facts()
    expected_results = {
        "devices": ['sd0', 'sd1']
    }

    assert results == expected_results


# Generated at 2022-06-22 23:27:08.905363
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    data = OpenBSDHardware.populate()
    # filter for testing purposes
    for key in list(data):
        if key not in ['devices', 'memfree_mb', 'memtotal_mb', 'processor', 'processor_cores', 'swapfree_mb', 'swaptotal_mb', 'uptime_seconds']:
            data.pop(key)

# Generated at 2022-06-22 23:27:12.870696
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    module = None
    hardware_facts = OpenBSDHardware(module)
    assert hardware_facts.platform == 'OpenBSD'


# Generated at 2022-06-22 23:27:24.187181
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    openbsd_hardware_obj = OpenBSDHardware()
    data = '''hw.product: OpenBSD
hw.version: 6.1 (GENERIC)
hw.uuid: 98868D28-862F4-4A4E4-9D9F4-4D5F4
hw.serialno: OpenBSD.61.amd64
hw.vendor: OpenBSD'''

# Generated at 2022-06-22 23:27:34.791217
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    oh = OpenBSDHardware(module)
    dmi_facts = {'product_name': 'Hardware', 'product_version': '1.2.3', 'product_uuid': 'UUID',
                 'product_serial': '123456', 'system_vendor': 'Vendor'}
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = 'sysctl'
    oh.sysctl = {'hw.product': 'Hardware',
                 'hw.version': '1.2.3',
                 'hw.uuid': 'UUID',
                 'hw.serialno': '123456',
                 'hw.vendor': 'Vendor'}
    assert oh.get_dmi_facts() == dmi_

# Generated at 2022-06-22 23:27:47.813504
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    class ModuleMock(object):
        def run_command(self, *args):
            if args == ('/sbin/sysctl',):
                return 0, ('hw.product=HP ProLiant DL360p Gen8',
                           'hw.version=',
                           'hw.uuid=1EBADF0D-8B2D-C910-18D5-1ACB096F5F5A',
                           'hw.serialno=1EBADF0D',
                           'hw.vendor=HP'), ''
            raise Exception("run_command: unexpected: %s" % repr(args))

        def get_bin_path(self, *args):
            return 'path'

    hardware_facts = OpenBSDHardware(ModuleMock())
    dmi_facts = hardware_facts.get_dmi_

# Generated at 2022-06-22 23:27:53.784746
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = MockModule()
    hw = OpenBSDHardware(module)
    hw.sysctl = {
        'hw.disknames': 'sd0,sd1,sd2,sd3',
    }
    assert hw.get_device_facts() == {'devices': ['sd0', 'sd1', 'sd2', 'sd3']}



# Generated at 2022-06-22 23:28:00.607174
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # Create an instance of OpenBSDHardware
    hardware_facts = OpenBSDHardware()

    # Define expected and observed values
    expected_uptime_seconds = 42
    observed_uptime_seconds = hardware_facts.get_uptime_facts()['uptime_seconds']

    # Assert expected and observed values
    assert expected_uptime_seconds == observed_uptime_seconds, "Expected uptime is %s, but observed uptime is %s" \
                                                               % (expected_uptime_seconds, observed_uptime_seconds)


# Generated at 2022-06-22 23:28:14.220071
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    facts = OpenBSDHardware(module).populate()
    assert type(facts['processor_speed']) == int
    assert len(facts['devices']) > 0
    assert type(facts['uptime_seconds']) == int
    assert type(facts['memfree_mb']) == int
    assert type(facts['memtotal_mb']) == int
    assert type(facts['swapfree_mb']) == int
    assert type(facts['swaptotal_mb']) == int
    for entry in facts['mounts']:
        assert type(entry['mount']) == str
        assert type(entry['device']) == str
        assert type(entry['fstype']) == str
        assert type(entry['options']) == str
       

# Generated at 2022-06-22 23:28:26.967215
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    hardware = OpenBSDHardware(dict(module=None))
    hardware.sysctl = dict(hw={'ncpuonline': '8',
                               'model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'})

    # Number of logical CPUs
    assert hardware.get_processor_facts()['processor_count'] == 8
    # Number of logical CPUs
    assert hardware.get_processor_facts()['processor_cores'] == 8
    # For each logical CPU we have a single 'processor' entry
    assert len(hardware.get_processor_facts()['processor']) == 8
    # All 'processor' entries are dominated by the model of the CPU

# Generated at 2022-06-22 23:28:28.434289
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    hardware_facts = OpenBSDHardware()
    assert hardware_facts.platform == 'OpenBSD'

# Generated at 2022-06-22 23:28:30.619900
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    facts = OpenBSDHardware().get_uptime_facts()

    assert facts is not None
    assert 'uptime_seconds' in facts.keys()

# Generated at 2022-06-22 23:28:34.744499
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    m = OpenBSDHardwareCollector.factory()
    m._load_sysctl_facts = lambda: {'hw.disknames': 'wd0,cd0'}
    assert m.get_device_facts() == {'devices': ['wd0', 'cd0']}

# Generated at 2022-06-22 23:28:42.474285
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    from ansible.module_utils.facts.utils import ModuleStub
    openbsd_hw = OpenBSDHardware({})
    openbsd_hw.module = ModuleStub({})
    openbsd_hw.module.run_command = lambda x: (0, '47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', 0)
    assert openbsd_hw.get_memory_facts() == {
        'memfree_mb': 27,
        'memtotal_mb': 46,
        'swapfree_mb': 67,
        'swaptotal_mb': 67,
    }


# Generated at 2022-06-22 23:28:55.472060
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})

    # Create a instance of class OpenBSDHardware
    my_obj = OpenBSDHardware(module)

    # Mock class methods
    my_obj.sysctl = {
        "hw.usermem": 770347520,
    }
    vmstat_output = '''procs    memory       page                    disks    traps          cpu
0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99'''
    my_obj.module.run_command = lambda x: (0, vmstat_output, "")
    swapctl_output = ' total: 69268 1K-blocks allocated, 0 used, 69268 available'

# Generated at 2022-06-22 23:29:06.600401
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.fact_cache import FactCache
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    from ansible.module_utils.facts.utils import get_file_content

    sysctl_output = get_file_content('test/unit/module_utils/facts/hardware/openbsd/sysctl.out')
    fact_cache = FactCache()
    fact_cache.populate_cache(OpenBSDHardware, sysctl_output)

    result = fact_cache.get_facts(OpenBSDHardware)['ansible_facts']
    product_uuid = result['dmi']['product_uuid']
    assert product_uuid == '00000000-0000-0000-0000-000000000200'



# Generated at 2022-06-22 23:29:15.794416
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = FakeModule()
    hardware_populator = OpenBSDHardware(module)
    module.run_command = lambda x: (0, 'hw.ncpuonline: 1\nhw.usermem: 1073741824\nhw.disknames: sd0\nhw.model: Intel(R) Core(TM) i3 CPU       M 350  @ 2.27GHz\nkern.boottime: 1449061290\nhw.machine: amd64', '')
    facts = hardware_populator.populate()
    assert facts['processor'] == ['Intel(R) Core(TM) i3 CPU       M 350  @ 2.27GHz']
    assert facts['devices'] == ['sd0']

# Generated at 2022-06-22 23:29:24.187278
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    facts = hardware.populate()

    assert 'devices' in facts
    assert 'dmi' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts

# Generated at 2022-06-22 23:29:30.618085
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.sysctl = {'hw.disknames': 'sd0,sd1,wd0,wd1'}
    device_facts = hardware_obj.get_device_facts()
    assert device_facts == {'devices': ['sd0', 'sd1', 'wd0', 'wd1']}



# Generated at 2022-06-22 23:29:37.095075
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    class ImplementedModule(object):
        def run_command(self, args):
            return 0, '14980', ''

        def get_bin_path(self, args):
            return '/usr/bin/sysctl'

    cls = OpenBSDHardware
    cls.module = ImplementedModule()
    cls.sysctl = {}
    expected_up_time = time.time() - 14980
    assert cls.get_uptime_facts()['uptime_seconds'] == int(expected_up_time)


# Generated at 2022-06-22 23:29:42.340595
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    hw = OpenBSDHardware({})
    assert hw.sysctl == {}, 'Error: sysctl should be empty'
    hw = OpenBSDHardware({}, collected_facts=None)
    assert hw.sysctl == {}, 'Error: sysctl should be empty'

# Generated at 2022-06-22 23:29:48.114131
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0,
                                            '1478299860',
                                            None))
    platform_openbsd = OpenBSDHardware(module)
    facts = platform_openbsd.populate()
    assert facts['uptime_seconds'] == 1478299860

# Generated at 2022-06-22 23:29:54.793542
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    openbsd_facts = OpenBSDHardware(module)
    openbsd_facts.sysctl = get_sysctl(module, ['hw'])

    dmi_facts = openbsd_facts.get_dmi_facts()

    sysctl_to_dmi = {
        'hw.product': 'product_name',
        'hw.version': 'product_version',
        'hw.uuid': 'product_uuid',
        'hw.serialno': 'product_serial',
        'hw.vendor': 'system_vendor',
    }

    # Check that all keys are defined as they are supposed to be
    for key in dmi_facts:
        assert(key in sysctl_to_dmi.values())


# Generated at 2022-06-22 23:30:03.137484
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    # test get_processor_facts method of class OpenBSDHardware
    openbsd_hardware = OpenBSDHardware(module)
    processor_facts = openbsd_hardware.get_processor_facts()
    assert 'processor' in processor_facts
    assert 'processor_cores' in processor_facts
    assert 'processor_count' in processor_facts



# Generated at 2022-06-22 23:30:09.951852
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    uname = 'OpenBSD 5.6-current'
    sysctl = {
        'hw.product': 'OpenBSD',
        'hw.vendor': 'OpenBSD',
        'hw.version': '5.6-current',
        'hw.uuid': 'beefbeef-beef-beef-beef-beefbeefbeef',
        'hw.serialno': '1234567890ABCDEF',
    }
    hardware = OpenBSDHardware(dict(uname=uname), dict(sysctl=sysctl))

    expected_keys = set(['product_name', 'product_version',
                         'product_uuid', 'system_vendor',
                         'product_serial'])
    dmi_facts = hardware.get_dmi_facts()

    assert set(dmi_facts.keys()) == expected

# Generated at 2022-06-22 23:30:20.753923
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = type('', (), {})()
    module.run_command = lambda cmd: (0, '  0  0  0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', '')

    hardware = type('OpenBSDHardware', (OpenBSDHardware, object), {})()
    hardware.module = module
    hardware.sysctl = {'hw.usermem': 4634405928}  # 4GB
    facts = hardware.get_memory_facts()
    assert facts['memfree_mb'] == 28160 // 1024
    assert facts['memtotal_mb'] == 4634405928 // 1024 // 1024

    module.run_command = lambda cmd: (0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', '')

# Generated at 2022-06-22 23:30:33.671417
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    m = OpenBSDHardware()
    m.sysctl = {'hw.product': 'OpenBSD',
                'hw.version': '6.0',
                'hw.uuid': 'c2a0b6f0-16e8-11e1-89cf-0018f3b6c8eb',
                'hw.serialno': 'OpenBSD',
                'hw.vendor': 'It\'s Good for Your Heart',
                'hw.machine': 'amd64'}


# Generated at 2022-06-22 23:30:42.910284
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    test_platform = 'OpenBSD'
    test_module = FakeModule()
    test_module.run_command = fake_run_command

    test_hardware = OpenBSDHardware(test_module)
    cpu_facts = test_hardware.get_processor_facts()
    assert cpu_facts['processor'] == ['Quad-Core AMD Opteron(tm) Processor 2384']
    assert cpu_facts['processor_count'] == '4'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_speed'] is None



# Generated at 2022-06-22 23:30:44.415314
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    hardware = OpenBSDHardware({})
    assert hardware.collector.platform == "OpenBSD"

# Generated at 2022-06-22 23:30:54.995286
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(
        argument_spec={
        },
        supports_check_mode=True
    )

    module.sysctl = {'hw.ncpuonline': '1',
                     'hw.model': 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz'}

    hw = OpenBSDHardware(module)
    result = hw.get_processor_facts()
    assert result['processor'] == ['Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz'], result['processor']
    assert result['processor_count'] == 1, result['processor_count']
    assert result['processor_cores'] == 1, result['processor_cores']
    assert result['processor_speed'] is None, result['processor_speed']


# Generated at 2022-06-22 23:31:07.578395
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )
    openbsd_hardware = OpenBSDHardware(module)
    openbsd_hardware.populate()

    memtotal_mb = openbsd_hardware.get('memtotal_mb')
    assert memtotal_mb is not None
    memfree_mb = openbsd_hardware.get('memfree_mb')
    assert memfree_mb is not None
    swaptotal_mb = openbsd_hardware.get('swaptotal_mb')
    assert swaptotal_mb is not None
    swapfree_mb = openbsd_hardware.get('swapfree_mb')
    assert swapfree_mb is not None


# Generated at 2022-06-22 23:31:09.058218
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    hardware = OpenBSDHardware()
    hardware.module = FakeAnsibleModule()
    hardware.populate()


# Generated at 2022-06-22 23:31:11.676802
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    collector = OpenBSDHardwareCollector()

    assert isinstance(collector.platform, str), 'Platform is not an string'
    assert isinstance(collector.collect(), dict), 'Collection is not a dictionary'

# Generated at 2022-06-22 23:31:21.521133
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    hardware = OpenBSDHardware({}, {})
    # sysctl hw.product and hw.serialno are tested in test_OpenBSDFacts_sysctl
    # here, we just test that we don't screw up the mapping.
    hardware.sysctl = {'hw.product': 'test_product',
                       'hw.serialno': 'test_serial'}
    hw_facts = hardware.get_dmi_facts()

    assert hw_facts['product_name'] == 'test_product'
    assert hw_facts['product_serial'] == 'test_serial'

# Generated at 2022-06-22 23:31:23.864056
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    facts = {'ansible_os_family': OpenBSDHardware.platform}
    detected_os = OpenBSDHardware(facts, None)
    assert detected_os.platform == 'OpenBSD'

# Generated at 2022-06-22 23:31:26.422191
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    hardware = OpenBSDHardware()
    hardware.sysctl = {'hw.disknames': 'sd0,sd1'}

    result = hardware.get_device_facts()

    assert result['devices'] == ['sd0', 'sd1']

# Generated at 2022-06-22 23:31:37.012845
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = FakeModule()
    hardware = OpenBSDHardware(module)

    # Failure case
    module.run_command.return_value = (1, '', '')
    assert hardware.get_uptime_facts() == {}
    module.run_command.assert_called_once_with(['/sbin/sysctl', '-n', 'kern.boottime'])

    # Success case
    module.run_command.reset_mock()
    module.run_command.return_value = (0, '1234567890', '')
    utime = hardware.get_uptime_facts()
    assert utime == {'uptime_seconds': int(time.time() - 1234567890)}

# Generated at 2022-06-22 23:31:46.302550
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModuleMock()
    # Test case 1: get_mount_facts() timeout
    hardware = OpenBSDHardware(module)
    hardware.get_mount_facts_org = hardware.get_mount_facts
    hardware.get_mount_facts = lambda: None
    facts = hardware.populate()
    assert len(facts) == 8

    # Test case 2: normal case
    hardware = OpenBSDHardware(module)
    hardware.get_mount_facts = hardware.get_mount_facts_org
    facts = hardware.populate()
    assert len(facts) == 22


# Generated at 2022-06-22 23:31:51.309137
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    hardware = OpenBSDHardware()
    hardware.sysctl = {'hw.disknames': 'wd0,wd1,cd0,sd0'}
    expected_facts = {'devices': ['wd0', 'wd1', 'cd0', 'sd0']}
    facts = hardware.get_device_facts()
    assert facts == expected_facts

# Generated at 2022-06-22 23:31:54.673958
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    collector = OpenBSDHardwareCollector()
    assert collector._platform == 'OpenBSD'

# Generated at 2022-06-22 23:32:04.379222
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list'),
            'gather_timeout': dict(default=10, type='int'),
        },
        supports_check_mode=True)

    if not module.params['gather_subset']:
        module.params['gather_subset'] = ['!all', '!min']

    # set up our base class to exit when timeout is reached
    class TimeoutExit(Exception):
        pass

    def time_out(signum, frame):  # pylint: disable=unused-argument
        raise TimeoutExit

    signal.signal(signal.SIGALRM, time_out)

    # setup the test object
    sysctl_cmd = module.get_bin_path('sysctl')


# Generated at 2022-06-22 23:32:11.409676
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    model = OpenBSDHardware({})
    sysctl = {'hw.disknames': 'sd0,sd1'}
    model.sysctl = sysctl
    model.module = type('AnsibleModule', (), {})
    model.module.run_command = lambda x: (0, '', '')
    assert model.get_device_facts() == {'devices': ['sd0', 'sd1']}

# Generated at 2022-06-22 23:32:16.132165
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    hw_facts = OpenBSDHardware()
    hw_facts.sysctl = {
        'kern.boottime': 111111,
    }
    assert hw_facts.get_uptime_facts() == {
        'uptime_seconds': int(time.time()) - 111111,
    }

# Generated at 2022-06-22 23:32:24.802890
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = get_mock_module()
    module.run_command = get_mock_run_command(stdout=cmd_output)
    hw = OpenBSDHardware(module)
    hw.sysctl = get_mock_sysctl()

    dev_facts = hw.get_device_facts()
    assert dev_facts['devices'] == ['sd0']
    module.run_command.assert_called_once_with("/sbin/sysctl -n hw.disknames")


# Generated at 2022-06-22 23:32:34.490152
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = openbsd_module_mock()
    hardware = OpenBSDHardware(module)

    hardware.sysctl = {'hw.ncpuonline': '1',
                       'hw.model': 'Intel(R) Core(TM) i7-3612QM CPU @ 2.10GHz'}
    expected = {'processor': ['Intel(R) Core(TM) i7-3612QM CPU @ 2.10GHz'],
                'processor_cores': '1',
                'processor_count': '1'}
    actual = hardware.get_processor_facts()

    assert actual == expected


# Generated at 2022-06-22 23:32:35.977238
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    m_open = OpenBSDHardware({})
    assert m_open.collect()

# Generated at 2022-06-22 23:32:43.648996
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})

    hardware = OpenBSDHardware(module)
    hardware.sysctl = {
        'hw.usermem': '171392430080',
    }
    hardware.module.run_command.return_value = (0,
                                                'procs    memory       page                    disks    traps          cpu\n'
                                                'r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n'
                                                '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n',
                                                '')

# Generated at 2022-06-22 23:32:54.622132
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule({})
    hardware_module = OpenBSDHardware(module)
    hardware_module.sysctl = {'hw.ncpuonline': '2',
                              'hw.model': 'Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz'}
    result = hardware_module.get_processor_facts()
    assert result['processor'] == ['Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz',
                                   'Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz']
    assert result['processor_count'] == 2
    assert result['processor_cores'] == 2


# Generated at 2022-06-22 23:33:00.242065
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(
        argument_spec = dict(
            timeout = dict(default=10, type='int')
        )
    )
    module.params['timeout'] = 1
    o = OpenBSDHardware(module)
    o.get_uptime_facts()
    module.exit_json()


# Generated at 2022-06-22 23:33:04.644719
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = MockModule()
    sysctl = {'hw.disknames': 'wd0,wd1'}
    setattr(module, 'run_command', mock_run_command)
    setattr(module, 'get_bin_path', mock_get_bin_path)
    setattr(module, 'get_sysctl', lambda x: sysctl)
    hw = OpenBSDHardware(module)
    assert hw.get_device_facts() == {'devices': ['wd0', 'wd1']}


# Generated at 2022-06-22 23:33:17.258365
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.run_command = MagicMock()

    m = re.compile(r'^OpenBSD\d\.\d(-\w+(-\w+)?)?$')

    def mock_run_command(command, check_rc=False, executable=None, use_unsafe_shell=False):  # pylint: disable=unused-argument
        rc = 0
        out = 'hw.ncpuonline=2\nhw.model=%s' % module.params['kernel']
        err = ''
        return rc, out, err

    hardware = OpenBSDHardwareCollector(module=module, subclasses=None)
    hardware.sysctl = get_sysctl(module, ['hw'])

# Generated at 2022-06-22 23:33:29.113866
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = FakeAnsibleModule({
        'sysctl_path': 'bin/sysctl',
        'hw.ncpuonline': '2',
        'hw.model': 'Intel(R) Core(TM) i7-6800K CPU @ 3.40GHz'
    })
    openbsd_hardware = OpenBSDHardware(module)
    cpu_facts = openbsd_hardware.get_processor_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor'][0] == 'Intel(R) Core(TM) i7-6800K CPU @ 3.40GHz'
    assert cpu_facts['processor'][1] == 'Intel(R) Core(TM) i7-6800K CPU @ 3.40GHz'


# Generated at 2022-06-22 23:33:38.833863
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    sysctl = {'hw.usermem': 2147483648,
              'hw.ncpuonline': 2}
    hw = OpenBSDHardware(module)
    hw.sysctl = sysctl
    from ansible.module_utils.facts.hardware import OpenBSDHardware
    OpenBSDHardware.get_memory_facts = mock.Mock(return_value={})
    facts = hw.populate()

    assert facts['processor_cores'] == 2
    assert facts['memtotal_mb'] == 2048
    assert facts['swaptotal_mb'] == 34
    assert facts['swapfree_mb'] == 34



# Generated at 2022-06-22 23:33:48.454550
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModuleMock({}, 'OpenBSD')
    hw = OpenBSDHardware(module)
    hw.sysctl = {'hw.ncpuonline': '2',
                 'hw.model': 'Intel(R) Core(TM) i7-4810MQ CPU @ 2.80GHz'}
    processor_facts = hw.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4810MQ CPU @ 2.80GHz'] * 2
    assert processor_facts['processor_count'] == 2



# Generated at 2022-06-22 23:33:50.081936
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    OpenBSDHardwareCollector()

# Generated at 2022-06-22 23:33:57.825317
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():

    class FakeModule():
        def run_command(self, cmd):
            assert cmd == ['/usr/bin/vmstat']
            return 0, "procs  memory  page    disks    traps          cpu\n  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n 0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99", None
        def get_bin_path(self, path, *args, **kwargs):
            assert path == 'sysctl'
            return '/sbin/sysctl'

    fakemodule = FakeModule()

    hardware = OpenBSDHardware(fakemodule)

# Generated at 2022-06-22 23:34:07.040598
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    answer = {
        'product_name': 'OpenBSD',
        'system_vendor': 'OpenBSD Foundation',
    }
    mock_module = MockModule({
        'hw.product': 'OpenBSD',
        'hw.version': 'OpenBSD',
        'hw.uuid': 'OpenBSD',
        'hw.serialno': 'OpenBSD',
        'hw.vendor': 'OpenBSD Foundation',
    })
    hw = OpenBSDHardware(mock_module)
    assert hw.get_dmi_facts() == answer


# Generated at 2022-06-22 23:34:09.136586
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    module = OpenBSDHardwareCollector()
    assert module.collect() == module.get_facts()

# Generated at 2022-06-22 23:34:18.702830
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():

    # Define test case scenario
    # Test case scenario:
    # OpenBSD 5.9 (GENERIC) #0: Fri Nov 20 03:49:14 UTC 2015
    # Test case 1:
    # Test that uptime facts are correctly collected with an uptime string as
    # returned by sysctl in OpenBSD 5.9:
    # - sysctl output: kern.boottime = 1481473755

    kern_boottime = '1481473755'
    sysctl_cmd = 'sysctl'

    # Test case 1:
    # Test that uptime facts are correctly collected with an uptime string as
    # returned by sysctl in OpenBSD 5.9:
    # - sysctl output: kern.boottime = 1481473755

# Generated at 2022-06-22 23:34:20.086486
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    OpenBSDHardwareCollector()

# Generated at 2022-06-22 23:34:30.760532
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    sysctl = {'hw.ncpuonline': 2, 'hw.model': 'Intel(R) Core(TM) i5-5287U CPU @ 2.90GHz'}
    hardware = OpenBSDHardware({}, sysctl)

    # Call get_processor_facts
    processor_facts = hardware.get_processor_facts()

    # Assert that get_processor_facts returns a dictionary containing the
    # following keys: 'processor', 'processor_count', 'processor_cores' and
    # 'processor_speed' whose values are:
    #   - 'processor': a list of strings
    #   - 'processor_count': an integer
    #   - 'processor_cores': an integer
    #   - 'processor_speed': an integer
    assert isinstance(processor_facts, dict)

# Generated at 2022-06-22 23:34:38.658121
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
        class FakeModule:
            def __init__(self):
                self.run_command_calls = []
                self.run_command_result = []
                self.fail_json = dict()
                self.fail_json_calls = []

            def get_bin_path(self, name):
                return name

            def run_command(self, cmd):
                self.run_command_calls.append(cmd)
                return self.run_command_result.pop()

            def fail_json(self, **params):
                self.fail_json_calls.append(params)

        module = FakeModule()
        module.run_command_result = [(0, '1556960075', '')]
        expected = {'uptime_seconds': int(time.time()) - 1556960075}
        openbsd_

# Generated at 2022-06-22 23:34:40.181889
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    hw = OpenBSDHardware()
    assert hw.platform == 'OpenBSD'

# Generated at 2022-06-22 23:34:51.365906
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware

    module = MockModule()
    handler = OpenBSDHardware(module)

    # Set current time to the starting time of testing function
    handler.start_time = int(time.time())

    # Mock sysctl output as follows:
    # hw.ncpuonline: 1
    # kern.boottime: 1080035785
    handler.sysctl = {'hw.ncpuonline': '1',
                      'kern.boottime': None}

    module.run_command.return_value = (0, '1080035785', '')

    # The function is expected to return uptime_seconds = 1080035785
    expected = {'uptime_seconds': 1080035785}
    assert expected == handler.get_uptime_facts()

# Generated at 2022-06-22 23:34:56.540331
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    hardware = OpenBSDHardware({}, dict(fake_binary='/bin/true'))
    hardware.populate()

    assert hardware.sysctl['hw.pagesize'] == '4096'

# Generated at 2022-06-22 23:35:04.073947
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():

    def mock_sysctl(module, args):
        return {'kern.boottime': '1407747973'}

    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, '', ''),
        'get_bin_path': lambda *args, **kwargs: '/bin/' + args[0],
    })

    facts = OpenBSDHardware(mock_module, 'x86_64', mock_sysctl).populate()
    assert facts['uptime_seconds'] == int(time.time() - 1407747973)