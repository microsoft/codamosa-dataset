

# Generated at 2022-06-17 00:22:13.097073
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:22:24.001424
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, "procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99", ""))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28
    assert memory_facts['memtotal_mb'] == 1024

#

# Generated at 2022-06-17 00:22:29.431917
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector.platform == 'OpenBSD'
    assert hardware_collector.fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:22:40.286106
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()

# Generated at 2022-06-17 00:22:50.390227
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\n  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28
    assert memory_facts['memtotal_mb']

# Generated at 2022-06-17 00:22:53.677903
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hw_collector = OpenBSDHardwareCollector()
    assert openbsd_hw_collector._fact_class == OpenBSDHardware
    assert openbsd_hw_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 00:23:02.288950
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    module.params = {}
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts

# Generated at 2022-06-17 00:23:06.377302
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:23:16.444913
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert memory_facts['swapfree_mb'] == 69268 // 1024
    assert memory_facts['swaptotal_mb'] == 69268 // 1024


# Generated at 2022-06-17 00:23:20.962909
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:23:33.224589
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1517962800'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1517962800)

# Generated at 2022-06-17 00:23:37.965935
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.module.run_command = MagicMock(return_value=(0, '1234567890', ''))
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1234567890)


# Generated at 2022-06-17 00:23:44.875633
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor']
    assert hardware_facts['devices']
    assert hardware_facts['mounts']
    assert hardware_facts['product_name']
    assert hardware_facts['product_version']
    assert hardware_facts['product_uuid']
    assert hardware_

# Generated at 2022-06-17 00:23:56.347665
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\n  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28
    assert memory_facts['memtotal_mb'] == 1024

# Generated at 2022-06-17 00:24:05.391315
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['processor'][0] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert hardware_obj.facts['processor_cores'] == 8
    assert hardware_obj.facts['processor_count'] == 8
    assert hardware_obj.facts['processor_speed'] == '2200'
    assert hardware_obj.facts['memtotal_mb'] == 16384
    assert hardware_obj.facts['memfree_mb'] == 12096
    assert hardware_obj.facts['swaptotal_mb'] == 8192
    assert hardware_obj.facts['swapfree_mb'] == 8192

# Generated at 2022-06-17 00:24:10.613968
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1'}
    device_facts = hardware.get_device_facts()
    assert device_facts['devices'] == ['sd0', 'sd1']


# Generated at 2022-06-17 00:24:22.118210
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware_facts = hardware.populate()

# Generated at 2022-06-17 00:24:35.027609
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = OpenBSDHardware(module).populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor']
    assert hardware_facts['devices']
    assert hardware_facts['mounts']
    assert hardware_facts['product_name']
    assert hardware_facts['product_version']
    assert hardware_facts['product_uuid']
    assert hardware_facts['product_serial']

# Generated at 2022-06-17 00:24:45.348482
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.ncpuonline': '2'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.get_memory_facts()
    assert hardware.facts['memfree_mb'] == 28160 // 1024
    assert hardware.facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0


# Generated at 2022-06-17 00:24:53.967504
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.module.run_command = MagicMock(return_value=(0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', ''))
    memory_facts

# Generated at 2022-06-17 00:25:03.810831
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector.platform == 'OpenBSD'
    assert hardware_collector.fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:25:12.354135
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['uptime_seconds'] > 0
    assert hardware_obj.facts['memtotal_mb'] > 0
    assert hardware_obj.facts['memfree_mb'] > 0
    assert hardware_obj.facts['swaptotal_mb'] > 0
    assert hardware_obj.facts['swapfree_mb'] > 0
    assert hardware_obj.facts['processor_count'] > 0
    assert hardware_obj.facts['processor_cores'] > 0
    assert hardware_obj.facts['devices']
    assert hardware_obj.facts['product_name']
    assert hardware_obj.facts['product_serial']
    assert hardware_obj.facts['product_uuid']
   

# Generated at 2022-06-17 00:25:21.821736
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()

# Generated at 2022-06-17 00:25:32.053458
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert memory_facts['swapfree_mb'] == 69268 // 1024
    assert memory_facts['swaptotal_mb'] == 69268 // 1024


# Generated at 2022-06-17 00:25:38.667729
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = OpenBSDHardwareCollector(module=module)
    hardware_collector.collect()
    hardware = hardware_collector.get_facts()

# Generated at 2022-06-17 00:25:49.412922
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\n  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 27
    assert memory_facts['memtotal_mb'] == 1024

# Generated at 2022-06-17 00:25:56.125675
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector.platform == 'OpenBSD'
    assert openbsd_hardware_collector.fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:26:06.569249
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)

    # Test with a valid kern.boottime
    hardware.sysctl = {'kern.boottime': '1518078146'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1518078146)

    # Test with an invalid kern.boottime
    hardware.sysctl = {'kern.boottime': 'invalid'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts == {}

    # Test with no kern.boottime
    hardware.sysctl = {}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts

# Generated at 2022-06-17 00:26:15.126630
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'}
    result = hardware.get_processor_facts()
    assert result['processor'] == ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz', 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz']
    assert result['processor_count'] == '2'
    assert result['processor_cores'] == '2'


# Generated at 2022-06-17 00:26:24.138279
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = OpenBSDHardware(module)
    hardware.populate()
    assert hardware.sysctl
    assert hardware.sysctl['hw.ncpuonline']
    assert hardware.sysctl['hw.usermem']
    assert hardware.sysctl['hw.model']
    assert hardware.sysctl['hw.disknames']
    assert hardware.sysctl['hw.product']
    assert hardware.sysctl['hw.version']
    assert hardware.sysctl['hw.uuid']
    assert hardware.sysctl['hw.serialno']
    assert hardware.sysctl['hw.vendor']


# Generated at 2022-06-17 00:26:49.310211
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    """
    This is a basic test for the constructor of the class OpenBSDHardwareCollector
    """
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector.platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:27:00.916963
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824', 'hw.ncpuonline': '1'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.get_memory_facts()
    assert hardware.facts['memfree_mb'] == 28160 // 1024
    assert hardware.facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0



# Generated at 2022-06-17 00:27:11.506377
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.ncpuonline': '1'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert memory_facts['swapfree_mb'] == 69268 // 1024

# Generated at 2022-06-17 00:27:14.509772
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.module.run_command = MagicMock(return_value=(0, "1523356852", ""))
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:27:21.553897
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.sysctl import get_sysctl

    module = AnsibleModuleMock()
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    hardware = OpenBSDHardware(module)
    hardware.sysctl = get_sysctl(module, ['kern'])
    hardware.get_uptime_facts()



# Generated at 2022-06-17 00:27:31.414920
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = OpenBSDHardware(module).populate()

# Generated at 2022-06-17 00:27:41.601104
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.product': 'OpenBSD',
                       'hw.version': '6.1',
                       'hw.uuid': '00000000-0000-0000-0000-000000000000',
                       'hw.serialno': '',
                       'hw.vendor': 'OpenBSD'}
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'OpenBSD'
    assert dmi_facts['product_version'] == '6.1'
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert dmi_facts['product_serial'] == ''

# Generated at 2022-06-17 00:27:48.188957
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:27:58.648562
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    module.get_file_content = get_file_content_mock
    module.get_mount_size = get_mount_size_mock
    module.get_sysctl = get_sysctl_mock
    hardware = OpenBSDHardware(module)
    hardware.populate()
    assert hardware.facts['uptime_seconds'] == 86400
    assert hardware.facts['memfree_mb'] == 8192
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 16384

# Generated at 2022-06-17 00:28:02.204818
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '1539707594', ''))
    hardware = OpenBSDHardware(module)
    assert hardware.get_uptime_facts() == {'uptime_seconds': 1539707594}


# Generated at 2022-06-17 00:28:53.461113
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)

    # Test case 1: sysctl returns a valid value
    hardware.sysctl = {'kern.boottime': '1515151515'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1515151515)

    # Test case 2: sysctl returns an invalid value
    hardware.sysctl = {'kern.boottime': 'invalid'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts == {}

# Generated at 2022-06-17 00:28:55.167510
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector._platform == 'OpenBSD'
    assert hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:28:59.822756
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:29:05.330308
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1', 'sd2']}



# Generated at 2022-06-17 00:29:15.018339
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.module.run_command = MagicMock(return_value=(0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', ''))
    memory_facts

# Generated at 2022-06-17 00:29:22.113011
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # Create a instance of class OpenBSDHardwareCollector
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    # Check if the instance is created successfully
    assert openbsd_hardware_collector is not None
    # Check if the instance is created successfully
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    # Check if the instance is created successfully
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:29:27.125074
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '1565495973', ''))
    hardware = OpenBSDHardware(module)
    assert hardware.get_uptime_facts() == {'uptime_seconds': 1565495973}


# Generated at 2022-06-17 00:29:34.348807
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '536870912'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.module.run_command = MagicMock(return_value=(0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', ''))
    memory_facts

# Generated at 2022-06-17 00:29:42.939279
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824', 'hw.ncpuonline': '1'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0 47512 28160 51 0 0 0 0 0 1 0 116 89 17 0 1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert memory_facts['swapfree_mb'] == 69268 // 1024
    assert memory_facts['swaptotal_mb'] == 69268 // 1024


# Generated at 2022-06-17 00:29:44.932359
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:31:50.882841
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    facts = hardware.populate()

# Generated at 2022-06-17 00:31:53.477266
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 15


# Generated at 2022-06-17 00:31:58.157838
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector.platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:32:00.744499
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:32:12.885490
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.product': 'OpenBSD',
                       'hw.version': '6.0',
                       'hw.uuid': '00000000-0000-0000-0000-000000000000',
                       'hw.serialno': '',
                       'hw.vendor': 'OpenBSD'}
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'OpenBSD'
    assert dmi_facts['product_version'] == '6.0'
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert dmi_facts['product_serial'] == ''