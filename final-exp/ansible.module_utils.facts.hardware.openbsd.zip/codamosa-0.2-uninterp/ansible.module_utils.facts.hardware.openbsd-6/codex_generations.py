

# Generated at 2022-06-17 00:22:05.553437
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1528594739'}
    assert hardware.get_uptime_facts() == {'uptime_seconds': int(time.time() - 1528594739)}

# Generated at 2022-06-17 00:22:15.354124
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices'] == ['wd0', 'wd1', 'sd0', 'sd1', 'cd0', 'cd1']
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz']
    assert hardware.facts['processor_cores'] == '4'
    assert hardware.facts['processor_count'] == '4'
    assert hardware.facts['memtotal_mb'] == '16384'
    assert hardware.facts['memfree_mb'] == '15862'
    assert hardware.facts['swaptotal_mb'] == '2047'
    assert hardware.facts['swapfree_mb'] == '2047'
   

# Generated at 2022-06-17 00:22:17.258496
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:22:24.541821
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:22:34.354656
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28
    assert memory_facts['memtotal_mb'] == 1024
    hardware

# Generated at 2022-06-17 00:22:41.268623
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hardware = OpenBSDHardware(module)
    facts = hardware.get_dmi_facts()
    assert facts['product_name'] == 'OpenBSD.amd64'
    assert facts['product_version'] == '6.0'
    assert facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert facts['product_serial'] == 'None'
    assert facts['system_vendor'] == 'OpenBSD'



# Generated at 2022-06-17 00:22:51.061186
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)

    # Test with a valid kern.boottime
    hardware.sysctl = {'kern.boottime': '1547141452'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1547141452)

    # Test with an invalid kern.boottime
    hardware.sysctl = {'kern.boottime': 'invalid'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts == {}

    # Test with a missing kern.boottime
    hardware.sysctl = {}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_

# Generated at 2022-06-17 00:23:01.080842
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = OpenBSDHardware(module).populate()

# Generated at 2022-06-17 00:23:11.141335
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz', 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'



# Generated at 2022-06-17 00:23:13.488630
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector.platform == 'OpenBSD'
    assert hardware_collector.fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:23:28.840749
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0



# Generated at 2022-06-17 00:23:38.496902
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0 47512 28160 51 0 0 0 0 0 1 0 116 89 17 0 1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 27
    assert memory_facts['memtotal_mb'] == 1024
    hardware.module.run_command = MagicMock(return_value=(0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['swapfree_mb'] == 67

# Generated at 2022-06-17 00:23:45.174376
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'}
    facts = hardware.get_processor_facts()
    assert facts['processor'] == ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz', 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz']
    assert facts['processor_count'] == '2'
    assert facts['processor_cores'] == '2'



# Generated at 2022-06-17 00:23:50.102405
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1518470117'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1518470117)

# Generated at 2022-06-17 00:24:01.552395
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = OpenBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices'] == ['wd0', 'wd1', 'sd0', 'sd1']
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 7984
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['processor_cores'] == '4'
    assert hardware.facts['processor_count'] == '4'
    assert hardware.facts['product_name'] == 'MacBookPro11,1'


# Generated at 2022-06-17 00:24:08.508116
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware
    assert openbsd_hardware_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 00:24:19.004975
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    rc, out, err = module.run_command("/usr/bin/vmstat")
    hardware.module.run_command = Mock(return_value=(rc, out, err))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1 // 1024 // 1024
    rc, out, err = module.run_command("/sbin/swapctl -sk")
    hardware.module.run_command = Mock(return_value=(rc, out, err))
    memory_facts = hardware.get_memory_facts()

# Generated at 2022-06-17 00:24:27.573140
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert memory_facts['swapfree_mb'] == 69268 // 1024
    assert memory_facts['swaptotal_mb'] == 69268 // 1024

# Generated at 2022-06-17 00:24:35.745335
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    hardware = OpenBSDHardware(dict())
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == 2
    assert processor_facts['processor_cores'] == 2


# Generated at 2022-06-17 00:24:40.962180
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1', 'sd2']}


# Generated at 2022-06-17 00:25:07.385809
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '4',
                       'hw.model': 'Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz'] * 4
    assert processor_facts['processor_count'] == '4'
    assert processor_facts['processor_cores'] == '4'


# Generated at 2022-06-17 00:25:18.910488
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28
    assert memory_facts['memtotal_mb'] == 1024

#

# Generated at 2022-06-17 00:25:22.637062
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    """
    Test OpenBSDHardwareCollector class.
    """
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector.platform == 'OpenBSD'
    assert hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:25:31.571569
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz', 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:25:38.297197
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1', 'sd2']}



# Generated at 2022-06-17 00:25:45.572471
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '2147483648',
                       'hw.physmem': '2147483648'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.get_memory_facts()
    assert hardware.facts['memfree_mb'] == 28160 // 1024
    assert hardware.facts['memtotal_mb'] == 2147483648 // 1024 // 1024
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0



# Generated at 2022-06-17 00:25:50.750550
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:25:58.209186
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1517963084'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1517963084)

# Generated at 2022-06-17 00:26:03.760202
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:26:15.567045
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.ncpuonline': '2'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert memory_facts['swapfree_mb'] == 69268 // 1024

# Generated at 2022-06-17 00:27:02.126589
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1']}

# Generated at 2022-06-17 00:27:13.553294
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.module.run_command = MagicMock(return_value=(0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', ''))
    memory_facts

# Generated at 2022-06-17 00:27:22.610976
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()

# Generated at 2022-06-17 00:27:24.436374
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.get_uptime_facts()

# Generated at 2022-06-17 00:27:29.596245
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1501082136'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1501082136)

# Generated at 2022-06-17 00:27:40.433849
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {
        'hw.product': 'OpenBSD',
        'hw.version': '6.1',
        'hw.uuid': '00000000-0000-0000-0000-000000000000',
        'hw.serialno': '0',
        'hw.vendor': 'OpenBSD',
    }
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'OpenBSD'
    assert dmi_facts['product_version'] == '6.1'
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert dmi_facts['product_serial'] == '0'
    assert dmi_facts

# Generated at 2022-06-17 00:27:43.089752
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:27:48.645257
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 107

# Generated at 2022-06-17 00:27:55.314108
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:28:04.750076
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.product': 'OpenBSD',
                       'hw.version': '6.1',
                       'hw.uuid': '00000000-0000-0000-0000-000000000000',
                       'hw.serialno': '0',
                       'hw.vendor': 'OpenBSD'}
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'OpenBSD'
    assert dmi_facts['product_version'] == '6.1'
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert dmi_facts['product_serial'] == '0'

# Generated at 2022-06-17 00:28:57.072803
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware_facts = hardware.populate()

# Generated at 2022-06-17 00:29:04.984674
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = OpenBSDHardware(module)
    hardware.populate()
    assert hardware.sysctl['hw.ncpuonline'] == '2'
    assert hardware.sysctl['hw.usermem'] == '8589934592'
    assert hardware.sysctl['hw.model'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert hardware.sysctl['hw.disknames'] == 'wd0,wd1'
    assert hardware.sysctl['hw.product'] == 'MacBookPro11,1'
    assert hardware.sysctl['hw.version'] == '1.0'
    assert hardware.sysctl['hw.uuid'] == 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX'

# Generated at 2022-06-17 00:29:14.788875
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware_facts = hardware.populate()

# Generated at 2022-06-17 00:29:24.096890
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = OpenBSDHardwareCollector(module=module)
    hardware_collector.collect()
    hardware_facts = hardware_collector.get_facts()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor']
    assert hardware_facts['devices']
    assert hardware_facts['product_name']
    assert hardware_facts['product_version']

# Generated at 2022-06-17 00:29:32.326911
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.ncpuonline': '2'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0 47512 28160 51 0 0 0 0 0 1 0 116 89 17 0 1 99', ''))
    hardware.get_memory_facts()
    assert hardware.facts['memfree_mb'] == 28160 // 1024
    assert hardware.facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert hardware.facts['swapfree_mb'] == 69268 // 1024
    assert hardware.facts['swaptotal_mb'] == 69268 // 1024


# Generated at 2022-06-17 00:29:41.948536
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz', 'Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:29:51.866581
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\n  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 27
    assert memory_facts['memtotal_mb'] == 1024

# Generated at 2022-06-17 00:29:59.032236
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz', 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:30:02.773824
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['swapfree_mb'] == 69268
    assert memory_facts['swaptotal_mb'] == 69268


# Generated at 2022-06-17 00:30:05.957556
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1']}


# Generated at 2022-06-17 00:31:11.389648
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz',
                                            'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'



# Generated at 2022-06-17 00:31:17.086667
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1512078984'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1512078984)


# Generated at 2022-06-17 00:31:20.008748
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector.platform == 'OpenBSD'
    assert hardware_collector.fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:31:30.829447
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()

# Generated at 2022-06-17 00:31:35.584858
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1536450045'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1536450045)

# Generated at 2022-06-17 00:31:41.564916
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '1', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == '1'
    assert processor_facts['processor_cores'] == '1'



# Generated at 2022-06-17 00:31:46.414789
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    device_facts = hardware.get_device_facts()
    assert device_facts['devices'] == ['sd0', 'sd1', 'sd2']



# Generated at 2022-06-17 00:31:57.336471
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_speed'] > 0
    assert hardware_facts['processor']
    assert hardware_facts['devices']
    assert hardware_facts['product_name']
    assert hardware_facts['product_version']
    assert hardware_facts['product_uuid']
   