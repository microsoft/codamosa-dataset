

# Generated at 2022-06-17 00:22:14.312600
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = OpenBSDHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]

# Generated at 2022-06-17 00:22:23.721457
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz', 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:22:34.294809
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '4',
                       'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_

# Generated at 2022-06-17 00:22:43.197535
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz'}
    facts = hardware.get_processor_facts()
    assert facts['processor'] == ['Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz', 'Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz']
    assert facts['processor_count'] == 2
    assert facts['processor_cores'] == 2


# Generated at 2022-06-17 00:22:51.971692
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = OpenBSDHardwareCollector(module=module)
    hardware_collector.populate()
    hardware = hardware_collector.get_facts()
    assert hardware['devices']
    assert hardware['mounts']
    assert hardware['memfree_mb']
    assert hardware['memtotal_mb']
    assert hardware['swapfree_mb']
    assert hardware['swaptotal_mb']
    assert hardware['uptime_seconds']
    assert hardware['processor']
    assert hardware['processor_cores']
    assert hardware['processor_count']
    assert hardware['product_name']
    assert hardware['product_serial']
    assert hardware['product_uuid']
    assert hardware['system_vendor']
    assert hardware['product_version']

# Generated at 2022-06-17 00:22:52.973355
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    OpenBSDHardwareCollector()

# Generated at 2022-06-17 00:22:58.190163
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:23:06.428378
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()


# Generated at 2022-06-17 00:23:11.592201
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1']}


# Generated at 2022-06-17 00:23:12.243161
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    OpenBSDHardwareCollector()

# Generated at 2022-06-17 00:23:30.681141
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = MockModule()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = '/usr/bin/sysctl'
    module.get_file_content.return_value = 'hw.ncpuonline: 2\nhw.model: Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'

    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}

    cpu_facts = hardware.get_processor_facts()


# Generated at 2022-06-17 00:23:40.010241
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.product': 'OpenBSD',
                       'hw.version': '6.3',
                       'hw.uuid': '00000000-0000-0000-0000-000000000000',
                       'hw.serialno': '',
                       'hw.vendor': 'OpenBSD'}
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'OpenBSD'
    assert dmi_facts['product_version'] == '6.3'
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert dmi_facts['product_serial'] == ''

# Generated at 2022-06-17 00:23:46.050495
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    # Create a fake module
    fake_module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, '', ''),
        'get_bin_path': lambda *args, **kwargs: '/sbin/sysctl',
    })()

    # Create a fake sysctl
    fake_sysctl = {
        'hw.product': 'OpenBSD',
        'hw.version': '6.3',
        'hw.uuid': '00000000-0000-0000-0000-000000000000',
        'hw.serialno': '1234567890',
        'hw.vendor': 'OpenBSD Foundation',
    }

    # Create a fake OpenBSDHardware object
    fake_OpenBSDHardware = OpenBSDHardware(fake_module)
    fake_OpenBSDHardware.sysctl

# Generated at 2022-06-17 00:23:57.997341
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {
        'hw.product': 'OpenBSD',
        'hw.version': '6.2',
        'hw.uuid': '00000000-0000-0000-0000-000000000000',
        'hw.serialno': '',
        'hw.vendor': 'OpenBSD',
    }
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'OpenBSD'
    assert dmi_facts['product_version'] == '6.2'
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert dmi_facts['product_serial'] == ''

# Generated at 2022-06-17 00:24:02.661338
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '1517897000', ''))
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1517897000)

# Generated at 2022-06-17 00:24:14.158080
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.ncpuonline': '1'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.get_memory_facts()
    assert hardware.facts['memfree_mb'] == 28160 // 1024
    assert hardware.facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0


# Generated at 2022-06-17 00:24:22.480941
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = OpenBSDHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]

    assert hardware.memfree_mb == hardware.memtotal_mb
    assert hardware.swapfree_mb == hardware.swaptotal_mb
    assert hardware.processor_count == hardware.processor_cores
    assert hardware.uptime_seconds > 0

    assert hardware.devices
    assert hardware.mounts

    assert hardware.product_name
    assert hardware.product_version
    assert hardware.product_uuid
    assert hardware.product_serial
    assert hardware.system_vendor



# Generated at 2022-06-17 00:24:35.065237
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'procs    memory       page                    disks    traps          cpu\n'
                                          'r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n'
                                          '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', '')
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024

# Generated at 2022-06-17 00:24:44.167789
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {
        'hw.product': 'OpenBSD',
        'hw.version': '6.3',
        'hw.uuid': '00000000-0000-0000-0000-000000000000',
        'hw.serialno': '',
        'hw.vendor': 'OpenBSD',
    }
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'OpenBSD'
    assert dmi_facts['product_version'] == '6.3'
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert dmi_facts['product_serial'] == ''

# Generated at 2022-06-17 00:24:53.484629
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = OpenBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == '2'
    assert hardware.facts['processor_cores'] == '2'
    assert hardware.facts['processor_speed'] == '0'
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['memtotal_mb'] == '16384'
    assert hardware.facts['memfree_mb'] == '13894'
    assert hardware.facts['swaptotal_mb'] == '8192'
    assert hardware.facts['swapfree_mb'] == '8192'

# Generated at 2022-06-17 00:25:13.333396
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:25:19.063478
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1515151515'}
    assert hardware.get_uptime_facts() == {'uptime_seconds': int(time.time() - 1515151515)}

# Generated at 2022-06-17 00:25:26.121302
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz', 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz']
    assert processor_facts['processor_count'] == 2
    assert processor_facts['processor_cores'] == 2


# Generated at 2022-06-17 00:25:33.504718
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()

# Generated at 2022-06-17 00:25:36.213135
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1', 'sd2']}



# Generated at 2022-06-17 00:25:41.669159
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:25:49.197084
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.module.run_command = MagicMock(return_value=(0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', ''))
    memory_facts

# Generated at 2022-06-17 00:25:58.498589
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['swapfree_mb'] == 69268
    assert memory_facts['swaptotal_mb'] == 69268


# Generated at 2022-06-17 00:26:05.540539
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    from ansible.module_utils.facts.utils import get_file_content

    # Mock the sysctl command
    def mock_run_command(self, cmd):
        return 0, 'kern.boottime: 1470994400', ''

    OpenBSDHardware.run_command = mock_run_command

    # Mock the time.time() function
    def mock_time():
        return 1470994400

    time.time = mock_time

    # Create an instance of OpenBSDHardware
    hardware = OpenBSDHardware(None)

    # Call the get_uptime_facts method
    uptime_facts = hardware.get_uptime_facts()

    # Assert that the uptime_seconds fact is correct

# Generated at 2022-06-17 00:26:14.251526
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '1', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == '1'
    assert processor_facts['processor_cores'] == '1'



# Generated at 2022-06-17 00:26:50.070548
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector._platform == 'OpenBSD'
    assert hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:26:56.761487
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1', 'sd2']}


# Generated at 2022-06-17 00:27:05.931104
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.populate()

# Generated at 2022-06-17 00:27:12.884757
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.module.run_command = MagicMock(return_value=(0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', ''))
    memory_facts

# Generated at 2022-06-17 00:27:21.798373
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.ncpuonline': '1'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert memory_facts['swapfree_mb'] == 69268 // 1024

# Generated at 2022-06-17 00:27:22.611398
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    OpenBSDHardwareCollector()

# Generated at 2022-06-17 00:27:32.535925
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.ncpuonline': '2'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\n'
                                                             'r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n'
                                                             '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n', ''))

# Generated at 2022-06-17 00:27:35.837286
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:27:44.181192
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz',
                                            'Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz']
    assert processor_facts['processor_count'] == 2
    assert processor_facts['processor_cores'] == 2


# Generated at 2022-06-17 00:27:53.826430
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\n'
                                                              'r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n'
                                                              '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28
   

# Generated at 2022-06-17 00:29:18.486051
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()
    assert hardware_obj.sysctl['hw.ncpuonline'] == '2'
    assert hardware_obj.sysctl['hw.usermem'] == '8589934592'
    assert hardware_obj.sysctl['hw.model'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'

# Generated at 2022-06-17 00:29:29.618324
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'hw.ncpuonline: 2', '')
    module.get_bin_path.return_value = '/sbin/sysctl'
    module.params = {}
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz', 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz']

# Generated at 2022-06-17 00:29:41.214326
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:29:44.407947
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {
        'kern.boottime': '1527078981',
    }
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1527078981)

# Generated at 2022-06-17 00:29:56.451213
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    hardware.module.run_command = MagicMock(return_value=(0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', ''))
    memory_

# Generated at 2022-06-17 00:30:05.014878
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = MockModule()
    hardware = OpenBSDHardware(module)
    hardware.populate()
    assert hardware.sysctl['hw.ncpuonline'] == '1'
    assert hardware.sysctl['hw.usermem'] == '8589934592'
    assert hardware.sysctl['hw.model'] == 'Intel(R) Core(TM) i7-4770 CPU @ 3.40GHz'
    assert hardware.sysctl['hw.disknames'] == 'wd0'


# Generated at 2022-06-17 00:30:11.450912
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    devices = hardware.get_device_facts()
    assert devices['devices'] == ['sd0', 'sd1', 'sd2']


# Generated at 2022-06-17 00:30:20.005362
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()
    assert hardware_obj.sysctl['hw.ncpuonline'] == '1'
    assert hardware_obj.sysctl['hw.usermem'] == '8589934592'
    assert hardware_obj.sysctl['hw.model'] == 'Genuine Intel(R) CPU T2080 @ 1.73GHz'
    assert hardware_obj.sysctl['hw.disknames'] == 'wd0'
    assert hardware_obj.sysctl['hw.product'] == 'OpenBSD.amd64'
    assert hardware_obj.sysctl['hw.version'] == '#1'
    assert hardware_obj.sysctl['hw.uuid'] == '00000000-0000-0000-0000-000000000000'
   

# Generated at 2022-06-17 00:30:29.564188
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = MockModule()
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    module.run_command.return_value = (0, 'procs    memory       page                    disks    traps          cpu\n'
                                           'r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n'
                                           '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n', '')
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 27

# Generated at 2022-06-17 00:30:32.377125
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware
