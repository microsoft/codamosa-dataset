

# Generated at 2022-06-17 00:22:11.243734
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0



# Generated at 2022-06-17 00:22:23.820347
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware_facts = hardware.populate()

# Generated at 2022-06-17 00:22:30.922862
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '1558246843', ''))
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1558246843)

# Generated at 2022-06-17 00:22:43.480693
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert memory_facts['swapfree_mb'] == 69268 // 1024
    assert memory_facts['swaptotal_mb'] == 69268 // 1024


# Generated at 2022-06-17 00:22:52.200736
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.ncpuonline': '1'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert memory_facts['swapfree_mb'] == 69268 // 1024

# Generated at 2022-06-17 00:23:01.876604
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.populate()
    assert hardware.sysctl['hw.ncpuonline'] == '1'
    assert hardware.sysctl['hw.usermem'] == '20971520'
    assert hardware.sysctl['hw.model'] == 'Genuine Intel(R) CPU T2050 @ 1.60GHz'
    assert hardware.sysctl['hw.disknames'] == 'wd0'


# Generated at 2022-06-17 00:23:09.405775
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28
    assert memory_facts['memtotal_mb'] == 1024

#

# Generated at 2022-06-17 00:23:17.594284
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor']
    assert hardware_facts['devices']
    assert hardware_facts['mounts']
    assert hardware_facts['product_name']
    assert hardware_facts['product_version']
    assert hardware_facts['product_uuid']
    assert hardware_

# Generated at 2022-06-17 00:23:29.914329
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i5-4300U CPU @ 1.90GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i5-4300U CPU @ 1.90GHz',
                                            'Intel(R) Core(TM) i5-4300U CPU @ 1.90GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:23:32.915505
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector.platform == 'OpenBSD'
    assert hardware_collector.fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:23:40.606851
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hw_collector = OpenBSDHardwareCollector()
    assert openbsd_hw_collector._platform == 'OpenBSD'
    assert openbsd_hw_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:23:43.957048
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.module.run_command = MagicMock(return_value=(0, '1557237893', ''))
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1557237893)

# Generated at 2022-06-17 00:23:55.424588
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.get_memory_facts()
    assert hardware.facts['memfree_mb'] == 28160 // 1024
    assert hardware.facts['memtotal_mb'] == 1073741824 // 1024 // 1024

# Generated at 2022-06-17 00:24:04.760088
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.product': 'OpenBSD',
                       'hw.version': '6.0',
                       'hw.uuid': '00000000-0000-0000-0000-000000000000',
                       'hw.serialno': '000000000000',
                       'hw.vendor': 'OpenBSD'}
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'OpenBSD'
    assert dmi_facts['product_version'] == '6.0'
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert dmi_facts['product_serial'] == '000000000000'

# Generated at 2022-06-17 00:24:10.041995
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1', 'sd2']}



# Generated at 2022-06-17 00:24:21.752251
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    # Test data
    sysctl_output = {
        'hw.product': 'OpenBSD',
        'hw.version': '6.3',
        'hw.uuid': '00000000-0000-0000-0000-000000000000',
        'hw.serialno': '000000000000',
        'hw.vendor': 'OpenBSD',
    }

    # Create instance of OpenBSDHardware
    openbsd_hardware = OpenBSDHardware(dict(), dict())
    openbsd_hardware.sysctl = sysctl_output

    # Call method get_dmi_facts of class OpenBSDHardware
    dmi_facts = openbsd_hardware.get_dmi_facts()

    # Assert that the expected dmi facts are present
    assert dmi_facts['product_name'] == 'OpenBSD'

# Generated at 2022-06-17 00:24:28.867874
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    """
    Constructor of class OpenBSDHardwareCollector should set the
    _fact_class attribute to OpenBSDHardware.
    """
    openbsd_hw_collector = OpenBSDHardwareCollector()
    assert openbsd_hw_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:24:41.019588
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()
    assert hardware_obj.sysctl['hw.ncpuonline'] == '1'
    assert hardware_obj.sysctl['hw.usermem'] == '1073741824'
    assert hardware_obj.sysctl['hw.model'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert hardware_obj.sysctl['hw.disknames'] == 'wd0'
    assert hardware_obj.sysctl['hw.product'] == 'MacBookPro11,3'
    assert hardware_obj.sysctl['hw.version'] == '1.0'

# Generated at 2022-06-17 00:24:47.217006
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'



# Generated at 2022-06-17 00:24:54.905080
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.sysctl import get_sysctl
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.base import Hardware, HardwareCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.platform import Platform
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
   

# Generated at 2022-06-17 00:25:05.626547
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1523207501'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1523207501)

# Generated at 2022-06-17 00:25:13.494401
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()
    assert hardware_obj.sysctl['hw.ncpuonline'] == '2'
    assert hardware_obj.sysctl['hw.usermem'] == '8589934592'
    assert hardware_obj.sysctl['hw.model'] == 'Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz'
    assert hardware_obj.sysctl['hw.disknames'] == 'wd0,wd1'
    assert hardware_obj.sysctl['hw.product'] == 'MacBookPro11,1'
    assert hardware_obj.sysctl['hw.version'] == '1.0'

# Generated at 2022-06-17 00:25:21.270545
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, '1501331216', ''))
    hardware = OpenBSDHardware(module)
    assert hardware.get_uptime_facts() == {'uptime_seconds': 1501331216}


# Generated at 2022-06-17 00:25:31.236408
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:25:36.839750
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)

    # Mock the sysctl command
    def mock_run_command(cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return 0, "kern.boottime=1501245813", ""

    hardware.module.run_command = mock_run_command

    # Call the method
    uptime_facts = hardware.get_uptime_facts()

    # Assert that the method returns the expected value
    assert uptime_facts == {'uptime_seconds': int(time.time() - 1501245813)}



# Generated at 2022-06-17 00:25:41.204157
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1517969948'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1517969948)

# Generated at 2022-06-17 00:25:42.970987
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector.platform == 'OpenBSD'
    assert hardware_collector.fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:25:49.511726
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.module.run_command = MagicMock(return_value=(0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', ''))
    memory_facts

# Generated at 2022-06-17 00:25:57.663300
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1530371815'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1530371815)

# Generated at 2022-06-17 00:26:04.950110
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '1535791561', ''))
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts == {'uptime_seconds': int(time.time() - 1535791561)}


# Generated at 2022-06-17 00:26:24.620926
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()
    assert hardware_obj.sysctl['hw.ncpuonline'] == '2'
    assert hardware_obj.sysctl['hw.usermem'] == '8589934592'
    assert hardware_obj.sysctl['hw.model'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert hardware_obj.sysctl['hw.disknames'] == 'wd0,wd1'
    assert hardware_obj.sysctl['hw.product'] == 'MacBookPro11,1'
    assert hardware_obj.sysctl['hw.version'] == '1.0'

# Generated at 2022-06-17 00:26:34.850065
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()

# Generated at 2022-06-17 00:26:44.249735
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\n  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28
    assert memory_facts['memtotal_mb']

# Generated at 2022-06-17 00:26:55.973530
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.module.run_command = MagicMock(return_value=(0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', ''))
    memory_facts

# Generated at 2022-06-17 00:27:02.993289
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1517095197'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1517095197)

# Generated at 2022-06-17 00:27:14.036758
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()

# Generated at 2022-06-17 00:27:17.015979
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:27:20.673151
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware
    assert openbsd_hardware_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 00:27:22.994728
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    hardware = OpenBSDHardware()
    hardware.sysctl = {'hw.disknames': 'sd0,sd1'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1']}

# Generated at 2022-06-17 00:27:32.018362
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'



# Generated at 2022-06-17 00:28:17.956746
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1527946688'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1527946688)

# Generated at 2022-06-17 00:28:26.356376
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz', 'Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:28:38.485530
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices'] == ['wd0', 'wd1']
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz']
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 4
    assert hardware.facts['system_vendor'] == 'Apple Inc.'

# Generated at 2022-06-17 00:28:41.070564
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # Test for constructor of class OpenBSDHardwareCollector
    obj = OpenBSDHardwareCollector()
    assert obj.platform == 'OpenBSD'
    assert obj.fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:28:54.287853
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\n  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024

# Generated at 2022-06-17 00:29:00.580749
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '151234', ''))
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 151234)

# Generated at 2022-06-17 00:29:11.627459
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                       'hw.ncpuonline': '4'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_

# Generated at 2022-06-17 00:29:22.459564
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824', 'hw.ncpuonline': '1'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.module.get_bin_path = MagicMock(return_value='/sbin/swapctl')
    hardware.module.run

# Generated at 2022-06-17 00:29:26.955632
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1535441379'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1535441379)

# Generated at 2022-06-17 00:29:34.243718
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    """
    Test get_dmi_facts method of class OpenBSDHardware.
    """
    class MockModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=(0, '', ''))
            self.get_bin_path = Mock(return_value='/usr/bin/sysctl')

    class MockOpenBSDHardware(OpenBSDHardware):
        def __init__(self):
            self.module = MockModule()
            self.sysctl = {'hw.product': 'OpenBSD',
                           'hw.version': '6.2',
                           'hw.uuid': '00000000-0000-0000-0000-000000000000',
                           'hw.serialno': '000000000000',
                           'hw.vendor': 'OpenBSD'}


# Generated at 2022-06-17 00:31:21.563595
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1528787935'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:31:30.908865
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.product': 'OpenBSD',
                       'hw.version': '6.0',
                       'hw.uuid': '00000000-0000-0000-0000-000000000000',
                       'hw.serialno': '00000000',
                       'hw.vendor': 'OpenBSD'}
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'OpenBSD'
    assert dmi_facts['product_version'] == '6.0'
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert dmi_facts['product_serial'] == '00000000'

# Generated at 2022-06-17 00:31:40.184461
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['devices'] == ['wd0', 'cd0', 'sd0']
    assert hardware_facts['memtotal_mb'] == hardware_facts['memfree_mb'] + hardware_facts['swaptotal_mb'] + hardware_facts['swapfree_mb']
    assert hardware_facts['processor_count'] == hardware_facts['processor_cores']
    assert hardware_facts['processor'] == ['Intel(R) Core(TM) i7-3667U CPU @ 2.00GHz']
    assert hardware_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:31:43.945616
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '1537494583', ''))
    hardware = OpenBSDHardware(module)
    assert hardware.get_uptime_facts() == {'uptime_seconds': int(time.time() - 1537494583)}

# Generated at 2022-06-17 00:31:53.805960
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = OpenBSDHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]