

# Generated at 2022-06-17 00:22:11.004202
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    obj = OpenBSDHardwareCollector()
    assert obj.platform == 'OpenBSD'
    assert obj.fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:22:18.859283
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1']}



# Generated at 2022-06-17 00:22:30.105856
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()
    assert hardware_obj.sysctl['hw.ncpuonline'] == '1'
    assert hardware_obj.sysctl['hw.usermem'] == '8589934592'
    assert hardware_obj.sysctl['hw.model'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert hardware_obj.sysctl['hw.disknames'] == 'sd0'
    assert hardware_obj.sysctl['hw.vendor'] == 'Intel'
    assert hardware_obj.sysctl['hw.product'] == 'MacBookPro11,3'
    assert hardware_obj.sysctl['hw.version'] == '1.0'
    assert hardware

# Generated at 2022-06-17 00:22:35.567765
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector._fact_class == OpenBSDHardware
    assert hardware_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 00:22:44.187214
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = MockModule()
    module.run_command.return_value = (0, 'hw.ncpuonline: 2', '')
    module.get_bin_path.return_value = '/sbin/sysctl'
    module.get_file_content.return_value = 'hw.model: Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz'
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz'}
    cpu_facts = hardware.get_processor_facts()

# Generated at 2022-06-17 00:22:49.280755
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.module.run_command = MagicMock(return_value=(0, '1520287068', ''))
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1520287068)

# Generated at 2022-06-17 00:22:59.413941
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = OpenBSDHardware(module).populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor']
    assert hardware_facts['devices']
    assert hardware_facts['mounts']


# Generated at 2022-06-17 00:23:04.995242
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hw_collector = OpenBSDHardwareCollector()
    assert openbsd_hw_collector._platform == 'OpenBSD'
    assert openbsd_hw_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:23:15.407825
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)


# Generated at 2022-06-17 00:23:18.446262
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    module = AnsibleModule(argument_spec={})
    collector = OpenBSDHardwareCollector(module=module)
    assert collector.platform == 'OpenBSD'
    assert collector.fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:23:35.890642
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] == int(time.time() - int(hardware_facts['boottime']))
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_seconds'] < 100000000
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_speed'] > 0

# Generated at 2022-06-17 00:23:41.833007
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.get_memory_facts()
    assert hardware.memfree_mb == 28160 // 1024
    assert hardware.memtotal_mb == 1073741824 // 1024 // 1024


# Generated at 2022-06-17 00:23:50.734004
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)

    hardware.sysctl = {'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz'}

    processor_facts = hardware.get_processor_facts()

    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz',
                                            'Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz']
    assert processor_facts['processor_cores'] == '2'
    assert processor_facts['processor_count'] == '2'


# Generated at 2022-06-17 00:24:01.009707
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i5-4200U CPU @ 1.60GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i5-4200U CPU @ 1.60GHz',
                                            'Intel(R) Core(TM) i5-4200U CPU @ 1.60GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'



# Generated at 2022-06-17 00:24:14.007733
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.ncpuonline': '1'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert memory_facts['swapfree_mb'] == 69268 // 1024

# Generated at 2022-06-17 00:24:19.981698
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.get_memory_facts()
    assert hardware.facts['memtotal_mb'] == 1024
    assert hardware.facts['memfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0


# Generated at 2022-06-17 00:24:23.341102
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'wd0,wd1'}
    assert hardware.get_device_facts() == {'devices': ['wd0', 'wd1']}


# Generated at 2022-06-17 00:24:27.333981
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector.platform == 'OpenBSD'
    assert hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:24:29.542496
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1514494766'}
    facts = hardware.get_uptime_facts()
    assert facts['uptime_seconds'] == int(time.time() - 1514494766)


# Generated at 2022-06-17 00:24:37.481481
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'hw.ncpuonline=2', '')
    module.get_bin_path.return_value = '/sbin/sysctl'
    module.get_file_content.return_value = 'hw.model=Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz'
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': 2, 'hw.model': 'Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz'}
    processor_facts = hardware.get_processor_facts()

# Generated at 2022-06-17 00:24:52.953745
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1488354984'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1488354984)

# Generated at 2022-06-17 00:25:04.282118
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz', 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz']
    assert processor_facts['processor_count'] == 2
    assert processor_facts['processor_cores'] == 2


# Generated at 2022-06-17 00:25:08.893533
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '1517098981', ''))
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1517098981)

# Generated at 2022-06-17 00:25:20.486660
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()

# Generated at 2022-06-17 00:25:31.936946
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['devices'] == ['wd0', 'cd0']
    assert hardware_obj.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware_obj.facts['processor_cores'] == '4'
    assert hardware_obj.facts['processor_count'] == '4'
    assert hardware_obj.facts['memtotal_mb'] == '8192'
    assert hardware_obj.facts['memfree_mb'] == '5'
    assert hardware_obj.facts['swaptotal_mb'] == '0'
    assert hardware_obj.facts['swapfree_mb'] == '0'
   

# Generated at 2022-06-17 00:25:35.080906
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    device_facts = hardware.get_device_facts()
    assert device_facts['devices'] == ['sd0', 'sd1', 'sd2']


# Generated at 2022-06-17 00:25:43.188513
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    test_module = type('test_module', (object,), {'run_command': lambda self, cmd: (0, 'hw.product=OpenBSD\nhw.version=6.1\nhw.uuid=\nhw.serialno=\nhw.vendor=OpenBSD\n', '')})()
    test_module.get_bin_path = lambda x: '/sbin/sysctl'
    test_OpenBSDHardware = OpenBSDHardware(test_module)
    assert test_OpenBSDHardware.get_dmi_facts() == {'product_name': 'OpenBSD', 'product_version': '6.1', 'product_uuid': '', 'product_serial': '', 'system_vendor': 'OpenBSD'}

# Generated at 2022-06-17 00:25:46.167852
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1513290569'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1513290569)

# Generated at 2022-06-17 00:25:48.682619
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    """
    Test OpenBSDHardwareCollector constructor
    """
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:25:56.295395
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1512341234'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1512341234)

# Generated at 2022-06-17 00:26:30.289309
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = OpenBSDHardware(module)
    hardware.populate()
    assert hardware.sysctl['hw.ncpuonline'] == '2'
    assert hardware.sysctl['hw.usermem'] == '8589934592'
    assert hardware.sysctl['hw.model'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'

# Generated at 2022-06-17 00:26:42.483066
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()
    assert hardware_obj.sysctl['hw.ncpuonline'] == '2'
    assert hardware_obj.sysctl['hw.usermem'] == '8589934592'
    assert hardware_obj.sysctl['hw.model'] == 'Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz'

# Generated at 2022-06-17 00:26:49.439464
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1', 'sd2']}



# Generated at 2022-06-17 00:26:56.065134
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hardware = OpenBSDHardware(module)
    assert hardware.get_device_facts() == {'devices': ['wd0', 'wd1', 'wd2']}


# Generated at 2022-06-17 00:27:03.088028
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = '/sbin/sysctl'
    module.get_file_content.return_value = ''
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count']

# Generated at 2022-06-17 00:27:06.589423
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware
    assert openbsd_hardware_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 00:27:11.901381
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:27:19.678783
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = OpenBSDHardware(module).populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor']
    assert hardware_facts['devices']
    assert hardware_facts['product_name']
    assert hardware_facts['product_version']
    assert hardware_facts['product_uuid']
    assert hardware_facts['product_serial']

# Generated at 2022-06-17 00:27:27.882760
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4790 CPU @ 3.60GHz'}
    assert hardware.get_processor_facts() == {'processor': ['Intel(R) Core(TM) i7-4790 CPU @ 3.60GHz', 'Intel(R) Core(TM) i7-4790 CPU @ 3.60GHz'], 'processor_count': '2', 'processor_cores': '2'}


# Generated at 2022-06-17 00:27:32.057021
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1', 'sd2']}


# Generated at 2022-06-17 00:29:03.994002
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.ncpuonline': '1'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.get_memory_facts()
    assert hardware.facts['memfree_mb'] == 27
    assert hardware.facts['memtotal_mb'] == 1024
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0


# Generated at 2022-06-17 00:29:11.626617
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)

    # Test with a valid uptime
    hardware.sysctl = {'kern.boottime': '1555555555'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1555555555)

    # Test with an invalid uptime
    hardware.sysctl = {'kern.boottime': 'invalid'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts == {}

# Generated at 2022-06-17 00:29:17.613196
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824', 'hw.ncpuonline': '2'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.get_memory_facts()
    assert hardware.facts['memfree_mb'] == 28160 // 1024
    assert hardware.facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0


# Generated at 2022-06-17 00:29:24.357302
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == 2
    assert processor_facts['processor_cores'] == 2


# Generated at 2022-06-17 00:29:32.855914
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.ncpuonline': '1'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28
    assert memory_

# Generated at 2022-06-17 00:29:37.449530
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector.platform == 'OpenBSD'
    assert hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:29:43.444554
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(rc=0, out='1537126589')
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1537126589)



# Generated at 2022-06-17 00:29:45.920602
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hw_collector = OpenBSDHardwareCollector()
    assert openbsd_hw_collector._platform == 'OpenBSD'
    assert openbsd_hw_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:29:52.441185
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '1234567890', ''))
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1234567890)


# Generated at 2022-06-17 00:29:58.236945
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.populate()
    assert hardware.sysctl['hw.ncpuonline'] == '2'
    assert hardware.sysctl['hw.usermem'] == '8589934592'
    assert hardware.sysctl['hw.model'] == 'Intel(R) Core(TM) i7-3667U CPU @ 2.00GHz'
    assert hardware.sysctl['hw.disknames'] == 'wd0,wd1'