

# Generated at 2022-06-17 00:22:10.733963
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1513168800'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1513168800)

# Generated at 2022-06-17 00:22:16.612075
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = OpenBSDHardwareCollector(module=module)
    hardware_facts = hardware_collector.collect()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor_speed'] > 0
    assert hardware_facts['processor']
    assert hardware_facts['devices']
    assert hardware_facts['product_name']
    assert hardware_facts['product_version']
    assert hardware_

# Generated at 2022-06-17 00:22:24.226539
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:22:34.324152
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.module.run_command = MagicMock(return_value=(0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', ''))
    memory_facts

# Generated at 2022-06-17 00:22:45.438167
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.product': 'OpenBSD',
                       'hw.version': '6.1',
                       'hw.uuid': '00000000-0000-0000-0000-000000000000',
                       'hw.serialno': '',
                       'hw.vendor': 'OpenBSD'}
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] == 'OpenBSD'
    assert dmi_facts['product_version'] == '6.1'
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert dmi_facts['product_serial'] == ''

# Generated at 2022-06-17 00:22:50.085156
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:22:53.848089
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:22:57.933678
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:23:01.058701
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector._fact_class == OpenBSDHardware
    assert hardware_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 00:23:12.177440
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.populate()
    assert hardware.sysctl
    assert hardware.facts['devices']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['uptime_seconds']
    assert hardware.facts['product_name']
    assert hardware.facts['product_version']
    assert hardware.facts['product_uuid']
    assert hardware.facts['product_serial']
    assert hardware.facts['system_vendor']

#

# Generated at 2022-06-17 00:23:30.367088
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\n  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28
    assert memory_facts['memtotal_mb']

# Generated at 2022-06-17 00:23:34.058946
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hw_collector = OpenBSDHardwareCollector()
    assert openbsd_hw_collector._platform == 'OpenBSD'
    assert openbsd_hw_collector._fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:23:40.868807
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1024


# Generated at 2022-06-17 00:23:46.498718
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.ncpuonline': '2'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.get_memory_facts()
    assert hardware.facts['memfree_mb'] == 28160 // 1024
    assert hardware.facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert hardware.facts['swapfree_mb'] == 69268 // 1024
    assert hardware.facts['swaptotal_mb'] == 69268 // 1024

# Generated at 2022-06-17 00:23:48.501846
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert OpenBSDHardwareCollector._platform == 'OpenBSD'
    assert OpenBSDHardwareCollector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:23:58.958894
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == 2
    assert processor_facts['processor_cores'] == 2


# Generated at 2022-06-17 00:24:03.908795
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.module.run_command = MagicMock(return_value=(0, '1495159938', ''))
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1495159938)


# Generated at 2022-06-17 00:24:08.805029
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:24:19.946496
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    test_sysctl = {
        'hw.product': 'OpenBSD',
        'hw.version': '6.1',
        'hw.uuid': '00000000-0000-0000-0000-000000000000',
        'hw.serialno': '000000000000',
        'hw.vendor': 'OpenBSD',
    }
    test_obj = OpenBSDHardware()
    test_obj.sysctl = test_sysctl
    dmi_facts = test_obj.get_dmi_facts()
    assert dmi_facts['product_name'] == 'OpenBSD'
    assert dmi_facts['product_version'] == '6.1'
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert dmi_facts['product_serial'] == '000000000000'

# Generated at 2022-06-17 00:24:23.818028
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.module.run_command = MagicMock(return_value=(0, '12345', ''))
    assert hardware.get_uptime_facts() == {'uptime_seconds': int(time.time() - 12345)}

# Generated at 2022-06-17 00:24:41.092394
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['devices'] == ['wd0', 'wd1']
    assert hardware_obj.facts['memtotal_mb'] == hardware_obj.facts['memfree_mb'] + hardware_obj.facts['swaptotal_mb']
    assert hardware_obj.facts['processor_count'] == hardware_obj.facts['processor_cores']
    assert hardware_obj.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware_obj.facts['processor_speed'] == '2200'
    assert hardware_obj.facts['product_name'] == 'MacBookPro11,1'

# Generated at 2022-06-17 00:24:52.846826
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = OpenBSDHardwareCollector(module=module)
    hardware_collector.populate()
    hardware = hardware_collector.get_facts()
    assert hardware['uptime_seconds'] > 0
    assert hardware['memtotal_mb'] > 0
    assert hardware['memfree_mb'] > 0
    assert hardware['swaptotal_mb'] > 0
    assert hardware['swapfree_mb'] > 0
    assert hardware['processor_count'] > 0
    assert hardware['processor_cores'] > 0
    assert hardware['processor_speed'] > 0
    assert hardware['devices']
    assert hardware['mounts']
    assert hardware['product_name']
    assert hardware['product_version']
    assert hardware['product_uuid']

# Generated at 2022-06-17 00:25:04.146709
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)

    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    hardware.module.run_command = MagicMock(return_value=(0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', ''))

    memory_facts

# Generated at 2022-06-17 00:25:07.032834
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hw_collector = OpenBSDHardwareCollector()
    assert openbsd_hw_collector._platform == 'OpenBSD'
    assert openbsd_hw_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:25:08.920066
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector._fact_class == OpenBSDHardware
    assert hardware_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 00:25:20.511060
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {
        'hw.ncpuonline': '4',
        'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
    }
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']


# Generated at 2022-06-17 00:25:31.966662
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()
    assert hardware_obj.sysctl['hw.ncpuonline'] == '2'
    assert hardware_obj.sysctl['hw.usermem'] == '8589934592'
    assert hardware_obj.sysctl['hw.model'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert hardware_obj.sysctl['hw.disknames'] == 'wd0,wd1,wd2,wd3,wd4,wd5,wd6,wd7,wd8,wd9,wd10,wd11,wd12,wd13,wd14,wd15'

# Generated at 2022-06-17 00:25:35.110577
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1524122834'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1524122834)

# Generated at 2022-06-17 00:25:38.588866
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1501240920'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1501240920)

# Generated at 2022-06-17 00:25:46.242702
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '1570781594', ''))
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1570781594)


# Generated at 2022-06-17 00:26:10.745422
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\n'
                                                              'r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n'
                                                              '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28
   

# Generated at 2022-06-17 00:26:17.110315
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-17 00:26:24.539807
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    hardware.module.run_command = MagicMock(return_value=(0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', ''))
    memory_

# Generated at 2022-06-17 00:26:29.196783
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hw = OpenBSDHardwareCollector()
    assert hw.platform == 'OpenBSD'
    assert hw.fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:26:36.253540
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor_speed'] > 0
    assert hardware_facts['devices']
    assert hardware_facts['mounts']
    assert hardware_facts['product_name']
    assert hardware_facts['product_version']
    assert hardware_facts['product_uuid']


# Generated at 2022-06-17 00:26:42.307050
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, '1512087200', ''))
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1512087200)

# Generated at 2022-06-17 00:26:48.739961
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert OpenBSDHardwareCollector._platform == 'OpenBSD'
    assert OpenBSDHardwareCollector._fact_class == OpenBSDHardware
    assert OpenBSDHardwareCollector.platform == 'OpenBSD'
    assert OpenBSDHardwareCollector.fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:26:53.513854
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '1538879987', ''))
    hardware = OpenBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1538879987)

# Generated at 2022-06-17 00:26:56.886135
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector.platform == 'OpenBSD'
    assert openbsd_hardware_collector.fact_class == OpenBSDHardware


# Generated at 2022-06-17 00:27:00.383495
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    assert hardware.get_device_facts() == {'devices': ['sd0', 'sd1', 'sd2']}


# Generated at 2022-06-17 00:27:58.526090
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    hardware = OpenBSDHardware({'module_setup': True})
    hardware.sysctl = {'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:28:05.503264
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = OpenBSDHardwareCollector(module=module)
    hardware_collector.collect()
    hardware_facts = hardware_collector.get_facts()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor']
    assert hardware_facts['devices']
    assert hardware_facts['system_vendor']
    assert hardware_facts['product_name']
    assert hardware_facts

# Generated at 2022-06-17 00:28:09.098633
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1518894200'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1518894200)

# Generated at 2022-06-17 00:28:19.881942
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160 // 1024
    assert memory_facts['memtotal_mb'] == 1073741824 // 1024 // 1024
    assert memory_facts['swapfree_mb'] == 69268 // 1024
    assert memory_facts['swaptotal_mb'] == 69268 // 1024


# Generated at 2022-06-17 00:28:23.228168
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    device_facts = hardware.get_device_facts()
    assert device_facts['devices'] == ['sd0', 'sd1', 'sd2']



# Generated at 2022-06-17 00:28:32.760343
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    facts = hardware.get_processor_facts()
    assert facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert facts['processor_count'] == '2'
    assert facts['processor_cores'] == '2'



# Generated at 2022-06-17 00:28:42.136451
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = lambda x: (0, '', '')
    hardware.module.run_command = lambda x: (0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', '')
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 28160
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['swapfree_mb'] == 69268
    assert memory_facts['swaptotal_mb'] == 69268


# Generated at 2022-06-17 00:28:54.364622
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()

# Generated at 2022-06-17 00:29:04.312615
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModuleMock()

# Generated at 2022-06-17 00:29:14.298354
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824', 'hw.ncpuonline': '2'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))

# Generated at 2022-06-17 00:31:01.197091
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.populate()
    assert hardware_obj.sysctl['hw.ncpuonline'] == '2'
    assert hardware_obj.sysctl['hw.usermem'] == '8589934592'
    assert hardware_obj.sysctl['hw.model'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'

# Generated at 2022-06-17 00:31:09.693690
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    facts = hardware.populate()
    assert 'uptime_seconds' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'processor_speed' in facts
    assert 'devices' in facts
    assert 'product_name' in facts
    assert 'product_version' in facts
    assert 'product_uuid' in facts
    assert 'product_serial' in facts
    assert 'system_vendor' in facts
    assert 'mounts' in facts

#

# Generated at 2022-06-17 00:31:19.154348
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'}
    processor_facts = hardware.get_processor_facts()
    assert processor_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                                            'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert processor_facts['processor_count'] == 2
    assert processor_facts['processor_cores'] == 2



# Generated at 2022-06-17 00:31:25.365388
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\n  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 27
    assert memory_facts['memtotal_mb'] == 1024

# Generated at 2022-06-17 00:31:35.553674
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.ncpuonline': '4'}
    hardware.module.run_command = MagicMock(return_value=(0, 'procs    memory       page                    disks    traps          cpu\n'
                                                              'r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n'
                                                              '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n', ''))
    memory_facts = hardware.get_memory_facts()
   

# Generated at 2022-06-17 00:31:40.096817
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'kern.boottime': '1575202439'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1575202439)

# Generated at 2022-06-17 00:31:50.807192
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.get_bin_path = MagicMock(return_value="/usr/bin/vmstat")
    module.get_file_content = MagicMock(return_value="")
    module.get_mount_size = MagicMock(return_value={})
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.get_sysctl = MagicMock(return_value={'hw.usermem': '1073741824'})
    openbsd = OpenBSDHardware(module)
    openbsd.get_memory_facts()
    assert openbsd.facts['memfree_mb'] == 1024

# Generated at 2022-06-17 00:32:01.548622
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = OpenBSDHardware(module).populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor']
    assert hardware_facts['devices']
    assert hardware_facts['mounts']
    assert hardware_facts['product_name']
    assert hardware_facts['product_version']
    assert hardware_facts['product_uuid']
    assert hardware_facts['product_serial']