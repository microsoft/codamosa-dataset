

# Generated at 2022-06-20 17:38:35.384219
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    """Unit test for method 'get_memory_facts' of class OpenBSDHardware"""
    import ansible.module_utils.facts.hardware.openbsd

    ansible.module_utils.facts.hardware.openbsd.to_text = lambda x: x

    h = OpenBSDHardware({
        'command': lambda *args, **kwargs: (0, '  0  0  0  47512 28160   51   0   0   0   0   0   1   0  116   89   17   0   1  99', '')
    })
    facts = h.get_memory_facts()

    assert facts
    assert facts['memfree_mb'] == 28
    assert facts['memtotal_mb'] == 471
    assert facts['swapfree_mb'] == 69

# Generated at 2022-06-20 17:38:48.961406
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = DummyModule()

    # Mock module.run_command()
    def run_command_mock(*args, **kwargs):
        command = args[0]
        if command == '/usr/bin/vmstat':
            output = """procs   memory       page                    disks    traps          cpu
      r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id
      0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99"""
        elif command == '/sbin/swapctl -sk':
            output = """total: 69268k bytes allocated = 0k used, 69268k available"""

# Generated at 2022-06-20 17:38:59.022370
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = FakeAnsibleModule()
    hardware_facts = OpenBSDHardware(module).populate()
    assert hardware_facts['uptime_seconds'] == 961
    assert hardware_facts['devices'] == ['wd0', 'wd1', 'cd0', 'cd1']
    assert hardware_facts['memtotal_mb'] == 4 * 1024
    assert hardware_facts['memfree_mb'] == 1 * 1024
    assert hardware_facts['processor'] == ['Genuine Intel(R) CPU @2.00GHz']
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['system_vendor'] == 'TestVendor'
    assert hardware_facts['product_name'] == 'TestProduct'
    assert hardware_facts['product_serial'] == 'TestSerial'


# Generated at 2022-06-20 17:39:03.710869
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(True, "0\n47512\t28160\t51\t0\t0\t0\t0\t0\t1\t0\t116\t89\t17\t0\t1\t99", "", 0)
    hardware = OpenBSDHardware()
    hardware.module = module
    hardware.sysctl['hw.usermem'] = '536870912'
    hardware_facts = hardware.get_memory_facts()
    assert hardware_facts['memfree_mb'] == 28
    assert hardware_facts['memtotal_mb'] == 512


# Generated at 2022-06-20 17:39:09.838353
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = MockModule()

    module.run_command_mock = Mock()
    module.run_command_mock.return_value = (0, 'ahci0 at pci0 dev 31 function 2\nscsibus0 at ahci0: 32 targets\nscsibus1 at ahci0: 32 targets\n', '')

    hw = OpenBSDHardware(module, Mock())
    hw.sysctl = {
        'hw.disknames': 'ahci0'
    }
    facts = hw.get_device_facts()

    assert facts['devices'] == ['ahci0']

# Generated at 2022-06-20 17:39:16.060942
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    hardware = OpenBSDHardware()
    hardware.get_memory_facts = OpenBSDHardware.get_memory_facts
    hardware.module = AnsibleModule(argument_spec={})
    hardware.sysctl = {'hw.usermem': '1073741824',
                       'hw.realmem': '2147483648'}

    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 512



# Generated at 2022-06-20 17:39:20.013109
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    # Create an instance of OpenBSDHardware class
    test_obj = OpenBSDHardware()

    assert test_obj
    assert test_obj.platform == 'OpenBSD'

# Generated at 2022-06-20 17:39:27.552432
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    out_str = """procs    memory       page                    disks    traps          cpu
r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id
0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99"""
    result = {'memfree_mb': 28 // 1024,
              'memtotal_mb': 47512 // 1024 // 1024}
    module = MockModule()
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': 1073737472}
    assert hardware.get_memory_facts() == result


# Generated at 2022-06-20 17:39:35.222611
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    test_module = type('', (), {'run_command': False})
    test_instance = OpenBSDHardware(test_module)
    test_instance.sysctl = {'hw.disknames': 'sd0,sd1,cd0,cd1'}
    test_result = test_instance.get_device_facts()
    assert 'devices' in test_result
    assert len(test_result['devices']) == 4
    assert test_result['devices'] == ['sd0', 'sd1', 'cd0', 'cd1']



# Generated at 2022-06-20 17:39:43.757025
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Testing how it works when vmstat runs well
    module = OpenBSDHardwareCollector
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, """\
procs    memory       page                    disks    traps          cpu
r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id
0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99""",
                                           '')
    module.module = mock_module

# Generated at 2022-06-20 17:39:54.009322
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = None
    h = OpenBSDHardware(module)
    h.sysctl = {}
    h.sysctl['kern.boottime'] = 1590118683
    r = h.get_uptime_facts()
    assert(r['uptime_seconds'] > 0)

# Generated at 2022-06-20 17:39:58.326573
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hw_facts = OpenBSDHardwareCollector()
    assert openbsd_hw_facts.platform == 'OpenBSD'
    assert openbsd_hw_facts.fact_class.platform == 'OpenBSD'
    assert openbsd_hw_facts.fact_class._platform == 'OpenBSD'

# Generated at 2022-06-20 17:40:04.171315
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
        # Declare variables for test case
        input_dict = {'hw.disknames': 'sd0,sd1'}
        output_dict = {}

        # Create an instance of OpenBSDHardware
        openbsd_hw = OpenBSDHardware(dict())

        # Assign module instance of BsdHardware to 'module' variable
        openbsd_hw.sysctl = input_dict

        # Call method get_device_facts of BsdHardware
        output_dict = openbsd_hw.get_device_facts()

        # Verify method get_device_facts returns expected dictionary
        assert output_dict['devices'] == ['sd0', 'sd1']

# Generated at 2022-06-20 17:40:08.778950
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware_collector = OpenBSDHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]
    assert hardware.get_device_facts()['devices'] == hardware.devices

# Generated at 2022-06-20 17:40:20.571177
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    class OSModule():
        def __init__(self):
            self.run_command_args = []
            self.run_command_rc = 0

        def get_bin_path(self, name, **kwargs):
            return name

        def run_command(self, args, **kwargs):
            self.run_command_args.append(args)
            return self.run_command_rc, '', ''

    module = OSModule()
    class Facts:
        def __init__(self):
            self._data = {
                'ansible_system': 'OpenBSD',
                'ansible_machine_id': None,
            }
        def get(self, name, default=None):
            return self._data.get(name, default)
        def __setitem__(self, name, value):
            self._

# Generated at 2022-06-20 17:40:22.747022
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    """
    The constructor of OpenBSDHardwareCollector can be invoked
    """
    OpenBSDHardwareCollector()

# Generated at 2022-06-20 17:40:34.823781
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    import sys
    from ansible.module_utils.facts.collector.openbsd import OpenBSDHardware
    from ansible.module_utils.facts.utils import get_file_content

    hardware_facts = OpenBSDHardware({})

    rc = 0
    out = get_file_content('tests/module_utils/facts/files/sysctl_hw.usermem')
    err = ''
    hardware_facts.module.run_command.return_value = rc, out, err

    rc = 0
    out = get_file_content('tests/module_utils/facts/files/vmstat')
    err = ''
    hardware_facts.module.run_command.return_value = rc, out, err

    rc = 0
    out = get_file_content('tests/module_utils/facts/files/swapctl')
   

# Generated at 2022-06-20 17:40:44.625587
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    import io
    from ansible.module_utils.facts import hardware as hw

    class MockModule(object):
        """
        Mock class for module
        """
        def __init__(self, run_command_dict=None):
            self.run_command_dict = run_command_dict

        def run_command(self, args, check_rc=False):  # test_OpenBSDHardware.py pylint: disable=no-self-use
            if self.run_command_dict is None:
                return 1, b'', b''
            else:
                key = ' '.join(args)
                return self.run_command_dict[key]

    test_hw = hw.OpenBSDHardware({})
    test_hw.module = MockModule()

# Generated at 2022-06-20 17:40:57.452588
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    mock_sysctl = {'hw.product': 'product_name',
                   'hw.version': 'product_version',
                   'hw.uuid': 'product_uuid',
                   'hw.serialno': 'product_serial',
                   'hw.vendor': 'system_vendor'}

    openbsd_hw = OpenBSDHardware({})
    openbsd_hw.sysctl = mock_sysctl
    facts = openbsd_hw.get_dmi_facts()
    assert 'system_vendor' in facts
    assert facts['system_vendor'] == 'system_vendor'
    assert 'product_name' in facts
    assert facts['product_name'] == 'product_name'
    assert 'product_version' in facts
    assert facts['product_version'] == 'product_version'

# Generated at 2022-06-20 17:41:05.091708
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModuleMock({})
    openbsd_hardware = OpenBSDHardware(module)

    assert openbsd_hardware.populate().keys() == ['devices', 'memfree_mb', 'memtotal_mb',
                                                  'mounts', 'processor', 'processor_cores',
                                                  'processor_count', 'swapfree_mb',
                                                  'swaptotal_mb', 'uptime_seconds']


# Unit test class for class OpenBSDHardwareCollector.

# Generated at 2022-06-20 17:41:23.092289
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():

    class MockModule(object):
        def __init__(self, *argv, **kwargs):
            self.run_command_results = dict(
                hw=[0, 'hw', ''],
                hw_product=[0, 'hw_product', ''],
                hw_version=[0, 'hw_version', ''],
                hw_uuid=[0, 'hw_uuid', ''],
                hw_serialno=[0, 'hw_serialno', ''],
                hw_vendor=[0, 'hw_vendor', '']
            )

        def run_command(self, cmd):
            return self.run_command_results[cmd.split(' ')[2]]

        def get_bin_path(self, cmd):
            return cmd

    module = MockModule()

# Generated at 2022-06-20 17:41:27.529435
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    module = OpenBSDHardwareCollector._create_fake_module()
    module.run_command = Mock(return_value=('0', 'OpenBSD.amd64', '', ''))
    hw_collector = OpenBSDHardwareCollector()
    assert hw_collector._platform == 'OpenBSD'
    assert hw_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-20 17:41:32.073402
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    hardware_module = OpenBSDHardware({})
    hardware_module.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'QEMU Virtual CPU version 2.0.0'}
    processor_facts = hardware_module.get_processor_facts()
    assert processor_facts['processor'] == ['QEMU Virtual CPU version 2.0.0', 'QEMU Virtual CPU version 2.0.0']
    assert processor_facts['processor_count'] == '2'
    assert processor_facts['processor_cores'] == '2'

# Generated at 2022-06-20 17:41:43.880449
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    hw = OpenBSDHardware({})
    assert hw.uptime_seconds is not None
    assert hw.uptime_seconds > 0

    assert hw.processor_cores is not None
    assert hw.processor_cores > 0

    assert hw.processor_count is not None
    assert hw.processor_count > 0

    assert hw.memtotal_mb is not None
    assert hw.memtotal_mb > 0

    assert hw.memfree_mb is not None
    assert hw.memfree_mb > 0

    assert hw.swaptotal_mb is not None
    assert hw.swaptotal_mb > 0

    assert hw.swapfree_mb is not None
    assert hw.swapfree_mb > 0

    # processor_speed is not available on OpenBSD


# Generated at 2022-06-20 17:41:46.101908
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    f = OpenBSDHardwareCollector()
    assert isinstance(f, OpenBSDHardwareCollector)


# Generated at 2022-06-20 17:41:55.882372
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    """
    Test get_processor_facts method of OpenBSDHardware class
    """
    def get_sysctl(self, keys):
        """
        Test wrapper for get_sysctl(self, keys) method
        """

# Generated at 2022-06-20 17:42:07.586358
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    # Prepare a fake ansible module
    class FakeModule:
        def __init__(self):
            self.run_command = get_sysctl

    module = FakeModule()
    # Get device facts
    module.facts = {}
    hardware = OpenBSDHardware(module)
    hardware_facts = hardware.populate()['ansible_facts']
    device_facts = hardware_facts['ansible_device_facts']
    assert 'devices' in device_facts
    # Test number of devices returned
    assert len(device_facts['devices']) > 0
    # Test if the expected devices are there
    for device in ('sd0', 'wd0', 'cd0', 'vnd0'):
        assert device in device_facts['devices']

# Generated at 2022-06-20 17:42:13.596127
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    m = OpenBSDHardware()
    m._module.run_command = lambda *args, **kw: (0, 'hw', '')
    m.sysctl = {'hw.vendor': 'OpenBSD',
                'hw.product': 'OpenBSD',
                'hw.version': '5.5',
                'hw.uuid': '1234',
                'hw.serialno': '1234'}
    dmi_facts = m.get_dmi_facts()

    assert 'product_name' in dmi_facts
    assert dmi_facts['product_name'] == 'OpenBSD'

    assert 'system_vendor' in dmi_facts
    assert dmi_facts['system_vendor'] == 'OpenBSD'

    assert 'product_version' in dmi_facts

# Generated at 2022-06-20 17:42:15.916635
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_collector = OpenBSDHardwareCollector(None)
    assert openbsd_collector.sysctl is None
    assert openbsd_collector.platform == 'OpenBSD'

# Generated at 2022-06-20 17:42:28.084432
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    # Setup
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, str(
        '0: vspd0 at root\n\
         1: wd0 at root\n\
         2: wd3 at root\n\
         3: cd1 at root\n\
         4: cd0 at root\n'), '')
    hardware = OpenBSDHardware(module=module)
    hardware.sysctl = {'hw.disknames': 'wd0,cd0'}
    device_facts = {'devices': ['wd0', 'cd0']}

    # Execute
    results = hardware.get_device_facts()

    # Verify
    assert results == device_facts



# Generated at 2022-06-20 17:42:35.144071
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    hardware = OpenBSDHardware()

    assert hardware.sysctl == {}

# Generated at 2022-06-20 17:42:37.074215
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    fact_class, platform = OpenBSDHardwareCollector.get_fact_class()
    assert fact_class is OpenBSDHardware and platform == 'OpenBSD'

# Generated at 2022-06-20 17:42:39.174942
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    openbsd_facts = OpenBSDHardware()
    assert openbsd_facts.platform == 'OpenBSD'

# Generated at 2022-06-20 17:42:51.217674
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = MockAnsibleModule()
    hw = OpenBSDHardware(module)
    res = hw.populate()
    assert 'memfree_mb' in res
    assert 'memtotal_mb' in res
    assert 'swapfree_mb' in res
    assert 'swaptotal_mb' in res
    assert 'processor' in res
    assert 'processor_cores' in res
    assert 'processor_count' in res
    assert 'processor_speed' in res
    assert 'uptime_seconds' in res
    assert 'product_name' in res
    assert 'product_version' in res
    assert 'product_uuid' in res
    assert 'product_serial' in res
    assert 'system_vendor' in res
    assert 'devices' in res
    assert 'mounts' in res

# Generated at 2022-06-20 17:42:54.538842
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = OpenBSDHardware(module)
    assert hardware_obj.populate()



# Generated at 2022-06-20 17:43:01.514548
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    """Unit test for method get_memory_facts of class OpenBSDHardware"""

    class MockModuleUtils(object):
        """Mock class to emulate module_utils.facts.system.get_file_content method"""

        def __init__(self, rc=0, out=None, err=None):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd, check_rc=True):
            return self.rc, self.out, self.err



    class MockSysModule(object):
        """Mock class to emulate module_utils.facts.system.get_file_content method"""

        def __init__(self, val=None):
            self.val = val

        def __getitem__(self, key):
            return self.val



# Generated at 2022-06-20 17:43:08.688086
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = FakeAnsibleModule(facts={'distribution': 'OpenBSD'})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.ncpuonline': '2',
                       'hw.model': 'Intel(R) Core(TM) i5-2520M CPU @ 2.50GHz'}
    facts = hardware.get_processor_facts()
    assert facts['processor_count'] == '2'
    assert facts['processor_cores'] == '2'
    assert facts['processor'] == ['Intel(R) Core(TM) i5-2520M CPU @ 2.50GHz',
                                  'Intel(R) Core(TM) i5-2520M CPU @ 2.50GHz']


# Generated at 2022-06-20 17:43:20.292240
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.utils import FactsParams
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    collected_facts = {"ansible_facts": {},
                       "ansible_devices": []}
    params = FactsParams()

    res = OpenBSDHardware(module, params, collected_facts).get_memory_facts()
    assert 'memtotal_mb' in res
    assert 'memfree_mb' in res
    assert 'swaptotal_mb' in res
    assert 'swapfree_mb' in res



# Generated at 2022-06-20 17:43:23.025242
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    hardware = OpenBSDHardware(dict())
    results = hardware.populate()

    assert results is not None


# Generated at 2022-06-20 17:43:29.243099
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardwareCollector
    hp = OpenBSDHardwareCollector()
    assert hasattr(hp, '_fact_class')
    assert hp._fact_class == OpenBSDHardware
    assert hasattr(hp, '_platform')
    assert hp._platform == 'OpenBSD'


# Generated at 2022-06-20 17:43:46.488820
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    class OpenBSDHardware(object):
        def __init__(self):
            self.sysctl = {'hw.ncpuonline': 2, 'hw.model': 'Intel(R) Celeron(R) CPU N3050 @ 1.60GHz'}

    facts_module = OpenBSDHardware()
    facts = OpenBSDHardware.get_processor_facts(facts_module)
    assert facts['processor'] == ['Intel(R) Celeron(R) CPU N3050 @ 1.60GHz',
                                  'Intel(R) Celeron(R) CPU N3050 @ 1.60GHz']
    assert facts['processor_count'] == 2
    assert facts['processor_cores'] == 2


# Generated at 2022-06-20 17:43:59.223128
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = FakeAnsibleModule()
    openbsd_hardware = OpenBSDHardware(module)
    # Get free memory. vmstat output looks like:
    #  procs    memory       page                    disks    traps          cpu
    #  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id
    #  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99

# Generated at 2022-06-20 17:44:07.628070
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = FakeAnsibleModule()

    expected_result = {
        'uptime_seconds': 12345678,
    }

    module.run_command = mock_run_command(0, str(12345678), '')

    openbsd_hw = OpenBSDHardware.platform_sys_facts(module)
    result = openbsd_hw.get_uptime_facts()

    assert result == expected_result



# Generated at 2022-06-20 17:44:10.069667
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    import platform
    os_platform = platform.system()
    assert OpenBSDHardwareCollector._platform == os_platform, \
        "Platform is not " + os_platform


# Generated at 2022-06-20 17:44:21.951041
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    class Module:
        def __init__(self, params):
            self.params = params

        def run_command(self, params):
            if params == ['/usr/bin/vmstat']:
                if self.params['memfree'] == 'normal':
                    return (0, 'procs    memory       page                    disks    traps          cpu\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n', None)
                elif self.params['memfree'] == 'insufficient':
                    return (0, '', None)

# Generated at 2022-06-20 17:44:34.313381
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = ModuleStub(dict(command='/sbin/sysctl -n hw', rc=0, stdout=""))
    module.run_command = ModuleStub.run_command
    hw = OpenBSDHardware(module)
    # Add some fake data to module:
    hw.sysctl = {'hw.ncpuonline': '2',
                 'hw.model': 'Intel(R) Xeon(R) CPU E5-2620 v3 @ 2.40GHz'}
    cpu_facts = hw.get_processor_facts()
    assert cpu_facts['processor'] == ['Intel(R) Xeon(R) CPU E5-2620 v3 @ 2.40GHz',
                                      'Intel(R) Xeon(R) CPU E5-2620 v3 @ 2.40GHz']

# Generated at 2022-06-20 17:44:44.574630
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = FakeModule()
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': 600078336}
    hardware.get_mount_facts = lambda: {'mounts': []}
    hardware.get_dmi_facts = lambda: {}
    hardware.get_device_facts = lambda: {}
    hardware.get_uptime_facts = lambda: {}
    hardware.get_processor_facts = lambda: {}
    mem_facts = hardware.get_memory_facts()

    assert mem_facts['memfree_mb'] == 2816
    assert mem_facts['memtotal_mb'] == 573


# Hack to be able to call get_memory_facts without having to mock its
# dependencies.

# Generated at 2022-06-20 17:44:47.033450
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    m = OpenBSDHardware({})
    assert m.platform == 'OpenBSD'

# Generated at 2022-06-20 17:44:58.439059
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    OpenBSDHardware.get_device_facts(module)
    assert module.ansible_facts['devices'] == ['wd0', 'wd1', 'wd2', 'wd3', 'wd4', 'wd5', 'wd6', 'wd7',
                                               'sd0', 'sd1', 'sd2', 'sd3', 'sd4', 'sd5', 'sd6', 'sd7',
                                               'cd0', 'cd1', 'cd2',
                                               'ch0', 'ch1', 'ch2', 'ch3',
                                               'vnd0', 'vnd1', 'vnd2', 'vnd3', 'vnd4', 'vnd5', 'vnd6', 'vnd7']

# Generated at 2022-06-20 17:45:08.450145
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    def get_sysctl(module, var):
        hw_facts = {}
        hw_facts['hw.product'] = 'test_product_name'
        hw_facts['hw.version'] = 'test_product_version'
        hw_facts['hw.uuid'] = 'test_product_uuid'
        hw_facts['hw.serialno'] = 'test_product_serial'
        hw_facts['hw.vendor'] = 'test_system_vendor'

        return hw_facts

    # mock module
    module = openbsd_hw_module = AnsibleModule(
        argument_spec=dict()
    )

    # mock the method get_sysctl
    setattr(openbsd_hw_module, 'get_sysctl', get_sysctl)

    # create OpenBSDHardware

# Generated at 2022-06-20 17:45:20.252448
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = FakeAnsibleModule()
    Hardware = OpenBSDHardware(module)
    Hardware.populate()
    processor = Hardware['processor']
    # We should have at least 1 item in processor list
    assert len(processor) == 1
    # And processor[0] should be non-empty
    assert processor[0] != ''

# Generated at 2022-06-20 17:45:28.467796
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.collector import get_collector
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    from ansible.module_utils.six import PY2

    m = get_collector('hardware')
    if not isinstance(m, OpenBSDHardware):
        raise Exception("Expected an OpenBSDHardware object but got {0}".format(m))

    try:
        m.get_mount_facts()
    except (timeout.TimeoutError):
        pass
    else:
        raise Exception("Expected a timeout.TimeoutError but got none")


# Generated at 2022-06-20 17:45:34.064969
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # Normal invocation
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert isinstance(openbsd_hardware_collector, HardwareCollector)
    assert openbsd_hardware_collector.platform == 'OpenBSD'
    assert openbsd_hardware_collector.fact_class == OpenBSDHardware

# Generated at 2022-06-20 17:45:44.856959
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware import OpenBSDHardware

    test_cases = [
        {
            'kern_boottime': '0',
            'uptime_seconds': 0,
        },
        {
            'kern_boottime': '1490292378',
            'uptime_seconds': 59,
        },
        {
            'kern_boottime': '1490292',
            'uptime_seconds': 0,
        },
        {
            'kern_boottime': '1490292378a',
            'uptime_seconds': 0,
        },

    ]

    for test_case in test_cases:
        openbsdfacts = OpenBSDHardware({}, None)

# Generated at 2022-06-20 17:45:54.438452
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    data = {
        'hw.ncpuonline': '4',
        'hw.model': 'Intel(R) Core(TM) i5-4210M CPU @ 2.60GHz',
    }
    with open('/tmp/test_OpenBSDHardware_get_processor_facts.txt', 'w') as fp:
        fp.write(str(data))


# Generated at 2022-06-20 17:46:02.947743
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = {}
    setattr(module, 'run_command', lambda *_, **__: (0, '', ''))
    setattr(module, 'get_bin_path', lambda *_, **__: '')
    setattr(module, 'get_file_content', lambda *_, **__: '')
    setattr(module, 'jsonify', lambda x: x)
    setattr(OpenBSDHardware, 'module', module)
    facts = OpenBSDHardware().populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts

# Generated at 2022-06-20 17:46:07.856683
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    HardwareCollector._module = module
    del module.params['gather_subset']
    collector = OpenBSDHardwareCollector()

    results = collector.get_facts()
    assert results['processor'] == ['Intel(R) Xeon(R) CPU X5560 @ 2.80GHz']



# Generated at 2022-06-20 17:46:14.642303
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsdHardwareCollector = OpenBSDHardwareCollector()
    assert openbsdHardwareCollector
    assert openbsdHardwareCollector.platform == openbsdHardwareCollector._platform
    assert openbsdHardwareCollector.fact_class == openbsdHardwareCollector._fact_class
    assert openbsdHardwareCollector.fact_class().platform == openbsdHardwareCollector._platform
    assert openbsdHardwareCollector._collect() == dict()

# Generated at 2022-06-20 17:46:20.105469
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # Initialize object
    oh = OpenBSDHardware(dict(), dict())

    # Set sysctl attr
    oh.sysctl = {
        'kern.boottime': '1590397345'
    }

    # Run test
    fact = oh.get_uptime_facts()

    assert fact['uptime_seconds'] == int(time.time() - 1590397345)



# Generated at 2022-06-20 17:46:23.115051
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    """
    Constructor of OpenBSDHardwareCollector
    """
    my_obj = OpenBSDHardwareCollector()
    assert my_obj
    assert isinstance(my_obj, OpenBSDHardwareCollector)

# Generated at 2022-06-20 17:46:44.704880
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    hardware_facts = {}
    devices = []
    devices.extend(['wd0', 'sd0', 'cd0', 'sd1', 'sd2'])
    hardware_facts['devices'] = devices
    module = FakeModule()
    hardware = OpenBSDHardware(module)
    assert hardware.get_device_facts() == hardware_facts


# Generated at 2022-06-20 17:46:51.154303
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    hw = OpenBSDHardware(None)
    hw.sysctl = {'hw.ncpuonline': 16, 'hw.model': 'Intel(R) Core(TM) i7-5500U CPU @ 2.40GHz'}
    assert hw.get_processor_facts() == {'processor': ['Intel(R) Core(TM) i7-5500U CPU @ 2.40GHz']*16,
                                        'processor_count': 16,
                                        'processor_cores': 16}


# Generated at 2022-06-20 17:46:56.947001
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    hw = OpenBSDHardware({'module_setup': False})
    hw.sysctl = {'hw.product': 'test',
                 'hw.version': 'version',
                 'hw.uuid': 'uuid',
                 'hw.serialno': 'serialno',
                 'hw.vendor': 'vendor',
                 'hw.model': 'model'}
    dmi_facts = hw.get_dmi_facts()
    assert dmi_facts['product_name'] == 'test'
    assert dmi_facts['product_version'] == 'version'
    assert dmi_facts['product_uuid'] == 'uuid'
    assert dmi_facts['product_serial'] == 'serialno'
    assert dmi_facts['system_vendor'] == 'vendor'

# Generated at 2022-06-20 17:47:05.503326
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    hardware = OpenBSDHardware({})
    hardware.sysctl = {}
    dmi_facts = hardware.get_dmi_facts()
    assert len(dmi_facts.keys()) == 0

    hardware.sysctl = {'hw.product': 'OpenBSD'}
    dmi_facts = hardware.get_dmi_facts()
    assert len(dmi_facts.keys()) == 1
    assert dmi_facts['product_name'] == 'OpenBSD'

    # all entries in sysctl_to_dmi

# Generated at 2022-06-20 17:47:07.956278
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    openbsd_unit_test_obj = OpenBSDHardware(module=None)
    assert openbsd_unit_test_obj.platform == 'OpenBSD'

# Generated at 2022-06-20 17:47:12.813857
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # Test case where this class can be instantiated
    openbsd_hw_collector = OpenBSDHardwareCollector()
    assert openbsd_hw_collector._fact_class == OpenBSDHardware
    assert openbsd_hw_collector._platform == 'OpenBSD'


# Generated at 2022-06-20 17:47:14.872623
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert OpenBSDHardwareCollector.get_platform() == 'OpenBSD'
    assert OpenBSDHardwareCollector.get_fact_class() == OpenBSDHardware


# Generated at 2022-06-20 17:47:20.947535
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = MockModule()
    hardware = OpenBSDHardware(module=module)
    hardware.sysctl = {'hw.disknames': 'wd0,wd1'}
    exp_res = {'devices': ['wd0', 'wd1']}
    result = hardware.get_device_facts()
    assert result == exp_res



# Generated at 2022-06-20 17:47:24.845250
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModuleMock()
    hardware = OpenBSDHardware(module)
    processor = hardware.get_processor_facts()

    assert processor is not None
    assert len(processor['processor']) > 0
    assert processor['processor_count'] > 0
    assert processor['processor_cores'] > 0



# Generated at 2022-06-20 17:47:31.263301
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    openbsd_hardware_fact = OpenBSDHardware({"module_setup": True})
    openbsd_hardware_fact.sysctl = {'hw.product': 'foo',
                                    'hw.version': 'bar',
                                    'hw.uuid': 'foobar',
                                    'hw.serialno': '',
                                    'hw.vendor': ''}
    result = openbsd_hardware_fact.get_dmi_facts()
    assert result['product_name'] == 'foo'
    assert result['product_version'] == 'bar'
    assert result['product_uuid'] == 'foobar'
    assert result['product_serial'] == ''
    assert result['system_vendor'] == ''

# Generated at 2022-06-20 17:48:13.163424
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    hardware_obj = OpenBSDHardwareCollector().collect()[0]
    dmi_facts_dict = hardware_obj.get_dmi_facts()
    assert 'system_vendor' in dmi_facts_dict

# Generated at 2022-06-20 17:48:18.567159
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    dmi_facts = {
        'hw.disknames': 'sd0,sd1'
    }
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))

    hw = OpenBSDHardware(module, dmi_facts)
    assert hw.get_device_facts() == {'devices': ['sd0', 'sd1']}
