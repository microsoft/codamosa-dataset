

# Generated at 2022-06-20 17:38:31.304534
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    obj = OpenBSDHardwareCollector()
    assert obj.platform == 'OpenBSD'
    assert obj._fact_class == OpenBSDHardware


# Generated at 2022-06-20 17:38:40.239776
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    hardware = OpenBSDHardware({'module_setup': True})
    hardware.sysctl['hw.product'] = 'OpenBSD'
    hardware.sysctl['hw.version'] = '6.1'
    hardware.sysctl['hw.uuid'] = '00000000-0000-0000-0000-000000000000'
    hardware.sysctl['hw.serialno'] = '00000000'
    hardware.sysctl['hw.vendor'] = 'OpenBSD Foundation'

    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['product_name'] == 'OpenBSD'
    assert dmi_facts['product_version'] == '6.1'
    assert dmi_facts['product_uuid'] == '00000000-0000-0000-0000-000000000000'
    assert dmi_facts['product_serial'] == '00000000'

# Generated at 2022-06-20 17:38:52.800815
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    OpenBSDHardware._is_platform_supported = classmethod(lambda *args: True)

    # When hw.ncpuonline is 2
    OpenBSDHardware.get_sysctl = lambda *args: {'hw.ncpuonline': 2}
    proc_facts = {'processor': ['Intel(R) Xeon(R) CPU E5450 @ 3.00GHz'],
                  'processor_count': 2,
                  'processor_cores': 2}
    assert proc_facts == OpenBSDHardware().get_processor_facts()

    # When hw.ncpuonline is 4
    OpenBSDHardware.get_sysctl = lambda *args: {'hw.ncpuonline': 4}

# Generated at 2022-06-20 17:39:01.011247
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = MagicMock(return_value='/sbin/sysctl')
    module.run_command = MagicMock(return_value=(0, 'hw.vendor: Microsoft Corporation\nhw.uuid: b3cdd5e5-02ad-427f-bd3e-f2ac9b189ed6\nhw.serialno: 12345\nhw.version: 6.0\nhw.product: Virtual Machine\n', ''))
    sysctl = get_sysctl(module, ['hw'])

    facts = OpenBSDHardware(module)

# Generated at 2022-06-20 17:39:03.583094
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(dict())
    dmi_facts = {'hw.disknames': 'sd0,sd1'}
    hardware = OpenBSDHardware(module, dmi_facts)
    result = hardware.get_device_facts()
    assert result == {'devices': ['sd0', 'sd1']}


# Generated at 2022-06-20 17:39:14.313585
# Unit test for method get_dmi_facts of class OpenBSDHardware

# Generated at 2022-06-20 17:39:26.408343
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    from ansible.module_utils.facts import timeout
    import ansible.module_utils.facts.utils as utils

    class MockModule(object):
        def run_command(self, command):
            if command == ["/usr/bin/vmstat"]:
                return (0, "procs    memory       page                    disks    traps          cpu\n r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n 0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99", "")

# Generated at 2022-06-20 17:39:37.898358
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})

    hardware = OpenBSDHardware(module)
    hardware.sysctl = {
        'hw.model': 'Intel(R) Core(TM) i5 CPU M 460  @ 2.53GHz',
        'hw.ncpuonline': '2'
        }
    hardware.get_processor_facts()
    ansible_facts = hardware.facts
    processor = ansible_facts['processor']
    processor_cores = ansible_facts['processor_cores']
    processor_count = ansible_facts['processor_count']

    assert len(processor) == 2
    assert processor[0] == processor[1] == 'Intel(R) Core(TM) i5 CPU M 460  @ 2.53GHz'
    assert processor_cores == '2'

# Generated at 2022-06-20 17:39:43.520263
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    rc, out, err = module.run_command('sysctl -n hw.usermem')
    out = to_text(out, errors='surrogate_or_strict')
    # 1330671024 * 1024 * 1024 ~= 139568 GB
    assert out.strip() == to_text(1330671024)
    rc, out, err = module.run_command(
        'sysctl -n hw.ncpuonline'
    )
    out = to_text(out, errors='surrogate_or_strict')
    assert out.strip() == to_text(1)
    rc, out, err = module.run_command(
        'sysctl -n hw.model'
    )
    out

# Generated at 2022-06-20 17:39:56.526940
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
        module = AnsibleModule(
            argument_spec = dict()
        )

        mock_run_command = MagicMock(return_value=(0, 'hw.ncpuonline: 32', ''))
        module.run_command = mock_run_command

        mock_get_bin_path = MagicMock(return_value='/bin/sysctl')
        module.get_bin_path = mock_get_bin_path

        mock_get_file_content = MagicMock(return_value='/dev/sd0a')
        get_file_content = MagicMock(return_value='/dev/sd0a')
        get_file_content.return_value = '/dev/sd0a'

        mock_get_mount_size = MagicMock(return_value={})

# Generated at 2022-06-20 17:40:11.484289
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    class TestArgs(object):
        def __init__(self, module, run_command):
            self.module = module
            self.run_command = run_command
    args = TestArgs(None, None)
    obj = OpenBSDHardware()
    obj.module = args
    obj.sysctl = {'hw.disknames': 'sd0,sd1'}
    assert obj.get_device_facts() == {'devices': ['sd0', 'sd1']}
    obj.sysctl = {'hw.disknames': ''}
    assert obj.get_device_facts() == {'devices': []}

# Generated at 2022-06-20 17:40:23.824899
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = MockModule()
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.product': 'Foo',
                       'hw.version': '1.2.3',
                       'hw.uuid': '12345678-1234-1234-1234-123456789012',
                       'hw.serialno': '1234567890',
                       'hw.vendor': 'FooBar Inc.'}

# Generated at 2022-06-20 17:40:27.296266
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = FakeAnsibleModule(
        command="/usr/bin/sysctl hw.disknames",
        stdout="hw.disknames=wd0,wd1",
        rc=0,
        start=0
    )
    hardware = OpenBSDHardware(module)
    result = hardware.get_device_facts()
    assert result == {'devices': ['wd0', 'wd1']}


# Generated at 2022-06-20 17:40:30.278000
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # Create instance of OpenBSDHardwareCollector class
    obj = OpenBSDHardwareCollector()
    # Check instance created successfully
    assert obj is not None

# Generated at 2022-06-20 17:40:34.438852
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._platform == 'OpenBSD'
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware

# Generated at 2022-06-20 17:40:44.420698
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    hardware = OpenBSDHardware.populate()
    assert hardware['system_vendor'].lower() == 'unknown'
    assert hardware['product_name'].lower() == 'unknown'
    assert hardware['product_version'].lower() == 'unknown'
    assert hardware['product_serial'].lower() == 'unknown'
    assert hardware['product_uuid'].lower() == 'unknown'
    assert hardware['processor'].lower() == 'unknown'
    assert hardware['processor_cores'].lower() == 'unknown'
    assert hardware['processor_count'].lower() == 'unknown'
    assert hardware['processor_speed'].lower() == 'unknown'
    assert hardware['memfree_mb'].lower() == 'unknown'

# Generated at 2022-06-20 17:40:45.298388
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    OpenBSDHardware()

# Generated at 2022-06-20 17:40:53.479047
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    fact_module = OpenBSDHardwareCollector.fetch_fact_module()
    assert fact_module.get_dmi_facts() == {
        'system_vendor': 'OpenBSD',
        'product_version': '6.1 (GENERIC) #0: Sun Mar 12 03:25:05 UTC 2017',
        'product_name': 'OpenBSD.amd64',
        'product_serial': '',
        'product_uuid': ''
    }



# Generated at 2022-06-20 17:40:55.211357
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector = OpenBSDHardwareCollector()
    assert hardware_collector.platform == 'OpenBSD'

# Generated at 2022-06-20 17:41:06.670634
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = OpenBSDHardware(module)

    hw.module.run_command = lambda *a, **ka: (0, '', '')
    hw.sysctl = {
        'hw.ncpuonline': 1,
        'hw.usermem': '976753664',
        'hw.model': 'Intel(R) Core(TM) i7-4600U CPU @ 2.10GHz',
        'hw.disknames': 'foo,bar',
        'hw.vendor': 'Foo Inc.',
        'hw.product': 'Bar 3000',
        'hw.version': '2.0',
        'hw.uuid': 'deadbeef',
        'hw.serialno': '1234',
    }

    facts = hw.populate

# Generated at 2022-06-20 17:41:27.895032
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = FakeAnsibleModule()
    set_module_args(dict(gather_subset='min'))
    openbsd_hw = OpenBSDHardware(module=module)
    openbsd_hw.get_device_facts()

    assert (openbsd_hw.facts['devices'] == ['sd0'])

# Generated at 2022-06-20 17:41:39.010081
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    dist_memory_facts = OpenBSDHardware().get_memory_facts()
    assert isinstance(dist_memory_facts, dict)
    assert 'memtotal_mb' in dist_memory_facts
    assert 'memfree_mb' in dist_memory_facts
    assert isinstance(dist_memory_facts['memtotal_mb'], int)
    assert isinstance(dist_memory_facts['memfree_mb'], int)
    assert 'swaptotal_mb' in dist_memory_facts
    assert 'swapfree_mb' in dist_memory_facts
    assert isinstance(dist_memory_facts['swaptotal_mb'], int)
    assert isinstance(dist_memory_facts['swapfree_mb'], int)


# Generated at 2022-06-20 17:41:47.813826
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    test_class = OpenBSDHardware
    test_instance = OpenBSDHardware(dict())

    # Test what happens when vmstat returns an error
    test_instance.module.run_command = lambda args: (1, '', '')
    assert test_instance.get_memory_facts() == {'memfree_mb': None, 'memtotal_mb': None,
                                                'swapfree_mb': None, 'swaptotal_mb': None}

    # Test what happens when vmstat returns no output
    test_instance.module.run_command = lambda args: (0, '', '')
    assert test_instance.get_memory_facts() == {'memfree_mb': None, 'memtotal_mb': None,
                                                'swapfree_mb': None, 'swaptotal_mb': None}

    # Test what

# Generated at 2022-06-20 17:41:51.026009
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_collector = OpenBSDHardwareCollector()
    assert openbsd_collector.platform == 'OpenBSD'
    assert openbsd_collector.fact_class == OpenBSDHardware

# Generated at 2022-06-20 17:41:53.640449
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    mod = 'fake_module'
    hardware = OpenBSDHardware(mod)
    assert hardware.module == mod
    assert hardware.sysctl == {}

# Generated at 2022-06-20 17:41:58.558843
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    hardware = OpenBSDHardware(dict(module=None))
    hardware.sysctl = {'hw.disknames': 'wd0,wd1'}
    device_facts = hardware.get_device_facts()
    assert device_facts['devices'] == ['wd0', 'wd1']

# Generated at 2022-06-20 17:42:08.363553
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Test when vmstat exits with non-zero status.
    module = MockModule()
    module.run_command.return_value = (1, "", "")
    hw = OpenBSDHardware(module=module)
    facts = hw.populate()

    # Test when vmstat exits with zero status
    module = MockModule()
    module.run_command.return_value = (0, "procs  memory       page                    disks    traps          cpu", "")
    hw = OpenBSDHardware(module=module)
    facts = hw.populate()
    assert facts['memfree_mb'] == 0
    assert facts['memtotal_mb'] == 0


# Generated at 2022-06-20 17:42:14.356497
# Unit test for method get_dmi_facts of class OpenBSDHardware

# Generated at 2022-06-20 17:42:16.073726
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    facts = OpenBSDHardwareCollector()
    assert facts._fact_class == OpenBSDHardware
    assert facts._platform == 'OpenBSD'

# Generated at 2022-06-20 17:42:26.683402
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # pylint: disable=protected-access
    hardware_instance = OpenBSDHardware(module=MagicMock())

    # Mock the system calls
    hardware_instance._module.run_command = MagicMock()
    hardware_instance._module.run_command.side_effect = [
        (0, '1478737193\n', ''),
    ]

    test_time = 1478737193
    expected_uptime_in_seconds = int(time.time() - test_time)
    assert expected_uptime_in_seconds == hardware_instance.get_uptime_facts()['uptime_seconds']

# Generated at 2022-06-20 17:43:18.109937
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    Hardware.module = {'run_command': openbsd_run_command}
    OpenBSDHardware.sysctl = {'hw.ncpuonline': '2',
                              'hw.model': 'Intel(R) Xeon(R) CPU E3-1225 v3'}
    processor_facts = OpenBSDHardware.get_processor_facts()
    assert processor_facts == {'processor': ['Intel(R) Xeon(R) CPU E3-1225 v3', 'Intel(R) Xeon(R) CPU E3-1225 v3'],
                               'processor_count': '2',
                               'processor_cores': '2'}



# Generated at 2022-06-20 17:43:25.107414
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    '''
    Test method get_device_facts of class OpenBSDHardware
    '''
    module = AnsibleModule(
        argument_spec={
            "filter": {'required': False, 'type': 'list', 'default': ['*']},
        },
        supports_check_mode=True)

    if module.check_mode:
        module.exit_json(changed=False)

    openbsd_hardware = OpenBSDHardware(module)
    module.exit_json(ansible_facts={'ansible_' + openbsd_hardware.platform: openbsd_hardware.populate()})


# pylint: disable=redefined-builtin, unused-wildcard-import, wildcard-import, locally-disabled
# import module snippets.  This are required
from ansible.module_utils.basic import *

# Generated at 2022-06-20 17:43:27.161159
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = DummyModule()
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.disknames': ',,'}
    device_facts = hardware.get_device_facts()
    assert device_facts['devices'] == ['']



# Generated at 2022-06-20 17:43:37.121403
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = None
    sysctl = {'hw.product': 'OpenBSD',
              'hw.version': '6.4',
              'hw.uuid': '97f12af0-a6ff-47f8-a6ff-a6ff-a6ff97f12af0',
              'hw.serialno': 'NO SERIAL',
              'hw.vendor': 'OpenBSD'}
    OpenBSDHardware = OpenBSDHardware(module)
    OpenBSDHardware.sysctl = sysctl
    dmi_facts = OpenBSDHardware.get_dmi_facts()

# Generated at 2022-06-20 17:43:50.195761
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = Mock()

    module.run_command.return_value = (0, "procs     memory     page              disks     traps          cpu", "")
    module.run_command.return_value = (0, "r b w   avm   fre   flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id", "")
    module.run_command.return_value = (0, "0 0 0 47512 28160   51   0   0   0   0   0   1   0  116   89   17  0  1 99", "")
    module.run_command.return_value = (0, "total: 69268 1K-blocks allocated, 0 used, 69268 available", "")

    hardware = OpenBSDHardware(module)

    result = hardware.get_memory_

# Generated at 2022-06-20 17:43:56.151440
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    Hardware.collector = OpenBSDHardwareCollector
    facts = OpenBSDHardware()
    mem_facts = facts.get_memory_facts()
    assert mem_facts['memfree_mb'] >= 0
    assert mem_facts['memtotal_mb'] > 0


# Generated at 2022-06-20 17:44:03.151235
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    openbsd_hw = OpenBSDHardware({'module_setup': False})
    openbsd_hw.sysctl = {'hw.usermem': 1234}
    expected = {
        'memfree_mb': 1,
        'memtotal_mb': 1,
        'swapfree_mb': 2,
        'swaptotal_mb': 2,
    }
    openbsd_hw.module.run_command = fake_run_command(expected)
    result = openbsd_hw.get_memory_facts()

    assert all(item in result.items() for item in expected.items())


# Generated at 2022-06-20 17:44:12.359225
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = FakeAnsibleModule()
    Hardware = OpenBSDHardware(module)
    Hardware.sysctl = {'hw.usermem': 69632, 'hw.physmem': 69632}
    Hardware.module.run_command.return_value = (0, '', '')
    Hardware.module.run_command = Mock(return_value = (0, 'total: 12345K bytes allocated = 0K used, 12345K available', ''))
    memory_facts = Hardware.get_memory_facts()
    assert memory_facts == {'swaptotal_mb': 12.0, 'swapfree_mb': 12.0, 'memfree_mb': 64.0, 'memtotal_mb': 64.0}


# Generated at 2022-06-20 17:44:23.553786
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.utils import get_file_content

    mtime = time.time() // 100 * 100


# Generated at 2022-06-20 17:44:35.557858
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    o = OpenBSDHardware()
    o.module.run_command = MagicMock()
    o.module.get_bin_path = Mock()
    o.module.get_bin_path.return_value = "/sbin/sysctl"
    o.sysctl = {"hw.product": "ThinkPad X220", "hw.version": "4299CTO",
                "hw.uuid": "00020003-0004-0005-0006-000700080009",
                "hw.serialno": "R9CZM023", "hw.vendor": "LENOVO" }

# Generated at 2022-06-20 17:46:15.811462
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    expected_return_value = {'system_vendor': '',
                             'product_serial': '',
                             'product_uuid': '',
                             'product_name': '',
                             'product_version': ''}

    ohc = OpenBSDHardware(_module=None)
    assert expected_return_value == ohc.get_dmi_facts()


# Generated at 2022-06-20 17:46:18.272524
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    openbsd_hw = OpenBSDHardware()
    openbsd_hw.sysctl = {"hw.disknames": "sd0,sd1,sd2"}
    assert openbsd_hw.get_device_facts() == {'devices': ['sd0', 'sd1', 'sd2']}

# Generated at 2022-06-20 17:46:27.582771
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )

    openbsdhw = OpenBSDHardware(module)
    collected_facts = openbsdhw.populate()

    assert collected_facts['devices'] == [
        'sd0',
        'sd1',
        'sd2',
        'sd3',
        'sd4',
        'wd0',
        'wd1',
        'wd2',
        'wd3',
        'wd4',
        'wd5',
        'wd6',
        'wd7',
    ]

    assert collected_facts['system_vendor'] == 'IBM'
    assert collected_facts['product_name'] == 'IBM System x3650 -[7979AC1]-'
    assert collected_facts['product_serial'] == 'XXXXXX'
   

# Generated at 2022-06-20 17:46:30.281944
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    module.exit_json(**hardware.get_device_facts())


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-20 17:46:40.354242
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Instance of module
    module = AnsibleModule(argument_spec={})
    # Instance of class OpenBSDHardware
    OpenBSDHardwareCollector.collect(module=module)
    # Data structure with facts.
    hardware_facts = module.params['ansible_facts']['ansible_hardware']

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['processor_count'] >= 0
    assert hardware_facts['processor_cores'] >= 0
    assert len(hardware_facts['processor']) == hardware_facts['processor_count']
    assert hardware_facts['devices'] is not None



# Generated at 2022-06-20 17:46:50.471171
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    test_module = FakeModule({'sysctl': '/sbin/sysctl'})
    test_object = OpenBSDHardware(module=test_module)

    # test old style response
    test_module.run_command = lambda *args, **kwargs: (0, 'boottime = 1477124783', '')
    result = test_object.get_uptime_facts()
    assert 'uptime_seconds' in result
    expected_uptime = int(time.time()) - 1477124783
    assert result['uptime_seconds'] == expected_uptime
    assert abs(result['uptime_seconds'] - expected_uptime) < 10, "is the system clock skewed?"
    # test new style response

# Generated at 2022-06-20 17:47:02.339803
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():

    class Fake(object):
        pass

    fake = Fake()
    fake.run_command = lambda x: (0, '', '')
    fake.module = lambda x, vars: None

    hw_getmem_fact = OpenBSDHardware(fake)
    hw_getmem_fact.sysctl = {'hw.usermem': 655360,
                             'hw.ncpuonline': 1}
    hw_getmem_fact.mem_size_mb = 640
    hw_getmem_fact.mem_free_mb = 632
    hw_getmem_fact.swap_size_mb = 1023
    hw_getmem_fact.swap_free_mb = 1003

    mem_facts = hw_getmem_fact.get_memory_facts()

# Generated at 2022-06-20 17:47:07.992559
# Unit test for constructor of class OpenBSDHardware
def test_OpenBSDHardware():
    openbsd_hardware = OpenBSDHardware()
    # values need to be a collection of the fields returned by the subclass
    values = ['memfree_mb', 'memtotal_mb', 'uptime_seconds', 'devices']
    for key in values:
        assert key in openbsd_hardware.data, '%s not in %s' % (key, openbsd_hardware.data)

# Generated at 2022-06-20 17:47:14.013095
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    module = AnsibleModule()
    hardware_facts = OpenBSDHardware(module)
    hardware_facts.populate()
    assert 'devices' in hardware_facts.facts
    assert 'sd0a' in hardware_facts.facts['devices']
    assert 'sd0b' in hardware_facts.facts['devices']



# Generated at 2022-06-20 17:47:24.947757
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    def test_run_command(self, cmd):
        """
        return (rc, out, error) for each cmd to test.
        """
        command = cmd[0]
        if command == 'sysctl':
            # Fake sysctl output for the test.
            sysctl_outputs = {
                "hw.product": "Dell PowerEdge T30",
                "hw.version": "Not Specified",
                "hw.uuid": "4C4C4544-4E-4C30-3031-C5-D1-B5-C0-00-09-06-30-00-28",
                "hw.serialno": "0015EL1",
                "hw.vendor": "Dell Inc.",
            }
            # BUG: sysctl(8) returns 'hw.version: Not Specified\