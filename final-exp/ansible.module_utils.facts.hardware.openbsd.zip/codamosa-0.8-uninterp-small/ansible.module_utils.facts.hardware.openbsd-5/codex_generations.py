

# Generated at 2022-06-24 22:19:30.461061
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    OpenBSDHardware_fixture = OpenBSDHardware()
    OpenBSDHardware_fixture.module.run_command = run_command_fixture

    OpenBSDHardware_fixture.sysctl = {
        'hw.usermem': '168318320',
    }
    OpenBSDHardware_fixture.module.run_command = run_command_fixture

    OpenBSDHardware_fixture.get_memory_facts()



# Generated at 2022-06-24 22:19:33.212517
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:19:36.724948
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    rv = open_b_s_d_hardware_0.get_processor_facts()
    assert isinstance(rv, dict)


# Generated at 2022-06-24 22:19:48.942360
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    """
    This test case tests the get_device_facts function of OpenBSDHardware class.
    It creates a OpenBSDHardware object and calls get_device_facts function.
    """
    # This is the class instantiation
    open_b_s_d_hardware_0 = OpenBSDHardware()

    # This is the result variable to capture the result
    open_b_s_d_hardware_0_result = {}

    # This is the id variable to capture the id of the result
    open_b_s_d_hardware_0_id = None

    # This is the facts variable to capture the dmi facts
    open_b_s_d_hardware_0_facts = {}

    # This is the sysctl variable

# Generated at 2022-06-24 22:19:58.375959
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    # Setup the class we are going to test
    open_b_s_d_hardware_0 = OpenBSDHardware(module=None)
    # Populate the class with our hardware facts
    hardware_facts = {u'hw.uuid': u'abc123'}
    setattr(open_b_s_d_hardware_0, 'sysctl', hardware_facts)
    # Run the method we are testing
    class_output = open_b_s_d_hardware_0.get_device_facts()
    # Once the test has completed we can now assert the results
    actual_output = {'devices': []}
    assert class_output == actual_output


# Generated at 2022-06-24 22:20:05.255474
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {'hw.model': 'AMD EPYC 7702 64-Core Processor', 'hw.ncpuonline': 4}
    open_b_s_d_hardware_0.module = get_module()
    open_b_s_d_hardware_0.populate()
    open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:20:16.152254
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()

    assert open_b_s_d_hardware_collector_0 is not open_b_s_d_hardware_collector_1
    assert open_b_s_d_hardware_collector_1 is not open_b_s_d_hardware_collector_0
    assert open_b_s_d_hardware_collector_0 is not open_b_s_d_hardware_collector_0


# Generated at 2022-06-24 22:20:19.040140
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    result = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:20:23.854727
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_1 = open_b_s_d_hardware_collector_0.collect()
    open_b_s_d_hardware_1.populate()


# Generated at 2022-06-24 22:20:25.584989
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():

    # There are no test cases for "get_uptime_facts" yet ...

    pass



# Generated at 2022-06-24 22:20:35.885637
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():

    float_0 = 2315.156
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(float_0)

    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'

# Generated at 2022-06-24 22:20:39.553792
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:20:45.657525
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.module.run_command = lambda *args, **kwargs: (0, ' procs    memory       page                    disks    traps          cpu\nr b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n', '')
    open_b_s_d_hardware_0.sysctl = {'hw.usermem': '4194288000'}
    var_0 = open_b

# Generated at 2022-06-24 22:20:50.382548
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_1 = OpenBSDHardware()
    var_1 = open_b_s_d_hardware_1.get_uptime_facts()

if __name__ == "__main__":
    test_case_0()
    test_OpenBSDHardware_get_uptime_facts()

# Generated at 2022-06-24 22:20:53.978309
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    float_0 = -14.78
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:20:57.462246
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    float_0 = -1215.251
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(float_0)
    var_0 = open_b_s_d_hardware_collector_0.collect()


# Generated at 2022-06-24 22:21:00.647203
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 22:21:03.559604
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:21:06.942559
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    float_0 = -1215.251
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(float_0)
    test_case_0()

if __name__ == '__main__':
    test_OpenBSDHardwareCollector()

# Generated at 2022-06-24 22:21:09.973716
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    float_1 = 3885.74
    open_b_s_d_hardware_0 = OpenBSDHardware(float_1)
    var_1 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:21:31.055589
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    float_0 = -214.768
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:21:37.457738
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = -3638.78
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.sysctl = {'hw': {'usermem': '1051259136'}}
    var_0 = open_b_s_d_hardware_0.get_memory_facts()

test_case_0()
test_OpenBSDHardware_get_memory_facts()

# Generated at 2022-06-24 22:21:40.914709
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:21:49.490848
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # Setup
    var_0 = -1215.251
    # Procedure call
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(var_0)
    ###########################################################################
    # Test for instance variables of class OpenBSDHardwareCollector
    ###########################################################################
    assert open_b_s_d_hardware_collector_0._fact_class == OpenBSDHardware
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-24 22:21:50.485002
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:21:57.573322
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()

    assert 'hw.disknames' in open_b_s_d_hardware_0.sysctl


# Generated at 2022-06-24 22:21:59.679514
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    float_0 = 1224.734
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(float_0)


# Generated at 2022-06-24 22:22:04.022868
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:22:07.705463
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    dict_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:22:15.438233
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.sysctl = map_0 = {}
    open_b_s_d_hardware_0.sysctl['hw.usermem'] = '1228'
    result_dict_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert result_dict_0 == {'swaptotal_mb': '0', 'swapfree_mb': '0', 'memfree_mb': '0', 'memtotal_mb': '11'}



# Generated at 2022-06-24 22:22:39.989926
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    assert open_b_s_d_hardware_0.populate() == {}


# Generated at 2022-06-24 22:22:43.725610
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(-1327.6)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:22:45.368851
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert OpenBSDHardwareCollector.__bases__[0].__name__ == 'HardwareCollector'


# Generated at 2022-06-24 22:22:53.568710
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    float_0 = -359.9
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:22:56.108805
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:23:00.626073
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    float_0 = -44.849
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.populate()
    var_1 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:23:01.660593
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    test_case_0()



# Generated at 2022-06-24 22:23:06.298105
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:23:09.953119
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    float_0 = 0.0119
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 22:23:13.462533
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    float_0 = float_0
    open_b_s_d_hardware_1 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:24:03.511095
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    with timeout.timeout():
        float_0 = 36306.299428
        open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
        var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:24:09.217104
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.populate()
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:24:12.890410
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # unit test for get_memory_facts
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    dict_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:24:16.207884
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    # Test case data
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    # Invoke method
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:24:22.053905
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_1 = -1215.251
    open_b_s_d_hardware_8 = OpenBSDHardware(float_1)
    var_1 = open_b_s_d_hardware_8.populate()
    open_b_s_d_hardware_8.get_memory_facts()



# Generated at 2022-06-24 22:24:25.037793
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:24:29.299429
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    float_0 = 1079.0
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:24:32.828037
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:24:37.650908
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.populate()
    # assert
    assert_exception = False
    try:
        assert(isinstance(open_b_s_d_hardware_0.get_processor_facts(), dict))
    except AssertionError:
        assert_exception = True
    assert not assert_exception


# Generated at 2022-06-24 22:24:41.083353
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # Define method input
    float_0 = 0.0

    # Create instance of class with input
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)

    # Check instance creation
    assert open_b_s_d_hardware_0 is not None

    # Call method
    open_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:25:48.033665
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = -4187550.637
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:25:54.390250
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:26:00.691362
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # Set up mock AnsibleModule object
    module_mock = mock.MagicMock()
    module_mock.run_command.return_value = (0, '1579534807', '')

    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.module = module_mock

    # Call get_uptime_facts() as if it were called by the AnsibleModule object
    open_b_s_d_hardware_0.get_uptime_facts()

if __name__ == '__main__':
    # test_case_0()
    print("Executing Tests ...")
    test_OpenBSDHardware_get_uptime_facts()
    print("Completed Tests")

# Generated at 2022-06-24 22:26:03.907714
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    if 'OpenBSD' in platform.system():
        float_0 = -1215.251
        open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
        var_0 = open_b_s_d_hardware_0.get_uptime_facts()
        print(var_0)

# Generated at 2022-06-24 22:26:06.231768
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
  float_0 = -1215.251
  open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
  # Call get_memory_facts of OpenBSDHardware
  open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:26:07.846782
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    test_case_0()

if __name__ == '__main__':
    # test_OpenBSDHardwareCollector()
    pass

# Generated at 2022-06-24 22:26:14.550568
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.populate()

    open_b_s_d_hardware_1 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.populate()
    var_0 = open_b_s_d_hardware_0.get_memory_facts()



# Generated at 2022-06-24 22:26:18.714671
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.get_memory_facts()
    open_b_s_d_hardware_0.get_uptime_facts()
    open_b_s_d_hardware_0.populate()
    open_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:26:23.076655
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    float_0 = -3.26049
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.populate()
    # Exception: TypeError
    # Exception: TypeError
    # Exception: TypeError
    # Exception: TypeError
    # Exception: TypeError
    # Exception: TypeError
    # Exception: TypeError
    # Exception: TypeError
    # Exception: TypeError
    # Exception: TypeError


# Generated at 2022-06-24 22:26:25.156369
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = 0
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:28:44.906484
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    float_0 = -1215.251
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(float_0)
    test_case_0()

# Generated at 2022-06-24 22:28:47.103249
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    module = AnsibleModule({'content': 'content'})
    class_0 = get_class(module)
    var_0 = class_0.get_dmi_facts()


# Generated at 2022-06-24 22:28:50.017437
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:28:52.199464
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    assert open_b_s_d_hardware_0.get_memory_facts() == None


# Generated at 2022-06-24 22:28:57.913304
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:29:03.820329
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_bsd_hardware_collector_0 = OpenBSDHardwareCollector()
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.populate()
    open_bsd_hardware_collector_0.collect(open_b_s_d_hardware_0)

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDHardwareCollector()

# Generated at 2022-06-24 22:29:08.003893
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    int_0 = -0.84518476
    open_b_s_d_hardware_0 = OpenBSDHardware(int_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()

# Generated at 2022-06-24 22:29:12.894176
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    float_0 = -1215.251
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.populate()
    open_b_s_d_hardware_0.get_processor_facts()

