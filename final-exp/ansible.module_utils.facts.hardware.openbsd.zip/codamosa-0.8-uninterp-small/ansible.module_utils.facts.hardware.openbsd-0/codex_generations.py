

# Generated at 2022-06-24 22:19:34.807469
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    dict_0 = {}
    float_0 = -555.031342
    open_b_s_d_hardware_0 = OpenBSDHardware(dict_0, float_0)
    
    # Test for case where 'sysctl' fails
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(1, '', ''))
    assert open_b_s_d_hardware_0.get_uptime_facts() == {}

    # Test for case where kern.boottime is not an int
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, 'abc', ''))
    assert open_b_s_d_hardware_0.get_uptime_facts() == {}

    #

# Generated at 2022-06-24 22:19:37.450697
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule({})
    openbsd_hw_collector = OpenBSDHardware(module)
    try:
        openbsd_hw_collector.populate()
    except timeout.TimeoutError:
        pass

# Generated at 2022-06-24 22:19:49.352618
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    dict_0 = {}
    float_0 = -969.5445702
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(dict_0, float_0)
    dict_1 = {}
    dict_1['uptime_seconds'] = time.time() - int(time.time())
    dict_1['memtotal_mb'] = int(1) // 1024 // 1024
    dict_2 = {}
    dict_3 = {}

    dict_2['sysctl'] = dict_3
    open_bsd_hardware = OpenBSDHardware(open_b_s_d_hardware_collector_0, dict_2)
    dict_4 = {}
    dict_4['uptime_seconds'] = time.time() - int(time.time())

# Generated at 2022-06-24 22:19:52.347946
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    dict_0 = {}
    float_0 = -661.806979
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(dict_0, float_0)


# Generated at 2022-06-24 22:19:57.371118
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    dict_0 = {}
    float_0 = -661.806979
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(dict_0, float_0)
    open_b_s_d_hardware_0 = OpenBSDHardware({}, open_b_s_d_hardware_collector_0)
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:20:00.243561
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:20:08.415573
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    dict_0 = {}
    float_0 = -661.806979
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(dict_0, float_0)
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)

    rc, out, err = open_b_s_d_hardware_0.module.run_command("/usr/bin/vmstat")

    open_b_s_d_hardware_0.sysctl = get_sysctl(open_b_s_d_hardware_0.module, ['hw'])
    memory_facts = open_b_s_d_hardware_0.get_memory_facts()
    print(memory_facts)

# Unit

# Generated at 2022-06-24 22:20:19.637459
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {
        'hw.ncpuonline': 1,
        'hw.model': 'Broadwell',
        'hw.usermem': 8589934592,
        'hw.ncpu': 2,
        'hw.disknames': 'sd0,sd1,cd0,wd0,wd1,',
    }
    open_b_s_d_hardware_0._module = Mock(name='_module')
    open_b_s_d_hardware_0._module.run_command.return_value = [0, '123\n', '']

# Generated at 2022-06-24 22:20:22.854010
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware = OpenBSDHardware(dict(), 1.0)
    assert open_b_s_d_hardware.get_processor_facts() == {}


# Generated at 2022-06-24 22:20:26.606752
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    dict_0 = {}
    float_0 = -711.764570
    open_b_s_d_hardware_0 = OpenBSDHardware(dict_0, float_0)
    assert open_b_s_d_hardware_0.populate() == {}


# Generated at 2022-06-24 22:20:34.178057
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    helper = OpenBSDHardware(var_0)
    var_1 = helper.get_memory_facts()
    assert var_1 == None


# Generated at 2022-06-24 22:20:37.300878
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    var_1 = OpenBSDHardware(var_0)
    var_2 = var_1.get_dmi_facts()
    assert var_2 == {}, var_2


# Generated at 2022-06-24 22:20:40.733540
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    obj_0 = OpenBSDHardware()
    obj_0.sysctl = {}
    obj_0.sysctl['hw.usermem'] = 2710363136
    obj_0.module = var_0
    obj_0.get_memory_facts()


# Generated at 2022-06-24 22:20:43.248250
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    var_1 = OpenBSDHardware(var_0)
    var_2 = get_memory_facts()


# Generated at 2022-06-24 22:20:52.751320
# Unit test for method populate of class OpenBSDHardware

# Generated at 2022-06-24 22:21:02.101111
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    OpenBSDHardware._module = Mock(name='Mock AnsibleModule')
    var_2 = 'sysctl'
    def mock_get_bin_path(var_0):
        if var_0 == var_2:
            return 'sysctl'
        else:
            return var_0
    OpenBSDHardware._module.get_bin_path = mock_get_bin_path
    OpenBSDHardware._module.run_command = Mock(return_value=('0', '1549463388', ''))
    var_1 = OpenBSDHardware()
    var_1.module = Mock(name='Mock AnsibleModule')
    var_3 = {'uptime_seconds': 3}
    var_1.sysctl = {'kern.boottime': str(int(time.time())-3)}
    var_1.token

# Generated at 2022-06-24 22:21:03.299317
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    var_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:21:04.435968
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    var_0 = OpenBSDHardware()
    var_0.populate(var_0)

# Generated at 2022-06-24 22:21:06.771316
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert isinstance(openbsd_hardware_collector, OpenBSDHardwareCollector)


# Generated at 2022-06-24 22:21:14.490618
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    print('Running test_OpenBSDHardware_populate')
    var_0 = OpenBSDHardware()
    # AssertionError: None != {'memfree_mb': 1023, 'memtotal_mb': 1023, 'swapfree_mb': 1023, 'swaptotal_mb': 1023, 'processor': ['Intel(R) Core(TM) i3-2370M CPU @ 2.40GHz'], 'processor_cores': 1, 'processor_count': 1, 'processor_speed': '2394.265', 'uptime_seconds': 5006, 'mounts': [{'mount': '/', 'device': '/dev/wd0a', 'fstype': 'ffs', 'options': 'rw', 'size_total': 10324000, 'size_available': 9638400}, {'mount': '/home', 'device': 'sw

# Generated at 2022-06-24 22:21:21.489506
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    var_0 = OpenBSDHardware()
    assert var_0.populate()


# Generated at 2022-06-24 22:21:22.615290
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    pass


# Generated at 2022-06-24 22:21:23.941782
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    obj_OpenBSDHardwareCollector = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:21:31.679305
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    fixture_get_uptime_facts_0 = {
        'sysctl': {
            u'kern.boottime': u'1536691265'
        },
        'module': {
            'get_bin_path':  lambda x, **kwargs: "/bin/sysctl"
        },
        'path': {
            'exists': lambda x, **kwargs: True
        }
    }


# Generated at 2022-06-24 22:21:34.419456
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    var_0 = OpenBSDHardware()
    var_1 = {}
    assert var_0.get_uptime_facts() == var_1


# Generated at 2022-06-24 22:21:36.216061
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    var_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:21:39.802770
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    from ansible.module_utils import facts
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardwareCollector
    hardware = OpenBSDHardwareCollector(facts.Facts)
    assert hardware.alias == 'hardware'
    return


# Generated at 2022-06-24 22:21:41.923705
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    test_case_0()

# Unit test execution
if __name__ == '__main__':
    # test_OpenBSDHardware_get_uptime_facts()
    pass

# Generated at 2022-06-24 22:21:43.466579
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    var_1 = OpenBSDHardware()


# Generated at 2022-06-24 22:21:50.748740
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    my_test_case = test_case_0()
    openbsd_hardware = OpenBSDHardware()

    var_0 = my_test_case.var_0
    entry = {'memfree_mb': 0, 'memtotal_mb': 0, 'mounts': [], 'swapfree_mb': 0, 'swaptotal_mb': 0, 'processor': [], 'processor_cores': 0, 'processor_count': 0, 'processor_speed': '', 'uptime_seconds': 0, 'devices': []}
    openbsd_hardware.populate(var_0)
    assert entry == var_0



# Generated at 2022-06-24 22:21:57.432320
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:22:03.436941
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
  bytes_0 = b'\xdd\x0f\xa4\xf2E'
  open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
  var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:07.697901
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    OpenBSDHardware.get_uptime_facts(open_b_s_d_hardware_0)


# Generated at 2022-06-24 22:22:11.876057
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert var_0 == {}



# Generated at 2022-06-24 22:22:15.669173
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    dmi_facts_0 = open_b_s_d_hardware_0.get_device_facts()



# Generated at 2022-06-24 22:22:22.260681
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    open_b_s_d_hardware_0.module.get_bin_path = MagicMock(return_value=b'/usr/bin/sysctl')
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0,b'1508510672',b''))
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    expected = {
        'uptime_seconds': int(time.time() - int(1508510672)),
    }

# Generated at 2022-06-24 22:22:26.067793
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert var_0 == {}


# Generated at 2022-06-24 22:22:26.893804
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    test_case_0()


# Generated at 2022-06-24 22:22:29.983964
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:22:34.803383
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware('k')
    var_0 = open_b_s_d_hardware_0.get_processor_facts()
    open_b_s_d_hardware_0.sysctl = {
        'hw.ncpuonline': '0',
        'hw.usermem': '2',
        'hw.model': 's',
    }
    for var_1 in open_b_s_d_hardware_0.populate():
        pass


# Generated at 2022-06-24 22:22:48.043705
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    dict_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:22:53.081526
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bytes_1 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_1 = OpenBSDHardware(bytes_1)
    open_b_s_d_hardware_1.get_processor_facts()


# Generated at 2022-06-24 22:22:54.527850
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():

    # Run test against case data 0
    test_case_0()



# Generated at 2022-06-24 22:22:57.413252
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:23:02.004127
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_3 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:23:02.778542
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    test_case_0()


# Generated at 2022-06-24 22:23:06.052493
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    module = AnsibleModule(argument_spec={})
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(module)
    assert open_b_s_d_hardware_collector_0._fact_class is OpenBSDHardware
    assert open_b_s_d_hardware_collector_0._platform is 'OpenBSD'

# Generated at 2022-06-24 22:23:08.678376
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    var_0 = OpenBSDHardwareCollector(bytes_0)
    assert len(var_0.data) == 0
    assert var_0.platform == 'OpenBSD'


# Generated at 2022-06-24 22:23:10.407784
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_3 = OpenBSDHardware()
    var_0 = open_b_s_d_hardware_3.populate()


# Generated at 2022-06-24 22:23:13.431764
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bytes_0 = b'\xef\xc7P\xf8\xbe\x90\xdc'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:23:25.453842
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()

# Generated at 2022-06-24 22:23:28.826711
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():

    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_1 = open_b_s_d_hardware_0.populate()
    assert var_1=={}


# Generated at 2022-06-24 22:23:37.412628
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.populate()


if __name__ == '__main__':
    test_case_0()
    test_OpenBSDHardware_populate()

# Generated at 2022-06-24 22:23:42.903820
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:23:47.096564
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:23:52.383251
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bytes_0 = b'\x93\xb5\xbb\x06\xe8'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()

# Generated at 2022-06-24 22:23:56.260374
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:59.501780
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(b'\xa8\x1a\x0e\xce\x08\xa6\x89\x42\xdd\x0f\xa4\xf2\xfa\x98\x0f\x00\x00\x00')
    var_1 = open_b_s_d_hardware_0.get_dmi_facts()
    assert var_1 == {}


# Generated at 2022-06-24 22:24:01.339121
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:24:12.360569
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Parameter handle_duplicates='replace'
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    open_b_s_d_hardware_0.populate()
    assert re.match('^\\S+ \\S+ \\S+ \\S+ \\S+ \\S+ \\S+ \\S+ \\S+ \\S+ \\d+ \d+ \d+ \d+ \d+ \d+ \d+ \d+ \d+ \\S+$', str(open_b_s_d_hardware_0.memory_facts)) == None

    # Parameter handle_duplicates='merge'

# Generated at 2022-06-24 22:24:49.727901
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    this_is_open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    byte_0 = b'\x7f\xff\xff\xff\xff\xff\xff\xff'
    open_b_s_d_hardware_0 = OpenBSDHardware(byte_0)
    open_b_s_d_hardware_0.get_device_facts()
    open_b_s_d_hardware_0.get_dmi_facts()
    open_b_s_d_hardware_0.get_memory_facts()
    open_b_s_d_hardware_0.populate()
    open_b_s_d_hardware_0.get_mount_facts()
    open_b_s_d_hardware_0.get_processor_

# Generated at 2022-06-24 22:24:57.749644
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    open_b_s_d_hardware_0.sysctl = {'hw.usermem': '0', 'hw.ncpuonline': '0'}
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert var_0 == {'swapfree_mb': 0, 'memtotal_mb': 0, 'memfree_mb': 0, 'swaptotal_mb': 0}



# Generated at 2022-06-24 22:25:04.648324
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bytes_0 = b'\xf7L\xbb\xf5'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert var_0 == {}
    bytes_1 = b'\xf4\x8e\xbf\xf4\x86\xb4\xc8'
    open_b_s_d_hardware_1 = OpenBSDHardware(bytes_1)
    var_1 = open_b_s_d_hardware_1.get_memory_facts()
    assert var_1 == {}
    bytes_2 = b'\x1d'
    open_b_s_d_hardware_2 = OpenBSDHardware(bytes_2)
   

# Generated at 2022-06-24 22:25:08.206992
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bytes_0 = b'\xf2\x15\xf6\xdb\xcd\xea'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:25:10.718214
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:25:17.082758
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    # Preconditions
    bytes_1 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_1 = OpenBSDHardware(bytes_1)

    # Test execution

    var_2 = open_b_s_d_hardware_1.get_device_facts()

    # Postconditions
    var_2 = "devices" in var_2
    assert var_2 == True

    # Postconditions
    var_3 = "hw.disknames" in open_b_s_d_hardware_1.sysctl
    assert var_3 == True



# Generated at 2022-06-24 22:25:20.415693
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    dict_0 = open_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:25:26.449291
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert (var_0 == 'dd0fa4f24500' or var_0 == 145435773414952)


# Generated at 2022-06-24 22:25:28.680322
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    test_OpenBSDHardwareCollector_0 = OpenBSDHardwareCollector()
    return test_OpenBSDHardwareCollector_0


# Generated at 2022-06-24 22:25:32.434908
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_1 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:26:43.922116
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:26:48.180896
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    assert get_memory_facts() == 'tested'

test_OpenBSDHardware_get_memory_facts.__doc__ = OpenBSDHardware.get_memory_facts.__doc__
# ---- End of unit tests for OpenBSDHardware ----

if __name__ == '__main__':
    from pytest import main
    main('-qq -p no:warnings'.split())

# Generated at 2022-06-24 22:26:57.741918
# Unit test for method get_processor_facts of class OpenBSDHardware

# Generated at 2022-06-24 22:26:59.472585
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(b'')
    module_0 = open_b_s_d_hardware_0.module
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:27:00.139184
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    pass  # TODO

# Generated at 2022-06-24 22:27:05.046954
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:27:07.255804
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes([]))
    print(open_b_s_d_hardware_0)
    open_b_s_d_hardware_0.populate()
    print(open_b_s_d_hardware_0.platform)


# Generated at 2022-06-24 22:27:11.166319
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert isinstance(open_b_s_d_hardware_collector_0, OpenBSDHardwareCollector)


# Generated at 2022-06-24 22:27:16.343971
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:27:17.130079
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    pass


# Generated at 2022-06-24 22:28:21.419962
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:28:28.551937
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = type('', (), {})()
    collected_facts = {}
    open_b_s_d_hardware_0 = OpenBSDHardware(module, collected_facts)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert var_0 == {
        'swaptotal_mb': 553,
        'memfree_mb': 1374,
        'swapfree_mb': 553,
        'memtotal_mb': 3518
    }


# Generated at 2022-06-24 22:28:31.330810
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bytes_0 = b'\xff\xfe\xff\x80\xae\x03'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:28:37.725804
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    open_b_s_d_hardware_0._get_dmi_facts = MagicMock()

    open_b_s_d_hardware_0.get_device_facts = MagicMock()

    open_b_s_d_hardware_0.get_mount_facts = MagicMock()

    open_b_s_d_hardware_0.get_uptime_facts = MagicMock()

    open_b_s_d_hardware_0.get_memory_facts = MagicMock(return_value=var_2)

    open_b_s_d_hardware_0.get_processor_

# Generated at 2022-06-24 22:28:38.639765
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    test_case_0()


# Generated at 2022-06-24 22:28:41.604759
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:28:50.279877
# Unit test for method get_uptime_facts of class OpenBSDHardware

# Generated at 2022-06-24 22:28:53.826254
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    ''' Unit test for method get_memory_facts of class OpenBSDHardware '''
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)

    var_0 = open_b_s_d_hardware_0.get_memory_facts()



# Generated at 2022-06-24 22:29:01.555164
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    assert open_b_s_d_hardware_0.get_processor_facts() == {
        'processor': ['Intel(R) Pentium(R) M processor 2.00GHz'],
        'processor_cores': '1',
        'processor_count': '1'}

# Generated at 2022-06-24 22:29:05.952854
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    bytes_0 = b'\xdd\x0f\xa4\xf2E'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    var_1 = open_b_s_d_hardware_0.get_device_facts()
    var_2 = [u'ahci0', u'ahcich0', u'ahcich1', u'ahcich2', u'ahcich3', u'ahcich4', u'ahcich5', u'ahcich6', u'ahcich7']
    var_3 = var_1['devices']
    assert var_3 == var_2
