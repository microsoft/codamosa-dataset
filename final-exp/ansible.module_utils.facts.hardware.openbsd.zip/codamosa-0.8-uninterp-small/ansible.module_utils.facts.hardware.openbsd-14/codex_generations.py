

# Generated at 2022-06-24 22:19:27.078074
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware({'sysctl': {'hw.product': 'SuperServer A1SAi-2550F', 'hw.version': '0123AB', 'hw.uuid': '0011-2233-4455-6677-8899-AABBCCDDEEFF', 'hw.serialno': '12345', 'hw.vendor': 'SuperMicro'}})
    open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:19:31.478716
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {u'hw.usermem': 2936012800}
    open_b_s_d_hardware_0.module = AnsibleModuleMock()
    open_b_s_d_hardware_0.module.run_command.return_value = (0, u' procs    memory       page                    disks    traps          cpu\n r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n 0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', '')

    open_b

# Generated at 2022-06-24 22:19:37.871022
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware({}, {}, open_b_s_d_hardware_collector_0)

    rc, out, err = open_b_s_d_hardware_0.module.run_command("sysctl hw.ncpuonline")
    if rc == 0:
        open_b_s_d_hardware_0.sysctl['hw.ncpuonline'] = out.split('=')[1].split()[0]
    
    rc, out, err = open_b_s_d_hardware_0.module.run_command("sysctl hw.model")
    if rc == 0:
        open_b_s_d_hardware_

# Generated at 2022-06-24 22:19:45.060110
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    print('Testing get_processor_facts')

    # test 0
    open_b_s_d_hardware = OpenBSDHardware({}, {})
    open_b_s_d_hardware_get_processor_facts_0 = open_b_s_d_hardware.get_processor_facts()
    print('get_processor_facts: ', open_b_s_d_hardware_get_processor_facts_0)


# Generated at 2022-06-24 22:19:49.163257
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.get_processor_facts()

# Generated at 2022-06-24 22:19:51.714524
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    test_case_OpenBSDHardware_populate_0()


# Generated at 2022-06-24 22:20:02.073484
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, 'RTL8111/8168/8411 PCI Express Gigabit Ethernet Controller (rev 0c)', ''))
    open_b_s_d_hardware_0.sysctl = {"hw.ncpuonline": "4", "hw.model": "Intel(R) Core(TM) i5-7200U CPU @ 2.50GHz"}

    processor_facts = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:20:04.607574
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    memory_facts = open_b_s_d_hardware_0.get_memory_facts()
    assert isinstance(memory_facts, dict) is True


# Generated at 2022-06-24 22:20:10.035590
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0._fact_class == OpenBSDHardware
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'

# Generated at 2022-06-24 22:20:13.836218
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()

   # Test 'platform' attribute.
    assert open_b_s_d_hardware_collector_0.platform == 'OpenBSD'



# Generated at 2022-06-24 22:20:22.030638
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware()


# Generated at 2022-06-24 22:20:26.319584
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # First test case
    open_b_s_d_hardware_0 = OpenBSDHardware()
    return_value_1 = open_b_s_d_hardware_0.get_memory_facts()
    # If assert fails, the test case will stop here.
    assert return_value_1 == {}


# Generated at 2022-06-24 22:20:28.811441
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:20:34.178615
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    assert open_b_s_d_hardware_0.get_memory_facts() == {'memfree_mb': 566, 'memtotal_mb': 8128, 'swapfree_mb': 1341, 'swaptotal_mb': 1342}



# Generated at 2022-06-24 22:20:41.146393
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware = OpenBSDHardware()

# Generated at 2022-06-24 22:20:43.472160
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:20:45.384586
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert(isinstance(OpenBSDHardwareCollector(), OpenBSDHardwareCollector))


# Generated at 2022-06-24 22:20:46.391984
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    pass


# Generated at 2022-06-24 22:20:52.690616
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    device_facts = {}
    devices = []

    # Call method
    open_b_s_d_hardware_0.sysctl = {'hw.disknames': 'wd0,cd0'}
    device_facts = open_b_s_d_hardware_0.get_device_facts()

    # Check results
    devices.extend(['wd0', 'cd0'])
    assert device_facts['devices'] == devices


# Generated at 2022-06-24 22:20:55.196010
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:21:09.469838
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():

    # Setup
    str_0 = '29W;s`\\yQIuCSmb'
    open_b_s_d_hardware_0 = OpenBSDHardware({str_0: str_0, str_0: str_0, str_0: str_0})
    str_1 = ''
    str_2 = ''
    str_3 = ''

    # Exercise
    var_0 = open_b_s_d_hardware_0.get_processor_facts()

    # Verify (partial)
    assert var_0['processor'] == ['Intel(R) Atom(TM) CPU  C2750  @ 2.40GHz'], var_0['processor']
    assert var_0['processor_count'] == '4', var_0['processor_count']

# Generated at 2022-06-24 22:21:13.412049
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '29W;s`\\yQIuCSmb'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    open_b_s_d_hardware_0 = OpenBSDHardware(dict_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:21:18.245928
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    data = ('$ sysctl -n kern.boottime\n'
            '{ sec = 1559681264, usec = 124704 } Sun Jun 16 01:14:24 2019\n')
    out = to_text(data, errors='surrogate_or_strict').split()
    uptime_seconds = int(time.time()) - int(out[3])
    assert uptime_seconds == 12



# Generated at 2022-06-24 22:21:24.547363
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = '&?aMzvY'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    open_b_s_d_hardware_0 = OpenBSDHardware(dict_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:21:25.685602
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert True


# Generated at 2022-06-24 22:21:33.519167
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    # Create an instance of class OpenBSDHardware
    str_0 = '29W;s`\\yQIuCSmb'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    open_b_s_d_hardware_0 = OpenBSDHardware(dict_0)
    # Call get_device_facts on this instance
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:21:37.457200
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # try with str_0
    str_0 = '29W;s`\\yQIuCSmb'
    open_b_s_d_hardware_0 = OpenBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:21:42.135774
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = 'O{Nx]a'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    open_b_s_d_hardware_0 = OpenBSDHardware(dict_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:21:47.571300
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    dict_0 = {'hw.ncpuonline': 'hw.ncpuonline'}
    open_b_s_d_hardware_0 = OpenBSDHardware(dict_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:21:49.020564
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    p_collector = OpenBSDHardwareCollector()
    assert p_collector != None


# Generated at 2022-06-24 22:21:56.331588
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:22:00.282464
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = 'PpER+'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'
    assert open_b_s_d_hardware_collector_0._fact_class == OpenBSDHardware


# Generated at 2022-06-24 22:22:03.107377
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert OpenBSDHardwareCollector()._collectors == [OpenBSDHardwareCollector()]

# Generated at 2022-06-24 22:22:07.658340
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:09.987313
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:22:14.384177
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    # Call method populate of class OpenBSDHardware
    assert open_b_s_d_hardware_0.populate() == None


# Generated at 2022-06-24 22:22:18.296841
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = 'Tm1yc'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:22:22.061211
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = 'm+z&V'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    int_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:22:25.119956
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:22:30.099854
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = 'PpER+'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    assert open_b_s_d_hardware_collector_0.platform == 'OpenBSD'


# Generated at 2022-06-24 22:22:50.629421
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:22:54.229917
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:22:56.881044
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:23:00.526304
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:23:09.799706
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    var_1 = open_b_s_d_hardware_0.get_device_facts()
    var_2 = open_b_s_d_hardware_0.get_memory_facts()
    var_3 = open_b_s_d_hardware_0.get_mount_facts()
    var_4 = open_b_s_d_hardware_0.get_processor_facts()
    var_5 = open_b_s_d_hardware_0.get_dmi_facts()
    var_6 = open_b_s_d

# Generated at 2022-06-24 22:23:13.577393
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.populate()
    var_0 = open_b_s_d_hardware_0.get_device_facts()
    assert type(var_0) is dict
    assert var_0['devices'] == 'fzyEJv'


# Generated at 2022-06-24 22:23:16.664497
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'CQ=X9'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_1 = OpenBSDHardware('z2_gN')
    var_0 = open_b_s_d_hardware_1.populate(open_b_s_d_hardware_0)

# Generated at 2022-06-24 22:23:23.076688
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_1 = 'PpER+'
    open_b_s_d_hardware_1 = OpenBSDHardware(str_1)
    bool_0 = open_b_s_d_hardware_1.get_device_facts()
    # assert isinstance(bool_0, dict)


# Generated at 2022-06-24 22:23:25.040551
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    try:
        OpenBSDHardwareCollector()
    except Exception as exception_0:
        assert type(exception_0) == TypeError


# Generated at 2022-06-24 22:23:25.900288
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    test_case_0()

# Generated at 2022-06-24 22:24:12.555329
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    # test_case_0
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:24:17.154273
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = 'PpER+'
    open_b_s_d_hardware_1 = OpenBSDHardware(str_0)
    # AssertionError: <MagicMock name='mock.get_sysctl.return_value.__getitem__()' id='4484289832'> != 'Lorem ipsum'
    #var_0 = open_b_s_d_hardware_1.get_dmi_facts()


# Generated at 2022-06-24 22:24:22.102332
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)

    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:24:26.227102
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = 'X-g:d'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()
    var_1 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:24:27.986352
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:24:32.040356
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:24:34.745791
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = 'A6U/='
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    assert open_b_s_d_hardware_collector_0._fact_class == OpenBSDHardware


# Generated at 2022-06-24 22:24:37.620022
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()



# Generated at 2022-06-24 22:24:38.343201
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    test_case_0()


# Generated at 2022-06-24 22:24:43.955011
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware('PpER+')
    open_b_s_d_hardware_0.get_device_facts = mock.Mock()
    open_b_s_d_hardware_0.get_dmi_facts = mock.Mock()
    open_b_s_d_hardware_0.get_memory_facts = mock.Mock()
    open_b_s_d_hardware_0.get_mount_facts = mock.Mock()
    open_b_s_d_hardware_0.get_processor_facts = mock.Mock()
    open_b_s_d_hardware_0.get_uptime_facts = mock.Mock()
    var_0 = open_b_s_d_hardware_0

# Generated at 2022-06-24 22:26:59.852556
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'D6aXU'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()
    assert type(var_0) is dict
    var_1 = open_b_s_d_hardware_0.get_processor_facts()
    assert type(var_1) is dict


# Generated at 2022-06-24 22:27:02.340123
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    assert get_processor_facts() == None


# Generated at 2022-06-24 22:27:05.253083
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:27:07.449475
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:27:11.765310
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:27:18.421986
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec = dict(
            module_name = dict(type='str', required=True),
            module_args = dict(type='str', required=True),
        ),
        supports_check_mode=True
    )
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    result = open_b_s_d_hardware_0.get_device_facts()
    assert result == {}


# Generated at 2022-06-24 22:27:22.824663
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()
    assert var_0 == {}

test_case_0()
test_OpenBSDHardware_get_processor_facts()

# Generated at 2022-06-24 22:27:27.924331
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:27:34.457318
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_dmi_facts = MagicMock(return_value={})
    open_b_s_d_hardware_0.get_device_facts = MagicMock(return_value={})
    open_b_s_d_hardware_0.get_mount_facts = MagicMock(return_value={})
    open_b_s_d_hardware_0.get_memory_facts = MagicMock(return_value={})
    open_b_s_d_hardware_0.get_uptime_facts = MagicMock(return_value={})
    open_b_s_d_hardware_

# Generated at 2022-06-24 22:27:39.567589
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    moduleMock = Mock()
    moduleMock.run_command.return_value = (0, 'kern.boottime: 507830540.0 seconds')
    str_0 = 'PpER+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.module = moduleMock
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert var_0['uptime_seconds'] == 495
