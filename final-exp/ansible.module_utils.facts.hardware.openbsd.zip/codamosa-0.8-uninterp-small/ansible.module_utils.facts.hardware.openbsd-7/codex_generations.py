

# Generated at 2022-06-24 22:19:27.491156
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert isinstance(open_b_s_d_hardware_collector_0, OpenBSDHardwareCollector)


# Generated at 2022-06-24 22:19:29.629334
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert callable(OpenBSDHardwareCollector)


# Generated at 2022-06-24 22:19:34.059157
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_instance_0 = OpenBSDHardware()
    open_b_s_d_hardware_instance_0.get_device_facts()


# Generated at 2022-06-24 22:19:46.363707
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    hardware = OpenBSDHardware()

# Generated at 2022-06-24 22:19:56.887181
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    hardware = OpenBSDHardware()

    ######################
    # Setup Fixed Inputs #
    ######################

    # Set the 'module' class attribute to the mock module.
    hardware.module = MagicMock()
    hardware.module.run_command.return_value = (0, '1427376924', '')

    ######################
    # Setup Fixed Inputs #
    ######################

    #######################
    # Exercise the method #
    #######################

    # Execute the code to be tested.
    results = hardware.get_uptime_facts()

    ######################
    # Validate Expected  #
    ######################

    assert results == {u'uptime_seconds': 1427376924}


# Generated at 2022-06-24 22:20:01.242544
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware({})
    # Test with valid parameter
    result = open_b_s_d_hardware_0.get_device_facts()
    assert (result["devices"] == []) is True


# Generated at 2022-06-24 22:20:05.058844
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'
    assert open_b_s_d_hardware_collector_0._fact_class == OpenBSDHardware

# Generated at 2022-06-24 22:20:08.908352
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware = OpenBSDHardware()
    open_b_s_d_hardware_populate = open_b_s_d_hardware.populate()


# Generated at 2022-06-24 22:20:10.799239
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:20:21.977331
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Memory only
    open_b_s_d_hardware_0 = OpenBSDHardware({'run_command_environ_update': {'PATH': ['/bin', '/usr/bin', '/sbin', '/usr/sbin', '/usr/local/bin', '/usr/local/sbin']}, 'sysctl': {'hw.usermem': '12884901888', 'hw.ncpuonline': '4', 'hw.model': 'Intel(R) Xeon(R) CPU E5-2640 v4 @ 2.40GHz', 'hw.disknames': 'wd0,wd1,wd2,wd3,wd4,wd5,wd6,wd7,', 'hw.realmem': '4194304'}})

    # Memory and processors only
    open_b_s_d_hardware_1 = OpenBSDHardware

# Generated at 2022-06-24 22:20:32.081832
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0._fact_class.get_device_facts() == {'devices': ['sd0', 'sd1']}


# Generated at 2022-06-24 22:20:36.585894
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_1 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()
    open_b_s_d_hardware_1.populate()


# Generated at 2022-06-24 22:20:42.104360
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(
        module=AnsibleModule(
            argument_spec=dict()
        )
    )
    assert (open_b_s_d_hardware_0.get_memory_facts() == {
        'memfree_mb': 3748,
        'memtotal_mb': 8051,
        'swapfree_mb': 1534,
        'swaptotal_mb': 2047
    })


# Generated at 2022-06-24 22:20:43.538015
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    pass


# Generated at 2022-06-24 22:20:46.206582
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():

    open_b_s_d_hardware_0 = OpenBSDHardware({})
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:20:49.115378
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    d1 = OpenBSDHardware()
    d1.populate()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDHardware_populate()

# Generated at 2022-06-24 22:20:52.056434
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:20:55.016479
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    assert open_b_s_d_hardware_0.get_uptime_facts() == {}


# Generated at 2022-06-24 22:21:02.194304
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    test_hostname = 'host'
    test_module = MagicMock()
    test_module.run_command = MagicMock(return_value=(1, 'output', 'error'))
    test_module.get_bin_path = MagicMock(return_value='/bin/sysctl')
    test_module.params = {'gather_subset': 'all'}
    test_module.get_file_content = MagicMock(return_value='/etc/fstab')
    test_module.collect_subset = MagicMock(return_value=None)

    open_b_s_d_hardware_0 = OpenBSDHardware(test_module)

# Generated at 2022-06-24 22:21:09.861211
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module = True
    open_b_s_d_hardware_0.sysctl = True
    open_b_s_d_hardware_0.run_command = True
    open_b_s_d_hardware_0.get_mount_size = True

    open_b_s_d_hardware_0.sysctl['hw.ncpuonline'] = True
    open_b_s_d_hardware_0.sysctl['hw.model'] = True

    open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:21:18.971494
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'tcN1($O@'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 22:21:24.075564
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = 'nQbH1{z.Rt^|C9T!x'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:21:27.564379
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '_&Z:z:+]D'
    open_b_s_d_hardware_1 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:21:34.391341
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = 'F:&NABofE '
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)

    # Call method get_uptime_facts of OpenBSDHardware
    assert open_b_s_d_hardware_0.get_uptime_facts() == {}

    # Call method get_uptime_facts of OpenBSDHardware
    assert open_b_s_d_hardware_0.get_uptime_facts() == {}

    # Call method get_uptime_facts of OpenBSDHardware
    assert open_b_s_d_hardware_0.get_uptime_facts() == {}



# Generated at 2022-06-24 22:21:36.570813
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:21:39.100053
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    i_0 = OpenBSDHardware('/M:$S\\R-IpZNTt')
    var_0 = i_0.get_uptime_facts()


# Generated at 2022-06-24 22:21:42.135685
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '&el`<4X2l'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:21:44.667273
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:21:50.707411
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:21:52.817056
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = 'X4Nq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:22:05.687496
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:22:07.755380
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()

# Generated at 2022-06-24 22:22:11.146916
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware('/M:$S\\R-IpZNTt')
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:22:15.438784
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()
    var_1 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:22:18.584647
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    return var_0


# Generated at 2022-06-24 22:22:21.718687
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:22:29.355960
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = 'M%c\\8A=c%+eZ\\l'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    str_1 = '_<M1$9^`-o#DApa3Y'
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector(str_1)
    assert open_b_s_d_hardware_collector_1._fact_class == open_b_s_d_hardware_collector_0._fact_class
    assert open_b_s_d_hardware_collector_1._platform == open_b_s_d_hardware_collector_0._platform


# Generated at 2022-06-24 22:22:32.761002
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'M@g$B7YP`*'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0._get_processor_facts()


# Generated at 2022-06-24 22:22:44.686596
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'd<Yg?_'
    str_1 = '~[)G('
    str_2 = 'Ui`$U'
    str_3 = '#G['
    str_4 = '^b'
    str_5 = 'T&w\T'
    str_6 = 'Jy'
    str_7 = '#z'
    str_8 = 'wC#'
    str_9 = 'g|'
    str_10 = '+^'
    str_11 = 'c6R'
    str_12 = 'Gn'
    str_13 = 'c%'
    str_14 = 'q'
    str_15 = 'Y'
    str_16 = '\'M'
    str_17 = 'D'

# Generated at 2022-06-24 22:22:49.084451
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    string_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(string_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:23:13.214401
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:23:14.404151
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_1 = 'OpenBSD'
    class_0 = OpenBSDHardwareCollector(str_1)


# Generated at 2022-06-24 22:23:19.975407
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:23:28.354819
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.sysctl = {'hw.usermem': '16086291456', 'hw.ncpuonline': '4'}
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=({'rc': 0, 'stdout': '', 'stderr': ''}))
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert len(var_0) == 4


# Generated at 2022-06-24 22:23:37.363996
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '2.3.3.7'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)

    var_0 = open_b_s_d_hardware_0.populate()
    assert var_0 == None

    str_0 = 'L-1Z[G,8W97PKY'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)

    var_0 = open_b_s_d_hardware_0.populate()
    assert var_0 == None

    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)

    var_0 = open_b_s_d_hardware

# Generated at 2022-06-24 22:23:46.081166
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    dict_0 = {}
    dict_0 = open_b_s_d_hardware_0.populate()
    assert dict_0 == {'devices': [], 'memfree_mb': 5026, 'mounts': [], 'processor': ['Intel(R) Core(TM) i7-7500U CPU @ 2.70GHz'], 'processor_cores': 1, 'processor_count': 1, 'memory_mb': {'memtotal_mb': 5027, 'swapfree_mb': 4997, 'swaptotal_mb': 5027}}

# Generated at 2022-06-24 22:23:57.259663
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )

    open_b_s_d_hardware_0 = OpenBSDHardware(module)
    var_1 = open_b_s_d_hardware_0.populate()
    mount_facts = open_b_s_d_hardware_0.get_mount_facts()
    assert 'mounts' in mount_facts
    assert 'device' in mount_facts['mounts'][0]
    assert 'fstype' in mount_facts['mounts'][0]
    assert 'mount' in mount_facts['mounts'][0]
    assert 'options' in mount_facts['mounts'][0]
    assert 'size_available' in mount_facts['mounts'][0]

# Generated at 2022-06-24 22:24:00.463618
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '@-dL^#,(Fv*Y0i'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:24:02.818030
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    mem = OpenBSDHardware('')
    mem.sysctl = get_sysctl(None, ['hw'])
    mem.get_memory_facts()


# Generated at 2022-06-24 22:24:09.227198
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()
    assert var_0 != None
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 22:24:42.471087
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = 'Xtt'
    sysctl_1 = {'hw.disknames': '*Y$m nZ.j'}
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts(sysctl_1)


# Generated at 2022-06-24 22:24:45.573448
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    try:
        OpenBSDHardwareCollector()
    except TypeError:
        pass
    else:
        raise Exception("Unit test failed as OpenBSDHardwareCollector() wasn't supposed to return anything")


# Generated at 2022-06-24 22:24:54.383639
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    print("Testing populate")
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()
    assert 'mounts' in var_0
    assert 'memtotal_mb' in var_0
    assert 'swaptotal_mb' in var_0
    assert 'devices' in var_0
    assert 'processor' in var_0
    assert 'product_serial' in var_0
    assert 'processor_cores' in var_0
    assert 'processor_count' in var_0
    assert 'uptime_seconds' in var_0
    assert 'memfree_mb' in var_0

# Generated at 2022-06-24 22:25:01.870645
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '^F(Htr'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, 'O', ''))
    var_0 = open_b_s_d_hardware_0.get_processor_facts()
    assert var_0 == {'processor_speed': 'O', 'processor_count': 1, 'processor_cores': 1}


# Generated at 2022-06-24 22:25:05.402270
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    test_case_0()

# Unit tests for class OpenBSDHardwareCollector
# Unit tests for method populate_facts of class OpenBSDHardwareCollector

# Generated at 2022-06-24 22:25:08.169883
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)

    assert open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:25:13.793956
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # OpenBSDHardwareCollector instantiation
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    assert open_b_s_d_hardware_collector_0.platform == 'OpenBSD'
    assert open_b_s_d_hardware_collector_0.fact_class.platform == 'OpenBSD'


# Generated at 2022-06-24 22:25:19.123534
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    tuple_0 = ('vB',)
    var_1 = open_b_s_d_hardware_0.get_device_facts(tuple_0)


# Generated at 2022-06-24 22:25:22.065780
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:25:30.006948
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = 'GI*$|JH#}'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    dict_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert len(dict_0) == 4
    assert dict_0.get('swapfree_mb') == 96
    assert dict_0.get('memfree_mb') == 48
    assert dict_0.get('swaptotal_mb') == 96
    assert dict_0.get('memtotal_mb') == 48


# Generated at 2022-06-24 22:26:44.819940
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:26:48.504192
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = 'avvX8W=_3s/s'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:26:52.514881
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:26:56.692367
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:27:07.262547
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    # Test case 1
    test_file_content_0 = str()
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_file_content = lambda  *args, **kwargs: test_file_content_0
    test_sysctl_0 = {str_0: str()}
    open_b_s_d_hardware_0.sysctl = test_sysctl_0
    var_0 = open_b_s_d_hardware_0.get_device_facts()
    assert var_0 == {'devices': []}
    # Test case 2
    test_file_content_1 = str()
    str_1

# Generated at 2022-06-24 22:27:11.858845
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0._get_memory_facts()


# Generated at 2022-06-24 22:27:14.776008
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    #assert var_0 == 'hw.usermem'


# Generated at 2022-06-24 22:27:23.029038
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '0pU`Nc=6'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_1 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_2 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_3 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_4 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_5 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_6 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_7 = OpenBSDHardware(str_0)

# Generated at 2022-06-24 22:27:24.087055
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    obj_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:27:30.256212
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    get_file_content_0 = get_file_content()
    str_0 = '/M:$S\\R-IpZNTt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts(get_file_content_0)
