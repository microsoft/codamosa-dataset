

# Generated at 2022-06-24 22:19:33.955706
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    print('Test case: test_OpenBSDHardware_get_uptime_facts')
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()

    open_b_s_d_hardware_collector_1.module.run_command = lambda *args, **kwargs: (0, 1548701370, '')
    assert open_b_s_d_hardware_collector_1.get_uptime_facts() == {'uptime_seconds': 493}


# Generated at 2022-06-24 22:19:37.487005
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware(get_sysctl, get_mount_size, get_file_content)
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:19:41.359314
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    if True:
        str_0 = '8A$\x0e'
        open_b_s_d_hardware_0 = OpenBSDHardware(str_0)



# Generated at 2022-06-24 22:19:44.466462
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_1 = '))%\x0b\x17'
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector(str_1)

# Generated at 2022-06-24 22:19:54.494533
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_3 = 'C\xf2\x0e0\x1a@\xd1\xbe\xc9\x0b\x04\xa2\x89\x10\x1d\x1f\xe4\x1c]\xfe\xa4'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_3)
    str_4 = 'C\xf2\x0e0\x1a@\xd1\xbe\xc9\x0b\x04\xa2\x89\x10\x1d\x1f\xe4\x1c]\xfe\xa4'
    dict_0 = open_b_s_d_hardware_0.get_uptime_facts(str_4)


# Generated at 2022-06-24 22:19:55.490965
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    test_case_0()


# Generated at 2022-06-24 22:20:01.081994
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector('test_str')
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0, 'test_str_1')
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:20:07.414084
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'A3DE'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.sysctl = {
        'hw.ncpuonline': '1',
        'hw.model': '2',
    }
    var_1 = open_b_s_d_hardware_0.get_processor_facts()
    assert var_1 == {
        'processor': ['2'],
        'processor_cores': '1',
        'processor_count': '1',
    }


# Generated at 2022-06-24 22:20:12.435966
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    print('Testing get_uptime_facts for class OpenBSDHardware')
    open_b_s_d_hardware_0 = OpenBSDHardware(module)
    open_b_s_d_hardware_0.populate()
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:20:15.821208
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts(): 
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:20:29.224270
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {'hw.usermem': '100000000'}
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0,'0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99',''))
    get_memory_facts_ret_val = open_b_s_d_hardware_0.get_memory_facts()
    assert get_memory_facts_ret_val == {'memfree_mb': 27, 'memtotal_mb': 96}

# Generated at 2022-06-24 22:20:32.883968
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()

    assert open_b_s_d_hardware_0.get_uptime_facts() == {}


# Generated at 2022-06-24 22:20:38.342163
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # Setup
    OpenBSDHardware = open_b_s_d_hardware_collector_0._fact_class()
    OpenBSDHardware.module = AnsibleModuleStub()

    # Test
    OpenBSDHardware.get_uptime_facts()

    # Generated result and expected result
    expected = [{}]
    assert OpenBSDHardware.sysctl['kern.boottime'] == expected


# Generated at 2022-06-24 22:20:42.863139
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(dict())
    open_b_s_d_hardware_0.sysctl = {'hw.usermem': '6073740288'}

    rc, out, err = open_b_s_d_hardware_0.module.run_command("/usr/bin/vmstat")

    if rc != 0:
        open_b_s_d_hardware_0.module.fail_json(msg=err)

    open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:20:48.698444
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_1._platform == 'OpenBSD'
    assert open_b_s_d_hardware_collector_1._fact_class == OpenBSDHardware
    assert open_b_s_d_hardware_collector_1.platform == 'OpenBSD'


# Generated at 2022-06-24 22:20:56.652147
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware = OpenBSDHardware()
    open_b_s_d_hardware.sysctl = {'hw.ncpuonline': '2',
                                  'hw.model': 'AMD-Opteron(tm) Processor 6276'}
    assert open_b_s_d_hardware.get_processor_facts(
    ) == {'processor': ['AMD-Opteron(tm) Processor 6276',
                        'AMD-Opteron(tm) Processor 6276'],
           'processor_cores': '2',
           'processor_count': '2'}


# Generated at 2022-06-24 22:21:01.317307
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    testopenbsdhardwareobj = OpenBSDHardware()
    testopenbsdhardwareobj.sysctl = {'hw.disknames': 'sd0,sd1'}
    testopenbsdhardwareobj.module = "Fake Module"
    assert testopenbsdhardwareobj.get_device_facts() == {'devices': ['sd0', 'sd1']}


# Generated at 2022-06-24 22:21:08.753888
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    sysctl = {'hw.usermem': 17179869184, 'hw.ncpu': 1, 'hw.pagesize': 4096, 'hw.physmem': 68719476736, 'hw.ncpuonline': 1}
    open_b_s_d_hardware_0.sysctl = sysctl
    assert open_b_s_d_hardware_0.get_memory_facts() == {'swaptotal_mb': 6711104, 'swapfree_mb': 6711104, 'memfree_mb': 166670, 'memtotal_mb': 16376}


# Generated at 2022-06-24 22:21:12.368882
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():

    # Test with invalid value for rc variable
    open_bsd_hardware_obj = OpenBSDHardware()
    open_bsd_hardware_obj.module.run_command = MagicMock(return_value=(100,"Invalid","Invalid"))
    assert open_bsd_hardware_obj.get_memory_facts() == {}


# Generated at 2022-06-24 22:21:15.841484
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    OpenBSDHardware_instance = OpenBSDHardware()
    print('### test_OpenBSDHardware_get_uptime_facts:')
    print('# Running OpenBSDHardware.get_uptime_facts()')
    print(OpenBSDHardware_instance.get_uptime_facts())


# Generated at 2022-06-24 22:21:33.071820
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_instance = OpenBSDHardwareCollector()

    result = open_b_s_d_hardware_instance.get_processor_facts()
    assert result == {'processor': ['Intel(R) Core(TM) i7-7700HQ CPU @ 2.80GHz'], 'processor_count': '8', 'processor_cores': '8'}


# Generated at 2022-06-24 22:21:36.225581
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()

    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:21:40.158701
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardwareCollector()
    for i in range(4):
        if __name__ == '__main__':
            open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:21:43.466672
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    print(OpenBSDHardware.get_processor_facts())


# Generated at 2022-06-24 22:21:51.608360
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '  procs    memory       page                    disks    traps          cpu\n  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n', ''))
    open_b_s_d_hardware_0.sysctl = {'hw.usermem': '1688824320'}
    result1 = open_b_s_d_hardware_0.get_memory

# Generated at 2022-06-24 22:22:00.961823
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    if not open_b_s_d_hardware_collector_0.__class__.__doc__:
        open_b_s_d_hardware_collector_0.__class__.__doc__ = ""
    if not open_b_s_d_hardware_collector_0.__init__.__doc__:
        open_b_s_d_hardware_collector_0.__init__.__doc__ = ""

    assert open_b_s_d_hardware_collector_0.__class__.__doc__ == "OpenBSDHardwareCollector class\n\n    OpenBSDHardwareCollector is a subclass of HardwareCollector.\n    It collects facts about OpenBSD-specific hardware.\n    "
    assert open_b_s_d_hardware_collector_0.__init

# Generated at 2022-06-24 22:22:01.398958
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    pass

# Generated at 2022-06-24 22:22:03.864802
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:22:11.875786
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.get_memory_facts()
    open_b_s_d_hardware_0.sysctl = {
        'hw.usermem': '4736',
        'hw.physmem': '4736',
        'hw.usermem64': '4736',
        'hw.physmem64': '4736',
        'hw.ncpuonline': '1',
    }
    open_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:22:18.212135
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    current_time = int(time.time())
    uptime_seconds = int(current_time - executed_time)
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()
    open_b_s_d_hardware_get_uptime_facts_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert open_b_s_d_hardware_get_uptime_facts_0 == {'uptime_seconds': uptime_seconds}


# Generated at 2022-06-24 22:22:40.122116
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)

    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:22:42.223310
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
  obj = OpenBSDHardwareCollector()
  obj.populate()


# Generated at 2022-06-24 22:22:48.993423
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # Input parameters initialization
    open_b_s_d_hardware_0 = OpenBSDHardware(False)
    # Invoke method
    result = open_b_s_d_hardware_0.get_memory_facts()
    # Check results
    print(result)
    assert len(result) == 5
    assert 'swaptotal_mb' in result
    assert 'memfree_mb' in result
    assert 'memtotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'ansible_memfree_mb' in result

# Generated at 2022-06-24 22:22:51.722999
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:22:53.763686
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    bool_0 = False
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(bool_0)

# Generated at 2022-06-24 22:22:58.173947
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    bool_0 = True
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.sysctl = dict()
    open_b_s_d_hardware_0.sysctl['hw.disknames'] = ','
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:23:00.871032
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert OpenBSDHardwareCollector._fact_class is OpenBSDHardware
    # assert OpenBSDHardwareCollector._platform is 'OpenBSD'

# Generated at 2022-06-24 22:23:03.249893
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    assert callable(OpenBSDHardware.get_uptime_facts)



# Generated at 2022-06-24 22:23:04.585114
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardwareCollector(bool_0)

# Generated at 2022-06-24 22:23:06.402644
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:23:29.265006
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    _fixture_setup()
    _fixture_teardown()



# Generated at 2022-06-24 22:23:35.502084
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.get_dmi_facts()



# Generated at 2022-06-24 22:23:38.623484
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    


# Generated at 2022-06-24 22:23:41.065048
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:43.516307
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector0 = OpenBSDHardwareCollector()

import unittest


# Generated at 2022-06-24 22:23:44.608404
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # Case '0'
    test_case_0()



# Generated at 2022-06-24 22:23:48.276496
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    bool_0 = False
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(bool_0)
    open_b_s_d_hardware_collector_0.collect()

# Generated at 2022-06-24 22:23:58.554184
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    fixture = [
        "procs    memory       page                    disks    traps          cpu",
        "r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id",
        "0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99",
    ]

    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)

    open_b_s_d_hardware_0.module.run_command = Mock(return_value = (0,"\n".join(fixture),''))

# Generated at 2022-06-24 22:24:01.886097
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    bool_0 = False
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(bool_0)
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-24 22:24:05.740046
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()
    assert var_0['devices'] == ['']


# Generated at 2022-06-24 22:25:02.337067
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():

    assert(var_0 != None)

# Generated at 2022-06-24 22:25:08.090000
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bool_0 = None
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert var_0['memtotal_mb'] is not None
    assert var_0['swaptotal_mb'] is not None


# Generated at 2022-06-24 22:25:10.237780
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:25:17.304527
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module_0 = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', required=False, default=['!all']),
            filter=dict(default=None, required=False)
        ),
        supports_check_mode=False
    )
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0, module_0)

    try:
        open_b_s_d_hardware_0.populate()
    except Exception as exception_0:
        exception_0.args += (open_b_s_d_hardware_0.module.params['filter'],)
        raise


# Generated at 2022-06-24 22:25:20.485936
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert var_0 == {}


# Generated at 2022-06-24 22:25:26.153334
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert var_0 == {'memfree_mb': None, 'memtotal_mb': None, 'swapfree_mb': None, 'swaptotal_mb': None}


# Generated at 2022-06-24 22:25:29.112180
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:25:32.147845
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # test OpenBSDHardwareCollector on virtual machine
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_collector_0.collect()

# Generated at 2022-06-24 22:25:34.380499
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware(None)
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:25:39.311609
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()
    bool_1 = False
    open_b_s_d_hardware_1 = OpenBSDHardware(bool_1)
    var_1 = open_b_s_d_hardware_1.get_processor_facts()


# Generated at 2022-06-24 22:27:59.899465
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bool_0 = True
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:28:03.880567
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 22:28:11.992846
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    #
    # Define a set of parameters which are required by the object constructor
    #
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.sysctl = {
        'hw.ncpuonline': '4',
        'hw.model': 'Intel(R) Core(TM) i7-7700HQ CPU @ 2.80GHz',
    }

# Generated at 2022-06-24 22:28:21.512873
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = open_file_0
    open_b_s_d_hardware_0 = OpenBSDHardware(module)
    open_b_s_d_hardware_0.sysctl = ['hw.product', 'hw.version', 'hw.uuid', 'hw.serialno', 'hw.vendor', 'hw.usermem', 'hw.model', 'hw.ncpuonline', 'hw.disknames']
    open_b_s_d_hardware_0.populate()


# Auxiliary dictionary for test_case_1
dict_0 = {'product_serial': '', 'system_vendor': '', 'product_name': '', 'product_uuid': '', 'product_version': ''}

# Auxiliary dictionary for test_case_1

# Generated at 2022-06-24 22:28:26.676525
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
  bool_var = False
  open_b_s_d_hardware_var = OpenBSDHardware(bool_var)
  sysctl_var = {'hw.usermem': '10', 'hw.ncpuonline': '2'}
  open_b_s_d_hardware_var.get_memory_facts()


# Generated at 2022-06-24 22:28:29.611892
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bool_0 = True
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert len(var_0) == 4


# Generated at 2022-06-24 22:28:31.197006
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    bool_0 = False
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(bool_0)

# Generated at 2022-06-24 22:28:35.701887
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bool_0 = True
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.populate()
    open_b_s_d_hardware_1 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_1.populate()
    open_b_s_d_hardware_2 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_2.populate()


# Generated at 2022-06-24 22:28:39.213942
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    print(var_0)
    assert var_0 == {}

# Generated at 2022-06-24 22:28:49.156225
# Unit test for method populate of class OpenBSDHardware