

# Generated at 2022-06-24 22:19:27.053258
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    hard = OpenBSDHardware(set())
    hard.module = AnsibleModule(argument_spec={})
    hard.module.run_command = Mock(return_value=(0, '', ''))
    hard.get_uptime_facts()

# Generated at 2022-06-24 22:19:32.185993
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module = MagicMock()
    open_b_s_d_hardware_0.sysctl = [MagicMock()]
    open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:19:35.055559
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:19:40.167744
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    print("Testing method get_device_facts of class OpenBSDHardware")
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {'hw.disknames': 'wd0,cd0'}
    result = open_b_s_d_hardware_0.get_device_facts()
    expected = {'devices': ['wd0', 'cd0']}
    assert result == expected


# Generated at 2022-06-24 22:19:42.216925
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    _open_b_s_d_hardware = OpenBSDHardware()
    _open_b_s_d_hardware.populate(collected_facts={})


# Generated at 2022-06-24 22:19:53.924762
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    """
    Test method get_uptime_facts of the OpenBSDHardware class
    """
    open_b_s_d_hardware_0 = OpenBSDHardware()

    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '1234', ''))
    open_b_s_d_hardware_0.module.get_bin_path = MagicMock(return_value='/usr/bin/sysctl')

    open_b_s_d_hardware_0.get_uptime_facts()

    assert open_b_s_d_hardware_0.module.run_command.call_count == 1
    assert open_b_s_d_hardware_0.module.get_bin_path.call_count == 1
    assert open_

# Generated at 2022-06-24 22:19:56.887743
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    openbsd_hardware_obj = OpenBSDHardware()
    # Populate the facts by calling the get_memory_facts method.
    openbsd_hardware_obj.get_memory_facts()


# Generated at 2022-06-24 22:20:06.616454
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    test_get_dmi_facts_0 = OpenBSDHardwareCollector()
    test_get_dmi_facts_1 = test_get_dmi_facts_0._fact_class()
    rc, out, err = test_get_dmi_facts_1.module.run_command('/sbin/sysctl -a')
    test_get_dmi_facts_1.sysctl = { line.split('=', 1)[0].strip(): line.split('=', 1)[1].strip() for line in out.splitlines() }
    test_get_dmi_facts_2 = test_get_dmi_facts_1.get_dmi_facts()
    test_get_dmi_facts_3 = test_get_dmi_facts_0._fact_class()
    rc, out, err = test_

# Generated at 2022-06-24 22:20:07.919718
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    test_case_0()



# Generated at 2022-06-24 22:20:12.849894
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(module=None)
    expected_processor_facts = {'processor': [], 'processor_cores': 0, 'processor_count': 0}
    assert open_b_s_d_hardware_0.get_processor_facts() == expected_processor_facts


# Generated at 2022-06-24 22:20:21.977338
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    result = open_b_s_d_hardware_0.get_processor_facts()
    print(result)


# Generated at 2022-06-24 22:20:25.667518
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware = OpenBSDHardware()

    # Testing if the populate method returns a non-empty dictionary
    populate_result = open_b_s_d_hardware.populate()
    assert(populate_result != {})


# Generated at 2022-06-24 22:20:36.431738
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():

    open_b_s_d_hardware_0 = OpenBSDHardware(module='paramiko')

    # Test with a mock of "hw.ncpuonline"
    open_b_s_d_hardware_0.sysctl = {'hw.ncpuonline': '1'}

    # Test with an empty value
    open_b_s_d_hardware_0.sysctl[u'hw.model'] = ''
    # Test with an int value
    open_b_s_d_hardware_0.sysctl[u'hw.model'] = 123
    # Test with a float value
    open_b_s_d_hardware_0.sysctl[u'hw.model'] = 123.0
    # Test with unicode

# Generated at 2022-06-24 22:20:38.939572
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector = OpenBSDHardwareCollector()
    assert(open_b_s_d_hardware_collector)


# Generated at 2022-06-24 22:20:45.347023
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()

    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.get_system_vendor_id()

# Generated at 2022-06-24 22:20:47.168334
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:20:56.299325
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module.run_command = lambda cmd, **args: (0, 'hw.disknames="wd0,wd1"', '')
    open_b_s_d_hardware_0.sysctl = {'hw.disknames': 'wd0,wd1'}
    expected = {'devices': ['wd0', 'wd1']}
    result = open_b_s_d_hardware_0.get_device_facts()
    assert result == expected


# Generated at 2022-06-24 22:20:59.452536
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    processor_facts_0 = open_b_s_d_hardware_0.get_processor_facts()
    return processor_facts_0


# Generated at 2022-06-24 22:21:03.805373
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():

    module = MockModule()

    # Mock class method
    module.run_command = Mock(side_effect=[(0, '1517085906', ''), (0, '', '')])

    mo = OpenBSDHardwareCollector.get_uptime_facts(module)

    assert mo == {'uptime_seconds': 1517085906}, 'wrong value'


# Generated at 2022-06-24 22:21:12.227354
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()

    # Output of 'vmstat'
    vmstat_out = 'procs memory page disks traps cpu r b w avm fre flt re pi po fr sr wd0 fd0 int sys cs us sy id 0 0 0 47512 28160 51 0 0 0 0 0 1 0 116 89 17  0  1 99'
    open_b_s_d_hardware_0.module.run_command = lambda x, *_, **__: (0, vmstat_out, '')

    # Output of 'sysctl'
    sysctl_out = {
        'hw.usermem': '548395008'
    }
    open_b_s_d_hardware_0.sysctl = sysctl_out

    # Output of 'swapctl'
   

# Generated at 2022-06-24 22:21:29.001977
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():

    o_b_s_d_hardware = OpenBSDHardware()
    o_b_s_d_hardware.sysctl = {
        'hw.ncpuonline': '4',
        'hw.model': 'Intel(R) Core(TM) i3-3225 CPU @ 3.30GHz'
    }
    cpu_facts = o_b_s_d_hardware.get_processor_facts()

# Generated at 2022-06-24 22:21:34.757961
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(
        dict(
            ansible_module=dict(
                run_command=dict(
                    side_effect=run_command_mock,
                ),
            ),
        )
    )
    assert open_b_s_d_hardware_0.get_device_facts() == dict(
        devices=list_0_0,
    )


# Generated at 2022-06-24 22:21:38.448303
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    print("Constructor test for OpenBSDHardwareCollector class")
    openbsd_hardware_collector_obj = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector_obj._fact_class == OpenBSDHardware


# Generated at 2022-06-24 22:21:40.078682
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:21:43.053444
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    test_case_0()


# Generated at 2022-06-24 22:21:46.706334
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():

    open_b_s_d_hardware_0 = OpenBSDHardware()

    open_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:21:50.161008
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:21:55.288756
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    assert open_b_s_d_hardware_0.populate() == None

# Generated at 2022-06-24 22:21:57.415893
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    test_case_0()


# Generated at 2022-06-24 22:21:59.679865
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:22:09.847053
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware = OpenBSDHardware()

    print (open_b_s_d_hardware.get_device_facts())


# Generated at 2022-06-24 22:22:17.741097
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module = Mock(run_command=Mock(return_value=(0, '', '')))
    open_b_s_d_hardware_0._module.run_command.return_value = (0, '', '')
    open_b_s_d_hardware_0._module.get_bin_path.return_value = '/usr/bin/sysctl'
    open_b_s_d_hardware_0.sysctl = {'kern.boottime': '-1'}
    result = open_b_s_d_hardware_0.get_uptime_facts()
    assert 'uptime_seconds' in result
    result = open_b_s_d_

# Generated at 2022-06-24 22:22:22.767456
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(None)
    return_value_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert return_value_0 == {'memfree_mb': 26124, 'swapfree_mb': 32, 'memtotal_mb': 7955, 'swaptotal_mb': 32}


# Generated at 2022-06-24 22:22:32.983233
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()


# Generated at 2022-06-24 22:22:36.484370
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0


# Generated at 2022-06-24 22:22:40.931874
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = MagicMock(return_value=(0, '  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))
    open_b_s_d_hardware_0.module = test_module
    open_b_s_d_hardware_0.sysctl = {'hw.usermem': '1048576', 'hw.ncpuonline': '4'}
    memory_facts = open_b_s_d_hardware_0.get_memory_facts()
    assert(memory_facts['memfree_mb'] == 28)
   

# Generated at 2022-06-24 22:22:42.983824
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    assert open_b_s_d_hardware_0.get_device_facts() == {'devices': ['sd0', 'sd1', 'sd2']}


# Generated at 2022-06-24 22:22:45.395693
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware = OpenBSDHardware()
    print(open_b_s_d_hardware.get_uptime_facts())


# Generated at 2022-06-24 22:22:49.766781
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware = OpenBSDHardware()
    result = open_b_s_d_hardware.get_processor_facts()
    assert result == {'processor': ['Intel(R) Xeon(R) CPU E5630  @ 2.53GHz'], 'processor_count': '2', 'processor_cores': '2'}


# Generated at 2022-06-24 22:22:52.077051
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()


# Generated at 2022-06-24 22:23:04.192331
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    assert open_b_s_d_hardware_0.get_uptime_facts() == {'uptime_seconds': 123}


# Generated at 2022-06-24 22:23:11.533487
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(module_spec='{"module_name": "ansible.module_utils.facts.hardware.openbsd", "module_args": {"fail_on_timeout": true}}')
    open_b_s_d_hardware_0.module = ModuleStub()
    open_b_s_d_hardware_0.module._ansible_version = 2.2
    open_b_s_d_hardware_0.sysctl = {'hw.ncpuonline': '1', 'hw.model': 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz'}

# Generated at 2022-06-24 22:23:21.919065
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    openbsd_hardware = OpenBSDHardware()

    openbsd_hardware.sysctl['hw.product'] = 'HPDesktopBoard'
    openbsd_hardware.sysctl['hw.version'] = 'v1.0'
    openbsd_hardware.sysctl['hw.uuid'] = '1e79e7f9-9c8d-11e6-97f6-0242ac110002'
    openbsd_hardware.sysctl['hw.serialno'] = '123451234512345'
    openbsd_hardware.sysctl['hw.vendor'] = 'HP'


# Generated at 2022-06-24 22:23:26.657793
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # Create an instance of class OpenBSDHardware
    open_b_s_d_hardware_0 = OpenBSDHardware()

    # Call method get_uptime_facts of class OpenBSDHardware
    result = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:32.570113
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardwareCollector().collect()

# Generated at 2022-06-24 22:23:37.187151
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0._fact_class == OpenBSDHardware
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'
    assert open_b_s_d_hardware_collector_0._priority == 30

# Generated at 2022-06-24 22:23:43.522779
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(mock_ansible_module) # module_utils.facts.hardware.openbsd.OpenBSDHardware object
    result = open_b_s_d_hardware_0.get_device_facts()
    assert result["devices"] == ['wd0', 'wd1']


# Generated at 2022-06-24 22:23:54.926941
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    # Test with no arguments.

# Generated at 2022-06-24 22:24:00.401858
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0._fact_class == open_b_s_d_hardware_collector_1._fact_class
    assert open_b_s_d_hardware_collector_0._platform == open_b_s_d_hardware_collector_1._platform

# Generated at 2022-06-24 22:24:05.936580
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    hardware = OpenBSDHardware()
    hardware.sysctl = {
        'hw.product': 'FreeBSD',
        'hw.version': '11.0-STABLE',
        'hw.uuid': '16fc10c0-4a4a-3b4c-b2d7-eacb0f8b1a26',
        'hw.serialno': '871f3c9b-2a30-0c0b-8e40-a0f5e5d5c5b5',
        'hw.vendor': 'The FreeBSD Project'
    }
    dmi_facts = hardware.get_dmi_facts()

# Generated at 2022-06-24 22:24:28.544477
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {'hw.product': 'SMC1690W', 'hw.version': '1.00', 'hw.uuid': '01234567-abcd-0123-abcd-0123456789ab', 'hw.serialno': '012345', 'hw.vendor': 'ASUSTeK Computer Inc.'}
    dmi_facts_0 = open_b_s_d_hardware_0.get_dmi_facts()
    assert dmi_facts_0['product_name'] == 'SMC1690W'
    assert dmi_facts_0['product_version'] == '1.00'
    assert dmi_facts_0['product_uuid']

# Generated at 2022-06-24 22:24:33.360763
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_get_device_facts_0 = OpenBSDHardware()
    open_b_s_d_hardware_get_device_facts_0.sysctl = {'hw.disknames': 'sd0'}
    open_b_s_d_hardware_get_device_facts_0.get_device_facts()


# Generated at 2022-06-24 22:24:40.450888
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0._module = FakeAnsibleModule()
    open_b_s_d_hardware_0._module.sysctl = {'hw.product': 'OpenBSD.amd64',
                                            'hw.version': 'RELEASE',
                                            'hw.uuid': 'xyz123',
                                            'hw.serialno': 'ABCD1234',
                                            'hw.vendor': 'OpenBSD'}
    open_b_s_d_hardware_0.sysctl = open_b_s_d_hardware_0._module.sysctl
    open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:24:49.608848
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
  openbsd_hardware_object = OpenBSDHardware()
  openbsd_hardware_object.module = MockModule()
  openbsd_hardware_object.module.run_command = my_run_command_function 
  openbsd_hardware_object.sysctl = get_sysctl_mock_object()
  cpu_facts = openbsd_hardware_object.get_processor_facts()
  assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4960HQ CPU @ 2.60GHz']
  assert cpu_facts['processor_count'] == '1'
  assert cpu_facts['processor_cores'] == '1'


# Generated at 2022-06-24 22:24:51.368010
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    hardware_facts_class_0 = OpenBSDHardware()
    hardware_facts_class_0.populate(None)

# Generated at 2022-06-24 22:24:57.134698
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    openBSDHW = OpenBSDHardware()
    openBSDHW.module.run_command = MagicMock(return_value=(0, 'hw.disknames: wd0,cd0,cd1', ''))
    openBSDHW.module._separator = MagicMock(return_value=',')
    openBSDHW.module.get_bin_path = MagicMock(return_value='/usr/bin/sysctl')

    assert openBSDHW.get_device_facts() == {'devices': ['wd0', 'cd0', 'cd1']}


# Generated at 2022-06-24 22:24:58.574631
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:25:01.446340
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(module=None)
    memory_facts = open_b_s_d_hardware_0.get_memory_facts()
    assert memory_facts['memfree_mb'] == 0
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0


# Generated at 2022-06-24 22:25:06.003488
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    print("Starting test_OpenBSDHardwareCollector")
    try:
        test_case_0()
        print("test_OpenBSDHardwareCollector: PASS")
    except:
        print("test_OpenBSDHardwareCollector: FAIL")


# Generated at 2022-06-24 22:25:14.725673
# Unit test for method get_dmi_facts of class OpenBSDHardware

# Generated at 2022-06-24 22:25:48.481110
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    openbsd_hardware_0 = OpenBSDHardware()
    openbsd_hardware_0.module = Mock_module
    openbsd_hardware_0.sysctl = {'kern.boottime': '1527172948'}
    assert openbsd_hardware_0.get_uptime_facts() == {'uptime_seconds': 1527178066}


# Generated at 2022-06-24 22:25:55.093583
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    test_case_0()
    open_b_s_d_hardware_0 = OpenBSDHardware({})
    open_b_s_d_hardware_0.populate()
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:25:57.588925
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()

    ##
    ## test get_mount_facts
    ##
    open_b_s_d_hardware_0.get_mount_facts()


# Generated at 2022-06-24 22:26:04.652207
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_bsd_hardware = OpenBSDHardware()
    open_bsd_hardware.sysctl = dict(
        [('hw.usermem', '5201993728'),
         ('hw.ncpuonline', '4')])
    open_bsd_hardware_dict = open_bsd_hardware.get_memory_facts()
    assert open_bsd_hardware_dict['memtotal_mb'] == 5017
    assert open_bsd_hardware_dict['memfree_mb'] == 2743
    assert open_bsd_hardware_dict['swaptotal_mb'] == 67
    assert open_bsd_hardware_dict['swapfree_mb'] == 67


# Generated at 2022-06-24 22:26:06.650945
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    hardware_0 = OpenBSDHardware()
    uptime_facts = hardware_0.get_uptime_facts()
    if not uptime_facts:
        raise AssertionError()


# Generated at 2022-06-24 22:26:11.231398
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector._fact_class == OpenBSDHardware
    assert open_b_s_d_hardware_collector._platform == 'OpenBSD'


# Generated at 2022-06-24 22:26:14.723349
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    test_OpenBSDHardware_populate_0 = OpenBSDHardware()
    test_OpenBSDHardware_populate_0.populate()


# Generated at 2022-06-24 22:26:21.418191
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    hard_facts = OpenBSDHardware(None)
    hard_facts.sysctl = {
        "hw.ncpuonline": "2",
        "hw.usermem": "1000",
        "hw.ncpu": "2",
        "hw.physmem": "940",
        "hw.model": "OpenBSD 6.3 amd64",
        "hw.ncpufound": "2",
        "hw.ncpus": "2",
        "hw.machine": "amd64",
        "hw.disknames": "wd0a,cd0"
    }

    hard_facts.module = FakeModule()
    hard_facts.module.run_command = FakeRunCommand({"kern.boottime": str(int(time.time() - 10))})
    out = hard_facts.get_uptime_facts()


# Generated at 2022-06-24 22:26:23.246080
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    return_value = open_b_s_d_hardware_0.get_memory_facts()
    assert type(return_value) == dict


# Generated at 2022-06-24 22:26:24.282483
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:27:39.059464
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module.run_command=MagicMock(return_value=(
         0, '  procs    memory       page                    disks    traps          cpu\n       r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n       0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n', ''))
    open_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:27:44.609367
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware = OpenBSDHardware()
    open_b_s_d_hardware.sysctl = {
        'hw.product': 'Foo',
        'hw.serialno': 'Bar',
        'hw.version': 'Baz',
        'hw.uuid': '',
        'hw.vendor': '',
    }
    dmi_facts = open_b_s_d_hardware.get_dmi_facts()
    assert dmi_facts == {
        'product_name': 'Foo',
        'product_serial': 'Bar',
        'product_version': 'Baz',
        'product_uuid': '',
        'system_vendor': '',
    }


# Generated at 2022-06-24 22:27:47.306650
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector = OpenBSDHardwareCollector()
    assert isinstance(open_b_s_d_hardware_collector, OpenBSDHardwareCollector)
    assert isinstance(open_b_s_d_hardware_collector, HardwareCollector)


# Generated at 2022-06-24 22:27:51.364680
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()

    result = open_b_s_d_hardware_0.get_processor_facts()
    assert result == {u'processor': [], u'processor_cores': None, u'processor_count': None}


# Generated at 2022-06-24 22:27:54.412213
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    print("Testing get_device_facts")
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()
    open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:27:57.525369
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
  open_b_s_d_hardware_collector = OpenBSDHardwareCollector()
  assert open_b_s_d_hardware_collector.platform == 'OpenBSD'


# Generated at 2022-06-24 22:28:06.454437
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware = OpenBSDHardware()
    #
    # Fact gathering module
    #
    module = AnsibleModule(
        argument_spec = dict()
    )

    #
    # Mocking sysctl module
    #
    hw = {
        'hw.ncpuonline': '1',
        'hw.model': 'GenuineIntel'
    }
    get_sysctl_mock = MagicMock(return_value=hw)
    with patch.dict(sysctl.__dict__, {'get_sysctl': get_sysctl_mock}):
        actual = open_b_s_d_hardware.get_processor_facts()

# Generated at 2022-06-24 22:28:08.800705
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()
    assert open_b_s_d_hardware_0.hw


# Generated at 2022-06-24 22:28:16.200848
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    obj = OpenBSDHardware()
    obj.sysctl = {'hw.product': 'TestProduct',
                  'hw.version': 'TestVersion',
                  'hw.uuid': 'TestUUID',
                  'hw.serialno': 'TestSerial',
                  'hw.vendor': 'TestVendor',
                  'hw.ncpuonline': '8',
                  'hw.usermem': '91273216',
                  'hw.disknames': 'wd0'}
    res = obj.get_dmi_facts()
    assert res['system_vendor'] == 'TestVendor'



# Generated at 2022-06-24 22:28:20.867582
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_collector_2 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_1._fact_class is OpenBSDHardware
