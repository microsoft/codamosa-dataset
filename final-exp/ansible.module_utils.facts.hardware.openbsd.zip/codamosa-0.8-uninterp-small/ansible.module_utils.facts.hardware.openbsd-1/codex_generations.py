

# Generated at 2022-06-24 22:19:29.206786
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0 != open_b_s_d_hardware_collector_1


# Generated at 2022-06-24 22:19:36.773896
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    '''
    Test get_dmi_facts method of OpenBSDHardware class
    '''
    open_b_s_d_hardware_0 = OpenBSDHardware({}, {})

# Generated at 2022-06-24 22:19:40.763714
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()

# Unit tests for class OpenBSDHardwareCollector

# Generated at 2022-06-24 22:19:45.286714
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    if not isinstance(open_b_s_d_hardware_collector_0, OpenBSDHardwareCollector):
        sys.exit(1)


# Generated at 2022-06-24 22:19:47.581119
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert not OpenBSDHardwareCollector()._fact_class
    assert not OpenBSDHardwareCollector()._platform


# Generated at 2022-06-24 22:19:52.745467
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {'hw.model': 'RP9,9100C@1.10GHz', 'hw.ncpu': '1', 'hw.ncpuonline': '1'}
    str_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:19:54.790529
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:19:58.426013
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Not really a test, but a way to see if the platform facts get populated properly.
    open_b_s_d_hardware = OpenBSDHardware()
    print(open_b_s_d_hardware.populate())

# Generated at 2022-06-24 22:20:07.436659
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    '''
    Test to get processor facts
    '''
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {}
    open_b_s_d_hardware_0.sysctl['hw.model'] = 'Intel(R) Core(TM) i7-4300U CPU @ 1.90GHz'
    open_b_s_d_hardware_0.sysctl['hw.ncpuonline'] = 1
    assert open_b_s_d_hardware_0.get_processor_facts() == {'processor': ['Intel(R) Core(TM) i7-4300U CPU @ 1.90GHz'], 'processor_count': '1', 'processor_cores': '1'}


# Generated at 2022-06-24 22:20:17.536958
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module.run_command = lambda *_, **__: (0, b'\x00\x00\x00\x00\x00\x00\x00\x00', b'')
    test_result = open_b_s_d_hardware_0.get_uptime_facts()
    test_result.pop('uptime_days')
    assert test_result == {'uptime_seconds': 0}


if __name__ == '__main__':
    test_case_0()
    test_OpenBSDHardware_get_uptime_facts()

# Generated at 2022-06-24 22:20:25.666806
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:20:36.537298
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware_0 = OpenBSDHardwareCollector._fact_class(dict(), timeout=5)
    open_b_s_d_hardware_0._module = open_b_s_d_hardware_0.module

# Generated at 2022-06-24 22:20:40.733396
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = open_b_s_d_hardware_collector_0.collect()
    return open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:20:43.192309
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    assert OpenBSDHardware.get_uptime_facts.__doc__ is not None


# Generated at 2022-06-24 22:20:52.721246
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    """
    Called when unit tests are run, get_uptime_facts function of OpenBSDHardware class has two different outputs.
    This function is needed to test the get_uptime_facts function of OpenBSDHardware class.
    """
    open_b_s_d_hardware_get_uptime_facts_hardware_obj = OpenBSDHardware()
    open_b_s_d_hardware_get_uptime_facts_uptime_facts_dict = {}
    open_b_s_d_hardware_get_uptime_facts_uptime_facts_dict['uptime_seconds'] = 1601
    open_b_s_d_hardware_get_uptime_facts_uptime_facts_dict_expected = {}
    open_b_s_d_hardware_get_uptime_facts_uptime_facts

# Generated at 2022-06-24 22:20:56.208107
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = 'nss_ldap: files dns'
    assert open_b_s_d_hardware_0.get_device_facts() == {'devices': ['nss_ldap', 'files', 'dns']}


# Generated at 2022-06-24 22:20:58.961926
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'



# Generated at 2022-06-24 22:21:01.735054
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(file_module, facts)

    open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:21:04.351485
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_bsd_hardware_0 = OpenBSDHardware()
    collected_facts_0 = {}
    open_bsd_hardware_0.populate(collected_facts_0)


# Generated at 2022-06-24 22:21:05.976975
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:21:15.359407
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:21:18.830121
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert type(var_0) is dict


# Generated at 2022-06-24 22:21:21.485706
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    collector = OpenBSDHardwareCollector("Linux")
    assert collector.platform == "Linux"


# Generated at 2022-06-24 22:21:23.035638
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert isinstance(OpenBSDHardwareCollector(), OpenBSDHardwareCollector)


# Generated at 2022-06-24 22:21:24.723693
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # TODO: Add your code here
    assert True, "No test was defined"


# Generated at 2022-06-24 22:21:25.858421
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    pass


# Generated at 2022-06-24 22:21:31.053693
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_1 = 711.134831
    open_b_s_d_hardware_1 = OpenBSDHardware(float_1)
    int_0 = open_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:21:33.987823
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    return open_b_s_d_hardware_collector_0

# Generated at 2022-06-24 22:21:40.873931
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    _module = mock.MagicMock()
    _module.run_command.return_value = [0, '1578620873', '']

    float_1 = 711.134831
    open_b_s_d_hardware_1 = OpenBSDHardware(float_1)

    open_b_s_d_hardware_1.module = _module
    assert open_b_s_d_hardware_1.get_uptime_facts() == {'uptime_seconds': int(time.time() - 1578620873)}

# Generated at 2022-06-24 22:21:51.150201
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    # Create a mock instance of the module with
    # methods we need for this test case
    module = MockModule()
    module.run_command.return_value = (0, 'hw.disknames=wd0,wd1', '')
    open_b_s_d_hardware_0 = OpenBSDHardware(module)
    open_b_s_d_hardware_0.sysctl = {'hw.disknames': 'wd0,wd1'}
    var_0 = open_b_s_d_hardware_0.get_device_facts()
    assert 'devices' in var_0
    assert len(var_0['devices']) == 2
    assert 'wd0' in var_0['devices']
    assert 'wd1' in var_0['devices']


# Generated at 2022-06-24 22:22:06.927388
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = 0.9604937
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:10.470819
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:22:13.583802
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware(1159.75)
    open_b_s_d_hardware_0.populate()

test_OpenBSDHardware_populate()

# Generated at 2022-06-24 22:22:15.329839
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    assert open_b_s_d_hardware_0.get_processor_facts() is None


# Generated at 2022-06-24 22:22:17.843209
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:22.267330
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0._fact_class == OpenBSDHardware
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-24 22:22:25.412771
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:22:30.834651
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    float_1 = 827.498596
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(float_1)
    open_b_s_d_hardware_collector_0.get_device_facts()
    var_0 = open_b_s_d_hardware_collector_0.platform
    open_b_s_d_hardware_collector_0.get_uptime_facts()


if __name__ == '__main__':
    test_case_0()
    test_OpenBSDHardwareCollector()

# Generated at 2022-06-24 22:22:35.009978
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = 525.653349
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    assert float_0 == float_0
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert len(var_0) == 4
    assert var_0['swapfree_mb'] == 62232
    assert var_0['swaptotal_mb'] == 62232
    assert var_0['memtotal_mb'] == 122776
    assert var_0['memfree_mb'] == 60544


# Generated at 2022-06-24 22:22:43.427304
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():

    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()
    assert var_0 == {'system_vendor': 'OpenBSD Project', 'product_name':
        'OpenBSD/amd64', 'product_version': '#4', 'product_uuid':
        '00000000-0000-0000-0000-000000000000', 'product_serial': '00000000000000'}


# Generated at 2022-06-24 22:23:22.913324
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    float_0 = 8.85715
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:23:30.186932
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_1 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.sysctl = {'hw.disknames': 'sd0,sd1'}
    open_b_s_d_hardware_1.sysctl = {'hw.disknames': 'sd0,sd1'}
    var_0 = open_b_s_d_hardware_0.get_device_facts()
    var_1 = open_b_s_d_hardware_1.get_device_facts()
    assert var_0 == var_1
    

# Generated at 2022-06-24 22:23:36.918406
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_1 = open_b_s_d_hardware_0.get_dmi_facts()
    assert var_1 == None


# Generated at 2022-06-24 22:23:46.385408
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    float_0 = 711.834015
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.module = MockModule()
    open_b_s_d_hardware_0.module.run_command.return_value = (
        0,
        "34",
        ""
        )

    open_b_s_d_hardware_0.module.time.return_value = 1000
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert var_0 == {
        'uptime_seconds': 966,
    }

    open_b_s_d_hardware_0.module.time.return_value = 1010
    var_0 = open

# Generated at 2022-06-24 22:23:49.684627
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    var_0 = open_b_s_d_hardware_collector_0.collect()


# Generated at 2022-06-24 22:23:54.553050
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:58.314781
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert var_0["uptime_seconds"] != None


# Generated at 2022-06-24 22:24:01.065110
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    float_1 = 711.134831
    open_b_s_d_hardware_1 = OpenBSDHardware(float_1)
    var_1 = open_b_s_d_hardware_1.get_uptime_facts()



# Generated at 2022-06-24 22:24:05.209200
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    float_0 = 828.052934
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.get_mount_facts()
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:24:10.601366
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:26:12.877968
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    float_0 = 739.3057515
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:26:16.992485
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_1 = open_b_s_d_hardware_0.get_device_facts()
    assert var_1 == None, 'Wrong value returned by get_device_facts of OpenBSDHardware'


# Generated at 2022-06-24 22:26:20.007915
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # OpenBSDHardware unit test case
    float_0 = 579.905746
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 22:26:22.122062
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_collector_0.get_cpu_facts('')


# Generated at 2022-06-24 22:26:24.493309
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:26:26.561037
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:26:28.397748
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:26:32.781573
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    float_0 = 711.134831
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    # Call populate(exception=False)
    var_0 = open_b_s_d_hardware_0.populate(False)
    # AssertionError: var_0 != None


# Generated at 2022-06-24 22:26:37.792682
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    float_0 = 526.09738
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    open_b_s_d_hardware_0.sysctl = {}
    open_b_s_d_hardware_0.sysctl['hw.usermem'] = 52428800
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:26:40.892254
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    float_0 = 573.177071
    open_b_s_d_hardware_0 = OpenBSDHardware(float_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()

