

# Generated at 2022-06-24 22:19:34.219956
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(None)
    open_b_s_d_hardware_0.module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    open_b_s_d_hardware_0.sysctl = {
        'hw.usermem': '134217728',
        'hw.physmem': '1281170432',
    }
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-24 22:19:43.665519
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    bytes_0 = None
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    get_mount_facts_0 = None
    get_uptime_facts_0 = None
    get_dmi_facts_0 = None
    get_memory_facts_0 = None
    get_processor_facts_0 = None
    open_b_s_d_hardware_0.populate(get_mount_facts_0)
    get_device_facts_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:19:48.672563
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(None)
    open_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:19:57.655444
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware = OpenBSDHardware(None)
    open_b_s_d_hardware._collect_platform_facts = lambda: {'hw': {'product': 'Test', 'version': 'Test', 'uuid': 'Test', 'serialno': 'Test', 'vendor': 'Test'}}
    dmi_facts = open_b_s_d_hardware.get_dmi_facts()
    assert sorted(dmi_facts.keys()) == [u'product_name', u'product_serial', u'product_uuid', u'product_version', u'system_vendor']


# Generated at 2022-06-24 22:20:05.409205
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    Hardware.run_command = MagicMock(side_effect=[[0, "0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n", ""]])
    OpenBSDHardware.sysctl = {"hw.usermem": 128, "hw.ncpuonline": 1}
    hardware_0 = OpenBSDHardware('module_name')
    assert hardware_0.get_memory_facts()['memfree_mb'] == 28
    assert hardware_0.get_memory_facts()['memtotal_mb'] == 123

# Generated at 2022-06-24 22:20:17.296627
# Unit test for method populate of class OpenBSDHardware

# Generated at 2022-06-24 22:20:26.209571
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_get_processor_facts_0 = OpenBSDHardware(None)
    open_b_s_d_hardware_get_processor_facts_0.sysctl = {'hw.model': 'foo', 'hw.ncpuonline': '1'}
    open_b_s_d_hardware_get_processor_facts_0.get_processor_facts()
    open_b_s_d_hardware_get_processor_facts_0.sysctl = {'hw.model': 'foo', 'hw.ncpuonline': '0'}
    open_b_s_d_hardware_get_processor_facts_0.get_processor_facts()


# Generated at 2022-06-24 22:20:28.693679
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    bytes_0 = None
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(bytes_0)
# Testing if exceptions are thrown

# Generated at 2022-06-24 22:20:39.559297
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bytes_0 = None
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    with mock.patch('ansible_collections.ansible.community.tests.unit.modules.system.openbsd.OpenBSDHardware.get_sysctl', new_callable=mock.PropertyMock) as mock_get_sysctl:
        mock_get_sysctl.return_value = {u'hw.ncpuonline': u'1', u'hw.model': u'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz'}
        num_0 = open_b_s_d_hardware_0.get_processor_facts()
        assert type(num_0) is dict
        assert type(num_0['processor']) is list
        assert num_

# Generated at 2022-06-24 22:20:42.109822
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert open_b_s_d_hardware_collector_0.module.params == None
    assert open_b_s_d_hardware_collector_0.module.params['timeout'] == 300


# Generated at 2022-06-24 22:20:58.686774
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)

    open_b_s_d_hardware_0.module.run_command.side_effect = [(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n', ''), (0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available\n', '')]
    var_0 = open_b_s_d_hardware_0.get_memory_facts()

    expected_0 = {'memfree_mb': 28, 'memtotal_mb': 47512, 'swapfree_mb': 69268, 'swaptotal_mb': 69268}


# Generated at 2022-06-24 22:21:01.816429
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:21:06.189677
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    # Test arguments and expected return values
    str_1 = '%s='
    open_b_s_d_hardware_1 = OpenBSDHardware(str_1)

    # Perform the test
    var_1 = open_b_s_d_hardware_1.get_processor_facts()

    # Return the results
    return var_1


# Generated at 2022-06-24 22:21:08.538420
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    assert True == open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:21:11.533374
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:21:13.999543
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:21:18.830521
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = 'OpenBSDHardwareCollector'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    assert open_b_s_d_hardware_collector_0._fact_class == OpenBSDHardware, 'expected a different fact class'
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD', 'expected a different platform'



# Generated at 2022-06-24 22:21:22.415524
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:21:26.159023
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:21:32.910150
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert var_0 == {}


# Generated at 2022-06-24 22:21:55.161467
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    assert len(open_b_s_d_hardware_0.populate()) == 14


# Generated at 2022-06-24 22:21:59.236818
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector('')
    assert open_b_s_d_hardware_collector_0._fact_class == 'OpenBSD'
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-24 22:22:04.961079
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0.platform == 'OpenBSD'
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-24 22:22:08.782767
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:22:13.270693
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    # The following test would fail because
    # OpenBSDHardware._processor_logical_cores is not initialized
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:22:16.810449
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.sysctl = dict
    open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:21.878190
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # Constructor test case
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0._fact_class == OpenBSDHardware
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-24 22:22:24.961819
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:22:28.040643
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:22:32.250324
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()
    assert var_0 == None


# Generated at 2022-06-24 22:23:21.869493
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:23:25.582269
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    int_0 = open_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:23:27.586258
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:31.756646
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:23:34.889738
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # Unit test for method get_uptime_facts of class OpenBSDHardware
    open_b_s_d_hardware_0 = OpenBSDHardware('__')
    open_b_s_d_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 22:23:38.155359
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:23:42.376365
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'BCBC1246'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    str_1 = 'KGWXD9'
    open_b_s_d_hardware_0.sysctl = {str_1: '6'}
    var_0 = open_b_s_d_hardware_0.get_processor_facts()
    print(var_0)


# Generated at 2022-06-24 22:23:46.404882
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = ',hardware:'
    str_1 = '_'
    str_2 = ','
    str_3 = 'ansible_facts'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert var_0 == {'uptime_seconds': 1278}, var_0


# Generated at 2022-06-24 22:23:49.317288
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    check_0 = OpenBSDHardwareCollector()
    # assert check_0._platform == 'OpenBSD'
    # assert check_0._fact_class == 'OpenBSDHardware'


# Generated at 2022-06-24 22:23:53.845623
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = 't'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:24:52.953610
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    populate_r_0 = OpenBSDHardware.populate('f')
    assert populate_r_0 == {}
    populate_r_1 = OpenBSDHardware.populate()
    assert populate_r_1 == {}


# Generated at 2022-06-24 22:24:58.630956
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:25:01.846112
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:25:08.282158
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    assert open_b_s_d_hardware_0.get_memory_facts( ) == {'memtotal_mb': 122880, 'memfree_mb': 108670, 'swaptotal_mb': 8192, 'swapfree_mb': 6053}


# Generated at 2022-06-24 22:25:15.202706
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.sysctl = dict({'hw.model': str_0, 'hw.ncpuonline': str_0, 'hw.usermem': str_0, 'hw.disknames': str_0})
    open_b_s_d_hardware_0.module = Mock()
    open_b_s_d_hardware_0.module.run_command.return_value = tuple([0, '', ''])
    str_1 = 'vmstat'
    open_b_s_d_hardware_0.run_command = Mock(return_value=tuple([0, str_0, '']))
    var_0 = open_

# Generated at 2022-06-24 22:25:19.860922
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:25:22.154992
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:25:24.328566
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


test_case_0()

# Generated at 2022-06-24 22:25:27.061344
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = '%s='
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:25:36.173285
# Unit test for method get_memory_facts of class OpenBSDHardware

# Generated at 2022-06-24 22:27:56.824779
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    # if var_0 is not None:
    #     var_0 = var_0.get('memfree_mb')
    # else:
    #     var_0 = 0
    # var_0 = var_0 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-24 22:27:59.230504
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    var_0 = OpenBSDHardwareCollector()
    assert var_0._platform == 'OpenBSD'
    assert var_0._fact_class == OpenBSDHardware


# Generated at 2022-06-24 22:28:02.261294
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:28:05.306015
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:28:14.388757
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    module_0 = AnsibleModule(
        argument_spec={},
    )
    try:
        open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(module_0)
    except:
        open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(module_0)
    var_1 = open_b_s_d_hardware_collector_0._fact_class.platform
    if var_1:
        var_2 = open_b_s_d_hardware_collector_0._platform
    else:
        var_2 = open_b_s_d_hardware_collector_0._platform

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDHardwareCollector()

# Generated at 2022-06-24 22:28:16.589758
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = 'A'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:28:18.230442
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:28:21.541167
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = '%s='
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:28:30.385600
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # Requires pytest-mock
    # https://pypi.python.org/pypi/pytest-mock
    # pytest --capture=sys -s test_OpenBSDHardware.py:test_OpenBSDHardware_get_uptime_facts

    module_mock = Mock()
    module_mock.get_bin_path.return_value = 'sysctl'
    module_mock.run_command.return_value = (0, '1523622447', '')
    openbsd = OpenBSDHardware('%s=')
    openbsd.module = module_mock
    expected = {'uptime_seconds': 1523622447}
    assert openbsd.get_uptime_facts() == expected

# Generated at 2022-06-24 22:28:33.228397
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    with open('test/unit/output/OpenBSDHardware_get_uptime_facts_output.txt') as file:
        assert file.read() == test_OpenBSDHardware_get_uptime_facts_output()

# Unit test output for method get_uptime_facts of class OpenBSDHardware