

# Generated at 2022-06-24 22:19:34.738642
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bytes_0 = b'\x08\x8b'
    bytes_1 = b'c@\xa8\xfd\xf3\xc3\xc4'
    bytes_2 = b'\xb4\xb2\xae\x16\x84\xba\xc1\x1c\xa5\x15\x80\x9e\x89\x8c\x0f\xef\x10\x16\x00@\x98\x1a\x9d\x1b\xd2\xc2\x18\x03\x00\x00'

# Generated at 2022-06-24 22:19:42.764520
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bytes_0 = b"nhw.ncpuonline: 2\x0ahw.ncpu: 2\x0ahw.byteorder: 1234\x0ahw.cpu_mhz: 2592\x0ahw.cpuspeed: 2592\x0ahw.pagesize: 4096\x0ahw.physmem: 17825792\x0ahw.usermem: 16124416\x0ahw.model: Intel(R) Xeon(R) CPU E5-2650L v4 @ 1.70GHz\x0ahw.machine: amd64\x0ahw.ncpufound: 2\x0ahw.disknames: wd0,sd0,sd1,sd2,sd3,cd0\x0a"

# Generated at 2022-06-24 22:19:45.623806
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    pass


# Generated at 2022-06-24 22:19:56.838552
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bytes_0 = b'$\x9e\xfa'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)

    bytes_1 = b'0\xdb'
    open_b_s_d_hardware_0._module = bytes_1
    int_0 = 0

# Generated at 2022-06-24 22:20:06.585340
# Unit test for constructor of class OpenBSDHardwareCollector

# Generated at 2022-06-24 22:20:08.790161
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()

# Generated at 2022-06-24 22:20:19.924784
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    bytes_0 = b'%\xf0\xa2\x15'
    open_b_s_d_hardware_0 = OpenBSDHardware(bytes_0)
    bytes_1 = b'*\xfa\x1f\xea\x0c\x13\xf5\x8e\t\r\t\xdc\x84\x8f\xad\xcco}'
    open_b_s_d_hardware_1 = OpenBSDHardware(bytes_1)
    bytes_2 = b'G\xfd\x98\xaf\xb2\xdc\x19\x05\x8c\xa3]\xc3\x17\x9b\xca\x0b\xa3'
    open_b_s_d_hardware_2 = OpenBSDHardware

# Generated at 2022-06-24 22:20:25.415947
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware = OpenBSDHardware(None)
    open_b_s_d_hardware.module.run_command("/usr/bin/vmstat") == 0
    assert open_b_s_d_hardware.get_memory_facts() == {'memfree_mb': 28160/1024, 'memtotal_mb': (47512+28160)/1024}


# Generated at 2022-06-24 22:20:36.071665
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    open_b_s_

# Generated at 2022-06-24 22:20:39.335209
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    dict_1 = open_b_s_d_hardware_0.populate()
    assert isinstance(dict_1, dict)


# Generated at 2022-06-24 22:20:50.255096
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = 'z`*}'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:20:53.125401
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = 'OpenBSDHardwareCollector'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:20:55.114412
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = ''
    var_0 = OpenBSDHardwareCollector(str_0)
    var_1 = OpenBSDHardwareCollector.populate(var_0)

# Generated at 2022-06-24 22:20:56.434040
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():

    # Invoke method
    # assert return type/value
    pass


# Generated at 2022-06-24 22:21:05.195886
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    swaptrans = {ord(u'k'): None,
                 ord(u'm'): None,
                 ord(u'g'): None}
    my_openbsd_hardware = OpenBSDHardware('/fake/path')
    mock_run_command = lambda *args, **kwargs: (0, '69268 1K-blocks allocated, 0 used, 69268 available', '')
    my_openbsd_hardware.module.run_command = mock_run_command
    my_openbsd_hardware.sysctl = {'hw.usermem': '603979776', 'hw.ncpuonline': '1'}
    var_1 = my_openbsd_hardware.get_memory_facts()
    assert var_1['swapfree_mb'] == 68

# Generated at 2022-06-24 22:21:08.506216
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 22:21:10.329174
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector("nt", "OUr")
    assert open_b_s_d_hardware_collector_0 != None

# Generated at 2022-06-24 22:21:16.984134
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()
    assert set(var_0.keys()) == set(['mounts', 'memfree_mb', 'memtotal_mb', 'processor', 'processor_count', 'processor_cores', 'devices', 'product_name', 'product_version', 'product_uuid', 'system_vendor', 'product_serial', 'swapfree_mb', 'swaptotal_mb'])
    assert var_0['processor_cores'] == 8
    assert var_0['product_version'] is None
    assert var_0['swaptotal_mb'] == 1331

# Generated at 2022-06-24 22:21:17.692746
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:21:21.686505
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_1 = OpenBSDHardware()
    var_1 = open_b_s_d_hardware_1.get_uptime_facts()


# Generated at 2022-06-24 22:21:47.111777
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert var_0 == {}


# Generated at 2022-06-24 22:21:49.873809
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(None)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert var_0.get('uptime_seconds') == None


# Generated at 2022-06-24 22:21:56.212301
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:21:58.939577
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = 'f'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:04.416858
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:22:14.722516
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'hw.ncpuonline'
    str_1 = 'hw.usermem'
    str_2 = 'hw.disknames'
    str_3 = 'hw.product'
    str_4 = 'hw.vendor'
    str_5 = 'hw.version'
    str_6 = 'hw.uuid'
    str_7 = 'hw.serialno'
    str_8 = 'hw.model'
    bool_0 = True
    str_9 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_9)
    var_0 = open_b_s_d_hardware_0.populate()
    var_1 = var_0['memory']['swapfree_mb']

# Generated at 2022-06-24 22:22:19.755588
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = 'P/'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:22:23.383103
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()
    var_1 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:22:25.625031
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    class_0 = OpenBSDHardwareCollector()
    assert class_0.platform == 'OpenBSD'
    assert class_0._fact_class == OpenBSDHardware


# Generated at 2022-06-24 22:22:28.884268
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()
    print(var_0)


# Generated at 2022-06-24 22:22:58.752033
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(None)
    str_0 = 'sysctl'
    int_0 = 0
    str_1 = ''
    str_2 = ''
    tuple_0 = (int_0, str_1, str_2)
    with mock.patch('ansible.module_utils.facts.hardware.openbsd.OpenBSDHardware.run_command', return_value=tuple_0):
        # Asserting the call of run_command method of OpenBSDHardware class with arguments (str_0, '-n', 'kern.boottime', )
        assert mock_run_command.call_args[0] == (str_0, '-n', 'kern.boottime', )
        # Asserting the call of run_command method of OpenBSDHardware class with

# Generated at 2022-06-24 22:23:04.446433
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware(None)

    str_0 = 'q3'
    setattr(open_b_s_d_hardware_0, 'module', str_0)
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:23:07.570508
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:23:11.135233
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()
    if (var_0 is not None):
        pass
    return

# Generated at 2022-06-24 22:23:13.213639
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '&!'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:23:15.532620
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_1 = '!~p'
    open_b_s_d_hardware_1 = OpenBSDHardware(str_1)
    open_b_s_d_hardware_1.get_dmi_facts()


# Generated at 2022-06-24 22:23:20.027408
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # OpenBSDHardwareCollector specialized to collect hardware on OpenBSD
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:23:21.061450
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    var_0 = 0

# Generated at 2022-06-24 22:23:25.243089
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '<#DV7F'
    # The following call may raise an exception, which we want to test for:
    try:
         open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    except:
         pass
    # Test whether the exception was raised:
    assert True

# Generated at 2022-06-24 22:23:27.850715
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_1 = '@dx'
    open_b_s_d_hardware_1 = OpenBSDHardware(str_1)
    var_1 = open_b_s_d_hardware_1.get_processor_facts()


# Generated at 2022-06-24 22:24:16.502605
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = '^'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    assert open_b_s_d_hardware_collector_0.platform == 'OpenBSD'


# Generated at 2022-06-24 22:24:19.845160
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = 'test_value'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:24:23.855706
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = 'j#'
    module_0 = get_module(str_0)
    module_0.run_command = MagicMock(return_value=(1, 'U5', 'U5'))
    open_b_s_d_hardware_1 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_1.get_uptime_facts()
    assert var_0 == dict()


# Generated at 2022-06-24 22:24:25.940756
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    pass


# Generated at 2022-06-24 22:24:28.023847
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert isinstance(OpenBSDHardwareCollector(), HardwareCollector)


# Generated at 2022-06-24 22:24:34.547678
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware('f')
    open_b_s_d_hardware_0.sysctl = {'hw.usermem': '0', }
    open_b_s_d_hardware_0.module = mock_module
    assert open_b_s_d_hardware_0.get_memory_facts() == {'memfree_mb': 0,
 'memtotal_mb': 0,
 'swapfree_mb': 0,
 'swaptotal_mb': 0}


# Generated at 2022-06-24 22:24:38.187667
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '+b'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    # This method isn't well-tested
    # as it calls external commands which can't easily be mocked
    #assert('uptime_seconds' in open_b_s_d_hardware_0.get_uptime_facts())


# Generated at 2022-06-24 22:24:40.541998
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '-h'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert var_0.__class__.__name__ == 'dict'


# Generated at 2022-06-24 22:24:46.413892
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    print('Test case 0')
    str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    print('var_0')
    print(var_0)
    print('-------------')


# Generated at 2022-06-24 22:24:47.360014
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()

# Generated at 2022-06-24 22:27:03.288945
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()

# Generated at 2022-06-24 22:27:09.118480
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # Test case 0
    str_0 = '!~p'

    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)

    open_b_s_d_hardware_0.sysctl = {'hw.usermem': 702269, 'hw.ncpuonline': 2}

    # Setup mock: /usr/bin/vmstat
    mock_stdout = b"""\
procs     memory     page          disks    traps    cpu
  r b w  avm   fre  flt  re  pi  po  fr  sr dk0 dk1  cs us sy id
  0 1 1 28156  55887   51   0   0   0   0   0   0   0  95  0  1 99
"""

    mock_stderr = b''


# Generated at 2022-06-24 22:27:10.869414
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():

    test_case_0()

# Generated at 2022-06-24 22:27:15.745272
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:27:18.573386
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:27:29.023384
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    _str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(_str_0)

    def testcase_method():
        var_0 = open_b_s_d_hardware_0.get_dmi_facts()
        return var_0

    testcase_method.__name__ = 'testcase_method'

    # Testcase that mocks is directory
    class TestcaseMock():
        def __init__(self, testcase_method):
            self.testcase_method = testcase_method
            self.is_directory_calls = 0
            self.is_directory_returns = []
            self.rm_calls = 0
            self.rm_returns = []

        def is_directory(self, path):
            self.is_directory_

# Generated at 2022-06-24 22:27:36.550192
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # Test case data
    test_data_0 = {'kern.boottime': 1550453601}
    # Initialization
    open_b_s_d_hardware_0 = OpenBSDHardware(None)
    # Execution
    result = open_b_s_d_hardware_0.get_uptime_facts(data=test_data_0)
    # Verification
    assert result == {'uptime_seconds': 1550453601}


# Generated at 2022-06-24 22:27:41.362940
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = 'P'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert var_0 == {}

    str_1 = 'hO'
    open_b_s_d_hardware_1 = OpenBSDHardware(str_1)
    var_1 = open_b_s_d_hardware_1.get_uptime_facts()
    assert var_1 == {}


# Generated at 2022-06-24 22:27:46.425698
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '!~p'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    return_value_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert return_value_0 == {'memtotal_mb': 1204, 'swapfree_mb': 186250, 'memfree_mb': 1142, 'swaptotal_mb': 186250}
    # TODO: remove these assertions
    assert isinstance(return_value_0, dict)


# Generated at 2022-06-24 22:27:51.854793
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '#KV7'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    str_1 = 'Dt>|$'
    str_2 = 'tCU<E'
    var_0 = open_b_s_d_hardware_0.module.run_command(str_1)
    assert (var_0 == str_2)
