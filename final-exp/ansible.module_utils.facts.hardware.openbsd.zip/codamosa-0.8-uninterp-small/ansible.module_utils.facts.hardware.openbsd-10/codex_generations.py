

# Generated at 2022-06-24 22:19:32.105360
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '}-_T\\4wzXgv1=0\n'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    open_b_s_d_hardware_0 = OpenBSDHardwareCollector.fetch_all(open_b_s_d_hardware_collector_0)
    dict_0 = open_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:19:34.052911
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:19:43.917065
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware({})
    open_b_s_d_hardware_0.module = open_b_s_d_hardware_0
    open_b_s_d_hardware_0.module.run_command = lambda *_: (0, '', '')
    open_b_s_d_hardware_0.sysctl = {
        'kern.boottime': '1545328707',
    }
    assert open_b_s_d_hardware_0.get_uptime_facts() == {'uptime_seconds': '26'}

# Generated at 2022-06-24 22:19:54.440135
# Unit test for method get_uptime_facts of class OpenBSDHardware

# Generated at 2022-06-24 22:20:03.467090
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '}-_T\\4wzXgv1=0\n'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    str_0 = '9iW1\n'
    open_b_s_d_hardware_0 = open_b_s_d_hardware_collector_0.populate(str_0)
    str_0 = 'N8j6U\n'
    open_b_s_d_hardware_0 = open_b_s_d_hardware_collector_0.populate(str_0)


# Generated at 2022-06-24 22:20:06.453589
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:20:18.008267
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '}-_T\\4wzXgv1=0\n'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    memory_facts_0 = {
        'memfree_mb': 0,
        'memtotal_mb': 0,
        'swapfree_mb': 0,
        'swaptotal_mb': 0}
    processor_facts_0 = {
        'processor': '',
        'processor_cores': 0,
        'processor_count': 0,
        'processor_speed': 0}
    device_facts_0 = {'devices': ['']}

# Generated at 2022-06-24 22:20:21.592369
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = '}-_T\\4wzXgv1=0\n'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:20:29.684811
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = '</\\\\}>qm6U%@\\\n'
    module_0 = get_module_0(str_0)
    module_1 = get_module_1(module_0)
    open_b_s_d_hardware_0 = OpenBSDHardware(module_1)
    open_b_s_d_hardware_0._module = module_1
    open_b_s_d_hardware_0.sysctl = get_sysctl(module_0, ['hw'])
    dmi_facts = open_b_s_d_hardware_0.get_dmi_facts()
    assert dmi_facts['product_name'] == 'QEMU Virtual Machine'
    assert dmi_facts['product_version'] == 'pc-i440fx-2.7'


# Generated at 2022-06-24 22:20:35.641561
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    processor = []
    for i in range(int(self.sysctl['hw.ncpuonline'])):
        processor.append(self.sysctl['hw.model'])
    cpu_facts['processor'] = processor
    cpu_facts['processor_count'] = self.sysctl['hw.ncpuonline']
    cpu_facts['processor_cores'] = self.sysctl['hw.ncpuonline']


# Generated at 2022-06-24 22:20:51.459870
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = ';v|U!7s<6)DhVNW/\n'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    str_1 = '*d`0z(O%f"T}Hpe^\n'
    str_2 = '0_0(W"p%c3^q&wZg\n'
    str_3 = 'hw.usermem=11309609984\n'
    str_4 = 'hw.ncpuonline=4\n'
    str_5 = 'hw.model=Intel(R) Core(TM) i7-7700 CPU @ 3.60GHz\n'
    str_6 = 'hw.disknames=wd0,cd0\n'

# Generated at 2022-06-24 22:21:01.097655
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware({'module': OpenBSDHardwareCollector('1')})
    open_b_s_d_hardware_0._sysctl = {}
    class AnsibleModule0():
        def run_command(self, arg0, arg1=None, arg2=None):
            raise OSError()
    open_b_s_d_hardware_0._module = AnsibleModule0()
    open_b_s_d_hardware_0.get_mount_facts = OpenBSDHardware.get_mount_facts
    open_b_s_d_hardware_0.get_processor_facts = OpenBSDHardware.get_processor_facts
    open_b_s_d_hardware_0.get_device_facts = OpenBSDHardware.get_device_facts

# Generated at 2022-06-24 22:21:04.742456
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = hardware_collector_0.collect()
    uptime_facts = open_b_s_d_hardware_0.get_uptime_facts()
    # Test assertions here


# Generated at 2022-06-24 22:21:12.991435
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'VqLRK!_5\n'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    str_1 = '\x1b\x1c\x1d\x1e\x1f'
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector(str_1)
    str_2 = '\x1a\x1a\x1d\x1b\x18'
    open_b_s_d_hardware_collector_2 = OpenBSDHardwareCollector(str_2)
    str_3 = '\x1b\x1d\x1f\x1e\x1e'
    open_b_s_d_hardware_collector_

# Generated at 2022-06-24 22:21:19.116622
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # TODO: Add more tests
    str_0 = 'oKjGd=8,9f;'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    assert [{'memtotal_mb': None,
             'swapfree_mb': None,
             'memfree_mb': None,
             'swaptotal_mb': None}] == open_b_s_d_hardware_collector_0.get_memory_facts()


# Generated at 2022-06-24 22:21:23.852045
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'NX(Ip=a0\n'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:21:26.720138
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    OpenBSDHardware_0 = OpenBSDHardware()
    # Test with ``collected_facts``
    collected_facts = {}
    OpenBSDHardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:21:37.715018
# Unit test for method get_memory_facts of class OpenBSDHardware

# Generated at 2022-06-24 22:21:41.461357
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '}-_T\\4wzXgv1=0\n'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    open_b_s_d_hardware_0 = OpenBSDHardware({}, {}, {}, {}, {})
    assert open_b_s_d_hardware_0.get_memory_facts() == {'memfree_mb': 0, 'swapfree_mb': 0, 'memtotal_mb': 0, 'swaptotal_mb': 0}


# Generated at 2022-06-24 22:21:51.171658
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {}
    open_b_s_d_hardware_0.sysctl['hw.model'] = 'Intel(R) Core(TM) i7-5557U CPU @ 3.10GHz'
    open_b_s_d_hardware_0.sysctl['hw.ncpuonline'] = '2'
    ret_val_1 = open_b_s_d_hardware_0.get_processor_facts()

# Generated at 2022-06-24 22:22:02.087453
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module = "AnsibleModule"
    open_b_s_d_hardware_0.sysctl = dict(hw=dict(ncpuonline=2, model="Genuine Intel(R) CPU T2300 @ 1.66GHz"))
    assert open_b_s_d_hardware_0.get_processor_facts() == dict(processor=["Genuine Intel(R) CPU T2300 @ 1.66GHz",
                                                                          "Genuine Intel(R) CPU T2300 @ 1.66GHz"], processor_count=2, processor_cores=2)



# Generated at 2022-06-24 22:22:12.907453
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # prepare the test environment
    open_b_s_d_hardware_0 = OpenBSDHardware()

    # test the facts
    hardware_facts = open_b_s_d_hardware_0.populate()
    assert 'devices' in hardware_facts
    assert 'memfree_mb' in hardware_facts
    assert 'uptime_seconds' in hardware_facts
    assert 'swapfree_mb' in hardware_facts
    assert 'processor_speed' not in hardware_facts
    assert 'processor_cores' in hardware_facts
    assert 'swaptotal_mb' in hardware_facts
    assert 'processor_count' in hardware_facts
    assert 'system_vendor' in hardware_facts
    assert 'product_name' in hardware_facts
    assert 'memtotal_mb' in hardware_facts
    assert 'processor'

# Generated at 2022-06-24 22:22:18.010693
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    setattr(open_b_s_d_hardware_0, 'sysctl', {'hw.usermem': '0'})
    assert open_b_s_d_hardware_0.get_memory_facts() == {'swapfree_mb': 0, 'swaptotal_mb': 0, 'memfree_mb': 0, 'memtotal_mb': 0}
    return None


# Generated at 2022-06-24 22:22:21.192278
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    assert open_b_s_d_hardware_0.get_uptime_facts() == {}


# Generated at 2022-06-24 22:22:23.101230
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    OpenBSDHardware_get_uptime_facts_instance = OpenBSDHardware()
    assert OpenBSDHardware_get_uptime_facts_instance.get_uptime_facts()


# Generated at 2022-06-24 22:22:25.077648
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    get_memory_facts_0 = OpenBSDHardware()
    get_memory_facts_0.populate()


# Generated at 2022-06-24 22:22:26.587395
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:22:29.983857
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = open_b_s_d_hardware_collector_0.collect()
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:22:30.919507
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert isinstance(OpenBSDHardwareCollector(), OpenBSDHardwareCollector)


# Generated at 2022-06-24 22:22:36.837928
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    hardware_facts_ = OpenBSDHardware({})
    hardware_facts_.populate()
    assert hardware_facts_.facts['uptime_seconds'] > 0

if __name__ == '__main__':
    # Unit test for class OpenBSDHardwareCollector(HardwareCollector)
    test_case_0()
    # Unit test for method get_uptime_facts of class OpenBSDHardware
    test_OpenBSDHardware_get_uptime_facts()

# Generated at 2022-06-24 22:22:50.315253
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module.get_bin_path = Mock(return_value='/usr/bin/vmstat')
    open_b_s_d_hardware_0.sysctl = {"hw.usermem": "1234"}
    open_b_s_d_hardware_0.module.run_command = Mock(return_value=(0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', ''))

    expected = {'memfree_mb': 27, 'memtotal_mb': 1}
    returned = open_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:22:57.016453
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware({})
    open_b_s_d_hardware_0.sysctl['hw.ncpuonline'] = '2'
    open_b_s_d_hardware_0.sysctl['hw.model'] = 'OpenBSD'
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, 'success', ''))
    open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:23:07.725908
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_instance = OpenBSDHardware()
    open_b_s_d_hardware_instance.module.run_command = lambda self: (
        (0, 'hw.ncpuonline: 4\nhw.model: Intel(R) Core(TM) i5 CPU       M 430  @ 2.27GHz', ''),
        0
    )
    open_b_s_d_hardware_instance.sysctl = {
        'hw.ncpuonline': '4',
        'hw.model': 'Intel(R) Core(TM) i5 CPU       M 430  @ 2.27GHz'
    }

    actual = open_b_s_d_hardware_instance.get_processor_facts()

    assert type(actual) is dict
    assert 'processor' in actual

# Generated at 2022-06-24 22:23:10.974070
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    openbsdhardware_0 = OpenBSDHardware({}, {'hw.ncpuonline': 2, 'hw.model': 'i386'})
    d = openbsdhardware_0.get_processor_facts()
    assert d.get('processor_count') == 2 and d.get('processor_cores') == 2 and d.get('processor') == ['i386', 'i386'],\
        'OpenBSDHardware.get_processor_facts failed'


# Generated at 2022-06-24 22:23:13.431930
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    hardware_obj = OpenBSDHardware()
    processor_result = hardware_obj.get_processor_facts()
    assert isinstance(processor_result, dict)
    assert "processor_cores" in processor_result
    assert "processor_count" in processor_result


# Generated at 2022-06-24 22:23:15.709906
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    openBSD_hardware = OpenBSDHardware()
    data = openBSD_hardware.get_processor_facts()
    assert data == {'processor_cores': '2',
                    'processor': ['core2'],
                    'processor_count': '2'}

# Generated at 2022-06-24 22:23:22.014734
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    result = open_b_s_d_hardware_0.get_dmi_facts()
    assert result['system_vendor'] == 'OpenBSD', 'Test Failed'


# Generated at 2022-06-24 22:23:24.260678
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware({})
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:31.172486
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_get_device_facts_device_facts_0 = {'devices': []}
    open_b_s_d_hardware_0.sysctl = {'hw.disknames': 'sd0,sd1'}
    open_b_s_d_hardware_get_device_facts_device_facts_1 = {'devices': ['sd0', 'sd1']}

    assert open_b_s_d_hardware_0.get_device_facts() == open_b_s_d_hardware_get_device_facts_device_facts_1
    open_b_s_d_hardware_0.sysctl = {}
    assert open_b_s_d_hardware_0

# Generated at 2022-06-24 22:23:33.505694
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    pass


# Generated at 2022-06-24 22:23:44.266221
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # The following call might fail if any of the OpenBSD specific facts is
    # missing because of the missing system tools, e.g. dmidecode.
    # In this case, it is not an error.
    open_b_s_d_hardware_1 = OpenBSDHardware(True)
    open_b_s_d_hardware_1.populate()

# Generated at 2022-06-24 22:23:47.813179
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:23:57.529855
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.module = MagicMock()

    path_0 = 'fake_path'
    open_b_s_d_hardware_0.module.get_bin_path = MagicMock(return_value=path_0)

    tuple_0 = (1, 'a', 'b')
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=tuple_0)

    # Call the method
    OpenBSDHardware._get_dmi_facts(open_b_s_d_hardware_0)


# Generated at 2022-06-24 22:24:00.429179
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bool_0 = False
    open_b_s_d_hardware_1 = OpenBSDHardware(bool_0)
    dict_0 = open_b_s_d_hardware_1.get_uptime_facts()
    assert len(dict_0) == 1

# Generated at 2022-06-24 22:24:01.407327
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    # Case 0
    test_case_0()


# Generated at 2022-06-24 22:24:02.393430
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # TODO: Needs to be implemented
    pass

# Generated at 2022-06-24 22:24:06.904066
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_1 = OpenBSDHardware.get_uptime_facts(open_b_s_d_hardware_0)


# Generated at 2022-06-24 22:24:08.411419
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    test_case_0()

# Generated at 2022-06-24 22:24:11.267973
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0.platform == 'OpenBSD'



# Generated at 2022-06-24 22:24:12.519546
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    bool_0 = False
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(bool_0)


# Generated at 2022-06-24 22:24:32.617238
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bool_0 = True
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:24:38.412315
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bool_0 = True
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert var_0 == None


# Generated at 2022-06-24 22:24:39.806160
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    assert True == True

# Generated at 2022-06-24 22:24:41.654642
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bool_0 = True
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:24:45.115004
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:24:48.296285
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    dict_0 = open_b_s_d_hardware_0.populate()
    print(dict_0)


# Generated at 2022-06-24 22:24:51.365922
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Test case 0
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:24:55.043078
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:24:56.420802
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    info_0 = {}
    res = OpenBSDHardwareCollector(info_0)
    assert res is not None


# Generated at 2022-06-24 22:25:01.650248
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.sysctl = dict()
    open_b_s_d_hardware_0.sysctl['hw.usermem'] = '129'
    rc_0, out_0, err_0 = open_b_s_d_hardware_0.module.run_command('/usr/bin/vmstat')
    open_b_s_d_hardware_0.populate()
    var_0 = open_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:25:21.318449
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    # Call OpenBSDHardware.get_dmi_facts()
    test_result = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:25:29.016328
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0._platform == "OpenBSD", "Expected OpenBSD, but got " + open_b_s_d_hardware_collector_0._platform
    assert open_b_s_d_hardware_collector_0._fact_class == OpenBSDHardware, "Expected OpenBSDHardware, but got " + open_b_s_d_hardware_collector_0._fact_class



# Generated at 2022-06-24 22:25:33.803677
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    str_0 = 'uV{2O]S'
    open_b_s_d_hardware_0._module = str_0
    dict_0 = open_b_s_d_hardware_0.get_device_facts()
    print(dict_0.values())



# Generated at 2022-06-24 22:25:38.037947
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    assert open_b_s_d_hardware_0.get_memory_facts() == {
        'memfree_mb': 0,
        'memtotal_mb': 0,
        'swapfree_mb': 0,
        'swaptotal_mb': 0}


# Generated at 2022-06-24 22:25:41.117335
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:25:43.511868
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    assert open_b_s_d_hardware_0.get_memory_facts() == {}


# Generated at 2022-06-24 22:25:46.291565
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:25:47.650037
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:25:49.552855
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:25:51.575767
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:26:54.324018
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()



# Generated at 2022-06-24 22:27:02.125317
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    memory_facts = {}
    # Get free memory. vmstat output looks like:
    #  procs    memory       page                    disks    traps          cpu
    #  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id
    #  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99
    cmd_0 = '/usr/bin/vmstat'

# Generated at 2022-06-24 22:27:05.872203
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    try:
        open_b_s_d_hardware_0 = OpenBSDHardware(None)
        open_b_s_d_hardware_0.get_memory_facts()
    except Exception as err:
        print("Exception raised in OpenBSDHardware.get_memory_facts: " + err.__str__())

# Generated at 2022-06-24 22:27:11.764776
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    # Process gets killed after 10 minutes
    # assert var_0 == {}


# Generated at 2022-06-24 22:27:16.407909
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # Case 1
    bool_0 = False
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(bool_0)
    assert open_b_s_d_hardware_collector_0._fact_class._platform == 'OpenBSD'



# Generated at 2022-06-24 22:27:18.349846
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    bool_1 = False
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(bool_1)



# Generated at 2022-06-24 22:27:28.771741
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bool_0 = False
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0, dmidecode_data=None)
    open_b_s_d_hardware_0.dmidecode = dmidecode_0
    open_b_s_d_hardware_0.mount_exists = mount_exists_0
    open_b_s_d_hardware_0.populate()
    var_0 = open_b_s_d_hardware_0.get_device_facts()
    var_1 = open_b_s_d_hardware_0.get_memory_facts()
    var_2 = open_b_s_d_hardware_0.get_dmi_facts()
    var_3 = open_b_s_d_hardware

# Generated at 2022-06-24 22:27:33.754252
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    bool_0 = True
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    open_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:27:37.162133
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    bool_0 = True
    open_b_s_d_hardware_0 = OpenBSDHardware(bool_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert var_0.has_key('uptime_seconds') == True


# Generated at 2022-06-24 22:27:39.492624
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():

    open_b_s_d_hardware_0 = OpenBSDHardware(False)

    open_b_s_d_hardware_0.get_dmi_facts()

    var_0 = open_b_s_d_hardware_0.populate()
    assert isinstance(var_0, dict)
