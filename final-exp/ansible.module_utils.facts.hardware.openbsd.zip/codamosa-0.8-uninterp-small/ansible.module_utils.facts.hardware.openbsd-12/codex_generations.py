

# Generated at 2022-06-24 22:19:31.298899
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {
        'hw.disknames': 'sd0',
    }
    open_b_s_d_hardware_0.module = MockModule('OpenBSD')

    open_b_s_d_hardware_0.get_device_facts()
    expected = {'devices': ['sd0']}
    assert open_b_s_d_hardware_0.device == expected



# Generated at 2022-06-24 22:19:40.607361
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    # Hardware defined in module_utils/facts/hardware/openbsd.py
    h = OpenBSDHardware(dict())
    h.sysctl['hw.ncpuonline'] = "4"
    h.sysctl['hw.model'] = "intel"
    # Method get_processor_facts() defined in module_utils/facts/hardware/openbsd.py
    d = h.get_processor_facts()
    # d is a dictionary and has the following key-values:
    # {'processor': ['intel', 'intel', 'intel', 'intel'], 'processor_cores': 4, 'processor_count': 4, 'processor_speed': ''}
    assert d['processor_count'] == 4
    assert d['processor_cores'] == 4
    assert d['processor'] == ['intel', 'intel', 'intel', 'intel']

# Generated at 2022-06-24 22:19:48.606287
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module = MagicMock()
    open_b_s_d_hardware_0.module.run_command.return_value = (0, "193635", "")
    # OpenBSDHardware.get_uptime_facts()
    result_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert result_0["uptime_seconds"] == 1


# Generated at 2022-06-24 22:19:52.914509
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    tuple_0 = ()
    open_b_s_d_hardware_0 = OpenBSDHardware(tuple_0)
    assert open_b_s_d_hardware_0.get_dmi_facts() == {}

# Generated at 2022-06-24 22:19:55.749570
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()

    tuple_0 = ()
    open_b_s_d_hardware_0.populate(tuple_0)


# Generated at 2022-06-24 22:20:03.958000
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    """
    Test method OpenBSDHardware.get_processor_facts
    """

    tuple_0 = ()
    open_b_s_d_hardware_0 = OpenBSDHardware(tuple_0)

    open_b_s_d_hardware_0.sysctl = {'hw.ncpuonline': '1', 'hw.model': 'Intel(R) Core(TM) i7-4850HQ CPU @ 2.30GHz'}

    cpu_facts_return_value = open_b_s_d_hardware_0.get_processor_facts()
    pass


# Generated at 2022-06-24 22:20:04.790157
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert not OpenBSDHardwareCollector


# Generated at 2022-06-24 22:20:09.681007
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.params['gather_subset'] = ['all']
    module.params['filter'] = ['*']
    module.exit_json(**OpenBSDHardware(module).populate())


# Generated at 2022-06-24 22:20:20.678999
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    tuple_0 = ()
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(tuple_0)
    test_OpenBSDHardware_0 = OpenBSDHardware()
    test_OpenBSDHardware_0.sysctl = {'hw.usermem': '133694976}'}

# Generated at 2022-06-24 22:20:24.706719
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    tuple_0 = ()
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector(tuple_0)
    assert len(open_b_s_d_hardware_collector_1._collectors) == 1


# Generated at 2022-06-24 22:20:38.054354
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()
    print(var_0)
    var_1 = True
    print(var_1)


# Generated at 2022-06-24 22:20:42.559431
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    var_0 = open_b_s_d_hardware_0


# Generated at 2022-06-24 22:20:49.339114
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Check if the method returns a dictionary.
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    assert isinstance(open_b_s_d_hardware_0.populate(), dict)

if __name__ == "__main__":
    test_case_0()
    test_OpenBSDHardware_populate()

# Generated at 2022-06-24 22:20:55.391897
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.populate()
    var_1 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:20:58.378898
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_collector_2 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_1 = OpenBSDHardware(open_b_s_d_hardware_collector_2)
    var_0 = open_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:21:00.080515
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:21:07.984215
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    m_0 = MagicMock()
    setattr(m_0, 'get_bin_path', MagicMock(return_value='/usr/bin/vmstat'))
    m_0.run_command.return_value = (0, '0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99', '')
    setattr(m_0, 'get_bin_path', MagicMock(return_value='/sbin/swapctl'))
    m_0.run_command.return_value = (0, 'total: 69268 1K-blocks allocated, 0 used, 69268 available', '')

# Generated at 2022-06-24 22:21:14.148983
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_1 = open_b_s_d_hardware_0.get_processor_facts()
    assert isinstance(var_1, dict)
    assert var_1 == {'processor': ['Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz'],
                     'processor_count': '4', 'processor_cores': '4'}


# Generated at 2022-06-24 22:21:15.023106
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:21:18.223490
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_1 = OpenBSDHardware(open_b_s_d_hardware_collector_1)
    var_0 = open_b_s_d_hardware_1.get_uptime_facts()


# Generated at 2022-06-24 22:21:35.139074
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0._fact_class is OpenBSDHardware
    assert open_b_s_d_hardware_collector_0._platform is 'OpenBSD'


# Generated at 2022-06-24 22:21:41.494875
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.populate()
    assert var_0['devices'] == ['wd0', 'wd1', 'wd0a', 'wd0d', 'wd1a', 'wd1d']


# Generated at 2022-06-24 22:21:48.460533
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()
    print(var_0)


# Generated at 2022-06-24 22:21:55.925387
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:21:59.843779
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:03.111413
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:22:08.868668
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:22:14.602673
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    open_b_s_d_hardware_0.populate()
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:22:20.631452
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:21.830800
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    pass
# (module_utils.facts.hardware.openbsd.OpenBSDHardware) -> dict


# Generated at 2022-06-24 22:23:05.524999
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_1 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:09.179177
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:23:11.975518
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_1 = OpenBSDHardware(OpenBSDHardwareCollector())
    if isinstance(open_b_s_d_hardware_1, Hardware):
        var_1 = open_b_s_d_hardware_1.get_uptime_facts()


# Generated at 2022-06-24 22:23:15.294495
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_1 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:22.872369
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_1 = OpenBSDHardware(open_b_s_d_hardware_collector_1)
    var_1 = open_b_s_d_hardware_1.get_uptime_facts()
    print(var_1)


# Generated at 2022-06-24 22:23:24.879693
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    assert OpenBSDHardware(OpenBSDHardwareCollector()).get_uptime_facts() == {'uptime_seconds': 0}


# Generated at 2022-06-24 22:23:28.665403
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:35.453194
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    try:
        open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    except NameError:
        assert False

    assert open_b_s_d_hardware_collector_0


# Generated at 2022-06-24 22:23:39.452594
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_1 = OpenBSDHardware(open_b_s_d_hardware_collector_1)
    open_b_s_d_hardware_1.populate()


# Generated at 2022-06-24 22:23:42.459750
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    open_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:24:41.967412
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:24:46.413379
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_1 = OpenBSDHardware(open_b_s_d_hardware_collector_1)
    open_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:24:47.849946
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()

# Generated at 2022-06-24 22:24:52.323810
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_1 = OpenBSDHardware(open_b_s_d_hardware_collector_1)
    var_0 = open_b_s_d_hardware_1.get_processor_facts()


# Generated at 2022-06-24 22:24:58.179784
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    expected_result_0 = {'processor_cores': '1', 'processor_count': '2', 'processor': ['ARM64 Processor rev 0 (aarch64)'], 'processor_speed': '0.002'}
    result_0 = open_b_s_d_hardware_0.get_processor_facts()

    assert result_0 == expected_result_0



# Generated at 2022-06-24 22:24:58.684545
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Run test case 0
    test_case_0()

# Generated at 2022-06-24 22:24:59.206090
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert True == True


# Generated at 2022-06-24 22:25:00.563942
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    pass  # TODO : Test if this works on a OpenBSD setup


# Generated at 2022-06-24 22:25:03.536099
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:25:09.670435
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_1 = OpenBSDHardware(open_b_s_d_hardware_collector_1)
    var_1 = open_b_s_d_hardware_1.populate()
    var_2 = open_b_s_d_hardware_1.get_dmi_facts()



# Generated at 2022-06-24 22:27:29.489741
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_1 = open_b_s_d_hardware_0.populate()
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:27:33.177412
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_1 = OpenBSDHardware(open_b_s_d_hardware_collector_1)
    var_1 = open_b_s_d_hardware_1.get_uptime_facts()
    assert var_1 == {'uptime_seconds': 1523907724, }


# Generated at 2022-06-24 22:27:38.001033
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    assert open_b_s_d_hardware_0.get_memory_facts() == {'memfree_mb': None, 'memtotal_mb': None, 'swapfree_mb': None, 'swaptotal_mb': None}


# Generated at 2022-06-24 22:27:40.077056
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector._platform == 'OpenBSD'


# Generated at 2022-06-24 22:27:43.590633
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:27:49.593770
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert var_0['swapfree_mb'] == 3913
    assert type(var_0['swapfree_mb']) is int
    assert var_0['memfree_mb'] == 6076
    assert type(var_0['memfree_mb']) is int
    assert var_0['swaptotal_mb'] == 5939
    assert type(var_0['swaptotal_mb']) is int
    assert var_0['memtotal_mb'] == 607

# Generated at 2022-06-24 22:27:50.683440
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:27:56.663095
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.populate()
    assert len(var_0) == 10
    assert var_0['processor'] == ['Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz']
    assert var_0['memtotal_mb'] == 8192

# Generated at 2022-06-24 22:28:02.261999
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    # Call test method to check if OpenBSDHardware.get_processor_facts() works as expected.
    result = open_b_s_d_hardware_0.get_processor_facts()

    assert result is not None


# Generated at 2022-06-24 22:28:04.486328
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_collector_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()
    var_1 = open_b_s_d_hardware_0.populate()
