

# Generated at 2022-06-24 22:19:27.667935
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()

    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:19:36.346131
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module = AnsibleModuleStub()
    open_b_s_d_hardware_0.module.run_command = stub_run_command
    open_b_s_d_hardware_0.sysctl = {'hw.usermem': '655360',
                                    'hw.ncpuonline': '4'}
    open_b_s_d_hardware_0.populate()
    memory_facts_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert memory_facts_0['memfree_mb'] == 28160
    assert memory_facts_0['memtotal_mb'] == 627

# Generated at 2022-06-24 22:19:44.898436
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    """
    Tests get_device_facts method of class OpenBSDHardware
    """
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {'hw.disknames': 'vnd0,vnd1,cd0'}
    assert open_b_s_d_hardware_0.get_device_facts() == {'devices': ['vnd0', 'vnd1', 'cd0']}


# Generated at 2022-06-24 22:19:55.249168
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    ansible_module_0 = AnsibleModule(
        argument_spec={
            'filter': {
                'required': False,
                'type': 'list',
                'choices': ['*']
            },
            'gather_subset': {
                'required': False,
                'type': 'list',
                'choices': ['all', '!all', 'min', '!min']
            }
        },
        supports_check_mode=False
    )
    open_b_s_d_hardware_0.module = ansible_module_0
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:19:59.810948
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(dict())

    dmi_facts = open_b_s_d_hardware_0.get_dmi_facts()
    assert dmi_facts is not None
    assert dmi_facts == {}


# Generated at 2022-06-24 22:20:08.191126
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    # Make a mock module
    test_module = type('', (), {})()
    test_module.run_command = lambda cmd, **kwargs: (0, 'hw.version=6.2\nhw.product=OpenBSD 6.2\nhw.uuid=none\nhw.serialno=none\nhw.vendor=OpenBSD\n', '')
    test_module.get_bin_path = lambda cmd: cmd
    # Make a mock facts
    test_facts = type('', (), {})()

    open_b_s_d_hardware_0 = OpenBSDHardware(module=test_module, facts=test_facts)


# Generated at 2022-06-24 22:20:14.186655
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    facts = open_b_s_d_hardware_0.get_memory_facts()
    assert facts['memfree_mb'] == 123
    assert facts['memtotal_mb'] == 456
    assert facts['swapfree_mb'] == 789
    assert facts['swaptotal_mb'] == 42


# Generated at 2022-06-24 22:20:17.233017
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware(dict())

    assert open_b_s_d_hardware_0.populate() == {}


# Generated at 2022-06-24 22:20:19.924029
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    assert open_b_s_d_hardware_0.populate() == {}


# Generated at 2022-06-24 22:20:21.545998
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # (not implemented)
    assert True


# Generated at 2022-06-24 22:20:30.860793
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:20:35.065580
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:20:37.727938
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # Constructor of class OpenBSDHardwareCollector should add an _fact_class attribute, call the parent's constructor and not throw an error
    assert True

# TESTCASE 1

# Generated at 2022-06-24 22:20:41.332009
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'RVGt'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()
    # Unit test for method get_processor_facts of class OpenBSDHardware

# Generated at 2022-06-24 22:20:46.895857
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)

    var_0 = open_b_s_d_hardware_collector_0.get_platform()
    str_1 = 'OpenBSD'
    assert var_0 == str_1


# Generated at 2022-06-24 22:20:54.371405
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = 'mQ8\x17AO\x1a\x1c'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.sysctl = {
        'hw.usermem': '394357042176',
    }
    open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:20:55.680733
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    var = OpenBSDHardware()
    uptime_facts = var.get_uptime_facts()



# Generated at 2022-06-24 22:21:01.009213
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    _fact_class = OpenBSDHardware
    _platform = 'OpenBSD'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(_fact_class, _platform)
    assert open_b_s_d_hardware_collector_0._fact_class == _fact_class
    assert open_b_s_d_hardware_collector_0._platform == _platform



# Generated at 2022-06-24 22:21:04.290942
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:21:08.011023
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '2c4'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    # Test your method with different arguments
    result = open_b_s_d_hardware_0.get_uptime_facts()
    assert result


# Generated at 2022-06-24 22:21:22.796330
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:21:30.643751
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = "Gp^;Nk"
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.populate()
    var_0 = open_b_s_d_hardware_0.get_device_facts()
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    var_0 = open_b_s_d_hardware_0.get_processor_facts()
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()

# Generated at 2022-06-24 22:21:34.448317
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():

    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:21:38.530228
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '/T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:21:43.597744
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_test_name = 'get_processor_facts'
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.sysctl
    var_1 = open_b_s_d_hardware_0.module
    var_2 = open_b_s_d_hardware_0.populate(var_1)

# Generated at 2022-06-24 22:21:45.672659
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'mPB6UiV6'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:21:53.502755
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = 'X9r\r,'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.module = MagicMock()
    open_b_s_d_hardware_0.module.run_command.return_value = (0, '', '')

    open_b_s_d_hardware_0.module.get_bin_path.return_value = 'LIaP_E4e4'

    var_0 = open_b_s_d_hardware_0.get_uptime_facts()

    assert var_0 == {
        'uptime_seconds': 0
    }


# Generated at 2022-06-24 22:21:57.456553
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    try:
        str_0 = 'T67\rrQ4cq'
        open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    except:
        pass


# Generated at 2022-06-24 22:22:03.147898
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_1 = 'T67\rrQ4cq'
    open_b_s_d_hardware_1 = OpenBSDHardware(str_1)
    var_1 = open_b_s_d_hardware_1.get_dmi_facts()



# Generated at 2022-06-24 22:22:07.702807
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:22:24.628047
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = '/tmp/ansible_4X0b4d'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    var_0 = open_b_s_d_hardware_collector_0._fact_class
    var_1 = open_b_s_d_hardware_collector_0._platform

if __name__ == "__main__":
    print('Processing unit tests')
    #test_case_0()
    test_OpenBSDHardwareCollector()
    # TODO: Write unit tests

# Generated at 2022-06-24 22:22:27.752698
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = 'r'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert var_0 == {}


# Generated at 2022-06-24 22:22:35.600000
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'G\xa2\xe1\xee\xdaP\xbd\x95\x1d\x80\xc1\xd8\xba\x95\xd7\xdc\x8c\x81\xbc\xcc\xc2Y\x12\x98\xca\xa9\x93\xb1\x8e\xab'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.sysctl = {'hw.ncpuonline': '1', 'hw.model': 'OpenBSD'}
    var_0 = open_b_s_d_hardware_0.get_processor_facts()

# Generated at 2022-06-24 22:22:39.728510
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:22:49.691433
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Case 0:
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    str_1 = 'R9\x16\x81\xfa\\\x05\x8d\r\xa3\x1c\xe1\x8f\xee\xc0\xec\xde\x8b\x06'
    open_b_s_d_hardware_1 = OpenBSDHardware(str_1)
    var_1 = open_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:22:51.110265
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:22:55.744948
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.populate()
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:22:58.763843
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # Setting up parameter values
    str_1 = 'sSHPueCw'

    # Instantiating OpenBSDHardwareCollector and calling constructor
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_1)


# Generated at 2022-06-24 22:23:00.037440
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    pass


# Generated at 2022-06-24 22:23:05.627982
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    # AssertionError: ValueError('"platform" argument is required')
    # AssertionError: AssertionError('No "platform" information')
    # AssertionError: AssertionError('No "distribution" information')

# Generated at 2022-06-24 22:23:52.113826
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:23:55.348715
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:23:58.483605
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    bool_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:24:01.235878
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:24:04.703033
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:24:05.256745
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    assert True

# Generated at 2022-06-24 22:24:11.437271
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()
    assert(var_0 == {'devices': ['sd0']})


# Generated at 2022-06-24 22:24:12.004287
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert len(OpenBSDHardwareCollector._platform) > 0

# Generated at 2022-06-24 22:24:15.142829
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    dict_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:24:21.884089
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    arg_0 = 'T67\rrQ4cq'
    obj_0 = OpenBSDHardware(arg_0)
    var_0 = obj_0.get_uptime_facts()
    assert var_0 == {}
    arg_0 = 'iYy$!'
    obj_0 = OpenBSDHardware(arg_0)
    var_0 = obj_0.get_uptime_facts()
    assert var_0 == {}
    arg_0 = 'z_\x7f'
    obj_0 = OpenBSDHardware(arg_0)
    var_0 = obj_0.get_uptime_facts()
    assert var_0 == {}
    arg_0 = '^\x0e\x03\x07\x1f\r\x10t\x02'
    obj_0 = OpenBSDHardware

# Generated at 2022-06-24 22:26:27.196545
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0._fact_class == OpenBSDHardware, 'Could not create class OpenBSDHardwareCollector'


# Generated at 2022-06-24 22:26:28.783389
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = 'G|O)Oz'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:26:32.360837
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_1 = 'ts6\rW8aX'
    open_b_s_d_hardware_1 = OpenBSDHardware(str_1)
    var_1 = open_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:26:35.129225
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = 'T67\rrQ4cq'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:26:38.321492
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():

    str_0 = 'T67\rr`4cq'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 22:26:39.126594
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # Test case0
    test_case_0()

# Generated at 2022-06-24 22:26:43.177987
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # Case 1:
    str_1 = 'T67\rrQ4cq'
    open_b_s_d_hardware_1 = OpenBSDHardware(str_1)
    var_1 = open_b_s_d_hardware_1.populate()


# Generated at 2022-06-24 22:26:47.258805
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = 'd5$X+'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()
    assert 'devices' in var_0
    assert len(var_0['devices']) == 4


# Generated at 2022-06-24 22:26:48.503186
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert isinstance(OpenBSDHardwareCollector(), HardwareCollector)


# Generated at 2022-06-24 22:26:50.372757
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    int_0 = OpenBSDHardware.get_processor_facts(0, 0)
