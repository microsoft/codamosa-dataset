

# Generated at 2022-06-24 22:19:27.763819
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:19:30.156148
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()

# Generated at 2022-06-24 22:19:35.104900
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()
    open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:19:41.288206
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    memory_facts_0 = OpenBSDHardware().populate()
    memory_facts_1 = OpenBSDHardware().get_memory_facts()
    assert memory_facts_1['swaptotal_mb'] == memory_facts_0['swaptotal_mb']
    assert memory_facts_1['memtotal_mb'] == memory_facts_0['memtotal_mb']
    assert memory_facts_1['swapfree_mb'] == memory_facts_0['swapfree_mb']
    assert memory_facts_1['memfree_mb'] == memory_facts_0['memfree_mb']


# Generated at 2022-06-24 22:19:45.644584
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_get_memory_facts_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:19:47.968339
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector = OpenBSDHardwareCollector()



# Generated at 2022-06-24 22:19:58.025984
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware({})
    open_b_s_d_hardware_0.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz', 'hw.ncpu': '4'}

    assert open_b_s_d_hardware_0.get_processor_facts() == {'processor': ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz', 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'], 'processor_cores': '2', 'processor_count': '2'}


# Generated at 2022-06-24 22:20:01.819390
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    if not isinstance(open_b_s_d_hardware_collector_0, OpenBSDHardwareCollector):
        assert False


# Generated at 2022-06-24 22:20:09.093344
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()

    open_b_s_d_hardware_0.sysctl = {
            'hw.ncpuonline': '1',
            'hw.model': 'Intel(R) Xeon(R) CPU E5-2630 v2 @ 2.60GHz',
            }

    open_b_s_d_hardware_0.module = {
            'run_command': lambda x: (0, '1', ''),
            'get_bin_path': lambda x: '/usr/bin/sysctl',
            }

    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:20:10.189261
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    pass # Nothing to test


# Generated at 2022-06-24 22:20:18.528473
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)

    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:20:22.125101
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:20:25.458541
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:20:30.542299
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_2 = ''
    open_b_s_d_hardware_2 = OpenBSDHardware(str_2)
    # Populate the 'uptime_seconds' attribute
    open_b_s_d_hardware_2.get_uptime_facts()
    var_1 = open_b_s_d_hardware_2.uptime_seconds


# Generated at 2022-06-24 22:20:32.649771
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:20:36.168704
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:20:37.588336
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # Unit Test Strings

    # Return Value Tests
    assert True == True

# Generated at 2022-06-24 22:20:42.259497
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.module.run_command = lambda x: (0, "12345\n", '')
    assert open_b_s_d_hardware_0.get_uptime_facts() == {'uptime_seconds': int(time.time() - 12345)}


# Generated at 2022-06-24 22:20:46.158452
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:20:49.589641
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:21:08.353795
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)

    assert open_b_s_d_hardware_0


# Generated at 2022-06-24 22:21:11.683445
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)

    var_0 = open_b_s_d_hardware_0.get_dmi_facts()

    assert var_0 == {}, "var_0 == {}"


# Generated at 2022-06-24 22:21:17.571198
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # Get the contents of file hw.usermem
    f = open("/tmp/hw.usermem.txt", "a")

    # To write contents of a file to a string
    var = f.read()

    # Close opend file
    f.close()

    # Create an instance of class OpenBSDHardware and invoke get_memory_facts method of it
    open_b_s_d_hardware_0 = OpenBSDHardware(var)
    open_b_s_d_hardware_0.get_memory_facts()



# Generated at 2022-06-24 22:21:21.154541
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    platform = 'OpenBSD'
    str_0 = 'OpenBSDHardware'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    print(open_b_s_d_hardware_collector_0.platform)
    print(open_b_s_d_hardware_collector_0._platform)


# Generated at 2022-06-24 22:21:26.562361
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()
    var_1 = open_b_s_d_hardware_0.populate()
    var_2 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:21:30.704464
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:21:33.477213
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    # Assert.
    assert open_b_s_d_hardware_collector_0


# Generated at 2022-06-24 22:21:37.416117
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    assert open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:21:40.729608
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:21:46.749185
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:11.007863
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    pass


# Generated at 2022-06-24 22:22:12.886174
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = ''
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:22:20.395778
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # Case 0: Test that module is created and that platform is set
    collector = OpenBSDHardwareCollector()
    assert collector._platform == 'OpenBSD'

    # Case 1: Test that module implements the facts_type property correctly
    assert collector.facts_type == 'hardware'

    # Case 2: Test that module implements the mandatory_facts property correctly
    assert collector.mandatory_facts == ('devices', 'memfree_mb', 'memtotal_mb', 'processor', 'swaptotal_mb')

    # Case 3: Test that module implements the optional_facts property correctly

# Generated at 2022-06-24 22:22:23.065588
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:22:25.951068
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:22:27.752300
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = ''
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)

# Generated at 2022-06-24 22:22:30.141006
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:22:32.224623
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:22:36.200437
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:22:40.978383
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    result_0 = open_b_s_d_hardware_0.get_uptime_facts()
#.
#.     assert result_0 == expected_0, 'Return value mismatch'
#.


# Generated at 2022-06-24 22:23:34.749498
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = 'hw.disknames'

    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    result = open_b_s_d_hardware_0.get_device_facts()

    assert result == {}
    assert result is not None

    str_1 = ''
    open_b_s_d_hardware_1 = OpenBSDHardware(str_1)
    var_1 = open_b_s_d_hardware_1.get_device_facts()


# Generated at 2022-06-24 22:23:37.602774
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    print(var_0)


# Generated at 2022-06-24 22:23:41.964968
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = ''
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    assert open_b_s_d_hardware_collector_0._fact_class == OpenBSDHardware
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'
    assert isinstance(open_b_s_d_hardware_collector_0, HardwareCollector)


# Generated at 2022-06-24 22:23:44.681680
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:23:49.187263
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert len(var_0) > 0


# Generated at 2022-06-24 22:23:54.107096
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # Test with default args
    str_1 = ''
    open_b_s_d_hardware_1 = OpenBSDHardware(str_1)
    var_1 = open_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:23:56.987215
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:23:59.061104
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware(str())
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:24:02.498051
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:24:08.797181
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = ''
    open_b_s_d_hardware = OpenBSDHardware(str_0)
    assert open_b_s_d_hardware.get_dmi_facts() == {
        'product_name': 'OpenBSD',
        'product_serial': 'OpenBSD',
        'system_vendor': 'OpenBSD',
    }


# Generated at 2022-06-24 22:26:13.554641
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()

    open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:26:14.375947
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert True == True

# Generated at 2022-06-24 22:26:21.756998
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.module.run_command = lambda cmd: (0, '', '')
    var_0 = open_b_s_d_hardware_0.get_memory_facts()
    assert var_0 == {'swapfree_mb': 0, 'swaptotal_mb': 0, 'memfree_mb': 0, 'memtotal_mb': 0}
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.module.run_command = lambda cmd: (1, '', '')
    var_0 = open_b_s

# Generated at 2022-06-24 22:26:23.907941
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:26:25.980032
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:26:31.837411
# Unit test for method get_memory_facts of class OpenBSDHardware

# Generated at 2022-06-24 22:26:33.902333
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:26:36.803286
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = ''
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)
    print(open_b_s_d_hardware_collector_0)

# Generated at 2022-06-24 22:26:41.014069
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardwareCollector
    str_0 = ''
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)

if __name__ == '__main__':
    test_OpenBSDHardwareCollector()
    test_case_0()
    print('unit_test success')

# Generated at 2022-06-24 22:26:43.900648
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()