

# Generated at 2022-06-24 22:19:31.620764
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    int_0 = 5508
    open_b_s_d_hardware_0 = OpenBSDHardware(int_0)
    memory_facts = {}
    memory_facts.update({'memfree_mb': 648})
    memory_facts.update({'memtotal_mb': 64245})
    memory_facts.update({'swapfree_mb': 79562})
    memory_facts.update({'swaptotal_mb': 79562})
    assert memory_facts == open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:19:35.614353
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    int_0 = None
    open_b_s_d_hardware_0 = OpenBSDHardware(int_0)
    dic_0 = open_b_s_d_hardware_0.get_processor_facts()
    assert dic_0 == {}



# Generated at 2022-06-24 22:19:43.577689
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    function = OpenBSDHardware.get_memory_facts
    int_0 = 3015
    open_b_s_d_hardware_0 = OpenBSDHardware(int_0)
    open_b_s_d_hardware_1 = OpenBSDHardware(int_0)
    open_b_s_d_hardware_1.run_command = classmethod(lambda *args, **kwargs: (0, '', ''))
    open_b_s_d_hardware_1.sysctl = {'hw.usermem': '358464'}
    var_1 = open_b_s_d_hardware_1.get_memory_facts()

# Generated at 2022-06-24 22:19:48.686250
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    int_0 = 3015
    open_b_s_d_hardware_0 = OpenBSDHardware(int_0)
    # OpenBSDHardware.get_uptime_facts must return dict
    assert isinstance(open_b_s_d_hardware_0.get_uptime_facts(), dict)


# Generated at 2022-06-24 22:19:59.861749
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    int_0 = 3015
    open_b_s_d_hardware_0 = OpenBSDHardware(int_0)
    open_b_s_d_hardware_0.sysctl = {'hw.ncpuonline': '1', 'hw.model': 'Intel(R) Core(TM) i5-6300U CPU @ 2.40GHz'}
    dict_0 = open_b_s_d_hardware_0.get_processor_facts()
    assert isinstance(dict_0, dict) is True
    msg = 'Expected dict, got %s' % repr(dict_0)
    assert dict_0 == {'processor_cores': '1', 'processor_count': '1', 'processor': ['Intel(R) Core(TM) i5-6300U CPU @ 2.40GHz']}, msg


# Generated at 2022-06-24 22:20:03.378272
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    int_0 = 3015
    open_b_s_d_hardware_0 = OpenBSDHardware(int_0)
    bool_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:20:07.189602
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    int_0 = 3015
    open_b_s_d_hardware_0 = OpenBSDHardware(int_0)
    open_b_s_d_hardware_0.module = MockModule
    dmi_facts_1 = open_b_s_d_hardware_0.get_dmi_facts()
    assert dmi_facts_1 != False


# Generated at 2022-06-24 22:20:09.731454
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    int_0 = 3015
    open_b_s_d_hardware_0 = OpenBSDHardware(int_0)


# Generated at 2022-06-24 22:20:17.539051
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(int_0)
    open_b_s_d_hardware_0.module = MockModule()
    open_b_s_d_hardware_0.module.run_command = Mock(return_value=(0, output_0, 0))
    open_b_s_d_hardware_0.sysctl = {'hw.usermem': int_0}
    open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:20:27.234749
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    int_0 = 3015
    open_b_s_d_hardware_0 = OpenBSDHardware(int_0)
    debug_0 = int_0
    open_b_s_d_hardware_0.module = debug_0
    open_b_s_d_hardware_0.sysctl = get_sysctl(debug_0, ['hw'])
    rc_0 = 0
    out_0 = '  procs    memory     page                    disks    traps          cpu\n  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n  0 0 0  47512  28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99'
    err

# Generated at 2022-06-24 22:20:40.028675
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = dict({u'hw.usermem': 256000, u'hw.ncpuonline': u'2'})
    open_b_s_d_hardware_0.get_memory_facts()
    open_b_s_d_hardware_1 = OpenBSDHardware()
    open_b_s_d_hardware_1.sysctl = dict({u'hw.usermem': 256000, u'hw.ncpuonline': u'2'})
    open_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:20:50.874020
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    sysctl_value = {'hw.ncpu': '8',
                    'hw.ncpuonline': '2',
                    'hw.model': 'Intel(R) Core(TM) i5-8250U CPU @ 1.60GHz'}

    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = sysctl_value
    return_value = open_b_s_d_hardware_0.get_processor_facts()
    assert return_value['processor'] == ['Intel(R) Core(TM) i5-8250U CPU @ 1.60GHz']
    assert return_value['processor_count'] == '2'
    assert return_value['processor_cores'] == '2'



# Generated at 2022-06-24 22:20:54.371266
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # Set up object instance
    open_b_s_d_hardware_0 = OpenBSDHardware()
    ############################################################################
    # TODO: Unit test get_memory_facts of OpenBSDHardware
    ############################################################################



# Generated at 2022-06-24 22:20:57.505546
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    sample_out = {'devices': ['wd0', 'sd0']}
    hardware = OpenBSDHardware({'hw.disknames': 'wd0,sd0'})
    assert hardware.get_device_facts() == sample_out


# Generated at 2022-06-24 22:21:06.099465
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():

    # Answer to be expected
    expected = {
        'processor_speed': '2194',
        'devices': ['sd0'],
        'memfree_mb': '99',
        'memtotal_mb': '816',
        'processor': ['Intel(R) Core(TM) i3-3217U CPU @ 1.80GHz'],
        'processor_cores': '2',
        'processor_count': '2',
        'uptime_seconds': '542'
    }

    # Class instantiation
    mocked_module = MockModule()
    open_b_s_d_hardware = OpenBSDHardware(mocked_module)

    # Populate
    result = open_b_s_d_hardware.populate()

    # assertEqual for result
    assertEqual(result, expected)




# Generated at 2022-06-24 22:21:14.016878
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

    # Mock the arguments and return values of the function get_sysctl.

# Generated at 2022-06-24 22:21:20.433779
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():

    # Initialize test case parameters
    openBSDHardware_getProcessorFacts_expectedResult = {'processor': [u'Intel(R) Core(TM) i7-4700MQ CPU @ 2.40GHz'], 'processor_count': u'8', 'processor_cores': u'8'}

    # Initialize test case class object
    testCase = OpenBSDHardware()

    # Get actual results
    openBSDHardware_getProcessorFacts_actualResults = testCase.get_processor_facts()

    # Compare actual and expected results
    assert openBSDHardware_getProcessorFacts_expectedResult == openBSDHardware_getProcessorFacts_actualResults


# Generated at 2022-06-24 22:21:29.728613
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware({})
    open_b_s_d_hardware_0.sysctl = {u'hw.model': u'Intel(R) Xeon(R) CPU E5-2660 v2 @ 2.20GHz', u'hw.ncpuonline': u'8'}
    open_b_s_d_hardware_0.module = None
    open_b_s_d_hardware_0.populate()
    assert open_b_s_d_hardware_0.populate() == {u'processor': [u'Intel(R) Xeon(R) CPU E5-2660 v2 @ 2.20GHz'] * 8, u'processor_cores': u'8', u'processor_count': u'8'}


# Generated at 2022-06-24 22:21:36.982668
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # given
    controller = OpenBSDHardware()
    controller.module.run_command = run_command_mock
    controller.sysctl = {'hw.usermem': '49995088896'}

    # when
    result = controller.get_memory_facts()

    # then
    assert result['memfree_mb'] == 2385
    assert result['memtotal_mb'] == 23815
    assert result['swapfree_mb'] == 2440
    assert result['swaptotal_mb'] == 2440


# Generated at 2022-06-24 22:21:44.789693
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():

    my_open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()

    # Apply 'test_case_0'
    test_case_0()

    my_open_b_s_d_hardware_0.populate()

    assert my_open_b_s_d_hardware_0.processor == ['Intel(R) Core(TM) i5-5300U CPU @ 2.30GHz']
    assert my_open_b_s_d_hardware_0.processor_cores == '2'
    assert my_open_b_s_d_hardware_0.processor_count == '2'
    assert my_open_b_s_d_hardware_0.processor_speed == ''

# Generated at 2022-06-24 22:21:56.626595
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
  open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
# Finalizer test of class OpenBSDHardwareCollector
# Ensure class OpenBSDHardwareCollector is created and initialized properly

# Generated at 2022-06-24 22:21:59.076967
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    return open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:22:02.059367
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:22:05.268184
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    assert open_b_s_d_hardware_0.get_uptime_facts() == {'uptime_seconds': 1767}

# Generated at 2022-06-24 22:22:10.306700
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    print('Testing populate')
    # Test module
    module_0 = AnsibleModule(
        argument_spec = dict()
    )
    # Test class
    open_b_s_d_hardware_0 = OpenBSDHardware(module_0)
    # Test method
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:22:14.007728
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    result = open_b_s_d_hardware_0.get_dmi_facts()
    assert type(result) == dict
    assert result == {}



# Generated at 2022-06-24 22:22:18.495330
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware()
    # Testing function call with mocked arguments
    open_b_s_d_hardware_0.get_uptime_facts()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDHardware_get_uptime_facts()

# Generated at 2022-06-24 22:22:21.949551
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.collect()
    open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:22:29.855072
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.subset = dict()
    open_b_s_d_hardware_0.subset['command'] = 'sysctl'
    open_b_s_d_hardware_0.subset['filter'] = 'hw.disknames'
    open_b_s_d_hardware_0.subset['rc'] = 0
    open_b_s_d_hardware_0.subset['stdout'] = 'wd0,cd0'
    open_b_s_d_hardware_0.subset['stderr'] = ''
    open_b_s_d_hardware_0.subset['warnings'] = []
    open_b_s_d_hard

# Generated at 2022-06-24 22:22:33.898638
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    hw = OpenBSDHardware()
    hw.sysctl = {'hw.usermem': '1073714176',
                 'hw.ncpuonline': '1'}
    out = hw.get_memory_facts()
    assert out['memfree_mb'] == int(out['memfree_mb'])
    assert out['memtotal_mb'] == int(out['memtotal_mb'])


# Generated at 2022-06-24 22:22:59.218311
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module = 'command'
    open_b_s_d_hardware_0.run_command = ['command']
    open_b_s_d_hardware_0.sysctl = {'hw': 'hw'}
    open_b_s_d_hardware_0.get_bin_path = ['path']

    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:06.911901
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    # Instantiate object of class OpenBSDHardware
    open_b_s_d_hardware_0 = OpenBSDHardware()

    # mock the sysctl dict
    open_b_s_d_hardware_0.sysctl = {
        'hw.disknames': 'sd1,sd2'
    }

    # call the method get_device_facts
    result = open_b_s_d_hardware_0.get_device_facts()

    assert result == {'devices': ['sd1', 'sd2']}

# Generated at 2022-06-24 22:23:08.280188
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()

# Generated at 2022-06-24 22:23:11.025488
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    out_1 = "1535113425"
    setattr(open_b_s_d_hardware_collector_0.module, "run_command", lambda *args, **kwargs: (0, out_1, ""))
    data = open_b_s_d_hardware_collector_0.get_uptime_facts()

    assert data["uptime_seconds"] == 1802


# Generated at 2022-06-24 22:23:16.992267
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {'hw.usermem': '11264000', 'hw.pagesize': '4096'}
    open_b_s_d_hardware_0.module = MagicMock()

# Generated at 2022-06-24 22:23:24.614729
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware( {}, {}, {} )
    open_b_s_d_hardware_0.sysctl = { 'hw.disknames': 'sd0,sd1' }
    expected = {'devices': ['sd0', 'sd1']}
    assert open_b_s_d_hardware_0.get_device_facts() == expected


# Generated at 2022-06-24 22:23:29.447775
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    oopenbsdhardware0 = OpenBSDHardware()
    oopenbsdhardware0.module.run_command = lambda x: (0, '', '')
    returned_memory_facts = oopenbsdhardware0.get_memory_facts()
    return_values = (
        {'swapfree_mb': 0, 'memfree_mb': 0, 'swaptotal_mb': 0, 'memtotal_mb': 0},
        returned_memory_facts
    )



# Generated at 2022-06-24 22:23:40.962212
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module = AnsibleModuleStub()

# Generated at 2022-06-24 22:23:43.728732
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware = OpenBSDHardware()
    assert isinstance(open_b_s_d_hardware.get_processor_facts(), dict)


# Generated at 2022-06-24 22:23:48.718213
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0.populate()
    open_b_s_d_hardware_collector_0.populate()


# Generated at 2022-06-24 22:24:44.933074
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:24:47.485227
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0 is not None


# Generated at 2022-06-24 22:24:49.366810
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    openbsd_hardware_instance = OpenBSDHardware()
    openbsd_hardware_instance.get_memory_facts()


# Generated at 2022-06-24 22:24:54.828499
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    openbsd_hw_ins = OpenBSDHardware()
    openbsd_hw_ins.sysctl = {'hw.usermem': 4294967296,
                             'hw.ncpuonline': '4',
                             'hw.model': 'Intel(R) Core(TM) i7-2630QM CPU @ 2.00GHz'}
    openbsd_hw_ins.populate()
    openbsd_hw_ins.get_processor_facts()


# Generated at 2022-06-24 22:25:03.130311
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0 = open_b_s_d_hardware_collector_0.collect()
    open_b_s_d_hardware_1 = open_b_s_d_hardware_collector_0.collect_device()
    open_b_s_d_hardware_2 = open_b_s_d_hardware_collector_0.collect_memory()
    open_b_s_d_hardware_3 = open_b_s_d_hardware_collector_0.collect_processor()

# Generated at 2022-06-24 22:25:08.538137
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    openBSDHardwareInstance = OpenBSDHardware()
    if not hasattr(openBSDHardwareInstance, 'get_processor_facts'):
        raise Exception("Method get_processor_facts not defined")

    openBSDHardwareInstance.sysctl = dict()
    openBSDHardwareInstance.sysctl['hw.ncpuonline'] = "0"
    openBSDHardwareInstance.get_processor_facts()


# Generated at 2022-06-24 22:25:15.300836
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    mem = {'swapfree_mb': 0.0, 'swaptotal_mb': 0.0, 'memtotal_mb': 0.0, 'memfree_mb': 0.0}
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, "", ""))
    open_b_s_d_hardware_0.sysctl = {'hw.usermem': 0}
    assert open_b_s_d_hardware_0.get_memory_facts() == mem


# Generated at 2022-06-24 22:25:23.550348
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # Test when boottime value is valid
    sysctl_cmd = 'sysctl'
    cmd = [sysctl_cmd, '-n', 'kern.boottime']
    rc = 0
    out = '1536673370'
    err = ''
    fake_module = type('FakeModule', (object,), {
        'run_command': lambda x, y, z: (rc, out, err),
        'get_bin_path': lambda x: sysctl_cmd
    })
    module = fake_module()
    uptime_facts = OpenBSDHardware(module).get_uptime_facts()
    assert (int(uptime_facts['uptime_seconds']) - int(time.time() - int(out))) == 0

# Generated at 2022-06-24 22:25:28.678392
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    assert open_b_s_d_hardware_0.get_processor_facts() == {'processor': ['Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz'], 'processor_count': '1', 'processor_cores': '1'}


# Generated at 2022-06-24 22:25:32.434202
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    assert open_b_s_d_hardware_0.get_memory_facts() == {'swaptotal_mb': {'changed': False, 'failed': False, 'stdout': ''}}


# Generated at 2022-06-24 22:27:50.078549
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_obj_0 = OpenBSDHardware()
    return_value_0 = open_b_s_d_hardware_obj_0.get_processor_facts()
    assert return_value_0 == {}


# Generated at 2022-06-24 22:27:52.754171
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    assert open_b_s_d_hardware_0.get_uptime_facts() == {}


# Generated at 2022-06-24 22:27:59.569548
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.sysctl = {}
    assert open_b_s_d_hardware_0.get_device_facts() == {'devices': []}
    open_b_s_d_hardware_0.sysctl = {'hw.disknames': 'sd0 sd1'}
    assert open_b_s_d_hardware_0.get_device_facts() == {'devices': ['sd0', 'sd1']}


# Generated at 2022-06-24 22:28:05.737024
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # The following are used to test populate method of class OpenBSDHardware
    open_b_s_d_hardware_collector_populate_0 = OpenBSDHardwareCollector()

    # Testing populate method of OpenBSDHardware class
    open_b_s_d_hardware_populate_0 = OpenBSDHardware()
    open_b_s_d_hardware_populate_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDHardware_populate()

# Generated at 2022-06-24 22:28:08.196742
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware = OpenBSDHardware()
    collected_facts = {u'ansible_system': u'OpenBSD'}
    open_b_s_d_hardware.populate(collected_facts)


# Generated at 2022-06-24 22:28:12.129084
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    open_b_s_d_hardware = OpenBSDHardware({"hw.disknames": "hda,hdb"})
    assert open_b_s_d_hardware.get_device_facts() == {"devices": ["hda", "hdb"]}


# Generated at 2022-06-24 22:28:16.657550
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware({})

# Generated at 2022-06-24 22:28:19.599917
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:28:21.936933
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    assert OpenBSDHardware(None).get_memory_facts() == {'memfree_mb': 3850, 'swaptotal_mb': 69728, 'memtotal_mb': 3946, 'swapfree_mb': 69728}


# Generated at 2022-06-24 22:28:30.974628
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector_0._fact_class is not None
    assert open_b_s_d_hardware_collector_0._fact_class == OpenBSDHardware
    assert open_b_s_d_hardware_collector_0._platform is not None
    assert open_b_s_d_hardware_collector_0._platform == 'OpenBSD'
    assert open_b_s_d_hardware_collector_0._fact_class.platform is not None
    assert open_b_s_d_hardware_collector_0._fact_class.platform == 'OpenBSD'
