

# Generated at 2022-06-24 22:19:31.455119
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware(module=None)

    open_b_s_d_hardware_0._module.run_command.side_effect = [
        (0, "1599748360", ""),
        (0, "", ""),
    ]

    open_b_s_d_hardware_0._module.get_bin_path.return_value = "/usr/bin/sysctl"

    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:19:34.061011
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:19:46.318211
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    open_b_s_d_hardware_object_0 = OpenBSDHardware()

    open_b_s_d_hardware_object_0.sysctl = {'hw.product': 'Dell Inc. Latitude D620  ', 'hw.uuid': '78A4783C-9A4A-11DB-9DD4-A4D2C08BAA57', 'hw.version': '01', 'hw.vendor': 'Dell Inc. ', 'hw.serialno': '3P3V7H1 '}

    ret = open_b_s_d_hardware_object_0.get_dmi_facts()


# Generated at 2022-06-24 22:19:54.884643
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_get_processor_facts_0 = OpenBSDHardware()
    open_b_s_d_hardware_get_processor_facts_0.sysctl = {'hw.ncpuonline': '1', 'hw.model': 'Intel Xeon'}
    open_b_s_d_hardware_get_processor_facts_1 = OpenBSDHardware()
    open_b_s_d_hardware_get_processor_facts_1.sysctl = {'hw.ncpuonline': '1', 'hw.model': 'Intel Xeon'}
    open_b_s_d_hardware_get_processor_facts_2 = OpenBSDHardware()

# Generated at 2022-06-24 22:19:57.606030
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:19:59.591094
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:20:03.157291
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_1 = OpenBSDHardwareCollector()
    assert openbsd_1._fact_class == OpenBSDHardware
    assert openbsd_1._platform == 'OpenBSD'
# # Unit test for OpenBSDHardware().get_mount_facts()

# Generated at 2022-06-24 22:20:06.330381
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    assert open_b_s_d_hardware_0.get_processor_facts() == dict({})


# Generated at 2022-06-24 22:20:09.383230
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():

    openbsd_hardware = OpenBSDHardware()
    openbsd_hardware.populate()
    openbsd_hardware.get_memory_facts()


# Generated at 2022-06-24 22:20:14.912896
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    open_b_s_d_hardware_0.module = open_b_s_d_hardware_collector_0.module
    open_b_s_d_hardware_0.populate()
    assert open_b_s_d_hardware_0.uptime_seconds is not None


# Generated at 2022-06-24 22:20:33.468035
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # Uncomment next line to test constructor without parameters
    # open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    # Uncomment next line to test constructor with parameters
    # open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector(parameters)
    assert True # executed without raising any exceptions



# Generated at 2022-06-24 22:20:42.470667
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_facts_0 = {'hw.ncpuonline': '2',
                                   'hw.model': 'Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz'}
    open_b_s_d_hardware_0 = OpenBSDHardware(open_b_s_d_hardware_facts_0)

    assert open_b_s_d_hardware_0.get_processor_facts() == {'processor': ['Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz',
                                                                          'Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz'],
                                                           'processor_count': '2',
                                                           'processor_cores': '2'}


# Generated at 2022-06-24 22:20:51.034439
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware({})
    open_b_s_d_hardware_0.sysctl = {'hw.ncpuonline': '1', 'hw.model': 'Intel(R) Core(TM) i3 CPU       M 350  @ 2.27GHz'}
    var_1 = open_b_s_d_hardware_0.get_processor_facts()
    assert var_1 == {'processor_count': '1', 'processor_cores': '1', 'processor': ['Intel(R) Core(TM) i3 CPU       M 350  @ 2.27GHz']}


# Generated at 2022-06-24 22:20:53.791751
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    oBSDH = OpenBSDHardware()
    oBSDH.module = Mock(return_value=0)
    oBSDH.get_uptime_facts()


# Generated at 2022-06-24 22:20:55.534833
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_1 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:20:57.189506
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:20:59.631788
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector = OpenBSDHardwareCollector()
    assert open_b_s_d_hardware_collector is not None


# Generated at 2022-06-24 22:21:02.315420
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    result = open_b_s_d_hardware_0.get_processor_facts()
    assert result == {}


# Generated at 2022-06-24 22:21:05.626553
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    # check that populate returns a dict of facts
    open_b_s_d_hardware_0 = OpenBSDHardware()
    # Should return a dict of facts, but it could be an empty dict
    assert type(open_b_s_d_hardware_0.populate()) == dict


# Generated at 2022-06-24 22:21:09.861668
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware()
    open_b_s_d_hardware_0.module.run_command = lambda x: (0, '1379909484', '')
    assert open_b_s_d_hardware_0.get_uptime_facts() == {'uptime_seconds': 439}

# Generated at 2022-06-24 22:21:24.167353
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()

# Generated at 2022-06-24 22:21:27.637986
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = 'o\rB32:-'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:21:35.298689
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = 'OWcV7x_Uh\\N,V^lZ!@'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    str_0 = 'v#b;wF8dDR)@*=Kt(-v'
    str_1 = 'L-{_E(`v2Qq3~,!(y!d'
    str_2 = '5X&B7Z5^%Zn|n-LK-:>'
    dict_0 = dict()
    dict_0[str_1] = str_2
    open_b_s_d_hardware_0.sysctl = dict_0
    var_0 = open_b_s_d_hardware_0.get_device_facts()

    assert var_0

# Generated at 2022-06-24 22:21:39.960541
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()
    assert var_0 == {}



# Generated at 2022-06-24 22:21:42.567423
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = '3YE#D"K\x0c-\x7f,\x1d^'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:21:48.108059
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()
    str_0 = 'Cv'
    open_b_s_d_hardware_collector_0._platform = str_0
    assert open_b_s_d_hardware_collector_0._platform == 'Cv'

# Generated at 2022-06-24 22:21:50.357983
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
        str_0 = '2AG\rM9)qdWMqyo_-x5k'
        open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
        open_b_s_d_hardware_0._get_memory_facts()

# Generated at 2022-06-24 22:21:58.534728
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = 'y0_ny-k6%9@W#!p.vn7B'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    int_0 = open_b_s_d_hardware_0.get_uptime_facts()
    int_1 = open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:21:59.581611
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    pass


# Generated at 2022-06-24 22:22:03.230417
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    OBSD_HW = OpenBSDHardware(None)
    assert type(OBSD_HW.get_memory_facts()) is dict


# Generated at 2022-06-24 22:22:19.409774
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    str_0 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:22:20.811639
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert isinstance(OpenBSDHardwareCollector, HardwareCollector)


# Generated at 2022-06-24 22:22:23.506537
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '=pkgZD]fj3'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:27.597656
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # function name must start with test_
    str_0 = 'T7V*t$h.=P_`uzm9~mD'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:31.265555
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = 'as^\rg8IoWk-v5R'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()
    assert 'devices' in var_0
    assert var_0['devices'] == ['sd0']


# Generated at 2022-06-24 22:22:33.654430
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_1 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_1 = OpenBSDHardware(str_1)
    var_1 = open_b_s_d_hardware_1.get_processor_facts()


# Generated at 2022-06-24 22:22:45.358157
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()

# Generated at 2022-06-24 22:22:50.040949
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '`:D\x1e\xad{\xec\x1b{8\xb6'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_uptime_facts()

    assert isinstance(var_0, dict)



# Generated at 2022-06-24 22:22:54.487322
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:58.482029
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    str_0 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    # Exception thrown here when module name is invalid
    open_b_s_d_hardware_0.module.get_bin_path('sysctl')
    open_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:39.486390
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    str_0 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:23:44.682692
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    # Test for exceptions.
    open_b_s_d_hardware_0.populate()
    assert(open_b_s_d_hardware_0.platform == 'OpenBSD')


# Generated at 2022-06-24 22:23:47.560469
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
     
    openbsd_hardware_0 = OpenBSDHardware()
    openbsd_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:23:52.427867
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_1 = 'XC0'
    open_b_s_d_hardware_1 = OpenBSDHardware(str_1)
    var_1 = open_b_s_d_hardware_1.get_processor_facts()



# Generated at 2022-06-24 22:23:58.527821
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    string__0 = {'hw.usermem': '3145', 'hw.ncpuonline': '1'}
    open_b_s_d_hardware__0 = OpenBSDHardware(string__0)
    result = open_b_s_d_hardware__0.get_memory_facts()
    assert result['memtotal_mb'] == 3072
    assert result['memfree_mb'] == 0
    assert result['swaptotal_mb'] == 0
    assert result['swapfree_mb'] == 0


# Generated at 2022-06-24 22:24:01.087929
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    module = ansible.module_utils.basic.AnsibleModule(
    )
    openbsd_hardware = OpenBSDHardwareCollector(module)
    assert openbsd_hardware._fact_class == OpenBSDHardware

# Generated at 2022-06-24 22:24:04.862760
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '#8ugjKw{f#7_i#R*`WL'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:24:09.511696
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = ''
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:24:11.240305
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = 'a:e!^D{y&mp~+l(Xn %t'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()


# Generated at 2022-06-24 22:24:14.435232
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    str_0 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    open_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:26:20.008634
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    open_b_s_d_hardware_collector_0 = OpenBSDHardwareCollector()


# Generated at 2022-06-24 22:26:21.096775
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    open_b_s_d_hardware_3 = OpenBSDHardware()
    open_b_s_d_hardware_3.get_uptime_facts()


# Generated at 2022-06-24 22:26:23.908520
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:26:29.260068
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    open_b_s_d_hardware_0 = OpenBSDHardware('fake_module')
    str_0 = 'o'
    open_b_s_d_hardware_0.sysctl[str_0] = 'fake_ncpuonline'
    str_1 = 'R'
    open_b_s_d_hardware_0.sysctl[str_1] = 'fake_model'
    var_0 = open_b_s_d_hardware_0.get_processor_facts()
    assert var_0 == {'processor': ['fake_model'], 'processor_cores': 'fake_ncpuonline', 'processor_count': 'fake_ncpuonline'}


# Generated at 2022-06-24 22:26:36.836888
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()
    str_1 = 'processor_cores'
    assert var_0[str_1] == 4
    str_2 = 'processor_count'
    assert var_0[str_2] == 4
    str_3 = 'processor'
    assert var_0[str_3] == ['Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz']


# Generated at 2022-06-24 22:26:40.027596
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    str_0 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:26:43.850589
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    dict_0 = open_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:26:53.743196
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    str_0 = '2AG\rM9)qdWMqyo_-x5k'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    str_1 = 'y"Y}Qn\x0eo\x1a$'
    dict_0 = {'a': 'b', 'c': 'd'}
    dict_1 = {'a': 'b', 'c': 'd'}
    dict_2 = {'a': 'b', 'c': 'd'}
    str_2 = 'z}N\x04\x00\x0e\x1b'
    dict_3 = {'a': 'b', 'c': 'd'}
    dict_4 = {'a': 'b', 'c': 'd'}
    dict_

# Generated at 2022-06-24 22:26:55.528951
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert(len(OpenBSDHardwareCollector().get_all_hardware_collectors()) > 0)


# Generated at 2022-06-24 22:27:00.068930
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    str_0 = '#\xB9\'\xC6\xA6\xD2\xA2\xA1\xE3\x8E'
    open_b_s_d_hardware_0 = OpenBSDHardware(str_0)
    var_0 = open_b_s_d_hardware_0.get_processor_facts()
