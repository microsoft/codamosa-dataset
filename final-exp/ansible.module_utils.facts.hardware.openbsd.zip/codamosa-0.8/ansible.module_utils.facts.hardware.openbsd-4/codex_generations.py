

# Generated at 2022-06-11 02:53:56.217292
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    from ansible.module_utils.facts.utils import get_mount_size

    # Get free memory. vmstat output looks like:
    #  procs    memory       page                    disks    traps          cpu
    #  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id
    #  0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99

# Generated at 2022-06-11 02:53:58.724533
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    import mock
    import sys

    x = OpenBSDHardwareCollector(mock.Mock())
    assert x._fact_class == OpenBSDHardware
    assert x._platform == 'OpenBSD'

# Generated at 2022-06-11 02:54:02.948869
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    test = OpenBSDHardware({'ANSIBLE_MODULE_ARGS': {'gather_subset': ['all']}})
    test.sysctl = {'hw.disknames': 'fwd0,wd0'}
    assert test.get_device_facts() == {'devices': ['fwd0', 'wd0']}


# Generated at 2022-06-11 02:54:12.413360
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command

    uptime_facts = OpenBSDHardware(module).get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == 1484842
    assert uptime_facts['uptime_days'] == int(1484842 / (3600 * 24))
    assert uptime_facts['uptime_hours'] == int(1484842 / 3600 % 24)
    assert uptime_facts['uptime_minutes'] == int(1484842 / 60 % 60)



# Generated at 2022-06-11 02:54:21.971077
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    result = {
            'processor' : ['Intel(R) Xeon(R) CPU E5410 @ 2.33GHz'],
            'processor_count' : 1,
            'processor_cores' : 1
            }
    module = AnsibleModule(argument_spec={})
    HW = OpenBSDHardware(module)
    HW.sysctl = {
            'hw.ncpuonline' : '1',
            'hw.model' : 'Intel(R) Xeon(R) CPU E5410 @ 2.33GHz'
            }
    assert HW.get_processor_facts() == result


# Generated at 2022-06-11 02:54:25.936493
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = OpenBSDHardware(module=module)

    # The last line of vmstat output looks like this
    # 0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99
    # test_vmstat_out is produced based on that.
    test_vmstat_out = """ procs     memory     page                      disks     traps        cpu
r b w   avm fre flt re pi po fr sr wd0 fd0    int   sys   cs us sy id
0 0 0  47512  3792   51   0   0   0   0   0   1   0  116    89   17  0  1 99"""

# Generated at 2022-06-11 02:54:31.054152
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = MockModule()
    # The module.run_command() method will return these values in the tuple:
    #   returncode, stdout, stderr
    # Whenever module.run_command() is called

# Generated at 2022-06-11 02:54:41.801776
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    mock_module = type('module', (object,), {'run_command': test_memory_facts_run_command})
    mock_OpenBSDHardware = type('OpenBSDHardware', (object,), {'module': mock_module, 'sysctl': {'hw.usermem': 725405696}})
    OpenBSDHardware.module = mock_module

    openbsd_memory_facts = OpenBSDHardware.get_memory_facts(mock_OpenBSDHardware)
    assert openbsd_memory_facts['memfree_mb'] == 596
    assert openbsd_memory_facts['memtotal_mb'] == 696
    assert openbsd_memory_facts['swapfree_mb'] == 596
    assert openbsd_memory_facts['swaptotal_mb'] == 696


# Generated at 2022-06-11 02:54:53.910341
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    test_module = type('AnsibleModule', (object,), {})()
    test_module.get_bin_path = lambda x: x
    test_module.run_command = lambda x: (0, '', '')
    test_module.get_file_content = lambda x: ''
    OpenBSDHardware(test_module).populate()
    #
    #  Unit test for method get_memory_facts of class OpenBSDHardware
    #
    test_module = type('AnsibleModule', (object,), {})()
    test_module.get_file_content = lambda x: ' total: 889196 8K-blocks allocated, 534208 used, 354992 available, 0 swapped out'
    test_module.run_command = lambda x: (0, '', '')
    test_OpenBSDHardware = OpenBSD

# Generated at 2022-06-11 02:55:00.580706
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    hardware_test_object = OpenBSDHardware(None)
    hardware_test_object.sysctl = {'hw.disknames': 'sd0,sd1,sd2'}
    hardware_test_object.get_device_facts()
    assert hardware_test_object.facts['devices'] == ['sd0', 'sd1', 'sd2']


# Generated at 2022-06-11 02:55:10.206590
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    hw = OpenBSDHardwareCollector()

    assert type(hw) is OpenBSDHardwareCollector
    assert hw._fact_class == OpenBSDHardware
    assert hw._platform == 'OpenBSD'

# Generated at 2022-06-11 02:55:21.645860
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = type('', (), {})()
    module.run_command = lambda *cmd: (0, '2', '')
    module.get_bin_path = lambda *cmd: '/bin/%s' % cmd[0]
    module.params = {}
    hardware = OpenBSDHardware(module)
    hardware.sysctl = dict(hw={'model': 'Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz', 'ncpuonline': '4'})
    result = hardware.get_processor_facts()

# Generated at 2022-06-11 02:55:22.593165
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    collector = OpenBSDHardwareCollector()
    assert collector

# Generated at 2022-06-11 02:55:26.265240
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    hardware_facts = OpenBSDHardware({})
    processor_facts = hardware_facts.get_processor_facts()
    assert processor_facts['processor']
    assert processor_facts['processor_cores']
    assert processor_facts['processor_count']

# Generated at 2022-06-11 02:55:32.784693
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')

    # Init hardware object
    hardware = OpenBSDHardware(module)

    # Test get_memory_facts
    hardware.get_memory_facts()
    module.run_command.assert_called_with('/usr/bin/vmstat')



# Generated at 2022-06-11 02:55:38.594306
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = MagicMock()
    module.run_command.return_value = (0, b'12345', b'')
    hardware = OpenBSDHardware(module)

    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts == {
        'uptime_seconds': int(time.time() - 12345),
    }

    module.run_command.assert_called_once_with([
        '/usr/sbin/sysctl',
        '-n',
        'kern.boottime',
    ])

# Generated at 2022-06-11 02:55:41.484027
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memfree_mb'] > 0



# Generated at 2022-06-11 02:55:46.286401
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    processor_facts = {
        "processor": ["Intel(R)"],
        "processor_cores": "2",
        "processor_count": "2",
    }
    assert processor_facts == hardware.get_processor_facts()


# Generated at 2022-06-11 02:55:58.172052
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    hardware = OpenBSDHardware(dict())

    # This is the output of sysctl hw.model on a x86_64 OpenBSD machine.
    sysctl = dict()
    sysctl['hw.model'] = 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'
    sysctl['hw.ncpuonline'] = '4'
    hardware.sysctl = sysctl

    processor_facts = hardware.get_processor_facts()

    # We expect to the following facts:
    expected_processor_facts = dict()
    expected_processor_facts['processor_count'] = '4'
    expected_processor_facts['processor_cores'] = '4'

# Generated at 2022-06-11 02:56:08.751539
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    hardware = OpenBSDHardware()
    hardware.module = MockModule()
    hardware.module.run_command.return_value = (0, 'hw.ncpuonline: 2', '')

    hardware.module.run_command.side_effect = [(0, 'hw.model: Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz', ''),
                                               (0, 'hw.model: Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz', ''),
                                               (0, 'hw.ncpuonline: 2', '')]

    hardware.get_processor_facts()

    assert hardware.facts['processor'][0] == "Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz"
    assert hardware.facts['processor'][1]

# Generated at 2022-06-11 02:56:27.370063
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = DummyModule()
    setattr(module, 'run_command', dummy_run_command)
    hardware = OpenBSDHardware(module)
    facts = hardware.get_processor_facts()

    assert facts['processor'] == ['Dummy CPU']
    assert facts['processor_count'] == '1'
    assert facts['processor_cores'] == '1'



# Generated at 2022-06-11 02:56:29.011071
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    OpenBSDHardwareCollector()

# Generated at 2022-06-11 02:56:33.944186
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = OpenBSDHardware(module)

    # Check if sysctl(8) is available
    rc, out, err = module.run_command("/usr/sbin/sysctl -n kern.boottime")
    if rc != 0:
        # we can't run the test if sysctl(8) is not available
        return {'changed': False, 'msg': ''}

    # Check if the sysctl(8) output is a digit.
    if not out.strip().isdigit():
        return {'changed': False, 'msg': ''}

    # Check if the elapsed time between now and the sysctl(8) output is
    # positive
    uptime_seconds = int(time.time()) - int(out)

# Generated at 2022-06-11 02:56:45.366994
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = DummyAnsibleModule()
    module.run_command = Mock(return_value=(0, '0', ''))
    sysctl = {'hw.usermem': '2147483648',
              'hw.ncpuonline': '4',
              'hw.model': 'Intel(R) Core(TM) i5-7360U CPU @ 2.30GHz',
              'hw.disknames': 'sd0,sd1,cd0,cd1',
              'hw.product': 'Lenovo ThinkPad T480',
              'hw.version': 'ThinkPad T480',
              'hw.uuid': '12345678-1234-1234-1234-1234567890ab',
              'hw.serialno': 'PF0PX40',
              'hw.vendor': 'LENOVO'}


# Generated at 2022-06-11 02:56:56.118964
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    # We are mocking vmstat command output and the kern.usermem sysctl
    # The mocked outupt of vmstat command is the output of:
    # vmstat -s | awk '{ print int($1) }' | tail -n 1
    # The mocked output of sysctl kern.usermem command is 999 * 1024 * 1024
    memory_facts = OpenBSDHardware.get_memory_facts(None, {'vmstat': 0, 'sysctl': '999'})
    assert memory_facts['memtotal_mb'] == 999
    assert memory_facts['memfree_mb'] == 0


# Generated at 2022-06-11 02:57:02.941700
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    import sys
    # Save the original sys.modules so we can restore it at the end of this
    # function. This is needed to be able to import module_utils.basic
    orig_sys_modules = sys.modules.copy()
    # Mock the basic module
    class OpenBSDModule():
        def run_command(self, *_, **__):
            return 0, '1487708727', ''
    mock_module = OpenBSDModule()
    sys.modules['ansible.module_utils.basic'] = mock_module
    # Import the class OpenBSDHardware and instantiate it
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    openbsd_hardware = OpenBSDHardware()
    # OpenBSDHardware.get_uptime_facts should return:
    # {'uptime_seconds':

# Generated at 2022-06-11 02:57:08.462573
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = type('obj', (object,),{'run_command':run_command_memory_facts})
    obj = OpenBSDHardwareCollector(module)
    facts = obj.collect()
    assert facts['memory']['memfree_mb'] == 28160
    assert facts['memory']['memtotal_mb'] == 47512
    assert facts['memory']['swapfree_mb'] == 69268
    assert facts['memory']['swaptotal_mb'] == 69268



# Generated at 2022-06-11 02:57:11.008888
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    module = None
    hardwareCollector = OpenBSDHardwareCollector(module)
    assert hardwareCollector.__class__.__name__ == 'OpenBSDHardwareCollector'

# Generated at 2022-06-11 02:57:21.367302
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    sysctl = {
        'hw.product': 'OpenBSD 6.0-stable',
        'hw.version': 'OpenBSD.amd64',
        'hw.uuid': '26fb7cd6-e2d3-46ec-9d1e-c210f9c88bd7',
        'hw.serialno': '696F70656E626F637344323342495352305243323030',
        'hw.vendor': 'OpenBSD'
    }

    test_hw = OpenBSDHardware(None, sysctl)
    dmi_facts = test_hw.get_dmi_facts()


# Generated at 2022-06-11 02:57:23.909448
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert OpenBSDHardwareCollector._platform == "OpenBSD"
    assert OpenBSDHardwareCollector._fact_class == OpenBSDHardware


# Generated at 2022-06-11 02:58:05.239409
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = FakeModule()
    module.run_command.return_value = 0, \
        "hint: I am the output of hw.ncpuonline", ""
    module.get_bin_path.return_value = "sysctl"

    hardware = OpenBSDHardware(module)
    facts = hardware.get_processor_facts()

    assert facts['processor_count'] == 1
    assert facts['processor_cores'] == 1


# Unit test to check if get_memory_facts works on valid input

# Generated at 2022-06-11 02:58:16.210027
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    class UnitTestModule(object):
        def run_command(self, command):
            class UnitTestRunCommand(object):
                def __init__(self, stdout, stderr, rc):
                    self.stdout = stdout
                    self.stderr = stderr
                    self.rc = rc
                def __getitem__(self, name):
                    return getattr(self, name)
            if command == ['/usr/bin/vmstat']:
                return UnitTestRunCommand(out, '', 0)
            elif command == ['/sbin/swapctl', '-sk']:
                return UnitTestRunCommand(out, '', 0)
    class UnitTestGetSysctl(object):
        def __init__(self, sysctl):
            self.sysctl = sysctl

# Generated at 2022-06-11 02:58:23.152963
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = OpenBSDHardware(module)
    hardware.populate()

    assert hardware.memory['memtotal_mb'] == 64128
    assert hardware.memory['memfree_mb'] == 17458
    assert hardware.memory['swaptotal_mb'] == 2047
    assert hardware.memory['swapfree_mb'] == 2047
    assert hardware.processor['processor_cores'] == 1
    assert hardware.processor['processor_count'] == 1
    assert hardware.processor['processor'] == ['Intel(R) Atom(TM) CPU  E3845  @ 1.91GHz']
    assert hardware.devices['devices'] == ['dk0', 'dk1', 'dk2', 'dk3', 'dk4']
    assert hardware.dmi['system_vendor'] == 'PCEngines'

# Generated at 2022-06-11 02:58:29.380481
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    h = OpenBSDHardware()
    # Note: this is the kern.boottime value from a OpenBSD 6.3 host.
    #       Use it to test the method in a way that is independent from
    #       the host generating the facts.
    h.sysctl['kern.boottime'] = 1535688700
    out = h.get_uptime_facts()
    print(out)


# Generated at 2022-06-11 02:58:32.864610
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    test_processor_facts = {
                            'processor': ['Intel(R) Core(TM) i5-5200U CPU @ 2.20GHz'],
                            'processor_cores': 1,
                            'processor_count': 1
                           }
    hardware = OpenBS

# Generated at 2022-06-11 02:58:43.823756
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = type('', (), {
        'run_command': lambda *_, **__: (0, '', ''),
        'get_bin_path': lambda _: ''
    })

# Generated at 2022-06-11 02:58:46.587129
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware_collector = OpenBSDHardwareCollector()
    assert openbsd_hardware_collector._fact_class == OpenBSDHardware
    assert openbsd_hardware_collector._platform == 'OpenBSD'

# Generated at 2022-06-11 02:58:56.660596
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():

    obj = OpenBSDHardware({'hw.usermem': '268435456'})
    obj.sysctl = {'hw.usermem': '268435456'}
    obj.module.run_command = lambda x: (0, "procs    memory       page                    disks    traps          cpu\n"
                                            "r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n"
                                            "0 0 0  47512   28160   51   0   0   0   0   0   1   0  116    89   17  0  1 99\n",
                                            None)
    memory_facts = obj.get_memory_facts()
    assert isinstance(memory_facts, dict)
    assert memory_facts

# Generated at 2022-06-11 02:59:07.450589
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    hardware = OpenBSDHardware({'run_command': module_function_stub})
    hardware.module.run_command.side_effect = [
        (0, 'test_hw.model', ''),
        (0, 'test_hw.ncpuonline', '')
    ]
    hardware.get_processor_facts()

    assert hardware.module.run_command.call_count == 2
    first_call_args, first_call_kwargs = hardware.module.run_command.call_args_list[0]
    first_call_executed_command = first_call_args[0]
    assert first_call_executed_command == ['/sbin/sysctl', '-n', 'hw.model']
    second_call_args, second_call_kwargs = hardware.module.run_command.call_args_

# Generated at 2022-06-11 02:59:11.553976
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    mdl = OpenBSDHardware(module=None)
    mdl.sysctl = {
        'hw.product': 'HP EliteDesk 800 G2 TWR',
        'hw.uuid': '7AA0C2A2-731B-11E6-B08B-000000000000',
        'hw.vendor': 'HP',
        'hw.serialno': 'CZC7130F12'
    }
    dmi_facts = mdl.get_dmi_facts()
    assert dmi_facts['product_name'] == 'HP EliteDesk 800 G2 TWR'
    assert dmi_facts['product_uuid'] == '7AA0C2A2-731B-11E6-B08B-000000000000'
    assert dmi_facts['system_vendor'] == 'HP'

# Generated at 2022-06-11 03:00:39.551985
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    mem_facts = {'memfree_mb': '28160',
                 'memtotal_mb': '47512',
                 'swapfree_mb': '69268',
                 'swaptotal_mb': '69268'}
    hardware = OpenBSDHardware({'run_command': fake_run_command})
    assert hardware.get_memory_facts() == mem_facts



# Generated at 2022-06-11 03:00:46.809371
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    from _sha import sha1
    from json import load
    from os.path import dirname, join
    from sys import modules

    file = join(dirname(modules[__name__].__file__), 'test_OpenBSDHardware.json')
    with open(file) as f:
        data = load(f)

    # Initialize the test class
    hw = OpenBSDHardware()
    hw.module = None
    hw.sysctl = data['input']['sysctl']

    # Populate the class
    facts = hw.populate()

    # Make sure the populated class is equal to the output of the unit test
    assert sha1(str(facts).encode()).hexdigest() == data['output']['_sha1']

# Generated at 2022-06-11 03:00:50.862248
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    # if platform is OpenBSD, then return an instance of class OpenBSDHardwareCollector
    hwc = OpenBSDHardwareCollector()
    assert hwc.platform == 'OpenBSD'
    assert hwc._fact_class == OpenBSDHardware


# Generated at 2022-06-11 03:00:58.519137
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = OpenBSDHardware()
    module.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i7-3517U CPU @ 1.90GHz'}
    expected = {'processor_count': '2', 'processor': ['Intel(R) Core(TM) i7-3517U CPU @ 1.90GHz','Intel(R) Core(TM) i7-3517U CPU @ 1.90GHz'], 'processor_cores': '2'}
    result = module.get_processor_facts()
    assert result == expected

# Generated at 2022-06-11 03:01:02.258378
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = get_mocked_module()
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {
        'hw.disknames': 'wd0'
    }
    assert hardware.get_device_facts() == {
        'devices': [
            'wd0'
        ]
    }


# Generated at 2022-06-11 03:01:04.741991
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    hardware = OpenBSDHardware(dict())
    result = hardware.get_uptime_facts()
    assert result == {
        'uptime_seconds': int(time.time() - int(time.time())),
    }

# Generated at 2022-06-11 03:01:12.443342
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    import time
    import mock

    kern_boottime = int(time.time())

    module = mock.MagicMock()
    module.run_command.return_value = (0, "{}".format(kern_boottime), '')

    h = OpenBSDHardware(module)
    module.get_bin_path.side_effect = lambda x: "/bin/{}".format(x)

    assert h.get_uptime_facts() == {
        'uptime_seconds': int(time.time() - kern_boottime)
    }

# Generated at 2022-06-11 03:01:14.741267
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    openbsd_hardware = OpenBSDHardwareCollector.load_collector()
    assert openbsd_hardware._fact_class == OpenBSDHardware

# Generated at 2022-06-11 03:01:25.039989
# Unit test for method get_uptime_facts of class OpenBSDHardware

# Generated at 2022-06-11 03:01:28.060752
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    assert OpenBSDHardwareCollector._platform == 'OpenBSD'
    assert OpenBSDHardwareCollector._fact_class == OpenBSDHardware

# Generated at 2022-06-11 03:03:18.091464
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    test_OpenBSDHardware_data = {'hw.product': 'VMware Virtual Platform',
                                 'hw.version': 'None',
                                 'hw.uuid': 'None',
                                 'hw.serialno': 'VMware-42 23 62 77 40 aa 1d b7-02 89 3c 8e 67 1e 5d aa',
                                 'hw.vendor': 'VMware, Inc.'}
    hardware = OpenBSDHardware(dict(), dict())
    hardware.sysctl = test_OpenBSDHardware_data
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'VMware Virtual Platform'
    assert dmi_facts['product_uuid'] == 'None'
   

# Generated at 2022-06-11 03:03:22.241556
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    from ansible.module_utils.facts import collector
    collector.collector.collect(['hardware'])
    hardware_facts = collector.collector.get_facts(['hardware'])['ansible_hardware']
    facts = OpenBSDHardware().populate()
    assert facts == hardware_facts

# Generated at 2022-06-11 03:03:26.594694
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = type('', (), {'run_command': lambda *args, **kwargs: (0, 'a b c d e\n', '')})()
    hardware = OpenBSDHardware(module, 'OpenBSD', [])
    hardware.sysctl = {}
    hardware.sysctl['hw.usermem'] = 3
    hardware.get_memory_facts()
    assert hardware.facts['memfree_mb'] == 4
    assert hardware.facts['memtotal_mb'] == 4


# Generated at 2022-06-11 03:03:29.291211
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    from ansible.module_utils.facts.hardware import OpenBSDHardwareCollector
    hw = OpenBSDHardwareCollector()
    assert isinstance(hw, OpenBSDHardwareCollector)


# Generated at 2022-06-11 03:03:32.925492
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = MockOpenBSDModule()
    facts = OpenBSDHardware(module=module).get_memory_facts()
    assert "memfree_mb" in facts
    assert "memtotal_mb" in facts
    assert "swapfree_mb" in facts
    assert "swaptotal_mb" in facts


# Generated at 2022-06-11 03:03:36.176340
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    module = 'the module'
    hw_collector = OpenBSDHardwareCollector(module)
    assert hw_collector._fact_class == OpenBSDHardware
    assert hw_collector._platform == 'OpenBSD'