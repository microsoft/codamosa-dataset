

# Generated at 2022-06-11 02:53:56.217150
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    # See module_utils/facts/hardware/test_memory_posix.c for some
    # example outputs from other operating systems.
    #
    # This is the real output of 'vmstat -m' on an OpenBSD 6.3-current
    # system, but then stripped down and tailored for the purposes of
    # this test.

# Generated at 2022-06-11 02:54:04.883558
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

    # Save a copy of the module, so we can restore it later
    orig_module = module
    HardwareCollector.set_module(module)
    HardwareCollector.set_up_subclass('OpenBSD')

    # Populate the HardwareCollector with an OpenBSDHardware object
    hardware_collector = HardwareCollector()
    hardware_collector.populate()

    # For each attribute in the OpenBSDHardware class, save it in the facts cache
    for attr_name in dir(hardware_collector.facts):
        if attr_name.startswith('_'):
            # Ignore private attributes
            continue

# Generated at 2022-06-11 02:54:15.819628
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    """
    hw.disknames value returned by sysctl is comma seperated values
    Example : 'wd0,sd0,cd0a'
    get_device_facts() should convert it to list.
    """

    openbsd_hardware = OpenBSDHardware({'module_setup': True, 'ansible_facts': {}})

    # setting value of hw.disknames to its example value
    openbsd_hardware.sysctl = {'hw.disknames': 'wd0,sd0,cd0a'}

    assert openbsd_hardware.get_device_facts() == {'devices': ['wd0', 'sd0', 'cd0a']}

# Generated at 2022-06-11 02:54:18.569292
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    result = OpenBSDHardwareCollector()
    assert result._platform == 'OpenBSD'
    assert result._fact_class == OpenBSDHardware

# Generated at 2022-06-11 02:54:28.820783
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    hardware_facts = OpenBSDHardware(dict())
    hardware_facts.sysctl = {'hw.model': 'Intel(R) Core(TM) i7-7600U CPU @ 2.80GHz',
                             'hw.ncpu': '2',
                             'hw.ncpuonline': '2'}
    facts = hardware_facts.get_processor_facts()
    assert facts['processor_count'] == '2'
    assert facts['processor_cores'] == '2'
    assert facts['processor'][0] == 'Intel(R) Core(TM) i7-7600U CPU @ 2.80GHz'

# Generated at 2022-06-11 02:54:32.424677
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    module = MagicMock()
    module.run_command.return_value = (0, '417345', '')
    module.get_bin_path.return_value = '/sbin/sysctl'
    OpenBSDHardware.module = module
    expected = {
        'uptime_seconds': int(time.time() - 417345),
    }

    assert OpenBSDHardware.get_uptime_facts() == expected


# Generated at 2022-06-11 02:54:42.530126
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    '''
    ansible.module_utils.facts.hardware.openbsd.OpenBSDHardware.populate
    '''
    import mock
    import os
    import sys

    class Mock(mock.MagicMock):
        '''
        ansible.module_utils.facts.hardware.openbsd.OpenBSDHardware.populate
        '''
        @classmethod
        def run_command(self, command):
            '''
            ansible.module_utils.facts.hardware.openbsd.OpenBSDHardware.run_command
            '''

# Generated at 2022-06-11 02:54:47.880915
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = FakeAnsibleModule()
    hardware = OpenBSDHardware(module)
    disks = ["sd0", "sd1", "wd0", "wd1"]
    hardware.sysctl = dict(hw=dict(disknames=",".join(disks)))
    facts = hardware.get_device_facts()

    assert facts['devices'] == disks

# Generated at 2022-06-11 02:54:59.589751
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    a = OpenBSDHardware()
    a.sysctl = {
        'hw.product': 'OpenBSD Virtual Machine',
        'hw.version': '6.1',
        'hw.uuid': 'ec9e40c4-a0f7-11e8-97f7-001b2163f3a4',
        'hw.serialno': '4.4.4',
        'hw.vendor': 'Sector_iO',
    }

    result = a.get_dmi_facts()
    assert(result['product_name'] == 'OpenBSD Virtual Machine')
    assert(result['product_version'] == '6.1')
    assert(result['product_uuid'] == 'ec9e40c4-a0f7-11e8-97f7-001b2163f3a4')

# Generated at 2022-06-11 02:55:01.164718
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    x = OpenBSDHardwareCollector()
    assert x.platform == 'OpenBSD'

# Generated at 2022-06-11 02:55:18.396875
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    import ansible.module_utils.facts.hardware.openbsd
    hardware_collector = ansible.module_utils.facts.hardware.openbsd.OpenBSDHardwareCollector()

    assert hardware_collector._platform == 'OpenBSD'
    assert hardware_collector._fact_class == ansible.module_utils.facts.hardware.openbsd.OpenBSDHardware



# Generated at 2022-06-11 02:55:24.019411
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    # Module params
    module = AnsibleFakeModule(CHECKMODE=False)
    # Prepare test data
    hardware = OpenBSDHardware(module=module)
    hardware.sysctl = {'hw.ncpuonline': 1, 'hw.model': 'Intel(R) Core(TM) i5-3320M CPU @ 2.60GHz'}
    # Run test
    result = hardware.get_processor_facts()
    # Assertion
    assert('processor' in result)
    assert('processor_count' in result)
    assert('processor_cores' in result)
    assert(result['processor_count'] == 1)
    assert(result['processor_cores'] == 1)
    assert(len(result['processor']) == 1)

# Generated at 2022-06-11 02:55:34.495928
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'procs     memory     page          disks   traps      cpu\nr b w avm fre flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id\n0 0 0 47612 28172   51   0   0   0   0   0   1   0  114    90   17  0  1 99\n', ''))
    # vmstat output from OpenBSD 5.8
    openbsd_hardware = OpenBSDHardware(module)
    memory_facts = openbsd_hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 27
    assert memory_facts['memtotal_mb'] == 512

# Generated at 2022-06-11 02:55:41.186111
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    test_module = 'ansible.module_utils.facts.hardware.openbsd.OpenBSDHardware'
    test_class = 'OpenBSDHardware'
    test_obj = 'hardware_obj'
    test_args = {}

# Generated at 2022-06-11 02:55:43.283580
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    facts = OpenBSDHardwareCollector()
    assert isinstance(facts, OpenBSDHardwareCollector)
    assert isinstance(facts.collect(), OpenBSDHardware)

# Generated at 2022-06-11 02:55:45.792723
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    """This is to test OpenBSDHardwareCollector class,
    it will raise a exception if the class is not exist"""
    OpenBSDHardwareCollector()

# Generated at 2022-06-11 02:55:57.672480
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    mem_read = "r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys  cs us sy id"
    mem_result = "0 0 0  49860   28160   51   0   0   0   0   0   1   0  116    89  17  0  1 99"
    fake_module = type('', (), {})()
    fake_module.run_command = lambda x, y: (0, mem_result, '')
    fake_module.params = {}
    hw = OpenBSDHardware(fake_module)
    assert hw.get_memory_facts() == { 'memfree_mb': 28, 'memtotal_mb': 49 }


# Generated at 2022-06-11 02:56:04.961955
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    module = FakeModule()
    openbsd_hw = OpenBSDHardware(module)
    openbsd_hw.sysctl = {'hw.disknames': 'sd0,sd1,sd2,sd3,sd4,sd5,sd6,sd7,sd8,sd9,cd0,cd1,wd0,wd1',
                         'hw.ncpuonline': 2,
                         'hw.usermem': '12884901888'}

    expected_devices = ['sd0', 'sd1', 'sd2', 'sd3', 'sd4', 'sd5', 'sd6', 'sd7',
                        'sd8', 'sd9', 'cd0', 'cd1', 'wd0', 'wd1']

    devices = openbsd_hw.get_device_facts()['devices']


# Generated at 2022-06-11 02:56:15.380520
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = FakeAnsibleModule()
    hardware_obj = OpenBSDHardware(module)
    hardware_obj.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i5-6300U CPU @ 2.40GHz'}
    cpu_facts = hardware_obj.get_processor_facts()
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-6300U CPU @ 2.40GHz', 'Intel(R) Core(TM) i5-6300U CPU @ 2.40GHz']
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '2'



# Generated at 2022-06-11 02:56:17.220168
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    har_obj = OpenBSDHardwareCollector()
    assert har_obj.platform == 'OpenBSD'


# Generated at 2022-06-11 02:57:00.445343
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = DummyAnsibleModule()
    dmi_facts = {
        'system_vendor': 'OpenBSD',
        'product_name': 'VirtualBox',
        'product_version': '1.0',
        'product_serial': 'None',
        'product_uuid': 'None',
    }

# Generated at 2022-06-11 02:57:04.882930
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():

    fake_module = FakeModule()
    fake_module.run_command = Mock(return_value=(0, "", ""))

    openbsd_hardware = OpenBSDHardware(fake_module)
    # mock sysctl
    openbsd_hardware.module = fake_module
    openbsd_hardware.sysctl = {'hw.ncpuonline': '2', 'hw.model': 'Intel(R) Core(TM) i3-2100 CPU @ 3.10GHz'}

    # get facts
    openbsd_hardware.get_processor_facts()

    # test the result

# Generated at 2022-06-11 02:57:10.147895
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    #Test the hardware collector is correctly initialized
    hardware_collector = OpenBSDHardwareCollector('ansible.module_utils.facts.hardware.openbsd', {})
    assert hardware_collector.platform == 'OpenBSD'
    assert hardware_collector.fact_class == 'ansible.module_utils.facts.hardware.openbsd.OpenBSDHardware'
    assert hardware_collector._facts == {}
    assert hardware_collector._warnings == []
    assert hardware_collector.module is None


# Generated at 2022-06-11 02:57:20.064055
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    hardware = OpenBSDHardware(module)
    facts = hardware.populate()
    assert 'devices' in facts
    assert 'swaptotal_mb' in facts
    assert 'dmi_facts' in facts
    assert 'processor_count' in facts
    assert 'uptime_seconds' in facts
    assert 'swapfree_mb' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'processor_cores' in facts
    assert 'processor_speed' not in facts
    assert 'processor' in facts
    assert 'mounts' in facts
    assert 'processor_count' in facts

# Generated at 2022-06-11 02:57:27.917081
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    hw = OpenBSDHardware({
        'hw.ncpuonline': '2',
        'hw.model': 'Intel(R) Xeon(R) CPU E5-1650 v3 @ 3.50GHz'
    })
    facts = hw.get_processor_facts()
    assert facts['processor'] == ['Intel(R) Xeon(R) CPU E5-1650 v3 @ 3.50GHz',
                                  'Intel(R) Xeon(R) CPU E5-1650 v3 @ 3.50GHz']
    assert facts['processor_count'] == 2
    assert facts['processor_cores'] == 2


# Generated at 2022-06-11 02:57:36.432310
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    dmi_facts = {}

    class fake_sysctl(object):
        def __init__(self):
            self.dmi_facts = dmi_facts
            self._sysctl = {'hw.product': 'test_product',
                            'hw.version': 'test_version',
                            'hw.uuid': 'test_uuid',
                            'hw.serialno': 'test_serialno',
                            'hw.vendor': 'test_vendor'}

        def __getitem__(self, key):
            return self._sysctl[key]

    class dummy_module(object):
        def __init__(self):
            self.params = {'gather_subset': [], 'filter': '*'}
            self.fail_json = {'msg': 'fail'}


# Generated at 2022-06-11 02:57:46.336902
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    sysctl_run_command_results = [
        (0, '1449444444'),
        (1, 'no such file or directory error'),
    ]

    module_inst = type('module', (object,), {})()
    module_inst.run_command = lambda cmd: sysctl_run_command_results.pop()
    module_inst.get_bin_path = lambda cmd: cmd

    sysctl_results = {
        'hw.ncpuonline': 1,
        'hw.model': 'Intel(R) Core(TM) i7-3615QM CPU @ 2.30GHz',
        'hw.usermem': 4294967296,  # 4 GB
        'hw.ncpu': 2,  # 2 cores
        'hw.disknames': 'sd0,sd1',
    }


# Generated at 2022-06-11 02:57:55.921154
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module=module)
    hardware.sysctl = {'hw.ncpuonline': '3',
                       'hw.model': 'Intel(R) Pentium(R) 4 CPU 2.80GHz'}
    res = hardware.get_processor_facts()
    assert res['processor'] == ['Intel(R) Pentium(R) 4 CPU 2.80GHz', 'Intel(R) Pentium(R) 4 CPU 2.80GHz', 'Intel(R) Pentium(R) 4 CPU 2.80GHz']
    assert res['processor_count'] == '3'
    assert res['processor_cores'] == '3'



# Generated at 2022-06-11 02:58:07.620312
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = Mock()
    module.run_command.return_value = (0, vmstat_out, None)
    fact = OpenBSDHardware(module)

    module.run_command.assert_called_with("/usr/bin/vmstat")

    assert fact.memory['memtotal_mb'] == int(sysctl_hw_usermem) // 1024 // 1024
    assert fact.memory['memfree_mb'] == int(vmstat_out.splitlines()[-1].split()[4]) // 1024

    module.run_command.return_value = (0, swapctl_out, None)


# Generated at 2022-06-11 02:58:14.490879
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)
    hardware.sysctl = {'hw.usermem': '4294967296', 'hw.ncpuonline': '1'}
    facts = hardware.get_memory_facts()
    assert facts['memfree_mb'] == 4096
    assert facts['memtotal_mb'] == 4096
    assert facts['swapfree_mb'] == 0
    assert facts['swaptotal_mb'] == 0


# Generated at 2022-06-11 02:59:02.685846
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd, check_rc=True):
            return (0, '', '')

        def get_bin_path(self, path):
            return path

    class MockSysctl(object):
        def __init__(self, data):
            self.data = data

        def __getitem__(self, key):
            return self.data[key]

    # The OpenBSD Hardware get_dmi_facts method is called with a sysctl
    # object that may or may not have a hw.product entry
    mock_module = MockModule({})

# Generated at 2022-06-11 02:59:12.752801
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = OpenBSDHardware(module)

    fake_out = """  procs    memory       page                    disks    traps          cpu
  r b w    avm     fre  flt  re  pi  po  fr  sr wd0 fd0  int   sys   cs us sy id
  0 0 0  54672   14504   51   0   0   0   0   0   1   0  116   155   17  0  1 99"""


# Generated at 2022-06-11 02:59:15.618827
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    module = None
    m = OpenBSDHardware(module=module)
    m.sysctl = {'hw.usermem': '100 MB'}
    m.get_memory_facts()
    assert m.memfree == m.memtotal

# Generated at 2022-06-11 02:59:19.815075
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    import sys
    import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware as OpenBSDHardwareMock
    from ansible.module_utils.facts import timeout

    class AnsibleModuleMock(object):

        @staticmethod
        def run_command(*args, **kwargs):
            return (0, to_bytes('{0}'.format(1300777839)), '')

        class time(object):
            time = 1300777839

    old_module = sys.modules['ansible.module_utils.facts.hardware.openbsd']

    timeout_timeout = timeout.timeout
    timeout.timeout = lambda *args, **kwargs: lambda f: f


# Generated at 2022-06-11 02:59:28.575108
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # set up OpenBSDHardware object with setting the sysctl method to
    # a mock
    class OpenBSDHardware_test(OpenBSDHardware):
        sysctl = {}
        sysctl['kern.boottime'] = '1510263670'

    # initialize the object
    testobj = OpenBSDHardware_test(None)

    # get the uptime_seconds from OpenBSDHardware.get_uptime_facts()
    uptime = testobj.get_uptime_facts()

    assert uptime['uptime_seconds'] == int(time.time() - 1510263670)

# Generated at 2022-06-11 02:59:30.760343
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    l = OpenBSDHardwareCollector()
    assert l._platform == "OpenBSD"


# Generated at 2022-06-11 02:59:38.721665
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    test_OpenBSDHardware = OpenBSDHardware({'module_setup': True})
    test_OpenBSDHardware_set_sysctl = {'hw.ncpuonline': '4', 'hw.model': 'Intel(R)'}
    test_OpenBSDHardware.sysctl = test_OpenBSDHardware_set_sysctl
    test_OpenBSDHardware_facts = test_OpenBSDHardware.get_processor_facts()
    assert test_OpenBSDHardware_facts['processor_count'] == 4
    assert test_OpenBSDHardware_facts['processor_cores'] == 4
    assert test_OpenBSDHardware_facts['processor'][0] == 'Intel(R)'
    assert test_OpenBSDHardware_facts['processor'][1] == 'Intel(R)'
    assert test_OpenBSDHardware_facts['processor'][2] == 'Intel(R)'
   

# Generated at 2022-06-11 02:59:50.270819
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = AnsibleModuleMock(dict(
        command_timeout=5,
    ))
    facts = OpenBSDHardware(module).populate()

    assert 'uptime_seconds' in facts
    assert isinstance(facts['uptime_seconds'], (int, long))
    assert 'mounts' in facts
    assert isinstance(facts['mounts'], list)
    assert 'memfree_mb' in facts
    assert isinstance(facts['memfree_mb'], (int, long))
    assert 'memtotal_mb' in facts
    assert isinstance(facts['memtotal_mb'], (int, long))
    assert 'swapfree_mb' in facts
    assert isinstance(facts['swapfree_mb'], (int, long))
    assert 'swaptotal_mb' in facts

# Generated at 2022-06-11 03:00:01.051991
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    """Unit test for method populate of class OpenBSDHardware
    """
    from ansible.module_utils.facts import collector

    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['all'], type='list'),
        'gather_timeout': dict(default=10, type='int'),
    })

    # Initialize the collector to get facts
    collector.collect(module=module)

    # Create the object OpenBSDHardware
    o_hardware = OpenBSDHardware(module=module)
    # Call the method populate
    o_hardware.populate()

    results = o_hardware.get_facts()
    # Comparing the results
    assert isinstance(results, dict)
    assert results['devices'] == ['wd0']
    assert results['processor_cores'] == '1'

# Generated at 2022-06-11 03:00:12.346460
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    ncprocs = 2
    ncproconline = 1
    module = object()
    sysctl = {'hw.model': 'openbsd',
              'hw.ncpu': ncprocs,
              'hw.ncpuonline': ncproconline}
    fake_OpenBSDHardware = OpenBSDHardware(module, sysctl)
    facts = fake_OpenBSDHardware.get_processor_facts()
    # test facts['processor'] list
    assert len(facts['processor']) == int(ncproconline)
    for i in range(len(facts['processor'])):
        assert facts['processor'][i] == sysctl['hw.model']
    # verify that processor count is correct
    assert facts['processor_count'] == sysctl['hw.ncpu']
    # verify that processor cores is correct
    assert facts

# Generated at 2022-06-11 03:01:50.489771
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    module = type('', (), {'run_command': lambda *args, **kwargs: (0, "", ""), 'get_bin_path': lambda *args, **kwargs: None})()
    hardware = OpenBSDHardware(module)

    hardware.populate()

    assert hardware.facts['uptime_seconds'] > 0
    assert hardware.facts['swaptotal_mb'] > 0
    assert hardware.facts['swapfree_mb'] > 0
    assert hardware.facts['memtotal_mb'] > 0
    assert hardware.facts['memfree_mb'] > 0
    assert 'hw.disknames' in hardware.sysctl
    assert hardware.facts['devices'] == hardware.sysctl['hw.disknames'].split(',')
    assert hardware.facts['processor'][0] == hardware.sysctl['hw.model']

# Generated at 2022-06-11 03:01:57.483527
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    # get_uptime_facts must be able to parse sysctl output.
    # We expect it to return a dict with a key 'uptime_seconds' and a numeric
    # value.
    module = FakeAnsibleModule()
    module.run_command = Mock(return_value=(0, "42", ""))
    hardware = OpenBSDHardware(module)
    uptime = hardware.get_uptime_facts()
    assert uptime['uptime_seconds'] == int(time.time() - 42)


# Mock AnsibleModule class

# Generated at 2022-06-11 03:01:58.880915
# Unit test for constructor of class OpenBSDHardwareCollector
def test_OpenBSDHardwareCollector():
    obj = OpenBSDHardwareCollector()
    assert obj.platform == 'OpenBSD'

# Generated at 2022-06-11 03:02:03.995968
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    import mock

    module = mock.MagicMock()
    module.run_command.return_value = (0, '1501738680', '')

    oh = OpenBSDHardware(module)
    uptime_facts = oh.get_uptime_facts()

    assert 'uptime_seconds' in uptime_facts
    assert int(time.time()) - uptime_facts['uptime_seconds'] == 1501738680

# Generated at 2022-06-11 03:02:13.422184
# Unit test for method populate of class OpenBSDHardware
def test_OpenBSDHardware_populate():
    '''
        This method unit tests the populate method of class OpenBSDHardware
    '''
    hardware_obj = OpenBSDHardware(dict())
    hardware_obj.module.run_command = lambda x: (0, 'i386', '')
    hardware_obj.module.get_bin_path = lambda x: '/path/to/bin/' + x
    hardware_obj.module.get_file_content = lambda x: None
    hardware_obj.sysctl = {'hw.usermem': '4265470904',
                           'hw.disknames': 'sd0',
                           'hw.model': 'AMD Athlon(tm)',
                           'hw.ncpuonline': '1'}
    populate_return_value = hardware_obj.populate()

# Generated at 2022-06-11 03:02:23.391357
# Unit test for method get_device_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_device_facts():
    for line in 'hw.disknames = sd0,sd1,cd0,cd1,wd0,wd1,wd2,wd3,wd4,wd5,wpi0,mpt0,mpt1,mpt2'.splitlines():
        mock_run_command_output_lines.append(line)
    mock_run_command_output_rcs.append(0)
    openbsd_hardware = OpenBSDHardware()
    openbsd_hardware.module = type(str("AnsibleModule"), (object,), {"run_command": mock_run_command})

# Generated at 2022-06-11 03:02:28.324241
# Unit test for method get_memory_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_memory_facts():
    OpenBSD = OpenBSDHardware()
    OpenBSD.module = MockModule()
    OpenBSD.populate()
    data = OpenBSD.get_memory_facts()
    assert data['memfree_mb'] == 28160
    assert data['memtotal_mb'] == 47512
    assert data['swapfree_mb'] == 69268
    assert data['swaptotal_mb'] == 69268



# Generated at 2022-06-11 03:02:39.257679
# Unit test for method get_uptime_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts import hardware
    from datetime import timedelta

    # Below is a fake kern.boottime sysctl output which needs to be converted
    # to an uptime_seconds fact.
    out = [b'1557237726   sec    =    Fri May 31 07:02:06 2019',
    b'the time and date the system was last booted']

    hardware_facts = hardware.OpenBSDHardware()
    hardware_facts.module.run_command = lambda x: (0, out[0], '')
    hardware_facts.sysctl = {}

    # The 1557237726 number should be converted to an uptime_seconds fact.
    uptime_facts = hardware_facts.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts

# Generated at 2022-06-11 03:02:48.453111
# Unit test for method get_processor_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_processor_facts():
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    from ansible.module_utils.facts.fake import FakeModule
    m = FakeModule(
        setup_cache_from_facts={
            'platform': 'OpenBSD'
        },
        sysctl={'hw.ncpuonline': 4,
                'hw.model': 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz'},
        module_name='test',
    )
    hardware = OpenBSDHardware(m)


# Generated at 2022-06-11 03:02:58.222399
# Unit test for method get_dmi_facts of class OpenBSDHardware
def test_OpenBSDHardware_get_dmi_facts():
    def mock_run_command(cmd):
        # Mocked run_command result of sysctl(8) command.
        return (0,
                """hw.product=OpenBSD
hw.version=6.7-amd64
hw.uuid=73a17f83-6fe9-11e4-b4ef-001a4a1923f1
hw.serialno=random test
hw.vendor=amd64
""",
                '')

    def mock_get_bin_path(path):
        return '/bin/%s' % path

    import sys

    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware
    from ansible.module_utils import basic

    # use a fake module to test code that can run only if executed in-process