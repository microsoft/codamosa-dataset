

# Generated at 2022-06-24 01:08:09.096618
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCC("My DCC", {}, {}, lambda s, a, e, f: Decimal(1))
    DCCRegistry.register(dcc)
    assert DCCRegistry.find("my dcc") is dcc
    DCCRegistry.register(dcc)


# Generated at 2022-06-24 01:08:19.032463
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    print("\n*** Testing dcfc_30_360_us ***")

    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof = datetime.date(2008, 2, 29), datetime.date(2008, 3, 1)


# Generated at 2022-06-24 01:08:21.793765
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCCRegistry.get_by_name('act/360').interest(Money('100'), 1/100, Date(2018,1,1), Date(2018,1,31))==Money('10.00')



# Generated at 2022-06-24 01:08:32.983046
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-24 01:08:39.018419
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(
        datetime.date(2018, 12, 31), datetime.date(2019, 12, 31), datetime.date(2019, 12, 31)
    ), 14) == Decimal(1)
    assert round(dcfc_act_365_l(
        datetime.date(2019, 1, 1), datetime.date(2020, 1, 1), datetime.date(2020, 1, 1)
    ), 14) == Decimal(1)
    assert round(dcfc_act_365_l(
        datetime.date(2020, 1, 1), datetime.date(2021, 1, 1), datetime.date(2021, 1, 1)
    ), 14) == Decimal('0.99726377952756')

# Generated at 2022-06-24 01:08:44.372268
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc_act_360 = DCC(name="act_360", altnames=set(), currencies=set(), calculate_fraction_method=dcc_act_360_30_360.calculate_fraction)
    start = Date(1,1,2020)
    asof = Date(1,2,2020)
    end = Date(1,3,2020)
    freq = None
    assert dcc_act_360.calculate_daily_fraction(start, asof, end) == ZERO

    asof = Date(3,2,2020)
    assert dcc_act_360.calculate_daily_fraction(start, asof, end) == Decimal("0.008333333333333333")
    
    asof = Date(2,2,2020)

# Generated at 2022-06-24 01:08:56.383226
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == Decimal('0.16986301369863')
    assert dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) == Decimal('0.17213114754098')
    assert dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)) == Decimal('1.08196721311475')
   

# Generated at 2022-06-24 01:08:59.116291
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    DCCRegistry = DCCRegistryMachinery()
    assert DCCRegistry.table == {}
    assert DCCRegistry._find_strict('AAA') == None
    assert DCCRegistry.find('AAA') == None
    assert DCCRegistry._is_registered('AAA') == False
    assert DCCRegistry._is_registered('AAA') == False
    assert DCCRegistry.registry == []


# Generated at 2022-06-24 01:09:04.335796
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_360(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:09:15.102654
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    test_principal = Money(1000, 'USD')
    test_rate = Decimal(24.5) / 100
    test_start = Date(2018, 12, 12)
    test_asof = Date(2020, 8, 8)
    test_end = Date(2021, 8, 8)
    test_freq = Decimal(1)
    test_eom = None

    principal = Money(1000, 'USD')
    rate = Decimal(24.5) / 100
    start = Date(2018, 12, 12)
    asof = Date(2020, 8, 8)
    end = Date(2021, 8, 8)
    freq = Decimal(1)
    eom = None


# Generated at 2022-06-24 01:09:23.244279
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    DCCRegistry.register(DCC("ACT/365", set(), _as_ccys({"EUR", "GBP", "USD"}), calculate_fraction_act_365))
    assert DCCRegistry["ACT/365"].calculate_fraction(Date(2018, 11, 1), Date(2018, 11, 16), Date(2019, 12, 15)) == Decimal("0.04383561643835616")
    assert DCCRegistry["ACT/365"].calculate_fraction(Date(2018, 11, 1), Date(2018, 11, 15), Date(2019, 12, 15)) == Decimal("0.0410958904109589")



# Generated at 2022-06-24 01:09:28.889115
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)


# Generated at 2022-06-24 01:09:32.430278
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dccr1 = DCCRegistryMachinery()
    dccr2 = DCCRegistryMachinery()
    assert dccr1 is not dccr2


# Generated at 2022-06-24 01:09:36.514940
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    # prep
    # action
    dcc_registry = DCCRegistryMachinery()
    # assert
    assert dcc_registry is not None



# Generated at 2022-06-24 01:09:49.764585
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal('1.10000000000000')


# Generated at 2022-06-24 01:09:52.303827
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC.interest(DCC.name, "ISMA 30/360", "Monthly", 30, 1, 0) == 0
test_DCC()


# Generated at 2022-06-24 01:10:01.440587
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,28), end=datetime.date(2008,2,28)),14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,29), end=datetime.date(2008,2,29)),14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=datetime.date(2007,10,31), asof=datetime.date(2008,11,30), end=datetime.date(2008,11,30)),14) == Decimal('1.10000000000000')


# Generated at 2022-06-24 01:10:08.174026
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)),14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)),14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)),14) == Decimal('1.10000000000000')


# Generated at 2022-06-24 01:10:15.189966
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    def check_dcfc_act_365_f(start, asof, end, expected_result, tol=1E-14):
        assert abs(dcfc_act_365_f(start, asof, end) - Decimal(expected_result)) < tol

    check_dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28), 0.16986301369863)
    check_dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29), 0.17260273972603)

# Generated at 2022-06-24 01:10:17.992887
# Unit test for function dcc
def test_dcc():
    pass
test_dcc()



# Generated at 2022-06-24 01:10:22.836787
# Unit test for method interest of class DCC
def test_DCC_interest():
    curr = "USD"
    principal = Money(1000, Currency[curr])
    rate = Decimal(0.01)
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 10)
    end = datetime.date(2014, 2, 1)
    freq = Decimal(1)
    dcc_mock = DCC(name="ACT/365 (NL)", altnames = set(), currencies = set(), calculate_fraction_method = None)
    dcc_mock.interest(principal, rate, start, asof, end, freq) == Money(10, Currency[curr])
    asof = datetime.date(2014, 2, 1)

# Generated at 2022-06-24 01:10:33.727334
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Test the date checks
    start1 = datetime.date(2005, 2, 28)
    end1 = datetime.date(2007, 2, 28)
    print(dcfc_act_act(start1, end1, end1)) # should print 0
    # Test for one year
    start2 = datetime.date(2005, 2, 28)
    end2 = datetime.date(2006, 2, 28)
    print(dcfc_act_act(start2, end2, end2)) # should print 1
    # Test for a leap year
    start3 = datetime.date(2004, 2, 28)
    end3 = datetime.date(2005, 2, 28)
    print(dcfc_act_act(start3, end3, end3)) # should print 1
    # Test for leap year

# Generated at 2022-06-24 01:10:41.504548
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    from decimal import Decimal
    from datetime import date
    from pyexlatex.math.money import Money
    from pyexlatex.math.currencies import Currencies

    principal = Money.of(Currencies["USD"], Decimal(1000000), date.today())
    start = date(2007, 12, 28)
    end = date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    round(dcc.calculate_fraction(start, end, end), 14)
    dcc.interest(principal, rate, start, end, end).qty
    dcc.interest(principal, rate, end, start, start).qty

DCCRegistry = DCCRegistryMachinery()



# Generated at 2022-06-24 01:10:51.944731
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.17222222222222')

# Generated at 2022-06-24 01:11:01.026639
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(datetime.date(2020, 1, 17), datetime.date(2020, 1, 17), datetime.date(2021, 3, 31)), 14) == Decimal('0.01166256214')
    assert round(dcfc_act_365_f(datetime.date(2020, 1, 17), datetime.date(2020, 1, 17), datetime.date(2021, 4, 1)), 14) == Decimal('0.01166414213')
    assert round(dcfc_act_365_f(datetime.date(2020, 1, 17), datetime.date(2020, 1, 17), datetime.date(2021, 4, 1), 2), 14) == Decimal('0.00583207107')



# Generated at 2022-06-24 01:11:09.564021
# Unit test for method coupon of class DCC

# Generated at 2022-06-24 01:11:17.183344
# Unit test for method interest of class DCC
def test_DCC_interest():
    principal = Money(100, 'USD')
    rate = 0.5
    start = datetime.date(2019, 1, 1)
    asof = datetime.date(2019, 1, 31)
    end = asof
    freq = Decimal(1)
    dcc = DCC('TEST', {'TST'}, _as_ccys({'USD'}),
              lambda start, asof, end, freq: _get_actual_day_count(start, asof) / _get_actual_day_count(start, end))
    assert dcc.interest(principal, rate, start, asof, end, freq).amount == Decimal('2.5')


# Generated at 2022-06-24 01:11:27.323168
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(start=datetime.date(2012, 1, 1), asof=datetime.date(2012, 12, 31), end=datetime.date(2012, 12, 31)), 4) == Decimal('1')
    assert round(dcfc_act_365_f(start=datetime.date(2012, 1, 2), asof=datetime.date(2012, 12, 31), end=datetime.date(2012, 12, 31)), 4) == Decimal('0.9972')
    assert round(dcfc_act_365_f(start=datetime.date(2012, 1, 3), asof=datetime.date(2012, 12, 31), end=datetime.date(2012, 12, 31)), 4) == Decimal('0.9945')

# Generated at 2022-06-24 01:11:36.254950
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    ex1_dcf = dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end)
    assert round(ex1_dcf, 10) == Decimal('0.5245901639')



# Generated at 2022-06-24 01:11:48.139768
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:11:57.518708
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .currencies import Currencies
    from .monetary import Amount

    # Checks if dates are provided properly:
    assert DCC("DCC", {"DCC"}, _as_ccys({"XXX"}), None).calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2016, 1, 1), datetime.date(2017, 1, 1)) == ZERO
    assert DCC("DCC", {"DCC"}, _as_ccys({"XXX"}), None).calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 2)) == ONE

# Generated at 2022-06-24 01:12:04.506237
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-24 01:12:15.207588
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    obj = DCCRegistryMachinery()
    DCC = namedtuple('DCC',('name,altnames,currencies,calculate_fraction_method'))
    dcc = DCC("name",{'altnames','currencies'},{'USD','EUR'},lambda start, asof, end, freq: 0.1)
    testcases = [
        (lambda: None,dcc,"name"),
        (lambda: None,dcc,"altnames"),
        (lambda: None,dcc,"currencies"),
        (lambda: None,dcc,"calculate_fraction_method"),
        (lambda: None,dcc,"random")
    ]
    for testcase in testcases:
        with pytest.raises(TypeError): testcase[0]


# Generated at 2022-06-24 01:12:24.357300
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2020, 3, 2), datetime.date(2020, 3, 2)

# Generated at 2022-06-24 01:12:35.171992
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .enums import DCCs

    assert DCCs.ACT_360.interest(Money(1, "USD"), 0.05, datetime.date(2018,1,1), datetime.date(2018,2,28)) == 0.0833333333333333
    assert DCCs.ACT_360.interest(Money(1, "USD"), 0.05, datetime.date(2018,1,1), datetime.date(2018,3,1)) == 0.0833333333333333
    assert DCCs.ACT_360.interest(Money(1, "USD"), 0.05, datetime.date(2018,1,1), datetime.date(2018,5,6)) == 0.208333333333333

# Generated at 2022-06-24 01:12:43.860180
# Unit test for method coupon of class DCC

# Generated at 2022-06-24 01:12:54.605032
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    dt1 = datetime.date(2007,12,28)
    dt2 = datetime.date(2008,2,28)
    assert dcfc_act_360(dt1,dt2,dt2) == pytest.approx(0.17222222222222)
    dt3 = datetime.date(2008,2,29)
    assert dcfc_act_360(dt1,dt3,dt3) == pytest.approx(0.175)
    dt4 = datetime.date(2007,10,31)
    dt5 = datetime.date(2008,11,30)
    assert dcfc_act_360(dt4,dt5,dt5) == pytest.approx(1.1)

# Generated at 2022-06-24 01:13:01.210932
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert (DCC('name', {'altnames'}, {Currency('INR')}, 'calculate_fraction_method')).interest(Money(10, 'INR'), 0.1, datetime.date(2008, 12, 31), datetime.date(2009, 12, 31), datetime.date(2009, 12, 31)) == Money(1, 'INR')


# Generated at 2022-06-24 01:13:07.228681
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert Decimal('0.16666666666667') == dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof)

# Generated at 2022-06-24 01:13:12.203958
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360.__dcc.interest(Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today()), Decimal(0.01), datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)).qty, 2) == 1722.22



# Generated at 2022-06-24 01:13:24.243681
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    dcf_30e_360 = dcfc_30_e_plus_360(start='28-Dec-2007', asof='28-Feb-2008', end='28-Feb-2008')
    assert dcf_30e_360 == Decimal('0.16666666666667')
    dcf_30e_360 = dcfc_30_e_plus_360(start='28-Dec-2007', asof='29-Feb-2008', end='29-Feb-2008')
    assert dcf_30e_360 == Decimal('0.16944444444444')
    dcf_30e_360 = dcfc_30_e_plus_360(start='31-Oct-2007', asof='30-Nov-2008', end='30-Nov-2008')

# Generated at 2022-06-24 01:13:30.286785
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    # Create a DCCRegistryMachinery instance
    DCCRegistryMachinery_instance = DCCRegistryMachinery()
    # Check the validity of the instance created
    assert DCCRegistryMachinery_instance != None

# Create a singleton instance of DCCRegistryMachinery
DCCRegistry = DCCRegistryMachinery()


# Generated at 2022-06-24 01:13:39.656223
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:13:50.484342
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008, 11, 30)), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-24 01:13:56.903893
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:13:59.899529
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    DCCRegistry.registry()
    DCCRegistry.table()

## Defines the registry singleton:
REGISTRY_INSTANCE: Optional[DCCRegistryMachinery] = None


# Generated at 2022-06-24 01:14:09.294864
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    # Test for example 1
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.1722222222')

    # Test for example 2
    ex2_start, ex2_asof, ex2_end = datetime.date(2019, 3, 2), datetime.date(2019, 10, 3), datetime.date(2020, 3, 2)  

# Generated at 2022-06-24 01:14:13.810494
# Unit test for constructor of class DCC
def test_DCC():
    try:
        dcc = DCC('Test', {'Test2', 'Test3'}, {Currencies['USD'], Currencies['EUR']}, calculate_fraction_method = _get_actual_day_count)
        print(dcc.name)
    except Exception as e:
        print(e)
    
    


# Generated at 2022-06-24 01:14:24.997783
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_f(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17260273972603')
    assert round(dcfc_act_365_f(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:14:29.608179
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCCs['Act/Act'].interest(Money(12345,Currencies['EUR']), Decimal(0.05), datetime.date(2016, 4, 3), datetime.date(2016, 5, 3)) == Money(187.5, Currencies['EUR'])



# Generated at 2022-06-24 01:14:40.477891
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    # Test 1:
    ex1_start = datetime.date(2019, 3, 2)
    ex1_asof = datetime.date(2019, 9, 10)
    ex1_end = datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')

# End of unit test for function dcfc_act_act_icma

# Generated at 2022-06-24 01:14:47.116198
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    principal = Money("1000.00", "USD")
    rate = Decimal("0.04")
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 12, 31)
    end = datetime.date(2015, 1, 1)
    freq = 1
    assert DCCRegistry["ACT/365"](start, asof, end, freq).interest(principal, rate, start, asof, end or asof, freq) == Money("40.00", "USD")

# Generated at 2022-06-24 01:14:56.566468
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:15:06.371666
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from .money import EUR, Money
    from .currencies import Currencies
    Currencies.add('EUR', 2)
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2015, 12, 31)
    end = datetime.date(2015, 12, 31)
    principal = EUR(100)
    rate = Decimal("0.05")
    freq = Decimal("2")
    eom = None
    ans = Money(Decimal("2.7027777777777777777777778"), Currency("EUR"))
    assert DCC(
        name="", altnames=None, currencies=None, calculate_fraction_method=None
    ).coupon(principal, rate, start, asof, end, freq, eom) == ans



# Generated at 2022-06-24 01:15:14.243855
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_end), 10)
    # Expected outcome is 0.537802395
    # Actual outcome is 0.537802395



# Generated at 2022-06-24 01:15:19.871114
# Unit test for function dcfc_act_365_a

# Generated at 2022-06-24 01:15:24.428198
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-24 01:15:29.509206
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    dates = [datetime.date(2007, 2, 28), datetime.date(2007, 10, 31), datetime.date(2008, 2, 28), datetime.date(2008, 2, 29)]
    assert [round(dcfc_30_360_german(datetime.date(2007, 2, 28), date, date), 14) for date in dates] == [0.0, 0.0833333333, 0.1666666666, 0.1666666666]
    assert [round(dcfc_30_360_german(datetime.date(2007, 10, 31), date, date), 14) for date in dates] == [0.0833333333, 0.0, 0.0833333333, 0.0833333333]

# Generated at 2022-06-24 01:15:39.286578
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCCRegistryMachinery()
    assert not dcc._is_registered('Actual/365')
    dcc.register(DCC('Actual/365', {'Act/365', 'Act/365F', 'A/365F', 'A/365', 'ACT/365'}, {Currency('GBP')}, _calc_act_act))
    assert dcc._is_registered('Actual/365')
    assert dcc.find('Actual/365') == dcc._find_strict('Actual/365')
    assert dcc.find('Actual/365') == dcc._find_strict('Act/365')
    assert dcc.find('Actual/365') == dcc._find_strict('Act/365F')
    assert dcc.find('Actual/365') == dcc._

# Generated at 2022-06-24 01:15:46.127817
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # Arguments
    dcc = DCC("Act/Act", {"actact", "aaa"}, {Currencies["USD"]}, calculate_act_act)
    # Result
    # __init__
    # register
    # Use assert statements to ensure behavior
    assert True


# Generated at 2022-06-24 01:15:52.590967
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-24 01:15:59.222866
# Unit test for function dcc
def test_dcc():
    @dcc("Test dcc", ccys={"USD"})
    def test_dcfc(start, asof, end, freq):
        return Decimal(1)

    assert DCCRegistry.find("Test dcc"), "Failed to find just registered DCC by name"
    assert DCCRegistry.find("test dcc"), "Failed to find just registered DCC by name with lower case and stripped"



# Generated at 2022-06-24 01:16:09.188137
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:16:14.762498
# Unit test for constructor of class DCC
def test_DCC():
    ## Arrange
    dcc: DCC = DCC(
        name='test',
        altnames={'test'},
        currencies={Currencies.USD},
        calculate_fraction_method=None
    )

    ## Assert
    assert dcc.name == 'test'
    assert dcc.altnames == {'test'}
    assert dcc.currencies == {Currencies.USD}
    assert dcc.calculate_fraction_method == None


# Generated at 2022-06-24 01:16:22.612776
# Unit test for constructor of class DCC
def test_DCC():
    test_tuple = DCC("name", {"altname"}, {"CUR", "cur"}, lambda a, b, c, d: Decimal(1))
    assert test_tuple.name == "name"
    assert test_tuple.altnames == {"altname"}
    assert test_tuple.currencies == {"CUR", "cur"}
    assert test_tuple.calculate_fraction_method(datetime.date(2011, 1, 1), datetime.date(2011, 1, 2), datetime.date(2011, 1, 3), None) == Decimal(1)



# Generated at 2022-06-24 01:16:33.750281
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert str(round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))=="Decimal('0.16986301369863')"

# Generated at 2022-06-24 01:16:35.753531
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    pr = DCCRegistry()
    result = pr.find("Act/Act")
    assert result != None
    assert result.name == "Act/Act"


# Generated at 2022-06-24 01:16:42.108685
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:16:49.212807
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert (DCC('ACT/365F (FIXED)', {}, {}, lambda start, asof, end, freq: 0).interest(Money(.5, Currency('USD')), .5, datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), 1) == Money(.5, Currency('USD')))


# Generated at 2022-06-24 01:16:57.627840
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC_30_360.coupon(Money('100', 'USD'), 0.5, datetime.date(2014, 1, 1), datetime.date(2014, 7, 31), datetime.date(2014, 7, 31), 2) == Money('2.5', 'USD')
    assert DCC_30_360.coupon(Money('100', 'USD'), 0.5, datetime.date(2014, 1, 1), datetime.date(2014, 8, 1), datetime.date(2014, 7, 31), 2) == Money('2.5', 'USD')
    assert DCC_30_360.coupon(Money('100', 'USD'), 0.5, datetime.date(2014, 1, 1), datetime.date(2014, 8, 1), datetime.date(2014, 7, 31), 2)

# Generated at 2022-06-24 01:17:04.403474
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    a = DCC("Actual/Actual (A/A)", {"Actual/365", "Actual/Actual"} , set(), _AFB_AF)
    assert a.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == ZERO
    assert a.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 1)) == ZERO
    assert a.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == ONE

# Generated at 2022-06-24 01:17:10.898914
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Unit test for function dcfc_30_e_360
    """
    assert dcc_annual_factor(dcfc_30_e_360, start=Date(2020, 8, 1), end=Date(2021, 8, 1)) == 1



# Generated at 2022-06-24 01:17:22.184594
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc = DCC("30/360 (ISMA)", {"30/360 (ISMA)"}, {"CHF"}, _calculate_fraction_30_360_isma)
    assert dcc.calculate_daily_fraction(datetime.date(2010, 10, 1), datetime.date(2010, 10, 2), datetime.date(2010, 12, 31)) == Decimal("0.005")
    assert dcc.calculate_daily_fraction(datetime.date(2010, 9, 30), datetime.date(2010, 10, 1), datetime.date(2010, 12, 31)) == Decimal("0.005")

# Generated at 2022-06-24 01:17:32.749574
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    # case 1: Feb 2019 - Feb 2020
    ex1_start, ex1_asof = datetime.date(2019, 2, 14), datetime.date(2020, 2, 14)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == (datetime.date(2020, 2, 14) - datetime.date(2019, 2, 14)).days/365
    # case 2: Feb 2019 - Feb 2020 (leap year)
    ex2_start, ex2_asof = datetime.date(2019, 2, 28), datetime.date(2020, 2, 29)

# Generated at 2022-06-24 01:17:43.597224
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:17:52.997353
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:18:04.693859
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)

    DCCRegistryMachinery_Test = DCCRegistryMachinery()
    DCCRegistryMachinery_Test.register(DCC("Act/Act", {"Actual/Actual"}, {"USD"}, actual_actual))
    DCCRegistryMachinery_Test.register(
        DCC("Act/360", {"Actual/360"}, {}, lambda start, asof, end, freq=None: _actual_360(start, asof, end))
    )
    dcc = DCCRegistryMachinery_Test.find("Act/Act")

# Generated at 2022-06-24 01:18:14.355924
# Unit test for function dcc
def test_dcc():
    """
    test dcc
    """
    @dcc("Act/Act", None, None)
    def calculate_fraction(start, asof, end, freq):
        return (asof - start) / (end - start)

    ## Get DCC:
    dcc = DCCRegistry.find("Act/Act")

    ## Associate a new attribute to the function:
    assert calculate_fraction.__dcc == dcc

    ## Associate a new attribute to the dict:
    assert calculate_fraction.__dict__["__dcc"] == dcc

    ## Get the attribute to the function:
    assert getattr(calculate_fraction, "__dcc") == dcc

    ## Get the attribute to the dict:
    assert calculate_fraction.__dict__.get("__dcc") == dcc

   