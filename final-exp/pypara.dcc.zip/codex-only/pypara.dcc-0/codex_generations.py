

# Generated at 2022-06-24 01:08:11.696612
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    import datetime

# Generated at 2022-06-24 01:08:17.097470
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:08:24.670147
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from collections import namedtuple

    testdata = namedtuple("testdata", "principal rate start asof end freq eom expected")
    dataset = [
        testdata(
            principal=Money(Decimal("100.00"), Currencies.EUR),
            rate=100 * 10**-4,
            start=datetime.date(2014, 4, 1),
            asof=datetime.date(2014, 4, 1),
            end=datetime.date(2014, 4, 30),
            freq=2,
            eom=31,
            expected=Money(Decimal("10.00"), Currencies.EUR),
        ),
    ]


# Generated at 2022-06-24 01:08:31.374381
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert(dcfc_30_e_360(start=datetime.date(2007,12,28), asof=datetime.date(2008, 2, 28)) == Decimal('0.16666666666667'))
    assert(dcfc_30_e_360(start=datetime.date(2007,12,28), asof=datetime.date(2008, 2, 29)) == Decimal('0.16944444444444'))
    assert(dcfc_30_e_360(start=datetime.date(2007,10,31), asof=datetime.date(2008, 11, 30)) == Decimal('1.08333333333333'))

# Generated at 2022-06-24 01:08:42.436545
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """Test function dcfc_30_e_360"""

    ## Initialize parameters:
    dates = (
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)),
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)),
        (datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)),
        (datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)),
    )

    ## Initialize expected results:
    expected_results = (
        Decimal('0.16666666666667'),
        Decimal('0.16944444444444'),
        Decimal('1.08333333333333'),
        Decimal('1.33055555555556'),
    )

# Generated at 2022-06-24 01:08:53.335933
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
  ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
  ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
  ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
  ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
  assert math.isclose(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 0.17222222222222)

# Generated at 2022-06-24 01:09:02.914449
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start = datetime.date(2019,8,30), asof = datetime.date(2019,8,31), end = datetime.date(2020, 6, 30)),14) == round(Decimal('0.028301886792453'),14)
    assert round(dcfc_act_365_l(start = datetime.date(2019,9,2), asof = datetime.date(2019,9,3), end = datetime.date(2020, 9, 1)),14) == round(Decimal('0.035616438356164'),14)

# Generated at 2022-06-24 01:09:14.957120
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("Act/Act")
    assert DCCRegistry.find("Act/360")
    assert DCCRegistry.find("Act/365")
    assert DCCRegistry.find("30/360")
    assert DCCRegistry.find("Act/Act")
    assert DCCRegistry.find("Act/365.25")
    assert DCCRegistry.find("Act/365L")
    assert not DCCRegistry.find("Act")
    assert not DCCRegistry.find("30/360P")
    assert not DCCRegistry.find("30/360S")
    assert not DCCRegistry.find("30/360E")
    assert not DCCRegistry.find("30E/360")
    assert not DCCRegistry.find("30E+/360")
    assert not D

# Generated at 2022-06-24 01:09:24.063469
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert(DCCRegistry["ACT/360"].calculate_daily_fraction(
        datetime.date(2016, 2, 29), datetime.date(2016, 8, 15), datetime.date(2017, 2, 28)) == Decimal(0.02083))
    assert(DCCRegistry["ACT/360"].calculate_daily_fraction(
        datetime.date(2016, 2, 29), datetime.date(2016, 8, 15), datetime.date(2017, 2, 28)) == Decimal(0.02083))

# Generated at 2022-06-24 01:09:33.671555
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    t = DCCRegistryMachinery()
    t.register(DCC("Act/Act", {"Actual/Actual"}))
    assert t.find("act/act") == DCC("Act/Act", {"Actual/Actual"})
    assert t.find("Act/Act") == DCC("Act/Act", {"Actual/Actual"})
    assert t.find("Actual/Actual") == DCC("Act/Act", {"Actual/Actual"})
    assert t.find("actual/actual") == DCC("Act/Act", {"Actual/Actual"})
    assert t.find("x") is None


# Definition of the day count convention registry.
DCCRegistry = DCCRegistryMachinery()


# Default Day Count Fraction Calculations:

# Generated at 2022-06-24 01:09:39.092225
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # Setup
    dcc = DCC("Act/Act", Set("AAA"), Set(Currencies["USD"]), dc_actual_actual)
    r = DCCRegistryMachinery()

    # Exercise and Verify
    assert not r._is_registered("Act/Act")
    r.register(dcc)
    assert r._is_registered("Act/Act")
    
    # Exercise and Verify
    assert not r._is_registered("AAA")
    r.register(dcc)
    assert r._is_registered("AAA")



# Generated at 2022-06-24 01:09:50.421066
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof) == 0.16666666666667)

# Generated at 2022-06-24 01:10:00.044478
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """Unit test for function dcfc_30_360_german."""
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_german(start, asof, asof), 14) == Decimal('0.16666666666667')
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_30_360_german(start, asof, asof), 14) == Decimal('0.16944444444444')
    start, asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)

# Generated at 2022-06-24 01:10:04.765021
# Unit test for function dcfc_30_360_german

# Generated at 2022-06-24 01:10:15.536617
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-24 01:10:24.634077
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    '''
    This is a unit test for function dcfc_act_act.
    '''
    ## Test 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

    ## Test 2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Dec

# Generated at 2022-06-24 01:10:34.443235
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Get a DCC definition:
    dcc = DCCRegistry.CouponAct365()

    # Calculate the daily fraction:
    daily = dcc.calculate_daily_fraction(datetime.date(2014, 3, 31), datetime.date(2014, 4, 2), datetime.date(2014, 4, 30))

    # Assert the result:
    assert daily == Decimal(7/31)

    # Calculate the daily fraction:
    daily = dcc.calculate_daily_fraction(datetime.date(2014, 3, 31), datetime.date(2014, 4, 2), datetime.datetime(2014, 4, 2))

    # Assert the result:
    assert daily == Decimal(2/31)


# Generated at 2022-06-24 01:10:36.004297
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    a = DCCRegistryMachinery()
    assert isinstance(a, DCCRegistryMachinery)


# Generated at 2022-06-24 01:10:43.163732
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    '''
    Test function dcfc_30_360_us
    '''
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)

# Generated at 2022-06-24 01:10:49.068016
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) ==  Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) ==  Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) ==  Decimal('1.08196721311475')

# Generated at 2022-06-24 01:11:00.037673
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:11:08.799752
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Test case 1
    # start = datetime.date(2014, 6, 4)
    # asof = datetime.date(2014, 6, 4)
    # end = datetime.date(2014, 9, 4)
    # freq = "3M"
    # result = DCCRegistry.get("30/360 US").calculate_daily_fraction(start, asof, end, freq)
    # assert result == 1 / 90

    # Test case 2
    start = datetime.date(2014, 6, 4)
    asof = datetime.date(2014, 6, 5)
    end = datetime.date(2014, 9, 5)
    freq = Decimal("3M")

# Generated at 2022-06-24 01:11:14.773786
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    assert not DCCRegistryMachinery()._is_registered('Act/Act')
    DCCRegistry.register(DCC("Act/Act", {'Actual/Actual'}, {}, calculate_fraction_actact))
    assert DCCRegistryMachinery()._is_registered('Act/Act')

# Unit tests for functions


# Generated at 2022-06-24 01:11:25.148081
# Unit test for method interest of class DCC
def test_DCC_interest():
    from decimal import Decimal
    from .monetary import Money
    from datetime import date
    from .currencies import Currencies
    from .commons.zeitgeist import Date
    from .dcc import DCCRegistry, DCC
    assert DCCRegistry.D30360.interest(Money('1.0', Currencies.USD), Decimal('0.025'), Date.today(), Date.today()+relativedelta(months=1))==Money('0.00083333', Currencies.USD)

# Generated at 2022-06-24 01:11:30.915994
# Unit test for function dcfc_30_e_360

# Generated at 2022-06-24 01:11:43.289061
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    verbose = False

    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    expected_value = Decimal("0.17222222222222")
    computed_value = dcfc_act_360(start=start, asof=asof, end=asof)
    if verbose:
        print("Expected value = %s, computed value = %s" % (expected_value, computed_value))
    assert expected_value == computed_value

    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    expected_value = Decimal("0.17500000000000")
    computed_value = dcfc_act_360(start=start, asof=asof, end=asof)


# Generated at 2022-06-24 01:11:52.653591
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    '''
    Tests the function dcfc_30_360_isda.
    '''

    # Setup
    d1_1 = datetime.date(2018, 1, 10)
    d1_2 = datetime.date(2018, 3, 5)
    d1_3 = datetime.date(2018, 6, 1)
    d1_4 = datetime.date(2019, 4, 1)
    d1_5 = datetime.date(2018, 10, 1)

    d2_1 = datetime.date(2018, 1, 1)
    d2_2 = datetime.date(2018, 3, 31)
    d2_3 = datetime.date(2018, 12, 31)
    d2_4 = datetime.date(2019, 4, 30)

# Generated at 2022-06-24 01:11:58.018361
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_360_

# Generated at 2022-06-24 01:12:09.913022
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    start = datetime.date(2007, 12, 28)
    asof  = datetime.date(2008, 2, 28)
    end   = datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_german(start, asof, end), 14) == Decimal('0.16666666666667')
    start = datetime.date(2007, 12, 28)
    asof  = datetime.date(2008, 2, 29)
    end   = datetime.date(2008, 2, 29)
    assert round(dcfc_30_360_german(start, asof, end), 14) == Decimal('0.16944444444444')
    start = datetime.date(2007, 10, 31)

# Generated at 2022-06-24 01:12:20.772831
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # Example from FINCAD
    start = datetime.date(2001, 1, 25)
    asof = datetime.date(2001, 12, 31)
    assert round(dcfc_30_360_isda(start, asof, asof), 14) == Decimal('0.11111111111111')

    start = datetime.date(2000, 5, 31)
    asof = datetime.date(2001, 5, 31)
    assert round(dcfc_30_360_isda(start, asof, asof), 14) == Decimal('1.00000000000000')

    start = datetime.date(2000, 2, 29)
    asof = datetime.date(2001, 2, 28)

# Generated at 2022-06-24 01:12:32.224788
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    import datetime
    from decimal import Decimal
    from collections import namedtuple
    ccy = namedtuple("Currency", ["code"])
    euro = ccy("EUR")

    #Simple, no leap day
    start = datetime.date(2000, 3, 21)
    asof = datetime.date(2000, 9, 1)
    end = datetime.date(2000, 9, 1)
    freq = 1
    eom = 15
    principal = 10_000.00
    rate = 0.1

    usd_dcc = DCC(
        name="US",
        altnames={"US", "USDC"},
        currencies={"USD"},
        calculate_fraction_method=_calculate_fraction_method_30_360_ISDA,
    )

    eur_dcc

# Generated at 2022-06-24 01:12:41.276559
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:12:46.439484
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act_icma(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act_icma(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-24 01:12:53.802061
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:13:05.132935
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    This method unit tests method find of class DCCRegistryMachinery
    """
    dcc = DCC(name='Act/Act', altnames={'ActualDCC','A/A','Act/Act','ACTUAL','Actual','ACT','Act','ACT/ACT','ACTUAL/ACTUAL','ACT/365','ACTUAL/365','Act/365','Actual/365','ACT/360','ACTUAL/360','Act/360','Actual/360'}, currencies={Currency('USD')}, calculate_fraction_method=DCC.calculate_fraction_method.__get__(DCC, DCC))
    DCCRegistry.register(dcc)
    assert DCCRegistry.find('ACT/ACT') == dcc
    assert DCCRegistry.find('USD') == None


# Generated at 2022-06-24 01:13:15.171157
# Unit test for method interest of class DCC
def test_DCC_interest():
    import datetime
    from decimal import Decimal
    from pyxir.commons.types import XType
    from pyxir.graph.axis import Axis
    from pyxir.graph.layer import XLayer
    from pyxir.graph.xgraph import XGraph

    from vivarium.library.money import Money
    from vivarium.library.random import Random
    from vivarium.library.unit import Units
    from vivarium.library.units import currencies, currencies_by_country, currencies_by_country_subunit
    from vivarium.library.units.currencies import Currencies, Currency
    from vivarium.library.units.money import Moneys

    currency_usd = currencies['USD']
    money_value = Money(1000, currency_usd)

    rate = Decimal(0.01)


# Generated at 2022-06-24 01:13:25.320074
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCC_30E_360.calculate_fraction(datetime.date(2016, 1, 1), datetime.date(2016, 1, 1), datetime.date(2016, 2, 1)) == 0
    assert DCC_30E_360.calculate_fraction(datetime.date(2016, 1, 1), datetime.date(2016, 1, 2), datetime.date(2016, 2, 1)) == Decimal('0.03')
    assert DCC_30E_360.calculate_fraction(datetime.date(2015, 1, 1), datetime.date(2015, 1, 1), datetime.date(2015, 2, 1)) == 0

# Generated at 2022-06-24 01:13:37.135968
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_plus_360(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:13:43.886371
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof)== Decimal('0.16666666666667')
    assert dcfc_30_360_

# Generated at 2022-06-24 01:13:50.974893
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2017, 8, 4), datetime.date(2017, 8, 4), datetime.date(2017, 8, 4)), 14) == Decimal('0.00000000000000')
    assert round(dcfc_30_360_isda(datetime.date(2017, 8, 4), datetime.date(2017, 9, 4), datetime.date(2017, 9, 4)), 14) == Decimal('0.03333333333333')
    assert round(dcfc_30_360_isda(datetime.date(2017, 8, 4), datetime.date(2017, 9, 5), datetime.date(2017, 9, 5)), 14) == Decimal('0.03611111111111')

# Generated at 2022-06-24 01:13:57.433970
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    print("Running unit test for dcfc_30_360_us...")
    ok = True
    if round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) != Decimal('0.16666666666667'):
        print("Error: dcfc_30_360_us failed for 2007,12,28 to 2008,2,28");
        ok = False

# Generated at 2022-06-24 01:14:03.410806
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2016, 12, 31)
    end = datetime.date(2017, 1, 1)
    freq = None
    dc30360_eom = DCC('dc30360_eom', {'dc30360_eom'}, {'USD', 'JPY'}, dc30360_eom_method)
    dc30360_eom.calculate_fraction(start, asof, end, freq)


# Generated at 2022-06-24 01:14:06.769597
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 29)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.17213114754098')


# Generated at 2022-06-24 01:14:16.062050
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    ## Create and initialize the object:
    drm = DCCRegistryMachinery()

    ## Define a new DCC:
    data = ("Actual/Actual (ISMA)", {"Act/Act"}, None, calculate_fraction_isda)

    ## Create a new DCC and register it:
    drm.register(DCC(*data))

    ## Get the result:
    result = drm._buffer_main["ACTUAL/ACTUAL (ISMA)"]

    ## Assert:
    assert isinstance(result, DCC)
    assert result.name == "Actual/Actual (ISMA)"
    assert result.altnames == {"Act/Act"}
    assert result.calculate_fraction_method == calculate_fraction_isda
    assert len(drm._buffer_altn) == 1

    ## Try to register

# Generated at 2022-06-24 01:14:25.726922
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:14:29.504200
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2019,3,2), datetime.date(2019,9,10), datetime.date(2020,3,2)),14)==Decimal("0.5245901639")



# Generated at 2022-06-24 01:14:36.412447
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)),14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)),14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)),14) == Decimal('1.08196721311475')

# Generated at 2022-06-24 01:14:46.507686
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:14:55.166793
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof, ex1_end = datetime.date(2020, 3, 12), datetime.date(2020, 3, 12), datetime.date(2021, 3, 13)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.02739726')


# Generated at 2022-06-24 01:15:04.448462
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:15:14.431126
# Unit test for method interest of class DCC
def test_DCC_interest():
    """
    Tests for method interest of class DCC.
    """
    from .monetary import Money

    ## Create a test DCC object:
    class TestDCC(DCC):
        """
        A test DCC implementation.
        """

        calculate_fraction_method = staticmethod(lambda start, asof, end, freq: ONE)

    ## Create a principal:
    principal = Money(100, "USD")

    ## Get the interest:
    interest = DCCRegistry.instance().get("ACT/ACT").interest(principal, 0.05, datetime.date(2017, 1, 1),
                                                             datetime.date(2017, 6, 30))

    ## Checks if we have the expected amount:
    assert interest.amount == 25


#: Defines an empty value for day count convention field.
DCC

# Generated at 2022-06-24 01:15:16.284145
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCC.interest(1,1,1,1,1,1)

# Generated at 2022-06-24 01:15:21.396213
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC("name", set(["altname1", "altname2"]), set([Currencies.USD]), DCF.ACT_ACT_ICMA) == DCC("name", set(["altname1", "altname2"]), set([Currencies.USD]), DCF.ACT_ACT_ICMA)


# Generated at 2022-06-24 01:15:28.102251
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)

    assert DCCRegistry.find("Act/Act").calculate_fraction(start, end, end) == Decimal("0.16942884946478")
    assert DCCRegistry.find("ACT/ACT").calculate_fraction(start, end, end) == Decimal("0.16942884946478")
    assert DCCRegistry.find("act/act").calculate_fraction(start, end, end) == Decimal("0.16942884946478")
    assert DCCRegistry.find("actact").calculate_fraction(start, end, end) == Decimal("0.16942884946478")

# Generated at 2022-06-24 01:15:39.593993
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:15:50.982701
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-24 01:16:03.565480
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Checks if method find of class DCCRegistryMachinery works as expected.
    """

    # Set up test data (preamble):

    # Set up test data (main):
    dcc_list = [
        DCC(
            name = "Act/Act",
            altnames = {
                "Act/Act (ICMA)",
                "Actual/Actual (ICMA)",
                "ICMA",
                "Actual/Actual (BIS)",
                "Act/Act (BIS)",
                "Actual/Actual",
                "Act/Act",
                },
            currencies = {Currencies["USD"]},
            calculate_fraction_method = _dcf_act_act
            ),
    ]
    dccr = DCCRegistryMachinery()

# Generated at 2022-06-24 01:16:13.741400
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:16:24.396664
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    """
    Tests for the "Act/365L" day count fraction convention.
    """
    ## Set up some examples for testing:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    ## Run the tests:

# Generated at 2022-06-24 01:16:34.630563
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from datetime import date

    assert DCCRegistry.get("ACT/360").calculate_daily_fraction(date(2020, 1, 1),
                                                               date(2020, 1, 1),
                                                               date(2020, 1, 2)) == Decimal(0)
    assert DCCRegistry.get("ACT/365").calculate_daily_fraction(date(2020, 1, 1),
                                                               date(2020, 1, 1),
                                                               date(2020, 1, 2)) == Decimal(0)
    assert DCCRegistry.get("ACT/ACT").calculate_daily_fraction(date(2020, 1, 1),
                                                               date(2020, 1, 1),
                                                               date(2020, 1, 2)) == Decimal(0)
    assert D

# Generated at 2022-06-24 01:16:44.822279
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    """
    Unit test.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:16:52.816790
# Unit test for method interest of class DCC
def test_DCC_interest():
    start = datetime.date(2014,  1,  1)
    asof = datetime.date(2015,  12, 31)
    end = datetime.date(2015,  12, 31)

    if DCC(name = "ACT/365", altnames = {"ACT/365"}, currencies = {"BRL"}, calculate_fraction_method = lambda start, asof, end, freq: _get_actual_day_count(start, end) / Decimal(365)).interest(Money(100, "BRL"), Decimal(0.10), start, asof, end) != Money(10, "BRL"):
        raise AssertionError("Should be equal to 10")


# Generated at 2022-06-24 01:17:00.687133
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .monetary import Money
    from .currencies import Currencies
    from .interest_rates import InterestRate
    from .dccs import DCCs

    usd = Currencies.USD
    one_month = InterestRate(Decimal('0.25'), usd, ONE, 'M', 'ACT/360')

    start = Date(2020, 1, 1)
    end = Date(2020, 2, 1)
    dcc = DCCs.ACT_360

    usd_interest = one_month.convert(dcc, start, end)
    usd_money = Money(1, usd)

    assert round(dcc.calculate_fraction(start, end, end), 7) == 0.0833333

# Generated at 2022-06-24 01:17:08.006124
# Unit test for function dcfc_act_act

# Generated at 2022-06-24 01:17:17.110650
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:17:25.916673
# Unit test for constructor of class DCC
def test_DCC():
    """
    Unit test for constructor of class DCC

    >>> test_DCC()
    """

    print("Creating instance of class DCC")
    name = "30/360 US"
    altnames = {"30/360 US", "30U/360", "30/360 US", "30/360 US (ISDA)", "30/360 (Bond)", "30/360 Convexity", "30E/360", "30E+/360"}
    currencies = {Currencies["NOK"], Currencies["EUR"], Currencies["USD"]}
    calculate_fraction_method = DCCRegistry.get("30/360 US")
    d = DCC(name, altnames, currencies, calculate_fraction_method)
    print("Instance attributes:")
    print(d.name)
    print(d.altnames)
    print

# Generated at 2022-06-24 01:17:29.419072
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC("test", {"test"}, Currencies.UK, lambda x, y, z, m: Decimal("1234")).coupon(Money("1", "CHF"), Decimal("0.1"), Date(1998, 1, 1), Date(1998, 1, 1), Date(1998, 1, 1), 1) == Money("1234", "CHF")


# Generated at 2022-06-24 01:17:37.275422
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc = DCCRegistry.find("Act/Act")
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    rate = Decimal(0.01)
    assert dcc is not None
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')

# Generated at 2022-06-24 01:17:46.550038
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    pnl = [(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), 0.16986301369863),
           (datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), 0.16986301369863),
           (datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), 1.08219178082192),
           (datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), 1.32602739726027)]

# Generated at 2022-06-24 01:17:57.032815
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .enums import DayCountBasis
    from .currencies import Currency
    from .monetary import Money
    from .temporal import BusinessTime
    import datetime
    # If the daycount convention is (30/360 ISDA), the interest for the dates (2019-07-01) and (2019-07-30) with a rate of 2% is 0.5000
    basis = DayCountBasis.ISDA
    start = datetime.date(2019, 7, 1)
    end = datetime.date(2019, 7, 30)
    rate = 0.02
    ccy = Currency.JPY
    principal_ccy = Currency.JPY
    principal = Money(Decimal('100.0'), principal_ccy)

# Generated at 2022-06-24 01:18:08.697357
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert  round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert  round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')