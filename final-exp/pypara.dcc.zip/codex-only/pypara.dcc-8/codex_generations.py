

# Generated at 2022-06-24 01:08:16.129356
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:08:26.084120
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    ex2_start, ex2_asof, ex2_end = datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), datetime.date(2020, 9, 10)
    ex3_start, ex3_asof, ex3_end = datetime.date(2020, 3, 2), datetime.date(2020, 9, 10), datetime.date(2021, 3, 2)

# Generated at 2022-06-24 01:08:37.607774
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start = datetime.date(2014,2,28), asof = date(2014,2,28)), 14) == Decimal('0.08333333333333')
    assert round(dcfc_30_360_german(start = datetime.date(2014,2,28), asof = date(2014,3,28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start = datetime.date(2014,2,28), asof = date(2014,5,30)), 14) == Decimal('0.5')
    assert round(dcfc_30_360_german(start = datetime.date(2014,2,28), asof = date(2014,2,12)), 14) == Dec

# Generated at 2022-06-24 01:08:47.430857
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex1_fraction = 0.16666666666667
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == ex1_fraction
    
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex2_fraction = 0.16944444444444
    assert round(dcfc_30_e_plus_360(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == ex

# Generated at 2022-06-24 01:08:56.680072
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Test method find of class DCCRegistryMachinery
    """
    principal = Money(amount=Decimal('1000000'), currency=Currencies["USD"], date=date.today())
    start = datetime.date(2007,12,28)
    end = datetime.date(2008,2,28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    if round(dcc.calculate_fraction(start, end, end), 14) != Decimal('0.16942884946478'):
        raise ValueError("find doesn't work as expected")

    if dcc.interest(principal, rate, start, end, end).qty != Decimal('1694.29'):
        raise ValueError("find doesn't work as expected")

   

# Generated at 2022-06-24 01:09:04.014409
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(date(2100,10,26), date(2100,10,29), date(2100,10,29)),14) == Decimal('0.002739726')
    assert round(dcfc_act_365_l(date(2100,10,26), date(2100,10,30), date(2100,10,29)),14) == Decimal('0.0054109589')
    #assert round(dcfc_act_365_l(date(2100,10,26), date(2100,10,31), date(2100,10,29)),14) == Decimal('0.0054109589')

# Generated at 2022-06-24 01:09:11.787050
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    """
    >>> ex1_start, ex1_asof, ex1_end = datetime.date(2017, 3, 2), datetime.date(2017, 9, 10), datetime.date(2018, 3, 2)
    >>> round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_end), 10)
    Decimal('0.5245901639')
    """


# Generated at 2022-06-24 01:09:20.486203
# Unit test for constructor of class DCC
def test_DCC():
    def _dc(a: int, b: int, c: int, d: int, e: int) -> Decimal:
        # Converts a,b,c,d,e to 10 based webscalar and returns its decimal form.
        digit = 'abcde'
        return Decimal(int(''.join([str(eval(x)) for x in digit])))

    # Test 1
    assert test_DCC.func1(_dc(1, 2, 3, 4, 5)) == Decimal(12345)



# Generated at 2022-06-24 01:09:32.772510
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dcc1 = DCC(
        name="DCC1",
        altnames={},
        currencies={},
        calculate_fraction_method= lambda x, y, z, w: Decimal(),
    )
    dcc2 = DCC(
        name="DCC2",
        altnames={"TEST"},
        currencies={},
        calculate_fraction_method= lambda x, y, z, w: Decimal(),
    )
    dcc_registry = DCCRegistryMachinery()
    dcc_registry.register(dcc1)
    assert(dcc_registry._is_registered("DCC1"))
    assert(not dcc_registry._is_registered("DCC2"))
    assert(dcc_registry._find_strict("DCC1") == dcc1)

# Generated at 2022-06-24 01:09:40.742265
# Unit test for method interest of class DCC
def test_DCC_interest():
    test_cases = []
    d = datetime.date(2020, 1, 1)
    d_end = datetime.date(2020, 1, 2)
    m = Money(1, Currencies.USD)
    dcc = DCC("",{'test_name'}, {Currencies.USD}, lambda dcc, start, asof, end, freq: 1)
    expected = m
    result = dcc.interest(m, 1.0, d, d, d_end)
    test_cases.append((m, 1.0, d, d, d_end, expected, result))
    return test_cases



# Generated at 2022-06-24 01:09:46.030506
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc = DCCRegistry.find("Act/Act")
    print(dcc.name)
    dcc = DCCRegistry.find("Actual/360")
    print(dcc.name)
    dcc = DCCRegistry.find("Act/360")
    print(dcc.name)
    dcc = DCCRegistry.find("Actual365")
    print(dcc.name)
    dcc = DCCRegistry.find("Act/365")
    print(dcc.name)
    dcc = DCCRegistry.find("S30/360")
    print(dcc.name)


# Generated at 2022-06-24 01:09:49.957255
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC("","",{},"")
    assert dcc.calculate_fraction("start","asof","end","freq") == None


# Generated at 2022-06-24 01:09:54.248473
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    with pytest.raises(TypeError):
        registry = DCCRegistryMachinery()
        registry.register(DCC('Act/Act', {'Simple', 'Money'}, {'EUR'}, calcf))
        registry.register(DCC('Act/Act', {'Simple', 'Money'}, {'USD'}, calcf))


# Generated at 2022-06-24 01:10:02.923679
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    start = datetime.date(2014, 11, 7)
    asof = datetime.date(2014, 12, 7)
    end = datetime.date(2016, 1, 7)
    freq = Decimal(1)

    ## Setup the day count convention:
    dcc = DCC("30E/360ISDA", set(), _as_ccys({"EUR", "USD"}), DA30E360ISDA)

    ## Create the payment schedule:
    sch = [start + datetime.timedelta(days=i) for i in range((end - start).days)]

    ## Get the expected daily factor for each day:
    expected = [dcc.calculate_daily_fraction(start, asof, end, freq) for asof in sch]

    ## Compare the results:

# Generated at 2022-06-24 01:10:09.449344
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC_ACT_365.coupon(Money(1000000, "USD"), Decimal(0.01), datetime.date(2000, 1, 1), datetime.date(2000, 3, 31), datetime.date(2000, 6, 30), Decimal(2)) == Money(15000, "USD")
    assert DCC_ACT_ACT_ICMA.coupon(Money(1000000, "USD"), Decimal(0.01), datetime.date(2000, 1, 1), datetime.date(2000, 3, 31), datetime.date(2000, 6, 30), Decimal(2)) == Money(15000, "USD")

# Generated at 2022-06-24 01:10:17.994214
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():

    assert round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28) ), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29) ), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30) ), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-24 01:10:28.335254
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)) == 0.166666666666667
    assert dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)) == 0.1694444444444444
    assert dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)) == 1.08333333333333
    assert dcfc_30_360_isda(datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)) == 1.33333333333333



# Generated at 2022-06-24 01:10:34.612938
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)), 14) == Decimal('0.5245901639344')


# Generated at 2022-06-24 01:10:37.815962
# Unit test for constructor of class DCC
def test_DCC():
    dcc = DCC("Test", {"Test_1"}, {"CURR"}, lambda: 0)
    assert(dcc.name == "Test")
    assert(dcc.altnames == {"Test_1"})
    assert(dcc.currencies == {"CURR"})


# Generated at 2022-06-24 01:10:41.381010
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    dcc_30_360_german = DayCountConvention("30/360 German")
    dcc_30_360_german.fraction = dcfc_30_360_german
    test_dcf(dcc_30_360_german, "30_360_german")



# Generated at 2022-06-24 01:10:51.355370
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dcc1 = DCC("dcc1", set(), set(), lambda a, b, c: 0)
    dcc2 = DCC("dcc2", set(), set(), lambda a, b, c: 0)
    dcc2 = DCC("dcc3", set(), set(), lambda a, b, c: 0)
    dcc = DCC("dcc", set(), set(), lambda a, b, c: 0)
    registry = DCCRegistryMachinery()
    registry.register(dcc1)
    registry.register(dcc)
    registry.find("dcc")
    registry.register(dcc2)


# Defines the day count convention registry:
DCCRegistry = DCCRegistryMachinery()



# Generated at 2022-06-24 01:10:56.861498
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex4_start, asof=ex4_asof, end=ex4_asof), 14) == 1.33333333333333



# Generated at 2022-06-24 01:11:04.987754
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Test case 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_end = ex1_asof
    ex1_expected = round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_end), 14)
    assert ex1_expected == Decimal('0.16666666666667')

    # Test case 2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex2_end = ex2_asof

# Generated at 2022-06-24 01:11:14.105025
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_act_360(start=start, asof=asof, end=asof), 14) == Decimal('0.17222222222222')


# Generated at 2022-06-24 01:11:25.072895
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:11:34.582359
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():

    # Test the DCCRegistryMachinery class method register

    t = DCCRegistryMachinery()
    dcc = DCC("Act/Act", set(["actual/actual","actual/360"]), set(["USD"]), calculate_fraction)
    t.register(dcc)
    assert t._buffer_altn == {"actual/actual": dcc, "actual/360": dcc}, 't._buffer_altn != expected value'
    assert t._buffer_main == {"act/act": dcc}, 't._buffer_main != expected value'
    return None

# Generated at 2022-06-24 01:11:46.869727
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    """
    Test for the function dcfc_act_365_a
    """

    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    expected1 = Decimal('0.16986301369863')

# Generated at 2022-06-24 01:11:56.499544
# Unit test for function dcc
def test_dcc():
    @dcc("Test", {"Test1", "Test2"})
    def test_dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        pass

    assert issubclass(type(test_dcfc), DCFC)
    assert test_dcfc.__dcc.name == "Test"
    assert test_dcfc.__dcc.altnames == {"Test1", "Test2"}
    assert test_dcfc.__dcc.currencies == set()
    assert test_dcfc.__dcc.calculate_fraction_method == test_dcfc

    assert DCCRegistry.find("Test").name == "Test"
    assert DCCRegistry.find("test").name == "Test"
    assert D

# Generated at 2022-06-24 01:12:03.041578
# Unit test for constructor of class DCC
def test_DCC():
    """
    Test constructor of class DCC.
    """
    curr_set: Set[Currency] = _as_ccys({'CAD'})
    dcc1 = DCC('30/360', {'30/360'}, curr_set, DCF.dcf30_360)
    assert dcc1.name == '30/360'
    assert dcc1.altnames == {'30/360'}
    assert dcc1.currencies == curr_set
    assert dcc1.calculate_fraction_method == DCF.dcf30_360


# Generated at 2022-06-24 01:12:13.865223
# Unit test for function dcc
def test_dcc():
    ## De-register 30/360 for our testing purpose:
    _ = DCCRegistry.find("30/360")
    DCCRegistry._buffer_main.pop("30/360")
    DCCRegistry._buffer_altn.pop("30/360")

    ## Create a day count fraction calculation function:
    @dcc("30/360", {"30/3", "30/3*"})
    def calculate_30360(start: Date, asof: Date, end: Date, freq: Union[int, Decimal]) -> Decimal:
        asof, end = asof or datetime.date.today(), end or asof or datetime.date.today()
        end_day, end_month, end_year = asof.day, asof.month, asof.year
        start_day, start_month, start

# Generated at 2022-06-24 01:12:22.204671
# Unit test for function dcc
def test_dcc():
    @dcc("A/A")
    def calculate_aa(start: datetime.date, asof: datetime.date, end: datetime.date, freq: Optional[Decimal] = None):
        ...

    @dcc("A/B")
    def calculate_ab(start: datetime.date, asof: datetime.date, end: datetime.date, freq: Optional[Decimal] = None):
        ...

    # Assertions:
    assert calculate_aa.__dcc.name == "A/A"
    assert calculate_ab.__dcc.name == "A/B"


#
# Test-case execution
#
if __name__ == "__main__":
    test_dcc()
    print("All tests passed!")

# Generated at 2022-06-24 01:12:28.544253
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal_ = Money(1000, Currencies.USD)
    rate_ = Decimal(1)
    start_ = Date(2014, 1, 1)
    asof_ = Date(2014, 4, 30)
    end_ = Date(2014, 7, 1)
    freq_ = Decimal(1)
    eom_ = None
    assert DCCRegistry.ACT_365.coupon(principal_, rate_, start_, asof_, end_, freq_, eom_) == Money(92.468, Currencies.USD)



# Generated at 2022-06-24 01:12:31.343629
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Unit test for method calculate_fraction of class DCC
    """
    start = datetime.date(2020,7,1)
    asof = datetime.date(2020,7,15)
    end = datetime.date(2021,7,1)
    freq = ONE
    print(DCC.calculate_fraction(start, asof, end, freq))

# Generated at 2022-06-24 01:12:34.923584
# Unit test for method coupon of class DCC
def test_DCC_coupon():

    assert DCC.coupon(Decimal(100),datetime.date(2017,1,1),datetime.date(2017,2,1),datetime.date(2017,3,1), 1, 15) == Decimal(0.27551020408163265)



# Generated at 2022-06-24 01:12:39.420672
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(  start=datetime.date(2020, 3,  1), end=datetime.date(2020, 5,  1)), 14)==round(Decimal('0.08333333333333'), 14)
    assert round(dcfc_30_e_360(  start=datetime.date(2020, 3, 31), end=datetime.date(2020, 5,  1)), 14)==round(Decimal('0.08333333333333'), 14)
    assert round(dcfc_30_e_360(  start=datetime.date(2020, 3, 31), end=datetime.date(2020, 5, 31)), 14)==round(Decimal('0.16666666666667'), 14)

# Generated at 2022-06-24 01:12:45.210173
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # setup
    dcc1 = DCC(name='test1', altnames={'name1', 'name2'}, currencies={'USD', 'EUR'}, calculate_fraction_method=ACF_30360)
    reg = DCCRegistryMachinery()
    # test
    assert reg.table == {}
    reg.register(dcc1)
    assert reg.table == {'test1': dcc1, 'name1': dcc1, 'name2': dcc1}
    assert reg.registry == [dcc1]
    # teardown
    pass


# Generated at 2022-06-24 01:12:49.339396
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2014,3,3),datetime.date(2014,3,3),datetime.date(2014,3,3)),14) == round(Decimal('0'),14)
    assert round(dcfc_nl_365(datetime.date(2014,3,3),datetime.date(2014,3,4),datetime.date(2014,3,3)),14) == round(Decimal('0'),14)
    assert round(dcfc_nl_365(datetime.date(2014,3,3),datetime.date(2014,3,10),datetime.date(2014,3,3)),14) == round(Decimal('0.08219178082192'),14)

# Generated at 2022-06-24 01:12:51.975453
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCCs.ACT_365[0].calculate_daily_fraction(datetime.date(2014, 1, 31), datetime.date(2014, 2, 1), datetime.date(2014, 2, 1)) == Decimal('0.027')
    

# Generated at 2022-06-24 01:12:58.172349
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():

    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof = datetime.date(2001, 2, 1), datetime.date(2001, 2, 29)


# Generated at 2022-06-24 01:13:04.183065
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ##########################################################################
    # 30/360 German
    ##########################################################################
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28),
                                    asof=datetime.date(2008, 2, 28),
                                    end=datetime.date(2008, 2, 28)), 9) == Decimal('0.166666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28),
                                    asof=datetime.date(2008, 2, 29),
                                    end=datetime.date(2008, 2, 29)), 9) == Decimal('0.169444444')

# Generated at 2022-06-24 01:13:09.874087
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(start=datetime.date(2007, 12, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_f(start=datetime.date(2007, 12, 28), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17260273972603')
    assert round(dcfc_act_365_f(start=datetime.date(2007, 10, 31), end=datetime.date(2008, 11, 30)), 14) == Decimal('1.08493150684932')

# Generated at 2022-06-24 01:13:14.274108
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 13) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 13) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 13) == Decimal('1.08196721311475')

# Generated at 2022-06-24 01:13:25.263089
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    "Test for function dcfc_nl_365"

    dcfc_nl_365(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 28), end = datetime.date(2008, 2, 28))
    dcfc_nl_365(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 29), end = datetime.date(2008, 2, 29))
    dcfc_nl_365(start = datetime.date(2007, 10, 31), asof = datetime.date(2008, 11, 30), end = datetime.date(2008, 11, 30))

# Generated at 2022-06-24 01:13:37.064522
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    # Import module
    import math

    # Define variables
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:13:43.604934
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    principal = Money.of(Currencies["USD"], Decimal("1000000"), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal("0.01")
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal("0.16942884946478")
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal("1694.29")
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal("0.00")

# Generated at 2022-06-24 01:13:54.282172
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    """
    Unit test fonction to test all methods of class DCCRegistryMachinery.

    >>> dcc = DCCRegistryMachinery()
    >>> type(dcc)
    <class 'srim.core.finance.dcc.DCCRegistryMachinery'>
    """
    pass


DCCRegistry = DCCRegistryMachinery()


# Generated at 2022-06-24 01:14:05.174303
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert round(dcc.interest(principal, rate, start, end, end).qty, 13) == Decimal('1694.2884946478')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0')

## Defines the DCC registry singleton:
D

# Generated at 2022-06-24 01:14:11.204808
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """
    Verifies the working of the dcfc_30_360_isda function.
    """
    assert dcfc_30_360_isda(start=datetime.date(2011, 3, 31), asof=datetime.date(2011, 6, 30), end=datetime.date(2011, 6, 30), freq=Decimal(3)) == Decimal("0.08333333333333")
    assert dcfc_30_360_isda(start=datetime.date(2011, 3, 30), asof=datetime.date(2011, 6, 30), end=datetime.date(2011, 6, 30), freq=Decimal(3)) == Decimal("0.08333333333333")

# Generated at 2022-06-24 01:14:18.813563
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert Money(52.5,"USD") == DCC("ACT/365 Fixed", {"ACT/365 Fixed"},
            _as_ccys({"USD", "SAR"}), act_365_fixed).coupon(Money(1000,"USD"),0.05,
            datetime.date(2014, 1, 1), datetime.date(2014, 12, 31), datetime.date(2015, 1, 1), 1)
    assert Money(53.05,"USD") == DCC("ACT/360", {"ACT/360"}, _as_ccys({"USD"}), act_360).coupon(Money(1000,"USD"),0.05,
            datetime.date(2014, 1, 1), datetime.date(2014, 12, 31), datetime.date(2015, 1, 1), 1)

# Generated at 2022-06-24 01:14:27.937736
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof))

# Generated at 2022-06-24 01:14:38.770304
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(start=datetime.date(2014, 3, 1),
                              asof=datetime.date(2014, 3, 2),
                              end=datetime.date(2014, 3, 2)) == dcfc_30_e_360(start=datetime.date(2014, 3, 1),
                                                                              asof=datetime.date(2014, 3, 2),
                                                                              end=datetime.date(2014, 3, 2))

# Generated at 2022-06-24 01:14:43.286910
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-24 01:14:47.390094
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    import datetime

    print('\nUnit test for function dcfc_30_360_us')

    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    #ex1_res = 0.16666666666667
    #ex2_res = 0.16944444444444
    #ex3

# Generated at 2022-06-24 01:14:56.903247
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """Unit test for function dcfc_30_360_us."""
    assert round(dcfc_30_360_us(start=datetime.date(2017, 3, 31), asof=datetime.date(2017, 4, 1), end=datetime.date(2017, 4, 1)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2017, 3, 31), asof=datetime.date(2017, 4, 28), end=datetime.date(2017, 4, 28)), 14) == Decimal('0.28333333333333')

# Generated at 2022-06-24 01:15:04.171537
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Create test data
    t_start = datetime.date(2017, 1, 1)
    t_asof = datetime.date(2017, 1, 3)
    t_end = datetime.date(2017, 1, 6)
    t_freq = Decimal(2)
    t_param1 = t_start
    t_param2 = t_asof
    t_param3 = t_end
    t_param4 = t_freq

    # Create expected data
    t_expected_fraction = Decimal(3/5)

    # Create actual data
    t_actual_fraction = DCCRegistry["ACT/360"].calculate_fraction(t_param1, t_param2, t_param3, t_param4)

    # Check if the interest rate is the same as expected


# Generated at 2022-06-24 01:15:14.211077
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc = DCC("Test", set(), set(), lambda *args: ONE)

    assert dcc.calculate_daily_fraction(
        datetime.date(2020, 3, 1),
        datetime.date(2020, 3, 31),
        datetime.date(2020, 3, 31),
    ) == ONE

    assert dcc.calculate_daily_fraction(
        datetime.date(2020, 3, 1),
        datetime.date(2020, 3, 3),
        datetime.date(2020, 3, 31),
    ) == Decimal("0.0606060606060606")


# Generated at 2022-06-24 01:15:23.150410
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863'))

# Generated at 2022-06-24 01:15:33.803179
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry.get_dcc('Act/360').calculate_fraction(datetime.date(2017,1,1), datetime.date(2017,1,1), datetime.date(2017,1,1)) == Decimal('0')
    assert DCCRegistry.get_dcc('Act/360').calculate_fraction(datetime.date(2017,1,1), datetime.date(2017,1,2), datetime.date(2017,1,2)) == Decimal('0.002777777777777778')
    assert DCCRegistry.get_dcc('Act/360').calculate_fraction(datetime.date(2017,1,2), datetime.date(2017,1,1), datetime.date(2017,1,1)) == Decimal('0')


# Generated at 2022-06-24 01:15:43.059250
# Unit test for function dcc
def test_dcc():
    @dcc("Test/Test", altnames={"TEST/TEST", "TEST/TEST-alt"}, ccys={"USD", "EUR"})
    def test_dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        ...

    assert test_dcfc == DCCRegistry.find("Test/Test").calculate_fraction_method
    assert test_dcfc == DCCRegistry.find("TEST/TEST").calculate_fraction_method
    assert test_dcfc == DCCRegistry.find("TEST/TEST-alt").calculate_fraction_method

    # Check the populations:
    assert len(DCCRegistry._buffer_main) == 1

# Generated at 2022-06-24 01:15:48.258026
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.17222222222222')

# Generated at 2022-06-24 01:15:56.935428
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    ## Create the new registry:
    registry = DCCRegistryMachinery()

    ## Check the is_registered method:
    assert not registry._is_registered("act/act")
    assert not registry._is_registered("act/360")
    assert not registry._is_registered("act/365")
    assert not registry._is_registered("30/360")

    ## Check the register method:
    registry.register(DCC("act/act", {"act/act-cf"}, {"USD"}))
    registry.register(DCC("act/360", {"act/360-cf"}, {"USD"}))
    registry.register(DCC("act/365", {"act/365-cf"}, {"USD"}))
    registry.register(DCC("30/360", {"30/360-cf"}, {"USD"}))

    ## Check the registry:
    assert registry

# Generated at 2022-06-24 01:16:04.006833
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCC(
        "MYACTUAL",
        {"myactual"},
        {"MYC"},
        lambda start, asof, end, freq: (end - start).days / 365,
    )
    registry = DCCRegistryMachinery()
    registry._buffer_main = {
        "MYACTUAL": dcc
    }
    registry._buffer_altn = {
        "myactual": dcc
    }
    # No exception is raised
    registry.register(dcc)


# Generated at 2022-06-24 01:16:14.513441
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)) == Decimal('0.16986301369863')
    assert dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29),datetime.date(2008, 2, 29)) == Decimal('0.17213114754098')
    assert dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30),datetime.date(2008, 11, 30)) == Decimal('1.08196721311475')

# Generated at 2022-06-24 01:16:21.628669
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')



# Generated at 2022-06-24 01:16:28.121258
# Unit test for function dcfc_act_365_l

# Generated at 2022-06-24 01:16:37.411608
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    with raises(TypeError, match="Day count convention 'Act/Act' is already registered"):
        DCCRegistry.register(DCC(name="Act/Act", altnames={"ACT/ACT", "ACTUAL/ACTUAL", "ACTUAL/365", "ACT/365"}, currencies={}, calculate_fraction_method=_method_act_act))
    with raises(TypeError, match="Day count convention 'Act/Act' is already registered"):
        DCCRegistry.register(DCC(name="Act/Act", altnames={"ACT/ACT", "ACTUAL/ACTUAL", "ACTUAL/365", "ACT/365"}, currencies={"TRY" }, calculate_fraction_method=_method_act_act))


# Generated at 2022-06-24 01:16:42.241980
# Unit test for constructor of class DCC
def test_DCC():
    # Test the DCC constructor
    DCC('SIA', {}, _as_ccys({}), lambda x, y, z, w: None)



# Generated at 2022-06-24 01:16:45.581901
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert 1 == 1



# Generated at 2022-06-24 01:16:51.236670
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=Decimal("2")), 14) == Decimal("0.26229508197")
test_dcfc_act_act_icma()



# Generated at 2022-06-24 01:16:59.363508
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find('act/act') == DCCRegistry.find('ACT/ACT')


DCCRegistry = DCCRegistryMachinery()
"""
The day count convention registry.
"""

# Registering the day count conventions:
## Act/Act:

# Generated at 2022-06-24 01:17:12.116464
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Test if "class DCCRegistryMachinery": the method find
    """
    # Create some test data
    ## Test 1
    name = "Act/Act"

# Generated at 2022-06-24 01:17:22.260290
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2014,1,1), asof=datetime.date(2014,12,31), end=datetime.date(2014,12,31)), 14) == Decimal('1.00000000000000')
    assert round(dcfc_act_365_l(start=datetime.date(2014,3,1), asof=datetime.date(2014,12,31), end=datetime.date(2014,12,31)), 14) == Decimal('0.90410958904110')

# Generated at 2022-06-24 01:17:25.674347
# Unit test for method interest of class DCC
def test_DCC_interest():

    # Set parameters
    principal = Money(principal=100, currency='USD')
    rate = 0.05
    start = Date(y=2020,m=1,d=1)
    asof = Date(y=2020,m=3,d=31)
    end = None
    freq = None
    # Get method output
    out = DCC.interest(self, principal, rate, start, asof, end, freq)
    # Get output from benchmark
    out_bf = Money(principal=2.08, currency='USD')
    # Assert output vs benchmark
    assert out == out_bf

# Generated at 2022-06-24 01:17:34.491353
# Unit test for constructor of class DCC
def test_DCC():
    # Create DCC instance
    DCC_instance = DCC("DCC", ["DCC", "DCC_30/360"], ['USD', 'GBP'], DCC.calculate_fraction)
    # Unit test for DCC_instance
    assert DCC_instance.name == "DCC"
    assert DCC_instance.altnames == {"DCC", "DCC_30/360"}
    assert DCC_instance.currencies == {Currencies["USD"], Currencies["GBP"]}
    assert DCC_instance.calculate_fraction_method == DCC.calculate_fraction


# Generated at 2022-06-24 01:17:45.034853
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-24 01:17:50.957562
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    last_pay = datetime.date(2015,12,15)
    p_principal = Money('3000', 'USD')
    p_rate = Decimal(5.5)
    p_start = datetime.date(2012, 12, 15)
    p_asof = datetime.date(2016,  1,  6)
    p_end = datetime.date(2016,  4,  6)
    p_freq = 2
    p_eom = 15
    result = DCC_1.coupon(p_principal,p_rate,p_start,p_asof,p_end,p_freq,p_eom)

# Generated at 2022-06-24 01:18:01.408891
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:18:10.158314
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    asof, start, end = datetime.date(2010, 1, 1), datetime.date(2010, 1, 1), datetime.date(2010, 1, 2)
    assert(dcfc_act_360(start=start, asof=asof, end=end) == 1 / 360)
    
    asof, start, end = datetime.date(2010, 1, 1), datetime.date(2010, 1, 1), datetime.date(2010, 1, 2)
    assert(dcfc_act_360(start=start, asof=asof, end=end) == 1 / 360)
    asof, start, end = datetime.date(2010, 1, 1), datetime.date(2010, 1, 1), datetime.date(2010, 1, 2)