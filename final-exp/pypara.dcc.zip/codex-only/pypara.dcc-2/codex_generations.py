

# Generated at 2022-06-24 01:08:11.027137
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert dcfc_30_360_us(start, asof, asof) == Decimal('0.16666666666666666666666666666666666666666')

# Generated at 2022-06-24 01:08:15.116468
# Unit test for function dcc
def test_dcc():
    @dcc("Act/360")
    def act360(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return (asof - start).days / 360

    if not isinstance(act360.__dcc, DCC):
        raise RuntimeError
    if act360.__dcc.name is not "Act/360":
        raise RuntimeError


# Generated at 2022-06-24 01:08:25.165893
# Unit test for function dcfc_30_360_isda

# Generated at 2022-06-24 01:08:35.441737
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    with open( 'ActA365_ActA.csv', 'r') as f:
        x = csv.reader(f, delimiter=',')
        next(x)  # Skip the header row.
        for row in x:
            start = datetime.date(int(row[0]), int(row[1]), int(row[2]))
            asof = datetime.date(int(row[3]), int(row[4]), int(row[5]))
            end = datetime.date(int(row[6]), int(row[7]), int(row[8]))
            assert(round(dcfc_act_365_a(start=start, asof=asof, end=end), 14) == Decimal(row[9]))
    print('test_dcfc_act_365_a passed')

# Generated at 2022-06-24 01:08:43.444023
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    dcc = DCC('ACT/365F', {'ACT/365F'}, _as_ccys({'USD'}), DCFCs['ACT/365F'])
    assert dcc.coupon(Money(100, Currencies['USD']), Decimal('0.03'), datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 3), Decimal('1')) == Money(Decimal('0.0109589041095890410958904109589'), Currencies['USD'])



# Generated at 2022-06-24 01:08:51.102960
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    from datetime import date
    from pyfin.dc import dcfc_30_e_plus_360
    assert round(dcfc_30_e_plus_360(start=date(2018, 6, 15),
                                    asof=date(2018, 7, 15),
                                    end=date(2018, 7, 15)), 14) == 0.08333333333333
    assert round(dcfc_30_e_plus_360(start=date(2018, 6, 15),
                                    asof=date(2018, 7, 16),
                                    end=date(2018, 7, 16)), 14) == Decimal('0.08333333333333')

# Generated at 2022-06-24 01:08:57.745578
# Unit test for function dcc
def test_dcc():
    @dcc("ACT/360", {"Actual/360", "Actual/Actual A/360"})
    def calculate_act_360(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Calculates the day count fraction based on Actual/360 convention.

        :param start: Start date.
        :param asof: As of date.
        :param end: End date.
        :return: Day count fraction.
        """
        ## Calculate the difference and return:
        return (asof - start).days / 360

    # Calculate the day count fraction:
    assert calculate_act_360(datetime.date(2007, 7, 1), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal

# Generated at 2022-06-24 01:09:01.562834
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    actual = DCCRegistry["ACT/365"].calculate_fraction(
        datetime.date(2016, 1, 1),
        datetime.date(2016, 12, 31),
        datetime.date(2016, 12, 31),
        Decimal(1)
    )

    expected = Decimal("1.00")

    assert actual == expected



# Generated at 2022-06-24 01:09:06.892556
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-24 01:09:18.791316
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2020, 5, 1), datetime.date(2020, 5, 1), datetime.date(2021, 5, 1)), 14) == Decimal('0.005479452054794')
    assert round(dcfc_act_365_a(datetime.date(2020, 5, 1), datetime.date(2020, 5, 1), datetime.date(2021, 5, 2)), 14) == Decimal('0.005479452054794')
    assert round(dcfc_act_365_a(datetime.date(2020, 5, 1), datetime.date(2020, 5, 1), datetime.date(2021, 5, 3)), 14) == Decimal('0.005479452054794')

# Generated at 2022-06-24 01:09:31.475259
# Unit test for function dcfc_30_360_isda

# Generated at 2022-06-24 01:09:40.745730
# Unit test for constructor of class DCC

# Generated at 2022-06-24 01:09:51.285918
# Unit test for method interest of class DCC
def test_DCC_interest():
    _p = 100000
    _r = 0.001
    _f = 0.5
    _st = datetime.date(2014, 1, 15)
    _a = datetime.date(2014, 1, 21)
    _e = datetime.date(2014, 7, 15)

    _C = DCC("DCC", set(), set(), lambda s, a, e, f: Decimal(1))

    _i = _C.interest(Money(_p, "USD"), _r, _st, _a, _e, _f)
    assert _i.amount == Decimal(100) and _i.currency == "USD"

    _i = _C.interest(Money(_p, "USD"), _r, _st, _a)

# Generated at 2022-06-24 01:09:59.529328
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    from .numpy_test_utils import numpy_assert
    test_cases = [
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), 0.16939890710383),
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), 0.17213114754098),
        (datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), 1.08196721311475),
        (datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), 1.32876712328767),
    ]
    numpy_assert('dcfc_act_365_l', test_cases, rtol=1e-8)


# Generated at 2022-06-24 01:10:02.511302
# Unit test for function dcc
def test_dcc():
    assert callable(dcc("Foo", ["Bar", "Baz"])), "dcc is a function"



# Generated at 2022-06-24 01:10:06.932431
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    test_result = round(dcfc_act_365_a(start=datetime.date(2008, 2, 1), asof=datetime.date(2009, 5, 31), end=datetime.date(2009, 5, 31)), 14)
    assert test_result == Decimal('1.32513661202186')
test_dcfc_act_365_a()


# Generated at 2022-06-24 01:10:12.981453
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:10:24.174142
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    start = datetime.date(2000,1,1)
    date = datetime.date(2020,1,1)
    end = datetime.date(2021,1,1)
    assert round(dcfc_act_365_f(start,date,end),14)==round(Decimal('20.00000000000000')/365,14)
    start = datetime.date(2020,12,31)
    date = datetime.date(2021,1,1)
    end = datetime.date(2021,2,2)
    assert round(dcfc_act_365_f(start,date,end),14)==round(Decimal('1.00000000000000')/365,14)
    start = datetime.date(2020,2,29)

# Generated at 2022-06-24 01:10:34.653660
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    test_instance = DCC("DCC",{'DCC'},{'USD','GBP','EUR','TRY','CHF','AUD','CNY','JPY','INR','GHS','NGN'},
        _actual_days_method)
    start_date = datetime.date(2011,7,15)
    end_date = datetime.date(2011,8,15)
    # normal case
    assert test_instance.calculate_fraction(start_date,datetime.date(2011,8,1),end_date,None) == Decimal('0.8333333333333333333333333333333')
    # asof date earlier than start date

# Generated at 2022-06-24 01:10:43.401511
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:10:46.927831
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(start=datetime.date(2010, 4, 2), asof=datetime.date(2010, 7, 2),end=datetime.date(2010, 7, 2)), 14) == Decimal('0.18356164383562')



# Generated at 2022-06-24 01:10:56.262890
# Unit test for method interest of class DCC
def test_DCC_interest():
    print('Interest Test')

# Generated at 2022-06-24 01:11:04.645720
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:11:12.394924
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from . import DayCountConventions as DCC
    from .commons.zeitgeist import Date
    from .monetary import Money
    from .currencies import Currency
    print("DCC(start = datetime.date(2019, 12, 20), end = datetime.date(2020, 12, 20), asof = datetime.date(2020, 12, 20), freq = 1) = ", 
    DCC.ACT_360(start=Date(year=2019, month=12, day=20), end=Date(year=2020, month=12, day=20), asof=Date(year=2020, month=12, day=20), freq=1))

# Generated at 2022-06-24 01:11:23.945371
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert dcfc_act_365_f(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == 1.08493150684932
    assert dcfc_act_365_f(datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), datetime.date(2009, 5, 31)) == 1.32876712328767
    assert dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == 0.16986301369863

# Generated at 2022-06-24 01:11:29.698265
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    import doctest
    doctest.testmod(verbose=False, optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 01:11:38.560747
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 10, 1), datetime.date(2020, 3, 2), datetime.date(2020, 9, 1)
    round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_end), 10)


# Generated at 2022-06-24 01:11:49.305376
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    start = datetime.date(2014, 4, 1)
    asof = datetime.date(2014, 10, 1)
    end = datetime.date(2015, 4, 1)
    freq = Decimal(1)
    eom = None
    expected = Money(12.50000, 'USD')
    actual = DCC_ACT_360.coupon(Money(100, 'USD'), Decimal(0.12), start, asof, end, freq, eom)
    assert expected == actual

    start = datetime.date(2014, 4, 1)
    asof = datetime.date(2014, 10, 1)
    end = datetime.date(2015, 4, 1)
    freq = Decimal(1)
    eom = 1
    expected = Money(12.50000, 'USD')

# Generated at 2022-06-24 01:11:57.828966
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-24 01:12:01.273378
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2008, 5, 30), asof=datetime.date(2008, 6, 30),
                                end=datetime.date(2008, 6, 30)), 14) == Decimal('0.083333333333333')



# Generated at 2022-06-24 01:12:07.254002
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    """
    Function to test function dcfc_act_365_a(start, asof, end)
    """

# Generated at 2022-06-24 01:12:12.164482
# Unit test for function dcc
def test_dcc():
    """
    Unit test for function dcc
    """
    @dcc("NewDcc", ccys={Currencies["USD"]})
    def f(s: Date, a: Date, e: Date, f: Optional[Decimal]) -> Decimal:
        """ Dcc sample function """
        return Decimal(1)

    @dcc("DccSample")
    def g(s: Date, a: Date, e: Date, f: Optional[Decimal]) -> Decimal:
        """ Dcc sample function """
        return Decimal(1)

    @dcc("DccSample")
    def h(s: Date, a: Date, e: Date, f: Optional[Decimal]) -> Decimal:
        """ Dcc sample function """
        return Decimal(1)


# Generated at 2022-06-24 01:12:22.001030
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc1 = DCC('ACT/ACT', {'actact'}, {Currencies["USD"]}, calculate_act_act_fraction)
    DCCRegistry.register(dcc1)
    assert dcc1 == DCCRegistry.find('ACT/ACT')
    assert dcc1 == DCCRegistry.find('actact')
    assert dcc1 == DCCRegistry.find('actAct')
    assert dcc1 == DCCRegistry.find('ACTACT')
    assert None == DCCRegistry.find('actact2')


# Unit tests for the DCC Registry.
DCCRegistry = DCCRegistryMachinery()


# Generated at 2022-06-24 01:12:33.462254
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 9, 10), asof=datetime.date(2020, 3, 2), end=datetime.date(2020, 9, 10)), 10) == Decimal('0.5')

# Generated at 2022-06-24 01:12:37.961011
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(datetime.date(2011, 8, 31), datetime.date(2012, 2, 28), datetime.date(2012, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(datetime.date(2011, 8, 31), datetime.date(2012, 2, 29), datetime.date(2012, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_360(datetime.date(2011, 8, 31), datetime.date(2012, 2, 29), datetime.date(2012, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-24 01:12:45.605266
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .commons.zeitgeist import Date
    
    dcc = DCCRegistry['ACT/360']
    start, asof, end = Date(2015, 1, 1), Date(2015, 12, 31), Date(2016, 1, 1)
    assert dcc.calculate_daily_fraction(start, asof, end) == Decimal('-0.0027777777777777777777777778')

    dcc = DCCRegistry['ACT/365']
    start, asof, end = Date(2015, 1, 1), Date(2015, 12, 31), Date(2016, 1, 1)
    assert dcc.calculate_daily_fraction(start, asof, end) == Decimal('-0.0027397260273972602739726027')

    dcc

# Generated at 2022-06-24 01:12:55.276048
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:13:00.546785
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:13:05.178360
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("act/act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("ACT/ACT") is not None
    assert DCCRegistry.find("Act/Act ") is not None
    assert DCCRegistry.find(" Act/Act") is not None
    assert DCCRegistry.find(" Act/Act ") is not None

# Generated at 2022-06-24 01:13:11.080414
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 2, 29)), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008, 11, 30)), 14) == Decimal('1.10000000000000')

# Generated at 2022-06-24 01:13:23.044473
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    import pytest
    from datetime import date
    from money import Money
    from numbers import Decimal
    from v3_0.shared.factory import Currencies
    from v3_0.shared.models.day_count_convention import DCC

    principal = Money.of(Currencies["USD"], Decimal(1000000), date.today())
    start = date(2007, 12, 28)
    end = date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-24 01:13:33.001438
# Unit test for method coupon of class DCC
def test_DCC_coupon():

    pass
    # principal = Money("1000.00")
    # rate = Decimal("0.05")
    # start = Date("2016-02-28")
    # asof = Date("2016-05-31")
    # end = Date("2017-02-28")
    # freq = 2
    # eom = 28
    #
    #
    #
    # assert DCC("",{},"",{}).coupon(principal, rate, start, asof, end, freq, eom) == Money("25.00000000")


DCCs = DCCRegistry()
"""
Defines the registry for day count conventions.
"""



# Generated at 2022-06-24 01:13:37.975995
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Unit test for dcfc_act_act.
    """
    ## ex1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')
    # ex2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-24 01:13:46.508848
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    import sys
    import os
    import datetime
    # Add parent directory to sys path to import app_config
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    import dcfc_30_360_german


    assert dcfc_30_360_german.dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:13:51.158349
# Unit test for function dcc
def test_dcc():
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("ACT/360") is not None
    assert DCCRegistry.find("Actual") is None



# Generated at 2022-06-24 01:13:59.242201
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Check if _construct_date raises value error
    with pytest.raises(ValueError):
        _construct_date(0, 1, 1)
    assert Decimal(DCCs["1/1"].calculate_daily_fraction(_construct_date(2018, 10, 10), _construct_date(2018, 10, 11), _construct_date(2018, 10, 12))) == Decimal('0.0000')
    assert Decimal(DCCs["1/1"].calculate_daily_fraction(_construct_date(2018, 10, 10), _construct_date(2018, 10, 11), _construct_date(2019, 10, 12))) == Decimal('1.0000')

# Generated at 2022-06-24 01:14:03.703571
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Test the calculate_fraction method on a few positive edge cases
    """
    # Set up some dates for our DCCs
    start_date = Date(2018, 1, 1)
    asof_date = Date(2018, 2, 28)
    end_date = Date(2018, 4, 30)

    # Set up a few rates
    rate = Decimal(0.06)
    freq = Decimal(2)

    # Set up a few money objects
    principal = Money(20, "USD")
    principal2 = Money(50, "USD")

    # Set up a few DCC objects

# Generated at 2022-06-24 01:14:13.736432
# Unit test for constructor of class DCC
def test_DCC():
    jpy = Currencies.get("JPY")
    dcc = DCC("name", {"test"}, {jpy}, lambda a, b, c, d: None)
    assert dcc.name == "name"
    assert dcc.altnames == {"test"}
    assert dcc.currencies == {jpy}
    assert dcc.calculate_fraction_method(None, None, None, None) == None
    assert dcc.interest(Money(100, "USD"), Decimal("0.1"), None, None, None, None) == Money(10, "USD")
    assert dcc.coupon(Money(100, "USD"), Decimal("0.1"), None, None, None, 1, None) == Money(50, "USD")



# Generated at 2022-06-24 01:14:20.891355
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10)==Decimal('0.5245901639')



# Generated at 2022-06-24 01:14:30.051597
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    ## Initialize:
    dcc = DCC(name="Act/Act", altnames={}, currencies={}, calculate_fraction_method=lambda *_: ZERO)

    ## Set:
    DCCRegistry.register(dcc)

    ## Assert:
    assert DCCRegistry._find_strict("Act/Act") == dcc.__dict__
    assert DCCRegistry._find_strict("ACT/ACT") == dcc.__dict__
    assert DCCRegistry._find_strict("act/act") == dcc.__dict__

    ## Cleanup:
    DCCRegistry._buffer_main = {}
    DCCRegistry._buffer_altn = {}

# Generated at 2022-06-24 01:14:34.437218
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_360_us(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')
    assert dcfc

# Generated at 2022-06-24 01:14:40.039818
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    for test_case in _all_tests:
        result = dcfc_act_act(start=test_case["start"], asof=test_case["asof"], end=test_case["end"], freq=test_case["freq"])
        assert result == Decimal(test_case["act_act"])


# Generated at 2022-06-24 01:14:51.493588
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Tests function dcfc_act_act for bugs.

    :return: None.
    """
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    asof = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest

# Generated at 2022-06-24 01:14:58.242040
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert dcfc_act_365_l(Date(1,1,1), Date(1,2,1), Date(1,2,1)) == 1/365
    assert dcfc_act_365_l(Date(4,4,4), Date(4,4,4), Date(4,4,4)) == 1/366


# Generated at 2022-06-24 01:15:05.334581
# Unit test for method interest of class DCC
def test_DCC_interest():
    dcc = DCC("", set(), set(), lambda x, y, z, w: Decimal(0))
    assert dcc.interest(Money(0, "EUR"), Decimal(0.0), Date(datetime.date.today()), Date(datetime.date.today())) == Money(0, "EUR")
    assert dcc.interest(Money(1, "EUR"), Decimal(0.0), Date(datetime.date.today()), Date(datetime.date.today())) == Money(0, "EUR")
    assert dcc.interest(Money(0, "EUR"), Decimal(0.0), Date(datetime.date.today()), Date(datetime.date.today()), Date(datetime.date.today())) == Money(0, "EUR")
    assert dcc.interest

# Generated at 2022-06-24 01:15:15.050518
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-24 01:15:26.124676
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-24 01:15:29.007369
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = Date(14,7,2020)
    asof = Date(14,7,2020)
    end = Date(22,7,2020)
    freq = Decimal(3)
    assert test_DCC.calculate_fraction(start, asof, end, freq) == ONE

#Unit test for method calculate_daily_fraction of class DCC


# Generated at 2022-06-24 01:15:39.885657
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    """
    Tests the dcfc_act_360 function with the example given by OpenGamma.
    """
    assert round(dcfc_act_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')



# Generated at 2022-06-24 01:15:51.108592
# Unit test for function dcfc_nl_365

# Generated at 2022-06-24 01:15:58.889091
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:16:04.208341
# Unit test for function dcc
def test_dcc():
    """
    Tests the dcc decorator.
    """

    ## Import numpy and pandas:
    import numpy as np
    import pandas as pd

    ## Define a test function:
    @dcc("DemoAct/Act", altnames={"Act/Act", "DemoAct/DemoAct"})
    def dcfc_dcc_demo_act_act(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Calculates day count fraction for 'Act/Act' DCC.
        """
        ## Calculate the year fraction with Act/Act:
        return np.busday_count(start, asof) / np.busday_count(start, end)

    ## Import the math module:
    import math

   

# Generated at 2022-06-24 01:16:14.693006
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:16:23.883855
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==Decimal('0.16986301369863')

# Generated at 2022-06-24 01:16:34.203105
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')
    return True


DCCRegistry = DCCRegistryMachinery()
DCCRegistry

# Generated at 2022-06-24 01:16:39.933629
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 7) == 0.1666667
    
    assert round(dcfc_30_e_360(start=datetime.date(2019, 1, 31), asof=datetime.date(2019, 2, 28), end=datetime.date(2019, 2, 28)), 7) == 0.0833333
    
    assert round(dcfc_30_e_360(start=datetime.date(2019, 1, 31), asof=datetime.date(2019, 2, 28), end=datetime.date(2019, 3, 31)), 7) == 0.4166667
    #print(d

# Generated at 2022-06-24 01:16:42.528979
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2020, 2, 13), datetime.date(2020, 4, 18), datetime.date(2021, 2, 13),1),10) == Decimal('0.4081967213')



# Generated at 2022-06-24 01:16:51.037435
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # the following test is written by using an example given in QuantLib documentation
    #https://quantlib.org/docs/python/daycounters.html
    # Example test:
    start = datetime.date(2018, 3, 31)
    asof = datetime.date(2018, 4, 16)
    end = datetime.date(2018, 6, 15)
    dcc = DCCRegistry['Actual/365']
    assert (dcc.calculate_daily_fraction(start, asof, end) == Decimal(0.043835616))



# Generated at 2022-06-24 01:17:02.081174
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert(round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383'))

# Generated at 2022-06-24 01:17:13.394824
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    ..  container:: example

        >>> import datetime
        >>> date = datetime.datetime(2019, 12, 31)
        >>> date1 = datetime.datetime(2020, 3, 31)
        >>> date2 = datetime.datetime(2020, 6, 30)
        >>> date3 = datetime.datetime(2020, 12, 31)
        >>> from abjad.money import Money
        >>> money = Money(1000, 'USD')
        >>> dcc = abjad.DCC('30')
        >>> dcc.coupon(money, 0.02, date, date1, date3, 2)
        Money(200, 'USD')
        >>> dcc.coupon(money, 0.02, date, date2, date3, 2)
        Money(100, 'USD')

    """
    pass



# Generated at 2022-06-24 01:17:17.238432
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Unit test for method coupon of class DCC
    """
    pass


# Generated at 2022-06-24 01:17:24.903634
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    asof_date = datetime.datetime.strptime("Oct 2017", "%b %Y").date()
    start_date = datetime.datetime.strptime("Jan 2016", "%b %Y").date()
    end_date = datetime.datetime.strptime("Jan 2017", "%b %Y").date()
    days = (end_date - start_date).days
    dcfc_30_e_360(start=start_date, asof=asof_date, end=end_date, freq=None)
    return True


# Generated at 2022-06-24 01:17:31.077709
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)

    assert(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16986301369863'))


# Generated at 2022-06-24 01:17:43.470310
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(start=datetime.date(2019,1,30),asof=datetime.date(2019,2,28),end=datetime.date(2019,2,28))==Decimal('0.08333333333333')
    assert dcfc_30_e_plus_360(start=datetime.date(2019,2,28),asof=datetime.date(2019,3,28),end=datetime.date(2019,3,28))==Decimal('0.08333333333333')
    assert dcfc_30_e_plus_360(start=datetime.date(2019,2,28),asof=datetime.date(2019,3,31),end=datetime.date(2019,3,31))==Decimal('0.08611111111111')


# Generated at 2022-06-24 01:17:45.738226
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    import pytest
    assert DCCRegistry.find("Act/Act") is not None



# Generated at 2022-06-24 01:17:57.090880
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(start = datetime.date(2012,12,31), asof = datetime.date(2013,1,1), end = datetime.date(2013,1,30)) == Decimal('1.000000000000000')
    assert dcfc_30_e_plus_360(start = datetime.date(2013,1,31), asof = datetime.date(2013,2,1), end = datetime.date(2013,2,28)) == Decimal('0.966666666666666')
    assert dcfc_30_e_plus_360(start = datetime.date(2013,1,28), asof = datetime.date(2013,2,1), end = datetime.date(2013,2,28)) == Decimal('1.000000000000000')
    assert dcfc

# Generated at 2022-06-24 01:18:05.909900
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    start = datetime.date(2012,12,15)
    asof = datetime.date(2015,1,6)
    end = datetime.date(2015,12,15)
    freq = 2
    eom = None
    principal = Money.from_amount(100)
    rate = Decimal(0.1)
    assert DCCRegistry.get("30U/360").coupon(principal, rate, start, asof, end, freq, eom) == Money.from_amount(7.9167)
