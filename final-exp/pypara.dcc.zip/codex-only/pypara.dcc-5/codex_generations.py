

# Generated at 2022-06-24 01:08:15.380375
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    '''
    function call: dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof)
    test data: ex1_start=datetime.date(2007, 12, 28), ex1_asof=datetime.date(2008, 2, 28)
    '''
    ex1_start=datetime.date(2007, 12, 28)
    ex1_asof=datetime.date(2008, 2, 28)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:08:25.403822
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies import Currencies
    from .monetary import Money
    import datetime
    ## Setup the test
    dcc = DCC(name='AFB',
              altnames={'ACT/360', 'ACT/360'},
              currencies={Currencies['CHF']},
              calculate_fraction_method=360)
    principal = Money(100, 'CHF')
    start = datetime.date(2005, 1, 1)
    asof = datetime.date(2005, 1, 1)
    end = datetime.date(2005, 1, 15)
    freq = 1
    ## Run the test
    actual = dcc.calculate_daily_fraction(start, asof, end, freq)
    ## Compare the actual with the expected

# Generated at 2022-06-24 01:08:35.497686
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:08:42.669731
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    ## Arrange ##
    saida = Decimal('0.33333333333333333333')
    bw = DCC('bw',set(),set(),_bus_252)

    ## Act ##
    resultado = bw.calculate_daily_fraction(datetime.date(2020,1,1),datetime.date(2020,1,3),datetime.date(2020,1,4))

    ## Assert ##
    assert resultado == saida




# Generated at 2022-06-24 01:08:53.640874
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    from math import isclose
    from .money import Money
    from .samples import sample_DCC
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert isclose(dcc.calculate_fraction(start, end, end), Decimal('0.16942884946478'))
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')

# Generated at 2022-06-24 01:09:02.942098
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-24 01:09:07.933126
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Test method find(name: str) -> Optional[DCC] with the following cases:

    * Case 1: Test if the method finds the standard day count convention for US dollars, Act/Act.

    * Case 2: Test if the method finds the alternative day count convention for US dollars, Act/Act.

    * Case 3: Test if the method finds the standard day count convention for US dollars, 30/360.

    * Case 4: Test if the method finds the standard day count convention for US dollars, 30E/360.

    * Case 5: Test if the method finds the standard day count convention for US dollars, 30U/360.

    * Case 6: Test if the method finds the standard day count convention for US dollars, 30/360 ISDA.
    """
    ## Case 1: Test if the method finds the standard day count convention for US dollars, Act/Act:


# Generated at 2022-06-24 01:09:15.138646
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Check the calculate_daily_fraction method of DCC for 1 case
    """
    assert DCC(name='Test', altnames=set(), currencies=set(), calculate_fraction_method=_actual_360_.calculate_fraction_method).calculate_daily_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 2)) == Decimal('0.002777777777777778')



# Generated at 2022-06-24 01:09:20.726283
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    """
    Tries to build a DCCRegistryMachinery object.
    """
    ## Construct a DCCRegistryMachinery object
    ## The constructor should not raise any exception.
    aInstance = DCCRegistryMachinery()


DCCRegistry = DCCRegistryMachinery()



# Generated at 2022-06-24 01:09:32.942119
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    print('Testing dcfc_30_360_isda...', end='')
    assert(isclose(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)),0.16666666666667))
    assert(isclose(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)),0.16944444444444))

# Generated at 2022-06-24 01:09:40.749311
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.17222222222222')

# Generated at 2022-06-24 01:09:45.413259
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), dat

# Generated at 2022-06-24 01:09:56.210022
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    start = datetime.date(2008, 10, 1)
    asof  = datetime.date(2008, 10, 31)
    assert dcfc_30_360_us(start=start, asof=asof, end=asof) == Decimal('0.083333333333333')

    start = datetime.date(2008, 10, 1)
    asof  = datetime.date(2009, 10, 1)
    assert dcfc_30_360_us(start=start, asof=asof, end=asof) == Decimal('1.0')

    start = datetime.date(2008, 10, 1)
    asof  = datetime.date(2009, 10, 2)
    assert dcfc_30_360_us(start=start, asof=asof, end=asof)

# Generated at 2022-06-24 01:10:02.062723
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc1 = DCC("Act/Act", {"Actual/Actual"}, {"USD"}, _calculate_fraction_act_act)
    dcc2 = DCC("Act/Act", {"Actual/Actual"}, {"USD"}, _calculate_fraction_act_act)
    r = DCCRegistryMachinery()
    r.register(dcc1)

    # Should raise TypeError:
    with pytest.raises(TypeError) as excinfo:
        r.register(dcc2)



# Generated at 2022-06-24 01:10:12.454869
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """
    This function performs unit test for function dcfc_30_360_isda.
    """
    ## Initialize test data set

# Generated at 2022-06-24 01:10:23.666675
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1, ex2, ex3, ex4 = datetime.date(2007,12, 28),datetime.date(2008,2,28),datetime.date(2007, 10, 31),datetime.date(2008,11, 30)
    ex5, ex6, ex7, ex8 = datetime.date(2007,2, 28),datetime.date(2008,12,31),datetime.date(2007, 3, 31),datetime.date(2008,3, 1)
    ex9, ex10, ex11, ex12 = datetime.date(2007,2, 28), datetime.date(2008,3,1), datetime.date(2007, 3, 31), datetime.date(2007, 5, 31)

    assert round(dcfc_act_360(ex1,ex2,ex2),14) == round

# Generated at 2022-06-24 01:10:34.565279
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:10:42.006156
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(ex1_start, ex1_asof, ex1_asof), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(ex2_start, ex2_asof, ex2_asof), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(ex3_start, ex3_asof, ex3_asof), 14) == Decimal('1.08196721311475')
    assert round(dcfc_act_365_l(ex4_start, ex4_asof, ex4_asof), 14) == Decimal('1.32876712328767')

# Generated at 2022-06-24 01:10:52.315684
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc = DCCRegistry.find("1/1")
    assert dcc.calculate_fraction(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31), datetime.date(2020, 1, 31)) == Decimal(1)
    assert dcc.calculate_fraction(datetime.date(2020, 1, 1), datetime.date(2020, 2, 29), datetime.date(2020, 2, 29)) == Decimal(1)
    assert dcc.calculate_fraction(datetime.date(2019, 1, 1), datetime.date(2019, 2, 28), datetime.date(2019, 2, 28)) == Decimal(1)

# Generated at 2022-06-24 01:10:58.786048
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from datetime import date
    from .currencies import Currency
    try:
        usd = Currency["USD"]
        frac = DCCRegistry[usd].calculate_daily_fraction(date(2019, 1, 1), date(2019, 1, 2), date(2020, 1, 1), 1)
        assert frac == 1 / 365
        frac = DCCRegistry[usd].calculate_daily_fraction(date(2019, 1, 1), date(2020, 1, 1), date(2020, 1, 1), 1)
        assert frac == 0
    except Exception as ex:
        print(ex.message)
        raise Exception("Unit test for method calculate_daily_fraction of class DCC failed.")


#: Defines a registry for day count conventions.

# Generated at 2022-06-24 01:11:04.730668
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():

    # Test input
    start = datetime.date(2019,4,4)
    asof = datetime.date(2019,4,4)
    end = datetime.date(2019,4,4)
    freq = Decimal(2)
    # 
    dcc = DCC('ACT/ACT', set(), set(), lambda strt, aso, end, freq: Decimal(0))
    dcc.calculate_fraction(start, asof, end, freq)


# Generated at 2022-06-24 01:11:09.247299
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dcc_registry = DCCRegistryMachinery()
    dcc_registry.register(DCC("Act/Act", {"Act/360"}, {Currencies["USD"]}, method_act_act_dcf))
    dcc_registry.register(DCC("Act/Act", {"Act/360"}, {Currencies["EUR"]}, method_act_act_dcf))
    assert dcc_registry._find_strict("Act/Act") == DCC("Act/Act", {"Act/360"}, {Currencies["USD"]}, method_act_act_dcf)
    assert dcc_registry.find("Act/Act") == DCC("Act/Act", {"Act/360"}, {Currencies["USD"]}, method_act_act_dcf)
    assert dcc_registry.find("Act/360") == D

# Generated at 2022-06-24 01:11:15.167448
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:11:17.730920
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
test_dcfc_act_365_l()



# Generated at 2022-06-24 01:11:27.757128
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 12, 30)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 12, 30)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 12, 30)), 14) == Decimal

# Generated at 2022-06-24 01:11:34.515508
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    obj = DCCRegistryMachinery()
    assert obj.find('Act/Act') == DCC(name='Act/Act', altnames={'Actual/Actual', 'Act/Act', 'Actual/Actual ISDA'}, currencies={}, calculate_fraction_method=_act_act)
    assert obj.find('30/360') == DCC(name='30/360', altnames={'30/360', '30E/360', '30U/360', '30/360 ISDA', '30/360 PS', '30/360 SIA', '30/360 US', '30E/360 ISDA'}, currencies={Currencies['USD']}, calculate_fraction_method=_thirty_360)

# Generated at 2022-06-24 01:11:46.828617
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .currencies import Currencies
    from .monetary.money import Money

    # Create a DCC object
    act_dcc = DCC(
        name='act/360',
        currencies={Currencies['USD'], Currencies['EUR'], Currencies['CAD'], Currencies['JPY']},
        altnames={'act/360', 'act/act', 'act/365', 'act/365', 'act/365l', 'act/365f'},
        calculate_fraction_method=calculate_act_360
    )
    start = Date(2008, 7, 7)
    asof = Date(2015, 10, 6)
    end = Date(2017, 8, 8)
    freq = 4

# Generated at 2022-06-24 01:11:55.757768
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from nose.tools import with_setup

    def setup_func():
        import random
        import datetime
        global principal, rate, start, asof, end, freq, eom
        principal = random.random()*100 
        rate = random.random()
        start = datetime.date(2014, 1, 1)
        asof = datetime.date(2015, 12, 31)
        end = datetime.date(2017, 1, 1)
        freq = 1
        eom = 15
        
    @with_setup(setup_func)
    def test_DCC_coupon_1():
        global principal, rate, start, asof, end, freq, eom

# Generated at 2022-06-24 01:12:03.859472
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28),end=datetime.date(2008, 2, 28)), 14)==Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29),end=datetime.date(2008, 2, 29)), 14)==Decimal('0.16986301369863')

# Generated at 2022-06-24 01:12:13.387011
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .market import Rates, Rate
    from .market.curves import CurveBuilder

    start = datetime.date(2017, 4, 21)
    end = datetime.date(2019, 4, 21)
    asof = datetime.date(2018, 4, 21)
    principal = Money(ONE, Currencies.USD)


# Generated at 2022-06-24 01:12:23.932275
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Tests the coupon method of the DCC class.
    """
    # Function: calculate_fraction_method for DCC
    def calculate_fraction_method(self, start, asof, end, freq):
        """
        Calculates the day count fraction based on the underlying methodology after performing some general checks.
        """
        return Decimal(1)
    # Function: interest for DCC
    def interest(self, principal, rate, start, asof, end, freq):
        return Decimal(0.01)
    # Test begin
    dcc = DCC('string', {'string'}, {Currencies['USD']}, calculate_fraction_method)
    dcc.interest = interest

# Generated at 2022-06-24 01:12:34.954331
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:12:43.700545
# Unit test for function dcc
def test_dcc():
    @dcc("Act/Act")
    def _dcfc_act_act(*args, **kwargs):
        pass

    @dcc("Act/Act", {"AAA", "Actual/Actual"})
    def _dcfc_act_act_alt(*args, **kwargs):
        pass

    @dcc("Act/Act", ccys={Currencies["USD"], Currencies["GBP"]})
    def _dcfc_act_act_cur(*args, **kwargs):
        pass

    ## Actual/Actual:
    dcc = DCCRegistry.find("Actual/Actual")
    assert dcc == DCCRegistry.find("Act/Act")
    assert dcc == DCCRegistry.find("ActualActual")

# Generated at 2022-06-24 01:12:54.465756
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(_get_dcfc("30E/360")("1980-01-01", "1980-01-31"), 14) == Decimal("0.08333333333333")
    assert round(_get_dcfc("30E/360")("1980-01-01", "1980-01-30"), 14) == Decimal("0.08333333333333")
    assert round(_get_dcfc("30E/360")("1980-01-01", "1980-01-29"), 14) == Decimal("0.07777777777778")
    assert round(_get_dcfc("30E/360")("1980-01-31", "1980-02-29"), 14) == Decimal("0.08333333333333")

# Generated at 2022-06-24 01:12:59.884566
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:13:04.105305
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2019, 3, 2), datetime.date(2019, 9, 11),datetime.date(2019, 9, 11)),10) == round(Decimal('0.5246575342'),10)



# Generated at 2022-06-24 01:13:14.410935
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    This unit test is for class DCC and its method calculate_daily_fraction.
    """
    # Get sample data
    name = "Actual/Actual ICMA"
    altnames = {"Act/Act ICMA", "Actual/Actual ICMA", "Actual/Actual", "Actual/365", "Act/365"}
    currencies = {"CAD", "CHF", "CNY", "DEM", "GBP", "JPY", "USD", "TRY", "BRL", "BGN"}
    calculate_fraction_method = lambda start, asof, end, freq: ONE if start == asof else ZERO

    # Create the DCC
    dcc = DCC(name, altnames, currencies, calculate_fraction_method)

    # Test for normal input

# Generated at 2022-06-24 01:13:18.556996
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof = datetime.date(2007, 1, 31), datetime.date(2007, 2, 28)

# Generated at 2022-06-24 01:13:30.964949
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 28), end = datetime.date(2008, 2, 28)) == 0.166666666666667
    assert dcfc_30_360_isda(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 29), end = datetime.date(2008, 2, 29)) == 0.169444444444444
    assert dcfc_30_360_isda(start = datetime.date(2007, 10, 31), asof = datetime.date(2008, 11, 30), end = datetime.date(2008, 11, 30)) == 1.0833333333333333
    assert dcfc_30_360_isda

# Generated at 2022-06-24 01:13:40.165505
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:13:49.369290
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    # This is the example from the ISDA documentation
    start = datetime.date(2019, 9, 23)
    asof = datetime.date(2020, 9, 23)
    #print(_get_actual_day_count(start, asof))
    compare = dcfc_act_365_l(start, asof, asof)
    test = Decimal('1.000000')
    if compare == test:
        print("PASS")
    else:
        print("FAIL")


# Generated at 2022-06-24 01:13:53.716990
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    """
    Unit test for function dcfc_act_365_l
    """
    print("Test dcfc_act_365_l")
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:13:59.447161
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """ Test that the dcfc_30_360_us function works. """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)


# Generated at 2022-06-24 01:14:09.686640
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2019, 1, 1), datetime.date(2019, 11, 30)
    ex2_start, ex2_asof = datetime.date(2019, 1, 1), datetime.date(2020, 11, 30)
    ex3_start, ex3_asof = datetime.date(2019, 1, 1), datetime.date(2021, 11, 30)
    round(dcfc_nl_365(start = ex1_start, asof = ex1_asof, end = ex1_asof), 14) == Decimal('0.972602739726027')
    round(dcfc_nl_365(start = ex2_start, asof = ex2_asof, end = ex2_asof), 14) == Decimal

# Generated at 2022-06-24 01:14:14.379880
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    test = Assert(TEST_SAMPLES)
    test.assertTrue(dcfc_nl_365(datetime.date(2019, 7, 1),datetime.date(2019, 7, 5),datetime.date(2019, 7, 5)) == 0.10958904109589)
    test.assertTrue(dcfc_nl_365(datetime.date(2019, 2, 28),datetime.date(2019, 3, 5),datetime.date(2019, 3, 5)) == 0.17260273972603)
    test.assertTrue(dcfc_nl_365(datetime.date(2019, 3, 1),datetime.date(2019, 3, 12),datetime.date(2019, 3, 12)) == 0.068493150684932)

# Generated at 2022-06-24 01:14:22.468139
# Unit test for function dcc
def test_dcc():
    from nose.tools import assert_true
    from types import FunctionType
    from pymonies import currencies, Money, Currencies
    from .dcc import (
        dcc,
        money_div,
        date_diff,
        date_diff_30_360,
        date_diff_act_act,
        date_diff_act_360,
        date_diff_act_365,
        date_diff_act_365_exact,
        date_diff_act_365_isda,
        date_diff_act_365_fixed
    )
    # Test dcc
    assert_true(isinstance(dcc, FunctionType))

# Generated at 2022-06-24 01:14:30.273863
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(
        start=datetime.date(2003, 4, 30), asof=datetime.date(2003, 11, 28), end=datetime.date(2003, 11, 28)), 14) \
        == Decimal('0.26111111111111')
    assert round(dcfc_30_360_isda(
        start=datetime.date(2004, 4, 28), asof=datetime.date(2004, 11, 30), end=datetime.date(2004, 11, 30)), 14) \
        == Decimal('0.26111111111111')

# Generated at 2022-06-24 01:14:36.999702
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    """Unit test for function dcfc_act_365_l"""
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:14:41.912863
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:14:53.864431
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    from numbers import Decimal
    from datetime import date
    from functools import partial
    import calendar
    import datetime
    from datetime import datetime
    from datetime import timedelta
    from datetime import time
    from pytz import timezone
    from pytz import UTC
    from fractions import Fraction
    from typing import Any
    from typing import Callable
    from typing import Dict
    from typing import List
    from typing import Optional
    from typing import Tuple
    from typing import Union
    from typing import cast
    from typing import TYPE_CHECKING
    from typing_extensions import Final
    if TYPE_CHECKING:
        from numbers import Real
        from fractions import Rational
    from .time.bumpers import Bumpers
    from .time.calendars import Calendars
    from .time.calendars import HolidayCal

# Generated at 2022-06-24 01:15:03.107271
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(asof=datetime.date(2013,10,3), end=datetime.date(2014,10,2), start=datetime.date(2013,10,2)), 14) == Decimal('1.000000000000000')
    assert round(dcfc_act_365_f(asof=datetime.date(2013,10,3), end=datetime.date(2014,10,2), start=datetime.date(2013,10,2)), 14) == Decimal('1.000000000000000')

# Generated at 2022-06-24 01:15:09.476956
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert(round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478'))
    assert(round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17216108990194'))
    assert(round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08243131970956'))

# Generated at 2022-06-24 01:15:15.364119
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Test method calculate_daily_fraction of class DCC
    from .currencies import Currencies
    from .monetary import Money
    money = Money(Decimal(100), Currencies.EUR)
    start = datetime.date(2018, 12, 1)
    asof = datetime.date(2019, 1, 1)
    end = datetime.date(2019, 2, 1)
    freq = Decimal(2)
    dcc = DCCRegistry.get("ACT/360")
    dcc.calculate_daily_fraction(start, asof, end, freq)



# Generated at 2022-06-24 01:15:26.311768
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    start, asof = datetime.date(2010, 12, 31), datetime.date(2011, 1, 1)
    asof_pd = pd.Timestamp(asof)
    asof_im, start_im = ql.Date(asof.day, asof.month, asof.year), ql.Date(start.day, start.month, start.year)
    assert ql.Thirty360(ql.Thirty360.European).dayCount(start_im, asof_im) == dcfc_30_e_360(start, asof, asof)
    dcc = ql.Thirty360(ql.Thirty360.European)
    assert dcc.name() == "30E/360 ISDA"

# Generated at 2022-06-24 01:15:30.954826
# Unit test for constructor of class DCC
def test_DCC():
    # Test that the constructor of class DCC works as expected
    eom = 29
    altnames = {"Actual360"}
    name = "ACTUAL360"
    calculate_fraction_method = lambda start, asof, end, freq: Decimal((asof - start).days) / Decimal(360)
    currencies = {Currencies.TRY}

    a = DCC(name, altnames, currencies, calculate_fraction_method)
    assert a.name == name
    assert a.altnames == altnames
    assert a.currencies == currencies
    assert a.calculate_fraction_method(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1), eom, None) == 0

# Generated at 2022-06-24 01:15:38.284780
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC(
        name="TEST",
        altnames=set(),
        currencies=set(),
        calculate_fraction_method=None,
    ).coupon(Money(1, "USD"), 1, datetime.date(2012,12,15), datetime.date(2016,1,6), datetime.date(2016, 2, 15), 2) == Money(0.020000000000000018, "USD")


# Generated at 2022-06-24 01:15:44.586631
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal('1.10000000000000')


# Generated at 2022-06-24 01:15:52.469885
# Unit test for method interest of class DCC
def test_DCC_interest():
    asserts = {
        # Test against known values (from excel)
        ("ACT/ACT", datetime.date(2020, 10, 15), datetime.date(2025, 10, 20), Money(0.005, "USD"), Decimal("1.0000"), Money(0.1243, "USD"))
    }
    for (name, start, end, principal, rate, expectation) in asserts:
        assert DCCRegistry[name].interest(principal, rate, start, end) == expectation


# Generated at 2022-06-24 01:16:00.106441
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = date(2007, 12, 28), date(2008, 2, 28)
    ex2_start, ex2_asof = date(2007, 12, 28), date(2008, 2, 29)
    ex3_start, ex3_asof = date(2007, 10, 31), date(2008, 11, 30)
    ex4_start, ex4_asof = date(2008, 2, 1), date(2009, 5, 31)
    assert(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16986301369863'))

# Generated at 2022-06-24 01:16:10.479233
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    _test_dcfc_for_list_of_dates(dates=_generate_list_of_dates(), dcfc=dcfc_30_e_plus_360)
# @dcc("30E/360")
# def dcfc_30_e_360(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
#     """
#     Computes the day count fraction for the "30E/360" convention.

#     :param start: The start date of the period.
#     :param asof: The date which the day count fraction to be calculated as of.
#     :param end: The end date of the period (a.k.a. termination date).
#     :return: Day count fraction.

#     >>> ex1_start, ex

# Generated at 2022-06-24 01:16:16.836315
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    start, asof, end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=start, asof=asof, end=end), 10) == Decimal('0.5245901639')



# Generated at 2022-06-24 01:16:20.900611
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    ## Check if dates are provided properly:
    if not start <= asof <= end:
        ## Nope, return 0:
        return ZERO

    ## Cool, we can proceed with calculation based on the methodology:
    return self[3](start, asof, end, freq)

# Generated at 2022-06-24 01:16:22.249535
# Unit test for function dcc
def test_dcc():
    import doctest

    doctest.run_docstring_examples(dcc, globals())



# Generated at 2022-06-24 01:16:27.040253
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(_ex_start, _ex_asof, _ex_asof), 14) == Decimal('0.16986301369863')


# Generated at 2022-06-24 01:16:32.554831
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Test default case
    assert DCCs["ACT/ACT"].calculate_daily_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), None) == 0



# Generated at 2022-06-24 01:16:36.957672
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')



# Generated at 2022-06-24 01:16:47.178902
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC("ICMA", ["ACT365", "ACT3Y5Y366"], Currencies.get_ccys(["EUR", "GBP", "USD", "SEK", "CHF", "DKK", "NOK"]), DCCRegistry.ACT_365F_DCC)


DCCRegistry: Dict[str, DCC] = {}


# Generated at 2022-06-24 01:16:52.293176
# Unit test for method interest of class DCC
def test_DCC_interest():
    dcc = DCC(
        name="ACT/365",
        altnames={"ACT/365"},
        currencies=_as_ccys({"USD"}),
        calculate_fraction_method=_act_365,
    )

    interest = dcc.interest(
        Money(100, "USD"),
        Decimal("0.01"),
        datetime.date(2014,1,1),
        datetime.date(2014,1,31)
    )
    assert interest == Money(1.08, "USD")


# Generated at 2022-06-24 01:17:00.257265
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Unit test for dcfc_30_360_us.
    """
    assert dcfc_30_360_us(datetime.date(2010, 1, 1), datetime.date(2010, 1, 1), datetime.date(2010, 1, 1)) == 1
    assert dcfc_30_360_us(datetime.date(2010, 1, 30), datetime.date(2010, 3, 31), datetime.date(2010, 3, 31)) == 1
    assert dcfc_30_360_us(datetime.date(2010, 1, 1), datetime.date(2010, 3, 31), datetime.date(2010, 3, 31)) == 0.75

# Generated at 2022-06-24 01:17:12.482153
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Set up a DCC object
    dccobj=DCC("30E/360 ISDA",{"30E/360 ISDA","30/360 ISDA","30/360","30U/360","30/360 PS"},
               _as_ccys({"USD", "EUR", "SEK","AUD"}),DCCRegistry.DCF_PS30E_360ISDA)
    # Test case 1
    # Check if calculate_daily_fraction gives correct result when asof is not a EOM
    testcase1=dccobj.calculate_daily_fraction(datetime.date(2017,2,20),datetime.date(2017,2,21),datetime.date(2017,8,15))

# Generated at 2022-06-24 01:17:17.060170
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    from datetime import date
    ex1_start, ex1_asof = date(2007, 12, 28), date(2008, 2, 28)
    ex2_start, ex2_asof = date(2007, 12, 28), date(2008, 2, 29)
    ex3_start, ex3_asof = date(2007, 10, 31), date(2008, 11, 30)
    ex4_start, ex4_asof = date(2008, 2, 1), date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==Decimal('0.16939890710383')

# Generated at 2022-06-24 01:17:25.059663
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(year = 2017, month=1, day=1)
    asof = datetime.date(year = 2017, month=1, day=2)
    end = datetime.date(year = 2017, month=1, day=3)
    freq = Decimal(1)
    dcc = DCC("ACT_360", {}, {}, None)
    result = dcc.calculate_fraction(start, asof, end, freq)
    expected = Decimal("1/360")
    assert (result == expected) # test if the method calculate_fraction of class DCC works as expected
    # Unit test for method calculate_daily_fraction of class DCC

# Generated at 2022-06-24 01:17:36.007816
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360(start=date(2007, 12, 28), asof=date(2008, 2, 28), end=date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360(start=date(2007, 12, 28), asof=date(2008, 2, 29), end=date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360(start=date(2007, 10, 31), asof=date(2008, 11, 30), end=date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:17:46.079871
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28),
                              datetime.date(2008, 2, 28)) == Decimal('0.1666666667')
    assert dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29),
                              datetime.date(2008, 2, 28)) == Decimal('0.1694444444')
    assert dcfc_30_360_german(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30),
                              datetime.date(2008, 11, 30)) == Decimal('1.0833333333')

# Generated at 2022-06-24 01:17:56.996384
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    f = DCCRegistryMachinery()
    f.register(DCC("30/360", set(), set(), _dcfc_thirty_360))
    f.register(DCC("30/360 DS", {'30/360 DS', '30/360 ds'}, set(), _dcfc_thirty_360_ds))
    f.register(DCC("30E/360", {'30E/360', '30E/360 ISDA', '30E/360 ISMA', '30E/360 D', '30E/360 E', '30E/360 P'}, set(), _dcfc_thirty_e360))

# Generated at 2022-06-24 01:18:08.661668
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcc_dcfc_nl_365(Date(2007, 12, 28), Date(2008, 2, 28), Date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcc_dcfc_nl_365(Date(2007, 12, 28), Date(2008, 2, 29), Date(2008, 2, 29)), 14) == Decimal('0.16986301369863')
    assert round(dcc_dcfc_nl_365(Date(2007, 10, 31), Date(2008, 11, 30), Date(2008, 11, 30)), 14) == Decimal('1.08219178082192')