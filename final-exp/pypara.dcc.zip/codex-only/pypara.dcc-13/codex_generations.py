

# Generated at 2022-06-24 01:08:12.727466
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    c1 = dcfc_30_360_german(datetime.date(2010, 1, 31), datetime.date(2010, 2, 28), datetime.date(2010, 2, 28))
    c2 = dcfc_30_360_german(datetime.date(2010, 1, 30), datetime.date(2010, 2, 28), datetime.date(2010, 2, 28))
    c3 = dcfc_30_360_german(datetime.date(2010, 1, 28), datetime.date(2010, 2, 28), datetime.date(2010, 2, 28))
    assert c1 == Decimal('0.166667')
    assert c2 == Decimal('0.166667')
    assert c3 == Decimal('0.166667')


# Generated at 2022-06-24 01:08:19.078766
# Unit test for function dcfc_30_e_360

# Generated at 2022-06-24 01:08:29.784277
# Unit test for function dcc
def test_dcc():
    @dcc("Test/Test")
    def test_dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return Decimal("1")

    @dcc("Test/Test", ccys={Currencies["USD"]})
    def test_dcfc2(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return Decimal("1")

    @dcc("Test/Test", altnames={"TEST/TEST"})
    def test_dcfc3(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return Decimal("1")


# Generated at 2022-06-24 01:08:36.807470
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(1996, 1, 1), asof=datetime.date(1996, 12, 31), end=datetime.date(1996, 12, 31)), 14) == Decimal('1')
    assert round(dcfc_act_365_l(start=datetime.date(1996, 1, 17), asof=datetime.date(1996, 12, 31), end=datetime.date(1996, 12, 31)), 14) == Decimal('0.96243291592169')

# Generated at 2022-06-24 01:08:39.155256
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCs.ACT_360.coupon(Money(1, "USD"), 1, datetime.date(2014, 1, 1), datetime.date(2014, 1, 1),
                               datetime.date(2014, 1, 3), Decimal(2)) == Money(0.003, "USD")



# Generated at 2022-06-24 01:08:44.192722
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    from datetime import date
    assert dcfc_30_e_plus_360(date(2020, 1, 1), date(2020, 1, 2), date(2020, 1, 2)) == 0.002777777777777778
    assert dcfc_30_e_plus_360(date(2020, 1, 1), date(2020, 1, 2), date(2020, 1, 2)) == dcfc_30_e_360(date(2020, 1, 1), date(2020, 1, 2), date(2020, 1, 2))



# Generated at 2022-06-24 01:08:49.873619
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=Decimal(2)), 10) == Decimal('0.5245901639')



# Generated at 2022-06-24 01:08:58.053679
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof) == 0.1666666666666666666666666666667

# Generated at 2022-06-24 01:09:03.555777
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')
# Test
test_dcfc_act_act_icma()



# Generated at 2022-06-24 01:09:15.027208
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    print(round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    print(round(dcfc_30_e_360(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14))
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)

# Generated at 2022-06-24 01:09:24.089897
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # test a new dcc
    newdcc = DCC(
        name="Act/Act",
        altnames={"Actual/Actual", "Actual/Actual (ISDA)", "Actual/Actual ICMA", "Act/Act (ISDA)", "Act/Act (ICMA)"},
        currencies={Currencies["USD"], Currencies["EUR"], Currencies["GBP"], Currencies["CHF"], Currencies["TRY"]},
        calculate_fraction_method=ActualActualICMA,
    )
    assert (newdcc.name not in DCCRegistry._buffer_main) and (newdcc.name not in DCCRegistry._buffer_altn)
    DCCRegistry.register(newdcc)
    assert newdcc == DCCRegistry.find("Act/Act")

    # test exception

# Generated at 2022-06-24 01:09:29.607727
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    import numpy as np; np.random.seed(0)
    def test_dcfc_act_365_f(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return _get_actual_day_count(start, asof) / Decimal(365)
    dates = _get_random_dates(20)
    dcf = np.array([dcfc_act_365_f(*dates[i], freq=1) for i in range(20)])
    dcf_test = np.array([test_dcfc_act_365_f(*dates[i], freq=1) for i in range(20)])
    np.testing.assert_almost_equal(dcf, dcf_test, decimal=14)



# Generated at 2022-06-24 01:09:39.274883
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ## Settle date
    to = datetime.date(2007, 11, 29)

    ## Trade date
    tt = datetime.date(2007, 11, 27)

    ## Unit test
    dcd = dcfc_30_360_us(start=tt, asof=to, end=to)
    assert dcd == Decimal('0.016666666666667')


#####################################################################################
## Unit test:

# Generated at 2022-06-24 01:09:45.178197
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_360_us

# Generated at 2022-06-24 01:09:46.731859
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    pytest.test_func(dcfc_act_act)



# Generated at 2022-06-24 01:09:56.672933
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    # round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-24 01:10:03.462580
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == 0.166666666666667
    assert dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == 0.169444444444444
    assert dcfc_30_e_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == 1.083333333333333

# Generated at 2022-06-24 01:10:08.388229
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry[str]('ACT/365')[3](datetime.date(2014, 11, 1), datetime.date(2014, 12, 1), datetime.date(2015, 11, 30), None) == Decimal('0.0273972602739726')


# Generated at 2022-06-24 01:10:15.447494
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:10:19.485609
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC(
        'CORRECT_CALCULATION_METHOD',
        {'CORRECT_CALCULATION_METHOD2'},
        {Currencies['AANG']},
        lambda start, asof, end, freq: (asof - start).days,
    ).coupon(Money(100, Currencies['AANG']), 0.5, datetime.date(2017, 1, 1), datetime.date(2019, 6, 1), datetime.date(2019, 12, 1), 1) == Money(62.5, Currencies['AANG'])


# Generated at 2022-06-24 01:10:29.220277
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)),14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)),14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)),14) == Dec

# Generated at 2022-06-24 01:10:36.566402
# Unit test for constructor of class DCC
def test_DCC():
    test_dcc = DCC("test", {'a', 'b'}, {Currencies["USD"], Currencies["TRY"]}, lambda s, a, e, f: Decimal("1.0"))
    assert test_dcc.name == "test"
    assert test_dcc.altnames == {'a', 'b'}
    assert test_dcc.currencies == {Currencies["USD"], Currencies["TRY"]}
    assert test_dcc.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal("1.0")


# Generated at 2022-06-24 01:10:47.475196
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Tests the day count fraction calculator method for "Act/Act" convention.
    """
    # Define some examples:
    ex1_start, ex1_asof, ex1_end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof, ex2_end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof, ex3_end = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof, ex4_

# Generated at 2022-06-24 01:10:55.878396
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    """
    Unit test for function dcfc_30_e_plus_360
    """
    start_date, end_date = datetime.date(2015,1,1), datetime.date(2016,1,1)
    result = dcfc_30_e_plus_360(start=start_date, asof=end_date, end=end_date)
    expected = 1.0
    assert result == expected

# Generated at 2022-06-24 01:11:04.607027
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == 0.16942884946478
    assert dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == 0.17216108990194
    assert dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == 1.08243131970956

# Generated at 2022-06-24 01:11:12.365557
# Unit test for constructor of class DCC
def test_DCC():
    """
    Tests the constructor of the class DCC.
    """
    ## Construct some DCC:
    afr_act_act = DCC(
        name="afr_act_act",
        altnames={"act/act", "afr_act/act"},
        currencies=_as_ccys({"ZAR", "CDF"}),
        calculate_fraction_method=lambda s, a, e, f: Decimal(
            max(0, min(e - s, a - s))
        ),
    )

    ## Check the class type here:
    assert isinstance(afr_act_act, DCC)

    ## Now check the DCC name and alternative names:
    assert afr_act_act.name == "afr_act_act"

# Generated at 2022-06-24 01:11:16.775949
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    a = DCC("foo", set(), {}, calculate_fraction_method=None)
    assert a.calculate_daily_fraction == a.calculate_daily_fraction

# Generated at 2022-06-24 01:11:26.719900
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    node = start
    period = 0
    while node != end:
        asof = node
        dcf = dcfc_30_e_plus_360(start=start, asof=asof, end=end)
        print("{}/{}: {}".format(asof, end, dcf))
        node = node + datetime.timedelta(days=1)
        period += dcf
    print("period: {}".format(period))
    assert period == 1.  # since there's only one leap day and day 31 is replaced by day 30


# Generated at 2022-06-24 01:11:33.747679
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """
    Test function dcfc_act_act_icma
    """

# Generated at 2022-06-24 01:11:41.218136
# Unit test for function dcfc_nl_365

# Generated at 2022-06-24 01:11:48.967009
# Unit test for function dcc
def test_dcc():
    @dcc("DCC", {}, {Currencies["USD"]})
    def dcc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        ...

    assert dcc.__name__ == "dcc"
    assert dcc.__dcc.name == "DCC"
    assert dcc.__dcc.altnames == set([])
    assert dcc.__dcc.currencies == {Currencies["USD"]}



# Generated at 2022-06-24 01:11:52.330314
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC("s", set(), set(), lambda : print("s")) == DCC("s", set(), set(), lambda : print("s"))


# Generated at 2022-06-24 01:11:59.830988
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')


## Define the day count conventions:
##
## ===> 30/360


# Generated at 2022-06-24 01:12:07.006847
# Unit test for method find of class DCCRegistryMachinery

# Generated at 2022-06-24 01:12:13.986514
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    #case 1
    DCC_test = DCC('name', 
              'altnames', 
              'currencies', 
              'calculate_fraction_method')
    start_test = datetime.date(2014, 1, 1)
    asof_test = datetime.date(2016, 1, 1)
    end_test = datetime.date(2020, 1, 1)
    freq_test = Decimal(1)
    assert (DCC_test.calculate_daily_fraction(start_test, asof_test, end_test, freq_test) == Decimal('0.75'))


# Generated at 2022-06-24 01:12:24.016328
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    """
    Unit test for function dcfc_30_e_plus_360
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    

# Generated at 2022-06-24 01:12:35.076571
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.17222222222222')

# Generated at 2022-06-24 01:12:40.040151
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    start = Date(2018, 3, 15)
    asof = Date(2018, 8, 31)
    end = Date(2019, 3, 15)
    assert dcfc_act_365_l(start=start, asof=asof, end=end) == Decimal('0.29452054794521')



# Generated at 2022-06-24 01:12:47.003788
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Test method DCC.coupon()
    """
    # DCC.coupon(self, principal, rate, start, asof, end, freq, eom = None):
    DCC_object_1 = DCC(
        name = "30/360",
        altnames = {"30/360 US", "30U/360", "BOND", "30/360 SIA"},
        currencies = {"USD"},
        calculate_fraction_method = _thirty_360_us,
    )
    # TODO: Need to implement the below test case after implementing the calculate_fraction_method
    # Money
    principal_1 = None
    # Decimal
    rate_1 = 0.06
    # Date
    start_1 = datetime.date(2014, 1, 1)
    asof_1 = dat

# Generated at 2022-06-24 01:12:51.886633
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14)==Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14)==Decimal('1.08196721311475')

# Generated at 2022-06-24 01:12:58.093716
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:13:02.964514
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Act
    actual = DCCRegistry['ACT/365F'].calculate_fraction(Date(2020,1,1), Date(2020,1,1), Date(2020,1,1))

    # Assert
    assert actual == ZERO

DCCRegistry: Dict[str, DCC] = {}
"""
Defines a dictionary of day count conventions for looking up by name.
"""



# Generated at 2022-06-24 01:13:09.536979
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Example data
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    # Expected values
    ex1_exp = Decimal('0.16666666666667')
    ex2_exp = Decimal('0.16944444444444')

# Generated at 2022-06-24 01:13:13.712965
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:13:24.277567
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    from random import choice, randint
    from . import dates, dates_rand
    for start, end in dates_rand.get_pairs(10000):
        f = dcfc_act_act(start, end, end)
        assert f == dcfc_act_act(end, start, start)
        assert 0 <= f <= 1
    for start, end in dates.get_pairs(10000):
        f = dcfc_act_act(start, end, end)
        assert f == dcfc_act_act(end, start, start)
        assert 0 <= f <= 1



# Generated at 2022-06-24 01:13:34.803822
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    data = [(datetime.date(2020, 2, 29), datetime.date(2021, 2, 28), Decimal('10.6232876712'))]

    for d in data:
        assert round(dcfc_act_365_f(d[0], d[1], d[1]), 11) == d[2]
    print('Test dcfc_act_365_f succeeded')



# Generated at 2022-06-24 01:13:39.651674
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    drm = DCCRegistryMachinery()
    a = NamedTuple("a", [("name", str), ("altnames", Set[str]), ("currencies", Set[Currency]), ("calculate_fraction_method", DCFC)])
    a.register(DCC("Act/360", {"Act/360"}, {"USD"}, calculate_fraction_act360))
    drm.register(a)
    DCCRegistry.register(DCC("A/360", {"A/360"}, {"USD"}, calculate_fraction_act360))
    assert abs(drm.find("Act/360").calculate_fraction(datetime.date(2007, 1, 1), datetime.date(2008, 1, 1), datetime.date(2008, 1, 1)) - Decimal("1")) < Decimal("0.0001")
    assert abs

# Generated at 2022-06-24 01:13:50.483144
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)) == decimal.Decimal('0.16666666666667')
    assert dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)) == decimal.Decimal('0.16944444444444')
    assert dcfc_30_e_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)) == decimal.Decimal('1.08333333333333')
    assert dcfc_30_e_360(datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)) == decimal.Decimal('1.33055555555556')



# Generated at 2022-06-24 01:14:00.636934
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08219178082192')

# Generated at 2022-06-24 01:14:09.463071
# Unit test for method interest of class DCC
def test_DCC_interest():
    # Arrange
    principal = Money(1, 'CNY')
    rate = 0.01
    start = datetime.date(2017,2,1)
    asof = datetime.date(2017,2,28)
    end = datetime.date(2017,2,28)
    freq = None
    expected_value = principal * rate * DCCRegistry.d30360e.calculate_fraction_method(start, asof, end, freq)
    # Act
    actual_value = DCCRegistry.d30360e.interest(principal, rate, start, asof, end, freq)
    # Assert
    assert expected_value.value == actual_value.value



# Generated at 2022-06-24 01:14:18.974842
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Test function dcfc_30_360_us.

    :return: None.
    """
    ## Result:
    RES = Decimal('0.16666666666667')

    ## Dates:
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex1_end = datetime.date(2008, 2, 28)

    ## Test1:
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_end), 14) == RES

    ## Test2:

# Generated at 2022-06-24 01:14:28.064144
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    import inspect
    import datetime

    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')


# Generated at 2022-06-24 01:14:38.855707
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29),datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30),datetime.date(2008, 11, 30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-24 01:14:41.412587
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end),10) == Decimal('0.5245901639')

test_dcfc_act_act_icma()
    

# Generated at 2022-06-24 01:14:52.241690
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Tests method find of the class DCCRegistryMachinery.
    """
    ## Empty registry:
    registry = DCCRegistryMachinery()

    ## Not found:
    name = "Act/Act"
    assert registry.find(name) is None

    ## Register a DCC:
    alts = {name}
    dcc = DCC(name, alts, set(), act_act_m)
    registry.register(dcc)

    ## Now the item should be found:
    assert registry.find("act/act") is not None
    assert registry.find("Act/Act") is not None

    ## Now try to register the same DCC again:
    with pytest.raises(TypeError):
        registry.register(dcc)

    ## Now try to have an alternative name conflict:

# Generated at 2022-06-24 01:15:02.738551
# Unit test for function dcc
def test_dcc():
    @dcc("Test")
    def test(start, asof, end, *args):
        pass
    # end @dcc
    test.__dcc.name
    test.__dcc.altnames == set([])
    test.__dcc.currencies == set([])
    test.__dcc.calculate_fraction_method
    # end test_dcc


#: Defines the set of registered day count conventions.
DCCS: Set[DCC] = set(DCCRegistry.table.values())



# Generated at 2022-06-24 01:15:13.979728
# Unit test for function dcc
def test_dcc():
    exc = None
    try:
        @dcc("Test", ccys={Currencies["USD"]})
        def test_dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
            return ONE
    except:
        exc = sys.exc_info()
    finally:
        assert not exc
        assert DCCRegistry.find("Test")
        assert DCCRegistry.find("Test").calculate_fraction_method.__name__ == "test_dcfc"
        assert DCCRegistry.find("Test").currencies == {Currencies["USD"]}


#: Actual/Actual ICMA

# Generated at 2022-06-24 01:15:18.953698
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test method calculate_daily_fraction() of class DCC.
    """
    assert DCCRegistry.get("ICMA").calculate_daily_fraction(Date(2018, 1, 1), Date(2018, 1, 10), Date(2018, 1, 31)) == Decimal("0.090909090909091")



# Generated at 2022-06-24 01:15:27.615033
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_start, end=ex1_start), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=ex2_start, asof=ex2_start, end=ex2_start), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=ex3_start, asof=ex3_start, end=ex3_start), 14) == Decimal('1.10000000000000')
    assert round(dcfc_act_360(start=ex4_start, asof=ex4_start, end=ex4_start), 14) == Decimal('1.34722222222222')


# Generated at 2022-06-24 01:15:39.257841
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from datetime import date

    assert DCCRegistry["ACT/365"].calculate_daily_fraction(date(2016, 1, 1), date(2016, 1, 1), date(2016, 1, 1)) == 0
    assert DCCRegistry["ACT/365"].calculate_daily_fraction(date(2016, 1, 1), date(2016, 1, 2), date(2016, 1, 2)) == 1
    assert DCCRegistry["ACT/365"].calculate_daily_fraction(date(2016, 1, 1), date(2016, 1, 3), date(2016, 1, 3)) == 1
    assert DCCRegistry["ACT/365"].calculate_daily_fraction(date(2016, 1, 1), date(2016, 1, 4), date(2016, 1, 4)) == 1


# Generated at 2022-06-24 01:15:50.619344
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal(0.16942884946478)
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal(1694.29)
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal(0.00)


# Generated at 2022-06-24 01:15:58.126345
# Unit test for function dcc
def test_dcc():
    """
    Tests the dcc decorator.
    """

    # %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    # Registers a day count convention with a function:
    @dcc("Test/Test", altnames={"test"}, ccys={Currencies.find("TRY")})
    def func_test_test(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Calculates the day count fraction.
        """
        return Decimal(1)

    # %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    # Checks the attributes:
    assert func_test_test.__

# Generated at 2022-06-24 01:16:09.588260
# Unit test for method find of class DCCRegistryMachinery

# Generated at 2022-06-24 01:16:19.408027
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    '''
    Test the attributes of all DCC in the DCCRegistryMachinery
    '''
    from collections import namedtuple
    from decimal import Decimal
    from datetime import date, datetime
    from dateutil.relativedelta import relativedelta
    from time import mktime
    import calendar
    import pytz
    import re
    import string
    import unittest
    import sys
    import ccy
    import holid
    import money
    import dcc
    import disp
    import qry
    import expr
    import types


# Generated at 2022-06-24 01:16:28.626234
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,28), end=datetime.date(2008,2,28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,29), end=datetime.date(2008,2,29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007,10,31), asof=datetime.date(2008,11,30), end=datetime.date(2008,11,30)), 14) == Dec

# Generated at 2022-06-24 01:16:38.068186
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCC(name="ACT/360", altnames=set(), currencies=set(), calculate_fraction_method=None).interest(
        principal=Money(Decimal("1000000"), Currencies["USD"]),
        rate=Decimal("0.049"),
        start=datetime.date(2017, 2, 1),
        asof=datetime.date(2017, 2, 28)
    ) == Money(Decimal("25000"), Currencies["USD"])


# Generated at 2022-06-24 01:16:47.274005
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    d1 = datetime.date(2006, 6, 15)
    d2 = datetime.date(2006, 8, 15)
    d3 = datetime.date(2006, 6, 30)
    d4 = datetime.date(2006, 6, 1)
    assert dcfc_30_360_us(start=d1, asof=d2, end=d2) == 0.5
    assert dcfc_30_360_us(start=d3, asof=d2, end=d2) == 0.5
    assert dcfc_30_360_us(start=d4, asof=d2, end=d2) == 0.5

    d1 = datetime.date(2006, 6, 15)
    d2 = datetime.date(2006, 8, 31)

# Generated at 2022-06-24 01:16:56.370569
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print ("Testing dcfc_act_act...")

# Generated at 2022-06-24 01:17:03.722918
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:17:08.841810
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    try:
        dccr = DCCRegistryMachinery()
    except NameError:
        pass
    dccr.register(DCC("DCC", "DCC", "USD", _dcc_act_act))


# Generated at 2022-06-24 01:17:15.718052
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert_equals(Decimal("0.16986301369863"),dcfc_nl_365(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)))
    assert_equals(Decimal("0.16986301369863"),dcfc_nl_365(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 2, 29)))
    assert_equals(Decimal("1.08219178082192"),dcfc_nl_365(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008, 11, 30)))

# Generated at 2022-06-24 01:17:24.471360
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    startdate = Date(2018, 2, 28)
    asofdate = Date(2018, 3, 2)
    enddate = Date(2018, 3, 30)

    dcc = DCC(
            name= "ACT/365",
            altnames={"ACT/365"},
            currencies={Currencies["USD"]},
            calculate_fraction_method=lambda s,a,e,f: Decimal(_get_actual_day_count(a, e))/365)
    calculated = dcc.calculate_daily_fraction(startdate, asofdate, enddate, 1)
    assert calculated == Decimal("0.00542465753424657534")


# Generated at 2022-06-24 01:17:30.838049
# Unit test for method interest of class DCC
def test_DCC_interest():
    # Set up
    test_principal = Money(10.00, "USD")
    test_rate = Decimal(0.05)
    test_start_date = Date(2013, 1, 1)
    test_asof_date = Date(2013, 1, 2)
    test_end_date = Date(2013, 1, 10)
    test_freq = None
    test_dcc = DCC(name="test_DCC",
        altnames=set("test_DCC"),
        currencies=set("USD"),
        calculate_fraction_method=lambda start, asof, end, freq: Decimal("0.1")
    )

    # Run test

# Generated at 2022-06-24 01:17:38.276509
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    """
    Test for function _dcfc_act_365_a
    """
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:17:45.145270
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ## 30/360 US Example from ISDA specification:
    start = datetime.date(1994, 9, 19)
    asof = datetime.date(1995, 9, 19)
    end = datetime.date(1995, 9, 19)
    print("dcfc_30_360_us: ", dcfc_30_360_us(start, asof, end))
    # Output:
    # dcfc_30_360_us:  1.083333333333333


# Generated at 2022-06-24 01:17:56.652781
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc_registry = DCCRegistry()
    df = dcc_registry['ACT/365']
    assert df.calculate_fraction(datetime.date(2015, 6, 10), datetime.date(2015, 6, 10), datetime.date(2016, 1, 1)) == ZERO
    assert df.calculate_fraction(datetime.date(2015, 6, 10), datetime.date(2015, 6, 11), datetime.date(2016, 1, 1)) == ZERO
    assert df.calculate_fraction(datetime.date(2015, 6, 10), datetime.date(2015, 6, 12), datetime.date(2016, 1, 1)) == ONE / 365

# Generated at 2022-06-24 01:18:06.829310
# Unit test for method interest of class DCC
def test_DCC_interest():
    start = datetime.date(2017, 1, 1)
    end = datetime.date(2018, 1, 1)
    asof = datetime.date(2017, 3, 3)
    principal = Money(1, "USD")
    rate = 0.1
    freq = 2
    actAccruedInterest = 0.25

    dcc = DCC("Actual/Actual", set(), _as_ccys({"USD"}), calculate_fraction_act_act_ISDA)

    expAccruedInterest = dcc.interest(principal, rate, start, asof, end, freq)

    assert expAccruedInterest.amount == actAccruedInterest
