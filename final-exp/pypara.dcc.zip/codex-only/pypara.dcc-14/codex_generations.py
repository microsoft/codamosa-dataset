

# Generated at 2022-06-24 01:08:14.351812
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-24 01:08:23.560181
# Unit test for method interest of class DCC
def test_DCC_interest():
    import pandas as pd
    dcc = DCCRegistry.get_dcc(DCCRegistry.ACTUAL_360)
    principal = 10000
    rate = 0.03
    start = datetime.date(2019, 11, 1)
    asof = datetime.date(2019, 11, 15)
    end = datetime.date(2019, 11, 15)
    freq = Decimal(1)
    results = dcc.interest(principal, rate, start, asof, end, freq)
    exp_results = Money(10000 * 0.03 * (15 - 1))
    assert results == exp_results


# Generated at 2022-06-24 01:08:33.108488
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_360(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:08:39.124476
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Runs tests for method find of class DCCRegistryMachinery
    """

    # Check if a day count convention is found properly.
    assert DCCRegistry.find("Act/Act") == DCC("Act/Act", {"Actual/Actual"}, set(), calculate_fraction_act_act)

    # Check if a day count convention is found properly when the given name is uppercased.
    assert DCCRegistry.find("ACT/ACT") == DCC("Act/Act", {"Actual/Actual"}, set(), calculate_fraction_act_act)

    # Check if a day count convention is found properly when the given name is uppercased and stripped.
    assert DCCRegistry.find("ACT/ACT      ") == DCC("Act/Act", {"Actual/Actual"}, set(), calculate_fraction_act_act)

# Generated at 2022-06-24 01:08:49.421199
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.17222222222222')

# Generated at 2022-06-24 01:08:57.087627
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    import os
    import tempfile
    from unittest import TestCase
    from shutil import rmtree
    from finance.session import Session
    from finance.currencies import Currencies

    ## Mock
    class MockCurrencies(Currencies):

        ## Disable error checking:
        def _check(self, *args, **kwargs):
            pass

    ## Create the day count registry:
    session = Session()
    session.currencies = MockCurrencies()
    registry = DCCRegistry(session)

    ## Make sure no registry is created:
    assert not registry.registry

    ## Mock registry entry:
    registry._buffer_main["Act/Act"] = ("Act/Act", {"Actual/Actual", "Act/Act"}, {"USD"}, lambda *args: ZERO)

    ## Create a temp directory:
    dirpath = temp

# Generated at 2022-06-24 01:09:06.632326
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:09:17.336914
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:09:29.565324
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    try:
        assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    except:
        assert 0
    try:
        assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')
    except:
        assert 0

# Generated at 2022-06-24 01:09:35.908914
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    """
    Test for the dcfc_nl_365 function.
    """
    start = datetime(year=2019, month=3, day=1)
    asof = datetime(year=2019, month=9, day=30)
    
    assert dcfc_nl_365(start=start, asof=asof, end=asof) == 0.4136986301369863



# Generated at 2022-06-24 01:09:47.231199
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    ##
    ## The coupon(...) method of the class DCC calculates the accrued interest for the coupon payment. The method is
    ## primarily used for bond coupon accruals which assumes the start date to be the first of regular payment schedules.
    ##

    ##
    ## Create a set of interest rate curves to use in the unit tests.
    ##

    ## Create a US treasury yield curve.
    us_curve = InterestRateCurveFactory(Currencies["USD"], datetime.date(2016, 12, 12))

# Generated at 2022-06-24 01:09:52.261883
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    This unit test only checks the behaviour of the coupon function for the following DCC:
    Actual Actual ISDA
    Actual Actual ICMA
    """
    from .monetary import USD

    # 1. ACTUAL ACTUAL ISDA
    # TODO
    # 2. ACTUAL ACTUAL ICMA
    # TODO
    


# Generated at 2022-06-24 01:09:58.865872
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    resultado = round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10)
    assert resultado == Decimal('0.5245901639')


# Generated at 2022-06-24 01:10:04.089401
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """
    Unit test for function dcfc_30_360_isda.
    """
    from unittest import TestCase
    from xldlib.utils.test import parameterized


# Generated at 2022-06-24 01:10:12.745132
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC('name',set(),set(),DCFC) == DCC('name',set(),set(),DCFC)
    assert DCC('',set(),set(),DCFC) != DCC('name',set(),set(),DCFC)

    assert repr(DCC('name',set(),set(),DCFC)) == "DCC(name={}, altnames={}, currencies={}, calculate_fraction_method={})".format('name',set(),set(),DCFC)


#DCC.calculate_fraction.__doc__ = "Calculates the day count fraction based on the underlying methodology after performing some general checks."
#DCC.calculate_daily_fraction.__doc__ = "Calculates daily fraction."
#DCC.interest.__doc__ = "Calculates the accrued interest."
#DCC.coupon.__doc__ =

# Generated at 2022-06-24 01:10:18.292441
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert (round(dcfc_30_360_isda(start=start, asof=asof, end=asof), 14) == Decimal('0.16666666666667'))
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert (round(dcfc_30_360_isda(start=start, asof=asof, end=asof), 14) == Decimal('0.16944444444444'))



# Generated at 2022-06-24 01:10:28.991971
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 28)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:10:37.969891
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    dcfc_act_365_a(datetime.date(2006,2,7), datetime.date(2006,2,8), datetime.date(2006,2,8))== 1



# Generated at 2022-06-24 01:10:44.467576
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_360_

# Generated at 2022-06-24 01:10:53.005381
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:11:01.412209
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    ## Initialize the registry:
    dccs = DCCRegistryMachinery()

    ## Mock the day count conventions:
    dccs.register(
        DCC("AAA", {"AAA1", "AAA2"}, {"AAA1", "AAA2"}, lambda s, a, e, f: Decimal(1))
    )
    dccs.register(
        DCC("BBB", {"BBB1", "BBB2"}, {"BBB1", "BBB2"}, lambda s, a, e, f: Decimal(2))
    )
    dccs.register(
        DCC("CCC", {"CCC1", "CCC2"}, {"CCC1", "CCC2"}, lambda s, a, e, f: Decimal(3))
    )

    ## Run the tests:
    assert dccs.find("AAA") == DCC

# Generated at 2022-06-24 01:11:09.852667
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert dcfc_act_365_l(datetime.date(1987, 11, 10), datetime.date(2000, 12, 10), datetime.date(2000, 12, 10),) == Decimal('1.328767123287671232876712328767')
    assert dcfc_act_365_l(datetime.date(1987, 11, 10), datetime.date(2000, 12, 10), datetime.date(2000, 12, 10)) == Decimal('1.328767123287671232876712328767')
    assert dcfc_act_365_l(datetime.date(1987, 11, 10), datetime.date(2000, 12, 10), datetime.date(2000, 12, 10)) == Decimal('1.328767123287671232876712328767')
    assert d

# Generated at 2022-06-24 01:11:17.818008
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:11:27.827294
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof = datetime.date(2008, 2, 29), datetime.date(2009, 2, 28)

# Generated at 2022-06-24 01:11:38.717708
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.10000000000000')

# Generated at 2022-06-24 01:11:44.320096
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Test for dcfc_30_360_german
    """
    # Test that errors are raised when an attempt is made to run dcfc_30_360_german on invalid dates
    with pytest.raises(Exception):
        dcfc_30_360_german(Date(1970, 1, 1), Date(1970, 1, 1), Date(1970, 3, 1))
    with pytest.raises(Exception):
        dcfc_30_360_german(Date(1970, 1, 1), Date(1970, 1, 1), Date(1970, 1, 1))
    # Test that dcfc_30_360_german returns the correct result

# Generated at 2022-06-24 01:11:54.573075
# Unit test for function dcc
def test_dcc():
    @dcc("Test DCC")
    def test_dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal]) -> Decimal:
        return Decimal(0.1)

    assert test_dcfc(datetime.date(2014, 1, 1), datetime.date(2014, 2, 1), datetime.date(2014, 3, 1), None) == Decimal(0.1)

    @dcc("Test DCC 1", altnames={"DCC1"}, ccys={Currencies["USD"]})
    def test_dcfc1(start: Date, asof: Date, end: Date, freq: Optional[Decimal]) -> Decimal:
        return Decimal(0.1)


# Generated at 2022-06-24 01:12:02.914071
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """
    Checks if the dcfc_act_act_icma function works as intended.
    """
    ## Prepare data for testing
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    ex2_start, ex2_asof, ex2_end = datetime.date(2018, 12, 20), datetime.date(2019, 12, 30), datetime.date(2020, 1, 10)
    ex3_start, ex3_asof, ex3_end = datetime.date(2015, 1, 10), datetime.date(2015, 12, 31), datetime.date(2016, 1, 1)
    ex4_start, ex4_asof, ex

# Generated at 2022-06-24 01:12:13.678493
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)== 0.16986301369863
    assert round(dcfc_act_365_a(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14)== 0.17213114754098
    assert round(dcfc_act_365_a(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14)== 1.08196721311475
    assert round(dcfc_act_365_a(start=ex4_start, asof=ex4_asof, end=ex4_asof), 14)== 1.32513661202186

# Generated at 2022-06-24 01:12:20.305387
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    today = datetime.date(2020, 9, 8)
    yesterday = datetime.date(2020, 9, 7)
    tomorrow = datetime.date(2020, 9, 9)
    assert DCC['ACT/365'].calculate_fraction(today, today, tomorrow, one) == ZERO
    assert DCC['ACT/365'].calculate_fraction(today, yesterday, tomorrow, one) == Decimal("1/365")

# Generated at 2022-06-24 01:12:31.836610
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:12:40.730570
# Unit test for function dcc
def test_dcc():
    @dcc("TestConv", ["testconv", "tcn"])
    def testconv_method(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        pass

    # Unit test for the function itself:
    assert testconv_method.__name__ == "testconv_method"
    assert testconv_method.__dcc.name == "TestConv"
    assert "testconv" in testconv_method.__dcc.altnames
    assert "tcn" in testconv_method.__dcc.altnames
    assert not testconv_method.__dcc.currencies
    assert DCCRegistry.find("TestConv") is not None
    assert DCCRegistry.find("testconv") is not None
    assert DCCRegistry.find

# Generated at 2022-06-24 01:12:51.667115
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    principal = Money('100', 'USD')
    asof = Date('2019-03-12')
    end = Date('2019-03-15')
    rate = Decimal(2.5)
    start = Date('2019-03-11')
    freq = 1
    dcc = DCC('name',{'altnames'},{'currencies'},calculate_fraction_method)
    #Testing for positive case
    assert dcc.calculate_fraction(start, asof, end, freq) == Decimal(4/365)
    #Testing for negative case
    end = Date('2019-03-09')
    assert dcc.calculate_fraction(start, asof, end, freq) == Decimal(0)

# Generated at 2022-06-24 01:13:03.513009
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from datetime import date
    from financepy.products.funding.Curves import RatesCurve
    from financepy.finutils.FinDate import FinDate
    from financepy.finutils.FinGlobalTypes import FinDayCountTypes
    from financepy.finutils.FinHelperFunctions import nextCouponPayDate, lastCouponPayDate
    from financepy.products.funding.FinIborSingleCurve import FinIborSingleCurve

    startDate = FinDate(9, 7, 2008)
    settleDate = startDate.addMonths(1)
    endDate = FinDate(9, 7, 2013)
    coupon = 0.05

    # THIS IS WRONG - NEED TO USE A RATE SWAP
    dccType = FinDayCountTypes.ACT_360
    liborCurve = FinIborSingleCurve(startDate)

# Generated at 2022-06-24 01:13:09.178011
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:13:14.088840
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # test case #1
    start, asof, end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)
    dcf = dcfc_30_360_german(start, asof, end)
    assert round(dcf, 12) == Decimal("0.16666666666667")
    # test case #2
    start, asof, end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)
    dcf = dcfc_30_360_german(start, asof, end)
    assert round(dcf, 12) == Decimal("0.16944444444444")
    # test case #3

# Generated at 2022-06-24 01:13:25.236021
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert test_dcfc_act_act_icma.__name__ in DCCRegistry.table.keys()
    for dcc_name in DCCRegistry.table.keys():
        dcc = DCCRegistry.table[dcc_name]
        if dcc.name in ["Act/Act (ICMA)", "Actual/Actual (ICMA)", "ISMA-99", "Act/Act (ISMA)"]:
            method = lambda a,b,c,d: dcc.calculate_fraction(start=a, asof=b, end=c, freq=d)
            assert isclose(method(datetime.date(2019, 1, 1), datetime.date(2019, 5, 1), datetime.date(2020, 1, 1)), 0.354838709677419)

# Generated at 2022-06-24 01:13:37.026274
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Test with 30/360
    dcc = DCCRegistry['ACT/360']
    assert dcc.calculate_fraction(datetime.date(2017, 3, 1),
                                  datetime.date(2017, 3, 1),
                                  datetime.date(2017, 9, 1)) == Decimal('0.0')
    assert dcc.calculate_fraction(datetime.date(2017, 3, 1),
                                  datetime.date(2017, 3, 2),
                                  datetime.date(2017, 9, 1)) == Decimal('0.0027777777777778')

# Generated at 2022-06-24 01:13:43.804194
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():

    # Start: 31 Dec 2007
    # Asof : 28 Feb 2008
    start = datetime.date(2007, 12, 31)
    asof = datetime.date(2008, 2, 28)
    assert dcfc_30_e_plus_360(start, asof) == float(0.166666666666667)

    # Start: 31 Dec 2007
    # Asof : 29 Feb 2008
    start = datetime.date(2007, 12, 31)
    asof = datetime.date(2008, 2, 29)
    assert dcfc_30_e_plus_360(start, asof) == float(0.169444444444444)

    # Start: 31 Oct 2007
    # Asof : 30 Nov 2008
    start = datetime.date(2007, 10, 31)
    asof = datetime.date

# Generated at 2022-06-24 01:13:54.685200
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    assert_equal(DCCRegistry._is_registered("Act/360"), True)
    assert_equal(DCCRegistry._is_registered("Act/365"), True)
    assert_equal(DCCRegistry._is_registered("Act/Act"), True)
    assert_equal(DCCRegistry._is_registered("30/360"), True)
    assert_equal(DCCRegistry._is_registered("30E/360"), True)


## Defines the day count registry instance:
DCCRegistry = DCCRegistryMachinery()


# Generated at 2022-06-24 01:14:05.210927
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    ## Define a principal:
    principal = Money.parse("100.0")

    ## Define the rate:
    rate = Decimal(0.05)

    ## Define the start date:
    start = Date(datetime.date(2014, 1, 1))

    ## Get the today's date:
    asof = Date()

    ## Define the end date:
    end = Date(datetime.date(2016, 12, 31))

    ## Calculate the coupon for each convention:
    for dcc in DCCRegistry.all():
        ## Calculate the coupon and print:
        coupon = dcc.coupon(principal, rate, start, asof, end, 2, 15)

# Generated at 2022-06-24 01:14:15.479370
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == round(Decimal('0.16939890710383'), 14)
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == round(Decimal('0.17213114754098'), 14)

# Generated at 2022-06-24 01:14:20.761674
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dcc_registry = DCCRegistryMachinery()
    dcc_name = "Act/Act"
    dcc_table = dcc_registry.table
    dcc_list = dcc_registry.registry

    assert dcc_table == {dcc_name: ACT_ACT, 'ACTUAL/ACTUAL': ACT_ACT}
    assert dcc_list == [ACT_ACT]


# Generated at 2022-06-24 01:14:29.220935
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    #Test ex1
    assert Decimal('0.16986301369863') == dcfc_act_365_f(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28))
    #Test ex2
    assert Decimal('0.17260273972603') == dcfc_act_365_f(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 2, 29))
    #Test ex3
    assert Decimal('1.08493150684932') == dcfc_act_365_f(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008, 11, 30))
    #

# Generated at 2022-06-24 01:14:38.810144
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    a = DCC("foo", set(), set(), lambda start, asof, end, freq: ONE)
    assert a.coupon(Money(100, Currencies.USD), Decimal("0.03"), Date(2017, 1, 1), Date(2017, 1, 1), Date(2017, 1, 1), 1)==Money(3, Currencies.USD)
    assert a.coupon(Money(100, Currencies.USD), Decimal("0.03"), Date(2017, 1, 1), Date(2017, 1, 1), Date(2017, 1, 1), 1, 15)==Money(3, Currencies.USD)

# Generated at 2022-06-24 01:14:47.400741
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    d = datetime.date(2019, 3, 2)
    d2 = datetime.date(2019, 9, 10)
    d3 = datetime.date(2020, 3, 2)
    assert dcfc_act_act_icma(d, d2, d3) == Decimal('0.524590163934426')
    assert dcc2.calculate_fraction(d, d2, d3) == Decimal('0.524590163934426')



# Generated at 2022-06-24 01:14:58.765156
# Unit test for function dcc
def test_dcc():
    """
    Unit tests for function dcc.
    """
    @dcc("DUMMY", {"A", "B", "C"}, {Currencies["USD"]})
    def dummy(start, asof, end, freq):
        return Decimal(0.5)

    assert dummy.__dcc.name == "DUMMY"
    assert dummy.__dcc.altnames == {"A", "B", "C"}
    assert dummy.__dcc.currencies == {Currencies["USD"]}
    assert dummy.__dcc.calculate_fraction_method == dummy
    assert dummy.__dcc.calculate_fraction(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal(0.5)




# Generated at 2022-06-24 01:15:05.652940
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Test all the cases defined under the doc string of the function dcfc_act_act
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:15:15.163833
# Unit test for constructor of class DCC
def test_DCC():
    """
    Test the constructor of class DCC
    """
    dcc = DCC("Act/360", {"act360"}, {"USD"}, lambda start, asof, end, freq: ONE)
    print("dcc.name:", dcc.name)
    print("dcc.altnames:", dcc.altnames)
    print("dcc.currencies:", dcc.currencies)

    _calculate_fraction_method = lambda start, asof, end, freq: ONE
    dcc = DCC("Act/360", {"act360"}, {"USD"}, _calculate_fraction_method)
    print("dcc.name:", dcc.name)
    print("dcc.altnames:", dcc.altnames)
    print("dcc.currencies:", dcc.currencies)
   

# Generated at 2022-06-24 01:15:26.190683
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC(
        name="1/1",
        altnames=set(),
        currencies=set(),
        calculate_fraction_method=_actual_actual_icma_actual_actual
    ).name == "1/1"
    assert DCC(
        name="1/1",
        altnames=set(),
        currencies=set(),
        calculate_fraction_method=_actual_actual_icma_actual_actual
    ).calculate_fraction_method == _actual_actual_icma_actual_actual

# Generated at 2022-06-24 01:15:30.981944
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC('name',
    {'SIA', 'SAI', 'SIAI'},
    _as_ccys({'USD'}),
    lambda start, asof, end, freq: _get_actual_day_count(start, end) / _get_actual_day_count(start, end))



# Generated at 2022-06-24 01:15:41.368061
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Unit test for :func:`thorn.api.date_model.DCC.coupon`.
    """
    ## Define the coupon:
    coupon = DCC.coupon

    ## Make sure that parameters are provided properly:
    from .monetary import Money
    from .currencies import USD
    assert coupon(Money(100, USD), Decimal(0.1), datetime.date(2012, 1, 1), datetime.date(2012, 2, 1)) == Money(0, USD)
    assert coupon(Money(100, USD), Decimal(0.1), datetime.date(2012, 1, 1), datetime.date(2012, 1, 1)) == Money(0, USD)

# Generated at 2022-06-24 01:15:46.438055
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    ## Define a registry:
    registry = DCCRegistryMachinery()

    ## Define a dummy dcc:
    dcc = DCC(name="DCC", altnames=set(), currencies=set(), calculate_fraction_method=lambda x, y, z, w: w)

    ## Try to register:
    registry.register(dcc)


# Generated at 2022-06-24 01:15:55.383573
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    """
    Unit test for method register of class DCCRegistryMachinery.
    """
    r = DCCRegistry()
    r.register(DCC("Act/Act", set(), set(), daycount.actual_actual))
    r.register(DCC("Act/365", set(), set(), daycount.actual_365))
    r.register(DCC("Act/360", set(), set(), daycount.actual_360))
    r.register(DCC("30/360", set(["U.S.", "US", "U.S. (Bond)", "US (Bond)"]), set(), daycount.thirty_360))

    with pytest.raises(TypeError):
        r.register(DCC("Act/Act", set(), set(), daycount.actual_actual))



# Generated at 2022-06-24 01:16:06.065527
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    start = Date(2008,7,7)
    asof = Date(2015,10,6)
    end = Date(2016,1,6)
    freq = Decimal(4)
    rate = Decimal('0.05')
    principal = Money('100', 'USD')
    eom = 7
    dcc = DCC(name = '30/360',altnames = {'30/360 US', '30/360 US (ISDA)', '30/360 US (NASD)', '30/360 US (BMA)'},currencies = {Currencies['USD'], Currencies['EUR']}, calculate_fraction_method = calculate_fraction_method)
    assert dcc.coupon(principal, rate, start, asof, end, freq, eom)


# Generated at 2022-06-24 01:16:15.407949
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08219178082192')

# Generated at 2022-06-24 01:16:25.169489
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    '''
    function dcfc_act_360 unit test
    '''
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:16:35.233597
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC(name='Actual/360 (A/360)', altnames={'act/360', '360/360'}, currencies=_as_ccys({'USD', 'EUR', 'GBP'}), calculate_fraction_method=DCCRegistry._calculate_fraction_A360).name == 'Actual/360 (A/360)'
    assert DCC(name='Actual/365 (A/365)', altnames={'act/365'}, currencies=_as_ccys({'AUD', 'CAD', 'CZK', 'DKK', 'HUF', 'NZD', 'NOK', 'SEK', 'ZAR'}), calculate_fraction_method=DCCRegistry._calculate_fraction_A365).name == 'Actual/365 (A/365)'


# Generated at 2022-06-24 01:16:41.494859
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert(round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478'))
    assert(dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29'))
    assert(dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00'))



# Generated at 2022-06-24 01:16:47.227909
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert ONE == DCCRegistry["ACT"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2018, 1, 1), datetime.date(2018, 1, 1))
    
    
    
    

# Generated at 2022-06-24 01:16:55.922947
# Unit test for function dcc
def test_dcc():
    @dcc("Act/Act", {"AFB", "FAB"}, {"USD"})
    def _act_act(d1: Date, d2: Date, d3: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Calculates the day count fraction for Actual / Actual.
        """
        ## We are calculating d2 - d1. Therefore, we should check it:
        if d1 < d2:
            return Decimal((d2 - d1).days) / Decimal((d3 - d1).days)
        else:
            return ZERO

    assert _act_act(datetime.date(2015, 2, 28), datetime.date(2015, 3, 1), datetime.date(2015, 12, 31)) == ONE
    #
    # Unit test for function _act_act


# Generated at 2022-06-24 01:17:02.670713
# Unit test for function dcc
def test_dcc():
    @dcc("Act/360", ccys={Currencies.USD, Currencies.EUR, Currencies.GBP})
    def act360(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Returns the day count fraction calculated by Act/360 convention.
        """
        ## Check if the dates are reasonable:
        if not start <= asof <= end:
            ## Nope, return zero:
            return ZERO

        ## Get the difference in days:
        diff = _days(asof, end)

        ## Calculate and return the day count fraction:
        return diff / 360


# Generated at 2022-06-24 01:17:13.710130
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-24 01:17:22.330471
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(datetime.date(2017, 1, 31), datetime.date(2017, 2, 28), datetime.date(2017, 2, 28)) \
           == Decimal('0.1')
    assert dcfc_30_360_us(datetime.date(2017, 1, 30), datetime.date(2017, 2, 28), datetime.date(2017, 2, 28)) \
           == Decimal('0.1')
    assert dcfc_30_360_us(datetime.date(2017, 1, 31), datetime.date(2017, 2, 31), datetime.date(2017, 2, 31)) \
           == Decimal('0.11666666666667')

# Generated at 2022-06-24 01:17:32.824485
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    """
    This function tests whether the dcfc_act_365_f function is behaving as expected.
    We tested the function against the examples given in the docstring. The test passes if the output is identical to
    the expected output.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
   

# Generated at 2022-06-24 01:17:35.392120
# Unit test for constructor of class DCC
def test_DCC():
    #This test is for the DCC constructor.
    # Since DCC is a NamedTuple, we are testing to see if it returns the proper
    # values for the fields
    # Note, the last argument is a function that also needs to be tested.
    DCC("name", "altnames", "currencies", "calculate_fraction_method")



# Generated at 2022-06-24 01:17:45.620853
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():

    def test_dcfc_act_act_icma_row(row):
        start_str, end_str, asof_str, expected = row
        start = datetime.datetime.strptime(start_str, '%Y-%m-%d').date()
        end = datetime.datetime.strptime(end_str, '%Y-%m-%d').date()
        asof = datetime.datetime.strptime(asof_str, '%Y-%m-%d').date()
        actual = dcfc_act_act_icma(start, asof, end, Decimal(2))
        assert(actual == expected)


# Generated at 2022-06-24 01:17:56.954886
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)
    Decimal('0.16666666666667')

# Generated at 2022-06-24 01:18:08.625656
# Unit test for method interest of class DCC
def test_DCC_interest():
    ## Test interest method of DCC
    from decimal import Decimal

    from .currencies import Currencies
    from .monetary import Money

    dcc = DCC(
        name="Actual/Actual",
        altnames=set(),
        currencies=set(),
        calculate_fraction_method=actual_actual
    )
    t1 = dcc.interest(Money(100, Currencies["EUR"]), Decimal(0.01), datetime.date(2017, 4, 1), datetime.date(2017, 4, 1))
    assert t1.currency == Currencies["EUR"] and t1.amount == Decimal(0)
