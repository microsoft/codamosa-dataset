

# Generated at 2022-06-24 01:08:11.866172
# Unit test for method interest of class DCC
def test_DCC_interest():
    """
    Tests the method interest of class DCC.
    """
    ccy = Currency("AUD")
    principal = Money(Decimal("1000000"), ccy)
    rate = Decimal("0.04")
    start = Date(datetime.date(2009, 10, 1))
    asof = Date(datetime.date(2009, 10, 8))
    end = Date(datetime.date(2009, 10, 8))
    freq = Decimal("4")
    assert DCCRegistry["Act/365"].interest(principal, rate, start, asof, end, freq) == Money(Decimal("1040"), ccy)

# Generated at 2022-06-24 01:08:21.613520
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Some unit test for the 30_360_us method.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)


# Generated at 2022-06-24 01:08:24.033750
# Unit test for constructor of class DCC
def test_DCC():
    pass
#   dcc = DCC("NL/365", "NL/365", {"USD", "EUR", "JPY"}, dcc_nl_365)
#   assert dcc.name == "NL/365"



# Generated at 2022-06-24 01:08:34.591376
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():

    ## Example 1:
    assert dcfc_30_360_us(start=datetime.date(2007, 12, 31), asof=datetime.date(2008, 3, 31), end=datetime.date(2008, 3, 31)) == Decimal("0.16666666666666")

    ## Example 2:
    assert dcfc_30_360_us(start=datetime.date(2008, 1, 1), asof=datetime.date(2008, 12, 31), end=datetime.date(2008, 12, 31)) == Decimal("0.99999999999999")

    # Example 3 (no date adjustments other than the last day of the month rule):

# Generated at 2022-06-24 01:08:45.915432
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    # Testing with given example
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')
    # Testing with a longer time period
    ex2_start, ex2_asof, ex2_end = datetime.date(1999, 1, 1), datetime.date(2000, 3, 1), datetime.date(2020, 3, 2)

# Generated at 2022-06-24 01:08:56.611272
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    d1 = DCC("Act/Act", {"Act/Act"}, {Currencies["USD"]}, DCFCActualActualICMA)
    d2 = DCC("Act/Act (ICMA)", {"Act/Act (ICMA)"}, {Currencies["USD"]}, DCFCActualActualICMA)
    d3 = DCC("Act/Act (ICMA) (1997)", {"Act/Act (ICMA) (1997)"}, {Currencies["USD"]}, DCFCActualActualICMA)
    d4 = DCC("Act/Act (ICMA) (2000)", {"Act/Act (ICMA) (2000)"}, {Currencies["USD"]}, DCFCActualActualICMA)

# Generated at 2022-06-24 01:09:02.215059
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start_date = datetime.date(2017, 1, 1)
    start_asof = datetime.date(2018, 12, 31)
    start_end = datetime.date(2019, 12, 31)

    test_DCC = DCC(
        name='ACT/ACT',
        altnames={},
        currencies={},
        calculate_fraction_method=_act_act_method
    )

    assert test_DCC.calculate_fraction(start_date, start_asof, start_end) == Decimal('1.003970199')



# Generated at 2022-06-24 01:09:14.849574
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    # Define a test function
    def dcc_print(name):
        """
        Finds and prints day count convention.
        """
        dcc = dccregistry.find(name)
        if dcc is not None:
            print(dcc)
        else:
            print("Not found.")

    # Default values for start, end and asof dates
    start_date = datetime.date(2007, 12, 28)
    asof_date = datetime.date(2008, 2, 28)
    end_date = datetime.date(2008, 2, 28)

    # Instantiate the registry
    dccregistry = DCCRegistryMachinery()

    # Try to register some day count conventions

# Generated at 2022-06-24 01:09:23.940935
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert dcfc_act_365_a(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31), datetime.date(2018, 12, 31)) == Decimal("1.01369863013699")
    assert dcfc_act_365_a(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31), datetime.date(2019, 12, 31)) == Decimal("1.01095890410959")
    assert dcfc_act_365_a(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31), datetime.date(2020, 12, 31)) == Decimal("1.01369863013699")

# Generated at 2022-06-24 01:09:27.382083
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Tests the method calculate_daily_fraction from class DCC.
    """
    ## Define a DCC object with an empty method:
    dcc = DCC(
        name='',
        altnames=set(),
        currencies=set(),
        calculate_fraction_method=lambda: 0,
    )

    ## Run the test:
    assert dcc.calculate_daily_fraction(None, None, None, None) == 0



# Generated at 2022-06-24 01:09:31.233527
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2017,12,31), datetime.date(2018,1,1), datetime.date(2018,1,1)),6) == 0.002740
    assert round(dcfc_nl_365(datetime.date(2017,11,30), datetime.date(2018,1,1), datetime.date(2018,1,1)),6) == 0.013699
    assert round(dcfc_nl_365(datetime.date(2017,10,31), datetime.date(2018,1,1), datetime.date(2018,1,1)),6) == 0.090411


# Generated at 2022-06-24 01:09:38.056307
# Unit test for function dcfc_act_act_icma

# Generated at 2022-06-24 01:09:49.933361
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from .currencies import Currencies

    ## Create a dummy currency with EUR and USD as its synonyms:
    dummy_ccy = Currency("XYZ", "Dummy Currency", "Dummy Currency", Symbols.XYZ, Currencies, "USD", "EUR")

    ## Create day count conventions:
    ACT_ACT_ISDA = DCC("Actual/Actual (ISDA)", {"Actual/Actual (ISDA)"}, _as_ccys({"USD", "EUR"}), actual_actual_isda)
    THIRTY_360_BMA = DCC("30/360 (BMA)", {"30/360 (BMA)"}, _as_ccys({"USD", "XYZ"}), thirty_360_bma)

    # Example 1

# Generated at 2022-06-24 01:09:55.571844
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    x = DCCRegistryMachinery()
    x._buffer_main = {'a': 1, 'b': 2, 'c': 3}
    x._buffer_altn = {'d': 4, 'e': 5, 'f': 6}
    assert x.find('a') == 1
    assert x.find('c') == 3
    assert x.find('d') == 4
    assert x.find('f') == 6
    assert x.find('g') is None


# Generated at 2022-06-24 01:10:02.599901
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    """
    Test function dcfc_act_365_f.
    """
    ex1_start, ex1_asof = date(2007, 12, 28), date(2008, 2, 28)
    ex2_start, ex2_asof = date(2007, 12, 28), date(2008, 2, 29)
    ex3_start, ex3_asof = date(2007, 10, 31), date(2008, 11, 30)
    ex4_start, ex4_asof = date(2008, 2, 1), date(2009, 5, 31)
    assert dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:10:06.462985
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from datetime import date
    from financepy.finutils.FinDate import FinDate

    startDate = FinDate(1, 1, 2018)
    endDate = FinDate(31, 1, 2018)
    testDate = FinDate(15, 1, 2018)
    dcc = DCCActualActual()
    frac = dcc.calculate_fraction(startDate, testDate, endDate)
    print(frac)



# Generated at 2022-06-24 01:10:15.852487
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
  date_start = datetime.date(2007, 12, 28)
  date_asof = datetime.date(2008, 2, 29)
  date_end = datetime.date(2012, 6, 10)
  expected = Decimal('0.16944444444444')
  computed = dcfc_30_e_plus_360(start=date_start, asof=date_asof, end=date_end)
  tol = 1e-14
  success = abs(expected - computed) < tol
  msg = "expected %s != computed %s" %(expected, computed)
  assert success, msg


# Generated at 2022-06-24 01:10:21.160090
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:10:29.380251
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal('1.10000000000000')


# Generated at 2022-06-24 01:10:39.199961
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:10:50.165005
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    #assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    #assert round

# Generated at 2022-06-24 01:10:57.120999
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # example 1
    start_date = datetime.date(2010, 12, 28)
    asof_date = datetime.date(2011, 10, 28)
    end_date = asof_date
    result = dcfc_30_360_isda(
        start=start_date,
        asof=asof_date,
        end=end_date,
        freq=None)
    expected = Decimal('0.308333333333333')
    eps = 10 ** -14
    assert abs(result - expected) <= eps



# Generated at 2022-06-24 01:11:02.530732
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2020, 5, 31), asof=datetime.date(2020, 8, 31), end=datetime.date(2020, 8, 31)), 14) == 0.24657534246575



# Generated at 2022-06-24 01:11:04.138088
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert (DCCRegistry.find("ACT/ACT") == DCCRegistry.find("act/act"))

# Generated at 2022-06-24 01:11:11.990697
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:11:23.402926
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    """
    Checks if the DCCRegistryMachinery is properly constructed.
    """
    ## import the unit test class:
    from . import UnitTest

    ## Initialize the test:
    test = UnitTest("DCCRegistryMachinery")
    test.create_test(test.__name__)

    ## Define a couple of dccs:
    dcc1 = DCC("ACT/ACT", {"Act/Act"}, {"USD"}, _act_act_method)
    dcc2 = DCC("ACT/365", {"Act/365"}, {"EUR", "GBP"}, _act_365_method)
    dcc3 = DCC("Act/360", {"Act/360"}, {"CHF"}, _act_360_method)

    ## Create a registry:
    registry = DCCRegistryMachinery()

    ## Register the dcc

# Generated at 2022-06-24 01:11:28.767568
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # Expected result: TypeError
    with assert_raises(TypeError):
        DCCRegistry.register(
            DCC(
                name="Act/Act",
                altnames={"Actual/Actual", "ActAct"},
                currencies={Currencies["EUR"], Currencies["USD"], Currencies["GBP"]},
                calculate_fraction_method=ACT_ACT_ISDA
            )
        )


# Generated at 2022-06-24 01:11:35.230773
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC("ACT/360", set(), set(), calculate_act_360).coupon(Money("100", "USD"), Decimal("0.05"), Date(2018,1,1), Date(2018,1,2), Date(2018,1,2), Decimal("12")) == Money("1.389", "USD")
    assert DCC("ACT/360", set(), set(), calculate_act_360).coupon(Money("100", "USD"), Decimal("0.05"), Date(2018,1,1), Date(2018,1,2), Date(2018,6,30), Decimal("6")) == Money("3.056", "USD")

# Generated at 2022-06-24 01:11:47.580224
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    print("TEST:", test_DCC_calculate_daily_fraction.__name__)

# Generated at 2022-06-24 01:11:57.058267
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCRegistry.BOND.calculate_fraction_method(datetime.date(2014, 1, 1), datetime.date(2015, 1, 1), datetime.date(2015, 7, 1), 2) == Decimal('0.5')
    assert DCCRegistry.ACTUAL_ACTUAL.calculate_fraction_method(datetime.date(2014, 1, 1), datetime.date(2015, 1, 1), datetime.date(2015, 7, 1), 2) == Decimal('0.5')
    assert DCCRegistry.BOND.calculate_fraction_method(datetime.date(2014, 1, 1), datetime.date(2015, 1, 1), datetime.date(2015, 1, 1), 2) == Decimal('0')
    assert DCCRegistry.ACTUAL

# Generated at 2022-06-24 01:12:04.913052
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-24 01:12:11.166931
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')


# Generated at 2022-06-24 01:12:13.772057
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC('Act/360', {'Act/360'}, {}, lambda x, y, z, c: ONE) == DCC('Act/360', {'Act/360'}, {}, lambda x, y, z, c: ONE)
test_DCC()



# Generated at 2022-06-24 01:12:22.337576
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-24 01:12:30.866867
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Unit test for method calculate_fraction of class DCC
    """
    # initialize DCC object
    dcc = DCC('act/360',set(),set(),lambda start, asof, end, freq: Decimal(((end - start).days / 360.0)))
    # call method
    dcc.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 2))

# Generated at 2022-06-24 01:12:42.217175
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from dateutil.relativedelta import relativedelta
    from .currencies import Currencies
    from .money import Money
    from .calendars import NullBusCalendar

    test_cases = [
        (
            (Money(1, Currencies["TRY"]), 1/365, datetime.date(2017,1,1), datetime.date(2017,1,2)),
            Money(2.73e-4, Currencies["TRY"])
        ),
        (
            (Money(1, Currencies["TRY"]), 1/365, datetime.date(2017,1,1), datetime.date(2017,3,3)),
            Money(0.0808, Currencies["TRY"])
        ),
    ]


# Generated at 2022-06-24 01:12:48.433352
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    print(dcfc_30_e_plus_360(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)))
    print(dcfc_30_e_plus_360(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 2, 29)))
    print(dcfc_30_e_plus_360(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008, 11, 30)))
    print(dcfc_30_e_plus_360(datetime.date(2008, 2, 1),datetime.date(2009, 5, 31),datetime.date(2009, 5, 31)))

## Part

# Generated at 2022-06-24 01:12:53.424134
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert(DCC.interest(DCC.US_30_360, Money('USD', 100000), 0.06, datetime.date(2017, 12, 15), datetime.date(2018, 3, 15))) == Money('USD', 25000)
    assert(DCC.interest(DCC.US_30_360, Money('USD', 100000), 0.06, datetime.date(2017, 6, 1), datetime.date(2018, 6, 1))) == Money('USD', 30000)    

# Generated at 2022-06-24 01:13:04.715249
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:13:14.881044
# Unit test for constructor of class DCC
def test_DCC():
    """
    Test case for the constructor of class DCC.
    """
    start_date = Date(2018, 10, 1)
    end_date = Date(2018, 12, 31)

    # test 30/360 day count convention
    dcc = DCC("30/360", {}, {Currencies.USD}, lambda a, b, c, d: Decimal("0.25"))
    assert dcc.calculate_fraction(start_date, Date(2018, 10, 1), end_date) == Decimal("0.11111111111111111")
    assert dcc.calculate_fraction(start_date, Date(2018, 10, 15), end_date) == Decimal("0.22222222222222222")

# Generated at 2022-06-24 01:13:25.292385
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    registry = DCCRegistryMachinery()
    name = "Actual/360"
    dcc = DCC("Actual/360", {"Act/360"}, {}, lambda start, asof, end, p: Decimal("0.0027777777777778"))
    registry.register(dcc)
    assert registry.find("Act/360").name == name
    assert registry.find("Actual/360").name == name
    assert registry.find("act/360").name == name
    assert registry.find("ACTUAL/360").name == name
    registry.register(DCC("Actual/365", {"Act/365"}, {}, lambda start, asof, end, p: Decimal("0.0027397260122111")))
    assert registry.registry[0].name == name

# Generated at 2022-06-24 01:13:37.104114
# Unit test for function dcc
def test_dcc():
    @dcc("testdcc")
    def testdcc(*args, **kwargs):
        pass

    @dcc("testdcc2", {"testdcc2a", "testdcc2b"})
    def testdcc2(*args, **kwargs):
        pass

    @dcc("testdcc3", ccys={Currencies["USD"], Currencies["EUR"]})
    def testdcc3(*args, **kwargs):
        pass

    @dcc("testdcc4", {"testdcc4a"}, {Currencies["USD"]})
    def testdcc4(*args, **kwargs):
        pass

    assert DCCRegistry.find("testdcc") is testdcc.__dcc
    assert DCCRegistry.find("testdcc2") is testdcc2.__dcc

# Generated at 2022-06-24 01:13:42.240986
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    for dcfc_name, dcfc_func in DCF_FACTORY.items():
        start, end, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)
        print("DCF = {} = {: %.10f}".format(dcfc_name, dcfc_func(start, asof, end)))

test_dcfc_act_365_l()


# Generated at 2022-06-24 01:13:47.407446
# Unit test for function dcc
def test_dcc():
    ## Define a dummy function:
    def test_calc(a: Date, b: Date, c: Date, d: int) -> Decimal:
        pass

    ## Run the decorator:
    dcc_func = dcc("TestDecorator", altnames={"ABC"})(test_calc)

    ## Check for correctness:
    assert dcc_func.__dcc.name == "TestDecorator"
    assert dcc_func.__dcc.altnames == {"ABC"}
    assert dcc_func is test_calc
#: Defines a model for day count convention lookup.
DCCLookup = Callable[[str], Optional[DCC]]



# Generated at 2022-06-24 01:13:56.053850
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Test case: dcfc_30_360_german
    print("Test case: dcfc_30_360_german")
    testDate_0 = Date(year=1969, month=6, day=1, hour=0, minute=0, second=0, timezone_info=None,
                      calendar=Calendar.MONDAY)
    dcfc_30_360_german_0 = dcfc_30_360_german(start=testDate_0, asof=testDate_0, end=testDate_0)
    print("dcfc_30_360_german: " + str(dcfc_30_360_german_0))
    return dcfc_30_360_german_0


# Generated at 2022-06-24 01:14:04.581355
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2))) == Decimal(0.5245901639)
    assert round(dcfc_act_act_icma(datetime.date(2008, 2, 29), datetime.date(2008, 7, 31), datetime.date(2009, 2, 28))) == Decimal(0.4805626071)
    assert round(dcfc_act_act_icma(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2009, 10, 31))) == Decimal(1.0926470588)

# Generated at 2022-06-24 01:14:08.827741
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    ACtACtI = DCC("Act/Act", {"Act/Act"}, {Currencies["USD"]}, _dc_act_act)
    print(DCCRegistry.find("Act/Act").name)
test_DCCRegistryMachinery_find()


# Generated at 2022-06-24 01:14:17.966893
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal('1.10000000000000')


# Generated at 2022-06-24 01:14:23.215611
# Unit test for function dcc
def test_dcc():
    pass



# Generated at 2022-06-24 01:14:33.343836
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    registry = DCCRegistryMachinery()
    registry.register(DCC("Test", {}, {}, lambda s, a, e, f: ZERO))
    dcc = registry.find("Test")
    assert dcc is not None


## Defines the main registry:
DCCRegistry = DCCRegistryMachinery()

## Defines the day count fraction calculation functions:
DCC_DCFC_ACTUAL_ACTUAL_ICMA = lambda s, a, e, f: (
    DCC_DCFC_ACTUAL_ACTUAL_AFB(s, a, e, f) if isinstance(f, Fraction) or isinstance(f, Decimal) else Decimal(0)
)


# Generated at 2022-06-24 01:14:44.509105
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    print("test DCC calculate_fraction")
    from .currencies import USD
    from .monetary import USDMoney
    from .util import date
    dcc = DCC(
        name="30/360 ISDA",
        altnames={"30360", "30/360", "30/360 ISDA", "30/360 ISMA"},
        currencies=_as_ccys({"USD", "CAD", "AUD"}),
        calculate_fraction_method=actual_30360_isfa,
    )

    assert dcc.calculate_fraction(start=None, asof=None, end=None, freq=None) == 0.0

# Generated at 2022-06-24 01:14:56.902424
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("Act/Act") != None
    assert DCCRegistry.find("ACT/ACT") != None
    assert DCCRegistry.find("act/act") != None
    assert DCCRegistry.find("ACT/act") != None
    assert DCCRegistry.find("act/ACT") != None
    assert DCCRegistry.find("30/360 (United States)") != None
    assert DCCRegistry.find("30/360 (united states)") != None
    assert DCCRegistry.find("30/360 (United states)") != None
    assert DCCRegistry.find("30/360 (united States)") != None
    assert DCCRegistry.find("30/360 (UnIted States)") != None
    assert DCCRegistry.find("30/360 (united States)")

# Generated at 2022-06-24 01:15:00.731046
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(start=datetime.date(2018, 10, 31), asof=datetime.date(2018, 11, 30), end=datetime.date(2018, 11, 30)) == 1 / 360



# Generated at 2022-06-24 01:15:02.252890
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc = DCCRegistry.find("Act/Act")
    assert dcc is not None 


# Generated at 2022-06-24 01:15:09.182840
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
    # raise Exception("Unit test not implemented")

# Generated at 2022-06-24 01:15:15.245098
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    """
    Unit test for method register of class DCCRegistryMachinery

    >>> dcc1 = DCC("XXX", {"YYY", "ZZZ"}, set(), DCFC(lambda: None))
    >>> dcc2 = DCC("XXX", {"YYY", "ZZZ"}, set(), DCFC(lambda: None))
    >>> drm = DCCRegistryMachinery()
    >>> drm.register(dcc1)
    >>> drm.register(dcc2)
    Traceback (most recent call last):
    ...
    TypeError: Day count convention 'XXX' is already registered
    """

# Generated at 2022-06-24 01:15:26.255567
# Unit test for method coupon of class DCC
def test_DCC_coupon():

    from .currencies import USD, EUR, JPY
    from .monetary import Money
    from .pricing.instruments import Bond
    from .time.qldates import Quarterly

    # Create a bond with USD-denominated principal and coupon
    bond = Bond(principal=Money(10000, USD), rate=Decimal(0.05), freq=Quarterly)
    print(bond)
    # Accrue interest
    print(bond.accrue(datetime.date(2016, 6, 30), datetime.date(2016, 12, 31)))
    # Accrue through the last payment date
    print(bond.accrue(datetime.date(2015, 12, 31), datetime.date(2016, 6, 30)))


    # Create a bond with EUR-denominated principal and coupon

# Generated at 2022-06-24 01:15:31.551391
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-24 01:15:33.846780
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    DCCRegistryMachinery()

## Create the DCC registry for further usage:
DCCRegistry = DCCRegistryMachinery()



# Generated at 2022-06-24 01:15:43.059284
# Unit test for function dcc
def test_dcc():
    #
    # Creating a simple DCC for testing purposes:
    #
    @dcc('KADCC', ccys={Currencies['USD']}, altnames={'KAD', 'KADAY', 'KADC'})
    def kadcc(start, end, freq):
        """
        Returns the fraction for Kadir's Act/Act DCC Model.
        """
        #
        # Define the values:
        #
        delta = end - start
        days = delta.days
        years = delta.days / 365.0

        #
        # Return the fractions:
        #
        if freq is None:
            return years
        else:
            return float(days) / (float(freq) * 365.0)

    #
    # Test the registered names:
    #

# Generated at 2022-06-24 01:15:51.331895
# Unit test for method register of class DCCRegistryMachinery

# Generated at 2022-06-24 01:15:55.816632
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
  # test case 1
  assert round(dcfc_act_360(
    start=datetime.date(2007, 12, 28), 
    asof=datetime.date(2008, 2, 28), 
    end=datetime.date(2008, 2, 28)), 14) == Decimal("0.17222222222222")
  # test case 2
  assert round(dcfc_act_360(
    start=datetime.date(2007, 12, 28), 
    asof=datetime.date(2008, 2, 29), 
    end=datetime.date(2008, 2, 29)), 14) == Decimal("0.17500000000000")
  # test case 3

# Generated at 2022-06-24 01:16:02.093468
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Unit test function for function dcfc_30_e_360.
    """
    import doctest
    from dateutil.relativedelta import relativedelta
    from numpy.testing import assert_allclose
    import numpy as np
    import pandas as pd
    from pandas.util.testing import assert_series_equal
    np.random.seed(97)

# Generated at 2022-06-24 01:16:13.835921
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    # Range 0 to 9
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find("Act/Act")
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find("ACT/ACT")
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find("act/act")
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find("A C T / A C T")
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find("A C T/A C T")
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find("A C T/A C T")

# Generated at 2022-06-24 01:16:23.475199
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Run function with input arguments:
    #     start: Date (datetime.date(2018, 7, 6))
    #     asof: Date (datetime.date(2018, 7, 6))
    #     end: Date (datetime.date(2018, 7, 6))
    #     freq: Optional[Decimal] = None
    # Unit test result
    assert ZERO == DCCs["Act360"].calculate_daily_fraction(datetime.date(2018, 7, 6), datetime.date(2018, 7, 6), datetime.date(2018, 7, 6)), "DCC method calculate_daily_fraction failed (1)"


# Generated at 2022-06-24 01:16:27.991567
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-24 01:16:36.891311
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:16:47.178431
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-24 01:16:55.882948
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Example 1:
    start_date, end_date = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    frac = dcfc_30_360_us(start=start_date, asof=start_date, end=end_date)
    assert round(frac, 14) == Decimal('0.16666666666667')

    # Example 2:
    start_date, end_date = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    frac = dcfc_30_360_us(start=start_date, asof=start_date, end=end_date)
    assert round(frac, 14) == Decimal('0.16944444444444')

    # Example 3:
    start_date, end_

# Generated at 2022-06-24 01:17:03.365570
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(
        datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)
    ), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(
        datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)
    ), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-24 01:17:13.823359
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == 0.1698630136986301
    assert dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == 0.1698630136986301
    assert dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == 1.0821917808219178

# Generated at 2022-06-24 01:17:25.443269
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), 2),
                 10) == Decimal("0.2622950819")
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), 4),
                 10) == Decimal("0.1311454095")
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), 12),
                 10) == Decimal("0.0437045363")


# Generated at 2022-06-24 01:17:36.042157
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    print("unit testing ... dcfc_30_360_us")

    ## Example 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:17:46.111217
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Tests the coupon method of the DCC class.
    """
    from .pricing import Coupon
    from .dccs import DCCRegistry
    from .monetary import Money

    #def test_prorated_calculation():
    principal = Money(1.0, Currencies.USD)
    rate = Decimal('0.01')
    asof = datetime.date(2017, 8, 8)
    firstday = datetime.date(2017, 7, 1)
    dcc = DCCRegistry.instance().get('ACT/360')
    coupon = dcc.coupon(principal, rate, firstday, asof, datetime.date(2018, 1, 1), Decimal(2))
    assert coupon == Money(0.5 , Currencies.USD)

    #def test_coupon

# Generated at 2022-06-24 01:17:57.373783
# Unit test for method interest of class DCC
def test_DCC_interest():
    dcc_dict = DCCRegistry.get_registered_dccs()
    dcc_list: List[DCC] = list(dcc_dict.values())
    c = Currencies["USD"]
    # Testing with a simple input
    if dcc_list[0].interest(Money(1, c), Decimal(0.05), datetime.date(2020,1,1), datetime.date(2020,1,1), datetime.date(2020,1,1)) != Decimal(0):
        raise AssertionError("Method interest is not working correctly")
    # Testing if the calculation is wrong

# Generated at 2022-06-24 01:18:08.987445
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert(round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==0.16666666666667)
    assert(round(dcfc_30_360_isda(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14)==0.16944444444444)
    assert(round(dcfc_30_360_isda(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14)==1.08333333333333)