

# Generated at 2022-06-24 01:08:15.410508
# Unit test for method calculate_daily_fraction of class DCC

# Generated at 2022-06-24 01:08:25.787093
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    print('\n', ex1_start, 'to', ex1_asof, ':')
    print(round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14), '\n',
          (ex1_asof.day - ex1_start.day) + 30 * (ex1_asof.month - ex1_start.month) + 360 * (ex1_asof.year - ex1_start.year), '\n')


# Generated at 2022-06-24 01:08:31.763792
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:08:36.901303
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc_registry = DCCRegistryMachinery()
    name = "Act/Act"
    dcc_registry.register(DCC(
        "Act/Act",
        {"Act/Act", "Actual/Actual", "ActAct", "ACT/ACT", "ACTACT"},
        {"USD"},
        calculate_actual_actual_fraction,
    ))
    dcc = dcc_registry.find(name)
    name = "Act/Act"
    assert dcc.name == name
    name = "Act/Act"
    assert dcc.name == name
    name = "Act/Act"
    assert dcc.name == name
    name = "Act/Act"
    assert dcc.name == name
    name = "Act/Act"
    assert dcc.name == name

# Generated at 2022-06-24 01:08:47.280667
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Test for the DCC 'calculate_daily_fraction' method.
    """
    ## Get a reference to a convention:
    afb = DCCRegistry[Currencies.USD]["Actual/360 US bond basis"]

    ## Create start and end dates:
    start = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 3, 3)

    ## Check the daily fraction at the start date:
    assert afb.calculate_daily_fraction(start, start, end) == ZERO

    ## Check the daily fraction at the end date:
    assert afb.calculate_daily_fraction(start, end, end) == ZERO

    ## Check the daily fraction at the mid-point:

# Generated at 2022-06-24 01:08:56.679294
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex_start = datetime.date(2007, 12, 28)
    ex_asof1 = datetime.date(2008, 2, 28)
    ex_asof2 = datetime.date(2008, 2, 29)
    ex_asof3 = datetime.date(2008, 11, 30)
    ex_asof4 = datetime.date(2009, 5, 31)
    ex_end = datetime.date(2008, 2, 28)
    assert round(dcfc_act_act(ex_start, ex_asof1, ex_end), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(ex_start, ex_asof2, ex_end), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-24 01:09:06.739430
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    # Testing data from https://github.com/J-Mo63/Money/blob/master/Money/tests/test_daycount.py
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:09:08.709788
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("Act/Act")

    assert DCCRegistry.find("Act-Act")

# Generated at 2022-06-24 01:09:20.788386
# Unit test for method coupon of class DCC
def test_DCC_coupon():

    # Dates:
    start = datetime.date(2014,12,1)
    asof = datetime.date(2015,5,5)
    end = datetime.date(2015,6,1)
    freq = Decimal(2)
    eom = None
    principal = Money('GBP', 1000.00)
    rate = Decimal(0.04)
    
    # Create a new DCC:
    a = DCC('ACT/360',{'US': 'ACT/360'}, 1, DCCRegistry['ACT/360'].calculate_fraction_method)
    
    # Check output:
    assert a.coupon(principal, rate, start, asof, end, freq, eom) == Money('GBP', 17.77)


# Generated at 2022-06-24 01:09:26.572191
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:09:35.989827
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    def test_dcfc_act_act_icma_single(start, asof, end, result):
        tmp = dcfc_act_act_icma(start, asof, end, result)
        assert (round(tmp, 4) == round(result, 4))

# Generated at 2022-06-24 01:09:47.262134
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    import datetime
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal("0.16942884946478")
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal("0.17216108990194")
    assert round(dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal("1.08243131970956")

# Generated at 2022-06-24 01:09:55.634373
# Unit test for function dcfc_30_e_plus_360

# Generated at 2022-06-24 01:09:58.017784
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    machinery = DCCRegistryMachinery()
    assert(machinery._buffer_main == {})
    assert(machinery._buffer_altn == {})


# Generated at 2022-06-24 01:10:01.488022
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCC('name', set(['altnames']), set(['currencies']), lambda s, a, e, f: 0)
    foo = DCCRegistry()
    foo.register(dcc)
    assert foo._buffer_main['name'] == dcc
    assert foo._buffer_altn['altnames'] == dcc


# Generated at 2022-06-24 01:10:11.147923
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    import datetime
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof))

# Generated at 2022-06-24 01:10:22.857861
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) \
        == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) \
        == Decimal('0.16944444444444')

# Generated at 2022-06-24 01:10:32.644472
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    dcc = DCC(
        name='ACT/365',
        altnames=set(),
        currencies={'USD'},
        calculate_fraction_method=_get_act_365_fraction
    )
    # datetime.date(2012, 12, 15), datetime.date(2016, 1, 6), 2
    # datetime.date(2012, 12, 15), datetime.date(2015, 12, 31), 2
    print(dcc.coupon(Money(1000, 'USD'),Decimal(0.05),datetime.date(2012, 12, 15),datetime.date(2015, 12, 31),datetime.date(2015, 12, 31),Decimal(2)))
# Unit test end


# Generated at 2022-06-24 01:10:40.022851
# Unit test for function dcfc_act_360
def test_dcfc_act_360():

    assert(round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222'))
    assert(round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17500000000000'))

# Generated at 2022-06-24 01:10:50.982951
# Unit test for function dcfc_30_e_360

# Generated at 2022-06-24 01:11:00.771305
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from decimal import Decimal
    from .currencies import Currencies
    from .monetary import Money
    from .time.calendars import Weekly
    
    # Test for method:
    # 1. calculate_fraction(start: datetime.date, asof: datetime.date, end: datetime.date, freq: Optional[decimal.Decimal] = None) -> decimal.Decimal
    # 2. calculate_daily_fraction(start: datetime.date, asof: datetime.date, end: datetime.date, freq: Optional[decimal.Decimal] = None) -> decimal.Decimal
    # 3. interest(principal: money.Money, rate: decimal.Decimal, start: datetime.date, asof: datetime.date, end: Optional[datetime.date], freq: Optional[decimal

# Generated at 2022-06-24 01:11:09.329839
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    ## Test  _has_leap_day()
    """

# Generated at 2022-06-24 01:11:20.754740
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_end, ex1_dcf = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), Decimal(0.16986301369863)
    ex2_start, ex2_end, ex2_dcf = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), Decimal(0.17213114754098)
    ex3_start, ex3_end, ex3_dcf = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), Decimal(1.08196721311475)

# Generated at 2022-06-24 01:11:29.497488
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .commons.zeitgeist import Date
    import datetime
    from .commons.numbers import ZERO
    today = datetime.date.today()
    start = Date(today.year, today.month, today.day)
    asof = Date(today.year, today.month, today.day)
    end = Date(today.year, today.month, today.day)
    freq = None
    obj=DCC('name', 'altnames', 'currencies', 'calculate_fraction_method')
    assert obj.calculate_daily_fraction(start, asof, end, freq) == ZERO
    assert obj.calculate_daily_fraction(start, asof, end) == ZERO

# Generated at 2022-06-24 01:11:41.120605
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2020, 8, 2), datetime.date(2021, 8, 2), datetime.date(2021, 8, 2)), 14) == Decimal('1.00027397260274')
    assert round(dcfc_act_365_l(datetime.date(2021, 8, 3), datetime.date(2022, 8, 3), datetime.date(2022, 8, 3)), 14) == Decimal('1.00068493150685')
    assert round(dcfc_act_365_l(datetime.date(2022, 8, 4), datetime.date(2023, 8, 4), datetime.date(2023, 8, 4)), 14) == Decimal('1.00109589041096')

# Generated at 2022-06-24 01:11:51.817656
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc1 = DCC("Test", ["TEST"], Currencies["USD"], lambda x, y, z, w: 1.0)
    dcc2 = DCC("TEST", ["TEST2"], Currencies["USD"], lambda x, y, z, w: 1.0)

    class TestRegistry(DCCRegistryMachinery):
        def __init__(self):
            super().__init__()
        def register(self, dcc: DCC) -> None:
            super().register(dcc)

        def find(self, name: str) -> Optional[DCC]:
            return self._find_strict(name)

    ## Create the registry and register the day count conventions:
    registry = TestRegistry()

    ## Attempt to register a new one:
    registry.register(dcc1)

# Generated at 2022-06-24 01:11:59.275042
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert 0.16666666666667 == round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14)
    assert 0.16944444444444 == round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14)
    assert 1.08333333333333 == round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14)

# Generated at 2022-06-24 01:12:10.164085
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:12:10.805862
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    pass

# Generated at 2022-06-24 01:12:14.635997
# Unit test for constructor of class DCC
def test_DCC():
    a = DCC("test", set(), set(), lambda: 0)
    assert a.altnames == set()
    assert a.calculate_fraction(0,0,0,0) == 0
    assert a.calculate_fraction_method(0,0,0,0) == 0
    assert a.currencies == set()
    assert a.name == "test"


# Generated at 2022-06-24 01:12:22.921882
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():

    ## Create a new registry:
    registry = DCCRegistryMachinery()

    ## Register an object of type DCC
    dcc = DCC("test", ["hello", "world"], ["USD", "EUR"], calculate_fraction_actact_isda_method)
    registry.register(dcc)

    assert registry._is_registered("test")
    assert registry._is_registered("hello")
    assert registry._is_registered("world")

    try :
        registry.register(dcc)
    except TypeError :
        pass


DCCRegistry = DCCRegistryMachinery()

# TODO: Be sure that the DCCs are registered in the lexicographical order:

# Generated at 2022-06-24 01:12:34.343527
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:12:43.211101
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:12:49.158921
# Unit test for function dcc
def test_dcc():
    assert isinstance(DCCRegistry, DCCRegistryMachinery)

    @dcc('Test Date 1')
    def day_count_fraction_calculator_1(start: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        pass

    assert day_count_fraction_calculator_1.__name__ == 'day_count_fraction_calculator_1'

    @dcc('Test Date 2', altnames={'Test'}, ccys={Currencies.CAD})
    def day_count_fraction_calculator_2(start: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        pass


# Generated at 2022-06-24 01:12:58.727267
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    print("\n*** Testing dcfc_30_360_german() ***\n")
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof = datetime.date(2007, 12, 31), datetime.date(2008, 2, 29)
   

# Generated at 2022-06-24 01:13:06.616881
# Unit test for method coupon of class DCC

# Generated at 2022-06-24 01:13:11.816958
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:13:21.204695
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    from datetime import date
    assert round(dcfc_act_365_f(date(2099,1,1), date(2099,12,31), date(2099,12,31)), 14) == Decimal('0.99657534246575')
    print('Passed.')


# Generated at 2022-06-24 01:13:27.751569
# Unit test for method interest of class DCC
def test_DCC_interest():
    """
    Unit test for method interest of class DCC
    """
    principal = Money.usd(100)
    rate = Decimal(0.1)
    start = Date(2016, 8, 1)
    asof = Date(2016, 9, 30)
    end = Date(2016, 10, 31)
    freq = Decimal(2)
    assert (DCCRegistry.temporary_eom().interest(principal, rate, start, asof, end, freq) == Money.usd(1000))


# Generated at 2022-06-24 01:13:34.897249
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')



# Generated at 2022-06-24 01:13:45.326959
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert dcfc_30_360_german(start=start, asof=asof, end=asof) == Decimal('0.16666666666667')

    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert dcfc_30_360_german(start=start, asof=asof, end=asof) == Decimal('0.16666666666667')

    start, asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)

# Generated at 2022-06-24 01:13:50.631069
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["Act/360"].calculate_fraction(
        datetime.date(2019,5,5),
        datetime.date(2019,6,5),
        datetime.date(2020,5,5),
        Decimal(1)
    ) == Decimal(31)/Decimal(360)


# Generated at 2022-06-24 01:14:01.068659
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    method_name = 'find';

    # Test 1: ensure find raises ValueError if name is None
    with raises(TypeError):
        DCCRegistry.find(None)
        # Test 2: ensure find raises ValueError if name is ''
    with raises(TypeError):
        DCCRegistry.find('')
        # Test 3: ensure find raises ValueError if name does not exist
    with raises(TypeError):
        DCCRegistry.find('abc')
        # Test 4: ensure find works for a single name
    assert(DCCRegistry.find('Act/Act') != None)
    # Test 5: ensure find works for multiple names with spaces
    assert(DCCRegistry.find('Act/Act  ') != None)
    assert(DCCRegistry.find('  Act/Act') != None)

# Generated at 2022-06-24 01:14:02.867150
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert math.isclose(dcfc_30_e_plus_360(datetime.date(2018, 5, 25), datetime.date(2018, 7, 1)), 0.1)
    return True
#


# Generated at 2022-06-24 01:14:13.317656
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("act/360")
    assert DCCRegistry.find("act/365")
    assert DCCRegistry.find("30/360")
    assert DCCRegistry.find("act/act")
    assert DCCRegistry.find("act/act isda")
    assert DCCRegistry.find("act/act icma")
    assert DCCRegistry.find("eu i30") # European 30/360
    assert DCCRegistry.find("eu 30") # European 30/360
    assert DCCRegistry.find("30e/360") # European 30/360
    assert DCCRegistry.find("act/act afb")
    assert DCCRegistry.find("actual")
    assert DCCRegistry.find("actual actual")
    assert DCCRegistry.find("actual/360")

# Generated at 2022-06-24 01:14:21.848834
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')



# Generated at 2022-06-24 01:14:32.689877
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:14:39.890856
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    test_dcc = DCC(
        "Actual/360",
        {"Actual360"},
        {"USD", "EUR"},
        _actual_360,
    )
    assert test_dcc.calculate_daily_fraction(datetime.date(2019, 12, 2), datetime.date(2019, 12, 5), datetime.date(2019, 12, 31)) == Decimal('0.0249999999999999985')

# Generated at 2022-06-24 01:14:40.370359
# Unit test for function dcc
def test_dcc():
    assert dcc


# Generated at 2022-06-24 01:14:43.965574
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC("name",{},{},None).name == "name"
    assert DCC("name",{},{},None).altnames == {}
    assert DCC("name",{},{},None).currencies == {}


# Generated at 2022-06-24 01:14:56.058686
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Test the calculate_daily_fraction method of the DCC class.
    """
    ## Run the test:
    asof = datetime.date(2017, 1, 2)
    start = datetime.date(2016, 12, 31)
    end = datetime.date(2017, 1, 30)
    dcf = DCC("ACT/360", {"act360", "act/360"}, {Currencies["EUR"]}, _DCC_ACT_360).calculate_daily_fraction(start, asof, end)

    ## Make sure that we are still compliant:
    assert dcf == ONE / Decimal("360"), "DCC calculate_daily_fraction failed."

# Generated at 2022-06-24 01:15:01.363050
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Performs the test for the function dcfc_30_360_german
    """

    # Create the sample data
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    ans = 0.16666666666667
    
    # Check the answer
    assert round(dcfc_30_360_german(start, asof, asof), 14) == ans


# Generated at 2022-06-24 01:15:13.875832
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert_raises(TypeError, lambda: DCC.calculate_daily_fraction(0, 0, 0, 0, 0))

    assert_raises(ValueError, lambda: DCC.calculate_daily_fraction(datetime.date(2014, 7, 1), datetime.date(2014, 5, 1), datetime.date(2014, 8, 1), 1, 30))
    assert_raises(ValueError, lambda: DCC.calculate_daily_fraction(datetime.date(2014, 7, 1), datetime.date(2014, 9, 1), datetime.date(2014, 8, 1), 1, 30))


# Generated at 2022-06-24 01:15:25.123621
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    ## Create an instance of the machinery:
    dccrm = DCCRegistryMachinery()

    ## Register it:
    dccrm.register(DCC("Act/Act", {"Actual", "Act/Actual"}, {"CHF"}, _act_act))

    ## Find by:
    assert dccrm.find("Act/Act")
    assert dccrm.find("Act/Actual")
    assert dccrm.find("Actual")
    assert dccrm.find("CHF")
    assert not dccrm.find("EUR")

    ## Check the table:

# Generated at 2022-06-24 01:15:36.213855
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-24 01:15:45.619875
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert (round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 10) == Decimal('0.1698630137'))

# Generated at 2022-06-24 01:15:54.697151
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-24 01:15:59.029430
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:16:08.867253
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # Examples of 30/360 ISDA calculation
    dcf_30_360_isda = [0.16666666666667, 0.16944444444444, 1.08333333333333, 1.33333333333333]
    dcf_30_360_isda_test = []
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime

# Generated at 2022-06-24 01:16:19.038754
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    """ Test the dcfc_act_365_f function """
    expected_dcfc_act_365_f = [
        (datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), 1.08493150684932),
        (datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), 1.32876712328767),
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), 0.16986301369863),
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), 0.17260273972603)
    ]

# Generated at 2022-06-24 01:16:26.199378
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=None), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=None), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=None), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:16:34.864186
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    method = getattr(DCCRegistry, 'find')
    assert method.__doc__ == '\n    Attempts to find the day count convention by the given name.\n\n    Note that all day count conventions are registered under stripped, uppercased names. Therefore,\n    the implementation will first attempt to find by given name as is. If it can not find it, it will\n    strip and uppercase the name and try to find it as such as a last resort.\n    '


# Generated at 2022-06-24 01:16:40.169417
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    start, end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_act_365_l(start, end, end), 14) == Decimal('0.16939890710383')
    start, end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_act_365_l(start, end, end), 14) == Decimal('0.17213114754098')
    start, end = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    assert round(dcfc_act_365_l(start, end, end), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-24 01:16:50.598881
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    td = DCC(
        name="30/360",
        altnames=["30-360", "30/360"],
        currencies=_as_ccys({"USD", "VND"}),
        calculate_fraction_method=DCCRegistry._dcc_methods["30/360"],
    )
    assert td.coupon(Money(1, "USD"), 0.1, datetime.date(2014, 7, 1), datetime.date(2014, 12, 31), 1) == Money(0.05, "USD")
    assert td.coupon(Money(1, "USD"), 0.1, datetime.date(2014, 7, 1), datetime.date(2014, 12, 31), 2) == Money(0.025, "USD")



# Generated at 2022-06-24 01:16:58.824767
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    r = DCCRegistryMachinery()
    r.register(DCC("Act/Act", {"ACT/ACT", "ACTUAL/ACTUAL", "ACTUAL-ACTUAL", "ACTUAL-ACT"}, {Currencies["USD"]}, calculate_fraction_actact))
    assert r._is_registered("DUMBA") == False
    assert r._is_registered("Act/Act") == True
    assert r._is_registered("ACT/ACT") == True
    assert r._is_registered("Actual/Actual") == True
    assert r._is_registered("Actual-Actual") == True
    assert r._is_registered("Actual-Act") == True
    assert set(r._buffer_main.keys()) == {"Act/Act"}

# Generated at 2022-06-24 01:17:04.378041
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    """
    Tests for method register of class DCCRegistryMachinery
    """
    dcc = DCC("Act/Act", {"Actual/Actual ISDA", "Act/Act (ISDA)", "Actual/Actual (ISDA)"}, set(), calculate_act_act)
    DCCRegistry.register(dcc)
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Actual/Actual ISDA") is not None
    assert DCCRegistry.find("Act/Act (ISDA)") is not None
    assert DCCRegistry.find("Actual/Actual (ISDA)") is not None



# Generated at 2022-06-24 01:17:12.152800
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex_start, ex_asof, ex_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex_start, asof=ex_asof, end=ex_end), 10) == Decimal('0.5245901639')



# Generated at 2022-06-24 01:17:18.041367
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    start = datetime.date(2018,12,31)
    asof = datetime.date(2019,1,1)
    assert dcfc_nl_365(start, asof, asof, None) == 0.002739726027397



# Generated at 2022-06-24 01:17:26.512336
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:17:36.136630
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-24 01:17:46.182349
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    """
    Tests the function dcfc_act_365_l
    """
    # test example 1
    example_1_start = Date(year=2008, month=2, day=28)
    example_1_asof = Date(year=2008, month=2, day=28)
    expected_value_1 = Decimal("0.16939890710383")

    calculated_value_1 = dcfc_act_365_l(
        start=example_1_start, asof=example_1_asof, end=example_1_asof
    )

    # test example 2
    example_2_start = Date(year=2008, month=2, day=28)
    example_2_asof = Date(year=2008, month=2, day=29)
    expected_value_2 = Dec

# Generated at 2022-06-24 01:17:57.030337
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    output_1_actual = dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof)

# Generated at 2022-06-24 01:18:08.695786
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    import datetime
    from datetime import date
    from decimal import Decimal
    from fractions import Fraction
    from quantulum3 import parser
    from quantulum3.parser import parsed_unit
    from quantulum3.parser.parsed_unit import ParsedUnit
    from quantulum3.quantity import Quantity
    from qf_lib.common.enums.frequency import Frequency
    from qf_lib.common.enums.price_field import PriceField
    from qf_lib.common.enums.trade_field import TradeField
    from qf_lib.common.tickers.tickers import BloombergTicker, BloombergTicker as BT, Ticker
    from qf_lib.common.utils.dateutils.string_to_date import str_to_date