

# Generated at 2022-06-24 01:08:15.283324
# Unit test for function dcc
def test_dcc():
    """
    Unit test for function dcc
    """

    def dummy_dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Dummy function to test function dcc.
        """

    @dcc("test", {"testalt"}, {"USD"})
    def dummy_dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Dummy function to test function dcc.
        """

    assert DCCRegistry.find("test") == DCC("test", {"testalt"}, {"USD"}, dummy_dcfc)

# Generated at 2022-06-24 01:08:25.369158
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """
    Tests the daycount method using ACT/ACT.
    """

    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    rate = Decimal(0.01)
    start_date = datetime.date(2019, 3, 2)
    end_date = datetime.date(2019, 12, 31)
    asof_date = datetime.date(2019, 9, 10)
    dcc = DCCRegistry.find("Act/Act (ICMA)")
    interest = dcc.interest(principal, rate, start_date, asof_date, end_date)
    assert round(interest.qty, 2) == Decimal("45384.92")



# Generated at 2022-06-24 01:08:35.497067
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof),14) == Decimal('0.16939890710383')

# Generated at 2022-06-24 01:08:42.424560
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC("name", {"TEST"}, {"TEST"}, DCFC(lambda start, asof, end, freq: ONE))
    start = Date(2021, 1, 10)
    asof = Date(2021, 1, 18)
    end = Date(2021, 1, 24)
    freq = None
    dcc.calculate_fraction(start, asof, end, freq)



# Generated at 2022-06-24 01:08:50.467999
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof, ex1_end = datetime.date(2008, 3, 3), datetime.date(2008, 5, 30), datetime.date(2008, 10, 10)
    ex2_start, ex2_asof, ex2_end = datetime.date(2008, 3, 3), datetime.date(2008, 10, 10), datetime.date(2009, 3, 3)
    ex3_start, ex3_asof, ex3_end = datetime.date(2008, 3, 3), datetime.date(2009, 3, 3), datetime.date(2010, 3, 3)

# Generated at 2022-06-24 01:08:55.068763
# Unit test for function dcc
def test_dcc():
    assert callable(dcc)
    assert isinstance(dcc("MyDCC", set(["MyDCC_1", "MyDCC_2"]), set([Currencies["USD"]])), Callable)



# Generated at 2022-06-24 01:09:00.230884
# Unit test for function dcc
def test_dcc():
    codecs = (
        ("Test/Act", ["test/act", "test-act", "testact"], ["USD", "EUR"]),
    )
    @dcc(*codecs[0])
    def test_act(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Day count fraction calculation method for 'Test/Act' day count convention.
        """
        ## Check if we have any valid dates:
        if start >= asof or asof >= end:
            ## Nope, return 0:
            return ZERO

        ## Get the fraction:
        return (asof - start).days / (end - asof).days

    def actual(codecs):
        dcc = DCCRegistry.find(codecs[0])

# Generated at 2022-06-24 01:09:12.912759
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    print('dcfc_act_365_l')
    assert round(dcfc_act_365_l(start=datetime.date(2008,1,1), asof=datetime.date(2008,1,1), end=datetime.date(2008,1,1)), 14) == Decimal('0.0027397260273973')
    assert round(dcfc_act_365_l(start=datetime.date(2008,1,1), asof=datetime.date(2009,2,1), end=datetime.date(2009,2,1)), 14) == Decimal('1.02739726027397')

# Generated at 2022-06-24 01:09:22.260429
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Unit test for function dcfc_30_360_german.
    """
    print("Test of function dcfc_30_360_german")
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:09:25.003432
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    assert type(DCCRegistryMachinery())


# Generated at 2022-06-24 01:09:29.190166
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:09:37.407506
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:09:42.665530
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal = principal = Money(1000000, Currencies.USD)
    rate = Decimal("0.025")
    start = datetime.date(2014,  1,  1)
    asof = datetime.date(2014,  1,  1)
    end = datetime.date(2014,  1,  1)
    freq = Decimal(1)
    eom = None
    def test_DCC_coupon_assertions(result: Money, expected: Money):
        assert result == expected
    dcc = DCC("act/360", {"Actual/360"}, _as_ccys({"USD", "CAD", "MXN", "HUF"}), _act_360)
    result = dcc.coupon(principal, rate, start, asof, end, freq, eom)


# Generated at 2022-06-24 01:09:49.657840
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')



# Generated at 2022-06-24 01:09:52.120571
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    # Attempt to find day count convention
    assert DCCRegistry.find("Actual/Actual"), DCCRegistry.find("ActAct")



# Generated at 2022-06-24 01:10:00.129588
# Unit test for method interest of class DCC
def test_DCC_interest():
    pass

# Generated at 2022-06-24 01:10:04.844044
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_360_us

# Generated at 2022-06-24 01:10:11.886295
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Checks if it returns the day count convention by the given name.
    """
    # Setup:
    name = "eoM"
    expected = "EOM"
    # Exercise:
    actual = DCCRegistry.find(name)
    # Verify:
    assert actual.name == expected



# Generated at 2022-06-24 01:10:17.283499
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    #NQP30Y, Start: 2019/6/28 End: 2020/6/30
    assert DCCRegistry.get_first_matching('30/360 (ISDA)').calculate_daily_fraction(datetime.date(2019,6,28),datetime.date(2020,6,30),datetime.date(2020,6,30)) == Decimal('0.00694')
    # NQP30Y, Start: 2019/6/28 End: 2020/6/30
    assert DCCRegistry.get_first_matching('30/360 (ISDA)').calculate_daily_fraction(datetime.date(2019, 6, 28), datetime.date(2020, 6, 29),datetime.date(2020, 6, 30)) == Decimal('0.006944')
    # NQ

# Generated at 2022-06-24 01:10:23.748195
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l(): assert int(dcfc_act_365_l(datetime.date(2019,3,1), datetime.date(2019,9,1), datetime.date(2019,9,1))) == 174


# Generated at 2022-06-24 01:10:34.625060
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.17222222222222')

# Generated at 2022-06-24 01:10:40.445007
# Unit test for function dcfc_act_365_a

# Generated at 2022-06-24 01:10:46.203113
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:10:53.704104
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    r=DCC(
        name="ACT/360",
        altnames=set([]),
        currencies=set([]),
        calculate_fraction_method=lambda start, asof, end, freq: Decimal(
            _get_actual_day_count(asof, end)
        ) / 360,
    )
    principal=Money(100,"USD")
    rate=Decimal(0.01)
    freq=2
    start=datetime.date(2014,  1,  1)
    asof=datetime.date(2015,  8, 31)
    eom=None
    assert r.coupon(principal,rate,start,asof,None,freq,eom)==Money(1.33,"USD")
    eom=15

# Generated at 2022-06-24 01:11:02.156267
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:11:13.040634
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-24 01:11:22.141868
# Unit test for constructor of class DCC
def test_DCC():
    def dcfunc(start, asof, end, freq):
        return ONE
    name = "Test"
    altnames = ("test", "Test")
    currencies = "TRL"
    new_dcc = DCC(name, altnames, currencies, dcfunc)
    assert new_dcc.name == name
    assert new_dcc.altnames == altnames
    assert new_dcc.currencies == Currencies[currencies]
    assert new_dcc.calculate_fraction_method == dcfunc


## =====================================================================================================================
## =====================================================================================================================
## =====================================================================================================================



# Generated at 2022-06-24 01:11:28.043360
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    print("\ntest_DCC_calculate_daily_fraction")
    start = datetime.date(2012, 1, 1)
    asof = datetime.date(2012, 1, 1)
    end = datetime.date(2012, 1, 1)
    freq = None
    assert DCCRegistry.get("ACT/ACT ISDA").calculate_daily_fraction(start, asof, end, freq) == Decimal("0")



# Generated at 2022-06-24 01:11:38.158780
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:11:43.786471
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert format_decimal(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof)) == Decimal('0.16986301369863')
    assert format

# Generated at 2022-06-24 01:11:48.100337
# Unit test for method interest of class DCC
def test_DCC_interest():
    dcc = DCC(name="test",altnames="test",currencies="test",calculate_fraction_method="test")
    dcc.interest(Money(1, "USD"),Decimal(0.5),Date(1,1,1),Date(1,1,1),Date(1,1,1))



# Generated at 2022-06-24 01:11:57.483746
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    print(round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')
    
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-24 01:12:08.579510
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Tests the function dcfc_30_e_360
    Note that tests are 4 rows of the example spreadsheet at:
    https://www.isda.org/a/cq3iE/2003-08-30-ISDA-day-count-convention-specification.xls
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)

# Generated at 2022-06-24 01:12:19.171896
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == 0.16942884946478
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == 0.17216108990194
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == 1.08243131970956
    assert round(dcfc_act_act(start=ex4_start, asof=ex4_asof, end=ex4_asof), 14) == 1.32625945055768
#: Defines the default day count

# Generated at 2022-06-24 01:12:24.802857
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:12:35.257756
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC.coupon(DCC("Actual/actual",
        {"Actual/actual"},
        {},
        _ActualActualActualICMA),
        Money("BGN", 1000.00),
        Decimal("0.1"),
        datetime.date(2014, 1, 1),
        datetime.date(2014, 3, 31),
        datetime.date(2014, 6, 1),
        2,
        ) == Money("BGN", 25.00)

# Generated at 2022-06-24 01:12:42.230227
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """
    start_date = datetime.date(2012, 12, 15)
    asof_date = datetime.date(2015, 12, 31)
    end_date = datetime.date(2016, 1, 6)
    freq = Decimal('2')
    day_count_fraction = DCCRegistry.DCC_ACTUAL_360.calculate_daily_fraction(start_date, asof_date, end_date, freq)
    assert day_count_fraction == Decimal('0')



# Generated at 2022-06-24 01:12:47.590747
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert str(_DCC_ACT_ACT.calculate_daily_fraction(datetime.date(2017, 1, 1),
                                                     datetime.date(2017, 1, 2),
                                                     datetime.date(2017, 2, 28))) == "Decimal('0.002739726027397260')"


# Generated at 2022-06-24 01:12:53.972518
# Unit test for method interest of class DCC
def test_DCC_interest():
    date = datetime.date.today()
    dc_convention = DCC(name="Actual360", altnames={"Act360"}, currencies=_as_ccys({"USD", "EUR"}),
        calculate_fraction_method=_actual_360).interest(Money(1000, Currencies['USD']), 0.06, date, date + datetime.timedelta(days=30))
    assert dc_convention == Money(0.6, Currencies['USD'])


# Generated at 2022-06-24 01:12:59.489584
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Testing function dcfc_act_act
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert ex1_start.year == 2007 and ex1_asof.year == 2008 and ex2_start.year == 2007 and ex2_asof.year == 2008 and ex3

# Generated at 2022-06-24 01:13:07.053433
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal("0.16986301369863")
    assert round(dcfc_act_365_a(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal("0.17213114754098")
    assert round(dcfc_act_365_a(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal("1.08196721311475")

# Generated at 2022-06-24 01:13:13.823098
# Unit test for method interest of class DCC
def test_DCC_interest():
    print("Testing DCC.interest")
    ccy="USD"
    principal=Money(1000000,ccy)
    rate=Decimal(0.01)
    start=Date(2018,1,1)
    asof=Date(2018,12,31)
    dcc=DCCs["ACT/360"]
    ans=dcc.interest(principal,rate,start,asof)
    assert ans.amount==Money(10000,ccy).amount


# Generated at 2022-06-24 01:13:23.705728
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal = Money(1000,'USD')
    rate = Decimal(0.01)
    start = Date(datetime.date(2000, 1, 1))
    asof = Date(datetime.date(2000, 1, 15))
    end = Date(datetime.date(2000, 2, 1))
    freq = Decimal(1)
    eom = None
    x = DCCRegistry.get_dcc('ACT/365')
    result = x.coupon(principal, rate, start, asof, end, freq, eom)
    assert result==Money(0.41, 'USD')



# Generated at 2022-06-24 01:13:25.566331
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dcc = DCCRegistryMachinery()
    assert isinstance(dcc, DCCRegistryMachinery)

# Generated at 2022-06-24 01:13:35.063749
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-24 01:13:42.504313
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_e_plus_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:13:52.107308
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:14:01.534831
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    obj = DCCRegistryMachinery()
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    test_DCCRegistryMachinery_register_principal = principal
    test_DCCRegistryMachinery_register_start = start
    test_DCCRegistryMachinery_register_end = end
    test_DCCRegistryMachinery_register_rate = rate
    test_DCCRegistryMachinery_register_dcc = dcc


# Generated at 2022-06-24 01:14:07.686309
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    """
    start_date, end_date = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_us(start_date, end_date), 11) == Decimal(0.1666666666667)

    start_date, end_date = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_30_360_us(start_date, end_date), 11) == Decimal(0.1694444444444)

    start_date, end_date = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    assert round(dcfc_30_360_us(start_date, end_date), 11)

# Generated at 2022-06-24 01:14:15.994260
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-24 01:14:25.691878
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Test function from QuantLib.xlsm
    assert abs(dcfc_30_360_us(datetime.date(2010, 2, 28), datetime.date(2010, 5, 31),datetime.date(2010, 5, 31)) -
               0.263888888888888) < EPSILON
    assert abs(dcfc_30_360_us(datetime.date(2010, 2, 28), datetime.date(2011, 2, 28), datetime.date(2011, 2, 28)) -
               1.000000000000000) < EPSILON
    assert abs(dcfc_30_360_us(datetime.date(2010, 2, 28), datetime.date(2010, 3, 31), datetime.date(2010, 3, 31)) -
               0.0833333333333333) < EPSILON

# Generated at 2022-06-24 01:14:28.439193
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC(name = "DCC", altnames = "DCC", currencies = "DCC", calculate_fraction_method = DCFC)



# Generated at 2022-06-24 01:14:30.386255
# Unit test for function dcc
def test_dcc():
    @dcc("TestDCC")
    def test_dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return ZERO



# Generated at 2022-06-24 01:14:35.438265
# Unit test for function dcc
def test_dcc():
    ## Check if function dcc is ok with default values:
    @dcc("name")
    def func1(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return Decimal(1)

    ## Check if function dcc is ok with non-default values:
    @dcc("name", {"altname1", "altname2"}, {Currencies["EUR"], Currencies["USD"]})
    def func2(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return Decimal(1)

    ## Check if the day count fraction calculation functions have been properly decorated:
    assert func1.__dcc.name == "name"
    assert func2.__dcc.name == "name"


# Generated at 2022-06-24 01:14:37.182645
# Unit test for function dcc
def test_dcc():
    @dcc("test", {"test2"})
    def test_func():
        pass

    assert test_func.__dcc.name == "test"
    assert test_func.__dcc.altnames == {"test2"}



# Generated at 2022-06-24 01:14:47.116846
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-24 01:14:56.566888
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:15:06.288789
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Unit-test for method coupon of class DCC.
    """
    ## Import packages:
    import unittest
    
    ## Define class:
    class DCC_coupon_Test(unittest.TestCase):
        """
        Defines a test-class for method coupon of class DCC.
        """
        def test_DCC_coupon_NO_1(self):
            """
            Test method coupon of class DCC with DCC_30360_ISDA_convention.
            """
            ## Get DCC:
            dcc = DCC_Registry.get('30360')

            ## Get dates:
            start = Date(2008, 7, 7)
            asof = Date(2015, 10, 6)
            end = Date(2015, 10, 6)
            freq = 4



# Generated at 2022-06-24 01:15:15.190750
# Unit test for function dcc
def test_dcc():
    @dcc("FACTOR", {"factor"}, {"EUR", "USD"})
    def factor_dcc(start, asof, end, freq=None):
        return ONE
    assert factor_dcc.__dcc.name == "FACTOR"
    assert factor_dcc.__dcc.altnames == {"factor"}
    assert factor_dcc.__dcc.currencies == {"EUR", "USD"}
    assert factor_dcc.__dcc.calculate_fraction_method == factor_dcc
    assert DCCRegistry.find("factor").name == "FACTOR"
    with raises(TypeError):
        @dcc("FACTOR", {"factor"}, {"EUR", "USD"})
        def factor_dcc(start, asof, end, freq=None):
            return

# Generated at 2022-06-24 01:15:26.224547
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007,12,28),asof=datetime.date(2008,2,28),end=datetime.date(2008,2,28)),14)==round(Decimal('0.16666666666667'),14)
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007,12,28),asof=datetime.date(2008,2,29),end=datetime.date(2008,2,29)),14)==round(Decimal('0.16944444444444'),14)

# Generated at 2022-06-24 01:15:34.133751
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    for test_params in [(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)), (datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)), (datetime.date(2007, 10, 31), datetime.date(2008, 11, 30))]:
        start, asof = test_params
        assert round(dcfc_act_act(start, asof, asof), 14) == round(dcfc_act_act_mc(start, asof, asof), 14)


fail_round_to_half_down = 0

# Generated at 2022-06-24 01:15:39.555137
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    f = DCCRegistry.register
    dcc = DCC("Act/Act", {"Actual/Actual"}, {"USD"}, calculate_actual_actual)
    with pytest.raises(TypeError, match = "Day count convention 'Act/Act' is already registered"):
        f(dcc)


# Generated at 2022-06-24 01:15:49.596140
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-24 01:16:00.250802
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    start_date = datetime.date(1,1,1)
    end_date = datetime.date(2018,12,31)
    asof_date = datetime.date(2018,1,1)
    res = dcfc_act_365_f(start_date,asof_date,end_date)
    assert res == 1761/Decimal(365)


# Generated at 2022-06-24 01:16:10.800725
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc = DCC('DCC', {'A', 'B'}, {Currencies['AED'], Currencies['AFN']}, lambda s, a, e, f: (e - a).days)

    assert dcc.calculate_daily_fraction(datetime.date(2010, 12, 31), datetime.date(2011, 1, 1), datetime.date(2011, 1, 3)) == Decimal('1')
    assert dcc.calculate_daily_fraction(datetime.date(2010, 12, 31), datetime.date(2011, 1, 1), datetime.date(2011, 1, 1)) == Decimal('0')

# Generated at 2022-06-24 01:16:21.602695
# Unit test for method interest of class DCC
def test_DCC_interest():
    bbg_convention = [
        {'start_date': datetime.date(2018, 11, 1),
         'end_date': datetime.date(2019, 5, 1),
         'interest': Money(2.194, 'EUR'),
         'asof': datetime.date(2019, 2, 4)},
        {'start_date': datetime.date(2019, 5, 1),
         'end_date': datetime.date(2019, 11, 1),
         'interest': Money(2.194, 'EUR'),
         'asof': datetime.date(2019, 7, 4)}
        ]
    for data in bbg_convention:
        start_date = data.get('start_date')
        asof = data.get('asof')

# Generated at 2022-06-24 01:16:32.937536
# Unit test for method interest of class DCC
def test_DCC_interest():
    import unittest
    from .currencies import Currencies

    from .exchange import ExchangeRate

    from .monetary import Money

    from .pricing import Price
    from .references import CDOR, CDOR6M

    USD, GBP, CAD = Currencies["USD"], Currencies["GBP"], Currencies["CAD"]
    CDOR_RATE = Price(AsOf=datetime.date(2019, 5, 1), Price=Decimal("2.00"), PriceCcy=CAD)
    CDOR6M_RATE = Price(AsOf=datetime.date(2019, 5, 1), Price=Decimal("2.00"), PriceCcy=CAD)
    USD_GBP = ExchangeRate(AsOf=datetime.date(2019, 5, 1), Rate=Decimal("0.76"))
    USD_C

# Generated at 2022-06-24 01:16:40.114960
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Eq. 1
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2007, 12, 28), end=datetime.date(2007, 12, 28)), 14) == Decimal('0')
    # Eq. 2
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    # Eq. 3

# Generated at 2022-06-24 01:16:45.546804
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    # Test case 1
    start_date = datetime.date(2019, 2, 28)
    end_date = datetime.date(2019, 3, 28)
    asof_date = datetime.date(2019, 3, 10)
    expected = 1 / 365
    actual = dcfc_act_365_f(start_date, asof_date, end_date)
    assert expected == actual

    # Test case 2
    start_date = datetime.date(2007, 12, 28)
    end_date = datetime.date(2008, 2, 29)
    asof_date = datetime.date(2008, 2, 29)
    expected = 1.72328767123288
    actual = dcfc_act_365_f(start_date, asof_date, end_date)

# Generated at 2022-06-24 01:16:50.753281
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert(round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == 0.16986301369863)
    assert(round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == 0.16986301369863)
    assert(round(dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == 1.08219178082192)

# Generated at 2022-06-24 01:16:58.960733
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:17:04.428959
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Unit test for method coupon of class DCC
    """
    from .monetary import Money
    from .currencies import Currencies

    #: The principal
    principal_usd = Money("40000.00", Currencies["USD"])
    #: The interest rate
    rate = 0.04
    #: The starting date
    start_date = datetime.date(2014, 1, 1)
    #: The asof date
    asof_date = datetime.date(2015, 12, 31)
    #: The ending date
    end_date = datetime.date(2016, 1, 1)
    #: The frequency
    freq = Decimal(2)
    #: The end of month date
    eom = 1

    #: The expected coupon

# Generated at 2022-06-24 01:17:14.358802
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    """
     Test for method register of class DCCRegistryMachinery
    """

    # Define a start date
    start_date = datetime.date(2007, 12, 28)

    # Define an end date
    end_date = datetime.date(2008, 2, 28)

    # Define a rate
    rate = Decimal(0.01)

    # Define a principal
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())

    # Define a list of day count conventions

# Generated at 2022-06-24 01:17:25.476826
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    '''
    Tests the function dcfc_30_360_german.
    '''
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:17:36.042416
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("Act/360") != None
    assert DCCRegistry.find("Actual/Actual") != None
    assert DCCRegistry.find("Act/365") != None
    assert DCCRegistry.find("Actual/Actual ISDA") != None
    assert DCCRegistry.find("30/360") != None
    #assert DCCRegistry.find("Act/Act") != None
    assert DCCRegistry.find("Act/Act ISMA") != None
    assert DCCRegistry.find("Act/Act ICMA") != None
    assert DCCRegistry.find("Act/Act AFB") != None
    assert DCCRegistry.find("30E/360 ISDA") != None
    assert DCCRegistry.find("30E+/360") != None
    #assert DCCReg

# Generated at 2022-06-24 01:17:45.329971
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCRegistry.get_by_name("act/360").coupon(Money(100, "USD"), 0.05, datetime.date(2017, 10, 1), datetime.date(2017, 11, 20), datetime.date(2017, 12, 1), 2).as_double() == 2.5
    assert DCCRegistry.get_by_name("act/365").coupon(Money(100, "USD"), 0.05, datetime.date(2017, 10, 1), datetime.date(2017, 11, 20), datetime.date(2017, 12, 1), 2).as_double() == 2.6759

# Generated at 2022-06-24 01:17:56.826765
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:18:08.512637
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Arrange
    start = datetime.date(2017, 2, 1)
    asof = datetime.date(2017, 3, 1)
    end = datetime.date(2017, 3, 1)
    freq = 2
    dcc = DCC(
        name='ACT/365', altnames={'ACT/365'}, currencies={}, calculate_fraction_method=_DCC_ACT_365.calculate_fraction_method)

    # Act
    retval = dcc.calculate_fraction(start, asof, end, freq)

    # Assert
    assert retval == Decimal('0.0219801980198019801980')
    assert id(retval) != id(Decimal('0.0219801980198019801980'))

