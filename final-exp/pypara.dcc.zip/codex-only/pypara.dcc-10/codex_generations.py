

# Generated at 2022-06-24 01:08:15.073220
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Tests method find of class DCCRegistryMachinery.
    """
    # Assert that the method find of class DCCRegistryMachinery returns None on empty table:
    assert not DCCRegistryMachinery().find("dccname")
    # Assert that the method find of class DCCRegistryMachinery returns the corresponding DCC on non-empty table:
    assert DCCRegistryMachinery().register(DCC("dccname", set(), set(), _actual365_actact)).find("dccname") == DCC(
        "dccname", set(), set(), _actual365_actact
    )
    # Assert that the method find of class DCCRegistryMachinery returns the corresponding DCC on non-empty table:

# Generated at 2022-06-24 01:08:24.569740
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Tests the method calculate_daily_fraction of the class DCC
    """
    #import the class
    from financepy.models.FinModel import DCC

    start = datetime.date(2016, 1, 1)
    end = datetime.date(2016, 4, 1)
    asof = datetime.date(2016, 1, 15)
    asof_minus_1 = asof - datetime.timedelta(days=1)
    freq = 1

    dcc = DCC("ACT/360", set(), _as_ccys({}), _act_360_method)

    # Get t-1 for asof
    asof_minus_1 = asof - datetime.timedelta(days=1)

    # Get the yesterday's factor

# Generated at 2022-06-24 01:08:31.236025
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """
    Testing for dcfc_act_act_icma
    """
    # Test function with non-leap-year date
    ex1_start = datetime.datetime(2019, 3, 2).date() # Non-leap-year date
    ex1_asof = datetime.datetime(2019, 9, 10).date() # Non-leap-year date
    ex1_end = datetime.datetime(2020, 3, 2).date() # Non-leap-year date
    ex1_freq = Decimal(4)
    ex1_output = Decimal('0.5245901639')
    obt1_output = dcfc_act_act_icma(ex1_start, ex1_asof, ex1_end, ex1_freq)

# Generated at 2022-06-24 01:08:42.561938
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    # unit test for the function dcfc_act_365_f
    assert dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16986301369863'), "dcfc_act_365_f computation is wrong"
    assert dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.17260273972603'), "dcfc_act_365_f computation is wrong"

# Generated at 2022-06-24 01:08:50.225172
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    DCC.coupon returns Money object
    """
    from .currencies import USD
    from datetime import date
    from .monetary import Money
    s = date.today()
    a = date.today()
    e = date.today() + relativedelta(months=1)
    assert isinstance(DCCRegistry.calculate_fraction(DCCRegistry.ACTUAL_360, s, a, e), Decimal)
    assert isinstance(DCCRegistry.calculate_fraction(DCCRegistry.ACTUAL_360, s, a, e, 2), Decimal)
    assert isinstance(DCCRegistry.ACTUAL_360.interest(Money(1000, USD), 0.1, s, a, e), Money)

# Generated at 2022-06-24 01:08:54.846782
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from dcc import DCC

    start = datetime.date(2026, 5, 7)
    prevdate = datetime.date(2026, 11, 7)
    nextdate = datetime.date(2026, 11, 7)
    actual = DCC.coupon(start,prevdate,nextdate)
    expected = 10.00
    assert actual == expected



# Generated at 2022-06-24 01:09:01.902903
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC('Act/365',{},{},None) == DCC('Act/365',set(),set(),None)
    assert DCC('Act/365',{'act/365'},{},None) == DCC('Act/365',{'act/365'},set(),None)
    assert DCC('Act/365',{},{'EUR'},None) == DCC('Act/365',set(),{Currencies['EUR']},None)
    assert DCC('Act/365',{},{},None) == DCC('Act/365',set(),set(),None)


# Generated at 2022-06-24 01:09:07.111386
# Unit test for function dcc
def test_dcc():
    with pytest.raises(TypeError):
        @dcc("Act/Act")
        def foobar():
            pass
        @dcc("Act/Act")
        def bazbar():
            pass

    @dcc("test")
    def test():
        pass
    assert test.__dcc.name == "test"
    assert list(test.__dcc.altnames) == []
    assert list(test.__dcc.currencies) == []
    assert test.__dcc.calculate_fraction_method is test

#: Defines the year fraction calculation function signature.
YFC = Callable[[Date, Date, Optional[Union[int, Decimal, Fraction]]], Decimal]



# Generated at 2022-06-24 01:09:19.001033
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:09:28.698369
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
test_dcfc_act_act_icma()



# Generated at 2022-06-24 01:09:38.246699
# Unit test for method interest of class DCC
def test_DCC_interest():
    dcc = DCC('act/360', {'act/360'}, {'USD', 'EUR'}, dccsdod)
    principal1 = Money(100, 'USD')
    principal2 = Money(100, 'EUR')
    rate = Decimal(0.1)
    start = datetime.date(2010,1,1)
    asof1 = datetime.date(2010,3,30)
    asof2 = datetime.date(2010,3,31)
    end1 = datetime.date(2010,3,31)
    end2 = datetime.date(2010,4,1)
    freq = Decimal(0.5)
    dcc.interest(principal1, rate, start, asof1, end1, freq) == Money(5.00, 'USD')
   

# Generated at 2022-06-24 01:09:50.022101
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    registry1 = DCCRegistryMachinery()
    dcc = DCC("Act/Act", {"Actual/Actual", "Actual/365", "Actual/Actual ISDA", "Actual/Actual ICMA"}, {Currencies["USD"]}, _actact)
    registry1.register(dcc)
    assert registry1._find_strict("act/act") is not None
    assert registry1._find_strict("Act/Act") is not None
    assert registry1._find_strict("Act/Act ") is not None
    assert registry1._find_strict("Actual/Actual") is not None
    assert registry1._find_strict("Actual/365") is not None
    assert registry1._find_strict("Actual/Actual ISDA") is not None
    assert registry1._find_

# Generated at 2022-06-24 01:09:58.574857
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    ## Mock a dummy DCC:
    dcc1 = DCC(
        name="TEST",
        altnames={"X"},
        currencies={"ISK"},
        calculate_fraction_method=lambda start, asof, end, freq: Decimal(0.1),
    )
    dcc2 = DCC(
        name="TEST",
        altnames={"X"},
        currencies={"TRY"},
        calculate_fraction_method=lambda start, asof, end, freq: Decimal(0.2),
    )

    ## Instantiate the registry:
    registry = DCCRegistryMachinery()

    ## Register the DCC:
    registry.register(dcc1)
    registry.register(dcc2)

    ## Assert on registration:
    assert "TEST" in registry.table
   

# Generated at 2022-06-24 01:10:04.880658
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print("dcfc_act_365_a, example 1: ", round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-24 01:10:10.206453
# Unit test for function dcc
def test_dcc():
    @dcc("Usual/Usual", altnames={"U/U", "U-U"})
    def _dcfc_usual(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return end - start

    @dcc("Actual/Actual", altnames={"Act/Act", "A/A", "A-A"})
    def _dcfc_actual(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return (end - start).days / 365.25

    assert _dcfc_actual.__dcc.name == "Actual/Actual"
    assert _dcfc_usual.__dcc.name == "Usual/Usual"




# Generated at 2022-06-24 01:10:16.335460
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """
    Unit tests for dcfc_30_360_isda()
    """
    ex1_start, ex1_end = datetime.date(2013, 3, 4), datetime.date(2013, 5, 31)
    ex2_start, ex2_end = datetime.date(2013, 5, 1), datetime.date(2013, 7, 31)
    ex3_start, ex3_end = datetime.date(2013, 7, 1), datetime.date(2013, 9, 30)
    ex4_start, ex4_end = datetime.date(2013, 9, 30), datetime.date(2013, 12, 31)
    assert dcfc_30_360_isda(ex1_start, ex1_start, ex1_end) == 0.1666666666666667
    assert dcfc

# Generated at 2022-06-24 01:10:24.145710
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2002, 4, 2), datetime.date(2020, 4, 2), datetime.date(2020, 4, 2)), 14) == Decimal('0.95444444444444')



# Generated at 2022-06-24 01:10:31.717691
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:10:40.113451
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC('MC', {'MC', 'MCBDA'}, {Currencies['USD']}, _day_count_fraction_actual_fixed_fixed).coupon(Money('USD', 3), Decimal(.01), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), Decimal(1), 1) == Money('USD', 0)

# Generated at 2022-06-24 01:10:51.109749
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act (ICMA)")
    assert round(dcc.calculate_fraction(start, end, end, 2.0), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end, 2).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start, 2).qty == Decimal('0.00')


# Generated at 2022-06-24 01:10:58.401492
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act(Date(2007, 12, 28), Date(2008, 2, 28), Date(2008, 2, 28)) == Decimal(0.16942884946478)
    assert dcfc_act_act(Date(2007, 12, 28), Date(2008, 2, 29), Date(2008, 2, 29)) == Decimal(0.17216108990194)
    assert dcfc_act_act(Date(2007, 10, 31), Date(2008, 11, 30), Date(2008, 11, 30)) == Decimal(1.08243131970956)
    assert dcfc_act_act(Date(2008, 2, 1), Date(2009, 5, 31), Date(2009, 5, 31)) == Decimal(1.32625945055768)

# Generated at 2022-06-24 01:11:05.882143
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_german(start=start, asof=asof, end=asof), 14) == Decimal('0.16666666666667')

    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_30_360_german(start=start, asof=asof, end=asof), 14) == Decimal('0.16944444444444')

    start, asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)

# Generated at 2022-06-24 01:11:10.506624
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    import doctest
    doctest.run_docstring_examples(dcfc_act_365_a, globals())


# Generated at 2022-06-24 01:11:14.798989
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2013, 4, 4), asof=datetime.date(2014, 4, 4), end=datetime.date(2014, 4, 4)), 6) == Decimal('1.000000')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2013, 4, 30), asof=datetime.date(2014, 4, 30), end=datetime.date(2014, 4, 30)), 6) == Decimal('1.000000')

# Generated at 2022-06-24 01:11:20.179547
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    try:
        dccreg = DCCRegistryMachinery()
        ## Attempt to register an existing DCC:
        dccreg.register(dccreg.table["Act/Act"])
        assert False
    except TypeError:
        assert True
DCCRegistry = DCCRegistryMachinery()

DCCRegistry.register(
    DCC(
        "Act/Act",
        {"Actual/Actual", "Act/Act"},
        {Currencies["USD"], Currencies["EUR"]},
        _act365,
    )
)

DCCRegistry.register(
    DCC(
        "Act/360",
        {"Actual/360", "Act/360"},
        {Currencies["USD"]},
        _act360,
    )
)


# Generated at 2022-06-24 01:11:28.671889
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(datetime.date(2019, 7, 31), datetime.date(2019, 8, 31), datetime.date(2020, 2, 28)) == 0.16666666666666666
    assert dcfc_30_360_us(datetime.date(2019, 7, 31), datetime.date(2019, 8, 31), datetime.date(2020, 2, 29)) == 0.16944444444444444
    assert dcfc_30_360_us(datetime.date(2019, 7, 31), datetime.date(2019, 8, 31), datetime.date(2020, 8, 31)) == 1.0833333333333333

# Generated at 2022-06-24 01:11:33.396029
# Unit test for function dcc
def test_dcc():
    @dcc("Foo", {"bar", "baz"})
    def dcff(start: Date, asof: Date, end: Date, freq: Decimal) -> Decimal:
        return ZERO

    assert dcff.__dcc.name == "Foo"
    assert dcff.__dcc.altnames == {"bar", "baz"}
    assert dcff.__dcc.currencies == set()
    assert dcff.__dcc.calculate_fraction_method == dcff



# Generated at 2022-06-24 01:11:41.029178
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')


# Generated at 2022-06-24 01:11:51.615683
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-24 01:11:57.052993
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:12:04.914031
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.17222222222222')

# Generated at 2022-06-24 01:12:14.813708
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-24 01:12:24.089380
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=ex1_asof), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=ex2_asof), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=ex3_asof), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:12:35.172454
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dcc = DCCRegistryMachinery()
    assert not dcc.find("AAA")
    assert dcc.find("ACT/ACT")

# Create a single instance which would be used to get the day count convention:
DCCRegistry: DCCRegistryMachinery = DCCRegistryMachinery()

## Register all day count conventions:


# Generated at 2022-06-24 01:12:39.460405
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(datetime.date(2012,12,31), datetime.date(2013,12,31), datetime.date(2013,12,31)) == Decimal('1.00000000000000')



# Generated at 2022-06-24 01:12:51.220441
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Test method calculate_fraction of class DCC.
    """
    ## Create test data:
    start = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 2)
    asof = datetime.date(2017, 1, 2)

    ## Create a test method:
    def test_dcfc(start, asof, end, freq):
        return ONE

    ## Create a DCC object:
    dcc = DCC(
        name="Test DCC",
        altnames=set(),
        currencies=set(),
        calculate_fraction_method=test_dcfc,
    )

    ## Perform test:
    assert dcc.calculate_fraction(start, asof, end) == ONE

# Generated at 2022-06-24 01:13:03.476487
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    """
    Unit test for function dcfc_act_365_a()
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:13:06.973568
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert dcfc_act_act_icma(datetime.date(2009, 2, 28), datetime.date(2009, 3, 2), datetime.date(2009, 8, 28)) == Decimal('0.03424657534246575342465753')



# Generated at 2022-06-24 01:13:14.501003
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """
    Test function: dcfc_30_360_isda
    """

    # get test data
    data = _get_test_data()
    # loop over data
    for d in data:
        # get end date
        end_date = _get_end_date(d)
        # compute day count fraction
        dcf = dcfc_30_360_isda(**d)
        # check result
        assert dcf == Decimal(d["DFC"])



# Generated at 2022-06-24 01:13:25.273246
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:13:34.991852
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ## Tests are only copied from the source code
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')


# Generated at 2022-06-24 01:13:45.351873
# Unit test for function dcfc_nl_365

# Generated at 2022-06-24 01:13:51.710986
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    name = 'AnotherDCC'
    altnames = {'AltName1', 'AltName2'}
    currencies = {Currency.of('USD'), Currency.of('EUR')}
    calculate_fraction_method = lambda s, a, e, f: Decimal(1)
    dcc = DCC(name, altnames, currencies, calculate_fraction_method)
    DCCRegistry.register(dcc)
    assert DCCRegistry.find(name) == dcc
    assert DCCRegistry.find('AltName1') == dcc
    assert DCCRegistry.find('AltName2') == dcc
    assert DCCRegistry.find('AltName3') is None


# Generated at 2022-06-24 01:14:01.755251
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    """
    Unit test for function dcfc_act_365_f
    """
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17260273972603')
    assert round(dcfc_act_365_f(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:14:07.923158
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ## Example #1:
    assert round(
        dcfc_30_360_us(
            start=datetime.date(2007, 12, 28),
            asof=datetime.date(2008, 2, 28),
            end=datetime.date(2008, 2, 28)
        ),
        14
    ) == Decimal('0.16666666666667')

    ## Example #2:
    assert round(
        dcfc_30_360_us(
            start=datetime.date(2007, 12, 28),
            asof=datetime.date(2008, 2, 29),
            end=datetime.date(2008, 2, 29)
        ),
        14
    ) == Decimal('0.16944444444444')

    ## Example #3:

# Generated at 2022-06-24 01:14:16.443160
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:14:26.021813
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # dcfc_30_360_us(start=datetime.date(year=2020, month=3, day=31), asof=datetime.date(year=2020, month=5, day=31))
    assert dcfc_30_360_us(start=datetime.date(year=2020, month=3, day=31), asof=datetime.date(year=2020, month=5, day=31)) == 0.067222222222222
    assert dcfc_30_360_us(start=datetime.date(year=2020, month=1, day=31), asof=datetime.date(year=2020, month=6, day=1)) == 0.1728
    # dcfc_30_360_us(start=datetime.date(year=2019, month=7,

# Generated at 2022-06-24 01:14:32.397296
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    """Test dcfc_30_e_plus_360 for correctness."""
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:14:44.350506
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .currencies import Eur, Usd
    from .monetary import Money
    from .time import today
    from .zpy.conventions import DCC

    ## Create a reference date:
    date = datetime.date(2017, 12, 12)

    ## Get day count convention:
    dcc = DCC.REGISTRY.get("ACT/360")
    assert dcc

    ## Create a euro money:
    eur = Money(100.0, Eur)

    ## Calculate the interest:
    assert dcc.interest(eur, Decimal("0.0"), date, date, date) == Money(0.0, Eur)
    assert dcc.interest(eur, Decimal("0.035"), date, date, date) == Money(0.35, Eur)

# Generated at 2022-06-24 01:14:56.794377
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    import unittest

    class _Test(unittest.TestCase):
        @classmethod
        def setUpClass(cls) -> None:
            pass
        
        @classmethod
        def tearDownClass(cls) -> None:
            pass
        
        def setUp(self) -> None:
            self._registry = DCCRegistryMachinery()
            self._registry.register(DCC('dcc-test', set(), set(), None))
        
        
        def tearDown(self) -> None:
            self._registry = None
        
        def test_DCCRegistryMachinery_find_1(self):
            self.assertIsNotNone(self._registry.find('dcc-test'))

# Generated at 2022-06-24 01:15:04.147257
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_e_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:15:14.211696
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC(name="1/1",
              currencies=Currencies.defaults(),
              calculate_fraction_method=lambda s, a, e, f: ONE * _get_actual_day_count(a, e) / _get_actual_day_count(s, e))
    assert dcc.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal(0)
    assert dcc.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == Decimal(1.0)

# Generated at 2022-06-24 01:15:23.151112
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:15:32.566018
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    import unittest
    import unittest.mock
    import random
    import datetime

    # Mock functions
    with unittest.mock.patch('finance.dcfc_act_act.calendar.isleap'):
        # Mock calendar.isleap to return False - unittest.mock.patch is a context manager
        calendar.isleap.return_value = False
        # set start and end date
        start = datetime.date(2007, 12, 28)
        end = datetime.date(2008, 2, 29)
        result = dcfc_act_act(start, end, end)
        assert result == 0.17671232876712328


# Generated at 2022-06-24 01:15:44.104304
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    '''
    Test to confirm that the day count fraction is computed correctly
    
    '''
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    

# Generated at 2022-06-24 01:15:53.397415
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    ## Define the principal amount:
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())

    ## Define the dates:
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)

    ## Define the rate:
    rate = Decimal(0.01)

    ## Find the registry item:
    registry = DCCRegistry.find("Act/Act")

    ## Check the calculated fraction:
    assert round(registry.calculate_fraction(start, end, end), 14) == Decimal("0.16942884946478")

    ## Calculate the interest:
    assert registry.interest(principal, rate, start, end, end).qty == Decimal("1694.29")

    ##

# Generated at 2022-06-24 01:15:57.591289
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 4) == 0.1694
    assert round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 4) == 0.1721
    assert round(dcfc_act_365_l(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 4) == 1.0820

# Generated at 2022-06-24 01:16:05.808539
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
    assert round(dcfc_act_act_icma(datetime.date(2018, 8, 3), datetime.date(2019, 3, 9), datetime.date(2019, 8, 3)), 10) == Decimal('0.4967741935')
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2020, 3, 1), datetime.date(2020, 9, 1), 2), 10) == Decimal('0.5034965035')


# Generated at 2022-06-24 01:16:14.937440
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dccReg = DCCRegistryMachinery()

    # Test find method
    assert dccReg.find("act/act") == None

    # Test is_registered method
    assert dccReg._is_registered("act/act") == False

    # Test register method
    assert dccReg.register(DCC("Act/Act", {"ACT"}, {"USD"}, _act_act_isda_method)) == None

    # Test find method
    assert dccReg.find("act/act") == DCC("Act/Act", {"ACT"}, {"USD"}, _act_act_isda_method)

    # Test is_registered method
    assert dccReg._is_registered("act/act") == True

# Creates the DCC registration machinery:
_DCC_REGISTRY = DCCRegistryMachinery()

# Register new D

# Generated at 2022-06-24 01:16:24.083387
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    print(dcfc_30_360_german(datetime.date(2020, 2, 28), datetime.date(2020, 3, 31), datetime.date(2020, 3, 31)))
    print(dcfc_30_360_german(datetime.date(2020, 2, 29), datetime.date(2020, 3, 31), datetime.date(2020, 3, 31)))
    print(dcfc_30_360_german(datetime.date(2020, 3, 31), datetime.date(2020, 4, 30), datetime.date(2020, 4, 30)))
    print(dcfc_30_360_german(datetime.date(2020, 3, 31), datetime.date(2020, 4, 30), datetime.date(2020, 4, 30)))

# Generated at 2022-06-24 01:16:30.164145
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-24 01:16:35.985334
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
  dcc = DCCRegistryMachinery()
  dcc.register("Act/365")
  assert(dcc.find("act/365") == "Act/365")
  assert(dcc.find("  ACT/365 ") == "Act/365")
  assert(dcc.find("Actual/365") == None)
  
DCCRegistry = DCCRegistryMachinery()



# Generated at 2022-06-24 01:16:41.348885
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    '''
    Define a known day count convention:
    '''
    def act_act(s: Date, a: Date, e: Date, f: Decimal) -> Decimal:
        '''
        Calculates day count fraction by the Actual Actual method.
        '''
        ## Do we have any leap year?
        has_any_leapday = _has_any_leapday(s, e)

        ## Get the number of years:
        years = e.year - s.year

        ## Get denominator:
        den = 365 + has_any_leapday

        ## Get numerator:
        num = (e - s).days + 1

        ## Return the fraction:
        return Decimal(num) / Decimal(years * den + num)

    ## Register the day count convention:

# Generated at 2022-06-24 01:16:52.741661
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof = datetime.date(2009, 2, 28), datetime.date(2010, 3, 31)
    ex6_start, ex6_asof = datetime.date(2010, 2, 28), dat

# Generated at 2022-06-24 01:17:00.627745
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    """
    Unit test for method register of class DCCRegistryMachinery
    """
    obj = DCCRegistryMachinery()
    obj.register(DCC("Act/Act", {"a/a"}, {"USD", "TRY"}, dcfc_act_act))
    assert "Act/Act" in obj._buffer_main
    assert "a/a" in obj._buffer_altn
    assert "USD" in obj._buffer_main["Act/Act"].currencies

    try:
        obj.register(DCC("Act/Act", {"a/a"}, {"INR", "TRY"}, dcfc_act_act))
        raise AssertionError("Should have raised error")
    except TypeError:
        pass


# Generated at 2022-06-24 01:17:06.480119
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    print(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof))

# Generated at 2022-06-24 01:17:12.603290
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')



# Generated at 2022-06-24 01:17:24.066391
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:17:28.558012
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    try:
        x = DCCRegistry.find("")
        assert False
    except TypeError as ex:
        assert str(ex) == "name must not be empty."



# Generated at 2022-06-24 01:17:38.031907
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    dcfc_act_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))
    dcfc_act_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29))
    dcfc_act_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30))
    dcfc_act_360(datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), datetime.date(2009, 5, 31))

# Generated at 2022-06-24 01:17:48.206438
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:17:49.306798
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    a = DCCRegistryMachinery()
    assert a._buffer_main == {}
    assert a._buffer_altn == {}


# Generated at 2022-06-24 01:17:56.955506
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    '''Verifies that the output is the same as the example
    '''
    test_start = datetime.date(2017, 12, 1)
    test_asof = datetime.date(2018, 1, 1)
    test_end = datetime.date(2019, 1, 1)
    test_output = round(dcfc_act_365_f(test_start, test_asof, test_end, 30),14)
    desired_output = 0.002739726027
    assert test_output == desired_output



# Generated at 2022-06-24 01:18:08.624586
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc={"name": "Act/Act", "altnames": {}, "currencies": {}, "calculate_fraction_method": lambda start, asof, end, freq:
    ((end - start).days / 365.0) if end.year == start.year else (
    (end - start).days / 365.25) * ((end.year - start.year) + ((end.month - start.month) / 12.0) + ((end.day - start.day) / 365.0))}
    dcc=DCC(**dcc)
    a = DCCRegistryMachinery()
    a.register(dcc)
    assert a.find("Act/Act") == dcc
    assert a.find("act/act") == dcc
    assert a.find("act/Act") == dcc

#