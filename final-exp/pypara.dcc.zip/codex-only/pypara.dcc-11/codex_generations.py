

# Generated at 2022-06-24 01:08:13.003351
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)),14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 2, 29)),14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008, 11, 30)),14) == Decimal('1.08219178082192')

# Generated at 2022-06-24 01:08:20.021586
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(datetime.date(2008, 1, 1), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14)  == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(datetime.date(2008, 1, 30), datetime.date(2008, 3, 3), datetime.date(2008, 3, 3)), 14)  == Decimal('0.3')
    assert round(dcfc_30_360_german(datetime.date(2008, 1, 30), datetime.date(2008, 3, 31), datetime.date(2008, 3, 31)), 14)  == Decimal('0.31111111111111')

# Generated at 2022-06-24 01:08:24.432279
# Unit test for method interest of class DCC
def test_DCC_interest():
    money = Money(100)
    rate = 1/365.0
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = None
    freq = None
    dcc = DCC("ACT/ACT", set(), set(), DCCRegistry.get("ACT/ACT"))
    assert dcc.interest(money, rate, start, asof, end, freq) == Money(0.273972602739726)



# Generated at 2022-06-24 01:08:34.962531
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC(
        name="ACTUAL_365L", altnames={"special"}, currencies={"USD"}, calculate_fraction_method=lambda x,y,z,t: ONE
    )
    assert dcc.calculate_fraction(datetime.date(2015,1,1),datetime.date(2015,1,2),datetime.date(2015,1,2)) == ONE
    assert dcc.calculate_fraction(datetime.date(2015,1,1),datetime.date(2015,1,2),datetime.date(2015,1,1)) == ZERO
    assert dcc.calculate_fraction(datetime.date(2015,1,1),datetime.date(2015,1,1),datetime.date(2015,1,1)) == ZERO

# Unit test

# Generated at 2022-06-24 01:08:44.587859
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) ==  Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) ==  Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14)

# Generated at 2022-06-24 01:08:56.399241
# Unit test for method coupon of class DCC
def test_DCC_coupon():

    ### Test 1:
    start = datetime.datetime.strptime('2016-07-01', '%Y-%m-%d').date()
    asof = datetime.datetime.strptime('2016-07-12', '%Y-%m-%d').date()
    end = datetime.datetime.strptime('2016-12-31', '%Y-%m-%d').date()

    principal = Money(1, 'USD')
    rate = Decimal(0.01)
    freq = Decimal(1)
    eom = None

    test1 = DCC(
        name="test1", altnames={'TEST1'}, currencies={Currencies['TEST1']}, calculate_fraction_method=DCC.calculate_fraction
    )


# Generated at 2022-06-24 01:08:56.801186
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    asse

# Generated at 2022-06-24 01:09:06.600287
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:09:18.469506
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """ Create a dummy DCC - needed for testing method coupon() of class DCC """
    dummyDCC = DCC('dummyDCC', {'DC30360', '30360'}, {'EUR', 'CHF'}, calculate_fraction_method=DCF_30_360)

    reference_date = datetime.date(2015, 12, 31)

    # First coupon payment
    start_date = datetime.date(2015, 1, 1)
    assert dummyDCC.coupon(Money(1, 'EUR'), 0.01, start_date, reference_date, Decimal(1)) == Money(0.0027, 'EUR')

    # Second coupon payment
    start_date = datetime.date(2015, 7, 1)

# Generated at 2022-06-24 01:09:31.361308
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:09:36.558616
# Unit test for function dcc
def test_dcc():
    @dcc('LMA')
    def test(s, a, e):
        return a

    assert test.__dcc.name == 'LMA'
    assert DCCRegistry.find('LMA') == test.__dcc

    try:
        @dcc('LMA')
        def test(s, a, e):
            return a
        raise Exception
    except TypeError as e:
        assert str(e) == "Day count convention 'LMA' is already registered"



# Generated at 2022-06-24 01:09:45.894508
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # this function tests the dcfc_30_e_360 function
    test_start = datetime.date(2018, 4, 30)
    test_asof = datetime.date(2018, 5, 30)
    test_end = datetime.date(2018, 7, 31)
    test_freq = None

    dcf1 = dcfc_30_e_360(start=test_start, asof=test_asof, end=test_end, freq=test_freq)
    assert dcf1 == Decimal('0.16666666666667')



# Generated at 2022-06-24 01:09:51.431230
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(datetime.date(2007,12,28),datetime.date(2008,2,28),datetime.date(2008,2,28)), 14) == Decimal('0.16666666666667')



# Generated at 2022-06-24 01:09:59.596885
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start,ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28) 
    ex2_start,ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29) 
    ex3_start,ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30) 
    ex4_start,ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31) 
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')
   

# Generated at 2022-06-24 01:10:04.891120
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    ## Setup the dates:
    start = datetime.date(2016, 10, 1)
    asof = datetime.date(2017, 10, 1)
    end = datetime.date(2017, 12, 6)

    ## Check if we can calculate the day count fraction:
    for name, dcc in DCCRegistry.dccs.items():
        print(F"Testing {name}")
        ## Calculate the fraction:
        fraction = dcc.calculate_fraction(start, asof, end)
        print(F"Calculated {Fraction.from_decimal(fraction)}")
        assert fraction == Decimal(1)

    ## Check the EOM convention:
    print(F"Testing EOM-13")
    ## Calculate the fraction:

# Generated at 2022-06-24 01:10:10.163544
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:10:15.304620
# Unit test for method interest of class DCC
def test_DCC_interest():
    # Arrange
    dcc = DCC('name', {}, {}, None)
    principal = Money(10, 'USD')
    rate = Decimal('0.1')
    start = datetime.date(2019, 1, 1)
    asof = datetime.date(2019, 2, 1)
    # Act
    interest = dcc.interest(principal, rate, start, asof)
    # Assert
    assert interest.ccy=='USD'
    assert interest.amount==Decimal('1')

# Generated at 2022-06-24 01:10:24.444422
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    """
    Tests method register of class DCCRegistryMachinery.
    """

    #import
    from scm.plams import Molecule, MoleculeError
    from scm.plams.tools.units import convert

    # defines dcc
    dcc = DCC("Act/Act", set(), set(), lambda s, a, e, f: (a - s).days/(e - s).days)

    # define test object
    dcc_reg = DCCRegistryMachinery()

    # test a successful registration
    dcc_reg.register(dcc)

    # test a successful registration of a different object
    dcc_reg.register(
    DCC("test", set(), set(), lambda s, a, e, f: (a - s).days/(e - s).days)
    )

    # test a successful registration of

# Generated at 2022-06-24 01:10:27.880283
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2017, 4, 8), datetime.date(2019, 2, 28), datetime.date(2022, 4, 8)
    assert(round(dcfc_act_act_icma( ex1_start, ex1_asof, ex1_end)) == Decimal(1.93290043290043))



# Generated at 2022-06-24 01:10:39.065252
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["30/360"].calculate_fraction(datetime.date(2014, 11, 15), datetime.date(2014, 12, 20), datetime.date(2015, 12, 20)) == Decimal("0.083333333")
    assert (DCCRegistry["30/360"].calculate_fraction(datetime.date(2014, 11, 15), datetime.date(2014, 12, 20), datetime.date(2015, 12, 20), 360) == Decimal("90")).quantize(ONE)

    assert DCCRegistry["30U/360"].calculate_fraction(datetime.date(2014, 11, 15), datetime.date(2014, 12, 20), datetime.date(2015, 12, 20)) == Decimal("0.083333333")

# Generated at 2022-06-24 01:10:50.030837
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:11:00.668850
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 28), end = datetime.date(2008, 2, 28)), 14) == round(Decimal('0.16986301369863'), 14)
    assert round(dcfc_act_365_f(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 29), end = datetime.date(2008, 2, 29)), 14) == round(Decimal('0.17260273972603'), 14)

# Generated at 2022-06-24 01:11:04.708647
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    ## Initialize the registry machinery:
    reg = DCCRegistryMachinery()

    ## Prepare the DCC model:
    dcc = DCC(
        name="Act/Act ISMA",
        altnames={"Act/Act ISMA", "Act/Act-ISMA", "Act/Act-isma"},
        currencies={Currencies["EUR"], Currencies["USD"]},
        calculate_fraction_method=_actact_isma,
    )

    ## Register the DCC:
    reg.register(dcc)

    ## Check the main buffer:
    assert reg._buffer_main["Act/Act ISMA"] == dcc
    assert reg._buffer_main.keys() == {"Act/Act ISMA"}
    assert reg._buffer_main.values() == {dcc}

# Generated at 2022-06-24 01:11:09.189488
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    """Unit test for function dcfc_act_365_l"""
    from .dates import test_date_tolerance_days

    r1_start, r1_end = dates.parse_yyyymmdd('2020-01-01'), dates.parse_yyyymmdd('2020-01-02')
    r1_asof = dates.parse_yyyymmdd('2020-01-01')
    assert dcfc_act_365_l(start=r1_start, asof=r1_asof, end=r1_end) == Decimal(ONE / 365)

    r2_start, r2_end = dates.parse_yyyymmdd('2020-01-01'), dates.parse_yyyymmdd('2020-02-02')

# Generated at 2022-06-24 01:11:15.158076
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Test function for dcfc_30_e_360
    """
    from dateutil.parser import parse
    assert round(dcfc_30_e_360(
        start = parse("2007-12-31"), asof = parse("2008-01-31"), end = parse("2008-01-31")
        ), 14) == Decimal('0.08333333333333')
    assert round(dcfc_30_e_360(
        start = parse("2007-12-31"), asof = parse("2008-02-29"), end = parse("2008-02-29")
        ), 14) == Decimal('0.08472222222222')

# Generated at 2022-06-24 01:11:25.634993
# Unit test for function dcc
def test_dcc():
    # Define a dummy dcfc function:
    def dummy_dcfc(s: Date, a: Date, e: Date, f: Optional[Decimal] = None) -> Decimal:
        """
        Dummy day count fraction calculator.
        """
        return Decimal(1)

    # Call the dcc decorator:
    decorator = dcc("dummy")

    # Use the decorator:
    dummy_function = decorator(dummy_dcfc)

    # Check if the decorated function is returned:
    assert dummy_function is not None

    # Check the newly registered dcc:
    dcc = DCCRegistry.find("dummy")
    assert dcc is not None

    # Check the attributes:
    assert dcc.name == "dummy"
    assert len(dcc.altnames) == 0

# Generated at 2022-06-24 01:11:33.072499
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    DCCRegistryMachinery()
test_DCCRegistryMachinery()


DCCRegistry = DCCRegistryMachinery()
"""
Defines a registry for day count conventions.
"""

DCCRegistry.register(DCC(
    name="30/360",
    altnames={"30/360", "ISMA 30/360", "AFB 30/360", "BMA 30/360"},
    currencies={Currencies["XTS"]},
    calculate_fraction_method=_calculate_fraction_30_360,
))


# Generated at 2022-06-24 01:11:36.486860
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    """
    Test function for class DCCRegistryMachinery
    """
    dcRegistry = DCCRegistryMachinery()
    assert dcRegistry is not None


# Generated at 2022-06-24 01:11:48.140099
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc_1 = DCC("Act/Act", altnames={"Act/360", "Actual/Actual", "Actual/360", "Actual/365"}, currencies={},
                calculate_fraction_method=_dcc_actual_actual)
    dcc_2 = DCC("Act/360", altnames={"Act/360", "Actual/360"}, currencies={},
                calculate_fraction_method=_dcc_actual_actual)
    dcc_3 = DCC("Act/365", altnames={"Act/365", "Actual/365"}, currencies={},
                calculate_fraction_method=_dcc_actual_actual)

# Generated at 2022-06-24 01:11:57.229219
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:12:04.266460
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:12:15.007051
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex1_calculated = round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-24 01:12:23.234226
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2012,2,29), asof=datetime.date(2012,8,30), end=datetime.date(2012,8,30)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2012,2,28), asof=datetime.date(2012,8,30), end=datetime.date(2012,8,30)), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:12:32.184628
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    start = datetime.date(2008, 4, 1)
    asof = datetime.date(2008, 4, 23)
    end = datetime.date(2008, 6, 23)
    freq = None
    assert round(dcfc_act_365_l(start,asof, end,freq),14) == Decimal('0.17260273972603')




# Generated at 2022-06-24 01:12:41.225826
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """Unit test for function dcfc_30_360_isda."""

    now = datetime.date.today()
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)


# Generated at 2022-06-24 01:12:45.433670
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    start = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 4, 1)
    assert dcfc_nl_365(start, end, end) == Decimal("0.9082191780821917808219178082192")
    start = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 1, 31)
    assert dcfc_nl_365(start, end, end) == Decimal("0.082191780821917808219178082192")
    start = datetime.date(2014, 2, 3)
    end = datetime.date(2014, 2, 28)

# Generated at 2022-06-24 01:12:50.784750
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    print("Test method calculate_fraction of class DCC")
    x = DCC(name = "name", altnames = set(), currencies = set(), calculate_fraction_method = 
        lambda start: datetime.date(2017, 1, 1))
    
    # Test 1
    start = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 2)
    asof = datetime.date(2017, 1, 2)
    freq = None
    assert x.calculate_fraction(start, asof, end, freq) == 1
    print("Test 1 passed")

    # Test 2
    start = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 2)

# Generated at 2022-06-24 01:13:03.440834
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:13:09.100730
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert abs(dcfc_act_365_f(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) - 0.16986301369863) < 1e-14
    assert abs(dcfc_act_365_f(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) - 0.17260273972603) < 1e-14

# Generated at 2022-06-24 01:13:13.557118
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex_dt_start = datetime.date(2007, 12, 28)
    ex_dt_asof = datetime.date(2008, 2, 28)
    ex_dt_asof2 = datetime.date(2008, 2, 29)
    ex_dt_asof3 = datetime.date(2008, 7, 31)
    ex_dt_asof4 = datetime.date(2008, 8, 1)
    ex_dt_asof5 = datetime.date(2008, 8, 2)
 
    ex_dcf = dcfc_act_365_a(start=ex_dt_start,\
        asof=ex_dt_asof,end=ex_dt_asof)

# Generated at 2022-06-24 01:13:25.042376
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof = datetime.date(2016, 2, 29), datetime.date(2016, 3, 31)

# Generated at 2022-06-24 01:13:36.834377
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    np.testing.assert_almost_equal(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof),  0.16666667, 14)

# Generated at 2022-06-24 01:13:45.994333
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcc_factory(dcfc_nl_365.flag)(datetime.date(2012,3,31),datetime.date(2012,4,1),datetime.date(2012,4,1)),15) == 0.0006849315068493
    assert round(dcc_factory(dcfc_nl_365.flag)(datetime.date(2012,3,31),datetime.date(2012,5,1),datetime.date(2012,5,1)),15) == 0.033150684931507
    assert round(dcc_factory(dcfc_nl_365.flag)(datetime.date(2011,3,31),datetime.date(2012,4,1),datetime.date(2012,4,1)),15) == 0.003150684931507

# Generated at 2022-06-24 01:13:50.425248
# Unit test for function dcc
def test_dcc():
    func = lambda x, y, z: x
    assert func == dcc('noop')(func)
    assert hasattr(func, '__dcc')
    assert hasattr(DCCRegistry, 'find')
    assert DCCRegistry.find('noop').calculate_fraction_method == func



# Generated at 2022-06-24 01:13:59.202812
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    '''
    Unit test for method coupon of class DCC.
    '''
    from datetime import date
    from .monetary import Money
    from .currencies import Currency

    alm_curr = Currency('USD')
    alm_principal = Money(50000.00, alm_curr)
    alm_rate = Decimal('0.0455')
    alm_start = date(2012,12,15)
    alm_asof = date(2016,3,8)
    alm_end = date(2016,1,6)
    alm_freq = Decimal(2)
    alm_eom = 15

    aai_curr = Currency('USD')
    aai_principal = Money(50000.00, aai_curr)
    aai_rate

# Generated at 2022-06-24 01:14:02.271308
# Unit test for function dcc
def test_dcc():
    import doctest

    doctest.testmod(optionflags= doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS)

# Test the dcc function:
test_dcc()



# Generated at 2022-06-24 01:14:11.038221
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC("a", {"b", "c"}, {}, lambda x, y, z, w: Decimal(1.0),).name == "a"
    assert DCC("a", {"b", "c"}, {}, lambda x, y, z, w: Decimal(1.0),).altnames == {"b", "c"}
    assert DCC("a", {"b", "c"}, {}, lambda x, y, z, w: Decimal(1.0),).currencies == set()
    assert DCC("a", {"b", "c"}, {}, lambda x, y, z, w: Decimal(1.0),).calculate_fraction_method(1, 2, 3, 4) == Decimal(1.0)

# Test for calculate_fraction method of class DCC

# Generated at 2022-06-24 01:14:18.790354
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08219178082192')

# Generated at 2022-06-24 01:14:27.898709
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.10000000000000')

# Generated at 2022-06-24 01:14:38.837181
# Unit test for function dcc
def test_dcc():
    @dcc("MY DCC", set())
    def my_dcc(start, asof, end, freq):
        return Decimal(1)

    assert my_dcc.__dcc is not None



# Generated at 2022-06-24 01:14:43.367025
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)),14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)),14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)),14) == Decimal

# Generated at 2022-06-24 01:14:50.204806
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    a = datetime.date(2018, 12, 12)
    b = datetime.date(2018, 12, 12)
    assert DCC.ACTUAL_360.coupon(Money(100, "USD"),0.5,a,b,3) is not None
    assert DCC.ACTUAL_360.coupon(Money(100, "USD"),0.5,a,b,3) <= 0




# Generated at 2022-06-24 01:14:56.867729
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    #import pudb; pudb.set_trace()
    a = DCC('aa', {'1', '2'}, {'3', '4'}, _get_actual_day_count)
    if a.coupon(Money(10, 'USD'), 1, Date(2020, 1, 1), Date(2020, 1, 2), Date(2021, 1, 1), 2) == Money(0.5, 'USD'):
        print('success')


# Generated at 2022-06-24 01:15:04.577426
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    print("Testing function dcfc_act_360...", end="")

    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:15:10.766408
# Unit test for method interest of class DCC
def test_DCC_interest():
    import datetime
    from decimal import Decimal
    from pytz import UTC
    from .monetary import Money

    # @Months("t")
    # @CashFlow(0, 20)
    # @DF("AFMA/RBA")
    # def cashflow(t):
    #     return Money(amount=1000, currency="AUD") * (1 + Decimal("0.12") * Decimal("0.056")) ** (t) * \
    #            (Decimal("1") + Decimal("0.12") * Decimal("0.056") * Decimal("0.056")) * (
    #             Decimal("0.056") / Decimal("12")) * DCC.get("AFMA/RBA").calculate_fraction(
    #         datetime.date(2019, 6, 10),


# Generated at 2022-06-24 01:15:22.485917
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:15:32.476073
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    user_input1 = datetime.date(2000, 1, 1)
    user_input2 = datetime.date(2000, 2, 1)
    user_input3 = datetime.date(2000, 3, 1)
    user_input4 = datetime.date(2000, 4, 1)
    user_input5 = datetime.date(2000, 5, 1)
    D1 = DCC('', '', '', '')
    Test_DCC_coupon = D1.coupon(Money(500000), Decimal(0.05), user_input1, user_input2, user_input3, 1, '')
    assert Test_DCC_coupon == Money(8000)


# Generated at 2022-06-24 01:15:44.004474
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Arrange
    # Act
    # Assert
    assert dcfc_act_act == dcc("Act/Act", {"Actual/Actual", "Actual/Actual (ISDA)"})
    assert dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == 0.16942884946478
    assert dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == 0.17216108990194
    assert dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30))

# Generated at 2022-06-24 01:15:53.451934
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start = datetime.date(2007, 12, 28),
                 asof = datetime.date(2008, 2, 28), end = datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start = datetime.date(2007, 12, 28),
                 asof = datetime.date(2008, 2, 29), end = datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:16:00.432946
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    print("Running unit test for function dcfc_30_e_360...")

    ## Initialize parameters:
    ex1_start = datetime.date(2007, 12, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex3_start = datetime.date(2007, 10, 31)
    ex4_start = datetime.date(2008, 2, 1)

    ex1_asof  = datetime.date(2008, 2, 28)
    ex2_asof  = datetime.date(2008, 2, 29)
    ex3_asof  = datetime.date(2008, 11, 30)
    ex4_asof  = datetime.date(2009, 5, 31)


# Generated at 2022-06-24 01:16:11.136136
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_end, ex1_asof = datetime.datetime(2006, 5, 7).date(),  datetime.datetime(2008, 5, 8).date(), datetime.datetime(2007, 5, 8).date()
    assert dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_end) == 0.9972602739726028

    ex2_start, ex2_end,  ex2_asof = datetime.datetime(2007, 2, 1).date(), datetime.datetime(2010, 2, 1).date(), datetime.datetime(2008, 2, 1).date()

# Generated at 2022-06-24 01:16:21.693524
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof, ex1_end = datetime.date(2013, 4, 8), datetime.date(2013, 6, 14), datetime.date(2013, 8, 20)
    assert dcfc_nl_365(ex1_start, ex1_asof, ex1_end) == Decimal('0.415890410958904')


# Generated at 2022-06-24 01:16:33.028658
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dccr = DCCRegistryMachinery()
    a_dcc = DCC(name="ACT/ACT", altnames=set(), currencies=set(), calculate_fraction_method=lambda s, a, e, f: ZERO)
    b_dcc = DCC(name="ACT/ACT MF", altnames=set(), currencies=set(), calculate_fraction_method=lambda s, a, e, f: ZERO)
    assert dccr.find("ACT/ACT") is None
    assert dccr.find("ACT/ACT MF") is None
    dccr.register(a_dcc)
    dccr.register(b_dcc)
    assert dccr.find("ACT/ACT") is a_dcc
    assert dccr.find("ACT/ACT MF") is b_dcc
    assert d

# Generated at 2022-06-24 01:16:42.949114
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Performs unit tests for function dcfc_act_act.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:16:53.233172
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    DCC_1 = DCC('Actual/Actual ICMA', {'ActActICMA'}, {Currencies['USD']}, actacticma)
    DCC_2 = DCC('Actual/Actual ISDA', {'ActActISDA'}, {Currencies['USD']}, actactisda)
    DCC_3 = DCC('Actual/Actual AFB', {'ActActAFB'}, {Currencies['USD']}, actactafb)
    DCC_4 = DCC('Actual/365L', {'Act365L'}, {Currencies['USD']}, act365l)
    DCC_5 = DCC('Actual/360', {'Act/360', 'Act360'}, {Currencies['USD']}, act360)

# Generated at 2022-06-24 01:16:57.098574
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    registry = DCCRegistryMachinery()
    with pytest.raises(TypeError) as excinfo:
        registry.register(DCC("Act/Act", {"act/act", "act/act ICMA"}, {"USD"}, dcff_act_act))
    assert "already registered" in str(excinfo.value)



# Generated at 2022-06-24 01:16:59.734385
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    _assert_dcfc_eq(dcfc_30_360_isda, "30/360 ISDA")
# Unit tests for function _get_actual_day_count and all implementation of dcfc_ functions:

# Generated at 2022-06-24 01:17:05.684889
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    assert DCCRegistry.__name__ == "DCCRegistry"
    assert DCCRegistry.__module__ == "finmath.models.daycount"
    assert DCCRegistry.__doc__ == "Provides the day count registry model."
    assert DCCRegistry.register.__module__ == "finmath.models.daycount"
    assert DCCRegistry.register.__name__ == "register"
    assert DCCRegistry.register.__qualname__ == "DCCRegistry.register"
    assert DCCRegistry.register.__doc__ == "Attempts to register the given day count convention."
    my_day_count_convention = DCC("Actual/Actual ICMA", {}, {}, lambda *args: ZERO)
    DCCRegistry.register(my_day_count_convention)
   

# Generated at 2022-06-24 01:17:07.992213
# Unit test for function dcc
def test_dcc():
    @dcc("N/A")
    def __unused_day_count_fraction(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return ZERO
    print("test_dcc: ", str(__unused_day_count_fraction.__dcc))



# Generated at 2022-06-24 01:17:15.266744
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["A/360"].calculate_fraction(Date(5,5,5), Date(5,5,5), Date(5,5,5)) == Decimal(0)
    assert DCCRegistry["A/360"].calculate_fraction(Date(5,5,5), Date(5,5,5), Date(5,5,6)) == Decimal(0)
    assert DCCRegistry["A/360"].calculate_fraction(Date(5,5,5), Date(5,5,5), Date(5,5,7)) == Decimal(1/360)

# Generated at 2022-06-24 01:17:23.495493
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(datetime.date(2011,1,5),datetime.date(2011,6,11),datetime.date(2011,6,11)),14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(datetime.date(2011,1,5),datetime.date(2011,6,12),datetime.date(2011,6,12)),14) == Decimal('0.17222222222222')


# Generated at 2022-06-24 01:17:31.323736
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    assert(__buffer_main is {})
    assert(__buffer_altn is {})
    assert(__buffer_main_1 is {})
    assert(__buffer_altn_1 is {})

    # assert(__registered is False)
    assert(__registered_1 is False)
    assert(__registered_2 is False)
    assert(__registered_3 is False)


# Create a new instance of class DCCRegistryMachinery
DCCRegistry = DCCRegistryMachinery()



# Generated at 2022-06-24 01:17:34.362075
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us == dcfc_30_360_us

# Generated at 2022-06-24 01:17:44.959477
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    # The start date
    start = Date(2018, 1, 1)
    # The asof date
    asof = Date(2018, 5, 31)
    # The end date
    end = Date(2018, 12, 31)
    # Create instances of the class Principal
    principal = Money.parse("USD 199.88")
    # Create an instance of the class Rate
    rate = 0.05
    # Create an instance of the class Frequency
    freq = 1
    # Create an instance of DCC
    dcc = DCC.__new__(DCC)
    assert dcc.coupon(principal, rate, start, asof, end, freq) == Money.parse("USD 10.00")

if __name__ == "__main__":
    import doctest

# Generated at 2022-06-24 01:17:56.621043
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # Examples from Wikipedia:
    # https://en.wikipedia.org/wiki/Day_count_convention#30/360_(ISDA)
    assert dcfc_30_360_isda(start=datetime.date(2000, 4, 30), asof=datetime.date(2000, 4, 30), end=None, freq=None) == Decimal(1)
    assert dcfc_30_360_isda(start=datetime.date(2000, 4, 30), asof=datetime.date(2000, 5, 30), end=None, freq=None) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:18:08.137093
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    ## Create some dates, currencies and amount:
    from .commons.zeitgeist import Date
    from .monetary import Money
    from .currencies import Currencies