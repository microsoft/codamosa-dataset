

# Generated at 2022-06-24 01:08:06.717675
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("Act/Act") is not None
# Test if the value of type DCC is not None

# Generated at 2022-06-24 01:08:12.800843
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')


# Generated at 2022-06-24 01:08:20.780330
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 2)
    asof = datetime.date(2017, 1, 1)
    freq = 1
    calculate_fraction_method = lambda start, asof, end: ZERO
    name = 'DCC'
    altnames = set()
    currencies = Currencies['USD']
    dcc = DCC(name, altnames, currencies, calculate_fraction_method)
    assert dcc.calculate_fraction(start, asof, end, 1) == 0


# Generated at 2022-06-24 01:08:31.689939
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-24 01:08:35.704850
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    ## Test 1:
    ## =======
    ## Test if day count convention is found by given name with the case intact.
    assert DCCRegistryMachinery().find("Act/Act")

    ## Test 2:
    ## =======
    ## Test if day count convention is found by given name by stripping the name.
    assert DCCRegistryMachinery().find("Act/Act   ")

    ## Test 3:
    ## =======
    ## Test if day count convention is found by given name by upper-casing the name.
    assert DCCRegistryMachinery().find("Act/act")



# Generated at 2022-06-24 01:08:40.860570
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert dcfc_act_360(datetime.date(2020, 2, 4), datetime.date(2020, 2, 4), datetime.date(2020, 2, 4)) == 1



# Generated at 2022-06-24 01:08:50.992915
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    """
    Unit test for constructor of class DCCRegistryMachinery
    """
    # pylint: disable=C0116
    # pylint: disable=C0115
    # pylint: disable=C0103
    # pylint: disable=W0105
    # pylint: disable=C0114

    def one_day_count_fraction_method(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return Decimal(1)

    def two_day_count_fraction_method(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return Decimal(2)


# Generated at 2022-06-24 01:08:58.928637
# Unit test for constructor of class DCC
def test_DCC():
    principal = Money(100, "USD")
    rate = Decimal('0.05')
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 12, 31)
    end = datetime.date(2015, 1, 1)
    freq = Decimal(1)
    eom = None
    assert(DCC(
        name="Actual/Actual ICMA",
        altnames={"Actual/Actual (ICMA)", "Actual/Actual (Euro)", "Actual/Actual"},
        currencies=set(),
        calculate_fraction_method=_act_act_icma
        ).calculate_fraction(start, asof, end, freq) == Decimal('1.027397'))

# Generated at 2022-06-24 01:09:05.301347
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(datetime.date(2015, 8, 20), datetime.date(2015, 8, 21), datetime.date(2015, 8, 21)), 14) == Decimal("0.002777777777778")
    assert round(dcfc_30_e_360(datetime.date(2015, 8, 20), datetime.date(2015, 8, 28), datetime.date(2015, 8, 28)), 14) == Decimal("0.036111111111111")
    assert round(dcfc_30_e_360(datetime.date(2015, 8, 31), datetime.date(2015, 9, 1), datetime.date(2015, 9, 1)), 14) == Decimal("0.002777777777778")

# Generated at 2022-06-24 01:09:15.725432
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:09:24.596927
# Unit test for method interest of class DCC
def test_DCC_interest():
    from dateutil.relativedelta import relativedelta
    from .currencies import Currency, Currencies
    from .money import Money

    assert DCCRegistry["ACT/360"].interest(Money(100, Currency("EUR")), 0.05, datetime.date(2017, 1, 1),
                                           datetime.date(2017, 1, 15)) == Money(2.5, Currency("EUR"))

    assert DCCRegistry["ACT/360"].interest(Money(100, Currency("EUR")), 0.05, datetime.date(2017, 1, 1),
                                           datetime.date(2017, 1, 16)) == Money(2.5, Currency("EUR"))


# Generated at 2022-06-24 01:09:30.063438
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert dcfc_act_360(datetime.date(2014, 2, 1), datetime.date(2014, 3, 1), datetime.date(
        2014, 2, 1), 1) == Decimal('0.033000000000000')
    assert dcfc_act_360(datetime.date(2014, 2, 1), datetime.date(2014, 3, 1), datetime.date(
        2014, 2, 1)) == Decimal('0.033000000000000')
    assert dcfc_act_360(datetime.date(2014, 2, 1), datetime.date(2014, 3, 31), datetime.date(
        2014, 2, 1), 1) == Decimal('0.038000000000000')

# Generated at 2022-06-24 01:09:35.271778
# Unit test for function dcc
def test_dcc():
    @dcc("TEST")
    def test(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return ONE

    assert test.__dcc == DCC("TEST", set(), set(), test)



# Generated at 2022-06-24 01:09:42.806234
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')


# Generated at 2022-06-24 01:09:52.864044
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    with pytest.raises(TypeError):
        dcfc_act_365_f(start=datetime.date(2007, 12, 28), asof=datetime.date(2009, 2, 28), end=datetime.date(2009, 2, 28), freq=2)
    assert dcfc_act_365_f(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:10:00.685132
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2)), 15) == \
           Decimal('0.003067484662577')
    assert round(dcfc_30_e_plus_360(datetime.date(2017, 1, 1), datetime.date(2017, 2, 1)), 15) == \
           Decimal('0.033333333333333')
    assert round(dcfc_30_e_plus_360(datetime.date(2017, 1, 1), datetime.date(2017, 2, 2)), 15) == \
           Decimal('0.033333333333333')

# Generated at 2022-06-24 01:10:06.491236
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    # Test case 1:
    start = Date(2008, 10, 31)
    asof = Date(2009, 10, 30)
    dcf = dcfc_30_e_plus_360(start=start, asof=asof)
    assert dcf == 1.0
    # Test case 2:
    start = Date(2008, 2, 1)
    asof = Date(2009, 5, 31)
    dcf = dcfc_30_e_plus_360(start=start, asof=asof)
    assert dcf == 1.333333333333333
    # Test case 3:
    start = Date(2007, 12, 28)
    asof = Date(2008, 2, 29)
    dcf = dcfc_30_e_plus_360(start=start, asof=asof)
   

# Generated at 2022-06-24 01:10:16.702285
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    strong_test_case1 = ((datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)), Decimal('0.16666666666667'))
    strong_test_case2 = ((datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)), Decimal('0.16944444444444'))
    strong_test_case3 = ((datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)), Decimal('1.08333333333333'))
    strong_test_case4 = ((datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)), Decimal('1.33055555555556'))


# Generated at 2022-06-24 01:10:27.210580
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(datetime.date(2019, 3, 2), datetime.date(2019, 3, 2), datetime.date(2020, 3, 2)), 14) == Decimal('0.00833333333333')
    assert round(dcfc_act_360(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)), 14) == Decimal('0.5541666666667')
    assert round(dcfc_act_360(datetime.date(2019, 9, 10), datetime.date(2019, 3, 2), datetime.date(2020, 3, 2)), 14) == Decimal('0.4416666666667')



# Generated at 2022-06-24 01:10:38.988623
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert dcfc_30_360_german(datetime.date(2014, 1, 29), datetime.date(2014, 1, 29), datetime.date(2014, 1, 29)) == 0
    assert dcfc_30_360_german(datetime.date(2014, 1, 31), datetime.date(2014, 1, 31), datetime.date(2014, 1, 31)) == 0
    assert dcfc_30_360_german(datetime.date(2014, 2, 28), datetime.date(2014, 2, 28), datetime.date(2014, 2, 28)) == 0
    assert dcfc_30_360_german(datetime.date(2014, 2, 28), datetime.date(2014, 2, 28), datetime.date(2014, 2, 28)) == 0
    assert d

# Generated at 2022-06-24 01:10:45.176469
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof = datetime.date(2008, 2, 1), datetime.date(2008, 12, 31)

# Generated at 2022-06-24 01:10:49.782015
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Check for the right behavior in case of bad input
    raise NotImplementedError("Please implement this unit test for method DCC.calculate_fraction")

# Generated at 2022-06-24 01:11:00.628562
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    from quantulum3 import parser
    from quantulum3.units import UNIT_LENGTH
    from pydantic import BaseModel
    from dcc import DCCRegistryMachinery as DCCReg

    dcc = DCCReg()
    # Test method find with a valid day count convention
    assert dcc.find(str(parser.parse('"Act/Act"', units=UNIT_LENGTH))) is not None

    # Test method find with invalid day count convention
    assert dcc.find(str(parser.parse('"Act/Actual"', units=UNIT_LENGTH))) is None
    # Test method _is_registered with a registered day count convention
    assert dcc._is_registered("Act/Act") == True

    # Test method _is_registered with an unregistered day count convention

# Generated at 2022-06-24 01:11:09.270892
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:11:13.520653
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    obj = DCC('ACT365', set(), set(), DCC._calculate_fraction_act365)
    start = datetime.date(2019, 12, 2)
    asof = datetime.date(2019, 12, 2)
    end = datetime.date(2019, 12, 3)
    freq = None
    expected = Decimal('1.00')
    actual = obj.calculate_daily_fraction(start, asof, end, freq)
    assert actual == expected

# Generated at 2022-06-24 01:11:24.769523
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from .monetary import Money
    from .currencies import EUR
    

# Generated at 2022-06-24 01:11:35.247258
# Unit test for function dcc
def test_dcc():
    @dcc("Test/Test")
    def test_func(s: Date, a: Date, e: Date, freq: Optional[Any] = None) -> Decimal:
        return Decimal(1)

    assert DCCRegistry.find("Test/Test").calculate_fraction(datetime.date(2000, 1, 1), datetime.date(2000, 1, 1), datetime.date(2000, 1, 1)) == Decimal(1)
    test_func()



# Generated at 2022-06-24 01:11:39.821617
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    start_date = datetime.date(2014, 2, 28)
    asof_date = datetime.date(2014, 7, 31)
    end_date = datetime.date(2014, 7, 31)
    exp_result = Decimal('0.472222')
    act_result = round(dcfc_30_360_german(start_date, asof_date, end_date), 6)
    assert act_result == exp_result


# Generated at 2022-06-24 01:11:44.114047
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert math.isclose(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 0.5245901639, rel_tol=1e-5, abs_tol=1e-5)


# Generated at 2022-06-24 01:11:48.604536
# Unit test for method interest of class DCC
def test_DCC_interest():
    dcc = DCC("ACTUAL365F", {"ACT/365F"}, {"USD"}, lambda x,y,z,f: Decimal(20))
    assert(dcc.interest(Money(20, "USD"), 0.02, datetime.date(2018, 1, 1), datetime.date(2018, 1, 1)) == Money(0.4, "USD"))


# Generated at 2022-06-24 01:11:57.867843
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC("ACT/ACT", {"ACT/ACT", "Actual/Actual", "Actual/365", "Act/365", "Act/Act", "Act/365", "A/A", "A/365"}, {
        "USD",
        "EUR",
        "GBP",
        "JPY",
        "CHF",
        "CAD",
        "AUD",
        "NZD",
    }, DCCRegistry.ACT_ACT).coupon(Money(1000000, 'USD'), Decimal(0.03), datetime.date(2019, 1, 15), datetime.date(2019, 6, 1), datetime.date(2019, 7, 15), Decimal(2)) == Money(1500.0, 'USD')

# Generated at 2022-06-24 01:12:06.125619
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    # Tests for Multiplicative day count convention
    #Test 1
    dcc_mul = DCCMultiplicative()
    assert dcc_mul.coupon(Money(principal=1000000, currency=Currencies['USD']), 0.04,
                  datetime.date(2018, 12, 1), datetime.date(2019, 1, 7),
                  datetime.date(2023, 12, 1), 2) == Money(currency="USD", amount=120.0)

    #Test 2

# Generated at 2022-06-24 01:12:13.423888
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert(DCCRegistry["ACT/365"].calculate_fraction(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2), datetime.date(2020, 1, 3)) == Decimal('0.0027419'))
    assert(DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2), datetime.date(2020, 1, 3)) == Decimal('0.0027778'))
    assert(DCCRegistry["ACT/365.25"].calculate_fraction(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2), datetime.date(2020, 1, 3)) == Decimal('0.0027392'))

# Generated at 2022-06-24 01:12:22.024586
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1),   datetime.date(2009, 5, 31)
    assert dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_e_

# Generated at 2022-06-24 01:12:29.776086
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    date1 = datetime.date(2007,12,28)
    date2 = datetime.date(2008,2,28)
    assert dcfc_act_365_a(date1,date2,date2) == 0.16986301369863


# Generated at 2022-06-24 01:12:38.112097
# Unit test for method interest of class DCC
def test_DCC_interest():
    dcc = DCC(
        name='Test',
        altnames={"Test"},
        currencies={},
        calculate_fraction_method=lambda a, b, c, d: Decimal(1))
    m = Money(10000.0, "EUR")
    assert dcc.interest(principal=m, rate=Decimal(0.1), start=datetime.date(2020, 1, 1), asof=datetime.date(2020, 1, 31), end=datetime.date(2020, 2, 1)) == Money(2000.0, "EUR")


# Generated at 2022-06-24 01:12:43.576225
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    print("Running test test_DCCRegistryMachinery_register...")
    dcc = DCC("Act/Act", {"Act/Act", "Actual/Actual"}, {"USD", "EUR"}, abc)
    DCCRegistry.register(dcc)
    assert DCCRegistry.find("Act/Act") == DCC("Act/Act", {"Act/Act", "Actual/Actual"}, {"EUR", "USD"}, abc)


# Generated at 2022-06-24 01:12:54.208992
# Unit test for constructor of class DCC
def test_DCC():
    from .monetary import Money
    from .currencies import Currencies
    curr = "USD"
    start_date = datetime.date(2018, 1, 1)
    asof_date = datetime.date(2018, 2, 1)
    end_date = datetime.date(2018, 10, 1)
    freq = 1
    new_dcc = DCC("name", {"name"}, _as_ccys({"USD"}), DCF_ACTUAL)
    # new_dcc.calculate_daily_fraction(start, asof, end)
    assert new_dcc.calculate_fraction(start_date, asof_date, end_date) == Decimal(1)/Decimal(9)

# Generated at 2022-06-24 01:13:05.203622
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert np.allclose(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof),0.16666666666667, rtol=1e-12)
   

# Generated at 2022-06-24 01:13:13.481453
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # create DCC object
    test_DCC = DCC('30E/360', {'act/360'}, {Currencies['USD']}, _dcc_30e360_method)
    # call calculate_daily_fraction method
    result = test_DCC.calculate_daily_fraction(datetime.date(2017, 4, 5), datetime.date(2017, 4, 7), datetime.date(2017, 4, 9))
    # test result
    assert result == Decimal('0.0002777777777777778')

# Generated at 2022-06-24 01:13:20.951862
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    test_start = datetime.date(2007, 12, 28)
    test_asof = datetime.date(2008, 2, 28)
    expected = 0.16666666666667
    actual = dcfc_30_e_plus_360(start=test_start, asof=test_asof, end=test_asof)
    assert round(actual, 14) == round(expected, 14)

# Generated at 2022-06-24 01:13:30.333024
# Unit test for function dcc
def test_dcc():
    @dcc("test", {"test2"}, {"USD"})
    def _test_func(start: Date, asof: Date, end: Optional[Date], freq: Optional[Decimal]) -> Decimal:
        pass
    assert DCCRegistry.find("test").name == "test"
    assert DCCRegistry.find("test2").name == "test"
    assert DCCRegistry.find("TEST").name == "test"
    assert DCCRegistry.find("TEST2").name == "test"
    assert DCCRegistry.find("test3") is None
    assert DCCRegistry.find("TEST3") is None
    assert len(DCCRegistry.table) == 3
    assert len(DCCRegistry.registry) == 1
    assert DCCRegistry.registry[0].name

# Generated at 2022-06-24 01:13:39.687910
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():

    assert dcfc_30_e_plus_360(
        datetime.date(2007, 12, 28),
        datetime.date(2008, 2, 28),
        datetime.date(2008, 2, 28)
    ) == Decimal('0.16666666666667')

    assert dcfc_30_e_plus_360(
        datetime.date(2007, 12, 28),
        datetime.date(2008, 2, 29),
        datetime.date(2008, 2, 29)
    ) == Decimal('0.16944444444444')


# Generated at 2022-06-24 01:13:45.593632
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """
    Tests the function dcfc_30_360_isda().
    """
    print("Testing dcfc_30_360_isda()...")
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_isda(start=start, asof=asof, end=asof), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=start, asof=asof, end=asof, freq=FREQ_ANNUAL), 14) == Decimal(
        '0.16666666666667'
    )

# Generated at 2022-06-24 01:13:49.149135
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # Setup
    registry = DCCRegistry()
    name = "1/1"
    altnames = {"1/1", "1"}
    currencies = {"USD"}
    calculate_fraction_method = _ytm_actact_s

    # Exercise
    registry.register(DCC(name, altnames, currencies, calculate_fraction_method))

    # Verify
    assert registry[name] == DCC(name, altnames, currencies, calculate_fraction_method)
    assert registry[altnames.pop()] == DCC(name, altnames, currencies, calculate_fraction_method)


# Generated at 2022-06-24 01:13:53.672013
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:14:03.082761
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    from datetime import date
    assert round(dcfc_30_360_german(start=date(2020, 2, 29), asof=date(2020, 3, 31), end=date(2020, 3, 31)), 14) == Decimal('1.08333333333333')
    assert round(dcfc_30_360_german(start=date(2020, 2, 29), asof=date(2020, 3, 31), end=date(2020, 3, 31)), 14) == Decimal('1.08333333333333')
    assert round(dcfc_30_360_german(start=date(2021, 2, 28), asof=date(2021, 3, 31), end=date(2021, 3, 31)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:14:13.436659
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    d1 = datetime.date(2017,3,31)
    d2 = datetime.date(2017,7,31)
    x = dcfc_30_e_plus_360(d1,d1,d2)
    assert x == Decimal('0.25')
    d1 = datetime.date(2017,2,28)
    d2 = datetime.date(2017,7,31)
    x = dcfc_30_e_plus_360(d1,d1,d2)
    assert x == Decimal('0.33333333333333')
    d1 = datetime.date(2016,2,29)
    d2 = datetime.date(2017,7,31)
    x = dcfc_30_e_plus_360(d1,d1,d2)
   

# Generated at 2022-06-24 01:14:24.674192
# Unit test for function dcc
def test_dcc():
    m = 1.0
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 15)
    end = datetime.date(2017, 2, 15)
    freq = 1
    ## This decorator can only be used for functions that define exactly the same signature as calculate_fraction_method
    @dcc('name', set(), set())
    def method(self, start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return 1
    print(method(m, start, asof, end, freq))
    print(method.__dcc)
    
test_dcc()


# Generated at 2022-06-24 01:14:34.131807
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    d = datetime.date
    principle = Money(Currency("USD"),Decimal("1000000"),d.today())
    start = d(2007,12,28)
    end = d(2008,2,28)
    rate = Decimal("0.01")
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start,end,end),14) == Decimal("0.16942884946478")
    assert dcc.interest(principle,rate,start,end,end).qty == Decimal("1694.29")
    assert dcc.interest(principle,rate,end,start,start).qty == Decimal("0.00")

##
## Define the registry:
##
# flake8: noqa
DCC

# Generated at 2022-06-24 01:14:43.967434
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    try:
        DCCRegistry.register(
            DCC(
                "Act/Act",
                {"NL"},
                {"TRY"},
                DCFC.ACTUAL_ACTUAL,
            )
        )
        raise AssertionError("DCCRegistry.register should raise TypeError here")
    except TypeError:
        pass
    try:
        DCCRegistry.register(
            DCC(
                "Actual/Actual",
                {"NL"},
                {"TRY"},
                DCFC.ACTUAL_ACTUAL,
            )
        )
        raise AssertionError("DCCRegistry.register should raise TypeError here")
    except TypeError:
        pass


# Generated at 2022-06-24 01:14:55.984302
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    """
    Test case for dcfc_nl_365
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:15:06.384098
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667'))

# Generated at 2022-06-24 01:15:11.713724
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-24 01:15:23.868904
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Testing the dcfc_act_act function.
    """
    # Define the dates for testing
    ex1_start, ex1_asof = DATE(2007, 12, 28), DATE(2008, 2, 28)
    ex2_start, ex2_asof = DATE(2007, 12, 28), DATE(2008, 2, 29)
    ex3_start, ex3_asof = DATE(2007, 10, 31), DATE(2008, 11, 30)
    ex4_start, ex4_asof = DATE(2008, 2, 1), DATE(2009, 5, 31)

    # Testing the dcfc_act_act function

# Generated at 2022-06-24 01:15:34.092501
# Unit test for method interest of class DCC
def test_DCC_interest():
    from unittest import TestCase
    from .monetary import Money
    _testObject = DCC(
        name="ACT/365",
        altnames=set(),
        currencies=set(),
        calculate_fraction_method=lambda s, a, e, f: Decimal(e - a).days / 365
    )
    assert _testObject.interest(
        Money(5, 'EUR'),
        Decimal(0.01),
        datetime.date(2020, 1, 1),
        datetime.date(2020, 4, 1),
        datetime.date(2021, 4, 1)
    ) == Money(0.1208219178, 'EUR')

# Generated at 2022-06-24 01:15:44.970391
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')
test_DCCRegistryMachinery_find()
DCCRegistry = DCC

# Generated at 2022-06-24 01:15:55.630620
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert abs(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) - 0.16942884946478) < 1e-8
    assert abs(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) - 0.17216108990194) < 1e-8
    assert abs(dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) - 1.08243131970956) < 1e-8

# Generated at 2022-06-24 01:16:06.316280
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert dcfc_act_365_f(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 28), end = datetime.date(2008, 2, 28)) == 0.16986301369863
    assert dcfc_act_365_f(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 29), end = datetime.date(2008, 2, 29)) == 0.17260273972603
    assert dcfc_act_365_f(start = datetime.date(2007, 10, 31), asof = datetime.date(2008, 11, 30), end = datetime.date(2008, 11, 30)) == 1.08493150684932
    assert dcfc_act_365_f

# Generated at 2022-06-24 01:16:16.218306
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert (dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof))==0.16939890710383

# Generated at 2022-06-24 01:16:24.270081
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-24 01:16:28.616635
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """
    Tests the dcfc_act_act_icma function.
    """
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), 
                                   end=datetime.date(2020, 3, 2)), 10) == round(0.5245901639, 10)



# Generated at 2022-06-24 01:16:36.943765
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 3) == 0.167
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 3) == 0.169
    assert round(dcfc_30_e_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 3) == 1.083

# Generated at 2022-06-24 01:16:47.178039
# Unit test for constructor of class DCC
def test_DCC():
    accrual_day_count_convention = DCC(
        'ACCRUAL_DAYS_DCC',
        {'30/360', '30E/360', '360/360', '30U/360', 'BOND BASIS'},
        set(),
        lambda s, asof, e, f: Decimal(_get_actual_day_count(asof, e)) / 360
    )
    assert(accrual_day_count_convention.name == 'ACCRUAL_DAYS_DCC')
    assert(accrual_day_count_convention.altnames == {'30/360', '30E/360', '360/360', '30U/360', 'BOND BASIS'})
    assert(accrual_day_count_convention.currencies == set())

# Generated at 2022-06-24 01:16:56.348043
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .currencies import Currency
    from .monetary import Money
    from .time.daycount import DCCRegistry
    from .time.daycount import DCC

    USD = Currency("USD")
    USD_actual_day_count = DCC.make(
        "actual/actual day count",
        set(),
        _as_ccys(["USD"]),
        lambda start, asof, end, freq: Decimal(_get_actual_day_count(start, asof) / _get_actual_day_count(start, end)),
    )

    USD_actual_day_count.currencies.add(USD)
    DCCRegistry.add(USD_actual_day_count)
    assert DCCRegistry.get_convention(USD) == USD_actual_day_count


# Generated at 2022-06-24 01:17:00.815365
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC('Convention', {'Alt'}, {Currencies['AUD']}, lambda a, b, c, d: (a, b, c, d))
    assert DCC(name='Convention', altnames={'Alt'}, currencies={Currencies['AUD']},
    calculate_fraction_method=lambda a, b, c, d: (a, b, c, d))


# Generated at 2022-06-24 01:17:05.221691
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    """Unit test for constructor of class DCCRegistryMachinery."""
    ## Constructor test
    assert DCCRegistryMachinery()._buffer_main == {}
    assert DCCRegistryMachinery()._buffer_altn == {}


# Generated at 2022-06-24 01:17:08.803890
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    import datetime
    ex1_start, ex1_asof, ex1_end = datetime.date(2008, 3, 3), datetime.date(2008, 6, 2), datetime.date(2008, 9, 1)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == 0.25



# Generated at 2022-06-24 01:17:15.697614
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCCRegistry.find("Act/Act")
    # Test for when condition: def _is_registered(self, name: str) -> bool:
    # Test for when then condition: return name in self._buffer_main or name in self._buffer_altn
    assert not dcc._is_registered("Act/Act")
    # Test for when condition: if self._is_registered(dcc.name):
    # Test for when condition: if self._is_registered(name):
    assert not dcc._is_registered("Act/Act")
    # Test for when condition: if self._is_registered(name):
    assert not dcc._is_registered("act/act")
    # Test for when then condition: raise TypeError(f"Day count convention '{dcc.name}' is already registered")
    assert dcc._

# Generated at 2022-06-24 01:17:25.574303
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_360_

# Generated at 2022-06-24 01:17:30.301787
# Unit test for method calculate_fraction of class DCC

# Generated at 2022-06-24 01:17:37.990562
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(datetime.date(2020, 4, 23), datetime.date(2020, 6, 1), datetime.date(2020, 8, 10)), 14) == Decimal('0.12162162162162')
    assert round(dcfc_act_365_f(datetime.date(2020, 4, 24), datetime.date(2020, 6, 2), datetime.date(2020, 8, 11)), 14) == Decimal('0.12476038338658')

    assert round(dcfc_act_365_f(datetime.date(2020, 4, 25), datetime.date(2020, 6, 1), datetime.date(2020, 8, 10)), 14) == Decimal('0.10864864864865')

# Generated at 2022-06-24 01:17:46.861390
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    # Test data drawn from www.formulaconversion.com
    asserteq(dcfc_act_365_l(datetime.date(2019, 6, 30), datetime.date(2019, 12, 31), datetime.date(2019, 12, 31)), Decimal(str(0.535616438356164)))
    asserteq(dcfc_act_365_l(datetime.date(2019, 6, 30), datetime.date(2020, 6, 30), datetime.date(2020, 6, 30)), Decimal(str(1.00)))

# Generated at 2022-06-24 01:17:50.843394
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCC('ACT/ACT', set(), set(), DCFC.__getitem__(0))
    DCCRegistry().register(dcc)


# Generated at 2022-06-24 01:18:01.385223
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():

    ## Model test:
    MODEL1 = DCC("MODEL1", set(), _as_ccys({"BRC", "VNM"}), lambda s, a, e, f: ZERO)
    assert MODEL1.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == ZERO

    ## Actual/Actual method test:
    AAA = DCC("AAA", {"ACTUAL360"}, _as_ccys({"THB", "BRL", "COP", "PKR", "PEN", "MXN"}), lambda s, a, e, f: _get_actual_day_count(a, e) / Decimal(360))

# Generated at 2022-06-24 01:18:10.129089
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == Decimal('0.166667')
    assert dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) == Decimal('0.169445')
    assert dcfc_30_e_plus_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)) == Decimal('1.083333')