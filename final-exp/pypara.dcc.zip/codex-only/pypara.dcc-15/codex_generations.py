

# Generated at 2022-06-24 01:08:19.009513
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Unit test for function dcfc_30_e_360.
    """
    from core_maths.test import almost_equal

    ## Test case 1:
    print("Testing Case 1 ...")
    start, asof, end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)
    ## Compare the actual value to a reference value:
    assert almost_equal(dcfc_30_e_360(start=start, asof=asof, end=end), Decimal("0.16666666666667"))

    ## Test case 2:
    print("Testing Case 2 ...")

# Generated at 2022-06-24 01:08:25.049178
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.10000000000000')

# Generated at 2022-06-24 01:08:29.633330
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    test_start_date = datetime.date(2007, 12, 28)
    test_end_date = datetime.date(2008, 2, 28)

    assert round(dcfc_act_360(start=test_start_date, asof=test_end_date, end=test_end_date), 14) == Decimal('0.17222222222222')


# Generated at 2022-06-24 01:08:36.708762
# Unit test for function dcc

# Generated at 2022-06-24 01:08:42.181686
# Unit test for method interest of class DCC
def test_DCC_interest():
    import financepy.finutils.finDateUtils as finDateUtils
    startDate = finDateUtils.datetimeToDate(datetime.datetime(2018, 4, 19))
    asofDate = finDateUtils.datetimeToDate(datetime.datetime(2018, 4, 20))
    endDate = finDateUtils.datetimeToDate(datetime.datetime(2018, 12, 19))
    principal = Money(100, 'USD')
    rate = 0.05
    DCCAct365 = DCC('ACT/365', {'Actual/365', 'Act/365', 'Act/365.'},
                    set(),
                    DCC._act365_fraction)
    interest = DCCAct365.interest(principal, rate, startDate, asofDate, endDate, 2)
    print(interest)

# Generated at 2022-06-24 01:08:46.599350
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    """
    验证函数 dcfc_act_365_l 正常运行
    :return:
    """
    assert dcfc_act_365_l.__dcc.names[0] == "Act/365L"
    assert dcfc_act_365_l.__dcc.names[1][0] == "Actual/365 Leap Year"

# Generated at 2022-06-24 01:08:56.678454
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Unit test for dcfc_act_act.

    Prints results for the years 2008, 2009, 2010 and 2011.
    """

    # Define function for DCC calculation
    def day_count(start, end):
        """Function to calculate days and day count fraction using a specified DCC"""

        # Calculate days
        days = end - start

        # Calculate day count fraction applying the specified DCC
        fraction = dcc_act_act.calculate_fraction(start, end, end)

        return(days, fraction)

    # Define list of years
    year_list = [2008, 2009, 2010, 2011]

    # Print header

# Generated at 2022-06-24 01:09:00.364172
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCRegistry.get_dcc('ACT/360').coupon(Money(100, Currencies.USD), 0.1, datetime.date(2016,1,1), datetime.date(2016,3,1), datetime.date(2016,3,1), 2) == Money(10, Currencies.USD)


# Generated at 2022-06-24 01:09:12.302747
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')



# Generated at 2022-06-24 01:09:20.117867
# Unit test for method interest of class DCC
def test_DCC_interest():
    convention = DCC('myDCC',{'myDCCAlt'},{Currencies['USD']},DCFC(start, asof, end, freq))
    Money(100, 'USD')
    Decimal(0.1)
    Date(2014,1,1)
    Date(2014,1,2)
    Date(2014,1,3)
    Decimal(1)
    convention.interest(principal, rate, start, asof, end, freq)



# Generated at 2022-06-24 01:09:32.591956
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    global dcfc_30_360_german
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof  = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof  = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof  = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof  = datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:09:40.296174
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2016, 1, 1)
    end = datetime.date(2016, 1, 7)
    asof = datetime.date(2016, 1, 7)
    actual = DCC('ACT/365.FIXED', 'ACT/365.FIXED', _as_ccys({'RUB'}), _calculate_act_365_fixed)(start, asof, end)
    expected = Decimal('6.00273972602739726027397260273972602739726')
    assert actual == expected

# Generated at 2022-06-24 01:09:46.929604
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    start_date = datetime.date(year=2020, month=1, day=16)
    asof_date = datetime.date(year=2020, month=12, day=31)
    end_date = datetime.date(year=2020, month=12, day=31)
    expected_dcf = 0.9833333333333333
    result = dcfc_30_360_isda(start_date, asof_date, end_date)
    assert result == expected_dcf

# Generated at 2022-06-24 01:09:55.649341
# Unit test for function dcc
def test_dcc():
    pass


## Constants:
ACT_ACT = dcc("Act/Act", {"Actual/Actual"})
ACT_360 = dcc("Act/360")
ACT_365 = dcc("Act/365")
ACT_ACT_ICMA = dcc("Act/Act ICMA", {"Act/Act ISDA"})
ACT_ACT_ISDA = dcc("Act/Act ISDA", {"Act/Act ICMA"})
ACT_ACT_AFB = dcc("Act/Act AFB", {"Actual/Actual AFB"})

## Aliases:
ACT_ACT_AFB_FIXED = ACT_ACT_AFB



# Generated at 2022-06-24 01:10:00.717028
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert _construct_date(2015, 1, 1) == DCC("", set(), set(), lambda start, asof, end, freq: ZERO).coupon(
        principal=Money("USD", 100.0),
        rate=Decimal("0.025"),
        start=datetime.date(2014, 1, 1),
        asof=datetime.date(2015, 12, 31),
        end=datetime.date(2016, 1, 1),
        freq=Decimal("2"),
        eom=15
    ).value


# Generated at 2022-06-24 01:10:06.661506
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)

# Generated at 2022-06-24 01:10:16.806799
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC(
        name="ACT/360",
        altnames=set(),
        currencies={Currencies.USD},
        calculate_fraction_method=dcf_act_360,
    ).coupon(
        Money(1, Currencies.USD),
        Decimal("0.01"),
        datetime.date(2014, 1, 1),
        datetime.date(2014, 1, 2),
        datetime.date(2015, 1, 1),
        12,
    ) == Money("0.002778", Currencies.USD)

# Generated at 2022-06-24 01:10:17.684505
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    assert DCCRegistryMachinery()


# Generated at 2022-06-24 01:10:25.370779
# Unit test for function dcfc_nl_365

# Generated at 2022-06-24 01:10:27.047117
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    """
    Unit test for class DCCRegistryMachinery
    """
    x = DCCRegistryMachinery()
    assert x._buffer_main == {}
    assert x._buffer_altn == {}


# Generated at 2022-06-24 01:10:33.879144
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert dcfc_act_act_icma(start = date(2019, 3, 2), asof = date(2019, 9, 10), end=date(2020, 3, 2), freq = 2) == Decimal('0.5245901639')


# Generated at 2022-06-24 01:10:41.594101
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    ## Instantiate
    x = DCCRegistryMachinery()
    y = DCCRegistryMachinery()
    ## Test for is_registered
    assert not x._is_registered('Act/Act')
    ## Test for register
    x.register(DCC('Act/Act', {'Actual/Actual','Actual','Act/Act'}, {Currency('USD')}, _dcf_act_act))
    assert x._is_registered('Act/Act')
    assert x._is_registered('Actual/Actual')
    assert 'Act/Act' in x._buffer_main
    assert 'Actual/Actual' not in x._buffer_main
    assert 'Act/Act' in y._buffer_main
    assert 'Actual/Actual' not in y._buffer_main
    ## Test for find

# Generated at 2022-06-24 01:10:51.068527
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    doc_str = """
        Attempts to find the day count convention by the given name.

        Note that all day count conventions are registered under stripped, uppercased names. Therefore,
        the implementation will first attempt to find by given name as is. If it can not find it, it will
        strip and uppercase the name and try to find it as such as a last resort.
    """
    #print(test_DCCRegistryMachinery_find.__doc__,end="")
    print(test_DCCRegistryMachinery_find.__doc__, end="")
    dcc_name = ""
    dcc = DCCRegistry.find(dcc_name)
    assert dcc is None


# Generated at 2022-06-24 01:10:58.356111
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863'))

# Generated at 2022-06-24 01:11:03.718446
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # get the method under test
    m = DCCRegistryMachinery.__dict__["register"]
    # check if method is callable
    assert callable(m)

    # create a dummy instance
    o = DCCRegistryMachinery()

    # run the method under test
    with pytest.raises(TypeError) as e:
        m(o, None)
    assert 'required positional argument' in str(e)



# Generated at 2022-06-24 01:11:11.670722
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    # 0.16666666666667
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == 0.16666666666667
    # 0.16944444444444
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == 0.16944444444444
    # 1.08333333333333

# Generated at 2022-06-24 01:11:22.955734
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Tests coupon method of class DCC.
    """
    ## Import the global scope:
    global _last_payment_date, _next_payment_date

    ## Import the library modules:
    import datetime
    from decimal import Decimal
    from pyengine.pricing.daycount import Currencies, DCC, Dollars, _construct_date, _last_payment_date, _next_payment_date

    ## Declare the mock function _last_payment_date used by the test method:

# Generated at 2022-06-24 01:11:31.417433
# Unit test for method coupon of class DCC
def test_DCC_coupon():
# test 1
    dcc=DCC("NAME","ALTNAME","CURRENCIES",calculate_fraction_method)
    dcc.coupon(principal=Money("100"), rate="0.5", start=datetime.date(2017, 11, 27), asof=datetime.date(2017, 11, 28),
               end=datetime.date(2017, 11, 29),freq=2, eom=int("28"))
#test 2
    dcc.coupon(principal=Money("50"), rate="0.5", start=datetime.date(2017, 11, 27), asof=datetime.date(2017, 11, 28),
               end=datetime.date(2017, 11, 29),freq=3, eom=int("28"))
#test 3
    dcc.coup

# Generated at 2022-06-24 01:11:41.098323
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08219178082192')

# Generated at 2022-06-24 01:11:44.999800
# Unit test for constructor of class DCC
def test_DCC():
    DCC("test", { "test1", "test2"}, { Currencies["USD"], Currencies["JPY"] }, lambda a,b,c,d : Decimal("1.5"))


# Generated at 2022-06-24 01:11:53.220998
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=2), 10) == Decimal('0.5245901639')



# Generated at 2022-06-24 01:11:57.391306
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,28), end=datetime.date(2008,2,28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,29), end=datetime.date(2008,2,29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-24 01:12:05.151478
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    import datetime
    from finmarketpy.economics.currencies import Currencies
    from finmarketpy.economics.curves import OISCurve
    from finmarketpy.economics.dcc import DCC
    from finmarketpy.economics.money import Money
    from finmarketpy.economics.pricing.bond import Bond
    from finmarketpy.economics.pricing.components import Coupon
    from finmarketpy.economics.pricing.instruments import ExchangeTradedInstrument
    from finmarketpy.economics.pricing.payments import Payment
    from finmarketpy.economics.tradedates import TradeDate
    from finmarketpy.economics.valuation import NPV

    tradeDate = TradeDate()
    curve = OISCurve(tradeDate)

# Generated at 2022-06-24 01:12:14.842520
# Unit test for function dcc
def test_dcc():
    @dcc('SomeDCC')
    def _dcc_test(a, b, c):
        return a + b + c
    assert _dcc_test(1, 2, 3) == 6
    assert DCCRegistry.find('somedcc').name == 'SomeDCC'
    assert DCCRegistry.find('Somedcc').name == 'SomeDCC'
    assert DCCRegistry.find('SomeDcc').name == 'SomeDCC'
    assert DCCRegistry.find('somedcc').calculate_fraction_method(10, 20, 30) == 60
    assert DCCRegistry.find('SomeDcc').calculate_fraction_method(10, 20, 30) == 60

# Generated at 2022-06-24 01:12:23.094582
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert dcfc_act_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.17222222222222')
    assert dcfc_act_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.17500000000000')
    assert dcfc_act_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.10000000000000')

# Generated at 2022-06-24 01:12:34.416016
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    '''
    Test coupon method of DCC class.
    Test cases from http://www.bondsonline.com/bac/pages/bac_calculate_interest.html
    
    '''
    test_case1 = DCC("30/360", set(), set(), DCCRegistry.instance()["30/360"].calculate_fraction_method)
    assert test_case1.coupon(Money("1000.0", "USD"), .06, datetime.date(2016, 3, 15), datetime.date(2016, 7, 1)) == Money("2.50", "USD")

# Generated at 2022-06-24 01:12:43.281302
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcch = DCCRegistryMachinery()
    dcch.register(DCC("Act/Act", {"Act"}, {"USD"}, calculate_act_act))
    assert dcch.find("Act/Act") == DCC("Act/Act", {"Act"}, {"USD"}, calculate_act_act)
    assert dcch.find("Act") == DCC("Act/Act", {"Act"}, {"USD"}, calculate_act_act)
    assert dcch.find("act/act") == DCC("Act/Act", {"Act"}, {"USD"}, calculate_act_act)
# pylint: disable=protected-access

# Enforce the atexit handler:
atexit.register(DCCRegistry._freeze)

## Defines the default currency of day count convention
CURRENCY_DCC = Currencies["USD"]



# Generated at 2022-06-24 01:12:47.422756
# Unit test for function dcc
def test_dcc():
    """
    Unit test for function dcc
    """

    import unittest

    class DCCTestCase(unittest.TestCase):
        """
        Details: https://github.com/TurboGears/tg2/issues/1013
        """

        def test_dcc_decorator(self):
            """
            Test DCC decorator
            """

            @dcc("TestDCC")
            def test_dcc(self, start, end, endofmonth, freq):
                return start, end, endofmonth, freq

            dcc = DCCRegistry.find("TestDCC")
            assert dcc

    unittest.main()



# Generated at 2022-06-24 01:12:57.337107
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Unit Test for function dcfc_30_360_german
    """

    print("\n-----------------------------------------------------------------------")
    print("Unit test for function dcfc_30_360_german")
    print("-----------------------------------------------------------------------")

    for _, test_case in enumerate(test_cases_30_360_german):
        print("Start date:", test_case[0])
        print("As of date:", test_case[1])
        print("Expected result:", test_case[2])
        res = dcfc_30_360_german(start=test_case[0], asof=test_case[1], end=test_case[1])
        print("Actual result  :", res)
        print("-----------------------------------------------------------------------")
        assert res == test_case[2], 'Error: Invalid result'

# Generated at 2022-06-24 01:13:05.795427
# Unit test for constructor of class DCC
def test_DCC():
    from .currencies import Currency
    from .enums import DCCEnum
    from ..fragments.money import Money
    a = DCC(name=DCCEnum.THIRTYE360_ISDA)
    assert a.name == DCCEnum.THIRTYE360_ISDA
    assert a.altnames == set()
    assert a.currencies == set()
    assert hasattr(a.calculate_fraction_method, '__call__')
    assert a.calculate_fraction(datetime.date(2017, 1, 1),datetime.date(2017, 1, 1),datetime.date(2017, 1, 2)) == 1

# Generated at 2022-06-24 01:13:10.645315
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    '''
    Tests dcfc_act_365_f function
    '''
    assert(round(dcfc_act_365_f(datetime.date(2019, 5, 24), datetime.date(2020, 5, 24), datetime.date(2020, 5, 24)), 14) == Decimal('1.00000000000000'))
    assert(round(dcfc_act_365_f(datetime.date(2019, 12, 18), datetime.date(2020, 5, 24), datetime.date(2020, 6, 18)), 14) == Decimal('0.56438356164384'))


# Generated at 2022-06-24 01:13:22.479451
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:13:25.485328
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc3 = dcc2 = dcc1 = DCCRegistryMachinery()
    assert dcc1.find("Act/Act") == None
    assert dcc2.find("") == None
    assert dcc3.find("Actual/Actual (ISMA)") == None

# Generated at 2022-06-24 01:13:37.244723
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 12) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:13:43.976902
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), Decimal(1)), 10) == 0.5244758065
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), Decimal(2)), 10) == 0.5245901639
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), Decimal(4)), 10) == 0.5246108839

# Generated at 2022-06-24 01:13:49.173684
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(
        datetime.date(2007, 12, 28),
        datetime.date(2008, 2, 28),
        datetime.date(2008, 2, 28)
    ) == 0.16666666666666666



# Generated at 2022-06-24 01:13:52.023498
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find('Act/Act') is not None
    assert DCCRegistry.find('act/act') is not None
    assert DCCRegistry.find('act/Act') is not None



# Generated at 2022-06-24 01:13:57.456070
# Unit test for constructor of class DCC
def test_DCC():
    """
    Tests the DCC constructor.

    :return: Nothing.
    """
    print("Testing DCC.")

    # Execute the constructor:
    dcc = DCC(
        "30/360",
        set(),
        set(),
        lambda s, a, e, f: _get_actual_day_count(a, e) / (_has_leap_day(a, e) and 366 or 365)
    )

    # Check the name:
    assert dcc.name == "30/360"



# Generated at 2022-06-24 01:14:05.403549
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:14:14.176418
# Unit test for method coupon of class DCC
def test_DCC_coupon():

    from .currencies import AED
    from .money import Money
    from .enums import DCCs

    t = DCCs.ACT_ACT_ICMA
    start = Date(2017, 1, 2)
    asof = start + relativedelta(months = 3, days = 19)
    end = start + relativedelta(months = 12)
    freq = 2
    eom = 15
    principal = Money.from_currency("1000000.00", AED)
    rate = 1 / 100

    print("accrued interest: " + str(t.coupon(principal, rate, start, asof, end, freq, eom).currency_amount))



# Generated at 2022-06-24 01:14:25.335018
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:14:31.932446
# Unit test for function dcc
def test_dcc():
    """
    Test function dcc.
    """
    @dcc("Test", ["Test123"], ["TEST"])
    def dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Test DCFC
        :return: Decimal
        """
        return Decimal(1)

    ## Test the DCC instance in the function:
    assert dcfc.__dcc.name == "Test"
    assert "Test123" in dcfc.__dcc.altnames
    assert "TEST" in dcfc.__dcc.currencies
    assert dcfc.__dcc.calculate_fraction_method is dcfc

    ## Test the registry:
    assert "Test" in DCCRegistry.table
   

# Generated at 2022-06-24 01:14:43.593298
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    print("Testing method calculate_fraction of class DCC")
    start = datetime.date(2018, 1, 1)
    asof = datetime.date(2018, 1, 2)
    end = datetime.date(2018, 1, 3)
    freq = Decimal(1)
    dcc = DCC("ACT/360", {}, {}, lambda start, asof, end, freq: Decimal("0.005555555555555555555555555555555555555556"))
    expected = Decimal("0.005555555555555555555555555555555555555556")
    actual_result = dcc.calculate_fraction(start, asof, end, freq)
    if expected == actual_result:
        print("Test successful")
   

# Generated at 2022-06-24 01:14:55.850748
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from importlib import reload
    import sys
    import os
    import pytest

    reload(sys)
    # sys.setdefaultencoding('utf-8')
    cur_dir = os.path.dirname(os.path.realpath(__file__))
    root_dir = os.path.abspath(os.path.join(cur_dir, "..", ".."))
    sys.path.append(root_dir)

# Generated at 2022-06-24 01:15:06.372181
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,28), end=datetime.date(2008,2,28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_f(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,29), end=datetime.date(2008,2,29)), 14) == Decimal('0.17260273972603')
    assert round(dcfc_act_365_f(start=datetime.date(2007,10,31), asof=datetime.date(2008,11,30), end=datetime.date(2008,11,30)), 14) == Dec

# Generated at 2022-06-24 01:15:10.920027
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-24 01:15:21.525180
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC(name="Actual/Actual (ICMA)", altnames=set(), currencies=set(), calculate_fraction_method=calculate_fraction_method)
    start = datetime.date(2014,  1,  1)
    asof = datetime.date(2016, 12, 31)
    end = datetime.date(2016, 12, 31)
    freq = Decimal(1)
    frac = dcc.calculate_fraction(start, asof, end, freq)
    if (frac != Decimal(2.9972630257)):
        raise AssertionError('The returned result doesn\'t match for calculate_fraction')


# Generated at 2022-06-24 01:15:28.181463
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)) == Decimal('0.524590163934426')
    assert dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2020, 3, 2), end=datetime.date(2020, 3, 2)) == Decimal('0.0')
    assert dcfc_act_act_icma(start=datetime.date(2020, 3, 2), asof=datetime.date(2020, 3, 2), end=datetime.date(2020, 3, 2)) == Decimal('1.0')


# Generated at 2022-06-24 01:15:32.205462
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("ACT/360").calculate_fraction(datetime.date(2008, 1, 1), datetime.date(2008, 1, 31), datetime.date(2008, 12, 31)) == Decimal(11) / Decimal(360)



# Generated at 2022-06-24 01:15:43.861401
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    """
    The test is based on the examples given in https://www.quantlib.org/install/user_quickstart.html#day-counting-conventions.
    """
    #(start,end,dcf)    

# Generated at 2022-06-24 01:15:51.519696
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == round(Decimal('0.16986301369863'), 14)

# Generated at 2022-06-24 01:15:59.282352
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667'))

# Generated at 2022-06-24 01:16:10.307975
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    global DCCRegistry
    DCCRegistry = DCCRegistryMachinery()
    DCCRegistry.register(DCC(name="Act/Act", altnames=set(), currencies=set(), calculate_fraction_method=cff_act_act))
    DCCRegistry.register(DCC(name="30/360", altnames=set(), currencies=set(), calculate_fraction_method=cff_30_360))
    DCCRegistry.register(DCC(name="30/360B", altnames=set(), currencies=set(), calculate_fraction_method=cff_30_360B))
    DCCRegistry.register(DCC(name="30/360E", altnames=set(), currencies=set(), calculate_fraction_method=cff_30_360E))

# Generated at 2022-06-24 01:16:21.216722
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:16:27.874498
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2018, 1, 31), datetime.date(2018, 2, 28), datetime.date(2018, 3, 31)), 14) == Decimal('0.090410958904110')
    assert round(dcfc_nl_365(datetime.date(2018, 1, 31), datetime.date(2018, 2, 28), datetime.date(2018, 3, 31), 0.5), 14) == Decimal('0.090410958904110')
    assert round(dcfc_nl_365(datetime.date(2018, 1, 31), datetime.date(2018, 2, 28), datetime.date(2018, 2, 28)), 14) == Decimal('0.082191780821918')

# Generated at 2022-06-24 01:16:33.037201
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-24 01:16:42.009339
# Unit test for constructor of class DCC
def test_DCC():
    new_DCC = DCC(
        "name", {"alt1", "alt2"}, {Currencies["USD"], Currencies["EUR"]}, lambda start, asof, end, freq: ONE
    )
    assert new_DCC.name == "name"
    assert new_DCC.altnames == {"alt1", "alt2"}
    assert new_DCC.currencies == {Currencies["USD"], Currencies["EUR"]}
    assert new_DCC.calculate_fraction_method(Date(1, 1, 2000), Date(1, 1, 2000), Date(1, 1, 2000)) == ZERO


# Generated at 2022-06-24 01:16:53.120277
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """
    Functional unit test for function dcfc_act_act_icma.
    """
    ##
    ## Test 1:
    ##
    ## Expected:
    ##
    ##    0.5245901639
    ##
    ## Input:
    ##
    ##  p1:  2019-03-02
    ##  p2:  2019-09-10
    ##  p3:  2020-03-02
    ##
    assert Decimal("0.5245901639") == dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2))

    ##
    ## Test 2:
    ##
    ## Expected:
    ##
    ##    0.5245901639
    ##

# Generated at 2022-06-24 01:16:57.760125
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    start = datetime.date(2009, 1, 1)
    asof = datetime.date(2009, 1, 31)
    end = datetime.date(2009, 2, 1)
    assert round(dcfc_30_360_german(start=start, asof=asof, end=end), 14) == Decimal('1.33333333333333')

    start = datetime.date(2009, 1, 1)
    asof = datetime.date(2009, 2, 1)
    end = datetime.date(2009, 3, 1)
    assert round(dcfc_30_360_german(start=start, asof=asof, end=end), 14) == Decimal('1.33333333333333')

    start = datetime.date(2009, 1, 30)
    asof = datetime

# Generated at 2022-06-24 01:17:03.777594
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Assert if the result of the dcfc_act_act calcuation (the function) matches the expected value
    assert(round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478'))
    assert(round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17216108990194'))
    assert(round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08243131970956'))

# Generated at 2022-06-24 01:17:14.012278
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert(0 == round(dcfc_act_365_f(datetime.date(2020,4,2),datetime.date(2020,4,2),datetime.date(2020,4,2)),2))
    assert(0.01 == round(dcfc_act_365_f(datetime.date(2020,4,2),datetime.date(2020,4,3),datetime.date(2020,4,2)),2))
    assert(0.27 == round(dcfc_act_365_f(datetime.date(2020,4,2),datetime.date(2020,4,30),datetime.date(2020,4,2)),2))

# Generated at 2022-06-24 01:17:22.078202
# Unit test for method interest of class DCC
def test_DCC_interest():
    principal = Money(amount=1000, currency=Currencies.EUR)
    rate = Decimal(0.02)
    start = Date(2018, 1, 1)
    asof = Date(2018, 1, 2)
    interest = DCCRegistry.get("30/360S").interest(principal, rate, start, asof)
    assert interest == Money(amount=5, currency=Currencies.EUR)
    

# Generated at 2022-06-24 01:17:29.420362
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')


## Defines the registry instance:
DCCRegistry = DCCRegistryMach

# Generated at 2022-06-24 01:17:35.971146
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    try:
        assert (dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2007, 12, 28), datetime.date(2007, 12, 28)) == Decimal("0.0027397260273973"))
    except:
        return False
    return True



# Generated at 2022-06-24 01:17:41.402172
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC.__annotations__['name'] == 'str'
    assert DCC.__annotations__['altnames'] == 'Set[str]'
    assert DCC.__annotations__['currencies'] == 'Set[Currency]'
    assert DCC.__annotations__['calculate_fraction_method'] == 'DCFC'



# Generated at 2022-06-24 01:17:48.738700
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)), 8) == Decimal(
        0.16666667)
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)), 8) == Decimal(
        0.16944444)
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)), 8) == Decimal(
        1.08333333)
    assert round(dcfc_30_e_plus_360(datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)), 8)

# Generated at 2022-06-24 01:18:00.626751
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-24 01:18:07.596372
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # Test for function register of class DCCRegistryMachinery
    # This is the example cited in PEP 484
    # https://www.python.org/dev/peps/pep-0484/#examples
    dcc_registry_machinery = registry.REGISTRY_DCC
    dcc_registry_machinery.register(DCC("Act/Act", {"act/act"}, {}, _calculate_actact_fraction))
    assert dcc_registry_machinery.find("Act/Act").name == "act/act"


# Generated at 2022-06-24 01:18:15.602248
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    ## test registry
    registry=DCCRegistryMachinery()

    ## test is_registered
    assert(registry._is_registered("Act/360") == False)
    assert(registry._is_registered("Act/Act") == False)
    assert(registry._is_registered("Act/365") == False)
    assert(registry._is_registered("Act/Act") == False)

    ## test register