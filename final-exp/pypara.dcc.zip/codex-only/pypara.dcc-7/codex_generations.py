

# Generated at 2022-06-24 01:08:11.769761
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    a1 = datetime.date(2019, 1, 16)
    b1 = datetime.date(2019, 1, 17)
    c1 = datetime.date(2019, 1, 18)
    assert dcfc_act_act(a1, b1, c1) == 0.00273972602739726

    a2 = datetime.date(2019, 1, 16)
    b2 = datetime.date(2019, 1, 18)
    c2 = datetime.date(2019, 1, 19)
    assert dcfc_act_act(a2, b2, c2) == 0.00555555555555556

    a3 = datetime.date(2019, 11, 1)
    b3 = datetime.date(2019, 11, 30)

# Generated at 2022-06-24 01:08:21.541174
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ## Example 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_actual = dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof)
    ex1_expected = 0.16666666666667
    assert ex1_actual == ex1_expected

    ## Example 2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex2_actual = dcfc_30_360_us(start=ex2_start, asof=ex2_asof, end=ex2_asof)
    ex2_expected = 0.16944

# Generated at 2022-06-24 01:08:25.671449
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    start = datetime.date(2019, 1, 30)
    end = datetime.date(2019, 6, 29)
    assert dcfc_nl_365(start, end, end, None) == Decimal('0.415068493')


# Generated at 2022-06-24 01:08:35.265337
# Unit test for constructor of class DCC
def test_DCC():

    name="DCC"
    altnames={"DCC3","DCC4"}
    currencies={"GBP","USD"}
    dc = DCC(name,altnames,currencies,None)
    assert dc.name=="DCC"
    assert dc.altnames=={"DCC3","DCC4"}
    assert dc.currencies=={"GBP","USD"}

    #test for calculate_fraction
    start = datetime.date(2010,1,1)
    asof = datetime.date(2010,12,31)
    end = datetime.date(2011,12,31)

    dc = DCC(name, altnames, currencies, None)
    dc.calculate_fraction(start,asof,end)


# Generated at 2022-06-24 01:08:45.971494
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:08:56.653983
# Unit test for function dcfc_act_act

# Generated at 2022-06-24 01:09:06.651871
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(datetime.date(2019, 1, 1), datetime.date(2019, 1, 2), datetime.date(2019, 12, 31)),9) == 0.002739726
    assert round(dcfc_act_365_f(datetime.date(2019, 2, 1), datetime.date(2019, 1, 2), datetime.date(2019, 12, 31)),9) == 0.965753425
    assert round(dcfc_act_365_f(datetime.date(2019, 2, 1), datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)),9) == 0.958904110

# Generated at 2022-06-24 01:09:18.543320
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
  assert round(dcfc_act_365_f(datetime.date(2019, 2, 24), datetime.date(2019, 3, 31), datetime.date(2021, 2, 29)),14) == Decimal('0.07739726027397')
  assert round(dcfc_act_365_f(datetime.date(2019, 3, 24), datetime.date(2019, 3, 31), datetime.date(2021, 2, 29)),14) == Decimal('0.073972602739726')
  assert round(dcfc_act_365_f(datetime.date(2019, 4, 24), datetime.date(2019, 3, 31), datetime.date(2021, 2, 29)),14) == Decimal('0.070273972602740')

# Generated at 2022-06-24 01:09:31.361410
# Unit test for function dcc
def test_dcc():
    @dcc("Test", set(["test", "TEST"]), set([Currencies["USD"]]))
    def _test_dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return ONE
    # Check that we have a DCC object created:
    assert hasattr(_test_dcfc, "__dcc")
    assert isinstance(_test_dcfc.__dcc, DCC)
    # Check the name of the DCC object
    assert _test_dcfc.__dcc.name == "Test"
    # Check if it is available under the main name:
    assert DCCRegistry.find("Test") == _test_dcfc.__dcc
    # Check if it is available under the alternative names:

# Generated at 2022-06-24 01:09:40.544075
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(datetime.date(2020, 1, 31), datetime.date(2020, 5, 31), datetime.date(2020, 6, 30)), 10) == Decimal('0.3111111111'), "Test for dcfc_act_360 Failed!"


# Generated at 2022-06-24 01:09:49.128075
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:09:58.630895
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Unit test for function "dcfc_30_360_german"
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    res = 0.16666666666667

# Generated at 2022-06-24 01:10:03.839721
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    from datetime import date
    assert dcfc_30_e_plus_360(date(2012,9,30),date(2012,10,30),date(2012,10,30)) == Decimal('0.1')
    assert dcfc_30_e_plus_360(date(2012,9,30),date(2012,10,31),date(2012,10,31)) == Decimal('0.1')
    assert dcfc_30_e_plus_360(date(2012,8,30),date(2012,9,30),date(2012,9,30)) == Decimal('0.1')
    assert dcfc_30_e_plus_360(date(2012,8,30),date(2012,9,30),date(2012,10,30)) == Decimal('0.3')
    assert dcf

# Generated at 2022-06-24 01:10:10.251585
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Unit test for function dcfc_act_act
    """
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_act_act(start, asof, asof), 14) == Decimal('0.16942884946478')

    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_act_act(start, asof, asof), 14) == Decimal('0.17216108990194')

    start, asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)

# Generated at 2022-06-24 01:10:20.666310
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # -------------------------------------------------------------
    # Start dates:
    # -------------------------------------------------------------
    # 30/360 US
    assert dcfc_30_360_us(start=datetime.date(year=2007, month=12, day=31), asof=datetime.date(year=2008, month=1, day=30), end=datetime.date(year=2008, month=1, day=30)) == Fraction('1/30')
    assert dcfc_30_360_us(start=datetime.date(year=2007, month=12, day=31), asof=datetime.date(year=2008, month=2, day=20), end=datetime.date(year=2008, month=2, day=20)) == Fraction('20/360')

# Generated at 2022-06-24 01:10:29.708048
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:10:37.815889
# Unit test for constructor of class DCC
def test_DCC():
    from .monetary import Money
    from .currencies import Currencies
    from dateutil.relativedelta import relativedelta
    from datetime import date
    dcc = DCC(
        name = "Actual/Actual (ISMA)",
        altnames = set(["Actual/Actual"]),
        currencies = set([Currencies['CHF'], Currencies['EUR'], Currencies['GBP'], Currencies['USD']]),
        calculate_fraction_method = lambda start, asof, end, freq: Decimal(
            _get_actual_day_count(asof, end) / _get_actual_day_count(start, end) if
            _get_actual_day_count(start, end) != 0 else Decimal(0)
        )
    )

# Generated at 2022-06-24 01:10:47.227443
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal(0.16986301369863)
    assert dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal(0.17213114754098)
    assert dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal(1.08196721311475)

# Generated at 2022-06-24 01:10:58.065997
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_360(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-24 01:11:05.532850
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Test case for function dcfc_30_360_german.
    """
    ## Test 1:
    ## The following should return 0.16666666666667:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    print(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof))

    ## Test 2:
    ## The following should return 0.16944444444444:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-24 01:11:12.942008
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == round(Decimal('0.16666666666667'), 14)
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == round(Decimal('0.16944444444444'), 14)

# Generated at 2022-06-24 01:11:24.256122
# Unit test for method interest of class DCC
def test_DCC_interest():
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 2, 28)
    end = datetime.date(2017, 3, 1)

    sum1 = 0
    sum2 = 0
    for i in _get_date_range(start, end):
        sum1 += _get_actual_day_count(start, i)
        sum2 += (i - start).days
    assert sum1 == sum2

    assert DCC.ACT_ACT_ICMA_ISDA_SIMPLE.interest(Money(100, 'USD'), 0.01, start, asof) == Money(1.58, 'USD')

# Generated at 2022-06-24 01:11:32.355028
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:11:44.615417
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-24 01:11:54.723342
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    # Create a test case
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)
    # Compute the day count fraction for "Act/360"
    result = dcfc_act_360(start, asof, end)
    # Compare the expected value with actual value
    assert round(result, 14) == Decimal('0.17222222222222')



# Generated at 2022-06-24 01:12:05.483686
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = dcfc_act_act
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')


# Generated at 2022-06-24 01:12:09.913631
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)),
                 14) == Decimal('0.5245901639')



# Generated at 2022-06-24 01:12:20.324068
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex0_start, ex0_asof = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10)
    ex1_start, ex1_asof = datetime.date(2020, 3, 2), datetime.date(2019, 9, 10)
    ex2_start, ex2_asof = datetime.date(2020, 3, 2), datetime.date(2020, 9, 10)
    ex3_start, ex3_asof = datetime.date(2020, 3, 1), datetime.date(2020, 9, 10)
    ex4_start, ex4_asof = datetime.date(2018, 2, 28), datetime.date(2019, 2, 28)
    ex5_start, ex5_asof = datetime.date(2019, 3, 2), dat

# Generated at 2022-06-24 01:12:31.838152
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-24 01:12:36.409542
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    dcfc_nl_365_ex1 = dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof)
    dcfc_nl_365_ex2 = dcf

# Generated at 2022-06-24 01:12:38.090990
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc=""
    res=""
    try:
        dcc = DCCRegistryMachinery.find("Act/Act")
        res = "pass"
    except Exception as e:
        res = "fail"
    return res


# Generated at 2022-06-24 01:12:45.492803
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    """
    Tests against dcfc_act_365_f examples provided.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)


# Generated at 2022-06-24 01:12:49.182960
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc = DCC('name',{},'currencies',lambda start, asof, end, freq: ONE)
    start = datetime.date(2020,1,1)
    asof = datetime.date(2020,1,2)
    end = datetime.date(2020,1,2)
    freq = Decimal('1')
    #
    x = dcc._calculate_daily_fraction(start, asof, end, freq)
    assert x == ONE




# Generated at 2022-06-24 01:12:55.952412
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    """
    Test the function dcfc_nl_365
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-24 01:13:05.308849
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863'))

# Generated at 2022-06-24 01:13:15.308882
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)),10)==round(Decimal(35/360),10) # day
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 2, 29)),10)==round(Decimal(36/360),10) # day
    assert round(dcfc_30_360_isda(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008, 11, 30)),10)==round(Decimal(396/360),10) # day

# Generated at 2022-06-24 01:13:25.319793
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == 0.166666666666667
    assert dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == 0.169444444444444
    assert dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == 1.08333333333333

# Generated at 2022-06-24 01:13:32.804193
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 28), end = datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')



# Generated at 2022-06-24 01:13:40.987184
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')


DCCRegistry = DCCRegistryMachinery()



# Generated at 2022-06-24 01:13:50.886975
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2017,12,31), datetime.date(2018,12,31), datetime.date(2018,12,31)), 14) == Decimal('1.00273972602740')
    assert round(dcfc_act_365_a(datetime.date(2017,12,31), datetime.date(2018,12,31), datetime.date(2019,12,31)), 14) == Decimal('1.99547945205479')
    assert round(dcfc_act_365_a(datetime.date(2017,12,31), datetime.date(2019,12,31), datetime.date(2019,12,31)), 14) == Decimal('1.99452054794521')

# Generated at 2022-06-24 01:13:59.223825
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC("Actual/365", {"Actual/365(Fixed)"}, _as_ccys({"USD"}), _actual_365_fixed_day_count_fraction) is not None
    assert DCC("Actual/365", {"Actual/365(Fixed)"}, _as_ccys({"USD"}), _actual_365_fixed_day_count_fraction) is not None
    assert DCC("Actual/365", {"Actual/365(Fixed)"}, _as_ccys({"USD"}), _actual_365_fixed_day_count_fraction) is not None
    assert DCC("Actual/365", {"Actual/365(Fixed)"}, _as_ccys({"USD"}), _actual_365_fixed_day_count_fraction) is not None

# Generated at 2022-06-24 01:14:09.341205
# Unit test for function dcc
def test_dcc():
    assert not DCCRegistry._find_strict("Act/Act")
    assert not DCCRegistry._find_strict("act/act")
    assert not DCCRegistry._find_strict(" act/act ")
    assert not DCCRegistry._find_strict("ACT/ACT")
    assert not DCCRegistry._find_strict("Act/Act ISDA")
    assert not DCCRegistry._find_strict("Act/Act ISDA (1980)")
    assert not DCCRegistry._find_strict("Act/Act (1980) ISDA")
    assert not DCCRegistry._find_strict("Act/Act (1980) ISDA")
    assert not DCCRegistry._find_strict("Actual/Actual")

# Generated at 2022-06-24 01:14:14.184540
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-24 01:14:25.361767
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Tests the function dcfc_30_e_360
    """
    assert dcfc_30_e_360(datetime.date(2018, 12, 31), datetime.date(2019, 12, 31), datetime.date(2019, 12, 31)) == 1
    assert dcfc_30_e_360(datetime.date(2018, 12, 31), datetime.date(2019, 11, 30), datetime.date(2019, 12, 31)) == Decimal('0.94444444444444')
    assert dcfc_30_e_360(datetime.date(2018, 12, 31), datetime.date(2019, 1, 31), datetime.date(2019, 12, 31)) == Decimal('1.02777777777778')

# Generated at 2022-06-24 01:14:31.958853
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc_1 = DCC("Name_1", {"A_1", "B_1"}, {"USD"}, _calculate_act_act_bf)
    dcc_2 = DCC("Name_2", {"A_2", "B_2"}, {"USD"}, _calculate_act_act_bf)
    dcc_3 = DCC("Name_3", {"A_3", "B_3"}, {"USD"}, _calculate_act_act_bf)
    dcc_4 = DCC("Name_4", {"A_4", "B_4"}, {"USD"}, _calculate_act_act_bf)
    mach = DCCRegistryMachinery()
    mach.register(dcc_1)
    mach.register(dcc_2)
    mach.register(dcc_3)

# Generated at 2022-06-24 01:14:43.636793
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    # These tests are from example calculations in Excel provided by ISDA
    assert dcfc_act_365_f(datetime.date(2019, 2, 28), datetime.date(2019, 5, 31), datetime.date(2019, 5, 31)) == \
        Decimal('0.103972602739726')
    assert dcfc_act_365_f(datetime.date(2019, 2, 28), datetime.date(2019, 5, 31), datetime.date(2020, 2, 28)) == \
        Decimal('0.520547945205479')


# Generated at 2022-06-24 01:14:55.828573
# Unit test for method coupon of class DCC

# Generated at 2022-06-24 01:15:04.615508
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof) == 0.16942884946478
    assert dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof) == 0.17216108990194
    assert dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof) == 1.08243131970956
    assert dcfc_act_act(start=ex4_start, asof=ex4_asof, end=ex4_asof) == 1.32625945055768


# Generated at 2022-06-24 01:15:13.151726
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .currencies import Currencies
    from .monetary import Money
    # Construct a Money Objects
    principal = Money(100,Currencies.AUD)
    # Construct a Money Objects
    rate = Money(0.08,Currencies.AUD)
    # Construct a Date Objects
    start = Date(2020,1,1)
    # Construct a Date Objects
    asof = Date(2020,3,1)
    # Construct a Date Objects
    end = Date(2021,3,1)
    # Call the Interest method
    DCC.interest(DCC,principal,rate,start,asof,end)

# Generated at 2022-06-24 01:15:23.561973
# Unit test for method interest of class DCC
def test_DCC_interest():
    dcc = DCC('ACT365', {'ACT365', '365', 'ACT/365', 'ACT/365F', '365F', 'ACTUAL/365', 'ACTUAL/365F'}, {'EUR', 'GBP', 'USD'}, lambda s, a, e, f: (_get_actual_day_count(s, a) / 365) if s < e else ZERO)
    r = dcc.interest(Money(1, 'EUR'), Decimal(0.4), start=datetime.date(2017, 8, 29), asof=datetime.date(2018, 8, 29))
    assert r == Money(0.4, 'EUR')



# Generated at 2022-06-24 01:15:29.097674
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    """
    This method is testing the dcfc_nl_365 function
    """
    print('Testing function dcfc_nl_365')
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:15:40.235323
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-24 01:15:46.713832
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    obj = DCCRegistryMachinery()
    dcc = DCC("name", {"alt"}, set(), lambda x, y, z, k: Decimal(1))

    obj.register(dcc)

    assert obj.table["name"] == dcc
    assert obj.table["alt"] == dcc



# Generated at 2022-06-24 01:15:51.519900
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')


# Generated at 2022-06-24 01:15:55.974882
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Test the method calculate_daily_fact of class DCC
    """
    ccy = Currencies["USD"]
    dcc = DCCRegistry["ACT/360"]
    interest = dcc.interest(Money(1_000, ccy), Decimal(0.1), datetime.date(2014, 3, 1), datetime.date(2014, 3, 6))
    assert abs(interest.amount - 0.5) < 0.001
    assert dcc.calculate_daily_fraction(datetime.date(2014, 3, 1), datetime.date(2014, 3, 6), datetime.date(2014, 3, 7)) == Decimal(1.0/6.0) == ZERO
    assert interest.currency == ccy


#: Defines the registry of day count convention definitions.

# Generated at 2022-06-24 01:16:08.249791
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .monetary import Money
    from .currencies import Currencies
    from .interest import IRR
    from .time import Per

    ## Set the currency
    ccy = Currencies["EUR"] 

    ## Set the principal
    principal = Money(10000, ccy)

    ## Set the tenor
    tenor = "5Y"

    ## Set the cashflow
    cf = [(Per(tenor).end, principal)]

    ## Set the cashflow at the end of each year
    cfYearly = [(Per(tenor).end, principal)]
    for i in range(0, 6):
        cfYearly.append((Per(tenor).start + relativedelta(years=i), principal))
    cfYearly.append((Per(tenor).end, principal))

    ## Calculate the IRR
    irr = IR

# Generated at 2022-06-24 01:16:14.973607
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC("DCC_NAME", {"NAME"}, {Currencies.USD}, lambda d1, d2, d3: Decimal(2))
    assert dcc.calculate_fraction(datetime.date(2012, 3, 1), datetime.date(2012, 3, 1), datetime.date(2012, 3, 1)) == Decimal(0)
    assert dcc.calculate_fraction(datetime.date(2012, 3, 1), datetime.date(2012, 3, 2), datetime.date(2012, 3, 2)) == Decimal(2)


# Generated at 2022-06-24 01:16:23.883780
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal = Money(1.0, 'USD')
    rate = Decimal(0.07)
    asof = Date(datetime.date(2018, 11, 21))
    end = asof
    freq = Decimal(1)
    eom = None
    start = Date(datetime.date(2018, 1, 1))

    ## Find the previous and next payment dates:
    prevdate = _last_payment_date(start, asof, freq, eom)
    nextdate = _next_payment_date(prevdate, freq, eom)

    ## Calculate the interest and return:
    return principal * rate * DCCActual360.calculate_fraction(prevdate, asof, nextdate, Decimal(freq))


# Generated at 2022-06-24 01:16:30.000051
# Unit test for function dcc
def test_dcc():
    @dcc("Actual/360", {'30/360', 'Act/360', 'A/360', 'A360', '360'})
    def _dcfc(start, asof, end, freq):
        return ((end - start).days + (asof - start).days) / 360

    assert DCCRegistry.find('Actual/360').name == 'Actual/360'
    DCCRegistry._buffer_main.clear()
    DCCRegistry._buffer_altn.clear()


#: Defines a converter from date string to date object.
to_date = lambda e: e.date() if not isinstance(e, datetime.date) else e



# Generated at 2022-06-24 01:16:36.436822
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    start = datetime.date(2012, 12, 15)
    asof = datetime.date(2015, 12, 31)
    end = datetime.date(2016, 1, 6)
    principal = Money(10000)
    rate = 0.01
    freq = 2
    eom = None
    dcc = DCC('name','altname',{},{})
    assert dcc.coupon(principal,rate,start,asof,end,freq,eom) == Money(50)



# Generated at 2022-06-24 01:16:44.316137
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    print(round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14))
    print(round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14))
    print(round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14))    

# Generated at 2022-06-24 01:16:53.640630
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCCs.ACT_365.interest(principal=Money.parse("100"), rate=Decimal("0.01"), start=Date(2017, 1, 2), asof=Date(2017, 1, 31)) == Money.parse("2.97"), "Failed on ACT_365"
    assert DCCs.ACT_360.interest(principal=Money.parse("100"), rate=Decimal("0.01"), start=Date(2017, 1, 2), asof=Date(2017, 1, 31)) == Money.parse("2.5"), "Failed on ACT_360"

# Generated at 2022-06-24 01:17:01.339336
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17260273972603')
    assert round(dcfc_act_365_f(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08493150684932')

# Generated at 2022-06-24 01:17:12.995362
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # Day count fraction examples retrieved from
    # http://www.datadisk.co.uk/html_docs/excel/app_e.htm
    assert round(dcfc_30_e_360(datetime.date(2004, 4, 30), datetime.date(2004, 4, 30)), 14) == Decimal('0.0')
    assert round(dcfc_30_e_360(datetime.date(2004, 4, 30), datetime.date(2004, 5, 31)), 14) == Decimal('0.08333333333333')
    assert round(dcfc_30_e_360(datetime.date(2004, 4, 30), datetime.date(2004, 6, 30)), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:17:21.698415
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(ex1_start, ex1_asof, ex1_end), 10) == round(Decimal('0.5245901639'), 10)



# Generated at 2022-06-24 01:17:32.401865
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 28)) == 0.16666666666666666
    assert dcfc_30_e_360(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 29)) == 0.1694444444444444
    assert dcfc_30_e_360(start = datetime.date(2007, 10, 31), asof = datetime.date(2008, 11, 30)) == 1.0833333333333333
    assert dcfc_30_e_360(start = datetime.date(2008, 2, 1), asof = datetime.date(2009, 5, 31)) == 1.3305555555555557

# Generated at 2022-06-24 01:17:38.510505
# Unit test for function dcc
def test_dcc():
    @dcc("Test")
    def func(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return ONE

    assert DCCRegistry.find("Test") is func.__dcc



# Generated at 2022-06-24 01:17:42.297660
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    DCC_obj = DCC("name","altnames","currencies", "calculate_fraction_method")

    # Test DCC calculate_fraction
    assert DCC_obj.calculate_fraction("start","asof","end") == ZERO


# Generated at 2022-06-24 01:17:49.333917
# Unit test for constructor of class DCC
def test_DCC():
    from datetime import date

    start_date = date(2014, 5, 1)
    asof_date = date(2014, 5, 15)
    end_date = date(2014, 12, 31)
    print(DCC('DCC30/360', set(), set(), DCC_30_360_ISDA.calculate_fraction_method).calculate_fraction(start_date, asof_date, end_date))

    start_date = date(2016, 12, 1)
    asof_date = date(2017, 1, 1)
    print(DCC('DCC30/360', set(), set(), DCC_30_360_ISDA.calculate_fraction_method).calculate_fraction(start_date, asof_date, end_date))

## http://www.isda

# Generated at 2022-06-24 01:17:57.945392
# Unit test for function dcc
def test_dcc():
    @dcc("Test", set(["Test"]))
    def dcfc(start, asof, end, freq):
        return Decimal(1.0)

    assert dcfc(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28), freq=None) \
        == Decimal(1.0)


#: Register the act-act calculation function under the given name.

# Generated at 2022-06-24 01:18:09.176702
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from .currencies import Currencies, Currency
    from .monetary import Money
    from datetime import date

    print("Testing DCC.coupon...")
    currency = Currencies.USD
    principal = Money("100", currency)
    rate = Decimal("0.05")
    freq = Decimal("1")
    start = date(2017, 7, 1)
    asof = date(2017, 7, 25)
    nextdate = date(2018, 7, 1)

    expected_coupon = Money("0.4375", currency)
    calculated_coupon = DCCRegistry.ACT360.coupon(principal, rate, start, asof, nextdate, freq)
    assert expected_coupon == calculated_coupon

    print("Testing DCC.coupon... Passed.")


