

# Generated at 2022-06-24 01:08:15.381407
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .monetary import Money, MoneyFactory
    from .currencies import Currencies
    from .prices import PRICES
    from .interestrates import InterestRate, InterestRateFactory
    # Setup
    mf = MoneyFactory(PRICES)
    irf = InterestRateFactory(PRICES)
    ccy = Currencies.USD
    dcc = DCCRegistry.ISDA

    start = Date(2018, 1, 1)
    asof = Date(2018, 12, 31)
    end = Date(2019, 1, 1)
    freq = 1

    #Execute
    actual = dcc.calculate_fraction(start, asof, end, freq)

    #Expect
    expected = Decimal("1")
    assert actual == expected, "incorrect calculation of dcc fraction"


# Generated at 2022-06-24 01:08:21.241756
# Unit test for function dcfc_act_act
def test_dcfc_act_act():

    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')

    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')


# Generated at 2022-06-24 01:08:28.318642
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), 
                       datetime.date(2008, 2, 28)) == Decimal('0.16986301369863')
    assert dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), 
                       datetime.date(2008, 2, 29)) == Decimal('0.16986301369863')
    assert dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), 
                       datetime.date(2008, 11, 30)) == Decimal('1.08219178082192')

# Generated at 2022-06-24 01:08:38.631741
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    """
    Unit test for function dcfc_act_365_a.

    It compares the result from dcfc_act_365_a to the result from dcfc_act_365_f.
    """

    list_of_date = list()
    # add example to the list
    list_of_date.append(datetime.date(2007, 12, 28))
    list_of_date.append(datetime.date(2008, 2, 28))
    list_of_date.append(datetime.date(2007, 12, 28))
    list_of_date.append(datetime.date(2008, 2, 29))
    list_of_date.append(datetime.date(2007, 10, 31))
    list_of_date.append(datetime.date(2008, 11, 30))
    list_

# Generated at 2022-06-24 01:08:44.587524
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Set up test data
    start = datetime.date(2000,1,1)
    asof = datetime.date(2000,1,1)
    end = datetime.date(2000,1,1)
    freq = 1
    # Call the function
    result = dcfc_30_360_german(start,asof,end,freq)



# Generated at 2022-06-24 01:08:56.420546
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:09:06.315969
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(datetime.date(2014, 1, 15), datetime.date(2014, 7, 15)), 14) == 0.5
    assert round(dcfc_30_360_us(datetime.date(2014, 1, 30), datetime.date(2014, 7, 15)), 14) == 0.5
    assert round(dcfc_30_360_us(datetime.date(2014, 1, 15), datetime.date(2014, 7, 30)), 14) == 0.5
    assert round(dcfc_30_360_us(datetime.date(2014, 1, 15), datetime.date(2014, 7, 31)), 14) == 0.50277777777778

# Generated at 2022-06-24 01:09:17.191591
# Unit test for constructor of class DCC
def test_DCC():
    ## Create the DCC
    dcc = DCC("Actual/Actual (ISDA)", {}, {Currencies.USD}, lambda x, y, z, w: Decimal(0))
    
    ## Assert the name is set correctly
    assert dcc.name == "Actual/Actual (ISDA)"
    
    ## Assert the currencies are set correctly
    assert dcc.currencies == {Currencies.USD}
    
    ## Assert the altnames are set correctly
    assert dcc.altnames == {}
    
    ## Assert calculate_fraction returns 0
    assert dcc.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal(0)



# Generated at 2022-06-24 01:09:26.147297
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert DCCRegistry.find("act/act")
    assert DCCRegistry.find("Act/Act")
    assert DCCRegistry.find("Actual/Actual")
    assert DCCRegistry.find("Actual/Actual (ISDA)")
    assert DCCRegistry.find("Actual/Actual (ISDA)") == DCCRegistry.find("Actual/Actual")



# Generated at 2022-06-24 01:09:35.271732
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC('test', ('test1', 'test2', 'test3'), ('USD', 'AUD'), lambda x, y, z, a: 1).name == 'test'
    assert DCC('test', ('test1', 'test2', 'test3'), ('USD', 'AUD'), lambda x, y, z, a: 1).altnames == {'test1', 'test2', 'test3'}
    assert DCC('test', ('test1', 'test2', 'test3'), ('USD', 'AUD'), lambda x, y, z, a: 1).currencies == {Currencies['USD'], Currencies['AUD']}

# Generated at 2022-06-24 01:09:36.572719
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    DCCRegistryMachinery()


# Generated at 2022-06-24 01:09:49.830359
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(datetime.date(2012,8,31),datetime.date(2012,9,30),datetime.date(2012,9,30)) == Decimal("0.033333333333333")
    assert dcfc_30_360_isda(datetime.date(2012,12,31),datetime.date(2013,9,30),datetime.date(2013,9,30)) == Decimal("0.78055555555556")
    assert dcfc_30_360_isda(datetime.date(2011,1,31),datetime.date(2011,4,1),datetime.date(2011,4,1)) == Decimal("0.083333333333333")

# Generated at 2022-06-24 01:09:59.223845
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2005, 2, 28), datetime.date(2006, 2, 28)
    ex2_start, ex2_asof = datetime.date(2004, 6, 30), datetime.date(2006, 6, 30)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 2, 29)
    ex4_start, ex4_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex5_start, ex5_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex6_start, ex6_asof = datetime.date(2008, 2, 1), dat

# Generated at 2022-06-24 01:10:03.902882
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert np.isclose(dcfc_30_360_us(start=datetime.date(2010, 12, 30), asof=datetime.date(2011, 1, 31), end=None), Decimal('0.0833333333333'))
    assert np.isclose(dcfc_30_360_us(start=datetime.date(2011, 1, 31), asof=datetime.date(2011, 3, 31), end=None), Decimal('0.1666666666667'))
    assert np.isclose(dcfc_30_360_us(start=datetime.date(2011, 3, 31), asof=datetime.date(2011, 3, 31), end=None), Decimal('0'))

# Generated at 2022-06-24 01:10:05.211166
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc = DCCRegistry.find('30e/360 ISDA')
    assert dcc.name == '30E/360 ISDA'

# Generated at 2022-06-24 01:10:15.937574
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert dcfc_act_365_l(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)) \
        == Decimal('0.16939890710383')
    assert dcfc_act_365_l(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 2, 29)) \
        == Decimal('0.17213114754098')
    assert dcfc_act_365_l(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008, 11, 30)) \
        == Decimal('1.08196721311475')

# Generated at 2022-06-24 01:10:23.361713
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """Unit test for function dcfc_act_act_icma"""
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')


# Generated at 2022-06-24 01:10:34.284486
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from dateutil.parser import parse as date_parse
    import numpy as np
    from .currencies import Currency
    from .monetary import Money
    from .pricing import N

    DATA = [
        [
            Money(10000, Currency('EUR')),
            N(0.0123),
            date_parse('2018-11-15'),
            date_parse('2018-12-31'),
            1 / 6,
            N(0.0034)
        ]
    ]

    for (principal, rate, start, asof, freq, expected_result) in DATA:
        # test normal interest
        actual_result = DCCs.ACT_360.coupon(principal, rate, start, asof, start, freq)

# Generated at 2022-06-24 01:10:37.503310
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    start = datetime.date(2007, 10, 31)
    asof = datetime.date(2008, 11, 30)
    assert dcfc_30_e_plus_360(start=start, asof=asof, end=asof) == pytest.approx(1.08333333333333333333)



# Generated at 2022-06-24 01:10:46.287041
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    registry = DCCRegistryMachinery()
    assert registry
    registry.register(DCC("Act/360", {"360", "Act360", "Act/360"}, {}, _dcf_act_360))
    dcc = registry.find("Act/360")
    assert dcc
    assert dcc.name == "Act/360"
    assert "Act360" in dcc.altnames
    assert Currencies["USD"] in dcc.currencies
    assert dcc.calculate_fraction is _dcf_act_360


# noinspection PyUnusedLocal

# Generated at 2022-06-24 01:10:53.545675
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == \
           Decimal('0.16666666666667')

# Generated at 2022-06-24 01:11:00.042995
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_f(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17260273972603')
    assert round(dcfc_act_365_f(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08493150684932')

# Generated at 2022-06-24 01:11:08.798767
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dccdict = {
        "name" : "Act/Act",
        "altnames" : {"ISMA", "AFB", "ISDA", "BIS"},
        "currencies" : {"USD"},
        "calculate_fraction_method" : dcActAct
    }
    dcc = DCC(**dccdict)

    dccregistry = DCCRegistryMachinery()
    dccregistry.register(dcc)

    assert dccregistry._is_registered("Act/Act") == True
    assert dccregistry._is_registered("Wrong/Name") == False

    assert dcc == dccregistry.find("Act/Act")
    assert dcc == dccregistry.find("Act/act")
    assert dcc == dccregistry.find("act/act")

# Generated at 2022-06-24 01:11:14.908572
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert isclose(dcfc_act_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 
                   Decimal('0.17222222222222'), rel_tol=1e-12)
    assert isclose(dcfc_act_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 
                   Decimal('0.17500000000000'), rel_tol=1e-12)

# Generated at 2022-06-24 01:11:20.261307
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-24 01:11:29.674070
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert(dcfc_act_365_f(datetime.date(2011, 1, 3), datetime.date(2011, 6, 30), datetime.date(2011, 9, 30)) == 0.50684931506849305)
    assert(dcfc_act_365_f(datetime.date(2011, 11, 8), datetime.date(2012, 11, 8), datetime.date(2012, 11, 8)) == 1.0)
    assert(dcfc_act_365_f(datetime.date(2011, 11, 8), datetime.date(2012, 11, 20), datetime.date(2012, 11, 8)) == 0.99315068493150678)


# Generated at 2022-06-24 01:11:41.328818
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    ## Test with AFE:
    dcc = DCCRegistry.afe
    assert dcc.calculate_daily_fraction(datetime.date(2018, 1, 2), datetime.date(2018, 1, 3), datetime.date(2018, 2, 3)) == ONE / THIRTY_THREE
    assert dcc.calculate_daily_fraction(datetime.date(2018, 2, 1), datetime.date(2018, 2, 2), datetime.date(2018, 2, 2)) == ZERO
    assert dcc.calculate_daily_fraction(datetime.date(2018, 2, 1), datetime.date(2018, 2, 2), datetime.date(2018, 2, 3)) == ONE / THIRTY_FOUR

# Generated at 2022-06-24 01:11:48.805216
# Unit test for constructor of class DCC
def test_DCC():
    print('Testing the constructor of class DCC')
    dc_1=DCC('30E/360',set(['30E/360']),set(['EUR']),_dc30_360)
    assert dc_1.name=='30E/360'
    assert dc_1.altnames==set(['30E/360'])
    assert dc_1.currencies==set(['EUR'])
    assert dc_1.calculate_fraction_method==_dc30_360
    print('Constructor of class DCC is working fine')


# Generated at 2022-06-24 01:11:58.065241
# Unit test for function dcc
def test_dcc():
    """
    Tests the dcc function.
    """

    # Test if dcc function works as expected:
    @dcc("Act/Act", {"Actual/Actual", "Act/Act"})
    def _dcc_actact(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Day count fraction calculator for Actual/Actual day count convention.
        """
        return (asof - start) / (end - start)


    # Check if dcc function acts as expected:
    assert _dcc_actact.__name__ == "_dcc_actact"
    assert _dcc_actact.__qualname__ == "_dcc_actact"

    # Check the actual attributes of the function:

# Generated at 2022-06-24 01:12:09.967537
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    # Check the result of function dcfc_act_365_f
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_f(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17260273972603')
    assert round(dcfc_act_365_f(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08493150684932')

# Generated at 2022-06-24 01:12:20.367347
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:12:31.916163
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:12:40.812398
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCC('A', {'B'}, {Currencies["USD"]}, lambda s, a, e, f: 2).interest(Money(10, 'USD'), 1, Date(2014, 1, 1), Date(2014, 1, 2)) == Money(0.0027777777777778, 'USD')
    assert DCC('A', {'B'}, {Currencies["USD"]}, lambda s, a, e, f: 2).interest(Money(10, 'USD'), 1, Date(2014, 1, 1), Date(2014, 1, 1)) == Money(0, 'USD')

# Generated at 2022-06-24 01:12:45.549476
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCCRegistry["ACT/360"].calculate_daily_fraction(
        datetime.date(2018, 1, 1),
        datetime.date(2018, 3, 1),
        datetime.date(2018, 12, 31)
    ) == Decimal(1) / Decimal(360)



# Generated at 2022-06-24 01:12:50.382761
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """

    >>> DCC('A', {'B'}, {'USD'}, lambda x,y,z: Decimal('0')).calculate_daily_fraction('a','b','c')
    Decimal('0')
    """



# Generated at 2022-06-24 01:12:54.632687
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')



# Generated at 2022-06-24 01:13:00.478952
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    result = DCCRegistry.AFB(DCCRegistry.AFB.name).calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 6, 30), datetime.date(2014, 12, 31), None)
    assert(result == 0.5)

# Generated at 2022-06-24 01:13:07.561378
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # Tests are passed to assertAlmostEqual, so that a test fails if the expected
    # and computed results differ by more than 1.0e-14.
    assertAlmostEqual(dcfc_30_e_360(datetime.date(2007, 12, 28),
                                      datetime.date(2008, 2, 28)),
                      0.16666666666667)
    assertAlmostEqual(dcfc_30_e_360(datetime.date(2007, 12, 28),
                                      datetime.date(2008, 2, 29)),
                      0.16944444444444)
    assertAlmostEqual(dcfc_30_e_360(datetime.date(2007, 10, 31),
                                      datetime.date(2008, 11, 30)),
                      1.08333333333333)

# Generated at 2022-06-24 01:13:16.391433
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof),14) == round(Decimal('0.16986301369863'),14)

# Generated at 2022-06-24 01:13:27.215043
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:13:37.750972
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert dcc("30/360 German")(
        start=datetime.date(2007, 12, 28),
        asof=datetime.date(2008, 2, 28),
        end=datetime.date(2008, 2, 28),
    ) == Decimal('0.16666666666667')
    assert dcc("30/360 German")(
        start=datetime.date(2007, 12, 28),
        asof=datetime.date(2008, 2, 29),
        end=datetime.date(2008, 2, 29),
    ) == Decimal('0.16944444444444')

# Generated at 2022-06-24 01:13:42.048548
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')


# Generated at 2022-06-24 01:13:49.051226
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    """
    Test cases for the function dcfc_act_365_a.

    Test cases are defined in the function dcfc_act_365_a.
    """
    pass
# Test cases for the function dcfc_act_365_a



# Generated at 2022-06-24 01:13:57.456634
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:14:03.183183
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10),
                                   end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')



# Generated at 2022-06-24 01:14:13.512914
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Unit test for method find of class DCCRegistryMachinery
    """
    from financepy.finutils.FinDate import FinDate
    from financepy.products.funding.FinIborSingleCurve import FinIborSingleCurve
    from financepy.products.funding.FinIborFRA import FinIborFRA
    from financepy.products.funding.FinIborDeposit import FinIborDeposit
    from financepy.products.funding.FinIborSwap import FinIborSwap
    from financepy.products.funding.FinIborFuture import FinIborFuture
    from financepy.products.bonds.FinBond import FinBond
    from financepy.products.bonds.FinBondYield import FinBondYield
    from financepy.products.bonds.FinSchedule import FinSchedule
   

# Generated at 2022-06-24 01:14:24.757828
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14)==Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14)==Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14)==Decimal

# Generated at 2022-06-24 01:14:30.050364
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    result = coupon(100000, 0.02, datetime.date(2005, 12,  1), datetime.date(2010, 12,  1), datetime.date(2021,  1,  1), 2, eom=2)
    assert result == Money('515.17')


#: Defines the set of day count conventions.
CONVENTIONS = set()



# Generated at 2022-06-24 01:14:36.898234
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Do the math of dcfc_act_act
    assert round(dcfc_act_act(start = datetime.date(2007, 12, 28), asof= datetime.date(2008, 2, 28), end = datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start = datetime.date(2007, 12, 28), asof= datetime.date(2008, 2, 29), end = datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-24 01:14:46.921405
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC("test", {}, {}, lambda a,b,c,d: 1.0).coupon(
        Money("EUR", Decimal("1.0")), Decimal("0.1"), Date("2018-01-01"), Date("2018-01-01"), Date("2018-01-01"), 1) == Money("EUR", Decimal("0.1"))
    start = Date("2018-01-01")
    asof = Date("2018-12-01")
    prev = Date("2018-07-01")
    next = Date("2019-01-01")
    rate = Decimal("0.2")
    principal = Money("EUR", Decimal("1.0"))
    expected = principal * rate * 6 / 12

# Generated at 2022-06-24 01:14:58.713858
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert (round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==Decimal('0.17222222222222'))

# Generated at 2022-06-24 01:15:05.198491
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ## From http://www.quantlib.org/PLATFORM_DOC/quantlib-documentation.html#Day-counting-conventions
    d1 = QL.Date(15, QL.March, 2011)
    d2 = QL.Date(15, QL.June, 2011)
    d3 = QL.Date(15, QL.September, 2011)
    d4 = QL.Date(15, QL.December, 2011)
    assert round(dcfc_30_360_us(
        start=d1.to_date(),
        asof=d2.to_date(),
        end=d2.to_date()
    ), 14) == Decimal('0.18333333333333')

# Generated at 2022-06-24 01:15:14.933627
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-24 01:15:21.992111
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 1, 6)
    asof = datetime.date(2014, 1, 3)
    freq = None
    assert dcc_30_365._replace(calculate_fraction=dcc_30_365.calculate_fraction_method).calculate_fraction(start, asof, end, freq) == Decimal('0.07')

# Generated at 2022-06-24 01:15:28.709488
# Unit test for constructor of class DCC
def test_DCC():
    dcc = DCC(name="ACT/360", altnames={"ACT_360"}, currencies=set(), calculate_fraction_method=lambda *args: Decimal("1.23"))
    assert dcc.name == "ACT/360"
    assert dcc.altnames == {"ACT_360"}
    assert dcc.currencies == set()
    assert dcc.calculate_fraction_method(Date(2018, 1, 1), Date(2018, 1, 2), Date(2018, 1, 2)) == Decimal("1.23")

###
# ACTUAL/ACTUAL
#
# The actual number of days in the period divided by the actual number of days in the year.



# Generated at 2022-06-24 01:15:35.253207
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    start, asof, end=datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)
    print(round(dcfc_act_360(start=start, asof=asof, end=end), 14))

test_dcfc_act_360()


# Generated at 2022-06-24 01:15:35.944194
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    pass

# Generated at 2022-06-24 01:15:46.669874
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    test = DCCRegistryMachinery()
    assert test

## Define the day count registry:
DCCRegistry: DCCRegistryMachinery = DCCRegistryMachinery()

## Register the day count conventions:
DCCRegistry.register(DCC("Act/Act", {"Actual/Actual"}, {}, _dcf_act_act))
DCCRegistry.register(DCC("Act/360", {"Actual/360"}, {Currencies["USD"]}, _dcf_act_360))
DCCRegistry.register(DCC("Act/365", {"Actual/365"}, {Currencies["USD"]}, _dcf_act_365))

# Generated at 2022-06-24 01:15:51.186374
# Unit test for method interest of class DCC
def test_DCC_interest():
    DCC = DCC(name='act/act', altnames=set(), currencies=set(), calculate_fraction_method=_actual_actual_act_act_ISDA)
    print(DCC.interest(Money('100', 'USD'), Decimal('0.01'), datetime.date(2019, 1, 1), datetime.date(2019, 6, 28)))


# Generated at 2022-06-24 01:15:57.762551
# Unit test for method interest of class DCC
def test_DCC_interest():
    dcc = DCC("test", {}, {}, lambda *args, **kwargs: None)
    money = dcc.interest(Money.USD(100), 0.01, Date(2018, 12, 1), Date(2019, 1, 1), Date(2019, 12, 31))
    assert (money == Money.USD(1.0))


# Generated at 2022-06-24 01:16:03.383290
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(start=Date(1, 1, 2016), asof=Date(1, 1, 2016), end=Date(1, 1, 2016)) == 0
    assert dcfc_30_360_us(start=Date(1, 2, 2016), asof=Date(1, 2, 2016), end=Date(1, 2, 2016)) == 0
    assert dcfc_30_360_us(start=Date(1, 3, 2016), asof=Date(1, 3, 2016), end=Date(1, 3, 2016)) == 0
    assert dcfc_30_360_us(start=Date(1, 4, 2016), asof=Date(1, 4, 2016), end=Date(1, 4, 2016)) == 0

# Generated at 2022-06-24 01:16:13.841588
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==Decimal('0.17222222222222')

# Generated at 2022-06-24 01:16:24.485116
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-24 01:16:34.670312
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')
    # AssertionError: assert round(dcc.calculate_fraction

# Generated at 2022-06-24 01:16:41.354122
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from osqutil.configuration import ConfigManager

    cfg = ConfigManager()
    cfg.add_defaults([
        ("connections", {"DB_TEST_ENGINE": "sqlite:///:memory:"}),
    ])
    cfg["connections"]["DB_TEST_ENGINE"]
    cfg.connect({})
    cfg.initdb()

    import osqutil.data.models
    import osqutil.finmath.cashflows

    # Save the ccy:
    ccy = Currencies["USD"]

# Generated at 2022-06-24 01:16:52.130461
# Unit test for function dcc
def test_dcc():
    @dcc("Thirty 360 ISMA")
    def isma360(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Calculates day count fraction according to the 360 ISMA convention.
        """
        return ((asof.year - start.year) * 360 + (asof.month - start.month) * 30 + (asof.day - start.day)) / 360

    assert isma360.__dcc.name == "Thirty 360 ISMA"



# Generated at 2022-06-24 01:17:00.124770
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Test data:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    # Expected results:
    ex1_expected_result = Decimal('0.16666666666667')
    ex2_expected_result = Decimal('0.16944444444444')
    ex3_expected_

# Generated at 2022-06-24 01:17:11.540160
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    test_DCC_calculate_fraction.__doc__ += '\n' + DCC.calculate_fraction.__doc__
    assert ZERO == DCC('', {},{},DCFC).calculate_fraction(datetime.date(2017, 12, 31),
                                                         datetime.date(2017, 12, 1),
                                                         datetime.date(2017, 12, 31))
    assert ONE == DCC('', {},{},DCFC).calculate_fraction(datetime.date(2017, 12, 31),
                                                        datetime.date(2017, 12, 31),
                                                        datetime.date(2017, 12, 31))

# Generated at 2022-06-24 01:17:17.913300
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert(dcfc_act_act_icma(datetime.date(2020,1,2),datetime.date(2020,2,29),datetime.date(2020,3,1),4) == float(31)/float(4*365))
test_dcfc_act_act_icma()



# Generated at 2022-06-24 01:17:26.426477
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(datetime.date(2013, 3, 1), datetime.date(2013, 9, 30), datetime.date(2013, 9, 30)) == 0.625
    assert dcfc_30_e_plus_360(datetime.date(2013, 2, 28), datetime.date(2013, 3, 1), datetime.date(2013, 3, 1)) == 0.0  
    assert dcfc_30_e_plus_360(datetime.date(2013, 2, 28), datetime.date(2013, 2, 28), datetime.date(2013, 2, 28)) == 0.0  

# Generated at 2022-06-24 01:17:30.752747
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert dcfc_act_365_l(datetime.date(2008, 1, 31), datetime.date(2009, 2, 28), datetime.date(2009, 2, 28)) == 1/Decimal(366)
    return dcfc_act_365_l(datetime.date(2008, 1, 31),datetime.date(2009,3,31),datetime.date(2009,3,31)) == 1/Decimal(366)


# Generated at 2022-06-24 01:17:43.036961
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d30_360 = DCC(
        name="30/360", altnames={"d30_360", "30/360", "thirty_360"}, currencies=_as_ccys({"USD"}),
        calculate_fraction_method=DCC._d30_360
    )

    usd = Currencies['USD']
    assert Money(10, usd).as_decimal() == Decimal(10)
    assert Money(10, usd) == Money(10, 'USD')
    assert Money(10, usd) == Money(10, Currencies['USD'])

    assert Money(10, usd) * Decimal(0.5) == Money(5, usd)
    assert Money(10, usd) * 0.5 == Money(5, usd)
    assert Money(10, usd) * Decimal

# Generated at 2022-06-24 01:17:43.571771
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    DCCRegistry()


# Generated at 2022-06-24 01:17:55.345930
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    as_of_date = datetime.date(2018, 7, 25)

# Generated at 2022-06-24 01:18:02.559268
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-24 01:18:10.346606
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    """
    The assertion below is made available on the official ISDA site.
    """
    assert dcfc_act_365_l(start=datetime.date(2015, 2, 11), asof=datetime.date(2017, 5, 10), end=datetime.date(2017, 6, 9)) == Decimal('1.03559322033898')
    print("Test passed.")
test_dcfc_act_365_l()

