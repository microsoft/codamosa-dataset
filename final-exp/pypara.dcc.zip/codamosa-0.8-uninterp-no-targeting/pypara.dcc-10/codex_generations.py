

# Generated at 2022-06-21 20:12:15.036902
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Tests the method find of class DCCRegistryMachinery.
    """
    target = DCCRegistryMachinery()
    target.register(DCC("ACT/365", {"act/365", "act365"}, {"USD", "EUR"}, dcf_act_act_basic))
    target.register(DCC("ACT/360", {"act/360", "act360"}, {"USD", "EUR"}, dcf_act_act_basic))
    target.register(DCC("ACT/364", {"act/364", "act364"}, {"USD", "EUR"}, dcf_act_act_basic))
    target.register(DCC("ACT/365L", {"act/365l", "act365l"}, {"USD", "EUR"}, dcf_act_act_leapyear))

# Generated at 2022-06-21 20:12:26.824182
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal = Money(4000, "CAD")
    rate = Decimal(0.05)
    start = Date(2018, 1, 1)
    asof = Date(2018, 3, 30)
    end = Date(2019, 1, 1)
    freq = Decimal(2)
    eom = 30
    expected = Money(100, "CAD")
    actual = DCCRegistry.ACTUAL.coupon(principal, rate, start, asof, end, Decimal(freq), eom)
    assert actual == expected
    expected = Money(166.666667, "CAD")
    actual = DCCRegistry.ACTUAL_360.coupon(principal, rate, start, asof, end, Decimal(freq), eom)
    assert actual == expected



# Generated at 2022-06-21 20:12:39.115326
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-21 20:12:46.759376
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(datetime.date(2015, 11, 30), datetime.date(2016, 2, 29)) == Decimal('0.08333333333333')
    assert dcfc_30_e_360(datetime.date(2015, 11, 30), datetime.date(2016, 2, 30)) == Decimal('0.08611111111111')
    assert dcfc_30_e_360(datetime.date(2016, 2, 29), datetime.date(2016, 5, 31)) == Decimal('0.08333333333333')
    assert dcfc_30_e_360(datetime.date(2016, 6, 30), datetime.date(2016, 8, 31)) == Decimal('0.08333333333333')

# Generated at 2022-06-21 20:12:52.149255
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(datetime.date(2018, 2, 28), datetime.date(2018, 3, 30), datetime.date(2018, 3, 30)),
                 14) == 0.08333333333333
    assert round(dcfc_30_360_german(datetime.date(2018, 2, 28), datetime.date(2018, 3, 31), datetime.date(2018, 3, 31)),
                 14) == 0.08611111111111
    assert round(dcfc_30_360_german(datetime.date(2018, 2, 30), datetime.date(2018, 3, 30), datetime.date(2018, 3, 30)),
                 14) == 0.08333333333333

# Generated at 2022-06-21 20:13:03.649365
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_f(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17260273972603')
    assert round(dcfc_act_365_f(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-21 20:13:11.499736
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert int(DCCRegistry.A30_360.interest(Money(100, "USD"), Decimal(0.00375), datetime.date(2015, 1, 1), datetime.date(2015, 12, 31)).value) == 3
    assert int(DCCRegistry.A30_360_US.interest(Money(100, "USD"), Decimal(0.00375), datetime.date(2015, 1, 1), datetime.date(2015, 12, 31)).value) == 3
    assert int(DCCRegistry.A30E_360.interest(Money(100, "USD"), Decimal(0.00376), datetime.date(2015, 1, 1), datetime.date(2016, 1, 1)).value) == 4

# Generated at 2022-06-21 20:13:23.428620
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2019, 10, 30)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2019, 10, 30)), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-21 20:13:31.185354
# Unit test for method interest of class DCC
def test_DCC_interest():
    class dummy_Money:
        def __init__(self, value):
            self.amount = value
        def __mul__(self, other):
            return dummy_Money(self.amount * other)

    principal=dummy_Money(10)
    rate=1
    start=asof=end=datetime.date(2022, 1, 1)
    freq=1
    result=10
    assert result==(DCC_ACT._DCC__calculate_fraction(start, asof, end, freq)*(rate*principal.amount)).amount

# unit test for method calculate_fraction of class DCC

# Generated at 2022-06-21 20:13:39.673697
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Unit test for function dcfc_30_360_german.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:14:14.375498
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = Date('2019-01-01')
    asof = Date('2019-12-31')
    end = Date('2021-12-31')
    freq = None
    assert DCCRegistry['ACT/ACT'].calculate_fraction(start, asof, end, freq)
    assert DCCRegistry['30/360'].calculate_fraction(start, asof, end, freq) == Decimal('0.833333333333333')
    assert DCCRegistry['NL/360'].calculate_fraction(start, asof, end, freq) == Decimal('0.833333333333333')

# Generated at 2022-06-21 20:14:17.421414
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert dcfc_nl_365(start=datetime.date(2021, 2, 28), asof=datetime.date(2021, 3, 1), end=datetime.date(2021, 3, 1)) == 1/365



# Generated at 2022-06-21 20:14:29.300738
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-21 20:14:39.460360
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    This function tests the behavior of the {% link dcfc_30_e_360.dcfc_30_e_360 %} function.
    """
    # Test {% link dcfc_30_e_360.dcfc_30_e_360 %} function.
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1),

# Generated at 2022-06-21 20:14:52.097389
# Unit test for function dcfc_act_365_l

# Generated at 2022-06-21 20:14:55.476380
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    test_start, test_end   = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    expected_fraction      = Decimal('0.16986301369863')
    output_fraction        = dcfc_act_365_f(start=test_start, asof=test_end, end=test_end)
    assert round(expected_fraction,14) == round(output_fraction,14)



# Generated at 2022-06-21 20:15:06.663416
# Unit test for constructor of class DCC
def test_DCC():
    Start_Date=datetime.datetime(2020, 12, 1)
    As_of_Date=datetime.datetime(2020, 12, 1)
    End_Date=datetime.datetime(2021, 1, 1)
    Freq=1
    Principal=Money(10000, 'USD')
    Rate=0.02
    dcc=DCC(name='Act/365F', altnames=set(), currencies=set(), calculate_fraction_method=calculate_fraction_method)
    result=dcc.calculate_fraction(Start_Date, As_of_Date, End_Date, Freq)
    assert (result==1/Decimal(365))
    interest=dcc.interest(Principal, Rate, Start_Date, As_of_Date, End_Date, Freq)

# Generated at 2022-06-21 20:15:18.520401
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007,12,28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007,12,28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007,10,31), datetime.date(2008,11,30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert (round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667'))

# Generated at 2022-06-21 20:15:27.512566
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCCRegistry.get_dcc("AFB").calculate_daily_fraction(
        datetime.date(2014, 4, 1),
        datetime.date(2014, 4, 1),
        datetime.date(2014, 4, 2),
        2
    ) == Decimal("0")
    assert DCCRegistry.get_dcc("AFB").calculate_daily_fraction(
        datetime.date(2014, 4, 1),
        datetime.date(2014, 4, 2),
        datetime.date(2014, 4, 2),
        2
    ) == Decimal("1")

# Generated at 2022-06-21 20:15:34.857770
# Unit test for constructor of class DCC
def test_DCC():
    from .currencies import CURRENCIES

# Generated at 2022-06-21 20:16:17.154282
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert dcfc_act_365_l(datetime.date(2008, 2, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16939890710383')
    assert dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16939890710383')
    assert dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.17213114754098')

# Generated at 2022-06-21 20:16:28.181460
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert (dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28))) == Decimal('0.16666666666667')
    assert (dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29))) == Decimal('0.16944444444444')
    assert (dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30))) == Decimal('1.08333333333333')

# Generated at 2022-06-21 20:16:37.216162
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Testing now...
    """
    ## Initialize the line counter:
    counter = 1

    ## Open the test file and read only the first line (header):
    with open("./dcfc_30_360_german_test.csv", "r") as f:
        header = f.readline().strip().split(",")

    ## Open the test file and read the lines (expected results):
    with open("./dcfc_30_360_german_test.csv", "r") as f:
        for line in f:
            if counter == 1:
                counter += 1
                continue

            ## Extract the expected result from the line:
            line = line.strip().split(",")
            expected_result = Decimal(line[-1])

            ## Extract the start and end dates from the line:


# Generated at 2022-06-21 20:16:41.469009
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2014, 2, 28), datetime.date(2014, 4, 30), datetime.date(2014, 4, 30)), 14) == Decimal('0.08333333333333')
    assert round(dcfc_30_360_isda(datetime.date(2014, 2, 28), datetime.date(2014, 4, 30), datetime.date(2014, 4, 30)), 14) == Decimal('0.08333333333333')
    assert round(dcfc_30_360_isda(datetime.date(2014, 2, 28), datetime.date(2014, 4, 30), datetime.date(2014, 4, 30)), 14) == Decimal('0.08333333333333')

# Generated at 2022-06-21 20:16:52.756142
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == \
        Decimal('0.16666666666667')

# Generated at 2022-06-21 20:17:04.854068
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """Unit test for function dcfc_30_360_us."""
    ex01_sd = datetime.date(2006, 12, 15)
    ex01_ed = datetime.date(2007, 3, 15)
    ex01_dcf = dcfc_30_360_us(ex01_sd, ex01_ed, ex01_ed)
    assert round(ex01_dcf, 14) == Decimal('0.25')

    ex02_sd = datetime.date(2006, 12, 30)
    ex02_ed = datetime.date(2007, 3, 31)
    ex02_dcf = dcfc_30_360_us(ex02_sd, ex02_ed, ex02_ed)
    assert round(ex02_dcf, 14) == Decimal('0.25')

   

# Generated at 2022-06-21 20:17:11.195367
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal('1.10000000000000')


# Generated at 2022-06-21 20:17:19.704777
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert dcc is not None
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')

DCCRegistry = DCCRegistryMach

# Generated at 2022-06-21 20:17:30.559924
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    result = round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-21 20:17:34.232716
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    # 1: Attempts to find the day count convention by the given name.
    # Arrange
    # Act
    dcc = DCCRegistry.find("Act/Act")
    # Assert
    assert dcc == DCCActAct()



# Generated at 2022-06-21 20:20:12.209944
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Test function for coupon of class DCC
    """
    a=DCC('DCC',{'DCC2'},{Currencies['CAD']},lambda start,asof,end,freq: ZERO)
    b=Money(5,"CAD")
    c=Decimal(9)
    d=datetime.date(2014,  1,  1)
    e=datetime.date(2015, 12, 31)
    f=datetime.date(2015,  1,  1)
    g=1
    h=None
    i=a.coupon(b,c,d,e,f,g,h)
    assert i.amount==Decimal(45)
    assert i.ccy==Currencies['CAD']



# Generated at 2022-06-21 20:20:18.487430
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.17222222222222')

# Generated at 2022-06-21 20:20:25.211355
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    """
    Test function dcfc_act_365_a
    """
    ## Get the example dates:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    ## Create the expected results:
    ex1_res = Decimal('0.16986301369863')
    ex2_

# Generated at 2022-06-21 20:20:34.949457
# Unit test for constructor of class DCC
def test_DCC():
    dcc_1 = DCC("test_dcc", {"test_dcc"}, {Currencies.USD}, lambda start, asof, end, freq: Decimal(1))
    dcc_2 = DCC("dcc_name", {"dcc_name"}, {Currencies.USD}, lambda start, asof, end, freq: Decimal(1))
    assert dcc_1 != dcc_2
    assert dcc_1.name == "test_dcc"
    assert dcc_1.altnames == {"test_dcc"}
    assert dcc_1.currencies == {Currencies.USD}
    assert dcc_1.calculate_fraction_method(Date.today(), Date.today(), Date.today(), 1) == Decimal(1)



# Generated at 2022-06-21 20:20:39.962109
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-21 20:20:50.627945
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:21:01.707834
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    # pylint: disable=missing-function-docstring
    
    # Test 1 (example from the function's docstring)
    # Start date: 2 March 2019
    # As-of date: 10 September 2019
    # End date: 2 March 2020
    # Expected result: 0.5245901639
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')
    
    # Test 2 
    # Start date: 1 August 2019
    # As-of date

# Generated at 2022-06-21 20:21:08.592085
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    q = dcfc_act_365_l(start=datetime.date(2018, 11, 15), asof=datetime.date(2018, 12, 18), end=datetime.date(2019, 1, 15), freq=Decimal('2'))
    assert(q == Decimal('0.31780821917808'))



# Generated at 2022-06-21 20:21:15.392612
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-21 20:21:24.460058
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_f(start=ex4_start, asof=ex4_asof, end=ex4_asof), 14) == Decimal('1.32876712328767')
test_dcfc_act_365_f()

