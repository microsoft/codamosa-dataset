

# Generated at 2022-06-21 20:12:02.389860
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    import doctest
    doctest.run_docstring_examples(dcfc_act_act, globals(), verbose=True)



# Generated at 2022-06-21 20:12:07.385463
# Unit test for constructor of class DCC
def test_DCC():
    dcc=DCC('act','alt',{'USD','GBP'},_act)
    assert dcc.name=='act'
    assert dcc.currencies=={'USD','GBP'}
    assert dcc.calculate_fraction_method==_act
    
    

# Generated at 2022-06-21 20:12:13.371771
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16942884946478')



# Generated at 2022-06-21 20:12:20.655481
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    """
    Test dcfc_act_365_f function.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)


# Generated at 2022-06-21 20:12:30.133026
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    registry = DCCRegistryMachinery()
    dcc = DCC(
        name="Act/Act",
        altnames={},
        currencies={Currencies["EUR"]},
        calculate_fraction_method=dcc_act_act_isda,
    )
    try:
        registry.register(dcc)
    except:
        pass

    try:
        return len(registry.registry) == 1 and registry.find("Act/Act") is not None
    except:
        raise AssertionError("test_DCCRegistryMachinery_register failed")



# Generated at 2022-06-21 20:12:37.756431
# Unit test for method interest of class DCC
def test_DCC_interest():
    v1=DCC(name='1',altnames={},currencies={},calculate_fraction_method=calculate_fraction_method)
    v1.interest(principal=Money('100','USD'),rate=Decimal('5'),start=Date('2019-01-01'),asof=Date('2019-01-02'),end=None,freq=None)


# Generated at 2022-06-21 20:12:50.038976
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from unittest import TestCase

    class _TestDCC(TestCase):
        class _TestModel(NamedTuple):
            name: str
            altnames: Set[str]
            currencies: Set[Currency]
            calculate_fraction_method: DCFC

        def setUp(self):
            self.start = datetime.date(2018, 1, 1)
            self.end = datetime.date(2019, 1, 1)

            self.dcc = DCC._TestModel(
                "TEST",
                altnames=set(),
                currencies=set(),
                calculate_fraction_method=lambda start: start,
            )


# Generated at 2022-06-21 20:12:56.419795
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal("0.16942884946478")



# Generated at 2022-06-21 20:13:04.428225
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    x = DCCRegistryMachinery()
    dcc= DCC("Actual/365", {}, {}, lambda s, a, e, f: a - s)
    x.register(dcc)
    assert x._buffer_main == {'Actual/365': dcc}
    assert x._buffer_altn == {}
    dcc2 = DCC("Actual/365", {'Actual/365F', 'Actual/365 (fixed)'}, {"DE"}, lambda s, a, e, f: a - s)
    assert_raises(TypeError, x.register, dcc2)


# Generated at 2022-06-21 20:13:12.306967
# Unit test for constructor of class DCC
def test_DCC():
    from .currencies import Currencies
    from .monetary import Money
    from .contrib.constants import dcc_act_360, dcc_act_36525
    assert dcc_act_360 is not None
    assert dcc_act_36525 is not None
    assert dcc_act_360.name == 'ACT_360'
    assert dcc_act_36525.name == 'ACT_36525'
    assert dcc_act_360.currencies == {Currencies.USD}
    assert dcc_act_36525.currencies == {Currencies.EUR}

# Generated at 2022-06-21 20:13:37.720646
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    """
    Please notice that the first round in this function is not necessary.
    """
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17260273972603')
    assert round(dcfc_act_365_f(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-21 20:13:48.765883
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-21 20:13:55.835005
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    
    # Define parameters
    # principal of money
    p = Money(0, 'CAD')
    # rate of interest
    r = Decimal(0.1)
    # start date
    sd = datetime.date(2020, 1, 1)
    # as of date
    ad = datetime.date(2020, 2, 1)
    # end date
    ed = datetime.date(2020, 2, 1)
    # frequency
    f = Decimal(1)
    
    # Calculate the daily interest
    dcc = DCC("30/360","", set(), _dcc_30_360_isda)
    di = dcc.interest(p, r, sd, ad, ed, f)
    
    # Calculate the daily fraction of the interest calculation
    dt = dcc.calculate_

# Generated at 2022-06-21 20:14:06.295770
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Test for method find of class DCCRegistryMachinery
    """
    machinery = DCCRegistryMachinery()
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    machinery.register(dcc)
    assert machinery.find("Act/Act").calculate_fraction(start, end, end) == 0.16942884946478
    assert machinery.find("Act/Act").interest(principal, rate, start, end, end).qty == Decimal('1694.29')

# Generated at 2022-06-21 20:14:17.463574
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-21 20:14:24.155296
# Unit test for method interest of class DCC
def test_DCC_interest():
    import datetime
    from financepy.finutils.FinDate import FinDate
    from financepy.market.curves.FinDiscountCurve import FinDiscountCurve
    colaCal = DCC("COLA", {"COLA"}, _as_ccys({"CLP", }), colaCalFraction)
    startDate = FinDate(1, 1, 2017)
    endDate = FinDate(1, 1, 2018)
    from financepy.market.curves.FinCurveTypes import FinCurveTypes
    discountCurve = FinDiscountCurve(startDate, colaCal)
    discountCurve.buildFromZeroRatesFwdRates(startDate, 0.01, "30/360", FinCurveTypes.ZERO_RATE)
    money = Money(60000.0, "PESO")
    rate

# Generated at 2022-06-21 20:14:25.750836
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc = DCCRegistry.find("Act/Act")
    assert dcc is not None



# Generated at 2022-06-21 20:14:37.291477
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """
    Unit test for dcfc_act_act_icma.

    >>> ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    >>> round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10)
    Decimal('0.5245901639')
    """
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10),
        end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')



# Generated at 2022-06-21 20:14:49.478716
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dcc = DCC(name="Act/Act", altnames={"Act-Act", "Act_Act", "ActAct"}, currencies={Currencies["USD"]}, calculate_fraction_method=dcf_act_act)
    DCCRegistry.register(dcc)
    assert DCCRegistry.registry == [dcc]
    assert DCCRegistry.table == {'Act/Act': dcc, 'Act-Act': dcc, 'Act_Act': dcc, 'ActAct': dcc}
    assert DCCRegistry.find('Act/Act.ICMA') == None
    assert DCCRegistry.find('Act/Act') == dcc
    assert DCCRegistry.find('Act-Act') == dcc
    assert DCCRegistry.find('Act_Act') == dcc

# Generated at 2022-06-21 20:15:01.455507
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act(datetime.date(2000, 1, 1), datetime.date(2000, 2, 1), datetime.date(2000, 2, 1)) == Decimal(1) / Decimal(366)
    assert dcfc_act_act(datetime.date(2000, 2, 1), datetime.date(2000, 2, 1), datetime.date(2000, 2, 1)) == Decimal(0)
    assert dcfc_act_act(datetime.date(2000, 3, 1), datetime.date(2000, 3, 1), datetime.date(2000, 3, 1)) == Decimal(1) / Decimal(366)

# Generated at 2022-06-21 20:16:09.951765
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    try:
        dcc = DCC("Act/Act", {}, {}, lambda start, asof, end, freq: ZERO)
        DCCRegistry.register(dcc)
    except TypeError as e:
        assert str(e) == "Day count convention 'Act/Act' is already registered"



# Generated at 2022-06-21 20:16:12.904684
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    conv_id_loc = dcc.DCCRegistry.find("US30/360")
    assert conv_id_loc.name == "US30/360"
# Class based unit test for class DCCRegistryMachinery

# Generated at 2022-06-21 20:16:25.350137
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dccReg=DCCRegistryMachinery()

# Generated at 2022-06-21 20:16:35.181915
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Test for dcfc_30_360_us (1 of 8):
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    # Test for dcfc_30_360_us (2 of 8):
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-21 20:16:46.067534
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    print(DCC(
        name="Test",
        altnames={},
        currencies=set(),
        calculate_fraction_method=lambda s, a, e, f: ONE
    ).coupon(Money(1, 'CHF'), Decimal(2), Date(2010, 1, 1), Date(2010, 1, 1), Date(2010, 1, 1), 1, 1,))
    print(DCC(
        name="Test",
        altnames={},
        currencies=set(),
        calculate_fraction_method=lambda s, a, e, f: ONE
    ).coupon(Money(1, 'CHF'), Decimal(2), Date(2010, 1, 1), Date(2010, 1, 1), Date(2010, 1, 1), 1, 1))

# Generated at 2022-06-21 20:16:56.809344
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """
    Test function dcfc_30_360_isda. Note that we also use the dcfc_30_360_isda
    function to test the dcc decorator.
    """

# Generated at 2022-06-21 20:17:08.885147
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCCs.ACT_365F.interest(Money("1.00", "USD"), ZERO, Date("2017-01-01"), Date("2018-01-01"), Date("2018-01-01")) == Money("0.00", "USD")
    assert DCCs.ACT_360.interest(Money("1.00", "USD"), ZERO, Date("2017-01-01"), Date("2018-01-01"), Date("2018-01-01")) == Money("0.00", "USD")
    assert DCCs.ACT_365L.interest(Money("1.00", "USD"), ZERO, Date("2017-12-31"), Date("2018-12-31"), Date("2018-12-31")) == Money("0.00", "USD")

# Generated at 2022-06-21 20:17:15.655858
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2016, 2, 29), asof=datetime.date(2016, 2, 29), end=datetime.date(2016, 2, 29)), 14) == round(Decimal(366) / Decimal(366), 14)
    assert round(dcfc_act_365_l(start=datetime.date(2016, 2, 29), asof=datetime.date(2017, 3, 1), end=datetime.date(2017, 3, 1)), 14) == round(Decimal(1) / Decimal(366), 14)

# Generated at 2022-06-21 20:17:26.683044
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    with pytest.raises(AssertionError):
        dcfc_act_act(datetime.date(2007,12,28), datetime.date(2008,2,28), datetime.date(2007,2,27), 12)
    with pytest.raises(AssertionError):
        dcfc_act_act(datetime.date(2007,12,28), datetime.date(2008,2,28), datetime.date(2008,2,28), -12)
    with pytest.raises(AssertionError):
        dcfc_act_act(datetime.date(2007,12,28), datetime.date(2008,2,28), datetime.date(2008,2,28), 'freq')

# Generated at 2022-06-21 20:17:36.816678
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), 
                               asof=datetime.date(2008, 2, 28), 
                               end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), 
                               asof=datetime.date(2008, 2, 29), 
                               end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')