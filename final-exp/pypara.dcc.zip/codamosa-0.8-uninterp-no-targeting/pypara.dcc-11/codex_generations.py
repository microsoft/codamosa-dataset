

# Generated at 2022-06-21 20:12:23.673360
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    DCC_instance = DCC('name','altnames','currencies','calculate_fraction_method')
    assert DCC_instance.calculate_fraction(datetime.date(2016,12,31),datetime.date(2016,12,31),datetime.date(2016,12,31),0) == 0
    assert DCC_instance.calculate_fraction(datetime.date(2016,12,31),datetime.date(2016,12,31),datetime.date(2016,12,31),None) == 0
    assert DCC_instance.calculate_fraction(datetime.date(2016,12,31),datetime.date(2016,12,31),datetime.date(2016,12,31),2) == 0

# Generated at 2022-06-21 20:12:34.375236
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from .currencies import CURRENCIES as CUR
    from .currencies import Currencies as CCY
    from .monetary import Money, RATE_FACTOR
    from .types import DCC_ACT_ACT_ISDA, DCC_ACT_ACT_ICMA
    assert DCC_ACT_ACT_ISDA.coupon(Money(CCY.USD, RATE_FACTOR * 100), RATE_FACTOR, datetime.date(2017, 1, 2), datetime.date(2017, 2, 1), datetime.date(2017, 3, 1), 2, None) == Money(CUR.USD, RATE_FACTOR * 0.0652750743)

# Generated at 2022-06-21 20:12:43.454002
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:12:49.653657
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Test function dcfc_30_360_german for unit test
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:12:59.805585
# Unit test for constructor of class DCCRegistryMachinery

# Generated at 2022-06-21 20:13:04.102913
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCs.get("ACT/360").coupon(Money(10000000, 'USD'), 0.0023, datetime.date(2011, 11, 1), datetime.date(2012, 1, 1), datetime.date(2012, 2, 1), 2) == Money(330.55555555555554, 'USD')

# Generated at 2022-06-21 20:13:11.333001
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .monetary import Money
    from .currencies import Currency
    from .currencies.units import HUNDRED
    import datetime
    assert (DCCRegistry['ACT/365F'].interest(Money(100, Currency.EUR), Decimal(0.05), datetime.date(2015, 1, 1), datetime.date(2015, 1, 10))) == Money(1.3698630136986301369863014, Currency.EUR)



# Generated at 2022-06-21 20:13:23.543981
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    for ex in [(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)),
               (datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)),
               (datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)),
               (datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)),
               (datetime.date(2008, 12, 31), datetime.date(2009, 2, 28)),
               (datetime.date(2008, 12, 31), datetime.date(2009, 3, 30))]:
        assert round(dcfc_30_360_german(*ex, *ex), 14) == round(dcfc_30_e_360(*ex, *ex), 14)



# Generated at 2022-06-21 20:13:31.258115
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    start = Date(2000,4,4)
    asof = Date(2001,4,4)
    end = Date(2002,4,4)
    freq = Decimal(12)
    
    actfact, actdailyfract = DCCRegistry["30/360"].__getitem__(3)(start, asof, end, freq), DCCRegistry["30/360"].calculate_daily_fraction(start, asof, end, freq)
    #print(actfact)
    #print(actdailyfract)
    assert actfact == actdailyfract, "Calculated daily fraction is wrong!"

# Generated at 2022-06-21 20:13:39.699508
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .monetary import Money
    from .currencies import Currencies

    principal = Money(1000, Currencies.USD)
    rate = Decimal(0.06)
    start = datetime.date(2018, 1, 1)
    asof = datetime.date(2018, 1, 4)
    end = datetime.date.today()
    freq = Decimal(1)

    assert principal.value == 1000
    assert rate == 0.06
    assert start == datetime.date(2018, 1, 1)
    assert asof == datetime.date(2018, 1, 4)
    assert end == datetime.date(2018, 6, 27)
    assert freq == Decimal(1)

    assert DCC.ACT360.calculate_daily_fraction(start, asof, end, freq) == Decimal

# Generated at 2022-06-21 20:14:15.689820
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCCs["act/360"].interest(Money(10000, Currencies["USD"]), Decimal("0.1"), datetime.date(2005, 2, 10), datetime.date(2005, 2, 20)) == Money(55.55, Currencies["USD"])
    assert DCCs["act/365"].interest(Money(10000, Currencies["USD"]), Decimal("0.1"), datetime.date(2005, 2, 10), datetime.date(2005, 2, 20)) == Money(54.78, Currencies["USD"])
    assert DCCs["act/act"].interest(Money(10000, Currencies["USD"]), Decimal("0.1"), datetime.date(2005, 2, 10), datetime.date(2005, 2, 20)) == Money(54.78, Currencies["USD"])
   

# Generated at 2022-06-21 20:14:22.915319
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # Imports
    from pyexlatex.presentation.beamer.frames.frametitle import FrameTitle
    from pyexlatex.presentation.beamer.sections.frame import Frame
    from pyexlatex.presentation.beamer.sections.section import Section

    # Define DCC to attempt to add
    dcc_to_add = DCC(
        name = 'Act/Act ICMA',
        altnames = {'Actual/Actual Actual ICMA', 'Actual/Actual ISDA', 'Actual/Actual ISMA', 'ISMA', 'ACT/ACT'},
        currencies = {},
        calculate_fraction_method = lambda start, asof, end, freq: ZERO
    )

    # Try registering with name that already exists
    dcc_reg = DCCRegistryMachinery()
   

# Generated at 2022-06-21 20:14:32.020108
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = asof = Date(2014, 1, 1)
    end = Date(2014, 1, 2)
    dc = DCCRegistry['act/365']

    assert dc.calculate_fraction(start, asof, end) == 1

    start = asof = Date(2014, 1, 1)
    end = Date(2014, 12, 31)
    dc = DCCRegistry['act/365']

    assert dc.calculate_fraction(start, asof, end) == 364 / 365

    start = asof = Date(2014, 1, 1)
    end = Date(2015, 12, 31)
    dc = DCCRegistry['act/365']

    assert dc.calculate_fraction(start, asof, end) == (365 + 364) / 365


# Generated at 2022-06-21 20:14:41.087606
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    import unittest

    DCC1 = DCC("DCC1", {}, {}, lambda x,y,z,w: ONE)
    DCC2 = DCC("DCC2", {}, {}, lambda x,y,z,w: ONE)
    DCC3 = DCC("DCC3", {}, {}, lambda x,y,z,w: ONE)

    class TestDCC(unittest.TestCase):
        @classmethod
        def setUpClass(cls) -> None:
            cls.dcc_map = {
                "DCC1": DCC1,
                "DCC2": DCC2,
                "DCC3": DCC3,
            }


# Generated at 2022-06-21 20:14:53.312867
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal("0.16986301369863")
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal("0.16986301369863")

# Generated at 2022-06-21 20:15:03.801424
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Unit test for function dcfc_30_360_us
    """
    ## Example dates and dates as of them:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    ## Compute all four DCFs:

# Generated at 2022-06-21 20:15:06.855489
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert test_dcfc_act_365_a


# Generated at 2022-06-21 20:15:12.330888
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), freq=Decimal(2)), 14)\
        == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), freq=Decimal(2)), 14)\
        == Decimal('0.16944444444444')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), freq=Decimal(2)), 14)\
        == Decimal('1.08333333333333')

# Generated at 2022-06-21 20:15:16.365822
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCCRegistry["30360"].calculate_daily_fraction(datetime.date(2018, 1, 2), datetime.date(2018, 1, 3), datetime.date(2018, 1, 3)) == Decimal("0.0002777777777777778")



# Generated at 2022-06-21 20:15:26.843991
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .market import DiscountCurve
    from .time import Date
    import datetime

    from .currencies import CNY
    from .monetary import Money

    dcc = DCCRegistry.get("ACT/360")
    curve = DiscountCurve.from_flat_zero_rates(CNY, Date(2000, 1, 1), 0.065, "CONTINUOUS", "ACT/365 FIXED")
    start = Date(2000, 1, 1)
    asof = Date(2000, 3, 3)
    end = Date(2000, 9, 9)
    pricipal = Money("CNY", 1000000)
    rate = Decimal(-0.065)
    freq = 4
    # print(dcc.interest(pricipal, rate, start, asof, end, freq))

# Generated at 2022-06-21 20:15:52.585126
# Unit test for constructor of class DCC
def test_DCC():
    dcc = DCC(
        name="30/360",
        altnames={"30360"},
        currencies=_as_ccys({"EUR", "USD", "TRY", "JPY", "GBP"}),
        calculate_fraction_method=_thirty_three_sixty,
    )

    assert dcc.name == "30/360"
    assert dcc.altnames == {"30360"}
    assert dcc.currencies == _as_ccys({"EUR", "USD", "TRY", "JPY", "GBP"})
    assert dcc.calculate_fraction_method == _thirty_three_sixty


# Generated at 2022-06-21 20:15:58.125174
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    d1 = datetime.date(2020,10,31)
    d2 = datetime.date(2020,11,30)
    d1_2 = datetime.date(2020,11,30)
    d3 = datetime.date(2020,12,31)
    d3_2 = datetime.date(2021,1,1)
    d4 = datetime.date(2021,1,31)
    d4_2 = datetime.date(2021,2,1)
    d5 = datetime.date(2021,2,28)
    d5_2 = datetime.date(2021,3,1)
    d6 = datetime.date(2021,2,29)
    d6_2 = datetime.date(2021,3,1)
    d7 = datetime

# Generated at 2022-06-21 20:16:02.197067
# Unit test for function dcc
def test_dcc():
    ## Check.
    import doctest
    from fxpt.functions.dcc.base import dcc
    doctest.testmod(dcc)


# Generated at 2022-06-21 20:16:07.912140
# Unit test for method interest of class DCC
def test_DCC_interest():
    start = datetime.date(2020,1,1)
    end = datetime.date(2020,4,1)
    test_interest = DCCRegistry['ACTACTICMA'].interest(Money('100', 'USD'), Decimal(2), start, end)
    assert test_interest.amount==Decimal('62')
    assert test_interest.currency=='USD'



# Generated at 2022-06-21 20:16:14.930548
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    """
    Unit tests for DCCRegistryMachinery().
    """
    ## Make a registry:
    registry = DCCRegistryMachinery()

    ## Register a DCC:
    registry.register(DCC("ACT/ACT", {}, {}, lambda s, aso, e, f: ONE))

    try:
        ## Register another DCC:
        registry.register(DCC("ACT/ACT", {}, {}, lambda s, aso, e, f: ONE))
        raise AssertionError("Should never reach here.")
    except TypeError:
        pass

    ## Now get it again, it should be there:
    assert registry.find("ACT/ACT")



# Generated at 2022-06-21 20:16:26.812893
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(start=datetime.date(2020, 1, 1), asof=datetime.date(2020, 1, 31), end=datetime.date(2020, 1, 31)) == 1 / 12
    assert dcfc_30_e_360(start=datetime.date(2020, 1, 31), asof=datetime.date(2020, 2, 29), end=datetime.date(2020, 2, 29)) == 1 / 12
    assert dcfc_30_e_360(start=datetime.date(2020, 1, 31), asof=datetime.date(2020, 2, 29), end=datetime.date(2020, 2, 29)) == 1 / 12

# Generated at 2022-06-21 20:16:33.298137
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal(0.16986301369863)
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal(0.16986301369863)
    assert round(dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal(1.08219178082192)

# Generated at 2022-06-21 20:16:40.060714
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-21 20:16:52.091832
# Unit test for function dcc
def test_dcc():
    # Define the day count fraction calculation function:
    @dcc("Test", {"Alt"}, {"USD"})
    def dcfc(start, asof, end, freq):
        return ZERO

    # Check the availability of the dcc instance:
    assert hasattr(dcfc, "__dcc")

    # Check if the dcc instance is properly registered:
    dcc = DCCRegistry.find("Test")
    assert dcc.name == "Test"
    assert dcc.altnames == {"Alt"}
    assert dcc.currencies == {"USD"}

    # Check if the alternative names are also properly registered:
    dcc = DCCRegistry.find("Alt")
    assert dcc.name == "Test"
    assert dcc.altnames == {"Alt"}
    assert dcc.currencies == {"USD"}

# Generated at 2022-06-21 20:16:59.660606
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)),14) == round(Decimal('0.16939890710383'),14)
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)),14) == round(Decimal('0.17213114754098'),14)

# Generated at 2022-06-21 20:18:07.730061
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """

# Generated at 2022-06-21 20:18:14.468487
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17260273972603')
    assert round(dcfc_act_365_f(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08493150684932')

# Generated at 2022-06-21 20:18:25.350970
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    def assert_coupon(curve_name, start, asof, freq, eom, start_balance, expected_interest):
        curve = curves.curves[curve_name]
        interest = curve.coupon(Money("100.00", currency), 0.05, start, asof, freq=freq, eom=eom)
        assert expected_interest == interest.value, f"\n      Curve: {curve_name}\n   Expected: {expected_interest}\n Calculated: {interest.value}"

    from tradekit.curves import curves
    from tradekit.curves.curve import Curve

    curve = Curve("TEST", "TEST", "TEST")
    curves.curves.append(curve)

    currency = Currencies["USD"]


# Generated at 2022-06-21 20:18:34.502973
# Unit test for method interest of class DCC
def test_DCC_interest():
    # Set Up
    principal = Money(1, "USD")
    rate = 0.5
    start = Date(2018, 1, 1)
    asof = Date(2018, 1, 2)
    end = Date(2018, 1, 2)
    freq = 1
    DCC_temp = DCC("", "", "", "")
    # Run Test
    return1 = DCC_temp.interest(principal, rate, start, asof, end, freq)
    # Get Result
    assert return1.currency == "USD"
    assert return1.amount == 0.5


# Generated at 2022-06-21 20:18:45.774280
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    print(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)))
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
   

# Generated at 2022-06-21 20:18:51.913756
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)), 14) == Decimal('0.172222222222')
    assert round(dcfc_act_360(datetime.date(2007, 10, 31),datetime.date(2008, 2, 28),datetime.date(2008, 11, 30)), 14) == Decimal('0.9361111111111')



# Generated at 2022-06-21 20:18:56.110714
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-21 20:19:06.527144
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-21 20:19:12.240708
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ### Test case 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_st, ex1_as = dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof)
    assert round(ex1_st, 14) == round(Decimal('0.16666666666667'), 14)
    assert round(ex1_as, 14) == round(Decimal('0.16666666666667'), 14)
    ### Test case 2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex2_st, ex2_as = dcfc_

# Generated at 2022-06-21 20:19:14.957698
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCC(name = "name", altnames = {}, currencies = {}, calculate_fraction_method = lambda s, a, e, f: ZERO).calculate_fraction(start=Date.today(), asof=Date.today(), end=Date.today(), freq=None)==ZERO