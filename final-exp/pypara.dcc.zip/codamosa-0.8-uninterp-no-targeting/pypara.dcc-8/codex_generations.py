

# Generated at 2022-06-21 20:12:25.710177
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-21 20:12:38.199204
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-21 20:12:46.006786
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    import datetime
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-21 20:12:51.581535
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-21 20:13:01.081455
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:13:09.828244
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal('1.10000000000000')


# Generated at 2022-06-21 20:13:21.355093
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .currencies import Currency, Currencies
    from .monetary import Money
    from .time import Date
    from .time.counting import DCC
    from .time.counting import DCCRegistry

    principal = Money(100000, currency=Currencies['EUR'])
    rate = Decimal('0.01')
    start = Date(2018, 11, 1)
    asof = Date(2019, 1, 1)
    end = asof
    freq = None

    convention = DCCRegistry['ACT/360']
    result = convention.interest(principal, rate, start, asof, end, freq)
    assert result == principal * rate * convention.calculate_fraction(start, asof, end, freq)


# Generated at 2022-06-21 20:13:31.294959
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-21 20:13:39.699745
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-21 20:13:47.214774
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-21 20:14:34.899507
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(round(dcfc_act_360(start=ex4_start, asof=ex4_asof, end=ex4_asof), 14))


# Generated at 2022-06-21 20:14:37.046643
# Unit test for function dcc
def test_dcc():
    @dcc("Test")
    def test_dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal: return None

    assert DCCRegistry.find("Test")



# Generated at 2022-06-21 20:14:43.501464
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Tests  :meth:`DCC.calculate_daily_fraction` method of class :class:`DCC`.
    """
    print("Testing DCC.calculate_daily_fraction(...)")

    # We will use the 30/360 convention for testing:
    test_dcc = DCCRegistry["ACT/360"]

    # Method calculate_daily_fraction must return 1/360:
    assert test_dcc.calculate_daily_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 15)) == Decimal("0.002777777777777778")



# Generated at 2022-06-21 20:14:49.659027
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal('1.10000000000000')


# Generated at 2022-06-21 20:14:57.055906
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(
        start=datetime.date(2019, 3, 2),
        asof=datetime.date(2019, 9, 10),
        end=datetime.date(2020, 3, 2)
    ), 10) == Decimal('0.5245901639')
test_dcfc_act_act_icma()


# Generated at 2022-06-21 20:15:05.491191
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
test_dcfc_act_act_icma()

DCCRegistry.register(DCC("Act/360", {"Actual/360", "Act/360 (BMA)", "Act/360 (ISDA)"}, set(), dcfc_act_360))
DCCRegistry.register(DCC("Act/30", {"Actual/30", "Act/30E", "Act/30E (ISDA)", "Act/30E (BMA)"}, set(), dcfc_act_360))

# Generated at 2022-06-21 20:15:11.148905
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-21 20:15:14.902959
# Unit test for constructor of class DCC
def test_DCC():
    DCC(
        name="ACT/ACT",
        altnames=set(["ACT/ACT","ACT/360"]),
        currencies=_as_ccys({'USD', 'EUR'}),
        calculate_fraction_method=dcc_act_act,
    )


# Generated at 2022-06-21 20:15:20.592219
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-21 20:15:28.730215
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    start1 = datetime.datetime(2018, 5, 15)
    asof1 = datetime.datetime(2018, 7, 15)
    end1 = datetime.datetime(2018, 10, 15)
    assert round(float(dcfc_act_365_l(start1, asof1, end1)), 13) == 0.323045267489712
    
    start2 = datetime.datetime(2018, 5, 15)
    asof2 = datetime.datetime(2018, 11, 15)
    end2 = datetime.datetime(2019, 6, 15)
    assert round(float(dcfc_act_365_l(start2, asof2, end2)), 12) == 1.03767123287671
    

# Generated at 2022-06-21 20:20:12.418606
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert dcfc_nl_365(datetime.date(2008, 2, 29), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == 0.169863013698630136986301369863013698630136986301369863013698630136986301369863013698630136986301369863013698630136986301369863013698630136986301369863013698630136986301369863013698630136986301369863013698630136986301369863013698630136986301369863013698630136986301369863013698630136986301369863013698630136

# Generated at 2022-06-21 20:20:23.703298
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(datetime.date(2016,8,23),datetime.date(2017,8,23),datetime.date(2017,8,23)),4) == Decimal('1.0')
    assert round(dcfc_act_365_f(datetime.date(2016,8,23),datetime.date(2017,8,22),datetime.date(2017,8,23)),4) == Decimal('0.9973')
    assert round(dcfc_act_365_f(datetime.date(2016,8,23),datetime.date(2016,12,7),datetime.date(2017,8,23)),4) == Decimal('0.6492')


# Generated at 2022-06-21 20:20:29.875617
# Unit test for method interest of class DCC
def test_DCC_interest():
    from math import isclose
    from .currencies import Currency
    from .monetary import Money
    from .money import UOM
    from .time import Date
    from .time.dcc import DCCRegistry, DCC
    from pyfinance.time.dcc import _FlatDCC
    dcc: DCC = DCCRegistry["Actual/Actual ICMA"]
    money: Money = Money(10, Currency.USD)
    result: Money = money * 0.5 * (Date(1997, 4, 30) - Date(1997, 1, 1)) / (Date(1998, 1, 1) - Date(1997, 1, 1))
    assert (result.amount == 5), "interest() should return 5 for 10 * 0.5 * (30/4-1/1)/(1/1/1998-1/1/1997)"

# Generated at 2022-06-21 20:20:40.299221
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-21 20:20:51.254566
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """
    """
    import pandas as pd
    import datetime
    """ Test all the examples defined in the unit tests. """
    def true_fraction(start, asof, end):
        """ Return the true fraction value. """
        from decimal import Decimal
        return Decimal((asof - start).days) / Decimal((end - start).days)


# Generated at 2022-06-21 20:20:57.415162
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert abs(float(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))) - 0.16666666666667) < 0.01
    assert abs(float(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29))) - 0.16944444444444) < 0.01
    assert abs(float(dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30))) - 1.08333333333333) < 0.01

# Generated at 2022-06-21 20:21:06.687211
# Unit test for method interest of class DCC
def test_DCC_interest():
    dcc = DCC("aaaa", set(["bbbb", "cccc"]), {"dddd"})
    try:
        dcc.interest("xxx", 1, start, asof, end, 2)
        assert False
    except TypeError as e:
        assert True

    try:
        dcc.interest("xxx", 1, start, asof, end, "2")
        assert False
    except TypeError as e:
        assert True

    try:
        dcc.interest(Money(currency="xxx", value=1), 1, start, asof, end, 2)
        assert False
    except TypeError as e:
        assert True


# Generated at 2022-06-21 20:21:14.303121
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(datetime.date(1997,4,4),datetime.date(1997,10,1),datetime.date(1997,10,1)), 14) == Decimal('0.3416666667')
    assert round(dcfc_act_360(datetime.date(1996,12,30),datetime.date(1997,12,30),datetime.date(1997,12,30)), 14) == Decimal('1')
    assert round(dcfc_act_360(datetime.date(1997,2,27),datetime.date(1997,5,30),datetime.date(1997,5,30)), 14) == Decimal('0.2638888889')

# Generated at 2022-06-21 20:21:25.738009
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .commons.enums import CurrencyCodes
    from .monetary import MoneyFactory
    start = datetime.date(2010, 1, 1)
    asof = datetime.date(2016, 3, 31)
    end = datetime.date(2016, 6, 30)
    currency = CurrencyCodes.USD
    principal = MoneyFactory.create(10000000, currency)
    rate = Decimal(0.0625)
    freq = Decimal(2)
    eom = 30
    ai_all = DCC["ACT/ACT"].interest(principal, rate, start, asof, end, freq)
    ai_prev = DCC["ACT/ACT"].interest(principal, rate, start, asof, None, freq)

# Generated at 2022-06-21 20:21:34.620801
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008, 11, 30)), 14) == Decimal('1.08219178082192')