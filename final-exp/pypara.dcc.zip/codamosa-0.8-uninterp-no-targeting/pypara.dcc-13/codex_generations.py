

# Generated at 2022-06-21 20:12:41.878304
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Tests the dcfc_act_act function.
    """
    assert(round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478'))
    assert(round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194'))

# Generated at 2022-06-21 20:12:48.948007
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    #start: Date, asof: Date, end: Date, freq: Optional[Decimal]):
    start = datetime.date(2014,1,1)
    asof = datetime.date(2014,1,15)
    end = datetime.date(2014,1,20)
    freq = None
    #ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    #ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    #ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    #ex4_start, ex4_asof = dat

# Generated at 2022-06-21 20:12:53.992993
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    import unittest
    class TestDcfc30E360(unittest.TestCase):
        def test_dcfc_30_e_360(self):
            ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
            ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
            ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
            ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:13:01.946435
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert(DCCRegistry.find("Act/Act"))
    assert(DCCRegistry.find("Act/Act").name == "Act/Act")
    assert(DCCRegistry.find("ACT/ACT"))
    assert(DCCRegistry.find("ACT/ACT").name == "Act/Act")
    assert(DCCRegistry.find("Act/Act (ISDA)").name == "Act/Act (ISDA)")
    assert(DCCRegistry.find("Actual/Actual (ISDA))") == None)
    assert(DCCRegistry.find("Actual/Actual (ISDA)") == None)
    assert(DCCRegistry.find("Actual/Actual (") == None)
    assert(DCCRegistry.find("Actual/Actual") == None)

# Generated at 2022-06-21 20:13:07.185996
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """test_dcfc_act_act_icma"""
    assert dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=4) == Decimal('0.5245901639')



# Generated at 2022-06-21 20:13:18.515085
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC("foo", {"bar"}, _as_ccys(["USD"]), lambda x, y, z, e: None).coupon(Money(123, "USD"), Decimal("0.01"), datetime.date(2014,  1,  1), datetime.date(2015, 12, 31), 1, None) == Money(123, "USD")
    assert DCC("foo", {"bar"}, _as_ccys(["USD"]), lambda x, y, z, e: None).coupon(Money(123, "USD"), Decimal("0.01"), datetime.date(2015,  1,  1), datetime.date(2015, 12, 31), 1, None) == Money(123, "USD")

# Generated at 2022-06-21 20:13:30.203157
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(
        datetime.date(2020, 2, 1),
        datetime.date(2020, 2, 1),
        datetime.date(2020, 2, 1)
    ) == Decimal('1')
    assert round(dcfc_30_e_360(
        datetime.date(2020, 2, 29),
        datetime.date(2020, 2, 29),
        datetime.date(2020, 2, 29)
    ), 14) == Decimal('1.0')
    assert round(dcfc_30_e_360(
        datetime.date(2020, 2, 29),
        datetime.date(2021, 2, 28),
        datetime.date(2021, 2, 28)
    ), 14) == Decimal('1.0')

# Generated at 2022-06-21 20:13:39.091940
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)),14)== Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 28)),14)== Decimal('0.16944444444444')

# Generated at 2022-06-21 20:13:50.809444
# Unit test for function dcfc_30_360_us

# Generated at 2022-06-21 20:14:03.322790
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    # Define the class
    m = DCCRegistryMachinery()
    # Define DCCs
    DCC1 = DCC('convention1', {'name1', 'name2'}, {Currencies['USD']}, dcf_ActAct)
    DCC2 = DCC('convention2', {'name3', 'name4'}, {Currencies['USD']}, dcf_ActAct)
    DCC3 = DCC('convention3', {'name5', 'name6'}, {Currencies['USD']}, dcf_ActAct)
    # Add DCCs to the registry
    m.register(DCC1)
    m.register(DCC2)
    m.register(DCC3)

# Generated at 2022-06-21 20:15:01.576841
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert isclose(dcfc_act_act(datetime.date(2007,12,28), datetime.date(2008,2,28), datetime.date(2008,2,28)),0.16942884946478)
    assert isclose(dcfc_act_act(datetime.date(2007,12,28), datetime.date(2008,2,29), datetime.date(2008,2,29)),0.17216108990194)
    assert isclose(dcfc_act_act(datetime.date(2007,10,31), datetime.date(2008,11,30), datetime.date(2008,11,30)),1.08243131970956)

# Generated at 2022-06-21 20:15:08.002297
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Shortcut
    def t(d1, m1, y1, d2, m2, y2, res):
        d1_ = datetime.date(y1, m1, d1)
        d2_ = datetime.date(y2, m2, d2)
        return dcfc_30_360_german(d1_, d2_, None) == res

    assert t(30, 6, 2007, 31, 12, 2007, 0.5) == True
    assert t(31, 6, 2007, 30, 9, 2008, 1.25) == True
    assert t(31, 6, 2007, 31, 9, 2008, 1.25) == True
    assert t(30, 6, 2007, 30, 9, 2008, 1.0) == True

# Generated at 2022-06-21 20:15:13.209349
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-21 20:15:17.522041
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Tests method find of class DCCRegistryMachinery.
    """
    dcc = DCC('name1', set(), set(), None)
    dcc2 = DCC('name2', set(), set(), None)
    buffer_main = {'name1': dcc}
    buffer_altn = {'name2': dcc2}
    method = DCCRegistryMachinery()
    method._buffer_main = buffer_main
    method._buffer_altn = buffer_altn
    result = method.find('name1')
    assert result == dcc
    result = method.find('name2')
    assert result == dcc2

# Generated at 2022-06-21 20:15:27.209247
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-21 20:15:39.240924
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Test data
    test_data_list = [
        [datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), Decimal('0.16942884946478')],
        [datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), Decimal('0.17216108990194')],
        [datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), Decimal('1.08243131970956')],
        [datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), Decimal('1.32625945055768')]
    ]
    # Execute unit test
    for test_data in test_data_list:
        assert test_data[2] == dcf

# Generated at 2022-06-21 20:15:49.620458
# Unit test for function dcfc_30_360_isda

# Generated at 2022-06-21 20:16:00.965315
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=date(2007, 12, 28), asof=date(2008, 2, 28), end=date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=date(2007, 12, 28), asof=date(2008, 2, 29), end=date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=date(2007, 10, 31), asof=date(2008, 11, 30), end=date(2008, 11, 30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-21 20:16:10.853850
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Tests the coupon method of the DCC class.
    """

    ## Test 1
    principal_USD = Money(1000000, Currency.USD)
    rate_USD = 0.05
    start_USD = Date(2019, 7, 19)
    asof_USD = Date(2019, 7, 22)
    end_USD = Date(2019, 7, 31)
    freq_USD = 2
    eom_USD = None
    expected_USD = Money(200, Currency.USD)
    calculated_USD = DCC.CALENDAR_DAYS.coupon(
        principal_USD, rate_USD, start_USD, asof_USD, end_USD, freq_USD, eom_USD
    )
    assert expected_USD == calculated_USD

    ## Test 2

# Generated at 2022-06-21 20:16:15.834018
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc = DCCRegistry.find("Actual/Actual")
    assert dcc.name == "Act/Act"


# Generated at 2022-06-21 20:17:36.827687
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Performs unit test for function dcfc_30_e_360.
    """

# Generated at 2022-06-21 20:17:41.906403
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-21 20:17:49.714720
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,28), end=datetime.date(2008,2,28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,29), end=datetime.date(2008,2,29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007,10,31), asof=datetime.date(2008,11,30), end=datetime.date(2008,11,30)), 14) == Dec

# Generated at 2022-06-21 20:18:02.680059
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Test for coupon method of DCC
    """
    from .monetary import Money, Currencies
    principal = Money(1000000, Currencies.USD)
    rate = 0.05
    start = datetime.date(2014,1,1)
    asof = datetime.date(2014,1,13)
    end = datetime.date(2014,7,1)
    freq = Decimal(2)
    eom = None
    assert DCC.ACT_ACT_ICMA.coupon(principal, rate, start, asof, end, freq, eom) == Money(25000, Currencies.USD)
    assert DCC.ACT_360.coupon(principal, rate, start, asof, end, freq, eom) == Money(25000, Currencies.USD)

# Generated at 2022-06-21 20:18:07.609659
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-21 20:18:10.721293
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .monetary import Money, Currencies
    from .dcc import DCCRegistry

    dcc = DCCRegistry['ACT/360']

    dcc.interest(Money(100, Currencies["USD"]), 0.07, datetime.date(2018, 1, 1), datetime.date(2018, 1, 2))



# Generated at 2022-06-21 20:18:17.033864
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .monetary import Money
    from .time.periods import Period
    from .time.timelines import Timeline
    from .time.markings import Point
    from .time.conventions import BusinessDayConventions
    from .time.dateadjusters import Roll
    from .time.timeline import TimelineContext
    from .time.timeline import TimelineContextManager
    from .time.timeline import timeline
    from .time.holidays import HolidayStore
    from .markets import Market
    import datetime
    import holidays
    # holidays.US is a subclass of holidays.HolidayBase
    engine = holidays.US()
    # Test holidays.US with the same code
    # engine = holidays.HolidayBase()

    assert "US" in engine.countries and "United States" in engine.countries

    # Add holidays.US to the default HolidayStore

# Generated at 2022-06-21 20:18:21.923797
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ## Test 1:
    start, end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    actual = round(dcfc_30_360_german(start, end, end), 14)
    expected = Decimal('0.16666666666667')
    assert actual == expected, f"Expected: {expected}, Actual: {actual}"
    ## Test 2:
    start, end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    actual = round(dcfc_30_360_german(start, end, end), 14)
    expected = Decimal('0.16944444444444')
    assert actual == expected, f"Expected: {expected}, Actual: {actual}"
    ## Test 3:

# Generated at 2022-06-21 20:18:23.179935
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    from .test import test_dcfc
    test_dcfc("30/360 ISDA", dcfc_30_360_isda)

# Generated at 2022-06-21 20:18:27.322049
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    >>> test_dcfc_30_360_german()
    True
    """
    ## Ex 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_dcf = dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof)
    ex1_dcf_expected = 0.16666666666667
    if ex1_dcf == ex1_dcf_expected:
        print("Test 1 passed")
    else:
        print("Test 1 failed")
        return False

    ## Ex 2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date

# Generated at 2022-06-21 20:19:36.260891
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17260273972603')



# Generated at 2022-06-21 20:19:47.187972
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-21 20:19:57.818891
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Tests that module function `dcfc_30_360_us()` works as expected.
    """

    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    ## Ex1:

# Generated at 2022-06-21 20:20:03.488084
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    d1 = datetime.date(2019,3,2)
    d2 = datetime.date(2019,9,10)
    d3 = datetime.date(2020,3,2)
    print(dcfc_act_act_icma(start=d1, asof=d2, end=d3), "Expected:", "0.5245901639")

# Generated at 2022-06-21 20:20:11.087535
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from datetime import datetime
    start = datetime.strptime('2017-06-30', '%Y-%m-%d')
    asof = datetime.strptime('2017-09-30', '%Y-%m-%d')
    end = datetime.strptime('2018-06-30', '%Y-%m-%d')
    freq = None
    DCCRegistry['ACT/360'].calculate_fraction(start, asof, end, freq)


# Generated at 2022-06-21 20:20:23.581018
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Tests the method find of class DCCRegistryMachinery
    """
    ## Define the test data:
    testdata = [
        {"dcc": DCC("Actual", ["Act", "Actual"], set(), _actual_actual_fraction), "input": "Act", "output": "Actual"},
        {"dcc": DCC("Actual", ["Act", "Actual"], set(), _actual_actual_fraction), "input": "Actual", "output": "Actual"}
    ]
    ### Perform the tests:
    import itertools
    for k, v in itertools.groupby(testdata, lambda t: t["output"]):
        print(k)
        rm = DCCRegistryMachinery()
        for test in v:
            print(test)

# Generated at 2022-06-21 20:20:32.776403
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Unit test for method coupon of class DCC
    """
    # Imports
    from dateutil.relativedelta import relativedelta
    from datetime import date, datetime
    import sys
    import os

    # Add your own path here
    sys.path.append(os.path.abspath("path to project"))

    # Load module
    from source_code.risk.models.instruments.bond import DCC
    from source_code.commons.conversions import convert
    from source_code.commons.numbers import ZERO, ONE
    from source_code.commons.money import Money
    from source_code.currencies import Currencies, Currency
    from source_code.monetary import Money

    from source_code.risk.models.instruments.bond import BOND

    # Set

# Generated at 2022-06-21 20:20:43.511355
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    # example 1
    ex1_start, ex1_asof, ex1_end = datetime.date(2018, 12, 17), datetime.date(2019, 3, 15), datetime.date(2019, 6, 14)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.2739726812')
    # example 2
    ex2_start, ex2_asof = datetime.date(2019, 3, 11), datetime.date(2019, 6, 10)
    assert round(dcfc_act_365_f(start=ex2_start, asof=ex2_asof, end=ex2_asof), 10) == Decimal('0.2712328767')



# Generated at 2022-06-21 20:20:47.862826
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    DCCRegistry.register(DCC(name="Act/360", altnames={"Act/360", "act/360"}, currencies={Currencies["USD"]}, calculate_fraction_method=DCFC.ACT_360))
    assert DCCRegistry.table['act/360'] == DCCRegistry.table['Act/360']


## Defines the day count conventions registry:
DCCRegistry = DCCRegistryMachinery()

########################################################################################################################
#
#   DAY COUNT CONVENTIONS
#
########################################################################################################################



# Generated at 2022-06-21 20:20:57.661960
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from .currencies import Currencies
    from .monetary import Money
    from decimal import Decimal
    import datetime
    dcc = DCC('1', {'1', '2' }, _as_ccys({'USD', 'EUR', 'JPY' }), DCF_30_360_ISDA)
    assert dcc.coupon(Money('10', Currencies.USD), Decimal('1'), datetime.date(2017, 1, 1), datetime.date(2017, 1, 31), datetime.date(2017, 1, 31), Decimal('1'), 1) == Money('0.33', Currencies.USD)

