

# Generated at 2022-06-21 20:12:45.461648
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:12:51.140426
# Unit test for constructor of class DCC
def test_DCC():
    DCC("ACT/360", {"ACT/360"}, _as_ccys({"USD"}), lambda s, a, e, f: _get_actual_day_count(s, a) / 360)
    DCC("30/360", {"30/360"}, _as_ccys({"USD"}), lambda s, a, e, f: _get_actual_day_count(s, a) / 360)



# Generated at 2022-06-21 20:12:54.496547
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCC("ACT/ACT", {"Act/Act", "Actual/Actual", "ActualActual", "ActAct"}, {Currencies["USD"]}, actual_actual_actual_method).interest(Money("USD", principal=100), rate=Decimal("0.25"), start=datetime.date(2016, 1, 20), asof=datetime.date(2016, 12, 31), end=datetime.date(2017, 1, 1), freq=1) == Money("USD", interest=Decimal("0.250126"))



# Generated at 2022-06-21 20:13:02.033841
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof),14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=ex2_start, asof=ex2_asof, end=ex2_asof),14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=ex3_start, asof=ex3_asof, end=ex3_asof),14) == Decimal('1.08333333333333')

# Generated at 2022-06-21 20:13:06.313237
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(datetime.date(2016, 10, 30), datetime.date(2016, 10, 31), datetime.date(2016, 10, 31)) == 1.001




# Generated at 2022-06-21 20:13:17.638512
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof),14) == Decimal('0.16942884946478')

# Generated at 2022-06-21 20:13:24.541318
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10)==Decimal('0.5245901639')


# Generated at 2022-06-21 20:13:35.817306
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-21 20:13:45.589024
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    int_curve = YieldCurve(rate_curve=[(Date(2019, 1, 1), 0.00), (Date(2020, 1, 1), 0.01)])
    fixed_leg = FixedLeg(currency=Currencies.USD, notional=Money(1000000, Currencies.USD), start_date=Date(2019, 1, 1), end_date=Date(2020, 1, 1), tenor='6M', payment_frequency=2, day_count_convention=DCCs.ACTUAL_360)
    fixed_leg.calculate_schedule(start_date=Date(2019, 1, 1))
    fixed_leg.calculate_day_count_fractions(DCCs.ACTUAL_360, int_curve)
    fixed_leg.calculate_accrued_interest()
    #print

# Generated at 2022-06-21 20:13:49.811191
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """
    Performs unit test for the dcfc_30_360_isda method.

    Returns:
        None

    Raises:
        AssertionError: If the unit test fails.

    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:14:31.031352
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC.coupon(DCCRegistry["ACT/ACT"], Money(100, "USD"), Decimal(0.1), datetime.date(2017, 1, 1),
                 datetime.date(2017, 1, 2), datetime.date(2017, 1, 1), 2) == Money(0.2, "USD")


    ## Find the previous and next payment dates:
    prevdate = datetime.date(1999, 12, 1)
    nextdate = datetime.date(2000, 2, 1)

    ## Calculate the interest and return:
    assert DCC.interest(DCCRegistry["ACT/ACT"], Money(100, "USD"), Decimal(0.1), prevdate, datetime.date(1999, 12, 31), nextdate, Decimal(2)) == Money(0.45, "USD")


# Generated at 2022-06-21 20:14:40.693230
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """
    ## Create a dummy dcc
    dcc = DCC('TEST',set(), set(), lambda s,a,e,f: Decimal(1))

    ## Unit tests

# Generated at 2022-06-21 20:14:52.763533
# Unit test for method interest of class DCC
def test_DCC_interest():
    """
    DCC.interest: 
        Tests for the DCC.interest method for instances created for the following conventions:
            ActualActual()
    """
    ## Construct the convention:
    conv = DCC(*ActualActual())

    ## Construct some dates:
    start = Date(2017, 1, 1)
    asof = Date(2017, 7, 1)
    end = Date(2018, 1, 1)

    ## Construct a principal object:
    principal = Money(1000, "USD")

    ## Run some tests:
    assert conv.interest(principal, Decimal(0.00), start, asof, end) == Money(0.00, "USD")
    assert conv.interest(principal, Decimal(0.05), start, asof, end) == Money(125.00, "USD")


# Generated at 2022-06-21 20:15:03.504660
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies import Currencies
    from .monetary import Money
    from .timebucket import TimeBucket

    print("Testing method calculate_daily_fraction of class DCC...")

    USD = Currencies["USD"]
    EUR = Currencies["EUR"]

    principal = Money(USD, 10000)
    rate = Decimal("0.01")
    start = Date(2017, 1, 1)
    asof = Date(2017, 1, 2)
    end = Date(2017, 2, 1)

    af = DCCRegistry["ACT/365F"].calculate_fraction
    da = DCCRegistry["ACT/365F"].calculate_daily_fraction

    assert da(start, asof, asof, None) == Decimal(0)

# Generated at 2022-06-21 20:15:14.716916
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    """
    Unit test for function dcfc_nl_365.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:15:20.564821
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    m = DCCRegistryMachinery()
    dcc_simple = DCC("Simple", set(), set(), lambda s, a, e, f: Decimal(1))
    m.register(dcc_simple)
    assert m._is_registered("Simple")
    assert not m._is_registered("Month")



# Generated at 2022-06-21 20:15:25.640161
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    pass



# Generated at 2022-06-21 20:15:36.333337
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof = datetime.date(2007, 11, 30), datetime.date(2008, 2, 29)
    ex6_start, ex6_asof = datetime.date(2007, 11, 30), dat

# Generated at 2022-06-21 20:15:42.633557
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=date(2019, 3, 2), asof=date(2019, 9, 10), end=date(2020, 3, 2)), 10) == round(Decimal('0.5245901639'), 10)



# Generated at 2022-06-21 20:15:47.844503
# Unit test for constructor of class DCC
def test_DCC():
    dcc = DCC(name="test", altnames=set(), currencies=set(), calculate_fraction_method=lambda a, b, c, d: 42)
    assert dcc.calculate_fraction(datetime.date(2020,1,1), datetime.date(2020,1,1), datetime.date(2020,1,1)) == 42



# Generated at 2022-06-21 20:16:14.357729
# Unit test for constructor of class DCC
def test_DCC():
    """
    Test the constructor of the class DCC.
    """
    ## Get a day count convention:
    dcc = DCC(name="TEST", altnames=[], currencies=[Currencies.USD], calculate_fraction_method=None)

    ## Check the contents:
    assert dcc.name == "TEST"
    assert dcc.altnames == set()
    assert dcc.currencies == {Currencies.USD}
    assert dcc.calculate_fraction_method is None

## Define a python test for the above function
test_DCC.pytestmark = pytest.mark.curve



# Generated at 2022-06-21 20:16:26.241520
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC("Actual/365", {"A/365"}, _as_ccys({"USD"}), calculate_fraction_actual_365).name == "Actual/365"
    assert set(DCC("Actual/365", {"A/365"}, _as_ccys({"USD"}), calculate_fraction_actual_365).altnames) == {"A/365"}
    assert set(DCC("Actual/365", {"A/365"}, _as_ccys({"USD"}), calculate_fraction_actual_365).currencies) == {Currencies.USD}
    assert DCC("Actual/365", {"A/365"}, _as_ccys({"USD"}), calculate_fraction_actual_365).calculate_fraction_method is not None

# Generated at 2022-06-21 20:16:32.973804
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-21 20:16:38.333610
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')
test_dcfc_act_act_icma()



# Generated at 2022-06-21 20:16:50.534356
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    from pandas.tseries.offsets import DateOffset
    import datetime
    # ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    # ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    # ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    # ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    # ex1_start,ex1_asof,ex2_start,ex2_asof,ex3_start,ex3_asof,ex

# Generated at 2022-06-21 20:16:58.225727
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-21 20:17:09.990432
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    start_date = datetime.date(2020, 4, 4)
    asof_date = datetime.date(2020, 4, 20)
    end_date = datetime.date(2020, 7, 30)
    
    # (A/365, Actual/365)
    dcc = DCC(name = 'ACT/365', 
              altnames = {'ACT/365', 'ACT/365L', 'ACT/365F', '365', '365L', '365F'}, 
              currencies = {Currencies['HKD'], Currencies['USD']}, 
              calculate_fraction_method = _calculate_act_365)
    
    

# Generated at 2022-06-21 20:17:19.238001
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    import datetime
    print('TESTING dcfc_30_e_plus_360')
    print('Test 1:')
    print(dcfc_30_e_plus_360(datetime.date(2018,5,31), datetime.date(2018,6,30), datetime.date(2018,6,30)))
    print('Test 2:')
    print(dcfc_30_e_plus_360(datetime.date(2018,5,31), datetime.date(2018,6,29), datetime.date(2018,6,29)))
    print('Test 3:')
    print(dcfc_30_e_plus_360(datetime.date(2018,5,31), datetime.date(2018,6,30), datetime.date(2018,6,30)))

# Generated at 2022-06-21 20:17:25.100271
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # Examples from https://en.wikipedia.org/wiki/Day_count_convention#30/360_ISDA
    import datetime
    assert round(dcfc_30_360_isda(datetime.date(2002, 10, 8), datetime.date(2002, 12, 12), datetime.date(2002, 12, 12)), 14) == Decimal('0.072222222222222')
    assert round(dcfc_30_360_isda(datetime.date(2002, 10, 8), datetime.date(2002, 12, 8), datetime.date(2002, 12, 8)), 14) == Decimal('0.072222222222222')

# Generated at 2022-06-21 20:17:35.361282
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """Test method calculate_fraction of class DCC
    """
    m = Money("100", "EUR")
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2018, 1, 1)
    end = datetime.date(2019,1,1)
    freq = Decimal("1")
    # Test case 1
    dcc = DCC("dc-name",["dc-name1", "dc-name2"], {Currencies["USD"]}, _dcfc_actual_actual)
    assert dcc.calculate_fraction(start, asof, end, freq) == Decimal(365)
    # Test case 2

# Generated at 2022-06-21 20:18:39.739957
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    ## Define the day count convention:
    dcc = DCC("MYDCC", {"MYALTDCC"}, {"MYCUR"}, lambda s, a, e, f: 0)

    ## Register the day count convention:
    DCCRegistry.register(dcc)

    ## Found by the main name:
    assert DCCRegistry.find("MYDCC") == dcc

    ## Found by the alternative name:
    assert DCCRegistry.find("MYALTDCC") == dcc

    ## Not found:
    assert DCCRegistry.find("NODCC") is None

    ## Clear the registry:
    DCCRegistry._buffer_main.clear()
    DCCRegistry._buffer_altn.clear()

    ## Test for case insensitive lookups:
    DCCRegistry.register(dcc)

    ## Found

# Generated at 2022-06-21 20:18:49.012863
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """test_DCC_calculate_fraction"""
    dcc = DCC("Actual/Actual (AFB)",
    {},
    {Currencies.USD, Currencies.GBP, Currencies.CAD, Currencies.HKD},
    _dcc_aafb)
    start = Date(2015, 1, 1)
    asof = Date(2015, 12, 31)
    end = Date(2016, 1, 1)
    freq = 2
    assert dcc.calculate_fraction(start, asof, end, freq) == 1
    assert dcc.calculate_fraction(start - relativedelta(years=1), asof, end, freq) == 1.0

# Generated at 2022-06-21 20:18:58.038573
# Unit test for method coupon of class DCC
def test_DCC_coupon():
   assert DCC(name='',altnames={},currencies={},calculate_fraction_method=lambda a, b, c, d:0).coupon(Money(12.3,'USD'),0,datetime.date(2014,1,1),datetime.date(2014,1,1))==Money(0,'USD')
   assert DCC(name='',altnames={},currencies={},calculate_fraction_method=lambda a, b, c, d:1).coupon(Money(12.3,'USD'),0,datetime.date(2014,1,1),datetime.date(2014,1,1))==Money(0,'USD')
   assert DCC(name='',altnames={},currencies={},calculate_fraction_method=lambda a, b, c, d:0.1).c

# Generated at 2022-06-21 20:19:00.820960
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    print(round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14))
    return None



# Generated at 2022-06-21 20:19:10.481803
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    """
    Unit test for method register of class DCCRegistryMachinery
    """
    ## Define the day count conventions:
    day_count_conventions = [
        DCC("30F/360", {"30F/360B", "30F/360S", "30/360"}, {"USD"}),
        DCC("Act/Act", {"Act/Act ICMA", "Act/Act ISDA", "Actual/Actual"}, {"USD", "EUR", "GBP"}),
    ]

    ## Initialize the registry:
    registry = DCCRegistryMachinery()

    ## Go through each convention:
    for day_count_convention in day_count_conventions:
        ## Register to the registry:
        registry.register(day_count_convention)

    ## Check if the day count conventions are properly registered:

# Generated at 2022-06-21 20:19:16.653145
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal = Money.parse('1000 USD')
    rate = 0.01
    start = Date.parse('2017-01-01')
    asof = Date.parse('2017-12-29')
    end = Date.parse('2017-12-31')
    freq = 1
    eom = None
    ans = DCC.parse('Act/360').coupon(principal, rate, start, asof, end, freq, eom)
    assert ans.value == Money.parse('1.64 USD')


# Generated at 2022-06-21 20:19:27.286797
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383'))

# Generated at 2022-06-21 20:19:35.775514
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ## 30/360 US
    ## Source: http://www.isda.org/c_and_a/pdf/mktc1122.pdf
    ## Section 3.4 - "30/360 US"

    ## Example 1
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

    ## Example 2
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-21 20:19:41.204004
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    for dccv, dccr in _dcc_test_cases:
        if dccv == '30/360 US':
            assert dcfc_30_360_us(*dccr) == _dcc_test_results[dccv]



# Generated at 2022-06-21 20:19:48.612994
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')


# Generated at 2022-06-21 20:21:33.041788
# Unit test for method interest of class DCC
def test_DCC_interest():
    # EOM
    assert DCCRegistry["30/360ISMA"].interest(Money(1.0, Currencies.USD), 0.01, Date(2017, 1, 1), Date(2017, 3, 1), freq=2, eom=31).amount == Decimal(0.0006944444444444444)
    # EOM
    assert DCCRegistry["30/360ISMA"].interest(Money(1.0, Currencies.USD), 0.01, Date(2017, 1, 1), Date(2017, 3, 1), freq=2, eom=31).amount == Decimal(0.0006944444444444444)
    # EOM