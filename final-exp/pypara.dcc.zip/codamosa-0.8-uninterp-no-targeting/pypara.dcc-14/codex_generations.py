

# Generated at 2022-06-21 20:12:30.296951
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28),
                             asof=datetime.date(2008, 2, 28),
                             end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28),
                             asof=datetime.date(2008, 2, 29),
                             end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-21 20:12:43.586507
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal('1.10000000000000')


# Generated at 2022-06-21 20:12:53.414671
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """Test of method coupon of class DCC"""
    dcc = DCC(
        name="ACT/ACT",
        altnames=set(),
        currencies=set(),
        calculate_fraction_method=None,
    )

    # Check the default value of method coupon
    assert dcc.coupon(principal=Money.parse("USD 100"), rate=Decimal(1), start=Date.parse("2018-06-01"), asof=Date.parse("2018-06-30"), end=Date.parse("2019-06-01"), freq=Decimal(2), eom=None, ) == Money.parse("USD 1")



# Generated at 2022-06-21 20:13:01.871059
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    startdate=datetime.date(2017, 1, 1)
    enddate=datetime.date(2017, 7, 1)
    interest_rate=Decimal(0.025)
    principal= Money(10, 'USD')
    freq =1

    dcc = DCCRegistry.get('ACT/360')
    answer= dcc.interest(principal, interest_rate, startdate, enddate, freq=Decimal(freq))
    assert answer.ccy == principal.ccy
    assert answer.amount == 500


# Generated at 2022-06-21 20:13:10.288998
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dc_30e360 = DCC(
        name="30E360",
        altnames={"30E/360", "30E360", "30/360 ISMA", "30/360 ISMA Convention", "360/360", "30/360", "1/12", "01/12"},
        currencies=_as_ccys({"USD"}),
        calculate_fraction_method=dcf_30e360,
    )

    assert dc_30e360.calculate_fraction(
        datetime.date(2017, 1, 1),
        datetime.date(2017, 1, 1),
        datetime.date(2017, 1, 2),
    ) == Decimal(0)

# Generated at 2022-06-21 20:13:21.671367
# Unit test for function dcfc_act_365_l

# Generated at 2022-06-21 20:13:32.532914
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    from numbers import Number
    from testdata import assert_decimal
    from unittest import TestCase
    from jsonschema import validate

    ## Test data:

# Generated at 2022-06-21 20:13:43.455393
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    start = Date(year=2007, month=12, day=28)
    asof = Date(year=2008, month=2, day=28)
    assert round(dcfc_act_365_f(start=start, asof=asof, end=start), 14) == 0.16986301369863
    asof = Date(year=2008, month=2, day=29)
    assert round(dcfc_act_365_f(start=start, asof=asof, end=start), 14) == 0.17260273972603
    start = Date(year=2007, month=10, day=31)
    asof = Date(year=2008, month=11, day=30)

# Generated at 2022-06-21 20:13:48.955889
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert(round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863'))
    assert(round(dcfc_nl_365(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.16986301369863'))
    assert(round(dcfc_nl_365(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08219178082192'))

# Generated at 2022-06-21 20:13:55.986551
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC_ACT_365.coupon(Money(100, Currencies.USD), 0.1, Date('2018-01-01'), Date('2018-02-01'), Date('2018-06-01'), 1, 1) == Money(0.5, Currencies.USD)
    assert DCC_ACT_360.coupon(Money(100, Currencies.USD), 0.1, Date('2018-01-01'), Date('2018-02-01'), Date('2018-06-01'), 1, 1) == Money(0.5, Currencies.USD)    

# Generated at 2022-06-21 20:14:29.411183
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ## Test data
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    ## Expected Result
    expected = 0.166666666666666666666666667
    ## Actual result
    actual = dcfc_30_e_plus_360(start, end, end)

    ## Assertion
    assert actual == expected, f"\nFailed: dcfc_30_e_plus_360\nActual:{actual}\nExpected:{expected}"
    print(f"Successful: dcfc_30_e_plus_360\nActual:{actual}\nExpected:{expected}")




# Generated at 2022-06-21 20:14:39.538744
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-21 20:14:45.758664
# Unit test for constructor of class DCC
def test_DCC():
    # test normal case:
    a = DCC('name', {'altnames'}, {'a'}, lambda a, b, c, d: Decimal('0.5'))
    assert a.name == 'name'
    assert a.altnames == {'altnames'}
    assert a.currencies == {'a'}
    assert a.calculate_fraction_method(datetime.date(2018, 3, 1), datetime.date(2018, 3, 2), datetime.date(2018, 3, 3)) == Decimal('0.5')

    # test Null case:
    b = DCC('name', {'altnames'}, {'a'}, lambda a, b, c, d: Decimal('0.55'))
    assert b.name == 'name'

# Generated at 2022-06-21 20:14:58.184683
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2))
           == Decimal("0.5245901639"))
    assert(dcfc_act_act_icma(datetime.date(2018, 2, 15), datetime.date(2018, 8, 15), datetime.date(2019, 2, 15))
           == Decimal("0.4993150685"))
    assert(dcfc_act_act_icma(datetime.date(2019, 4, 29), datetime.date(2019, 10, 29), datetime.date(2020, 4, 29))
           == Decimal("0.4986301370"))



# Generated at 2022-06-21 20:15:06.089665
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:15:17.459781
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-21 20:15:20.082474
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    import doctest
    doctest.testmod()


# Generated at 2022-06-21 20:15:28.344865
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    ## Create an instance of DCCRegistryMachinery
    my_DCC_registry_machinery = DCCRegistryMachinery()

    ## Create an instance of DCC
    my_DCC_1 = DCC(name = 'Act/Act', altnames = {'Actual/Actual'}, currencies = {'USD'}, calculate_fraction_method = 'dcf_act_act')

    ## Create an instance of DCC
    my_DCC_2 = DCC(name = '30/360', altnames = {'Thirty/360'}, currencies = {'EUR'}, calculate_fraction_method = 'dcf_30E_360')

    ## Assertion on the is_registered method
    assert my_DCC_registry_machinery._is_registered('Act/Act') == False
    assert my_

# Generated at 2022-06-21 20:15:33.542079
# Unit test for function dcc
def test_dcc():
    @dcc("My1")
    def _dcfc_1(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return ONE

    @dcc("My2", set(["MY2"]), set([]))
    def _dcfc_2(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return ONE

    @dcc("My3", set(["MY3"]), set(["MY"]))
    def _dcfc_3(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return ONE


# Generated at 2022-06-21 20:15:34.533581
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    t = DCCRegistry()
    return t


## Initialize the day count registry:
DCCRegistry = DCCRegistryMachinery()



# Generated at 2022-06-21 20:16:34.627529
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2019, 12, 31), datetime.date(2020, 1, 31),
                                  datetime.date(2020, 1, 31)), 14) == Decimal(0.08333333333333)
    assert round(dcfc_30_360_isda(datetime.date(2019, 12, 1), datetime.date(2020, 2, 1),
                                  datetime.date(2020, 2, 1)), 14) == Decimal(0.08333333333333)
    assert round(dcfc_30_360_isda(datetime.date(2019, 12, 31), datetime.date(2020, 1, 31),
                                  datetime.date(2020, 1, 31)), 14) == Decimal(0.08333333333333)

# Generated at 2022-06-21 20:16:40.680286
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC('30360E', {"30/360E", "30-360E"}, _as_ccys({"USD"}), _dcc_30360E).calculate_fraction(
        datetime.date(2014, 1, 1), datetime.date(2014,  1,  1), datetime.date(2014,  7,  1)
    ) == ZERO
    assert DCC('30360E', {"30/360E", "30-360E"}, _as_ccys({"USD"}), _dcc_30360E).calculate_fraction(
        datetime.date(2014, 1, 1), datetime.date(2014,  1,  2), datetime.date(2014,  7,  1)
    ) == Decimal("0.1458333333")

# Generated at 2022-06-21 20:16:51.061396
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """Test of function dcfc_act_act_icma"""
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    ex1_dx = Decimal('0.5245901639')
    # Unit test for function dcfc_act_act_icma
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == ex1_dx
    print('Unit test for function dcfc_act_act_icma [OK]')

# Generated at 2022-06-21 20:16:54.294813
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    ## Attempt to register the new model:
    with raises(TypeError):
        DCCRegistry.register(DCC("Act/Act", {}, {}, calculate_act_act_fraction))



# Generated at 2022-06-21 20:16:57.434279
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCC_ACTUAL_ACTUAL_ICMA.calculate_daily_fraction(
        datetime.date(2014,5,5),datetime.date(2014,6,10),datetime.date(2014,7,5)) - Decimal('0.468690')==Decimal('0')


# Generated at 2022-06-21 20:17:06.326560
# Unit test for constructor of class DCC
def test_DCC():
    dcc = DCC("name", {}, {}, lambda x, y, z, w: w)
    assert(dcc.name == "name")
    assert(dcc.altnames == set())
    assert(dcc.currencies == set())
    assert(dcc.calculate_fraction_method(
        datetime.date(2017, 1, 1),
        datetime.date(2017, 1, 1),
        datetime.date(2017, 1, 1),
        1.0000000000
    ) == 1.0000000000)


# Generated at 2022-06-21 20:17:11.136948
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(datetime.date(2007,12,28), datetime.date(2008,2,28)),14) == Decimal('0.16666666666667')
    
    

# Generated at 2022-06-21 20:17:19.646719
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc1 = DCC(name="Actual/Actual", altnames={"Act/Act", "AAA"}, currencies=[], calculate_fraction_method=lambda x, y, z, f: ZERO)
    dcc2 = DCC(name="Actual/360", altnames={"Act/360"}, currencies=[], calculate_fraction_method=lambda x, y, z, f: ZERO)

    dcc_registry = DCCRegistryMachinery()
    with CaptureConsole() as cc:
        dcc_registry.register(dcc1)
        dcc_registry.register(dcc1)
    assert cc.output == ['TypeError: Day count convention \'Actual/Actual\' is already registered\n']

    dcc_registry = DCCRegistryMachinery()

# Generated at 2022-06-21 20:17:30.405431
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    # Initialize a day count convention registry
    dccRegistry = DCCRegistry()

    # Define the 30/360 day count convention
    dcc30360 = DCC(
        name = "30/360",
        altnames = {"30-360", "U30/360", "30U/360", "U30-360", "30U-360"},
        currencies = {Currencies["CAD"], Currencies["DKK"], Currencies["HKD"], Currencies["JPY"], Currencies["USD"]},
        calculate_fraction_method = dcf_30360
    )
    dccRegistry.register(dcc30360)

    # Define the Act/Act day count convention

# Generated at 2022-06-21 20:17:40.548126
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert(round(dcfc_act_360(start=datetime.date(2007, 12, 28), end=datetime.date(2008, 2, 28)), 14)) == Decimal('0.17222222222222')
    assert(round(dcfc_act_360(start=datetime.date(2007, 12, 28), end=datetime.date(2008, 2, 29)), 14)) == Decimal('0.17500000000000')
    assert(round(dcfc_act_360(start=datetime.date(2007, 10, 31), end=datetime.date(2008, 11, 30)), 14)) == Decimal('1.10000000000000')

# Generated at 2022-06-21 20:19:56.925839
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 20:20:02.012625
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-21 20:20:12.605265
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(
        dcfc_30_360_isda(
            start=datetime.date(2017, 4, 15), asof=datetime.date(2017, 4, 17), end=datetime.date(2017, 4, 17)
        ),
        14,
    ) == Decimal('0.00555555555556')
    assert round(
        dcfc_30_360_isda(
            start=datetime.date(2017, 4, 15), asof=datetime.date(2017, 5, 17), end=datetime.date(2017, 5, 17)
        ),
        14,
    ) == Decimal('0.04722222222222')

# Generated at 2022-06-21 20:20:23.785272
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14)==Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14)==Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14)==Dec

# Generated at 2022-06-21 20:20:29.973047
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-21 20:20:35.409389
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-21 20:20:45.559555
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .currencies import Currencies
    from .monetary import Money
    
    CHF = Currencies["CHF"]
    DCCActual365 = DCCRegistry["Actual/365"]
    DCCActual360 = DCCRegistry["Actual/360"]
    DCCActualActual = DCCRegistry["Actual/Actual"]
    DCCActualActualAFB = DCCRegistry["Actual/Actual AFB"]
    DCC30E360 = DCCRegistry["30E/360"]
    
    assert DCCActual365.interest(Money(200, CHF), Decimal('0.0625'), datetime.date(2013, 1, 31), datetime.date(2013, 3, 2)) == Money(0.8194444444444444, CHF)
    assert DCCAct

# Generated at 2022-06-21 20:20:58.334399
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal('1.10000000000000')


# Generated at 2022-06-21 20:21:07.243325
# Unit test for method find of class DCCRegistryMachinery

# Generated at 2022-06-21 20:21:14.711888
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    import pandas as pd
    import numpy as np
    
    df = pd.DataFrame(columns=["start", "end", "act/365a"])
    i = 0