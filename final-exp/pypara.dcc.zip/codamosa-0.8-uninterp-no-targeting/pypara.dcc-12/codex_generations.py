

# Generated at 2022-06-21 20:12:19.338896
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .commons.zeitgeist import Date
    from .currencies import Currencies
    from .monetary import Money

    ## Setup our DCC:
    dcc = DCC(
        "Test DCC", {"test-dcc"}, _as_ccys({"EUR"}),
        lambda s, a, e, f: Decimal(0) if (s >= e) else (Decimal(1) if (a == e) else (a - s) / (e - s)),
    )

    ## Check first and last dates:
    assert dcc.calculate_fraction(Date(2014, 1, 1), Date(2014, 3, 1), Date(2014, 3, 1)) == Decimal(0)

# Generated at 2022-06-21 20:12:23.674200
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert set("abcd") == set("abcd")
# EOF



# Generated at 2022-06-21 20:12:28.170686
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof, freq=None), 14) == Decimal('0.16666666666667')
   

# Generated at 2022-06-21 20:12:37.556939
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Check to see if daily fraction is calculated correctly (within 0.0001) . 
    # Check to see if daily fraction for dates that are not one day apart is 0. 
    print( DCC('name', 'altnames', 'currencies', 'calculate_fraction_method').calculate_daily_fraction(datetime.date(2018, 1, 1), datetime.date(2018, 1, 2), datetime.date(2018, 1, 3), None) - Decimal(0.0010))
    print( DCC('name', 'altnames', 'currencies', 'calculate_fraction_method').calculate_daily_fraction(datetime.date(2018, 1, 1), datetime.date(2018, 1, 2), datetime.date(2018, 1, 4), None) - Decimal(0.0000))


# Generated at 2022-06-21 20:12:49.903048
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ## Example from PRDC
    ex1_start, ex1_asof, ex1_end = datetime.date(2018, 1, 16), datetime.date(2018, 12, 31), datetime.date(2019, 1, 15)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.9589041096')
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_end, end=ex1_end), 10) == Decimal('1.0000000000')
    ## Example from JQuantLib

# Generated at 2022-06-21 20:13:01.966011
# Unit test for constructor of class DCC
def test_DCC():
    """Unit test for constructor of class DCC."""

    _DCC = DCC(
        name='dccname',
        altnames=['alt1', 'alt2'],
        currencies=Currencies.as_currencies(['usd', 'eur', 'jpy']),
        calculate_fraction_method = lambda x, y, z, a: 1,
    )
    assert _DCC.name == 'dccname'
    assert str(_DCC) == "DCC(name='dccname')"
    assert repr(_DCC) == "DCC(name='dccname', altnames=['alt1', 'alt2'], currencies={<Currency:usd>, <Currency:jpy>, <Currency:eur>}, calculate_fraction_method=<function <lambda> at ...>)"
    assert _D

# Generated at 2022-06-21 20:13:06.061445
# Unit test for constructor of class DCC
def test_DCC():
    Test = DCC(name=None,
               altnames=None,
               currencies=None,
               calculate_fraction_method=None)
    Test.__init__
    return Test
# Jinsong
# Test for method interest of class DCC

# Generated at 2022-06-21 20:13:15.907105
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-21 20:13:27.266607
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    dcc = DCC(
        name="30/360",
        altnames=["30/360", "30E/360"],
        currencies=set(),
        calculate_fraction_method=_30_360,
    )
    principal = Money(100, 'USD')
    rate = 0.05
    start = datetime.date(2012, 12, 15)
    asof = datetime.date(2016, 1, 6)
    end = datetime.date(2016, 4, 6)
    freq = 2
    eom = 15
    result = dcc.coupon(principal, rate, start, asof, end, freq, eom = eom)
    assert result == Money(2.39, 'USD')


# Generated at 2022-06-21 20:13:37.037740
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-21 20:14:07.542946
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:14:18.191243
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():

    #Test00
    start = datetime.date(2019, 12, 8)
    asof = datetime.date(2020, 3, 1)
    end = datetime.date(2020, 3, 31)
    freq = 1
    result_expected = 1/4
    result_actual = DCCRegistry.get_instance().get_by_name("ACTUAL/360").calculate_fraction(start, asof, end, Decimal(freq))
    if result_expected ==  result_actual:
        print("Test00: PASSED")
    else:
        print("Test00: FAILED")

    #Test01
    start = datetime.date(2020, 2, 1)
    asof = datetime.date(2020, 2, 21)

# Generated at 2022-06-21 20:14:30.689608
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    #ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-21 20:14:38.829135
# Unit test for constructor of class DCC
def test_DCC():
    dcc = DCC(
        "Actual/Actual (ISDA)",
        {"ActualActualISDA"},
        _as_ccys({"USD", "EUR", "JPY"}),
        lambda start, asof, end, freq: _get_actual_day_count(start, asof) / _get_actual_day_count(start, end)
    )

    assert isinstance(dcc, DCC)
    assert isinstance(DCC.interest(dcc, Money(100, "USD"), 0.03, Date(2020, 1, 1), Date(2020, 1, 2)), Money)



# Generated at 2022-06-21 20:14:41.711158
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCC_A_365.calculate_fraction(datetime.date(2016, 1, 2), datetime.date(2016, 12, 31), datetime.date(2017, 1, 1)) == Decimal((366 - 2) / 366)



# Generated at 2022-06-21 20:14:54.272774
# Unit test for method coupon of class DCC

# Generated at 2022-06-21 20:14:57.054473
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC(0,0,0,0).coupon(Money(1, 'EUR'), 1, 1,2,3,1,1) == 1


# Generated at 2022-06-21 20:15:08.693468
# Unit test for method interest of class DCC
def test_DCC_interest():
    """
    To test the interest method of class DCC
    """
    """
    The example is taken from a test case used in a python package QuantLib
    https://pypi.org/project/QuantLib/
    https://github.com/lballabio/QuantLib/blob/master/QuantLib/test-suite/interestrate.cpp
    """
    # Fixture Setup
    dcc = DCC(
        name='ACT/360',
        altnames=set(),
        currencies=set(),
        calculate_fraction_method=_act_360,
    )
    principal = Money(1234.5, Currencies.EUR)
    rate = Decimal('0.02')
    start = datetime.date(2014, 12, 21)
    asof = datetime.date(2015, 2, 17)


# Generated at 2022-06-21 20:15:13.811846
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    for start, asof, expected in [
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 28),  Decimal('0.16666666666667')),
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 29),  Decimal('0.16944444444444')),
        (datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), Decimal('1.08333333333333')),
        (datetime.date(2008, 2, 1),   datetime.date(2009, 5, 31),  Decimal('1.33055555555556')),
    ]:
        assert round(dcfc_30_360_german(start=start, end=asof, asof=asof), 14)

# Generated at 2022-06-21 20:15:18.775567
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:15:51.459085
# Unit test for method interest of class DCC
def test_DCC_interest():
    d = datetime.date(2016, 5, 10)
    d1 = datetime.date(2016, 5, 9)
    d2 = datetime.date(2016, 5, 11)
    x = DCC(name="test", altnames=set(), currencies=set(), calculate_fraction_method=lambda a, b, c, d: Decimal(1))
    assert x.interest(Money(0, Currency("USD")), rate=Decimal(1), start=d1, asof=d, end=d2, freq=Decimal(1)) == Money(0, Currency("USD"))
    assert x.interest(Money(5, Currency("USD")), rate=Decimal(1), start=d1, asof=d, end=d2, freq=Decimal(1)) == Money(5, Currency("USD"))
   

# Generated at 2022-06-21 20:15:56.318532
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    """
    >>> dcfc_30_e_plus_360(datetime.date(2008, 1, 31), datetime.date(2008, 2, 29), datetime.date(2008, 3, 31))
    Decimal('0.1')
    """
    dt_start, dt_asof, dt_end = datetime.date(2008, 1, 31), datetime.date(2008, 2, 29), datetime.date(2008, 3, 31)
    assert dcfc_30_e_plus_360(dt_start, dt_asof, dt_end) == Decimal('0.1')

# Generated at 2022-06-21 20:16:03.962512
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')



# Generated at 2022-06-21 20:16:13.345989
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2015, 2, 28), asof=datetime.date(2016, 2, 28), end=datetime.date(2016, 2, 28)), 14) == Decimal('1.000000000000000')
    assert round(dcfc_act_365_l(start=datetime.date(2015, 3, 31), asof=datetime.date(2016, 3, 31), end=datetime.date(2016, 3, 31)), 14) == Decimal('1.000000000000000')
    assert round(dcfc_act_365_l(start=datetime.date(2015, 2, 28), asof=datetime.date(2016, 3, 31), end=datetime.date(2016, 3, 31)), 14) == Decimal('1.000000000000000')




# Generated at 2022-06-21 20:16:25.449765
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof, ex1_end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2012, 2, 28)
    ex2_start, ex2_asof, ex2_end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2012, 2, 29)
    ex3_start, ex3_asof, ex3_end = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2012, 11, 30)

# Generated at 2022-06-21 20:16:35.254546
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-21 20:16:41.546117
# Unit test for function dcc
def test_dcc():
    @dcc("Test DCC")
    def test_dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return Decimal(asof.year + asof.month + asof.day - start.year - start.month - start.day)

    assert test_dcfc(datetime.date(2019, 1, 1), datetime.date(2019, 2, 1), datetime.date(2019, 12, 1)) == 31



# Generated at 2022-06-21 20:16:52.792917
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    test_cases = (
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), Decimal("0.16939890710383")),
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), Decimal("0.17213114754098")),
        (datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), Decimal("1.08196721311475")),
        (datetime.date(2008,  2,  1), datetime.date(2009, 5, 31), Decimal("1.32876712328767"))
    )


# Generated at 2022-06-21 20:17:04.856414
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    
    
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
   

# Generated at 2022-06-21 20:17:11.243774
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')


## Default instance of the day count convention registry machinery:
DCCRegistry = D

# Generated at 2022-06-21 20:21:09.189349
# Unit test for method interest of class DCC
def test_DCC_interest():
    DCC_ex = DCC("Actual/365","A365",set(),_get_actual_day_count)
    assert DCC_ex.interest(Money(100, "USD"), Decimal("0.03"), datetime.date(2017, 1, 1), datetime.date(2017, 2, 1)) == Money("0.30", "USD")


# Generated at 2022-06-21 20:21:11.145658
# Unit test for function dcc
def test_dcc():
    @dcc("Act/Act", {'Actual/Actual'})
    def _(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        pass
    
    assert _.__dcc.name == 'Act/Act'


# Generated at 2022-06-21 20:21:19.124710
# Unit test for function dcc
def test_dcc():
    assert DCCRegistry._find_strict('test_dcc') is None
    @dcc('test_dcc')
    def test_func(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return ZERO
    assert test_func is not None
    assert test_func.__dcc is not None
    assert test_func.__dcc.name == 'test_dcc'
    assert DCCRegistry._find_strict('test_dcc') is test_func.__dcc
    assert DCCRegistry._find_strict('Test_DCc') is test_func.__dcc
    test_func.__dcc.altnames = {'test_dcc_alt'}

# Generated at 2022-06-21 20:21:31.201581
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    exp1 = Decimal('0.16939890710383')
    exp2 = Decimal('0.17213114754098')
    exp3 = Decimal('1.08196721311475')