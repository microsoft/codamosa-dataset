

# Generated at 2022-06-21 20:12:04.095061
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert dcfc_nl_365(datetime.date(2007,12,28), datetime.date(2008,2,28)) == 0.16986301369863
    assert dcfc_nl_365(datetime.date(2007,12,28), datetime.date(2008,2,29)) == 0.16986301369863
    assert dcfc_nl_365(datetime.date(2007,10,31), datetime.date(2008,11,30)) == 1.08219178082192
    assert dcfc_nl_365(datetime.date(2008,2,1), datetime.date(2009,5,31)) == 1.32602739726027


# Generated at 2022-06-21 20:12:16.201708
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)), 14) == Decimal(
        '0.16666666666667')
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)), 14) == Decimal(
        '0.16944444444444')
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)), 14) == Decimal(
        '1.08333333333333')

# Generated at 2022-06-21 20:12:28.771339
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Unit test for function dcfc_30_360_us()
    """
    ## Example 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

    ## Example 2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_30_360_us(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal

# Generated at 2022-06-21 20:12:36.625722
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    start = datetime.datetime(2019,3,2).date()
    asof = datetime.datetime(2019,9,10).date()
    end = datetime.datetime(2020,3,2).date()
    assert round(dcfc_act_act_icma(start, asof, end,12),10)==round(Decimal('0.5245901639'),10)
    assert round(dcfc_act_act_icma(asof, start, end,12),10)==0



# Generated at 2022-06-21 20:12:49.443003
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert dcfc_act_360(datetime.date(2019, 2, 1), datetime.date(2019, 2, 1), datetime.date(2019, 2, 1)) == Decimal(0)
    assert dcfc_act_360(datetime.date(2019, 1, 1), datetime.date(2019, 1, 1), datetime.date(2019, 2, 1)) == Decimal(1/360)
    assert dcfc_act_360(datetime.date(2019, 1, 1), datetime.date(2019, 1, 2), datetime.date(2019, 2, 1)) == Decimal(2/360)
    assert dcfc_act_360(datetime.date(2019, 1, 1), datetime.date(2019, 1, 31), datetime.date(2019, 2, 1)) == Dec

# Generated at 2022-06-21 20:13:01.506793
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from osqutil.dataframe import DfUtil
    from osqutil.configutil import ConfigUtil
    from osqutil.timeseries import TimeSeries
    from osmdm.dating.dateutil import DateUtil
    from osmdm.dating.dcc import DCC
    
    ## Get the list of dates:
    dates = DateUtil.list_dates("2016-01-01", "2016-12-31")
    
    ## Calculate the daily factor:
    fractions = [DCC.ACT_360.calculate_daily_fraction(dates[0], d, dates[-1]) for d in dates]
    
    ## Check if all sum up to 1:
    assert DfUtil.round(sum(fractions), 9)==1
    
    ## Plot the daily factor:
    ts = TimeSeries

# Generated at 2022-06-21 20:13:10.117054
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2015, 2, 28), datetime.date(2015, 12, 31), datetime.date(2015, 12, 31)), 14) == Decimal('0.95890410958904')
    assert round(dcfc_act_365_l(datetime.date(2016, 2, 28), datetime.date(2016, 12, 31), datetime.date(2016, 12, 31)), 14) == Decimal('0.95890410958904')
    assert round(dcfc_act_365_l(datetime.date(2017, 2, 28), datetime.date(2017, 12, 31), datetime.date(2017, 12, 31)), 14) == Decimal('0.95890410958904')

# Generated at 2022-06-21 20:13:21.877415
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-21 20:13:32.720376
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry.ISDA.calculate_fraction(Date(2017, 2, 7), Date(2017, 2, 7), Date(2017, 2, 7)) == ZERO
    assert DCCRegistry.ISDA.calculate_fraction(Date(2017, 2, 7), Date(2017, 2, 8), Date(2017, 2, 8)) == ONE
    assert DCCRegistry.ISDA.calculate_fraction(Date(2017, 2, 7), Date(2017, 2, 7), Date(2017, 2, 8)) == ZERO
    assert DCCRegistry.ISDA.calculate_fraction(Date(2015, 1, 1), Date(2015, 1, 1), Date(2015, 1, 31)) == Decimal("0.00821917808219178")
    assert DCCRegistry.IS

# Generated at 2022-06-21 20:13:43.615034
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.17222222222222')

# Generated at 2022-06-21 20:14:10.606862
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    x = DCCRegistry()
    y = DCC(
        "DAYCOUNT",
        {"DCC", "DCC", "DCC"},
        {Currencies.USD, Currencies.EUR},
        lambda start, asof, end, freq: ZERO,
    )
    x.register(y)


# Generated at 2022-06-21 20:14:19.728526
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=None), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=None), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=None), 14) == Decimal('1.08219178082192')

# Generated at 2022-06-21 20:14:31.000152
# Unit test for method calculate_daily_fraction of class DCC

# Generated at 2022-06-21 20:14:38.446039
# Unit test for method interest of class DCC
def test_DCC_interest():

    dcc = DCC("ACT/ACT", {}, {}, calculate_fraction_method=_calculate_dcc_act_act)
    principal = Money("100")
    rate = Decimal("0.05")
    start = Date(datetime.datetime(2017,1,1))
    asof = Date(datetime.datetime(2018,1,1))
    end = None
    freq = None

    assert dcc.interest(principal, rate, start, asof, end, freq) == Money("5")



# Generated at 2022-06-21 20:14:50.427889
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    # Test cases from the OpenGamma source code.
    assert dcfc_30_e_plus_360(
        datetime.date(2007, 12, 28),
        datetime.date(2008, 2, 28),
        datetime.date(2008, 2, 28)
    ) == Decimal('0.16666666666667')
    assert dcfc_30_e_plus_360(
        datetime.date(2007, 12, 28),
        datetime.date(2008, 2, 29),
        datetime.date(2008, 2, 29)
    ) == Decimal('0.16944444444444')

# Generated at 2022-06-21 20:15:00.627352
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    principal = Money("100.0", "USD")
    start = Date("2017-1-1")
    asof = Date("2017-1-2")
    end = Date("2017-1-2")
    freq = Decimal("1")
    eom = 1

    act_calculate_daily_fraction = DCC.calculate_daily_fraction(principal, start, asof, end, freq)
    exp_calculate_daily_fraction = Money("0.0", "USD")

    assert act_calculate_daily_fraction == exp_calculate_daily_fraction


# Generated at 2022-06-21 20:15:12.707708
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC(
        name = "ACT/365",
        altnames = {"ACT/365", "ACT/365F", "30/365", "30/365F", "30/360"},
        currencies = Currencies["EUR", "USD", "CAD", "GBP"],
        calculate_fraction_method = _actual_act_365_fraction
    ) == DCC(
        "ACT/365",
        {"ACT/365", "ACT/365F", "30/365", "30/365F", "30/360"},
        _as_ccys({"EUR", "USD", "CAD", "GBP"}),
        _actual_act_365_fraction
    )


# Generated at 2022-06-21 20:15:15.550720
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find("Act/act") == DCCRegistry.find("ACT/Act") == DCCRegistry.find("ACT/act")


# Generated at 2022-06-21 20:15:24.225900
# Unit test for constructor of class DCC
def test_DCC():
    dcc = DCC(name = 'MYOWN', altnames = set(), currencies = set(), calculate_fraction_method = lambda x,y,z,w: ZERO)
    assert(dcc.name == 'MYOWN')
    assert(len(dcc.altnames) == 0)
    assert(len(dcc.currencies) == 0)
    assert(dcc.calculate_fraction_method(datetime.datetime(2017,1,1),datetime.datetime(2017,1,2),datetime.datetime(2017,1,3),None) == ZERO)


# Generated at 2022-06-21 20:15:34.899265
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-21 20:16:35.401064
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-21 20:16:36.928429
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dcc = DCCRegistryMachinery()
    assert dcc is not None


# Generated at 2022-06-21 20:16:48.150767
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .currencies import Currencies
    from .dcc.dcc import DCC
    from .monetary import Money
    from .schedule import ScheduleInfo


    ## Create the schedule info:
    schinfo = ScheduleInfo(currency=Currencies.USD, principal=10000, rate=0.05, frequency=2, fixed_rate=True)

    ## Create the DCC:
    dcc = DCC.AFB(schinfo)

    ## Checks:
    assert dcc.calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1)) == 0

# Generated at 2022-06-21 20:16:56.934875
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Tests the day count fraction calculation function.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:17:04.866926
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    start = datetime.date(2019, 3, 2)
    asof = datetime.date(2019, 9, 10)
    end = datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start, asof, end), 10) == Decimal('0.5245901639')



# Generated at 2022-06-21 20:17:15.318340
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:17:16.688990
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    '''Test coupons calculation for DCC
    '''
    return

# Generated at 2022-06-21 20:17:19.108670
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # ...
    pass



# Generated at 2022-06-21 20:17:29.855825
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex1 = dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof)

# Generated at 2022-06-21 20:17:40.064941
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    from money import Money
    from datetime import date

    registry = DCCRegistryMachinery()
    registry.register(DCC("Act/Act", {"Act/Act", "Actual/Actual", "Actual/360", "A/360", "A360"}, {"USD"}, Act_Act))
    registry.register(DCC("Act/360", {"Act/360", "Actual/360", "A/360", "A360"}, {"USD"}, Act_Act))
    registry.register(DCC("30/360", {"30E/360", "30US", "30/360", "360/360", "ISMA"}, {"USD"}, Thirty_360))
    registry.register(DCC("30/360", {"30E/360", "30US", "30/360", "360/360", "ISMA"}, {"GBP"}))

    principal

# Generated at 2022-06-21 20:18:55.245119
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Tests method find of class DCCRegistryMachinery
    """
    DCCRegistry.register(DCC("DC30/360(PI)", {"30/360", "PI"}, {Currencies["USD"]}, DCFC30360Pi))
    assert DCCRegistry.find("DC30/360(PI)") is not None
    assert DCCRegistry.find("30/360") is not None


# Generated at 2022-06-21 20:19:05.439084
# Unit test for method interest of class DCC
def test_DCC_interest():
    #>>> from financials.currencies import USD
    #>>> from financials.interestrates import ZeroRateCurve, ZERO
    #>>> from financials.valuation import Money
    #>>> ir = ZeroRateCurve(USD, start="2020-01-01", daycount="ACT/360")
    #>>> ir = ir.with_rates(**{d.strftime("%Y-%m-%d"): ZERO for d in ir.dates()})
    #>>> DCC["ACT/365"].interest(Money(100, USD), Decimal("0.10"), ... , datetime.date(2020, 1, 1), datetime.date(2020, 1, 2))
    #Money(10, USD)
    usd = Currencies.USD
    start = Date(year=2020, month=1, day=1)
    end  

# Generated at 2022-06-21 20:19:13.777794
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    DCCRegistryMachinery()
    DCCRegistryMachinery._is_registered(DCCRegistryMachinery(), "Actual/Actual (ISMA)")
    DCCRegistryMachinery._find_strict(DCCRegistryMachinery(), "Actual/Actual (ISMA)")
    DCCRegistryMachinery.find(DCCRegistryMachinery(), "Actual/Actual (ISMA)")
    DCCRegistryMachinery.register(DCCRegistryMachinery(), DCC("Actual/Actual (ISMA)", set(), set(), _dcc_act_act))
    DCCRegistryMachinery.register(DCCRegistryMachinery(), DCC("Actual/30 (Fixed)", set(), set(), _dcc_act_30))

# Generated at 2022-06-21 20:19:24.494478
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-21 20:19:28.580279
# Unit test for function dcc

# Generated at 2022-06-21 20:19:35.376886
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2019, 10, 10), datetime.date(2020, 11, 10), datetime.date(2021, 11, 10)), 14) == Decimal('0.37671232876712')



# Generated at 2022-06-21 20:19:41.836604
# Unit test for function dcc
def test_dcc():
    result = dcc(name='ACT/ACT ISDA')
    assert type(result) == types.FunctionType
if __name__ == '__main__':
    test_dcc()



# Generated at 2022-06-21 20:19:50.237531
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Test case #1
    print("Test case #1")

    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)

    nod = dcfc_30_360_us(start, asof)

    print("nod:", nod)

    # Test case #2
    print("Test case #2")

    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)

    nod = dcfc_30_360_us(start, asof)

    print("nod:", nod)

    print("Done.")


if __name__ == "__main__":
    test_dcfc_30_360_us()

# Generated at 2022-06-21 20:19:51.753054
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    instanceDCCR = DCCRegistryMachinery()
    assert instanceDCCR
    return None


# Generated at 2022-06-21 20:20:03.848352
# Unit test for function dcfc_30_360_isda