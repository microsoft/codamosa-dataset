

# Generated at 2022-06-21 20:12:06.764159
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCC("CNNM_1", {}, {}, DCFC_ACT_ACT_DIFF)
    DCCRegistry.register(dcc)

# Generated at 2022-06-21 20:12:14.543612
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')

test_dcfc_act_act_icma()



# Generated at 2022-06-21 20:12:19.963384
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof, ex1_end = datetime.date(2008, 12, 31), datetime.date(2009, 4, 1), datetime.date(2010, 12, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_end), 14) == Decimal('0.26027397260274')




# Generated at 2022-06-21 20:12:27.382950
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 2, 29)), 14) == Decimal('0.17260273972603')
    assert round(dcfc_act_365_f(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008, 11, 30)), 14) == Decimal('1.08493150684932')

# Generated at 2022-06-21 20:12:33.895342
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    c = DCC(name="test",
            altnames=set(),
            currencies=set(),
            calculate_fraction_method=None)
    assert c.coupon(Money(Decimal(1), Currencies.USD),
                    Decimal(0.5),
                    datetime.date(2017, 1, 1),
                    datetime.date(2017, 1, 10),
                    datetime.date(2017, 1, 15),
                    Decimal(4)) == Money(Decimal(0.05), Currencies.USD)



# Generated at 2022-06-21 20:12:41.700521
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """Test for method find of class DCCRegistryMachinery."""
    # Init
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal('0.01')
    # Execute
    result = DCCRegistry.find("Act/Act")
    # Validate,
    assert (result.interest(principal, rate, start, end, end).qty == Decimal('1694.29'))
    assert (result.interest(principal, rate, end, start, start).qty == Decimal('0.00'))



# Generated at 2022-06-21 20:12:46.474781
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:12:56.991512
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    import pytest
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert (round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667'))

# Generated at 2022-06-21 20:13:01.142235
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:13:04.906200
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    with pytest.raises(TypeError) as _excinfo:
        dcc_registry_machinery.register(DCC("Act/Act", {}, {}, lambda start, asof, end, freq: ONE))
    assert "Act/Act" in str(_excinfo.value)



# Generated at 2022-06-21 20:13:41.990681
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCs["30/360 ISDA"].coupon(Money(100, "USD"), 0.05, datetime.date(2018, 1, 1), datetime.date(2018, 12, 31), datetime.date(2019, 1, 1), 2) == Money(2.5, "USD")


# Generated at 2022-06-21 20:13:53.301548
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # 2/28, 2/29, 2/29, 2/29
    months = [datetime.date(2014, 2, 28), datetime.date(2015, 2, 28), datetime.date(2016, 2, 29), datetime.date(2017, 2, 28)]
    day_counts = [dcfc_30_360_isda(months[i],months[i+1],months[i+1]) for i in range(0,3)]
    print(day_counts)
    # [Decimal('0.16666666666666666'), Decimal('0.16666666666666666'), Decimal('0.16666666666666666'), Decimal('0.16666666666666666')]
    # 1/31, 2/28, 2/29, 2/28

# Generated at 2022-06-21 20:14:05.124346
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert(round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383'))
    assert(round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098'))
    assert(round(dcfc_act_365_l(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08196721311475'))

# Generated at 2022-06-21 20:14:16.555372
# Unit test for function dcc

# Generated at 2022-06-21 20:14:18.512287
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dcc = DCCRegistryMachinery()
    assert dcc._buffer_main == {}
    assert dcc._buffer_altn == {}


# Registry model.
DCCRegistry = DCCRegistryMachinery()
# Global model.
DCC = DCC


# Generated at 2022-06-21 20:14:25.011340
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC_ACT_360.coupon(principal=Money("1000.00", "EUR"), rate=Decimal("1.10"), start=date(2017, 1, 1), asof=date(2017, 1, 2), end=date(2017, 2, 1), freq=Decimal("1.00")) == Money("0.30", "EUR")
    assert DCC_ACT_360.coupon(principal=Money("1000.00", "EUR"), rate=Decimal("0.11"), start=date(2017, 6, 1), asof=date(2018, 5, 8), end=date(2018, 6, 1), freq=Decimal("2.00")) == Money("49.87", "EUR")

# Generated at 2022-06-21 20:14:29.232979
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Example 1:
    ex_1_start = datetime.date(2007, 12, 28)
    ex_1_asof = datetime.date(2008, 2, 28)
    ex_1_end = datetime.date(2008, 2, 28)
    ex_1_dcfc = dcfc_30_360_us(start=ex_1_start, asof=ex_1_asof, end=ex_1_end)
    ex_1_dcfc_str = "{0:.14f}".format(ex_1_dcfc)
    print("Example 1 start date: %s" % ex_1_start)
    print("Example 1 asof date: %s" % ex_1_asof)
    print("Example 1 end date: %s" % ex_1_end)


# Generated at 2022-06-21 20:14:39.222584
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:14:41.775677
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    result = DCCRegistry.find("Act/Act")
    assert result == DCC("Act/Act", {"Act/Act", "Actual/Actual"}, {"USD"}, _calculate_fraction_act_act)



# Generated at 2022-06-21 20:14:50.481672
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Tests the method find.
    """
    # DCCRegistryMachinery
    dcc = DCCRegistryMachinery()

    # Test with successful cases
    assert dcc.find('Act/Act') is not None
    assert dcc.find('ACT/ACT') is not None
    assert dcc.find('    Act/Act    ') is not None

    # Test with error cases
    with pytest.raises(TypeError) as excinfo:
        dcc.find('Actual/Actual')
    assert 'is already registered' in str(excinfo.value)

