

# Generated at 2022-06-21 20:12:06.525722
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dccRegistryMachinery = DCCRegistryMachinery()
    print(dccRegistryMachinery._buffer_main)
    print(dccRegistryMachinery._buffer_altn)


## setup the registry machinery:
DCCRegistry: DCCRegistryMachinery = DCCRegistryMachinery()



# Generated at 2022-06-21 20:12:18.464290
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    # 2019-03-02 to 2020-03-02
    assert round(dcfc_act_act_icma(datetime.date(2019,3,2), datetime.date(2019,9,10), datetime.date(2020,3,2)),10) == round(Decimal('0.5245901639'),10)
    assert round(dcfc_act_act_icma(datetime.date(2019,3,2), datetime.date(2020,3,2), datetime.date(2020,3,2)),10) == round(Decimal('1.000000000'),10)

# Generated at 2022-06-21 20:12:30.515676
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC(name="", altnames=set(), currencies=set(), calculate_fraction_method=lambda *args: ZERO)
    start = Date(1, 1, 1900)
    asof = Date(1, 1, 1900)
    end = Date(1, 1, 1900)
    freq = None
    assert dcc.calculate_fraction(start, asof, end, freq) == ZERO
    asof = Date(2, 1, 1900)
    assert dcc.calculate_fraction(start, asof, end, freq) == ZERO
    asof = Date(1, 1, 1901)
    assert dcc.calculate_fraction(start, asof, end, freq) == ZERO

# Generated at 2022-06-21 20:12:43.541236
# Unit test for function dcc
def test_dcc():
    # Test normal use cases:
    assert dcc("Test", set(["Test2"]), set([]))(lambda x, y, z: 0).__dcc.name == "Test"
    assert dcc("Test", set(["Test2"]), set([]))(lambda x, y, z: 0).__dcc.altnames == set(["Test2"])
    assert dcc("Test", set(["Test2"]), set([]))(lambda x, y, z: 0).__dcc.currencies == set([])
    assert dcc("Test", set(["Test2"]), set([]))(lambda x, y, z: 0).__dcc.calculate_fraction_method(0, 0, 0) == 0
    # Test when name is in registry

# Generated at 2022-06-21 20:12:55.706788
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCCs["ACT/360"].calculate_fraction == calculate_act_360_fraction
    assert DCCs["ACT/365"].calculate_fraction == calculate_act_365_fraction
    assert DCCs["ACT/ACT"].calculate_fraction == calculate_act_act_fraction
    assert DCCs["30/360"].calculate_fraction == calculate_30_360_fraction
    assert DCCs["30/360Eur"].calculate_fraction == calculate_30_360Eur_fraction
    assert DCCs["30E/360Eur"].calculate_fraction == calculate_30_360Eur_fraction
    assert DCCs["30E/360ISDA"].calculate_fraction == calculate_30_360ISDA

# Generated at 2022-06-21 20:13:02.586074
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
	registry = DCCRegistry()
	dcc = DCC("test", {"test2"}, {"USD"}, (lambda x,y,z,q: 1))
	registry.register(dcc)
	assert registry.find("test").name == "test"
	assert registry.find("test2").name == "test"
	assert registry.find("USD").name == "test"
	assert registry.registry == [dcc]

# Generated at 2022-06-21 20:13:07.659080
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert(round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667'))
    assert(round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444'))

# Generated at 2022-06-21 20:13:18.566679
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    from collections import namedtuple
    Case = namedtuple("Case", ["start", "asof", "end", "expect"])

# Generated at 2022-06-21 20:13:30.238008
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    import datetime
    from quantulum3 import Money
    from quantulum3.time.dcc import DCC
    from quantulum3.time.dcc import _last_payment_date

    assert _last_payment_date(datetime.date(2014,1,1), datetime.date(2015,12,31), 2) == datetime.date(2015,7,1)
    assert _last_payment_date(datetime.date(2014,1,1), datetime.date(2015,12,31), 1) == datetime.date(2015,1,1)
    assert _last_payment_date(datetime.date(2014,1,1), datetime.date(2015,12,31), 0.25) == datetime.date(2015,3,1)

# Generated at 2022-06-21 20:13:41.698866
# Unit test for function dcc
def test_dcc():
    @dcc("simple", {"simple interest", "simple interest count"}, {"USD"})
    def simple(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Calculates the simple day count fraction.
        """
        return Decimal((asof - start).days) / Decimal((end - start).days)

    # Test registering a function with decorator dcc
    @dcc("simple_unit", {"simple interest", "simple interest count"}, {"USD"})
    def simple(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Calculates the simple day count fraction.
        """
        return Decimal((asof - start).days) / Decimal((end - start).days)

# Generated at 2022-06-21 20:14:20.590519
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Part 1: Positive test cases:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)


# Generated at 2022-06-21 20:14:28.387442
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)),14) == Decimal("0.16986301369863")
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)),14) == Decimal("0.17213114754098")
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)),14) == Decimal("1.08196721311475")

# Generated at 2022-06-21 20:14:37.981822
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_expected = Decimal('0.16942884946478')
    ex2_expected = Decimal('0.17216108990194')
    ex3_expected = Decimal('1.08243131970956')
    ex4_expected = Decimal('1.32625945055768')
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)

# Generated at 2022-06-21 20:14:41.054949
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc = DCCRegistry.find("act/act")
    assert dcc.name == "Act/Act"


# Generated at 2022-06-21 20:14:53.185662
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc = DCC("act/360", set(), set(), None)
    assert dcc.calculate_daily_fraction(datetime.date(2008, 1, 1), datetime.date(2008, 1, 1), datetime.date(2008, 1, 1)) == Decimal("0")
    assert dcc.calculate_daily_fraction(datetime.date(2008, 1, 1), datetime.date(2008, 1, 2), datetime.date(2008, 1, 2)) == Decimal("0.00277777777777777777777777777777")

# Generated at 2022-06-21 20:15:00.936738
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    if not (DCCRegistry.find("act/act")):
        assert False
        ## print(DCCRegistry.find("act/act"))
    else:
        assert True
    if not (DCCRegistry.find("act/365")):
        #print("Expectedly fails")
        assert False
    else:
        assert True

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_DCCRegistryMachinery()

# Generated at 2022-06-21 20:15:13.068071
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    print('Testing dcfc_act_360()... ', end='')
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:15:18.122031
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-21 20:15:27.281862
# Unit test for method interest of class DCC
def test_DCC_interest():
	assert round(DCC.interest(DCC('act/360', {'act/360'}, {}, calculate_fraction_method), Money(1, 'USD'), 0.01, datetime.date(2014, 7, 15), datetime.date(2014, 12, 15), datetime.date(2014, 12, 15)),2) == Money(5.00, 'USD')
	assert round(DCC.interest(DCC('act/360', {'act/360'}, {}, calculate_fraction_method), Money(1, 'USD'), 0.01, datetime.date(2014, 7, 15), datetime.date(2014, 12, 15)),2) == Money(5.00, 'USD')

# Generated at 2022-06-21 20:15:39.276719
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    start = datetime.date(2017, 1, 31)
    asof = datetime.date(2017, 12, 31)
    end = datetime.date(2018, 1, 31)
    assert dcfc_30_360_isda(start, asof, end) == Decimal('1.08333333333333')
    start = datetime.date(2018, 2, 28)
    asof = datetime.date(2018, 6, 30)
    end = datetime.date(2018, 8, 31)
    assert dcfc_30_360_isda(start, asof, end) == Decimal('0.3')
    start = datetime.date(2018, 1, 27)
    asof = datetime.date(2018, 6, 30)
    end = datetime.date(2018, 8, 31)


# Generated at 2022-06-21 20:17:11.243996
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.10000000000000')

# Generated at 2022-06-21 20:17:19.359917
# Unit test for function dcfc_act_act

# Generated at 2022-06-21 20:17:30.115987
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-21 20:17:40.390173
# Unit test for constructor of class DCCRegistryMachinery

# Generated at 2022-06-21 20:17:44.476977
# Unit test for function dcc
def test_dcc():
    def a(a: Date, b: Date, c: Date, *args):
        pass

    a = dcc('hello')(a)
    assert a.__dcc.name == 'hello'



# Generated at 2022-06-21 20:17:54.516030
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Unit test for method calculate_fraction of class DCC.
    """
    def _test(name, start, asof, end, freq, expected, msg) -> None:
        print(f"Testing '{name}'...")
        ## Calculate:
        actual = DCCRegistry[name].calculate_fraction(start, asof, end, freq)
        ## Compare:
        assert expected == actual, msg

    ## Test cases:
    _test(
        "30/360 PS US", datetime.date(2017, 2, 1), datetime.date(2017, 3, 1), datetime.date(2017, 10, 1), None, Decimal(
            "0.0833"
        ),
        "30/360 PS US: February",
    )

# Generated at 2022-06-21 20:18:06.217853
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCC("Test", set(), set(), None)
    dcc2 = DCC("Test", set(), set(), None)
    dcc3 = DCC("Test3", set(), set(), None)
    dcc4 = DCC("Test4", set(["Test"]), set(), None)
    Registry = DCCRegistryMachinery()
    assert Registry._is_registered(dcc.name) == False
    Registry.register(dcc)
    assert Registry._is_registered(dcc.name) == True
    with pytest.raises(TypeError):
        Registry.register(dcc2)
    with pytest.raises(TypeError):
        Registry.register(dcc3)
    with pytest.raises(TypeError):
        Registry.register(dcc4)


# Generated at 2022-06-21 20:18:13.110523
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCRegistry["30/360"].coupon(Money(100, Currencies.USD), Decimal(0.06), datetime.date(2017,12,15), datetime.date(2017,12,31), datetime.date(2018,1,15), Decimal(1)) == Money(0.2, Currencies.USD)
    assert DCCRegistry["ACT/ACT"].coupon(Money(100, Currencies.USD), Decimal(0.06), datetime.date(2017,12,15), datetime.date(2017,12,31), datetime.date(2018,1,15), Decimal(1)) == Money(0.23, Currencies.USD)

# Generated at 2022-06-21 20:18:18.832902
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Define a method which returns base 36 representation of the method:
    def _to_base36(number):
        if not isinstance(number, int):
            raise TypeError('number must be an integer')
        if number < 0:
            raise ValueError('number must be positive')

        if number < 36:
            return base36[number]

        return _to_base36(number // 36) + base36[number % 36]

    # Define a method which returns base 36 number out of base 36 text representation:
    def _from_base36(number):
        return int(number, 36)

    # Define the base 36 digits:
    base36 = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    # Define the member test cases:

# Generated at 2022-06-21 20:18:23.338982
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ## Data:
    start_dates = [datetime.date(2007,12,28), datetime.date(2007,12,28), datetime.date(2007,10,31), datetime.date(2008,2,1)]
    asof_dates = [datetime.date(2008,2,28), datetime.date(2008,2,29), datetime.date(2008,11,30), datetime.date(2009,5,31)]
    dcfcs = [Decimal('0.16666666666667'),Decimal('0.16944444444444'),Decimal('1.08333333333333'),Decimal('1.33333333333333')]
    ## Test:

# Generated at 2022-06-21 20:21:15.507064
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert dcc.calculate_fraction(start, end, end) == Decimal("0.16942884946478")
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal("1694.29")
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal("0.00")


# Generated at 2022-06-21 20:21:25.786134
# Unit test for function dcc
def test_dcc():
    def dummy_dcc(x: int) -> float:
        pass

    assert hasattr(dummy_dcc, "__dcc")


#
# Actual DCCs registered.
#
# Note that DCC dicts and DCCRegistry are mutable. Therefore you are encouraged to NOT
# use `dccs = DCCRegistry.registry` unless you want to create a snapshot of the original
# registry and then play around with it. If you ever want to change anything in the main
# registry itself, please clone it first.
#



# Generated at 2022-06-21 20:21:34.642015
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    class_obj = DCC('name', 'altnames', 'currencies', 'calculate_fraction_method')
    principal = 100
    rate = Decimal(0.05)
    start = Date(datetime.date(2014,  1,  1))
    asof = Date(datetime.date(2014,  1,  1))
    end = Date(datetime.date(2014,  1,  1))
    freq = 1
    eom = None
    interest = class_obj.interest(principal, rate, start, asof, end or asof, freq)
    coupon_amount = class_obj.coupon(principal, rate, start, asof, end, freq, eom)
    assert coupon_amount == interest

    principal = Money.parse("USD 100")