

# Generated at 2022-06-21 20:12:23.459560
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert (round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) - Decimal('0.16986301369863')) < 1e-12
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert (round(dcfc_act_365_a(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) - Decimal('0.17213114754098')) < 1e-12
    ex3_start,

# Generated at 2022-06-21 20:12:34.247123
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    import pytest
    from hypothesis import example, given, settings
    from hypothesis.strategies import dates, decimals
    from datetime import date
    from fractional import Fraction

# Generated at 2022-06-21 20:12:43.263468
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """ Test function dcfc_30_e_360. """
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-21 20:12:49.505724
# Unit test for method register of class DCCRegistryMachinery

# Generated at 2022-06-21 20:13:01.554864
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    import unittest
    class Test_DCC_Act_365F(unittest.TestCase):
        def test_dcfc_act_365_f_1(self):
            ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
            self.assertAlmostEqual(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), Decimal('0.16986301369863'))
        def test_dcfc_act_365_f_2(self):
            ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-21 20:13:06.669324
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:13:18.073357
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("act/act").name == "Act/Act"
    assert DCCRegistry.find("Act/act").name == "Act/Act"
    assert DCCRegistry.find("Act/360").name == "Act/360"
    assert DCCRegistry.find("Act/365").name == "Act/365"
    assert DCCRegistry.find("Act/365 Nominal").name == "Act/365 Nominal"
    assert DCCRegistry.find("Act/366").name == "Act/366"
    assert DCCRegistry.find("act/365 fixed").name == "Act/365 Fixed"
    assert DCCRegistry.find("Act/365.25").name == "Act/365.25"

# Generated at 2022-06-21 20:13:29.851862
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """
    Test for function dcfc_act_act_icma
    """
    from utils.common import set_excel_style
    from utils.common import get_out_file
    from utils.common import write_excel

    # specify input parameters
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)

    # set output file path
    local_path = os.path.dirname(__file__)
    out_file, sheet_name = get_out_file(local_path, "test_act_act_icma")

    # write to excel
    excel_style = set_excel_style(11, 0, 0, 0)
   

# Generated at 2022-06-21 20:13:41.143704
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-21 20:13:53.103729
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2018, 1, 31), datetime.date(2018, 2, 28), datetime.date(2018, 2, 28)), 14) == Decimal("0.16666666666667")
    assert round(dcfc_30_360_isda(datetime.date(2018, 1, 31), datetime.date(2018, 2, 1), datetime.date(2018, 2, 28)), 14) == Decimal("0.16666666666667")
    assert round(dcfc_30_360_isda(datetime.date(2018, 1, 31), datetime.date(2018, 3, 1), datetime.date(2018, 3, 31)), 14) == Decimal("0.16666666666667")

# Generated at 2022-06-21 20:14:27.770749
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    d1 = datetime.date(2007, 12, 28)
    d2 = datetime.date(2008, 2, 29)
    actual = dcfc_30_360_german(start=d1, asof=d2, end=d2)
    assert round(actual, 15) == Decimal('0.16944444444444')
    expected = 0.16944444444444
    assert round(actual, 14) == Decimal(expected)



# Generated at 2022-06-21 20:14:38.869228
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.10000000000000')

# Generated at 2022-06-21 20:14:51.118848
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-21 20:14:59.380504
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    >>> o = DCC('test',set(),set(),_calculate_actual_day_fraction)
    >>> o.coupon(Money(10,'USD'),Decimal(0.1),datetime.date(2014,1,1),datetime.date(2014,1,1),datetime.date(2014,1,1),1)
    Money(10.00, USD)
    """


    DCC.coupon(ONE, ZERO, ONE, ONE, ONE, ONE)

# Generated at 2022-06-21 20:15:09.655637
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    import datetime
    test1 = dcfc_nl_365(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 28), end = datetime.date(2008, 2, 28))
    test2 = dcfc_nl_365(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 29), end = datetime.date(2008, 2, 29))
    return test1, test2


# Generated at 2022-06-21 20:15:14.710772
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:15:19.196466
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert Decimal(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof)) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:15:20.946549
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc = DCCRegistry.find("Act/Act")
    assert dcc == ACT_ACT



# Generated at 2022-06-21 20:15:28.924844
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 13) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 13) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 13) == Decimal('1.08219178082192')

# Generated at 2022-06-21 20:15:33.990020
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-21 20:16:28.188901
# Unit test for function dcc
def test_dcc():
    dcc("TestConvention", {"AlternativeName"})(lambda _: Decimal(1))
    assert DCCRegistry.find("TestConvention")
    assert DCCRegistry.find("AlternativeName")
    assert DCCRegistry.find("testconvention")

    try:
        dcc("TestConvention", {"AlternativeName"})(lambda _: Decimal(1))
        assert False
    except TypeError:
        assert True

    try:
        dcc("TestConvention", {"AlternativeName"})(lambda _: Decimal(1))
        assert False
    except TypeError:
        assert True

    try:
        dcc("TestConvention", {"AlternativeName"})(lambda _: Decimal(1))
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-21 20:16:32.732277
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    """
    Checks that the function dcfc_30_e_plus_360() computes the correct day count fraction for the "30E+/360" convention.
    """
    ex_start = datetime.date(2007, 12, 31)
    ex_asof  = datetime.date(2008, 12, 30)
    assert round(dcfc_30_e_plus_360(start=ex_start, asof=ex_asof, end=ex_asof),14) == Decimal('1.08333333333333')



# Generated at 2022-06-21 20:16:38.862328
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    ccy =  Currencies["USD"]
    curr = Decimal(str(ccy.factor))
    principal = Money(Decimal(10), ccy)
    dcc = DCCRegistry["30/360"]
    start = Date(2019, 6, 28)
    asof = Date(2019, 10, 30)
    end = Date(2019, 10, 30)
    assert dcc.coupon(principal, rate=Decimal('0.05'), start=start, asof=asof, end=end, freq=1, eom=None) == Money(Decimal('2.5555555555555E-2'), ccy)



# Generated at 2022-06-21 20:16:51.019703
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Get today's date:
    today = datetime.date.today()

    # Set the tolerance:
    tol = Decimal("0.000001")

    # Check the function with dates dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))
    assert abs(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) - Decimal("0.16942884946478")) < tol

    # Check the function with dates dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29))


# Generated at 2022-06-21 20:16:58.584726
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof),14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:17:10.084176
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-21 20:17:19.333732
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863'))

# Generated at 2022-06-21 20:17:25.139366
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert (dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal("0.16666666666667"))

# Generated at 2022-06-21 20:17:30.297191
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    assert(round(dcfc_act_act(start=start, asof=asof, end=asof), 14) == 0.16942884946478)



# Generated at 2022-06-21 20:17:40.494143
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==Decimal('0.17222222222222')

# Generated at 2022-06-21 20:18:44.635674
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ## Example 1:
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 6) == Decimal('0.166667')

    ## Example 2:
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 6) == Decimal('0.169444')

    ## Example 3:

# Generated at 2022-06-21 20:18:48.848538
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(
        start=datetime.date(2008, 3, 31), asof=datetime.date(2008, 4, 30), end=datetime.date(2008, 4, 30)
    ), 14) == Decimal("0.15555555555556")
    assert round(dcfc_30_360_german(
        start=datetime.date(2008, 3, 31), asof=datetime.date(2008, 5, 30), end=datetime.date(2008, 5, 30)
    ), 14) == Decimal("0.15555555555556")

# Generated at 2022-06-21 20:18:57.896928
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCCs["ACT/360"].calculate_daily_fraction(datetime.date(2013, 12, 31), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1)) == 0
    assert DCCs["ACT/365"].calculate_daily_fraction(datetime.date(2013, 12, 31), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1)) == 0
    assert DCCs["ACT/365F"].calculate_daily_fraction(datetime.date(2013, 12, 31), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1)) == 0


# Generated at 2022-06-21 20:19:08.028399
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .utils.synthetic import synthetic_callable
    from .utils.testing import assert_DCC
    from .utils.testing import get_event_asof
    from .utils.testing import get_event_start

    assert_DCC(DCC, name='MODIFIED_FOLLOWING', altnames=set(), currencies=set(), calculate_fraction_method=synthetic_callable(__name__, 'DCC.calculate_fraction_method'))
    assert_DCC(DCC, name='ACTUAL_360', altnames=set(), currencies=set(), calculate_fraction_method=synthetic_callable(__name__, 'DCC.calculate_fraction_method'))

# Generated at 2022-06-21 20:19:14.140370
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 20:19:24.968001
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    import sys, datetime, unittest

    class TestDcfcActAct(unittest.TestCase):
        def test_dcfc_act_act_ex1(self):
            ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
            self.assertEqual(Decimal('0.16942884946478'), dcfc_act_act(ex1_start, ex1_asof, ex1_asof))
        def test_dcfc_act_act_ex2(self):
            ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-21 20:19:34.164300
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcctypes = [dcc for dcc in DCCRegistry.registry if dcc.name.startswith("Act")]
    dcc = DCCRegistry.find("Act/Act")
    assert dcc in dcctypes, "'Act/Act' is not found in DCCRegistry"
    dcc = DCCRegistry.find("Act/Act".upper())
    assert dcc in dcctypes, "'Act/Act' is not found in DCCRegistry"
    dcc = DCCRegistry.find("Act/Act".lower())
    assert dcc in dcctypes, "'Act/Act' is not found in DCCRegistry"
    dcc = DCCRegistry.find("Act/Act".strip())
    assert dcc in dcctypes, "'Act/Act' is not found in DCCRegistry"


# Generated at 2022-06-21 20:19:46.574076
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-21 20:19:49.036467
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCCRegistry.find('Act/Act')
    assert dcc.name == 'Act/Act'
    assert 'Act/Act' in dcc.altnames


# Generated at 2022-06-21 20:20:00.483339
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    # Example 1:
    ex_start, ex_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex_end = ex_asof
    assert round(dcfc_act_360(start=ex_start, asof=ex_asof, end=ex_end), 14) == Decimal('0.17222222222222')
    
    # Example 2
    ex_start, ex_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex_end = ex_asof
    assert round(dcfc_act_360(start=ex_start, asof=ex_asof, end=ex_end), 14) == Decimal('0.17500000000000')

    # Example 3
   