

# Generated at 2022-06-21 20:12:41.792597
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), freq=2), 14) == Decimal(
        "0.083333333333333")
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), freq=2), 14) == Decimal(
        "0.0861111111111111")
    assert round(dcfc_30_360_us(start=datetime.date(2008, 2, 29), asof=datetime.date(2008, 5, 29), freq=2), 14) == Decimal(
        "0.0861111111111111")



# Generated at 2022-06-21 20:12:53.795961
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """


# Generated at 2022-06-21 20:13:01.872124
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    ## Setup:
    dcc = DCC("ACT/360", {"A/360"}, _as_ccys({"AED", "SAR"}), calculate_act_360)
    start = Date(2015, 1, 1)
    asof = Date(2015, 1, 2)
    end = Date(2015, 1, 3)

    ## Assert:
    assert dcc.calculate_daily_fraction(start, asof, end) == Decimal("0.002777778")



# Generated at 2022-06-21 20:13:06.997395
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dc = DCC('Actual/Actual', {'Actual/Actual ISDA', 'Act/Act ISDA', 'Act/Act', 'Actual/Actual', 'A/A ISDA', 'A/A', 'ISDA'}, {'BRL', 'CAD', 'CHF', 'EUR', 'GBP', 'HKD', 'JPY', 'KRW', 'MXN', 'USD', 'ZAR'}, lambda *args: Decimal(1.0))
    dc_reg = DCCRegistryMachinery()
    dc_reg.register(dc)
    assert dc_reg.find('Actual/Actual') == dc
    assert dc_reg.find('Act/Act ISDA') == dc
    assert dc_reg.find('Act/Act') == dc

# Generated at 2022-06-21 20:13:18.464597
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:13:30.202562
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(datetime.date(2019,6,28),datetime.date(2019,8,29),datetime.date(2019,8,29))==0.1666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666667
    assert dcfc_30_360_isda(datetime.date(2018,12,28),datetime.date(2019,2,28),datetime.date(2019,2,28))==0.1666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666667
    assert dcfc_30_360_isda(datetime.date(2018,12,28),datetime.date(2019,2,28),datetime.date(2019,2,28))==0.1666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666667
   

# Generated at 2022-06-21 20:13:37.121923
# Unit test for constructor of class DCC
def test_DCC():
    dcc = DCC(name="tname", altnames=["aname"], currencies=['USD'], calculate_fraction_method=_calculate_act_365_fraction)

    assert dcc.name == "tname"
    assert dcc.altnames == {'aname'}
    assert dcc.currencies == {Currencies['USD']}
    assert dcc.calculate_fraction_method == _calculate_act_365_fraction



# Generated at 2022-06-21 20:13:45.789505
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof, ex1_freq = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), 2
    ex2_start, ex2_asof, ex2_freq = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), 2
    ex3_start, ex3_asof, ex3_freq = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), 2
    ex4_start, ex4_asof, ex4_freq = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), 2
    # Test 1

# Generated at 2022-06-21 20:13:54.623878
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    ## Test if DCCRegistryMachinery is a class
    assert inspect.isclass(DCCRegistryMachinery)
    ## Test if DCCRegistryMachinery's instance is an instance
    ## of DCCRegistryMachinery
    assert isinstance(DCCRegistryMachinery(), DCCRegistryMachinery)
    ## Test if DCCRegistryMachinery's instance is an instance of object
    assert isinstance(DCCRegistryMachinery(), object)
    ## Test if DCCRegistryMachinery is a subclass of object
    assert issubclass(DCCRegistryMachinery, object)
    ## Test if DCCRegistryMachinery is a subclass of object
    assert not issubclass(DCCRegistryMachinery, DayCountConvention)
    ## Test if DCCRegistryMachinery is a subclass of object

# Generated at 2022-06-21 20:14:05.791595
# Unit test for function dcc
def test_dcc():
    def func(a,b,c,d=None):
        pass

    dcc = dcc("dcc", None, None)
    dcc(func)
    return func.__dcc.name



# Generated at 2022-06-21 20:14:28.546470
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')



# Generated at 2022-06-21 20:14:39.384926
# Unit test for function dcfc_nl_365

# Generated at 2022-06-21 20:14:44.390109
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    dates = [datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)]
    expected = [Decimal('0.16986301369863'), Decimal('0.16986301369863'), Decimal('0.17213114754098'), Decimal('1.32513661202186'),Decimal('1.32513661202186')]
    epsilon = 0.00001
    i = 0
    while i < 5:
        val = dcfc_act_365_a(dates[0], dates[i], dates[i])
        assert expected[i] - val < epsilon
        i += 1



# Generated at 2022-06-21 20:14:50.381679
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    #
    # TODO: Improve the test cases.
    #
    assert round(dcfc_30_e_360(datetime.date(2014,5,5),datetime.date(2014,5,5)),14) == 0.0
    assert round(dcfc_30_e_360(start=datetime.date(2016,11,30),asof=datetime.date(2016,12,2)),14) == 0.0083333333333333
    assert round(dcfc_30_e_360(start=datetime.date(2016,11,30),asof=datetime.date(2017,1,2)),14) == 0.083333333333334

# Generated at 2022-06-21 20:14:52.535698
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    if __name__ == "__main__":
        main()


# Generated at 2022-06-21 20:14:56.674149
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    #print(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof))
    #print(dcfc_30_360_us(start=ex2_start

# Generated at 2022-06-21 20:15:03.209808
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert (DCC("name", set("altnames"), _as_ccys({"ccy"}), lambda a,b,c,d: 0).interest(
        Money("1", Currencies.USD),
        Decimal("1.0"),
        datetime.date(1970, 1, 1),
        datetime.date(1970, 1, 1),
        Decimal("1.0")
        ) == Money("1.0", Currencies.USD))
test_DCC_interest()



# Generated at 2022-06-21 20:15:14.448553
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Checks the calculation of daily fraction.
    """
    # pylint: disable=bad-whitespace
    ##
    ## Constant:
    ##

    eom = 15

    ##
    ## DEF-30/360
    ##
    start = datetime.date(2017, 1, 1)
    end   = datetime.date(2017, 1, 1)
    #
    asof  = datetime.date(2017, 1, 1)
    assert DCCRegistry.get("DEF-30/360").calculate_daily_fraction(start, asof, end) == ZERO
    #
    asof  = datetime.date(2017, 1, 2)
    assert DCCRegistry.get("DEF-30/360").calculate_daily_fraction(start, asof, end) == Dec

# Generated at 2022-06-21 20:15:19.056243
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_e_360

# Generated at 2022-06-21 20:15:27.682672
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14)==Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14)==Decimal('1.10000000000000')

# Generated at 2022-06-21 20:15:51.136349
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == round(Decimal('0.16986301369863'), 14)
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == round(Decimal('0.16986301369863'), 14)
    assert round(dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == round(Decimal('1.08219178082192'), 14)

# Generated at 2022-06-21 20:16:02.108213
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007,12,28),asof=datetime.date(2008,2,28),end=datetime.date(2008,2,28)),14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start=datetime.date(2007,12,28),asof=datetime.date(2008,2,29),end=datetime.date(2008,2,29)),14) == Decimal('0.17500000000000')
    assert round(dcfc_act_360(start=datetime.date(2007,10,31),asof=datetime.date(2008,11,30),end=datetime.date(2008,11,30)),14) == Decimal('1.10000000000000')


# Generated at 2022-06-21 20:16:12.103147
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-21 20:16:24.003275
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal = Money(100.0, "EUR")
    rate = Decimal(0.05)
    start = Date(datetime.date(2008, 5, 28))
    asof = Date(datetime.date(2008, 6, 2))
    end = Date(datetime.date(2008, 7, 28))
    freq = Decimal(2)
    eom = None
    assert DCC(name="name", altnames=set(), currencies=set(), calculate_fraction_method=lambda a,b,c,d: Decimal(0))\
           .coupon(principal, rate, start, asof, end, freq, eom) == Money(0.2041666666, "EUR")


# Generated at 2022-06-21 20:16:34.277511
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1 = datetime.date(2005, 1, 30), datetime.date(2005, 2, 28)
    ex2 = datetime.date(2005, 1, 30), datetime.date(2005, 3, 30)
    ex3 = datetime.date(2005, 1, 30), datetime.date(2005, 2, 28)
    ex4 = datetime.date(2005, 1, 31), datetime.date(2005, 2, 28)
    ex5 = datetime.date(2005, 1, 31), datetime.date(2005, 3, 31)
    ex6 = datetime.date(2005, 1, 31), datetime.date(2005, 2, 28)
    ex7 = datetime.date(2005, 2, 28), datetime.date(2005, 3, 31)

# Generated at 2022-06-21 20:16:43.984230
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08219178082192')

# Generated at 2022-06-21 20:16:49.682910
# Unit test for method interest of class DCC
def test_DCC_interest():
    import datetime

    assert DCC("Actual/Actual ICMA", {}, {}, afb).interest(Money("USD", 1.0), 0.05, datetime.date(2000, 3, 1), datetime.date(2000, 12, 31)) == Money("USD", 0.05684586288601062)


# Generated at 2022-06-21 20:16:57.736822
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    def test(F,T,result):
        assert result==round(F(start=T[0], asof=T[1], end=T[1]), 14), "Test "+str(T)+" Failed"

# Generated at 2022-06-21 20:17:09.630077
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    """
    Unit test for function dcfc_30_e_plus_360

    :return: None.
    :raises: AssertionError - when the function does not return the correct result.
    """
    start1 = datetime.date(2007, 12, 28)
    start2 = datetime.date(2007, 12, 28)
    start3 = datetime.date(2007, 10, 31)
    start4 = datetime.date(2008, 2, 1)

    asof1 = datetime.date(2008, 2, 28)
    asof2 = datetime.date(2008, 2, 29)
    asof3 = datetime.date(2008, 11, 30)
    asof4 = datetime.date(2009, 5, 31)


# Generated at 2022-06-21 20:17:19.025804
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # Test case 1:
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    assert round(dcfc_30_e_360(start, asof), 14) == Decimal('0.16666666666667')
    # Test case 2:
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)
    assert round(dcfc_30_e_360(start, asof), 14) == Decimal('0.16944444444444')
    # Test case 3:
    start = datetime.date(2007, 10, 31)
    asof = datetime.date(2008, 11, 30)

# Generated at 2022-06-21 20:17:59.122474
# Unit test for method interest of class DCC
def test_DCC_interest():
    start = datetime.date(2020, 1, 23)
    asof = datetime.date(2020, 2, 5)
    end = asof
    principal = Money(50, Currencies.USD)
    rate = Decimal(1)
    dcc = DCC("ACT/ACT", set(), set(), _calculate_act_act_fraction)
    expected = Money(1.267, Currencies.USD)
    calculated = dcc.interest(principal, rate, start, asof, end)
    assert calculated == expected

# Generated at 2022-06-21 20:18:08.893317
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(
        datetime.date(2007, 12, 28),
        datetime.date(2008, 2, 28),
        datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_f(
        datetime.date(2007, 12, 28),
        datetime.date(2008, 2, 29),
        datetime.date(2008, 2, 29)), 14) == Decimal('0.17260273972603')

# Generated at 2022-06-21 20:18:19.754427
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    """
    Note: (1) This test was copied from the library: fintools:
    https://github.com/Fintools/fintools, by Mathieu Fauvel.

    (2) Comments were added to the original, but all the credit should go
    to Mathieu Fauvel.
    """
    ## Create the test dates, and the expected values:

# Generated at 2022-06-21 20:18:29.224857
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    format_str = '{:<28} {:<28} {:<14} : {:<14}'
    print(format_str.format('Start Date', 'End Date', 'Actual', 'Expected'))
    format_str = '{:<28} {:<28} {:<14.14f} : {:<14.14f}'

# Generated at 2022-06-21 20:18:40.299374
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    """
    Unit tests for function dcfc_30_e_plus_360
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:18:49.464739
# Unit test for function dcc
def test_dcc():
    """
    Unit test for function dcc
    """
    from .money import Money
    from .currencies.iso4217 import Currencies
    from .currencies.currency import Currency
    
    @dcc( "MYDCC", ccys=  { Currencies['USD'] } )
    def mydcc(start, asof, end, freq):
        return Decimal(1.0)

    principal = Money.of( Currencies["USD"], Decimal(1000000), datetime.date.today())
    rate = Decimal(0.01)
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)

    # test that DCCRegistry.find works
    dcc = DCCRegistry

# Generated at 2022-06-21 20:18:58.504406
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Tests for method coupon of class DCC.
    """
    from .currencies import Currencies

    from .enums import DCCs

    from .monetary import Money

    ## Init:
    principal = Money(100_000, Currencies.USD)
    rate = Decimal(0.005)
    start = Date(2014, 12, 15)
    asof = Date(2020, 8, 24)
    end = Date(2024, 12, 15)
    freq = Decimal(2)
    eom = 15

    ## Calculate the coupon:
    coupon1 = DCCs.ACT30360.coupon(principal, rate, start, asof, end, freq, eom)

# Generated at 2022-06-21 20:19:05.680651
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    print(round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10))



# Generated at 2022-06-21 20:19:13.682225
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    start = datetime.date(2008, 7, 1)
    asof = datetime.date(2008, 12, 31)
    end = datetime.date(2009, 7, 1)
    freq = 2
    eom = 1
    principal = Money("1000.00", "USD")
    rate = Decimal("0.0500")
    ai = principal * rate * DCCRegistry.find("ACT/ACT").calculate_fraction(start, asof, end, Decimal(freq))
    assert (
        DCCRegistry.find("ACT/ACT").coupon(principal, rate, start, asof, end, Decimal(freq), 1)
        == ai
    ), "DCC.coupon failed"


# Generated at 2022-06-21 20:19:24.351109
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    print("test_dcfc_act_365_f()")
    ex1_start, ex1_asof = datetime.date(2008, 5, 1), datetime.date(2008, 5, 2)
    ex2_start, ex2_asof = datetime.date(2008, 5, 1), datetime.date(2008, 7, 1)
    ex3_start, ex3_asof = datetime.date(2008, 5, 1), datetime.date(2008, 5, 31)
    ex4_start, ex4_asof = datetime.date(2008, 5, 1), datetime.date(2009, 5, 1)
    ex5_start, ex5_asof = datetime.date(2008, 5, 1), datetime.date(2010, 5, 1)
    ex6_start, ex

# Generated at 2022-06-21 20:19:52.359023
# Unit test for function dcc
def test_dcc():
    @dcc("Act/Act", {"Actual/Actual", "Actual/365", "Actual/360", "A/A", "A/365", "A/360"})
    def dcfc_act_act(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return Decimal((asof - start).days) / Decimal((end - start).days)

    assert dcfc_act_act(datetime.date(2014, 1, 1), datetime.date(2015, 8, 1), datetime.date(2016, 1, 1)) == Decimal("0.49315068493151")

# Generated at 2022-06-21 20:20:03.848772
# Unit test for function dcc
def test_dcc():
    ## Initialize the DCC registry:
    DCCRegistry.__init__()

    ## Define a dummy DCC with alternate names:
    alt_names = {"some-alt-name", "another-alt-name"}

    ## Define the dummy DCFC which uses the dummy DCC:
    @dcc("Some Name", alt_names, {"TRY", "USD"})
    def dummy_dcfc(*args):
        pass

    ## Check if the DCFC can be found under the main name:
    assert DCCRegistry.find("Some Name") == DCCRegistry.find(f"  {dummy_dcfc.__dcc.name}  ")

    ## Check if the DCFC can be found under the alternate names:
    for altname in alt_names:
        assert DCCRegistry.find(altname)

# Generated at 2022-06-21 20:20:13.562245
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-21 20:20:19.615853
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["A360"].calculate_fraction(datetime.date(2020, 1, 1), datetime.date(2020, 3, 31), datetime.date(2022, 6, 30)) == 0.25
    assert DCCRegistry["A365"].calculate_fraction(datetime.date(2020, 1, 1), datetime.date(2020, 3, 31), datetime.date(2022, 6, 30)) == 0.25
    assert DCCRegistry["ISMA"].calculate_fraction(datetime.date(2020, 1, 1), datetime.date(2020, 3, 31), datetime.date(2022, 6, 30), Decimal(2)) == Decimal(0.23943661971831)
    assert DCCRegistry["30360E"].calcul

# Generated at 2022-06-21 20:20:23.387328
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert round(dcfc_act_360(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,28), end=datetime.date(2008,2,28)), 14) == Decimal('0.17222222222222')



# Generated at 2022-06-21 20:20:26.796619
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    assert round(dcfc_act_360(start, end), 15) == Decimal('0.17222222222222')



# Generated at 2022-06-21 20:20:32.076629
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    """
    Tests the function dcfc_act_365_a.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:20:37.654572
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    # The "Act/Act (ICMA)" convention is the same as "Act/Act" convention with a frequency parameter
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    freq = Decimal(4)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end, freq=freq), 10) == \
           round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_end, freq=freq), 10)




# Generated at 2022-06-21 20:20:46.685974
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    '''
    This is a string-based unit test for the function dcfc_act_365_a
    '''
    test_tuple = (
        ((datetime.date(2019, 3, 2), datetime.date(2020, 2, 28)), 365/365),
        ((datetime.date(2019, 3, 2), datetime.date(2020, 2, 29)), 366/365),
        ((datetime.date(2019, 2, 28), datetime.date(2020, 3, 2)), 366/365),
        ((datetime.date(2019, 2, 28), datetime.date(2020, 3, 7)), 372/365),
        ((datetime.date(2019, 2, 28), datetime.date(2020, 3, 8)), 373/365),
    )

# Generated at 2022-06-21 20:20:57.541963
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    start_date = datetime.date(2007, 12, 28)
    end_date = datetime.date(2008, 2, 28)
    assert round(dcfc_act_360(start_date, start_date, end_date), 14) == Decimal('0.17222222222222')
    assert round(dcfc_act_360(start_date, end_date, end_date), 14) == Decimal('0.17222222222222')

