

# Generated at 2022-06-21 20:12:20.550894
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == Decimal('0.16939890710383')
    assert dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) == Decimal('0.17213114754098')
    assert dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)) == Decimal('1.08196721311475')

# Generated at 2022-06-21 20:12:32.207399
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    from numbers import Number

    from prague.math import _is_number, approx

    from pepy.domain.money import Money

    from q1.mth.daycountconvention import DCC, DCCRegistryMachinery, DCC_ACTACT, DCC_30360

    with pytest.raises(TypeError):
        DCCRegistryMachinery().register(DCC_ACTACT)

    m: Money = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    assert approx(_is_number(DCC_ACTACT.interest(m, Decimal(0.01), datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)).qty))

# Generated at 2022-06-21 20:12:44.916849
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_act_365_f(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17260273972603')


# Generated at 2022-06-21 20:12:50.776780
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    """
    Unit test for function dcfc_act_365_a
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:13:00.110452
# Unit test for method interest of class DCC
def test_DCC_interest():
    """
    Tests the interest method of class DCC
    """
    # Taken from example in https://www.rapidtables.com/calc/finance/accrued-interest-calculator.html
    # Accrued interest from January 1, 2015 to April 2, 2015 
    assert DCCRegistry.get('actual/actual').interest(Money(10000.00,'EUR'), Decimal(0.04), datetime.date(2015, 1, 1), datetime.date(2015, 4, 2)) == Money(1016.93,'EUR')
    
    
    
    

# Generated at 2022-06-21 20:13:08.535412
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    import unittest
    from qbundle.model.dcc import DayCountConventions

    class TestDCCRegistryMachinery(unittest.TestCase):
        def test_find(self):
            registry = DCCRegistry()
            registry.register(DayCountConventions.ACT_365)
            registry.register(DayCountConventions.ACT_360)
            registry.register(DayCountConventions.ACT_ACT)
            self.assertEqual(
                str(registry.find("Act_365")),
                "DCC(name='ACT/365', altnames={'ACT365', 'ACT/365', 'ACT_365'}, currencies={}, calculate_fraction_method=<function _act_act_fraction at 0x7f7c4c4f4a60>)"
            )
            self.assertEqual

# Generated at 2022-06-21 20:13:19.478800
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 3, 31)), 14) == 0.16666666666666666
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 3, 31)), 14) == 0.16944444444444444
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008, 12, 31)), 14) == 1.0833333333333333



# Generated at 2022-06-21 20:13:30.340518
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Tests the find method of class DCCRegistryMachinery.
    """
    # Setup the registry:
    dcc = DCC(name="Act/Act", altnames={"Actual/Actual"}, currencies=set(), calculate_fraction_method=lambda: Decimal(0))
    obj = DCCRegistryMachinery()
    obj.register(dcc)

    # Test the find method:
    assert obj.find("Act/Act") == dcc
    assert obj.find("Actual/Actual") == dcc
    assert obj.find("Actual/Actual ".strip()) == dcc
    assert obj.find("Actual/Actual ".upper()) == dcc
    assert obj.find("Act/Act ".strip()) == dcc
    assert obj.find("Act/Act ".upper()) == dcc
    assert obj

# Generated at 2022-06-21 20:13:39.173825
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    print("Testing daycount_fraction_calculator.dcfc_30_360_isda...")

    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:13:47.036214
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCC("A", set(), set(), DCFC).calculate_daily_fraction(
        datetime.date(2014, 1, 1),
        datetime.date(2014, 1, 31),
        datetime.date(2014, 5, 31),
        2
    ) == 0

    assert DCC("A", set(), set(), DCFC).calculate_daily_fraction(
        datetime.date(2014, 1, 1),
        datetime.date(2014, 2, 1),
        datetime.date(2014, 5, 1),
        2
    ) == 0.25


# Generated at 2022-06-21 20:14:14.509556
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert dcfc_act_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.17222222222222')
    assert dcfc_act_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.17500000000000')
    assert dcfc_act_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.10000000000000')

# Generated at 2022-06-21 20:14:17.224287
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc_registry = DCCRegistryMachinery()
    assert hasattr(dcc_registry, 'find')
    assert callable(dcc_registry.find)

# Generated at 2022-06-21 20:14:23.955216
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    """
    Tests the dcfc_act_365_f function.
    """
    ## Given
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    ex2_start, ex2_asof, ex2_end = datetime.date(2019, 1, 2), datetime.date(2019, 9, 10), datetime.date(2020, 1, 2)
    ex3_start, ex3_asof, ex3_end = datetime.date(2019, 9, 2), datetime.date(2019, 9, 10), datetime.date(2020, 9, 2)
    ex4_start, ex4_asof, ex4_end = datetime.date

# Generated at 2022-06-21 20:14:28.270615
# Unit test for function dcc
def test_dcc():
    ## Should not raise any exceptions:
    @dcc("Act/Act")
    def func(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None):
        pass

    ## Check if the attributes are there:
    assert hasattr(func, '__dcc')
    assert func.__dcc.name == 'Act/Act'
    assert func.__dcc.altnames == set([])
    assert func.__dcc.currencies == set([])
    assert func.__dcc.calculate_fraction_method is func


# Generated at 2022-06-21 20:14:39.383744
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Test dcfc_30_e_360.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-21 20:14:51.986125
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    print("\n=== Test function dcfc_act_act ===\n")

    # Test cases

# Generated at 2022-06-21 20:15:02.599885
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Unit test for method coupon of class DCC
    """
    DCC_obj=DCC('Actual/Actual (ISMA)',set(),set(),lambda a, b, c, d: ZERO)
    principal = Money(1,'USD')
    rate = Decimal('0.01')
    start = Date(2017,1,1)
    asof = Date(2017,1,2)
    end = Date(2017,1,3)
    freq = Decimal('1')
    eom = 1
    value_expected = Money(0.01,'USD')
    value_result = DCC_obj.coupon(principal,rate,start,asof,end,freq,eom)
    assert value_expected == value_result

# Generated at 2022-06-21 20:15:08.714117
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:15:20.127517
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert Decimal(round(dcfc_act_act_icma(start=datetime.date(2020, 6, 2), asof=datetime.date(2020, 12, 1), end=datetime.date(2021, 6, 2),
                                           freq=2), 10)) == Decimal('0.6575342466')
    assert Decimal(round(dcfc_act_act_icma(start=datetime.date(2020, 6, 2), asof=datetime.date(2020, 12, 1), end=datetime.date(2021, 6, 2),
                                           freq=1), 10)) == Decimal('0.6594550402')

# Generated at 2022-06-21 20:15:28.405826
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    ## Define the main registry buffer:
    DCCRegistryMachinery._buffer_main: Dict[str, DCC] = {}

    ## Defines the registry buffer for alternative DCC names:
    DCCRegistryMachinery._buffer_altn: Dict[str, DCC] = {}

    ## Define the day count convention:
    dcc = DCC("Act/Act", {"Actual/actual", "Actual/Actual", "ActualActual", "ActAct", "Act/act", "Act/Act"}, {},
              calculate_fraction_method=calculate_act_act_fraction)
    DCCRegistry.register(dcc)
    assert DCCRegistry.find('Act/Act') == dcc
    assert DCCRegistry.find('Actual/Actual') == dcc
    assert D

# Generated at 2022-06-21 20:16:39.967388
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal(0.16666666666667)
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal(0.16944444444444)
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-21 20:16:52.088006
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:16:56.135749
# Unit test for function dcc
def test_dcc():
    assert len(DCCRegistry.registry) == 0
    @dcc("Test/Act", ccys={Currencies["CHF"], Currencies["EUR"]})
    def test_dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return ZERO
    assert len(DCCRegistry.registry) == 1
    dcc = DCCRegistry.find("Test/Act")
    assert dcc.name == "Test/Act"
    assert dcc.calculate_fraction_method.__name__ == "test_dcfc"
    assert dcc.calculate_fraction_method.__module__ == "__main__"

# Generated at 2022-06-21 20:17:02.218507
# Unit test for function dcc
def test_dcc():
    ## Define some constants:
    epsilon = Decimal("0.000000000000001")
    start_date = datetime.date(2007, 12, 28)
    end_date = datetime.date(2008, 1, 20)
    test_value = Decimal("0.0085")

    ## Define the test function:
    @dcc("Test Convention", set())
    def test_dcfc(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        """
        Test day count fraction calculator that returns the test value.
        """
        return test_value

    ## Make sure that it succeeds:
    assert test_dcfc(start_date, end_date, end_date) == test_value

# Generated at 2022-06-21 20:17:06.661178
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    print("\nRunning unit test for method register of class DCCRegistryMachinery\n")

# Generated at 2022-06-21 20:17:17.156165
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert 0.166666666667 == round(dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), \
        datetime.date(2008, 2, 28)),14)
    assert 0.1694444444444 == round(dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), \
        datetime.date(2008, 2, 29)),14)
    assert 1.0833333333333 == round(dcfc_30_e_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), \
        datetime.date(2008, 11, 30)),14)

# Generated at 2022-06-21 20:17:28.382250
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-21 20:17:30.380761
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    dat1 = datetime.date(2018, 1, 31)
    dat2 = datetime.date(2018, 2, 28)
    print(dcfc_30_360_german(start=dat1, asof=dat2, end=dat2))



# Generated at 2022-06-21 20:17:36.025357
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    name = 'Act/Act'
    altnames = {'Act', 'Act/Act ISMA 99'}
    currencies = {Currencies['USD']}
    calculate_fraction_method = calculate_act_act_fraction
    dcc = DCC(name, altnames, currencies, calculate_fraction_method)
    registry = DCCRegistryMachinery()
    registry.register(dcc)



# Generated at 2022-06-21 20:17:44.129519
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start = date(2007, 12, 28)
    ex1_asof = date(2008, 2, 28)
    ex_dcf = dcfc_act_365_a(ex1_start, ex1_asof, ex1_asof)
    assert round(ex_dcf, 14) == Decimal('0.16986301369863')

    ex2_start = date(2007, 12, 28)
    ex2_asof = date(2008, 2, 29)
    ex_dcf = dcfc_act_365_a(ex2_start, ex2_asof, ex2_asof)
    assert round(ex_dcf, 14) == Decimal('0.17213114754098')

    ex3_start = date(2007, 10, 31)
    ex3

# Generated at 2022-06-21 20:19:13.462611
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert (dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16942884946478'))
    assert (dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.17216108990194'))
    assert (dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08243131970956'))

# Generated at 2022-06-21 20:19:22.102278
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    e1_start = datetime.date(2019, 3, 2)
    e1_asof = datetime.date(2019, 9, 10)
    e1_end = datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=e1_start, asof=e1_asof, end=e1_end), 10) == Decimal('0.5245901639')
    print('Test passed!')

test_dcfc_act_act_icma()



# Generated at 2022-06-21 20:19:25.467023
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    a = DCCRegistryMachinery()
    assert a._buffer_main == {}
    assert a._buffer_altn == {}
    assert a.find("Act/Act") is None


# Generated at 2022-06-21 20:19:34.510658
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2020,9,10), datetime.date(2020, 9, 20), datetime.date(2020, 9, 20)),14) == round(Decimal('0.095890410958904'),14)
    assert round(dcfc_act_365_l(datetime.date(2020,9,10), datetime.date(2020, 9, 20), datetime.date(2020, 9, 20)),1) == round(Decimal('0.095890410958904'),1)



# Generated at 2022-06-21 20:19:46.663311
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    assert_equal(round(dcfc_act_360(datetime.date(2020,  1, 30), datetime.date(2020, 2, 29), datetime.date(2020, 3, 31)), 14), Decimal('0.097222222222222'))
    assert_equal(round(dcfc_act_360(datetime.date(2020,  1, 30), datetime.date(2020, 2, 29), datetime.date(2020, 3, 30)), 14), Decimal('0.086111111111111'))
    assert_equal(round(dcfc_act_360(datetime.date(2020,  1, 30), datetime.date(2020, 2, 29), datetime.date(2020, 3, 29)), 14), Decimal('0.075000000000000'))

# Generated at 2022-06-21 20:19:57.037830
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17260273972603')
    assert round(dcfc_act_365_f(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08493150684932')

# Generated at 2022-06-21 20:20:02.148601
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == round(Decimal('0.16666666666667'), 14)
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == round(Decimal('0.16944444444444'), 14)

# Generated at 2022-06-21 20:20:11.027582
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    # register a DCC which has no altnames, currencies
    namedtuple = DCC('Act/Act', {}, {}, lambda x, y, z, w: w)
    machinery = DCCRegistryMachinery()
    machinery.register(namedtuple)
    assert machinery._is_registered('Act/Act') == True
    assert machinery.find('Act/Act') == namedtuple
    assert machinery._is_registered('alt') == False
    assert machinery.find('alt') == None
    assert machinery.registry == [namedtuple]
    assert machinery.table['Act/Act'] == namedtuple


# Generated at 2022-06-21 20:20:23.495053
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    '''
    Test function dcfc_30_e_360 with
    test values from http://www.isda.org/c_and_a/pdf/mktc1198.pdf
    '''
    assert dcfc_30_e_360(datetime.date(1996, 1, 15), datetime.date(1996, 2, 14), datetime.date(1996, 2, 14)) == Decimal('0.166666666666667')
    assert dcfc_30_e_360(datetime.date(1996, 1, 15), datetime.date(1996, 2, 13), datetime.date(1996, 2, 13)) == Decimal('0.166666666666667')

# Generated at 2022-06-21 20:20:32.489244
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    DCCRegistry.register(DCC("Act/Act", {"ActAct", "Actual/Actual"}, {}, dcc_actact))
    DCCRegistry.register(DCC("ActAct", {"ActAct", "ActAct"}, {}, dcc_actact))
    assert DCCRegistry.find("ActAct") is not None
    assert DCCRegistry.find("IbnAct/Act") is not None
    assert DCCRegistry.find("ActActual/ActActual") is None


## Register day count conventions:
DCCRegistry.register(DCC("Act/Act", {"ActAct", "ActActual/ActActual"}, {}, dcc_actact))
DCCRegistry.register(DCC("Act/360", {"Act360"}, {}, dcc_act360))