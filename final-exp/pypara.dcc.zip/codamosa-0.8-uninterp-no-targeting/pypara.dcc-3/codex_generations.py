

# Generated at 2022-06-21 20:12:10.663963
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    # TODO: write unit tests for all methods of class DCCRegistryMachinery
    # TODO: test all of the methods of class DCC
    # TODO: write unit tests for all methods of class DCCRegistry
    dccRegistryMachinery = DCCRegistryMachinery()

# Generated at 2022-06-21 20:12:23.567417
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    cases = (
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), Decimal('0.16666666666667')),
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), Decimal('0.16944444444444')),
        (datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), Decimal('1.08333333333333')),
        (datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), Decimal('1.33333333333333')),
        )


# Generated at 2022-06-21 20:12:34.342888
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(start=Date(2006, 1, 31), asof=Date(2006, 6, 30), end=Date(2006, 6, 30)) == decimal.Decimal('0.50000000000000')
    assert dcfc_30_e_360(start=Date(2006, 1, 31), asof=Date(2006, 5, 31), end=Date(2006, 5, 31)) == decimal.Decimal('0.40000000000000')
    assert dcfc_30_e_360(start=Date(2006, 1, 30), asof=Date(2006, 5, 30), end=Date(2006, 5, 30)) == decimal.Decimal('0.33333333333333')

# Generated at 2022-06-21 20:12:43.465625
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    DCCRegistryMachinery()


## Day count registry for the package:
DCCRegistry = DCCRegistryMachinery()

## Register day count conventions to the registry:
register_dcc(DCC("30E/360", {"30/360E", "30/360 European", "30E/360", "30/360E"}, {Currencies["USD"]}, dcc_30e360))
register_dcc(DCC("30E/360ISDA", {"30/360E", "30/360 European", "30E/360", "30/360E"}, {Currencies["USD"]}, dcc_30e360isda))
register_dcc(DCC("30E+/360", {"30/360E", "30E+/360", "30/360E"}, {Currencies["USD"]}, dcc_30ep360))


# Generated at 2022-06-21 20:12:50.506863
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')

# Generated at 2022-06-21 20:12:54.301500
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    from proj.calc import dcfc_30_e_360, BizDayConv, Date
    assert dcfc_30_e_360(start=Date(1,1,2018), asof=Date(30,12,2018), end=Date(30,12,2018))==Decimal('1.0')
    assert dcfc_30_e_360(start=Date(1,1,2018), asof=Date(31,12,2018), end=Date(31,12,2018), freq=Decimal('2'))==Decimal('0.983333333')

# Generated at 2022-06-21 20:13:05.531087
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    import math
    import datetime
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert math.isclose(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 0.16986301369863)


# Generated at 2022-06-21 20:13:16.702596
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # No day count convention is registered at the start.
    # Assert that len(DCCRegistry.transient.registry) == 0
    assert len(DCCRegistry.transient.registry) == 0

    # The given day count convention is added to the registry.
    # Call DCCRegistry.register(DCC(name = "Act/365", altnames = {"ACT/365", "act/365", "Act/365F"}, currencies = set(), calculate_fraction_method = lambda start, asof, end, frequency: ZERO))

# Generated at 2022-06-21 20:13:28.788872
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    ## Define a DCC:
    dcc1 = DCC("Actual/Actual", {"Act/Act", "ISDA"}, {Currencies["USD"]}, _actact)
    dcc2 = DCC("30/360", {"30/360"}, {Currencies["USD"]}, _thrthr)

    ## Create a new model:
    model = DCCRegistryMachinery()

    ## Register the DCCs:
    model.register(dcc1)
    model.register(dcc2)

    ## Check if we can find the DCCs properly:
    assert model.find("Actual/Actual") == dcc1
    assert model.find("Act/Act") == dcc1
    assert model.find("ISDA") == dcc1
    assert model.find("30/360") == dcc2

   

# Generated at 2022-06-21 20:13:33.517324
# Unit test for function dcc
def test_dcc():
    # Test registering a DCC which has its name already registered before:
    try:
        dcc('Act/Act/365')(lambda x, y, z, _: x)
    except TypeError:
        pass
    else:
        raise Exception('`dcc` function did not raise TypeError when an already registered name is given.')


# Generated at 2022-06-21 20:14:09.736916
# Unit test for method interest of class DCC
def test_DCC_interest():
    # Check that correct interest rate is returned for DCC 30u/360
    principal = Money(amount=ZERO, currency=Currencies.USD)
    start = Date(2004, 2, 1)
    asof = Date(2004, 2, 29)
    end = Date(2004, 3, 1)
    rate = Decimal(0.12)
    dcc = DCCRegistry.get_convention(name="30u/360")
    interest = dcc.interest(principal=principal, rate=rate, start=start, asof=asof, end=end)
    interest_expected = principal * rate * dcc.calculate_fraction(start=start, asof=asof, end=end)
    assert interest == interest_expected

# Generated at 2022-06-21 20:14:19.143999
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == round(Decimal('0.16986301369863'), 14)
    assert round(dcfc_act_365_f(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == round(Decimal('0.17260273972603'), 14)

# Generated at 2022-06-21 20:14:30.900003
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(datetime.date(2018, 4, 7), datetime.date(2018, 5, 1), datetime.date(2018, 5, 1)), 14) == Decimal('0.14172320927500')
    assert round(dcfc_act_act(datetime.date(2018, 4, 7), datetime.date(2018, 5, 1), datetime.date(2018, 5, 1)), 14) == Decimal('0.14172320927500')
    assert round(dcfc_act_act(datetime.date(2018, 4, 7), datetime.date(2018, 5, 1), datetime.date(2018, 5, 1)), 14) == Decimal('0.14172320927500')

# Generated at 2022-06-21 20:14:40.586761
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof) == 0.16986301369863
    assert dcfc_nl_365(start=ex2_start, asof=ex2_asof, end=ex2_asof) == 0.16986301369863
    assert dcfc_nl_365(start=ex3_start, asof=ex3_asof, end=ex3_asof) == 1.08219178082192
    assert dcfc_nl_365(start=ex4_start, asof=ex4_asof, end=ex4_asof) == 1.32602739726027


# Generated at 2022-06-21 20:14:41.717297
# Unit test for function dcc
def test_dcc():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)



# Generated at 2022-06-21 20:14:46.679246
# Unit test for function dcfc_30_360_us

# Generated at 2022-06-21 20:14:49.264943
# Unit test for function dcc
def test_dcc():
    ## Test the registration of the function:
    @dcc('Test Method')
    def dcfc():
        pass

    ## Make sure that the function has been registered properly:
    assert dcfc.__dcc.name == 'Test Method'



# Generated at 2022-06-21 20:14:52.539536
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dcc = DCCRegistryMechinery()
    assert dcc._buffer_main == {}
    assert dcc._buffer_altn == {}


# Generated at 2022-06-21 20:14:57.620279
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    def test_bad_inputs():
        try:
            DCCRegistry.register("99_not_a_DCC")
        except TypeError:
            pass
        else:
            raise AssertionError("Expected TypeError to be raised")
    test_bad_inputs()


# Generated at 2022-06-21 20:15:05.793330
# Unit test for constructor of class DCC
def test_DCC():
    start = Date(2000, 1, 1)
    asof = Date(2001, 1, 1)
    end = Date(2001, 12, 31)
    freq = Decimal(0.5)
    principal = Money(10.0, 'USD')
    rate = Decimal(0.2)
    eom = 15
    
    ## Get t-1 for asof:
    asof_minus_1 = asof - datetime.timedelta(days=1)

    ## Get the yesterday's factor:
    if asof_minus_1 < start:
        yfact = ZERO
    else:
        yfact = calculate_fraction_method(start, asof_minus_1, end, freq)

    ## Get today's factor:

# Generated at 2022-06-21 20:15:32.094814
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2011, 12, 27), asof=datetime.date(2013, 12, 27), end=datetime.date(2013, 12, 27)), 14) == Decimal('1.45205479452055')



# Generated at 2022-06-21 20:15:44.460434
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    pass
    # assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    # assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')
    # assert round(dcfc_act_act(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-21 20:15:52.813752
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    startDate = datetime.date(2018, 10, 6)
    asOfDate = datetime.date(2018, 12, 5)
    endDate = datetime.date(2018, 12, 5)
    assert round(dcfc_act_360(start = startDate, asof = asOfDate, end = endDate), 8) == Decimal('0.08333333')


# Generated at 2022-06-21 20:16:03.959664
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof = datetime.date(2008, 1, 31), datetime.date(2008, 2, 29)
    ex6_start, ex6_asof = datetime.date(2008, 1, 31), dat

# Generated at 2022-06-21 20:16:13.346611
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    ## Get the convention:
    dcc = DCCRegistry["30/360"]

    ## Run tests:
    assert dcc.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == 0
    assert dcc.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == 0
    assert dcc.calculate_fraction(datetime.date(2017, 2, 28), datetime.date(2017, 3, 31), datetime.date(2017, 3, 31)) == 1

# Generated at 2022-06-21 20:16:23.131489
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    dcc = DCCRegistryMachinery()
    if dcc.table is not {}:
        raise Exception('The table of a new DCCRegistryMachinery is not empty')
    if dcc.registry is not []:
        raise Exception('The registry of a new DCCRegistryMachinery is not empty')
    if dcc._buffer_main is not {}:
        raise Exception('The _buffer_main of a new DCCRegistryMachinery is not empty')
    if dcc._buffer_altn is not {}:
        raise Exception('The _buffer_altn of a new DCCRegistryMachinery is not empty')


# Generated at 2022-06-21 20:16:33.602516
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 8, 31), datetime.date(2007, 12, 28)), 14) == Decimal(".1191666666667")
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 8, 31), datetime.date(2008, 2, 28)), 14) == Decimal(".1805555555556")
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 8, 31), datetime.date(2008, 2, 29)), 14) == Decimal(".1833333333333")
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 8, 31), datetime.date(2008, 2, 30)), 14) == Decimal

# Generated at 2022-06-21 20:16:43.219040
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act.__name__ == 'dcfc_act_act'
    assert dcfc_act_act.__dcc.name == 'Act/Act'
    assert dcfc_act_act.__dcc.altnames == {'Actual/Actual', 'Actual/Actual (ISDA)'}

# Generated at 2022-06-21 20:16:53.907195
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    '''
    Test coupon of class DCC
    '''
    test_principal = Money(10, Currencies["EUR"])
    test_rate = Decimal("0.1")
    test_dcc = DCC("Test", {"T"}, {Currencies["EUR"]}, lambda s, a, e, f: ONE)

    def test_func(start, asof, end, freq):
        '''
        Test function for coupon method
        '''
        return test_principal * test_rate * test_dcc.calculate_fraction(start, asof, end, freq)


# Generated at 2022-06-21 20:17:00.918107
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) ==Decimal('0.16986301369863')

# Generated at 2022-06-21 20:21:10.389254
# Unit test for constructor of class DCC
def test_DCC():
    from .holidays.easter import Easter
    from .holidays.weekend import Weekend

    ea = Easter(Weekend(1))
    interest = DCC("mydc", {'mydc', 'myff'}, {Currencies.USD}, lambda s, a, e, f: ONE)
    interest.calculate_fraction(Date(2020, 1, 1), Date(2020, 1, 1), Date(2020, 1, 1), None)
    interest.calculate_daily_fraction(Date(2020, 1, 1), Date(2020, 1, 1), Date(2020, 1, 1), None)
    interest.interest(Money(1, Currencies.USD), Decimal(1), Date(2020, 1, 1), Date(2020, 1, 1), Date(2020, 1, 1), None)
    interest.coupon

# Generated at 2022-06-21 20:21:16.368716
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc1 = DCC(name="Act/Act", altnames={"Act/Act", "Actual/Actual", "Actual/Actual (ICMA)"}, currencies=set(), calculate_fraction_method=_dcf_act_act)
    reg = DCCRegistryMachinery()
    reg.register(dcc1)
    dcc2 = DCC(name="Act/Act", altnames={"Act/Act", "Actual/Actual", "Actual/Actual (ICMA)"}, currencies=set(), calculate_fraction_method=_dcf_act_act)
    exists = True
    try:
        reg.register(dcc2)
    except TypeError:
        exists = False
    assert exists == False

# Generated at 2022-06-21 20:21:28.105549
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    # Unit test for function dcfc_30_e_plus_360
    assert dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28),
                              datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29),
                              datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')

# Generated at 2022-06-21 20:21:35.359498
# Unit test for function dcfc_30_e_plus_360