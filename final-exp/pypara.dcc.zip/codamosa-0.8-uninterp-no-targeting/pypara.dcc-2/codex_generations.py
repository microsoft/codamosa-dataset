

# Generated at 2022-06-21 20:12:28.937319
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    ## Compute:
    ans1 = dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof)

# Generated at 2022-06-21 20:12:38.627978
# Unit test for function dcc
def test_dcc():
    @dcc("foo")
    def _(x: Date, y: Date, z: Date, freq: Optional[Decimal] = None):
        return x

    assert _.__dcc.name == "foo"
    assert _.__dcc.altnames == set([])
    assert _.__dcc.currencies == set([])

# Defines the day count conventions:
#: Day count convention for no interest accrual.

# Generated at 2022-06-21 20:12:42.939530
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    datetime_today = datetime.today()
    ex1_start, ex1_asof = datetime_today.replace(year=2007, month=12, day=28), datetime_today.replace(year=2008, month=2, day=28)
    ex2_start, ex2_asof = datetime_today.replace(year=2007, month=12, day=28), datetime_today.replace(year=2008, month=2, day=29)
    ex3_start, ex3_asof = datetime_today.replace(year=2007, month=10, day=31), datetime_today.replace(year=2008, month=11, day=30)
    ex4_start, ex4_asof = datetime_today.replace(year=2008, month=2, day=1), datetime_

# Generated at 2022-06-21 20:12:49.990413
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2017, 1, 1)
    end = datetime.date(2020, 1, 1)
    asof = datetime.date(2019, 1, 1)
    dcc = DCC("DCC", None, None, None)
    assert dcc.calculate_fraction(start, asof, end) == Decimal('0')
    
test_DCC_calculate_fraction()



# Generated at 2022-06-21 20:13:02.052205
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    # Test 1
    # Check the day count fraction for 2020-02-29 in a leap year
    # Leap year is 1, non-leap year is 0
    # Start date is Feb 28, 2020
    # End date is Feb 29, 2020
    #
    # Expected result is: 0.00273972602739726
    start=datetime.date(2020, 2, 28)
    end=datetime.date(2020, 2, 29)
    actual=dcfc_act_365_l(start, start, end)
    expected=0.00273972602739726
    tol=1e-14
    success=abs(actual-expected)<tol
    msg="Result for Test 1 incorrect."
    assert success, msg
    print("Test 1 successful.")

    # Test 2
    # Check the day

# Generated at 2022-06-21 20:13:12.133759
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Unit test for method calculate_fraction of class DCC
    """
    start = datetime.date.today().replace(year=2000)
    asof = datetime.date.today().replace(year=2001)
    end = datetime.date.today().replace(year=2001)

    assert DCCRegistry["ACT/ACT DCC"].calculate_fraction(start, asof, end) == Decimal("1")
    assert DCCRegistry["ACT/365 DCC"].calculate_fraction(start, asof, end) == Decimal("365") / Decimal("366")



# Generated at 2022-06-21 20:13:24.398696
# Unit test for method interest of class DCC
def test_DCC_interest():
    """
    Unit test for method interest of class DCC
    """
    ## Check if we can calculate interest given a principal and rate
    princ = Money(1000000,'USD')
    rate = Decimal('0.05')
    start = datetime.date(2018,1,1)
    asof = datetime.date(2018,12,31)
    end = datetime.date(2019,1,1)
    freq = Decimal(4)
    dcc = DCC('ACT360',set(['ACT360','ACT/360','360','ACT/365','365']),_as_ccys({'USD'}),DCFACT360)
    assert dcc.interest(princ, rate, start, asof, end, freq) == Money(Decimal('50000.00'),'USD')
    ## Check if we can calculate

# Generated at 2022-06-21 20:13:35.695712
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    start = datetime.date(2007, 12, 28)
    date = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)
    assert round(dcfc_nl_365(start=start, asof=date, end=end), 14) == round(Decimal('0.16986301369863'), 14)
    date = datetime.date(2008, 2, 29)
    end = datetime.date(2008, 2, 29)
    assert round(dcfc_nl_365(start=start, asof=date, end=end), 14) == round(Decimal('0.16986301369863'), 14)
    date = datetime.date(2008, 11, 30)
    end = datetime.date(2008, 11, 30)

# Generated at 2022-06-21 20:13:45.582769
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCC("Act/Act", {"Act/Act", "Actual/Actual"}, {Currencies.USD}, calculate_fraction_actact)
    DCCRegistry.register(dcc)
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal("0.16942884946478")
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal("1694.29")

# Generated at 2022-06-21 20:13:54.575609
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == Decimal(str(0.16666666666667))
    assert dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) == Decimal(str(0.16944444444444))

# Generated at 2022-06-21 20:14:33.723195
# Unit test for function dcc
def test_dcc():
    f = lambda x,y,z : x
    f = dcc('dcc', [], [])(f)
    assert isinstance(f, types.FunctionType)
    assert getattr(f, '__dcc', None) is not None


##
## Actual day count convention definitions
##


# Generated at 2022-06-21 20:14:42.173753
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    """
    Compare the results for example 1 to the reference value.
    """
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)

# Generated at 2022-06-21 20:14:48.463070
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    assert round(dcfc_act_365_f(start=datetime.date(2017,5,5), asof=datetime.date(2017,6,5),\
                            end=datetime.date(2017,6,10)), 3) == 0.068
    assert round(dcfc_act_365_f(start=datetime.date(2015,5,5), asof=datetime.date(2017,6,5),\
                            end=datetime.date(2018,6,10)), 3) == 1.004
    assert round(dcfc_act_365_f(start=datetime.date(2016,1,1), asof=datetime.date(2016,2,1),\
                            end=datetime.date(2016,1,1)), 3) == 0.031
    assert round

# Generated at 2022-06-21 20:15:00.582983
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-21 20:15:07.305087
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Convention:
    # - Start: 28 December 2007
    # - Asof: 28 February 2008
    dcfc_30_360_us(
        start=datetime.date(2007, 12, 28),  # Same as above
        asof=datetime.date(2008, 2, 28),  # Same as above
        end=datetime.date(2008, 2, 29),  # Same as above
        freq=1
    )

    dcfc_30_360_us(
        start=datetime.date(2007, 12, 28),  # Same as above
        asof=datetime.date(2008, 2, 28),  # Same as above
        end=datetime.date(2008, 2, 29),  # Same as above
        freq=1
    )
# #
# #
# #
# #

# Generated at 2022-06-21 20:15:18.607978
# Unit test for function dcfc_act_360
def test_dcfc_act_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 8) == 0.17222222

# Generated at 2022-06-21 20:15:26.112162
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    """
    Test function dcfc_act_365_f()
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)
    assert round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')


# Generated at 2022-06-21 20:15:32.103271
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    from pyexcel_xlsx import get_data
    from pyexcel_xlsx import save_data
    import os
    import re

    ## Prepare a list of DCCs
    data = get_data("Day Count Convention.xlsx")
    sheet = data.get("Sheet1")

    ## Get the name of day count convention and the list of alternative names
    dcc_names = [item[0] for item in sheet if str(item[0]) != "None"]
    alt_names = [item[1] for item in sheet if str(item[1]) != "None"]

    ## Split the alternative names
    alt_names_split = [alt_name.split("; ") for alt_name in alt_names]

    ## Initialize the header

# Generated at 2022-06-21 20:15:44.460968
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    print("dcfc_30_360_us")
    r = dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28))
    print("    start=2007-12-28, asof=2008-2-28, r={:0.14f}".format(r))
    assert round(r, 14) == round(Decimal('0.16666666666667'), 14)
    r = dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29))

# Generated at 2022-06-21 20:15:52.288954
# Unit test for method register of class DCCRegistryMachinery

# Generated at 2022-06-21 20:19:16.197288
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)),14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)),14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_us(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)),14) == Decimal('1.08333333333333')

# Generated at 2022-06-21 20:19:26.833968
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)

# Generated at 2022-06-21 20:19:35.497528
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    from dateutil.relativedelta import relativedelta
    from datetime import date
    from decimal import Decimal
    ## Test case 1
    start, asof = date(2007, 12, 28), date(2008, 2, 28)
    end = asof
    res = Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=start, asof=asof, end=end), 14) == res
    ## Test case 2
    start, asof = date(2007, 12, 28), date(2008, 2, 29)
    end = asof
    res = Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=start, asof=asof, end=end), 14) == res
    ## Test

# Generated at 2022-06-21 20:19:47.013852
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667'))

# Generated at 2022-06-21 20:19:57.584065
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCCRegistry['Act/360'].calculate_daily_fraction(datetime.date(2013, 9, 5), datetime.date(2013, 10, 4), datetime.date(2013, 12, 4)) == Decimal('0.0222222222222222222222222222222222')
    assert DCCRegistry['Act/360'].calculate_daily_fraction(datetime.date(2013, 9, 5), datetime.date(2013, 12, 4), datetime.date(2013, 12, 4)) == Decimal('0.10000000000000000000000000000000')

# Generated at 2022-06-21 20:19:59.804260
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert hasattr(DCCRegistry, 'find')
    assert callable(getattr(DCCRegistry, 'find'))

# Generated at 2022-06-21 20:20:10.868772
# Unit test for constructor of class DCCRegistryMachinery
def test_DCCRegistryMachinery():
    DCCRegistryMachinery()

DCCRegistry = DCCRegistryMachinery()
DCCRegistry.register(DCC(
    name='Act/Act',
    altnames=set(),
    currencies={Currencies['EUR'], Currencies['USD']},
    calculate_fraction_method=_actact,
))
DCCRegistry.register(DCC(
    name='Act/360',
    altnames={'ISDA', 'IA360', 'Act/365', 'IA365'},
    currencies={Currencies['USD']},
    calculate_fraction_method=_act360,
))

# Generated at 2022-06-21 20:20:17.354833
# Unit test for function dcfc_act_365_f
def test_dcfc_act_365_f():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert (round(dcfc_act_365_f(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863'))

# Generated at 2022-06-21 20:20:24.466378
# Unit test for constructor of class DCC
def test_DCC():
    assert DCC(name="x", altnames=set(), currencies=set(), calculate_fraction_method=None).name == "x"
    assert DCC(name="x", altnames=set(), currencies=set(), calculate_fraction_method=None).altnames == set()
    assert DCC(name="x", altnames=set(), currencies=set(), calculate_fraction_method=None).currencies == set()
    assert DCC(name="x", altnames=set(), currencies=set(), calculate_fraction_method=None).calculate_fraction_method is None


# Generated at 2022-06-21 20:20:30.066667
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    r1 = dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end)
    assert r1 == Decimal('0.5245901639'), 'dcfc_act_act_icma() for case 1 failed!'
    ex2_start, ex2_asof, ex2_end = datetime.date(2019, 6, 28), datetime.date(2019, 9, 2), datetime.date(2020, 6, 28)

# Generated at 2022-06-21 20:21:28.057279
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = "2011-01-01"
    asof = "2011-02-15"
    end = "2011-03-15"
    freq = None
    principal = Money("100", "GBP")
    rate = Decimal("0.04")
    start_date = Date(start)
    asof_date = Date(asof)
    end_date = Date(end)
    ccy = Currencies["EUR"]
    obj = DCC("name", set(["altname"]), set(["GBP", "EUR"]), _get_actual_day_count)
    assert obj.calculate_fraction(start_date, asof_date, end_date, freq) == Decimal('0.26355')

# Generated at 2022-06-21 20:21:35.212787
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    print("\nTesting function dcfc_30_360_us.\n")
    ## Test 1:
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    print("- start: {}, asof: {}, end: {}".format(start, asof, asof))
    print("- dcf:   {}".format(round(dcfc_30_360_us(start, asof, asof), 14)))

    ## Test 2:
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)
    print("- start: {}, asof: {}, end: {}".format(start, asof, asof))