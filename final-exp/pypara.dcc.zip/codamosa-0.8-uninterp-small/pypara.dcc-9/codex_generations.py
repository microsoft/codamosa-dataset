

# Generated at 2022-06-26 00:42:05.694484
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    import math

    print(math.pi)

    print("\nstart date: 2007-02-28")
    start = datetime.date(2007, 2, 28)
    ex1 = {'asof':datetime.date(2007, 3, 30), 'nod':30}
    ex2 = {'asof':datetime.date(2007, 4, 30), 'nod':60}
    ex3 = {'asof':datetime.date(2008, 3, 30), 'nod':390}
    ex4 = {'asof':datetime.date(2007, 2, 28), 'nod':0}

    exs = [ex1, ex2, ex3, ex4]

    for ex in exs:
        asof = ex['asof']
        nod = ex['nod']

        df = d

# Generated at 2022-06-26 00:42:10.611537
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():

    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)


    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:42:18.458143
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert(round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal("0.5245901639"))


# Generated at 2022-06-26 00:42:28.615764
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-26 00:42:38.948622
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_0 = DCC(name = 'Actual', altnames = set(), currencies = set(), calculate_fraction_method = lambda start, asof, end, freq: ZERO)
    # Test case where d_c_c_0 has already been registered
    try:
        d_c_c_registry_machinery_0.register(d_c_c_0)
        assert False, "Should have raised a TypeError."
    except TypeError:
        assert True
    # Test execution of DCCRegistry.register()
    d_c_c_registry_machinery_0.register(d_c_c_0)
    # Test case where d_c_c_0 has already been

# Generated at 2022-06-26 00:42:43.817030
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():

    # Compute the day count fraction:
    dcf = dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))

    # Print the result:
    print("30/360 U.S. day count fraction:", dcf)



# Generated at 2022-06-26 00:42:55.614442
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28))
    dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29))
    dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30))

# Generated at 2022-06-26 00:43:03.794402
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    # This is a regression test with a number of dates corresponding to the test case:
    # System.out.println(
    #   "TEST 30E+/360 => "+
    #     ( (dcfc(new Date(27.04.2007),new Date(30.04.2008), "30E+/360")) - 1.0)
    # );
    ex1_start, ex1_asof = datetime.date(2007, 4, 27), datetime.date(2008, 4, 30)
    print(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof))

# Generated at 2022-06-26 00:43:14.868592
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ## Test 1 - Normal case:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-26 00:43:24.331846
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    print("Testing dcfc_30_e_plus_360...")
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 29)
    dc = dcfc_30_e_plus_360(start, asof, end)
    print(dc)

    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 29)
    dc = dcfc_30_e_plus_360(start, asof, end)
    print(dc)

    assert(dc==0.16666666666667)
    print("Test Passed")


# Generated at 2022-06-26 00:44:06.109242
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Case 1
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex1_end = ex1_asof
    ex1_freq = None
    ex1_correct = Decimal('0.16942884946478')
    ex1_computed = round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_end, freq=ex1_freq), 14)
    ex1_message = "dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_end, freq=ex1_freq)"

# Generated at 2022-06-26 00:44:15.165090
# Unit test for method interest of class DCC
def test_DCC_interest():
    # Test case 1
    d_c_c_0 = DCC(
        name = 'dcc_0', 
        altnames = set([]), 
        currencies = set([]), 
        calculate_fraction_method = lambda start, asof, end, freq: 0.0
    )
    m_o_n_e_y_0 = Money(
        amount = 7.356128925351367, 
        currency = Currencies.JPY
    )
    principal = m_o_n_e_y_0
    rate = 0.5
    start = datetime.date(2007, 7, 3)
    asof = datetime.date(2028, 11, 12)
    end = datetime.date(2032, 4, 13)
    freq = None
    assert d_c

# Generated at 2022-06-26 00:44:23.717252
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCRegistry.INSTANCE.actual["30/360"]

# Generated at 2022-06-26 00:44:30.761938
# Unit test for method coupon of class DCC
def test_DCC_coupon():

    ## Define our parameters:
    principal = Money(currency='USD', amount=10)
    rate = Decimal(2)
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2018, 1, 1)
    end = datetime.date(2017, 2, 1)
    freq = Decimal(2)
    eom = 15

    ## Define our convention and calculate the coupon:
    convention = DCCRegistry.get("30/360 US")
    coupon = convention.coupon(principal, rate, start, asof, end, freq, eom)

    ## A coupon of 0.10 is expected:
    assert(coupon == Money("0.10", "USD"))



# Generated at 2022-06-26 00:44:36.686066
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Declare a reference to the class `DCC`
    ref_DCC = DCC
    # Call method calculate_daily_fraction of class `DCC`
    input_start_date = datetime.date(2016, 12, 29)  # type: Date
    input_asof_date = datetime.date(2017, 1, 4)  # type: Date
    input_end_date = datetime.date(2017, 1, 4)  # type: Date
    input_freq = None  # type: Optional[Decimal]
    input_d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    input_d_c_c_0 = input_d_c_c_registry_machinery_0.act(DCCRegistryInvoker())  # type: Optional[

# Generated at 2022-06-26 00:44:46.940086
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Datetime objects
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    # Target values
    tgt_s1_asof = Decimal('0.16666666666667')
    tgt_s2_asof = Decimal('0.16944444444444')
    tgt_

# Generated at 2022-06-26 00:44:56.229474
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    d_c_c_registry_machinery_1 = DCCRegistryMachinery()

    start_date_1 = datetime.date(year=2007, month=12, day=1)
    asof_date_1 = datetime.date(year=2008, month=5, day=1)
    end_date_1 = datetime.date(year=2008, month=5, day=1)

    day_count_fraction_1 = d_c_c_registry_machinery_1.get_day_count_fraction_calculator("30/360 US")(start_date_1, asof_date_1, end_date_1)

    print("Test Day Count Fraction = ", day_count_fraction_1)


# Generated at 2022-06-26 00:45:02.400181
# Unit test for method interest of class DCC
def test_DCC_interest():
    _d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_30_day = DCC("30-day", {"30-day-month"}, set(), _d_c_c_registry_machinery_0._f30day)
    d_c_c_0 = DCC("ACT/360", {"act-360"}, set(), _d_c_c_registry_machinery_0._factor)
    d_c_c_1 = DCC("ACT/365", {"act-365"}, set(), _d_c_c_registry_machinery_0._factor)

# Generated at 2022-06-26 00:45:10.479843
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(datetime.date(2016,1,1),datetime.date(2016,1,1),datetime.date(2016,1,1)),10) == 0
    assert round(dcfc_30_e_360(datetime.date(2016,1,1),datetime.date(2017,1,1),datetime.date(2017,1,1)),10) == 1
    assert round(dcfc_30_e_360(datetime.date(2016,1,1),datetime.date(2016,5,31),datetime.date(2016,5,31)),10) == 0.5
    


# Generated at 2022-06-26 00:45:15.620100
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    
    dcc = DCC("name", set(), set(), lambda start, asof, end, freq: ONE)
    start = datetime.date(2018, 5, 10)
    asof = datetime.date(2018, 5, 10)
    end = datetime.date(2018, 5, 10)
    print("Value returned by method calculate_daily_fraction of class DCC is:", dcc.calculate_daily_fraction(start, asof, end, freq))


# Generated at 2022-06-26 00:46:00.269282
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d_cc_0 = DCC('', '', '', '')
    d_cc_0_0 = copy.deepcopy(d_cc_0)
    d_cc_0_0 = copy.deepcopy(d_cc_0)
    d_cc_0_0 = copy.deepcopy(d_cc_0)
    d_cc_0_0 = copy.deepcopy(d_cc_0)
    d_cc_0_0 = copy.deepcopy(d_cc_0)
    d_cc_0_0 = copy.deepcopy(d_cc_0)
    d_cc_0_0 = copy.deepcopy(d_cc_0)
    d_cc_0_0 = copy.deepcopy(d_cc_0)
    d_cc_0_0 = copy.deepcopy

# Generated at 2022-06-26 00:46:05.360887
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    # define d_c_c_0:
    d_c_c_0 = DCC(name='name', altnames={'altnames'}, currencies={'currencies'}, calculate_fraction_method=act_act)
    # register d_c_c_0:
    d_c_c_registry_machinery_0.register(d_c_c_0)


# Generated at 2022-06-26 00:46:14.535144
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-26 00:46:21.373609
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal = Money(currency=Currencies.USD, amount=100)
    rate = Decimal(0.05)
    start = Date(year=2014, month=1, day=1)
    asof = Date(year=2015, month=12, day=31)
    end = Date(year=2015, month=1, day=1)
    freq = Decimal(1)
    eom = 1
    d = DCC(name='', altnames=set(), currencies=set(), calculate_fraction_method=lambda start, asof, end, freq: Decimal(0.5))
    for x in range(0, 3):
        d.coupon(principal, rate, start, asof, end, freq, eom)
    return



# Generated at 2022-06-26 00:46:22.897220
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    import doctest
    count, _ = doctest.testmod()
    assert count > 0


# Generated at 2022-06-26 00:46:29.545711
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Check if the result is correct for the following inputs:
    #     start = datetime.date(2007, 12, 28)
    #     asof = datetime.date(2008, 2, 28)
    #     end = datetime.date(2008, 2, 28)
    #     freq = None
    dcfc_30_360_us_result = dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))


# Generated at 2022-06-26 00:46:38.150716
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-26 00:46:40.845831
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    str_0 = ''
    optional_0 = d_c_c_registry_machinery_0.find(str_0)


# Generated at 2022-06-26 00:46:49.466637
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-26 00:46:55.758283
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """
    Unit test for function dcfc_act_act_icma.
    """

    ## Test 1:
    ex1_start = datetime.date(2019, 3, 2)
    ex1_asof = datetime.date(2019, 9, 10)
    ex1_end = datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')

    ## Test 2:
    ex2_start = datetime.date(2011, 10, 11)
    ex2_asof = datetime.date(2013, 10, 10)
    ex2_end = datetime.date(2013, 12, 31)

# Generated at 2022-06-26 00:49:09.466431
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    str_0 = ''
    d_c_c = d_c_c_registry_machinery_0.find(str_0)
    date_0 = datetime.date(1,1,1)
    date_1 = datetime.date(1,1,1)
    date_2 = datetime.date(1,1,1)
    decimal_0 = d_c_c.calculate_daily_fraction(date_0,date_1,date_2)
    str_1 = ''
    optional_0 = d_c_c_registry_machinery_0.find(str_1)


# Generated at 2022-06-26 00:49:17.422768
# Unit test for method interest of class DCC
def test_DCC_interest():
    _v_principal_0 = Money('19.4800000000')
    _v_rate_0 = Decimal('0.8139420000')
    _v_start_0 = datetime.date(2019, 10, 1)
    _v_asof_0 = datetime.date(2019, 11, 1)

    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    str_0 = 'ACT/ACT ISDA'
    optional_0 = d_c_c_registry_machinery_0.find(str_0)

    money_0 = optional_0[0].interest(_v_principal_0, _v_rate_0, _v_start_0, _v_asof_0)


# Generated at 2022-06-26 00:49:20.537726
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    try:
        start_0 = datetime.date(2007, 12, 28)
        asof_0 = datetime.date(2008, 2, 28)
        end_0 = datetime.date(2008, 2, 28)
        actual_0 = dcfc_act_365_a(start_0, asof_0, end_0)
        expected_0 = Decimal('0.16986301369863')
        assert actual_0 == expected_0
    except Exception:
        print('Exception: ', Exception)


# Generated at 2022-06-26 00:49:28.274808
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # If a is greater than b, c is greater than d; If e is greater than f, g is greater than h.
    # Then, if a is greater than b, g is greater than h; If e is greater than f, c is greater than d.
    # Asserting the truth of these conclusions is equivalent to asserting that True is in the list of logical and operation between a, b, c, d, e and f
    # The first test case is if a is greater than b, g is greater than h
    a, b, c, d, e, f, g, h = 6, 4, -1, -3, 2, -3, -3, 2
    assert (a > b and g > h) == (test_suite_dcfc_act_act(a, b, c, d, e, f, g, h))
    #

# Generated at 2022-06-26 00:49:30.211542
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_0 = d_c_c_registry_machinery_0.registry[0]
    d_c_c_registry_machinery_0.register(d_c_0)


# Generated at 2022-06-26 00:49:30.770153
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert 1 == 1


# Generated at 2022-06-26 00:49:37.158773
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    d_c_c_0 = DCC(
        'string_0',
        {'string_0', 'string_1', 'string_2'},
        {Currencies.USD},
        lambda string_0, string_1, string_2, decimal_0: decimal_0
    )
    money_0 = Money.eur(string_0='string_0')
    decimal_0 = Decimal('0.043863260035509728')
    date_0 = Date(2018, 12, 30)
    date_1 = Date(2003, 12, 30)
    decimal_1 = d_c_c_0.calculate_daily_fraction(date_0, date_1, date_1, decimal_0)
    money_1 = money_0 * decimal_1


# Generated at 2022-06-26 00:49:39.432672
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    dcfc_act_365_a(datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), datetime.date(2009, 5, 31), None)
    dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30), None)


# Generated at 2022-06-26 00:49:41.864534
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    str_0 = ''
    optional_0 = d_c_c_registry_machinery_0.find(str_0)


# Generated at 2022-06-26 00:49:48.712801
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08196721311475')
