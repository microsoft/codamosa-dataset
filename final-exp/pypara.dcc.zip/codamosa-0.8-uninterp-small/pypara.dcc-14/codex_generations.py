

# Generated at 2022-06-26 00:42:17.538721
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    start = datetime.date(2022, 4, 15)
    end = datetime.date(2022, 6, 15)
    asof = datetime.date(2022, 6, 15)
    freq = None

    assert round(dcfc_30_e_plus_360(start=start, asof=asof, end=end, freq=freq), 14) == Decimal('0.16666666666667')



# Generated at 2022-06-26 00:42:28.570668
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    date_0 = datetime.date(2017, 9, 15)
    date_1 = datetime.date(2017, 12, 12)
    date_2 = datetime.date(2018, 3, 3)
    assert dcfc_30_360_us(date_0, date_1, date_2) == Decimal('0.33333333333333'), "Wrong answer!"
    assert dcfc_30_360_us(date_1, date_0, date_2) == Decimal('0.36111111111111'), "Wrong answer!"
    assert dcfc_30_360_us(date_2, date_0, date_1) == Decimal('0.38888888888889'), "Wrong answer!"

# Generated at 2022-06-26 00:42:33.846470
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Retrieve the source code of the function dcfc_30_360_us
    source_code_str = get_source_code_str(dcfc_30_360_us)

    # Test the source code string
    test_source_code_str(source_code_str)


# Generated at 2022-06-26 00:42:41.981643
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Test 1
    start_1, asof_1 = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    result_1 = dcfc_act_act(start=start_1, asof=asof_1, end=ex1_asof)
    print("dcfc_act_act(%s, %s, %s): %s" % (start_1, asof_1, ex1_asof, result_1))
    assert result_1 == Decimal('0.16942884946478')
    # Test 2
    start_1, asof_1 = datetime.date(2007, 12, 28),

# Generated at 2022-06-26 00:42:51.730588
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)
    round(dcfc_30_e_360(start=start, asof=asof, end=end), 14)
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)
    end = datetime.date(2008, 2, 29)
    round(dcfc_30_e_360(start=start, asof=asof, end=end), 14)
    start = datetime.date(2007, 10, 31)
    asof = datetime.date(2008, 11, 30)
    end = datetime.date(2008, 11, 30)
   

# Generated at 2022-06-26 00:42:53.690104
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    test_case_0()

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 00:43:03.445426
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .currencies import Currencies
    from .enums import DaycountConventions
    import datetime as module_0
    date_0 = module_0.date()
    date_1 = module_0.date()
    dcc = DCCRegistry[DaycountConventions.ACTUAL_360]
    dcc.calculate_fraction(date_0, date_1, date_1)
    dcc = DCCRegistry[DaycountConventions.ACTUAL_365:Currencies.ALL]
    dcc.calculate_fraction(date_0, date_1, date_1)
    dcc = DCCRegistry[DaycountConventions.ACTUAL_365:Currencies.ALL]
    dcc.calculate_fraction(date_0, date_1, date_1)

# Generated at 2022-06-26 00:43:14.501474
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667'))

# Generated at 2022-06-26 00:43:17.544881
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')


# Generated at 2022-06-26 00:43:28.417801
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    inputs = (datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))
    actual = dcfc_30_360_isda(*inputs)
    expected = Decimal('0.16666666666667')
    assert actual == expected
    inputs = (datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29))
    actual = dcfc_30_360_isda(*inputs)
    expected = Decimal('0.16944444444444')
    assert actual == expected
    inputs = (datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30))
    actual = dcfc_

# Generated at 2022-06-26 00:44:14.386399
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # Arrange
    start = module_0.date(2007, 12, 28)
    asof = module_0.date(2008, 2, 28)
    end = module_0.date(2008, 2, 28)
    freq = None

    # Act
    actual = dcfc_30_e_360(start, asof, end, freq)

    # Assert
    expected = Decimal('0.16666666666667')
    assert actual == expected, 'Expected: {0}, Actual: {1}'.format(expected, actual)


# Generated at 2022-06-26 00:44:20.142480
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    print('Defining dcfc_act_365_a')
    def dcfc_act_365_a(start, asof, end, freq=None): return _get_actual_day_count(start, asof) / Decimal(366 if _has_leap_day(start, asof) else 365)
    print('Running test case 0...')
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start,

# Generated at 2022-06-26 00:44:26.859574
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof)


# Generated at 2022-06-26 00:44:34.242077
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    # Python 3.7.3
    ex1_start, ex1_asof = module_0.date(2007, 12, 28), module_0.date(2008, 2, 28)
    ex2_start, ex2_asof = module_0.date(2007, 12, 28), module_0.date(2008, 2, 29)
    ex3_start, ex3_asof = module_0.date(2007, 10, 31), module_0.date(2008, 11, 30)
    ex4_start, ex4_asof = module_0.date(2008, 2, 1), module_0.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-26 00:44:44.849494
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """Test for dcfc_30_360_german"""

    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Dec

# Generated at 2022-06-26 00:44:54.435776
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert (DCCRegistry.actual_actual_icma_actual_actual(
        datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), None) == 0.0)
    assert (DCCRegistry.actual_actual_icma_actual_actual(
        datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 1), None) == 0.0)
    assert (DCCRegistry.actual_actual_icma_actual_actual(
        datetime.date(2014, 1, 1), datetime.date(2014, 3, 31), datetime.date(2014, 1, 1), None) == 90.0)

# Generated at 2022-06-26 00:44:56.187157
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act(1, 2, 3, 1) == 0
    pass


# Generated at 2022-06-26 00:44:57.359060
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert 0 == dcc("NL/365")
    

# Generated at 2022-06-26 00:45:06.594090
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert 0 == DCC.interest(Money(1.0), Decimal(0.0), Date(1, 1, 2019), Date(1, 1, 2019), Date(1, 1, 2019), Decimal(0.0))
    assert 0 == DCC.interest(Money(1.0), Decimal(0.0), Date(1, 1, 2019), Date(1, 1, 2019), Date(1, 1, 2019), Decimal(0.0))
    assert 0 == DCC.interest(Money(1.0), Decimal(1.0), Date(1, 1, 2019), Date(1, 1, 2019), Date(1, 1, 2019), Decimal(1.0))

# Generated at 2022-06-26 00:45:15.086932
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Test function dcfc_30_360_german
    """
    import pytest

    with pytest.raises(TypeError) as excinfo:
        dcfc_30_360_german(start = 3, asof = 3, end = 3, freq = 3)
    with pytest.raises(TypeError) as excinfo:
        dcfc_30_360_german(start = 'test', asof = 'test', end = 'test', freq = 'test')
    with pytest.raises(TypeError) as excinfo:
        dcfc_30_360_german(start = mock.Mock(), asof = mock.Mock(), end = mock.Mock(), freq = mock.Mock())

# Generated at 2022-06-26 00:47:16.193694
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    principal = Money({Currency('CAD'): Decimal('1.0')})
    start = _construct_date(year = 2017, month = 1, day = 1)
    asof = _construct_date(year = 2017, month = 1, day = 1)
    end = _construct_date(year = 2017, month = 1, day = 1)
    freq = Decimal('6')
    rate = Decimal('0.1')
    eom = 2
    dcc = DCC(name = 'x', altnames = set(), currencies = set(), calculate_fraction_method = DCCRegistry.act_365f_)
    x_0 = dcc.calculate_fraction(start, asof, end, freq)
    assert x_0 == Decimal('0.002739726')
    x_1

# Generated at 2022-06-26 00:47:28.907097
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    ## Initialize:
    money = Money(1000, Currencies.USD)
    rate = Decimal(".12")

    ## Following is the convention:
    ##
    ## start  asof    end    freq   interest
    ## 1/1    1/1     1/1    None   0
    ## 1/1    1/1     1/2    None   0
    ## 1/1    1/2     1/2    None   0
    ## 1/1    1/2     1/3    None   0.01
    ## 1/1    1/2     1/4    None   0.01
    ## 1/1    1/3     1/3    None   0
    ## 1/1    1/3     1/4    None   0
    ## 1/1    1/3     1/5    None

# Generated at 2022-06-26 00:47:34.367792
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dccreg = DCCRegistryMachinery()
    dcc = DCC(name="30/360 EOM", altnames={"30/360_EOM", "30/360eom"}, currencies={Currencies["USD"]}, calculate_fraction_method=dcfc_30_360_eom)
    dccreg.register(dcc)
    assert dccreg.find("30/360 EOM") is dcc
    assert dccreg.find("30/360_EOM") is dcc
    assert dccreg.find("30/360eom") is dcc
    dcc = DCC(name="Act/Act", altnames={"Act/Act", "Actual/365"}, currencies={Currencies["USD"]}, calculate_fraction_method=dcfc_act_act)

# Generated at 2022-06-26 00:47:40.691411
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Declare test data
    date_0 = datetime.date()

    # Invoke the method to be tested
    DCC(
        name = "",
        altnames = {
            ""
        },
        currencies = {
            Currencies[""]
        },
        calculate_fraction_method = lambda start, asof, end, freq: 0
    ).calculate_daily_fraction(
        date_0,
        date_0,
        date_0,
    )


# Generated at 2022-06-26 00:47:42.794821
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    date_0 = datetime.date()

    test_case_0()

import datetime as module_1


# Generated at 2022-06-26 00:47:47.576742
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    date = '12/13/2010'
    asof = '12/12/2013'
    end = '12/12/2013'
    freq = 0.5
    prc_0 = DCC(date, asof, end, freq)
    exp_prc_0 = 0.00
    assert prc_0 == exp_prc_0



import datetime as module_0


# Generated at 2022-06-26 00:47:51.769102
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14)
    round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14)
    round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14)

# Generated at 2022-06-26 00:47:59.784099
# Unit test for method coupon of class DCC
def test_DCC_coupon():
        dcc = DCC('', set(), set(), lambda start, asof, end, freq: 0)
        dcc.coupon(Money('EUR', 0), 0., date_0, date_0, date_0, 0.)
        dcc.coupon(Money('EUR', 0), 0., date_0, date_0, date_0, 1.)
        dcc.coupon(Money('EUR', 0), 0., date_0, date_0, date_0, 2.)
        dcc.coupon(Money('EUR', 0), 1., date_0, date_0, date_0, 3.)
        dcc.coupon(Money('EUR', 0), 4., date_0, date_0, date_0, 4.)

# Generated at 2022-06-26 00:48:05.019285
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ## Test for day count convention: 30E+/360
    ex1_start, ex1_asof = module_0.date(2007, 12, 28), module_0.date(2008, 2, 28)
    ex2_start, ex2_asof = module_0.date(2007, 12, 28), module_0.date(2008, 2, 29)
    ex3_start, ex3_asof = module_0.date(2007, 10, 31), module_0.date(2008, 11, 30)
    ex4_start, ex4_asof = module_0.date(2008, 2, 1), module_0.date(2009, 5, 31)

# Generated at 2022-06-26 00:48:09.607686
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    date_0 = datetime.date(2008, 2, 29)
    date_1 = datetime.date(2009, 11, 2)
    date_2 = datetime.date(2007, 12, 28)
    date_3 = datetime.date(2007, 10, 31)
    date_4 = datetime.date(2008, 8, 29)
    date_5 = datetime.date(2012, 1, 1)
    date_6 = datetime.date(2009, 7, 30)
    date_7 = datetime.date(2021, 11, 30)
    date_8 = datetime.date(2010, 8, 31)
    date_9 = datetime.date(2011, 8, 30)
    date_10 = datetime.date(2008, 2, 28)

# Generated at 2022-06-26 00:50:11.948079
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-26 00:50:16.461618
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    date_0 = datetime.date(year=1, month=1, day=1)
    date_1 = datetime.date()
    date_2 = datetime.date(year=1, month=1, day=1)
    dcfc_30_360_us(start=date_0, asof=date_1, end=date_2, freq=None)


# Generated at 2022-06-26 00:50:22.462096
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    end_0 = datetime.date()
    
    # Base test case
    start_1 = datetime.date()
    asof_1 = datetime.date()
    end_1 = datetime.date()
    freq_1 = None
    test_DCC_calculate_daily_fraction_base_1 = DCC(start=start_1, asof=asof_1, end=end_1, freq=freq_1)
    assert test_DCC_calculate_daily_fraction_base_1.calculate_daily_fraction() == None, "calculate_daily_fraction() did not return the expected output"
    # Base test case
    start_1 = datetime.date()
    asof_1 = datetime.date()

# Generated at 2022-06-26 00:50:26.019632
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    """
    Test unit for function dcfc_nl_365
    """

    # Setup
    date_0 = module_0.date()
    date_1 = module_0.date()
    date_2 = module_0.date()

    # Exercise
    result_0 = dcfc_nl_365(date_0, date_1, date_2)

    # Verify
    assert result_0 is 0.0
    
    # Cleanup - none necessary



# Generated at 2022-06-26 00:50:29.856925
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert callable(dcfc_act_act)


# Unit tests for function _construct_date

# Generated at 2022-06-26 00:50:34.751417
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=module_0.date(2007, 12, 28), asof=module_0.date(2008, 2, 28), end=module_0.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=module_0.date(2007, 12, 28), asof=module_0.date(2008, 2, 29), end=module_0.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')

# Generated at 2022-06-26 00:50:37.281301
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    date_0 = module_0.date()
    date_1 = module_0.date()
    date_2 = module_0.date()
    DCC_0 = DCC(None, None, None, None)
    DCC_0.calculate_daily_fraction(date_0, date_1, date_2)

# Generated at 2022-06-26 00:50:43.366600
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    print("Test dcfc_30_e_360")

    # Test cases:
    ex1_start = module_0.date(2007, 12, 28)
    ex1_asof = module_0.date(2008, 2, 28)
    ex1_end = module_0.date(2008, 2, 28)
    res_ex1 = dcfc_30_e_360(ex1_start, ex1_asof, ex1_end)
    assert round(res_ex1, 14) == Decimal('0.16666666666667')

    ex2_start = module_0.date(2007, 12, 28)
    ex2_asof = module_0.date(2008, 2, 29)
    ex2_end = module_0.date(2008, 2, 29)

# Generated at 2022-06-26 00:50:47.321780
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Setup
    start = module_0.date(2018, 9, 1)
    asof = module_0.date(2019, 1, 1)
    end = module_0.date(2019, 1, 1)
    # Invoke the function under test
    actual_result = dcfc_30_360_german(start, asof, end)
    # Check the results
    assert isinstance(actual_result, Decimal)
    expected_result = Decimal('0.13888888888889')
    assert actual_result == expected_result


# Generated at 2022-06-26 00:50:51.932076
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    start = datetime.date(2019, 3, 2)
    asof = datetime.date(2019, 9, 10)
    end = datetime.date(2020, 3, 2)
    freq = None
    assert round(dcfc_act_act_icma(start=start, asof=asof, end=end, freq=freq), 10) == Decimal('0.5245901639')

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# EOF