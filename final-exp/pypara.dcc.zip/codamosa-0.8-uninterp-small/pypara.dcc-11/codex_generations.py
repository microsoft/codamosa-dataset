

# Generated at 2022-06-26 00:41:44.454483
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_dcfc = dcfc_30_e_360(ex1_start, ex1_asof, ex1_asof)
    expected = Decimal('0.16666666666667')

    assert ex1_dcfc == expected


# Generated at 2022-06-26 00:41:54.621385
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)

# Generated at 2022-06-26 00:42:06.198123
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:42:14.176528
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # initialize
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_0 = DCC(name = "", altnames = set(), currencies = set(), calculate_fraction_method = DCFC(lambda a1, a2, a3, a4: 1))

    # invoke
    result = d_c_c_registry_machinery_0.register(d_c_c_0)

    # test
    assert result is None


# Generated at 2022-06-26 00:42:22.480112
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
   assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
   assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
   assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-26 00:42:34.508355
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == pytest.approx(0.16666666667, 0.001)
    assert dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == pytest.approx(0.1694444444, 0.001)
    assert dcfc_30_360_german(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == pytest.approx(1.0833333333, 0.001)
    assert dcfc_

# Generated at 2022-06-26 00:42:40.442609
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    result1 = dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end)
    expected = Decimal('0.5245901639')
    print("Actual:", result1)
    print("Expected:", expected)
    assert result1 == expected


# Generated at 2022-06-26 00:42:44.147567
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')


# Generated at 2022-06-26 00:42:53.995400
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Let's start by creating a list of the test cases to be run:
    test_cases_0_start = [
        datetime.date(year=2007, month=12, day=28),
        datetime.date(year=2007, month=12, day=28),
        datetime.date(year=2007, month=10, day=31),
        datetime.date(year=2008, month=2, day=1),
    ]
    test_cases_0_asof = [
        datetime.date(year=2008, month=2, day=28),
        datetime.date(year=2008, month=2, day=29),
        datetime.date(year=2008, month=11, day=30),
        datetime.date(year=2009, month=5, day=31),
    ]


# Generated at 2022-06-26 00:43:00.089489
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)
    end = datetime.date(2008, 2, 29)
    everyday = datetime.timedelta(days=1)
    for date_loop in [start, asof, end]:
        date_loop += everyday
    assert dcfc_30_e_360(start, asof, end) == Decimal("0.16944444444444")


# Generated at 2022-06-26 00:43:48.619391
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    pass


# Generated at 2022-06-26 00:43:52.768502
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Inputs
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)
    freq = None
    assert dcfc_30_360_us(start, asof, end, freq) == 0.16666666666667


# Generated at 2022-06-26 00:44:05.188166
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert(round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)), 14) ==  Decimal('0.16666666666667'))
    assert(round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)), 14) ==  Decimal('0.16944444444444'))
    assert(round(dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)), 14) ==  Decimal('1.08333333333333'))

# Generated at 2022-06-26 00:44:11.888013
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    asof_month=datetime(2019,9,14)
    start_month=datetime(2019,8,15)
    end_month=datetime(2019,9,14)
    start_year=datetime(2019,1,1)
    end_year=datetime(2019,12,31)
    start_leap_year=datetime(2020,1,1)
    end_leap_year=datetime(2020,12,31)
    nod_month=dcfc_30_360_german(start_month,asof_month,end_month)
    nod_year=dcfc_30_360_german(start_year,asof_month,end_year)

# Generated at 2022-06-26 00:44:16.894996
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_0 = d_c_c_registry_machinery_0.dcc_registry["ACT_365F"]
    d_c_c_0.calculate_fraction(datetime.date(2014, 3, 31), datetime.date(2014, 10, 1), datetime.date(2014, 12, 31))


# Generated at 2022-06-26 00:44:22.664346
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-26 00:44:26.827579
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    dates = [datetime.date(2020, 1, 14), datetime.date(2020, 1, 15), datetime.date(2020, 1, 16)]

    actual = dcfc_nl_365(dates[0], dates[1], dates[2])
    expected = float(1/365)

    assert_that(actual, is_(expected))


# Generated at 2022-06-26 00:44:33.633200
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    print("Function dcfc_30_360_us: Start of Unit Test")
    exp_result = Decimal("0.16666666666667")
    s = datetime.date(2007,12,28)
    a = datetime.date(2008,2,28)
    e = datetime.date(2008,2,28)
    real_result = dcfc_30_360_us(start=s, asof=a, end=e)
    print("Expected result:  %f" % exp_result)
    print("Real result:      %f" % real_result)
    assert(exp_result == real_result)
    print("Function dcfc_30_360_us: Unit Test successful")
    return


# Generated at 2022-06-26 00:44:39.983843
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    start = datetime.datetime.strptime("28/12/2007", format).date()
    end = datetime.datetime.strptime("28/02/2008", format).date()
    asof = datetime.datetime.strptime("29/02/2008", format).date()
    assert round(dcfc_30_e_360(start, asof, end), 14) == Decimal('0.16944444444444')




# Generated at 2022-06-26 00:44:44.314966
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert d_c_c_registry_machinery_0.find('ERROR') == None
    assert d_c_c_registry_machinery_0.find('Act/Act') == d_c_c_registry_machinery_0.find('Act/Act')


# Generated at 2022-06-26 00:46:04.729642
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dccRegistryMachineryObj = DCCRegistryMachinery()
    dcc = dccRegistryMachineryObj.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')

# Generated at 2022-06-26 00:46:08.990258
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    # Test case:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_expected = Decimal('0.17086505190311')
    # Test case:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex2_expected = Decimal('0.17361111111111')
    # Test case:
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex3_expected = Decimal('1.08333333333333')
    # Test case:
    ex4_start, ex4_asof = datetime.date

# Generated at 2022-06-26 00:46:17.090407
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    date_0 = datetime.date(2019, 2, 11)
    date_1 = datetime.date(2, 11, 2019)
    decimal_0 = Decimal('0.5')
    decimal_1 = Decimal('0.5')
    decimal_2 = Decimal('0.5')
    money_0 = Money(decimal_2, 'USD')
    money_1 = Money(decimal_1, 'USD')
    dcc_0 = DCC('test0', {'test1', 'test2'}, {'USD', 'EUR'}, dcfc_act_365_a)
    dcc_1 = DCC('test3', {'test4'}, {'GBP', 'JPY'}, dcfc_act_360_e)

# Generated at 2022-06-26 00:46:24.613951
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(DT.date(2014, 1, 10), DT.date(2014, 12, 29), DT.date(2014, 12, 29)) == Decimal('0.36444444444444')
    assert dcfc_30_e_360(DT.date(2014, 10, 31), DT.date(2014, 11, 30), DT.date(2014, 11, 30)) == Decimal('0.033333333333333')
    assert dcfc_30_e_360(DT.date(2013, 2, 24), DT.date(2014, 12, 29), DT.date(2014, 12, 29)) == Decimal('1.30611111111111')

# Generated at 2022-06-26 00:46:28.830286
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    # Case-1
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    actual = dcfc_act_365_l(start, end, end)
    assert actual == 0.16939890710383, "Actual and Expected does not match"
    # Case-2
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 29)
    actual = dcfc_act_365_l(start, end, end)
    assert actual == 0.17213114754098, "Actual and Expected does not match"
    # Case-3
    start = datetime.date(2007, 10, 31)
    end = datetime.date(2008, 11, 30)

# Generated at 2022-06-26 00:46:37.430853
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    start_date = datetime.date(2008, 2, 1)
    asof_date = datetime.date(2009, 5, 31)
    end_date = datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start_date, asof_date, end_date), 14) == round(Decimal('1.32602739726027'), 14)
    start_date = datetime.date(2007, 10, 31)
    asof_date = datetime.date(2008, 11, 30)
    end_date = datetime.date(2008, 11, 30)
    assert round(dcfc_nl_365(start_date, asof_date, end_date), 14) == round(Decimal('1.08219178082192'), 14)
    start_date

# Generated at 2022-06-26 00:46:41.294876
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    # Create an instance of class DCCRegistryMachinery
    dcc_registry_machinery_0 = DCCRegistryMachinery()

    # Call method find with argument dcc_0.name of instance dcc_registry_machinery_0
    dcc_registry_machinery_0.find(dcc_0.name)


# Generated at 2022-06-26 00:46:46.268794
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert abs(dcfc_act_365_l(datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), datetime.date(2009, 5, 31)) - Decimal('1.32876712328767')) < 1e-13

    # Unit test for function dcfc_act_365_a

# Generated at 2022-06-26 00:46:53.044108
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:46:57.436359
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    date_0 = None
    date_1 = Date(2016, 1, 1)
    date_2 = Date(2016, 1, 1)
    decimal_0 = ZERO
    decimal_1 = Decimal('0.00273972602739726')

    ## Get the convention:
    dc_convention = DCCRegistry['ACT/ACT']

    ## Calculate fraction:
    decimal_2 = dc_convention.calculate_fraction(date_0, date_1, date_2)

    ## Assert:
    assert decimal_0 == decimal_2


# Generated at 2022-06-26 00:48:30.612727
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Test 1
    date_0 = datetime.date(2012, 8, 3)
    date_1 = datetime.date(2011, 1, 7)
    date_2 = datetime.date(2016, 5, 12)
    assert round(dcfc_act_act(date_2, date_1, date_2), 3) == Decimal('0.011')
    assert round(dcfc_act_act(date_0, date_0, date_0), 1) == Decimal('0.0')


# Generated at 2022-06-26 00:48:35.594219
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    Money = Money(cur = "USD", amount = 10)
    Decimal = Decimal(10)
    date_0 = None
    date_1 = None
    date_2 = None
    dcc_0 = DCC(name = "name", altnames = "altnames", currencies = "currencies", calculate_fraction_method = "calculate_fraction_method")
    decimal_0 = dcc_0.calculate_daily_fraction(date_0, date_1, date_2)
    


# Generated at 2022-06-26 00:48:40.209388
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    print("***** func_unit_test_for_dcfc_30_360_german *****")
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)


# Generated at 2022-06-26 00:48:49.423076
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    date_0 = None
    date_1 = None
    date_2 = None
    date_3 = None
    decimal_0 = None
    decimal_1 = None
    decimal_2 = None
    decimal_3 = None
    decimal_4 = None
    decimal_5 = None
    decimal_6 = None
    decimal_7 = None
    decimal_8 = None
    decimal_9 = None
    decimal_10 = None
    decimal_11 = None
    decimal_12 = None
    decimal_13 = None
    decimal_14 = None
    decimal_15 = None
    decimal_16 = None
    decimal_17 = None
    decimal_18 = None
    decimal_19 = None
    decimal_20 = None
    decimal_21 = None
    decimal_22 = None
    decimal_23 = None
    decimal_

# Generated at 2022-06-26 00:48:54.286047
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    pass
    # start = datetime.date(1999, 12, 30)
    # asof = datetime.date(2000, 1, 1)
    # end = datetime.date(2000, 1, 1)
    # print(dcfc_30_360_us(start, asof, end))

    # '''
    # Output should be:
    # 0.00833333333333333
    # '''


# Generated at 2022-06-26 00:48:59.063708
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    start = datetime.date(2019, 1, 3)
    asof  = datetime.date(2019, 1, 31)
    end   = datetime.date(2019, 1, 31)
    assert round(dcfc_30_360_us(start, asof, end), 15) == round(Decimal(30)/Decimal(360), 15)

if __name__ == "__main__":
    #test_dcfc_30_360_us()
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 00:49:01.395782
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    # Test case 0
    date_0 = None
    decimal_0 = dcfc_30_e_plus_360(date_0, date_0, date_0)
    test_array_0 = np.array([[Decimal(exp) for exp in [21]], [Decimal(exp) for exp in [21]], [Decimal(exp) for exp in [21]]])



# Generated at 2022-06-26 00:49:08.006065
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)
    freq = None
    expected = Decimal('0.16942884946478')
    computed = dcfc_act_act(start, asof, end, freq)
    tol = 1e-14
    success = abs(expected - computed) < tol
    msg = 'computed = %g != %g (expected)' % (computed, expected)
    assert success, msg


# Generated at 2022-06-26 00:49:12.213788
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    # Test case 0
    assert dcfc_act_365_a(datetime.date(2018, 11, 23), datetime.date(2018, 11, 23), datetime.date(2018, 11, 23)) == Decimal('0.0')
    
    # Test case 1
    assert dcfc_act_365_a(datetime.date(2018, 11, 23), datetime.date(2018, 12, 24), datetime.date(2019, 1, 22)) == Decimal('0.40273972602739')
    
    # Test case 2
    assert dcfc_act_365_a(datetime.date(2018, 12, 24), datetime.date(2019, 1, 22), datetime.date(2018, 11, 23)) == Decimal('-0.38356164383561')
    
   

# Generated at 2022-06-26 00:49:20.042034
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    start = datetime.datetime.fromisoformat('2019-01-01')
    asof = datetime.datetime.fromisoformat('2019-01-31')
    end = datetime.datetime.fromisoformat('2019-01-31')
    decimal_0 = dcfc_30_360_isda(start, asof, end)
    decimal_1 = dcfc_30_360_isda(start, asof, end)
    decimal_2 = dcfc_30_360_isda(start, asof, end)
    decimal_3 = dcfc_30_360_isda(start, asof, end)
    decimal_4 = dcfc_30_360_isda(start, asof, end)