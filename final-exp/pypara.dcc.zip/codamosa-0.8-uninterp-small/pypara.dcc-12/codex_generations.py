

# Generated at 2022-06-26 00:42:18.683695
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:42:22.303953
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    dates = [datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)]
    actual_results = []
    for i in dates:
        actual_results.append((i, dcfc_30_e_plus_360(dates[0], i, i)))
    assert actual_results == [(datetime.date(2007, 12, 28), Decimal('0.16666666666667'))]



# Generated at 2022-06-26 00:42:34.239119
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:42:42.268355
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ## Test case 0:
    ex0_start = datetime.date(2007, 12, 28)
    ex0_asof = datetime.date(2008, 2, 28)
    ex0_end = datetime.date(2008, 2, 28)
    ex0_freq = None

    ex0_result = dcfc_30_360_us(ex0_start, ex0_asof, ex0_end, ex0_freq)
    assert round(ex0_result, 14) == Decimal('0.16666666666667')

    ## Test case 1:
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 29)
    ex1_end = datetime.date(2008, 2, 29)
    ex1_

# Generated at 2022-06-26 00:42:52.032983
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Module level unit test for function dcfc_30_360_german
    """
    logging.debug("BEGIN - test_dcfc_30_360_german")
    ret = dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), None)
    if not ret == Decimal('0.16666666666667'):
        logging.error("Expected value is 0.16666666666667, returns %s" % ret)
        raise TypeError()
    ret = dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), None)

# Generated at 2022-06-26 00:43:02.289656
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    dcc_0 = d_c_c_registry_machinery_0.get_dcc_by_name('ACT/360')
    money_0 = Money(Decimal(1.2),Currencies['EUR'])
    money_1 = Money(Decimal(0.5),Currencies['EUR'])
    d_c_c_0 = DCC(dcc_0.name,dcc_0.altnames,dcc_0.currencies,dcc_0.calculate_fraction_method)

# Generated at 2022-06-26 00:43:13.771960
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    from decimal import Decimal
    from .currencies import Currencies
    from .monetary import Money
    from .dcc.base import DCC
    from .commons.zeitgeist import Date
    d_c_c_0 = DCC(name='test_dcc_0', altnames={'test_dcc_0'}, currencies={Currencies(code='AUD', numeric='036', decimals=2)},calculate_fraction_method=None)
    principal = Money(value='2', currency=Currencies(code='AUD', numeric='036', decimals=2))
    rate = Decimal('0.1')
    start=Date(year=2019, month=1, day=1)
    asof=Date

# Generated at 2022-06-26 00:43:23.269924
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    print("\nUnit test for function dcfc_30_360_isda")
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    # ex1_start, ex1_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    #

# Generated at 2022-06-26 00:43:26.904905
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    d_c_c_registry_machinery_1 = DCCRegistryMachinery()
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()


# Generated at 2022-06-26 00:43:32.690925
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Test case 1
    d_c_c_registry_machinery_1 = DCCRegistryMachinery()
    d_c_c_registry_machinery_1.register_dcc("30/360 US")
    result_1 = d_c_c_registry_machinery_1.dcc_factory("30/360 US",datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28))
    assert round(result_1, 14) == 0.16666666666667

    # Test case 2
    d_c_c_registry_machinery_2 = DCCRegistryMachinery()
    d_c_c_registry_machinery_2.register_dcc("30/360 US")
    result

# Generated at 2022-06-26 00:44:14.959074
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-26 00:44:20.499339
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert dcfc_30_360_german(datetime.date(2018, 2, 28), datetime.date(2018, 3, 31), datetime.date(2018, 3, 31)) == Decimal('0.1')
    assert dcfc_30_360_german(datetime.date(2016, 2, 1), datetime.date(2017, 9, 30), datetime.date(2017, 9, 30)) == Decimal('0.869444444444444')
    assert dcfc_30_360_german(datetime.date(2016, 2, 1), datetime.date(2017, 10, 2), datetime.date(2017, 10, 2)) == Decimal('0.869444444444444')


# Generated at 2022-06-26 00:44:24.835371
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    string_0 = "Act/Act"
    d_c_c_0 = DCCRegistry.find(string_0)
    d_c_c_1 = d_c_c_registry_machinery_0.find(string_0)
    assert d_c_c_0 == d_c_c_1


# Generated at 2022-06-26 00:44:27.804019
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert(round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639'))


# Generated at 2022-06-26 00:44:34.871457
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(datetime.date(2000,1,31), datetime.date(2000,2,28), datetime.date(2000,2,28)), 14)==Decimal('0.08333333333333')
    assert round(dcfc_30_360_us(datetime.date(2000,1,31), datetime.date(2000,2,29), datetime.date(2000,2,29)), 14)==Decimal('0.08611111111111')
    assert round(dcfc_30_360_us(datetime.date(1997,2,28), datetime.date(1998,1,30), datetime.date(1998,1,30)), 14)==Decimal('10.083333333333')

# Generated at 2022-06-26 00:44:45.659691
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:44:55.299254
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(date(2018, 6, 30), date(2018, 7, 31), date(2018, 7, 31)) == Decimal(1) / Decimal(360)
    assert dcfc_30_360_us(date(2019, 1, 31), date(2019, 2, 28), date(2019, 2, 28)) == Decimal(28) / Decimal(360)
    assert dcfc_30_360_us(date(2018, 6, 30), date(2018, 7, 31), date(2018, 7, 31), freq=3) == Decimal(1) / Decimal(360)
    assert dcfc_30_360_us(date(2018, 1, 31), date(2018, 2, 28), date(2018, 2, 28), freq=3) == Decimal(28)

# Generated at 2022-06-26 00:45:01.899556
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """Test dcfc_30_360_isda"""
    # Assign values to variables for test
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)

    # Setup test values

# Generated at 2022-06-26 00:45:06.633905
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start = datetime.date(2018, 7, 31)
    ex1_asof = datetime.date(2019, 1, 31)
    assert dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof) == (1.0 / 3)


# Generated at 2022-06-26 00:45:15.086166
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Test case 1
    print("Test case 1: dcfc_30_360_german(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,28))")
    start = datetime.date(2007,12,28)
    asof = datetime.date(2008,2,28)
    assert dcfc_30_360_german(start=start, asof=asof) == 0.166666666666667
    print("Check if it is the same as Excel's DAYS360(28-12-2007,28-02-2008,FALSE)")
    print("It passed!")
    print("")
    # Test case 2

# Generated at 2022-06-26 00:47:40.172625
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    a = datetime.date(2014, 1, 30)
    b = datetime.date(2014, 2, 28)
    c = datetime.date(2014, 3, 31)
    d = datetime.date(2014, 4, 30)
    x = datetime.date(2014, 5, 31)
    y = datetime.date(2014, 6, 30)
    z = datetime.date(2014, 7, 31)

    print(dcfc_30_360_german(a, b, c))
    print(dcfc_30_360_german(b, c, d))
    print(dcfc_30_360_german(c, d, x))
    print(dcfc_30_360_german(d, x, y))

# Generated at 2022-06-26 00:47:50.196082
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal_0 = Money.from_amount(100)
    rate_0 = Decimal(100)
    start_0 = datetime.date(2017, 1, 1)
    asof_0 = datetime.date(2017, 1, 2)
    end_0 = datetime.date(2017, 1, 3)
    freq_0 = 1
    eom_0 = None
    dcc_0 = DCC(name = "name", altnames = set(), currencies = set(), calculate_fraction_method = lambda start, asof, end, freq: 1)
    coupon_result = dcc_0.coupon(principal_0, rate_0, start_0, asof_0, end_0, freq_0, eom_0)
    assert isinstance(coupon_result, Money)


# Generated at 2022-06-26 00:47:55.391768
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():

    # Define dates
    start_date = datetime.date(2007, 12, 28)
    asof_date = datetime.date(2008, 2, 28)
    end_date = datetime.date(2008, 2, 28)

    # Calculate day count fraction using function
    day_count = dcfc_30_360_us(start=start_date, asof=asof_date, end=end_date)

    # Test desired results
    assert round(day_count, 14) == 0.16666666666667


# Generated at 2022-06-26 00:48:01.099161
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    start_date = datetime.date(2020,4,4)
    asof_date = datetime.date(2020,4,20)
    end = asof_date

    actual_value = round(dcfc_30_360_isda(start = start_date,asof =asof_date,end = end ),14)
    expected_value = Decimal('0.16666666666667')

    assert_that(actual_value).is_close_to(expected_value,10**-14)


# Generated at 2022-06-26 00:48:06.595239
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    d_c_c_registry_machinery_1 = DCCRegistryMachinery()
    d_c_c_registry_machinery_1.get_instance(None)
    money_instance_0 = Money(0, None)
    result = d_c_c_registry_machinery_1.get_instance(None).coupon(money_instance_0, 0, None, None, None, None, None)
    assert result == money_instance_0


# Generated at 2022-06-26 00:48:08.998643
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    d_c_c_0 = DCC('1', {'1'}, {'1'}, '1')
    d_c_c_0.calculate_daily_fraction('1', '1', '1')


# Generated at 2022-06-26 00:48:15.576730
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():

    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)

    assert (dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667'))


# Generated at 2022-06-26 00:48:23.134419
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():

    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:48:31.691551
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Test cases:
    # Test case 1:
    # The next method to be tested is calculate_daily_fraction of class DCC
    # Input parameters:
    # method_param_0 = datetime.date(2017, 1, 1)
    # method_param_1 = datetime.date(2017, 1, 1)
    # method_param_2 = datetime.date(2017, 1, 1)
    # method_param_3 = None
    # Expected output:
    # return_value_0 = 0.0
    method_param_0 = datetime.date(2017, 1, 1)
    method_param_1 = datetime.date(2017, 1, 1)
    method_param_2 = datetime.date(2017, 1, 1)
    method_param_3 = None
    return_value_

# Generated at 2022-06-26 00:48:34.515034
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start = datetime.date(2019,2,28)
    ex1_asof = datetime.date(2019,3,1)
    assert dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.0020833333333333')

test_dcfc_30_e_360()
