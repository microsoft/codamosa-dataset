

# Generated at 2022-06-26 00:42:06.378512
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from .currencies import Currency, Currencies
    from .monetary import Money
    
    ccys = Currencies
    
    for ccy in ccys.values():
        test_ccy = Currency(ccy)
        dcc = DCCRegistry[ccy]
        dcc_name = dcc[0]
        dcc_altnames = dcc[1]
        dcc_currencies = dcc[2]
        dcc_calculate_fraction_method = dcc[3]
        
        d_c_c_instance_0 = DCC(dcc_name, dcc_altnames, dcc_currencies, dcc_calculate_fraction_method)
        
        principal_0 = Money(Decimal('0.00'), test_ccy)

# Generated at 2022-06-26 00:42:17.332455
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2008, 1, 1), asof=datetime.date(2008, 12, 31), end=datetime.date(2009, 1, 1)), 10) == Decimal('1.0000000000')
    assert round(dcfc_act_act_icma(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.1721610899')

# Generated at 2022-06-26 00:42:27.069530
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Arrange
    dccExample = DCC(
        name="sample",
        altnames={},
        currencies={},
        calculate_fraction_method=lambda x, y, z, w: 0.0,
    )
    start = datetime.date(year=2020, month=6, day=29)
    asof = datetime.date(year=2020, month=6, day=30)
    end = datetime.date(year=2020, month=7, day=1)

    # Act
    result = dccExample.calculate_daily_fraction(start, asof, end)

    # Assert
    assert (result == Decimal('0.00'))


# Generated at 2022-06-26 00:42:37.875580
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-26 00:42:44.602492
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
  print("Expecting false: " + str(_is_last_day_of_month(datetime.date(2017, 9, 1))))
  print("Expecting false: " + str(_is_last_day_of_month(datetime.date(2017, 9, 30))))
  print("Expecting true: " + str(_is_last_day_of_month(datetime.date(2017, 9, 28))))
  print("Expecting true: " + str(_is_last_day_of_month(datetime.date(2017, 9, 29))))
  print("Expecting 0.16666666666667: " + str(dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))))

# Generated at 2022-06-26 00:42:54.357699
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    # Test Case 1
    start1 = datetime.date(2017,11, 9)
    asof1 = datetime.date(2018, 1, 9)
    end1 = datetime.date(2018, 1, 9)
    assert round(dcfc_30_e_plus_360(start1, asof1, end1), 14) == Decimal('0.16666666666667')

    # Test Case 2
    start2 = datetime.date(2010, 2, 28)
    asof2 = datetime.date(2010, 3, 31)
    end2 = datetime.date(2010, 3, 31)
    assert round(dcfc_30_e_plus_360(start2, asof2, end2), 14) == Decimal('0.16666666666667')

    # Test Case 3
    start3

# Generated at 2022-06-26 00:43:02.410667
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """
    Unit tests for function dcfc_30_360_isda
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-26 00:43:14.035276
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ##
    # Test simple.
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_act_act(start, asof, asof), 14) == Decimal('0.16942884946478')
    ##
    # Test for leap year.
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_act_act(start, asof, asof), 14) == Decimal('0.17216108990194')
    ##
    # Test cross year.
    start, asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)

# Generated at 2022-06-26 00:43:23.471320
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert isinstance(dcfc_act_act(ex1_start, ex1_asof, ex1_asof), Decimal)
    assert dcfc_act_act(ex1_start, ex1_asof, ex1_asof) == Decimal('0.16942884946478')
    assert dcfc_act_act(ex2_start, ex2_asof, ex2_asof) == Decimal('0.17216108990194')
    assert dcfc_act_act(ex3_start, ex3_asof, ex3_asof) == Decimal('1.08243131970956')
    assert dcfc_act_act(ex4_start, ex4_asof, ex4_asof) == Decimal('1.32625945055768')



# Generated at 2022-06-26 00:43:31.336102
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ''' Test case for function dcfc_act_365_l. '''
    # Test case 1
    start_date = datetime.datetime.strptime('2018-12-28', '%Y-%m-%d').date()
    asof_date = datetime.datetime.strptime('2019-02-28', '%Y-%m-%d').date()
    end_date = datetime.datetime.strptime('2019-02-28', '%Y-%m-%d').date()
    assert(dcfc_act_365_l(start=start_date,asof=asof_date,end=end_date)==Decimal('0.16939890710383'))

    # Test case 2

# Generated at 2022-06-26 00:44:12.872346
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert (round(dcfc_30_360_isda(datetime.date(2000, 9, 29), datetime.date(2000, 12, 29), datetime.date(2000, 12, 29)), 14)) ==  Decimal('0.14166666666667')
    assert (round(dcfc_30_360_isda(datetime.date(2000, 9, 30), datetime.date(2000, 12, 30), datetime.date(2000, 12, 30)), 14)) ==  Decimal('0.14444444444444')
    assert (round(dcfc_30_360_isda(datetime.date(2000, 9, 15), datetime.date(2000, 12, 15), datetime.date(2000, 12, 15)), 14)) ==  Decimal('0.15555555555556')
   

# Generated at 2022-06-26 00:44:21.350795
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    test_ex1_start, test_ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    test_ex2_start, test_ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    test_ex3_start, test_ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    test_ex4_start, test_ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-26 00:44:29.107444
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 2), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 2), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 8, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-26 00:44:37.567596
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-26 00:44:47.483878
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    '''
    Define a set of tests for the dcfc_30_360_german function
    '''

    # Test cases
    tests = [[datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), Decimal(0.16666666666667)],
             [datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), Decimal(0.16944444444444)],
             [datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), Decimal(1.08333333333333)],
             [datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), Decimal(1.33055555555556)]]

    # Execute the tests

# Generated at 2022-06-26 00:44:57.065091
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    # Check first test case
    assert round(dcfc_30_e_plus_360(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 28), end = datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    # Check second test case
    assert round(dcfc_30_e_plus_360(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 29), end = datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    # Check third test case

# Generated at 2022-06-26 00:45:06.225651
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert pytest.approx(dcfc_30_360_us(start=datetime.date(2017, 12, 12), asof=datetime.date(2018, 2, 8), end=datetime.date(2018, 2, 8)), 0.0001) == 0.055556
    assert pytest.approx(dcfc_30_360_us(start=datetime.date(2018, 12, 12), asof=datetime.date(2019, 2, 28), end=datetime.date(2019, 2, 28)), 0.0001) == 0.083333
    assert pytest.approx(dcfc_30_360_us(start=datetime.date(2017, 12, 12), asof=datetime.date(2019, 1, 31), end=datetime.date(2019, 1, 31)), 0.0001)

# Generated at 2022-06-26 00:45:14.794656
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Inputs
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    start1, asof1 = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    start2, asof2 = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    start3, asof3 = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    # Expected returns
    return_0 = Decimal('0.16942884946478')
    return_1 = Decimal('0.17216108990194')
    return_2 = Decimal('1.08243131970956')

# Generated at 2022-06-26 00:45:21.916558
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Given
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_registry_machinery_1 = DCCRegistryMachinery(1)
    d_c_c_registry_machinery_0.DCCS.append(d_c_c_registry_machinery_1)
    principal = Money(15, Currencies.DKK)
    rate = Decimal('0.5')
    start = Date(1, 4, 1)
    asof = Date(1, 4, 2)
    end = Date(1, 4, 3)
    freq = None
    d_c_c_registry_machinery_0.DCCS[0]._name = str()
    d_c_c_registry_m

# Generated at 2022-06-26 00:45:29.903748
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 00:49:42.870556
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    start = datetime.date(2018,9,9)
    asof = datetime.date(2018,9,9)
    end = datetime.date(2018,9,9)
    freq = 1
    eom = 9
    principal = Money.parse("100.0 EUR")
    rate = 0.1
    dcc = DCC(name="Actual/Actual ISDA",altnames=set(),currencies=set(),calculate_fraction_method=lambda a, b, c, d: 1)

    money = dcc.coupon(principal, rate, start, asof, end, freq, eom)
    assert money == Money.parse("10 EUR")

    start = datetime.date(2018,9,9)
    asof = datetime.date(2018,9,9)


# Generated at 2022-06-26 00:49:49.682778
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    assert round(dcfc_30_360_us(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.16944444444444')

    ex3_start = datetime.date(2007, 10, 31)
   

# Generated at 2022-06-26 00:50:01.506554
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    # Test 1
    assert (round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478'))


# Generated at 2022-06-26 00:50:10.646965
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert(round(dcfc_act_act(start=datetime.date(2008, 7, 20), asof=datetime.date(2008, 7, 20), end=datetime.date(2008, 7, 20)), 14) == Decimal('0'))
    assert(round(dcfc_act_act(start=datetime.date(2019, 6, 22), asof=datetime.date(2019, 9, 3), end=datetime.date(2020, 1, 23)), 14) == Decimal('0.041352818184165'))

# Generated at 2022-06-26 00:50:16.779179
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    d_start = datetime.date(2020, 12, 21)
    d_asof = datetime.date(2020, 12, 22)
    d_end = datetime.date(2020, 12, 23)
    d_freq = None
    d_return = Decimal(1)
    d_return_value = DCCRegistryMachinery().DCC_actual_actual_ISMA.calculate_daily_fraction(d_start, d_asof, d_end, d_freq)
    assert d_return_value == d_return, "Return value mismatch"


# Generated at 2022-06-26 00:50:22.774859
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2017, 10, 1), datetime.date(2017, 10, 2), datetime.date(2017, 10, 3)), 14) == Decimal('0.004166666666667')
    assert round(dcfc_30_360_isda(datetime.date(2017, 2, 28), datetime.date(2017, 3, 1), datetime.date(2017, 3, 2)), 14) == Decimal('0.004166666666667')
    assert round(dcfc_30_360_isda(datetime.date(2017, 10, 31), datetime.date(2017, 11, 30), datetime.date(2017, 12, 31)), 14) == Decimal('0.04166666666667')

# Generated at 2022-06-26 00:50:26.925679
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # Test 1
    d_c_c_registry_machinery_1 = DCCRegistryMachinery()
    d_c_c_0 = DCC('', set(), set(), DCFC(lambda start, asof, end, freq: None))
    try:
        d_c_c_registry_machinery_1.register(d_c_c_0)
        assert False, 'expected exception here'
    except TypeError as e:
        assert str(e) == "Day count convention 'Act/Act' is already registered"


# Generated at 2022-06-26 00:50:29.027450
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert pd.Timedelta('90 days 00:00:00') == dcfc_30_360_us(start=datetime.date(2018, 1, 1), asof=datetime.date(2018, 4, 1), end=datetime.date(2018, 4, 1))


# Generated at 2022-06-26 00:50:36.443227
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from . import Currencies
    dcc_0 = DCC(name="ACT_ACT_ISDA",
                altnames=[],
                currencies={Currencies.USD},
                calculate_fraction_method=lambda start, asof, end, freq: _get_actual_day_count(start, asof) / _get_actual_day_count(start, end))
    money_0 = Money(amount=Decimal('11.0000000'), currency=Currencies.USD)
    start_0 = Date(year=2013, month=11, day=29)
    asof_0 = Date(year=2014, month=2, day=1)
    end_0 = Date(year=2014, month=2, day=4)
    freq_0 = ONE

# Generated at 2022-06-26 00:50:39.104423
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():

    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_registry_machinery_0.register(DCC('', {}, {}, 0))
    assert d_c_c_registry_machinery_0._is_registered('0') == True
