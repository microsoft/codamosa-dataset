

# Generated at 2022-06-26 00:41:57.850841
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    print('Test day count fraction "30E/360"')
    # Test case 1:
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = asof
    assert round(dcfc_30_e_360(start, asof, end), 14) == Decimal('0.16666666666667')
    # Test case 2:
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)
    end = asof
    assert round(dcfc_30_e_360(start, asof, end), 14) == Decimal('0.16944444444444')
    # Test case 3:
    start = datetime.date(2007, 10, 31)

# Generated at 2022-06-26 00:42:03.741566
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    print("Test for function dcfc_30_360_us ...")
    assert round(dcfc_30_360_us(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 28), end = datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 29), end = datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-26 00:42:04.610752
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert True # What to test?

# Generated at 2022-06-26 00:42:10.331148
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)
    dcfc_nl_365_ret_0 = dcfc_nl_365(start, asof, end)
    print(dcfc_nl_365_ret_0)
    assert dcfc_nl_365_ret_0 == Decimal('0.16986301369863')
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)
    end = datetime.date(2008, 2, 29)
    dcfc_nl_365_ret_1 = dcfc_nl_365(start, asof, end)

# Generated at 2022-06-26 00:42:19.344868
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    date_0 = module_0.date(2008,2, 1)
    date_1 = module_0.date(2009,5, 31)
    date_2 = module_0.date(2009,5, 31)
    decimal_0 = dcfc_act_365_a(date_0, date_1, date_2)
    decimal_1 = Decimal('1.32513661202186')
    decimal_0 = decimal_0.quantize(decimal_1)
    assert(decimal_0 == decimal_1)


# Generated at 2022-06-26 00:42:30.354382
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    from math import isclose
    from pandas import DataFrame
    from pandas.util.testing import assert_frame_equal
    from natcap.invest import datetime

    # Test DataFrame
    verify_data = 'dcc_test_data_30_e_360.csv'
    calc_data = 'dcc_test_data_30_e_360_calc.csv'  # result

    #Read in pre-calculated test data
    verification = pd.read_csv(verify_data)

    #Create DataFrame to hold calculated results
    calc_results = pd.DataFrame(index=['dcf'], columns=verification.columns)

    #Compute day_count_fraction in calc_results DataFrame

# Generated at 2022-06-26 00:42:38.026293
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    # Boolean for checking if test case passed
    passed = True
    # Get the date that is used in the test
    start = datetime.date(2008, 2, 1)
    end = datetime.date(2009, 5, 31)
    testcase = start
    # Calculate expected output
    expected_output = 1.32513661202186
    # Get the actual output
    actual_output = dcfc_act_365_a(start, testcase, end, None)
    # Check if the test case passes
    if actual_output != expected_output:
        passed = False
    assert passed



# Generated at 2022-06-26 00:42:44.695026
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    from datetime import date
    import itertools
    k = [0, 1]
    k_1 = list(itertools.product(k, k, k))
    for first, second, third in k_1:
        assert abs(dcfc_act_365_l(date(2007, 12, 28), date(2008, 2, 28), date(2008, 2, 28)) - 0.16939890710383) < 0.000001
        assert abs(dcfc_act_365_l(date(2007, 12, 28), date(2008, 2, 29), date(2008, 2, 29)) - 0.17213114754098) < 0.000001

# Generated at 2022-06-26 00:42:54.552709
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    import calendar as module_0
    import datetime as module_1
    from decimal import Decimal as class_0

    # Test cases for dcfc_act_act

    # Default values for arguments
    ex1_start = module_1.date(2007, 12, 28)
    ex1_asof = module_1.date(2008, 2, 28)
    ex2_start = module_1.date(2007, 12, 28)
    ex2_asof = module_1.date(2008, 2, 29)
    ex3_start = module_1.date(2007, 10, 31)
    ex3_asof = module_1.date(2008, 11, 30)
    ex4_start = module_1.date(2008, 2, 1)

# Generated at 2022-06-26 00:43:04.090110
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_us(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-26 00:43:28.260444
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    principal = Money(0.1, Currencies.GBP)
    rate = Decimal(0.1)
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 2, 1)
    end = datetime.date(2017, 3, 1)
    freq = Decimal(1)
    interest = Decimal(0.00273972602739726)
    eom = 15
    value = DCCs.ACT_360.calculate_daily_fraction(start, asof, end, freq)
    assert value == interest



# Generated at 2022-06-26 00:43:33.479951
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    date1=datetime.date(2007, 12, 28)
    date2=datetime.date(2008, 2, 28)
    date3=datetime.date(2008, 2, 29)
    date4=datetime.date(2007, 10, 31)
    date5=datetime.date(2008, 11, 30)
    date6=datetime.date(2008, 2, 1)
    date7=datetime.date(2009, 5, 31)
    assert dcfc_act_365_a(date1,date2,date2) == Decimal('0.16986301369863')
    assert dcfc_act_365_a(date1,date3,date3) == Decimal('0.17213114754098')

# Generated at 2022-06-26 00:43:47.230749
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():

    # Setup
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)

    ## Get D1 and D2:
    d1 = start.day
    d2 = asof.day

    ## Need to change D1?
    if _is_last_day_of_month(start):
        ## Yep, change it:
        d1 = 30

        ## Shall we change the d2, too?
        if _is_last_day_of_month(asof):
            d2 = 30

    ## Revisit d2:
    if d2 == 31 and (d1 == 30 or d1 == 31):
        d2 = 30

    ## Revisit d1:

# Generated at 2022-06-26 00:43:56.151351
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc_registry = DCCRegistryMachinery()

    # Test with a negative number
    dcc = DCC("TEST1", {"TEST1"}, set(), dcfc_30_360)
    dcc_registry.register(dcc)
    assert dcc_registry.find("test1") == dcc

    # Test with a positive number
    dcc = DCC("TEST2", {"TEST2"}, set(), dcfc_act_360)
    dcc_registry.register(dcc)
    assert dcc_registry.find("test2") == dcc

    # Test with zero
    dcc = DCC("TEST3", {"TEST3"}, set(), dcfc_act_360)
    dcc_registry.register(dcc)

# Generated at 2022-06-26 00:44:07.992205
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), datetime.date(2009, 5, 31)) == Decimal('1.33055555555556')
    assert dcfc_30_e_360(datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), datetime.date(2009, 7, 31)) == Decimal('1.34626984126984')
    assert dcfc_30_e_360(datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), datetime.date(2009, 11, 30)) == Decimal('2.27777777777778')

# Generated at 2022-06-26 00:44:11.717920
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    start = datetime.date(2018, 12, 28)
    asof = datetime.date(2019, 2, 28)
    end = datetime.date(2019, 2, 28)
    result = dcfc_30_360_isda(start, asof, end)
    assert result == 0.16666666666667


# Generated at 2022-06-26 00:44:14.929044
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():

    # Arrange
    start = datetime.date(2018, 5, 15)
    asof = datetime.date(2018, 5, 31)
    end = datetime.date(2018, 6, 15)

    # Act
    result = dcfc_30_e_plus_360(start, asof, end)

    # Assert
    assert Decimal("0.16666666666667") == result



# Generated at 2022-06-26 00:44:17.913277
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    tuple_0 = DCC("Act/Act", {"Act/Act"}, {"USD"}, dcfc_act_act)
    dccregistrymachinery_0 = DCCRegistryMachinery()
    dccregistrymachinery_0.register(tuple_0)
    assert dccregistrymachinery_0.find("Act/Act") == tuple_0


# Generated at 2022-06-26 00:44:23.632424
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_e_plus_360(start=ex2_start, asof=ex2_asof, end=ex2_asof) == Decimal('0.16944444444444')
    assert dcfc_30_e_plus_360(start=ex3_start, asof=ex3_asof, end=ex3_asof) == Decimal('1.08333333333333')

# Generated at 2022-06-26 00:44:27.616327
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=module_1.date(2019, 3, 2), asof=module_1.date(2019, 9, 10), end=module_1.date(2020, 3, 2)), 10) == Decimal('0.5245901639')


## Unit tests for all methods of the DayCount class:

# Generated at 2022-06-26 00:45:06.508752
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    # Convention name: Act/Act
    # Frequency: Annual
    # Start date: 2019-03-02
    # As of date: 2019-07-05
    # End date: 2020-03-02
    # Result: 0.261194029850746
    date_0 = module_1.date(2019, 3, 2)
    date_1 = module_1.date(2019, 7, 5)
    date_2 = module_1.date(2020, 3, 2)
    decimal_0 = dcfc_act_act_icma(date_0, date_1, date_2, None)
    print(decimal_0)


# Generated at 2022-06-26 00:45:11.643095
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # Test the invoking of a method having a return type
    assert dcc_act_365_fixed.name is not None, "Method register did not return a value"
    # Test that the method raised an error when called with invalid argument values
    try:
        dcc_act_360.register(dcc)
    except TypeError:
        pass
    else:
        raise Exception("Expected TypeError, but no exception was raised")


# Generated at 2022-06-26 00:45:18.828856
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    ## Construct some date:
    start = datetime.date(2014, 12, 15)
    end = datetime.date(2016, 1, 6)
    asof = datetime.date(2015, 12, 15)

    ## Calculate daily fraction with 30/360:
    assert DCC.ACT_30_360.calculate_daily_fraction(start, asof, end) == Decimal("0.025")

    ## Calculate daily fraction with 30E/360:
    assert DCC.ACT_30E_360.calculate_daily_fraction(start, asof, end) == Decimal("0.025")

    ## Calculate daily fraction with 30E+/360:

# Generated at 2022-06-26 00:45:26.525038
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    obj = DCCRegistryMachinery()
    dcc = _BUILTIN_DCCS[0]
    obj.register(dcc)
    assert obj._buffer_main.get(dcc.name) == dcc
    assert obj._buffer_altn.get(dcc.altnames[0]) == dcc

if __name__ == "__main__":
    test_case_0()
    test_DCCRegistryMachinery_register()
 
# Snippet from: https://github.com/wesm/pydata-book/blob/2nd-edition/examples/ipython_bug.py
# Date: 2015-12-16
from IPython.core.display import HTML
HTML("<script>Jupyter.notebook.kernel.restart()</script>")
 
# Sn

# Generated at 2022-06-26 00:45:30.754025
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(ex1_start, ex1_asof, ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-26 00:45:33.782152
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    date_0 = datetime.date()
    date_1 = datetime.date()
    date_2 = datetime.date()
    decimal_0 = dcc_act_360.calculate_daily_fraction(date_0, date_1, date_2)


# Generated at 2022-06-26 00:45:37.591522
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Define a local instance of the DCC class
    instance = DCC("name", "altnames", "currencies", "calculate_fraction_method")
    # Attempt to call the method with different parameters
    instance.calculate_fraction(date, date, date)

# Generated at 2022-06-26 00:45:45.904583
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert Decimal('0.16666666666667') == dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))
    assert Decimal('0.16944444444444') == dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29))
    assert Decimal('1.08333333333333') == dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30))
    assert Decimal('1.33333333333333') == dcfc_30_360_isda

# Generated at 2022-06-26 00:45:50.338926
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    date_0 = datetime.date()
    date_1 = datetime.date()
    date_2 = datetime.date()
    decimal_0 = decimal()
    decimal_1 = dcc_0.calculate_fraction(date_0, date_1, date_2, decimal_0)


# Generated at 2022-06-26 00:45:52.565750
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    # Setting up
    string_0 = "    "
    dcc_0 = DCCRegistry.find(string_0)
    # Testing
    assert dcc_0 is not None


# Generated at 2022-06-26 00:50:51.777121
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    date_0 = module_1.date(2000, 11, 20)
    date_1 = module_1.date(2001, 8, 7)
    decimal_0 = dcfc_30_360_isda(date_0, date_1, date_1)
    assert decimal_0 == 0.23055555555556


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 00:50:55.814951
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Create a DCC instance
    someDcc = DCC()

    # Some date variables to work with
    start = datetime.date(2019, 1, 15)
    asof = datetime.date(2019, 1, 18)
    end = datetime.date(2019, 1, 19)

    # Calculate the daily fraction
    decimal_0 = someDcc.calculate_daily_fraction(start, asof, end)
    print(decimal_0)


# Generated at 2022-06-26 00:51:02.061151
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    print("Method calculate_daily_fraction")

    # Case 0
    date_0 = module_1.date()
    date_1 = module_1.date()
    date_2 = module_1.date()
    result = self.calculate_daily_fraction(date_0, date_1, date_2)
    assert result == decimal_0

    # Case 1
    date_0 = module_1.date()
    date_1 = module_1.date()
    date_2 = module_1.date()
    result = self.calculate_daily_fraction(date_0, date_1, date_2)
    assert result == decimal_0

    # Case 2
    date_0 = module_1.date()
    date_1 = module_1.date()
    date_2 = module

# Generated at 2022-06-26 00:51:05.461158
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    start = module_1.date()
    asof = module_1.date()
    end = module_1.date()
    freq = Decimal()
    decimal_0 = dcc_2.calculate_daily_fraction(start, asof, end, freq)


# Generated at 2022-06-26 00:51:07.999764
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # Insert code here to implement the test
    print_function('Pass')

if __name__ == "__main__":
    test_dcfc_30_360_isda()

 

# Generated at 2022-06-26 00:51:09.914037
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert True == True

if __name__ == '__main__':
    print(test_case_0())
    test_dcfc_act_act_icma()


# Generated at 2022-06-26 00:51:15.841549
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    examples_of_dates = [
    datetime.date(2007,12,28), datetime.date(2008,2,28),
    datetime.date(2007,12,28), datetime.date(2008,2,29),
    datetime.date(2007,10,31), datetime.date(2008,11,30),
    datetime.date(2008,2,1), datetime.date(2009,5,31)
    ]
    examples_of_results = [
    0.16939890710383, 0.17213114754098,
    1.08196721311475, 1.32876712328767
    ]
    for i in range(4):
        start = examples_of_dates[i*2]
        asof = examples_of_dates[i*2+1]
       