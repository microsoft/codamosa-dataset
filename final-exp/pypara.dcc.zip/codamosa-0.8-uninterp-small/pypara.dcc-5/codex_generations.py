

# Generated at 2022-06-26 00:42:17.375474
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """
    Tests cases for the dcfc_30_360_isda function.
    """
    ## Example 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    print(round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

    ## Example 2:

# Generated at 2022-06-26 00:42:25.278120
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert(dcfc_30_360_us(start=datetime.date(2019, 5, 31), asof=datetime.date(2019, 7, 5), end=datetime.date(2020, 7, 5))==0.055555555555555)
    assert(dcfc_30_360_us(start=datetime.date(2019, 5, 31), asof=datetime.date(2019, 7, 5), end=datetime.date(2019, 7, 5))==0.055555555555555)

# Generated at 2022-06-26 00:42:36.363057
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_360_

# Generated at 2022-06-26 00:42:46.919837
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    print('Testing dcfc_act_act ... ', end='')
    assert(round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) ==
           Decimal('0.16942884946478'))
    assert(round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) ==
           Decimal('0.17216108990194'))

# Generated at 2022-06-26 00:42:53.298493
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    from ..date import Date
    from decimal import Decimal

    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')

# Generated at 2022-06-26 00:43:03.226770
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Test dcfc_30_360_us for 28 days
    d_s = datetime.date(2019,1,1)
    d_f = datetime.date(2019,1,28)
    d = dcfc_30_360_us(d_s,d_f,d_f)
    assert d == 0.0833333333333333
    print("Test dcfc_30_360_us for 28 days passed")

    # Test dcfc_30_360_us for 29 days
    d_s = datetime.date(2019,1,1)
    d_f = datetime.date(2019,1,29)
    d = dcfc_30_360_us(d_s,d_f,d_f)
    assert d == 0.0833333333333333

# Generated at 2022-06-26 00:43:14.268426
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Declare variables
    d_c_c_registry_machinery = DCCRegistryMachinery()
    test_accrual_add_method_0 = _add_method()
    test_accrual_add_method_1 = _add_method()
    test_accrual_add_method_2 = _add_method()
    test_accrual_add_method_3 = _add_method()
    test_accrual_add_method_4 = _add_method()
    test_accrual_add_method_5 = _add_method()
    test_accrual_add_method_6 = _add_method()
    test_accrual_add_method_7 = _add_method()
    test_accrual_add_method_8 = _add_method()


# Generated at 2022-06-26 00:43:23.710309
# Unit test for function dcfc_30_360_isda

# Generated at 2022-06-26 00:43:27.607656
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_registry_machinery_0.register(d_c_c_0)


# Generated at 2022-06-26 00:43:33.080890
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Test cases:
    # 1st:
    d_1_1 = datetime.date(2017, 11, 2)
    d_2_1 = datetime.date(2017, 11, 30)
    # 2nd:
    d_1_2 = datetime.date(2017, 12, 2)
    d_2_2 = datetime.date(2017, 12, 31)
    # 3rd:
    d_1_3 = datetime.date(2017, 11, 2)
    d_2_3 = datetime.date(2017, 11, 30)
    # 4th:
    d_1_4 = datetime.date(2017, 9, 30)
    d_2_4 = datetime.date(2017, 12, 31)
    # 5th:
    d_1_5 = datetime.date

# Generated at 2022-06-26 00:44:43.255550
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    principal = Money("USD", Decimal("1000000"), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal("0.01")

    dcc_registry_machinery_0 = DCCRegistryMachinery()
    dcc_registry_machinery_0.register(DCC(name="Test0", altnames=set(), currencies=set(), calculate_fraction_method=ActualActualICMA().calculate_daycount_fraction))
    dcc_registry_machinery_0.register(DCC(name="Test1", altnames=set(), currencies=set(), calculate_fraction_method=ActualActualICMA().calculate_daycount_fraction))
    d

# Generated at 2022-06-26 00:44:52.314282
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Set up
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    e_p_act_exact_m_class_0 = d_c_c_registry_machinery_0.get_dcc_by_name("Actual/Exact")
    date_0 = Date(2018, 10, 6)
    date_1 = Date(2018, 10, 6)
    date_2 = Date(2018, 10, 6)
    expected_result_0 = ONE
    freq_0 = None
    # Call the method
    actual_result_0 = e_p_act_exact_m_class_0.calculate_fraction(date_0, date_1, date_2, freq_0)
    # Verify the result
    assert actual_result

# Generated at 2022-06-26 00:44:57.896243
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')


# Generated at 2022-06-26 00:45:07.342218
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-26 00:45:13.799558
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d_c_c_0 = DCC("ACTUAL/ACTUAL (ISDA)", set(), set(), lambda start, asof, end, freq: Decimal("1"))
    start_0 = datetime.date(2010, 1, 1)
    asof_0 = datetime.date(2011, 1, 1)
    end_0 = datetime.date(2011, 1, 1)
    tuple_assignment_0 = d_c_c_0.calculate_fraction(start_0, asof_0, end_0)
    assert tuple_assignment_0 == Decimal("1")


# Generated at 2022-06-26 00:45:21.117105
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc = DCCRegistry.find("Act/Act")
    assert dcc.name == "Act/Act", "Incorrect day count name"
    assert dcc.calculate_fraction_method(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16942884946478'), "Incorrect day count fraction"
    assert dcc.interest(Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today()), Decimal(0.01), datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)).qty == Decimal('1694.29'), "Incorrect interest calculation"

## Defines the day count

# Generated at 2022-06-26 00:45:28.320697
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # Test case 1
    ex1_start, ex1_asof, ex1_dc_fraction_expected = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), Decimal('0.16666666666667')
    ex1_dc_fraction_computed = dcfc_30_e_360(start = ex1_start, asof = ex1_asof, end = ex1_asof)
    assert ex1_dc_fraction_expected == ex1_dc_fraction_computed

    # Test case 2
    ex2_start, ex2_asof, ex2_dc_fraction_expected = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), Decimal('0.16944444444444')
    ex2_dc

# Generated at 2022-06-26 00:45:36.701008
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Example from https://en.wikipedia.org/wiki/Day_count_convention
    dcc_machinery_0 = DCC(name = "Actual/360",
                          altnames = set(),
                          currencies = set(),
                          calculate_fraction_method = lambda start, asof, end, freq: Decimal(_get_actual_day_count(start, asof)) / 360)
    assert dcc_machinery_0.calculate_daily_fraction(datetime.date(2000, 1, 1), datetime.date(2000, 1, 2), datetime.date(2000, 2, 1)) == ONE / 360

# Generated at 2022-06-26 00:45:44.469306
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-26 00:45:53.618813
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():

    # Test case 1.1
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

    # Test case 1.2
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_30_360_german(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.16944444444444')

    # Test case 1

# Generated at 2022-06-26 00:47:17.206335
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:47:23.260867
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():

    def func_case_1():
        # Parameters
        start = datetime.date(year=2007, month=12, day=28)
        asof = datetime.date(year=2008, month=2, day=28)
        end = datetime.date(year=2008, month=2, day=28)
        # Expected result
        expected_result = Decimal('0.16666666666667')
        # Function under test
        actual_result = round(dcfc_30_e_plus_360(start=start, asof=asof, end=end), 14)
        # Verify
        assert actual_result == expected_result

    def func_case_2():
        # Parameters
        start = datetime.date(year=2007, month=12, day=28)

# Generated at 2022-06-26 00:47:30.561501
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_end = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_end = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_end, end=ex1_end), 14) == 0.16939890710383, 'Expected result is not matching'

# Generated at 2022-06-26 00:47:41.844689
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    print('Testing method calculate_daily_fraction of class DCC')
    dcc_object = DCC('B3', {'B3', 'b3'}, {Currencies['USD'], Currencies['RUB']}, TestClass)
    start = Date(2017, 1, 1)
    asof = Date(2017, 1, 10)
    end = Date(2017, 1, 15)
    freq = None
    # The following call will fail if the name of the method calculate_fraction_method in class DCC is altered
    assert dcc_object.calculate_daily_fraction(start, asof, end, freq) == Decimal(1.0)


# Generated at 2022-06-26 00:47:51.202526
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(datetime.date(2007,12,28), datetime.date(2008,2,28), datetime.date(2008,2,28)) == Decimal('0.16666666666667')
    assert dcfc_30_360_us(datetime.date(2007,12,28), datetime.date(2008,2,29), datetime.date(2008,2,29)) == Decimal('0.16944444444444')
    assert dcfc_30_360_us(datetime.date(2007,10,31), datetime.date(2008,11,30), datetime.date(2008,11,30)) == Decimal('1.08333333333333')

# Generated at 2022-06-26 00:47:59.360814
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
  principal = Money(100,'EUR')
  rate = Decimal(0.1)
  start = datetime.date(2014, 1, 1)
  asof = datetime.date(2014, 1, 1)
  end = datetime.date(2014, 1, 2)
  freq = Decimal(1)
  temp_DCC = DCC('ACT/360', {'ACT/360', 'ACTUAL/360', 'ACT_360'}, _as_ccys({'EUR', 'USD'}), lambda start, asof, end, freq: _get_actual_day_count(asof, end) / 360)
  result = temp_DCC.calculate_fraction(start, asof, end, freq)
  expected = 0.0027777777777778

# Generated at 2022-06-26 00:48:04.649176
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    # Test 1
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_registry_machinery_0.register(DCC("Act/Act", {"Act/Act", "Actual/Actual"}, {"AUD", "CAD", "EUR", "GBP", "JPY", "USD"}))
    print(d_c_c_registry_machinery_0.find("Act/Act"))
    assert d_c_c_registry_machinery_0.find("Act/Act").name == "Act/Act"
    assert d_c_c_registry_machinery_0.find("Act/Act").altnames == {"Act/Act", "Actual/Actual"}
    assert d_c_c_registry_machinery

# Generated at 2022-06-26 00:48:13.306251
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    print("Testing dcfc_30_360_isda()...", end="")

    # USD example from ISDA documentation
    assert(dcc_factory("30/360 ISDA", datetime.date(2014, 11, 17), datetime.date(2023, 8, 15), datetime.date(2049, 11, 15)) == 0.08869565217391304)
    assert(dcc_factory("30/360 ISDA", datetime.date(2014, 11, 17), datetime.date(2023, 8, 15)) == 0.08869565217391304)

# Generated at 2022-06-26 00:48:18.522615
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)
    start2 = datetime.date(2008, 2, 29)
    asof2 = datetime.date(2008, 4, 30)
    start3 = datetime.date(2008, 2, 28)
    asof3 = datetime.date(2008, 4, 29)
    start4 = datetime.date(2008, 2, 28)
    asof4 = datetime.date(2008, 4, 30)
    start5 = datetime.date(2008, 2, 29)
    asof5 = datetime.date(2008, 4, 29)

# Generated at 2022-06-26 00:48:21.930753
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert dcfc_act_act_icma( start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=4) == 0.5245901639344262


# Generated at 2022-06-26 00:49:43.874392
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    str_0 = 'o+|BjKDd-VKJ-{x+0&5K'
    str_1 = 'h>9CKBY?r&3qP(J7<u}%'
    str_2 = 'gNjK^Tf+R,HJ$FyN"j/B'
    str_3 = '%4Zqm+aA)?KXm,m*?}Y'
    optional_0 = DCCRegistryMachinery.instance()
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_0 = d_c_c_registry_machinery_0.find(str_1)
    money_0 = Money.ZERO

# Generated at 2022-06-26 00:49:48.106546
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    import unittest
    import numpy as np
    import datetime


# Generated at 2022-06-26 00:50:00.042853
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    test_DCC = DCC(name="test",altnames={"alt"},currencies={Currencies.USD},calculate_fraction_method=lambda a,b,c,d: ONE)
    principal_0 = Money(1.00, Currencies.USD)
    rate_0 = Decimal(1.0)
    start_0 = Date(2012, 12, 15)
    asof_0 = Date(2016, 1, 6)
    end_0 = Date(2015, 12, 15)
    freq_0 = Decimal(2)
    eom_0 = 15 
    print(test_DCC.coupon(principal_0, rate_0, start_0, asof_0, end_0, freq_0, eom_0))

test_DCC_coupon()


# Generated at 2022-06-26 00:50:07.748535
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    start_0 = datetime.date(year=2018, month=1, day=31)
    asof_0 = datetime.date(year=2018, month=2, day=1)
    end_0 = datetime.date(year=2019, month=1, day=31)
    freq_0 = None
    dcfc_30_360_us_result_0 = dcfc_30_360_us(start_0, asof_0, end_0, freq_0)
    assert round(dcfc_30_360_us_result_0, 14) == Decimal('0.0027777777777778')


# Generated at 2022-06-26 00:50:16.295859
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Test valid operation with valid input
    start = datetime.date(2010, 1, 1)
    asof = datetime.date(2010, 2, 1)
    end = datetime.date(2010, 2, 28)
    actual_0 = dcfc_30_360_german(start, asof, end)
    expected_0 = Decimal('0.08333333333333')
    assert_equal(actual_0, expected_0)

    start = datetime.date(2010, 1, 31)
    asof = datetime.date(2010, 2, 28)
    end = datetime.date(2010, 2, 28)
    actual_1 = dcfc_30_360_german(start, asof, end)
    expected_1 = Decimal('0.08333333333333')
    assert_equal

# Generated at 2022-06-26 00:50:19.389516
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Test case with test object as argument
    str_0 = 'b<nX/Q!]*jDl"k}f*p3#'
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    optional_0 = d_c_c_registry_machinery_0.find(str_0)



# Generated at 2022-06-26 00:50:23.412959
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    str_0 = 'b<nX/Q!]*jDl"k}f*p3#'
    optional_0 = d_c_c_registry_machinery_0.find(str_0)



# Generated at 2022-06-26 00:50:28.802194
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    start_0 = datetime.date(2008, 2, 1)
    asof_0 = datetime.date(2009, 5, 31)
    end_0 = datetime.date(2009, 5, 31)
    freq_0 = 1
    assert [dcfc_30_360_isda(start_0, asof_0, end_0, freq_0), datetime.date(2009, 5, 31)] == [Decimal('1.33333333333333'), datetime.date(2009, 5, 31)]
    start_1 = datetime.date(2007, 12, 28)
    asof_1 = datetime.date(2008, 2, 28)
    end_1 = datetime.date(2008, 2, 28)
    freq_1 = 1

# Generated at 2022-06-26 00:50:32.575993
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    datetime_0 = datetime.date(year=2017, month=12, day=31)
    datetime_1 = datetime.date(year=2017, month=12, day=31)
    datetime_2 = datetime.date(year=2017, month=12, day=31)
    result_0 = dcfc_30_360_us(start=datetime_0, asof=datetime_1, end=datetime_2)
    print(result_0)


# Generated at 2022-06-26 00:50:37.058599
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')