

# Generated at 2022-06-26 00:42:00.918057
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    import datetime
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 8) == Decimal('0.52459016')


# Generated at 2022-06-26 00:42:10.650514
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-26 00:42:20.175042
# Unit test for method find of class DCCRegistryMachinery

# Generated at 2022-06-26 00:42:25.065093
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_e

# Generated at 2022-06-26 00:42:36.149519
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-26 00:42:46.839118
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Preparation
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    # Assertions

# Generated at 2022-06-26 00:42:47.810005
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert True == True



# Generated at 2022-06-26 00:42:56.893948
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Default case
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    start = datetime.date(year=2017, month=8, day=29)
    asof = datetime.date(year=2018, month=1, day=2)
    end = datetime.date(year=2018, month=3, day=2)
    result = d_c_c_registry_machinery_0.d_c_c_registry.act_act.calculate_fraction(start=start,asof=asof,end=end)
    assert result == Decimal('0.14935064935064935009')
    # Base case
    start = datetime.date(year=2017, month=8, day=29)

# Generated at 2022-06-26 00:43:03.368626
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    start = _day_to_date(19)
    asof = _day_to_date(996)
    end = _day_to_date(1033)
    freq = Decimal(1.0)
    dcfc_act_act_icma_actual = dcfc_act_act_icma(start, asof, end)
    dcfc_act_act_icma_expected = Decimal('6.13445378151261')
    assert_equal(dcfc_act_act_icma_actual, dcfc_act_act_icma_expected)


# Generated at 2022-06-26 00:43:09.379079
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(datetime.date(2007,12,28),datetime.date(2008,2,28),datetime.date(2008,2,28)),14) == round(Decimal('0.16666666666667'),14)
    assert round(dcfc_30_360_us(datetime.date(2007,12,28),datetime.date(2008,2,29),datetime.date(2008,2,29)),14) == round(Decimal('0.16944444444444'),14)
    assert round(dcfc_30_360_us(datetime.date(2007,10,31),datetime.date(2008,11,30),datetime.date(2008,11,30)),14) == round(Decimal('1.08333333333333'),14)

# Generated at 2022-06-26 00:43:38.312951
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Test cases for function dcfc_act_act
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)

# Generated at 2022-06-26 00:43:42.493247
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    print(DCCs.ACT_360.calculate_daily_fraction(Date(2016,12,2), Date(2016,12,3), Date(2016,12,31), 2))


# Generated at 2022-06-26 00:43:48.689325
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    principal_0 = 1
    rate_1 = -1
    start_0 = datetime.date(2017, 1, 1)
    asof_0 = datetime.date(2017, 1, 1)
    end_1 = datetime.date(2017, 1, 1)
    freq_0 = None
    d_c_c_0 = DCC.acc_act_360

    test_result = d_c_c_0.interest(principal_0, rate_1, start_0, asof_0, end_1, freq_0)

    assert test_result == 1


# Generated at 2022-06-26 00:43:57.565023
# Unit test for function dcfc_30_e_plus_360

# Generated at 2022-06-26 00:43:58.419634
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert(True == True)

# Generated at 2022-06-26 00:44:09.568418
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():

    import numpy as np
    import itertools
    import random
    import matplotlib.pyplot as plt

    class Test_DCC_class:
        def __init__(self):
            self.name = ""
            self.altnames = set()
            self.currencies = set()
            self.calculate_fraction_method = lambda start, asof, end, freq: 0

        def calculate_fraction(self, start, asof, end, freq):
            return 0

        def calculate_daily_fraction(self, start, asof, end, freq):
            return 0

        def interest(self, principal, rate, start, asof, end, freq):
            return 0

    test_DCC_class_0 = Test_DCC_class()
    test_DCC_class_

# Generated at 2022-06-26 00:44:12.374753
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    # Setup
    str_0 = "}'|r"
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    # Check
    optional_0 = d_c_c_registry_machinery_0.find(str_0)
    assert optional_0 is None



# Generated at 2022-06-26 00:44:20.825165
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    print("unit test starts")
    assert(dcfc_30_360_us(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)) == Decimal('0.16666666666667'))
    assert(dcfc_30_360_us(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 2, 29)) == Decimal('0.16944444444444'))
    assert(dcfc_30_360_us(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008, 11, 30)) == Decimal('1.08333333333333'))

# Generated at 2022-06-26 00:44:28.335683
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    money_0 = Money(int_0=96922, currency_0=currency_0)
    d_c_c_0 = DCC(name="", altnames=set(), currencies=set(), calculate_fraction_method=defaultfraction)
    date_0 = Date(datetime_0=datetime_0)
    date_1 = Date(datetime_0=datetime_1)
    date_2 = Date(datetime_0=datetime_2)
    result = d_c_c_0.coupon(principal=money_0, rate=0.026260606899081758, start=date_0, asof=date_1, end=date_2, freq=Decimal("172"))


# Generated at 2022-06-26 00:44:33.306782
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    str_0 = "Act/Act (ICMA)"
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    optional_0 = d_c_c_registry_machinery_0.find(str_0)
    print(optional_0)



# Generated at 2022-06-26 00:44:59.565606
# Unit test for method interest of class DCC
def test_DCC_interest():
    principal_0 = Money(amount=ONE, currency=Currencies.GBP)
    rate_0 = ZERO
    start_0 = datetime.date(2017, 1, 1)
    asof_0 = datetime.date(2017, 1, 1)
    optional_0 = DCCRegistry.find("Actual/Actual (ICMA)")
    d_c_c_0 = optional_0.get()
    money_0 = d_c_c_0.interest(principal_0, rate_0, start_0, asof_0)
    principal_1 = Money(amount=ONE, currency=Currencies.GBP)
    rate_1 = ZERO
    start_1 = datetime.date(2017, 1, 1)
    asof_1 = datetime.date(2017, 1, 1)

# Generated at 2022-06-26 00:45:09.031614
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)
    actual_result_0 = dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof)
    actual_result_1 = d

# Generated at 2022-06-26 00:45:13.690651
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')


# Generated at 2022-06-26 00:45:21.015625
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # Test case for function dcfc_30_360_isda
    
    # Test case with custom arguments
    dcfc_30_360_isda(start=datetime.date(2018, 1, 26), asof=datetime.date(2018, 3, 27), end=datetime.date(2018, 3, 27))
    
    # Test case with default arguments
    dcfc_30_360_isda(start=datetime.date(2018, 1, 26), asof=datetime.date(2018, 3, 27), end=datetime.date(2018, 3, 27))
    

# Generated at 2022-06-26 00:45:28.259215
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    # Declaration of test data
    principal_0 = Money.from_amount_decimal("CZK", "200.00")
    rate_0 = Decimal("0.05")
    start_0 = datetime.date(2019, 1, 1)
    asof_0 = datetime.date(2019, 1, 1)
    end_0 = datetime.date(2019, 12, 31)
    freq_0 = Decimal("1")
    eom_0 = None

    # Required processing
    interest = Money.from_amount_decimal("CZK", "10.0")
    calculated_interest = DCCRegistry["Act/360"].coupon(
        principal_0, rate_0, start_0, asof_0, end_0, freq_0, eom_0
    )

   

# Generated at 2022-06-26 00:45:36.604936
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    t_date_0 = Date(716, 0, 0) # Value <= 100
    t_date_1 = Date(516, 0, 0) # Value <= 100
    t_date_2 = Date(864, 0, 0) # Value >= 100
    t_date_3 = Date(817, 0, 0) # Value >= 100
    d_c_c_0 = DCC("name", set({}), set({}), DCCRegistryMachinery._dcf_ACT360)
    d_c_c_1 = DCC("name", set({}), set({}), DCCRegistryMachinery._dcf_ACT365)
    d_c_c_2 = DCC("name", set({}), set({}), DCCRegistryMachinery._dcf_ACT36525)
    d_c_c_3

# Generated at 2022-06-26 00:45:40.969666
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    optional_0 = d_c_c_registry_machinery_0.find('30/360 ISDA')
    optional_1 = {'30/360 US Municipal', 'Bond Basis', '30/360 ISDA'}
    assert optional_0 == optional_1


# Generated at 2022-06-26 00:45:47.012729
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    start_0 = datetime.date(2019, 3, 2)
    asof_0 = datetime.date(2019, 9, 10)
    end_0 = datetime.date(2020, 3, 2)
    d_c_c_0 = dcc_registry.find("Act/Act (ICMA)")
    assert(round(d_c_c_0.calculate_fraction(start_0, asof_0, end_0, 2), 10) == Decimal('0.5245901639'))

# Generated at 2022-06-26 00:45:51.407103
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    start_0 = datetime.date(2008, 3, 11)
    asof_0 = datetime.date(2008, 4, 1)
    end_0 = datetime.date(2008, 2, 17)
    result = dcfc_nl_365(start_0, asof_0, end_0)
    assert result == 30 / 365


# Generated at 2022-06-26 00:45:55.516506
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10)
    assert True


# Generated at 2022-06-26 00:46:33.242970
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    print(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)))
    print(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)))
    print(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)))
    print(dcfc_act_365_a(datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), datetime.date(2009, 5, 31)))


# Generated at 2022-06-26 00:46:41.261942
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal("0.16666666666667")
    assert dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal("0.16944444444444")
    assert dcfc_30_360_german(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal("1.08333333333333")

# Generated at 2022-06-26 00:46:50.017138
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ## Get all years of interest by checking the leap year:
    years = {year: calendar.isleap(year) for year in range(start.year, asof.year + 1)}

    ## Define the buffer of days for the day count. The former is for non-leap years, the latter for leap years:
    buffer: List[int] = [0, 0]

    ## Iterate over the date range and count:
    for date in _get_date_range(start, asof):
        ## Check the year and modify buffer accordingly:
        if years[date.year]:
            ## Yep, it is a leap year:
            buffer[1] += 1
        else:
            ## Nope, not a leap year:
            buffer[0] += 1

    ## Done, compute and return:
    return Decimal(buffer[0]) / Decimal

# Generated at 2022-06-26 00:46:54.949937
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    str_0 = "|}"
    str_1 = "}"
    d_c_c_0 = DCC(str_0, {str_1}, {Currency.of("PEN")}, lambda start, asof, end: start)
    try:
        d_c_c_registry_machinery_0.register(d_c_c_0)
    except:
        pass
    str_2 = "~T"
    str_3 = "~T"
    d_c_c_1 = DCC(str_2, {str_3}, {Currency.of("PEN")}, lambda start, asof, end: start)

# Generated at 2022-06-26 00:47:04.046290
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert abs((dcfc_30_360_us(datetime.date(2018, 1, 31), datetime.date(2018, 2, 28), datetime.date(2018, 3, 31), None) - 0.08333333333333333) / 0.08333333333333333) < 0.01

    assert abs((dcfc_30_360_us(datetime.date(2018, 1, 31), datetime.date(2018, 2, 28), datetime.date(2018, 3, 30), None) - 0.07777777777777779) / 0.07777777777777779) < 0.01


# Generated at 2022-06-26 00:47:10.216813
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    str_0 = "}'|r"
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    optional_0 = d_c_c_registry_machinery_0.find(str_0)


# Generated at 2022-06-26 00:47:13.738929
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)) == Decimal('0.5245901639')


# Generated at 2022-06-26 00:47:20.281477
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    date_0 = datetime.date(year = 2020, month = 4, day = 9)
    dcc_0 = DCC(name = 'name', altnames = set(), currencies = set(), calculate_fraction_method = DCFC)
    dcc_0.calculate_daily_fraction(start = date_0, asof = datetime.date(year = 2020, month = 10, day = 8), end = datetime.date(year = 2020, month = 7, day = 11), freq = 5)
    dcc_0.calculate_daily_fraction(start = date_0, asof = datetime.date(year = 2020, month = 9, day = 3), end = datetime.date(year = 2020, month = 10, day = 27), freq = 1)
    dcc_0.calculate_

# Generated at 2022-06-26 00:47:23.786160
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)
    freq = None
    actual = dcfc_act_act(start, asof, end, freq)
    desired = 0.16942884946478
    tol = 1e-12
    assert abs(actual - desired) <= tol


# Generated at 2022-06-26 00:47:30.155823
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof) == 0.1666666666666667

# Generated at 2022-06-26 00:48:27.149597
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    d_c_c_0 = DCC(str_0, set_0, set_1, (lambda d_c_f: d_c_f))
    calendar.timegm()
    d_c_c_0.calculate_daily_fraction(date_0, date_1, date_2, decimal_0)


# Generated at 2022-06-26 00:48:34.734902
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal("0.16666666666667")
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    assert round(dcfc_30_360_us(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal("0.16944444444444")
    ex3_start = datetime.date(2007, 10, 31)
   

# Generated at 2022-06-26 00:48:38.525045
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert(round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639'))


# Generated at 2022-06-26 00:48:45.826189
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    s_0 = datetime.datetime(2017, 1, 1)
    a_0 = datetime.datetime(2017, 1, 1)
    e_0 = datetime.datetime(2017, 1, 1)
    f_0 = Decimal('1.0')
    d_0 = DCC("test_name_0", {'test_altname_0', 'test_altname_1'}, {Currencies.EUR, Currencies.USD}, lambda s, a, e, f: Decimal('1.0'))
    # The following call would raise an exception if the test fails
    d_0.calculate_daily_fraction(s_0, a_0, e_0, f_0)



# Generated at 2022-06-26 00:48:50.073404
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:48:54.624902
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    start_date_0 = datetime.date(2016, 8, 5)
    asof_date_0 = datetime.date(2016, 9, 29)
    end_date_0 = datetime.date(2016, 9, 30)
    frequency_0 = 6
    decimal_0 = DCC.calculate_daily_fraction(start_date_0, asof_date_0, end_date_0, frequency_0)


# Generated at 2022-06-26 00:48:59.921989
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    str_0 = "zBp@"
    date_0 = datetime.date(2012, 6, 11)
    date_1 = datetime.date(2012, 5, 15)
    date_2 = datetime.date(2012, 7, 24)
    optional_0 = DCCRegistryMachinery().find(str_0)
    if optional_0 is not None:
        decimal_0 = optional_0.get().calculate_fraction(date_0, date_1, date_2)
    else:
        decimal_0 = 0


# Generated at 2022-06-26 00:49:06.069235
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start = datetime.date(2019, 3, 2)
    ex1_asof = datetime.date(2019, 9, 10)
    ex1_end = datetime.date(2020, 3, 2)
    expected_0 = Decimal('0.5245901639')
    actual_0 = dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end, freq=None)
    assert expected_0.compare_total(actual_0) == 0


# Generated at 2022-06-26 00:49:12.959083
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)

# Generated at 2022-06-26 00:49:21.363025
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start = datetime.datetime.strptime("2020-01-31", "%Y-%m-%d").date()
    ex1_asof = datetime.datetime.strptime("2020-02-28", "%Y-%m-%d").date()
    print(dcfc_30_360_isda(ex1_start, ex1_asof, ex1_asof))
    ex2_start = datetime.datetime.strptime("2020-01-31", "%Y-%m-%d").date()
    ex2_asof = datetime.datetime.strptime("2020-02-29", "%Y-%m-%d").date()