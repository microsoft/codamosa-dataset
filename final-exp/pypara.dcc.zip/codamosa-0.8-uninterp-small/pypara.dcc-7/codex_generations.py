

# Generated at 2022-06-26 00:42:02.295633
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # Initialize the start and asof dates
    ex1_start = datetime.date(2000,1,1)
    ex1_asof = datetime.date(2000,12,31)
    ex2_start = datetime.date(2000,3,30)
    ex2_asof = datetime.date(2000,7,31)
    ex3_start = datetime.date(2000,1,31)
    ex3_asof = datetime.date(2000,2,28)
    ex4_start = datetime.date(2000,1,30)
    ex4_asof = datetime.date(2000,1,31)
    ex5_start = datetime.date(2000,1,30)
    ex5_asof = datetime.date(2000,2,29)
    ex6

# Generated at 2022-06-26 00:42:12.646850
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Test case for method calculate_fraction of class DCC

    :return: None
    """
    # Test case for DCC.calculate_fraction - 1
    d_c_c_0 = DCC(d_c_c_registry_machinery_0.d_c_c_registry_name_0, d_c_c_registry_machinery_0.d_c_c_registry_altnames_0, d_c_c_registry_machinery_0.d_c_c_registry_currencies_0, d_c_c_registry_machinery_0.d_c_c_registry_method_0)

# Generated at 2022-06-26 00:42:21.051564
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-26 00:42:31.683853
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """Test that calculate daily fraction returns the right day count fraction"""
    ### Arrange
    start = datetime.date(2016, 6, 15)
    asof = datetime.date(2016, 7, 15)
    end = datetime.date(2016, 9, 15)
    freq = None
    # Get dcc instance by name
    dcc = DCCRegistry['Act360']
    # Expected result from the actual calculation
    expected = Decimal('0.08333333333333333')
    ### Act
    result = dcc.calculate_daily_fraction(start, asof, end, freq)
    ### Assert
    assert result == expected, "calculate daily fraction does not match expected result."


# Generated at 2022-06-26 00:42:40.808137
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    arguments_list  = [(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))]
    arguments_list += [(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29))]
    arguments_list += [(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30))]
    arguments_list += [(datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), datetime.date(2009, 5, 31))]

# Generated at 2022-06-26 00:42:44.305241
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=None), 10) == Decimal('0.5245901639')


# Generated at 2022-06-26 00:42:54.104769
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-26 00:43:03.720734
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Test case 1
    start1 = datetime.date(2007, 12, 28)
    asof1 = datetime.date(2008, 2, 28)
    end1 = datetime.date(2008, 2, 28)

    # Test case 2
    start2 = datetime.date(2007, 12, 28)
    asof2 = datetime.date(2008, 2, 29)
    end2 = datetime.date(2008, 2, 29)

    # Test case 3
    start3 = datetime.date(2007, 10, 31)
    asof3 = datetime.date(2008, 11, 30)
    end3 = datetime.date(2008, 11, 30)

    # Test case 4
    start4 = datetime.date(2008, 2, 1)

# Generated at 2022-06-26 00:43:14.793554
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Test case 0
    dt0_start = datetime.date(2007, 12, 28)
    dt0_asof = datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_german(start=dt0_start, asof=dt0_asof, end=dt0_asof), 14) == Decimal('0.16666666666667')

    # Test case 1
    dt1_start = datetime.date(2007, 12, 28)
    dt1_asof = datetime.date(2008, 2, 29)
    assert round(dcfc_30_360_german(start=dt1_start, asof=dt1_asof, end=dt1_asof), 14) == Decimal('0.16944444444444')

   

# Generated at 2022-06-26 00:43:24.254239
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28),
                                end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29),
                                end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')

# Generated at 2022-06-26 00:43:48.269219
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-26 00:43:57.177307
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    print(dcfc_30_360_us(start = datetime.date(2019, 6, 28), asof = datetime.date(2019, 7, 31), end = datetime.date(2019, 7, 31)))
    print(dcfc_30_360_us(start = datetime.date(2019, 6, 29), asof = datetime.date(2019, 7, 31), end = datetime.date(2019, 7, 31)))
    print(dcfc_30_360_us(start = datetime.date(2019, 6, 30), asof = datetime.date(2019, 7, 31), end = datetime.date(2019, 7, 31)))

# Generated at 2022-06-26 00:44:08.147007
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal_0 = Money(10000.0, 'USD')
    rate_0 = Decimal('0.03')
    start_0 = Date(2014, 1, 1)
    asof_0 = Date(2014, 1, 15)
    end_0 = Date(2014, 3, 31)
    freq_0 = 1
    eom_0 = None
    instance_0 = DCC('ACT/360', None, None, None)
    money_0 = instance_0.coupon(principal_0, rate_0, start_0, asof_0, end_0, freq_0, eom_0)
    print(money_0.amount)
    print(money_0.currency)



# Generated at 2022-06-26 00:44:11.486597
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    start_date = datetime.date(2007, 12, 31)
    asof_date = datetime.date(2008, 2, 29)
    actual = dcfc_30_e_plus_360(start=start_date, asof=asof_date, end=asof_date)
    expected = Decimal(59) / Decimal(360)
    assert actual == expected


# Generated at 2022-06-26 00:44:14.472661
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    dcfc_act_365_l_0 = dcfc_act_365_l(ex4_start, ex4_asof, ex4_asof, freq=1)
    assert round(dcfc_act_365_l_0, 14) == round(Decimal('1.32876712328767'), 14)

    # Function that ignores input and returns None

# Generated at 2022-06-26 00:44:17.013880
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    global dcc_registry
    dcc_registry = DCCRegistry()
    assert dcc_registry.find("ActAct")
    assert dcc_registry.find(" ACTACT ")
    assert dcc_registry.find("   ActAct    ")


# Generated at 2022-06-26 00:44:22.723243
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(ex1_start, ex1_asof, ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-26 00:44:24.682055
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Check that the method calculate_fraction of class DCC
    # contains proper code
    assert True == True


# Generated at 2022-06-26 00:44:31.642393
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .money import Money
    from .currencies import Currencies
    from . import DCCs
    DCCs.load_all()
    currency_0=Currencies['USD']
    principal_0=Money.parse('USD 100.00')
    rate_0=Decimal('0.01')
    start_0=Date(2017, 1, 1)
    asof_0=Date(2017, 12, 31)
    end_0=None
    freq_0=None
    assert DCCs['30/360 SIA'].interest(principal_0, rate_0, start_0, asof_0, end_0, freq_0)==Money.parse('USD 10.00')


# Generated at 2022-06-26 00:44:40.990998
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(
        dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)),
        14,
    ) == Decimal("0.16986301369863")
    assert round(
        dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)),
        14,
    ) == Decimal("0.16986301369863")

# Generated at 2022-06-26 00:44:58.039455
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    # Test parameters
    start_0 = None
    asof_0 = None
    end_0 = None
    decimal_0 = dcfc_act_act_icma(start_0, asof_0, end_0)



# Generated at 2022-06-26 00:45:03.487570
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    date_0 = _make_date(0, 0, 0)
    date_1 = _make_date(0, 0, 0)
    date_2 = _make_date(0, 0, 0)
    decimal_0 = dcfc_30_360_german(date_0, date_1, date_2)
    assert round(decimal_0, 14) == Decimal('0E-14')



# Generated at 2022-06-26 00:45:09.073347
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    date_0 = None
    decimal_0 = dcfc_act_act_icma(date_0, date_0, date_0)
    decimal_1 = dcfc_act_act_icma(date_0, date_0, date_0)
    decimal_2 = dcfc_act_act_icma(date_0, date_0, date_0)
    assert decimal_0 == decimal_1 == decimal_2


# Generated at 2022-06-26 00:45:16.893185
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    # Test for cancellation of scalar values
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 29)
    freq = 4
    assert (dcfc_act_365_a(start, asof, end) == dcfc_act_365_a(start, asof, end))
    assert (dcfc_act_365_a(start, asof, end, freq) == dcfc_act_365_a(start, asof, end, freq))

    # Test for commutativity of addition
    assert (dcfc_act_365_a(start, asof, end) == dcfc_act_365_a(start, asof, end))

# Generated at 2022-06-26 00:45:19.108460
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), datetime.date(2009, 5, 31)), 14) == Decimal('1.32876712328767')
    
    

# Generated at 2022-06-26 00:45:23.099342
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)
    decimal_0 = dcfc_30_e_360(start, asof, end)
    decimal_1 = dcfc_30_e_360(start, asof, end)


# Generated at 2022-06-26 00:45:24.821970
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcc_types["30E+/360"]() == dcfc_30_e_plus_360


# Generated at 2022-06-26 00:45:32.586823
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    date_0 = None
    decimal_0 = ZERO
    date_1 = Date(2019, 1, 16)
    date_2 = Date(2019, 1, 14)
    date_3 = Date(2019, 5, 19)
    decimal_1 = Decimal('0.0023282438')
    decimal_2 = Decimal('0.0022857143')
    decimal_3 = Decimal('0.0023282438')
    decimal_4 = Decimal('0.0023282438')
    decimal_5 = Decimal('0.0023282438')
    decimal_6 = Decimal('0.0023282438')
    decimal_7 = Decimal('0.0023282438')
    assert _get_actual_day_count(date_1, date_1) == 0

# Generated at 2022-06-26 00:45:41.090288
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    date_0 = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    date_1 = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    date_2 = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    date_3 = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    decimal_0 = dcfc_nl_365(date_0, date_0, date_0)
    decimal_1 = dcfc_nl_365(date_1, date_1, date_1)
    decimal_2 = dcfc_nl_365(date_2, date_2, date_2)
    decimal_3 = dcfc_

# Generated at 2022-06-26 00:45:50.270116
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Test starts here
    object_0 = DCC('string_0', {'string_0'}, {Currency('string_0')}, dcfc_nl_365)
    arg_0 = Date(0, 0, 0)
    arg_1 = Date(0, 0, 0)
    arg_2 = Date(0, 0, 0)
    arg_3 = Decimal()
    dict_0 = {'int_0': 1}
    dict_1 = {'int_0': 1}
    dict_2 = {'int_0': 1}
    dict_3 = {'int_0': 1}
    dict_4 = {'int_0': 1}
    dict_5 = {'int_0': 1}
    dict_6 = {'int_0': 1}

# Generated at 2022-06-26 00:46:58.470818
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Test 0
    ex1_start = datetime.date(2017, 2, 28)
    ex1_asof = datetime.date(2017, 3, 31)
    ex1_end = datetime.date(2017, 4, 30)
    expected_0 = Decimal('0.16666666666667')
    actual_0 = dcfc_30_360_german(ex1_start, ex1_asof, ex1_end)
    assert actual_0 == expected_0, 'test_dcfc_30_360_german actual_0'

    # Test 1
    ex2_start = datetime.date(2017, 3, 31)
    ex2_asof = datetime.date(2017, 4, 30)
    ex2_end = datetime.date(2017, 6, 30)
    expected

# Generated at 2022-06-26 00:47:04.587792
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 1, 1)
    freq = 2
    result = DCC_0.calculate_fraction(start, asof, end, freq)
    assert result == 0.0


# Generated at 2022-06-26 00:47:11.395705
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    asof = datetime(2016,11,1)
    end = datetime(2017,11,1)
    start = datetime(2016,11,1)
    decimal_0 = dcfc_act_act(start, asof, end)

    return decimal_0


# Generated at 2022-06-26 00:47:18.663762
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10)
    if (round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == 0.5245901639):
        print("test_dcfc_act_act_icma - test #1 Passed!")
    else:
        print("test_dcfc_act_act_icma - test #1 Failed!")



# Generated at 2022-06-26 00:47:21.077279
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    start_date = datetime.date(2007, 12, 28)
    end_date =  datetime.date(2008, 2, 27)
    decimal_0 = dcfc_nl_365(start_date, start_date, end_date)



# Generated at 2022-06-26 00:47:23.959787
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    date_0 = datetime.date(2017, 3, 21)
    date_1 = datetime.date(2017, 3, 21)
    date_2 = datetime.date(2017, 3, 21)
    decimal_0 = dcc_nl_365.calculate_fraction(date_0, date_1, date_2)


# Generated at 2022-06-26 00:47:30.335151
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-26 00:47:34.356866
# Unit test for method interest of class DCC
def test_DCC_interest():
    dcc = DCC("actual/360", set(), set(), dcfc_nl_360)
    interest = dcc.interest(Money("10.00"), Decimal("0.15"), datetime.date(2008, 7, 7), datetime.date(2008, 7, 31))
    print("interest: " + str(interest))


# Generated at 2022-06-26 00:47:42.680547
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)),14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)),14) == Decimal('0.16944444444444')

# Generated at 2022-06-26 00:47:51.767678
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal(0.169398907103824)
    assert dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal(0.172131147540984)
    assert dcfc_act_365_l(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal(1.08196721311475)