

# Generated at 2022-06-26 00:42:06.425061
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)


# Generated at 2022-06-26 00:42:17.302207
# Unit test for method interest of class DCC
def test_DCC_interest():
    dcc_obj = DCC('DCC name',{'DCC altname1', 'DCC altname2'},{Currencies.CAD, Currencies.CHF},(lambda start, asof, end, freq: Decimal(abs(start-end).days) / Decimal(360)))
    start = getattr(datetime,'date')(2016,8,9)
    asof = getattr(datetime,'date')(2016,8,10)
    end = getattr(datetime,'date')(2016,8,10)
    principal = Money(100, Currencies.CAD)
    rate = Decimal('0.015')
    freq = Decimal(1)
    result = dcc_obj.interest(principal, rate, start, asof, end, freq)
    assert result.amount == Dec

# Generated at 2022-06-26 00:42:28.476299
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-26 00:42:31.724585
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    start: Date = datetime.date(2007, 12, 28)
    asof: Date = datetime.date(2008, 2, 28)
    end: Date = datetime.date(2008, 2, 28)
    freq: Optional[Decimal] = None
    expected: Decimal = 0.166666666666667
    #expected = Decimal("0.16666666666667")
    actual: Decimal = dcfc_30_e_plus_360(start=start, asof=asof, end=end, freq=freq)
    assert (expected == actual)


# Generated at 2022-06-26 00:42:36.240961
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = date(2007, 12, 28), date(2008, 2, 28)
    ex2_start, ex2_asof = date(2007, 12, 28), date(2008, 2, 29)
    ex3_start, ex3_asof = date(2007, 10, 31), date(2008, 11, 30)
    ex4_start, ex4_asof = date(2008, 2, 1), date(2009, 5, 31)

    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:42:46.918102
# Unit test for function dcfc_30_e_360

# Generated at 2022-06-26 00:42:56.174825
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():

    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_e

# Generated at 2022-06-26 00:43:04.380070
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    d_c_c_0 = DCC("ACT/360", {"actual/365", "act/365"}, {"USD", "EUR"}, d_c_c_registry_machinery_0.d_c_f_c_m_0)
    principal_0 = Money(20, "USD")
    rate_0 = Decimal("1.1")
    start_0 = datetime.date(2017, 1, 1)
    asof_0 = datetime.date(2018, 1, 1)
    end_0 = datetime.date(2018, 1, 1)
    freq_0 = Decimal("0.5")
    result = d_c_c_0.interest(principal_0, rate_0, start_0, asof_0, end_0, freq_0)

# Generated at 2022-06-26 00:43:14.945492
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()

# Generated at 2022-06-26 00:43:22.607867
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """
    Execute the test for the dcfc_act_act_icma function.
    """
    import unittest
    import math

    # Test parameters
    ex_start = datetime.date(2019, 3, 2)
    ex_asof = datetime.date(2019, 9, 10)
    ex_end = datetime.date(2020, 3, 2)
    ex_freq = 2
    ex_result = math.isclose(dcfc_act_act_icma(start=ex_start, asof=ex_asof, end=ex_end, freq=ex_freq), 0.5245901639)

    # Test result
    assert(ex_result)



# Generated at 2022-06-26 00:43:48.556276
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    for year in range(1800,1802):
        for month in range(1,13):
            for day in range(1,32):
                date1 = _construct_date(year,month,day)
                date2 = _construct_date(year+1,month,day)
                result = dcfc_act_act(date1,date1,date2)
                if result == Decimal(0.00):
                    result = dcfc_act_act(date1,date1,date1)
                if result == Decimal(0.00):
                    print(date1)
                assert(result != Decimal(0.00))


# Generated at 2022-06-26 00:43:53.540162
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # given
    start, asof = datetime.date(2020, 6, 30), datetime.date(2020, 10, 30)

    # when
    actual = dcfc_30_e_360(start, asof, end=asof)

    # then
    expected = Decimal("0.3")
    assert actual == expected
# End of unit test for function dcfc_30_e_360


# Generated at 2022-06-26 00:44:03.603137
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    d_c_c_machinery_0 = DCCMachinery()
    asof_machinery_1 = DateMachinery()
    start_machinery_2 = DateMachinery()
    end_machinery_3 = DateMachinery()
    freq_machinery_4 = int_machinery
    d_c_c_machinery_0.calculate_daily_fraction(start_machinery_2.sample(), asof_machinery_1.sample(), end_machinery_3.sample(), freq_machinery_4.sample())


# Generated at 2022-06-26 00:44:10.912130
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Unit test for function dcfc_30_e_360.
    """
    dcc_registry_machinery_1 = DCCRegistryMachinery()
    print("Testing function dcfc_30_e_360")
    print("Test case 1")
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    assert pytest.approx(round(
        dcc_registry_machinery_1.get_dcfc("30E/360")(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)) == Decimal(
        '0.16666666666667')
    print("Test case 2")
    ex2_start = datetime.date

# Generated at 2022-06-26 00:44:14.827274
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    print("Unit test for `dcfc_30_360_german` function")
    print("")

    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)

    print(ex1_start, ex1_asof)
    print(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof))


# Generated at 2022-06-26 00:44:19.938569
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    # Note: Used datetimes must be within same year!
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10)


# Generated at 2022-06-26 00:44:27.147807
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:44:30.942158
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    date_start = datetime.date(2020, 1, 1)
    date_asof = datetime.date(2020, 2, 1)
    date_end = datetime.date(2020, 2, 1)
    assert dcfc_nl_365(date_start,date_asof,date_end,1) == Decimal('0.02739726')


# Generated at 2022-06-26 00:44:34.920865
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    dcfc_30_360_isda_0 = dcfc_30_360_isda(
        start=datetime.datetime(2000,1,1),
        asof=datetime.datetime(2001,1,1),
        end=datetime.datetime(2001,1,1),
        freq=None
    )
    assert(dcfc_30_360_isda_0 == 1)


# Generated at 2022-06-26 00:44:45.699263
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_registry_machinery_1 = DCCRegistryMachinery()
    name_0 = "ActAct"
    d_c_0 = DCC(name_0, set(), set(), lambda arg_0, arg_1, arg_2, arg_3=None: arg_0)
    d_c_c_registry_machinery_0.register(d_c_0)
    d_c_1 = DCC("ActAct", set(), set(), lambda arg_0, arg_1, arg_2, arg_3=None: arg_1)
    d_c_c_registry_machinery_1.register(d_c_1)
    d_c_2 = D

# Generated at 2022-06-26 00:47:01.959061
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    This function is defined for unit test of calculate_daily_fraction() method of class DCC
    
    """
    ## Create instance of class DCC
    d_c_c_0 = DCC("name", {"altnames"}, {Currencies["code"]}, dcff1)
    
    ## Correct values for unit test
    c_v_d_c_c_calculate_daily_fraction_0 = 0
    c_v_d_c_c_calculate_daily_fraction_1 = 1
    
    ## Code for unit test

# Generated at 2022-06-26 00:47:04.153865
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCRegistryMachinery().coupon(None, None, None, None, None, None, None) is None


# Generated at 2022-06-26 00:47:15.758785
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    print("Test coupon of DCC")
    start = datetime.date(2014, 6, 1)
    asof = datetime.date(2017, 6, 15)
    end = datetime.date(2017, 12, 1)
    freq = Decimal('4')
    eom = None
    principal = Money(Decimal('100'),'USD')
    rate = Decimal('0.02')
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_0 = d_c_c_registry_machinery_0.DCCRegistry_register_0['30360']

# Generated at 2022-06-26 00:47:27.601878
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    # FIXME: use pytest-datadir for test data files.
    test_case = load_json("tests/test-cases/test_dcfc_act_act_icma.json")
    start, asof, end = test_case["start"], test_case["asof"], test_case["end"]
    freq = Decimal(test_case["freq"])
    expect = Decimal(test_case["expect"])
    assert expect == dcfc_act_act_icma(start, asof, end, freq)



# Generated at 2022-06-26 00:47:32.657959
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(start=datetime.date(2019,1,15),asof=datetime.date(2019,1,31),end=datetime.date(2019,1,31))
    assert dcfc_30_e_360(start=datetime.date(2019,1,15),asof=datetime.date(2019,2,28),end=datetime.date(2019,2,28))
    assert dcfc_30_e_360(start=datetime.date(2019,1,15),asof=datetime.date(2019,2,28),end=datetime.date(2019,2,28))


# Generated at 2022-06-26 00:47:45.099390
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Case 0
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal("0.16942884946478")
    assert dcfc_

# Generated at 2022-06-26 00:47:53.838161
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-26 00:48:01.942243
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-26 00:48:06.963821
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-26 00:48:13.536211
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    start = datetime.datetime(year=2018, month=1, day=30)
    asof = datetime.datetime(year=2018, month=1, day=31)
    end = datetime.datetime(year=2019, month=1, day=28)
    freq = 1

    for convention in DCCRegistryMachinery().conventions:
        day_count_convention = DCCRegistryMachinery().get_convention(convention)
        day_count_fraction = day_count_convention.calculate_daily_fraction(start, asof, end, freq)


# Generated at 2022-06-26 00:51:25.329716
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    dcc_0 = DCC("name_0", set(), set(), lambda start, asof, end, freq: Decimal("2"))
    start_0 = datetime.date(2019, 5, 27)
    asof_0 = datetime.date(2025, 4, 2)
    end_0 = datetime.date(2025, 12, 11)
    freq_0 = Decimal("3")
    eom_0 = Decimal("5")
    # Testing with principal = Money(value=Decimal("3.0"), currency=Currency(name='RUB', code='RUB')) and rate = Decimal("1.0")
    # Expected result: Money(value=Decimal("0.666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666"), currency=Currency(name='RUB', code