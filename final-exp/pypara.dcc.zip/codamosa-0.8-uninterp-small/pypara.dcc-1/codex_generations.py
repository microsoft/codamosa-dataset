

# Generated at 2022-06-26 00:42:03.107256
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start = datetime.date.fromisoformat('2007-12-28')
    ex1_asof = datetime.date.fromisoformat('2008-02-28')
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == 0.16666666666667
    ex2_start = datetime.date.fromisoformat('2007-12-28')
    ex2_asof = datetime.date.fromisoformat('2008-02-29')
    assert round(dcfc_30_360_us(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == 0.16944444444444

# Generated at 2022-06-26 00:42:09.136645
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex1_res = round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-26 00:42:18.982455
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # Test with start date, valuation date and end date as of the same day.
    start_date = datetime.date(2019, 1, 18)
    valuation_date = datetime.date(2019, 1, 18)
    end_date = datetime.date(2019, 1, 18)
    result_0 = dcfc_30_360_isda(start_date, valuation_date, end_date)
    # The result should be 0.16666666666667
    print("Result should be: 0.16666666666667")
    print("Result is: " + str(result_0))
    # Test with start date, valuation date and end date as of the same day.
    start_date = datetime.date(2019, 2, 18)
    valuation_date = datetime.date(2019, 3, 31)
    end_date

# Generated at 2022-06-26 00:42:24.481867
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    d_c_c_registry_machinery_1 = DCCRegistryMachinery()
    assert d_c_c_registry_machinery_1.dcfc_nl_365(datetime.date(2019, 11, 29), datetime.date(2020, 4, 7), datetime.date(2020, 5, 28), 1) == Decimal('0.13150684931507')



# Generated at 2022-06-26 00:42:35.666887
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:42:43.165248
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    test_case_0()
    _dcc_ACT_360 = DCCRegistryMachinery()._dcc_ACT_360
    _dcc_ACT_365 = DCCRegistryMachinery()._dcc_ACT_365
    _dcc_ACT_ACT_ISDA = DCCRegistryMachinery()._dcc_ACT_ACT_ISDA
    _dcc_ACT_ACT_ICMA = DCCRegistryMachinery()._dcc_ACT_ACT_ICMA
    _dcc_ACT_ACT_CMA = DCCRegistryMachinery()._dcc_ACT_ACT_CMA
    _dcc_ACT_ACT_AFB = DCCRegistryMachinery()._dcc_ACT_ACT_AFB
    _dcc_ACT_ACT_NH = DCCRegistryMachinery()._dcc_ACT

# Generated at 2022-06-26 00:42:46.213227
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360.__doc__ is not None
    assert callable(dcfc_30_e_360)
    assert dcfc_30_e_360("", "", "")



# Generated at 2022-06-26 00:42:57.235365
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    # Test for dcfc_act_365_a
    # initialize
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)
    # expected result
    expected_output = Decimal('0.16986301369863')
    # actual output
    actual_output = round(dcfc_act_365_a(start, asof, end), 14)
    # compare
    assert actual_output == expected_output
    # message
    print("Actual output is equal to the expected output")


# Generated at 2022-06-26 00:43:05.070812
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    test_01 = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    test_02 = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    test_03 = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    test_04 = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    ex1_start, ex1_asof = test_01
    ex2_start, ex2_asof = test_02
    ex3_start, ex3_asof = test_03
    ex4_start, ex4_asof = test_04

    expected_01 = Decimal('0.16666666666667')
    expected_02 = Decimal

# Generated at 2022-06-26 00:43:15.199933
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # data for test case
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex1_expected = Decimal('0.16666666666667')
    ex2_expected = Decimal('0.16944444444444')
    ex3_expected = Decimal('1.08333333333333')

# Generated at 2022-06-26 00:43:57.214793
# Unit test for method interest of class DCC
def test_DCC_interest():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    """Tests interest function on DCC class"""
    # Test data
    test_data = [
        ([0.20, 0.20, 0.20], Money(1000.0, 1, 2), Money(1000.0, 1, 2), Money(1000.0, 0, 2), None, Date(2000, 1, 1), None, Date(2000, 1, 1), None, 0, 365, None, 0, 365)
    ]
    for ind, (result, principal, rate, expected_result, self, start, asof, end, freq, _expected_result, rnd, _result, rnd1, _expected_result1) in enumerate(test_data):
        # Set arguments
        d_c_c_registry

# Generated at 2022-06-26 00:44:08.672339
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():

    # test 1
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), freq = Decimal(2)), 10) == Decimal('0.5245901639')

    # test 2
    with pytest.raises(TypeError):
        dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 8, 10), datetime.date(2020, 3, 2), freq = Decimal(2))

    # test 3

# Generated at 2022-06-26 00:44:12.940919
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():

    # Test case 0
    ex0_start, ex0_asof, ex0_end = datetime.date(2014, 12, 12), datetime.date(2015, 3, 30), datetime.date(2015, 3, 30)
    _0 = dcfc_30_e_360(start=ex0_start, asof=ex0_asof, end=ex0_end, freq=None)
    assert isinstance(_0, Decimal)
    assert round(_0, 6) == Decimal('0.144444')


# Generated at 2022-06-26 00:44:21.385348
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_registry_machinery_0.set_currencies(Currencies[Currencies.USD])
    d_c_c_registry_machinery_0.set_name("JF")
    d_c_c_registry_machinery_0.set_altnames(["NL/365", "NL/365F", "NL/365S", "NL365S", "NL/365SUS", "NL/365CC", "NL/365A"])
    d_c_c_registry_machinery_0.set_method(calculate_fraction_method)

# Generated at 2022-06-26 00:44:29.360174
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    print ('Executing test_DCC_coupon')
    e = DCC('test_DCC_coupon',
            {'test_DCC_coupon_alt_1', 'test_DCC_coupon_alt_2'},
            Currencies['test_DCC_coupon_currency_1'],
            DCCRegistryMachinery._actual_day_count_fraction)
    r = Decimal(1.0)
    p = Money(1000, Currencies['test_DCC_coupon_currency_2'])
    s = Date(1945, 2, 3)
    a = Date(1945, 2, 4)
    e_ = Date(1945, 2, 4)
    f = Decimal(4)
    eo = 1

# Generated at 2022-06-26 00:44:37.935012
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Example 1
    asof = date(2007, 7, 13)
    start = date(2007, 4, 13)
    end = date(2007, 7, 13)
    assert math.isclose(dcfc_30_360_us(start, asof, end), 0.25, abs_tol=0.00001)
    # Example 2
    asof = date(2007, 7, 13)
    start = date(2007, 4, 30)
    end = date(2007, 7, 13)
    assert math.isclose(dcfc_30_360_us(start, asof, end), 0.25, abs_tol=0.00001)
    # Example 3
    asof = date(2007, 7, 13)
    start = date(2007, 5, 31)

# Generated at 2022-06-26 00:44:47.782308
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-26 00:44:57.323433
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    # Set the test case
    ex1_start = datetime.date(2019, 3, 2)
    ex1_asof = datetime.date(2019, 9, 10)
    ex1_end = datetime.date(2020, 3, 2)
    # Calculate the day count fraction
    dcf = dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end)
    # Check if the day count fraction is correct
    assert round(dcf, 10) == Decimal('0.5245901639')



# Generated at 2022-06-26 00:45:02.942626
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))
    assert dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29))

# Generated at 2022-06-26 00:45:12.230712
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    if True:
        d_c_c_machinery_0 = DCCMachinery()
        d_c_c_registry_machinery_0 = DCCRegistryMachinery()
        money = Money
        today = Date
        dcc1 = d_c_c_registry_machinery_0.get("ACT/365")
        principal_0 = money(10, "USD")
        rate_0 = Decimal(0.1)
        start_0 = today(2017, 1, 1)
        asof_0 = today(2017, 1, 2)
        end_0 = today(2017, 1, 10)
        freq_0 = Decimal(0.5)

# Generated at 2022-06-26 00:48:07.425595
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies import Currencies
    from .money import Money
    from .currenciess import Currenciess
    currenciess_0 = Currenciess()
    currencies_0 = Currencies()
    currencies_0.add(currenciess_0)
    CEN = None # <== Remove this line and add yours
    cen = currencies_0.get(CEN)

# Generated at 2022-06-26 00:48:13.797344
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')


# Generated at 2022-06-26 00:48:22.189923
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    print('Testing method calculate_daily_fraction of class DCC')
    print('')
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_registry_machinery_0.d_c_c_registry
    d_c_c_registry_machinery_0.d_c_c_registry.items()
    d_c_c_registry_machinery_0.d_c_c_registry.keys()

# Generated at 2022-06-26 00:48:30.602324
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ## Example 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_dcfc = dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof)
    print("Example 1, ex1_dcfc = dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof)")
    print(f"ex1_dcfc = {ex1_dcfc}")
    ## Example 2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex2

# Generated at 2022-06-26 00:48:33.303139
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_registry_machinery_0.test_method_DCC_calculate_fraction()


# Generated at 2022-06-26 00:48:37.714851
# Unit test for method register of class DCCRegistryMachinery

# Generated at 2022-06-26 00:48:42.136515
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16986301369863')

# Generated at 2022-06-26 00:48:51.595061
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC('30E/360 ISDA', set(), set(), lambda a,b,c,d: Decimal(1))
    start = Date(2017, 1, 1)
    asof = Date(2017, 1, 1)
    end = Date(2017, 1, 1)
    freq = None
    r = dcc.calculate_fraction(start, asof, end, freq)
    assert r == Decimal(1), 'Result: ' + str(r)
    start = Date(2017, 1, 1)
    asof = Date(2017, 1, 1)
    end = Date(2017, 1, 2)
    freq = None
    r = dcc.calculate_fraction(start, asof, end, freq)
    assert r == Decimal(1), 'Result: '

# Generated at 2022-06-26 00:48:59.107728
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    print("dcfc_30_360_isda test case 1 - 0/0/0")
    date_0 = datetime.date(2007, 12, 28)
    date_1 = datetime.date(2008, 2, 28)
    str_1 = str(dcfc_30_360_isda(start = date_0, asof = date_1, end = date_1, freq = Decimal(0)))
    str_2 = "0.16666666666667"
    assert str_1 == str_2
    print("dcfc_30_360_isda test case 1 - passed")
    print("dcfc_30_360_isda test case 2 - 0/0/1")
    date_0 = datetime.date(2007, 12, 28)

# Generated at 2022-06-26 00:49:06.241732
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ## Prepare necessary data:
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof  = datetime.date(2008, 2, 28)

    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof  = datetime.date(2008, 2, 29)

    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof  = datetime.date(2008, 11, 30)

    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof  = datetime.date(2009, 5, 31)

    exp1 = Decimal('0.16942884946478')
    exp2 = Decimal('0.17216108990194')
    exp3 = Decimal