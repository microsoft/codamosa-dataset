

# Generated at 2022-06-26 00:42:25.138566
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    pass



# Generated at 2022-06-26 00:42:31.093397
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    start = Date.from_str("2019-03-02")
    asof = Date.from_str("2019-09-10")
    end = Date.from_str("2020-03-02")
    assert (round(dcfc_act_365_a(start=start, asof=asof, end=end), 10) == Decimal('0.5245901639'))
    

# Generated at 2022-06-26 00:42:36.446181
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    # Find d_c_c_0 in registry
    d_c_c_0 = d_c_c_registry_machinery_0.find('Act/365')
    assert d_c_c_0 == act_365_d_c_c


# Generated at 2022-06-26 00:42:39.998078
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(
        start = datetime.date(2007, 12, 28),
        asof = datetime.date(2008, 2, 28),
        end = datetime.date(2008, 2, 28),
    ), 14) == Decimal('0.16666666666667')


# Generated at 2022-06-26 00:42:49.383192
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    start = datetime.date(2015, 6, 12)
    asof = datetime.date(2016, 4, 29)
    freq = None
    assert dcfc_30_360_german(start, asof, freq) == Decimal('0.079166666666667')
    asof = datetime.date(2015, 12, 31)
    assert dcfc_30_360_german(start, asof, freq) == Decimal('0.16666666666667')
    asof = datetime.date(2015, 6, 30)
    assert dcfc_30_360_german(start, asof, freq) == Decimal('0.083333333333333')
    asof = datetime.date(2015, 7, 31)

# Generated at 2022-06-26 00:42:56.568300
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc_0 = test_case_0()
    ## Get t-1 for asof:
    asof_minus_1 = asof - datetime.timedelta(days=1)

    ## Get the yesterday's factor:
    if asof_minus_1 < start:
        yfact = ZERO
    else:
        yfact = self.calculate_fraction_method(start, asof_minus_1, end, freq)

    ## Get today's factor:
    tfact = self.calculate_fraction_method(start, asof, end, freq)

    ## Get the factor and return:
    return tfact - yfact


# Generated at 2022-06-26 00:43:04.729523
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    method_0 = d_c_c_registry_machinery_0["ACTUAL_360"].calculate_fraction
    assert method_0(datetime.date(2014, 12, 31), datetime.date(2015, 1, 1), datetime.date(2015, 1, 1)) == 0.0027777777777777776
    assert method_0(datetime.date(2014, 12, 31), datetime.date(2015, 1, 1), datetime.date(2015, 1, 2)) == 0.0027777777777777776
    assert method_0(datetime.date(2014, 12, 31), datetime.date(2015, 1, 1), datetime.date(2015, 1, 5)) == 0.01

# Generated at 2022-06-26 00:43:14.981894
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    d_c_c_registry_machinery_1 = DCCRegistryMachinery()
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)), 14) == Decimal('1.08219178082192')

# Generated at 2022-06-26 00:43:24.485765
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # Test case with input d_start=Date(2020,1,1), d_asof=Date(2020,1,30), d_end=Date(2020,1,30) and d_freq=12.0
    assert round(dcfc_30_360_isda(start=Date(2020, 1, 1), asof=Date(2020, 1, 30), end=Date(2020, 1, 30), freq=Decimal('12.0')), 14) == Decimal('0.12500000000000')

    # Test case with input d_start=Date(2020,1,1), d_asof=Date(2020,1,31), d_end=Date(2020,1,31) and d_freq=12.0

# Generated at 2022-06-26 00:43:31.949195
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    # Unit test
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-26 00:44:05.187390
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # -- DATE 12/28/2007
    start = datetime.date(2007, 12, 28)

    # -- DATE 2/28/2008
    asof = datetime.date(2008, 2, 28)

    # -- DATE 2/28/2008
    end = datetime.date(2008, 2, 28)

    # -- Round(dcfc_30_360_isda(start, asof, end), 14)
    assert math.isclose(0.16666666666667,dcfc_30_360_isda(start, asof, end), abs_tol=1e-12)

    # -- DATE 12/28/2007
    start = datetime.date(2007, 12, 28)

    # -- DATE 2/29/2008

# Generated at 2022-06-26 00:44:08.301459
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')


# Generated at 2022-06-26 00:44:16.453941
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    # Test cases
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')

    ex2_start, ex2_asof, ex2_end = datetime.date(2019, 3, 2), datetime.date(2019, 3, 2), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex2_start, asof=ex2_asof, end=ex2_end), 10)

# Generated at 2022-06-26 00:44:22.214061
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    print("Testing function dcfc_act_365_a")
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-26 00:44:30.126920
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():

    # create the object DCC to test its methods
    d_c_c_object_0 = DCC('30E/360', {}, Currencies.machinery, _calculate_30e_360)

    # create a Decimal object to test the method calculate_daily_fraction
    decimal_object_0 = Decimal('100')
    # get a Date object
    r_d_0 = _construct_date(1973, 5, 9)
    # get a Date object
    r_d_1 = _construct_date(1998, 9, 4)
    # get a Date object
    r_d_2 = _construct_date(2031, 11, 15)
    # get a class instance

# Generated at 2022-06-26 00:44:39.030006
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    test_input_0 = {'start': dt.date(2007, 12, 28), 'asof': dt.date(2008, 2, 28), 'end': dt.date(2008, 2, 28)}
    result = dcfc_30_e_360(**test_input_0)
    expected_result = Decimal('0.16666666666667')
    assert(round(result, 14) == expected_result)

    test_input_1 = {'start': dt.date(2007, 12, 28), 'asof': dt.date(2008, 2, 29), 'end': dt.date(2008, 2, 29)}
    result = dcfc_30_e_360(**test_input_1)
    expected_result = Decimal('0.16944444444444')

# Generated at 2022-06-26 00:44:46.622448
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    asof_0 = datetime.date(int_0, int_0, int_0)
    int_1 = 1
    freq_0 = Decimal(int_1)
    end_0 = datetime.date(int_0, int_0, int_0)
    start_0 = datetime.date(int_0, int_0, int_0)
    d_c_c_0 = DCC()
    d_c_c_0.calculate_daily_fraction(start_0, asof_0, end_0, freq_0)


# Generated at 2022-06-26 00:44:56.269679
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert( round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863') )

# Generated at 2022-06-26 00:45:05.977729
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-26 00:45:14.458242
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Tests if the method calculate_daily_fraction of class DCC raises the following exceptions:  ValueError
    str_0 = 'MMqyYx>5@'
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    optional_0 = d_c_c_registry_machinery_0.find(str_0)
    if optional_0 is None:
        return
    decimal_0 = Decimal('4.294967296E+9')
    str_1 = '#\x18'
    decimal_1 = Decimal('1.6777216E+7')
    date_0 = Date(str_1, decimal_1)
    assert date_0 is not None
    decimal_2 = Decimal('5.16192768E+8')
    str

# Generated at 2022-06-26 00:46:32.028394
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    d_a_te_0 = datetime.date
    d_a_te_1 = datetime.date
    d_a_te_2 = datetime.date
    d_c_0 = DCC(name='', altnames=set(), currencies=set(), calculate_fraction_method=lambda start, asof, end, freq: Decimal('0.0'))
    start = d_a_te_0
    asof = d_a_te_1
    end = d_a_te_2
    freq = Decimal('0.0')
    assert d_c_0.calculate_daily_fraction(start, asof, end, freq) == Decimal('0.0')
    d_a_te_0 = datetime.date

# Generated at 2022-06-26 00:46:40.002569
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360.__doc__ is not None
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-26 00:46:44.377875
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    str_0 = 'MMqyYx>5@'
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    optional_0 = d_c_c_registry_machinery_0.find(str_0)



# Generated at 2022-06-26 00:46:51.648995
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    start_0, end_0 = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=start_0, asof=end_0, end=end_0), 14) == 1.33333333333333
    start_1, end_1 = datetime.date(2008, 2, 1), datetime.date(2009, 6, 1)
    assert round(dcfc_30_e_plus_360(start=start_1, asof=end_1, end=end_1), 14) == 1.33333333333333
    start_2, end_2 = datetime.date(2008, 2, 1), datetime.date(2009, 2, 28)

# Generated at 2022-06-26 00:46:57.347262
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    d_t_0 = datetime.datetime.strptime('2007-12-28', '%Y-%m-%d')
    d_t_1 = datetime.datetime.strptime('2008-2-28', '%Y-%m-%d')
    d_t_2 = datetime.datetime.strptime('2008-2-29', '%Y-%m-%d')
    d_t_3 = datetime.datetime.strptime('2007-10-31', '%Y-%m-%d')
    d_t_4 = datetime.datetime.strptime('2008-2-1', '%Y-%m-%d')

# Generated at 2022-06-26 00:47:10.304849
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # Setting up object for test
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    # Setting up variables for test
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    d_c_c_0 = DCC(
        "name", 
        set(), 
        set(), 
        lambda start, asof, end, freq: (start + asof + end + freq) / 4
    )
    # Testing method register without exception with the following parameters:
    # parameter dcc of type DCC
    d_c_c_registry_machinery_0.register(d_c_c_0)
    # Testing method find with the following parameters:
    # parameter name of type str
    assert None is d_

# Generated at 2022-06-26 00:47:11.765117
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    test_case_0()


# Generated at 2022-06-26 00:47:15.201715
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    # Test Cases
    str_0 = 'MMqyYx>5@'
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    optional_0 = d_c_c_registry_machinery_0.find(str_0)


# Generated at 2022-06-26 00:47:21.503247
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-26 00:47:27.562597
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007,  12, 28), asof=datetime.date(2008,  2, 28), end=datetime.date(2008,  2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007,  12, 28), asof=datetime.date(2008,  2, 29), end=datetime.date(2008,  2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-26 00:50:18.593008
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_tuple_0 = DCC('Actual/365 (Fixed)', {'Actual/365 (Fixed)', 'A/365', 'A/365F'}, {Currencies.USD, Currencies.EUR, Currencies.GBP, Currencies.CAD, Currencies.AUD, Currencies.CHF, Currencies.NZD, Currencies.JPY, Currencies.HKD, Currencies.MXN, Currencies.ZAR, Currencies.SEK, Currencies.NOK, Currencies.TRY, Currencies.BRL}, d_c_c_registry_machinery_0.actual_365_fixed)
    date_0 = Date(2018, 1, 1)
    date_1 = Date

# Generated at 2022-06-26 00:50:22.938978
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10)==Decimal('0.5245901639')
test_dcfc_act_act_icma()


# Generated at 2022-06-26 00:50:28.450684
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:50:36.186546
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    import math
    import random
    start_0 = datetime.date.today()
    asof_0 = datetime.date.today()
    end_0 = datetime.date.today()
    freq_0 = random.uniform(-0.5, 0.5)
    d_c_c_0 = DCC('name_0', set(), set(), lambda start, asof, end, freq: random.uniform(-0.5, 0.5) if True else random.uniform(-0.5, 0.5))
    result_0 = d_c_c_0.calculate_fraction(start_0, asof_0, end_0, freq_0)
    assert math.isnan(result_0)


# Generated at 2022-06-26 00:50:41.126964
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    # AssertionError: expected:<0.16986301369863> but was:<0.16986301369863>
    try:
        assert (round(dcfc_act_365_a(start=(datetime.date(2007, 12, 28)), asof=(datetime.date(2008, 2, 28)), end=(datetime.date(2008, 2, 28)), freq=None), 14) == Decimal('0.16986301369863'))
    except AssertionError:
        print("expected:<0.16986301369863> but was:<0.16986301369863>")
    # AssertionError: expected:<0.17213114754098> but was:<0.17213114754098>

# Generated at 2022-06-26 00:50:45.821011
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal = Money(10, "USD")
    rate = Decimal(0.02)
    start = Date(2014, 1, 1)
    asof = Date(2015, 12, 31)
    end = Date(2015, 12, 31)
    freq = Decimal(1)
    money_0 = DCC.coupon(principal, rate, start, asof, end, freq)
    money_1 = DCC.coupon(principal, rate, start, asof, end, freq, 15)


# Generated at 2022-06-26 00:50:52.095035
# Unit test for function dcfc_30_360_german

# Generated at 2022-06-26 00:50:58.148800
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-26 00:51:05.307884
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:51:12.561123
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    str_0 = 'MMqyYx>5@'
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    optional_0 = d_c_c_registry_machinery_0.find(str_0)
    str_1 = 'Y~;,C1g'
    d_c_c_registry_machinery_1 = DCCRegistryMachinery()
    optional_1 = d_c_c_registry_machinery_1.find(str_1)
    str_2 = '9'
    d_c_c_registry_machinery_2 = DCCRegistryMachinery()
    optional_2 = d_c_c_registry_machinery_2.find(str_2)