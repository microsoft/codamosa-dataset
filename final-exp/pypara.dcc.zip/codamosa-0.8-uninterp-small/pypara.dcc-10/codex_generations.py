

# Generated at 2022-06-26 00:42:13.412653
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    def test_data_0():
        ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
        ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
        ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
        ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

        test_data_0_0 = (ex1_start, ex1_asof)

        test_data_0_1 = Decimal('0.16666666666667')

        test_data_0_2

# Generated at 2022-06-26 00:42:17.028504
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert str(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28))) == '0.16666666666667'


# Generated at 2022-06-26 00:42:27.855475
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    dcfc_act_act()

## DCC Models:

# Actual / Actual (ISDA):
ACTUAL_ACTUAL = DCC("Act/Act", {"Actual/Actual", "Actual/Actual (ISDA)"})

# Actual / 360:
ACTUAL_360 = DCC("Act/360", {"Actual/360"})

# Actual / 365:
ACTUAL_365 = DCC("Act/365", {"Actual/365"})

# Actual / Actual (Historical):
ACTUAL_ACTUAL_HISTORICAL = DCC("Act/Act (Historical)", {"Actual/Actual (Historical)"})

# Actual / Actual (ICMA):
ACTUAL_ACTUAL_ICMA = DCC("Act/Act (ICMA)", {"Actual/Actual (ICMA)"})

#

# Generated at 2022-06-26 00:42:38.312208
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-26 00:42:41.349509
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_tuple_0 = DCC


# Generated at 2022-06-26 00:42:42.608248
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # TODO: implement test case
    raise NotImplementedError("Method not implemented")


# Generated at 2022-06-26 00:42:52.441439
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert (dcfc_30_360_isda(datetime.date(2019, 1, 4), datetime.date(2019, 1, 4), datetime.date(2019, 1, 4)) == Decimal('0E-14'))
    assert (dcfc_30_360_isda(datetime.date(2019, 1, 4), datetime.date(2019, 1, 12), datetime.date(2019, 1, 12)) == Decimal('0.026666666666667'))
    assert (dcfc_30_360_isda(datetime.date(2019, 1, 4), datetime.date(2019, 1, 12), datetime.date(2019, 1, 12)) == Decimal('0.026666666666667'))

# Generated at 2022-06-26 00:43:02.323345
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-26 00:43:13.168926
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    # Test 1
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)
    assert (dcfc_30_e_plus_360(start=start, asof=asof, end=end) == Decimal('0.16666666666667'))

    # Test 2
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)
    end = datetime.date(2008, 2, 29)

# Generated at 2022-06-26 00:43:16.840423
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(datetime.date(2021, 2, 28), datetime.date(2021, 3, 31), datetime.date(2021, 3, 31),
                                   Decimal(5)), 14) == round(Decimal(0.16944444444444), 14)



# Generated at 2022-06-26 00:44:44.360564
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Example 1
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex1_end = datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_end), 14) == Decimal('0.16666666666667')

    # Example 2
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex2_end = datetime.date(2008, 2, 29)

# Generated at 2022-06-26 00:44:53.240567
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    start_0 = Date(23, 1, 2020)
    asof_0 = Date(11, 6, 2020)
    pub_0 = dcfc_30_e_360(start_0, asof_0, asof_0)
    assert round(pub_0, 14) == Decimal("0.16666666666667")
    start_1 = Date(10, 4, 2029)
    asof_1 = Date(9, 1, 2032)
    pub_1 = dcfc_30_e_360(start_1, asof_1, asof_1)
    assert round(pub_1, 14) == Decimal("2.95833333333333")
    start_2 = Date(21, 5, 2024)
    asof_2 = Date(2, 1, 2032)
    pub_2

# Generated at 2022-06-26 00:45:01.211972
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    result = dcfc_30_360_us(
        start=datetime.date(2007, 12, 28),
        asof=datetime.date(2008, 2, 29)
    )
    assert result == Decimal('0.16944444444444')

    result = dcfc_30_360_us(
        start=datetime.date(2007, 12, 28),
        asof=datetime.date(2008, 2, 28)
    )
    assert result == Decimal('0.16666666666667')

    result = dcfc_30_360_us(
        start=datetime.date(2007, 10, 31),
        asof=datetime.date(2008, 11, 30)
    )
    assert result == Decimal('1.08333333333333')

    result = dcfc_30

# Generated at 2022-06-26 00:45:11.033965
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    d_c_c_registry_machinery_1 = DCCRegistryMachinery()
    test_start_date_0 = Date('2017-01-01')
    test_asof_date_0 = Date('2017-01-02')
    test_end_date_0 = Date('2017-01-03')
    test_frequency_0 = Decimal('1')
    base_d_c_c_0 = DCC('Test DCC',
        set(),
        set(),
        lambda s, a, e, f: (Decimal('1')))
    test_dcc_0 = DCC('Test DCC',
        set(),
        set(),
        lambda s, a, e, f: (Decimal('0')))
    DCCRegistry.register(base_d_c_c_0)
   

# Generated at 2022-06-26 00:45:16.301881
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():

    a_date_0 = datetime.date(2008, 2, 1)
    a_date_1 = datetime.date(2008, 2, 29)
    a_date_2 = datetime.date(2008, 2, 28)

    result_0 = dcfc_30_360_us(a_date_0, a_date_1, a_date_0)
    result_1 = dcfc_30_360_us(a_date_0, a_date_2, a_date_0)
    assert result_0 == result_1

# Generated at 2022-06-26 00:45:23.364119
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    # test case 1
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

    # test case 2
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_act_365_a(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17213114754098')

    # test case 3
    ex

# Generated at 2022-06-26 00:45:31.066894
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    a_d_c_0 = DCC(name='name', altnames=set(), currencies=set(), calculate_fraction_method=lambda start, asof, end, freq: (start < end)*(asof >= start)*(asof <= end)*(asof - start))
    a_start_0 = datetime.date(2010, 5, 2)
    a_asof_0 = datetime.date(2010, 5, 2)
    a_end_0 = datetime.date(2010, 5, 5)
    a_freq_0 = None
    a_d_c_0.calculate_daily_fraction(a_start_0, a_asof_0, a_end_0, a_freq_0)


# Generated at 2022-06-26 00:45:39.298437
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2014, 1, 1)
    start_first_quarter = datetime.date(2014, 1, 1)
    start_second_quarter = datetime.date(2014, 4, 1)
    start_third_quarter = datetime.date(2014, 7, 1)
    start_fourth_quarter = datetime.date(2014, 10, 1)
    end = datetime.date(2014, 11, 1)
    asof_first_quarter = datetime.date(2014, 2, 1)
    asof_second_quarter = datetime.date(2014, 5, 1)
    asof_third_quarter = datetime.date(2014, 8, 1)
    asof_fourth_quarter = datetime.date(2014, 11, 1)
    freq_quarterly = 4

    d_c

# Generated at 2022-06-26 00:45:47.900181
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d_c_c_registry_machinery_1 = DCCRegistryMachinery()
    d_c_c_registry_machinery_1.DCC.calculate_fraction(datetime.date(2017, 3, 26), datetime.date(2017, 6, 30), datetime.date(2017, 12, 31))
    d_c_c_registry_machinery_1.DCC.calculate_fraction(datetime.date(2017, 3, 26), datetime.date(2017, 12, 31), datetime.date(2017, 12, 31))

# Generated at 2022-06-26 00:45:56.148971
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == pytest.approx(0.16942884946478)
    assert dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == pytest.approx(0.17216108990194)
    assert dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == pytest.approx(1.08243131970956)

# Generated at 2022-06-26 00:47:13.469711
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Simple date check
    assert dcfc_30_360_german(start=datetime.date(2018, 12, 12), asof=datetime.date(2018, 12, 13), end=datetime.date(2018, 12, 13)) == Decimal('0.008333333333333'), "Date: 2018-12-12, 2018-12-13, "


# Generated at 2022-06-26 00:47:20.054470
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    print("test_dcfc_30_360_us:")
    assert(dcfc_30_360_us(start=datetime.date(2017, 2, 28), asof=datetime.date(2017, 5, 1), end=datetime.date(2017, 5, 1)) == Decimal("0.08"))
    assert(dcfc_30_360_us(start=datetime.date(2017, 2, 28), asof=datetime.date(2017, 5, 31), end=datetime.date(2017, 5, 31)) == Decimal("0.28"))

# Generated at 2022-06-26 00:47:29.836630
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-26 00:47:43.072721
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc_0 = DCC("name", ["altnames"], ["currencies"], "calculate_fraction_method")
    principal_0 = Money("principal", "currencies")
    rate_0 = Decimal("rate")
    start_0 = Date("start")
    asof_0 = Date("asof")
    end_0 = Date("end")
    freq_0 = Decimal("freq")
    eom_0 = int("eom")

    # Case 1
    try:
        # Action
        ret_c_1 = dcc_0.interest(principal_0, rate_0, start_0, asof_0, end_0, freq_0)
        # print("ret_c_1:", ret_c_1)
    except Exception as exc:
        pass



# Generated at 2022-06-26 00:47:45.797209
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ## Get the new start date, if required:
    start_date=datetime.date(year=2008, month=2, day=29)
    end_date=datetime.date(year=2009, month=2, day=28)

    expected_result=Decimal('1.02777777777778')

    obtained_result=dcfc_30_360_german(start=start_date, asof=end_date, end=end_date)
    assert expected_result == obtained_result


# Generated at 2022-06-26 00:47:51.806030
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')


# Generated at 2022-06-26 00:47:56.013942
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    #Test 1
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == 0.16666666666667
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    #Test 2
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-26 00:48:00.989067
# Unit test for function dcfc_30_e_360

# Generated at 2022-06-26 00:48:03.401063
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    a = datetime.date(2016, 4, 6)
    b = datetime.date(2016, 5, 9)
    dcfc_30_e_plus_360(a, b, b)
    #assert dcfc_30_e_plus_360(a, b, b) == Decimal('0.3')


# Generated at 2022-06-26 00:48:08.215834
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    """ Unit test for function dcfc_30_e_plus_360 """
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)

# Generated at 2022-06-26 00:50:50.814860
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_registry_machinery_0.put_d_c_c(date(2016, 2, 19), date(2016, 2, 19), date(2016, 2, 19), True)


# Generated at 2022-06-26 00:50:53.616285
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    year = 2018
    month = 3
    day = 1
    start = Date(year, month, day)
    asof = Date(year, month, day)
    end = Date(year, month, day)
    freq = None
    DCC.calculate_fraction(start, asof, end, freq)

# Generated at 2022-06-26 00:50:59.670980
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28))==Decimal("0.16666666666667")
    assert dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29))==Decimal("0.16944444444444")
    assert dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30))==Decimal("1.08333333333333")

# Generated at 2022-06-26 00:51:07.276559
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    test_case_0()
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-26 00:51:13.729908
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .currencies import Currencies
    from .monetary import Money
    from .commons.numbers import Decimal
    from .commons.numbers import Decimal
    from .commons.numbers import Decimal
    from .commons.numbers import Decimal
    from .commons.numbers import Decimal
    from .commons.numbers import Decimal
    from .commons.numbers import Decimal
    from .commons.numbers import Decimal

    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    principal = Money('1000', Currencies.USD)
    rate = Decimal('0.005')
    start = Date(2018, 5, 1)
    asof = Date(2018, 6, 29)
    d_c_c_registry_machinery

# Generated at 2022-06-26 00:51:19.572108
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    print("Test case for calculate_fraction of class DCC.")
    print("DCC.calculate_fraction(datetime.date(2017,1,1), datetime.date(2017,1,1) , datetime.date(2017,1,1))")
    if DCCRegistry().__z_asset__().calculate_fraction(datetime.date(2017,1,1), datetime.date(2017,1,1) , datetime.date(2017,1,1)) != 1:
        print("Error")
    print("DCC.calculate_fraction(datetime.date(2017,1,1), datetime.date(2017,1,1) , datetime.date(2017,1,2))")