

# Generated at 2022-06-26 00:41:55.221074
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14)==Decimal('0.17216108990194')
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14)==Decimal('1.08243131970956')

# Generated at 2022-06-26 00:42:06.307635
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    d_cfc = dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))
    assert round(d_cfc, 14) == Decimal('0.16986301369863')

    d_cfc = dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29))
    assert round(d_cfc, 14) == Decimal('0.17213114754098')


# Generated at 2022-06-26 00:42:17.301728
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2008,3,1), datetime.date(2008,3,31), datetime.date(2008,3,31), None), 14) == Decimal('0.086111111111111')
    assert round(dcfc_30_360_isda(datetime.date(2008,3,1), datetime.date(2008,3,31), datetime.date(2008,3,31), None), 14) == Decimal('0.086111111111111')
    assert round(dcfc_30_360_isda(datetime.date(2008,3,1), datetime.date(2008,4,30), datetime.date(2008,4,30), None), 14) == Decimal('0.097222222222222')
   

# Generated at 2022-06-26 00:42:21.832768
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    obj = DCCRegistryMachinery()
    if obj._is_registered("name"):
        # Verify that this is not re-registered
        raise RuntimeError("register failed due to repeated registry.")
    else:
        # Register a new instance of class DCC
        obj.register(DCC())
        if not obj._is_registered("name"):
            # Verify that this is registered successfully
            raise RuntimeError("register failed due to a bad registry.")
        else:
            return True


# Generated at 2022-06-26 00:42:33.755778
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .monetary import Money
    from .currencies import GBP

    dcc_A_360 = DCCRegistry['Actual/360']

    endDt_1 = Date(2017, 5, 9)
    asofDt_1 = Date(2017, 5, 9)
    startDt_1 = Date(2017, 5, 9)

    cashflow_1 = Money(150000, GBP)
    rate_1 = Decimal(0.0625)
    freq_1 = Decimal(2)

    interest_1 = dcc_A_360.interest(cashflow_1, rate_1, startDt_1, asofDt_1, endDt_1, freq_1)
    assert(interest_1.units == Decimal(1500.0))


# Generated at 2022-06-26 00:42:41.918190
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)  == Decimal('0.16986301369863')
    assert round

# Generated at 2022-06-26 00:42:45.532393
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    d_c_f_c_3 = dcfc_30_360_isda(datetime.date(2014, 11, 20), datetime.date(2016, 5, 19), datetime.date(2015, 11, 20))
    assert d_c_f_c_3 == 0.6666666666666666


# Generated at 2022-06-26 00:42:55.129126
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    start1 = datetime.date(2007, 12, 28)
    start2 = datetime.date(2007, 12, 30)
    start3 = datetime.date(2007, 12, 15)
    start4 = datetime.date(2007, 2, 28)
    start5 = datetime.date(2007, 2, 15)
    start6 = datetime.date(2007, 2, 30)

    asof1 = datetime.date(2008, 2, 28)
    asof2 = datetime.date(2008, 2, 29)
    asof3 = datetime.date(2007, 11, 30)
    asof4 = datetime.date(2007, 11, 15)
    asof5 = datetime.date(2008, 1, 31)
    asof6 = datetime.date(2007, 11, 31)

   

# Generated at 2022-06-26 00:43:03.290640
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    ## Create a Day Count Convention
    d_c_c_0 = DCC(name = 'test_name_0', altnames = set([str('test_altname_0'), str('test_altname_1')]), currencies = set([Currencies['USD'], Currencies['EUR']]), calculate_fraction_method = lambda p_0, p_1, p_2, p_3: Decimal('0.5'))
    ## Create a Date
    date = datetime.date(2007, 2, 23)
    ## Some data for testing
    start = date
    asof = date
    end = date
    freq = Decimal('0.5')

    ## Execute the function under test

# Generated at 2022-06-26 00:43:14.348032
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    print("Testing function dcfc_30_e_360...")
    assert_almost_equal(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), Decimal("0.16666666666667"))
    assert_almost_equal(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), Decimal("0.16944444444444"))

# Generated at 2022-06-26 00:43:50.266369
# Unit test for function dcfc_act_act

# Generated at 2022-06-26 00:43:55.395357
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d_c_c_0 = DCC("a","b",Currencies["USD"],"")
    date_0 = datetime.date(1,1,1)
    date_1 = datetime.date(1,1,1)
    date_2 = datetime.date(1,1,1)
    d_c_c_0.calculate_fraction(date_0,date_1,date_2)


# Generated at 2022-06-26 00:44:07.384004
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667'))

# Generated at 2022-06-26 00:44:15.972751
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC(
        name="name",
        altnames={},
        currencies={},
        calculate_fraction_method=lambda x1, x2, x3, x4: ZERO,
    )
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 1)
    freq = None
    res = dcc.calculate_fraction(start, asof, end, freq)
    assert res == ZERO
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 1)
    freq = ONE
    res = dcc.calculate_f

# Generated at 2022-06-26 00:44:19.358097
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d_c_c_0 = DCC()
    d_c_c_0.calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 4, 1), datetime.date(2014, 7, 1))



# Generated at 2022-06-26 00:44:27.431385
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    ## Default parameters
    d_c_c_0 = DCC(name="", altnames={""}, currencies={}, calculate_fraction_method=lambda start, asof, end, freq: Decimal("NaN"))   
    ## Invalid arguments
    assert d_c_c_0.calculate_fraction(start=None, asof=None, end=None, freq=None) == ZERO
    assert d_c_c_0.calculate_fraction(start=datetime.date(2020, 1, 1), asof=datetime.date(2020, 1, 1), end=datetime.date(2020, 1, 1), freq=1) == ZERO
    ## Valid arguments

# Generated at 2022-06-26 00:44:34.878131
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Check the function dcfc_30_e_360 for the following values:

    | Start Date | Asof Date | End Date      | Day Count Fraction |
    ----------------------------------------------------------------
    | 2007-12-28 | 2008-02-28| 2008-02-28    | 0.16666666666667   |
    | 2007-12-28 | 2008-02-29| 2008-02-29    | 0.16944444444444   |
    | 2007-10-31 | 2008-11-30| 2008-11-30    | 1.08333333333333   |
    | 2008-02-01 | 2009-05-31| 2009-05-31    | 1.33055555555556   |
    """

# Generated at 2022-06-26 00:44:45.661225
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:44:52.730604
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    try:
        ex0_start, ex0_asof, ex0_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
        s = round(dcfc_act_act_icma(start=ex0_start, asof=ex0_asof, end=ex0_end), 10)
        assert s == (Decimal('0.5245901639'))
    except:
        return False
    return True



# Generated at 2022-06-26 00:45:00.917092
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():

    # Test Case 1
    d_c_c_1 = DCC('name',{'altnames'},{'currencies'},lambda start : start)
    d_c_c_1.calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 3))

    # Test Case 2
    d_c_c_2 = DCC('name',{'altnames'},{'currencies'},lambda start : start)
    d_c_c_2.calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 3), datetime.date(2017, 1, 3))

    # Test Case 3

# Generated at 2022-06-26 00:45:41.598591
# Unit test for function dcfc_30_360_german

# Generated at 2022-06-26 00:45:50.752819
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    from datetime import datetime
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == 0.16666666666667
    assert round

# Generated at 2022-06-26 00:45:58.280299
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # dcfc_30_360_isda(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
    # TODO: Add more test cases....
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 30)
    end = datetime.date(2008, 2, 30)
    result = dcfc_30_360_isda(start, asof, end)
    expected = Decimal('0.16944444444444')
    assert (result == expected)
    end = datetime.date(2008, 5, 31)
    result = dcfc_30_360_isda(start, asof, end)
    expected = Decimal('0.16944444444444')
   

# Generated at 2022-06-26 00:46:06.629940
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert(round(dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667'))
    assert(round(dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444'))
    assert(round(dcfc_30_360_us(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333'))

# Generated at 2022-06-26 00:46:14.918171
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667'))

# Generated at 2022-06-26 00:46:19.157696
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    d_c_c_0 = DCC()
    principal = Money()
    rate = Decimal()
    start = datetime.date()
    asof = datetime.date()
    end = datetime.date()
    freq = Union[int, Decimal]
    eom = Optional[int]
    d_c_c_0.coupon(principal, rate, start, asof, end, freq, eom)


# Generated at 2022-06-26 00:46:26.906059
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    #
    # Attempts to register the given day count convention.
    #
    d_c_c_0 = DCC()
    d_c_c_0.name = "name_0"
    # d_c_c_0.altnames
    # d_c_c_0.currencies
    # d_c_c_0.calculate_fraction_method
    #
    d_c_c_1 = DCC()
    d_c_c_1.name = "name_0"
    d_c_c_1.altnames = {"altname_0"}
    # d_c_c_1.currencies
    # d_c_c_1.calculate_fraction_method

# Generated at 2022-06-26 00:46:32.127224
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    try:
        print(dcfc_act_act_icma(start = datetime.date(2019, 3, 2), asof = datetime.date(2019, 9, 10), end = datetime.date(2020, 3, 2)))
    except TypeError as err:
        print(err)
    except ValueError as err:
        print(err)
    except Exception as err:
        print(err)


# Generated at 2022-06-26 00:46:40.066042
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-26 00:46:48.772582
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Test case 1
    d_c_f_c_func = dcfc_act_act
    start_1 = datetime.date(2007, 12, 28)
    end_1 = datetime.date(2008, 2, 28)
    freq_1 = None
    exp_1 = Decimal('0.16942884946478')
    # Check expected against actual
    assert exp_1 == d_c_f_c_func(start_1, end_1, end_1, freq_1)
    # Test case 2
    start_2 = datetime.date(2007, 12, 28)
    end_2 = datetime.date(2008, 2, 29)
    freq_2 = None
    exp_2 = Decimal('0.17216108990194')
    # Check expected against actual
