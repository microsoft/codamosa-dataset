

# Generated at 2022-06-26 00:42:06.162130
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCC.calculate_fraction(DCC(), datetime.date(2014, 12, 24), datetime.date(2014, 12, 24), datetime.date(2014, 12, 24), None) == 0
    assert DCC.calculate_fraction(DCC(), datetime.date(2014, 11, 24), datetime.date(2014, 12, 24), datetime.date(2014, 12, 24), None) == 1
    assert DCC.calculate_fraction(DCC(), datetime.date(2014, 12, 24), datetime.date(2014, 12, 26), datetime.date(2014, 12, 26), None) == 2

# Generated at 2022-06-26 00:42:17.164069
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    start_date = datetime.date(2017, 1, 1)
    end_date = datetime.date(2017, 2, 1)
    
    computed_result = d_c_c_0.calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 2, 2))
    expected_result = 0
    assert computed_result == expected_result
    
    computed_result = d_c_c_0.calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 2, 2))
    expected_result = 0
    assert computed_result == expected_result
    

# Generated at 2022-06-26 00:42:28.089921
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Define the testing data
    start = datetime.datetime.strptime('2020-01-01', '%Y-%m-%d')
    asof = datetime.datetime.strptime('2021-01-01', '%Y-%m-%d')
    end = datetime.datetime.strptime('2021-01-01', '%Y-%m-%d')
    freq = 12
    # Define right answer
    right = 1
    # Get result
    result = dcfc_act_act(start, asof, end, freq)
    # Check result
    assert result == right

# Unit test cases for function dcc

# Generated at 2022-06-26 00:42:34.464603
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    d_c_c_0 = DCC()
    s_0 = 2
    asof_0 = 2
    e_0 = 2
    freq_0 = None
    assert d_c_c_0.calculate_daily_fraction(start=s_0, asof=asof_0, end=e_0, freq=freq_0) == 0


# Generated at 2022-06-26 00:42:42.395110
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    dcc_30_360_german = dcfc_30_360_german(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28))
    assert dcc_30_360_german == Decimal('0.16666666666667')
    dcc_30_360_german = dcfc_30_360_german(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 2, 29))
    assert dcc_30_360_german == Decimal('0.16944444444444')

# Generated at 2022-06-26 00:42:52.218226
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # test 1
    # see at: https://github.com/KazanPythonMeetup/yield-toolset/blob/master/tests/test_daycount.py
    d_c_c_0 = DCC()
    start = datetime.date(2019, 1, 1)
    asof = datetime.date(2019, 2, 1)
    end = datetime.date(2019, 3, 1)
    freq = None
    result = d_c_c_0.calculate_fraction(start, asof, end, freq)
    assert result == 1
    # test 2
    # see at: https://github.com/KazanPythonMeetup/yield-toolset/blob/master/tests/test_daycount.py

# Generated at 2022-06-26 00:43:00.376312
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Test cases for method calculate_daily_fraction of class DCC
    """
    p_d_c_c_0_0 = Money(amount=0.0, currency=Currencies["TRY"])
    p_d_c_c_0_1 = Money(amount=9999998.0, currency=Currencies["TRY"])
    p_d_c_c_0_2 = Money(amount=0.0, currency=Currencies["TRL"])
    p_d_c_c_1_0 = Decimal(0.0)
    p_d_c_c_1_1 = Decimal(1.0)
    p_d_c_c_2_0 = datetime.date(2000, 1, 1)

# Generated at 2022-06-26 00:43:07.343086
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)),
                 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)),
                 14) == Decimal('0.16944444444444')

# Generated at 2022-06-26 00:43:16.495826
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    settlement_date = datetime.date(2016, 9, 15)
    payment_date = datetime.date(2016, 9, 15)
    next_payment_date = datetime.date(2016, 12, 15)

# Generated at 2022-06-26 00:43:27.313473
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)


# Generated at 2022-06-26 00:44:12.539128
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    actualDate = datetime.date(2020, 5, 31)
    actualDate_1 = datetime.date(2020, 6, 1)
    principal = Money(100, Currencies.USD)
    rate = Decimal(0.01)
    start = datetime.date(2020, 1, 31)
    end = datetime.date(2020, 6, 30)
    freq = Decimal(0.5)
    eom = 1
    frequency = 1

    dcc_registry = DCCRegistry()
    dcc = dcc_registry.DCC_ACT_360
    

# Generated at 2022-06-26 00:44:18.486011
# Unit test for function dcfc_30_360_german

# Generated at 2022-06-26 00:44:25.808547
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # Test case data
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)
    # Expected results
    expected_result = Decimal('0.16666666666667')
    # Perform the test
    test_result = dcfc_30_360_isda(start, asof, end)
    # Print out the test results
    print('test_dcfc_30_360_isda')
    print('  Expected:', expected_result)
    print('  Actual:  ', test_result)
    assert expected_result == test_result, 'Test FAILED'


# Generated at 2022-06-26 00:44:33.420555
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():

    # Test case 0
    ex0_start = datetime.date(2020, 1, 1)
    ex0_asof = datetime.date(2020, 1, 1)
    ex0_end = datetime.date(2020, 1, 1)

    dcfc_act_act_icma(start=ex0_start, asof=ex0_asof, end=ex0_end)

    # Test case 1
    ex1_start = datetime.date(2019, 3, 2)
    ex1_asof = datetime.date(2019, 9, 10)
    ex1_end = datetime.date(2020, 3, 2)


# Generated at 2022-06-26 00:44:43.809940
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:44:52.769721
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    assert dcfc_act_act(
        ex1_start,
        ex1_asof,
        ex1_asof
    ) == Decimal('0.16942884946478')
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    assert dcfc_act_act(
        ex2_start,
        ex2_asof,
        ex2_asof
    ) == Decimal('0.17216108990194')
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime

# Generated at 2022-06-26 00:45:00.939800
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert abs(dcfc_30_360_german(start=Date(2008,1,1),
                                  asof=Date(2008,1,31),
                                  end=Date(2008,1,31)) - Decimal('0.083333333333333')) < Decimal('0.00000000000001')
    assert abs(dcfc_30_360_german(start=Date(2008,2,29),
                                  asof=Date(2008,3,3),
                                  end=Date(2008,3,3)) - Decimal('0.044444444444444')) < Decimal('0.00000000000001')

# Generated at 2022-06-26 00:45:06.916728
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    principal = Money.of("SAR", 1)
    rate = Decimal("1")
    start = Date.today()
    end =  Date.today()
    asof = Date.today()
    freq = Decimal("0")
    d_c_c_0 = DCC()
    d_c_c_0.interest(principal, rate, start, end, asof, freq)


# Generated at 2022-06-26 00:45:15.049764
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    start_date = datetime.date(2019, 3, 2)
    end_date = datetime.date(2020, 3, 2)
    as_of_date_1 = datetime.date(2019, 3, 2)
    as_of_date_2 = datetime.date(2019, 9, 10)
    assert (round(dcfc_act_act_icma(start_date, as_of_date_1, end_date), 9) == Decimal(0.0))
    assert (round(dcfc_act_act_icma(start_date, as_of_date_2, end_date), 9) == Decimal(0.524590164))


# Generated at 2022-06-26 00:45:20.812511
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal = Money(100, Currencies.GBP)
    rate = Decimal('0.1')
    start = Date.from_str('2017-01-01')
    asof = Date.from_str('2017-04-02')
    end = Date.from_str('2017-07-01')
    freq = 2
    eom = None
    d_c_c_0 = DCC()
    assert d_c_c_0

    assert d_c_c_0.coupon(principal, rate, start, asof, end, freq, eom) == Money(20, Currencies.GBP)


# Generated at 2022-06-26 00:46:21.748928
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == round(Decimal('0.16666666666667'), 14)
    assert round(dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == round(Decimal('0.16944444444444'), 14)
    assert round(dcfc_30_360_german(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == round(Decimal('1.08333333333333'), 14)

# Generated at 2022-06-26 00:46:23.278003
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 00:46:31.884086
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    
    assert dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_360

# Generated at 2022-06-26 00:46:37.687535
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2012, 1, 3)
    asof = datetime.date(2012, 12, 31)
    end = datetime.date(2014, 1, 2)
    freq = Decimal(2)
    d_c_c_0 = DCC(name = "test_DCC_calculate_fraction_0",altnames = set(),currencies = set(),calculate_fraction_method = None)
    assert d_c_c_0.calculate_fraction(start, asof, end, freq) == 0

# Generated at 2022-06-26 00:46:45.723015
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # d_c_c_0 = DCC()
    # d_c_c_0.calculate_fraction
    assert DCC.calculate_fraction.__name__ == 'calculate_fraction'
    d_c_c_0 = DCC()
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = datetime.date(2018, 1, 1)
    freq = Decimal(1)
    d_c_c_0.calculate_fraction(start, asof, end, freq)  # This is supposed to pass



# Generated at 2022-06-26 00:46:49.092227
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex_start, ex_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex_result = 0.16666666666667
    assert ex_result == dcfc_30_360_german(start=ex_start, asof=ex_asof, end=ex_asof)



# Generated at 2022-06-26 00:46:53.246847
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d_c_c = DCC('test_name', {'test_alternative_name'}, {Currencies['USD']}, lambda start, asof, end, freq: 1.0)
    start = Date(2020, 7, 3)
    asof = Date(2020, 7, 3)
    end = Date(2020, 7, 5)
    assert d_c_c.calculate_fraction(start, asof, end, None) == 1.0


# Generated at 2022-06-26 00:46:56.873130
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Unit test for dcfc_act_act
    """
    try:
        dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))
    except Exception as e:
        print ("Function 'dcfc_act_act' raised an exception: %s" % e)
        assert False
    else:
        assert True

# Test case for function _construct_date

# Generated at 2022-06-26 00:47:09.310981
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Test case 1:
    ## Instantiate DCC object
    dcc_1 = DCC(name = 'Act/Act ISDA', altnames = {'Actual/Actual ISDA'}, currencies = {Currencies.USD}, calculate_fraction_method = calculate_fraction_actual_actual)
    start_1 = datetime.date(2014, 6, 1)
    asof_1 = datetime.date(2014, 6, 2)
    end_1 = datetime.date(2014, 7, 1)
    freq_1 = 1
    assert dcc_1.calculate_daily_fraction(start_1, asof_1, end_1, freq_1) == Decimal('1/30')
    # Test case 2:
    ## Instantiate DCC object

# Generated at 2022-06-26 00:47:17.560446
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Test 0
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-26 00:48:33.348354
# Unit test for method interest of class DCC
def test_DCC_interest():
    d_c_c_0 = DCC("name", set(), set(), lambda a, b, c, d: ZERO)
    m_0 = Money("0", "currency1")
    date_0 = datetime.date(2018, 5, 6)
    date_1 = datetime.date(2018, 5, 6)
    s_0 = Decimal("0")
    m_1 = d_c_c_0.interest(m_0, s_0, date_0, date_1)
    assert m_1 == Money("0", "currency1")
    m_0 = Money("25", "currency2")
    s_0 = Decimal("1")
    m_1 = d_c_c_0.interest(m_0, s_0, date_0, date_1)
    assert m_1

# Generated at 2022-06-26 00:48:39.951134
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    print("Test dcfc_30_360_us(start, asof):\n")

# Generated at 2022-06-26 00:48:49.033055
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    d_c_c_0 = DCC("Act/Act", {"Actual/Actual", "Actual/Actual (ISDA)"}, {Currency("USD")}, dcfc_act_act)
    assert d_c_c_0.name == "Act/Act"
    assert d_c_c_0.altnames == {"Actual/Actual", "Actual/Actual (ISDA)"}
    assert d_c_c_0.currencies == {Currency("USD")}
    assert round(d_c_c_0.calculate_fraction_method(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == 0.16942884946478

# Generated at 2022-06-26 00:48:56.827359
# Unit test for function dcfc_act_act

# Generated at 2022-06-26 00:49:00.966279
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    x_actual = DCC(name='DCC', altnames=set(), currencies=set(), calculate_fraction_method=None).calculate_fraction(asof=datetime.date(2017, 10, 10), start=datetime.date(2017, 10, 10), end=datetime.date(2017, 10, 10), freq=None)
    x_expected = Decimal(0)
    assert x_actual == x_expected

# Generated at 2022-06-26 00:49:07.809376
# Unit test for method interest of class DCC
def test_DCC_interest():
    # Create a DCC
    d_c_c_0 = DCC()

    # Create a Money
    money_0 = Money()

    # Create an int
    int_0 = 1
    # Create a Decimal
    decimal_0 = Decimal()
    # Create a Date
    date_0 = Date()

    # Call the method
    try:
        d_c_c_0.interest(money_0, decimal_0, date_0, date_0, date_0, decimal_0, int_0)
    except AssertionError as e:
        print(str(e))
        return False
    except Exception as e:
        print(str(e))
        return False
    else:
        return True


# Generated at 2022-06-26 00:49:10.557404
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    with pytest.raises(TypeError):
        d_c_c_0 = DCC()
        d = datetime.date(2007, 12, 28)
        dcfc_act_act(d_c_c_0, d, d)


# Generated at 2022-06-26 00:49:18.324224
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ## (start, asof, end, freq)
    test_cases = (
        (datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), 3),
        (datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), 4)
    )
    for test_case in test_cases:
        assert dcfc_act_act_icma(test_case[0], test_case[1], test_case[2], test_case[3]) == 0.5245901639



# Generated at 2022-06-26 00:49:21.388903
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    d_c_c_0 = DCC("Test1", {}, set(), lambda start, asof, end, freq: (asof - start) / (end - start))
    d_C_C_registry = DCCRegistryMachinery()
    d_C_C_registry.register(d_c_c_0)
    assert d_C_C_registry._buffer_main["Test1"] is not None
    assert d_C_C_registry._buffer_altn["Test1"] is not None


# Generated at 2022-06-26 00:49:27.382692
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Create test data
    principal = Money(1, "USD")
    rate = Decimal(1)
    start = Date(1, 1, 1)
    asof = Date(1, 1, 1)
    end = Date(1, 1, 1)
    freq = Decimal(1)

    # Create and initialize an instance of class DCC
    d_c_c_0 = DCC()

    # Invoke method calculate_fraction of the class instance d_c_c_0
    retval_0 = d_c_c_0.calculate_fraction(start, asof, end, freq)
