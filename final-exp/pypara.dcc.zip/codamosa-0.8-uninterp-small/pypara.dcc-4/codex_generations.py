

# Generated at 2022-06-26 00:42:07.943455
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    v_dcfc_30_360_isda_0 = dcfc_30_360_isda( asof=datetime.date( year=2018, month=1, day=5 ), end=datetime.date( year=2018, month=1, day=5 ), freq=1, start=datetime.date( year=2017, month=12, day=6 ) )
    v_dcfc_30_360_isda_1 = dcfc_30_360_isda( asof=datetime.date( year=2018, month=7, day=5 ), end=datetime.date( year=2018, month=7, day=5 ), freq=3, start=datetime.date( year=2018, month=1, day=5 ) )
    v_dcfc_30_360_isda_2

# Generated at 2022-06-26 00:42:17.830787
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    coupon_0 = DCC('name_0', {}, {}, lambda start, asof, end, freq: Decimal(0)).coupon(Money(100.0, 'currency_0', 0.0), Decimal(0), datetime.date(0, 0, 0), datetime.date(0, 0, 0), datetime.date(0, 0, 0), 2)
    assert coupon_0 == Money(0.0, 'currency_0', 0.0)

# Generated at 2022-06-26 00:42:23.769282
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
        # initiates object of class DCCRegistryMachinery
        d_c_c_registry_machinery_1 = DCCRegistryMachinery()
        # calls the function _get_date_range defined in module _date_util and saves the result in variable result_0
        result_0 = _get_date_range(datetime.date(1, 1, 1), datetime.date(2, 1, 1))
        # checks if variable result_0 is of type Iterable[Date]
        if False:
            raise TypeError("result_0 has type {}, expected Iterable[Date]".format(type(result_0)))
        # calls the function _get_date_range defined in module _date_util and saves the result in variable result_1

# Generated at 2022-06-26 00:42:35.000671
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    # Tests whether calculate_fraction does not divide by a number <= 0.
    d_c_c_registry_machinery_0.case_0(DCC('', {}, {}, _calculate_fraction_30e360))
    # Tests whether calculate_fraction does not divide by a number <= 0.
    d_c_c_registry_machinery_0.case_1(DCC('', {}, {}, _calculate_fraction_30e360))
    # Tests whether calculate_fraction does not divide by a number <= 0.

# Generated at 2022-06-26 00:42:42.728331
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    d_c_c_machinery_0 = DCCRegistryMachinery()
    d_c_c_machinery_0.register_all(dcc.__dict__)
    d_c_c_machinery_0.register_all(dcc_currency.__dict__)

    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)

# Generated at 2022-06-26 00:42:52.582215
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-26 00:43:00.661841
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Test Day Count Convention: 30/360 German
    """
    assert Decimal(str(dcfc_30_360_german(start=date(2017, 9, 16), asof=date(2017, 12, 31), end=date(2017, 12, 31)))) == Decimal(1)
    assert Decimal(str(dcfc_30_360_german(start=date(2017, 9, 16), asof=date(2018, 1, 31), end=date(2018, 1, 31)))) == Decimal(1)
    assert Decimal(str(dcfc_30_360_german(start=date(2017, 9, 15), asof=date(2018, 1, 31), end=date(2018, 1, 31)))) == Decimal(1)

# Generated at 2022-06-26 00:43:07.569571
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert (dcfc_30_360_us(datetime.date(2018, 1, 1),
                           datetime.date(2018, 2, 1),
                           datetime.date(2018, 2, 1)) == Decimal('0.08333333'))
    assert (dcfc_30_360_us(datetime.date(2018, 1, 1),
                           datetime.date(2018, 2, 28),
                           datetime.date(2018, 2, 28)) == Decimal('0.26666667'))
    assert (dcfc_30_360_us(datetime.date(2018, 4, 1),
                           datetime.date(2018, 5, 1),
                           datetime.date(2018, 5, 1)) == Decimal('0.08333333'))

# Generated at 2022-06-26 00:43:11.933995
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')


# Generated at 2022-06-26 00:43:19.444552
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    s = datetime.date(2016, 1, 1)
    a = datetime.date(2017, 12, 31)
    e = datetime.date(2018, 7, 1)
    f = Decimal(0.5)
    d = Decimal(1)
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_0 = DCC(
        name = 'name',
        altnames = {'altname1', 'altname2'},
        currencies = _as_ccys({'CAD', 'USD', 'EUR'}),
        calculate_fraction_method = lambda start: start,
    )
    d_c_c_0.calculate_daily_fraction(s, a, e, f)
# Unit test end



# Generated at 2022-06-26 00:44:11.777811
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(datetime.date(2014, 11, 7), datetime.date(2015, 5, 18), datetime.date(2015, 5, 18)), 14) == Decimal('0.51111111111111')
    assert round(dcfc_30_360_german(datetime.date(2014, 11, 7), datetime.date(2015, 5, 19), datetime.date(2015, 5, 19)), 14) == Decimal('0.51111111111111')
    assert round(dcfc_30_360_german(datetime.date(2014, 11, 7), datetime.date(2015, 5, 20), datetime.date(2015, 5, 20)), 14) == Decimal('0.51666666666667')

# Generated at 2022-06-26 00:44:20.251437
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ## Test case 1:
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex1_expected_result = (Decimal('0.16942884946478'))
    ex1_actual_result = dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof, freq=None)
    ex1_assertion_status = (ex1_actual_result == ex1_expected_result)
    if(ex1_assertion_status):
        print("Passed Test case 1 for function dcfc_act_act")

# Generated at 2022-06-26 00:44:27.511815
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """Test day count fraction for convention 30E/360."""
    assert dcfc_30_e_360(Date(2015, 9, 28), Date(2015, 9, 29), Date(2015, 9, 29)) == Decimal('0.008333333333333')
    assert dcfc_30_e_360(Date(2015, 9, 28), Date(2015, 9, 29), Date(2015, 9, 29)) == Decimal('0.008333333333333')
    assert dcfc_30_e_360(Date(2015, 9, 28), Date(2015, 9, 30), Date(2015, 9, 30)) == Decimal('0.016666666666667')

# Generated at 2022-06-26 00:44:33.451770
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    print('\nTest for method dcfc_act_act_icma')
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')



# Generated at 2022-06-26 00:44:43.854808
# Unit test for function dcfc_30_e_360

# Generated at 2022-06-26 00:44:50.467820
# Unit test for method interest of class DCC
def test_DCC_interest():
    principal = Money("2000", "USD")
    rate = Decimal("2")
    start = Date("2019-01-02")
    asof = Date("2019-01-04")
    end = Date("2019-01-04")
    freq = Decimal("1")
    dcc = DCC("TEST", set(), set(), lambda s, a, e, f: Decimal("1.0"))
    result = dcc.interest(principal, rate, start, asof, end, freq)
    assert result == Money("40", "USD")


# Generated at 2022-06-26 00:44:59.379480
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # Case 1
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert(round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667'))
    # Case 2
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert(round(dcfc_30_e_360(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.16944444444444'))
    # Case 3
    ex3_

# Generated at 2022-06-26 00:45:07.743708
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d_c_c_registry_machinery_1 = DCCRegistryMachinery()
    test_d_c_c_calculate_fraction_0 = d_c_c_registry_machinery_1.d_c_c_registry.get_dcc('')
    test_d_c_c_calculate_fraction_result_0 = test_d_c_c_calculate_fraction_0.calculate_fraction(test_d_c_c_calculate_fraction_0, 0, 0)
    assert test_d_c_c_calculate_fraction_result_0 == 0


# Generated at 2022-06-26 00:45:14.204139
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    """
    Test to see if the result of dcfc_30_e_plus_360 is correct.
    """
    start_date = datetime.date(year=2019, month=10, day=31)
    end_date = datetime.date(year=2019, month=12, day=31)

    result = dcfc_30_e_plus_360(start_date, end_date, end_date)

    assert result == 1/12

if __name__ == '__main__':
    test_dcfc_30_e_plus_360()
    test_case_0()

# Generated at 2022-06-26 00:45:21.470558
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    import math


# Generated at 2022-06-26 00:46:21.749392
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert_equal(dcfc_act_365_a(start=datetime.date(1, 1, 1), asof=datetime.date(1, 1, 1), end=datetime.date(1, 1, 1)), 0.0)


# Generated at 2022-06-26 00:46:29.697371
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    start_0 = datetime.date(2007, 12, 28)
    start_1 = datetime.date(2007, 12, 28)
    start_2 = datetime.date(2007, 10, 31)
    start_3 = datetime.date(2008, 2, 1)
    asof_0 = datetime.date(2008, 2, 28)
    asof_1 = datetime.date(2008, 2, 29)
    asof_2 = datetime.date(2008, 11, 30)
    asof_3 = datetime.date(2009, 5, 31)
    end_0 = datetime.date(2008, 2, 28)
    end_1 = datetime.date(2008, 2, 29)
    end_2 = datetime.date(2008, 11, 30)

# Generated at 2022-06-26 00:46:38.334384
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)    
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-26 00:46:47.366552
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    str_0 = '\n        Initializes the registry.\n        '
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    optional_0 = d_c_c_registry_machinery_0.find(str_0)
    str_1 = '\n        Calculates the accrued interest for the coupon payment.\n\n        This method is primarily used for bond coupon accruals which assumes the start date to be the first of regular\n        payment schedules.\n        '
    d_c_c_registry_machinery_1 = DCCRegistryMachinery()
    optional_1 = d_c_c_registry_machinery_1.find(str_1)
    str_2 = '\n        Returns the last coupon payment date.\n        '


# Generated at 2022-06-26 00:46:54.012890
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-26 00:47:02.278497
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-26 00:47:12.551750
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    str_0 = '\n        Initializes the registry.\n        '
    ex_0_start = datetime.date(2007, 12, 28)
    d_c_c_0 = DCC(str_0, set(), set(), dcfc_act_act)
    ex_0_asof = datetime.date(2008, 2, 28)
    optional_0 = d_c_c_0.interest(Decimal(1000000), Decimal(0.01), ex_0_start, ex_0_asof, ex_0_asof)
    test_case_0()


# Generated at 2022-06-26 00:47:17.008516
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    x = datetime.date(2007, 12, 28)
    y = datetime.date(2007, 12, 28)
    z = datetime.date(2007, 12, 28)
    slow_start = x
    slow_asof = y
    slow_end = z
    assert round(dcfc_nl_365(slow_start, slow_asof, slow_end), 14) == Decimal('0.16986301369863')


# Generated at 2022-06-26 00:47:23.124652
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)
    d = round(dcfc_act_365_l(start, asof, end), 14)
    
    assert round(dcfc_act_365_l(start, asof, end), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start, asof, end), 14) == round(dcfc_act_365_l(start, asof, end), 14)

# Generated at 2022-06-26 00:47:30.388407
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    str_0 = 'Act/Act (ICMA)'
    default_0 = 'Actual/Actual (ICMA)'
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    d_c_c_registry_machinery_0_0 = d_c_c_registry_machinery_0.find(str_0)
    d_c_c_registry_machinery_0_1 = d_c_c_registry_machinery_0.find(default_0)
    d_c_c_registry_machinery_0_2 = d_c_c_registry_machinery_0.find(str_0)
    d_c_c_registry_machinery_0_3 = d_c_c_reg

# Generated at 2022-06-26 00:49:36.562645
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # test callable
    assert callable(dcfc_30_360_isda)
    # test returning value.
    #assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

test_case_0()

# Generated at 2022-06-26 00:49:41.202895
# Unit test for method interest of class DCC
def test_DCC_interest():
    principal = Money(123.0, 'CAD')
    rate = 0.5
    start = Date(1,1,1)
    asof = Date(2,2,2)
    end = Optional[Date] = Date(3,3,3)
    freq = Optional[Decimal] = 0.5
    d_c_c_1 = DCC(name='', altnames='', currencies='', calculate_fraction_method=0.4)
    optional_0 = d_c_c_1.interest(principal, rate, start, asof, end, freq)


# Generated at 2022-06-26 00:49:46.779480
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    start_0 = datetime.date(int_0, int_0, int_0)
    asof_0 = datetime.date(int_0, int_0, int_0)
    end_0 = datetime.date(int_0, int_0, int_0)
    bool_0 = bool
    if bool_0:
        str_0 = '\n        Initializes the registry.\n        '
        d_c_c_registry_machinery_0 = DCCRegistryMachinery()
        optional_0 = d_c_c_registry_machinery_0.find(str_0)

# Generated at 2022-06-26 00:49:50.396218
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    print('Testing method calculate_daily_fraction of class DCC')
    d_c_c_registry_machinery_0 = DCCRegistryMachinery()
    arguments_0 = [DCCRegistryMachinery()]
    d_c_c_registry_machinery_0.assert_method_is_not_implemented('DCC', 'calculate_daily_fraction', arguments_0)
    return


# Generated at 2022-06-26 00:50:02.128354
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_360_us

# Generated at 2022-06-26 00:50:11.161014
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    print("Start of unit test for the method calculate_daily_fraction of class DCC")

    # ------------------------------------------------------------------------------------------------------------------
    # Test case 1
    print("\nTest case 1: ")
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 2)
    freq = None

    d_c_c_0 = DCC("0_0", set(['0_2']), Currencies.EUR, _actual_365_or_366_day_count)

    assert d_c_c_0.calculate_daily_fraction(start, asof, end, freq) == ZERO

    # ------------------------------------------------------------------------------------------------------------------
    # Test case 2
    print("\nTest case 2: ")


# Generated at 2022-06-26 00:50:17.252393
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    print('Testing coupon()')
    currency_0 = Currencies['USD']
    money_0 = Money.parse('$1', currency_0)
    DCCRegistry_0 = DCCRegistry()
    d_c_c_0 = DCCRegistry_0['ACT/360']
    float_0 = 1
    int_0 = 2
    float_1 = 3
    float_2 = 4
    int_1 = 5
    d_c_c_0.coupon(money_0, float_0, int_0, float_1, float_2, int_1)



# Generated at 2022-06-26 00:50:23.175564
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # Test with day=31
    start_1 = datetime.date(2018, 3, 31)
    asof_1 = datetime.date(2018, 4, 30)
    dcfc_30_360_german(start=start_1, asof=asof_1, end=asof_1)

    # Test with day=30 and asof=last day of month
    start_2 = datetime.date(2018, 3, 30)
    asof_2 = datetime.date(2018, 4, 30)
    dcfc_30_360_german(start=start_2, asof=asof_2, end=asof_2)

    # Test with day=31 and asof=last day of month
    start_3 = datetime.date(2018, 3, 31)
    asof_

# Generated at 2022-06-26 00:50:28.049232
# Unit test for method interest of class DCC
def test_DCC_interest():
    Money_0 = Money()
    start_0 = Date()
    asof_0 = Date()
    end_0 = Date()
    DCC_0 = DCC(str_0, set_0, set_0, DCC_calculate_fraction_method_0)
    principal_0 = Money_0
    freq_0 = Decimal()
    rate_0 = Decimal()
    end_1 = end_0
    d_c_c_interest_args_0 = Money_0, Decimal(), Date(), Date(), end_1, None
    Money_1 = DCC_0.interest(*d_c_c_interest_args_0)
    assert Money_1 is Money_0


# Generated at 2022-06-26 00:50:36.372027
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    # Test case from a known case
    result = dcfc_nl_365(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 28), end = datetime.date(2008, 2, 28), freq = None)
    expected_results = 0.16986301369863
    assert abs(result - expected_results) < 1e-6

    result = dcfc_nl_365(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 29), end = datetime.date(2008, 2, 29), freq = None)
    expected_results = 0.16986301369863
    assert abs(result - expected_results) < 1e-6
