

# Generated at 2022-06-12 06:10:52.506750
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Test for method calculate_fraction of class DCC
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 2)
    freq = None
    expected = Decimal('1')
    act = ACT360.calculate_fraction(start, asof, end, freq)
    assert act == expected, '{0} != {1}'.format(act, expected)




# Generated at 2022-06-12 06:11:03.192884
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    start = datetime.date(2017, 8, 20)
    asof = datetime.date(2017, 8, 21)
    end = datetime.date(2017, 8, 21)
    freq = None
    _calculate_daily_fraction = DCCRegistry["act/act afb"].calculate_daily_fraction
    _calculate_daily_fraction(start, asof, end, freq)


floating = "floating"
fixed = "fixed"

#: Defines a dictionary of all known day count convention models.

# Generated at 2022-06-12 06:11:16.008397
# Unit test for method register of class DCCRegistryMachinery

# Generated at 2022-06-12 06:11:20.852134
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Unit test for function dcfc_30_e_360
    """
    assert round(dcfc_30_e_360(start=datetime.date(2019,2,28), asof=datetime.date(2019,3,31), freq=Decimal(1)),14)==Decimal('0.08333333333333')


# Generated at 2022-06-12 06:11:25.138684
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(start=datetime.date(2020, 1, 31), asof=datetime.date(2020, 2, 28), end=None, freq=None) == 0.033333333333333
    assert dcfc_30_e_plus_360(start=datetime.date(2020, 1, 31), asof=datetime.date(2020, 2, 29), end=None, freq=None) == 0.033333333333333
    assert dcfc_30_e_plus_360(start=datetime.date(2020, 1, 31), asof=datetime.date(2020, 3, 31), end=None, freq=None) == 0.13333333333333

# Generated at 2022-06-12 06:11:29.851405
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert (round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863'))
    assert (round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863'))

# Generated at 2022-06-12 06:11:41.245248
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ## Create the unit test data (as a list of tuples):
    utd = [
        (datetime.date(2006, 12, 31), datetime.date(2007, 1, 31), datetime.date(2007, 12, 31), 1.08333333333333),
        (datetime.date(2006, 12, 31), datetime.date(2007, 3, 31), datetime.date(2007, 12, 31), 0.91666666666667),
        (datetime.date(2007, 1, 31), datetime.date(2007, 3, 31), datetime.date(2007, 4, 30), 0.83333333333333),
        (datetime.date(2007, 1, 31), datetime.date(2007, 3, 31), datetime.date(2007, 12, 31), 1.66666666666667)
    ]

# Generated at 2022-06-12 06:11:46.225169
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Testing doc string
    """
    test_object = DCC(
        name="",
        altnames={},
        currencies={},
        calculate_fraction_method=lambda a, b, c, d: 0
    )
    assert test_object.calculate_fraction(datetime.date(2001, 1, 2), datetime.date(2001, 1, 3), datetime.date(2001, 1, 4)) == Decimal('0')


# Generated at 2022-06-12 06:11:59.676359
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(start=Date(1, 1, 2018), asof=Date(1, 2, 2018), end=Date(31, 1, 2018)) == 0.08333333333333333
    assert dcfc_30_360_us(start=Date(1, 4, 2018), asof=Date(30, 4, 2018), end=Date(30, 4, 2018)) == 0.08333333333333333
    assert dcfc_30_360_us(start=Date(1, 3, 2018), asof=Date(31, 3, 2018), end=Date(31, 3, 2018)) == 0.08333333333333333
    assert dcfc_30_360_us(start=Date(1, 2, 2018), asof=Date(28, 2, 2018), end=Date(28, 2, 2018))

# Generated at 2022-06-12 06:12:08.498015
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert(round(dcfc_act_act(start = datetime.date(2007, 12, 28), \
        asof = datetime.date(2008, 2, 28), end = datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478'))
    assert(round(dcfc_act_act(start = datetime.date(2007, 12, 28), \
        asof = datetime.date(2008, 2, 29), end = datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194'))

# Generated at 2022-06-12 06:12:53.592390
# Unit test for method interest of class DCC
def test_DCC_interest():
    """
    Tests the method interest of class DCC.
    """
    ## Construct a DCC:
    dcc = DCC("Actual/actual", set(), set(), calculate_actual_actual_fraction)

    ## Construct a currency and principal:
    currency = Currencies["USD"]
    principal = 100.0 * currency

    ## Calculate the interest:
    interest = dcc.interest(principal, Decimal("0.05"), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1))
    assert interest == 0

    interest = dcc.interest(principal, Decimal("0.05"), datetime.date(2014, 1, 1), datetime.date(2014, 1, 2))
    assert interest == 0.05


# Generated at 2022-06-12 06:13:06.277001
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    '''
    This is testing the day count fraction calculation for 30/360_us
    '''
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-12 06:13:14.464920
# Unit test for method interest of class DCC
def test_DCC_interest():
    from dateutil.relativedelta import relativedelta
    from datetime import datetime
    from decimal import Decimal
    from finlib.currencies import Currencies
    from finlib.monetary import Money
    from finlib.dcc import DCC, DCCRegistry

    assert isinstance(DCCRegistry['afb'], DCC)
    assert isinstance(DCC("Actual/Actual (ISDA)", {"Actual/Actual", "Actual/365", "Actual/Actual (AFB)"}, set(), lambda a,b,c,d: Decimal("0.0")), DCC)

    assert DCCRegistry['afb'].interest(Money("10.00", Currencies['USD']), Decimal("0.05"), datetime.today(), datetime.today() + relativedelta(days=5))

# Generated at 2022-06-12 06:13:20.466069
# Unit test for function dcfc_30_360_isda

# Generated at 2022-06-12 06:13:33.025435
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(datetime.date(2015, 3, 1), datetime.date(2015, 3, 1), datetime.date(2015, 3, 3)) == 0.0833333333333333
    assert dcfc_30_360_us(datetime.date(2015, 2, 27), datetime.date(2015, 3, 1), datetime.date(2015, 3, 3)) == 0.0833333333333333
    assert dcfc_30_360_us(datetime.date(2015, 2, 28), datetime.date(2015, 3, 1), datetime.date(2015, 3, 3)) == 0.0833333333333333

# Generated at 2022-06-12 06:13:45.573907
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .calendars import WesternCalendar
    from .currencies import Currency
    from .currencies import Currencies
    from .enums import DayCount

    currency=Currencies.USD
    rate=Decimal('0.01')
    start=datetime.date(2020,5,1)
    end=datetime.date(2020,8,1)
    asof=datetime.date(2020,8,1)
    principal=Money(100,currency)

    calendar=WesternCalendar(currency)
    daycountconvention=DCCRegistry.get(DayCount.ACTUAL365_FIXED,currency)
    actual=daycountconvention.calculate_daily_fraction(start,asof,end)
    actual_interest=principal*actual*rate

# Generated at 2022-06-12 06:13:54.226044
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    import datetime
    from decimal import Decimal
    from finmath.currencies import Currencies
    from finmath.monetary import Money

    ## Define the start, asof and end dates
    start_date = datetime.date(2016, 1, 1)
    asof_date = datetime.date(2016, 1, 15)
    end_date = datetime.date(2016, 1, 31)

    ## Create a money object
    principal = Money(Decimal("100000.00"), Currencies.USD)

    ## Create a DCC object
    dcc = DCC("act/360", {}, {}, lambda start, asof, end, freq: (end - asof).days / 360.0)

    ## Calculate the interest

# Generated at 2022-06-12 06:14:05.891557
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')


# Generated at 2022-06-12 06:14:11.310616
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc = DCC(name='ACT360', currencies={}, altnames=None, calculate_fraction_method=lambda start, asof, end, freq: ONE)
    return dcc.calculate_daily_fraction(datetime.date(2016, 1, 1),datetime.date(2016, 1, 1),datetime.date(2016, 1, 1), None)



# Generated at 2022-06-12 06:14:21.475550
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    #assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    #assert round(d

# Generated at 2022-06-12 06:16:41.972689
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-12 06:16:51.439946
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    for d in [datetime.date(2010,3,1), datetime.date(2010,3,31), datetime.date(2010,5,1)]:
        assert round(dcfc_30_360_isda(datetime.date(2010,2,26),d,d),12) == Decimal('0.0250000000')
    for d in [datetime.date(2010,3,1), datetime.date(2010,3,31), datetime.date(2010,5,1)]:
        assert round(dcfc_30_360_isda(datetime.date(2010,3,1),d,d),12) == Decimal('0.0333333333')

# Generated at 2022-06-12 06:17:03.147184
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Unit test function for function dcfc_30_360_us.

    :return: None
    """
    # Data required:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    # Test:

# Generated at 2022-06-12 06:17:10.995681
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    The dcfc_30_360_us function unit test.
    """
    assert round(dcfc_30_360_us(
        start=datetime.date(2018, 12, 28),
        asof=datetime.date(2019, 2, 28),
        end=datetime.date(2019, 2, 28)
    ), 14) == Decimal('0.16666666666667')

    assert round(dcfc_30_360_us(
        start=datetime.date(2018, 12, 28),
        asof=datetime.date(2019, 2, 29),
        end=datetime.date(2019, 2, 29)
    ), 14) == Decimal('0.16944444444444')


# Generated at 2022-06-12 06:17:23.865574
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert(DCCRegistry.get_dcc('act/360').coupon(Money(1000, 'EUR'), 0.05, Date(2014,  1,  1), Date(2015,  2, 16), Date(2015,  2, 16), 2) == Money(8.333333333333333333333333, 'EUR'))
    assert(DCCRegistry.get_dcc('act/360').coupon(Money(1000, 'EUR'), 0.05, Date(2014,  1,  1), Date(2015,  2, 16), Date(2015,  1,  1), 2) == Money(8.333333333333333333333333, 'EUR'))

# Generated at 2022-06-12 06:17:35.900672
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Unit test for function dcfc_act_act.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-12 06:17:47.804269
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-12 06:17:59.108398
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert dcfc_act_365_l(datetime.date(2007,12,28), datetime.date(2008,2,28), datetime.date(2008,2,28)) == Decimal('0.16939890710383')
    assert dcfc_act_365_l(datetime.date(2007,12,28), datetime.date(2008,2,29), datetime.date(2008,2,29)) == Decimal('0.17213114754098')
    assert dcfc_act_365_l(datetime.date(2007,10,31), datetime.date(2008,11,30), datetime.date(2008,11,30)) == Decimal('1.08196721311475')

# Generated at 2022-06-12 06:18:10.141436
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    print("Testing the function dcfc_nl_365...", end="")
    assert dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16986301369863')
    assert dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.16986301369863')
    assert dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08219178082192')
    assert dcfc_nl

# Generated at 2022-06-12 06:18:22.760078
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    print('Testing function dcfc_30_e_360:')
    assert round(dcfc_30_e_360(datetime.date(2007, 1, 31), datetime.date(2007, 2, 28), datetime.date(2007, 2, 28))) == 0.08333333333333
    assert round(dcfc_30_e_360(datetime.date(2007, 1, 31), datetime.date(2007, 2, 28), datetime.date(2007, 2, 28), freq=Decimal(2))) == 0.08333333333333
    assert round(dcfc_30_e_360(datetime.date(2007, 2, 28), datetime.date(2007, 3, 31), datetime.date(2007, 3, 31))) == 0.08333333333333