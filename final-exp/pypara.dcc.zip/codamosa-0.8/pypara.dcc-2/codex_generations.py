

# Generated at 2022-06-12 06:10:52.587309
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """
    Test function dcfc_act_act_icma
    """
    start = datetime.date(2019, 3, 2)
    asof = datetime.date(2019, 9, 10)
    end = datetime.date(2020, 3, 2)
    freq = 2
    actual = dcfc_act_act_icma(start, asof, end, freq)
    expected = 0.52459016393442624
    assert round(actual, 5) == expected
    print("Test function dcfc_act_act_icma: passed")



# Generated at 2022-06-12 06:10:55.971751
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    # Test example 1
    assert dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)) == Decimal('0.5245901639')


# Generated at 2022-06-12 06:11:06.489275
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)== Decimal('0.16942884946478')

# Generated at 2022-06-12 06:11:18.975214
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)
    dcc = DCCRegistry.find("Act/Act")
    assert round(dcc.calculate_fraction(start, end, end), 14) == Decimal('0.16942884946478')
    assert dcc.interest(principal, rate, start, end, end).qty == Decimal('1694.29')
    assert dcc.interest(principal, rate, end, start, start).qty == Decimal('0.00')
test_DCCRegistryMachinery_find()



# Generated at 2022-06-12 06:11:27.345603
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == round(Decimal('0.16666666666667'), 14)
    assert round

# Generated at 2022-06-12 06:11:31.059564
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    test_result = dcfc_act_365_l(datetime.date(2017, 9, 1), datetime.date(2018, 8, 31), datetime.date(2020, 9, 1))
    print(round(test_result, 6))
test_dcfc_act_365_l()


# Generated at 2022-06-12 06:11:41.876668
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-12 06:11:52.148261
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    from dcc import DCCRegistry, DCC
    import dcc.constants as constants
    import dcc.methods as methods
    import datetime

    ## Prepare expected values:
    ## 30/360 ISMA

# Generated at 2022-06-12 06:11:56.702322
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Unit test for function dcfc_act_act
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-12 06:12:07.065857
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    """
    This unit test verifies the correctness of dcfc_act_365_a function
    """
    # 1st example
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_dcf = dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof)
    assert round(ex1_dcf, 14) == Decimal('0.16986301369863')
    print('dcfc_act_365_a function is working fine, 1st example.')
    # 2nd example
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-12 06:12:36.113014
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    
    start = Date(2020,8,1)
    end = Date(2020,8,31)
    asof = Date(2020,8,12)

    dcc = DCC("ACT/ACT", {"ACT/ACT"}, {"USD"}, DAY_COUNT_FRACTION_ACTUAL_ACTUAL)

    assert dcc.calculate_daily_fraction(start, asof, end) == Decimal("0.096774193548387")
    assert dcc.calculate_daily_fraction(start, asof, end, 2) == Decimal("0.096774193548387")
    
    
    
    
    
    
    
    
    
    



# Generated at 2022-06-12 06:12:43.583562
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(datetime.date(2019, 2, 28), datetime.date(2019, 3, 31), datetime.date(2019, 3, 31)) == Decimal('0.08333333333333')
    assert dcfc_30_e_plus_360(datetime.date(2019, 1, 31), datetime.date(2019, 2, 28), datetime.date(2019, 2, 28)) == Decimal('0.08333333333333')
    assert dcfc_30_e_plus_360(datetime.date(2019, 5, 31), datetime.date(2019, 7, 31), datetime.date(2019, 7, 31)) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:12:56.368702
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:13:08.900924
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:13:15.945997
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-12 06:13:28.865007
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:13:41.138725
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    This method is used to test calculate_daily_fraction of class DCC
    """

# Generated at 2022-06-12 06:13:49.456430
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    dec_equal(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof),
        Decimal('0.16666666666667'))

# Generated at 2022-06-12 06:13:50.180481
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    pass



# Generated at 2022-06-12 06:14:02.457046
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert dcfc_act_365_l(datetime.date(2007, 3, 30), datetime.date(2007, 4, 2), datetime.date(2007, 4, 2)) == Decimal("0.0082191780821918")
    assert dcfc_act_365_l(datetime.date(2008, 3, 30), datetime.date(2008, 4, 2), datetime.date(2008, 4, 2)) == Decimal("0.0082191780821918")
    assert dcfc_act_365_l(datetime.date(2006, 10, 24), datetime.date(2007, 10, 24), datetime.date(2007, 10, 24)) == Decimal("1.00000000000000")

# Generated at 2022-06-12 06:15:03.032950
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(
        dcc_30_e_360('2012-12-31', '2013-12-31'),
        14
    ) == Decimal('1.08333333333333')


# Generated at 2022-06-12 06:15:14.920265
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,28), end=datetime.date(2008,2,28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007,12,28), asof=datetime.date(2008,2,29), end=datetime.date(2008,2,29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-12 06:15:23.632272
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC(
        name='ACT/360',
        altnames=["ACT/360", "30/360", "EU", "30U/360", "ACT/360", "BMA"],
        currencies=_as_ccys(['USD', 'EUR']),
        calculate_fraction_method=DCCRegistry.get_method("ACT/360")
    ).coupon(Money(1000000, 'USD'), 0.025, datetime.date(2014, 1, 1), datetime.date(2014, 7, 1), datetime.date(2014, 7, 20), Decimal(2)) == Money(4375, 'USD')



# Generated at 2022-06-12 06:15:30.358679
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_act_act(start, asof, asof), 14) == Decimal("0.16942884946478")



# Generated at 2022-06-12 06:15:42.450266
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    ex3_start = datetime.date(2007, 10, 31)
    ex3_asof = datetime.date(2008, 11, 30)
    ex4_start = datetime.date(2008, 2, 1)
    ex4_asof = datetime.date(2009, 5, 31)

# Generated at 2022-06-12 06:15:51.683794
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:16:03.590467
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print("Example 1: ", round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14))

# Generated at 2022-06-12 06:16:15.559855
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_360_us(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-12 06:16:17.712267
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Unit test for method calculate_fraction of class DCC

    """
    pass



# Generated at 2022-06-12 06:16:28.885873
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    ## Get EUR
    eur = Currency.EUR

    ## Get EUR-30/360
    dcc = DCCRegistry.get_dcc(name="EUR-30/360", currency=eur)

    ## Start and end
    start = Date.us_parse("11/7/2017")
    end = Date.us_parse("11/7/2018")

    ## Date with increment
    for i in range(1, 400):
        date = start + datetime.timedelta(days=i)
        ## Perform calculation
        daily_fraction = dcc.calculate_daily_fraction(start=start, asof=date, end=end, freq=Decimal(12))
        ## Convert daily fraction to monetary value
        interest = Money.usd(1000.0) * daily_fraction
        ## Print out

# Generated at 2022-06-12 06:18:27.442164
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from datetime import date
    from numbers import Number
    from .monetary import Money
    from .currencies import Currencies, Currency
    from .dccs import DCCs, DCC


# Generated at 2022-06-12 06:18:37.248799
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Tests the day count fraction calculator for `Act/Act`.
    """
    ## Define the test data:
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_act_act(start, asof, asof), 14) == Decimal("0.16942884946478")
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_act_act(start, asof, asof), 14) == Decimal("0.17216108990194")
    start, asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)

# Generated at 2022-06-12 06:18:49.113650
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-12 06:18:54.456335
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(0.16986301369863, 14) == round(dcfc_nl_365(datetime.date(2007,12,28), datetime.date(2008,2,28), datetime.date(2008,2,28)), 14)
    assert round(0.16986301369863, 14) == round(dcfc_nl_365(datetime.date(2007,12,28), datetime.date(2008,2,29), datetime.date(2008,2,28)), 14)
    assert round(1.08219178082192, 14) == round(dcfc_nl_365(datetime.date(2007,10,31), datetime.date(2008,11,30), datetime.date(2008,11,30)), 14)

# Generated at 2022-06-12 06:19:05.222128
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """

    from .currencies import AED_Currencies_Currencies, AED_Currencies_Currency, JPY_Currencies_Currencies, JPY_Currencies_Currency
    from .monetary import AED_Monetary_Money, JPY_Monetary_Money


# Generated at 2022-06-12 06:19:16.485368
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .currencies import Currencies
    from .monetary import Money
    from .schedule import Schedule
    from .schedule import ScheduleBuilder
    from .schedule.exceptions import ScheduleError
    from .schedule.functions import end_of_month

    start = datetime.date(2016, 1, 2)
    end = datetime.date(2017, 1, 2)
    sch = ScheduleBuilder(start, end, '1m', end_of_month(), True)
    dates = sch.build()
    asof = datetime.date(2016,3,2)


# Generated at 2022-06-12 06:19:17.264834
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 06:19:19.156912
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act


# Generated at 2022-06-12 06:19:26.288066
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # Example 1
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof),14) == 1.33333333333333

    # Example 2
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_30_e_360(start=ex2_start, asof=ex2_asof, end=ex2_asof),14) == 1.33055555555556

    # Example 3
    ex3_start, ex3_asof = datetime.date

# Generated at 2022-06-12 06:19:28.371258
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    dcc_tests(dcfc_30_360_isda, "30/360 ISDA")