

# Generated at 2022-06-12 06:10:56.957723
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    try:
        from nose.tools import assert_almost_equal
    except ImportError:
        from nose2.tools import assert_almost_equal
    a = dcfc_30_e_360(datetime.date(2000, 1, 1), datetime.date(2000, 1, 1), datetime.date(2000, 1, 1), freq=None)
    assert_almost_equal(a, 0.0)
    b = dcfc_30_e_360(datetime.date(2000, 1, 1), datetime.date(2000, 1, 2), datetime.date(2000, 1, 1), freq=None)
    assert_almost_equal(b, 0.0027777777777777776)

# Generated at 2022-06-12 06:11:02.259185
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 28), end = datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start = datetime.date(2007, 12, 28), asof = datetime.date(2008, 2, 29), end = datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start = datetime.date(2007, 10, 31), asof = datetime.date(2008, 11, 30), end = datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:11:07.058242
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:11:14.583450
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    """
    Test for function dcfc_nl_365()
    """
    # Test cases from http://www.isda.org/c_and_a/pdf/ISDA-SIMM-v1.6.pdf, p.58
    assert dcfc_nl_365(datetime.date(1500,1,1),datetime.date(1501,1,1),datetime.date(1501,1,1),None) == 1
    # Test cases from http://www.isda.org/c_and_a/pdf/ISDA-SIMM-v1.6.pdf, p.60
    assert dcfc_nl_365(datetime.date(2000,1,1),datetime.date(2001,1,1),datetime.date(2001,1,1),None) == 1
    # Test cases

# Generated at 2022-06-12 06:11:25.557830
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(rnd(dcfc_act_365_a(datetime.date(2007,12,28), datetime.date(2008,2,28), datetime.date(2008,2,28))), 14) == Decimal('0.16986301369863')
    assert round(rnd(dcfc_act_365_a(datetime.date(2007,12,28), datetime.date(2008,2,29), datetime.date(2008,2,29))), 14) == Decimal('0.17213114754098')

# Generated at 2022-06-12 06:11:34.762317
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC("12/365", ["12/365", "12/366"], _as_ccys({"AEU", "USA"}), _actual_365)
    start = Date(2011, 1, 1)
    asof = Date(2012, 1, 1)
    end = Date(2012, 1, 31)
    freq = Decimal(2)
    frac_actual = dcc.calculate_fraction(start, asof, end, freq)
    frac_expected = ONE
    assert frac_expected == frac_actual

# Generated at 2022-06-12 06:11:37.153092
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    # This function requires a unit test function.
    pass



# Generated at 2022-06-12 06:11:41.549348
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:11:52.196277
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    start2019, asof2019 = datetime.date(2019, 2, 15), datetime.date(2019, 2, 15)
    start2018, asof2018 = datetime.date(2018, 2, 28), datetime.date(2018, 6, 1)
    start2017, asof2017 = datetime.date(2017, 3, 31), datetime.date(2017, 6, 1)
    start2016, asof2016 = datetime.date(2016, 3, 31), datetime.date(2016, 2, 29)
    assert dcfc_30_360_isda(start=start2019, asof=asof2019, end=asof2019) == Decimal(0)

# Generated at 2022-06-12 06:12:04.042106
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    # Test the function dcfc_30_e_plus_360
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-12 06:12:42.408224
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Test the function dcfc_30_360_us.
    """
    ## Example 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    ## Example 2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-12 06:12:46.883189
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')


# Generated at 2022-06-12 06:12:53.072665
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=2), 10) == Decimal('0.2622950820')
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 4, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=2), 10) == Decimal('0.2622950820')

# Generated at 2022-06-12 06:13:05.983111
# Unit test for function dcfc_30_e_360

# Generated at 2022-06-12 06:13:14.213204
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    return
    # ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    # ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    # ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    # ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    _test_dcfc_30_e_360_one(ex1_start, ex1_asof, Decimal('0.16666666666667'))
    _test_dcfc_30_e_360

# Generated at 2022-06-12 06:13:18.200751
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    date1 = datetime.date(2019,11,14)
    date2 = datetime.date(2020,11,14)
    assert (round(dcfc_30_e_plus_360(start=date1, asof=date2, end=date2),14) == Decimal('1.00000000000000'))
    print('test_dcfc_30_e_plus_360 passed')


# Generated at 2022-06-12 06:13:22.827688
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_30_360_isda(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-12 06:13:26.991126
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-12 06:13:35.512839
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from .iconverters import MoneyConverter
    from .icurves import DiscountCurve, InterestRate
    from .currencies import USD

    principal = MoneyConverter.convert(10e3, USD, None)
    rate = InterestRate(Decimal("0.05"))
    start = Date(2014, 12, 31)
    asof = Date(2015, 11, 17)
    freq = Decimal(2)

    dcc = DCCRegistry.get("ACT/365")
    res = dcc.coupon(principal, rate.rate, start, asof, None, freq)
    tgt = Money(159.32, USD)
    assert res == tgt

    asof = Date(2015, 1, 1)

# Generated at 2022-06-12 06:13:46.756218
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(
        start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')

    assert round(dcfc_30_360_us(
        start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')


# Generated at 2022-06-12 06:15:02.670105
# Unit test for function dcfc_30_360_us

# Generated at 2022-06-12 06:15:14.476140
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    date1 = Date(2017, 1, 15)
    date2 = Date(2017, 1, 31)
    date3 = Date(2017, 7, 31)
    date4 = Date(2017, 8, 7)
    date5 = Date(2017, 9, 1)
    date6 = Date(2018, 1, 31)
    date7 = Date(2018, 2, 1)
    date8 = Date(2018, 7, 31)
    date9 = Date(2018, 8, 1)
    date10 = Date(2018,9,1)
    date11 = Date(2018,11,10)
    date12 = Date(2019,1,1)
    date13 = Date(2019,7,31)
    date14 = Date(2019,8,1)
    date15 = Date(2019,9,1)

# Generated at 2022-06-12 06:15:25.004555
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .currencies import Currencies
    from .monetary import Money
    from .commons.datetime import parse_date
    from .exchanges import ExchangeResolver, ExchangeRate, DailyExchangeRatesTable
    from .exchanges import EphemeralExchangeRatesTable
    from .exchanges import CurrencyExchangeRatesTable
    from .exchanges import GoogleExchangeRatesTable
    from .exchanges import EodExchangeRatesTable
    from .exchanges import YahooExchangeRatesTable
    from .exchanges import EuropeanCentralBankExchangeRatesTable
    from .exchanges import BankOfIsraelExchangeRatesTable
    from .exchanges import BankOfTaiwanExchangeRatesTable
    from .exchanges import BankOfCanadaExchangeRatesTable
    from .exchanges import BancoDeMexicoExchangeRatesTable

# Generated at 2022-06-12 06:15:36.362950
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    """
    Test actuarial day counter.
    """
    # pylint: disable=unused-argument

# Generated at 2022-06-12 06:15:48.024314
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():

    ## Test 1:
    dcc = DCC("CACT", {"ACT/360"}, {}, lambda s, a, e, f: ONE / 360)
    print("DCC : " + str(dcc.calculate_daily_fraction(Date(2014, 4, 1), Date(2014, 4, 1), Date(2014, 7, 1))))  # 0.002777777777777778

    ## Test 2:
    dcc = DCC("ACT/360", {"CACT"}, {}, lambda s, a, e, f: ONE / 360)
    print("DCC : " + str(dcc.calculate_daily_fraction(Date(2014, 4, 1), Date(2014, 4, 1), Date(2014, 7, 1))))  # 0.002777777777777778


# Generated at 2022-06-12 06:15:53.476008
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ## Prepare the test data:
    ex1_start, ex1_asof, ex1_end = datetime.date(2007, 12, 31), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)
    ex2_start, ex2_asof, ex2_end = datetime.date(2008, 1, 31), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof, ex3_end = datetime.date(2008, 1, 30), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)

# Generated at 2022-06-12 06:15:54.720908
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    raise NotImplementedError()


# CLASSES #####################################################################



# Generated at 2022-06-12 06:16:03.491565
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    test(Decimal('0.16986301369863'), dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-12 06:16:15.375351
# Unit test for function dcfc_30_e_plus_360

# Generated at 2022-06-12 06:16:26.161493
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .currencies import Currencies as Currs
    from .monetary import Money as M

    DCC = DCC.calculate_fraction


# Generated at 2022-06-12 06:17:03.448893
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 1, 28), datetime.date(2008, 2, 28)) == Decimal('0.02739726')
    assert dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.07671233')
    assert dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 3, 28)) == Decimal('0.10389610')

# Generated at 2022-06-12 06:17:11.207558
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    def calculate_fraction_method(start, asof, end, freq):
        if asof < end and asof > start:
            return (asof - start).days / (end - start).days
        elif asof == end:
            return Decimal(1.0)
        else:
            return Decimal(0.0)
    dcc = DCC('temp', {'dummy'}, {}, calculate_fraction_method)
    dcc.calculate_daily_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 3, 31), None)

# Generated at 2022-06-12 06:17:19.922901
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    """
    Unit-test for function dcfc_30_e_plus_360.
    """
    assert round(dcfc_30_e_plus_360(start=datetime.date(2019, 10, 10), asof=datetime.date(2019, 10, 31), end=datetime.date(2019, 11, 1)), 14) == Decimal(0.055555555555556)



# Generated at 2022-06-12 06:17:22.961113
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    today = datetime.date.today()
    dcc = DCC(
        name='Actual/Actual (ISMA)',
        altnames=('Actual/Actual (ISMA)',),
        currencies=('XTS',),
        calculate_fraction_method=DCF_ACTUAL_ACTUAL_ISMA
    )
    dcc.calculate_fraction(today, today, today) == ZERO
    return True


# Generated at 2022-06-12 06:17:35.141807
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667'))

# Generated at 2022-06-12 06:17:43.093406
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    import unittest, datetime
    cls = unittest.TestCase()
    p = datetime.date(2020, 1, 1)
    a = datetime.date(2020, 1, 2)
    e = datetime.date(2020, 1, 1)
    f = Decimal(1)
    cls.assertEqual(0, DCCActual360().calculate_daily_fraction(p, a, e, f))



# Generated at 2022-06-12 06:17:52.209344
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:17:54.897689
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCC("DCC","altnames","currencies", dc_method).interest(Money("1", "AUD"), Decimal('0.5'), datetime.date(2017, 1, 1), datetime.date(2017, 3, 1)) == Money("0.5", "AUD")
DCC_ALL_LIST = []

# Generated at 2022-06-12 06:18:05.356043
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .monetary import Money
    from .currencies import Currencies
    dcc = DCC(name='test', altnames=set(), currencies=set(), calculate_fraction_method=test_DCC_calculate_fraction)
    ccy = Currencies['USD']
    result = dcc.interest(Money(100, ccy), Decimal(0.5), datetime.date(2019,11,18), datetime.date(2019,11,18))
    assert result.amount == Decimal(100) * Decimal(0.5) * Decimal(1/365)

# Generated at 2022-06-12 06:18:13.234488
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    dates = (
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), 0.16942884946478),
        (datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), 0.17216108990194),
        (datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), 1.08243131970956),
        (datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), 1.32625945055768),
    )
    for start, asof, expected in dates:
        assert round(dcfc_act_act(start, asof, asof), 14) == round(expected, 14)



# Generated at 2022-06-12 06:19:22.995851
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    ## 0/2 = 0:
    assert DCCRegistry.get_dcc("ACT/365.FIXED").calculate_daily_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 3)) == Decimal("0")

    ## 1/1 = 1:
    assert DCCRegistry.get_dcc("ACT/365.FIXED").calculate_daily_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 3)) == ONE

    ## 1/2 = 0.5:

# Generated at 2022-06-12 06:19:35.146117
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    class TestDCCRegistryMachinery_register(unittest.TestCase):
        def test_simple(self):
            def f(x, y, z):
                return x + y + z

            dccReg = DCCRegistryMachinery()
            dccReg.register(DCC("Act/Act", {"act/act"}, {"USD"}, f))

            self.assertTrue("act/act" in dccReg.table)
            self.assertTrue("Act/Act" in dccReg.table)
            self.assertFalse("act/act/act" in dccReg.table)
            self.assertFalse("act" in dccReg.table)
            self.assertFalse("Act/Act/Act" in dccReg.table)
            self.assertFalse("Act" in dccReg.table)
            self.assertTrue

# Generated at 2022-06-12 06:19:46.131862
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_end = datetime.date(2008, 2, 29)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex2_end = datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex3_end = datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex4_end

# Generated at 2022-06-12 06:19:57.820295
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCCRegistry.instance["act/365bf"].interest(Money("100.0", "USD"), Decimal("0.05"), datetime.date(2017,12,31), datetime.date(2018,2,28)) == Money("0.8260273972602740", "USD") # tests method interest of class DCC, with arguments (Money(100.0, USD), Decimal('0.05'), datetime.date(2017,12,31), datetime.date(2018,2,28)), and returns Money(0.8260273972602740, USD)

# Generated at 2022-06-12 06:20:09.524832
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    """
    Test function dcfc_nl_365
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    ex1_start2, ex1_asof2, ex1_end2 = datetime.date(2008, 1, 31), datetime.date(2008, 2, 24),

# Generated at 2022-06-12 06:20:18.058665
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')