

# Generated at 2022-06-12 06:11:01.285360
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    today = datetime.date.today()
    tomorrow = today + datetime.timedelta(days = 1)
    assert dcfc_30_e_360(today, tomorrow) == 1 / 360


# Generated at 2022-06-12 06:11:13.579975
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    print(DCCRegistry.get_instance().get("ACT/360").coupon(
        Money(100, Currencies.EUR),
        Decimal("0.10"),
        datetime.date(2014, 1, 1),
        datetime.date(2014, 1, 2),
        datetime.date(2014, 1, 3),
        1,
    ))
    print(DCCRegistry.get_instance().get("ACT/360").coupon(
        Money(100, Currencies.EUR),
        Decimal("0.10"),
        datetime.date(2014, 1, 1),
        datetime.date(2014, 1, 5),
        datetime.date(2014, 1, 3),
        1,
    ))

# Generated at 2022-06-12 06:11:22.945132
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    start, asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    start, asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    nod = (asof.day - start.day) + 30 * (asof.month - start.month) + 360 * (asof.year - start.year)

# Generated at 2022-06-12 06:11:36.065705
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ## Example 1
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    ## Example 2
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    round(dcfc_30_360_isda(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.16944444444444')
    ## Example 3
    ex3_start, ex3

# Generated at 2022-06-12 06:11:40.502152
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    """
    The unit test for the Act/365A day count convention calculation.
    """
    #
    # First example
    #
    # Calculate the day count fraction for the example dates
    example1_start = datetime.date(2007, 12, 28)
    example1_asof = datetime.date(2008, 2, 28)
    example1_daycount_fraction = dcfc_act_365_a(start=example1_start, asof=example1_asof, end=example1_asof)
    # Assert the result is the expected one
    assert example1_daycount_fraction == pytest.approx(0.16986301369863)
    #
    # Second example
    #
    # Calculate the day count fraction for the example dates
    example2_start = datetime

# Generated at 2022-06-12 06:11:51.770467
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    t0 = datetime.date(2017, 1, 1)
    t1 = datetime.date(2017, 1, 1)
    t2 = datetime.date(2017, 1, 2)
    t3 = datetime.date(2017, 1, 30)
    t4 = datetime.date(2017, 2, 28)
    t5 = datetime.date(2017, 2, 29)
    t6 = datetime.date(2017, 3, 1)
    t7 = datetime.date(2017, 3, 31)
    t8 = datetime.date(2017, 4, 30)
    t9 = datetime.date(2017, 5, 31)
    t10 = datetime.date(2018, 2, 28)
    t11 = datetime.date(2018, 3, 1)

# Generated at 2022-06-12 06:12:03.731272
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:12:11.962148
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:12:24.688526
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    import unittest
    import random

    start_month = random.choice(range(1, 13))
    start_day = random.choice(range(1, 29))

    start = [datetime.date(2007, start_month, start_day), datetime.date(2008, start_month, start_day), datetime.date(2009, start_month, start_day)]
    asof = [datetime.date(2007, start_month, 30), datetime.date(2008, start_month, 30), datetime.date(2009, start_month, 30)]

    start_month == 2 and start_day > 28 and start.append(datetime.date(2008, start_month, start_day))

# Generated at 2022-06-12 06:12:32.369643
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:13:03.575717
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start_date = datetime.date(2019, 7, 1)
    asof_date = datetime.date(2019, 7, 10)
    end_date = datetime.date(2019, 8, 12)
    freq = 1
    dcc = DCC("EOM", set(), set(), _ACTUAL_ACTUAL_ISDAF)
    print(dcc.calculate_fraction(start_date, asof_date, end_date, freq))



# Generated at 2022-06-12 06:13:05.982001
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Unit test for method calculate_fraction of class DCC
    """
    raise NotImplementedError()

# Generated at 2022-06-12 06:13:10.766376
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==Decimal('0.16666666666667')

# Generated at 2022-06-12 06:13:13.681781
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    x = dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2))
    assert round(x, 10) == Decimal('0.5245901639')
    return None
test_dcfc_act_act_icma()



# Generated at 2022-06-12 06:13:19.336733
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from datetime import date
    cc = DCC("", {}, set(), lambda x, y, z, freq=None: x if y == date(2017, 9, 4) else ZERO)
    end = date(2017, 9, 5)
    x = cc.calculate_daily_fraction(date(2017, 9, 1), date(2017, 9, 4), end)
    assert x == 1
    x = cc.calculate_daily_fraction(date(2017, 9, 1), date(2017, 9, 5), end)
    assert x == 0
    x = cc.calculate_daily_fraction(date(2017, 9, 1), end, end)
    assert x == 0

# Generated at 2022-06-12 06:13:32.474144
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(dt.date(1999,10,30),dt.date(1999,12,31),dt.date(1999,12,31)),14) == round(Decimal(61)/Decimal(360),14)
    assert round(dcfc_30_e_360(dt.date(1999,10,31),dt.date(1999,12,31),dt.date(1999,12,31)),14) == round(Decimal(60)/Decimal(360),14)
    assert round(dcfc_30_e_360(dt.date(1999,10,30),dt.date(1999,12,30),dt.date(1999,12,30)),14) == round(Decimal(60)/Decimal(360),14)

# Generated at 2022-06-12 06:13:45.498194
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .monetary import Money

    from .currencies import Currencies

    from .markets import Markets

    mkt = Markets.get("EUR-LUX")

    eur = Currencies.get("EUR")

    ccy = Money(Decimal("100"), eur, mkt)

    sd = datetime.date(2016, 1, 15)

    ed = datetime.date(2016, 4, 15)

    asof = datetime.date(2016, 1, 16)

    freq = 1

    dcc = DCCRegistry.get("30E/360")

    dcf = dcc.calculate_fraction(sd, asof, ed, freq)

    interest = ccy * Decimal("0.01") * dcf


# Generated at 2022-06-12 06:13:56.132952
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find(): 
    dccm = DCCRegistryMachinery()
    # dccm instance should be of class DCCRegistryMachinery
    assert isinstance(dccm, DCCRegistryMachinery)
    # dccm.find should be a method
    assert callable(dccm.find)
    # dccm.find should have one parameter
    assert len(inspect.signature(dccm.find).parameters) == 2
    # dccm.find should take param name
    assert "name" in inspect.signature(dccm.find).parameters
    # dccm.find should have 1 return value
    assert len(inspect.signature(dccm.find).return_annotation) == 1
    # dccm.find should return None or a DCCRegistryMachinery
    assert inspect.sign

# Generated at 2022-06-12 06:14:07.653129
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == 0.16666666666667
    assert dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == 0.16944444444444
    assert dcfc_30_e_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == 1.08333333333333

# Generated at 2022-06-12 06:14:12.994312
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert(dcfc_act_365_a(datetime.date(2007, 12, 31), datetime.date(2010, 12, 31),datetime.date(2010, 12, 31)) == 1)


# Generated at 2022-06-12 06:15:00.367427
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start= datetime.date(2012,12,1), asof= datetime.date(2013,5,31) ,end= datetime.date(2020,5,31)),2) == Decimal('0.19')


# Generated at 2022-06-12 06:15:08.870376
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    ex1_freq = Decimal(2)
    assert round(dcfc_act_act_icma(ex1_start, ex1_asof, ex1_end, ex1_freq), 10) == Decimal('0.5245901639')


# def dcfc_act_act_icma(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
#     """
#     Computes the day count fraction for "Act/Act (ICMA)" convention.

#     :param start: The start date of the period.
#    

# Generated at 2022-06-12 06:15:18.267417
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2018, 6, 8), asof=datetime.date(2018, 6, 8), end=datetime.date(2018, 6, 8)), 14) == Decimal('0.0')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2015, 12, 10), asof=datetime.date(2016, 2, 10), end=datetime.date(2016, 2, 10)), 14) == Decimal('0.08333333333333')

# Generated at 2022-06-12 06:15:27.390464
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    import datetime
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof)) == Decimal('0.16986301369863')
   

# Generated at 2022-06-12 06:15:37.152756
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    DCC.calculate_fraction calls DCC.method_calculate_fraction(start, asof, end, freq)
    """
    start = Date.from_date(date(2010, 1, 1))
    asof = Date.from_date(date(2010, 1, 1))
    end = Date.from_date(date(2011, 1, 1))
    freq = Decimal('0.5')
    def method_calculate_fraction(start, asof, end, freq):
        """
        A dummy method
        """
        return Decimal('2.0')
    dcc = DCC(name="dcc", altnames=set(), currencies=set(),
              method_calculate_fraction=method_calculate_fraction)
    assert dcc.calcul

# Generated at 2022-06-12 06:15:42.507669
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    start, asof, end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)
    expected = Decimal('0.16942884946478')
    result = dcfc_act_act(start, asof, end)
    assert result == expected


# Generated at 2022-06-12 06:15:51.714259
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Unit test for function dcfc_30_360_german.
    """
    try:
        from datetime import date
    except ImportError:
        from datetime import datetime as date


# Generated at 2022-06-12 06:16:02.721309
# Unit test for method interest of class DCC
def test_DCC_interest():
     from .currencies import Currencies
     from .monetary import Money
     from .daycounts import DCCs
     import datetime
     
     money = Money(100, Currencies.USD)
     dcConv = DCCs.ISMA_30_360
     dc_start = datetime.date(2018, 6, 15)
     dc_asof = datetime.date(2018, 12, 31)
     dc_end = datetime.date(2019, 1, 15)
     dc_rate = 0.05
     
     interest = dcConv.interest(money, dc_rate, dc_start, dc_asof, dc_end)
     assert interest == Money(-1.53, Currencies.USD)

# Generated at 2022-06-12 06:16:14.760015
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # 2018-01-01 - 2018-02-01 -> 0.016438356164383563
    assert DCCRegistry.__AC30_360__.calculate_daily_fraction(datetime.date(2018, 1, 1), datetime.date(2018, 2, 1), datetime.date(2018, 2, 1)) == Decimal('0.016438356164383563')
    # 2018-01-01 - 2018-02-01 -> 0.016438356164383563
    assert DCCRegistry.__ACT_365__.calculate_daily_fraction(datetime.date(2018, 1, 1), datetime.date(2018, 2, 1), datetime.date(2018, 2, 1)) == Decimal('0.016438356164383563')
    # 2018-01-

# Generated at 2022-06-12 06:16:20.841633
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    principal = Money(100, Currencies.GBP)
    start = Date(1, 2, 2017)
    asof = Date(2, 3, 2017)
    end = Date(9, 10, 2017)
    freq = Decimal(3)
    expected = Money(1.49, Currencies.GBP)
    assert DCC.ACT30E360.calculate_daily_fraction(start, asof, end, freq) == expected

# Generated at 2022-06-12 06:17:25.329990
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:17:37.146406
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:17:48.766557
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():

    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 12, 31)
    end = datetime.date(2015, 1, 1)
    freq = 1

    simple = DCC('simple', set(), set(), _simple_day_count_fraction)
    daily_fraction = simple.calculate_daily_fraction(start, asof, end, freq)
    assert daily_fraction == Decimal('0.0958904109589041')

    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 12, 31)
    end = datetime.date(2015, 1, 1)
    freq = Decimal(1)


# Generated at 2022-06-12 06:17:55.531123
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2007,12,28),datetime.date(2008,2,28),datetime.date(2008,2,28)),14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(datetime.date(2007,12,28),datetime.date(2008,2,29),datetime.date(2008,2,29)),14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(datetime.date(2007,10,31),datetime.date(2008,11,30),datetime.date(2008,11,30)),14) == Decimal('1.08333333333333')

# Generated at 2022-06-12 06:17:57.561092
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCC('name', set('altnames'), set(Currencies['USD']), lambda start, asof, end, freq: 1.0). interest(
        Money(1000000000, 'USD'), 0.05, datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Money(50000000, 'USD')



# Generated at 2022-06-12 06:18:08.882333
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCCRegistry['ACT/ACT ISMA'][0].calculate_daily_fraction(datetime.date(2014,  1,  1), datetime.date(2014,  6,  1), datetime.date(2014,  7,  1)) == Decimal("0.0321")
    assert DCCRegistry['ACT/365'][0].calculate_daily_fraction(datetime.date(2014,  1,  1), datetime.date(2014,  6,  1), datetime.date(2014,  7,  1)) == Decimal("0.01649")

# Generated at 2022-06-12 06:18:15.444299
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_us(start=start, asof=asof, end=asof), 14) == Decimal('0.16666666666667')

    start, asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_30_360_us(start=start, asof=asof, end=asof), 14) == Decimal('0.16944444444444')

    start, asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)

# Generated at 2022-06-12 06:18:19.367965
# Unit test for method interest of class DCC
def test_DCC_interest():
    m = Money('4.0012', 'USD')
    DCC_temp = DCC(name='30/360', altnames={'30/360'}, currencies={Currencies['USD']}, calculate_fraction_method=_convention_30360)
    assert(DCC_temp.interest(m, Decimal(0.01), date(2018,2,1), date(2018,3,1), date(2018,3,1), Decimal(0.01)) == Money('0.0012', 'USD'))


# Generated at 2022-06-12 06:18:30.452197
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    for count in range(6):
        rand_yr = randrange(1, 2100)
        rand_month = randrange(1, 13)
        rand_day_start = randrange(1, 29)
        rand_day_end = randrange(1, 29)
        start_date = datetime.date(rand_yr, rand_month, rand_day_start)
        end_date = datetime.date(rand_yr, rand_month, rand_day_end)
        assert dcfc_30_360_german(start_date, end_date, end_date) == dcfc_30_e_360(start_date, end_date, end_date)


# Generated at 2022-06-12 06:18:36.073790
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
