

# Generated at 2022-06-12 06:11:11.384528
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    _start = datetime.date(2014,  1,  1)
    _end = datetime.date(2014,  4,  1)
    _asof = datetime.date(2014,  1,  1)
    _freq = 1
    _convention = DCC(
        "ACT/ACT", set(), _as_ccys(set()),
        lambda start, asof, end, freq: Decimal(1) * Decimal(_get_actual_day_count(start, end)) / Decimal(_get_actual_day_count(start, end))
    )
    _result = _convention.calculate_daily_fraction(_start, _asof, _end, _freq)
    _expected_result = Decimal(0)

# Generated at 2022-06-12 06:11:19.381965
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    DCCRegistry.register(DCC(name="Act/Act", altnames={"Actual/Actual", "Actual Actual"}, currencies={}, calculate_fraction_method=lambda s, a, e, f: Decimal((e - a).days) / Decimal((e - s).days)))
    ret = DCCRegistry.find("Act/Act")
    assert ret is not None

# Generated at 2022-06-12 06:11:27.806676
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from decimal import Decimal
    assert DCC('ACT/ACT', {'Actual/Actual', 'Act/Act', 'Actual/365', 'Act/365', 'Actual/365.25', 'Act/365.25', 'Actual/366', 'Act/366', 'AFB', 'ISMA'}, {'USD', 'VND', 'ZAR'}, _DCC_ACT_ACT_function).calculate_fraction(datetime.date(2018, 1, 2), datetime.date(2018, 1, 3), datetime.date(2018, 2, 1)) == Decimal('0.0028301886792452830188679245')

# Generated at 2022-06-12 06:11:39.737686
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-12 06:11:51.145553
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    import datetime
    from decimal import Decimal
    from dbcurves.models import DCC

    # Case 1:
    # act
    start = datetime.date(2010, 1, 4)
    asof = datetime.date(2010, 1, 15)
    end = datetime.date(2010, 1, 27)
    dcc = DCC.ACT_365
    actual = dcc.calculate_fraction(start, asof, end)
    # assert
    expected = Decimal('0.10775862068965517')
    assert actual == expected

    # Case 2:
    # act
    start = datetime.date(2010, 1, 4)
    asof = datetime.date(2010, 1, 15)
    end = datetime.date(2010, 1, 27)
    dcc

# Generated at 2022-06-12 06:11:57.398447
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2017, 10, 6), datetime.date(2017, 12, 31), datetime.date(2018, 3, 31)), 14) == round(Decimal('0.23333333333333'), 14)



# Generated at 2022-06-12 06:12:05.149826
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    principal = Money(Decimal('1000.00'), Currency.USD)
    rate = Decimal('0.04')
    start = Date(datetime.date(2010, 1, 1))
    asof = Date(datetime.date(2010, 1, 31))
    end = Date(datetime.date(2010, 2, 1))
    freq = Decimal('0.5')
    eom = None
    result = DCC.interest(principal, rate, start, asof, end, freq)
    assert(result == money)

# Generated at 2022-06-12 06:12:11.303150
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=Date(2019, 3, 2), asof=Date(2019, 9, 10), end=Date(2020, 3, 2)),14) == 0.5245901639


# Generated at 2022-06-12 06:12:23.635412
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == 0.16942884946478
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == 0.17216108990194
    assert round(dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == 1.08243131970956

# Generated at 2022-06-12 06:12:31.846511
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-12 06:13:37.177933
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 4, 30), datetime.date(2008, 4, 30)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 5, 31), datetime.date(2008, 5, 31)), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:13:47.306298
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert Decimal("0.16942884946478")==dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))
    assert Decimal("0.17216108990194")==dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29))
    assert Decimal("1.08243131970956")==dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30))

# Generated at 2022-06-12 06:13:53.412494
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    start_date = datetime.date(2013, 4, 1)
    end_date = datetime.date(2014, 4, 1)
    assert (dcfc_30_e_360(start_date, start_date, end_date) == Decimal('0.083333333333333'))
    assert (dcfc_30_e_360(start_date, end_date, end_date) == Decimal('1.08333333333333'))



# Generated at 2022-06-12 06:14:05.583485
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:14:16.646953
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    # ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    # ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    # ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex1_start, ex1_asof = datetime.date(2008, 6, 30), datetime.date(2008, 8, 30)

# Generated at 2022-06-12 06:14:27.622468
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    frq = 2
    expected = Decimal('0.2622950819')
    result = dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end, freq=frq)
    assert(result == expected)


# Generated at 2022-06-12 06:14:36.385816
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    DCC('actual/actual', {'actual/actual', 'actual/365', 'act/act', 'act/365'}, {Currencies.USD, Currencies.EUR},
        lambda a, b, c, d: Decimal(_get_actual_day_count(a, b)) / Decimal(max(_get_actual_day_count(a, c), 1))).coupon(Money(1, Currencies.USD), Decimal(0.05), datetime.date(2017, 11, 19), datetime.date(2017, 11, 26), datetime.date(2018, 11, 19), 1)



# Generated at 2022-06-12 06:14:43.056902
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == Decimal('0.16942884946478')
    assert dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) == Decimal('0.17216108990194')
    assert dcfc_act_act(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)) == Decimal('1.08243131970956')
    assert dcfc_act_

# Generated at 2022-06-12 06:14:53.082882
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    principal = Money(100, Currencies.EUR)
    rate = Decimal("0.05")
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 12, 31)
    freq = 1
    dcc = DCC("Actual/Actual (AFB)", {}, {}, calculate_fraction_method=calculate_fraction_method_actual_actual)
    assert dcc.interest(principal, rate, start, asof, end, freq) == Money(5.0, Currencies.EUR)
    assert dcc.calculate_daily_fraction(start, asof, end, freq) == Decimal("0")

# Generated at 2022-06-12 06:15:02.716058
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """
    ####################################################################################################################
    # ACTUAL ACT ACTUAL/365
    ####################################################################################################################

    # First let's initialize the DCC method:
    start = datetime.date(2020, 1, 1)
    end = datetime.date(2020, 1, 3)

# Generated at 2022-06-12 06:17:19.868653
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    start = Date(2018, 1, 1)
    asof = Date(2018, 1, 1)
    end = Date(2018, 12, 30)
    freq = 1.0
    act = calculate_daily_fraction(start, asof, end, freq)
    exp = 0
    assert act == exp


# Generated at 2022-06-12 06:17:24.492855
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Define the day count fraction calculation method function.
    def calculate_fraction_method(start: Date, asof: Date, end: Date, freq: Optional[Decimal] = None) -> Decimal:
        return _get_actual_day_count(start, asof) / _get_actual_day_count(start, end)

    dcc = DCC(
        name="Actual/365",
        altnames=set(),
        currencies=_as_ccys({"BND"}),
        calculate_fraction_method=calculate_fraction_method
    )
    start, asof, end = datetime.date(2015, 1, 1), datetime.date(2015, 1, 2), datetime.date(2015, 2, 1)
    daily_fraction = dcc.calculate_daily_f

# Generated at 2022-06-12 06:17:30.796009
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # create a dummy dcc
    dcc = DCC("Actual/Actual ICMA", {}, {}, lambda x,y,z,a: Decimal(1))
    result = dcc.calculate_daily_fraction(asof=Date(2020, 4, 7), end=Date(2020, 6, 12), start=Date(2020, 2, 20))
    assert result == 1



# Generated at 2022-06-12 06:17:39.730423
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    y1 = datetime.date(2018, 1, 1)
    y2 = datetime.date(2018, 1, 2)
    y3 = datetime.date(2018, 1, 3)

    a1 = datetime.date(2018, 1, 1)
    a2 = datetime.date(2018, 1, 2)
    a3 = datetime.date(2018, 1, 3)

    x1 = datetime.date(2018, 1, 1)
    x2 = datetime.date(2018, 1, 2)
    x3 = datetime.date(2018, 1, 3)

    # Expected output to the test cases
    e_afb_1 = Decimal(1)
    e_afb_2 = Decimal(1)
    e_afb_3 = Decimal(1)

    e_

# Generated at 2022-06-12 06:17:48.327448
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    should_raise = AnyException(ValueError)
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-12 06:17:53.774266
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from datetime import date
    import pytest
    from finance.daycount.conventions import libor
    dcc = libor.DCC_LIBOR
    start = date(2019, 12, 31)
    asof = date(2019, 12, 31)
    end = date(2020, 3, 31)
    freq = Decimal(0.5)
    assert dcc.calculate_fraction(start, asof, end, freq) == pytest.approx(Decimal('0.003616438356164383562'))


# Generated at 2022-06-12 06:18:05.670928
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies import Currencies
    from .monetary import Money
    from .time import DayCountConventions as DCCs

    ## Define the range:
    start = datetime.date(2016, 1, 1)
    end = datetime.date(2017, 1, 1)

    ## Define the currency:
    currency = Currencies["TRY"]

    ## Define the principal:
    principal = Money(-100.0, currency)

    ## Define the rate:
    rate = Decimal("0.10")

    ## Calculate the factor and interest:
    act_dfact = DCCs["ACT/ACT"].calculate_daily_fraction
    act_efact = DCCs["ACT/ACT"].calculate_fraction
    eur_dfact = DCCs["ACT/360"].calcul

# Generated at 2022-06-12 06:18:12.640879
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    start_date = datetime.date(2020, 6, 30)
    asof_date = datetime.date(2020, 7, 1)
    end_date = datetime.date(2020, 7, 5)
    dcc = DCC(name = "ACT/360",
               altnames = ("act/360", "act-360", "act_360", "act360",),
               currencies = set(),
               calculate_fraction_method = Act360().calculate_fraction)
    assert dcc.calculate_daily_fraction(start_date, asof_date, end_date) == Decimal('0.0027777777777777776')



# Generated at 2022-06-12 06:18:23.651477
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    
    start = datetime.date(2019, 1, 14)
    asof = datetime.date(2019, 3, 14)
    
    
    result = dcfc_30_e_360(start, asof, end = asof)
    result_float = float(result)
    result_dict = {"30E/360": result_float}
    
    pd.testing.assert_frame_equal(result_df,
                                  pd.DataFrame(result_dict, index=[0]),
                                  check_dtype=False)



# Generated at 2022-06-12 06:18:34.933252
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2010, 2, 1), asof=datetime.date(2010, 5, 2), end=datetime.date(2010, 5, 2)), 14) == Decimal('0.12604329369141')
    assert round(dcfc_act_act(start=datetime.date(2010, 2, 1), asof=datetime.date(2010, 5, 2), end=datetime.date(2010, 5, 2), freq = 1), 14) == Decimal('0.12604329369141')