

# Generated at 2022-06-12 06:11:02.462120
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof   = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof   = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof   = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof   = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof   = datetime.date(2008, 2, 28), datetime.date(2009, 3, 4)

# Generated at 2022-06-12 06:11:14.833473
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(
        datetime.date(2007, 12, 28),
        datetime.date(2008, 2, 28)
    ), 14) == round(Decimal('0.16666666666667'), 14)
    assert round(dcfc_30_360_isda(
        datetime.date(2008, 5, 30),
        datetime.date(2008, 8, 29)
    ), 14) == round(Decimal('0.10000000000000'), 14)
    assert round(dcfc_30_360_isda(
        datetime.date(2007, 12, 28),
        datetime.date(2008, 2, 29)
    ), 14) == round(Decimal('0.16944444444444'), 14)

# Generated at 2022-06-12 06:11:27.526573
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert is_equal_decimal(
        dcfc_30_360_us(
            datetime.date(1971, 11, 25),
            datetime.date(1972, 4, 30),
            datetime.date(1972, 4, 30)
        ),
        Decimal("0.22222222222222")
    )

    assert is_equal_decimal(
        dcfc_30_360_us(
            datetime.date(2015, 11, 2),
            datetime.date(2016, 4, 30),
            datetime.date(2016, 4, 30)
        ),
        Decimal("0.22222222222222")
    )


# Generated at 2022-06-12 06:11:33.621741
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies import Currencies
    from .monetary import Money

    # Actual vs expected
    assert DCCRegistry['ACT/360'].calculate_daily_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 1),
                                                           datetime.date(2014, 1, 2)) == 0
    assert DCCRegistry['ACT/360'].calculate_daily_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 1),
                                                           datetime.date(2014, 1, 1)) == 0

# Generated at 2022-06-12 06:11:44.486928
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2),datetime.date(2019, 9, 10),datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2),datetime.date(2019, 3, 31),datetime.date(2020, 3, 2)), 10) == Decimal('0.0491803279')
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2),datetime.date(2019, 4, 30),datetime.date(2020, 3, 2)), 10) == Decimal('0.0983606558')

# Generated at 2022-06-12 06:11:56.764323
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert Decimal(str(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)))) ==  Decimal('0.16986301369863')
    assert Decimal(str(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)))) ==  Decimal('0.17213114754098')

# Generated at 2022-06-12 06:12:07.098457
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert_almost_equal(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), Decimal('0.16666666666667'))
    assert_almost_equal(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), Decimal('0.16944444444444'))

# Generated at 2022-06-12 06:12:17.436072
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    DCC_ = DCC(
        name="Actual/Actual (ISMA)",
        altnames={"Actual/Actual", "Act/Act", "Actual/Actual (ISDA)", "Actual/Actual (Bond)", "Act/Act (ISMA)", "ACTUAL/ACTUAL"},
        currencies={Currencies.USD, Currencies.GBP, Currencies.JPY, Currencies.EUR, Currencies.EUR},
        calculate_fraction_method=_ActualActual_ISMA_DCF,
    )

# Generated at 2022-06-12 06:12:24.890853
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    start_date = datetime.date(2007, 12, 28)
    asof_date = datetime.date(2008, 2, 28)
    end_date = datetime.date(2008, 2, 28)
    frq = None
    assert round(dcfc_act_act(start_date, asof_date, end_date, frq), 14) == Decimal('0.16942884946478')


# Generated at 2022-06-12 06:12:32.486442
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # ISMA
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 2)
    expected = Decimal('0.0027777777777778')
    daily_fraction = DCCRegistry['ISMA'].calculate_daily_fraction(start, asof, end)
    assert daily_fraction == expected

    # 30E/360
    start = datetime.date(2017, 2, 28)
    asof = datetime.date(2017, 2, 28)
    end = datetime.date(2017, 6, 30)
    expected = Decimal(1/3)
    daily_fraction = DCCRegistry['30E/360'].calculate_daily_fraction

# Generated at 2022-06-12 06:13:13.723807
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) , 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) , 14) == Decimal('0.16944444444444')

# Generated at 2022-06-12 06:13:19.946872
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert (round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)),14) == round(Decimal('0.16666666666667'),14))
    assert (round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 28)),14) == round(Decimal('0.16944444444444'),14))

# Generated at 2022-06-12 06:13:32.280389
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    r = DCC("test", {}, {}, lambda a, b, c, d: ONE)
    #Test with nominal dates
    assert r.coupon(Money(1000, Currencies.EUR), Decimal("0.05"), Date(2011,8,15), Date(2012,7,15), Date(2022,8,15), Decimal("2"), 15) == Money(4167, Currencies.EUR)
    #Test with non nominal dates
    assert r.coupon(Money(1000, Currencies.EUR), Decimal("0.05"), Date(2011,12,20), Date(2012,7,15), Date(2022,8,15), Decimal("2"), 15) == Money(5000, Currencies.EUR)



# Generated at 2022-06-12 06:13:45.496861
# Unit test for function dcfc_act_act

# Generated at 2022-06-12 06:13:56.103430
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-12 06:14:07.652864
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .currencies import Currencies
    from .monetary import Money
    from .schedule import Period, PeriodUnit, Schedule
    from .util import const
    from .commons.zeitgeist import Date

    conv = DCCRegistry['ACT_360']
    start = Date(1,1,23)
    asof = Date(2,2,23)
    end = Date(3,3,23)
    freq = 3
    Money(1, []) * 2 * conv.calculate_fraction(start, asof, end, freq)
    conv.interest(Money(1, Currencies.USD), 2, start, asof, end, freq)
    conv.coupon(Money(1, Currencies.USD), 2, start, asof, end, freq)


# Generated at 2022-06-12 06:14:15.364221
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    ## Test 1:
    assert DCCRegistry.get("ACT/365", Currencies.get("USD")).coupon(
        Money(100, Currencies.get("USD")),
        Decimal(0.05),
        datetime.date(2014, 1, 1),
        datetime.date(2015, 12, 31),
        datetime.date(2015, 12, 31),
        2,
    ) == Money(2.4958904110, Currencies.get("USD"))


# Generated at 2022-06-12 06:14:21.239087
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # Defines test parameters
    dcc = DCC(name="Test", altnames={"A", "B"}, currencies={}, calculate_fraction_method=lambda *_: ZERO)

    # Attempts to register the code:
    DCCRegistry.register(dcc)

    # Finds the convention:
    found = DCCRegistry.find("Test")

    # Checks the convention:
    assert found and found.name == "Test"



# Generated at 2022-06-12 06:14:27.539871
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof) == round(0.16666666666667,14)
    assert dcfc_30_

# Generated at 2022-06-12 06:14:29.864867
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    ## TODO:
    pass

# Generated at 2022-06-12 06:14:51.079494
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    from financepy.finutils.FinGlobalVariables import FIN_DCC_ACT_ACT_ICMA
    assert DCCRegistry.find("Act/Act") == FIN_DCC_ACT_ACT_ICMA
    assert DCCRegistry.find("ActAct") == FIN_DCC_ACT_ACT_ICMA
    assert DCCRegistry.find("Act/Act ICMA") == FIN_DCC_ACT_ACT_ICMA
    assert DCCRegistry.find("Actact icma") == FIN_DCC_ACT_ACT_ICMA

# Generated at 2022-06-12 06:15:01.863025
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    from collections import namedtuple

    from hamcrest import (
        assert_that,
        is_,
        is_not,
    )

    # Define a day count convention:
    DCC = namedtuple('DCC', ['name', 'altnames', 'currencies', 'calculate_fraction_method'])

    # Define a dummy calculation method:
    def calc(start: datetime.date, asof: datetime.date, end: datetime.date) -> Decimal:
        return Decimal('1')

    # Create the registry:
    r = DCCRegistryMachinery()

    # Register a new day count convention:
    r.register(DCC(name='test', altnames=set(), currencies=set(), calculate_fraction_method=calc))

    # Make sure that we can find the convention

# Generated at 2022-06-12 06:15:09.587931
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCCRegistry['Simple'].calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 2)) == 1
    assert DCCRegistry['ACT/365'].calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 2)) == 1
    assert DCCRegistry['ACT/360'].calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 2)) == 1


# Generated at 2022-06-12 06:15:19.189960
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry.find('act/365').calculate_fraction(Date(2018,12,17),Date(2020,7,29),Date(2020,7,29))==Decimal(1.752054794520548)
    assert DCCRegistry.find('eu/360').calculate_fraction(Date(2018,12,17),Date(2020,7,29),Date(2020,7,29))==Decimal(1.805555555555556)
    assert DCCRegistry.find('30/360psa').calculate_fraction(Date(2018,12,17),Date(2020,7,29),Date(2020,7,29))==Decimal(1.8)

# Generated at 2022-06-12 06:15:28.885730
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Test method calculate_fraction of the class DCC.
    """
    ## Define the register:

# Generated at 2022-06-12 06:15:39.879540
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    import math
    import unittest

    def round6(x):
        return math.floor(x * 10 ** 6) / 10 ** 6

    class TestDcfcAct365A(unittest.TestCase):
        def test_dcfc(self):
            ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
            ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
            ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)

# Generated at 2022-06-12 06:15:50.238965
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    import pandas as pd


# Generated at 2022-06-12 06:15:57.989594
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert(round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639'))
    

# Generated at 2022-06-12 06:16:07.310885
# Unit test for method interest of class DCC
def test_DCC_interest():
    start = datetime.date(2016,  1,  1)
    asof = datetime.date(2016,  4,  1)
    end = datetime.date(2016, 12, 31)
    principal = Money(50000.00, "USD")
    rate = Decimal('0.03')
    expected = Money(375.0, "USD")
    acutal = DCCRegistry["ACT/360"].interest(principal, rate, start, asof, end)
    assert acutal == expected


# Generated at 2022-06-12 06:16:18.565044
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-12 06:17:11.382029
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:17:18.372918
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-12 06:17:27.777532
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16939890710383'))

# Generated at 2022-06-12 06:17:38.656605
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    "Test function dcfc_30_360_us"

    print("Testing dcfc_30_360_us")

    testing_dates = [datetime.date(2007, 12, 28),
                     datetime.date(2007, 12, 29),
                     datetime.date(2007, 12, 30),
                     datetime.date(2007, 12, 31),
                     datetime.date(2008, 1, 28),
                     datetime.date(2008, 2, 28),
                     datetime.date(2008, 2, 29),
                     datetime.date(2007, 10, 31),
                     datetime.date(2008, 11, 30),
                     datetime.date(2008, 2, 1),
                     datetime.date(2009, 5, 31)]


# Generated at 2022-06-12 06:17:45.360426
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)) == 0.524590163934426



# Generated at 2022-06-12 06:17:53.580679
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2009,11,30),asof=datetime.date(2009,12,30),end=datetime.date(2009,12,30)),14) == Decimal('0.08333333333333')
    assert round(dcfc_30_360_isda(start=datetime.date(2008,2,28),asof=datetime.date(2008,3,31),end=datetime.date(2008,3,31)),14) == Decimal('0.09722222222222')

# Generated at 2022-06-12 06:18:03.423419
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    d=datetime.date(2017, 1, 1)
    e=datetime.date(2017, 1, 2)
    f=datetime.date(2017, 1, 3)
    d1=DCC('',set(''),set(''),_calculate_dcf_actact)
    assert d1.calculate_fraction(d,e,f)==(Decimal('1.0'))
    assert d1.calculate_fraction(d,d,f)==(Decimal('0.0'))
    assert d1.calculate_fraction(d,f,e)==(Decimal('0.0'))
    
    

# Generated at 2022-06-12 06:18:10.180169
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCRegistry["30E360"].coupon(principal=Money(100, "AFN"), rate=Decimal('.05'), start=Date(day=1, month=1, year=2019), asof=Date(day=1, month=1, year=2020), end=Date(day=1, month=1, year=2021), freq=Decimal('.5'), eom=1) == Money(Decimal('5'), 'AFN')
test_DCC_coupon()



# Generated at 2022-06-12 06:18:12.260204
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    dcfc_30_e_360()
   

# Generated at 2022-06-12 06:18:24.947573
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """
    Test for dcfc_30_360_isda
    """
    assert round(dcfc_30_360_isda(datetime.date(2019, 12, 31), datetime.date(2020, 1, 31), datetime.date(2020, 1, 31)), 14) - Decimal('0.08333333333333') < EPSILON
    assert round(dcfc_30_360_isda(datetime.date(2019, 12, 30), datetime.date(2020, 1, 31), datetime.date(2020, 1, 31)), 14) - Decimal('0.08333333333333') < EPSILON