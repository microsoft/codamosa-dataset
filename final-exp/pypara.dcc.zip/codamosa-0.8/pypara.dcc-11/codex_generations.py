

# Generated at 2022-06-12 06:10:50.448923
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # from math import isclose
    assert isclose(round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14), Decimal('0.16942884946478'))
    assert isclose(round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14), Decimal('0.17216108990194'))
    assert isclose(round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14), Decimal('1.08243131970956'))

# Generated at 2022-06-12 06:11:02.392566
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383'))

# Generated at 2022-06-12 06:11:14.715945
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from .currencies import CURRENCIES
    from .monetary import Money
    from .time.calendars.western import *
    p1 = Money(10000, CURRENCIES["USD"])
    r1 = 0.05
    s1 = datetime.date(2014,  1, 15)
    a1 = datetime.date(2015,  1,  1)
    e1 = datetime.date(2015,  6,  1)
    f1 = Decimal(2)
    cashflow = DCC.ACT_360.coupon(p1, r1, s1, a1, e1, f1)
    assert cashflow == Money(123.67 * 2, CURRENCIES["USD"])
    #
    p2 = Money(10000, CURRENCIES["USD"])

# Generated at 2022-06-12 06:11:27.370115
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    Expected1 = round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-12 06:11:39.354002
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    d1 = datetime.date(2007, 12, 28)
    d2 = datetime.date(2008, 2, 28)
    d3 = datetime.date(2008, 2, 29)
    d4 = datetime.date(2007, 10, 31)
    d5 = datetime.date(2008, 11, 30)
    d6 = datetime.date(2008, 2, 1)
    d7 = datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=d1, asof=d2, end=d2), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=d1, asof=d3, end=d3), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-12 06:11:50.776121
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    # Test cash flow on reserved date
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')
    # Test cash flow on last day of reserved period
    ex2_start, ex2_asof, ex2_end = datetime.date(2020,3,2), datetime.date(2020,3,2), datetime.date(2021,3,2)

# Generated at 2022-06-12 06:12:02.898593
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof = datetime.date(2007,12,31), datetime.date(2008,2,29)
    ex6_start, ex6_asof = datetime.date(2008,2,29), dat

# Generated at 2022-06-12 06:12:11.203348
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    #Test case 1
    print("Test case 1")
    assert DCCRegistry["30/360 PS"].calculate_fraction(Date(2017,1,1),Date(2017,1,1),Date(2017,1,2)) == Decimal("0")
    assert DCCRegistry["30/360 PS"].calculate_fraction(Date(2017,1,1),Date(2017,1,1),Date(2017,12,31)) == Decimal("0")
    assert DCCRegistry["30/360 PS"].calculate_fraction(Date(2017,1,1),Date(2017,1,1),Date(2017,1,1)) == Decimal("0")

# Generated at 2022-06-12 06:12:23.524144
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-12 06:12:25.237647
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("Act/Act") is not None


# Generated at 2022-06-12 06:12:47.155960
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16666666666667')
    assert dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 29)) == 0.16666666666667
    assert dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 29)) == Fraction(7, 42)



# Generated at 2022-06-12 06:12:59.983074
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry.ACTUAL_365L.calculate_fraction(datetime.date(2010, 10, 1), datetime.date(2010, 12, 31), datetime.date(2011, 1, 1)) == datetime.timedelta(91).days/Decimal('365')
    assert DCCRegistry.ACTUAL_365L.calculate_fraction(datetime.date(2011, 1, 1), datetime.date(2011, 1, 1), datetime.date(2012, 1, 1)) == Decimal(0)
    assert DCCRegistry.ACTUAL_ACTUAL_ISDA.calculate_fraction(datetime.date(2008, 10, 18), datetime.date(2015, 10, 19), datetime.date(2020, 10, 19)) == datetime.timedelta(2134).days

# Generated at 2022-06-12 06:13:11.180698
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    def asdu_fixture():
        return estr.add(
            estr.add(
                '<DCC name="Act/Act" altnames={"Actual/Actual"} currencies=""""',
                estr.add(
                    'calculate_fraction_method="<operator.method \'__main__.dc_act_act_fraction\'>"'),
                '>'),
            '</DCC>')

    def act_act_fixture():
        return estr.add(
            '<DCC name="Act/Act" altnames={"Actual/Actual"} currencies=""""',
            estr.add(
                'calculate_fraction_method="<operator.method \'__main__.dc_act_act_fraction\'>"'),
            '>')


# Generated at 2022-06-12 06:13:17.016424
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:13:21.765600
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCC("ACTUAL365", {"ACT/365F", "ACT/ACT", "ACT/365F", "ACT/ACTUAL"}, {Currencies["USD"], Currencies["GBP"]}, _act_act)
    DCCRegistry.register(dcc)


# Generated at 2022-06-12 06:13:33.686614
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 30)

# Generated at 2022-06-12 06:13:42.338214
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    for d1, d2 in ((datetime.date(2019, 4, 30), datetime.date(2019, 6, 28)),
                   (datetime.date(2019, 6, 4), datetime.date(2019, 8, 28))):
        assert dcfc_30_360_german(d1, d2, d2) == dcfc_30_e_360(d1, d2, d2)



# Generated at 2022-06-12 06:13:54.384655
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    test_data = [
        (1, 2, 3, 4, 5),
    ]
    for arg_data in test_data:
        with pytest.raises(TypeError):
            DCC(*arg_data)
    test_data = [
        ("test1", {"test1"}, {Currencies["EUR"]}, lambda s, a, e, f: ZERO),
        ("test2", {"test2"}, {Currencies["EUR"]}, lambda s, a, e, f: ONE),
    ]
    for arg_data in test_data:
        with pytest.raises(TypeError):
            DCC(*arg_data).calculate_fraction()

# Generated at 2022-06-12 06:13:57.891864
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    pass



# Generated at 2022-06-12 06:14:04.726254
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2017, 1, 1)
    end   = datetime.date(2017, 2, 1)
    today = datetime.date(2017, 1, 2)
    dcc   = DCC("Test", "Test", set(), lambda s,a,e,f: Decimal("1"))

    assert dcc.calculate_fraction(start, today, end) == Decimal("1")

# Generated at 2022-06-12 06:14:21.541643
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("Act/Act") == DCC("Act/Act", {"30/360", "Act/act"}, {"USD"}, _act_act)


DCCRegistry = DCCRegistryMachinery()



# Generated at 2022-06-12 06:14:31.264584
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():

    registry = DCCRegistryMachinery()
    registry.register(DCC('Act/365', set(), set(), DCF_Actual_Actual_365))
    registry.register(DCC('Act/Act', {'Actual/Actual'}, set(), DCF_Actual_Actual_365))
    assert_equal(registry.table['Act/Act'], DCC('Act/Act', {'Actual/Actual'}, set(), DCF_Actual_Actual_365))
    assert_equal(registry.table['Actual/Actual'], DCC('Act/Act', {'Actual/Actual'}, set(), DCF_Actual_Actual_365))
    assert_equal(len(registry.registry), 2)


# Generated at 2022-06-12 06:14:39.792283
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """ Unit test for function dcfc_30_360_german """
    assert round(dcfc_30_360_german(datetime.date(2007, 2, 28), datetime.date(2007, 3, 31), datetime.date(2007, 3, 31)), 8) == 0.08333333
    assert round(dcfc_30_360_german(datetime.date(2007, 2, 28), datetime.date(2007, 3, 30), datetime.date(2007, 3, 31)), 8) == 0.08333333
    assert round(dcfc_30_360_german(datetime.date(2008, 2, 29), datetime.date(2008, 3, 31), datetime.date(2008, 3, 31)), 8) == 0.08333333

# Generated at 2022-06-12 06:14:50.690941
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(datetime.date(2007,12,28),datetime.date(2008,2,28)),14)==Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(datetime.date(2007,12,28),datetime.date(2008,2,29)),14)==Decimal('0.16944444444444')
    assert round(dcfc_30_e_plus_360(datetime.date(2007,10,31),datetime.date(2008,11,30)),14)==Decimal('1.08333333333333')

# Generated at 2022-06-12 06:14:57.613874
# Unit test for method interest of class DCC
def test_DCC_interest():
    a = DCC(
        name="Test",
        altnames=set(),
        currencies=set(),
        calculate_fraction_method=(lambda st, aso, end, freq: ONE)
    )

    assert a.interest(Money(100.0, Currencies.USD), 0.5, datetime.datetime.now(), datetime.datetime.now()) == Money(50.0, Currencies.USD)



# Generated at 2022-06-12 06:15:05.249839
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(datetime.date(2012, 12, 30), datetime.date(2013, 3, 31), datetime.date(2013, 3, 31)) == Decimal("0.166666666666667")
    assert dcfc_30_e_360(datetime.date(2012, 12, 30), datetime.date(2013, 3, 29), datetime.date(2013, 3, 29)) == Decimal("0.166666666666667")


# Generated at 2022-06-12 06:15:15.672820
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .currencies import USD
    from .monetary import Money
    from .tenors import TENOR_3M, TENOR_1M
    assert DCCRegistry.ISDA.calculate_fraction(Date(1, 1, 2017), Date(1, 1, 2017), Date(30, 1, 2017)) == Decimal('0')
    assert DCCRegistry.ISDA.calculate_fraction(Date(1, 1, 2017), Date(1, 1, 2017), Date(31, 1, 2017)) == Decimal('0')
    assert DCCRegistry.AFB.calculate_fraction(Date(1, 1, 2017), Date(1, 1, 2017), Date(30, 1, 2017)) == Decimal('0')

# Generated at 2022-06-12 06:15:26.153584
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    dcfc_act_act(datetime.date(2010, 1, 1), datetime.date(2010, 1, 1), datetime.date(2010, 1, 1)) == Decimal(0)
    dcfc_act_act(datetime.date(2010, 1, 1), datetime.date(2010, 1, 1), datetime.date(2010, 1, 2)) == Decimal(0)
    dcfc_act_act(datetime.date(2010, 1, 2), datetime.date(2010, 1, 1), datetime.date(2010, 1, 2)) == Decimal(1)
    dcfc_act_act(datetime.date(2010, 1, 1), datetime.date(2011, 1, 1), datetime.date(2010, 1, 1)) == Decimal(0)
    dcf

# Generated at 2022-06-12 06:15:34.602229
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    a = DCC("act/act icma", "act/act icma", _as_ccys({"USD", "EUR", "CAD"}),
            lambda start, asof, end, freq: _get_actual_day_count(start, end) / _get_actual_day_count(start, asof))
    assert a.calculate_fraction(datetime.date(2020,1,1),datetime.date(2020,1,1),datetime.date(2020,1,2)) == Decimal(0)


# Generated at 2022-06-12 06:15:47.841576
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Dates in tests are:
    # - start day = 28th
    # - asof day = 31st
    # - start month = 12th (December)
    # - asof month = 1st (January)
    # - start year = 2007
    # - asof year = 2008
    # result = 0.08333333333333
    assert dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 1, 31),
                         end=datetime.date(2008, 1, 31)) == 0.08333333333333
    # result = 0.08333333333333

# Generated at 2022-06-12 06:19:18.963507
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .currencies import Currencies
    from .monetary import Money

    ## This is the start date:
    start = datetime.date(2019, 9, 20)
    ## This is the end date:
    end = datetime.date(2019, 9, 23)

    ## Check:
    print(
        "f30360_isda.calculate_fraction(start=%s, asof=%s, end=%s, freq=None) == %s" %
        (start, start, end, f30360_isda.calculate_fraction(start, start, end, None))
    )


# Generated at 2022-06-12 06:19:23.704226
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    start, asof = datetime.date(2014, 9, 20), datetime.date(2014, 10, 20)
    year = (asof.year - start.year)
    month = asof.month - start.month
    days = asof.day - start.day
    nod = days + month * 30 + year * 360
    return nod / 360



# Generated at 2022-06-12 06:19:27.848067
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    dcf = dcfc_act_365_a
    assert round(dcf(datetime.date(2007,12,28),datetime.date(2008,2,28),datetime.date(2008,2,28)), 14) == Decimal('0.16986301369863')
    assert round(dcf(datetime.date(2007,12,28),datetime.date(2008,2,29),datetime.date(2008,2,29)), 14) == Decimal('0.17213114754098')
    assert round(dcf(datetime.date(2007,10,31),datetime.date(2008,11,30),datetime.date(2008,11,30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-12 06:19:30.577355
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    
    
    

# Generated at 2022-06-12 06:19:38.584831
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .commons.zeitgeist import Date
    from decimal import Decimal
    from .monetary import Money
    from .currencies import Currencies
    from .currencies import Currency
    USD = Currencies.USD

    def dc30360isda(start: Date, asof: Date, end: Date, freq: Optional[Decimal]=None) -> Decimal:
        '''
        This function implements the actual day count fraction calculation engine for 30/360 ISDA convention and is 
        used by the actual calculation method 'calculate_fraction' of class DCC.
        '''
        ## Checks if dates are provided properly:
        if not start<=asof<=end:
            ## Nope, return 0:
             return ZERO
        
        ## Get the number of months:

# Generated at 2022-06-12 06:19:47.741010
# Unit test for method calculate_fraction of class DCC

# Generated at 2022-06-12 06:19:58.457117
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Test case 1
    start1 = datetime.date(2020, 12, 31)
    asof1 = datetime.date(2021, 1, 1)
    end1 = datetime.date(2021, 1, 31)
    freq1 = Decimal(1)
    expected_result1 = Decimal(1 / 31)
    actual_result1 = _DC.calculate_daily_fraction(start1, asof1, end1, freq1)
    assert actual_result1 == expected_result1
    print(actual_result1)

    # Test case 2
    start2 = datetime.date(2019, 12, 31)
    asof2 = datetime.date(2021, 1, 1)
    end2 = datetime.date(2021, 1, 31)
    freq2 = Dec

# Generated at 2022-06-12 06:20:10.344092
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Unit test for this module.
    """
    assert_equal(
        float(dcfc_30_360_us(datetime.date(2012, 1, 15), datetime.date(2012, 2, 15))),
        0.083333333333333338
    )
    assert_equal(
        float(dcfc_30_360_us(datetime.date(2012, 1, 30), datetime.date(2012, 2, 29))),
        0.083333333333333338
    )
    assert_equal(
        float(dcfc_30_360_us(datetime.date(2012, 1, 1), datetime.date(2012, 2, 29))),
        0.083333333333333338
    )

# Generated at 2022-06-12 06:20:17.640116
# Unit test for method interest of class DCC
def test_DCC_interest():
    m1: Money = Money(10, "EUR")
    m2: Money = Money(6, "EUR")
    dcc: DCC = DCC("30E/360", {"ThirtyE360"}, _as_ccys({"EUR", "USD"}), _dcc_calculate_30e_360)
    assert dcc.interest(m1, 0.03, datetime.date(2017, 1, 1), datetime.date(2017, 12, 31)) == m2
    assert dcc.interest(m1, 0.03, datetime.date(2017, 1, 1), datetime.date(2017, 12, 31), datetime.date(2017, 12, 31)) == m2
