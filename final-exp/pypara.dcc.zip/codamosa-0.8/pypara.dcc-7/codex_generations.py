

# Generated at 2022-06-12 06:11:01.004072
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-12 06:11:13.161320
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = Date(2004, 2, 25)
    asof = Date(2004, 5, 18)
    end = Date(2004, 8, 25)
    dcc = DCC("ACT/ACT", {}, _as_ccys({"USD"}), day_count_act_act)
    assert dcc.calculate_fraction(start, asof, end) == Decimal("0.31034482758620686")
    dcc = DCC("ACT/365", {}, _as_ccys({"USD"}), day_count_act_365)
    assert dcc.calculate_fraction(start, asof, end) == Decimal("0.31034482758620686")

# Generated at 2022-06-12 06:11:23.419387
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies import Currencies
    from .monetary import Money
    from .curves import DCCRegistry
    import datetime

    dcc = DCCRegistry.find_by_name("30/360")
    ccy = Currencies.USD
    principal = Money(1000, ccy)
    rate = Decimal(0.02)
    start = datetime.date(2019, 1, 15)
    end = datetime.date(2019, 2, 15)
    freq = 2

# Generated at 2022-06-12 06:11:36.577892
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ## Start date of period is 31st of a month:
    assert dcfc_30_e_360(start=_d(2019, 1, 31), asof=_d(2019, 3, 1), end=_d(2019, 3, 1)) == 0.0833333333333333
    assert dcfc_30_e_360(start=_d(2019, 1, 31), asof=_d(2019, 3, 30), end=_d(2019, 3, 30)) == 0.291666666666667
    assert dcfc_30_e_360(start=_d(2019, 1, 31), asof=_d(2019, 3, 31), end=_d(2019, 3, 31)) == 0.294444444444444

# Generated at 2022-06-12 06:11:45.517572
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert abs(dcfc_act_act(
        datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) - 0.16942884946478) < 0.00001
    assert abs(dcfc_act_act(
        datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) - 0.17216108990194) < 0.00001
    assert abs(dcfc_act_act(
        datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) - 1.08243131970956) < 0.00001

# Generated at 2022-06-12 06:11:49.820171
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies import CURRENCIES

    for ccy in CURRENCIES:
        for dcc in DCCRegistry.dcc_for(ccy):
            test_DCC_calculate_daily_fraction_for_dcc(dcc)



# Generated at 2022-06-12 06:11:52.281533
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    DCC = DCC(
        name="name",
        altnames=None,
        currencies=None,
        calculate_fraction_method=None)
    print(DCC.calculate_fraction)



# Generated at 2022-06-12 06:12:04.135615
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == round(Decimal('0.16666666666667'), 14))
   

# Generated at 2022-06-12 06:12:07.995753
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    dcc = DCC("name", {"altname"}, {"currency"}, lambda x, y, z, w: Decimal(1))
    assert dcc.coupon(Money(1), Decimal(1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 3), 1) == Money(1)

# Generated at 2022-06-12 06:12:18.969384
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(datetime.date(2014,9,30), datetime.date(2014,12,31), datetime.date(2014,12,31)),14) == round(Decimal('0.25'),14)
    assert round(dcfc_30_360_german(datetime.date(2014,9,30), datetime.date(2015,3,31), datetime.date(2015,3,31)),14) == round(Decimal('0.52777777777778'),14)
    assert round(dcfc_30_360_german(datetime.date(2014,9,30), datetime.date(2015,11,30), datetime.date(2015,11,30)),14) == round(Decimal('1.02777777777778'),14)

# Generated at 2022-06-12 06:12:51.944041
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC('Actual365F',{'Actual/365F'},{Currencies['USD']},DCC.Actual365F(datetime.date(2017, 10, 1),datetime.date(2018, 12, 31),datetime.date(2018, 10, 1),None))
    return dcc.calculate_fraction(datetime.date(2017, 10, 1),datetime.date(2018, 12, 31),datetime.date(2018, 10, 1),None)


# Generated at 2022-06-12 06:13:04.974280
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_e_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')
    assert dcfc

# Generated at 2022-06-12 06:13:09.737411
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Test code:
    start = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 1, 2)
    asof = datetime.date(2014, 1, 2)
    print(DCCRegistry["ACT/360"].calculate_daily_fraction(start, asof, end))
    print(DCCRegistry["30/360"].calculate_daily_fraction(start, asof, end))
    print(DCCRegistry["ACT/365"].calculate_daily_fraction(start, asof, end))
    print(DCCRegistry["ACT/ACT"].calculate_daily_fraction(start, asof, end))
    # Output:
    # 0.002777777777777778
    # 0.0
    #

# Generated at 2022-06-12 06:13:20.654694
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-12 06:13:28.017839
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    nod = (asof.day - start.day) + 30 * (asof.month - start.month) + 360 * (asof.year - start.year)
    dcf = nod / Decimal(360)


# Generated at 2022-06-12 06:13:39.313010
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14)==Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14)==Decimal('1.08333333333333')

# Generated at 2022-06-12 06:13:48.282950
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    # ex1
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    end = ex1_asof
    result = dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=end)
    assert round(result, 14) == round(Decimal('0.16986301369863'), 14)
    # ex2
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    end = ex2_asof
    result = dcfc_nl_365(start=ex2_start, asof=ex2_asof, end=end)

# Generated at 2022-06-12 06:13:59.467096
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=None), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=None), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=None), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-12 06:14:10.631026
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16853776322161')
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17131707317073')
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08036585365854')

# Generated at 2022-06-12 06:14:20.995922
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    # Example 1:
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

    # Example 2:
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17216108990194')

    # Example 3:
    ex3

# Generated at 2022-06-12 06:15:50.393395
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:15:56.018795
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(start = datetime.date(2016,3,21), asof = datetime.date(2016,3,31), end = datetime.date(2016,3,31)) == 1.0
    numpy.testing.assert_almost_equal(dcfc_30_e_plus_360(start = datetime.date(2016,3,21), asof = datetime.date(2016,3,31), end = datetime.date(2016,3,31)), 1.0) 

# Generated at 2022-06-12 06:16:08.687269
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-12 06:16:16.809755
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    npv_expect_dcfc_30_360_german = [0.02777777777777778, 0.02777777777777778, 0.3333333333333334, 0.3333333333333334]
    for i in range(4):
        assert abs(dcfc_30_360_german(**_get_calc_args(i))) - npv_expect_dcfc_30_360_german[i] < _EPSILON


# End Day Counting Conventions


# Start Frequency Calculations



# Generated at 2022-06-12 06:16:21.654170
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert(DCC("ACT360", set(), set(), lambda s, a, e, f : Decimal(1)).coupon(Money(2.0, "USD"), Decimal(0.1),
                                                                              datetime.date(2018, 1, 1),
                                                                              datetime.date(2018, 2, 1))) == \
    Money(0.3, "USD")



# Generated at 2022-06-12 06:16:34.859275
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Calculates the day count fraction accordingly to the 30/360 German convention.
    """

    # Test 1:
    ex1_start = datetime.date(2007, 12, 28)
    ex1_asof = datetime.date(2008, 2, 28)
    ex1_dayCount = dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof)
    assert round(ex1_dayCount, 12) == round(Decimal('0.1666666666666667'), 12)

    # Test 2:
    ex2_start = datetime.date(2007, 12, 28)
    ex2_asof = datetime.date(2008, 2, 29)

# Generated at 2022-06-12 06:16:43.070367
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)


# Generated at 2022-06-12 06:16:50.543880
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')

test_dcfc_act_act_icma()



# Generated at 2022-06-12 06:17:02.432177
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    def test_calc(self, d1, d2, res):
        self.assertEqual(round(dcfc_30_360_isda(start=d1, asof=d1, end=d1), 14), res)
        self.assertEqual(dcfc_30_360_isda(start=d2, asof=d2, end=d2), res)

    d1 = Aug1st = datetime.date(2008, 8, 1)
    d2 = Jan1st = datetime.date(2009, 1, 1)
    test_calc(self=None, d1=d1, d2=d1, res=0.95833333333333)

# Generated at 2022-06-12 06:17:10.558838
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:19:00.673073
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(datetime.date(2020,8,31), datetime.date(2020,9,1), datetime.date(2020,9,1)) == 1/360



# Generated at 2022-06-12 06:19:13.115408
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:19:22.072858
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')

# Generated at 2022-06-12 06:19:28.424495
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert (round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863'))
    assert (round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863'))
    assert (round(dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08219178082192'))

# Generated at 2022-06-12 06:19:36.063018
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 12, 30), datetime.date(2018, 1, 1)) == 1
    assert DCCRegistry["ACT/ACT"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 12, 30), datetime.date(2018, 1, 1)) == 365


# Generated at 2022-06-12 06:19:46.762181
# Unit test for method interest of class DCC
def test_DCC_interest():
    principal = 100
    rate = 0.5
    start = datetime.date(day=12, month=5, year=2019)
    asof = datetime.date(day=15, month=5, year=2019)
    end = datetime.date(day=20, month=5, year=2019)
    freq = 12

    actual_result = DCC_ACT_360.interest(principal, rate, start, asof, end, freq)
    expected_result = principal * rate * DCC_ACT_360.calculate_fraction(start, asof, end, freq)

    assert actual_result == expected_result, 'Actual Result: {}, Expected Result: {}'.format(actual_result, expected_result)

# Generated at 2022-06-12 06:19:56.626603
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Setup
    d = datetime.date(2020,7,14)
    sd = datetime.date(2021,1,1)
    f = datetime.date(2021,7,1)
    r = relativedelta(d, f)
    d1 = r.days
    d2 = r.months
    t = d1 / 360
    p = principal.amount
    # Exercise
    test_DCC_calculate_fraction = DCC.calculate_fraction(d1, d2, t, p)
    # Verify
    assert test_DCC_calculate_fraction.calculate_fraction == 20.55


# Generated at 2022-06-12 06:20:04.503361
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(datetime.date(2013, 12, 31), datetime.date(2014, 2, 28), None), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_360(datetime.date(2013, 12, 31), datetime.date(2014, 2, 28), None), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_360(datetime.date(2013, 12, 31), datetime.date(2014, 2, 28), None), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-12 06:20:13.630293
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC("ACT/365", set(), set(), lambda s, a, e, f: Decimal(_get_actual_day_count(s, e)) / Decimal(365))
    result = dcc.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1))
    expected = Decimal("0")
    assert result == expected
    result = dcc.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2))
    expected = Decimal("1") / Decimal("365")
    assert result == expected

# Generated at 2022-06-12 06:20:21.473189
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC._make(('test_day_count_convention', {'test', 'test_name'}, {Currencies['USD']},
                      lambda start, asof, end, freq: Decimal(0))).coupon(Money(0, Currencies['USD']), Decimal(0), Date(2000, 1, 1),
                                                                         Date(2000, 1, 1), Date(2000, 1, 1), int(0), None) == Money(0, Currencies['USD'])

