

# Generated at 2022-06-12 06:11:06.524246
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-12 06:11:19.064881
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:11:22.331491
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    import doctest
    doctest.testmod()
if __name__ == "__main__":
    test_dcfc_30_e_360()


# Generated at 2022-06-12 06:11:35.368084
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    _assert_close(
        dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)),
        0.16666666666667
    )
    _assert_close(
        dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)),
        0.16944444444444
    )
    _assert_close(
        dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)),
        1.08333333333333
    )
    _assert_close

# Generated at 2022-06-12 06:11:39.728923
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex1_out = round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-12 06:11:51.145135
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # NZD 30/360
    dcc = DCC(
        'NZD 30/360',
        {'ACT/365', 'ACT/360'},
        {Currencies['NZD'], Currencies['AUD']},
        lambda start, asof, end, freq: Decimal(360) * _get_actual_day_count(asof, end) / Decimal(360)
    )
    assert dcc.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal(0)

# Generated at 2022-06-12 06:11:56.087602
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    print("Testing DCC.coupon ... ", end="")

    ## Cases:

# Generated at 2022-06-12 06:12:06.717209
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    """
    Unit test for function dcfc_30_360_isda
    """
    print("Testing function dcfc_30_360_isda")


# Generated at 2022-06-12 06:12:16.193035
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    from finrisk import QC_3927
    from scipy.stats import norm
    import matplotlib.pyplot as plt

    # pick the model parameters
    sigma = 0.2
    a = 0.5
    # pick the model parameters
    sigma = 0.2
    a = 0.5
    # pick the number of days to simulate
    ndays = 365 * 5
    # compute the Lévy measure
    levy_measure = QC_3927(sigma, a)
    # draw the Lévy measure
    xmin = -0.5
    xmax = 2.5
    npoints = 500
    xvalues = np.linspace(xmin, xmax, npoints)
    yvalues = levy_measure.pdf(xvalues)
    # draw the sample paths
    npaths = 100

# Generated at 2022-06-12 06:12:27.968340
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:13:34.536227
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start= datetime.date(2007, 12, 28), asof= datetime.date(2008, 2, 28), end= datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start= datetime.date(2007, 12, 28), asof= datetime.date(2008, 2, 29), end= datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start= datetime.date(2007, 10, 31), asof= datetime.date(2008, 11, 30), end= datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:13:46.173485
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-12 06:13:55.273226
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_360_

# Generated at 2022-06-12 06:14:07.005461
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Unit test for function "dcfc_30_360_us".
    """
    ## Prices:
    assert isclose(dcfc_30_360_us(datetime.date(2017, 11, 30), datetime.date(2018, 4, 15), datetime.date(2018, 4, 15)), Decimal(0.1527777777777778), abs_tol=eps)

    ## Returns:
    assert isclose(dcfc_30_360_us(datetime.date(2017, 11, 30), datetime.date(2018, 4, 15), datetime.date(2018, 5, 15)), Decimal(0.0472222222222222), abs_tol=eps)



# Generated at 2022-06-12 06:14:18.211133
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dates = [
        datetime.date(2008, 4, 16),
        datetime.date(2008, 5, 26),
        datetime.date(2008, 6, 10),
        datetime.date(2008, 6, 26),
        datetime.date(2008, 7, 5),
        datetime.date(2008, 7, 14),
        datetime.date(2008, 8, 9),
        datetime.date(2008, 9, 17),
        datetime.date(2008, 10, 16),
        datetime.date(2008, 11, 20),
        datetime.date(2009, 8, 20),
        datetime.date(2009, 10, 20),
        datetime.date(2009, 11, 30),
    ]

# Generated at 2022-06-12 06:14:25.056445
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal=Money(100, "EUR")
    rate=0.05
    start=Date(1,2,2017)
    asof=Date(1,5,2017)
    end=Date(1,7,2017)
    freq=1
    eom=None
    DCC=DCC()
    assert DCC.coupon(principal, rate, start, asof, end, freq, eom)==Money(1.25,"EUR")



# Generated at 2022-06-12 06:14:36.469932
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for the method 'calculate_daily_fraction' of class 'DCC'.
    """
    def _test_DCC_calculate_daily_fraction(dcc: DCC, start: Date, asof: Date, end: Date, expected: Decimal):
        """
        Tests the method 'calculate_daily_fraction' of class 'DCC'
        """
        fraction = dcc.calculate_daily_fraction(start, asof, end)
        #print(dcc.name, start, asof, end, fraction, expected)
        assert fraction == expected, "Expected {0} but got {1}".format(expected, fraction)


# Generated at 2022-06-12 06:14:43.079599
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Performs unit tests for function dcfc_30_360_german().
    """
    funcs = [dcfc_30_360_german]
    convention = "30/360 German"

    ## German:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    ex

# Generated at 2022-06-12 06:14:50.122963
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-12 06:15:01.186076
# Unit test for method interest of class DCC
def test_DCC_interest():
    """

    >>> test_DCC_interest()
    True
    """

# Generated at 2022-06-12 06:15:47.979373
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    date1 = datetime.date(2016, 10, 10)
    date2 = datetime.date(2017, 1, 1)
    date3 = datetime.date(2017, 3, 3)
    date4 = datetime.date(2017, 12, 12)

    dcc = DCC(
        "act/act",
        {},
        {Currencies["USD"], Currencies["EUR"], Currencies["RUB"]},
        lambda start, asof, end, freq: Decimal(
            _get_actual_day_count(asof, end) / _get_actual_day_count(start, end)
        ),
    )
    assert dcc.calculate_fraction(date1, date2, date4, None) == Decimal("0.22758620689655172")


# Generated at 2022-06-12 06:15:53.428523
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(datetime.date(2016, 1, 15), datetime.date(2016, 1, 15), datetime.date(2016, 1, 15)) == 0
    assert dcfc_30_360_us(datetime.date(2016, 1, 15), datetime.date(2016, 1, 29), datetime.date(2016, 1, 29)) == 0.166666666666667
    assert dcfc_30_360_us(datetime.date(2016, 2, 29), datetime.date(2016, 3, 31), datetime.date(2016, 3, 31)) == 0.166666666666667
    assert dcfc_30_360_us(datetime.date(2016, 1, 30), datetime.date(2016, 3, 31), datetime.date(2016, 3, 31))

# Generated at 2022-06-12 06:16:05.570703
# Unit test for method interest of class DCC
def test_DCC_interest():
    currency = Currencies["USD"]
    principal = Money(amount=100, currency=currency)
    rate = Decimal(0.05)
    start = Date(datetime.date(2017, 1, 1))
    asof = Date(datetime.date(2017, 1, 7))
    end = Date(datetime.date(2017, 4, 1))
    freq = Decimal(0.25)
    model = DCC("NAME", set(), set(), lambda x,y,z,a: (z-y)/(z-x))
    assert model.interest(principal, rate, start, asof, end, freq) == Money(amount=2.5, currency=currency)
    assert model.interest(principal, rate, start, asof, end) == Money(amount=1.25, currency=currency)


# Generated at 2022-06-12 06:16:16.860404
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), 
                                end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29),
                                end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-12 06:16:22.786065
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc = DCC(
        "name",
        {"name", "altname"},
        {"USD"},
        lambda start, asof, end, freq: Decimal(2),
    )
    result = dcc.calculate_daily_fraction(
        datetime.date(2017, 1, 1),
        datetime.date(2017, 1, 2),
        datetime.date(2017, 1, 3),
    )
    assert result == Decimal(1)



# Generated at 2022-06-12 06:16:36.108506
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-12 06:16:43.858711
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert (DCCRegistry['30E/360ISDA'].calculate_daily_fraction(
        datetime.date(2017, 1, 1),
        datetime.date(2017, 1, 2),
        datetime.date(2017, 1, 31),
    ) == Decimal(1) / Decimal(30))
    assert (DCCRegistry['30E/360ISDA'].calculate_daily_fraction(
        datetime.date(2017, 1, 1),
        datetime.date(2017, 1, 1),
        datetime.date(2017, 1, 31),
    ) == Decimal(0))

# Generated at 2022-06-12 06:16:51.332864
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for the DCC (NamedTuple) DCC.calculate_daily_fraction method.
    """
    ## Create a DCC instance for testing:
    dcc = DCC(name='act/360',
              altnames=set(),
              currencies=set(),
              calculate_fraction_method=_ACT360_DCF.calculate_fraction)

    ## Run a test case:
    assert dcc.calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 5),
                                        None) == Decimal('0.002777777777777778')



# Generated at 2022-06-12 06:17:01.001236
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc = DCC(
        name="30E/360",
        altnames={"30E_360"},
        currencies=set(),
        calculate_fraction_method=calculate_30e360_fraction,
    )
    # Expected: 1/360
    start = Date(2018, 8, 17)
    asof = Date(2018, 8, 18)
    end = Date(2018, 12, 31)
    freq = Decimal(4)
    assert dcc.calculate_daily_fraction(start, asof, end, freq) == Decimal("0.002777777777777778")

# Generated at 2022-06-12 06:17:09.759012
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    '''
    Check the function calculate_fraction of DCC.

    :return: A boolean value if test passes otherwise a sample of failed data.
    :rtype: bool
    '''
    ## This test covers the following days count conventions:

# Generated at 2022-06-12 06:17:37.102323
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    
        # Check if returns 0.0 if dates are provided improperly.
    assert DCC("test",{"test"},{Currencies['TRY']},lambda x,y,z,q:ONE).calculate_fraction(datetime.date(2017,1,1),datetime.date(2016,1,1),datetime.date(2016,1,1))==ZERO
    assert DCC("test",{"test"},{Currencies['TRY']},lambda x,y,z,q:ONE).calculate_fraction(datetime.date(2017,1,1),datetime.date(2017,1,1),datetime.date(2017,1,2))==ONE


    

# Generated at 2022-06-12 06:17:48.725293
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert_equals(round(dcfc_30_360_isda(ex1_start, ex1_asof, ex1_asof), 14), Decimal('0.16666666666667'))

# Generated at 2022-06-12 06:17:55.511110
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Test for dcfc_30_360_german
    """
    assert dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == 0.16666666666667
    assert dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) == 0.16944444444444
    assert dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)) == 1

# Generated at 2022-06-12 06:18:02.748427
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    A = datetime.date(day = 1, month = 1, year = 2000)
    B = datetime.date(day = 31, month = 1, year = 2000)
    return DCC("act_act_isda", {"act_act_isda"}, _as_ccys({"USD"}), act_act_isda).calculate_fraction(A, B, B)


# Generated at 2022-06-12 06:18:12.223442
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    """
    Test case for the function dcfc_30_e_plus_360.
    """
    # Test case #1:
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 2, 28)
    expected = Decimal('0.16666666666667')
    result = dcfc_30_e_plus_360(start=start, asof=asof, end=end)
    assert(result == expected)

    # Test case #2:
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)
    end = datetime.date(2008, 2, 29)

# Generated at 2022-06-12 06:18:17.191739
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:18:25.010897
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """Test function dcfc_30_360_us
    """
    ## Test data:
    test_data = [(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), 0.166666666666667),
                 (datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), 0.169444444444444),
                 (datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), 1.08333333333333),
                 (datetime.date(2008, 2, 1), datetime.date(2009, 5, 31), 1.33333333333333)]

    ## Verify results:

# Generated at 2022-06-12 06:18:35.931383
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Validate that the daily fraction is correctly calculated
    """

    ## Set up the parameters:
    dcc = DCC(
        name='Actual/360',
        altnames=set(),
        currencies=_as_ccys({'USD'}),
        calculate_fraction_method=actual360
    )

    ## Run the test:
    assert dcc.calculate_daily_fraction(datetime.date(2018,4,10),datetime.date(2018,4,30),datetime.date(2018,5,10) ) == Decimal(20) / Decimal(360)

# Generated at 2022-06-12 06:18:47.371154
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    dcc_1 = DCC('_ACT/360', frozenset(), frozenset(), lambda s, a, e, f: Decimal((a - s).days) / Decimal(360))
    dcc_2 = DCC('_ACT/365', frozenset(), frozenset(), lambda s, a, e, f: Decimal((a - s).days) / Decimal(365))
    dcc_3 = DCC('_30/360', frozenset(), frozenset(), lambda s, a, e, f: Decimal((a - s).days) / Decimal(360))
    start_date = datetime.date(2020,1,1)
    asof_date = datetime.date(2020,3,1)

# Generated at 2022-06-12 06:18:51.850981
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """ """
    assert round(dcfc_30_360_us(datetime.date(2020, 5, 1), datetime.date(2020, 5, 15), datetime.date(2020, 6, 15)), 14) == Decimal("0.14583333333333")
    assert round(dcfc_30_360_us(datetime.date(2020, 5, 1), datetime.date(2020, 5, 15), datetime.date(2020, 6, 30)), 14) == Decimal("0.28472222222222")
    assert round(dcfc_30_360_us(datetime.date(2020, 5, 1), datetime.date(2020, 5, 15), datetime.date(2020, 7, 15)), 14) == Decimal("0.43055555555556")

# Generated at 2022-06-12 06:20:06.433372
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # A couple of test cases:
    ex1 = dcfc_30_360_isda(datetime.date(2007,11,30), datetime.date(2008,11,30), datetime.date(2008,11,30), )
    ex2 = dcfc_30_360_isda(datetime.date(2008,12,31), datetime.date(2012,12,31), datetime.date(2012,12,31), )
    ex3 = dcfc_30_360_isda(datetime.date(2007,12,31), datetime.date(2008,1,31), datetime.date(2008,1,31), )

# Generated at 2022-06-12 06:20:16.683873
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCCRegistry["30/360"].interest(Money(10, "USD"), Decimal(1), datetime.date(2017, 1, 1), datetime.date(2017, 2, 1)) == Money(0.0833333333333333, "USD")
    assert DCCRegistry["30/360 US"].interest(Money(100, "USD"), Decimal(1), datetime.date(2017, 1, 1), datetime.date(2017, 2, 1)) == Money(0.0833333333333333, "USD")
    assert DCCRegistry["30E/360"].interest(Money(10, "USD"), Decimal(1), datetime.date(2017, 1, 1), datetime.date(2017, 2, 1)) == Money(0.0833333333333333, "USD")