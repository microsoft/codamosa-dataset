

# Generated at 2022-06-12 06:11:04.278672
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:11:09.240730
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    start = Date(2020, 1, 1)
    end = Date(2020, 3, 1)
    asof = Date(2020, 2, 10)
    dcc = DCCRegistry.registry[0]
    assert(dcc.calculate_fraction(start, asof, end)== Decimal("0.547945205479452"))


# Generated at 2022-06-12 06:11:20.246570
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies import Currencies
    from .enums import DCCType
    from .daycounts import DCCRegistry
    from .monetary import Money
    from .schedule import Schedule
    dcc = DCCRegistry[DCCType.ACT_360]
    principal = Money(100, Currencies.USD)
    rate = Decimal('0.1')
    start = Date(2000, 1, 1)
    asof = Date(2000, 1, 1)
    end = Date(2000, 6, 1)
    freq = Decimal(1)
    result = dcc.calculate_daily_fraction(start, asof, end, freq)
    assert result == Decimal('0.0002777777777777777777777777777778')

# Generated at 2022-06-12 06:11:28.112422
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    # Prepare an item
    item_name = "MyTestDCC"
    item_altnames = {"MYTESTDCC", "MYTEST", "TEST"}
    item_currencies = {"USD", "TRY"}
    item_calculate_fraction_method = lambda start, asof, end, freq: Decimal(0)
    item = DCC(item_name, item_altnames, item_currencies, item_calculate_fraction_method)

    # A registry instance
    registry = DCCRegistryMachinery()

    # Register the item
    registry.register(item)

    # Find item by its name
    assert registry.table[item_name] == item

    # Find item by its alternative names
    for altname in item_altnames:
        assert registry.table[altname] == item


# Generated at 2022-06-12 06:11:40.017131
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383'))

# Generated at 2022-06-12 06:11:51.384563
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:11:55.342148
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    from utils import test_func
    test_func(dcfc_30_360_us, "dcfc_30_360_us", dc_30_360_us)



# Generated at 2022-06-12 06:12:03.221417
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC("AF", {"name1", "name2"}, {}, _act_act_isda)
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 3, 31)
    end = datetime.date(2017, 6, 30)
    freq = None
    assert dcc.calculate_fraction(start, asof, end) == Decimal('0.222891566265060240963855421686747')

# Generated at 2022-06-12 06:12:11.480909
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    ## Arrange:
    #   Empty registry
    r = DCCRegistryMachinery()

    ## Act:
    #   Try to find a DCC with name = "Foo"
    d = r.find("Foo")

    ## Assert:
    assert d == None

    ## Arrange:
    #   Registering a DCC with name = "Foo"
    r.register(DCC("Foo", set(["Bar"]), set([]), _actact_method))

    ## Act:
    #   Try to find a DCC with name = "Foo"
    d = r.find("Foo")

    ## Assert:
    assert d.name == "Foo"

    ## Act:
    #   Try to find a DCC with name = "Bar"
    d = r.find("Bar")



# Generated at 2022-06-12 06:12:23.858812
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Data
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    ex1_result = round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-12 06:12:43.286689
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc = DCC(
        "Bond Basis",
        set(),
        set(),
        calculate_fraction_method=lambda s, a, e, f : 1
    )

    ## Test:
    #  AsOfDate:    [   ]      [   ]      [   ]      [   ]      [   ]      [   ]      [   ]      [   ]      [   ]
    #  StartDate:   [   ]      [   ]      [   ]      [   ]      [   ]      [   ]      [   ]      [   ]      [   ]
    #  EndDate:     [   ]      [   ]      [   ]      [   ]      [   ]      [   ]      [   ]      [   ]      [   ]
    #  Freq:        [   ]      [   ]      [   ]

# Generated at 2022-06-12 06:12:55.911129
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-12 06:13:03.878317
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    dcc = DCC('name', {'AN'}, {Currencies['EUR']}, DCF_ACT_360)
    assert dcc.coupon(Money(1000, Currencies['EUR']), 0.04, datetime.date(2018, 1, 1), datetime.date(2018, 1, 1),
                      datetime.date(2018, 1, 1), 1) == Money(2.7778, Currencies['EUR'])



# Generated at 2022-06-12 06:13:12.806481
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_360_german(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-12 06:13:19.362704
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(datetime.date(2015, 2, 4), datetime.date(2015, 2, 4), datetime.date(2015, 2, 4)), 14) == \
        Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(datetime.date(2015, 2, 4), datetime.date(2015, 2, 5), datetime.date(2015, 2, 5)), 14) == \
        Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(datetime.date(2015, 2, 4), datetime.date(2015, 2, 6), datetime.date(2015, 2, 6)), 14) == \
        Decimal('0.16666666666667')

# Generated at 2022-06-12 06:13:32.475624
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry.get_dcc('ACT/360').calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 3, 31), datetime.date(2017, 3, 31)) == Decimal(90).quantize(Decimal('.01'))
    assert DCCRegistry.get_dcc('ACT/360').calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 4, 1), datetime.date(2017, 3, 31)) == Decimal(90).quantize(Decimal('.01'))

# Generated at 2022-06-12 06:13:39.925401
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCRegistry['ACT/360'].coupon(Money(1, "USD"), Decimal('0.075'), datetime.date(2010, 1, 6), datetime.date(2010, 4, 6), freq=Decimal('2'), eom=30).value == Decimal('0.2234567901234568')



# Generated at 2022-06-12 06:13:45.014241
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    print ( "----test_DCC_coupon()----")
    print ( "test1")
    print ( "test2")
    print ( "test3")
    print ( "test4")
    print ( "test5")
    print ( "test6")
    print ( "test7")
    print ( "test8")
    print ( "test9")



# Generated at 2022-06-12 06:13:55.786085
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    '''
    DCC.calculate_daily_fraction method
    '''
    from dateutil.relativedelta import relativedelta
    from .currencies import Currencies as currencies
    # create dummy dates
    start = datetime.date.today() + relativedelta(days=-3)
    asof = datetime.date.today()
    end = datetime.date.today() + relativedelta(days=+3)
    # create dummy frequency
    freq = Decimal(0.5)
    # create dummy day count convention
    dcc = DCC(
        name='Dummy Day Count Convention',
        altnames=set(),
        currencies=set(),
        calculate_fraction_method=calculate_DCC_fraction,
    )
    # calculate daily fraction
    daily_fraction = dcc

# Generated at 2022-06-12 06:14:00.348980
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    a = DCC(name='b', altnames={}, currencies=_as_ccys({}), calculate_fraction_method=None)
    assert a.calculate_daily_fraction(None, None, None) == 0



# Generated at 2022-06-12 06:14:28.695828
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    DCCRegistry.register(
        DCC(
            "Annual",
            {"annually", "annual", "ANNUALLY", "ANNUAL"},
            {Currencies["USD"]},
            _annual
        )
    )
    DCCRegistry.register(
        DCC(
            "Actual/Actual",
            {"act/act", "actual/actual", "actual/365", "actual/365fixed", "Act/Act", "ACT/ACT"},
            {Currencies["EUR"]},
            _actact
        )
    )
    assert DCCRegistry.find("ACT/ACT") is not None
    assert DCCRegistry.find("Act/Act") is not None

# Generated at 2022-06-12 06:14:34.384404
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    start_date = datetime.date(2017, 1, 1)
    asof_date = datetime.date(2017, 1, 2)
    end_date = datetime.date(2017, 2, 1)
    frequency = 1

    dcc_name = "Actual/360"

    assert DCCRegistry[dcc_name].calculate_daily_fraction(start_date, asof_date, end_date, frequency) == 0.002777777777777778



# Generated at 2022-06-12 06:14:41.779032
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-12 06:14:51.496644
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # test data
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:15:01.896329
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    # 1. -----------------------------
    name = 'ISMA-30/360'
    # 1.1. create an instance of DCCRegistryMachinery:
    dccrm = DCCRegistryMachinery()
    # 1.2. register two dccs:
    dcc1 = DCC(name='ISMA-30/360', altnames={"ISM-30/360", "ACT/360", "ACT/ACT", "ISDA"}, currencies={"GBP, EUR"}, calculate_fraction_method=calculate_fraction_method)
    dccrm.register(dcc1)

# Generated at 2022-06-12 06:15:08.532864
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCC(
        name='Act/365',
        altnames={'Act/365.F', 'A/365F', 'A/365'},
        currencies={},
        calculate_fraction_method=_act_act_fraction,
    )
    dccreg = DCCRegistryMachinery()
    dccreg.register(dcc)
    assert dccreg._buffer_main == {'Act/365': dcc}
    assert dccreg._buffer_altn == {'Act/365.F': dcc, 'A/365F': dcc, 'A/365': dcc}



# Generated at 2022-06-12 06:15:15.194866
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    print("TEST: test_DCCRegistryMachinery_register")
    m = DCCRegistryMachinery()
    m.register(DCC("30E/360", {"30E/360", "30/360"}))
    assert m.find("30E/360")

    # Test the TypeError
    try:
        m.register(DCC("30E/360", {"30E/360", "30/360"}))
    except TypeError as te:
        assert "is already registered" in str(te)



# Generated at 2022-06-12 06:15:25.233139
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end, freq=Decimal(2)), 10) == Decimal('0.26229508194')



# Generated at 2022-06-12 06:15:36.401061
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == round(Decimal(0.16666666666667), 14)
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == round(Decimal(0.16944444444444), 14)

# Generated at 2022-06-12 06:15:41.924317
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Tests the method calculate_fraction of class DCC
    """
    start = datetime.date(2017, 2, 1)
    asof = datetime.date(2017, 2, 1)
    end = datetime.date(2017, 2, 1)
    freq = None
    from .daycount import DCCRegistry
    result = DCCRegistry["ACT/360"].calculate_fraction(start, asof, end, freq)
    assert result == 1.0
    assert isinstance(result, Decimal)

    start = datetime.date(2017, 2, 1)
    asof = datetime.date(2017, 2, 2)
    end = datetime.date(2017, 2, 2)
    freq = None
    from .daycount import DCCRegistry
    result = D

# Generated at 2022-06-12 06:16:29.131440
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007,12,28), datetime.date(2008,2,28)
    ex2_start, ex2_asof = datetime.date(2007,12,28), datetime.date(2008,2,29)
    ex3_start, ex3_asof = datetime.date(2007,10,31), datetime.date(2008,11,30)
    ex4_start, ex4_asof = datetime.date(2008,2,1), datetime.date(2009,5,31)
    ex1 = round(dcfc_30_360_german(start=ex1_start,asof=ex1_asof,end=ex1_asof),14)

# Generated at 2022-06-12 06:16:36.545721
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Arrange
    dcc = DCCRegistry['ACT/ACT']
    start = datetime.date(2014, 1, 1)
    end = datetime.date(2016, 1, 1)
    asof = datetime.date(2016, 1, 1)

    # Act
    actual = dcc.calculate_daily_fraction(start, asof, end, freq=1)

    # Assert
    assert actual == 0.5



# Generated at 2022-06-12 06:16:44.071329
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Tests the day count fraction calculation method method.
    """

    ## Create a test day count convention:
    dcc = DCC(
        "ACTUAL/365 FIXED",
        {"30E/360", "30/360", "30/360 ISDA", "BOND BASIS", "BOND BASIS US", "DUTCH"},
        _as_ccys({"EUR", "USD", "CHF", "GBP"}),
        lambda start, asof, end, freq: Decimal(_get_actual_day_count(start, end) / 365.0)
    )

    ## Run some tests:
    assert dcc.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 4, 4), datetime.date(2017, 4, 4)) == 0
   

# Generated at 2022-06-12 06:16:46.908423
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = Date(2017, 10, 18)
    asof = Date(2017, 10, 21)
    end = Date(2017, 10, 21)
    freq = 1

    result = DCC.calculate_fraction(start, asof, end, freq)

    assert result == Decimal(3)

# Generated at 2022-06-12 06:16:55.835501
# Unit test for method interest of class DCC
def test_DCC_interest():
    r_in = 0.1
    pr_in = Money(1000,Currencies.USD)
    s_in = Date(2020, 1, 1)
    a_in = Date(2020, 1, 7)
    e_in = Date(2020, 1, 31)
    f_in = Decimal(12)
    c_in = Decimal(1)
    a_out = Money(0.2, Currencies.USD)
    a_result = DCC.interest(r_in,pr_in,s_in,a_in,e_in,f_in,c_in)
    assert a_out == a_result



# Generated at 2022-06-12 06:17:04.432918
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC(name='30/360 ISDA', altnames=set(), currencies=set(), calculate_fraction_method=DCCRegistry.dcc_30_360_isda)
    print(dcc.calculate_fraction(datetime.date(2016,1,1), datetime.date(2016,1,1), datetime.date(2016,6,30)))
    print(dcc.calculate_fraction(datetime.date(2017,11,1), datetime.date(2018,1,1), datetime.date(2018,5,31)))

# Generated at 2022-06-12 06:17:11.598023
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    day_count_convention_altnames = ['Actual/Actual', 'Actual/Actual (NAB)', 'Act/Act (ISDA)', 'Act/Act', 'actual/actual']
    day_count_convention = DCC(
        name='Actual/Actual',
        altnames=day_count_convention_altnames,
        currencies=set(),
        calculate_fraction_method=dc.actual_actual,
    )
    dccRegistry = DCCRegistry()
    dccRegistry.register(day_count_convention)
    assert  dccRegistry.find('Actual/Actual') is not None
    assert  dccRegistry.find('Act/Act') is not None
    assert  dccRegistry.find('Act/Act (ISDA)') is not None
#

# Generated at 2022-06-12 06:17:18.530225
# Unit test for function dcfc_30_360_german

# Generated at 2022-06-12 06:17:27.831013
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Tests ``DCC.coupon`` method.
    """
    assert (
        DCCs[30360][45].coupon(Money(100, "USD"), Decimal("0.1"), datetime.date(2020, 5, 1), datetime.date(2020, 7, 30), datetime.date(2020, 10, 1), Decimal(2))
        == Money(7.5, "USD")
    )
    assert (
        DCCs[30360][45].coupon(Money(100, "USD"), Decimal("0.1"), datetime.date(2020, 5, 1), datetime.date(2020, 5, 15), datetime.date(2020, 8, 1), Decimal(2))
        == Money(2.5, "USD")
    )

# Generated at 2022-06-12 06:17:38.656755
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Test 0
    dcc = DCC(name = "test_dcc1", altnames = None, currencies = None, calculate_fraction_method = None)
    assert dcc.calculate_fraction(datetime.date(2019,1,1), datetime.date(2019,11,1), datetime.date(2019,12,31), None) == Decimal('0.901639344262295') 

    # Test 1
    assert dcc.calculate_fraction(datetime.date(2019,1,1), datetime.date(2019,1,1), datetime.date(2019,1,1), Decimal('1')) == Decimal('0.0') 

    # Test 2

# Generated at 2022-06-12 06:19:07.012528
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    test_start1, test_asof1, test_end1 = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    test_start2, test_asof2, test_end2 = datetime.date(2019, 5, 31), datetime.date(2019, 8, 30), datetime.date(2020, 5, 31)
    assert dcfc_act_act_icma(start=test_start1, asof=test_asof1, end=test_end1) == Decimal('0.524590163934426')

# Generated at 2022-06-12 06:19:18.014589
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:19:25.505044
# Unit test for function dcfc_30_360_us

# Generated at 2022-06-12 06:19:36.958201
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert [ dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, i, 28)) == 0.08333333333333333333333333333333 for i in range(1, 13) ]
    assert [ dcfc_30_360_us(datetime.date(2008, 12, 31), datetime.date(2009, i, 28)) == 0.08333333333333333333333333333333 for i in range(1, 13) ]
    assert [ dcfc_30_360_us(datetime.date(2009, 12, 31), datetime.date(2010, i, 30)) == 0.08333333333333333333333333333333 for i in range(1, 13) ]

# Generated at 2022-06-12 06:19:46.655172
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start=datetime.date(2020,3,1)
    end=datetime.date(2021,3,1)
    asof=datetime.date(2020,12,1)

    start=datetime.date(2000,1,1)
    end=datetime.date(2020,1,1)
    asof=datetime.date(2020,1,1)

    dc=DCCRegistry["ACT/365"]

    print(type(dc))
    print(type(dc.calculate_fraction_method))
    result=dc.calculate_fraction_method(start,asof,end)
    print(type(result),result)


# Generated at 2022-06-12 06:19:57.934784
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==Decimal('0.16666666666667'))

# Generated at 2022-06-12 06:20:05.952515
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end),10) == Decimal('0.5245901639')

# Generated at 2022-06-12 06:20:13.395890
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')


# Generated at 2022-06-12 06:20:20.637747
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start_date = datetime.date(2012,12,1)
    asof_date = datetime.date(2012,12,31)
    end_date = datetime.date(2013,1,1)
    for day_count_convention in DCCRegistry.get_all():
        print(day_count_convention)
        print(day_count_convention.calculate_fraction(start_date,asof_date,end_date))