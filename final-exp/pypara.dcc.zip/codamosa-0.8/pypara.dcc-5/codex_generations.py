

# Generated at 2022-06-12 06:11:23.648642
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    d_1 = datetime.date(2008, 5, 30)
    d_2 = datetime.date(2008, 6, 30)
    print(dcfc_30_e_360(d_1, d_2))

if __name__ == '__main__':
    test_dcfc_30_e_360()


# Generated at 2022-06-12 06:11:36.735572
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(date(2007,12,28), date(2008,2,28)) == Decimal('0.16666666666667')
    assert dcfc_30_e_plus_360(date(2007,12,28), date(2008,2,29)) == Decimal('0.16944444444444')
    assert dcfc_30_e_plus_360(date(2007,10,31), date(2008,11,30)) == Decimal('1.08333333333333')
    assert dcfc_30_e_plus_360(date(2008,2,1), date(2009,5,31)) == Decimal('1.33333333333333')



# Generated at 2022-06-12 06:11:37.937264
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    pass


# Generated at 2022-06-12 06:11:47.111313
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667'), "ERROR function dcfc_30_e_360"
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444'), "ERROR function dcfc_30_e_360"

# Generated at 2022-06-12 06:11:59.929890
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # Set up test cases:
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    expected = Decimal('0.16666666666667')
    # Do the actual test:
    actual = dcfc_30_360_isda(start, asof, asof)
    # Check if expected and actual don't differ:
    assert almostequal(expected, actual, places=14)
    # Create a new test case, where the asof date is changed to the 29th of February (leap year):
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)
    expected = Decimal('0.16944444444444')
    # Do the actual test:
    actual = dcfc_

# Generated at 2022-06-12 06:12:06.990619
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2019, 1, 1)
    asof = datetime.date(2019, 1, 30)
    end = datetime.date(2019, 2, 1)
    assert DCC(
        name="test_DCC_calculate_fraction", 
        altnames={}, 
        currencies=set(), 
        calculate_fraction_method=lambda start, asof, end, freq: Decimal("19")).calculate_fraction(start, asof, end) == Decimal("19")
test_DCC_calculate_fraction()



# Generated at 2022-06-12 06:12:13.097476
# Unit test for method interest of class DCC
def test_DCC_interest():
    dcc = DCC('Actual', {'A', 'Actual'}, {Currencies['TRY'], Currencies['USD']}, _actual_365_method)

    assert dcc.interest(Money(1, 'USD'), 0.1, datetime.date(2018, 5, 1), datetime.date(2018, 5, 1)) == Money(0, 'USD')
    assert dcc.interest(Money(1, 'USD'), 0.1, datetime.date(2018, 5, 1), datetime.date(2018, 5, 2)) == Money(0.1, 'USD')


# Generated at 2022-06-12 06:12:25.976572
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_360_us

# Generated at 2022-06-12 06:12:33.143309
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-12 06:12:36.870551
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert 0.166666666666667 == dcfc_30_e_plus_360(start=start, asof=asof, end=end)



# Generated at 2022-06-12 06:13:03.412484
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2007, 12, 28), end=datetime.date(2007, 12, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc

# Generated at 2022-06-12 06:13:12.650317
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28),
                                    asof=datetime.date(2008, 2, 28),
                                    end=datetime.date(2008, 2, 28)),
                 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28),
                                    asof=datetime.date(2008, 2, 29),
                                    end=datetime.date(2008, 2, 29)),
                 14) == Decimal('0.16944444444444')

# Generated at 2022-06-12 06:13:19.206809
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert(round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) ==  Decimal('0.16666666666667'))
    assert(round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) ==  Decimal('0.16944444444444'))

# Generated at 2022-06-12 06:13:32.436455
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    import datetime
    #  Date 1:
    d1 = datetime.date(2009, 12, 2)
    #  Date 2:
    d2 = datetime.date(2010, 2, 28)
    #  Day count fraction:
    dcf = dcfc_30_e_360(start=d1, asof=d2, end=None)
    #  Check that dcf is equal to 0.08333333333333333:
    assert( dcf == 0.08333333333333333 )
    #  d2 = datetime.date(2010, 12, 2)
    d2 = datetime.date(2010, 12, 2)
    #  Day count fraction:
    dcf = dcfc_30_e_360(start=d1, asof=d2, end=None)
    #  Check

# Generated at 2022-06-12 06:13:43.114647
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC("ACT/365", {"ACT/365"}, _as_ccys({"USD", "CAD", "EUR", "GBP"}), _act_365_dc_fraction).coupon(
        Money("100", "USD"),
        Decimal("0.02"),
        datetime.date(2017, 1, 1),
        datetime.date(2017, 1, 1),
        datetime.date(2018, 1, 1),
        Decimal("1")
    ) == Money("1.96167224080268", "USD")


# Generated at 2022-06-12 06:13:52.409240
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')



# Generated at 2022-06-12 06:14:05.141627
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008, 2, 28)), 14) == 0.16942884946478
    assert round(dcfc_act_act(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008, 2, 29)), 14) == 0.17216108990194
    assert round(dcfc_act_act(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008, 11, 30)), 14) == 1.08243131970956

# Generated at 2022-06-12 06:14:16.167779
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-12 06:14:23.809330
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    f = _as_ccys
    dcc = DCC('test', {'test2'}, f({'ABC'}), lambda s, a, e, f: Decimal(1))
    result = dcc.calculate_daily_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1))
    assert result == Decimal(0)

# Generated at 2022-06-12 06:14:35.529999
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(1985, 1, 15), datetime.date(1986, 1, 14), datetime.date(1986, 1, 14)), 14) == Decimal('1.00000000000000')
    assert round(dcfc_30_360_isda(datetime.date(1985, 6, 3), datetime.date(1986, 6, 3), datetime.date(1986, 6, 3)), 14) == Decimal('1.00000000000000')
    assert round(dcfc_30_360_isda(datetime.date(1985, 6, 3), datetime.date(1986, 6, 3), datetime.date(1986, 6, 3), Decimal('1')), 14) == Decimal('1.00000000000000')

# Generated at 2022-06-12 06:15:27.893254
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Function to test function dcfc_30_e_360.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-12 06:15:37.478537
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(datetime.date(2019, 1, 31), datetime.date(2020, 2, 29), end=datetime.date(2020, 2, 29)), 14) == 1.08333333333333
    assert round(dcfc_30_360_us(datetime.date(2019, 2, 28), datetime.date(2020, 2, 29), end=datetime.date(2020, 2, 29)), 14) == 1.00833333333333
    assert round(dcfc_30_360_us(datetime.date(2019, 2, 28), datetime.date(2020, 3, 1), end=datetime.date(2020, 3, 1)), 14) == 1.00555555555556

# Generated at 2022-06-12 06:15:48.490790
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    # Test 1
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = asof
    expected = Decimal("0.16666666666667")

    # Test 2
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)
    end = asof
    expected = Decimal("0.16944444444444")

    # Test 3
    start = datetime.date(2007, 10, 31)
    asof = datetime.date(2008, 11, 30)
    end = asof
    expected = Decimal("1.08333333333333")

    # Test 4
    start = datetime.date(2008, 2, 1)

# Generated at 2022-06-12 06:15:54.911153
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert (DCCRegistry["act/act"]).coupon(Money(100, "USD"), 0.01, datetime.date(2014, 3, 31), datetime.date(2014, 12, 31), datetime.date(2015, 12, 31), 2) == Money(1.5, "USD")

    assert (DCCRegistry["act/act"]).coupon(Money(100, "USD"), 0.01, datetime.date(2014, 4, 1), datetime.date(2014, 12, 31), datetime.date(2015, 12, 31), 2) == Money(1.5, "USD")


# Generated at 2022-06-12 06:15:59.489834
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-12 06:16:12.461066
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14)==Decimal('0.17216108990194')
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14)==Decimal('1.08243131970956')

# Generated at 2022-06-12 06:16:23.497547
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    '''Test suite for function dcfc_30_360_isda
    '''
    def test_dcfc_30_360_isda_helper(
            start_date: str, asof_date: str, end_date: str, freq: Optional[Decimal], expected_value : str):
        '''Helper unit test function for function dcfc_30_360_isda
        '''

# Generated at 2022-06-12 06:16:33.299128
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    registry = DCCRegistryMachinery()
    registry.register(DCC("A/A", {}, {}, lambda x, y, z, w: (z - y).days))
    registry.register(DCC("A/365", {}, {}, lambda x, y, z, w: (z - y).days))
    registry.register(DCC("A/360", {"ACT/360"}, {"USD"}, lambda x, y, z, w: (z - y).days / 360))



# Generated at 2022-06-12 06:16:42.169494
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCCRegistry.ACT_360.calculate_daily_fraction(datetime.date(2019,1,1), datetime.date(2019,1,1), datetime.date(2019,1,2)) == Decimal('0.002777778')
    assert DCCRegistry.ACT_360.calculate_daily_fraction(datetime.date(2018,1,1), datetime.date(2018,1,1), datetime.date(2019,1,2)) == Decimal('0.002777778')
    assert DCCRegistry.ACT_365F.calculate_daily_fraction(datetime.date(2019,1,1), datetime.date(2019,1,1), datetime.date(2019,1,2)) == Decimal('0.002743498')
    assert D

# Generated at 2022-06-12 06:16:51.441710
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(float(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))), 14) == 0.16986301369863
    assert round(float(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29))), 14) == 0.16986301369863
    assert round(float(dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30))), 14) == 1.08219178082192

# Generated at 2022-06-12 06:18:43.221136
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # (1) With dcf=0.5, t-1 dcf=0.5, dcf=1.0, expected 0.5 increase
    start = datetime.date(2018, 6, 1)
    asof = datetime.date(2018, 6, 15)
    end = datetime.date(2018, 6, 30)
    freq = None 
    dcc = DCC('ACT/ACT ISDA', {'ACT/ACT ISDA', 'Actual/Actual ISDA', '30/360 ISDA', 'ISDA', '30E/360 ISDA', '30E+/360 ISDA'}, _as_ccys({'USD'}), calculate_fraction_method=calc_fraction_act_act_isda)

# Generated at 2022-06-12 06:18:48.136787
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = datetime.date(2008, 3, 31)
    assert round(dcfc_30_360_us(start=start, asof=asof, end=end), 2) == 0.17

    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)
    end = datetime.date(2008, 2, 29)
    assert round(dcfc_30_360_us(start=start, asof=asof, end=end), 2) == 0.17

    start = datetime.date(2007, 10, 31)
    asof = datetime.date(2008, 11, 30)

# Generated at 2022-06-12 06:18:55.889163
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies import Currencies

    dcc = DCC(
        "30U",
        {"NL","30U"},
        _as_ccys({"EUR", "USD", "GBP", "CHF", "CZK", "PLN", "RON", "HRK", "HUF", "SEK"}),
        calculate_fraction_method=calculate_fraction_method_30U,
    )

    ## 30/360 US:
    start = Date(2014, 5, 1)
    end = Date(2016, 4, 1)
    asof = Date(2016, 3, 1)
    assert dcc.calculate_daily_fraction(start, asof, end) == Decimal("0.00277777777777")
    start = Date(2014, 5, 2)

# Generated at 2022-06-12 06:19:05.311011
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Unit test for method calculate_fraction of class DCC
    DCC_1 = DCC(name = '30/360', altnames = {'30/360 US', 'NL/360', 'N/360', '30E/360', '30U/360', '30S/360'}, currencies = {Currencies['USD']}, calculate_fraction_method = None)
    DCC_1.calculate_fraction(start = datetime.date(2016, 8, 3), asof = datetime.date(2017, 10, 23), end = datetime.date(2017, 10, 23))
    DCC_1.calculate_fraction(start = datetime.date(2008, 1, 30), asof = datetime.date(2009, 7, 31), end = datetime.date(2009, 7, 31))
    D

# Generated at 2022-06-12 06:19:16.802216
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    ## Simple tests for Australian 30/360:
    aus30360 = DCC("AUS/30/360", {"30/360"}, _as_ccys({"AUD", "CAD", "CHF", "GBP", "JPY", "SEK", "USD"}),
                   lambda start, asof, end, freq: Decimal(30 * (asof.year - start.year))
                   + Decimal(30 * (min(asof.month, 6) - min(start.month, 6)))
                   + Decimal(min(asof.day, 30) - min(start.day, 30)))

    ## Create two dates:
    start = datetime.date(2011, 1, 1)
    end = datetime.date(2011, 1, 30)

    ## Check the daily fractions:

# Generated at 2022-06-12 06:19:24.429541
# Unit test for function dcfc_30_360_isda

# Generated at 2022-06-12 06:19:30.248270
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    principal = Money.of(Currencies["USD"], Decimal(1000000), datetime.date.today())
    start = datetime.date(2007, 12, 28)
    end = datetime.date(2008, 2, 28)
    rate = Decimal(0.01)

    ## Without registeration:
    dcc = DCR.find("Act/Act")
    assert dcc == DCR.find("Act/Act-ISDA")
    assert dcc == DCR.find("Actual 365")
    assert dcc == DCR.find("ACTUAL")
    assert dcc == DCR.find("Actual")
    assert dcc == DCR.find("Actual/Actual")
    assert dcc == DCR.find("Actual/Actual-ISDA")

# Generated at 2022-06-12 06:19:38.585362
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-12 06:19:44.804761
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    start = datetime.date(2013, 1, 31)
    asof = datetime.date(2013, 2, 28)
    end = datetime.date(2013, 2, 28)
    assert dcfc_30_e_plus_360(start, asof, end) == Decimal('0.077777777777778')



# Generated at 2022-06-12 06:19:48.239976
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Unit test for method calculate_fraction of class DCC
    """
    # TODO
    pass
