

# Generated at 2022-06-12 06:11:07.770232
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10),
                                   datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2020, 9, 10),
                                   datetime.date(2020, 3, 2)), 10) == Decimal('0.0')
    assert round(dcfc_act_act_icma(datetime.date(2020, 3, 2), datetime.date(2020, 9, 10),
                                   datetime.date(2020, 3, 2)), 10) == Decimal('0.0')


# Generated at 2022-06-12 06:11:14.672957
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2020, 2, 29), asof=datetime.date(2020, 4, 30), end=datetime.date(2020, 4, 30)), 14) == Decimal('0.33888888888889')
    assert round(dcfc_30_360_isda(start=datetime.date(2020, 2, 28), asof=datetime.date(2020, 4, 30), end=datetime.date(2020, 4, 30)), 14) == Decimal('0.34166666666667')

# Generated at 2022-06-12 06:11:25.848551
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:11:38.100789
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667'))

# Generated at 2022-06-12 06:11:49.563211
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # Get the start/asof/end dates of the period:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    # Compute and test the day count fraction:

# Generated at 2022-06-12 06:12:02.575118
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    class MyDCC(DCC):
        def calculate_fraction_method(self, start, asof, end, freq):
            return Decimal(asof.day)

    assert MyDCC(
        'MY',
        set(),
        set(),
        MyDCC.calculate_fraction_method
    ).calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal(0)


# Generated at 2022-06-12 06:12:10.940286
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:12:23.130627
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(start=datetime.date(2020,5,8), asof=datetime.date(2020,5,31), end=datetime.date(2020,5,31)) == 0.105555555555555556
    assert dcfc_30_e_360(start=datetime.date(2020,5,8), asof=datetime.date(2020,6,1), end=datetime.date(2020,6,1)) == 0.111111111111111111
    assert dcfc_30_e_360(start=datetime.date(2020,5,9), asof=datetime.date(2020,6,1), end=datetime.date(2020,6,1)) == 0.105555555555555556
    assert dcfc_30_

# Generated at 2022-06-12 06:12:31.570014
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Test the dcfc_30_e_360 function from the
    DayCounts.py script.
    """
    # Set the start date of the period.
    ex1_start = datetime.date(2007,12,28)
    # Set the date which the day count fraction to be calculated as of.
    ex1_asof = datetime.date(2008,2,28)
    # Set the end date of the period (a.k.a. termination date).
    ex3_end = datetime.date(2008,11,30)
    # Compute the day count fraction and compare to the expected value.

# Generated at 2022-06-12 06:12:38.200817
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    from decimal import Decimal
    from datetime import date
    # given
    ex1_start, ex1_asof = date(2007, 12, 28), date(2008, 2, 28)
    ex2_start, ex2_asof = date(2007, 12, 28), date(2008, 2, 29)
    ex3_start, ex3_asof = date(2007, 10, 31), date(2008, 11, 30)
    ex4_start, ex4_asof = date(2008, 2, 1), date(2009, 5, 31)
    # when
    d1 = dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof)

# Generated at 2022-06-12 06:15:05.823911
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert (
        DCCRegistry.D30360_BUS_252.calculate_daily_fraction(
            datetime.date(2012, 12, 15), datetime.date(2015, 12, 31), datetime.date(2016, 1, 6), 2
        )
        == Decimal(0)
    )

    assert (
        DCCRegistry.D30360_BUS_252.calculate_daily_fraction(
            datetime.date(2015, 12, 15), datetime.date(2015, 12, 16), datetime.date(2016, 1, 6), 2
        )
        == Decimal(0)
    )


# Generated at 2022-06-12 06:15:12.985097
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=2), 10) == round(Decimal('0.2622950819'), 10)
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 10, 1), asof=datetime.date(2020, 4, 1), end=datetime.date(2020, 10, 1), freq=2), 10) == round(Decimal('0.5245901639'), 10)

# Generated at 2022-06-12 06:15:22.769565
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:15:31.056478
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    print(30 * '=', ' Unit Test of method "calculate_daily_fraction" in class DCC', 30 * '=')
    # Unit test for DCC.calculate_daily_fraction for ACT/365
    # Simple case
    start = Date(datetime.datetime(2010, 2, 19))
    asof = Date(datetime.datetime(2010, 3, 1))
    end = Date(datetime.datetime(2010, 5, 1))
    result = DCCRegistry['ACT/365'].calculate_daily_fraction(start, asof, end)
    expected = Decimal(0.0273972602739726)
    msg = 'Method calculate_daily_fraction returns {}, expected {}'.format(result, expected)
    assert result == expected, msg
    # Leap-year

# Generated at 2022-06-12 06:15:43.393611
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert(round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667'))

# Generated at 2022-06-12 06:15:52.184088
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    check(dcfc_act_act,start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28),end=datetime.date(2008, 2, 28),expected=Decimal('0.16942884946478'))
    check(dcfc_act_act,start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29),end=datetime.date(2008, 2, 29),expected=Decimal('0.17216108990194'))
    check(dcfc_act_act,start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30),end=datetime.date(2008, 11, 30),expected=Decimal('1.08243131970956'))

# Generated at 2022-06-12 06:16:03.644243
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-12 06:16:15.620196
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:16:26.434678
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    # Case 1
    start_1 = datetime.date(2018,12,31)
    asof_1 = datetime.date(2019,1,31)
    
    expected_result_1 = Decimal('0.032258064516129')
    actual_result_1 = round(dcfc_nl_365(start=start_1, asof=asof_1, end=asof_1),14)
    
    assert (expected_result_1 == actual_result_1)
    
    # Case 2
    start_2 = datetime.date(2019,12,31)
    asof_2 = datetime.date(2020,1,31)
    
    expected_result_2 = Decimal('0.032258064516129')

# Generated at 2022-06-12 06:16:34.618525
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
  assert dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof, freq=None) == 0.16942884946478



# Generated at 2022-06-12 06:17:08.062464
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from .currencies import USD
    from .exceptions import DateOutOfRangeException
    dollars = USD
    assert DCCRegistry[dollars]["30/360"].coupon(
        principal=dollars(100),
        rate=0.01,
        start=datetime.date(year=2014, month=1, day=15),
        asof=datetime.date(year=2014, month=1, day=15),
        end=datetime.date(year=2014, month=7, day=15),
        freq=6,
        eom=15,
    ) == USD(0)


# Generated at 2022-06-12 06:17:15.549803
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(start=datetime.date(2019, 5, 31), asof=datetime.date(2019, 6, 30), end=datetime.date(2019, 6, 30)) == Decimal('0.083333333333333')



# Generated at 2022-06-12 06:17:26.237031
# Unit test for method interest of class DCC
def test_DCC_interest():
    principal = Money(currency='USD',amount=1000)
    principal_ = Money(currency='USD',amount=900)
    rate = Decimal('0.05')
    rate_ = Decimal('0.5')
    start = Date(year=2018,month=5,day=26)
    start_ = Date(year=2017,month=1,day=1)
    asof = Date(year=2018,month=5,day=27)
    asof_ = Date(year=2018,month=5,day=25)
    end = Date(year=2019,month=5,day=26)
    end_ = Date(year=2018,month=5,day=26)
    freq = Decimal('1')
    freq_ = Decimal('2')

# Generated at 2022-06-12 06:17:37.864829
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Unit test for function dcfc_act_act
    """
    import unittest
    import doctest
    doctest.testmod()

    class TestDcfcActAct(unittest.TestCase):
        """
        Unit test class for function dcfc_act_act
        """
        def test_dcfc_act_act_nominal_dates(self):
            """
            Test nominal dates for function dcfc_act_act
            """
            # dcfc_act_act is deterministic for nominal dates:

# Generated at 2022-06-12 06:17:49.398085
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert isclose(
        dcfc_30_360_isda(
            datetime.date(year=2019, month=10, day=31),
            datetime.date(year=2020, month=10, day=31),
            datetime.date(year=2020, month=10, day=31),
        ),
        1.0,
        abs_tol=0.000001
    )

# Generated at 2022-06-12 06:18:00.196641
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-12 06:18:02.208582
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    import doctest
    doctest.testmod()


# Generated at 2022-06-12 06:18:11.965905
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-12 06:18:24.726334
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry.get('ACT/360', 'USD').calculate_fraction(start=datetime.date(2017, 1, 1),
                                                                asof=datetime.date(2018, 1, 1),
                                                                end=datetime.date(2018, 12, 31),
                                                                freq=None) == Decimal('1.00000000')
    assert DCCRegistry.get('ACT/360', 'USD').calculate_fraction(start=datetime.date(2017, 1, 1),
                                                                asof=datetime.date(2017, 2, 1),
                                                                end=datetime.date(2017, 12, 31),
                                                                freq=None) == Decimal('0.08333333')

# Generated at 2022-06-12 06:18:35.735661
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    '''
    Tests the function dfc_act_act
    '''
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == 0.16942884946478
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == 0.17216108990194
    assert round(dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == 1.08243131970956

# Generated at 2022-06-12 06:19:12.642200
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Unit test for function dcfc_30_360_german
    """
    import pandas as pd
    import pandas.io.excel

    ## Load data from an Excel file:
    df = pandas.io.excel.read_excel(
        io="./test/Data for unit tests.xlsx",
        sheetname="dcfc_30_360_german")

    for index, row in df.iterrows():
        start, asof, end, freq, expected = row
        assert abs(dcfc_30_360_german(start, asof, end, freq) - expected) < Decimal("1e-12")


# Generated at 2022-06-12 06:19:18.751633
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    principal = Money(100, "EUR")
    rate = 0.1
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2019, 2, 28)
    end = datetime.date(2019, 4, 1)
    freq = 2
    eom = 15
    actual = DCC("","","",_actual_360_method).coupon(principal,rate,start,asof,end,freq,eom).amount
    expected = 5*100*0.1/12
    assert actual == expected



# Generated at 2022-06-12 06:19:22.911420
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-12 06:19:32.026609
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start_date = datetime.date(2019, 1, 15)
    asof_date = datetime.date(2019, 3, 31)
    end_date = datetime.date(2019, 4, 30)
    freq = 1
    dcc = DCC("name", set(), set(), _actual_actual_dc)
    assert dcc.calculate_fraction(start_date, asof_date, end_date, freq) == Decimal("0.0604164667")

# Generated at 2022-06-12 06:19:41.879804
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Tests the :func:`DCC.calculate_daily_fraction` method of the :class:`DCC` class.
    """
    ## Get the dcc:
    dcc = DCCRegistry["ACT/ACT ISDA"]

    ## For now, we will just do the first 10 years:
    start = datetime.date(2014, 1, 1)
    end = datetime.date(2024, 1, 1)

    ## Asof:
    asof = start

    ## Print the header:
    print("Date,Fraction")

    ## Print first row:
    print("{0},{1}".format(asof, dcc.calculate_daily_fraction(start, asof, end)))

    ## Today's date:

# Generated at 2022-06-12 06:19:46.313830
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2020,6,30), datetime.date(2020,12,31), datetime.date(2021,6,30)),14)==Decimal('0.5000000000')


# Generated at 2022-06-12 06:19:57.896635
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-12 06:20:09.618061
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_e_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-12 06:20:21.237686
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')