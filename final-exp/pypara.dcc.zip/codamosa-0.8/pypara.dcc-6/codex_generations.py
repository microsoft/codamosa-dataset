

# Generated at 2022-06-12 06:11:04.173400
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    print('Testing dcfc_30_e_360... ', end='')
    assert(fabs(dcfc_30_e_360(datetime.date(2000, 1, 25), datetime.date(2000, 1, 25), freq=360) - Decimal('0.0')) < eps)
    assert(fabs(dcfc_30_e_360(datetime.date(2000, 1, 25), datetime.date(2000, 2, 25), freq=360) - Decimal('0.0333333333333')) < eps)
    assert(fabs(dcfc_30_e_360(datetime.date(2000, 1, 25), datetime.date(2001, 1, 25), freq=360) - Decimal('1.0')) < eps)

# Generated at 2022-06-12 06:11:16.737363
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Test for method calculate_daily_fraction for class DCC
    """

    # Convention 30/360
    DCC_30_360 = DCC(
        name = '30/360',
        altnames = {'30U/360'},
        currencies = _as_ccys({'EUR'}),
        calculate_fraction_method = calculate_fraction_30_360
    )

    # Convention 30E/360
    DCC_30E_360 = DCC(
        name = '30E/360',
        altnames = {'30/360E'},
        currencies = _as_ccys({'EUR'}),
        calculate_fraction_method = calculate_fraction_30E_360
    )

    # Convention 30E+/360

# Generated at 2022-06-12 06:11:20.948798
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(start_date, asof_date, end_date) == 0.33819444444444444



# Generated at 2022-06-12 06:11:22.699617
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    d1 = datetime.date(2016, 12, 12)
    d2 = datetime.date(2017, 1, 11)
    mydcf = dcfc_30_e_plus_360(d1, d2, d2)
    print(mydcf)

# Generated at 2022-06-12 06:11:35.905906
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC(
        "Actual/Actual (ISDA)",
        {"Act/Act", "Act/Act (ISDA)", "Actual/Actual (ISDA)", "ACT/ACT", "ACT/ACT (ISDA)", "ACTUAL/ACTUAL (ISDA)"},
        _as_ccys({"USD", "GBP", "CAD", "AUD"}),
        _actual_actual_isda,
    )
    print(dcc.calculate_fraction(datetime.date(2011,1,1), datetime.date(2011, 4, 1), datetime.date(2011, 7, 1)))

# Generated at 2022-06-12 06:11:45.025099
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    """
    ex1_start = dt.date(year=2008, month=1, day=31)
    ex1_asof = dt.date(year=2008, month=2, day=29)
    ex1_end = dt.date(year=2008, month=3, day=31)
    ex2_start = dt.date(year=2008, month=2, day=29)
    ex2_asof = dt.date(year=2008, month=3, day=31)
    ex2_end = dt.date(year=2008, month=5, day=31)
    ex3_start = dt.date(year=2008, month=2, day=28)

# Generated at 2022-06-12 06:11:57.455505
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(ex1_start, ex1_asof, ex1_asof), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(ex2_start, ex2_asof, ex2_asof), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(ex3_start, ex3_asof, ex3_asof), 14) == Decimal('1.08333333333333')
    assert round(dcfc_30_360_isda(ex4_start, ex4_asof, ex4_asof), 14) == Decimal('1.33333333333333')


# Generated at 2022-06-12 06:12:09.258430
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert 0.16986301369863 == dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28))
    assert 0.16986301369863 == dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29))
    assert 1.08219178082192 == dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30))

# Generated at 2022-06-12 06:12:19.279872
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ## Define test sample:
    start, end = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    asofs = [(start + datetime.timedelta(days=x)) for x in range(0, 60)]

    ## Generate test results:
    test_results = [(
        str(asof),
        round(Decimal(_get_actual_day_count(start, asof)) / Decimal(366 if _has_leap_day(start, asof) else 365), 14))
        for asof in asofs
    ]

    ## Validate test results:

# Generated at 2022-06-12 06:12:29.442232
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-12 06:13:54.306508
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC(
        name="ACT/ACT",
        altnames=set(),
        currencies=set(),
        calculate_fraction_method=dcc_act_act_calculate_fraction
    )
    assert dcc.calculate_fraction(
        datetime.date(2016, 12, 31),
        datetime.date(2017,  1,  1),
        datetime.date(2017,  1, 31)
    ) == Decimal('0.03287671232876712')

# Generated at 2022-06-12 06:14:06.296895
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) \
        == Decimal('0.16942884946478')
    assert dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) \
        == Decimal('0.17216108990194')
    assert dcfc_act_act(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)) \
        == Decimal('1.08243131970956')

# Generated at 2022-06-12 06:14:17.540251
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2013,3,1),datetime.date(2013,10,31),datetime.date(2014,3,1)),6) == Decimal('0.508767')
    assert round(dcfc_act_365_a(datetime.date(2012,12,30),datetime.date(2013,9,30),datetime.date(2013,12,31)),6) == Decimal('0.816733')
    assert round(dcfc_act_365_a(datetime.date(2012,12,31),datetime.date(2013,9,30),datetime.date(2013,12,31)),6) == Decimal('0.816062')

# Generated at 2022-06-12 06:14:21.173958
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    DCC.calculate_fraction(start=Date(2017,1,1), asof=Date(2017,1,1), end=Date(2017,1,5))

# Generated at 2022-06-12 06:14:32.093485
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    date_1 = datetime.date(2012, 9, 30)
    date_2 = datetime.date(2012, 9, 29)
    date_3 = datetime.date(2012, 2, 29)
    date_4 = datetime.date(2013, 2, 28)
    assert round(dcfc_30_360_german(start=date_1, asof=date_2, end=date_2), 14) == Decimal('0.002777777777778')
    assert round(dcfc_30_360_german(start=date_3, asof=date_4, end=date_4), 14) == Decimal('1.00277777777778')

# Generated at 2022-06-12 06:14:34.276493
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), Decimal(2)), 10) == Decimal('0.5245901639')


# Generated at 2022-06-12 06:14:45.962323
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .currencies import Currencies
    from .monetary import Money
    from .time.daycount import DCCRegistry, _get_actual_day_count, _get_date_range
    import datetime
    import calendar
    # 1. Test if this method returns 0 if the given dates are not in the right order
    assert DCCRegistry['ACT/360'].calculate_fraction(datetime.date(2018, 1, 1), datetime.date(2018, 1, 2), datetime.date(2018, 1, 1)) == 0
    # 2. Test if this method returns 0 if the asof date is before the start date or after the end date

# Generated at 2022-06-12 06:14:58.015985
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:15:07.337003
# Unit test for method register of class DCCRegistryMachinery

# Generated at 2022-06-12 06:15:11.501978
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')


# Generated at 2022-06-12 06:20:18.280019
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2009,1,1), asof=datetime.date(2009,1,1), end=datetime.date(2009,1,1)), 14) == Decimal('0.002777777777778')
    assert round(dcfc_30_e_360(start=datetime.date(2009,1,1), asof=datetime.date(2009,2,1), end=datetime.date(2009,2,1)), 14) == Decimal('0.083333333333333')
    assert round(dcfc_30_e_360(start=datetime.date(2009,12,31), asof=datetime.date(2009,12,31), end=datetime.date(2009,12,31)), 14) == Decimal