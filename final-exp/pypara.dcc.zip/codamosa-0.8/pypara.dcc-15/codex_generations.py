

# Generated at 2022-06-12 06:11:14.709612
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)==Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14)==Decimal('0.17216108990194')
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14)==Decimal('1.08243131970956')

# Generated at 2022-06-12 06:11:25.889721
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Testing the calculate_fraction method of class DCC.
    """
    ## The list of DCCs to test:
    dccs = [
        ('ACT/360', ('ACT/360',), ('USD', 'EUR'), ACT_360),
        ('ACT/365', ('ACT/365',), ('GBP',), ACT_365),
        ('ACT/ACT', ('ACT/ACT',), ('RUB',), ACT_ACT),
        ('30/360', ('30/360', '30U/360', '30E/360', 'E30/360', 'NL/360', 'BON/360',), ('JPY',), THIRTY_360),
    ]

    ## Convert currencies:

# Generated at 2022-06-12 06:11:30.508838
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    """Test the function dcfc_nl_365"""
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-12 06:11:37.383457
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')


# Generated at 2022-06-12 06:11:41.715827
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-12 06:11:52.477349
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    """
    Unit test function dcfc_30_e_plus_360
    """
    assert round(dcfc_30_e_plus_360(datetime.date(2008, 1, 31), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.08333333333333')
    assert round(dcfc_30_e_plus_360(datetime.date(2008, 1, 31), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.08333333333333')
    assert round(dcfc_30_e_plus_360(datetime.date(2008, 1, 31), datetime.date(2008, 3, 31), datetime.date(2008, 3, 31)), 14)

# Generated at 2022-06-12 06:11:56.050043
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCC.interest(DCC,[100000000,0.05,datetime.date(2017, 1, 1),datetime.date(2017, 8, 31)]) == [1000000025.0]


# Generated at 2022-06-12 06:12:06.682116
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(date(2007, 12, 28), date(2008, 2, 28), date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(date(2007, 12, 28), date(2008, 2, 29), date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(date(2007, 10, 31), date(2008, 11, 30), date(2008, 11, 30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-12 06:12:16.190825
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    ## Test case 1
    start_date = datetime.date(2017, 1, 1)
    asof_date = datetime.date(2017, 1, 1)
    end_date = datetime.date(2017, 1, 1)
    test_dcc = DCC("30/360", {}, {}, None)
    assert test_dcc.calculate_daily_fraction(start_date, asof_date, end_date) == ZERO

    ## Test case 2
    start_date = datetime.date(2017, 1, 1)
    asof_date = datetime.date(2017, 1, 2)
    end_date = datetime.date(2017, 1, 2)
    test_dcc = DCC("30/360", {}, {}, None)
    assert test_dcc.calculate

# Generated at 2022-06-12 06:12:28.008118
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start= datetime.date(2007, 12, 28), asof= datetime.date(2008, 2, 28), end= datetime.date(2008, 2, 28)), 14) == round(Decimal('0.16986301369863'), 14)
    assert round(dcfc_nl_365(start= datetime.date(2007, 12, 28), asof= datetime.date(2008, 2, 29), end= datetime.date(2008, 2, 29)), 14) == round(Decimal('0.16986301369863'), 14)

# Generated at 2022-06-12 06:13:04.922762
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    print("Checking function: dcfc_30_360_german()")
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    ex5_start, ex5_asof = datetime.date(2008, 5, 31), datetime.date(2009, 2, 28)

# Generated at 2022-06-12 06:13:13.537443
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)),14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)),14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)),14) == Decimal('1.08196721311475')

# Generated at 2022-06-12 06:13:20.867480
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    _start = datetime.date(2019, 3, 2)
    _asof = datetime.date(2019, 9, 10)
    _end = datetime.date(2020, 3, 2)
    _freq = Decimal(2)
    frac = dcfc_act_act_icma(_start, _asof, _end, _freq)
    assert isinstance(frac, Decimal)
    assert frac == Decimal('0.5245901639')



# Generated at 2022-06-12 06:13:33.245960
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    dcc = DCC(
        name='30/360', altnames={'30E360'}, currencies={Currencies['USD']}, calculate_fraction_method=dcc_30_360(as_of_date_is=0)
    )
    value = dcc.calculate_fraction(datetime.date(2016, 5, 31), datetime.date(2016, 7, 15), datetime.date(2016, 12, 15))
    assert value == Decimal('0.04')

    dcc = DCC(
        name='30/360', altnames={'30E360'}, currencies={Currencies['USD']}, calculate_fraction_method=dcc_30_360(as_of_date_is=1)
    )

# Generated at 2022-06-12 06:13:45.576881
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 31), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-12 06:13:54.276836
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:13:59.579700
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-12 06:14:05.627384
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16942884946478')



# Generated at 2022-06-12 06:14:16.699510
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-12 06:14:28.826092
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Tests for function dcfc_30_e_360.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)


# Generated at 2022-06-12 06:15:27.718613
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(Date(Year(2020), Month(1), Day(1)), Date(Year(2020), Month(1), Day(31)), Date(Year(2020), Month(3), Day(5))) == Decimal('0.16666666666667')
    assert dcfc_30_360_isda(Date(Year(2020), Month(1), Day(1)), Date(Year(2020), Month(1), Day(31)), Date(Year(2020), Month(3), Day(6))) == Decimal('0.16944444444444')

# Generated at 2022-06-12 06:15:37.364555
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    bf = 'calculate_daily_fraction'
    ns = {DCC}
    lc = locals()

# Generated at 2022-06-12 06:15:48.408485
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal('0.16666666666667')
    assert dcfc_30_360_us

# Generated at 2022-06-12 06:15:52.607620
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert math.isclose(dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) , 0.166666666667), "test 1 failed"
    assert math.isclose(dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) , 0.169444444444), "test 2 failed"
    assert math.isclose(dcfc_30_e_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) , 1.083333333333), "test 3 failed"

# Generated at 2022-06-12 06:15:57.589778
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2), datetime.date(2020, 1, 2)),14) == round(Decimal('0.00068493150684932'),14)
    assert round(dcfc_act_365_l(datetime.date(2020, 1, 1), datetime.date(2020, 1, 10), datetime.date(2020, 1, 2)),14) == round(Decimal('0.0068493150684932'),14)
    assert round(dcfc_act_365_l(datetime.date(2000, 1, 1), datetime.date(2001, 1, 1), datetime.date(2001, 1, 1)),14) == round(Decimal('1.0'),14)

# Generated at 2022-06-12 06:16:02.683029
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ## Import packages:
    import datetime
    from decimal import Decimal

    ## Define test data:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    ## Testing:

# Generated at 2022-06-12 06:16:11.786233
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["Actual/Actual (ICMA)"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal('0')
    assert DCCRegistry["Actual/Actual (ICMA)"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 2, 1), datetime.date(2017, 3, 1)) == Decimal('0.776712328767124')


# Generated at 2022-06-12 06:16:23.436604
# Unit test for method register of class DCCRegistryMachinery

# Generated at 2022-06-12 06:16:36.731122
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc = DCC("30/360 PSA", {"PSA"}, {"USD"}, lambda s, a, e, f: ONE)
    assert dcc.calculate_daily_fraction(
        datetime.date(2000, 1, 31),
        datetime.date(2000, 2, 28),
        datetime.date(2000, 3, 31),
        Decimal("1")
    ) == ONE
    assert dcc.calculate_daily_fraction(
        datetime.date(2000, 1, 31),
        datetime.date(2000, 2, 28),
        datetime.date(2000, 3, 31),
        Decimal("2")
    ) == ONE

# Generated at 2022-06-12 06:16:43.098367
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    ## Test parameters
    start = datetime.date(2016, 4, 11)
    asof = datetime.date(2016, 5, 10)
    end = datetime.date(2017, 5, 10)
    freq = 2
    principal = Money(100, 'USD')
    rate = 0.01
    a = DCCRegistry.get('30/360-ISDA')
    yfact = a.calculate_fraction(start, asof, end, freq)
    tfact = a.calculate_fraction(start, asof, end, freq)
    assert (tfact - yfact) == 0.03

# Generated at 2022-06-12 06:18:25.437307
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), \
                    end=datetime.date(2008, 2, 28)), 14) == round(Decimal('0.16666666666667'), 14)
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), \
                    end=datetime.date(2008, 2, 29)), 14) == round(Decimal('0.16944444444444'), 14)

# Generated at 2022-06-12 06:18:36.191950
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """
    start_date = Date(datetime.date(2017, 1, 1))
    asof_date = Date(datetime.date(2017, 1, 2))
    end_date = Date(datetime.date(2017, 1, 3))
    freq = None
    dcc = DCC("Test", None, {}, _a_30e_360)
    expected = Decimal("0.0027777777777778")
    actual = dcc.calculate_daily_fraction(start_date, asof_date, end_date, freq)
    assert abs(actual - expected) < Decimal("1E-14"), "Expected {} got {}".format(expected, actual)


# Generated at 2022-06-12 06:18:37.776396
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    import doctest
    doctest.testmod(verbose=False, optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-12 06:18:42.528776
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    result = dcfc_30_360_isda(dt.date(2020,2,21), dt.date(2020,3,31), dt.date(2020,3,31))
    expected = Decimal('0.0833')
    assert result == expected

# Generated at 2022-06-12 06:18:53.206924
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:19:04.638988
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    print('Testing 30_360_us ... ', end='')
    # Test standard cases:
    start = datetime.date(year=2008, month=3, day=20); asof = datetime.date(year=2008, month=6, day=20); end = asof

# Generated at 2022-06-12 06:19:16.346400
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC.
    """
    # Import packages:
    import sys
    import pytest
    import sectool.calculus.daycountconventions as dc
    import datetime

    # Define arguments:
    start = datetime.date(2019, 1, 1)
    asof = datetime.date(2019, 1, 2)
    end = datetime.date(2019, 1, 3)
    freq = None

    # Check if dcc is the correct class:
    assert(isinstance(dc.ACT365, dc.DCC))

    # Create expected output:
    expected_output = Decimal("0.00273972602739726")

    # Test if the method calculate_daily_fraction gives the correct result:

# Generated at 2022-06-12 06:19:24.247335
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Unit test for function dcfc_30_360_german
    """
    import random
    import dateutil.relativedelta as rd
    ref_date = datetime.date.today()
    for _i in range(0, 999):
        start = ref_date + rd.relativedelta(days=random.randint(-3650,3650))
        end = ref_date + rd.relativedelta(days=random.randint(-3650,3650))
        asof = start + rd.relativedelta(days=random.randint(0,3650))

# Generated at 2022-06-12 06:19:30.127315
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == 0.16666666666667
    assert dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) == 0.16944444444444
    assert dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)) == 1.08333333333333

# Generated at 2022-06-12 06:19:38.562244
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    """
    Test function dcfc_nl_365.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal