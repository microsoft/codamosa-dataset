

# Generated at 2022-06-12 06:11:27.489374
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-12 06:11:35.080193
# Unit test for method interest of class DCC
def test_DCC_interest():
    freq = Decimal(1)
    start = Date(datetime.date(2017, 1, 1))
    end = start+ relativedelta(months=1)
    asof = start
    principal = Money(12, 'CNY')
    rate = Decimal(0.01)
    assert DCCRegistry.ACT_360.interest(principal, rate, start, asof, end, freq) == Money(0.12, 'CNY')

# Generated at 2022-06-12 06:11:40.420100
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    """
    Tests the function dcfc_act_act_icma
    """
    ## Test the function
    assert dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)) == 0.5245901639344262



# Generated at 2022-06-12 06:11:49.697584
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(datetime.date(2013,5,5),datetime.date(2017,5,5),datetime.date(2017,5,5)),14) == 1.365
    assert round(dcfc_act_365_l(datetime.date(2013,5,5),datetime.date(2018,5,5),datetime.date(2017,5,5)),14) == 1.34246575342466
    assert round(dcfc_act_365_l(datetime.date(2013,5,5),datetime.date(2018,5,6),datetime.date(2017,5,5)),14) == 1.34246575342466

# Generated at 2022-06-12 06:12:02.716523
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14)

# Generated at 2022-06-12 06:12:11.053744
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-12 06:12:23.299006
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:12:31.662023
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ## Test cases
    ex1_start, ex1_asof = datetime.date(2007,12,28), datetime.date(2008,2,28)
    ex2_start, ex2_asof = datetime.date(2007,12,28), datetime.date(2008,2,29)
    ex3_start, ex3_asof = datetime.date(2007,10,31), datetime.date(2008,11,30)
    ex4_start, ex4_asof = datetime.date(2008,2,1), datetime.date(2009,5,31)
    ## Test the implementation

# Generated at 2022-06-12 06:12:42.446555
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from datetime import date
    from py2cd.dcc import DCCRegistry
    from py2cd.monetary import Money

    principal = Money(Decimal(100), "EUR")
    rate = Decimal(0.025)
    start = date(2012, 12, 15)
    asof = date(2016, 1, 6)
    end = date(2016, 1, 6)
    freq = Decimal(2)
    eom = None
    dcc = DCCRegistry["ACT/360"]
    assert dcc.coupon(principal, rate, start, asof, end, freq, eom).get_amount() == Decimal('0.69444444444444444444444444444444')

    asof = date(2015, 12, 31)

# Generated at 2022-06-12 06:12:55.109568
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-12 06:13:54.575004
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Test for method calcaulte_fraction of class DCC.
    """
    ## DCC for testing:
    dcc = DCC(name='DCC', altnames={'DCC'}, currencies={Currencies.USD}, calculate_fraction_method=_act_360_calculate_fraction)
    assert dcc.calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 4, 30)) == Decimal('0.00000000000000')
    assert dcc.calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 4, 30), freq=Decimal('1')) == Decimal('0.00000000000000')
    assert d

# Generated at 2022-06-12 06:13:59.867948
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-12 06:14:10.949723
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc = DCC("ACT/ACT", {"Actual/Actual", "Actual365", "Actual/365", "Actual/365 (Fixed)"}, set(), _dcf_act_act)
    # or
    dcc1 = DCCRegistry.get_dcc_by_name("ACT/ACT")
    start = Date(2019, 1, 1)
    end = Date(2019, 1, 31)
    assert dcc.calculate_daily_fraction(start, Date(2019, 1, 1), end) == Decimal("0")
    assert dcc.calculate_daily_fraction(start, Date(2019, 1, 2), end) == Decimal("0.00273972602739726")

# Generated at 2022-06-12 06:14:21.239972
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    print(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof))

# Generated at 2022-06-12 06:14:27.568694
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    This function tests the dcfc_30_360_us function.
    :return: None
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-12 06:14:38.325651
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    """
    Tests the function ``dcfc_act_act``.
    """
    ## Example 1:
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 28)
    end = asof
    result1 = round(dcfc_act_act(start, asof, end), 14)
    assert result1 == Decimal(0.16942884946478)

    ## Example 2:
    start = datetime.date(2007, 12, 28)
    asof = datetime.date(2008, 2, 29)
    end = asof
    result2 = round(dcfc_act_act(start, asof, end), 14)
    assert result2 == Decimal(0.17216108990194)

    ## Example 3:
    start

# Generated at 2022-06-12 06:14:50.228765
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:14:59.435932
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert math.isclose(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), None), 0.5245901639, rel_tol=1e-9)
    assert math.isclose(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 9), datetime.date(2020, 3, 2), None), 0.5219576719, rel_tol=1e-9)

# Generated at 2022-06-12 06:15:06.649798
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    # Given
    start = datetime.date(2020, 2, 28)
    asof = datetime.date(2020, 2, 29)
    end = datetime.date(2020, 3, 1)
    freq = 1.5
    # When
    dcc = DCC(name='DCC_TEST', altnames={'DCC_TEST'}, currencies={Currencies.USD}, calculate_fraction_method=None)
    result = dcc.calculate_fraction(start, asof, end, freq)
    # Then
    assert result == 1.5

# Generated at 2022-06-12 06:15:16.095834
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(datetime.date(2017,7,28), datetime.date(2017,7,28), datetime.date(2017,7,28)) == Decimal(0)
    assert dcfc_30_360_isda(datetime.date(2017,7,28), datetime.date(2017,7,29), datetime.date(2017,7,29)) == Decimal(1/360)
    assert dcfc_30_360_isda(datetime.date(2017,7,28), datetime.date(2017,7,31), datetime.date(2017,7,31)) == Decimal(3/360)

# Generated at 2022-06-12 06:16:35.131514
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:16:43.273598
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies.currency_fixtures import JPY
    from .currencies.factory import CurrencyFactory
    from .environments import Environments
    from .monetary.money import Money
    from .pricing.fx.fxdeal import FxDeal

    # Get the environment:
    env = Environments.market()

    # Get fx rates:
    fxrates = {
        FxDeal("USD/JPY", Money("100", "USD"), Money("130", "JPY")): Date(2018, 1, 1),
    }

    # Get the USD/JPY fx rate:
    fx = env.get_fx_rate("USD/JPY", fxrates)

    # Get the USD and JPY currencies:
    usd = CurrencyFactory("USD")
    jpy = CurrencyFactory("JPY")


# Generated at 2022-06-12 06:16:47.287914
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Unit test.
    """
    ## Set parameters:
    start = datetime.date(2007, 3, 31)
    end = datetime.date(2007, 4, 30)

    ## Compute day count fraction:
    res = dcfc_30_360_german(
        start=start,
        asof=end,
        end=end
    )

    assert res == Decimal("0.083333333333333")



# Generated at 2022-06-12 06:16:58.660087
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28)), 14) == Decimal("0.16666666666667")
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29)), 14) == Decimal("0.16944444444444")
    assert round(dcfc_30_360_us(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30)), 14) == Decimal("1.08333333333333")

# Generated at 2022-06-12 06:17:09.520135
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_assert = dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof)
    ex1_assert_result = 0.16939890710383
    assert round(ex1_assert, 14) == ex1_assert_result

    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex2_assert = dcfc_act_365_l(start=ex2_start, asof=ex2_asof, end=ex2_asof)
    ex2_assert_result = 0.172

# Generated at 2022-06-12 06:17:22.228507
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28),asof=datetime.date(2008, 2, 28),end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28),asof=datetime.date(2008, 2, 29),end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-12 06:17:35.043083
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry.get_instance()['act/act'].calculate_fraction(datetime.date(2017,1,1), datetime.date(2017,1,2), datetime.date(2017,1,1)) == ZERO
    assert DCCRegistry.get_instance()['act/act'].calculate_fraction(datetime.date(2017,1,1), datetime.date(2017,1,2), datetime.date(2017,1,2)) == Decimal('1')
    assert DCCRegistry.get_instance()['act/act'].calculate_fraction(datetime.date(2017,1,1), datetime.date(2017,1,2), datetime.date(2017,2,2)) == Decimal('1.0328467153285')
    assert DCC

# Generated at 2022-06-12 06:17:47.396056
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof) == Decimal(
        '0.16666666666667')
    assert dcfc_30

# Generated at 2022-06-12 06:17:54.742638
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Test case 1:
    assert DCC_ACT_365F.calculate_daily_fraction(datetime.date(2014,2,1), datetime.date(2014,2,1), datetime.date(2014,2,1)) == Decimal('0.0410958904109589')
    # Test case 2:
    assert DCC_ACT_365F.calculate_daily_fraction(datetime.date(2014,2,1), datetime.date(2014,3,1), datetime.date(2014,3,1)) == Decimal('0.0273972602739726')
    # Test case 3:

# Generated at 2022-06-12 06:18:07.536715
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28),datetime.date(2008, 2, 28),datetime.date(2008,2,28)),14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28),datetime.date(2008, 2, 29),datetime.date(2008,2,29)),14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31),datetime.date(2008, 11, 30),datetime.date(2008,11,30)),14) == Decimal('1.08196721311475')