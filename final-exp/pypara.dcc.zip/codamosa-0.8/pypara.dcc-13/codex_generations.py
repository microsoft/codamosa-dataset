

# Generated at 2022-06-12 06:11:06.005510
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(datetime.date(2018, 12, 15), datetime.date(2020, 1, 10), datetime.date(2020, 1, 10)),
                 14) == Decimal('0.54761904761905')
    assert round(dcfc_30_e_plus_360(datetime.date(2018, 2, 15), datetime.date(2020, 1, 10), datetime.date(2020, 1, 10)),
                 14) == Decimal('0.54657534246575')

# Generated at 2022-06-12 06:11:18.838259
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:11:30.553272
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from .currencies import USD, JPY
    from .monetary import Money
    from .timezone import get_current_timezone
    from .utils import gen_date
    from .valueobjects import DatePeriod, DateRange

    assert DCC_365_ACTUAL.coupon(Money(1000000, JPY), 1.25, gen_date(2017, 7, 1), gen_date(2017, 7, 1), gen_date(2018, 7, 1), 2, 15) == Money(192, JPY)
    assert DCC_365_ACTUAL.coupon(Money(1000000, JPY), 0.5, gen_date(2018, 1, 1), gen_date(2018, 7, 1), gen_date(2018, 7, 1), 2, 15) == Money(41, JPY)
    assert DCC_365_

# Generated at 2022-06-12 06:11:41.717789
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:11:52.117652
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:12:03.996028
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-12 06:12:06.466675
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    import unittest
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 06:12:12.422112
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    dcc = DCC('ACT/ACT', set(), set(), lambda *args: Decimal("0.5"))
    principal = Money("100 USD")
    rate = Decimal("0.005")
    start = Date(2014, 1, 10)
    end = Date(2014, 6, 10)
    asof = Date(2014, 2, 10)
    freq = 1
    eom = 10
    coupon = dcc.coupon(principal, rate, start, asof, end, freq, eom)
    assert coupon == Money("1.25 USD")



# Generated at 2022-06-12 06:12:25.239071
# Unit test for function dcfc_30_360_us

# Generated at 2022-06-12 06:12:29.670886
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    from tunos import dcf
    start, asof, end = datetime.date(2007, 12, 26), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)
    x1 = dcf.dcfc_30_360_german(start, asof, end)
    print(f"Answer: {x1}") # the number is exactly 0.17

# Generated at 2022-06-12 06:13:20.644560
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2018, 10, 1)
    end = datetime.date(2018, 12, 1)
    asof = datetime.date(2018, 11, 1)

    dcc = DCC("Testing DCC", set(), set(), lambda start, asof, end, freq: Decimal(1))
    assert dcc.calculate_fraction(start, asof, end) == 1
    assert dcc.calculate_fraction(asof, asof, end) == 1


# Generated at 2022-06-12 06:13:33.121560
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-12 06:13:45.574696
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-12 06:13:54.277283
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Test method calculate_daily_fraction of class DCC
    """
    # Test:
    start = datetime.date(2008, 7, 7)
    asof = datetime.date(2008, 7, 8)
    end = datetime.date(2015, 10, 6)
    freq = 4
    dcc = DCC(name='ACT/365', altnames={'ACT365F', 'ACT/ACTAFB', 'ACT/ACTICMA'},
              currencies={Currencies['USD'], Currencies['JPY']},
              calculate_fraction_method=DCC._ACT_365_F(start, asof, end, freq))
    assert dcc.calculate_daily_fraction(start, asof, end) == Decimal('0.002739726027397')

# Generated at 2022-06-12 06:13:58.560704
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 29), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 9)), 14) == round(Decimal('0.08333333333333'), 14)
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 29), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == round(Decimal('0.16666666'), 14)
    assert round(dcfc_30_360_us(start=datetime.date(2007, 11, 30), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14)

# Generated at 2022-06-12 06:14:09.509167
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    # type: () -> None
    """
    Unit test for method register of class DCCRegistryMachinery
    """
    # Test case 1
    # Test data 1
    dcc1 = DCC("Actual/Actual (ISDA)", {"Act/Act ISDA"}, {"USD"}, _calculate_fraction_act_act_isda)
    # Test code 1
    DCCRegistry.register(dcc1)
    # Test case 2
    # Test data 2
    dcc2 = DCC("Actual/Actual (ISMA)", {"Act/Act ISMA"}, {"USD"}, _calculate_fraction_act_act_isma)
    # Test code 2
    DCCRegistry.register(dcc2)
    # Test case 3
    # Test data 3

# Generated at 2022-06-12 06:14:20.260356
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """
    import datetime
    from decimal import Decimal

    from .monetary import Money, Currency

    ##################################################################
    #----USD - Actual/360
    dcc = DCCRegistry["ACT360"]
    assert dcc.calculate_daily_fraction(
        datetime.date(2014, 12, 31),
        datetime.date(2015,  1,  1),
        datetime.date(2015,  1,  1),
        Decimal(2)
    ) == Decimal(0.00555556)

# Generated at 2022-06-12 06:14:26.809110
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    from quantitative_analytics.interest_rates import day_counters
    f = day_counters.dcfc_30_e_plus_360

    assert f.__name__ == 'dcfc_30_e_plus_360'
    assert f.__doc__ != None

    assert f(datetime.date(2018, 1, 1), datetime.date(2018, 1, 31), datetime.date(2018, 1, 31)) == Decimal('0.083333333333333333333333333333333333')
    assert f(datetime.date(2018, 1, 31), datetime.date(2018, 2, 1), datetime.date(2018, 2, 1)) == Decimal('0.083333333333333333333333333333333333')

# Generated at 2022-06-12 06:14:37.674112
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert dcfc_30_360_isda(date(2007, 12, 28), date(2008, 2, 28), date(2008, 2, 28)) == 0.166666666666667
    assert dcfc_30_360_isda(date(2007, 12, 28), date(2008, 2, 29), date(2008, 2, 29)) == 0.169444444444444
    assert dcfc_30_360_isda(date(2007, 10, 31), date(2008, 11, 30), date(2008, 11, 30)) == 1.08333333333333
    assert dcfc_30_360_isda(date(2008, 2, 1), date(2009, 5, 31), date(2009, 5, 31)) == 1.33333333333333


# Generated at 2022-06-12 06:14:41.880643
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Tests the dcfc_30_360_us function.

    :return: None
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)