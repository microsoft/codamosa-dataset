

# Generated at 2022-06-18 02:42:08.955764
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:42:17.014323
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:42:28.426697
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:42:41.158840
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """
    # Test 1
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 1, 1)
    freq = None
    dcc = DCC('', set(), set(), _actual_actual_icma)
    assert dcc.calculate_daily_fraction(start, asof, end, freq) == Decimal('0')

    # Test 2
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 1, 2)
    freq = None

# Generated at 2022-06-18 02:42:46.477647
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:42:58.054843
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:43:05.882847
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-18 02:43:13.182351
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    # Test 1
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_isda(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    # Test 2
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_30_360_isda(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.16944444444444')
    # Test 3
    ex3_start,

# Generated at 2022-06-18 02:43:21.778033
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=Decimal(2)), 10) == Decimal('0.2622950819')

# Generated at 2022-06-18 02:43:28.457665
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')


# Generated at 2022-06-18 02:44:05.546909
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-18 02:44:17.757346
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:44:27.921770
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-18 02:44:36.958371
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .currencies import Currencies
    from .monetary import Money
    from .time import Date

    ## Create a DCC:
    dcc = DCC(
        name="Actual/Actual (ICMA)",
        altnames={"Actual/Actual (ICMA)", "Actual/Actual (ISDA)", "Actual/Actual", "Act/Act", "Actual/Actual (Bond)"},
        currencies=_as_ccys({"USD", "EUR", "GBP", "CHF", "JPY", "CAD", "AUD", "NZD", "SEK"}),
        calculate_fraction_method=_actual_actual_icma,
    )

    ## Calculate the fraction:

# Generated at 2022-06-18 02:44:43.989865
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:44:55.721252
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["ACT/ACT"].calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1)) == Decimal("0")
    assert DCCRegistry["ACT/ACT"].calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 2)) == Decimal("1")
    assert DCCRegistry["ACT/ACT"].calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 2)) == Decimal("1")

# Generated at 2022-06-18 02:44:59.876759
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-18 02:45:11.434982
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Test method calculate_daily_fraction of class DCC.
    """
    import unittest
    from decimal import Decimal
    from datetime import date
    from financepy.finutils.FinDateUtilities import FinDateUtilities
    from financepy.finutils.FinFrequency import FinFrequency
    from financepy.products.funding.FinDayCount import FinDayCountTypes
    from financepy.products.funding.FinDayCount import FinDayCount

    class TestMethods(unittest.TestCase):

        def test_DCC_calculate_daily_fraction(self):
            dcc = FinDayCount(FinDayCountTypes.ACT_360)
            startDate = FinDateUtilities.date(2014, 1, 1)
            endDate = FinDateUtilities.date(2014, 12, 31)
            asof

# Generated at 2022-06-18 02:45:19.464189
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:45:27.787319
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Unit test for method calculate_fraction of class DCC
    """
    # Test 1
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 1, 1)
    freq = None
    dcc = DCC("ACT/360", {"ACT/360"}, _as_ccys({"USD"}), _dcc_act_360)
    assert dcc.calculate_fraction(start, asof, end, freq) == 0

    # Test 2
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 1, 2)
    freq = None
    dcc = D

# Generated at 2022-06-18 02:50:59.868597
# Unit test for method calculate_fraction of class DCC

# Generated at 2022-06-18 02:51:08.130882
# Unit test for method calculate_fraction of class DCC

# Generated at 2022-06-18 02:51:12.732240
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
