

# Generated at 2022-06-18 02:42:06.957733
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:42:11.858364
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_e_plus_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-18 02:42:18.784169
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_german(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:42:26.370525
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:42:39.558146
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-18 02:42:49.352674
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Unit test for method calculate_fraction of class DCC
    """
    # Test 1
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 1)
    freq = None
    dcc = DCC("ACT/365", {"ACT/365"}, {"USD"}, _act_365)
    assert dcc.calculate_fraction(start, asof, end, freq) == 0

    # Test 2
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 2)
    end = datetime.date(2017, 1, 2)
    freq = None

# Generated at 2022-06-18 02:42:56.583407
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 1)
    freq = None
    dcc = DCC("", set(), set(), lambda start, asof, end, freq: Decimal(1))
    assert dcc.calculate_fraction(start, asof, end, freq) == Decimal(1)


# Generated at 2022-06-18 02:43:05.443110
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_a(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-18 02:43:12.635993
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:43:21.200077
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-18 02:44:00.382623
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal('0.0')
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == Decimal('0.002777777777777778')
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 2)) == Decimal('0.002777777777777778')


# Generated at 2022-06-18 02:44:12.128853
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:44:22.653937
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    """
    Unit test for function dcfc_30_e_360
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-18 02:44:34.419685
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies import Currencies
    from .monetary import Money
    from .commons.zeitgeist import Date
    from .commons.numbers import ZERO, ONE
    from .daycount import DCCRegistry, DCC
    from .daycount.methods import _actual_360, _actual_365, _actual_actual, _actual_365_fixed, _actual_actual_icma, _actual_actual_isda, _actual_actual_afb, _actual_actual_icma_eom, _actual_actual_isda_eom, _actual_actual_afb_eom, _thirty_360, _thirty_360_isda, _thirty_360_isda_eom, _thirty_360_eurobond, _thirty_360_eurobond_eom, _thirty_

# Generated at 2022-06-18 02:44:45.056677
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCs.ACT_360.coupon(Money(100, Currencies.USD), Decimal(0.05), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), 1) == Money(0, Currencies.USD)
    assert DCCs.ACT_360.coupon(Money(100, Currencies.USD), Decimal(0.05), datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 1), 1) == Money(0.04166666666666666666666666667, Currencies.USD)

# Generated at 2022-06-18 02:44:56.421782
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:45:07.211991
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-18 02:45:16.733153
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:45:26.415968
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08219178082192')

# Generated at 2022-06-18 02:45:32.304894
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_us(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-18 02:46:00.603694
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:46:11.950764
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 2)
    end = datetime.date(2014, 1, 3)
    freq = None
    dcc = DCC(
        name='ACT/360',
        altnames={'ACT/360', 'ACTUAL/360', 'ACTUAL/360', 'A/360', 'A360', 'ACT/360'},
        currencies={Currencies['USD']},
        calculate_fraction_method=lambda start, asof, end, freq: Decimal(_get_actual_day_count(asof, end)) / 360
    )
    assert dcc.calculate_fraction(start, asof, end, freq) == Decimal(1) / 360


# Generated at 2022-06-18 02:46:15.894184
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    dcc = DCCRegistry.find("Act/Act")
    assert dcc.name == "Act/Act"
    assert dcc.altnames == {"Actual/Actual", "Actual/Actual (Bond)", "Actual/Actual (ISMA)", "Actual/Actual (ICMA)"}
    assert dcc.currencies == {Currencies["USD"], Currencies["EUR"], Currencies["GBP"], Currencies["CHF"], Currencies["CAD"], Currencies["JPY"]}
    assert dcc.calculate_fraction_method == _calculate_act_act_fraction


# Generated at 2022-06-18 02:46:27.510475
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Tests the method calculate_daily_fraction of class DCC.
    """
    ## Define a test DCC:
    test_dcc = DCC(
        name="TEST",
        altnames={"TEST"},
        currencies=_as_ccys({"XXX"}),
        calculate_fraction_method=lambda s, a, e, f: Decimal(1),
    )

    ## Test the daily fraction calculation:
    assert test_dcc.calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal(0)

# Generated at 2022-06-18 02:46:39.240105
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-18 02:46:48.291833
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal("0.000000000000000")
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == Decimal("0.0027777777777778")
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 3)) == Decimal("0.0055555555555556")
   

# Generated at 2022-06-18 02:46:58.703566
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry.get("ACT/360").calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal("0.000000000000000")
    assert DCCRegistry.get("ACT/360").calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == Decimal("0.0027777777777778")

# Generated at 2022-06-18 02:47:09.640893
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=Decimal(2)), 10) == Decimal('0.2622950819')

# Generated at 2022-06-18 02:47:16.644047
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:47:22.457989
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """
    # Test case 1
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 1)
    freq = None
    dcc = DCC("ACT/365", {"ACT/365"}, _as_ccys({"USD", "EUR"}), _act_365)
    assert dcc.calculate_daily_fraction(start, asof, end, freq) == Decimal("0")

    # Test case 2
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 2)
    end = datetime.date(2017, 1, 2)


# Generated at 2022-06-18 02:48:11.875131
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCCRegistry.get("ACT/365").calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 3)) == Decimal("0.002739726027397")
    assert DCCRegistry.get("ACT/360").calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 3)) == Decimal("0.002777777777778")
    assert DCCRegistry.get("ACT/365L").calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 3)) == Decimal

# Generated at 2022-06-18 02:48:22.291715
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:48:31.665139
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_e_plus_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-18 02:48:37.946512
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-18 02:48:40.859940
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')


# Generated at 2022-06-18 02:48:50.478330
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Test case 1
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 1, 1)
    freq = None
    assert DCCRegistry["ACT/360"].calculate_daily_fraction(start, asof, end, freq) == 0

    # Test case 2
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 2)
    end = datetime.date(2014, 1, 2)
    freq = None

# Generated at 2022-06-18 02:49:01.201090
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:49:08.839707
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    ## Create a dummy DCC:
    dcc = DCC(
        name="Dummy",
        altnames={"Dummy1", "Dummy2"},
        currencies={Currencies["USD"]},
        calculate_fraction_method=lambda s, a, e, f: Decimal(0.5),
    )

    ## Register the DCC:
    DCCRegistry.register(dcc)

    ## Check if the DCC is registered:
    assert DCCRegistry.find("Dummy") == dcc
    assert DCCRegistry.find("Dummy1") == dcc
    assert DCCRegistry.find("Dummy2") == dcc
    assert DCCRegistry.find("dummy") == dcc
    assert DCCRegistry.find("dummy1") == dcc
    assert DCCRegistry.find

# Generated at 2022-06-18 02:49:15.950208
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:49:23.178273
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-18 02:50:43.104507
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:50:49.387019
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_360_us(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_360_us(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-18 02:50:59.363828
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .currencies import Currencies
    from .monetary import Money
    from .time import Date
    from .time.daycount import DCCRegistry
    from .time.daycount.methods import _actual_actual_icma
    from .time.daycount.methods import _actual_actual_isda
    from .time.daycount.methods import _actual_actual_icma_eom
    from .time.daycount.methods import _actual_actual_isda_eom
    from .time.daycount.methods import _actual_actual_isda_eom_30_360
    from .time.daycount.methods import _actual_actual_isda_eom_30_360_eom
    from .time.daycount.methods import _actual_actual_isda_eom_30_360

# Generated at 2022-06-18 02:51:06.804829
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-18 02:51:16.040369
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    # Test case 1
    dcc = DCC("ACT/360", {"ACT/360"}, _as_ccys({"USD", "EUR"}), _act_360)
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 1)
    freq = None
    assert dcc.calculate_daily_fraction(start, asof, end, freq) == Decimal("0")

    # Test case 2
    dcc = DCC("ACT/360", {"ACT/360"}, _as_ccys({"USD", "EUR"}), _act_360)
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 2)
   