

# Generated at 2022-06-18 02:42:05.513436
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:42:14.904307
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:42:21.192763
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:42:30.066538
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:42:42.204881
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-18 02:42:52.055225
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:42:59.008293
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:43:03.780033
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    from .currencies import Currencies
    from .monetary import Money
    from .curves import Curve
    from .curves.interpolators import LinearInterpolator
    from .curves.interpolators import StepInterpolator
    from .curves.interpolators import StepInterpolator
    from .curves.interpolators import StepInterpolator
    from .curves.interpolators import StepInterpolator
    from .curves.interpolators import StepInterpolator
    from .curves.interpolators import StepInterpolator
    from .curves.interpolators import StepInterpolator
    from .curves.interpolators import StepInterpolator
    from .curves.interpolators import StepInterpolator
    from .curves.interpolators import StepInterpolator

# Generated at 2022-06-18 02:43:09.630928
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    """
    Unit test for method coupon of class DCC
    """
    from .currencies import Currencies
    from .monetary import Money
    from .time.calendars.target import TARGET
    from .time.daycounters import ActualActual
    from .time.periods import Period
    from .time.schedule import Schedule
    from .time.tenors import Tenor
    from .time.units import Day
    from .time.weekdays import Weekdays

    # Test 1:
    # Test the coupon calculation for a bond with the following details:
    #   - Principal: 100,000,000
    #   - Coupon: 5%
    #   - Frequency: Semi-annual
    #   - Start date: 1st January 2014
    #   - End date: 1st January 2019
    #   - Day counter: Actual/Act

# Generated at 2022-06-18 02:43:20.543033
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:43:47.645996
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:43:52.412238
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-18 02:44:01.996674
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["ACT/ACT"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal('0')
    assert DCCRegistry["ACT/ACT"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == Decimal('1')
    assert DCCRegistry["ACT/ACT"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 3)) == Decimal('2')

# Generated at 2022-06-18 02:44:13.578060
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from datetime import date
    from decimal import Decimal
    from finpy.products.currencies import Currencies
    from finpy.products.monetary import Money
    from finpy.products.daycountconventions import DCCRegistry
    from finpy.products.daycountconventions import DCC

    # Test 1
    start = date(2018, 1, 1)
    asof = date(2018, 1, 2)
    end = date(2018, 1, 3)
    freq = Decimal(1)
    dcc = DCCRegistry.get_dcc('ACT/360')
    assert dcc.calculate_daily_fraction(start, asof, end, freq) == Decimal('0.002777777777777778')

    # Test 2
    start = date(2018, 1, 1)

# Generated at 2022-06-18 02:44:23.299632
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Unit test for function dcfc_30_360_us
    """
    ## Test 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_dcf = dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof)
    assert round(ex1_dcf, 14) == Decimal('0.16666666666667')

    ## Test 2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-18 02:44:35.181126
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry.get_dcc("ACT/360").calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1)) == Decimal("0")
    assert DCCRegistry.get_dcc("ACT/360").calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 2)) == Decimal("1")
    assert DCCRegistry.get_dcc("ACT/360").calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 3)) == Decimal("2")
    assert DCCRegistry.get_d

# Generated at 2022-06-18 02:44:45.803007
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:44:56.798924
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Test function dcfc_30_360_us.
    """
    ## Test 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_dcf = dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof)
    assert round(ex1_dcf, 14) == Decimal('0.16666666666667')

    ## Test 2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-18 02:45:08.195217
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-18 02:45:17.823827
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc = DCC(
        name="30/360",
        altnames={"30/360", "30/360 US", "30/360 US (NASD)", "30/360 ISDA", "30/360 ISDA (NASD)"},
        currencies=_as_ccys({"USD", "EUR", "GBP", "JPY", "CHF", "CAD", "AUD", "NZD"}),
        calculate_fraction_method=_dcc_30_360_calculate_fraction,
    )
    assert dcc.calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal('0.00')

# Generated at 2022-06-18 02:46:09.982489
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find("Act/Act")
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find("act/act")
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find("ACT/ACT")
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find("Act/act")
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find("act/Act")
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find("Act/Act ")
    assert DCCRegistry.find("Act/Act") == DCCRegistry.find(" Act/Act")
    assert DCCRegistry.find("Act/Act") == DCC

# Generated at 2022-06-18 02:46:20.817356
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == 0

# Generated at 2022-06-18 02:46:31.249499
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCCRegistry.get("ACT/360").interest(Money(100, "USD"), Decimal(0.05), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Money(0, "USD")
    assert DCCRegistry.get("ACT/360").interest(Money(100, "USD"), Decimal(0.05), datetime.date(2017, 1, 1), datetime.date(2017, 1, 2)) == Money(0.05, "USD")
    assert DCCRegistry.get("ACT/360").interest(Money(100, "USD"), Decimal(0.05), datetime.date(2017, 1, 1), datetime.date(2017, 1, 3)) == Money(0.10, "USD")

# Generated at 2022-06-18 02:46:42.597642
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=Decimal(2)), 10) == Decimal('0.2622950820')

# Generated at 2022-06-18 02:46:51.582857
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCC("Act/Act", {"Actual/Actual", "Actual/Actual (ISDA)", "Actual/Actual (Bond)", "Act/Act"}, {}, _dcc_act_act)
    DCCRegistry.register(dcc)
    assert DCCRegistry.find("Act/Act") == dcc
    assert DCCRegistry.find("Actual/Actual") == dcc
    assert DCCRegistry.find("Actual/Actual (ISDA)") == dcc
    assert DCCRegistry.find("Actual/Actual (Bond)") == dcc
    assert DCCRegistry.find("Act/Act") == dcc
    assert DCCRegistry.find("Act/Act").name == "Act/Act"

# Generated at 2022-06-18 02:47:02.966401
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-18 02:47:12.813488
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:47:17.683772
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:47:24.631435
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:47:34.003845
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:48:50.478928
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 1, 1)
    freq = None
    assert DCCRegistry.get("ACT/365").calculate_fraction(start, asof, end, freq) == 0
    assert DCCRegistry.get("ACT/360").calculate_fraction(start, asof, end, freq) == 0
    assert DCCRegistry.get("ACT/ACT").calculate_fraction(start, asof, end, freq) == 0
    assert DCCRegistry.get("ACT/ACT ISDA").calculate_fraction(start, asof, end, freq) == 0

# Generated at 2022-06-18 02:49:01.200328
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None

# Generated at 2022-06-18 02:49:11.616602
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Test function dcfc_30_360_us.
    """
    ## Test 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex1_result = dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof)
    assert round(ex1_result, 14) == Decimal('0.16666666666667')

    ## Test 2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-18 02:49:23.891056
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1)) == Decimal("0.00")
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 2)) == Decimal("0.00")
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 2)) == Decimal("0.00")
    assert DCCRegistry["ACT/360"].calculate_

# Generated at 2022-06-18 02:49:36.013294
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:49:40.974079
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:49:47.149889
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCC("Act/Act", {"Actual/Actual", "Act/Act"}, {"USD"}, _calculate_act_act_fraction)
    DCCRegistry.register(dcc)
    assert DCCRegistry.find("Act/Act") == dcc
    assert DCCRegistry.find("Actual/Actual") == dcc
    assert DCCRegistry.find("Act/Act") == dcc
    assert DCCRegistry.find("Actual/Actual") == dcc
    assert DCCRegistry.find("Act/Act") == dcc
    assert DCCRegistry.find("Actual/Actual") == dcc
    assert DCCRegistry.find("Act/Act") == dcc
    assert DCCRegistry.find("Actual/Actual") == dcc
    assert DCC

# Generated at 2022-06-18 02:49:58.359701
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None

# Generated at 2022-06-18 02:50:09.068081
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:50:15.976028
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')