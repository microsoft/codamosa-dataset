

# Generated at 2022-06-18 02:41:56.156463
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Test method calculate_daily_fraction of class DCC
    """
    # Test case 1
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 1)
    freq = None
    dcc = DCC(name="ACT/360", altnames=set(), currencies=set(), calculate_fraction_method=DCCRegistry.ACT_360.calculate_fraction_method)
    assert dcc.calculate_daily_fraction(start, asof, end, freq) == Decimal('0')

    # Test case 2
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 2)
    end = datetime

# Generated at 2022-06-18 02:42:00.302437
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')


# Generated at 2022-06-18 02:42:09.201728
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """
    ## Create a dummy DCC object:
    dcc = DCC("Dummy", set(), set(), lambda s, a, e, f: Decimal(a.day - s.day) / Decimal(e.day - s.day))

    ## Test:
    assert dcc.calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 2)) == ZERO
    assert dcc.calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == ONE

# Generated at 2022-06-18 02:42:14.040159
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_plus_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:42:20.185487
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:42:28.285721
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCRegistry["ACT/360"].coupon(Money(100, "USD"), Decimal(0.05), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), 1) == Money(0, "USD")
    assert DCCRegistry["ACT/360"].coupon(Money(100, "USD"), Decimal(0.05), datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 1), 1) == Money(0.05, "USD")

# Generated at 2022-06-18 02:42:41.158963
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal(0)
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == Decimal(1)
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 3)) == Decimal(1)

# Generated at 2022-06-18 02:42:49.969333
# Unit test for method calculate_daily_fraction of class DCC

# Generated at 2022-06-18 02:43:01.067858
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from datetime import date
    from decimal import Decimal
    from financepy.products.funding.Currencies import Currencies
    from financepy.products.funding.DayCountConventions import DCC, DCCRegistry
    from financepy.products.funding.Money import Money

    dcc = DCCRegistry.get_dcc('ACT/360')
    start = date(2017, 1, 1)
    asof = date(2017, 1, 1)
    end = date(2017, 1, 2)
    freq = Decimal(1)
    daily_fraction = dcc.calculate_daily_fraction(start, asof, end, freq)
    assert daily_fraction == Decimal(0)

    asof = date(2017, 1, 2)
    daily_fraction = dcc.calculate_daily

# Generated at 2022-06-18 02:43:06.783359
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Tests the method find of class DCCRegistryMachinery.
    """
    ## Create the registry:
    registry = DCCRegistryMachinery()

    ## Register some day count conventions:
    registry.register(DCC("Act/Act", {"Act/Act", "Actual/Actual", "Actual/365", "Actual/365 Fixed"}, set(), _dcf_act_act))
    registry.register(DCC("Act/360", {"Act/360", "Actual/360"}, set(), _dcf_act_360))
    registry.register(DCC("Act/365", {"Act/365", "Actual/365"}, set(), _dcf_act_365))

# Generated at 2022-06-18 02:43:40.760146
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08196721311475')

# Generated at 2022-06-18 02:43:54.215052
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:44:00.821321
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCCRegistry["ACT/360"].calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal('0.002777777777777778')
    assert DCCRegistry["ACT/360"].calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == Decimal('0.002777777777777778')
    assert DCCRegistry["ACT/360"].calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 3), datetime.date(2017, 1, 3)) == Decimal

# Generated at 2022-06-18 02:44:12.613060
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:44:23.065519
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:44:34.914306
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_nl_365(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-18 02:44:45.508182
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    assert DCCRegistry["ACT/360"].calculate_daily_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1)) == Decimal("0")
    assert DCCRegistry["ACT/360"].calculate_daily_fraction(datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 2)) == Decimal("0.002777777777777778")

# Generated at 2022-06-18 02:44:56.799149
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies import Currencies
    from .monetary import Money
    from .time.calendars import BusinessCalendar
    from .time.calendars.western import WesternCalendar
    from .time.daycount import DCC

    ## Define a calendar:
    calendar = BusinessCalendar(WesternCalendar(Currencies.USD), WesternCalendar(Currencies.EUR))

    ## Define a day count convention:
    dcc = DCC.ACT_360

    ## Define a principal:
    principal = Money(100, Currencies.USD)

    ## Define a rate:
    rate = Decimal("0.05")

    ## Define a start date:
    start = calendar.adjust(datetime.date(2014, 1, 1), "FOLLOWING")

    ## Define an end date:

# Generated at 2022-06-18 02:45:08.195724
# Unit test for method interest of class DCC
def test_DCC_interest():
    """
    Unit test for method interest of class DCC
    """
    # Test 1
    # Test with a simple case
    # Expected result: 0.00
    assert DCCRegistry["ACT/360"].interest(Money(100, "USD"), Decimal(0.1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Money(0, "USD")

    # Test 2
    # Test with a simple case
    # Expected result: 0.00
    assert DCCRegistry["ACT/360"].interest(Money(100, "USD"), Decimal(0.1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 2)) == Money(0.2777777777777778, "USD")

    # Test 3
    # Test with

# Generated at 2022-06-18 02:45:17.472086
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)) == Decimal('0.16942884946478')
    assert dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)) == Decimal('0.17216108990194')
    assert dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)) == Decimal('1.08243131970956')

# Generated at 2022-06-18 02:49:40.283577
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_act_365_l(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16939890710383')

# Generated at 2022-06-18 02:49:51.536050
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:49:56.486243
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-18 02:50:03.191396
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    """
    Tests the method register of class DCCRegistryMachinery.
    """
    ## Create the registry:
    registry = DCCRegistryMachinery()

    ## Create a DCC:
    dcc = DCC("Act/Act", {"Actual/Actual", "Act/Act"}, {"USD"}, _calculate_act_act_fraction)

    ## Register the DCC:
    registry.register(dcc)

    ## Check if the DCC is registered:
    assert registry.find("Act/Act") == dcc

    ## Check if the DCC is registered:
    assert registry.find("Actual/Actual") == dcc

    ## Check if the DCC is registered:
    assert registry.find("Act/Act") == dcc

    ## Check if the DCC is registered:

# Generated at 2022-06-18 02:50:12.430587
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal("0.0")
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == Decimal("0.002777777777777778")
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 2)) == Decimal("0.002777777777777778")


# Generated at 2022-06-18 02:50:22.867594
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), 2), 10) == Decimal('0.2622950819')
    assert round(dcfc_act_act_icma(datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2), 4), 10) == Decimal('0.1311475096')

# Generated at 2022-06-18 02:50:31.854452
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:50:42.430868
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_e_plus_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-18 02:50:48.721618
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """
    # Test 1
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 2)
    end = datetime.date(2014, 1, 3)
    freq = None
    dcc = DCC("ACT/365", {"ACT/365", "ACT/365F"}, _as_ccys({"USD", "EUR"}), _act_365_fraction)
    assert dcc.calculate_daily_fraction(start, asof, end, freq) == Decimal("0.002739726027397")

    # Test 2
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 3)


# Generated at 2022-06-18 02:50:53.954054
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')