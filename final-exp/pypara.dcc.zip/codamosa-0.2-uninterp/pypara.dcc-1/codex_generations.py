

# Generated at 2022-06-18 02:41:43.920793
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Test for method calculate_fraction of class DCC
    """
    # Test for method calculate_fraction of class DCC
    # Test for method calculate_fraction of class DCC
    # Test for method calculate_fraction of class DCC
    # Test for method calculate_fraction of class DCC
    # Test for method calculate_fraction of class DCC
    # Test for method calculate_fraction of class DCC
    # Test for method calculate_fraction of class DCC
    # Test for method calculate_fraction of class DCC
    # Test for method calculate_fraction of class DCC
    # Test for method calculate_fraction of class DCC
    # Test for method calculate_fraction of class DCC
    # Test for method calculate_fraction of class DCC
    # Test for method calculate_fraction of class D

# Generated at 2022-06-18 02:41:54.751616
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    ex1_start, ex1_asof, ex1_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)
    assert round(dcfc_act_act_icma(start=ex1_start, asof=ex1_asof, end=ex1_end), 10) == Decimal('0.5245901639')
    ex2_start, ex2_asof, ex2_end = datetime.date(2019, 3, 2), datetime.date(2019, 9, 10), datetime.date(2020, 3, 2)

# Generated at 2022-06-18 02:42:02.118756
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from datetime import date
    from decimal import Decimal
    from financepy.finutils.FinDate import FinDate
    from financepy.finutils.FinGlobalTypes import FinDayCountTypes
    from financepy.products.funding.FinIborSingleCurve import FinIborSingleCurve
    from financepy.products.funding.FinIborDeposit import FinIborDeposit
    from financepy.products.funding.FinIborSwap import FinIborSwap
    from financepy.products.funding.FinIborFRA import FinIborFRA
    from financepy.products.funding.FinIborFuture import FinIborFuture
    from financepy.products.funding.FinIborCapFloor import FinIborCapFloor
    from financepy.products.funding.FinIborCaplet import FinIborCaplet

# Generated at 2022-06-18 02:42:08.507106
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:42:19.231234
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from .currencies import Currencies
    from .monetary import Money
    from .daycount import DCCRegistry
    from datetime import date
    from decimal import Decimal
    dcc = DCCRegistry.get_dcc('ACT/360')
    principal = Money(Decimal('100'), Currencies.USD)
    rate = Decimal('0.05')
    start = date(2014, 1, 1)
    asof = date(2014, 1, 15)
    end = date(2014, 1, 31)
    freq = Decimal('1')
    eom = None

# Generated at 2022-06-18 02:42:29.743629
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:42:41.993243
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:42:51.922018
# Unit test for method register of class DCCRegistryMachinery
def test_DCCRegistryMachinery_register():
    dcc = DCC("Act/Act", {"Actual/Actual", "Actual/365", "Actual/Actual (ISDA)", "Act/Act", "Act/365"}, {}, _calculate_fraction_act_act)
    DCCRegistry.register(dcc)
    assert dcc.name in DCCRegistry.table
    assert dcc.altnames.intersection(DCCRegistry.table.keys())
    assert dcc.currencies.intersection(DCCRegistry.table.keys())
    assert DCCRegistry.find("Act/Act") == dcc
    assert DCCRegistry.find("Act/Act").name == dcc.name
    assert DCCRegistry.find("Act/Act").altnames == dcc.altnames

# Generated at 2022-06-18 02:43:02.242820
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:43:08.064408
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Tests the method calculate_fraction of class DCC.
    """
    ## Create a dummy DCC:
    dcc = DCC("dummy", {"dummy"}, set(), lambda s, a, e, f: Decimal(1))

    ## Test the method:
    assert dcc.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == 1
    assert dcc.calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == 1

# Generated at 2022-06-18 02:43:27.575093
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:43:38.700712
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)) == Decimal('0.16666666666667')
    assert dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)) == Decimal('0.16944444444444')
    assert dcfc_30_e_plus_360(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)) == Decimal('1.08333333333333')

# Generated at 2022-06-18 02:43:51.677215
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    dcc = DCC(name='ACT/360', altnames=set(), currencies=set(), calculate_fraction_method=lambda start, asof, end, freq: (asof - start).days / 360)
    assert dcc.calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 3)) == Decimal('0.002777777777777778')
    assert dcc.calculate_daily_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 3)) == Decimal('0.002777777777777778')

# Generated at 2022-06-18 02:43:56.923061
# Unit test for function dcfc_act_365_l
def test_dcfc_act_365_l():
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16939890710383')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_l(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Decimal

# Generated at 2022-06-18 02:44:05.736039
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .currencies import Currencies
    from .monetary import Money
    from .commons.zeitgeist import Date
    from .commons.numbers import ZERO, ONE
    from .daycount import DCCRegistry
    from .daycount import DCC
    from .daycount import _get_actual_day_count
    from .daycount import _get_date_range
    from .daycount import _has_leap_day
    from .daycount import _is_last_day_of_month
    from .daycount import _last_payment_date
    from .daycount import _next_payment_date
    from .daycount import _construct_date
    from .daycount import DCFC
    from decimal import Decimal
    from typing import Callable, Dict, Iterable, List, NamedTuple, Optional, Set, Union

# Generated at 2022-06-18 02:44:09.785083
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=Decimal(2)), 10) == Decimal('0.2622950820')

# Generated at 2022-06-18 02:44:20.684411
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .currencies import Currencies
    from .monetary import Money
    from .commons.zeitgeist import Date
    from .daycount import DCCRegistry
    from decimal import Decimal
    dcc = DCCRegistry.get_dcc("ACT/360")
    principal = Money(Decimal("100.00"), Currencies.USD)
    rate = Decimal("0.05")
    start = Date(2018, 1, 1)
    asof = Date(2018, 1, 31)
    end = Date(2018, 2, 28)
    freq = Decimal("1")
    assert dcc.interest(principal, rate, start, asof, end, freq) == Money(Decimal("2.50"), Currencies.USD)

# Generated at 2022-06-18 02:44:28.854646
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:44:37.813635
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:44:47.445519
# Unit test for method interest of class DCC
def test_DCC_interest():
    from .currencies import Currencies
    from .monetary import Money
    from .time import Date
    from .time.calendars.target import TARGET
    from .time.daycount import DCC, DCCRegistry
    from .time.holidays import HolidayCalendar, HolidayCalendarFactory
    from .time.holidays.united_kingdom import UnitedKingdom
    from .time.holidays.united_states import UnitedStates

    # Create a calendar
    calendar = HolidayCalendarFactory('UnitedKingdom')

    # Create a DCC
    dcc = DCCRegistry.get_instance('ACT/365')

    # Create a date
    date = Date(2018, 1, 1)

    # Create a money
    money = Money(100, Currencies.USD)

    # Calculate the interest

# Generated at 2022-06-18 02:45:20.793948
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    """
    Unit test for function dcfc_30_360_german.
    """
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

# Generated at 2022-06-18 02:45:31.823941
# Unit test for function dcfc_nl_365
def test_dcfc_nl_365():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_nl_365(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16986301369863')

# Generated at 2022-06-18 02:45:36.907237
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:45:42.483975
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    # Test case 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_e_360(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')
    # Test case 2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    assert round(dcfc_30_e_360(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.16944444444444')
    # Test case 3:
    ex

# Generated at 2022-06-18 02:45:53.253859
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:46:02.742263
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 1)
    freq = None
    assert DCCRegistry.get("ACT/360").calculate_fraction(start, asof, end, freq) == 0
    assert DCCRegistry.get("ACT/365").calculate_fraction(start, asof, end, freq) == 0
    assert DCCRegistry.get("ACT/ACT").calculate_fraction(start, asof, end, freq) == 0
    assert DCCRegistry.get("ACT/ACT ISDA").calculate_fraction(start, asof, end, freq) == 0

# Generated at 2022-06-18 02:46:07.782010
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:46:18.360048
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:46:30.313645
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """
    ## Create a DCC object:
    dcc = DCC(
        name="ACT/365",
        altnames={"ACT/365", "ACT/365F", "ACT/365L", "ACT/365.25", "ACT/365.25F", "ACT/365.25L", "ACT/ACT", "ACT/ACT.ISDA"},
        currencies=_as_ccys({"USD", "EUR", "GBP", "CHF", "JPY", "CAD", "AUD", "NZD", "SEK", "NOK", "DKK", "TRY"}),
        calculate_fraction_method=_act_365,
    )

    ## Test:

# Generated at 2022-06-18 02:46:41.984081
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCCRegistry["30/360"].interest(Money(100, "USD"), Decimal(0.05), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Money(0, "USD")
    assert DCCRegistry["30/360"].interest(Money(100, "USD"), Decimal(0.05), datetime.date(2017, 1, 1), datetime.date(2017, 1, 2)) == Money(0.0416666666666666666666666666667, "USD")
    assert DCCRegistry["30/360"].interest(Money(100, "USD"), Decimal(0.05), datetime.date(2017, 1, 1), datetime.date(2017, 1, 3)) == Money(0.0833333333333333333333333333333, "USD")
    assert DCCReg

# Generated at 2022-06-18 02:47:33.262075
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:47:42.253336
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:47:48.706113
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from datetime import date
    from decimal import Decimal
    from financepy.products.funding.Curves import Curve, CurveDCC
    from financepy.products.funding.Curves import CurveTypes
    from financepy.products.funding.Curves import CurveInterpolationTypes
    from financepy.products.funding.Curves import CurveDayCountTypes
    from financepy.products.funding.Curves import CurveCalibrationTypes
    from financepy.products.funding.Curves import CurveBootstrapTypes
    from financepy.products.funding.Curves import CurveInterpolatorTypes
    from financepy.products.funding.Curves import CurveExtrapolatorTypes
    from financepy.products.funding.Curves import CurveInterpolator
    from financepy.products.funding.Curves import CurveInterpolatorFactory

# Generated at 2022-06-18 02:47:59.903422
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Unit test for method calculate_daily_fraction of class DCC
    """
    # Test case 1
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 1)
    end = datetime.date(2014, 1, 1)
    freq = None
    dcc = DCC('', set(), set(), _actual_actual_icma_method)
    assert dcc.calculate_daily_fraction(start, asof, end, freq) == Decimal('0')

    # Test case 2
    start = datetime.date(2014, 1, 1)
    asof = datetime.date(2014, 1, 2)
    end = datetime.date(2014, 1, 2)
    freq = None

# Generated at 2022-06-18 02:48:10.501429
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:48:19.672216
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    """
    Test for method calculate_daily_fraction of class DCC
    """
    # Test for method calculate_daily_fraction of class DCC
    # Test for method calculate_daily_fraction of class DCC
    # Test for method calculate_daily_fraction of class DCC
    # Test for method calculate_daily_fraction of class DCC
    # Test for method calculate_daily_fraction of class DCC
    # Test for method calculate_daily_fraction of class DCC
    # Test for method calculate_daily_fraction of class DCC
    # Test for method calculate_daily_fraction of class DCC
    # Test for method calculate_daily_fraction of class DCC
    # Test for method calculate_daily_fraction of class DCC
    # Test for method calculate_daily_fraction of class DCC
    #

# Generated at 2022-06-18 02:48:30.407046
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:48:36.955772
# Unit test for method find of class DCCRegistryMachinery

# Generated at 2022-06-18 02:48:47.865531
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from datetime import date
    from decimal import Decimal
    from financepy.finutils.FinDate import FinDate
    from financepy.finutils.FinGlobalTypes import FinDayCountTypes
    from financepy.products.funding.FinIborSingleCurve import FinIborSingleCurve
    from financepy.products.funding.FinIborDeposit import FinIborDeposit
    from financepy.products.funding.FinIborSwap import FinIborSwap
    from financepy.products.funding.FinIborFRA import FinIborFRA
    from financepy.products.funding.FinIborFuture import FinIborFuture
    from financepy.products.funding.FinIborCapFloor import FinIborCapFloor
    from financepy.products.funding.FinIborCapFloor import FinIborCapFloorTypes

# Generated at 2022-06-18 02:48:59.150361
# Unit test for method interest of class DCC
def test_DCC_interest():
    assert DCCRegistry["ACT/360"].interest(Money(100, "USD"), 0.05, datetime.date(2015, 1, 1), datetime.date(2015, 1, 1)) == Money(0, "USD")
    assert DCCRegistry["ACT/360"].interest(Money(100, "USD"), 0.05, datetime.date(2015, 1, 1), datetime.date(2015, 1, 2)) == Money(0.1388888888888889, "USD")
    assert DCCRegistry["ACT/360"].interest(Money(100, "USD"), 0.05, datetime.date(2015, 1, 1), datetime.date(2015, 1, 3)) == Money(0.2777777777777778, "USD")
    assert DCCRegistry["ACT/360"].interest