

# Generated at 2022-06-18 02:41:45.359272
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:41:56.118048
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:42:05.934930
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:42:11.601193
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:42:15.928252
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None
    assert DCCRegistry.find("Act/Act") is not None

# Generated at 2022-06-18 02:42:27.358934
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == 0
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == Decimal('0.002777777777777778')
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 3)) == Decimal('0.005555555555555556')
    assert DCCRegistry

# Generated at 2022-06-18 02:42:39.766229
# Unit test for method find of class DCCRegistryMachinery
def test_DCCRegistryMachinery_find():
    """
    Tests the method find of class DCCRegistryMachinery.
    """
    ## Create the registry:
    registry = DCCRegistryMachinery()

    ## Create the day count convention:
    dcc = DCC(
        name="Actual/Actual",
        altnames={"Act/Act", "Actual/Actual (ISDA)", "Actual/Actual (Bond)", "Actual/Actual (ICMA)"},
        currencies={Currencies["USD"], Currencies["EUR"]},
        calculate_fraction_method=calculate_fraction_actual_actual,
    )

    ## Register the day count convention:
    registry.register(dcc)

    ## Find the day count convention:
    assert registry.find("Act/Act") == dcc
    assert registry.find("Actual/Actual")

# Generated at 2022-06-18 02:42:49.462879
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:43:01.067361
# Unit test for function dcfc_30_360_german
def test_dcfc_30_360_german():
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_german(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:43:06.813041
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["ACT/ACT"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal("0")
    assert DCCRegistry["ACT/ACT"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == Decimal("1")
    assert DCCRegistry["ACT/ACT"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 3)) == Decimal("1")

# Generated at 2022-06-18 02:43:27.507443
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:43:38.594133
# Unit test for function dcfc_30_e_plus_360
def test_dcfc_30_e_plus_360():
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_e_plus_360(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-18 02:43:48.519142
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:43:53.553949
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:44:00.490137
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC("ACT/360", {"ACT/360"}, _as_ccys({"USD"}), _act_360).coupon(Money(100, "USD"), Decimal("0.05"), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), 1) == Money(0, "USD")
    assert DCC("ACT/360", {"ACT/360"}, _as_ccys({"USD"}), _act_360).coupon(Money(100, "USD"), Decimal("0.05"), datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 1), 1) == Money(0.05, "USD")

# Generated at 2022-06-18 02:44:12.231252
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry.get("ACT/360").calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == Decimal(0)
    assert DCCRegistry.get("ACT/360").calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == Decimal(1)
    assert DCCRegistry.get("ACT/360").calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 3)) == Decimal(1)
    assert DCCRegistry.get("ACT/360").calculate_fraction

# Generated at 2022-06-18 02:44:22.729635
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:44:34.555787
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Unit test for function dcfc_30_360_us.
    """
    ## Test case 1:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

    ## Test case 2:
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)

# Generated at 2022-06-18 02:44:45.144388
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    """
    Test function dcfc_30_360_us.
    """
    ## Test data:
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)

    ## Test:

# Generated at 2022-06-18 02:44:56.500027
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies import Currencies
    from .monetary import Money
    from .commons.zeitgeist import Date
    from .daycount import DCCRegistry
    from .daycount import DCC

    # Test for DCC.ACT_360
    dcc = DCCRegistry.get_dcc('ACT_360')
    start = Date(2018, 1, 1)
    asof = Date(2018, 1, 2)
    end = Date(2018, 1, 3)
    freq = Decimal(1)
    assert dcc.calculate_daily_fraction(start, asof, end, freq) == Decimal('0.002777777777777778')

    # Test for DCC.ACT_365
    dcc = DCCRegistry.get_dcc('ACT_365')
    start

# Generated at 2022-06-18 02:45:31.909035
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from .currencies import Currencies
    from .monetary import Money
    from .time import Date
    from .time.dcc import DCCRegistry, DCC

    ## Create a DCC:

# Generated at 2022-06-18 02:45:36.970159
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=ex2_start, asof=ex2_asof, end=ex2_asof), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(start=ex3_start, asof=ex3_asof, end=ex3_asof), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-18 02:45:42.534645
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:45:53.377484
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCC("ACT/ACT", {"ACT/ACT"}, _as_ccys({"USD"}), _act_act_dcf).coupon(Money(100, "USD"), 0.05, datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), 1) == Money(0, "USD")
    assert DCC("ACT/ACT", {"ACT/ACT"}, _as_ccys({"USD"}), _act_act_dcf).coupon(Money(100, "USD"), 0.05, datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 1), 1) == Money(0.05, "USD")

# Generated at 2022-06-18 02:46:02.913605
# Unit test for function dcfc_30_e_360
def test_dcfc_30_e_360():
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_e_360(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:46:07.929638
# Unit test for function dcfc_act_365_a
def test_dcfc_act_365_a():
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16986301369863')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17213114754098')
    assert round(dcfc_act_365_a(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec

# Generated at 2022-06-18 02:46:13.282239
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    ex1_start, ex1_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 28)
    ex2_start, ex2_asof = datetime.date(2007, 12, 28), datetime.date(2008, 2, 29)
    ex3_start, ex3_asof = datetime.date(2007, 10, 31), datetime.date(2008, 11, 30)
    ex4_start, ex4_asof = datetime.date(2008, 2, 1), datetime.date(2009, 5, 31)
    assert round(dcfc_30_360_us(start=ex1_start, asof=ex1_asof, end=ex1_asof), 14) == Decimal('0.16666666666667')

# Generated at 2022-06-18 02:46:25.145628
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    from .currencies import Currencies
    from .monetary import Money
    from .enums import DayCountConventions
    from .daycount import DCCRegistry

    dcc = DCCRegistry[DayCountConventions.ACTUAL_360]
    assert dcc.coupon(Money(100, Currencies.USD), 0.05, datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), 1) == Money(0, Currencies.USD)
    assert dcc.coupon(Money(100, Currencies.USD), 0.05, datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 1), 1) == Money(0.05, Currencies.USD)

# Generated at 2022-06-18 02:46:35.179047
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08333333333333')

# Generated at 2022-06-18 02:46:39.258673
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:49:10.897448
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 28), datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(datetime.date(2007, 12, 28), datetime.date(2008, 2, 29), datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')
    assert round(dcfc_act_act(datetime.date(2007, 10, 31), datetime.date(2008, 11, 30), datetime.date(2008, 11, 30)), 14) == Decimal('1.08243131970956')

# Generated at 2022-06-18 02:49:23.283127
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)) == 0
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 2)) == Decimal('0.002777777777777778')
    assert DCCRegistry["ACT/360"].calculate_fraction(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2), datetime.date(2017, 1, 3)) == Decimal('0.005555555555555556')
    assert DCCRegistry

# Generated at 2022-06-18 02:49:30.091660
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:49:40.701235
# Unit test for function dcfc_30_360_us
def test_dcfc_30_360_us():
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_us(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')

# Generated at 2022-06-18 02:49:46.131775
# Unit test for function dcfc_act_act
def test_dcfc_act_act():
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16942884946478')
    assert round(dcfc_act_act(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.17216108990194')

# Generated at 2022-06-18 02:49:57.523088
# Unit test for method calculate_fraction of class DCC
def test_DCC_calculate_fraction():
    """
    Unit test for method calculate_fraction of class DCC
    """
    # Test 1
    start = datetime.date(2017, 1, 1)
    asof = datetime.date(2017, 1, 1)
    end = datetime.date(2017, 1, 1)
    freq = None
    dcc = DCC(
        name='ACT/360',
        altnames=set(),
        currencies=set(),
        calculate_fraction_method=lambda start, asof, end, freq: Decimal(
            _get_actual_day_count(start, end)) / Decimal(360)
    )
    assert dcc.calculate_fraction(start, asof, end, freq) == Decimal('0')

    # Test 2

# Generated at 2022-06-18 02:50:08.902186
# Unit test for method coupon of class DCC
def test_DCC_coupon():
    assert DCCRegistry.get("ACT/ACT").coupon(Money(100, "USD"), Decimal("0.05"), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), datetime.date(2014, 1, 1), 1) == Money(0, "USD")
    assert DCCRegistry.get("ACT/ACT").coupon(Money(100, "USD"), Decimal("0.05"), datetime.date(2014, 1, 1), datetime.date(2014, 1, 2), datetime.date(2014, 1, 1), 1) == Money(0.05, "USD")

# Generated at 2022-06-18 02:50:20.639049
# Unit test for method calculate_daily_fraction of class DCC
def test_DCC_calculate_daily_fraction():
    from datetime import date
    from decimal import Decimal
    from financepy.finutils.FinDate import FinDate
    from financepy.finutils.FinFrequency import FinFrequency
    from financepy.finutils.FinDayCount import FinDayCountTypes
    from financepy.finutils.FinDayCount import FinDayCount
    from financepy.finutils.FinGlobalTypes import FinSwapTypes
    from financepy.products.funding.FinIborSingleCurveSwap import FinIborSingleCurveSwap
    from financepy.products.funding.FinIborDeposit import FinIborDeposit
    from financepy.products.funding.FinIborFuture import FinIborFuture
    from financepy.products.funding.FinIborFRA import FinIborFRA
    from financepy.products.funding.FinIborSwap import FinI

# Generated at 2022-06-18 02:50:28.870300
# Unit test for function dcfc_act_act_icma
def test_dcfc_act_act_icma():
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2)), 10) == Decimal('0.5245901639')
    assert round(dcfc_act_act_icma(start=datetime.date(2019, 3, 2), asof=datetime.date(2019, 9, 10), end=datetime.date(2020, 3, 2), freq=2), 10) == Decimal('0.2622950819')

# Generated at 2022-06-18 02:50:35.666338
# Unit test for function dcfc_30_360_isda
def test_dcfc_30_360_isda():
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 28), end=datetime.date(2008, 2, 28)), 14) == Decimal('0.16666666666667')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 12, 28), asof=datetime.date(2008, 2, 29), end=datetime.date(2008, 2, 29)), 14) == Decimal('0.16944444444444')
    assert round(dcfc_30_360_isda(start=datetime.date(2007, 10, 31), asof=datetime.date(2008, 11, 30), end=datetime.date(2008, 11, 30)), 14) == Dec