

# Generated at 2022-06-25 05:34:43.629686
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    play_context_1 = play_context_0.set_task_and_variable_override(
        task=None,
        variables=None,
        templar=None
    )


# Generated at 2022-06-25 05:34:49.623626
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    for plugin in context.CLIARGS['connection']:
        if plugin == 'local':
            continue
        plugin_obj = load_plugin(plugin, 'connection')
        play_context_0 = PlayContext()
        play_context_0.set_attributes_from_plugin(plugin_obj)
        msg = "{} => expand_vars:"
        print("{} {}".format(msg, play_context_0.remote_addr))


# Generated at 2022-06-25 05:34:52.376411
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    print("TEST: PlayContext.set_attributes_from_plugin")
    play_context = PlayContext()
    play_context.set_attributes_from_plugin("""ansible_ssh_host=""")


# Generated at 2022-06-25 05:34:56.264765
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context_1 = PlayContext()
    assert_equal(play_context_1, None)

# Generated at 2022-06-25 05:34:58.957389
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_1 = PlayContext()
    plugin_1 = 'some_string'
    play_context_1.set_attributes_from_plugin(plugin_1)


# Generated at 2022-06-25 05:35:05.025716
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.playbook.task import Task
    from ansible.template.template import Templar
    from ansible.template.vars import VariableManager
    from ansible.utils.vars import combine_vars
    # Testing data
    data_dict = {'foo': 'bar'}
    another_data_dict = {'foo': 'baz'}
    yet_another_data_dict = {'foo': 'yet_another'}
    play_context_0 = PlayContext()
    variable_manager_0 = VariableManager()
    variable_manager_0.extra_vars = data_dict
    variable_manager_0.host_vars = {'1.1.1.1': {'foo': 'another'}}

# Generated at 2022-06-25 05:35:09.573372
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    pc = PlayContext()
    assert pc.timeout == C.DEFAULT_TIMEOUT
    assert pc.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    pc.set_attributes_from_cli()
    assert pc.timeout == int(C.DEFAULT_TIMEOUT)
    assert pc.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE


# Generated at 2022-06-25 05:35:12.678724
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()


# Generated at 2022-06-25 05:35:16.229388
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_1 = PlayContext()
    play_context_2 = play_context_1.set_task_and_variable_override()


# Generated at 2022-06-25 05:35:21.566649
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_1 = PlayContext()
    plugin_class = get_plugin_class('winrm')
    plugin_instance = plugin_class(task=None, connection=None, play_context=play_context_1, loader=None, templar=None, shared_loader_obj=None)
    play_context_1.set_attributes_from_plugin(plugin_instance)



# Generated at 2022-06-25 05:35:38.734918
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()
    play_context.set_attributes_from_plugin(PlayContext())


# Generated at 2022-06-25 05:35:43.130818
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Setup
    play_context_0 = PlayContext()
    plugin = None
    # Test Call
    play_context_0.set_attributes_from_plugin(plugin)
    # Test Assertions
    assert(True)


# Generated at 2022-06-25 05:35:46.660235
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    display.logger.setLevel(logging.DEBUG)
    play_context_0 = PlayContext()
    play_context_0.set_task_and_variable_override(task='an_task', variables='an_variables', templar='a_templar')


# Generated at 2022-06-25 05:35:54.846997
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Ensure set_attributes_from_plugin() for class PlayContext doesn't lead to an exception
    '''

    # do not run the test if there is no network plugin available
    if not is_network_plugin_available():
        return

    play_context = PlayContext()
    connection_plugin = get_network_plugin(play_context)
    connection_plugin._load_name = 'network_cli'
    play_context.set_attributes_from_plugin(connection_plugin)


# Generated at 2022-06-25 05:36:05.751736
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    # create a PlayContext to add variables
    play_context_0 = PlayContext()
    play_context_0.port = 22
    # add ansible_ssh_port for all connection types
    for connection_type in C.DEFAULT_TRANSPORT:
        variables = {connection_type:'ssh'}
        play_context_0.update_vars(variables)
        assert "ansible_ssh_port" in variables
        assert variables["ansible_ssh_port"] == 22
    # add ansible_port for all connection types
    for connection_type in C.DEFAULT_TRANSPORT:
        variables = {connection_type:'ssh'}
        play_context_0.update_vars(variables)
        assert "ansible_port" in variables
        assert variables["ansible_port"] == 22




# Generated at 2022-06-25 05:36:15.265229
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_1 = PlayContext()
    # task_object: create dictionary, populate all attributes of task_object
    task_object_1 = dict()
    task_object_1['action'] = 'action_0'
    task_object_1['args'] = 'args_0'
    task_object_1['async_val'] = 'async_val_0'
    task_object_1['async_jid'] = 'async_jid_0'
    task_object_1['become'] = 'become_0'
    task_object_1['become_method'] = 'become_method_0'
    task_object_1['become_user'] = 'become_user_0'
    task_object_1['become_flags'] = 'become_flags_0'

# Generated at 2022-06-25 05:36:22.332575
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Create a PlayContext object
    play_context_0 = PlayContext()
    # Create a Task object
    task_0 = Task()
    # Assign values to variables
    variables_0 = dict()
    # Create a Templar object
    templar_0 = Templar(loader=None, variables=variables_0)
    # Call method set_task_and_variable_override of PlayContext object
    result_0 = play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)
    assert result_0._attributes['become'] == False
    assert result_0._attributes['become_method'] == ''
    assert result_0._attributes['become_pass'] == ''
    assert result_0._attributes['become_user'] == ''

# Generated at 2022-06-25 05:36:26.477656
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    print("Testing set_attributes_from_plugin of class PlayContext")

    play_context_0 = PlayContext()
    connection_plugin_0 = ConnectionPlugin()

    # TEST 1
    # Test of 'set_attributes_from_plugin' with existing plugin
    try:
        # play_context_0.set_attributes_from_plugin(connection_plugin_0)
        assert True
    except:
        assert False


# Generated at 2022-06-25 05:36:32.735450
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    dict_0 = dict()
    dict_0['ansible_user'] = 'root'
    dict_0['ansible_port'] = 22
    dict_0['ansible_ssh_common_args'] = "-o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no"
    dict_0['ansible_ssh_private_key_file'] = '/var/tmp/ssh-key/id_rsa'
    dict_0['ansible_host'] = 'somehost'

    variables = dict_0

    # Test case #0: no delegation, setting the right type of variables
    dict_0 = dict()
    dict_0['remote_user'] = 'admin'
    dict_0['remote_addr'] = 'somehost'
    dict_0['port'] = 22

# Generated at 2022-06-25 05:36:42.290029
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play = Play.load(dict(
        name = "Ansible Play 0",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='ping'), register='ping_results')
        ]
    ))


# Generated at 2022-06-25 05:37:11.164582
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    set_attributes_from_plugin_plugin = { '_default_become_method': 'sudo', '_network_os': 'ios', '_default_become_user': 'root', '_default_check_mode': False, '_default_become': False, '_default_private_key_file': '/path/to/file', '_default_no_log': False, '_default_verbosity': False, '_default_connection': 'smart' }

    expected_connection = 'smart'
    expected_remote_addr = 'dummy_remote_addr'
    expected_remote_user = 'dummy_remote_user'
    expected_port = 'dummy_port'
    expected_private_key_file = '/path/to/file'
    expected_no_log = False
    expected_verbosity = False


# Generated at 2022-06-25 05:37:12.963503
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin(None)


# Generated at 2022-06-25 05:37:15.847504
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Test with a non-none play
    play_context_0 = PlayContext(None)
    play_context_0.set_attributes_from_cli()
    # Test anonymous Executable
    assert play_context_0.executable is None



# Generated at 2022-06-25 05:37:24.559450
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = dict()
    templar_0 = Templar(loader=MockLoader())
    play_context_1 = play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)

if __name__ == "__main__":
    import logging
    #logging.basicConfig(filename="tests_results.log", level=logging.DEBUG)

    test_case_0()
    test_PlayContext_set_task_and_variable_override()

    print("Test PASSED OK")

# Generated at 2022-06-25 05:37:32.158463
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    # no attributes for member plugin
    # no return value for set_attributes_from_plugin
    # plugin is a parameter
    play_context_0 = PlayContext()
    plugin_0 = MagicMock(name='Mock Plugin')
    plugin_0.get_option.return_value = None

    # no exceptions should be raised when invoking
    # plugin is a Mock
    # options is an empty dictionary
    play_context_0.set_attributes_from_plugin(plugin_0)

    # no return value for set_attributes_from_plugin
    # plugin is a parameter
    play_context_0 = PlayContext()
    plugin_0 = MagicMock(name='Mock Plugin')
    plugin_0.get_option.return_value = None

    # no exceptions should be raised when invoking
    # plugin is a Mock


# Generated at 2022-06-25 05:37:41.550490
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context_0 = PlayContext()
    # Test that ansible connection type is 'ssh'
    assert (play_context_0.connection == 'ssh')
    # Test that ansible timeout is 10
    assert play_context_0.timeout == 10
    # Test that ansible port is 22
    assert play_context_0.port == 22
    # Test that ansible password is ''
    assert play_context_0.password == ''
    # Test that ansible become password is ''
    assert play_context_0.password == ''
    # Test that ansible prompt is ''
    assert play_context_0.prompt == ''
    # Test that ansible success_key is ''
    assert play_context_0.success_key == ''

# Generated at 2022-06-25 05:37:45.167850
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    assert play_context_0.timeout == C.DEFAULT_TIMEOUT
    assert play_context_0.verbosity == 0
    # PlayContext.set_attributes_from_cli() # TODO
    assert play_context_0.timeout == C.DEFAULT_TIMEOUT
    assert play_context_0.verbosity == 0


# Generated at 2022-06-25 05:37:47.216907
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin('connection', {})

    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin('network_cli', {})


# Generated at 2022-06-25 05:37:52.883205
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Create an instance of PlayContext
    play_context = PlayContext()

    # Create an instance of task object
    task_obj = Task()

    # Create an instance of variables
    variables = dict()

    # Create an instance of templar object
    templar_obj = Templar(loader=DictDataLoader())

    # Invoke method set_task_and_variable_override()
    play_context.set_task_and_variable_override(task_obj, variables, templar_obj)


# Generated at 2022-06-25 05:38:02.806999
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_1 = PlayContext()

    test_module_0 = AnsibleModule()
    setattr(test_module_0, 'remote_user', 'root')
    setattr(test_module_0, 'delegate_to', 'test_host')

    test_module_1 = AnsibleModule()
    setattr(test_module_1, 'remote_user', 'root')

    variables = dict()
    variables['ansible_host'] = 'test_host'
    variables['ansible_port'] = '22'
    variables['ansible_user'] = 'test_user'
    variables['ansible_password'] = 'test_password'
    variables['ansible_ssh_private_key_file'] = '/Users/test_user/.ssh/id_rsa'

# Generated at 2022-06-25 05:38:37.449289
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Create a new PlayContext object
    play_context_0 = PlayContext()

    # Call the method
    plugin = 'net_ping'
    play_context_0.set_attributes_from_plugin(plugin)


# Generated at 2022-06-25 05:38:44.804569
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # create mocks for verify
    # class Task
    task_class_mock = mocker.patch('ansible.playbook.play_context.Task')

    task_instance_mock = mocker.Mock(spec=Task)
    task_class_mock.return_value = task_instance_mock
    task_instance_mock.become_user = None
    task_instance_mock.delegate_to = None
    task_instance_mock.connection = None
    task_instance_mock.remote_addr = None
    task_instance_mock.remote_user = None
    task_instance_mock.port = None
    task_instance_mock.no_log = None
    task_instance_mock.environment = None
    task_instance_mock.executable = None
   

# Generated at 2022-06-25 05:38:50.056143
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Instantiate an instance of PlayContext with no arguments
    pc = PlayContext(None, None)

    # Instantiate a task and variable instance
    task = Task()
    var = dict()
    templar = Templar()

    # Call the function
    pc.set_task_and_variable_override(task, var, templar)

# Generated at 2022-06-25 05:38:58.898888
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    hostvars = {'ansible_ssh_host': '192.0.7.10', 'ansible_password': 'ansible', 'ansible_port': 22}
    play_context = PlayContext()
    play_context.connection = 'smart'
    play_context.port = 22
    play_context.remote_user = 'root'
    play_context.update_vars(hostvars)
    if hostvars.get('ansible_port') == play_context.port:
        raise Exception("ansible_port should not equal to default port 22")
    if play_context.port == 22:
        raise Exception("port should not equal to the value of hostvars['ansible_port']:" +
                        hostvars.get('ansible_port'))

# Generated at 2022-06-25 05:39:00.397309
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plugin = object()
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin(plugin)


# Generated at 2022-06-25 05:39:06.895970
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    # Pick up a valid plugin.  For now, use the local user module, but it probably doesn't matter
    plugin = get_plugin_class('user')()
    play_context_0.set_attributes_from_plugin(plugin)


# Generated at 2022-06-25 05:39:09.661787
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin_0 = Mock_Plugin()
    play_context_0.set_attributes_from_plugin(plugin_0)


# Generated at 2022-06-25 05:39:13.213183
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin_0 = 'str'
    play_context_0.set_attributes_from_plugin(plugin_0)


# Generated at 2022-06-25 05:39:15.181860
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context_0 = PlayContext()
    assert isinstance(play_context_0, PlayContext)


# Generated at 2022-06-25 05:39:19.346100
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    result = play_context_0.set_attributes_from_plugin(plugin='plugin')
    assert result is None


# Generated at 2022-06-25 05:39:59.890319
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Test with empty play context
    play_context_0 = PlayContext()
    task_0 = Task()
    test_vars_0 = {}
    templar_0 = Templar(loader=None, variables=None)
    retval_0 = play_context_0.set_task_and_variable_override(task=task_0, variables=test_vars_0, templar=templar_0)
    assert retval_0 is not play_context_0
    assert retval_0 is not templar_0
    assert retval_0 is not task_0
    assert retval_0 is not test_vars_0

    # Test with simple play context
    play_context_1 = PlayContext()
    play_context_1.become_pass = "g"
    play_context_

# Generated at 2022-06-25 05:40:11.589762
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    play_context_0 = PlayContext()
    play_context_0._attributes = {}
    play_context_0._attributes['connection'] = 'smart'

    task_0 = Task()
    task_0._attributes = {}
    task_0._attributes['check_mode'] = False
    task_0._attributes['delegate_to'] = None
    task_0._attributes['diff'] = False
    task_0._attributes['remote_user'] = 'root'

    variables_0 = {}

    templar_0 = Templar(Loader())

    # test
    new_info = play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)

    # assert
    assert new_info._attributes['check_mode'] == False


# Generated at 2022-06-25 05:40:17.272498
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_1 = PlayContext()
    task_1 = Task()
    variables_1 = dict()
    templar_1 = Templar()
    result = play_context_1.set_task_and_variable_override(task_1, variables_1, templar_1)


# Generated at 2022-06-25 05:40:19.373303
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_1 = PlayContext()
    play_context_1.set_attributes_from_cli()


# Generated at 2022-06-25 05:40:23.150085
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # This function tests the constructor of class PlayContext
    #
    #  Expected result:
    # shoud return an instance of PlayContext

    play_context_0 = PlayContext()
    if not isinstance(play_context_0, PlayContext):
        raise AssertionError('Return value  of PlayContext() is not type PlayContext')

    return play_context_0



if __name__ == "__main__":
    test_PlayContext()

# Generated at 2022-06-25 05:40:26.978923
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    import ansible.plugins.connection.ssh as ssh
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin(ssh.Connection())


# Generated at 2022-06-25 05:40:39.083122
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.plugins.connection.paramiko_ssh import Connection as ParamikoConnection
    from ansible.plugins.connection.ssh import Connection as SSHConnection
    from ansible.plugins.connection.docker import Connection as DockerConnection
    from ansible.plugins.connection.netconf import Connection as NetconfConnection
    from ansible.plugins.connection.local import Connection as LocalConnection
    from ansible.plugins.connection.winrm import Connection as WinRMConnection
    from ansible.plugins.connection.smart import Connection as SmartConnection
    from ansible.plugins.connection.persistent import Connection as PersistentConnection

    play_context_0 = PlayContext()
    play_context_1 = PlayContext()
    play_context_2 = PlayContext()
    play_context_3 = PlayContext()
    play_context_4 = PlayContext()
    play_context_5

# Generated at 2022-06-25 05:40:48.607841
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # Test expected success for test case.
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = dict()
    templar_0 = Templar(loader=None, variables=None)
    new_info_0 = play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)
    assert isinstance(new_info_0, PlayContext)

    # Test expected failure for test case.
    #play_context_1 = PlayContext()
    #task_1 = Task()
    #variables_1 = dict()
    #templar_1 = Templar(loader=None, variables=None)
    #try:
    #    play_context_1.set_task_and_variable_override(task_1, variables

# Generated at 2022-06-25 05:40:51.836020
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    conn = Connection.sftp
    play_context_0.set_attributes_from_plugin(conn)


# Generated at 2022-06-25 05:40:54.984411
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pc = PlayContext()
    plugin = MockModule()
    pc.set_attributes_from_plugin(plugin)


# Generated at 2022-06-25 05:42:14.472399
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Setup
    play_context_0 = PlayContext()
    context.CLIARGS = {'timeout': '100', 'private_key_file': '~/.ssh/id_rsa', 'verbosity': '0'}

    # Exercise
    play_context_0.set_attributes_from_cli()

    # Verify
    assert play_context_0.timeout == 100
    assert play_context_0.private_key_file == '~/.ssh/id_rsa'
    assert play_context_0.verbosity == 0
    assert play_context_0.start_at_task == None


# Generated at 2022-06-25 05:42:15.834681
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()


# Generated at 2022-06-25 05:42:19.863536
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    result = play_context_0.set_attributes_from_plugin(ansible.plugins.connection.local.Connection)
    assert result is None


# Generated at 2022-06-25 05:42:30.366912
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    display.verbosity = 2

    # Make inventory and play_source usable
    inventory = InventoryManager(loader=DataLoader())
    host = inventory.add_host(host=Host())

    play_source = dict(
        name = "Ansible Play 0",
        hosts = 'all',
        gather_facts = 'no',
        tasks = []
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=DataLoader())

    # At this point, several properties are None, not False
    play_context_0 = PlayContext()
    assert play_context_0.become is False
    assert play_context_0.become_user is None
    assert play_context_0.connection is None
    assert play_context_0.remote_addr is None
    assert play_context_0.remote

# Generated at 2022-06-25 05:42:31.031857
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    pass


# Generated at 2022-06-25 05:42:42.435156
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # FIXME: Disable 'test_PlayContext_set_task_and_variable_override' until it is fixed
    return

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar

    class MyTemplar:
        def __init__(self):
            self.host_name = 'host1'

        def template(self, value):
            return self.host_name

    class MyTask(Task):
        def __init__(self):
            self.remote_user = 'user1'
            self.delegate_to = '{{ host_name }}'


# Generated at 2022-06-25 05:42:44.956743
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    context.CLIARGS = {}
    context.CLIARGS['timeout'] = False
    play_context_0.set_attributes_from_cli()


# Generated at 2022-06-25 05:42:53.656678
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plugin_name = 'ping'
    plugin_class = get_plugin_class(plugin_name)
    plugin_instance = plugin_class()
    options = C.config.get_configuration_definitions(plugin_class, plugin_name)
    options['timeout'] = {'name': 'timeout'}
    options['timeout_value'] = 10
    play = object()
    play_context = PlayContext(play)
    play_context.set_attributes_from_plugin(plugin_instance)
    assert options['timeout_value'] == play_context.timeout, 'Expected: %s, Actual: %s' % (options['timeout_value'], play_context.timeout)


# Generated at 2022-06-25 05:42:58.442594
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()
    plugin_1 = connection_loader.get('netconf', class_only=True)()
    plugin_2 = connection_loader.get('network_cli', class_only=True)()

    play_context.set_attributes_from_plugin(plugin_1)
    play_context.set_attributes_from_plugin(plugin_2)

    assert play_context.network_os == 'ios'
    assert play_context.port == 22

# Generated at 2022-06-25 05:43:06.732751
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    global play_context_0
    global play_context_1
    global delegated_vars

    task_0 = Task()
    task_0.remote_user = delegated_user
    task1_delegate_to = '127.0.0.1'
    task1_current_user = 'current_user'
    task_1 = Task()
    task_1.delegate_to = task1_delegate_to
    task_1.remote_user = task1_current_user
    variables = {'ansible_delegated_vars': {'127.0.0.1': delegated_vars}}
    templar = Templar()

    play_context_0.set_task_and_variable_override(task_0, variables, templar)