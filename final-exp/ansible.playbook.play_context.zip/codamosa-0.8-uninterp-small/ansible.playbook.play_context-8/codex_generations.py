

# Generated at 2022-06-25 05:34:52.976391
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()

    ansible_connection = "ssh"
    ansible_become_user = "root"
    ansible_become_method = "su"
    ansible_become_pass = "sudopassword"
    ansible_ssh_pass = "sshpassword"
    ansible_user = "ansibleuser"
    ansible_port = "22"
    ansible_host = "1.1.1.1"
    ansible_executable = "/usr/bin/ssh"
    ansible_remote_tmp = "/tmp"

# Generated at 2022-06-25 05:35:03.062420
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # test 1
    play_context_1 = PlayContext()
    plugin_1 = plugin_loader.get('raw')
    play_context_1.set_attributes_from_plugin(plugin_1)
    for_test_1 = dict(
        become=False, become_method=None, become_user=None, check=False,
        connection=None, diff=False, executable=None, no_log=None, other_vars=dict(),
        play=None, passwords=dict(), pipelining=True, port=None, remote_addr=None, remote_user=None,
        retries=0, sudo=False, timeout=C.DEFAULT_TIMEOUT, transport='paramiko',
        verbosity=0, become_pass=None
    )

# Generated at 2022-06-25 05:35:11.451120
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Setup
    play_context_1 = PlayContext()
    plugin_1 = get_plugin_class('docker')()
    plugin_1.set_options(dict(debug=True, docker_extra_args='-H tcp://localhost:2375'))

    try:
        play_context_1.set_attributes_from_plugin(plugin_1)
    except Exception as e:
        raise Exception('PlayContext.set_attributes_from_plugin failed, reason: ' + str(e))


# Generated at 2022-06-25 05:35:15.288989
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Verify that PlayContext.set_attributes_from_plugin sets attributes when list of
    # attributes passed is empty
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin([])


# Generated at 2022-06-25 05:35:19.337423
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    expected_play_context = PlayContext()

    play_context_0 = PlayContext()

    assert(play_context_0._attributes == expected_play_context._attributes)

test_case_0()

# Generated at 2022-06-25 05:35:31.136186
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.config.manager import ConfigManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    playbook = Playbook()

# Generated at 2022-06-25 05:35:41.350713
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    global host_vars
    global magic_vars

    play_context_0 = PlayContext()

    set_task_and_variable_override(play_context_0, host_vars, magic_vars)

    magic_vars['ansible_connection'] = 'test_value'
    magic_vars['ansible_ssh_user'] = 'test_value'
    magic_vars['ansible_ssh_pass'] = 'test_value'
    magic_vars['ansible_become_user'] = 'test_value'
    magic_vars['ansible_become_pass'] = 'test_value'

    set_task_and_variable_override(play_context_0, host_vars, magic_vars)


# Generated at 2022-06-25 05:35:48.993121
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = AnsibleTask()
    templar_0 = Templar(loader=None)
    variables_0 = VariableManager(loader=None, inventory=None)

    # No value
    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)
    assert "connection" not in play_context_0.__dict__

    # With value
    task_0.connection = "network_cli"
    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)
    assert "network_cli" == play_context_0.connection


# Generated at 2022-06-25 05:35:59.720013
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    test = dict()

    play = dict(
        become_pass = 'foo',
        become_user = 'bar',
        connection = 'local',
        inventory = 'inventory',
        no_log = False,
        private_key_file = '/tmp/key',
        remote_addr = '127.0.0.1',
        remote_user = 'jdoe',
        remote_port = 22,
        verbosity = 1,
    )

    for k, v in play.items():
        test[k] = v

    plugin = BakedPlugin('/tmp/ansible_test_set_attributes_from_plugin_0.py', '/tmp', False)

    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin(plugin)

# Generated at 2022-06-25 05:36:09.365774
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plg = dict(
        class_name='Baz',
        module='too',
        name='toomany',
        aliases=[],
        parallel_once=False,
        run_once=False,
        _terms=dict(
            foo=dict(required=False, type='str', name='foo'),
            bar=dict(required=False, type='str', name='bar'),
        ),
    )
    # The 'cls' argument is used only to look up configuration options.
    class_name = plg['class_name']
    cls = 'cls'

# Generated at 2022-06-25 05:36:27.728306
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_test = PlayContext(play=None, passwords=None)
    task_test = AnsiblePlaybookEntry()
    variables_test = dict()
    templar_test = Templar(loader=None, variables=None)

    play_context_set_task_and_var_override_test = play_context_test.set_task_and_variable_override(task_test, variables_test, templar_test)

# Generated at 2022-06-25 05:36:36.453434
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    my_dict = dict(one=1, two=2)
    my_list = list()

    my_list.append(my_dict)

    play_context_0 = PlayContext()
    try:
        play_context_0.set_attributes_from_plugin(my_list)
    except:
        print("The method set_attributes_from_plugin() isn't working correctly")

test_case_0()
test_PlayContext_set_attributes_from_plugin()

# Generated at 2022-06-25 05:36:39.972957
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_obj = Task()
    variable_obj = {}
    result = play_context_0.set_task_and_variable_override(task_obj, variable_obj)
    assert result is not None


# Generated at 2022-06-25 05:36:50.622217
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-25 05:36:56.823288
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    import copy
    from ansible.playbook.task import Task

    play_context = PlayContext()
    new_info = play_context.copy()
    new_info.connection = 'smart'
    new_info.remote_addr = '10.100.100.100'
    new_info.remote_user = 'test'
    new_info.port = 2222
    new_info.connection_user = 'test'
    new_info.timeout = 600
    new_info.no_log = False
    new_info.become = True
    new_info.become_method = 'sudo'
    new_info.become_user = 'ansible'
    new_info.prompt = 'some string'
    new_info.success_key = 'some string'

# Generated at 2022-06-25 05:37:05.010644
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_1 = PlayContext()
    l = {'module_name': 'from_system_facts.py', '_load_name': 'from_system_facts', 'from_system_facts_facts': 
    {'from_system_facts': {'from_system_facts': 'from_system_facts', 'item_1': 'from_system_facts', 'item_2': 'from_system_facts'}}}

    play_context_1.set_attributes_from_plugin(l)


# Generated at 2022-06-25 05:37:13.378528
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Create a temp directory
    temp_dir = tempfile.mkdtemp()

    # Create a file and store the connection info
    fp = open(os.path.join(temp_dir, 'connection_info.yml'), 'w')
    play_context_0 = PlayContext()
    play_context_0.become = True
    play_context_0.become_method = 'sudo'
    play_context_0.become_user = 'some_become_user'
    play_context_0.become_pass = 'some_become_pass'
    play_context_0.connection = 'local'
    play_context_0.no_log = False
    play_context_0.remote_addr = 'localhost'
    play_context_0.remote_user = 'some_remote_user'

# Generated at 2022-06-25 05:37:24.355534
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # 1st test, test_case_1
    play_context_0 = PlayContext()
    # Set
    task_0 = Task()
    variables_0 = dict()
    templar_0 = Templar()
    # Call the method
    assert_equal(play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0), play_context_0)

    # 2nd test, test_case_2
    play_context_1 = PlayContext()
    # Set
    task_1 = Task()
    task_1.check_mode = None
    task_1.diff = None
    task_1.delegate_to = None
    task_1.remote_user = None
    variables_1 = dict()
    templar_1 = Templar()
   

# Generated at 2022-06-25 05:37:29.686490
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    # task =
    # variables =
    # templar =
    # check if setup can be called w/o parameters
    # since this method is used in _new_play(), the callee will expect a populated task & templar to be passed
    # TODO: how to test the response of this method?
    play_context_0.set_task_and_variable_override(task, variables, templar)

# Generated at 2022-06-25 05:37:40.533308
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    play_context.remote_user = "someuser"
    play_context.remote_addr = "somehost"
    play_context.port = 22
    play_context.connection = "smart"

    play = Play()
    # None
    new_info = play_context.set_task_and_variable_override(Task(), dict(), Templar())
    assert new_info.connection == "ssh"
    assert new_info.remote_user == "someuser"
    assert new_info.remote_addr == "somehost"
    assert new_info.port == 22
    assert new_info.no_log is None
    assert new_info.check_mode is None
    assert new_info.diff is None

    # task.delegate_to is set
    new_info = play_context

# Generated at 2022-06-25 05:38:34.709319
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    host_name = 'foo'
    inventory = Inventory("")
    inventory.get_host(host_name).vars = {"ansible_host": "foo"}
    PlayContext.set_attributes_from_plugin(host_name, inventory)


# Generated at 2022-06-25 05:38:38.978589
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # playbook_txt =
    # host_txt =
    # args_txt =
    # password_txt =
    # play =
    # plugin =
    # passwords =
    # connection_lockfd =
    # play_context_0 = PlayContext(play, passwords, connection_lockfd)
    pass


# Generated at 2022-06-25 05:38:43.502796
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    args = {
        'connection_lockfd': None,
    }
    play_context_0 = PlayContext(**args)
    plugin = None
    play_context_0.set_attributes_from_plugin(plugin)
    assert play_context_0

    # Test with plugin = 'shell'
    plugin = 'shell'
    play_context_0.set_attributes_from_plugin(plugin)
    assert play_context_0


# Generated at 2022-06-25 05:38:54.692038
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = ansible.playbook.play_context.PlayContext()

    # Set task_0 attributes
    task_0 = ansible.playbook.task.Task()
    # Connection attributes
    task_0.remote_user = 'user_0'
    task_0.no_log = 'value_1'
    task_0.port = 'value_2'
    task_0.become_pass = 'value_3'
    task_0.private_key_file = 'value_4'
    task_0.remote_addr = 'value_5'
    task_0.password = 'value_6'
    task_0.executable = 'value_7'
    task_0.become = 'value_8'
    task_0.become_user = 'value_9'
    task_

# Generated at 2022-06-25 05:38:59.045183
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = Task()
    task_0.remote_user = "root"
    task_0.no_log = False
    task_0.connection = "ssh"
    variables_0 = dict()
    templar_0 = Templar(loader=None)
    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)


# Generated at 2022-06-25 05:39:09.835307
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    playbook_path = C.DEFAULT_PLAYBOOK_PATH
    if playbook_path:
        playbook_path.append('../test/playbooks/playbook_0.yaml')

    loader, inventory, variable_manager = CLIFactory().loader()
    passwords = dict(conn_pass='pass')
    variable_manager.set_inventory(inventory)
    variable_manager.set_playbook_basedir(os.path.dirname(playbook_path[0]))

    while True:
        groups = variable_manager.get_groups_dict()
        if 'lunar' in groups:
            break

        variable_manager.extra_vars = dict(ansible_ssh_host='lunar', ansible_ssh_pass='pass')
        variable_manager.set_inventory(inventory)
        variable_manager.set_play

# Generated at 2022-06-25 05:39:22.555142
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-25 05:39:24.825102
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context_0 = PlayContext()



# Generated at 2022-06-25 05:39:28.900276
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = {}
    templar_0 = Templar(loader=None, variables=None)
    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)


# Generated at 2022-06-25 05:39:32.948215
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # setup
    play_context_0 = PlayContext()
    task_0 = mock.MagicMock()
    variables_0 = {}
    templar_0 = Templar(loader=None)

    # function call
    play_context_1 = play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)

    # assert
    assert play_context_1 is not None

# Generated at 2022-06-25 05:40:07.084436
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # test without task
    with pytest.raises(TypeError):
        PlayContext().set_task_and_variable_override(None, dict(), Templar())

    # test without variables
    with pytest.raises(TypeError):
        PlayContext().set_task_and_variable_override(dict(), None, Templar())

# Generated at 2022-06-25 05:40:17.623279
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # Instantiation of class PlayContext
    play_context_0 = PlayContext()
    # Implementation of tests for attributes
    play_context_0.executable = play_context_0.executable
    play_context_0.port = play_context_0.port
    play_context_0.remote_addr = play_context_0.remote_addr
    play_context_0.connection = play_context_0.connection
    play_context_0.remote_user = play_context_0.remote_user
    play_context_0.password = play_context_0.password
    play_context_0.timeout = play_context_0.timeout
    play_context_0.connection_user = play_context_0.connection_user
    play_context_0.private_key_file = play_context_0.private_

# Generated at 2022-06-25 05:40:18.911504
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()


# Generated at 2022-06-25 05:40:24.374076
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Test PlayContext.set_attributes_from_cli
    # we have to set up the play_context before setting the attributes
    play_context_0 = PlayContext()

    play_context_0.set_attributes_from_cli()

## This test case works fine, but is commented out because it throws an exception
##    assert play_context_0.verbosity == 0
##    assert play_context_0.start_at_task == None
##    assert play_context_0.timeout == C.DEFAULT_TIMEOUT
##    assert play_context_0.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE


# Generated at 2022-06-25 05:40:27.374014
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_1 = PlayContext()
    result = play_context_1.set_attributes_from_plugin(None)
    assert result is None


# Generated at 2022-06-25 05:40:39.456065
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # create a test task
    task = Task()
    task.vars = {
        'ansible_connection': 'local',
        'ansible_port': '1337',
        'ansible_ssh_port': '1337',
        'test_var': 'task_var'
    }
    # create a test play
    play = Play()
    # create a test playcontext
    play_context = PlayContext()

    # call set_task_and_variable_override with task and vars from task
    play_context.set_task_and_variable_override(task, task.vars)

    # assert that the task vars have overridden the defaults in the play context
    assert(play_context.port == '1337')
    assert(play_context.remote_addr == 'test_remote_addr')


# Generated at 2022-06-25 05:40:43.958625
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    '''
    Unit test for method set_task_and_variable_override of class PlayContext
    '''
    # Define the test variables
    p_context = PlayContext()
    variables = {'ansible_connection': 'local', 'ansible_user': 'ec2-user'}
    task = MagicMock()
    templar = MagicMock()

    # Return variables.get(delegated_host_name, dict()) as a dict()
    templar.template.return_value = 'test_host'
    variables['ansible_delegated_vars'] = {'test_host': {'ansible_connection': 'ssh', 'ansible_user': 'test_user', 'ansible_port': '100'}}

    # Define the expected result
    expected_result = PlayContext()
   

# Generated at 2022-06-25 05:40:45.638928
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()


# Generated at 2022-06-25 05:40:53.670858
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = {}
    templar_0 = Templar(loader=Mock())
    PlayContext_set_task_and_variable_override_ret_val = play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)
    assert PlayContext_set_task_and_variable_override_ret_val is not None


# Generated at 2022-06-25 05:41:05.434308
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context_0 = PlayContext()
    assert play_context_0._attributes['connection'] == 'smart'
    assert play_context_0._attributes['remote_addr'] is None
    assert play_context_0._attributes['remote_user'] == 'root'
    assert play_context_0._attributes['password'] == ''
    assert play_context_0._attributes['port'] is None
    assert play_context_0._attributes['timeout'] == 10
    assert play_context_0._attributes['connection_user'] is None
    assert play_context_0._attributes['private_key_file'] == '~/.ssh/id_rsa'
    assert play_context_0._attributes['network_os'] is None
    assert play_context_0._attributes['docker_extra_args'] is None

# Generated at 2022-06-25 05:42:14.392540
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():

    # Run test case
    test_case_0()



# Generated at 2022-06-25 05:42:16.810834
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    # 1. create a PlayContext object, 2. get a plugin object, 3. call method set_attributes_from_plugin
    play_context_0 = PlayContext()
    plugin = 'connection.network_cli'
    play_context_0.set_attributes_from_plugin(plugin)


# Generated at 2022-06-25 05:42:21.388147
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin_0 = connection_loader.get('winrm', play_context_0, '')
    play_context_0.set_attributes_from_plugin(plugin_0)


# Generated at 2022-06-25 05:42:31.470883
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    import mock
    with mock.patch('ansible.executor.task_executor.TaskExecutor') as mock_task_executor:
        from ansible.executor.task_executor import TaskExecutor
        from ansible.plugins.loader import connection_loader, module_loader
        from ansible.playbook.task import Task
        from ansible.playbook.play import Play
        play_context_1 = PlayContext(play=Play().load({u'hosts': u'localhost', u'name': u'localhost', u'gather_facts': u'no', u'tasks': [{u'action': {u'module': u'sleep', u'args': {u'delay': 5}}, u'name': u'sleep 5'}]}, loader=None, variable_manager=None))
        # create task
        task

# Generated at 2022-06-25 05:42:42.824765
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    args = {}
    args['network_os'] = 'network_os'
    args['become_user'] = 'become_user'
    args['become_method'] = 'become_method'
    args['become_exe'] = 'become_exe'
    args['become_flags'] = 'become_flags'
    args['become_pass'] = 'become_pass'
    args['connection'] = 'connection'
    args['connection_user'] = 'connection_user'
    args['delegate_to'] = 'delegate_to'
    args['diff'] = 'diff'
    args['executable'] = 'executable'
    args['private_key_file'] = 'private_key_file'
    args['remote_addr'] = 'remote_addr'

# Generated at 2022-06-25 05:42:44.788857
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_1 = PlayContext()
    args_0 = {}
    set_attributes_from_plugin(play_context_1, args_0)


# Generated at 2022-06-25 05:42:49.493938
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = Task()
    variables = dict()
    templar = Templar()
    new_info = play_context_0.set_task_and_variable_override(task_0, variables, templar)


# Generated at 2022-06-25 05:42:58.731003
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    print("==================================")
    print("Start unit test for PlayContext.set_task_and_variable_override()")
    argv = context.CLIARGS
    host_list = Inventory(loader=None, variable_manager=None, host_list=argv['inventory']).list_hosts('all')
    hosts = tuple(map(lambda host: Host(name=host), host_list))
    variable_manager = VariableManager(loader=None, inventory=Inventory(loader=None, host_list=hosts))

# Generated at 2022-06-25 05:43:07.073089
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin_0 = DummyConnectionPlugin()

    play_context_0.set_attributes_from_plugin(plugin_0)
    assert play_context_0._attr_host_name == u'1.2.3.4', 'Attribute _attr_host_name is wrong. Expected value 1.2.3.4, found ' + play_context_0._attr_host_name
    assert play_context_0._attr_remote_user == u'johndoe', 'Attribute _attr_remote_user is wrong. Expected value johndoe, found ' + play_context_0._attr_remote_user
    assert play_context_0._attr_port == 1234, 'Attribute _attr_port is wrong. Expected value 1234, found ' + play_context_0._attr

# Generated at 2022-06-25 05:43:11.701337
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    '''
    Unit test for method set_task_and_variable_override
    of class PlayContext
    '''
    templar = Templar(loader=None, variables={})

    new_info = test_case_itm_0.set_task_and_variable_override(task, variables, templar)
