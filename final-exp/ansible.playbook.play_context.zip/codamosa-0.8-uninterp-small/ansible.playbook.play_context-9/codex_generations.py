

# Generated at 2022-06-25 05:34:58.171422
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    bool_0 = False
    play_context_0 = PlayContext(bool_0)
    ShellModule_1 = mock.Mock()

    # Call method
    play_context_0.set_attributes_from_plugin(ShellModule_1)


# Generated at 2022-06-25 05:35:07.610449
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    bool_0 = False
    play_context_0 = PlayContext(bool_0)
    dict_0 = dict()
    connection_0 = Connection(dict_0)

    # This test needs to call set_attributes_from_plugin with a set of
    # arguments that don't crash.  Not sure how to get them other than
    # to pull them from an existing call.  Isolating that into a plugin
    # is not trivial because it is accessed via a plugin loader, which
    # doesn't get set up during a test.
    from ansible.plugins.connection.paramiko_ssh import Connection as Connection_paramiko_ssh
    play_context_0.set_attributes_from_plugin(Connection_paramiko_ssh())



# Generated at 2022-06-25 05:35:11.521456
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    # get the task object to use for the set_task_and_variable_override
    play_context_0.set_task_and_variable_override()



# Generated at 2022-06-25 05:35:14.582420
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    bool_0 = False
    play_context_0 = PlayContext(bool_0)
    play_context_0.set_attributes_from_cli()



# Generated at 2022-06-25 05:35:26.209083
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    bool_0 = False
    play_context_0 = PlayContext(bool_0)
    dict_0 = {}
    dict_1 = {}
    dict_1['test_0'] = dict_0
    set_0 = set()
    dict_0['test'] = set_0
    set_0.add(play_context_0)
    dict_2 = {}
    dict_2['a'] = dict_1
    dict_2['b'] = dict_1
    dict_2['c'] = dict_1
    dict_0['robert'] = dict_2
    dict_1['test_1'] = dict_0
    dict_0['test_2'] = dict_0
    dict_1['test_3'] = dict_0
    dict_0['test_4'] = dict_0
    dict_

# Generated at 2022-06-25 05:35:28.948089
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    result_0 = PlayContext()
    result_0.set_attributes_from_plugin('plugin')


# Generated at 2022-06-25 05:35:39.147119
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    bool_0 = False
    play_context_0 = PlayContext(bool_0)
    play_context_0.set_attributes_from_cli()
    task_0 = Task()
    variables_0 = dict()
    task_0.become = False
    task_0.delegate = False
    task_0.become_user = 'root'
    task_0.become_method = 'sudo'
    task_0.check_mode = False
    task_0.connection = 'ssh'
    task_0.silent = False
    task_0.diff = False
    task_0.remote_user = 'root'
    variables_0['inventory_hostname'] = '127.0.0.1'
    variables_0['ansible_connection'] = 'smart'
    #print(play_

# Generated at 2022-06-25 05:35:42.947137
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    bool_0 = False
    play_context_0 = PlayContext(bool_0)
    str_0 = "paramiko"
    play_context_0.set_attributes_from_plugin(str_0)

# Generated at 2022-06-25 05:35:47.922460
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Instantiate an empty play context
    play_context_0 = PlayContext()

    # Set plugin to some value
    plugin_0 = "PLUGIN"

    # Call method set_attributes_from_plugin
    play_context_0.set_attributes_from_plugin(plugin_0)


# Generated at 2022-06-25 05:35:57.100095
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Setup test environment
    play_context_0 = PlayContext()
    # Command line options:
    #   connection:
    #     smart
    #   become:
    #     True
    #   become_method:
    #     sudo
    #   become_user:
    #     root
    #   become_pass:
    #     (not specified)
    #   private_key_file:
    #     /home/ansible/.ssh/id_rsa
    #   verbosity:
    #     0
    #   timeout:
    #     30
    #   start_at_task:
    #     (not specified)
    #   step:
    #     False
    #   force_handlers:
    #     False
    #   force_remote_user:
    #     False
    #   pip

# Generated at 2022-06-25 05:36:16.957654
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    play_context_set_attributes_from_plugin = PlayContext()

    # set your plugin
    plugin = play_context_set_attributes_from_plugin.set_attributes_from_plugin()


# Generated at 2022-06-25 05:36:18.687555
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_1 = PlayContext()
    play_context_1.set_attributes_from_plugin(['connection'])


# Generated at 2022-06-25 05:36:25.666868
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Data for task
    task_name = u'set_fact'
    task_args = {u'debug_enabled': False, u'_raw_params': u'environment_variables', u'_uses_shell': False, u'_uses_delegate_to': False, u'_delegate_to': None, u'_loop': None, u'_use_async': False, u'_use_async_wait': False, u'_Changed': False, u'_failed_when_result': False, u'_is_import_plugin': False, u'_no_log': False, u'_ansible_check_mode': False}
    task_delegate_to = None
    task_changed = False
    task_always_run = False
    task_tags = []
    task_register = None
   

# Generated at 2022-06-25 05:36:27.376368
# Unit test for constructor of class PlayContext
def test_PlayContext():
    context = PlayContext(play=Play(), passwords={'conn_pass': 'pass'})
    assert context.password == "pass"
    assert context.become_pass == ""



# Generated at 2022-06-25 05:36:40.016173
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_1 = Task()
    task_1.remote_user = "remoteuser_0"
    task_1.become = "become_1"
    task_1.become_user = "become_user_2"
    task_1.become_method = "become_method_3"
    task_1.delegate_to = "delegate_to_4"
    task_1.no_log = "no_log_5"
    task_1.check_mode = "check_mode_6"
    task_1.diff = "diff_7"
    variables_8 = dict()
    variables_8['dictitem_9'] = dict()
    variables_8['variable_10'] = "variable_10"

# Generated at 2022-06-25 05:36:41.185941
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Context Variables
    assert PlayContext().set_attributes_from_cli()


# Generated at 2022-06-25 05:36:47.385229
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_1 = PlayContext()
    task_1 = Task()
    task_1.delegate_to = "localhost"
    templar_1 = Templar()
    test_task = Task()
    test_task.delegate_to = "localhost"
    templar = Templar()
    variables = dict()
    variables["ansible_ssh_private_key_file"] = [".ssh/id_rsa"]
    variables["ansible_ssh_user"] = "example"
    variables["ansible_ssh_host"] = "example.com"
    variables["ansible_ssh_port"] = "22"
    result = PlayContext.set_task_and_variable_override(test_task, variables, templar)
    assert result.remote_user == "example"

# Generated at 2022-06-25 05:37:00.124563
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # create task object
    task0 = Task()
    task0.remote_user = 'test_remote_user'

    # create templar object
    loader0 = DataLoader()
    templar0 = Templar(loader=loader0)

    # test for delegate_to set
    play_context_0 = PlayContext()
    variables0 = dict()
    play_context_0.set_task_and_variable_override(task0, variables0, templar0)
    assert play_context_0.remote_user == 'test_remote_user'

    # test for delegate_to not set, remote_user set
    play_context_0.remote_user = 'remote_user'
    play_context_0.set_task_and_variable_override(task0, variables0, templar0)
   

# Generated at 2022-06-25 05:37:06.797987
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # create an object of class PlayContext called play_context_0
    play_context_0 = PlayContext()

    # create an instance of class connection plugin 
    plugin = connection_loader.get('shmux')()
    plugin.set_option('shmux_mode', 'ssh')

    # call the set_attributes_from_plugin of class PlayContext
    play_context_0.set_attributes_from_plugin(plugin)


# Generated at 2022-06-25 05:37:09.465269
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin_0 = AnsibleModule()
    play_context_0.set_attributes_from_plugin(plugin_0)


# Generated at 2022-06-25 05:37:33.240342
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-25 05:37:42.471894
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    test_case_1_data = {
        'module_defaults': {
            'docker_extra_args': None
        },
        'param_map': {},
        'invocation': {
            'module_name': 'docker',
            'module_args': 'foo',
            'module_vars': {
                'docker_extra_args': 'bar'
            }
        }
    }

    test_case_1_module = MockModule(**test_case_1_data)
    test_case_1_connection = PlayContext()
    test_case_1_connection.set_attributes_from_plugin(test_case_1_module)

    assert test_case_1_connection._docker_extra_args == 'bar'


# Generated at 2022-06-25 05:37:53.557231
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    play_context_1 = PlayContext()
    play_context_1.become_user = "adam"
    play_context_1.become_method = "sudo"
    play_context_1.become = True
    play_context_1.connection = "smart"
    play_context_1.remote_user = "root"

    # Task with become_user set
    task_0 = Task()
    task_0.become_user = "bob"
    # Task with connection set
    task_1 = Task()
    task_1.connection = "ssh"
    # Task with remote_user set
    task_2 = Task()
    task_2.remote_user = "sue"

    # Variables for task with become_user
    variables_0 = dict()
    # Variables for task with

# Generated at 2022-06-25 05:38:00.625795
# Unit test for constructor of class PlayContext
def test_PlayContext():
    try:
        play_context_0 = PlayContext()
        if play_context_0._connection_lockfd is not None and play_context_0._pipelining is not False and play_context_0._verbosity == 0:
            test_case_0()
            print("")
    except (AttributeError, TypeError) as e:
        print('PlayContext.__init__ raised TypeError/AttributeError exception: ' + str(e))
        print("")


# Generated at 2022-06-25 05:38:06.309141
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pc = PlayContext()
    pc.remote_user = 'siri'
    pc.connection = 'ssh'
    pc.port = '22'
    pc.timeout = 10
    pc.ssh_common_args = ''
    pc.ssh_extra_args = ''
    pc.sftp_extra_args = ''
    pc.scp_extra_args = ''
    pc.become = False
    pc.become_method = 'sudo'
    pc.become_user = 'root'
    pc.become_pass = '1234'
    pc.become_flags = '-H'
    pc.verbosity = 0
    pc.check_mode = False
    pc.no_log = False
    pc.only_tags = set()
    pc.skip_tags = set()
    pc.start

# Generated at 2022-06-25 05:38:07.944329
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    #assert False # TODO: implement your test here
    pass

# Generated at 2022-06-25 05:38:11.902066
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    ansible_connection = 'local'
    ansible_connection = ansible_connection.replace('local', 'smart')
    assert ansible_connection == 'smart'


# Generated at 2022-06-25 05:38:14.722037
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    set_attributes_from_plugin_0 = play_context_0.set_attributes_from_plugin()


# Generated at 2022-06-25 05:38:17.852486
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    print ("Testing PlayContext.set_attributes_from_plugin")
    # Set up values for test
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin()
    print ("PlayContext.set_attributes_from_plugin method completed")


# Generated at 2022-06-25 05:38:22.034146
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    try:
        import __main__
        __main__.__file__ = os.path.abspath('setup')
        setup = imp.load_source('setup', 'setup')
    except IOError as e:
        print("Failed to import the 'setup.py' file: %s" % e)
        return False

    play_context = PlayContext()
    play_context.set_attributes_from_plugin(setup)

    return play_context._environment == {} and play_context._no_log == False


# Generated at 2022-06-25 05:38:45.306065
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Testing with a task and a connection lockfd
    # Create a task
    task_0 = Task()
    # Create a connection lockfd
    connection_lockfd_0 = 0
    # Create an instance of a PlayContext
    play_context_0 = PlayContext(None, None, connection_lockfd_0)
    # Create a dictionary
    variables_0 = dict()
    # Create an instance of a Templar
    templar_0 = Templar(loader=None, variables=None, shared_loader_obj=None)
    # Call the method set_task_and_variable_override
    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)


# Generated at 2022-06-25 05:38:52.449202
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    print('In test_PlayContext_set_task_and_variable_override')

    play_context_0 = PlayContext()

    # Check the default values of the PlayContext object
    assert play_context_0.transport is None
    assert play_context_0.remote_addr is None
    assert play_context_0.remote_user is None
    assert play_context_0.port is None
    assert play_context_0.connection == 'smart'
    assert play_context_0.timeout == 10
    assert play_context_0.ssh_common_args == ''
    assert play_context_0.ssh_extra_args == ''
    assert play_context_0.sftp_extra_args == ''
    assert play_context_0.scp_extra_args == ''
    assert play_context_0.ssh

# Generated at 2022-06-25 05:38:56.717710
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # TODO: mock plugin obj
    # init play_context object
    play_context_test = PlayContext()
    play_context_test.set_attributes_from_plugin("test_plugin")

    # check the result
    # expected result is that play_context_test.connection is "test_plugin"
    assert play_context_test.connection=="test_plugin"


# Generated at 2022-06-25 05:38:59.014836
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Test variables
    plugin = None
    play_context_0 = PlayContext(play=None, passwords=None, connection_lockfd=None)
    play_context_0.set_attributes_from_plugin(plugin)


# Generated at 2022-06-25 05:38:59.631995
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    test_case_0()


# Generated at 2022-06-25 05:39:08.357858
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context = PlayContext()

    # Test for constructor with the correct paramters
    assert play_context is not None

    # Test for constructor with a wrong parameter name
    try:
        play_context = PlayContext(wrongparamname="wrongparamvalue")
    except Exception as e:
        assert isinstance(e, TypeError)

    # Test for constructor with a wrong parameter type
    try:
        play_context = PlayContext(connection_lockfd=2.0)
    except Exception as e:
        assert isinstance(e, TypeError)


# Generated at 2022-06-25 05:39:10.209291
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()
    play_context.set_attributes_from_plugin('shell')


# Generated at 2022-06-25 05:39:21.115888
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()

    class task_0():

        def __init__(self):
            self.remote_user = None
            self.delegate_to = None
            self.check_mode = None

        def __getattribute__(self, attr):
            if attr == 'remote_user':
                raise AttributeError()
            return object.__getattribute__(self, attr)
    task_0 = task_0()
    variables = dict()
    templar = MockTemplar()
    result = play_context_0.set_task_and_variable_override(task_0, variables, templar)


# Generated at 2022-06-25 05:39:31.666189
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Test setup
    play_context_1 = PlayContext()
    ssh_0        = SSHConnection()

    ssh_0.set_options(
        host_keys_filename='host_keys_filename_value',
        control_path='%(directory)s/%%C',
        ssh_args='ssh_args_value',
        cacert='cacert_value',
        pipelining='pipelining_value',
        scp_if_ssh='scp_if_ssh_value',
        remote_tmp='remote_tmp_value'
    )
    # Test step 1:
    # Test condition 1
    # Expected result: No exception should be raised when calling this method
    play_context_1.set_attributes_from_plugin(ssh_0)

    # Test step 2:
    # Test condition 1
   

# Generated at 2022-06-25 05:39:34.067246
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    test_plugin_0 = InventoryScript(filename="/usr/share/ansible/plugins/inventory/test.py")
    play_context_0.set_attributes_from_plugin(test_plugin_0)


# Generated at 2022-06-25 05:40:17.394823
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()

    # test 4: invalid plugin
    plugin = "invalid_plugin"
    with pytest.raises(AnsibleError):
        play_context.set_attributes_from_plugin(plugin)

    # test 5: valid plugin with all settings
    plugin = 'net_ping'
    ping_options = {
        'host': 'host',
        'data': 'data',
        'source': 'source',
        'vrf': 'vrf',
        'destination': 'destination',
        'ttl': 'ttl',
        'count': 'count',
        'timeout': 'timeout',
        'state': 'state',
        'df_bit': 'df_bit',
        'interval': 'interval',
        'vlan': 'vlan'
    }
   

# Generated at 2022-06-25 05:40:19.463826
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_1 = PlayContext()
    def_opts_1 = plugin_options()
    play_context_1.set_attributes_from_plugin(def_opts_1)


# Generated at 2022-06-25 05:40:22.886031
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_1 = PlayContext()
    task_1 = Task()
    variables_1 = {}
    templar_1 = Templar()
    play_context_1.set_task_and_variable_override(task_1, variables_1, templar_1)


# Generated at 2022-06-25 05:40:24.823500
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context_1 = PlayContext(None, None, None)



# Generated at 2022-06-25 05:40:36.768380
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    assert play_context_0.name == ''

    # test with ssh plugin
    play_context_0.set_attributes_from_plugin('ssh')
    assert play_context_0.name == 'ssh'
    assert play_context_0.connection == 'ssh'
    assert play_context_0.scp_if_ssh == False
    assert play_context_0.socket_path == '/some/path'

    # test with winrm plugin
    play_context_0.set_attributes_from_plugin('winrm')
    assert play_context_0.name == 'winrm'
    assert play_context_0.connection == 'winrm'
    assert play_context_0.transport == 'kerberos'
    assert play_context_0.server_cert_

# Generated at 2022-06-25 05:40:42.987557
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    arg_0 = dict()
    arg_0['port'] = 'test'
    arg_0['timeout'] = 'test'
    arg_0['verbosity'] = 'test'
    play_context_0.set_attributes_from_cli(arg_0)
    play_context_0.set_attributes_from_cli()


# Generated at 2022-06-25 05:40:48.340738
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Test case 1:
    #   Test Instance creation
    play_context_0 = PlayContext()

    # Test case 2:
    #   Test templar attribute
    play_context_0 = PlayContext()
    task_0 = dict()
    variables_0 = dict()
    templar_0 = dict()
    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)

# Generated at 2022-06-25 05:40:50.884523
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context = PlayContext()
    play_context.set_attributes_from_cli()


# Generated at 2022-06-25 05:41:01.564602
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    '''
    This is for testing whether the result of set_attributes_from_cli() is actually considered.
    '''
    # Initialize PlayContext instance
    play_context_0 = PlayContext()

    # Generate command line options
    class Options(object):
        def __init__(self):
            self.timeout = 30
            self.private_key_file = "play_context_test/key_file"
            self.verbosity = 1
            self.start_at_task = "task_2"

    options = Options()

    # Make the command line options accessible to the PlayContext instance
    context.CLIARGS = options
    play_context_0.set_attributes_from_cli()

    # Verify that the attributes have been set properly
    assert (play_context_0.timeout == options.timeout)


# Generated at 2022-06-25 05:41:03.874296
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    runner_test_case_0()
    play_context_test_case_0()
    play_context_test_case_1()


# Generated at 2022-06-25 05:42:31.515446
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    play_context = PlayContext()


# Generated at 2022-06-25 05:42:42.859132
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    '''
    Test for PlayContext.set_task_and_variable_override
    '''

    print('Test PlayContext.set_task_and_variable_override')

    ### Create a play_context
    play_context = PlayContext(None)

    ### Create a task
    test_task = Task()

    test_task.remote_user = 'test_remote_user'
    test_task.sudo = 'true'
    test_task.sudo_user = 'test_sudo_user'
    test_task.su = 'true'
    test_task.su_user = 'test_su_user'
    test_task.su_pass = 'test_su_pass'
    test_task.become = 'true'
    test_task.become_method = 'su'
    test_task.bec

# Generated at 2022-06-25 05:42:53.916322
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()
    # test connection plugin
    connection_plugin = Connection(play_context)
    play_context.set_attributes_from_plugin(connection_plugin)
    assert play_context.remote_addr is None
    assert play_context.port is None
    assert play_context.remote_user is None
    assert play_context.password is None
    assert play_context.private_key_file is None
    assert play_context.connection == 'ssh'
    assert play_context.timeout == C.PERSISTENT_COMMAND_TIMEOUT
    assert play_context.accelerate_port is None
    assert play_context.accelerate_ipv6 is False
    assert play_context.accelerate_timeout is 30
    assert play_context.accelerate_multi_key is False
   

# Generated at 2022-06-25 05:43:04.479580
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    playbook_args_0 = {'connection': 'ssh', 'delegate_to': 'localhost', 'become_method': 'sudo', 'remote_user': 'root', 'become': False, 'timeout': 10, 'port': 22, 'become_user': 'root', 'verbosity': 2, 'remote_addr': '10.0.0.1'}
    from ansible.plugins.loader import connection_loader
    connection_loader.get('local')
    module_0 = connection_loader.get('local')
    play_context_0.set_attributes_from_plugin(module_0)
    assert play_context_0.connection == 'local'


# Generated at 2022-06-25 05:43:08.818099
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = VariableManager()
    templar_0 = Templar(variables=variables_0)
    play_context_updated_0 = play_context_0.set_task_and_variable_override(task_0=task_0, variables=variables_0, templar=templar_0)
    assert play_context_updated_0.timeout == C.DEFAULT_TIMEOUT
    assert play_context_updated_0.connection == 'smart'



# Generated at 2022-06-25 05:43:18.687470
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plugin_id = "wait_for"
    test_file = os.path.join(os.path.dirname(__file__), 'ansible_test_data/test_PlayContext_set_attributes_from_plugin.json')
    plugin_path = os.path.dirname(__file__)
    plugin_args = json.loads(open(test_file, 'r').read())
    plugin = ConnectionBase(name=plugin_id, load_name=plugin_id, class_name=plugin_id,
                            runner=None,
                            config=plugin_args, plugin_args=plugin_args,
                            output_path=plugin_path)
    play_context_0 = PlayContext(None, None, None)
    play_context_0.set_attributes_from_plugin(plugin)
    assert len

# Generated at 2022-06-25 05:43:19.885040
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()



# Generated at 2022-06-25 05:43:25.722207
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    play = Play()
    variables = dict()
    templar = Templar(loader=None)

    task = Task()
    task.connection = "local"
    task.remote_user = "some_user"

    play_context = PlayContext()

    play_context.set_attributes_from_play(play)

    new_info = play_context.set_task_and_variable_override(task, variables, templar)

    assert new_info.connection == "local"
    assert new_info.remote_user == "some_user"

# Generated at 2022-06-25 05:43:31.418651
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_1 = PlayContext()
    play_context_1.set_attributes_from_plugin( module='setup' )
    play_context_1.set_attributes_from_plugin( module='command' )
    play_context_1.set_attributes_from_plugin( module='copy' )
    play_context_1.set_attributes_from_plugin( module='raw' )
    play_context_1.set_attributes_from_plugin( module='shell' )
    play_context_1.set_attributes_from_plugin( module='debug' )
    play_context_1.set_attributes_from_plugin( module='script' )
    play_context_1.set_attributes_from_plugin( module='synchronize' )
    play_context_1.set_att

# Generated at 2022-06-25 05:43:37.418750
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    context.CLIARGS = {'timeout': '42'}
    play_context = PlayContext()
    play_context.set_attributes_from_cli()
    assert play_context.timeout == 42
