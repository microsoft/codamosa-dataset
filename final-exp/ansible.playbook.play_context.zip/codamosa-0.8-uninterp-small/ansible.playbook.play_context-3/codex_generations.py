

# Generated at 2022-06-25 05:34:43.628984
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()
    assert play_context_0._verbosity is 0
    assert play_context_0._prompt is ''
    assert play_context_0._success_key is ''
    assert play_context_0._connection_lockfd is None
    assert play_context_0._force_handlers is False
    assert play_context_0._only_tags.__class__.__name__ is 'set'
    assert play_context_0._skip_tags.__class__.__name__ is 'set'
    assert play_context_0._start_at_task is None
    assert play_context_0._step is False
    assert play_context_0._timeout is C.DEFAULT_TIMEOUT
    assert play_context_0

# Generated at 2022-06-25 05:34:48.259272
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    print("Test: set_attributes_from_plugin")

    # just some test data
    plugin = {'name': 'test'}

    # create play_context instance
    play_context_0 = PlayContext()

    # invoke method
    play_context_0.set_attributes_from_plugin(plugin)


# Generated at 2022-06-25 05:34:53.252821
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    print('Test: set_task_and_variable_override of PlayContext class')
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = {}
    templar_0 = Templar(loader=None, variables=None)
    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)


# Generated at 2022-06-25 05:35:02.203027
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    dict_0 = None
    play_context_0 = PlayContext(dict_0)

    # Test using an invalid option
    play_context_0.set_attributes_from_cli()
    assert (hasattr(play_context_0, "verbosity"))

    # Test for values that are set
    play_context_0.set_attributes_from_cli()
    assert (hasattr(play_context_0, "private_key_file"))
    assert (hasattr(play_context_0, "verbosity"))
    assert (hasattr(play_context_0, "start_at_task"))



# Generated at 2022-06-25 05:35:05.169655
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    dict_0 = None
    play_context_0 = PlayContext(dict_0)
    play_context_0.set_attributes_from_cli()


# Generated at 2022-06-25 05:35:12.132531
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    dict_0 = {'connection_lockfd': 0, '_attributes': {'connection': 'smart'}}
    play_context_0 = PlayContext(dict_0)
    data_dict_0 = {'_task': {}, '_variables': {'ansible_connection': 'smart'}}
    result = play_context_0.set_task_and_variable_override(data_dict_0['_task'], data_dict_0['_variables'], data_dict_0['_use_step_wrapper'])

# Generated at 2022-06-25 05:35:19.517223
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    variables_0 = collections.OrderedDict()
    variables_0['host_list'] = 'localhost'
    variables_0['vault_pass'] = 'secret'
    variables_0['ansible_ssh_user'] = 'zenoss'
    task_0 = Task()
    play_context_0.set_task_and_variable_override(task_0, variables_0, None)


# Generated at 2022-06-25 05:35:21.576526
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    # set_attributes_from_plugin raises exception
    with pytest.raises(Exception):
        pass


# Generated at 2022-06-25 05:35:25.920063
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Create instance
    play_context_0 = PlayContext()

    # Get attribute connection, as it is private
    attr = play_context_0._get_attr_connection()

    # Check if connection is ssh
    assert attr == 'ssh'


# Generated at 2022-06-25 05:35:36.268621
# Unit test for constructor of class PlayContext
def test_PlayContext():
    dict_0 = {}
    play_context_0 = PlayContext(dict_0)
    str_0 = str(play_context_0)

# Generated at 2022-06-25 05:35:52.439044
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin_0 = None
    try:
        play_context_0.set_attributes_from_plugin(plugin_0)
    except Exception as e:
        assert type(e) == TypeError


# Generated at 2022-06-25 05:36:00.784318
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    
    # set up test data
    play_context_0 = PlayContext()
    playbook_path = '/home/akshayaa/ansible-latest/test/integration/inventory_tests/test.yml'
    task = Task.load(dict(action = dict(module = 'command', args = 'ls')), play=dict(name = 'command test', connection = 'local', gather_facts = 'no', hosts = 'localhost', tasks = [dict(name = 'command test', action = dict(module = 'command', args = 'ls'))]))
    variables = {}
    variables['hostvars'] = {'localhost': {'ansible_connection': 'ssh', 'ansible_host': '127.0.0.1', 'ansible_user': 'akshayaa', 'ansible_port': 22}}

# Generated at 2022-06-25 05:36:03.784855
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    play_context_1 = play_context_0.copy()
    assert play_context_0 == play_context_1


# Generated at 2022-06-25 05:36:12.927595
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    task_0 = dict2obj({
        'check_mode': None,
        'delegate_to': None,
        'delegate_facts': True,
        'remote_user': 'root',
        'no_log': False
    })
    variables_0 = dict2obj({
        'ansible_ssh_host': '127.0.0.1',
        'ansible_connection': 'local',
        'ansible_ssh_pass': None,
        'ansible_ssh_port': 22,
        'ansible_ssh_user': 'root',
        'ansible_ssh_private_key_file': None
    })

# Generated at 2022-06-25 05:36:14.656083
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    for plugin in get_all_plugin_loaders():
        play_context_0.set_attributes_from_plugin(plugin)


# Generated at 2022-06-25 05:36:21.943858
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    test_module_name = 'test_module'
    test_module_args = 'test_module_args'
    test_module_action = 'test_module_action'
    for test_case in test_cases:
        play_context_test_case = copy.deepcopy(PlayContext())
        if 'test_connection' in test_case:
            play_context_test_case.connection = test_case['test_connection']
        if 'test_remote_addr' in test_case:
            play_context_test_case.remote_addr = test_case['test_remote_addr']
        if 'test_remote_user' in test_case:
            play_context_test_case.remote_user = test_case['test_remote_user']
        if 'test_port' in test_case:
            play_

# Generated at 2022-06-25 05:36:25.246854
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # arrange
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = dict()

    # action
    result = play_context_0.set_task_and_variable_override(task_0, variables_0, None)

    # assert
    assert result is not None


# Generated at 2022-06-25 05:36:27.926785
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_1 = Task()
    variables_2 = dict()
    templar_3 = Templar()
    play_context_0.set_task_and_variable_override(task_1, variables_2, templar_3)


# Generated at 2022-06-25 05:36:33.886206
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """
    Unit test for method set_attributes_from_plugin
    :return:
    """
    playbook_path = playbook_file_name('connection.yml')
    expect_attributes = {
        'ansible_ssh_private_key_file': '/home/key_file',
        'ansible_ssh_user': 'worker',
        'ansible_ssh_port': 22,
        'ansible_connection': 'ssh',
    }
    play_context = PlayContext(play=Play().load(playbook_path, variable_manager=VariableManager(), loader=Loader()))
    play_context.set_attributes_from_plugin(get_plugin('ssh'))
    attrs = play_context._attributes
    for attr,value in expect_attributes.items():
        assert attrs[attr] == value

# Generated at 2022-06-25 05:36:36.615249
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    set_attributes_from_plugin_0 = PlayContext()
    set_attributes_from_plugin_0.set_attributes_from_plugin(plugin="plugin")


# Generated at 2022-06-25 05:37:27.762731
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin_0 = ShellModule()
    plugin_0.set_options()
    play_context_0.set_attributes_from_plugin(plugin_0)
    if context.CLIARGS.get('timeout', False):
        if play_context_0.executable != 'sh':
            print("\nFailed to set_attributes_from_plugin")
            return False
    else:
        if play_context_0.executable != '/bin/sh':
            print("\nFailed to set_attributes_from_plugin")
            return False
    return True


# Generated at 2022-06-25 05:37:36.292832
# Unit test for method set_attributes_from_plugin of class PlayContext

# Generated at 2022-06-25 05:37:44.412578
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    yaml_data = """
    - name: test play
      hosts: localhost
      connection: local
      gather_facts: False
      tasks:
        - name: test task
          debug:
            msg: the ansible timeout value is {{ ansible_timeout }}
    """
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play = Play.load(yaml_data, variable_manager=variable_manager, loader=DataLoader())
    play._target_hosts = [Host(name="localhost")]
    play_context_test = PlayContext(play)
    play_context_test.set_attributes_from_cli()
    assert play_context_test.timeout == 10


# Generated at 2022-06-25 05:37:50.150249
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Create an instance of PlayContext
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = dict()
    templar_0 = Templar()
    connection_0= play_context_0.set_task_and_variable_override(task_0,variables_0,templar_0)

# Generated at 2022-06-25 05:37:54.719279
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Retrieve the value of parameter "net_os" from the connection plugin
    associated with the given PlayContext object
    '''

    # initialize vars
    play_context_0 = PlayContext()
    plugin_0 = plugin.connection_loader.get('ssh', play_context_0, '/path/to/ansible_module')
    play_context_0.set_attributes_from_plugin(plugin_0)
    net_os = play_context_0.network_os

    # assert
    assert(net_os is None)

# Generated at 2022-06-25 05:37:59.991491
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Test that it can set variables properly
    play_context_0 = PlayContext()
    task_0 = MagicMock()
    task_0.connection = 'ssh'
    task_0.remote_user = 'root'
    variables_0 = dict()
    variables_0['ansible_connection'] = 'local'
    templar_0 = MagicMock()
    assert play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0) is not None


# Generated at 2022-06-25 05:38:06.670781
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_2 = PlayContext()
    task_2 = Task()
    variables_2 = {}
    templar_2 = Templar(loader=None, variables=variables_2)
    assert play_context_2.set_task_and_variable_override(task_2, variables_2, templar_2) == play_context_2



# Generated at 2022-06-25 05:38:11.324332
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Test using a normal task with no delegation
    task0 = MagicMock(name='task0')
    variables0 = {'ansible_ssh_port': 42, 'ansible_user': 'testuser', 'ansible_ssh_host': 'testhost'}
    templar0 = MagicMock(name='templar0')
    pc0 = PlayContext(play=None, passwords={'conn_pass': 'testpass', 'become_pass': 'testpass'})
    new_info = pc0.set_task_and_variable_override(task0, variables0, templar0)
    # Check that the new_info instance is not the original, but a copy
    assert new_info is not pc0
    # Check that the new_info instance is an instance of PlayContext

# Generated at 2022-06-25 05:38:19.416940
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    class Play():
        def __init__(self, name, force_handlers=False):
            self.name = name
            self.force_handlers = force_handlers
    play_0 = Play("play_0", False)
    play_context_0.set_attributes_from_play(play_0)
    class Task():
        def __init__(self, name, remote_user=None, become=False, become_user=None, delegate_to=None, check_mode=None, diff=None):
            self.name = name
            self.remote_user = remote_user
            self.become = become
            self.become_user = become_user
            self.delegate_to = delegate_to
            self.check_mode = check_mode
           

# Generated at 2022-06-25 05:38:21.480818
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()
    expected = 'ec2'
    actual = play_context_0.network_os
    assert actual == expected


# Generated at 2022-06-25 05:39:21.196232
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    module_name = "test_module"
    play_context = PlayContext(play=None)
    task = Task()
    task.module_name = module_name
    task.connection = 'local'
    task.delegate_to = ''
    task.remote_user = "root"

    variables = {'ansible_connection': 'local', 'ansible_ssh_user': 'ansible', 'localhost': ''}
    templar = Templar(variables=variables)

    play_context = play_context.set_task_and_variable_override(task=task, variables=variables, templar=templar)
    assert play_context.connection == "local"
    assert play_context.remote_user == "root"
    assert play_context.remote_addr == "localhost"
    assert play_context

# Generated at 2022-06-25 05:39:28.118118
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """
    PlayContext: set_attributes_from_plugin should set no positional arguments (defaults),
    also should set all plugin attributes
    """

    fake_plugin_class = connection_loader.get('local')
    fake_plugin = fake_plugin_class()

    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin(fake_plugin)


# Generated at 2022-06-25 05:39:34.924903
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    class_dict_0 = {}
    plugin_0 = PluginLoader('netconf', class_dict_0, 'netconf', C.get_config_path())
    plugin_0.add_option('host', 'netconf_host')
    plugin_0.add_option('port', 'netconf_port')
    play_context_0.set_attributes_from_plugin(plugin_0)
    assert play_context_0.port == plugin_0.get_option('port'), "PlayContext.set_attributes_from_plugin method failed, expected: %s, actual: %s" % (play_context_0.port, plugin_0.get_option('port'))

# Generated at 2022-06-25 05:39:37.316013
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # TODO: Implement this method
    raise NotImplementedError()


# Generated at 2022-06-25 05:39:48.195325
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()

    _connection_lockfd = play_context_0.get_connection_lockfd()
    assert play_context_0.get_become() == False
    assert play_context_0.get_become_flags() == C.DEFAULT_BECOME_FLAGS
    assert play_context_0.get_become_method() == None
    assert play_context_0.get_become_pass() == None
    assert play_context_0.get_become_user() == None
    assert play_context_0.get_force_handlers() == False
    assert play_context_0.get_network_os() == None
    assert play_context_0.get_only_tags() == set()

# Generated at 2022-06-25 05:39:51.538790
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    context.CLIARGS = dict()
    context.CLIARGS['timeout'] = 5
    play_context_0.set_attributes_from_cli()
    assert(isinstance(play_context_0.timeout, int))
    assert(play_context_0.timeout == 5)


# Generated at 2022-06-25 05:39:52.429916
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    test_case_0()

# Generated at 2022-06-25 05:40:03.178515
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    play_context.vault_password = 'secret'

    task = Task()
    task.become = 'no'
    task.become_user = 'root'
    task.connection = 'local'
    task.timeout = 1
    task.ssh_password = 'ssh_password'
    task.remote_user = 'remote_user'
    task.environment = 'environment'
    task.port = 1
    task.delegate_to = 'localhost'
    task.remote_addr = 'localhost'
    task.only_tags = ['a', 'b']
    task.skip_tags = ['c', 'd']


# Generated at 2022-06-25 05:40:07.844054
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    task_0 = Task()
    variables_0 = dict()
    templar_0 = Templar(loader=None, variables=dict())
    new_info_0 = PlayContext.set_task_and_variable_override(task_0, variables_0, templar_0)
    print(new_info_0)


# Generated at 2022-06-25 05:40:11.987250
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_2 = PlayContext()
    task_2 = MockTask()
    variables_2 = dict()
    templar_2 = MockTemplar()

    result = play_context_2.set_task_and_variable_override(task_2, variables_2, templar_2)

    # verify
    assert result != None



# Generated at 2022-06-25 05:42:13.552403
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    import unittest
    import sys
    import tempfile
    import shutil
    import os
    import pipes

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    from ansible import constants as C
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader



# Generated at 2022-06-25 05:42:21.128706
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()
    FakePlugin = namedtuple('FakePlugin', ['get_option'])
    plugin = FakePlugin(get_option=lambda key: 'option_' + key)
    play_context.set_attributes_from_plugin(plugin)
    assert getattr(play_context, 'option_test') == 'option_test'
    assert getattr(play_context, '_test') is None


# Generated at 2022-06-25 05:42:26.489057
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context_0 = PlayContext(play=play)
    play_context_0.set_task_and_variable_override(task=task, variables=variables, templar=templar)

# Generated at 2022-06-25 05:42:34.182005
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    set_attributes_from_plugin = PlayContext.set_attributes_from_plugin
    # Test using arg1 plugin
    plugin = 'custom'
    options = []
    if set_attributes_from_plugin(plugin):
        options = C.config.get_configuration_definitions(get_plugin_class(plugin), plugin._load_name)
    assert_equals(options, [])

    # Test using arg1 plugin and arg2 plugin_options
    plugin = 'custom'
    options = ['one', 'two']
    if set_attributes_from_plugin(plugin, plugin_options=options):
        options = C.config.get_configuration_definitions(get_plugin_class(plugin), plugin._load_name)
    assert_equals(options, ['one', 'two'])


# Generated at 2022-06-25 05:42:45.081236
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    yaml_string = '---\n' \
                  '- hosts: localhost\n' \
                  '  connection: local\n' \
                  '  gather_facts: no\n' \
                  '  vars:\n' \
                  '    ansible_ssh_port: 22\n' \
                  '  tasks:\n' \
                  '  - name: test\n' \
                  '    debug:\n' \
                  '      msg: "{{ ansible_ssh_port }}"\n'

    yaml_results = [{'msg': '22'}]

    # load a play with a task

# Generated at 2022-06-25 05:42:47.246655
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # play_context_obj = PlayContext()
    play_context_obj = PlayContext(play={'force_handlers': False})
    play_context_obj.set_attributes_from_plugin(plugin={'_load_name': 'abc'})


# Generated at 2022-06-25 05:42:52.151731
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin_0 = paramiko_connection.Connection(play_context_0)

    play_context_0.set_attributes_from_plugin(plugin_0)


# Generated at 2022-06-25 05:42:53.531460
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context_0 = PlayContext()


# Generated at 2022-06-25 05:42:56.019848
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plugin_0 = user_plugin(None)

    play_context_0 = PlayContext(None, None)

    play_context_0.set_attributes_from_plugin(plugin_0)


# Generated at 2022-06-25 05:42:58.286960
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    task = Task()
    variables = {}

    play_context.set_task_and_variable_override(task, variables, Templar())
