

# Generated at 2022-06-25 05:35:03.501109
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    class PluginB(ConnectionBase):
        transport = 'conn_test_b'

        def get_option(self, k):
            return getattr(self, k, None)

    play_context_0 = PlayContext()
    plugin_b = PluginB()
    plugin_b.test_option_b = 'test_value_b'
    play_context_0.set_attributes_from_plugin(plugin_b)
    assert play_context_0.test_option_b == 'test_value_b'


# Generated at 2022-06-25 05:35:14.468963
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # define some mock task, variable and templar objects
    class task_obj:
        def __init__(self):
            self.remote_user = 'test_user'
            self.delegate_to = 'test_delegate_host'
            self.connection = 'test_connection'
            self.port = 'test_port'
            self.remote_addr = 'test_remote_addr'
            self.timeout = 'test_timeout'
            self.check_mode = 'test_check_mode'
            self.diff = 'test_diff'

    class templar_obj:
        def template(self, delegate_to):
            return delegate_to

    class variables_obj:
        def __init__(self):
            self.ansible_delegated_vars = Variables()

    # use the mock objects

# Generated at 2022-06-25 05:35:26.211321
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    test_case = 'default'
    if test_case == 'default':
        play_context_0.set_attributes_from_cli()
    elif test_case == 'timeout':
        context.CLIARGS = dict(timeout = 'guf')
        with pytest.raises(AnsibleError):
            play_context_0.set_attributes_from_cli()
        context.CLIARGS = dict(timeout = '5')
        play_context_0.set_attributes_from_cli()
    elif test_case == 'start_at_task':
        context.CLIARGS = dict(start_at_task = 'guf')
        play_context_0.set_attributes_from_cli()
    else:
        raise Exception

# Generated at 2022-06-25 05:35:37.104977
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    vars_0 = dict()
    task_0 = Task()
    templar_0 = Templar(loader=None, variables=dict())

    #test with default values
    play_context_0.set_attributes_from_cli()
    play_context_0.set_attributes_from_play(Play())
    play_context_0.set_attributes_from_plugin(object())
    play_context_0.set_task_and_variable_override(task_0, vars_0, templar_0)

    #test to verify default values
    assert play_context_0.timeout == C.DEFAULT_TIMEOUT
    assert play_context_0.verbosity == 0
    assert play_context_0.start_at_task == None

# Generated at 2022-06-25 05:35:42.325756
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = dict()
    templar_0 = Templar(loader=None)
    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)


# Generated at 2022-06-25 05:35:50.769304
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Regression test for #38787
    play_context = PlayContext()
    task = Task()
    task.delegate_to = "$vsphere_server"
    task.remote_user = "test_user"
    task.become = True
    task.become_method = "winrm"
    task.become_user = "become_user"
    task.become_pass = "become_pass"

# Generated at 2022-06-25 05:35:58.693748
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # Create a user test case
    tasks = {'name': 'test_task'}
    task = Task()
    task.vars = tasks
    templar = Templar(loader=None)

    # Create a user test case
    play_context = PlayContext()
    play_context.set_task_and_variable_override(task, task.vars, templar)

    return play_context

if __name__ == '__main__':
    print(test_PlayContext_set_task_and_variable_override())

# Generated at 2022-06-25 05:36:06.040143
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_1 = PlayContext()
    task_1 = dict(name="task_1")
    variables_1 = dict(ansible_user="test")
    templar_1 = dict(template="test")
    play_context_1.set_task_and_variable_override(task_1, variables_1, templar_1)
    try:
        assert play_context_1.remote_user == "test"
    except AssertionError:
        raise AssertionError("Testcase 1 failed.")


# Generated at 2022-06-25 05:36:13.833394
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    test_plugin = DummyNetworkModule()
    test_plugin.CONNECTION = 'local'
    test_plugin.TRANSPORT = 'local'
    test_plugin.REMOTE_USER = 'foo'
    play_context_1 = PlayContext()
    play_context_1.set_attributes_from_plugin(test_plugin)
    assert play_context_1.connection == 'local'
    assert play_context_1.transport == 'local'
    assert play_context_1.remote_user == 'foo'


# Generated at 2022-06-25 05:36:21.853221
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    task = Task()
    variables = dict()
    # Set parameters of task that are going to be overridden
    task.remote_user = 'user'
    task.delegate_to = '127.0.0.1'
    task.sudo = True
    task.sudo_user = 'user'
    task.become = False
    task.become_user = 'user'
    task.verbosity = 2
    task.check_mode = True
    task.diff = True
    delegated_vars = dict()

    # Set values for task params that are going to be overridden
    variables['ansible_user'] = 'root'
    variables['ansible_ssh_user'] = 'root'
    variables['ansible_become'] = True

# Generated at 2022-06-25 05:36:39.219633
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_1 = PlayContext()


# Generated at 2022-06-25 05:36:40.918143
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context_0 = PlayContext()

    print(play_context_0._attributes)


# Generated at 2022-06-25 05:36:45.133410
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()

    task_0 = Task()
    variables_0 = {}
    templar_0 = Templar(loader=object)

    try:
        play_context_0.set_task_and_variable_override(task_0,variables_0,templar_0)
    except AttributeError:
        print("AttributeError")
    except ValueError:
        print("ValueError")
    except TypeError:
        print("TypeError")


# Generated at 2022-06-25 05:36:49.250408
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = dict()
    templar_0 = Templar(variables=variables_0)
    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)


# Generated at 2022-06-25 05:37:00.688803
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # import this here so we only get the side effects of doing so if we actually run tests
    from ansible.playbook.play_context import PlayContext

    # Set up the input data for test case
    play_context_0 = PlayContext()
    task_0 = AnsibleTask()
    variables_0 = dict()
    templar_0 = Templar()

    # Call the function being tested
    new_info_0 = play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)

    # Check that we get the correct result
    assert new_info_0.remote_user == "root"
    assert new_info_0.connection == "smart"
    assert new_info_0.check_mode == False

# Generated at 2022-06-25 05:37:11.897559
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    '''
    Tests if values of PlayContext after a call to set_task_and_variable_override are as expected
    Method tested - set_task_and_variable_override
    '''

    ################################################################################
    # 1.1 set all parameters in a task
    ################################################################################

    task_1_1 = Task()
    task_1_1.action = 'action_1'
    task_1_1.async_val = 'async_val_1'
    task_1_1.async_seconds = 'async_seconds_1'
    task_1_1.async_poll_interval = 'async_poll_interval_1'
    task_1_1.become = 'become_1'

# Generated at 2022-06-25 05:37:21.879662
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Create a PlayContext
    play_context_0 = PlayContext()

    # Create task from yaml
    yaml = """
    name: ping
    action: ping
    remote_user: test-user
    become: yes
    become_method: sudo
    delegate_to: host1
    delegate_facts: True
    register: task_output
    """
    task = load_task_v2(yaml, name='ping')
    variables = dict()

    # Instantiate a HostVarsVarsManager
    host_vars_manager = HostVarsVarsManager()

    # Set a global variable and retrieve it from the HostVarsVarsManager
    host_vars_manager._set_variable('inventory_hostname', 'host1')

# Generated at 2022-06-25 05:37:24.575529
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Test with connection = "ansible.executor.task_result.TaskResult"
    # Test with delegate_to = "ansible.executor.task_result.TaskResult"
    # Test with hostvars = "ansible.executor.task_result.TaskResult"
    pass


# Generated at 2022-06-25 05:37:29.034143
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    name_0 = 'name_0'
    plugin_0 = getattr(__import__("{0}".format(name_0),fromlist=['name_0']), 'name_0')
    play_context_0.set_attributes_from_plugin(plugin_0)
    return (play_context_0)


# Generated at 2022-06-25 05:37:32.529766
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_1 = PlayContext()
    print(play_context_1.port)
    play_context_1.set_attributes_from_plugin('network_cli')


# Generated at 2022-06-25 05:38:06.668692
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    # setup
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin('test')


# Generated at 2022-06-25 05:38:16.940252
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from jinja2.environment import Environment
    from jinja2 import Template
    from ansible.vars.hostvars import HostVars
    from ansible.vars.task_vars import TaskVars
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play


    variables = HostVars()
    variables['ansible_connection'] = "smart"
    variables['ansible_python_interpreter'] = "/usr/bin/python"
    variables['ansible_shell_type'] = "csh"
    variables['ansible_shell_executable'] = None

    environment = Environment()
    templar = Template(environment)
    task_

# Generated at 2022-06-25 05:38:24.288410
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_obj = PlayContext()
    # Test method with arguments task:
    #Task(args=None, as_item=None, action=None, args_template=None,_loop=False,when=True,delegated_vars=None,delegate_facts=None,always_run=False,register=None,local_action=None,connection=None,run_once=False,_task_fields=('action', 'args', 'delegate_to', 'delegate_facts', 'notify', 'loop', 'loop_args', 'local_action', 'module_name', 'poll', 'register', 'retries', 'run_once', 'until', 'tags', 'when', 'async', 'async_poll', 'ignore_errors', 'listen', 'remote_user', 'transport', 'connection', 'sudo', '

# Generated at 2022-06-25 05:38:27.416707
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli( )


# Generated at 2022-06-25 05:38:32.524835
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    task = Task()
    variables = dict()
    variables['ansible_user'] = 'ansible_user'
    templar = Templar()
    new_info = play_context.set_task_and_variable_override(task, variables, templar)
    assert new_info is not None

# Generated at 2022-06-25 05:38:39.115759
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.playbook.task import Task

    play_context_0 = PlayContext()
    task_0 = Task()

    # Test case where variable variable_names does not exist in variable list
    play_context_0.set_task_and_variable_override(task_0, {}, {})

    # Test case where variable variable_names does exist in variable list
    #play_context_0.set_task_and_variable_override(task_0, {}, {})



# Generated at 2022-06-25 05:38:45.094177
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # PlayContext TestCase Vars

    play_context_0 = PlayContext()

    # TestCase with invalid args
    try:
        play_context_0.set_task_and_variable_override(task=None, variables=None, templar=None)
    except Exception as e:
        if (e.args[0] != "task or variables were not specified"):
            raise Exception(str(e))

# Generated at 2022-06-25 05:38:48.553482
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()
    play_context.set_attributes_from_plugin(None)


# Generated at 2022-06-25 05:38:52.972846
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin_0 = None

    # Call the method to test
    play_context_0.set_attributes_from_plugin(plugin_0)


# Generated at 2022-06-25 05:38:58.715754
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.plugins.connection.ssh import Connection as ssh_Connection
    play_context = PlayContext()
    data1 = {'become': True, 'become_user': 'root', 'become_method': 'su'}
    ssh_connection = ssh_Connection(play_context)
    ssh_connection.set_options(data1)
    play_context.set_attributes_from_plugin(ssh_connection)
    assert play_context._become == True
    assert play_context._become_method == 'su'
    assert play_context._become_user == 'root'


# Generated at 2022-06-25 05:40:11.523258
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Test for var1=var_ansible_port, var2=ansible_port
    # var1 should not be considered and var2 should be considered
    check_play_context_set_task_and_variable_override('ansible_port', ('var1', 'var2'))
    # test for var1 = ansible_ssh_port, var2 = ansible_port
    # var1 should be considered and var2 should not be considered
    check_play_context_set_task_and_variable_override('ansible_port', ('var1', 'var2'),
                                                       delegate_to='ansible_ssh_port')
    # test for var1 = ansible_winrm_port, var2 = ansible_port
    # var1 should be considered and var2 should not be considered
    check_play_context_

# Generated at 2022-06-25 05:40:21.164316
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    host_var_1 = "hostvar_1"
    host_var_2 = "hostvar_2"

    play_context_1 = PlayContext()
    task_1 = Task()

    # Sample data to test connection options from task
    task_1.connection = "ssh"
    task_1.remote_addr = "myhost.somewhere.org"
    task_1.become = True

    # Sample data to test inventory variables
    vars_1 = dict()
    vars_1['ansible_connection'] = "winrm"
    vars_1['ansible_winrm_server_cert_validation'] = "ignore"
    vars_1['ansible_user'] = "someuser"
    vars_1['ansible_become_pass'] = "mypass"
    vars_

# Generated at 2022-06-25 05:40:26.236031
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin = 'network_os'
    play_context_0.set_attributes_from_plugin(plugin)

if __name__ == '__main__':
    test_case_0()
    test_PlayContext_set_attributes_from_plugin()

# Generated at 2022-06-25 05:40:29.746208
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    context.CLIARGS = {'timeout': 5}
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()
    assert play_context_0.timeout == 5


# Generated at 2022-06-25 05:40:34.779064
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    host_vars = dict(ansible_ssh_user='foobar', ansible_become_user='root', ansible_become_pass='s3cr3t')
    host = Host(name='foobar', port=22)
    host.set_variable_manager(VariableManager())
    host.set_data(host_vars)

    pc_0 = PlayContext()
    pc_1 = PlayContext()
    pc_2 = PlayContext()
    pc_3 = PlayContext()
    pc_4 = PlayContext()
    pc_5 = PlayContext()
    pc_6 = PlayContext()
    pc_7 = PlayContext()

    task = Task()

    task.vars['ansible_ssh_user'] = 'foo'
    pc_0 = pc_0.set_task_and_variable_override

# Generated at 2022-06-25 05:40:44.540778
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    with mock.patch('ansible.module_utils.connection.network_common.C.DEFAULT_TIMEOUT', 42):
        with mock.patch('ansible.module_utils.connection.network_common.context.CLIARGS', {'timeout': 36}):
            play_context_0.set_attributes_from_cli()
            assert play_context_0.timeout == 36
    with mock.patch('ansible.module_utils.connection.network_common.context.CLIARGS', {'timeout': 42}):
        play_context_0.set_attributes_from_cli()
        assert play_context_0.timeout == 42


# Generated at 2022-06-25 05:40:47.789003
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context_0 = PlayContext(connection_lockfd=3)
    assert play_context_0.connection_lockfd == 3
    play_context_1 = PlayContext(connection_lockfd=3)
    assert play_context_1.connection_lockfd == 3


# Generated at 2022-06-25 05:40:53.194088
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_1 = PlayContext()
    task_0 = {}
    variables_0 = {}
    templar_0 = {}
    new_info_0 = play_context_1.set_task_and_variable_override(task_0, variables_0, templar_0)


# Generated at 2022-06-25 05:40:57.765400
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plugin = 'cloudformation'
    options = C.config.get_configuration_definitions(get_plugin_class(plugin), plugin._load_name)
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin(plugin)
    play_context_0.set_attributes_from_play()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:41:00.605591
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = MockTask()
    variables_0 = dict()
    templar_0 = MockTemplar()
    new_info_0 = play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)


# Generated at 2022-06-25 05:43:27.740326
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Values of variables that will be passed to the constructor of the
    # class under test
    play_0 = None
    passwords_0 = None
    connection_lockfd_0 = None

    # Instantiation of the class under test
    play_context_0 = PlayContext(play_0, passwords_0, connection_lockfd_0)

    # Testing if the instance can be pickled
    try:
        pickled = pickle.dumps(play_context_0)
    except:
        print('\nWhat: Could not pickle the instance', file=sys.stderr)
        sys.exit(1)

    # Testing if the instance can be unpickled

# Generated at 2022-06-25 05:43:29.320417
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()

    play_context_0.set_attributes_from_plugin({"status": "active"})
    assert True


# Generated at 2022-06-25 05:43:38.466910
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-25 05:43:45.266735
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_1 = PlayContext()
    task_1 = Task()
    variables_1 = dict()
    templar_1 = Templar(loader=None)
    result_1 = play_context_1.set_task_and_variable_override(task=task_1, variables=variables_1, templar=templar_1)
    assert isinstance(result_1, PlayContext)


# Generated at 2022-06-25 05:43:53.861189
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    variables = {
        'ansible_local': 'local',
        'ansible_connection': 'local',

        'ansible_ssh_private_key_file': '/home/foo/.ssh/id_rsa',

        'ansible_ssh_host': '192.168.0.13',
        'ansible_ssh_port': 54321,
        'ansible_ssh_user': 'bob',
        'ansible_ssh_pass': 'notsecret',

        'ansible_ssh_common_args': '-o ProxyCommand="ssh -W %h:%p -q user@bastion "'
    }

    # Test case 1

# Generated at 2022-06-25 05:44:00.196387
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # This is a very complex method. We will replace it with a dummy variable.
    # This is not testing anything at all.
    # TODO: We need to figure out how to test that method.
    play_context_0 = PlayContext()
    parameter_1 = Dummy()
    play_context_0.set_attributes_from_plugin(parameter_1)


# Generated at 2022-06-25 05:44:08.579799
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.vars.manager import VariableManager 
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task 
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.init import Inventory
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    inventory = InventoryManager(loader=DataLoader(), sources=C.DEFAULT_HOST_LIST)
    ds = inventory._inventory.groups["win_ds"]
    vm = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-25 05:44:10.322773
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin = None
    play_context_0.set_attributes_from_plugin(plugin)


# Generated at 2022-06-25 05:44:14.881110
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    display.verbosity = 2

    # test object creation
    test_object_0 = PlayContext()

    # test attributes
    task_0 = Task()
    variables_0 = {}
    templar_0 = Templar(loader=None)

    test_object_0.set_task_and_variable_override(task_0, variables_0, templar_0)

    # test assertions


# Generated at 2022-06-25 05:44:20.946841
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin_0 = MagicMock()
    plugin_1 = MagicMock()

    plugin_0.get_option.return_value = 'None'
    plugin_1.get_option.return_value = 'None'

    play_context_0.set_attributes_from_plugin(plugin_0)
    play_context_0.set_attributes_from_plugin(plugin_1)

