

# Generated at 2022-06-25 05:35:00.741687
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # test0 - test reference
    play_context_0 = PlayContext()
    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)

    # test1 - test task_0.remote_user = 'mary'
    play_context_1 = PlayContext()
    play_context_1.set_task_and_variable_override(task_1, variables_0, templar_0)

    # test2 - test task_0.delegate_to = 'mary'
    play_context_2 = PlayContext()
    play_context_2.set_task_and_variable_override(task_2, variables_0, templar_0)

    # test3 - test task_0.delegate_to = '{{jane}}'


# Generated at 2022-06-25 05:35:05.288575
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()

    # Check expected behavior:
    result = play_context_0.set_attributes_from_plugin(play_context_0)
    assert result is None


# Generated at 2022-06-25 05:35:16.524531
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    #check for valid connection plugin

    def get_plugin_instance(self, name):
        if name == 'local':
            return C.plugins.connection.LocalConnection(CliAPScheduler([], []), 'local')
        raise AnsibleError("the requested plugin was not found")
    dummy_plugins = mock.Mock()
    dummy_plugins.connection = mock.Mock()
    dummy_plugins.connection.get_plugin_instance = mock.Mock(wraps=get_plugin_instance)

    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin('local')

    #check for invalid connection plugin
    def get_plugin_instance(self, name):
        raise AnsibleError("the requested plugin was not found")
    dummy_plugins = mock.Mock()
    dummy_plugins

# Generated at 2022-06-25 05:35:22.470587
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()

    # Create an instance for class ConnectionPlugin
    plugin = ConnectionPlugin()
    options = { "ansible_user": {
                    "name": "remote_user",
                    "default": "root",
                    "env": ["ANSIBLE_REMOTE_USER"],
                    "ini": ["remote_user"]
                }
            }
    plugin._options = ImmutableDict(options)
    plugin.get_option = lambda x: getattr(plugin, x)
    plugin.remote_user = "test_remote_user"
    plugin._load_name = "connection"

    # call the method under test
    play_context.set_attributes_from_plugin(plugin)

    # check if the method sets the remote_user correctly
    assert play_context.remote_user == "test_remote_user"



# Generated at 2022-06-25 05:35:34.052592
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Exercise 1: without setting a task, and without defaults
    play_context = PlayContext()
    variables = dict()

    play_context_new, variables_new = play_context.set_task_and_variable_override(None, variables, None)

    assert not play_context_new.no_log

    # Exercise 2: without setting a task, and with defaults
    play_context = PlayContext()
    variables = dict()
    play_context.no_log = True

    play_context_new, variables_new = play_context.set_task_and_variable_override(None, variables, None)

    assert play_context_new.no_log

    # Exercise 3: with a task, and with defaults
    play_context = PlayContext()
    variables = dict()
    play_context.no_log = True



# Generated at 2022-06-25 05:35:43.309776
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # Mock stuff
    mock_task = Mock()
    mock_task.serialize = lambda: ""

    # Mock variables

# Generated at 2022-06-25 05:35:54.011019
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    #
    # Unit test for method set_attributes_from_plugin of class PlayContext
    fs = Filesystem()
    os.mkdir('/home/test_PlayContext_set_attributes_from_plugin')
    os.mkdir('/home/test_PlayContext_set_attributes_from_plugin/ansible')
    os.mkdir('/home/test_PlayContext_set_attributes_from_plugin/ansible/plugins')
    os.mkdir('/home/test_PlayContext_set_attributes_from_plugin/ansible/plugins/connection')
    os.mkdir('/home/test_PlayContext_set_attributes_from_plugin/ansible/plugins/connection/ssh')


# Generated at 2022-06-25 05:36:03.733412
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Create an instance of class PlayContext
    play_context_0 = PlayContext()
    assert isinstance(play_context_0, PlayContext)

    # Create an instance of class User
    user_0 = User()
    assert isinstance(user_0, User)

    # Assign the value 'local' to attribute `connection` of user_0
    user_0.connection = 'local'

    # Assign the value None to attribute `port` of user_0
    user_0.port = None

    # Assign the value None to attribute `timeout` of user_0
    user_0.timeout = None

    # Assign the value None to attribute `remote_user` of user_0
    user_0.remote_user = None

    # Create an instance of class User
    user_1 = User()

# Generated at 2022-06-25 05:36:12.887829
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Create an empty play_context
    play_context = PlayContext()
    # Create an empty variable_manager
    variable_manager = VariableManager()
    variable_manager._extra_vars = {}
    variable_manager._options_vars = {}
    variable_manager._internal_cache = {}

    # Create a task
    task = Task()
    # Set task_vars to empty dict
    task.vars = dict()

    # Set task.delegate_to to None
    task.delegate_to = None

    # Call set_task_and_variable_override with play_context, task, variable_manager and variables
    # Since task.delegate_to is None, no variable is retrieved from variable_manager

# Generated at 2022-06-25 05:36:20.101654
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # construct some plugin to be passed to PlayContext
    plugin = ConnectionBase()
    plugin.set_options(dict(
        network_os='junos',
        host='127.0.0.1',
        port=22,
        username='joe',
        password='pass',
        private_key_file='/etc/ansible/key',
        verbosity=1,
    ))

    # construct PlayContext object
    play_context = PlayContext()
    play_context.set_attributes_from_plugin(plugin)

    # test attributes from plugin
    assert_true(hasattr(play_context, 'network_os'))
    assert_true(hasattr(play_context, 'host'))
    assert_true(hasattr(play_context, 'port'))

# Generated at 2022-06-25 05:36:47.670775
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # fixture
    play_context_0 = PlayContext()

    # assertions
    def assert_connection_method():
        return play_context_0.connection_method()

    def assert_connection_method_with_value(value):
        return play_context_0.connection_method(value)

    def assert_connection_method_with_kwargs(**kwargs):
        return play_context_0.connection_method(**kwargs)

    assert play_context_0.connection is None
    assert play_context_0.remote_addr is None
    assert play_context_0.remote_user is None
    assert play_context_0.port is None
    assert play_context_0.remote_pass is None
    assert play_context_0.password is None
    assert play_context_0.private_key_file is None

# Generated at 2022-06-25 05:37:00.180234
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    def test_case_1():
        ''' PlayContext.set_task_and_variable_override(task, variables) should set the attributes as per
        the task variables. '''
        play_context_1 = PlayContext()
        task_1 = Task()
        task_1.vars = {'ansible_user': 'ec2-user', 'ansible_port': '22', 'ansible_become_user': 'root',
                       'ansible_become_method': 'sudo', 'ansible_become_pass': 'pass'}
        variables_1 = variables.VariableManager()
        templar_1 = Templar(loader=None, variables=variables_1)

# Generated at 2022-06-25 05:37:05.596291
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Make a new PlayContext instance
    play_context = PlayContext()

    # Make a shell plugin instance
    shell_plugin_instance = ShellModule()

    # Call the method
    play_context.set_attributes_from_plugin(shell_plugin_instance)


# Generated at 2022-06-25 05:37:12.036147
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin("ec2")
    play_context_0.set_attributes_from_plugin("libvirt_lxc")
    play_context_0.set_attributes_from_plugin("libvirt_lxc")
    play_context_0.set_attributes_from_plugin("docker")
    play_context_0.set_attributes_from_plugin("lxc")
    play_context_0.set_attributes_from_plugin("omd")



# Generated at 2022-06-25 05:37:13.754694
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pass


if __name__ == '__main__':

    test_case_0()
    test_PlayContext_set_task_and_variable_override()

# Generated at 2022-06-25 05:37:19.582950
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # test_case_0
    play_context_0 = PlayContext()
    task_0 = Task()
    templar_0 = Templar(loader=FileLoader())
    variables_0 = {}
    play_context_1 = play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)

# Generated at 2022-06-25 05:37:22.937092
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    set_attributes_from_plugin_0 = play_context_0.set_attributes_from_plugin('get_option')


# Generated at 2022-06-25 05:37:31.145234
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    logging.info("Testing PlayContext.set_attributes_from_plugin")

    class C(object):
        def __init__(self):
            self.options = dict()

    c = C()

    class P(object):

        def __init__(self):
            self._load_name = "name"
            self.options = dict()

    class P2(P):

        def __init__(self):
            super(P2, self).__init__()
            self.get_option = get_option

        def get_option(self, option):
            return self.options[option]

    class M(object):
        @staticmethod
        def register_plugin(plugin_name, api_version, cls):
            c.cls = cls

    p2 = P2()


# Generated at 2022-06-25 05:37:31.752489
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pass


# Generated at 2022-06-25 05:37:41.943286
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    class Play:
        def __init__(self):
            self.force_handlers = True
            self.remote_user = 'ec2-user'

    play_context=PlayContext(play=Play())
    play_context.set_attributes_from_cli()

    class Task:
        def __init__(self):
            self.any_errors_fatal = True
            self.connection = 'smart'
            self.delegate_to = 'cch_test_case'
            self.no_log = False
            self.remote_user = 'test_user'

    class Variables:
        def __init__(self):
            self.ansible_user = 'ec2-user'
            self.ansible_become = True
            self.ansible_become_pass = '1234567'

   

# Generated at 2022-06-25 05:37:56.642386
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context = PlayContext()


# Generated at 2022-06-25 05:38:00.618708
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    paramiko = None
    play_context_0.set_attributes_from_plugin(paramiko)


# Generated at 2022-06-25 05:38:03.170316
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Create a test PlayContext object
    play_context_0 = PlayContext()
    # Create a test plugin object and call the set_attributes_from_plugin method
    plugin_0 = PluginLoader('action', 'ping', None, 'ping', None)
    play_context_0.set_attributes_from_plugin(plugin_0)


# Generated at 2022-06-25 05:38:14.750933
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    PASSWORD_NAME_LIST = ['become_password', 'become_pass', 'ansible_become_pass']

    def dict_contains_keys(attr_dict, key_list):
        for key in key_list:
            if key not in attr_dict:
                return False
        return True

    play = Play()

    # Case 1: test whether the task step will override the play step
    pc = PlayContext()
    play.vars = {'ansible_connection': 'local'}
    task_host = 'host1'
    task = Task(hosts=task_host, connection='ssh', delegate_to='delegate_host')
    task.vars = {'ansible_connection': 'ssh'}

    templar = Templar(variables=play.vars)

# Generated at 2022-06-25 05:38:20.096618
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin = BaseConnection()
    play_context_0.set_attributes_from_plugin(plugin)
    debug('type(play_context_0) is %s' % type(play_context_0))
    debug('play_context_0._attributes is %s' % play_context_0._attributes)


# Generated at 2022-06-25 05:38:23.312111
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    play_context_0 = PlayContext()
    variables_0 = {}
    play_context_0.update_vars(variables_0)

    # play_context_1 test
    play_context_1 = PlayContext()
    variables_0 = {}
    play_context_1.update_vars(variables_0)

# Generated at 2022-06-25 05:38:35.107670
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    class TestPlayContext(object):
        _become_plugin = None
        _prompt = ''
        _success_key = ''
        _connection_lockfd = None
        force_handlers = False

    class TestTask(object):
        name = 'mock_task'
        delegate_to = None
        check_mode = None
        remote_user = 'mock_user'
        diff = None
        action = 'setup'
        connection = None
        no_log = None
        lusr = None

    # create mock variabels
    variables = dict()
    variables.update({'ansible_connection': 'smart'})
    variables.update({'ansible_ssh_port': '80'})
    variables.update({'ansible_ssh_host': 'localhost'})

# Generated at 2022-06-25 05:38:37.642522
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plugin = 'local'
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin(plugin)


# Generated at 2022-06-25 05:38:48.622207
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    hostvars = {"ansible_ssh_pass": "pass", "ansible_ssh_port": "port", "ansible_ssh_user": "user"}

    # Test for override for delegate_to
    pc1 = PlayContext(dict(remote_user="remote_user2", connection="connection2"))
    task1 = Task(dict(delegate_to="delegate_to_host"))
    pc2 = pc1.set_task_and_variable_override(task1, hostvars, Templar())
    assert pc2.remote_user == "remote_user2"
    assert pc2.connection == "connection2"

    # Test for not override for delegate_to
    pc1 = PlayContext(dict(remote_user="remote_user2", connection="connection2"))

# Generated at 2022-06-25 05:38:52.172278
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    assert play_context_0 != None


# Generated at 2022-06-25 05:39:47.303178
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = dict()
    templar_0 = Templar(loader=None, variables=None)
    play_context_0.set_task_and_variable_override(task=task_0, variables=variables_0, templar=templar_0)



# Generated at 2022-06-25 05:39:58.420154
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    play_context_orig = PlayContext()

    # Set up mock object for the task object.
    task_mock = MagicMock()
    task_mock.delegate_to = 'delegated_host'
    task_mock.remote_user = 'local_user'

    # Set up mock object for the variables object.

# Generated at 2022-06-25 05:40:05.540623
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    '''test_PlayContext_set_task_and_variable_override'''
    unittest.TestCase.maxDiff = None

    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = dict()
    templar_0 = Templar(loader=None)

    # Test with task={"delegate_to": None}
    # Test with variables={'ansible_ssh_user': 'test_value_1'}
    # Test with variables={'ansible_winrm_user': 'test_value_2'}
    # Test with variables={'ansible_connection': 'test_value_3'}
    # Test with variables={'ansible_remote_user': 'test_value_4'}
    # Test with variables={'ansible_user': 'test_value_5

# Generated at 2022-06-25 05:40:08.063283
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plugin = object
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin(plugin)


# Generated at 2022-06-25 05:40:13.939254
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = {}
    templar_0 = Templar(loader=None, variables=None)

    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)


# Generated at 2022-06-25 05:40:15.841782
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin_0 = plugin_loader.find_plugin('/etc/ansible/plugins/connection', 'netconf')
    play_context_0.set_attributes_from_plugin(plugin_0)


# Generated at 2022-06-25 05:40:21.195096
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context = PlayContext()
    assert(not play_context.become_user)
    assert(not play_context.check_mode)
    assert(not play_context.connection)
    assert(not play_context.diff)
    assert(not play_context.executable)
    assert(not play_context.force_handlers)
    assert(not play_context.no_log)
    assert(not play_context.network_os)
    assert(play_context.password == '')
    assert(not play_context.prompt)
    assert(not play_context.remote_addr)
    assert(not play_context.remote_user)
    assert(not play_context.success_key)
    assert(play_context.timeout == C.DEFAULT_TIMEOUT)

# Generated at 2022-06-25 05:40:23.494415
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_1 = PlayContext()
    play_context_1.set_attributes_from_plugin(dict)


# Generated at 2022-06-25 05:40:35.815517
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Test PlayContext set_attributes_from_plugin() with no parameters
    # verify play_context_0.expect_passwords = None
    # verify play_context_0.new_stdin = None
    play_context_0 = PlayContext()
    plugin_0 = plugin_loader.find_plugin(None, 'ConnectionBase')
    play_context_0.set_attributes_from_plugin(plugin_0)
    expected = None
    actual = play_context_0.expect_passwords
    assert actual == expected, 'Test Failed for PlayContext set_attributes_from_plugin(): Expected: {}, Actual: {}'.format(expected, actual)
    expected = None
    actual = play_context_0.new_stdin

# Generated at 2022-06-25 05:40:38.989097
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Create a new PlayContext object
    play_context_obj = PlayContext()

    play_context_obj.set_attributes_from_cli()



# Generated at 2022-06-25 05:41:48.411279
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext(None)  # play=None, passwords=None, connection_lockfd=None)
    plugin = connection_loader.get('local')
    play_context_0.set_attributes_from_plugin(plugin)


# Generated at 2022-06-25 05:41:58.398347
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = Task()
    task_0.become = 'yes'
    task_0.delegate_to = '127.0.0.1'
    task_0.check_mode = 'no'
    task_0.diff = 'yes'
    task_0.remote_user = 'tom'
    variables_0 = {}
    variables_0['ansible_connection'] = 'smart'
    variables_0['ansible_python_interpreter'] = '/usr/bin/python'
    templar_0 = Templar(loader=None)
    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)
    assert play_context_0.become == 'yes'
    assert play_

# Generated at 2022-06-25 05:42:07.618745
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Test the modules but not the network modules which need more work
    for plugin_type in ('connection', 'become'):
        for plugin_name in os.listdir(os.path.join(C.DEFAULT_MODULE_PATH, plugin_type)):
            if plugin_name in C.IGNORE_FILES:
                continue
            try:
                if plugin_type == 'connection':
                    plugin_class = connection_loader.get(plugin_name, class_only=True)
                else:
                    plugin_class = become_loader.get(plugin_name, class_only=True)
            except AttributeError:
                # if the module is bad, we don't care except to state that the test failed
                assert False, "Plugin %s failed to load" % plugin_name
                continue

# Generated at 2022-06-25 05:42:10.967689
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin_0 = C.config.get_plugin_class('action')

    play_context_0.set_attributes_from_plugin(plugin_0)

# test case for class PlayContext.get_start_at_task

# Generated at 2022-06-25 05:42:18.124593
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    task = Task(name='test_task', action='test_action')
    variables = {}
    templar = Templar()
    play_context = PlayContext()

    new_play_context = play_context.set_task_and_variable_override(task=task, variables=variables, templar=templar)

    assert new_play_context.connection == 'ssh'
    assert new_play_context.connection_user == ''
    assert new_play_context.no_log == False
    assert new_play_context.network_os == ''
    assert new_play_context.remote_addr == ''
    assert new_play_context.remote_user == ''
    assert new_play_context.password == ''
    assert new_play_context.port == None
    assert new_play_context.private_key

# Generated at 2022-06-25 05:42:26.999590
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    hostname_0 = "localhost"
    port_0 = 22
    username_0 = "root"
    password_0 = "ansible"
    connection_0 = "ssh"
    timeout_0 = 10
    remote_user_0 = "root"
    inventory_hostname_0 = "localhost"
    ansible_ssh_host_0 = "localhost"
    ansible_ssh_port_0 = 22
    ansible_ssh_user_0 = "root"
    ansible_ssh_pass_0 = "ansible"
    ansible_verbosity_0 = 3
    ansible_private_key_file_0 = "/root/.ssh/id_rsa"
    ansible_become_pass_0 = "ansible"
    ansible_connection_0 = "ssh"

    # create task 0
   

# Generated at 2022-06-25 05:42:38.671968
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    print('Test case PlayContext set_task_and_variable_override ...')

    # Instantiate task
    task = Task()
    task.connection = 'smart'
    task.port = 22
    task.remote_user = 'test_user'
    task.delegate_to = 'test_delegate'
    vars = {'ansible_ssh_host': 'test_host', 'ansible_ssh_port': 'test_port', 'ansible_ssh_user': 'test_ssh_user'}
    templar = Templar(loader=None, variables=vars)

    # Instantiate PlayContext
    play_context = PlayContext()
    play_context.copy = MagicMock()
    play_context.copy.return_value = play_context
    play_context.DEBUG = False
    play_context.set

# Generated at 2022-06-25 05:42:46.108339
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """
    Check if set_attributes_from_plugin works.
    """

    # Check that setting a ssh plugin works
    play_context_0 = PlayContext()
    ssh = Connection(shared_loader_obj, 'ssh')

    play_context_0.set_attributes_from_plugin(ssh)

    assert play_context_0._attributes['private_key_file'] == C.DEFAULT_PRIVATE_KEY_FILE
    assert play_context_0._attributes['verbosity'] == 0


# Generated at 2022-06-25 05:42:54.337784
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    hostvars = {'host1': {'host_var': 'host_var_value'},
                'host2': {'host_var': 'host_var_value'}}
    task_vars = {'task_var': 'task_var_value'}
    templar = Templar(loader=DictDataLoader({}), variables=task_vars)

    # Test 1:
    # Test that if the task has a 'connection' attribute set to ssh, then
    # the play_context.connection value is set to ssh
    task = Task()
    task._attributes['connection'] = 'ssh'
    play_context_0 = PlayContext()
    play_context_1 = play_context_0.set_task_and_variable_override(task, hostvars, templar)

# Generated at 2022-06-25 05:42:59.082097
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Create a new instance of PlayContext
    play_context_0 = PlayContext()

    # Get a BaseConnection plugin for system 'local'
    base_connection_0 = get_plugin_class('local', 'connection')(play_context_0)

    # Invoke method set_attributes_from_plugin of PlayContext instance with param plugin=base_connection_0
    play_context_0.set_attributes_from_plugin(base_connection_0)

    pass
