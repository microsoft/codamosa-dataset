

# Generated at 2022-06-25 05:35:03.529565
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plugin_name = 'git'
    plugin_class = get_plugin_class(plugin_name)
    plugins = plugin_class._load_name

    options = C.config.get_configuration_definitions(plugin_class, plugins)
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin(plugin_class(play_context_0, ansible.constants.DEFAULT_LOAD_CALLBACK_PLUGIN, options))


# Generated at 2022-06-25 05:35:09.562915
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plugin_name = 'TestPlugin'
    test_file_path = get_data_path()
    sys.path.insert(0, test_file_path)
    test_plugin = __import__(plugin_name)
    play_context = PlayContext()
    play_context.set_attributes_from_plugin(test_plugin)
    assert play_context.options == 'TestOptions'


# Generated at 2022-06-25 05:35:21.605789
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_1 = PlayContext()
    play_context_1.deprecate('test_play_context_1')

    task_1 = Task()
    task_1.deprecate('test_task_1')

    variables_1 = dict()
    variables_1['ansible_user'] = None
    variables_1['ansible_port'] = None
    variables_1['ansible_connection'] = None
    variables_1['ansible_ssh_private_key_file'] = None

    task_1.remote_user = 'test_remote_user'
    task_1.port = 5555

    play_context_1.set_task_and_variable_override(task_1, variables_1, Templar())
    play_context_1_dict = play_context_1.serialize()

    play

# Generated at 2022-06-25 05:35:26.948806
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Test execution of method set_task_and_variable_override of class PlayContext
    play_context = PlayContext()
    task = Task()
    variables = dict()
    templar = Templar()

    play_context.set_task_and_variable_override(task, variables, templar)


# Generated at 2022-06-25 05:35:33.532796
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # Setting up play_context object
    play_context = PlayContext()

    # Setting up task object
    task = Task()

    # Setting up variables dictionary object
    variables = dict()
    variables['ansible_delegated_vars'] = dict()

    # Setting up templar object
    templar = Templar()

    play_context.set_task_and_variable_override(task, variables, templar)

# Generated at 2022-06-25 05:35:43.288103
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    hostvars = dict()
    hostvars['ansible_connection'] = 'winrm'
    hostvars['ansible_winrm_server_cert_validation'] = 'ignore'
    hostvars['ansible_user'] = 'vagrant'
    hostvars['ansible_password'] = 'vagrant'
    hostvars['ansible_port'] = 5986
    hostvars['ansible_winrm_transport'] = ['plaintext', 'kerberos']

    task_dict = dict()
    task_dict['remote_user'] = 'vagrant'
    task_dict['connection'] = 'winrm'
    task_dict['delegate_to'] = '127.0.0.1'
    task_dict['delegate_facts'] = False
    task_dict['register'] = 'foo'

# Generated at 2022-06-25 05:35:45.828947
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    expected_results_0 = {}

    _ = PlayContext()
    _.set_attributes_from_plugin(test_case_0)
    assert _ == expected_results_0






# Generated at 2022-06-25 05:35:54.982758
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Create a mock object for the class AnsibleCLI
    mock_ansible_cli = create_autospec(context.CLIARGS).return_value
    mock_ansible_cli.timeout = None
    mock_ansible_cli.verbosity = None

    play_context_obj = PlayContext()
    play_context_obj.set_attributes_from_cli()

    assert(play_context_obj.timeout == C.DEFAULT_TIMEOUT)
    assert(play_context_obj.verbosity == 0)


# Generated at 2022-06-25 05:36:07.529272
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Setup
    play_context = PlayContext()
    task = Task()
    task.set_loader(TestMock())
    task.action = "shell"
    task.args = dict(chdir="/tmp")
    task.sudo = True
    task.sudo_user = "bob"
    task.environment = dict(ANSIBLE_MODULE_ARGS=dict(shell="/bin/sh", chdir="/tmp"))
    task.delegate_to = "localhost"
    task.only_if = "ansible --version"
    task.not_if = "false"
    task.poll = 10
    task.remote_user = None
    task.transport = "paramiko"
    task.no_log = False
    task.run_once = True
    task.become = True
    task.become_user

# Generated at 2022-06-25 05:36:16.230542
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    play_context.prompt = ''
    play_context.success_key = ''
    play_context.connection_lockfd = None
    play_context.remote_addr = "127.0.0.1"
    play_context.port = 22
    play_context.remote_user = "ansible"
    play_context.password = ""
    play_context.private_key_file = "/home/ansible/.ssh/id_rsa"
    play_context.executable = "/bin/bash"
    play_context.timeout = 10
    play_context.connection = "ssh"
    play_context.accelerate_port = None
    play_context.accelerate_timeout = 30
    play_context.accelerate_connect_timeout = None
    play_context.no

# Generated at 2022-06-25 05:36:37.042987
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    context.CLIARGS = {'timeout': 5}
    ssh_plugin = C.config.get_plugin_loader('connection').get('ssh')
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin(ssh_plugin)
    assert play_context_0.timeout == 5
    assert isinstance(play_context_0.timeout, int)


# Generated at 2022-06-25 05:36:39.168051
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    ctx = dict()

    PlayContext._set_attributes_from_plugin(ctx, plugin='some_plugin')


# Generated at 2022-06-25 05:36:42.425020
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    display.display("TESTING: set_attributes_from_plugin()")

    play_context_0 = PlayContext()
    # test case where args is empty
    plugin_0 = 'plugin'
    play_context_0.set_attributes_from_plugin(plugin_0)


# Generated at 2022-06-25 05:36:46.823175
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()


# Generated at 2022-06-25 05:36:48.388866
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    test_case_0()


# Generated at 2022-06-25 05:36:53.377444
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    dbg = """
    This test is not done
    It depends on remote_user and remote_password,
    which are not set when executing tests.
    """
    display.display(dbg)
    return True


# Generated at 2022-06-25 05:36:56.012530
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Initialize:
    play_context = PlayContext()
    plugin = None
    play_context.set_attributes_from_plugin(plugin=plugin)


# Generated at 2022-06-25 05:37:07.079202
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()

    # Set test values for attributes "become_plugin"

    # Set test values for attributes "become"

    # Set test values for attributes "connection"

    # Set test values for attributes "remote_user"

    # Set test values for attributes "accelerate_port"

    # Set test values for attributes "timeout"

    # Set test values for attributes "no_log"

    # Set test values for attributes "network_os"

    # Set test values for attributes "port"

    # Set test values for attributes "remote_addr"

    # Set test values for attributes "remote_pass"

    # Set test values for attributes "check"

    # Set test values for attributes "private_key_file"

    # Set test values for attributes "remote_tmp"

    # Set test values for attributes "acceler

# Generated at 2022-06-25 05:37:15.924064
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    global test_play_context_instance
    orig_play_context_instance = test_play_context_instance.copy()

    yaml_output = """
    - hosts: localhost
      remote_user: root
      gather_facts: false
      tasks:
      - name: test play context
        debug:
          var: ansible_connection
        connection: docker
    """
    play = Play().load(yaml_output, variable_manager=VariableManager(), loader=DataLoader())

    # template task.delegate_to for test

# Generated at 2022-06-25 05:37:20.958270
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_1 = PlayContext()

    test_plugin_0 = ConnectionBase()
    play_context_1.set_attributes_from_plugin(test_plugin_0)

    test_plugin_1 = None
    play_context_1.set_attributes_from_plugin(test_plugin_1)


# Generated at 2022-06-25 05:37:38.701875
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin(None)


# Generated at 2022-06-25 05:37:46.312444
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Create a test PlayContext object
    play_context_0 = PlayContext()
    # Create a temporary test CLIARGS varible
    test_cliargs_0 = {}
    setattr(context, 'CLIARGS', test_cliargs_0)
    # Set a test timeout value for the test CLIARGS variable
    test_timeout_0 = C.DEFAULT_TIMEOUT
    setattr(test_cliargs_0, 'timeout', test_timeout_0)
    # Set a test private key file for the test CLIARGS variable
    test_private_key_file_0 = C.DEFAULT_PRIVATE_KEY_FILE
    setattr(test_cliargs_0, 'private_key_file', test_private_key_file_0)
    # Set a test verbosity value for the test CLIARGS variable
   

# Generated at 2022-06-25 05:37:54.133421
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # Create a play, task and variable instance
    test_play = Play.load(dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        ), variable_manager=None, loader=None)

    test_task = test_play.tasks[0]
    test_variables = dict(
        ansible_connection = 'local',
        ansible_ssh_user = 'user',
        ansible_ssh_pass = 'pass',
        ansible_sudo_pass = 'pass'
    )

    # Create

# Generated at 2022-06-25 05:38:00.944927
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    """
        Test if PlayContext() class sets attributes from command line correctly
    """
    context.CLIARGS = {
        "timeout": 1,
        "private_key_file": "key_file",
        "verbosity": 1
    }
    play_context_0 = PlayContext()
    assert play_context_0.timeout == 1
    assert play_context_0.private_key_file == "key_file"
    assert play_context_0.verbosity == 1


# Generated at 2022-06-25 05:38:12.572569
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Instantiate an instance of PlayContext
    play_context_0 = PlayContext()

    # Setting the following attributes of PlayContext
    play_context_0.become = False
    play_context_0.become_method = 'sudo'
    play_context_0.become_user = 'root'
    play_context_0.connection = 'ssh'
    play_context_0.user = 'ansible'
    play_context_0.port = 22
    play_context_0.remote_addr = '192.168.0.1'
    play_context_0.remote_user = 'ansible'
    play_context_0.timeout = 10

    # Calling the method

# Generated at 2022-06-25 05:38:18.504793
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    play_context_1 = play_context_0.set_task_and_variable_override(Task(), dict(), Templar())

test_PlayContext_set_task_and_variable_override()

# Generated at 2022-06-25 05:38:23.373247
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = dict()
    templar_0 = Templar(variables=variables_0)
    assert play_context_0.set_task_and_variable_override(task=task_0,
                                                         variables=variables_0,
                                                         templar=templar_0)

if __name__ == "__main__":
    test_PlayContext_set_task_and_variable_override()

# Generated at 2022-06-25 05:38:35.340452
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Test-0: No cli options passed

    # Test-1: timeout cli option passed
    try:
        with patch.dict(context.CLIARGS, {'timeout': '60'}):
            play_context_1 = PlayContext()
            assert play_context_1.timeout == 60
    except:
        assert False
    # Test-2: verbosity cli option passed
    try:
        with patch.dict(context.CLIARGS, {'verbosity': '3'}):
            play_context_2 = PlayContext()
            assert play_context_2.verbosity == 3
    except:
        assert False
    # Test-3: no verbosity option passed

# Generated at 2022-06-25 05:38:43.501799
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    ##
    # Dicks in the playbook

    # create a fake task
    task = Task()
    task.become = False
    task.become_user = 'root'
    task.delegate_to = 'localhost'
    task.remote_user = 'dick'
    task.no_log = False
    task.check_mode = False
    task.diff = True

    # Create a fake variables
    variables = dict()
    variables['ansible_become_user'] = 'special_user'
    variables['ansible_become'] = True
    variables['ansible_become_method'] = 'su'
    variables['ansible_become_pass'] = '123'
    variables['ansible_ssh_user'] = 'special_ssh_user'

# Generated at 2022-06-25 05:38:48.883283
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # Case 1: PlayContext is created without passing a task or variables arguments.
    play_context_1 = PlayContext(play=Play())
    play_context_1.set_attributes_from_cli()
    play_context_1.set_attributes_from_play(Play())
    play_context_1.set_task_and_variable_override(task=Task(), variables=dict(), templar=None)

    # Case 2: PlayContext is created with task.delegate_to and task.remote_user.
    play_context_2 = PlayContext(play=Play())
    play_context_2.set_attributes_from_cli()
    play_context_2.set_attributes_from_play(Play())

# Generated at 2022-06-25 05:39:10.914044
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Test: Load module, set attributes
    play_context_1 = PlayContext()
    module_name_0 = 'service'
    module_class_0 = get_plugin_class(module_name_0)
    load_name_0 = 'service_linux'
    plugin_0 = module_class_0(load_name_0)
    play_context_1.set_attributes_from_plugin(plugin_0)
    # Test: Ensure no host or play is set
    assert play_context_1.host == ''
    assert play_context_1.play == ''


# Generated at 2022-06-25 05:39:23.050084
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    t = Task()
    t.role = 'crawler'
    t.handler = True
    t.loop_control = 'loop_control'
    t.no_log = False
    t.delegate_to = '127.0.0.1'
    variables = {'ansible_python_interpreter': '/usr/bin/python', 'ansible_connection': 'winrm', 'ansible_port': 5986,
                 'ansible_host': '127.0.0.1'}
    templar = Templar()
    templar.init_templar()

    assert(isinstance(play_context_0.set_task_and_variable_override(t, variables, templar), object))


# Testing attribute connection of class PlayContext

# Generated at 2022-06-25 05:39:30.607249
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # TYPE: class PlayContext, class Play, class Task
    play_context_0 = PlayContext()
    play_0 = Play()
    task_0 = Task()

    # TYPE: dict
    variables = dict()
    templar = Templar()


    # TEST: Set attributes for task
    for attr in TASK_ATTRIBUTE_OVERRIDES:
        setattr(task_0, attr, "somevalue")

    # TEST: Set attribute for delegation to
    task_0.delegate_to = "idleloop"

    # TEST: Set attributes for ansible magic variables
    variable_names = ["ansible_ssh_user", "ansible_user"]
    for variable_name in variable_names:
        variables[variable_name] = 'rbarrios'


    new_info = play_context

# Generated at 2022-06-25 05:39:35.628453
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_1 = PlayContext()
    assert play_context_1.verbosity == 0
    assert play_context_1.timeout == C.DEFAULT_TIMEOUT
    context.CLIARGS = dict(verbosity=1, timeout=30)
    play_context_2 = PlayContext()
    assert play_context_2.verbosity == 1
    assert play_context_2.timeout == 30
    context.CLIARGS = dict()
    play_context_3 = PlayContext()
    assert play_context_3.verbosity == 0
    assert play_context_3.timeout == C.DEFAULT_TIMEOUT



# Generated at 2022-06-25 05:39:37.778471
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()
    play_context.set_attributes_from_plugin("shell")
    assert play_context.executable == '/bin/sh'
    play_context.set_attributes_from_plugin("raw")
    assert play_context.executable == '/bin/sh'

# Generated at 2022-06-25 05:39:41.697967
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    variables_0 = dict()
    task_0 = dict()


# Generated at 2022-06-25 05:39:49.430186
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()
    assert play_context_0.timeout == C.DEFAULT_TIMEOUT, 'setting attribute timeout on play_context_0 failed'
    assert play_context_0.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE, 'setting attribute private_key_file on play_context_0 failed'
    assert play_context_0.verbosity == 0, 'setting attribute verbosity on play_context_0 failed'
    assert play_context_0.start_at_task is None, 'setting attribute start_at_task on play_context_0 failed'


# Generated at 2022-06-25 05:39:53.940873
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    play_context = PlayContext()
    task = Task()
    task2 = Task()
    variables = dict()

    # Test case for method set_task_and_variable_override with args=
    # (task, variables, templar)
    # and testing task.delegate_to is not None
    play_context2 = play_context.set_task_and_variable_override(task, variables, templar())
    if play_context2.remote_user != play_context.remote_user:
        raise Exception
    if play_context2.connection == play_context.connection:
        raise Exception
    if play_context2.executable != play_context.executable:
        raise Exception

    # Test case for method set_task_and_variable_override with args=
    # (task, variables, templ

# Generated at 2022-06-25 05:40:02.715427
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-25 05:40:09.014493
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # set_task_and_variable_override is expecting the following parameters:
    #  task -- The task object with the parameters that were set on it
    #  variables -- Variables from inventory
    #  templar -- Templar instance if templating variables is needed
    templar_0 = Templar(loader=None, variables={})
    play_context_0 = PlayContext(play=None, passwords=None, connection_lockfd=None)
    task_mock = MagicMock()
    task_mock.__getitem__.return_value = "test"
    task_mock.delegate_to = None
    task_mock.remote_user = None
    play_context_0 = play_context_0.set_task_and_variable_override(task_mock, {}, templar_0)


# Generated at 2022-06-25 05:40:47.987695
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    yaml_data = """
        ---
        - hosts: localhost
          gather_facts: no
          tasks:
            - name: 1
              debug:
                 msg: "1"
            - name: 2
              debug:
                msg: "2"
              become: yes
              become_user: root
            - name: 3
              debug:
                msg: "3"
              become: yes
              become_user: my_user
            - name: 4
              debug:
                msg: "4"
              become: yes
              become_user: "{{ test_var }}"
            - name: 5
              debug:
                msg: "5"
              become: yes
              become_user: "{{ test_var | default(test_var_default) }}"

    """


# Generated at 2022-06-25 05:40:56.980097
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    context_0 = PlayContext()
    task_0 = Task()
    variables_0 = {}
    templar_0 = Templar()
    try:
        PlayContext.set_task_and_variable_override(context_0, task_0, variables_0, templar_0)
    except (IOError, OSError) as exception_0:
        # On Windows, IOError may be raised
        print(exception_0)
    except TypeError as exception_1:
        print(exception_1)

test_case_0()
test_PlayContext_set_task_and_variable_override()

# Generated at 2022-06-25 05:41:08.420874
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    task_0 = Task()
    variables_0 = dict()
    templar_0 = Templar()

    def mock_create_hostvars_dir(path):
        pass

    create_hostvars_dir_old = task_0.create_hostvars_dir
    task_0.create_hostvars_dir = mock_create_hostvars_dir

    play_context_0 = PlayContext()

    def mock_is_local(self, connection):
        return (True,)

    connection_is_local_old = PlayContext.is_local
    PlayContext.is_local = mock_is_local

    def mock_template_data(self, data, fail_on_undefined=True, override_vars=False):
        return ('a',)

    templar_template_data_old = templ

# Generated at 2022-06-25 05:41:09.983211
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # FIXME
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()


# Generated at 2022-06-25 05:41:15.114935
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    # Create arguments
    plugin_0 = None
    play_context_0.set_attributes_from_plugin(plugin_0)


# Generated at 2022-06-25 05:41:21.411637
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Temporary hack until DSL is implemented.
    # These tests should live within the main module test.yml
    import sys
    import json
    import copy
    from ansible.utils.display import Display
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultAES256
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.module_utils.common.removed import removed_module


# Generated at 2022-06-25 05:41:29.859771
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_1 = PlayContext()
    play_context_1.set_attributes_from_cli()
    assert play_context_1.timeout == 300
    assert play_context_1.verbosity == 0
    assert play_context_1.connection == 'smart'
    assert play_context_1.remote_addr == '172.17.0.2'
    assert play_context_1.remote_user == 'root'
    assert play_context_1.port == 22
    assert play_context_1.password == ''
    assert play_context_1.private_key_file == '~/.ssh/id_rsa'


# Generated at 2022-06-25 05:41:38.434212
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pc = PlayContext()
    task = dict(
        delegate_to = 'localhost',
        remote_user = 'local_user',
        connection  = 'paramiko',
        port        = 22,
        become      = True,
        become_user = 'local_user',
    )
    variables = dict(
        ansible_connection  = 'ssh',
        ansible_port        = 23,
        ansible_become      = True,
        ansible_become_user = 'remote_user',
    )
    templar = DictData()
    new_pc = pc.set_task_and_variable_override(task, variables, templar)
    assert(new_pc.delegate_to == 'localhost')
    assert(new_pc.remote_user == 'local_user')

# Generated at 2022-06-25 05:41:45.410775
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # hostvars
    variables = dict()

    templar = Templar(loader=DictDataLoader({}))

    # Create new PlayContext object
    play_context = PlayContext()

    task_0 = Task()
    task_0._variable_manager = VariableManager()
    task_0.connection = 'local'

    task_1 = Task()
    task_1._variable_manager = VariableManager()
    task_1.connection = 'network_cli'


    new_context = play_context.set_task_and_variable_override(task_0, variables, templar)
    assert new_context.connection == 'local', \
        'Failed to set connection to local'

    new_context = play_context.set_task_and_variable_override(task_1, variables, templar)


# Generated at 2022-06-25 05:41:53.289175
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # setup
    play_context = PlayContext()
    task = Mock()
    variables = Mock()

    # set defaults
    variables.get.return_value = None
    variables.get.return_value = None
    variables.get.return_value = None

    # step1:
    result = play_context.set_task_and_variable_override(task, variables, None)

    # assertions
    assert result.connection == ''
    assert result.remote_addr == ''
    assert result.remote_user == ''
    assert result.port == ''
    assert result.private_key_file == ''
    assert result.password == ''

# Generated at 2022-06-25 05:42:30.581140
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()

    # task is a Task() object
    task = Task()
    task.delegate_to = "foo"
    task.remote_user = 'bar'

    # templar is a Templar() object
    templar = Templar()

    # variables is a dict
    variables = {'ansible_delegated_vars': {'foo': {'ansible_host': 'foo'}}}

    play_context_0.set_task_and_variable_override(task, variables, templar)


# Generated at 2022-06-25 05:42:34.498233
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()
    var_connection_0 = play_context_0._attributes.get("connection")
    # validate if the instance attribute 'connection' is equal to the value of connection_0
    assert var_connection_0 == "smart"

# Generated at 2022-06-25 05:42:45.267818
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    # Mock Plugin class
    plugin_0 = Mock()
    plugin_1 = Mock()
    # Mock the plugin get_option method
    plugin_0.get_option.return_value = 'connectionType'
    plugin_1.get_option.return_value = 'connectionType'
    # Mock the config.get_configuration_definitions method

# Generated at 2022-06-25 05:42:50.210627
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_1 = PlayContext()
    play_context_1.set_task_and_variable_override(play_context_1, {'item': 'item0'}, 'templar')
    play_context_1.set_task_and_variable_override(play_context_1, {'item': 'item0'}, 'templar')


# Generated at 2022-06-25 05:42:59.294517
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    import os
    import pwd
    from ansible.utils.vault import VaultLib
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.network.base import NetworkCollector

    task_data = {
        'name': 'Task name',
        'remote_user': 'TestRemoteUser',
        'connection': 'local',
        'port': 5555,
        'timeout': 5,
        'check_mode': True,
        'delegate_to': 'TestDelegateTo'
    }


# Generated at 2022-06-25 05:43:06.551332
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # create PlayContext object
    play_context_obj = PlayContext()

    play_context_obj.become_method = 'su'
    play_context_obj.become_user = 'become_user'
    play_context_obj.become = True
    play_context_obj.connection = 'ssh'
    play_context_obj.force_handlers = True
    play_context_obj.inventory = 'inventory'
    play_context_obj.port = 22
    play_context_obj.remote_addr = '1.1.1.1'
    play_context_obj.remote_user = 'remote_user'
    play_context_obj.timeout = 10
    play_context_obj.verbosity = 4
    play_context_obj.hostname = 'hostname'

# Generated at 2022-06-25 05:43:16.945105
# Unit test for constructor of class PlayContext
def test_PlayContext():

    play_context_0 = PlayContext()
    assert play_context_0.verbosity == 0, "play_context_0.verbosity != 0"
    assert play_context_0.no_log == None, "play_context_0.no_log != None"
    assert play_context_0.network_os == None, "play_context_0.network_os != None"
    assert play_context_0.connection == None, "play_context_0.connection != None"
    assert play_context_0.timeout == 10, "play_context_0.timeout != 10"
    assert play_context_0.port == None, "play_context_0.port != None"
    assert play_context_0.remote_user == None, "play_context_0.remote_user != None"
    assert play_context_

# Generated at 2022-06-25 05:43:21.134123
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context = PlayContext()
    play_context.set_attributes_from_cli()


# Generated at 2022-06-25 05:43:25.593811
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    def test_set_attribute_from_plugin_base():
        play_context_1 = PlayContext()
        play_context_1._set_attributes_from_plugin(["connection", "ssh"])
        assert_equal(play_context_1.connection, "ssh")

    def test_set_attribute_from_plugin_not_base():
        play_context_2 = PlayContext()
        play_context_2._set_attributes_from_plugin(["network_os", "junos"])
        assert_equal(play_context_2.network_os, "junos")


# Generated at 2022-06-25 05:43:29.108346
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # create a PlayContext object
    play_context_0 = PlayContext()
    # set a value for cliarg timeout
    context.CLIARGS = dict(timeout=600.2)
    # call the method set_attributes_from_cli
    play_context_0.set_attributes_from_cli()
    # check that timeout of play_context_0 was set to 600
    assert play_context_0.timeout == 600
