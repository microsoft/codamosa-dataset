

# Generated at 2022-06-25 05:34:40.641007
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_1 = PlayContext()

    # Test with variables
    variables_1 = {}
    variables_1['ansible_become_pass'] = 'test_value'

    play_context_2 = play_context_1.set_task_and_variable_override(None, variables_1, None)
    assert(play_context_2.become_pass == 'test_value')


# Generated at 2022-06-25 05:34:50.779377
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    play_context_0 = PlayContext()
    plugin_loader_0 = PluginLoader(
        'Connection', 'ssh', 'connection_plugins/ssh.py')
    plugin_loader_1 = PluginLoader(
        'Connection', 'local', 'connection_plugins/local.py')

    plugin_loader_1.get_plugin_class.get_option.return_value = None
    plugin_loader_0.get_plugin_class.get_option.return_value = None
    class d:
        options = dict()
    plugin_loader_1.get_plugin_class.return_value.doc.return_value = d
    plugin_loader_0.get_plugin_class.return_value.doc.return_value = d

# Generated at 2022-06-25 05:35:03.056883
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    play_context.become = False
    play_context.check_mode = False
    play_context.connection = "smart"
    play_context.host_pattern = "all"
    play_context.network_os = None
    play_context.port = 22
    play_context.remote_addr = "10.0.2.15"
    play_context.remote_user = "vagrant"
    play_context.timeout = 10
    play_context.verbosity = 0
    play_context.only_tags = set()
    play_context.skip_tags = set()
    print(play_context)

    task = Task()
    task.action = "ping"
    task.async_val = None
    task.async_seconds = None

# Generated at 2022-06-25 05:35:12.291412
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context = PlayContext()
    assert isinstance(play_context, PlayContext)

    endpoint = dict(
        timeout = 5,
        port = 1234
    )
    play_context.set_endpoint(endpoint)
    assert play_context.timeout == 5
    assert play_context.port == 1234

    for_host = dict(
        become = True,
        become_user = "root"
    )
    play_context.set_for_host(for_host)
    assert play_context._become
    assert play_context._become_user == 'root'

# Generated at 2022-06-25 05:35:23.276107
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Test 1
    # Test args
    task = Task()
    variables = {'ansible_user': 'ansible'}
    templar = Templar()

    play_context_0 = PlayContext()

    # Test function
    result = play_context_0.set_task_and_variable_override(task, variables, templar)

    # Test assertions
    assert result.connection == 'ssh'
    assert result.executable == '/bin/sh'
    assert result.remote_addr == '127.0.0.1'
    assert result.port == 22
    assert result.remote_user == 'ansible'
    assert result.password == ''
    assert result.no_log == False
    assert result.timeout == 10
    assert result.network_os == 'default'
    assert result.become == False


# Generated at 2022-06-25 05:35:31.885327
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    args = MagicMock()
    args.verbosity = 1
    args.timeout = 2
    args.private_key_file = 'private_key_file'

    context.CLIARGS = args
    play_context_ = PlayContext()
    play_context_.set_attributes_from_cli()

    assert play_context_.verbosity == 1
    assert play_context_.timeout == 2
    assert play_context_.private_key_file == "private_key_file"


# Generated at 2022-06-25 05:35:42.367287
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # case 1
    test_task = Task()
    test_task.delegate_to = 'test_task_delegate_to'
    test_task.remote_user = 'test_task_remote_user'
    test_task.check_mode = 'test_task_check_mode'
    test_task.diff = 'test_task_diff'

    test_variables = {}
    test_variables['ansible_delegated_vars'] = {'hostA': {'ansible_host': 'hostA_ansible_host'}}
    test_variables['ansible_become_password'] = 'ansible_become_password'
    test_variables['ansible_become_user'] = 'ansible_become_user'

# Generated at 2022-06-25 05:35:46.027546
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    plugin_0 = plugin_loader()

    try:
        play_context_0.set_attributes_from_plugin(plugin_0)
    except (AttributeError, EOFError, ImportError, TypeError, ValueError):
        pass


# Generated at 2022-06-25 05:35:51.459588
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    play_context_0 = PlayContext()
    variables = {}
    play_context_0.update_vars(variables)
    assert not variables


# Generated at 2022-06-25 05:36:00.228480
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    play_context = PlayContext()
    variables = dict()
    play_context.update_vars(variables)
    assert variables == dict()

    play_context = PlayContext()
    play_context._attributes['remote_user'] = 'ansible'
    variables = dict()
    play_context.update_vars(variables)
    assert variables == dict(
            ansible_user='ansible',
            ansible_ssh_user='ansible',
            ansible_connection='ssh',
            ansible_ssh_port=22,
            ansible_connection_user='ansible',
            ansible_port=22,
            ansible_host='',
            ansible_ssh_host='',
        )


# Generated at 2022-06-25 05:36:33.860579
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()
    assert play_context_0.timeout == 1


# Generated at 2022-06-25 05:36:36.182835
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_plugin()



# Generated at 2022-06-25 05:36:37.468304
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_1 = PlayContext()


# Generated at 2022-06-25 05:36:39.592710
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    # test git issue #34372
    play_context_1 = play_context_0.set_task_and_variable_override(task=None, variables=dict(), templar=None)



# Generated at 2022-06-25 05:36:46.397587
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()

    class DummyClass0(object):
        def __init__(self):
            self._options = dict()

        def get_option(self, key):
            return self._options[key]

    dummy_instance0 = DummyClass0()
    dummy_instance0._options['connection'] = 'netconf'
    dummy_instance0._options['ansible_network_os'] = 'junos'
    dummy_instance0._options['ansible_login_user'] = 'test'
    dummy_instance0._options['ansible_login_pass'] = 'test'
    dummy_instance0._options['ansible_become'] = True
    dummy_instance0._options['ansible_become_method'] = 'enable'
    dummy_instance0._options['ansible_become_pass']

# Generated at 2022-06-25 05:36:49.181808
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    task = Task()
    variables = {}
    templar = Templar()
    play_context.set_task_and_variable_override(task, variables, templar)



# Generated at 2022-06-25 05:36:51.822967
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    context = PlayContext()
    context.set_attributes_from_plugin(None)


# Generated at 2022-06-25 05:36:56.602914
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Configure variables and parameters
    play_context_0 = PlayContext()
    task = Task()
    variables = dict()
    templar = Templar(loader=DataLoader())

    # Execute the function
    play_context_0.set_task_and_variable_override(task, variables, templar)


# Generated at 2022-06-25 05:37:02.456713
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context = PlayContext()
    context.CLIARGS = {'timeout': '50'}
    play_context.set_attributes_from_cli()
    assert hasattr(play_context, 'timeout')
    assert play_context.timeout == 50
    context.CLIARGS = {}


# Generated at 2022-06-25 05:37:11.133272
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    play_context_0 = PlayContext( play=play_0, passwords=dict() )
    # test with a task
    result = play_context_0.set_task_and_variable_override( task=task_0,
                                                            variables=inventory_0,
                                                            templar=None )
    assert result.remote_user == 'bob'
    # test with a transport
    result = play_context_0.set_task_and_variable_override( task=task_0,
                                                            variables={ 'ansible_ssh_user': 'bob'},
                                                            templar=None )
    assert result.remote_user == 'jim'
    assert result.remote_user == result.connection_user
    # test with empty values

# Generated at 2022-06-25 05:38:15.017864
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()

    # set_task_and_variable_override() missing required argument 'task', won't be tested

    # set_task_and_variable_override() missing required argument 'variables', won't be tested

    # set_task_and_variable_override() missing required argument 'templar', won't be tested

    # check return values and params
    rv = play_context_0.set_task_and_variable_override(task=None, variables=None, templar=None)
    assert isinstance(rv, PlayContext)


# Generated at 2022-06-25 05:38:17.218718
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    test_PlayContext_set_attributes_from_plugin_0()


# Generated at 2022-06-25 05:38:24.443270
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_0 = PlayContext()
    task_0 = Task()
    variables_0 = dict()
    templar_0 = Templar()
    result = play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)
    assert result.__class__ == PlayContext
    play_context_0 = PlayContext()
    vars = {'ansible_winrm_port': '5986',
            'ansible_connection': 'winrm',
            'ansible_winrm_path': '/wsman',
            'ansible_winrm_scheme': 'https',
            'ansible_winrm_server_cert_validation': 'ignore'}

# Generated at 2022-06-25 05:38:36.163078
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Note:  This is mainly a regression test for the bug where we were failing
    #        to set the 'network_os' field in the connection info based on the
    #        value reported by the connection plugin.
    play = Play()
    play._play_ds = dict(
        name='test play',
        hosts='testhost',
        gather_facts='no',
        tasks=[
            Play.Task(name='test task', action='test_action', args={'test_arg': 123}),
        ]
    )
    play._hosts = Hosts([Host('testhost', port=123)])
    pc = PlayContext(play, passwords=dict())
    plugin = FakePlugin()
    plugin._load_name = 'fake'
    plugin.set_option('network_os', 20)

    pc.set_attributes_from

# Generated at 2022-06-25 05:38:43.189202
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # create a PlayContext
    play_context_0 = PlayContext()

    # create a task object
    task_0 = Task()

    # create a variable dictionary
    variables_0 = Dict()

    # create a templar instance
    templar_0 = Templar()

    # call method with args task and variables and templar
    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)

    # check if method returns a PlayContext
    assert isinstance(play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0), PlayContext)


# Generated at 2022-06-25 05:38:50.136980
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Tests for passing paramiko.SSHClient() instance
    play_context_0 = PlayContext()
    expected_value_0 = 'paramiko'
    plugin_0 = paramiko.SSHClient()
    play_context_0.set_attributes_from_plugin(plugin_0)
    attr_name_0 = 'connection'
    attribute_value_actual_0 = getattr(play_context_0, attr_name_0)
    assert attribute_value_actual_0 == expected_value_0


# Generated at 2022-06-25 05:38:58.034494
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    assert play_context_0._timeout == C.DEFAULT_TIMEOUT
    play_context_0.set_attributes_from_cli()
    assert play_context_0._timeout == C.DEFAULT_TIMEOUT
    assert play_context_0._verbosity == 0
    assert play_context_0._private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert play_context_0._pipelining == C.ANSIBLE_PIPELINING
    assert play_context_0._start_at_task == None
    assert play_context_0._step == False


# Generated at 2022-06-25 05:39:03.208643
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Init:
    play_context = PlayContext()
    task = Task()
    # Set some attributes of task class
    task.delegate_to = '10.1.1.1'
    task.remote_user = 'root'
    task.check_mode = None
    task.diff = None

    task.connection = 'local'
    task.become = False
    task.become_method = 'sudo'
    task.become_user = 'john'

    variables = {}

    # Delegated host variables for test case
    variables[u'ansible_host'] = u'10.1.1.1'
    variables['ansible_port'] = 22
    variables[u'ansible_user'] = u'root'

    # Execute method
    new_info = play_context.set_task_

# Generated at 2022-06-25 05:39:08.929304
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    """
    Function to test method set_task_and_variable_override of class PlayContext
    :return:
    """
    play_context_0 = PlayContext()
    task = None
    variables = dict()
    templar = dict()
    play_context_0.set_task_and_variable_override(task, variables, templar)


# Generated at 2022-06-25 05:39:14.640471
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_0 = PlayContext()
    play_context_0.set_attributes_from_cli()
    assert 'private_key_file' in play_context_0._attributes
    assert 2147483647 == play_context_0.timeout
    assert 2147483647 == play_context_0.verbosity


# Generated at 2022-06-25 05:41:10.685651
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Mocks
    class Host:
        def __init__(self):
            self.name = 'host_name'

    class Inventory:
        def __init__(self):
            self.hosts = {'host_name': Host()}

    class Task:
        def __init__(self):
            self.delegate_to = 'delegate_to_host_name'
            self.remote_user = 'remote_user'

    class VariableManager:
        def __init__(self):
            pass

        def get_vars(self, host, include_hostvars=True):
            if host.name == 'delegate_to_host_name':
                return {'ansible_host': 'host', 'ansible_user': 'delegate_user'}

# Generated at 2022-06-25 05:41:19.989515
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    print("UNIT TEST: PlayContext.set_attributes_from_plugin")
    # Get subclasses of plugin, just in case
    plugin_classes = get_all_subclasses(Plugin)
    plugin_classes.sort()


# Generated at 2022-06-25 05:41:26.841971
# Unit test for constructor of class PlayContext
def test_PlayContext():

    play_context_1 = PlayContext()

    play_context_2 = PlayContext()

    try:
        if play_context_1.become_pass == play_context_2.become_pass:
            print("ok")
        else:
            print("failed")
    except Exception as e:
        print("Expected error:", e)

if __name__ == "__main__":
    test_PlayContext()

# Generated at 2022-06-25 05:41:36.430514
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # setup test vars
    play_context_1 = PlayContext()
    play_context_1.timeout = 60
    play_context_1.remote_user = 'admin'

    task_1 = Task()
    task_1.timeout = 100
    task_1.remote_user = 'root'


    task_1.delegate_to = 'test_host'
    task_1.delegate_facts = True

    variables = dict(ansible_ssh_user='delegate_user')
    variables['ansible_delegated_vars'] = dict()
    variables['ansible_delegated_vars']['test_host'] = dict(ansible_user='delegate_user')
    templar = Templar(loader=None)

    new_info = play_context_1.set_task_and

# Generated at 2022-06-25 05:41:43.732829
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-25 05:41:49.706284
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    test_PlayContext_instance = PlayContext()
    context.CLIARGS = dict()
    context.CLIARGS['verbosity'] = 3
    test_PlayContext_instance.set_attributes_from_cli()
    assert test_PlayContext_instance._verbosity == 3


# Generated at 2022-06-25 05:41:53.799608
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Unit test for method set_attributes_from_plugin of class PlayContext
    '''
    instance = PlayContext()
    set_attributes_from_plugin(instance, plugin=PlayContext())


# Generated at 2022-06-25 05:41:59.971619
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Create the default test case
    play_context_0 = PlayContext()
    # Set the test case arguments for function 'set_task_and_variable_override'
    task = 'SSH'
    variables = dict()
    templar = 'SSH'
    # Perform the test
    set_task_and_variable_override_ret_val = play_context_0.set_task_and_variable_override(task, variables, templar)
    # Return the results
    return set_task_and_variable_override_ret_val


# Generated at 2022-06-25 05:42:09.575600
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_0 = PlayContext()
    from ansible.plugins.connection.ssh import Connection as ConnectionSSH
    ssh_conn = ConnectionSSH(play_context_0, '/')
    play_context_0.set_attributes_from_plugin(ssh_conn)
    assert(play_context_0.network_os == 'default')
    from ansible.plugins.connection.netconf import Connection as ConnectionNETCONF
    netconf_conn = ConnectionNETCONF(play_context_0, '/')
    play_context_0.set_attributes_from_plugin(netconf_conn)
    assert(play_context_0.network_os == 'default')

if __name__ == '__main__':
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-25 05:42:18.232765
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # set_task_and_variable_override() tests
    # First test case to check if set_task_and_variable_override() works correctly when
    # ansible_ssh_private_key_file is defined in magic_mapping.
    magic_mapping = {'private_key_file': ['ansible_ssh_private_key_file']}
    variables = {'ansible_ssh_private_key_file': '~/.ssh/id_rsa1'}
    # Create play_context_1 and test is magic variable was updated
    play_context_1 = PlayContext()
    play_context_1.set_task_and_variable_override(
            MagicMock(), variables, MagicMock())
    # Check if PlayContext._attributes['private_key_file'] is set to correct value
    assert play

# Generated at 2022-06-25 05:44:22.885510
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # create a task, a variable dictionary and a templar
    task_0 = Task()
    variables_0 = {C.DEFAULT_SUDO_TEST_PATH: '/usr/bin/sudo'}
    templar_0 = Templar()

    play_context_0 = PlayContext()
    play_context_0.set_task_and_variable_override(task_0, variables_0, templar_0)
