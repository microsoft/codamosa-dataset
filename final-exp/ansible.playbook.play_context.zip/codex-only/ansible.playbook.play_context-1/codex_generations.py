

# Generated at 2022-06-23 06:34:27.215260
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    pc = PlayContext()
    pc.set_become_plugin('plugin_obj')


# Generated at 2022-06-23 06:34:33.298382
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    '''
    Unit test for method update_vars of class PlayContext
    '''
    import ansible.playbook.play_context
    p = ansible.playbook.play_context.PlayContext()
    v = {}
    p.update_vars(v)
    assert 'ansible_port' in v


# Generated at 2022-06-23 06:34:41.686555
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    p = PlayContext()
    class plugin_class:
        name = 'plugin_name'
        _load_name = 'plugin_load_name'
    class plugin_instance():
        def get_option(self, option):
            return 'plugin_option_%s' % option
    
    class config_class():
        def get_configuration_definitions(name, load_name):
            return {'option1': {'name': 'option1'},
                    'option2': {'name': 'option2'}}
    
    plugin = plugin_instance()
    plugin.__class__ = plugin_class
    C.config = config_class()
    p.set_attributes_from_plugin(plugin)


# Generated at 2022-06-23 06:34:50.657934
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    import os
    import sys

    # Dictionary of modules and the expected results
    # with the __import__ stubbed out
    #
    # Note: This doesn't actually test that the environment variables are
    #       set correctly, just that set_attributes_from_cli will set them
    #       if it thinks it should

# Generated at 2022-06-23 06:35:00.213804
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    import sys
    import os
    import mock
    import unittest
    import tempfile
    import ansible.plugins.loader

    class AnsibleTestCase(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def compile_hosts_pattern(self, host_pattern):
            match = {}
            return match.keys()

        def get_no_log(self, connection_type):
            return True


    class TestPlayContext(AnsibleTestCase):

        def setUp(self):
            super(TestPlayContext, self).setUp()

            self.play = mock.MagicMock()
            self.play.force_handlers = False

# Generated at 2022-06-23 06:35:03.666068
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    param = mock.MagicMock()
    self_obj = PlayContext()
    self_obj.set_become_plugin(param)
    assert self_obj._become_plugin == param


# Generated at 2022-06-23 06:35:11.910617
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    pc = PlayContext()
    pc._attributes['connection'] = 'ssh'
    pc._attributes['remote_addr'] = '100.100.100.100'
    pc._attributes['remote_user'] = 'root'
    pc._attributes['port'] = 2222
    variables = {}
    pc.update_vars(variables)
    assert(variables['ansible_connection'] == 'ssh')
    assert(variables['inventory_hostname'] == '100.100.100.100')
    assert(variables['ansible_user'] == 'root')
    assert(variables['ansible_port'] == 2222)

# Test for method _get_attr_connection of class PlayContext

# Generated at 2022-06-23 06:35:23.580958
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    context.CLIARGS = dict()
    context.CLIARGS['timeout'] = '5'
    context.CLIARGS['verbosity'] = '5'
    context.CLIARGS['private_key_file'] = 'my_key'
    context.CLIARGS['start_at_task'] = 'my_task'

    my_context = PlayContext()
    my_context.set_attributes_from_cli()

    assert context.CLIARGS['timeout'] == my_context.timeout
    assert context.CLIARGS['verbosity'] == my_context.verbosity
    assert context.CLIARGS['private_key_file'] == my_context.private_key_file
    assert context.CLIARGS['start_at_task'] == my_context.start_at_task
#

# Generated at 2022-06-23 06:35:35.130362
# Unit test for constructor of class PlayContext
def test_PlayContext():

    play = Play()
    passdict = {'conn_pass': 'abc', 'become_pass': 'xyz'}

    pc = PlayContext(play, passdict, None)

    # make sure role attribute assignment works as expected
    assert pc.connection == C.DEFAULT_TRANSPORT
    assert pc.remote_user == C.DEFAULT_REMOTE_USER
    assert pc.remote_addr == None
    assert pc.port == C.DEFAULT_REMOTE_PORT
    assert pc.network_os == None
    assert pc.accelerate_ipv6 == None
    assert pc.timeout == C.DEFAULT_TIMEOUT

    assert pc.password == "abc"
    assert pc.become_pass == "xyz"

    pc = PlayContext(play, dict(), None)
    assert pc.password == ""


# Generated at 2022-06-23 06:35:40.312733
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play_context = PlayContext()
    play = Play()
    play.timeout = 15
    play_context.set_attributes_from_play(play)
    
    assert play_context.timeout == 15



# Generated at 2022-06-23 06:35:41.649780
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    pass


# Generated at 2022-06-23 06:35:54.534719
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Test set_attributes_from_cli method of class PlayContext

    # Test with only play
    play = Play().load({'name': 'test_play'})
    pctx = PlayContext(play)

    pctx.set_attributes_from_cli()
    assert pctx.timeout == C.DEFAULT_TIMEOUT
    assert pctx.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert pctx.verbosity == 0

    # Test with only cli args
    #Make the context.CLIARGS as object
    context.CLIARGS = mock_objects.make_context_cliargs_object()
    context.CLIARGS['timeout'] = 3

    pctx = PlayContext()
    pctx.set_attributes_from_cli()
    assert pctx.timeout

# Generated at 2022-06-23 06:35:55.812535
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    PlayContext.update_vars()

# __main__ for testing
if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-23 06:36:05.498373
# Unit test for method set_attributes_from_play of class PlayContext

# Generated at 2022-06-23 06:36:14.100954
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    class Bunch():
        def __init__(self, **kwds):
            self.__dict__.update(kwds)
    args = Bunch(verbosity=42)

    class Bunch():
        def __init__(self, **kwds):
            self.__dict__.update(kwds)
    context.CLIARGS = args

    playcontext = PlayContext()
    playcontext.set_attributes_from_cli()

    assert playcontext._verbosity == 42

# Generated at 2022-06-23 06:36:25.197412
# Unit test for constructor of class PlayContext
def test_PlayContext():
     play = Play()
     context = PlayContext(play)
     assert context.verbosity == 0
     assert type(context.only_tags) == set
     assert type(context.skip_tags) == set
     assert context.start_at_task is None
     assert context.step is False
     assert context.ask_pass is False
     assert context.ask_su_pass is False
     assert context.ask_sudo_pass is False
     assert context.ask_vault_pass is False
     assert context.become is False
     assert context.become_method is None
     assert context.become_user is None
     assert context.check_mode is False
     assert context.connection_lockfd is None
     assert context.diff is False
     assert context.forks == 5
     assert context.private_key_file == C.DE

# Generated at 2022-06-23 06:36:34.678621
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    test_pc = PlayContext()
    test_task = Task()
    test_task._role = dict(name='foo')
    test_task._role._role_path = '/foo/bar'
    test_task._role._vars_per_block = dict()

    test_tmplr = Templar(loader=loader)

    test_vm = VariableManager()
    test_vm.set_host_variable(host='127.0.0.1', varname='ansible_host', value='127.0.0.1')

# Generated at 2022-06-23 06:36:44.196013
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    args = {}
    p = Playbook().load('test_runner/ansible_runner_docker/test_runner/ansible_runner_docker/hosts', 'exec_host', 'setup', 'setup', loader=None, variable_manager=variable_manager, loader_plugin_filters=None)
    passwords = {}
    play_context = PlayContext(p, passwords)
    play_context.set_attributes_from_plugin('exec_host')
    play_context.set_attributes_from_plugin('setup')

# Generated at 2022-06-23 06:36:47.049041
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    '''
    Unit test for the method PlayContext.update_vars of class PlayContext
    '''

    # Test data
    test_data = dict(
        test_data='init_data',
        ansible_ssh_pass='ansible_ssh_pass'
    )

    # Test object
    pc = PlayContext()

    # Test result
    pc.update_vars(test_data)

    # Test assertion
    assert test_data['ansible_ssh_pass'] == pc.password


# Generated at 2022-06-23 06:36:47.489912
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    pass

# Generated at 2022-06-23 06:36:50.605101
# Unit test for constructor of class PlayContext
def test_PlayContext():
    try:
        play_context = PlayContext()
        assert False, 'Expected an exception'
    except Exception:
        pass



# Generated at 2022-06-23 06:36:55.848125
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    play_context = PlayContext()
    play_context.update_vars(variables={})


# Generated at 2022-06-23 06:37:02.787996
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    p = PlayContext()
    # Test with empty variables
    variables = {}
    result = p.update_vars(variables)
    assert result is None
    # Test with variables
    variables = {'ansible_user': 'admin'}
    result = p.update_vars(variables)
    assert result is None
    assert variables != {}
    

# Generated at 2022-06-23 06:37:08.155109
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    class TestPlayContext(PlayContext):
        def __init__(self, play, passwords, connection_lockfd):
            self.play = play
            self.connection_lockfd = connection_lockfd
            # legacy
            self.force_handlers = play.force_handlers
    context = TestPlayContext(object, {}, None)
    context.set_become_plugin(None)
    assert context._become_plugin is None



# Generated at 2022-06-23 06:37:14.208456
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    class Task:
        pass

    task = Task()
    variables = dict()
    templar = Templar(loader=None)
    new_info = set_task_and_variable_override(task, variables, templar)
    assert new_info is None


# Generated at 2022-06-23 06:37:23.938647
# Unit test for constructor of class PlayContext
def test_PlayContext():
    '''
    This test is a first try to start using pytest for unit testing.
    It tests the constructor of the PlayContext class.
    '''
    # set up arguments
    args = {}
    args['start_at_task'] = None
    args['step'] = False
    args['only_tags'] = set()
    args['skip_tags'] = set()
    args['verbosity'] = 0
    args['private_key_file'] = C.DEFAULT_PRIVATE_KEY_FILE
    args['pipelining'] = False
    args['connection'] = 'paramiko'
    args['timeout'] = C.DEFAULT_TIMEOUT
    args['network_os'] = None
    args['docker_extra_args'] = ""
    args['timeout'] = C.DEFAULT_TIMEOUT

# Generated at 2022-06-23 06:37:26.301380
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play_context = PlayContext(play=None, passwords=None, connection_lockfd=None)
    play_context.set_attributes_from_play()

# Generated at 2022-06-23 06:37:31.297196
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    play = Play()
    passwords = {'conn_pass': 'conn_pass', 'become_pass': 'become_pass'}
    connection_lockfd = None
    p = PlayContext(play, passwords, connection_lockfd)
    plugin = None
    p.set_become_plugin(plugin)



# Generated at 2022-06-23 06:37:38.025041
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.plugins.connection.paramiko_ssh import Connection as Connection_paramiko
    conn = Connection_paramiko(host='hostname', port=22, local_port=10, username='test_user')
    p = PlayContext()
    p.set_attributes_from_plugin(conn)
    assert p.username == 'test_user'
    assert p.port == 22
    assert p._local_port == 10
    assert p.host == 'hostname'

# Generated at 2022-06-23 06:37:51.674687
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    attempts = 1000
    task = Task()
    variables = dict()
    templar = Templar()

    # valid combinations of values for remaining fields and checks for remote_addr
    remote_addr_list = ['1.1.1.1', '127.0.0.1', 'localhost']
    rem_port_list = [22, 2222, None]
    use_shell = [True, False]
    use_tty = [True, False]
    remote_user = ['root', 'user1', 'user2', None]
    connection = ['smart', 'ssh', 'paramiko', None]

    for i in range(attempts):
        remote_addr = random.choice(remote_addr_list)
        rem_port = random.choice(rem_port_list)
        my_shell = random.choice(use_shell)

# Generated at 2022-06-23 06:37:53.158172
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    assert True

# Generated at 2022-06-23 06:38:05.461879
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.connection import NetworkConnectionBase
    import os

    # Create an instance of the PlayContext class
    play = Play().load({}, variable_manager={}, loader=None)
    passwords = {}
    connection_lockfd = None
    play_context = PlayContext(play=play, passwords=passwords, connection_lockfd=connection_lockfd)
    # Create dummy value for the method 'set_attributes_from_plugin' of the play_context object
    plugin = get_plugin_class('connection')(NetworkConnectionBase)

    # Execute the method with the created dummy value
    play_context.set_attributes_from_plugin(plugin)

    # If the file exists, the method is good

# Generated at 2022-06-23 06:38:17.978382
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    my_play = Play().load({u"name": u"Ansible Play", u"id": u"9da6a2f8-1b11-65c6-e36f-3d8bafbcb091", u"connection": u"local", u"hosts": u"localhost", u"gather_facts": u"yes", u"roles": []}, variable_manager=VariableManager(), loader=DataLoader())
    passwords = dict()
    connection_lockfd = None
    obj = PlayContext(play=my_play, passwords=passwords, connection_lockfd=connection_lockfd)
    plugin = 'some_plugin'
    obj.set_become_plugin(plugin)
    assert obj._become_plugin == plugin

# Generated at 2022-06-23 06:38:29.418884
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    # PlayContext with constructor arguments: play, passwords
    play = Play()
    passwords = {}
    connection_lockfd = None
    pc = PlayContext(play, passwords, connection_lockfd)

    # priv_pass is None
    # as there is no connection plugin, no default value will be set, it will raise AttributeError
    variables = {}

    # testing conditions
    if pc.connection not in C.CONNECTION_PLUGINS:
        raise AttributeError("connection plugin %s could not be found" % pc.connection)

    pc.update_vars(variables)

    assert 'ansible_password' in variables
    assert 'ansible_shell_type' in variables

# Generated at 2022-06-23 06:38:31.818544
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # Test a negative timeout value
    play_context = PlayContext()
    play_context.timeout = -1
    assert play_context.timeout == -1


# Generated at 2022-06-23 06:38:36.873970
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    """Unit test for method PlayContext.set_become_plugin"""
    # Mock
    plugin = Mock(spec=object)

    # Test
    context = PlayContext()
    context.set_become_plugin(plugin)

    # Assertions
    # NOTE These assertions are not expected to survive refactoring.
    assert context._become_plugin is plugin

# Generated at 2022-06-23 06:38:51.233652
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Setup data
    options = {'test_option_1': {'name': 'test_flag_1', 'default': None, 'type': 'string'},
               'test_option_2': {'name': 'test_flag_2', 'default': None, 'type': 'string'},
               'test_option_3': {'name': 'test_flag_3', 'default': None, 'type': 'string'},
               }
    plugin = object()
    plugin._load_name = 'test_plugin_name'
    plugin_get_option = MagicMock(return_value='test_value')
    plugin.get_option = plugin_get_option
    play_context = PlayContext()
    play_context.set_attributes_from_plugin(plugin)
    # Execute

# Generated at 2022-06-23 06:39:03.318963
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # Testing constructor of class PlayContext
    play = dict(
        remote_user='max',
        become=True,
        become_user='paul',
        become_method='sudo',
    )
    passwords = dict(
        conn_pass='passwd',
        become_pass='passwd',
    )
    play_context = PlayContext(play, passwords)

    assert play_context.remote_user == play['remote_user']
    assert play_context.become == play['become']
    assert play_context.become_user == play['become_user']
    assert play_context.become_method == play['become_method']
    assert play_context.password == passwords['conn_pass']
    assert play_context.become_pass == passwords['become_pass']


# Generated at 2022-06-23 06:39:07.971907
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    playcontext = PlayContext()
    plugin = PrivilegeEscalation()
    playcontext.set_become_plugin(plugin)
    assert isinstance(playcontext._become_plugin, PrivilegeEscalation)


# Generated at 2022-06-23 06:39:11.468655
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    p = PlayContext()
    v = {"ansible_ssh_host": ""}
    p.update_vars(v)
    assert v == {"ansible_ssh_host": ""}


# Generated at 2022-06-23 06:39:20.540454
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # Note: hostvars is really not optional.  The only time it could be omitted is when we create
    # hostvars just so we can invoke its deserialize method to load it from a serialized
    # data source.
    hostvars = {}
    hostvars['hostname'] = '127.0.0.1'
    pc = PlayContext(hostvars=hostvars)

    hostvars['connection'] = 'ssh'
    assert pc.connection == 'ssh'

    hostvars.pop('connection')
    assert pc.connection == C.DEFAULT_TRANSPORT

    hostvars['port'] = '2222'
    assert pc.port == 2222

    hostvars.pop('port')
    assert pc.port == C.DEFAULT_REMOTE_PORT


# Generated at 2022-06-23 06:39:24.221655
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    play_context = PlayContext()
    play_context.set_become_plugin('some_value')
    assert play_context._become_plugin == 'some_value'

# Generated at 2022-06-23 06:39:29.463942
# Unit test for constructor of class PlayContext

# Generated at 2022-06-23 06:39:38.789765
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    '''
    Ensure that a localhost connection is made when
    no connection is specified on the CLI
    '''
    play_context = PlayContext(None, {}, None)
    play_context.set_attributes_from_cli()
    assert play_context.connection == 'local'
    
    play_context = PlayContext(None, {}, None)
    context.CLIARGS = {'connection': 'network_cli'}
    play_context.set_attributes_from_cli()
    assert play_context.connection == 'network_cli'
    context.CLIARGS = {}



# Generated at 2022-06-23 06:39:45.169754
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    import unittest
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    class TestPlay(unittest.TestCase):

        def __init__(self):
            unittest.TestCase.__init__(self)
            self.play = Play()

        def setUp(self):
            self.p_context = PlayContext()

        def test_empty_play(self):
            self.p_context.set_attributes_from_play(self.play)

            self.assertEqual(self.p_context.force_handlers, False)

        def test_force_handlers_true(self):
            self.play.force_handlers = True
            self.p_context.set_attributes_from_play(self.play)

            self.assertE

# Generated at 2022-06-23 06:39:47.343147
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pass # TODO

# Generated at 2022-06-23 06:39:50.186303
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = MagicMock()
    play.force_handlers = False
    play_context = PlayContext(play=play, password={'conn_pass': '', 'become_pass': ''}, connection_lockfd=None)
    assert play_context.force_handlers is False

# Generated at 2022-06-23 06:40:00.256598
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    p = Play()
    p.connection = 'network_cli'
    p.become = True
    p.become_user = 'ansible'
    p.become_method = 'enable'
    p.remote_user = 'remote_user'
    p.become_pass = 'become_pass'
    p.password = 'password'
    p.port = 22
    p.remote_addr = '127.0.0.1'
    p.transport = 'paramiko'
    p.private_key_file = 'private_key_file'
    p.verbosity = 0
    p.force_handlers = False
    p.start_at_task = None
    p.step = False

    pc = PlayContext()
    pc.set_attributes_from_play(p)


# Generated at 2022-06-23 06:40:10.305719
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    '''
    PlayContext - set_become_plugin
    '''
    yaml_data = '''
        hosts: localhost
        tasks:
          - name: test foo
            ping:
    '''
    play = Play.load(yaml_data, variable_manager=VariableManager())
    play.post_validate(Templar(loader=None))
    passwords = dict(conn_pass='foo')
    connection_lockfd = None
    pc = PlayContext(play=play, passwords=passwords, connection_lockfd=connection_lockfd)
    plugin = {'name': 'foo', 'foo': 'bar'}
    pc.set_become_plugin(plugin)
    assert pc._become_plugin == plugin

# Generated at 2022-06-23 06:40:14.854514
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    # Setup test
    pc = PlayContext()
    play = Play()
    play.force_handlers = True

    # Test
    pc.set_attributes_from_play(play)

    # Verify
    assert pc.force_handlers == True


# Generated at 2022-06-23 06:40:19.734289
# Unit test for constructor of class PlayContext
def test_PlayContext():
    pc = PlayContext(C.DataLoader())
    assert pc.remote_addr is None
    assert pc.remote_user == 'root'
    assert pc.port is None
    assert pc.password == ''
    assert pc.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert pc.connection == 'smart'
    assert pc.timeout == C.DEFAULT_TIMEOUT
    assert pc.shell == '/bin/sh'
    assert pc.executable is None
    assert pc.verbosity == 0
    assert not pc.only_tags
    assert not pc.skip_tags
    assert pc._become is True
    assert pc._become_method == 'sudo'
    assert pc._become_user == 'root'
    assert pc.become is None
    assert pc.become_method is None

# Generated at 2022-06-23 06:40:30.539621
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = Mock()
    play.force_handlers = False

    pc = PlayContext(play=play, passwords=None)
    assert pc.force_handlers == False
    assert pc._play == play

    play2 = Mock()
    play2.force_handlers = True
    pc = PlayContext(play=play2, passwords=None)
    assert pc.force_handlers == True
    assert pc._play == play2


# Generated at 2022-06-23 06:40:44.052331
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_plugin_class

# Generated at 2022-06-23 06:40:47.535485
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # PlayContext object assignment
    PlayContext_obj = PlayContext()
    # Test for set_attributes_from_plugin
    assert PlayContext_obj.set_attributes_from_plugin('network_os') == None


# Generated at 2022-06-23 06:40:48.077529
# Unit test for constructor of class PlayContext
def test_PlayContext():
    assert PlayContext()

# Generated at 2022-06-23 06:40:54.090034
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play = None
    passwords = {}
    connection_lockfd = None
    obj = PlayContext(play=play, passwords=passwords, connection_lockfd=connection_lockfd)
    plugin = None
    obj.set_attributes_from_plugin(plugin=plugin)

# Generated at 2022-06-23 06:41:03.497387
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    PluginClass = get_plugin_class('connection', 'local')
    PluginInstance = PluginClass()
    Local.set_options(PluginInstance)
    with patch.object(PluginClass,'get_option', return_value="test"):
        instance = PlayContext(play=None, passwords=None, connection_lockfd=None)
        instance.set_attributes_from_plugin(PluginInstance)
        assert instance.executable == "test"
        assert instance.only_tags == set()
        assert instance.skip_tags == set()
        assert instance.tags == "test"
        assert instance.name == "test"



# Generated at 2022-06-23 06:41:06.289232
# Unit test for constructor of class PlayContext
def test_PlayContext():
    pc = PlayContext()
    # FIXME: add some tests here!
    pass

# FIXME: remove this once we depend on ansible 2.11 or later

# Generated at 2022-06-23 06:41:12.380274
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    play = Play()
    playcontext = PlayContext(play)
    variables = dict()
    new_variables = playcontext.set_task_and_variable_override(play, variables, None)
    playcontext.update_vars(new_variables)
    assert new_variables['ansible_ssh_host'] == playcontext.remote_addr

# Generated at 2022-06-23 06:41:22.742381
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    PlayContext.set_become_plugin.argtypes = [ becomelib._BecomeMethod ]
    PlayContext._become_plugin = None
    PlayContext.prompt = ''
    PlayContext.success_key = ''

    assert PlayContext._become_plugin is None
    assert PlayContext.prompt == ''
    assert PlayContext.success_key == ''

    PlayContext.set_become_plugin(None)
    assert PlayContext._become_plugin is None
    assert PlayContext.prompt == ''
    assert PlayContext.success_key == ''


# Generated at 2022-06-23 06:41:35.700115
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-23 06:41:39.483057
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    '''
    PlayContext - Test set_become_plugin
    '''

    p = PlayContext()
    p.set_become_plugin('test_plugin')
    assert p._become_plugin == 'test_plugin'



# Generated at 2022-06-23 06:41:41.873766
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    v = {}
    pc = PlayContext()
    pc.update_vars(v)
    assert v == {}

# Generated at 2022-06-23 06:41:54.396725
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 4
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()

    templar = Templar(loader=loader, variables=variable_manager)
    from ansible.module_utils.connection import Connection
    connection = Connection()
    from ansible.plugins.loader import connection_loader
    connection = connection_loader.get(connection.transport, connection, templar)
    class Play:
        def __init__(self, force_handlers):
            self.force_handlers = force_handlers
    play=Play(force_handlers=True)
    passwords = {}
    connection_lockfd = None

# Generated at 2022-06-23 06:41:56.300268
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    assert PlayContext().set_become_plugin()


# Generated at 2022-06-23 06:41:57.506023
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
  pass

# Generated at 2022-06-23 06:42:09.758320
# Unit test for constructor of class PlayContext
def test_PlayContext():
    playcontext = PlayContext()
    # Check we have all the attributes set to None or False
    assert not playcontext.password
    assert not playcontext.become_pass
    assert not playcontext.prompt
    assert not playcontext.success_key
    assert not playcontext.connection_lockfd
    assert not playcontext.force_handlers
    assert not playcontext.start_at_task
    assert not playcontext.step
    assert not playcontext.verbosity
    assert not playcontext._become_plugin

    # Check that we have all the attributes set to defaults
    assert playcontext.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert playcontext.timeout == C.DEFAULT_TIMEOUT
    assert playcontext.become == False
    assert playcontext.become_method == 'sudo'
   

# Generated at 2022-06-23 06:42:20.763738
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    class Play(object):
        def __init__(self, force_handlers=None):
            self.force_handlers = force_handlers

    class Task(object):
        def __init__(self, delegate_to=None, remote_user=None, check_mode=None, diff=None, no_log=None, become=None,
                     become_user=None, become_method=None, delegate_facts=None, become_flags=None, module_defaults=None,
                     connection=None, index=None):
            self.delegate_to = delegate_to
            self.remote_user = remote_user
            self.check_mode = check_mode
            self.diff = diff
            self.no_log = no_log
            self.become = become
            self.become_user = become_user


# Generated at 2022-06-23 06:42:33.324594
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    play_context = PlayContext(None, None)
    play_context.no_log = True
    play_context.verbosity = 4
    play_context.remote_addr = None
    play_context.become = True
    play_context.become_user = None
    play_context.become_method = None
    play_context.connection_user = 'user'
    variables = {}
    play_context.update_vars(variables)
    assert variables.get('ansible_no_log', None) == True
    assert variables.get('ansible_verbose', None) == 4


# ##############################################################################
# ######  END PlayContext
# ##############################################################################


# ##############################################################################
# ###### BEGIN Origin
# ##############################################################################


# Generated at 2022-06-23 06:42:37.760761
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    variables = {}
    play = None
    passwords = {}
    connection_lockfd = None
    play_context = PlayContext(play=play, passwords=passwords, connection_lockfd=connection_lockfd)
    play_context.update_vars(variables)
# Once a class inherits from FieldAttribute, we should create the appropriate getter and setter methods
    def test_PlayContext_instance_attribute_remote_addr_create_setter():
        _remote_addr_inst_setter(self, value)

    def test_PlayContext_instance_attribute_remote_addr_create_getter():
        _remote_addr_inst_getter(self)

    def test_PlayContext_instance_attribute_port_create_setter():
        _port_inst_setter(self, value)


# Generated at 2022-06-23 06:42:38.525786
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pass

# Generated at 2022-06-23 06:42:46.405056
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    """
    test_PlayContext_set_become_plugin.py
        - class PlayContext
            - test set_become_plugin
    """

    # test obj create
    play_context = PlayContext()

    # test set_become_plugin
    assert hasattr(play_context, 'set_become_plugin'), "test_PlayContext_set_become_plugin.py test case 0 failed"

    # test update
    become_plugin = {'name': 'become_plugin', 'path': 'path'}
    test_res = play_context.set_become_plugin(become_plugin)
    assert isinstance(test_res, None)

# Generated at 2022-06-23 06:42:49.097290
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    c = PlayContext(name="test")
    c.set_become_plugin("test")



# Generated at 2022-06-23 06:43:00.377799
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Initialization
    ################################################################################
    # FIXTURES

    # Test 0
    ################################################################################
    assert True
    # Test 1
    ################################################################################
    play_context = PlayContext()
    task = Task()
    variables = {}
    templar = ""
    expected = play_context
    actual = play_context.set_task_and_variable_override(task, variables, templar)
    # compare expected and actual

# Generated at 2022-06-23 06:43:08.756906
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    failed = False
    try:
        class fake_task(object):
            pass

        class fake_variables(object):
            pass

        pc = PlayContext()
        task = fake_task()
        variables = fake_variables()
        variables.ansible_ssh_user = "test_ssh_user"
        pc.update_vars(variables)
        # check for presence of PlayContext in the returned dict
        if not isinstance(pc, PlayContext):
            failed = True
    except Exception as ex:
        failed = True

    # Fail the module if exceptions/errors were raised
    assert not failed, 'Test PlayContext.update_vars failed'


# Generated at 2022-06-23 06:43:19.492427
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    my_playContext = PlayContext()
    my_task = Task()
    my_task.delegate_to = "localhost"
    variables = {}
    my_Templar = Templar(None, None)
    updated_info = my_playContext.set_task_and_variable_override(my_task, variables, my_Templar)
    assert updated_info is not None


# test_PlayContext_set_task_and_variable_override()



# Generated at 2022-06-23 06:43:27.910232
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    '''
    PlayContext update_vars()
    '''
    # values mapped from
    # https://github.com/ansible/ansible/blob/stable-2.4/lib/ansible/playbook/__init__.py

    context._init_global_context(play_context=None)
    # setting play context
    pctx = PlayContext(play=None)

    variables = dict()
    variables['ansible_ssh_host'] = None
    variables['ansible_host'] = None

    # updating variables with defaults
    pctx.update_vars(variables)

    # verify
    assert variables['ansible_ssh_host'] == None
    assert variables['ansible_host'] == None


# Generated at 2022-06-23 06:43:38.410999
# Unit test for constructor of class PlayContext
def test_PlayContext():
    '''
    :return:
    '''
    play = Play()
    play.vars = {}
    pc = PlayContext(play)
    assert isinstance(pc, PlayContext)


#
# Ansible-specific connection configuration
#

# We will use a base class for this because the interface is more
# consistent and we can alter the underlying object without having to
# rewrite code.  This allows for a fairly consistent underlying
# interface for different connection types, to a point.  See the
# ConnectionInterface class for more details.

# Add the configuration to the class so that instances of the class
# can be created without having to pass in configuration information
# specific to Ansible for it to function.

# ConnectionPlugins need to be able to modify the PlayContext according to cli/setting overrides or inventory/task info,
# as well as adjust the

# Generated at 2022-06-23 06:43:49.492902
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    import types
    import copy
    import mock
    import ansible.playbook.play_context
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()

    variable_dict = dict()
    play_context.update_vars(variable_dict)
    assert variable_dict['ansible_connection'] == 'ssh'
    assert variable_dict['ansible_ssh_user'] == 'root'
    assert variable_dict['ansible_ssh_host'] == 'localhost'
    assert variable_dict['ansible_ssh_pass'] == ''
    assert variable_dict['ansible_ssh_port'] == 22

    assert variable_dict['ansible_user'] == 'root'
    assert variable_dict['ansible_host'] == 'localhost'

# Generated at 2022-06-23 06:43:49.917578
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    pass

# Generated at 2022-06-23 06:43:55.996542
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    field_names = PlayContext.FIELD_NAMES

    # Instantiate the class we are testing
    module = PlayContext()

    # Set up data needed to pass to the module being tested
    plugin = PlayContext._get_attr_connection

    # Fire off the code we are testing
    module.set_attributes_from_plugin(plugin)

    # Look at the data that comes back
    # assert field_names == result
    assert True


# Unit tests for class PlayContext

# Generated at 2022-06-23 06:44:04.816997
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    class MockConnectionPlugin(object):
        def __init__(self, name, **kwargs):
            self._load_name = name

        def get_option(self, opt):
            return opt

    class MockPlaybook(object):
        def __init__(self):
            self.extra_vars = None

    play = MockPlaybook()
    pc = PlayContext(play=play)

    pc.set_attributes_from_plugin(MockConnectionPlugin('ssh', foo='foo', bar='bar'))
    assert pc.foo == 'foo'
    assert pc.bar == 'bar'


# Generated at 2022-06-23 06:44:09.679375
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    variables = {}
    task = MagicMock(spec=Task)
    context = PlayContext(MagicMock(spec=Play))
    assert context.set_task_and_variable_override(task, variables, MagicMock(spec=Templar)) is not None



# Generated at 2022-06-23 06:44:22.600417
# Unit test for constructor of class PlayContext
def test_PlayContext():

    # Construct a play context with default arguments
    play_context = PlayContext()

    # Validate all the instance variables
    assert(play_context.connection == 'smart')
    assert(play_context.remote_addr == '')
    assert(play_context.remote_user == pwd.getpwuid(os.geteuid()).pw_name)
    assert(play_context.port == None)
    assert(play_context.password == '')
    assert(play_context.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE)
    assert(play_context.timeout == C.DEFAULT_TIMEOUT)
    assert(play_context.verbosity == 0)
    assert(play_context.only_tags == set())
    assert(play_context.skip_tags == set())

# Generated at 2022-06-23 06:44:34.163232
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    # FIXME: Does not call set_attributes_from_play()
    p = PlayContext(play=None, passwords=None, connection_lockfd=None)

    variables = {}

    p.update_vars(variables)

    assert variables.get('ansible_connection', None) == 'local'

    p = PlayContext(play=None, passwords=None, connection_lockfd=None)
    p.remote_addr = 'answer'

    p.update_vars(variables)

    assert variables.get('ansible_connection', None) == 'local'

    variables = {}

    p.connection = 'ssh'
    p.remote_addr = 'answer'

    p.update_vars(variables)

    assert variables.get('ansible_connection', None) == 'ssh'