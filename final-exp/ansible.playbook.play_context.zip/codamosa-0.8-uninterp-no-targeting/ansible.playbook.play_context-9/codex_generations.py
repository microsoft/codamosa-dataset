

# Generated at 2022-06-21 00:53:36.986854
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    context.CLIARGS = dict(timeout=10)
    pc = PlayContext()
    assert pc.timeout == 10



# Generated at 2022-06-21 00:53:39.316457
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    context = PlayContext()
    assert not context._attributes
    context.set_attributes_from_plugin('local')


# Generated at 2022-06-21 00:53:51.881349
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    v = dict(a='some_a',
             b='some_b',
             c='some_c')
    t = Mock()
    t.__dict__ = dict(a=None,
                      b=None,
                      c=None,
                      d='some_d',
                      e=None,
                      f=None,
                      delegate_to=None)
    pci = PlayContext(None)
    pci.set_attributes_from_plugin('dummy')
    pci.set_attributes_from_cli()
    pci.set_attributes_from_play(None)
    pci.update_vars(v)
    pci_copy = pci.copy()
    pci_copy.populate_task_vars(t)
    pci.set_task_and_variable_override(t, v, None)


# Generated at 2022-06-21 00:53:57.610886
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    pc = PlayContext()
    pc.set_attributes_from_cli()
    print(">>> " + ("PASS" if pc._timeout == C.DEFAULT_TIMEOUT else "FAIL"))

    context.CLIARGS = {'timeout': 100}
    pc = PlayContext()
    pc.set_attributes_from_cli()
    print(">>> " + ("PASS" if pc._timeout == 100 else "FAIL"))


# Generated at 2022-06-21 00:54:02.291288
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    pc = PlayContext()
    variables = {'ansible_ssh_port': 5}
    pc.update_vars(variables)
    assert variables == {'ansible_ssh_port': 5, 'ansible_port': 5}


# Generated at 2022-06-21 00:54:04.671575
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    test_obj = PlayContext()
    test_obj.set_become_plugin(None)


# Generated at 2022-06-21 00:54:07.279076
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    PlayContext = connection.PlayContext()
    PlayContext.set_attributes_from_plugin('')
    assert PlayContext is not None


# Generated at 2022-06-21 00:54:19.070110
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    '''
    Unit test for method PlayContext.set_become_plugin
    '''

    # For each test case:
    # if exception is expected, test_case is a tuple of (Exception, callable, callable_args, callable_kwargs)
    # if valid return value expected, test_case is a tuple of (None, callable, callable_args, callable_kwargs)
    # if attribute verification is required, test_case is a tuple of (None, None, None, attr_dict)
    test_cases = [
    ]

    play_context = PlayContext()

    for idx, test_case in enumerate(test_cases):
        if len(test_case) == 4:
            exc_type_expected, callable_obj, callable_args, callable_kwargs = test_case


# Generated at 2022-06-21 00:54:28.683519
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    f_module_utils_basic = module_utils.basic
    f_basic = basic
    f_field_attribute = field_attribute
    f_config = config

# Generated at 2022-06-21 00:54:33.520443
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context = PlayContext()

    assert play_context.timeout == C.DEFAULT_TIMEOUT
    assert play_context.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert play_context.verbosity == 0

# Generated at 2022-06-21 00:54:54.603334
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    attrnames = [attr for attr in vars(PlayContext) if attr.startswith('_')]
    values = {'_attributes': {}}
    for attr in attrnames:
        values[attr] = 'test_PlayContext_' + attr.lstrip('_')
    obj = PlayContext(values)
    assert isinstance(obj, PlayContext)
    params = {'play': None, 'passwords': None, 'connection_lockfd': None}
    obj = PlayContext(**params)
    assert isinstance(obj, PlayContext)
    for attr in attrnames:
        setattr(obj, attr, values[attr])
    assert obj._attributes == values['_attributes']
    assert obj.verbosity == 0
    assert obj.force_handlers == False

# Generated at 2022-06-21 00:55:07.536765
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    runner_mock = MagicMock()
    add_become_plugin(runner_mock)
    temp_path = tempfile.mkdtemp()
    pb_p = 'test/test_runner_lookup_plugin/action_plugins/become_test.py'
    shutil.copy(pb_p, temp_path)
    added_plugin_path = pb_p.replace('test/test_runner_lookup_plugin', temp_path)
    runner_mock.action_loader = PluginLoader('action', added_plugin_path, 'become_test', 'become_test')
    p = Play()
    pb = Playbook()
    p.become_method = 'become_test'
    passwords = {}
    pc = PlayContext(p, passwords)
    pc.set_become

# Generated at 2022-06-21 00:55:16.542312
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = "all",
        gather_facts = "no",
        tasks = [
            dict(action=dict(module="shell", args="ls"), register="shell_out"),
            dict(action=dict(module="debug", args=dict(msg="{{shell_out.stdout}}")))
        ]
    ), variable_manager=VariableManager())

    play_context = PlayContext(play)
    assert play_context.become_method == 'sudo'
    assert play_context.become_user == 'root'
    assert play_context.password == ''
    assert play_context.remote_user == 'root'
    assert play_context.connection == 'paramiko'
    assert play_context.port == 22

# Test for _get_

# Generated at 2022-06-21 00:55:27.350895
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():

    # TODO: Add the test cases for Singlue Connection Test
    # TODO: Add the test cases for Multipe Connection Test

    # PlayContext.update_vars() on success
    def test_PlayContext_update_vars_success():
        
        # Test when variable mapping is correct
        pass

    # PlayContext.update_vars() on failure
    def test_PlayContext_update_vars_failure():
        
        # Test when variable mapping is wrong
        pass


# Generated at 2022-06-21 00:55:32.435133
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    context.CLIARGS = ImmutableDict(connection='smart')

    play = Play()
    play._attributes['force_handlers'] = False
    play._attributes['timeout'] = 10

    play_context = PlayContext(play=play, passwords=None, connection_lockfd=None)

    assert play_context.timeout == 10
    assert play_context.force_handlers == False


# Generated at 2022-06-21 00:55:41.640923
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Unit test for method set_attributes_from_plugin of class PlayContext
    '''
    connection_options = {'some': 'connection_options'}
    conn_plugin = Connection(play_context=PlayContext(play=None, passwords=None, connection_lockfd=None))
    conn_plugin.set_options(connection_options)
    pc = PlayContext(play=None, passwords=None, connection_lockfd=None)
    pc.set_attributes_from_plugin(conn_plugin)
    # attribute 'some' is set to 'connection_options'
    assert pc.some == 'connection_options'

    # attribute 'port' is set to None
    assert pc.port is None


# Generated at 2022-06-21 00:55:50.924701
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    from ansible.config.manager import ConfigManager

    config_manager = ConfigManager()
    config_data = config_manager.get_data()

    play_context = PlayContext(config_manager=config_manager, config_data=config_data)
    play_context.set_attributes_from_cli()

    # test output
    assert play_context.defaults_are_set_for_play == True
    assert play_context.only_tags == set()
    assert play_context.skip_tags == set()
    assert play_context.become == False

    # test output method
    assert play_context.ssh_executable == None
    assert play_context.scp_executable == None
    assert play_context.scp_extra_args == None


# Generated at 2022-06-21 00:55:52.638280
# Unit test for constructor of class PlayContext
def test_PlayContext():
    PlayContext()



# Generated at 2022-06-21 00:55:54.841482
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    x = PlayContext()
    assert x.set_attributes_from_plugin(
        plugin=None
    ) == None

# Generated at 2022-06-21 00:56:03.154664
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Testing the PlayContext.set_attributes_from_cli method
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    C.CLIARGS = {'timeout': '2', 'verbosity': '5'}
    context.CLIARGS = {'timeout': '2', 'verbosity': '5'}
    context.CLIARGS['verbosity'] = '5'
    context.CLIARGS['timeout'] = '2'
    play_context = PlayContext(loader=loader)
    play_context.set_attributes_from_cli()
    assert play_context.timeout == 2
    assert play_context.verbosity == 5

# Generated at 2022-06-21 00:56:23.710736
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # ensure that there are no remaining config options for the deprecated connection plugins
    for plugin_name in ('paramiko', 'ssh', 'local', 'chroot', 'docker', 'jail', 'smart'):
        assert not C.config.get_configuration_definitions(get_plugin_class(plugin_name), plugin_name)

    # assert that we raise exception when a PlayContext instance is copied with a deprecated connection plugin
    pc = PlayContext()
    pc.connection = 'ssh'
    assert not pc.ssh_executable
    pc.set_attributes_from_plugin('ssh')
    assert pc.ssh_executable
    try:
        PlayContext(connection='ssh')
        assert False
    except AssertionError:
        pass

    pc = PlayContext(connection='ssh')

# Generated at 2022-06-21 00:56:27.794261
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    play = object()
    passwords = object()
    connection_lockfd = object()
    pc = PlayContext(play=play, passwords=passwords, connection_lockfd=connection_lockfd)
    variables = {"ansible_ssh_host": "test_ansible_ssh_host"}
    pc.update_vars(variables)
    assert variables == {"ansible_ssh_host": "test_ansible_ssh_host", "ansible_host": "test_ansible_ssh_host"}


# Generated at 2022-06-21 00:56:36.335736
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    context = AnsibleContext(load_plugins=False)
    context.CLIARGS = ImmutableDict()
    new_instance = PlayContext(play=None, passwords=None, connection_lockfd=None)
    try:
        new_instance.set_become_plugin(plugin=None)
    except Exception as e:
        traceback.print_exc()
        assert False
    assert True


# Generated at 2022-06-21 00:56:37.449666
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pass


# Generated at 2022-06-21 00:56:50.899307
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play_name = "localhost"
    play_hosts = ["localhost"]
    play_connection = "smart"
    play_remote_user = ""
    play_remote_port = 22
    play_become_user = None
    play_become_pass = None
    play_force_handlers = False
    play_vars = {}
    play_tags = {}

    # Creates a play object
    play = Play().load(play_name, play_hosts, play_connection, play_remote_user, play_remote_port, play_become_user, play_become_pass, play_force_handlers, play_vars, play_tags)
    # Creates a play context object
    play_context = PlayContext()
    # Invokes the method under test
    play_context.set_attributes_

# Generated at 2022-06-21 00:56:59.082916
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    class FakePlugin(object):
        def __init__(self):
            self.become = 'become'
            self._load_name = '_load_name'
        def get_option(self,*args,**kwargs):
            return 'get_option'
    fake_plugin = FakePlugin()
    pc = PlayContext()
    pc.set_attributes_from_plugin(fake_plugin)
    assert pc.become == 'become'


# Generated at 2022-06-21 00:57:03.343623
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    p = PlayContext()
    p.set_attributes_from_plugin(None)
    assert p._attributes == {}

# Generated at 2022-06-21 00:57:11.543890
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    test_plugin = plugin_loaders['shell']('/bin/sh', '', '', '', '', load_options=True)
    test_play = Play()
    test_play.name = 'TESTPLAY'
    test_play_context = PlayContext(play=test_play)
    test_play_context.set_attributes_from_plugin(test_plugin)
    assert test_play_context._executable == '/bin/sh'
    

# Generated at 2022-06-21 00:57:18.984308
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play_instance = Play()
    context_instance = PlayContext(play=play_instance, passwords=None, connection_lockfd=None)
    assert context_instance.force_handlers == False
    context_instance.set_attributes_from_play(play_instance)
    assert context_instance.force_handlers == False

# Generated at 2022-06-21 00:57:25.793544
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    playbook = Playbook()
    inventory = Inventory()
    pc = PlayContext(playbook=playbook, inventory=inventory)
    sample_variables = {'var1': 'val1', 'var2': 'val2', 'var3': 'val3'}
    expected_result = {'var1': 'val1', 'var2': 'val2', 'var3': 'val3'}
    pc.update_vars(sample_variables)
    assert(sample_variables == expected_result)


# Generated at 2022-06-21 00:57:53.424414
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    new_vars = []
    old_vars = []
    play_context = PlayContext()
    play_context.update_vars(new_vars)
    assert new_vars == old_vars

# Generated at 2022-06-21 00:57:57.198055
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    play_context = PlayContext(play=None, passwords=None, connection_lockfd=None)
    assert play_context.set_become_plugin(None) == None


# Generated at 2022-06-21 00:58:08.278197
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # setup inventory and variables, fake master
    # initialize with our "fake test" inventory
    # load the InventoryPlugin to help us set things up
    inventory = InventoryPlugin('inventory_plugins/test_inventory.py', 'fake_inventory', C.DEFAULT_HOST_LIST)

    # Create the variable manager, which will be shared throughout
    # the code, ensuring a consistent view of global variables
    variable_manager = VariableManager()

    # create the basic data structures needed for a Task
    task = Task()
    task.action = 'setup'
    task.args = {}
    task.async_val = None
    task.async_seconds = None
    task.become_method = None
    task.become_user = None
    task.check_mode = False
    task.connection = 'ssh'
    task.delegate_

# Generated at 2022-06-21 00:58:13.915816
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    #
    #   set_task_and_variable_override inputs:
    #           task, variables, templar
    #
    #   set_task_and_variable_override outputs:
    #           new_info
    #
    #
    #   this test will determine if the outputs named above are equal to a given output variable value
    #
    #   for this unit test, the following inputs were chosen
    #           task = Dict[str, Any]
    #           variables = Dict[str, Any]
    #           templar = Dict[str, Any]
    #
    #   the following outputs were chosen
    #           new_info = Dict[str, Any]
    #
    task = FakeTask()
    variables = FakeVars()
    templar = Templar(vars=variables)

# Generated at 2022-06-21 00:58:19.476462
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    var = PlayContext()
    var.set_attributes_from_plugin('Module Name')
    assert var.connection == "local"
    assert var.port == 5986
    




# Generated at 2022-06-21 00:58:28.593126
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    pc = PlayContext()
    assert pc._verbosity == 0
    assert pc._port is None
    assert pc._private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert pc._timeout == C.DEFAULT_TIMEOUT
    assert pc._remote_user == C.DEFAULT_REMOTE_USER
    assert pc._remote_pass == ''
    assert pc._connection == C.DEFAULT_TRANSPORT
    assert pc._accelerate is False
    assert pc._timeout == C.DEFAULT_TIMEOUT
    assert pc._pipelining is C.ANSIBLE_PIPELINING
    assert pc._ssh_common_args is None
    assert pc._ssh_extra_args is None
    assert pc._sftp_extra_args is None
    assert pc._scp_extra_args is None


# Generated at 2022-06-21 00:58:40.252539
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # test against a real play
    play = Play().load(load_file_common_arguments(dict(
        playbooks=dict(
            playbooks=['test/test.yml'],
            inventory='test/test.yml'
        )
    ))[0])

    play_context = PlayContext()

    set_module_args(dict(
        delegate_to='192.0.2.1'
    ))
    module_args = get_module_args()

    info = play_context.set_task_and_variable_override(play.tasks[0], dict(ansible_ssh_user='foo', ansible_user='bar'), templar=Templar(loader=None))
    assert '192.0.2.1' == info.remote_addr
    assert ' ssh ' == info.exec

# Generated at 2022-06-21 00:58:41.234067
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    pass


# Generated at 2022-06-21 00:58:44.313038
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()
    play_context.set_attributes_from_plugin(plugin=None)


# Generated at 2022-06-21 00:58:57.423020
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-21 00:59:55.792564
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    # Test PlayContext.set_attributes_from_play with PlayContext object

    # setup the object to be used for the test
    #setup the object to be used for the test
    attr_test_object = PlayContext(
                play=None,
                passwords=None,
                connection_lockfd=None,
                )
    attr_test_object._attributes['force_handlers'] = False
    attr_test_object.set_attributes_from_play(play)
    #assert that the expected value is equal to the actual value
    assert attr_test_object._attributes['force_handlers'] == play.force_handlers


# Generated at 2022-06-21 01:00:06.669341
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    p = Playbook.load('/home/cobalt/ansible/lib/ansible/playbook/__init__.py', '__main__', loader, variable_manager)
    pc = p.get_variable_manager().get_vars()
    play = Play().load({}, p, pc)
    pc = PlayContext(play=play)
    pc.set_attributes_from_play(play)
    assert pc._attributes['remote_user'] is None
    assert pc.force_handlers is False
    assert pc.only_tags is set()
    assert pc.skip_tags is set()
    assert pc.start_at_task is None
    assert pc.check_mode is False
    assert pc.diff is True

# Generated at 2022-06-21 01:00:19.360710
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    context = PlayContext()
    context.become = True
    context.become_method = 'sudo'
    context.become_user = 'a'
    context.connection = 'smart'
    context.no_log = True
    context.network_os = 'cisco'
    context.remote_addr = 'd'
    context.remote_port = 'e'
    context.remote_user = 'f'
    context.timeout = 'g'
    variables = {}

    context.update_vars(variables)


# Generated at 2022-06-21 01:00:30.682494
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # The constructor is not called directly, but it is always called
    # before the other tests.  It is also called directly in some
    # runtime cases.
    #
    # The constructor should not be called outside the context of a
    # play.  That is, a PlayContext object should always be associated
    # with a play.  The purpose of the PlayContext object is to capture
    # the settings associated with a particular play.  For example,
    # the value of the "ssh" executable is only usable in the context
    # of a play.  It is not a global setting.  Assigning it to a
    # PlayContext object associates it with a play.
    play = MagicMock()
    play.connection = 'ssh'
    play.remote_addr = 'host2'
    play.remote_user = 'user2'
    play.port

# Generated at 2022-06-21 01:00:41.541374
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    try:
        from mock import MagicMock
    except ImportError:
        from unittest.mock import MagicMock

    host_vars = dict()
    host_vars['ansible_host'] = 'foo'
    host_vars['ansible_user'] = 'foo'
    host_vars['ansible_network_os'] = 'foo'

    host = MagicMock()
    host.vars = host_vars

    # -- set_task_and_variable_override

    task = MagicMock()
    task.delegate_to = None
    task.check_mode = None
    task.diff = None
    task.run_once = None
    task.subset = None
    task.tags = None
    task.when = None
    task.remote_user = 'foo'



# Generated at 2022-06-21 01:00:48.967894
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    fake_cliargs = {
        'verbosity': 1,
        'timeout': '4'
    }
    context_obj = PlayContext(connection_lockfd=None)
    context_obj.set_attributes_from_cli()
    for key in fake_cliargs.keys():
        if(fake_cliargs[key] != getattr(context_obj, key)):
            print ("{0} {1} {2} {3}".format(key, fake_cliargs[key], getattr(context_obj, key), type(getattr(context_obj, key))))
            assert False 

# Generated at 2022-06-21 01:00:54.292915
# Unit test for constructor of class PlayContext
def test_PlayContext():
    p = PlayContext()
    assert p.prompt is None
    assert p.success_key is None
    assert p.timeout == 300
    assert p.connection == 'smart'


# Generated at 2022-06-21 01:01:03.087486
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # Setup play context object
    pc = PlayContext()

    # Test object attributes
    assert isinstance(pc.timeout, int) and pc.timeout == C.DEFAULT_TIMEOUT
    assert isinstance(pc.remote_user, string_types) and len(pc.remote_user) == 0
    assert isinstance(pc.port, int) and pc.port == C.DEFAULT_REMOTE_PORT
    assert isinstance(pc.password, string_types) and len(pc.password) == 0
    assert isinstance(pc.connection, string_types) and pc.connection == "smart"
    assert isinstance(pc.remote_addr, string_types) and len(pc.remote_addr) == 0
    assert isinstance(pc.private_key_file, string_types) and pc.private_key_file == C.DEFAULT

# Generated at 2022-06-21 01:01:08.742293
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play = Play()
    play_context = PlayContext(play=play)
    # Check all attributes of play context has been set.
    for field in vars(play_context):
        assert getattr(play_context, field) is not None, '%s field of PlayContext class is None' % field

if __name__ == "__main__":
    test_PlayContext()

# Generated at 2022-06-21 01:01:15.766774
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    instance = PlayContext(play=None, passwords=None, connection_lockfd=None)

    with pytest.raises(TypeError):
        instance.set_attributes_from_cli(arg1='arg1')

    instance.set_attributes_from_cli()

