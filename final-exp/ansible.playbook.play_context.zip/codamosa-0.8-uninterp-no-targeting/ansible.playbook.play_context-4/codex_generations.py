

# Generated at 2022-06-21 00:53:51.581007
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    # create a new PlayContext instance
    pc = PlayContext()

    # test where plugin is None
    pc.set_become_plugin(None)

    # test where plugin is not None
    #  test fails because mocker patch did not handle Mock() as it should be (tested by running the code)
    pc.set_become_plugin(delegation.DelegationBase())
    assert pc._become_plugin == delegation.DelegationBase()


# Generated at 2022-06-21 00:54:00.129301
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context = PlayContext(play=Mock())
    assert play_context.force_handlers is False

    # test defaults
    assert play_context.remote_user == os.environ.get('USER', None)
    assert play_context.connection == 'smart'
    assert play_context.remote_addr == '127.0.0.1'
    assert play_context.port == '22'
    assert play_context.timeout == C.DEFAULT_TIMEOUT
    assert play_context.password == ''
    assert play_context.prompt == ''
    assert play_context.success_key == ''
    assert play_context.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert play_context.remote_tmp == C.DEFAULT_REMOTE_TMP

# Generated at 2022-06-21 00:54:12.622727
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = create_instance(Play)
    setattr(play, 'connection', 'smart')
    setattr(play, 'gather_facts', 'yes')
    setattr(play, 'force_handlers', True)
    setattr(play, 'become', 'yes')
    setattr(play, 'become_method', 'sudo')
    setattr(play, 'tags', ['test_tag'])
    setattr(play, 'tasks', [])

    playcontext = PlayContext(play)
    playcontext.set_attributes_from_play(play)

    assert playcontext.connection == 'smart'
    assert not playcontext.gather_facts
    assert playcontext.force_handlers
    assert playcontext.become
    assert playcontext.become_method == 'sudo'


# Generated at 2022-06-21 00:54:14.863060
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    variables = dict(ansible_host="host1", ansible_port="10000", ansible_user="ansible", remote_addr="host1", port="10000")
    play_context = PlayContext()
    result = play_context.set_task_and_variable_override(None, variables, None)
    assert result != None


# Generated at 2022-06-21 00:54:23.420822
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.vars.manager import VariableManager
    from ansible.vars.clean import module_response_deepcopy
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook_include import PlaybookInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    hoge_play_dict = {
        'name': 'hoge',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'name': 'hoge task 1',
             'setup': {}
             },
            {'name': 'hoge task 2',
             'setup': {'connection': 'local'}
             }
        ]
    }

# Generated at 2022-06-21 00:54:33.464254
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    def test_names(names, expected_names):
        names = [name for name in names if name]
        names.sort()
        expected_names.sort()
        names.should.equal(expected_names)

    pc = PlayContext(dict(remote_user='user', become=True, become_method='sudo'))
    pc.connection.should.equal('smart')
    pc.executable.should.equal('/bin/sh')

    pc = PlayContext(dict(remote_user='user', become=True))
    pc.connection.should.equal('smart')


# Generated at 2022-06-21 00:54:35.553924
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    ins=PlayContext()
    variables={'a':1}
    ins.update_vars(variables)
    assert variables['ansible_connection'] == 'smart'



# Generated at 2022-06-21 00:54:42.098622
# Unit test for constructor of class PlayContext
def test_PlayContext():
    '''
    PlayContext - constructor test
    '''
    play_context = PlayContext()
    assert play_context.remote_addr is None
    assert play_context.password == ''
    assert play_context.port is None
    assert play_context.remote_user == 'root'
    assert play_context.connection == 'smart'
    assert play_context.timeout == C.DEFAULT_TIMEOUT
    assert play_context.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert play_context.network_os is None
    assert play_context.become is False
    assert play_context.become_method == 'sudo'
    assert play_context.become_user == 'root'
    assert play_context.become_pass == ''
    assert play_context.become_exe

# Generated at 2022-06-21 00:54:44.671751
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play = object()
    passwords = object()
    connection_lockfd = object()

    context_ = PlayContext(play, passwords, connection_lockfd)
    plugin = object()

    context_.set_attributes_from_plugin(plugin)

    assert {'play_context': context_} == plugin._play_context_vars


# Generated at 2022-06-21 00:54:49.226847
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    """
    Unit test for set_become_plugin of class PlayContext
    """
    # Initialization of class variables & objects
    oPlayContext = PlayContext()

    # List of mocked parameters
    oPlugin = ''

    # Testing the call of method set_become_plugin with mocked parameters
    oPlayContext.set_become_plugin(oPlugin)

# Generated at 2022-06-21 00:55:28.123583
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    test_instance = PlayContext()
    test_instance.set_attributes_from_cli()


# Generated at 2022-06-21 00:55:40.701823
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Tests if the attributes in the Playcontext object is set correctly after setting them from a plugin object
    '''
    c = PlayContext()

    options = dict()
    options['foo'] = dict()
    options['foo']['default'] = 'bar'
    options['foo']['name'] = 'bar'
    options['foo']['type'] = 'string'

    options['baz'] = dict()
    options['baz']['default'] = 'foo'

    options['toto'] = dict()
    options['toto']['default'] = 'babar'
    options['toto']['name'] = 'babar'
    options['toto']['type'] = 'string'


# Generated at 2022-06-21 00:55:44.111488
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    pc = PlayContext()
    pc.set_attributes_from_cli()
    assert isinstance(pc.timeout, int)
    assert isinstance(pc.private_key_file, basestring)
    assert isinstance(pc.verbosity, int)
    assert pc.start_at_task is None

# Generated at 2022-06-21 00:55:55.909045
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    runner = Runner()
    vec = DummyVec(runner)

    ###############################################
    # set up patches
    m_IsolatedAsyncLoader = mock.patch('ansible.module_utils._text.IsolatedAsyncLoader')
    m_get_loader = mock.patch('ansible.parsing.dataloader.DataLoader.get')
    m_VaultLib = mock.patch('ansible.parsing.vault.VaultLib')
    m_VaultSecret = mock.patch('ansible.parsing.vault.VaultSecret')

    ###############################################
    # execute
    m_IsolatedAsyncLoader.start()
    m_get_loader.start()
    m_VaultLib.start()
    m_VaultSecret.start()

    context.CLIARGS = dict

# Generated at 2022-06-21 00:55:56.558024
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    pass

# Generated at 2022-06-21 00:55:57.897845
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    display.DEBUG = True
    pytest.skip("Not tested yet")

# Generated at 2022-06-21 00:56:02.033529
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    from ansible.module_utils.become import Become
    new_PlayContext=PlayContext()
    new_PlayContext.set_become_plugin(Become())


# Generated at 2022-06-21 00:56:08.091293
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    module = TestModule.play_contexts[0]

    # TODO: add more set checkpoints to check the behaviour of the method
    module.set_attributes_from_plugin(module._attributes['_network_os'])

    assert module.network_os == 'cisco_ios'


# Generated at 2022-06-21 00:56:13.647555
# Unit test for constructor of class PlayContext
def test_PlayContext():
    class FakeArgs(object):
        timeout = 20

    context.CLIARGS = FakeArgs()

    pc = PlayContext()
    assert pc.timeout == 20

    pc = PlayContext(None, None)
    assert pc.timeout == 20

    context.CLIARGS = None

# Generated at 2022-06-21 00:56:23.079573
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    test_inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    
    config_instance = Config()
    config_instance.load()

    play_source = dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args='')),
                dict(action=dict(module='shell', args='ls'))
             ]
        )

    play_context = PlayContext()

    play = Play().load(play_source, variable_manager=VariableManager(loader=DataLoader()), loader=DataLoader())
    play._variable_manager.set_inventory(test_inventory)


# Generated at 2022-06-21 00:57:03.898627
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import plugin_loader

    plugin_loader.add_directory('./lib/ansible/plugins/become')

    context = PlayContext()

    context.become_method = 'sudo'
    context.become_user = 'root'

    context.set_become_plugin(plugin_loader.get(context.become_method, class_only=True))

    ret = context.become_pass

    assert ret == ""
    assert context.become_method == 'sudo'
    assert context.become_user == 'root'


# Generated at 2022-06-21 00:57:14.888151
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from units.mock.loader import DictDataLoader

# Generated at 2022-06-21 00:57:19.441844
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    p = Play()
    loader = DataLoader()
    context._init_global_context(loader=loader)
    pc = PlayContext(play=p)
    pc.set_attributes_from_cli()
    print("pc.timeout is {}".format(pc.timeout))


# Generated at 2022-06-21 00:57:24.944671
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # create instance of class with args
    playcontext_instance = PlayContext(play=None, passwords=None, connection_lockfd=None)
    # apply test
    playcontext_instance.set_attributes_from_cli()


# Generated at 2022-06-21 00:57:27.388691
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    pc = PlayContext()
    bp = pc.set_become_plugin()
    assert pc._become_plugin == bp, "PlayContext._become_plugin == returned bp (None)"


# Generated at 2022-06-21 00:57:38.499706
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.playbook.play import Play

    example_plugin = 'testplugin'
    example_config_file_option = 'test_config_file'
    example_data_file_option = 'test_data_file'

    class testplugin:
        def __init__(self):
            self._load_name = example_plugin

        def get_option(self, key):
            if key == 'test_config_file':
                return "test_config.yml"
            elif key == 'test_data_file':
                return "/test_data.yml"
            else:
                return None

    # TODO
    # need to mock _get_plugin_class(plugin)
    def get_plugin_class(plugin):
        return testplugin

    # TODO
    # need to mock options = C.config

# Generated at 2022-06-21 00:57:42.317424
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play.Play.load=MagicMock(return_value=None)
    playcontext = PlayContext()
    playcontext.set_attributes_from_play(play.Play())
    assert playcontext._attributes['force_handlers'] == False


# Generated at 2022-06-21 00:57:54.740033
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # patching out cli
    class cliargs:
        def __init__(self):
            self.connection = "local"
            self.become = True
            self.become_user = "root"
            self.become_method = "su"
            self.become_ask_pass = True
            self.check = True
            self.diff = True
            self.vault_password_file = ".vault"

    # mocking out play object
    class play:
        def __init__(self):
            self.connection = "smart"

    context.CLIARGS = cliargs()
    o = PlayContext(play=play())
    o.set_attributes_from_cli()
    assert o.connection == "local"
    assert o.become == True
    assert o.become_

# Generated at 2022-06-21 00:58:04.794447
# Unit test for constructor of class PlayContext
def test_PlayContext():
    pc = PlayContext()
    assert pc.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE

    conn_pass = 'conn_passwd'
    become_pass = 'become_passwd'
    pc = PlayContext(passwords={'conn_pass': conn_pass,
                                'become_pass': become_pass})
    assert pc.password == conn_pass
    assert pc.become_pass == become_pass
    assert pc.prompt == ''
    assert pc.success_key == ''

    pc = PlayContext(connection_lockfd=6)
    assert pc.connection_lockfd == 6

# Generated at 2022-06-21 00:58:16.711337
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play = AnsiblePlay()
    pc = PlayContext(play, passwords={}, connection_lockfd=42)

    # Case: variables from inventory
    task = DataLoader().load(dict(
        remote_addr=None,
        connection='paramiko',
        remote_user='foo',
        no_log=None,
        check_mode=None,
        diff=None,
        port=None,
        become=None,
        become_method=None,
        become_user=None,
        become_pass=None,
    ))


# Generated at 2022-06-21 00:59:39.561771
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    context.CLIARGS = dict()
    context.options_context.defaults = dict()

    play = Play()
    task = Task()
    variables = dict()
    templar = Templar()

    p = PlayContext()

    task.remote_user = "foo"
    task.delegate_to = None

    context.CLIARGS['timeout'] = "10"
    context.options_context.defaults['remote_addr'] = "192.168.1.1"
    context.options_context.defaults['remote_user'] = "boo"

    variables['ansible_user'] = "boo"
    variables['ansible_remote_addr'] = "192.168.1.1"
    variables['ansible_port'] = "22"
    variables['ansible_connection'] = "smart"


# Generated at 2022-06-21 00:59:48.687248
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    '''
    Unit test for method set_become_plugin of class PlayContext
    '''
    p = PlayContext()
    # call the method
    plugin = become.Become()
    p.set_become_plugin(plugin)
    desired = become.Become()
    actual = p._become_plugin
    assert actual == desired, 'Test failed because expected for {0} is actual for {1}'.format(desired, actual)


# Generated at 2022-06-21 01:00:00.035806
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play = Play().load({}, variable_manager=VariableManager(), loader=DataLoader())
    pc = PlayContext(play, passwords={})

    # FIXME: this should use the actual defaults on the fields
    assert pc.become == False
    assert pc.become_method == 'sudo'
    assert pc.become_user == 'root'
    assert pc.check_mode == False
    assert pc.connection == 'smart'
    assert pc.executable is None
    assert pc.force_handlers == False
    assert pc.host_list == None
    assert pc.inventory is None
    assert pc.only_tags == set()
    assert pc.skip_tags == set()
    assert pc.module_path == None
    assert pc.remote_addr == None
    assert pc.remote_user == 'root'

# Generated at 2022-06-21 01:00:08.581841
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    p = PlayContext()
    p.remote_addr = "192.168.1.10"
    p.port = "5555"
    p.remote_user = "user"
    #p.become_method = "su"
    #p.become_user = "root"
    p.connection = "ssh"
    p.ssh_executable = "/usr/bin/ssh"
    p.private_key_file = "key.pem"
    v = dict()
    p.update_vars(v)
    v = dict()
    p.update_vars(v)
    v = dict()
    p.update_vars(v)
    assert(v['ansible_host'] == '192.168.1.10')
    assert(v['ansible_port'] == '5555')

# Generated at 2022-06-21 01:00:15.931227
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    # Testing PlayContext.set_attributes_from_play
    # PlayContext.set_attributes_from_play(self, play) method does not need to run
    # individual unit tests as it just sets the attributes for PlayContext object
    # and these are set by the Play object. So, no unit test is required.
    pass


# Generated at 2022-06-21 01:00:28.615304
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.connection.paramiko_ssh import Connection as Paramiko_ssh_Connection

    plugin_class = get_plugin_class('connection', 'paramiko_ssh')
    assert plugin_class == Paramiko_ssh_Connection

    AnsibleConnection = get_plugin_class('connection', '__init__')

    pc = PlayContext()

    pc.set_attributes_from_plugin(AnsibleConnection()) # default

    pc.set_attributes_from_plugin(Paramiko_ssh_Connection()) # ssh is paramikos

    assert pc.connection == 'ssh' # ssh is paramikos

    pc.set_attributes_from_plugin(AnsibleConnection(task_uuid='t.u.1'))
    assert pc.connection == 'ssh' #

# Generated at 2022-06-21 01:00:39.570324
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():

    # Ensures that when a connection_user is not set, it defaults to the remote_user
    connection_user = 'waffles'
    remote_user = 'bacon'
    info = PlayContext()
    info._attributes['connection_user'] = connection_user
    info._attributes['remote_user'] = remote_user
    test_vars = dict()
    try:
        info.update_vars(test_vars)
    except:
        pass
    assert connection_user == test_vars[C.MAGIC_VARIABLE_MAPPING.get('connection_user')[0]]

    # Ensures that when a connection_user is set, it overrides the remote_user
    connection_user = 'waffles'
    remote_user = 'bacon'
    info = PlayContext()
    info._

# Generated at 2022-06-21 01:00:49.757688
# Unit test for constructor of class PlayContext
def test_PlayContext():
    '''
    Tests creation of the PlayContext class, and documents some features
    '''
    import types

    # Test creation of PlayContext w/o required `play' object
    try:
        PlayContext()
    except TypeError as err:
        assert "missing 1 required positional argument: 'play'" in str(err)
    else:
        assert False, "Expected TypeError"

    myplay = Mock(spec=Play())
    passwords = dict(conn_pass='mypass', become_pass='mybecomepass')
    # Create a PlayContext object
    pc = PlayContext(play=myplay, passwords=passwords, connection_lockfd=42)

    # Ensure PlayContext has necessary attributes
    assert hasattr(pc, 'play')
    assert hasattr(pc, 'connection')

# Generated at 2022-06-21 01:01:00.746754
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # create a new PlayContext object
    play_context = PlayContext()

    # run a bunch of assertions to make sure the constructor worked as expected
    assert play_context.remote_addr == C.LOCALHOST
    assert play_context.connection == C.DEFAULT_TRANSPORT
    assert play_context.remote_user == pwd.getpwuid(os.geteuid())[0]
    assert play_context.network_os is None
    assert play_context.port is None
    assert play_context.timeout == C.DEFAULT_TIMEOUT
    assert play_context.password == ''
    assert play_context.prompt == ''
    assert play_context.success_key == ''
    assert play_context.connection_lockfd is None
    assert not play_context.become
    assert play_context.become

# Generated at 2022-06-21 01:01:05.112371
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    test_play_context = PlayContext()
    test_play = object()
    test_play_context.set_attributes_from_play(test_play)
