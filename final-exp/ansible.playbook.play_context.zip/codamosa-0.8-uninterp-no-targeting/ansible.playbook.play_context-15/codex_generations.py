

# Generated at 2022-06-21 00:53:33.970626
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    # setup test
    test_PlayContext_set_become_plugin.play_context = PlayContext()
    # test method
    test_PlayContext_set_become_plugin.play_context.set_become_plugin(plugin='plugin')
    assert test_PlayContext_set_become_plugin.play_context._become_plugin == 'plugin'
    # teardown test
    del(test_PlayContext_set_become_plugin.play_context)


# Generated at 2022-06-21 00:53:38.678339
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    # TODO: set attributes of play to test
    play = None

    # create a PlayContext instance to test
    play_context = PlayContext()

    # use the object to call the method set_attributes_from_play
    play_context.set_attributes_from_play(play)

# Generated at 2022-06-21 00:53:42.478334
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    mock_plugin = Mock()
    context = PlayContext(None)
    context.set_become_plugin(mock_plugin)
    assert context._become_plugin == mock_plugin
    del context
    

# Generated at 2022-06-21 00:53:53.324907
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    # test_PlayContext_update_vars() => checking if variables are updated properly or not
    test_obj = PlayContext()
    for prop, var_list in C.MAGIC_VARIABLE_MAPPING.items():
        try:
            if 'become' in prop:
                continue

            var_val = getattr(test_obj, prop)
            for var_opt in var_list:
                if var_opt not in variables and var_val is not None:
                    variables[var_opt] = var_val
        except AttributeError:
            continue
    
    assert variables == C.MAGIC_VARIABLE_MAPPING

# Generated at 2022-06-21 00:54:00.890069
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    # inputs
    fake_connection_lockfd=0
    fake_privilege_escalation=dict(become=True)
    fake_become_pass=''

    # create a dummy instance and set up a fake privilege escalation plugin
    pc = PlayContext()
    pc.become_pass = fake_become_pass
    pc.connection_lockfd = fake_connection_lockfd
    fake_become_plugin = MagicMock()

    # test
    pc.set_become_plugin(fake_become_plugin)

    # make sure the fake plugin was configured with the instance's
    # connection lock file descriptor
    fake_become_plugin.assert_has_calls([
        call.set_become_context(fake_connection_lockfd, fake_privilege_escalation)
    ])

    pc._become

# Generated at 2022-06-21 00:54:12.865528
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    '''
    PlayContext.set_become_plugin() function test case.
    '''
    _play = dict(
        name='myplay',
        hosts='all',
        gather_facts='no',
        become='no',
    )

    _play = Play().load(_play, variable_manager=MagicMock(), loader=MagicMock())

    _passwords = dict(
        conn_pass='pass',
        become_pass='pass',
    )

    _pc = PlayContext(play=_play, passwords=_passwords, connection_lockfd=None)

    _become_plugin = MagicMock()
    _pc.set_become_plugin(_become_plugin)

    assert _pc._become_plugin is _become_plugin



# Generated at 2022-06-21 00:54:19.911692
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():

    vars = {
        'foo': 'bar',
        'ansible_connection': 'local',
        'ansible_host': 'localhost',
    }
    pc = PlayContext(vars)

    pc.update_vars(vars)

    for prop, var_list in C.MAGIC_VARIABLE_MAPPING.items():
        for var_opt in var_list:
            assert vars.get(var_opt), vars[var_opt]


# Generated at 2022-06-21 00:54:25.852327
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    from ansible.playbook.play import Play
    play_context = PlayContext(play=Play())

    # Setup Play to be used in test_set_attributes_from_play
    play = Play()
    play.vars = dict()
    play.connection = 'smart'
    play.remote_user = 'something'
    play.transport = 'something'
    play.remote_port = 'something'
    play.timeout = 'something'
    play.sudo_user = 'something'
    play.sudo = 'something'
    play.sudo_pass = 'something'
    play.su = 'something'
    play.su_pass = 'something'
    play.become = 'something'
    play.become_method = 'something'
    play.become_user = 'something'
    play.become

# Generated at 2022-06-21 00:54:35.108275
# Unit test for constructor of class PlayContext
def test_PlayContext():
    pc = PlayContext()
    assert not pc.remote_addr
    assert not pc.remote_user
    assert not pc.password
    assert not pc.private_key_file
    assert pc.timeout == C.DEFAULT_TIMEOUT
    assert not pc.connection_user
    assert not pc.become
    assert not pc.become_method
    assert not pc.become_user
    assert not pc.become_pass
    assert not pc.verbosity
    assert not pc.only_tags
    assert not pc.skip_tags
    assert not pc.start_at_task
    assert not pc.step
    assert not pc.connection_lockfd
    assert not pc.prompt
    assert pc.force_handlers == False
    assert not pc.success_key


# Generated at 2022-06-21 00:54:48.578364
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = MagicMock()
    play.connection = 'network_cli'
    play.remote_user = 'play user'
    play.remote_addrs = ['192.168.10.4']
    play.network_os = 'ios'

    play.become = True
    play.become_method = 'enable'
    play.become_user = 'root'
    play.become_pass = 'secret'

    play.vars = {
        'ansible_become_exe': '/opt/bin/su',
        'ansible_become_flags': '-c',
        'ansible_become_pass': 'secret',
    }

    play.ansible_password = 'secret'
    play.ansible_winrm_transport = ['basic', 'ssl']
    play.ansible_

# Generated at 2022-06-21 00:55:05.994560
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Argument for staticmethod set_attributes_from_plugin
    plugin = None

    # Calling staticmethod set_attributes_from_plugin
    PlayContext.set_attributes_from_plugin(plugin)


# Generated at 2022-06-21 00:55:18.808663
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    '''
        calling set_attributes_from_play with play parameter
    '''
    context.CLIARGS = dict(connection='ssh', forks=10, become=False,
                           become_method='sudo', become_user='root', check=False, diff=False)
    args = dict(module_path=None, forks=10, become=False,
                become_method='sudo', become_user='root', check=False, diff=False)

    playcontext=PlayContext(None, **args)
    assert playcontext.fork_count == 10
    assert playcontext.connection == 'ssh'
    assert playcontext.become == False
    assert playcontext.become_method == 'sudo'
    assert playcontext.become_user == 'root'
    assert playcontext.check_mode == False

# Generated at 2022-06-21 00:55:32.090092
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.unsafe_proxy import to_safe_text
    from ansible.plugins.loader import load_plugin
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variables = VariableManager()
    inventory = InventoryManager("/etc/ansible/hosts", loader=loader,
                                 sources=["all"])

# Generated at 2022-06-21 00:55:35.813393
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    # create a instance of PlayContext for test
    new_info = PlayContext()
    # create a mock for variables
    variables = MagicMock()
    # test if update_vars(variables) works as expected
    new_info.update_vars(variables)

# Generated at 2022-06-21 00:55:43.519228
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    # PlayContext.set_attributes_from_play(play)

    # Setup args to pass to the method
    play = MagicMock()
    play.force_handlers = False

    # Setup the dummy PlayContext instance that we are going to call the method on
    dummy_play_context_instance = PlayContext()

    # Now call the method and check what it returns
    result = dummy_play_context_instance.set_attributes_from_play(play)

    # Check what the method returns
    assert result == None

    # Check to see that the object was 'changed' by the method call
    assert dummy_play_context_instance.force_handlers == False

# Generated at 2022-06-21 00:55:53.471589
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    def call_method(play):
        p = PlayContext()
        p.set_attributes_from_play(play)
        
        return p
    play =  Mock()
    play.connection = 'local'
    play.remote_user = 'remote_user'
    play.force_handlers = False

    #play dict has connection as key
    assert call_method(play)._attributes['connection'] == 'local'
    play.connection = None
    #play dict has no connection as key. so default connection is ssh
    assert call_method(play)._attributes['connection'] == 'ssh'
    play.connection = None
    play.remote_user = None
    assert call_method(play)._attributes['remote_user'] == 'root'
    play.remote_user = None
    play.force_handlers

# Generated at 2022-06-21 00:56:03.231490
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Update task and variable override test,
    # to test remote_user, start_at_task, etc.
    loader, inventory, variable_manager = \
    C.DEFAULT_LOADER, C.DEFAULT_INVENTORY, VariableManager()
    inventory.loader = loader
    inventory.hosts = ['localhost']
    inventory.groups = dict((i, Group(i)) for i in inventory.hosts)
    variable_manager.set_inventory(inventory)

    play_source = dict(
            name = "test",
            hosts = "localhost",
            gather_facts = "no",
            tasks = [
                dict(action=dict(module="setup")),
                dict(action=dict(module="shell", args="ifconfig"))
             ]
        )

# Generated at 2022-06-21 00:56:13.092847
# Unit test for constructor of class PlayContext
def test_PlayContext():
    class MyPlay(object):
        def __init__(self, **kwargs):
            for k, v in iteritems(kwargs):
                setattr(self, k, v)

    passwords = {'conn_pass': 'test_pass', 'become_pass': 'test_pass'}

# Generated at 2022-06-21 00:56:17.636255
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    try:
        pc = PlayContext(None)
        p = MockPlugin()
        pc.set_become_plugin(p)
    except Exception as e:
        print("Test Failed: " + str(e))


# Generated at 2022-06-21 00:56:30.379500
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    from collections import namedtuple
    from ansible.executor.task_result import TaskResult
    from ansible.compat.tests.mock import patch
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-21 00:56:51.682570
# Unit test for constructor of class PlayContext
def test_PlayContext():
    pass

# Generated at 2022-06-21 00:56:58.756951
# Unit test for constructor of class PlayContext
def test_PlayContext():

    # initialize some values for passwords
    passwords = {'conn_pass': 'secret', 'become_pass': 'lolwut'}

    # initialize values for a connection lock file
    connection_lockfd = 9001

    # create a PlayContext object
    context = PlayContext(passwords=passwords, connection_lockfd=connection_lockfd)

    # test password attributes
    assert(context.password == passwords['conn_pass'])
    assert(context.become_pass == passwords['become_pass'])

    # test file descriptor for a lock
    assert(context.connection_lockfd == connection_lockfd)

# Generated at 2022-06-21 00:57:12.905833
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    from ansible.plugins.become import BecomeBase
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    become_plugin = BecomeBase()
    task = Task()
    variables = dict()
    variable_manager = VariableManager()
    play_context = PlayContext(play=Play.load(dict(name='test name', hosts='test hosts', gather_facts='yes', tasks=[task])))
    play_context.set_become_plugin(become_plugin=become_plugin)
    play_context.set_task_and_variable_override(task=task, variables=variables, templar=True)

    play_context.update_vars(variables=variables)
    play_context.set_attributes

# Generated at 2022-06-21 00:57:25.678704
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.template import Templar

    fake_loader = DataLoader()
    fake_inventory = Inventory(loader=fake_loader, variable_manager=VariableManager(), host_list=[])
    fake_variable_manager = VariableManager()
    fake_variable_manager.set_inventory(fake_inventory)
    fake_play = Play().load({}, fake_variable_manager, fake_loader)
    fake_play.become = True
    fake_play.become_method = 'sudo'
    fake_play.become

# Generated at 2022-06-21 00:57:27.969208
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # FIXME: Needs implementation
    raise NotImplementedError()



# Generated at 2022-06-21 00:57:33.729087
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    try:
        from ansible.plugins.loader import become_loader
    except:
        # assume plugins are not installed
        pass
    else:
        connection = PlayContext(play = None, passwords = None)
        assert connection is not None
        connection.set_become_plugin(become_loader.get('sudo'))
        assert connection._become_plugin.name == 'sudo'


# Generated at 2022-06-21 00:57:44.102975
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    p = PlayContext()
    vars = {}
    p.update_vars(vars)
    assert vars == {}

    p.connection = 'local'
    p.remote_user = 'root'
    p.update_vars(vars)
    assert vars == {'ansible_connection': 'local', 'ansible_user': 'root'}

    vars = {}
    p.no_log = False
    p.update_vars(vars)
    assert vars == {'ansible_connection': 'local', 'ansible_user': 'root', 'ansible_no_log': False}

    vars = {}
    p.become = True
    p.become_user = 'root'
    p.update_vars(vars)

# Generated at 2022-06-21 00:57:49.014084
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play_context = PlayContext(play=None)
    play = Play(
        name='test play',
        hosts=['test_host'],
        tasks=[],
        force_handlers=False,
        serial=1,
    )

    play_context.set_attributes_from_play(play=play)

    assert play_context.force_handlers is False

# Generated at 2022-06-21 00:57:53.853603
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    # create an instance of the PlayContext class and set the attributes of the play play
    play = Play()
    play.force_handlers = False

    test_obj = PlayContext(play=play)
    test_obj.set_attributes_from_play(play)

    assert test_obj.force_handlers == play.force_handlers

# Generated at 2022-06-21 00:58:04.598610
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pc = PlayContext()
    task = Task()
    task._role = None
    task.run_once = False
    task.remote_user = 'remote_user_test'
    task.delegate_to = None
    task.no_log = False
    task.any_errors_fatal = False
    task.dep_chain = None
    task.loop = None
    task.loop_args = []
    task.loop_var = None
    task.itervars = dict()
    task.items = []
    task.item_var = None
    task.item_label = None
    task.until = None
    task.retries = 3
    task.delay = 3

# Generated at 2022-06-21 00:58:43.740064
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    print("Test of method set_task_and_variable_override of class PlayContext")
    ###
    # Tests
    ###
    # Test 1: set_task_and_variable_override
    print("Test 1: set_task_and_variable_override")
    print("Expected:  {'connection': 'ssh', 'remote_addr': 'ansible-server.localdomain', 'remote_user': 'root'}")
    task = Task()
    task.delegate_to = 'ansible-server.localdomain'
    task.remote_user = 'root'
    play = Play()
    play.force_handlers = True

# Generated at 2022-06-21 00:58:57.138036
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-21 00:59:05.586768
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pc = PlayContext()
    p = Play().load(dict(
        name = "Ansible Play 2",
        hosts = 'web',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='debug', args=dict(msg='{{test_var}}')))
        ]
    ), variable_manager=VariableManager())
    task = p.tasks[0]
    vars = dict(test_var='TEST')
    pc.set_task_and_variable_override(task, vars, 'dummy')
    assert pc.remote_user == 'root'
    assert pc.port == 22
    assert pc._attributes['remote_addr'] == '{{inventory_hostname}}'



# Generated at 2022-06-21 00:59:18.955071
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # arrange
    play = Play().load(dict(
        name='test play',
        hosts={'all'},
        gather_facts='no'
    ), variable_manager=VariableManager(), loader=Mock())
    passwords = dict(
        conn_pass='1',
        become_pass='2'
    )
    connection_lockfd = 0
    connection = PlayContext(play, passwords, connection_lockfd)

    task = Task()
    task.action = 'setup'
    task.delegate_to = 'foo'
    task.remote_user = 'bar'
    task.timeout = 42
    task.check_mode = False
    task.diff = False


# Generated at 2022-06-21 00:59:21.577521
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    assert PlayContext.set_become_plugin == 'overridden_value'


# Generated at 2022-06-21 00:59:24.113898
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # FIXME: can't test this yet due to call to templar.template()
    pass

# Generated at 2022-06-21 00:59:38.116405
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = {'become': False, 'name': 'test_play', 'force_handlers': False}
    instance = PlayContext(play=play)
    assert instance.force_handlers == False
    assert instance.become == False
    assert instance.become_method == 'sudo'
    assert instance.become_user == 'root'
    assert instance.become_pass == ''
    assert instance.become_exe == '/bin/sudo'
    assert instance.become_flags == '-H'
    assert instance.prompt == ''
    assert instance.success_key == ''
    assert instance.connection_lockfd == None
    assert instance.verbosity == 0
    assert instance.only_tags == set()
    assert instance.skip_tags == set()
    assert instance.start_at_task == None

# Generated at 2022-06-21 00:59:41.673519
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():

    play_context = PlayContext()
    play_context.set_attributes_from_cli()
    play_context.network_os = 'junos'
    variables = {}
    play_context.update_vars(variables)

    assert variables == {'ansible_network_os': 'junos'}

# Generated at 2022-06-21 00:59:45.081115
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    play_context = PlayContext()
    variables = dict()
    play_context.update_vars(variables)
    # assert: should not raise an exception
    # assert: variables should be empty
    assert variables == dict()


# Generated at 2022-06-21 00:59:48.457326
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    class PlayContext_fixture(PlayContext):
        def __init__(self):
            pass


# Generated at 2022-06-21 01:00:53.594865
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play_context = PlayContext()
    play =  Play()
    play.force_handlers = True
    play_context.set_attributes_from_play(play)
    assert play_context.force_handlers == True

# Generated at 2022-06-21 01:00:57.630170
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    # Test PlayContext object creation
    p = PlayContext()

    # Test set_attributes_from_play method of PlayContext class
    p.set_attributes_from_play(play=Play())



# Generated at 2022-06-21 01:01:06.453420
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    test_instance = PlayContext(play=None, passwords=None, connection_lockfd=None)

    assert isinstance(test_instance, PlayContext) == True
    test_instance.set_attributes_from_cli()
    assert test_instance._verbosity == 0
    assert test_instance._only_tags == set()
    assert test_instance._skip_tags == set()
    assert test_instance._start_at_task is None


# Generated at 2022-06-21 01:01:07.981725
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    pass #  TODO

# Generated at 2022-06-21 01:01:21.326540
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # setup some dummy class as context.CLIARGS
    class DummyClass(object):
        def get(self, key, default):
            if key == 'start_at_task':
                return 'task to start at'
            elif key == 'timeout':
                return '120'
            elif key == 'verbosity':
                return 3
            elif key == 'private_key_file':
                return '/tmp/secret'
            else:
                return default

    context.CLIARGS = DummyClass()

    # test with no play provided
    playcontext = PlayContext()

    # test with a play object
    class dummy_play(object):
        def __init__(self):
            self.timeout = 45
            self.remote_user = 'some_user'

# Generated at 2022-06-21 01:01:29.377642
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    conn = Connection.new_connection()
    task = Task()
    task.connection = 'docker'
    conn_pass = '$ANSIBLE_NET_SSH_PASSWORD'
    passwords = dict(conn_pass=conn_pass)
    pc = PlayContext(play=task, passwords=passwords)
    pc.set_attributes_from_plugin(conn)
    assert pc.login_password == conn_pass
    assert pc.no_log == False


# Generated at 2022-06-21 01:01:42.173592
# Unit test for constructor of class PlayContext

# Generated at 2022-06-21 01:01:45.626160
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    '''
    Unit test for method set_become_plugin of class PlayContext
    '''
    pc = PlayContext()
    bp = dict()
    pc.set_become_plugin(bp)
    assert pc._become_plugin == bp



# Generated at 2022-06-21 01:01:52.369443
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    from ansible.module_utils.facts.system.distribution import DistributionFactModule
    from ansible.module_utils.facts.system.distribution import Distributor
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    import ansible.constants as C
    import ansible.module_utils.facts.virtual.base as BaseFactModule
    import pytest
    import copy
    import sys
    import os

    dist = DistributionFactModule()
    dist_data = dist.get_facts()
    with open('/etc/os-release') as os_release_file:
        os_release_content = os_release_file.readlines()
    #os_release_content = [b'NAME="CentOS Linux"\n', b'VERSION="7 (Core)"\n']
    os_release_dict

# Generated at 2022-06-21 01:01:55.552401
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # create a class object to test
    play_context = PlayContext()
    context.CLIARGS = {'timeout': '900'}
    play_context.set_attributes_from_cli()

    expected_timeout = 900
    expected_result = PlayContext()
    expected_result.timeout = expected_timeout
    assert play_context == expected_result
