

# Generated at 2022-06-21 00:53:29.473884
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # Nothing to test at the moment
    pass

# Generated at 2022-06-21 00:53:37.211532
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():

    import mock
    import unittest2
    from ansible.playbook.play import Play

    class TestPlayContextSetAttributesFromPlay(unittest2.TestCase):
        @mock.patch('ansible.utils.plugin_docs.get_action_class')
        @mock.patch('ansible.playbook.play.Play.load')
        @mock.patch('ansible.playbook.play.Play.serialize')
        def test_play_context_set_attributes_from_play_with_args(self, mock_serialize, mock_load, mock_get_action_class):
            play_context = PlayContext()
            play_context_set_attributes_from_play_results = PlayContext()

# Generated at 2022-06-21 00:53:43.659875
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    # TODO: Add some tests so this method is covered
    config = ConfigParser()
    config.add_section('ssh_connection')
    config.set('ssh_connection', 'ssh_args', '-o ControlMaster=auto -o ControlPersist=60s')
    config.set('ssh_connection', 'pipelining', 'True')
    ansible_cfg = C.config.load(config)
    context.CLIARGS = ImmutableDict(ansible_cfg)
    connection = 'local' 
    remote_addr = 'localhost' 
    network_os = '' 
    port = 22 
    remote_user = 'root'
    # FIXME: updated should be a dict
    updated = {'ansible_connection': 'local'} 
    obj = PlayContext()

    # TODO: need to add

# Generated at 2022-06-21 00:53:54.251194
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    lm_PlayContext = LmMock(PlayContext)
    lm_CLIARGS = LmMock(globals.CLIARGS)

    lm_CLIARGS.get = MagicMock(return_value=2)
    lm_PlayContext.set_attributes_from_cli()

    lm_CLIARGS.get = MagicMock(return_value="persist_test")
    lm_PlayContext.set_attributes_from_cli()

    lm_CLIARGS.get = MagicMock(return_value="tcp")
    lm_PlayContext.set_attributes_from_cli()


# Generated at 2022-06-21 00:53:56.549829
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    test_PlayContext = PlayContext(None, {}, None)
    test_PlayContext.set_attributes_from_plugin("ssh")
    assert test_PlayContext._attributes['connection'] == 'ssh'

# Generated at 2022-06-21 00:54:09.311599
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """
    Test set_attributes_from_plugin of PlayContext Class.
    :return:
    """

# Generated at 2022-06-21 00:54:20.456502
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pc = PlayContext()
    pc.set_attributes_from_plugin('copy')


# Generated at 2022-06-21 00:54:30.680821
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    # Setup and test object
    passwords = {u'become_pass': u'bogus'}
    c = PlayContext(passwords=passwords, connection_lockfd=9)
    test_id = u'ansible.module_utils.common.become.Sudo'
    plugin = {u'_load_name': test_id}
    c.set_become_plugin(plugin)

    # Test for attributes
    assert c._get_attr_become() is True # pylint: disable=protected-access
    assert c.become is True
    assert c.become_method == u'sudo'
    assert c.become_exe == u'sudo'
    assert c.become_user == u'root'
    assert c.become_pass == u'bogus'

# Generated at 2022-06-21 00:54:39.484162
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # PLAYCONTEXT_SET_ATTRIBUTES_FROM_CLI
    # set_attributes_from_cli: Configures this connection information instance with data from
    # options specified by the user on the command line. These have a
    # lower precedence than those set on the play or host.
    # PlayContext.set_attributes_from_cli() returns None.

    # FIXME: get_connection_type()
    # ssh_pass = options.ssh_pass
    # transport = get_connection_type()

    # NOTE: AnsibleOptions() is default
    # FIXME: connection related command line args
    # play_context.set_attributes_from_cli(options)
    assert True



# Generated at 2022-06-21 00:54:40.669640
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # FIXME: Write this unit test for class PlayContext method set_attributes_from_cli
    assert False

# Generated at 2022-06-21 00:55:16.537359
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = Play()
    context = PlayContext()

    # set random values
    play.connection = "smart"
    context.set_attributes_from_play(play=play)
    assert context.connection == "smart"
    play.connection = "paramiko"
    context.set_attributes_from_play(play=play)
    assert context.connection == "paramiko"
    play.connection = "local"
    context.set_attributes_from_play(play=play)
    assert context.connection == "local"
    play.connection = "ssh"
    context.set_attributes_from_play(play=play)
    assert context.connection == "ssh"
    play.force_handlers = False
    context.set_attributes_from_play(play=play)
    assert context.force_hand

# Generated at 2022-06-21 00:55:30.642464
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    task = Task()
    task.delegate_to = None
    task.check_mode = None
    task.diff = None
    task.no_log = None
    variables = {'ansible_port': 123,'ansible_host': 'test_host','ansible_user': 'test_user',
     'ansible_connection': 'test_connection','ansible_ssh_pass': 'test_ssh_pass','ansible_become': True,
     'ansible_become_method': 'test_become_method','ansible_become_user': 'test_become_user','ansible_become_pass': 'test_become_pass',
     'ansible_become_exe': 'test_become_exe','ansible_become_flags': 'test_become_flags'}
    templ

# Generated at 2022-06-21 00:55:31.830662
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    pass

# Generated at 2022-06-21 00:55:38.464302
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # This is a test to check if set_task_and_variable_override has all expected attributes
    play = {}
    passwords = {}
    connection_lockfd = {}
    hostinfo = PlayContext(play, passwords, connection_lockfd)
    assert hostinfo.set_task_and_variable_override(task = {}, variables = {}, templar = {})


# Generated at 2022-06-21 00:55:44.489747
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    # TODO: Implement unit test for stubbed functions PlayContext.set_attributes_from_play()
    #       Ensure that set_attributes_from_play() raises an exception whenever called
    assert False, "Implement me"


# Generated at 2022-06-21 00:55:56.473152
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    PythonPlugin('faked_connection',
                 {'DOCUMENTATION': 'This is a faked connection plugin',
                  'INVENTORY_HOSTNAME': 'string',
                  'USER': 'string',
                  'HOST': 'string',
                  'PORT': 'integer',
                  'PASSWORD': 'string'},
                 ["faked_connection"]
                 )
    mocked_connection = FakeConnection()
    pc = PlayContext(connection=mocked_connection)
    pc.set_attributes_from_plugin(mocked_connection)
    assert pc.user == "faked_user"
    assert pc.port == 12345

    # pylint: disable=line-too-long

# Generated at 2022-06-21 00:55:59.215800
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    task = None
    variables = {}
    templar = None

    new_info = play_context.set_task_and_variable_override(task, variables, templar)

# Generated at 2022-06-21 00:56:11.574407
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = Play()
    play.vars = dict(
        ansible_default_ipv4='v4',
        ansible_default_ipv6='v6',
        ansible_user='user',
        ansible_port='port',
        ansible_shell_type='shell_type',
        ansible_shell_executable='shell_executable',
        ansible_ssh_private_key_file='private_key_file',
        ansible_ssh_executable='executable',
        ansible_scp_executable='scp_executable',
        ansible_sftp_executable='sftp_executable',
        ansible_connection='connection',
    )
    play.force_handlers = 'force'

# Generated at 2022-06-21 00:56:13.648125
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    p = PlayContext()
    p.set_attributes_from_cli()

# Generated at 2022-06-21 00:56:15.048797
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    p1 = PlayContext()
    p1.set_attributes_from_cli()


# Generated at 2022-06-21 00:56:33.593107
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    assert True == True



# Generated at 2022-06-21 00:56:43.125800
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    mock_Class = Mock(spec=PlayContext)
    mock_self = mock_Class.return_value
    mock_plugin = Mock(spec=object)
    mock_plugin._load_name = 'test'
    mock_plugin.get_option = Mock(return_value='test')
    mock_config = Mock(spec=object)
    mock_config.get_configuration_definitions = Mock(return_value=True)

    with patch('ansible.utils.plugin_docs.get_plugin_class', return_value=mock_plugin), patch.object(C.config, 'get_configuration_definitions', return_value=mock_config):
        test_result = PlayContext.set_attributes_from_plugin(mock_self, mock_plugin)
        assert test.result == None



# Generated at 2022-06-21 00:56:48.150706
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    play = FakePlay()
    play_context = PlayContext(play)
    plugin = FakePlugin()
    play_context.set_become_plugin(plugin)
    assert play_context._become_plugin == plugin


# Generated at 2022-06-21 00:56:49.616997
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pass



# Generated at 2022-06-21 00:57:01.037261
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # initialize both objects; should be same
    set_attributes_from_cli_obj0 = PlayContext()
    set_attributes_from_cli_obj1 = PlayContext()

    # verify if both the objects are same
    assert set_attributes_from_cli_obj0 == set_attributes_from_cli_obj1

    # from above assert statement we can infer that both the objects are same

    # set values in obj0
    set_attributes_from_cli_obj0._attributes['timeout'] = 1
    set_attributes_from_cli_obj0._attributes['remote_user'] = 'user1'
    set_attributes_from_cli_obj0._attributes['port'] = 22
    set_attributes_from_cli_obj0._attributes['host_keys'] = None

    # set values

# Generated at 2022-06-21 00:57:10.048927
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    runner_mock = MagicMock()
    task_mock = MagicMock()
    loader_mock = MagicMock()
    templar_mock = MagicMock()

    pc_obj = PlayContext(runner_mock, task_mock, loader_mock, templar_mock)
    pc_obj.set_become_plugin(loader_mock)


# Generated at 2022-06-21 00:57:19.623192
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
  data = dict(paramiko='paramiko', ssh='ssh', docker='docker', winrm='winrm', network_cli='network_cli')
  play_context = PlayContext()
  play_context.set_attributes_from_cli()
  assert play_context.connection in data.values(), "Expected play_context.connection to return one of %s, got %s"%(data.values(),play_context.connection)


# Generated at 2022-06-21 00:57:23.542901
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    # config = ConfigParser.RawConfigParser()
    # assert config.sections() == []
    # config.read('ansible.cfg')
    assert True==True



# Generated at 2022-06-21 00:57:35.666777
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play = Dummy()
    passwords = Dummy()

    context = PlayContext(play, passwords, 1)  # connection_lockfd=1
    plugin = Dummy()
    context.set_attributes_from_plugin(plugin)
    assert context.port == plugin.port
    assert context.user == plugin.user


# =====
# plugin = Dummy()
# options = C.config.get_configuration_definitions(get_plugin_class(plugin), plugin._load_name)
# for option in options:
#     if option:
#         flag = options[option].get('name')
#         if flag:
#             assert getattr(context, flag) == plugin.get_option(flag)
#
# task.name = "setup"
# templar = Templar(loader=None, variables={})
# context.

# Generated at 2022-06-21 00:57:40.664526
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    PlayContext_Obj = PlayContext()
    PlayContext_Obj.become_plugin='plugin_example'
    set_become_plugin()
    assert PlayContext_Obj.become_plugin == 'plugin_example'

# Generated at 2022-06-21 00:58:02.556246
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    variables = {}
    c = PlayContext()
    c.update_vars(variables)
    assert variables['ansible_connection'] == 'ssh'
    assert variables['ansible_ssh_user'] is None
    assert variables['ansible_ssh_pass'] is None
    assert variables['ansible_ssh_port'] == 22



# Generated at 2022-06-21 00:58:09.599507
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plugin = get_plugin_class('command')()
    setattr(plugin, '_load_name', 'command')
    context = PlayContext()
    context.set_attributes_from_plugin(plugin)


if __name__ == '__main__':
    test_PlayContext_set_attributes_from_plugin()

# Generated at 2022-06-21 00:58:18.653140
# Unit test for constructor of class PlayContext
def test_PlayContext():
    """It should set default values when invoked with no parameters."""
    play_context = PlayContext()

    assert play_context.remote_addr == ''
    assert play_context.connection == 'smart'
    assert play_context.remote_user == 'root'
    assert play_context.port == None
    assert play_context.remote_pass == ''
    assert play_context.timeout == 10
    assert play_context.connection_user == 'root'
    assert play_context.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert play_context.pipelining == C.ANSIBLE_PIPELINING
    assert play_context.network_os == ''
    assert play_context.docker_extra_args == ''
    assert play_context.connection_lockfd == None

# Generated at 2022-06-21 00:58:20.710142
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context = PlayContext()
    assert isinstance(play_context, PlayContext)

# Generated at 2022-06-21 00:58:23.355175
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    """
    Test method set_task_and_variable_override of class PlayContext
    """
    pass

# Generated at 2022-06-21 00:58:30.110003
# Unit test for constructor of class PlayContext
def test_PlayContext():

    # test constructor of class PlayContext
    test_info = dict()
    test_info['connection'] = 'local'
    test_info['connection_host'] = ''
    test_info['connection_port'] = None
    test_info['connection_user'] = ''
    test_info['network_os'] = ''
    test_info['remote_addr'] = ''
    test_info['remote_user'] = 'test_user'
    test_info['remote_pass'] = 'test_pass'
    test_info['private_key_file'] = ''
    test_info['timeout'] = 10
    test_info['verbosity'] = 0
    test_info['no_log'] = False
    test_info['ssh_executable'] = 'ssh'
    test_info['scp_executable'] = 'scp'

# Generated at 2022-06-21 00:58:36.715452
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play = TestPlaybook()
    passwords = TestPasswords()
    connection_lockfd = TestConnectionLockFileDescriptor()
    play_context = PlayContext(play, passwords, connection_lockfd)
    play_context.set_attributes_from_cli()
    expected_value = 'sample_value'
    actual_value = play_context.timeout
    assert actual_value == expected_value


# Generated at 2022-06-21 00:58:38.116409
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    assert True is True


# Generated at 2022-06-21 00:58:42.620836
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play_instance = Play()
    play_instance.force_handlers = True
    play_context_instance = PlayContext(play=play_instance)
    assert play_context_instance.force_handlers == True

# Generated at 2022-06-21 00:58:50.121462
# Unit test for method update_vars of class PlayContext

# Generated at 2022-06-21 00:59:19.403824
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    """Test for method set_become_plugin of class PlayContext."""
    # test for jinja2 template error
    play = Play()
    play.vars = dict()
    play.vars['ansible_connection'] = 'local'
    pc = PlayContext(play=play)

# Generated at 2022-06-21 00:59:22.607416
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    PlayContext_inst=PlayContext()
    PlayContext_inst.set_attributes_from_plugin(C.config)


# Generated at 2022-06-21 00:59:27.622319
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    config.init_config()
    parser = config.get_config_parser()
    parser.read_dict(CONFIG_PARSER_DEFAULTS)
    args = parser.parse_args()
    args.timeout = "0"
    context.CLIARGS = args
    temp = PlayContext()
    attr_dict = temp.serialize()
    assert attr_dict == dict(timeout=0)


# Generated at 2022-06-21 00:59:28.903552
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
  play_context = PlayContext()
  assert play_context._become_plugin is None


# Generated at 2022-06-21 00:59:38.048231
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    '''
    None of the attributes of Task and variables should be None.
    None of the attributes of task should be set to the default value.
    None of the attributes of variables should be set to the default value.
    :return:
    '''
    task = Task()
    variables = {}
    templar = Templar()

    new_info = PlayContext()
    new_info.set_task_and_variable_override(task, variables, templar)
    assert new_info.connection is None

# Generated at 2022-06-21 00:59:47.232954
# Unit test for constructor of class PlayContext
def test_PlayContext():
    context = PlayContext()
    assert context.connection is None
    assert context.remote_addr is None
    assert context.remote_user is None
    assert context.password is None
    assert context.port is None
    assert context.private_key_file is None
    assert context.timeout is None
    assert context.shell is None
    assert context.network_os is None
    assert context.verbosity is None
    assert context.other_vars is None
    assert context.become is None
    assert context.become_method is None
    assert context.become_user is None
    assert context.become_pass is None
    assert context.become_exe is None
    assert context.become_flags is None
    assert context.become_plugin is None
    assert context.prompt is None
    assert context.success_

# Generated at 2022-06-21 00:59:53.515445
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    # set_attributes_from_play
    play = Play()
    play.force_handlers = True
    play_context = PlayContext(play=play)
    assert play_context.force_handlers, "Failed to set force_handlers from play"


# Generated at 2022-06-21 00:59:58.513337
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    env = dict()
    play = dict(vars=dict())
    instance = PlayContext(play)
    instance.set_attributes_from_play(play)
    assert play['vars'] ==  dict()


# Generated at 2022-06-21 01:00:01.846315
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    play_context = PlayContext(play=None, passwords=None, connection_lockfd=None)
    become_plugin = become_loader.get(None)()
    play_context.set_become_plugin(become_plugin)


# Generated at 2022-06-21 01:00:08.032680
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    my_instance = PlayContext()
    plugin = ConnectionBase()
    my_instance.set_attributes_from_plugin(plugin)

# Generated at 2022-06-21 01:00:48.779494
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    with pytest.raises(TypeError) as excinfo:
        # Unit test: TypeError is raised to make sure passing argument of wrong type class
        context = PlayContext(play=None, passwords=None, connection_lockfd=None)
        context.update_vars(7)
    assert "instance has no attribute 'items'" in str(excinfo.value)
    # Unit test: variables is a dictionary, the correct type of argument
    context = PlayContext(play=None, passwords=None, connection_lockfd=None)
    context.update_vars({})
    assert context


# Generated at 2022-06-21 01:00:55.244646
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    runner_mock = Mock()
    p = PlayContext(play=runner_mock)
    plugin_mock = Mock()
    p.set_become_plugin(plugin_mock)
    assert p._become_plugin == plugin_mock

# Generated at 2022-06-21 01:00:57.104616
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    set_become_plugin(self, plugin)


# Generated at 2022-06-21 01:01:03.013048
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    variables = {}
    pc = PlayContext()
    pc.update_vars(variables)
    assert variables == {'ansible_ssh_private_key_file': '~/.ssh/id_rsa', 'ansible_ssh_user': 'root'}

# Generated at 2022-06-21 01:01:07.589719
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    cls = im.get_instance_mock(PlayContext, {
        '_become_plugin': None
    })

    cls.set_become_plugin('fake')

    assert cls._become_plugin == 'fake'


# Generated at 2022-06-21 01:01:09.126743
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    pass


# Generated at 2022-06-21 01:01:13.582824
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Unit test for method set_attributes_from_plugin of class PlayContext
    '''
    pass

# Generated at 2022-06-21 01:01:17.943842
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    connection_plugin_test = PlayContext(play=None, passwords=None, connection_lockfd=None)
    connection_plugin_test.set_attributes_from_plugin('connection_plugin_test')

# Generated at 2022-06-21 01:01:23.574725
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    context.CLIARGS = dict(timeout=10)
    play_context=PlayContext()
    play_context.set_attributes_from_cli()
    assert play_context.timeout == 10

# Generated at 2022-06-21 01:01:27.782356
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play_obj = Play.load(dict(name="test play",
                              hosts=['all'],
                              gather_facts='no',
                              tasks=[dict(action=dict(module='debug', args=dict(msg='test message')))]))
    play_obj._injector = DictDataLoader({})
    play_obj._tqm = MagicMock(autospec=TaskQueueManager)

    play_context = PlayContext()
    play_context.set_attributes_from_play(play_obj)
    assert play_context.force_handlers == False

# Generated at 2022-06-21 01:02:45.892055
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    """ test_PlayContext_update_vars """
    variables = None
    my_PlayContext = PlayContext()
    variable_dict = my_PlayContext.update_vars(variables)
    assert variable_dict is None


# Generated at 2022-06-21 01:02:51.532059
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
   play = Play()
   templar = Templar(loader=None)
   task = Task()
   task.remote_user = "remote_user"
   task.delegate_to = "delegate_to"
   passwords = {}
   connection_lockfd = None
   pc = PlayContext(play, passwords, connection_lockfd)
   pc.set_task_and_variable_override(task, {}, templar)

# Generated at 2022-06-21 01:03:03.279855
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Update the value of each attribute to default and return the value to the attribute dictionary
    def reset_attribute_value_to_default(attribute_dict):
        for key, value in iteritems(attribute_dict):
            attribute_dict[key].default = attribute_dict[key].value
        return attribute_dict

    # Create a temporary object of class PlayContext and assign it to the temporary variable
    play_context_object = PlayContext()

    # Update the attribute dictionary with the default value of each attribute
    play_context_object.attribute_dict = reset_attribute_value_to_default(play_context_object.attribute_dict)

    # Update the plugin name to 'raw'
    plugin_name = 'raw'

    # Invoke the method set_attributes_from_plugin of class PlayContext to update the value of each attribute
    play_context_

# Generated at 2022-06-21 01:03:10.914301
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Setup
    test_object = PlayContext()
    fake_plugin = {
        "setup_connections": "exit 0",
        "transport": "fake_transport"
    }

    test_object.set_attributes_from_plugin(fake_plugin)

    assert test_object._connection == "fake_transport"
    assert test_object._setup_connections == "exit 0"
