

# Generated at 2022-06-21 00:53:23.618280
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # PlayContext.set_task_and_variable_override() # TODO: may need to mock /stub: playbook.templar.template(task.delegate_to)
    pass

# Generated at 2022-06-21 00:53:26.267107
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    from unittest.mock import patch
    c = PlayContext()
    c.set_become_plugin('become_plugin')
    assert c._become_plugin == 'become_plugin'


# Generated at 2022-06-21 00:53:32.746870
# Unit test for constructor of class PlayContext
def test_PlayContext():
    pass
#>>> pytest tests/unit/test_play_context.py -v
#====================================== test session starts =========================================
#platform linux2 -- Python 2.7.5 -- py-1.4.30 -- pytest-2.7.2
#rootdir: /Users/atticus/dev/ansible/ansible, inifile:
#collected 1 items
#
#tests/unit/test_play_context.py::test_PlayContext PASSED
#
#============================= 1 passed in 0.01 seconds =========================

# Generated at 2022-06-21 00:53:39.340791
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    p = PlayContext()

    variables = dict()
    p.update_vars(variables)
    assert set(variables.keys()) == set(['ansible_host', 'ansible_port', 'ansible_user', 'ansible_connection', 'ansible_ssh_port', 'ansible_ssh_user', 'ansible_ssh_host', 'ansible_ssh_pass', 'ansible_ssh_extra_args', 'ansible_sftp_extra_args', 'ansible_scp_extra_args', 'ansible_ssh_private_key_file', 'ansible_ssh_common_args', 'ansible_ssh_executable', 'ansible_shell_type', 'ansible_shell_executable', 'ansible_python_interpreter', 'ansible_winrm_server_cert_validation'])

# Generated at 2022-06-21 00:53:51.928150
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    t1 = Task()
    t1.become = True
    t1.become_user = 'bob'
    t1.become_method = 'sudo'
    t1.delegate_to = 'localhost'
    v1 = dict()
    v1['ansible_connection'] = 'local'
    v1['ansible_become_user'] = 'bob'
    v1['ansible_become_pass'] = 'bob_pass'
    v1['ansible_become_method'] = 'sudo'
    v1['ansible_remote_user'] = 'alice'
    v1['ansible_host'] = 'localhost'
    v1['ansible_user'] = 'alice'
    v1['ansible_port'] = '22'

# Generated at 2022-06-21 00:54:01.036061
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    # create an instance of the class to be tested
    context = PlayContext()

    # create a dictionary, set the context by using set_attributes_from_play,
    # set connection, set connection_user, set host_ip, set remote_user
    pdict = {'connection': 'ssh', 'connection_user': 'ansible', 'host_ip': '10.20.30.40', 'remote_user': 'user'}
    context.set_attributes_from_play(pdict)

    # create a dictionary that includes connection, connection_user, host_ip, remote_user.
    vdict = {}

    # call the method being tested
    context.update_vars(vdict)

    # verify whether the result is correct

# Generated at 2022-06-21 00:54:13.928210
# Unit test for constructor of class PlayContext
def test_PlayContext():
    PLAY_DS = dict(
        name="test_play",
        hosts="all",
        gather_facts="no",
        user="test_user",
        connection="test_connection"
    )
    PASSWORDS = dict(
        conn_pass="test_conn_pass",
        become_pass="test_become_pass"
    )
    play = Play().load(PLAY_DS, variable_manager=VariableManager(), loader=DictDataLoader())

    play_context = PlayContext(play=play, passwords=PASSWORDS)

    assert play_context.remote_user == "test_user"
    assert play_context.connection  == "test_connection"
    assert play_context.password == "test_conn_pass"
    assert play_context.become_pass == "test_become_pass"

# Generated at 2022-06-21 00:54:20.207567
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-21 00:54:26.120461
# Unit test for constructor of class PlayContext
def test_PlayContext():
    args = {
        'host_list':['test1', 'test2', 'test3'],
        'remote_user':'testuser',
        'connection':'local'
    }
    play_context = PlayContext(**args)
    assert play_context.host_list == ['test1', 'test2', 'test3']
    assert play_context.remote_user == 'testuser'
    assert play_context.connection == 'local'

# Generated at 2022-06-21 00:54:38.526028
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    import ansible.module_utils.network.nios

    mock_task = Mock()
    mock_task.__dict__['_attributes'] = {'connection': 'smart', 'ansible_port': '1234', 'ansible_user': 'test_user'}
    mock_task.__dict__['remote_user'] = None
    mock_task.__dict__['delegate_to'] = 'delegated_host'


# Generated at 2022-06-21 00:54:57.403536
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # testing the set_attributes_from_cli with different timeout value, it should return
    # respective timeout value
    
    context.CLIARGS = {'timeout' : 5}
    play_context = PlayContext()
    play_context.set_attributes_from_cli()
    assert play_context.timeout == 5

    context.CLIARGS = {'timeout' : None}
    play_context = PlayContext()
    play_context.set_attributes_from_cli()
    assert play_context.timeout == C.DEFAULT_TIMEOUT


# Generated at 2022-06-21 00:55:02.359432
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    play_context = PlayContext(play=Play())

    assert play_context._become_plugin is None

    play_context.set_become_plugin('sudo')

    assert play_context._become_plugin == 'sudo'


# Generated at 2022-06-21 00:55:06.629154
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play = Play()
    play_context = PlayContext(play, passwords=None, connection_lockfd=None)
    play_context.set_attributes_from_cli()


# Generated at 2022-06-21 00:55:08.693220
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context_instance = PlayContext()
    play_context_instance.__init__()

# Generated at 2022-06-21 00:55:17.379007
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    for cls_name in ["LocalConnection", "SshConnection", "WinrmConnection"]:
        m = module_loader.get_plugin_class(C.BLACKLIST, cls_name)
        plugin = m(cls_name, None, task_uuid = 'dummy')
        pc = PlayContext()
        pc.set_attributes_from_plugin(plugin)
        assert getattr(pc, 'connection') == cls_name.lower()



# Generated at 2022-06-21 00:55:31.116603
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    # No vars set, they should all be set
    context = PlayContext()
    context.remote_addr = '1.2.3.4'
    context.remote_user = 'test_user'
    context.port = 22
    context.password = 'test_pass'
    context.become = True
    context.become_method = 'sudo'
    context.become_user = 'test_root'
    context.become_pass = 'test_root_pass'
    context.become_exe = 'sudo'
    context.become_flags = '-H'
    context.prompt = '[sudo via ansible, key=value] password:'
    context.success_key = 'BECOME-SUCCESS-'
    context.timeout = 10
    context.su = True
    context.su_user

# Generated at 2022-06-21 00:55:32.456950
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # set_task_and_variable_override(self, task, variables, templar=None)
    # TODO: test
    pass


# Generated at 2022-06-21 00:55:41.449700
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    conn_plugin =  get_plugin_class('basic_connection')()
    opts = C.config.get_configuration_definitions(get_plugin_class('basic_connection'), 'basic_connection').copy()
    opts.pop('cache')
    conn_plugin.set_options(opts)

    play = mock.MagicMock()
    pc = PlayContext(play)
    pc.set_attributes_from_plugin(conn_plugin)

    for k, v in opts.items():
        val = v['default']
        if val:
            if not isinstance(val, string_types):
                continue
            if '{{' in val and '}}':
                continue
            assert getattr(pc, k) == val



# Generated at 2022-06-21 00:55:51.204301
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    '''Unit test for method update_vars of class PlayContext'''
    ####
    # init args
    ####
    # play=None, passwords=None, connection_lockfd=None
    ####
    # init return values
    ####
    # self
    ####
    # placeholders
    ####
    play = None
    passwords = None
    connection_lockfd = None
    ####
    # class init
    ####
    play_context = PlayContext(play, passwords, connection_lockfd)
    # properties
    ####
    # _play = FieldAttribute(isa='play')
    # _remote_addr = FieldAttribute(isa='string')
    # _remote_user = FieldAttribute(isa='string')
    # _port = FieldAttribute(isa='int')
    # _remote_pass =

# Generated at 2022-06-21 00:56:01.807663
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # create a "PlayContext"
    my_class = PlayContext()
    # loader for vars
    my_class.loader = DictDataLoader({})
    # variables from inventory
    my_class.variables = get_vars({}, [])
    # command line args
    C.CLIARGS = {'start_at_task': None, 'private_key_file': '', 'timeout': 30}
    # create a "Play" object
    my_play = Play()
    # create a "Task"
    my_play.tasks.append(Task())
    # set up the stuff
    my_class.set_attributes_from_play(my_play)
    my_class.set_attributes_from_cli()
    # get the actual result
    result = my_class.set_task_and

# Generated at 2022-06-21 00:56:36.409902
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    _task = Mock
    _variables = Mock
    _templar = Mock
    result = play_context.set_task_and_variable_override(_task, _variables, _templar)
    assert type(result) == PlayContext

# Generated at 2022-06-21 00:56:44.763137
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    """
    Test case for PlayContext.set_task_and_variable_override
    """
    # Mock the PlayContext object
    play_context_test = PlayContext()

    # Create some constants.
    USER = C.MAGIC_VARIABLE_MAPPING.get('remote_user')[0]
    REMOTE_ADDR_DEFAULT = C.MAGIC_VARIABLE_MAPPING.get('remote_addr')[0]

    # Mock a templar object.
    templar_test = MagicMock()
    templar_test.template.return_value = 'test_delegate_to'

    # Mock a task object.
    task_test = MagicMock()
    task_test.delegate_to = C.MAGIC_VARIABLE_MAPPING.get

# Generated at 2022-06-21 00:56:47.920815
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play_context = PlayContext(play=None)
    play = Play()
    play_context.set_attributes_from_play(play)


# Generated at 2022-06-21 00:56:51.458914
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    test_instance = PlayContext()
    test_instance.set_become_plugin(None)
    pytest.fail('An error should be raised')

# Generated at 2022-06-21 00:57:01.616337
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    PlayContext.instance = None
    hostvars = dict(
        ansible_ssh_user = "ssh_user",
        ansible_ssh_pass = "ssh_pass",
        ansible_ssh_port = "ssh_port",
        ansible_ssh_extra_args = "ssh_extra_args",
        ansible_shell_type = "shell_type",
        ansible_shell_executable = "shell_executable",
        ansible_become_method = "become_method",
        ansible_become_user = "become_user",
        ansible_become_pass = "become_pass",
        ansible_become_exe = "become_exe",
        ansible_become_flags = "become_flags")
    task2 = Task()
    task2._attributes

# Generated at 2022-06-21 00:57:10.066223
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    original_fixture_path = context.FIXTURE_DIR

# Generated at 2022-06-21 00:57:10.929605
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    assert (True)


# Generated at 2022-06-21 00:57:24.803186
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.connection.netconf import Connection
    from ansible.module_utils.connection import Connection as ConnectionUtil

    # set up
    options = Connection.get_option_names()
    details = C.config.get_configuration_definitions('connection', 'netconf')
    plug = Connection('netconf')
    ctx = PlayContext()
    ctx.set_attributes_from_plugin(plug)

    # make sure options are set
    for o in options:
        assert hasattr(ctx, o)

    # make sure they are set correctly
    for o in details:
        if o == 'network_os':
            continue
        assert getattr(ctx, o) == details[o]['default']



# Generated at 2022-06-21 00:57:28.364508
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    variables = dict()
    play_context = PlayContext(play=None)
    play_context.update_vars(variables)


# Generated at 2022-06-21 00:57:34.607619
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    variables = {}
    play_context = PlayContext()
    play_context.set_attributes_from_cli()
    play_context.update_vars(variables)
    assert variables['ansible_connection'] == 'local'
    assert variables['ansible_diff_mode'] == 'dst'
    assert variables['ansible_python_interpreter'] == '/usr/bin/env python'
    assert variables['ansible_user'] == 'root'



# Generated at 2022-06-21 00:58:37.634871
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    # Need to call the constructor from the class to allow init to be called
    play = Play()
    play.force_handlers = True
    model = PlayContext(play)
    model.set_attributes_from_play(play)

    # force_handlers is the only field that should be set
    assert model.force_handlers == True
    assert model.enable_handlers == None
    assert model.diff == None
    assert model.verbosity == None
    assert model.timeout == None
    assert model.only_tags == None
    assert model.skip_tags == None
    assert model.become == None
    assert model.become_user == None
    assert model.become_pass == None
    assert model.become_method == None
    assert model.connection == None
    assert model.remote_addr == None


# Generated at 2022-06-21 00:58:46.478034
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    from collections import namedtuple
    Options = namedtuple('Options', ['ask_pass'])
    options = Options(ask_pass=False)
    config = namedtuple('config', ['become_user', 'become_method', 'become_ask_pass', 'become_ask_pass', 'ask_pass'])
    config = config(become_user = "test", become_method = "su", become_ask_pass = True, become_ask_pass = True, ask_pass = True)
    become_plugin = Become()
    #play_context = PlayContext(play=None, passwords=None, connection_lockfd=None)
    play_context = PlayContext()
    play_context.set_become_plugin(become_plugin)
    assert True == True

    # Unit test for method set_task_

# Generated at 2022-06-21 00:58:51.561682
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    PlayContext._get_attr_connection = MagicMock(return_value='local')
    playcontext = PlayContext()
    playcontext.set_attributes_from_plugin(dict())


# Generated at 2022-06-21 00:58:52.624966
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    pass

# Generated at 2022-06-21 00:58:54.954597
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play_args = {}
    pc = PlayContext(play=play_args)
    assert pc.force_handlers == False



# Generated at 2022-06-21 00:59:04.714867
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    play_context = PlayContext()
    play_context.set_attributes_from_cli()
    play_context.set_attributes_from_play(play={"hosts": "testhost"})
    variables = {}
    play_context.update_vars(variables)
    assert variables["ansible_ssh_user"] == "root"
    assert variables["ansible_connection"] == "ssh"
    assert variables["ansible_port"] == 22
    assert variables["ansible_user"] == "root"


# Generated at 2022-06-21 00:59:18.450234
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    from ansible.playbook.play import Play
    from ansible.constants import C
    from ansible.executor.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import connection_loader

    p = Play()
    pc = PlayContext(p)

    loader = connection_loader

    # 'None' used for argument connection_lockfd of method __init__ of class PlayContext
    pc = PlayContext(p, None)

    # 'None' used for argument connection_lockfd of method __init__ of class PlayContext
    pc = PlayContext(p)

    # 'None' used for argument play of method __init__ of class PlayContext
    pc = PlayContext(None, None)

    # 'None' used for argument passwords of method __init__ of

# Generated at 2022-06-21 00:59:23.550508
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    global __password
    obj = PlayContext(play=_fake_play())
    assert obj.become_pass == ''
    obj.set_become_plugin(None)
    obj.set_become_plugin(_fake_become_plugin())
    __password = 'password_t'
    assert obj.become_pass == 'password_t'


# Generated at 2022-06-21 00:59:37.629836
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context=PlayContext()
    context.CLIARGS={'password':'some_password', 'start_at_task':'some_task', 'timeout':'some_timeout', 'private_key_file':'some_private_key_file', 'verbosity':'3'}
    play_context.set_attributes_from_cli()
    assert play_context.start_at_task == 'some_task'
    assert play_context.private_key_file == 'some_private_key_file'
    assert play_context.timeout == 'some_timeout'
    assert play_context.private_key_file == 'some_private_key_file'
    assert play_context.verbosity == '3'
    context.CLIARGS={}
    play_context.set_attributes_from_cli()


# Generated at 2022-06-21 00:59:42.914776
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    # Testing method PlayContext.set_become_plugin of class PlayContext
    args = dict()

    p = Play()
    c = PlayContext(play=p)
    c.set_become_plugin(None)
    assert p
    assert c



# Generated at 2022-06-21 01:01:29.377279
# Unit test for constructor of class PlayContext
def test_PlayContext():
    context = PlayContext()
    assert context.verbosity == 0
    assert context.only_tags == set()
    assert context.skip_tags == set()
    assert context.become is False
    assert context.become_method is None
    assert context.become_user is None
    assert context.become_pass is None
    assert context.start_at_task is None
    assert context.step is False
    assert context.force_handlers is False

# Generated at 2022-06-21 01:01:42.175432
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # create a test PlayContext object
    pc = PlayContext()

    # create a test Task object
    test_task = Task()

    # create a test AnsibleVariableManager object and add some variables
    test_variables = AnsibleVariableManager()
    test_variables.add_host_vars({"variables": {"var1": "value1", "var2": "value2"}})
    
    # test the method
    assert (pc.set_task_and_variable_override(test_task, test_variables, Templar()) == pc)
    #dict of pc attributes
    pc_attributes = {attr: getattr(pc, attr) for attr in vars(pc) if attr[0] != '_'}
    #dict of test_variables attributes

# Generated at 2022-06-21 01:01:49.395751
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Testing overriding task attribute
    task = _Task()
    task._attributes['delegate_to'] = 'delegated'
    variables = {}

    pc = PlayContext(None)
    pc = pc.set_task_and_variable_override(task, variables, Templar())
    assert pc._attributes['delegate_to'] == 'delegated'

    # Testing overriding based on inventory_hostname
    task = _Task()
    task._attributes['remote_user'] = 'root'
    variables = {'ansible_ssh_user': 'admin'}
    pc = PlayContext(None)
    pc = pc.set_task_and_variable_override(task, variables, Templar())
    assert pc.remote_user == 'admin'

    # Testing with a delegated host

# Generated at 2022-06-21 01:02:01.169043
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    '''
    Test to execute method set_attributes_from_play of class PlayContext.
    '''
    json_data = '{"remote_addr":"1.1.1.1","remote_user":"1","port":22}'
    data=json.loads(json_data)
    play_object = Play().load(data, variable_manager=VariableManager(), loader=DataLoader())
    play_context_object = PlayContext()
    play_context_object.set_attributes_from_play(play_object)


# Generated at 2022-06-21 01:02:12.487029
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    context._init_global_context(config=None)
    variables = dict()
    context.CLIARGS = dict(become=True,become_method='su',become_user='root',remote_user='ansible-ssh')
    playcontext_object = PlayContext(play=Play("play"),passwords=dict(conn_pass="connpass",become_pass="becomepass"))
    playcontext_object.update_vars(variables)
    assert playcontext_object.remote_user == 'ansible-ssh'
    assert playcontext_object.connection == 'ssh'
    assert playcontext_object.become == True
    assert playcontext_object.become_method == 'su'
    assert playcontext_object.become_user == 'root'

# Generated at 2022-06-21 01:02:24.603190
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    import mock
    import test.support.ansible_runner
    import test.support.ansible_playbook_mock
    import test.support.connection_mock
    import test.support.plugins_mock
    import test.support.lib_mock
    from ansible import constants as C
    from ansible.plugins.loader import get_become_plugin
    from ansible.playbook.play_context import PlayContext


    conn_mock = test.support.connection_mock.ConnectionMock()
    plugin_mock = test.support.plugins_mock.PluginMock()
    pb_mock = test.support.ansible_playbook_mock.PlaybookRunnerMock()
    become_plugin = get_become_plugin(C.DEFAULT_BECOME_METHOD)
    become_plugin

# Generated at 2022-06-21 01:02:31.086219
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    context = ansible.context.CLIARGS = ImmutableDict()
    context.become = False
    context.become_method = "sudo"
    context.become_user = "root"
    context.become_pass = ""
    context.connection = "ssh"
    context.timeout = 10
    context.verbosity = 0
    context.start_at_task = ""

    p = PlayContext()
    p._become_plugin = "foo"
    p.set_become_plugin("bar")

    assert p._become_plugin == "bar"


# Generated at 2022-06-21 01:02:41.603957
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """ Unit test for set_attributes_from_plugin of class PlayContext """

    ###########################################################################
    #
    #   This is a test for the set_attributes_from_plugin of PlayContext
    #
    #   Here is the test plan:
    #
    #   1. Initialize a PlayContext
    #   2. First test if the plugin was loaded and return if there was no plugin
    #   3. Get the options from the plugin
    #   4. Test if the options are valid and if not there is no need to set attributes
    #   5. Test if there was a flag for options and if not there is no need to set attributes
    #   6. Check if the attributes were set correctly
    #
    ###########################################################################

    ansible_object = AnsibleModule(argument_spec=dict())
    ansible_

# Generated at 2022-06-21 01:02:49.434292
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Test function for PlayContext set_attributes_from_cli
    context.CLIARGS = dict(timeout=10, verbosity=4, private_key_file="~/.ssh/id_rsa")
    with pytest.raises(NotImplementedError) as exec_info:
        new_pc = PlayContext()
        new_pc.set_attributes_from_cli()


# Generated at 2022-06-21 01:02:53.685373
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    # PlayContext.update_vars() ==> None
    assert PlayContext().update_vars() == None
    
    