

# Generated at 2022-06-21 00:53:46.115760
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    hostvars = dict()

    p = PlayContext()
    p.connection = 'smart'
    p.remote_user = 'remote_user'
    p.port = 2222
    p.remote_addr = '127.0.0.1'
    p.private_key_file = '/home'
    p.timeout = 1
    p.update_vars(hostvars)

    assert hostvars == dict(ansible_port=2222, ansible_user=u'remote_user', ansible_ssh_private_key_file='/home', ansible_connection='ssh', ansible_timeout=1, ansible_host='127.0.0.1')



# Generated at 2022-06-21 00:53:57.177276
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    '''
    PlayContext.set_task_and_variable_override
    '''

    options = {
        'connection': 'local', 'module_path': '/home/pratik/.ansible/plugins/modules', 'forks': 5, 'remote_user': 'pratik',
        'private_key_file': None, 'ssh_common_args': '', 'ssh_extra_args': '', 'sftp_extra_args': '',
        'scp_extra_args': '', 'become': False, 'become_method': 'sudo', 'become_user': 'pratik', 'verbosity': None,
        'check': False, 'listhosts': None, 'listtasks': None, 'listtags': None, 'syntax': None, 'start_at_task': None
    }



# Generated at 2022-06-21 00:54:03.047771
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Test if the variable 'new_info' is generated correctly when calling method set_attributes_from_plugin()
    play_context = PlayContext()
    plugin = 'local'
    new_info = play_context.set_attributes_from_plugin(plugin)
    assert play_context.new_info == new_info


# Generated at 2022-06-21 00:54:12.396440
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    '''
    PlayContext - update_vars
    '''
    play_context = PlayContext()
    variables = dict()
    play_context.update_vars(variables)
    assert len(variables) == 0

    play_context = PlayContext()
    variables = dict()
    play_context.update_vars(variables)
    assert len(variables) == 0

    play_context = PlayContext()
    variables = dict()
    play_context.update_vars(variables)
    assert len(variables) == 0


# Generated at 2022-06-21 00:54:18.436520
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play = FakePlay()
    play.vars = dict(a=1, b=2)

    pc = PlayContext(play, dict(conn_pass='foo', become_pass='bar'))

    assert pc.password == 'foo'
    assert pc.become_pass == 'bar'

    # test if play vars copied
    assert pc.a == 1
    assert pc.b == 2

# Generated at 2022-06-21 00:54:20.496526
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plugin = PlayContext()
    cls = PlayContext.set_attributes_from_plugin
    cls(plugin)


# Generated at 2022-06-21 00:54:21.071918
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    pass

# Generated at 2022-06-21 00:54:21.666853
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pass

# Generated at 2022-06-21 00:54:24.620935
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    d = PlayContext(play=dict())
    os = None
    d.set_become_plugin(sys.modules[__package__+'.'+os])



# Generated at 2022-06-21 00:54:26.047600
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # FIXME: Write a unit test
    return


# Generated at 2022-06-21 00:55:14.048143
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # Check for defaults
    play_context = PlayContext()
    assert play_context.remote_addr == ''
    assert play_context.port == None
    assert play_context.remote_user == 'root'
    assert play_context.connection == 'smart'
    assert play_context.timeout == 10
    assert play_context.network_os == ''

    # Check for original attributes
    play_context = PlayContext(C.DEFAULT_REMOTE_PORT, 'test_user', 'ssh')
    assert play_context.remote_addr == ''
    assert play_context.port == C.DEFAULT_REMOTE_PORT
    assert play_context.remote_user == 'test_user'
    assert play_context.connection == 'smart'
    assert play_context.timeout == 10
    assert play_context.network_os == ''

# Generated at 2022-06-21 00:55:20.719811
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    args = {'timeout': '10', 'private_key_file': '~/.ssh/private_key_file', 'verbosity': '5', 'start_at_task': 'yes'}
    context.CLIARGS = args
    play_context = PlayContext()
    play_context.set_attributes_from_cli()
    args['timeout'] = 10
    args['verbosity'] = 5
    assert context.CLIARGS == args
    assert play_context.timeout == 10
    assert play_context.private_key_file == '~/.ssh/private_key_file'
    assert play_context.verbosity == 5
    assert play_context.start_at_task == 'yes'

# Generated at 2022-06-21 00:55:23.829697
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    PlayContext#set_attributes_from_plugin
    '''
    pass

# Generated at 2022-06-21 00:55:27.497198
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    temp_instance = PlayContext()
    # TODO implement this
    # temp_instance.set_attributes_from_plugin(self, plugin)
    return None

# Generated at 2022-06-21 00:55:38.974444
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    pc = PlayContext()
    play = Play().load({
        'hosts': 'all',
        'gather_facts': 'no',
        'remote_user': 'bob',
        'connection': 'local',
    }, variable_manager=VariableManager())

    pc.set_attributes_from_play(play)

    assert pc.gather_facts == 'no'
    assert pc.remote_user == 'bob'
    assert pc.connection == 'local'

    with pytest.raises(Exception):
        pc.set_attributes_from_play(None)

# Generated at 2022-06-21 00:55:42.683684
# Unit test for constructor of class PlayContext
def test_PlayContext():
    playcontext = PlayContext()
    assert playcontext.remote_addr == '127.0.0.1'

# Generated at 2022-06-21 00:55:48.285766
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # test __init__()
    play_context = PlayContext(play=True)
    assert play_context.password == ''
    assert play_context.become_pass == ''
    assert play_context.prompt == ''
    assert play_context.success_key == ''

# Generated at 2022-06-21 00:55:59.087722
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    mocked_task = mock.MagicMock()
    mocked_task.delegate_to = 'localhost'
    mocked_task.remote_user = 'test_user'
    mocked_task.tags = set()
    mocked_task.become = False
    mocked_task.become_user = 'test_become'
    mocked_task.delegate_facts = None
    mocked_task.check_mode = None
    mocked_task.diff = None

    mocked_templar = mock.MagicMock()
    mocked_templar.template.return_value='localhost'
    mocked_context = PlayContext()
    mocked_context.connection = 'smart'
    mocked_context.remote_user = 'test_user'
    mocked_context.transport = 'paramiko'
    mocked_context.become = True
   

# Generated at 2022-06-21 00:56:00.781283
# Unit test for constructor of class PlayContext
def test_PlayContext():
    assert PlayContext()._attributes == {}


# Generated at 2022-06-21 00:56:07.752650
# Unit test for constructor of class PlayContext
def test_PlayContext():
    '''
    Unit test for constructor of class PlayContext
    '''
    passwords = {'conn_pass': 'secret', 'become_pass': 'secret'}
    play_context = PlayContext(passwords=passwords)
    assert play_context.password == 'secret'
    assert play_context.become_pass == 'secret'

# Generated at 2022-06-21 00:57:13.234516
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar

    variables = {'inventory_hostname': 'foo'}

    play = Play()
    play.hosts = 'all'
    play.force_handlers = False

    play._ds = {'name': 'test play',
                'hosts': 'all',
                'gather_facts': 'no',
                'tasks': [
                    {'action': {'module': 'foo', 'args': 'bar'}}
                ]}

    task = Task()
    task._load_data(play._ds['tasks'][0])

    templar = Templar(loader=None, variables=variables)

    # test for all the 'MAGIC_VARIABLE_MAPPING'

# Generated at 2022-06-21 00:57:15.405903
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    pass # TODO: implement your test here


# Generated at 2022-06-21 00:57:26.976445
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    attr = 'connection'
    attrs_considered = [attr]
    C.MAGIC_VARIABLE_MAPPING = {
        attr: ['ansible_ssh_host', 'ansible_host']
    }

    # create a task object
    task_obj = MagicMock()
    task_obj.connection = None

    # create variables
    variables = dict()
    variables['ansible_ssh_host'] = '10.0.0.1'
    variables['ansible_host'] = '10.0.0.1'

    # create PlayContext instance
    mock_play = MagicMock()
    ctx = PlayContext(play=mock_play)

    # check before set_task_and_variable_override
    assert getattr(ctx, attr) is None

    # set value

# Generated at 2022-06-21 00:57:38.265028
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.loader import connection_loader
    connection_plugin_name = "paramiko"
    plugin_connection_mocking = {}
    conn_instance = connection_loader.get(connection_plugin_name, cls=ConnectionBase)
    plugin_connection_mocking["_attributes"] = {"host": "localhost", "port": 3306, "user": "testuser", "password": "testpass"}
    conn_instance.set_options(plugin_connection_mocking)
    play_context = PlayContext()
    play_context.set_attributes_from_plugin(plugin = conn_instance)
    assert play_context.connection == connection_plugin_name
    assert play_context.host == "localhost"


# Generated at 2022-06-21 00:57:46.402875
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
  import json
  # Now stubs for different methods of class PlayContext:
  class PlayContextStub:
    def set_attributes_from_play(self, play):
      pass
    def copy(self):
      return new_info_stub
  class PlayStub:
    force_handlers = False
  class templarStub:
    def template(self, task_delegate_to):
      return delegated_host_name
  new_info_stub = PlayContextStub()
  # The test starts here:
  context.CLIARGS = {'timeout':10}
  task = PlayStub()
  play = PlayStub()
  variables = {'a': 1, 'b': 2}
  templar = templarStub()

# Generated at 2022-06-21 00:57:50.448857
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """
    Test case to validate PlayContext.set_attributes_from_plugin
    """
    # setup test
    test_obj = PlayContext()
    test_obj.set_attributes_from_plugin("test_obj")
    assert test_obj == dict()


# Generated at 2022-06-21 00:57:57.992028
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    config = configparser.ConfigParser()
    config.read('test/integration/ansible.cfg')
    config.read('test/integration/hosts')

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-21 00:57:59.449041
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # TODO
    pass


# Generated at 2022-06-21 00:58:08.570636
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    plugin = None
    task = Mock()
    variables = {}
    templar = Mock()
    obj = PlayContext(plugin, task, variables, templar)
    for attr in TASK_ATTRIBUTE_OVERRIDES:
        getattr(task, attr, None)
    for (attr, variable_names) in iteritems(C.MAGIC_VARIABLE_MAPPING):
        for variable_name in variable_names:
            if attr in attrs_considered:
                continue
            # if delegation task ONLY use delegated host vars, avoid delegated FOR host vars
            if task.delegate_to is not None:
                delegated_vars = variables.get('ansible_delegated_vars', dict()).get(delegated_host_name, dict())

# Generated at 2022-06-21 00:58:09.752258
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # TODO: Implement unit test
    pass


# Create a class, so that we can subclass it from Python to easily create mock objects

# Generated at 2022-06-21 01:00:05.195221
# Unit test for constructor of class PlayContext
def test_PlayContext():

    # create a play
    play = Play().load({
        'name': 'foobar',
        'connection': 'local',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'action': {'module': 'shell', 'args': 'ls'}}
        ]
    }, variable_manager=VariableManager())

    # create a PlayContext
    pc = PlayContext(play)

    # check if play context is valid
    assert pc is not None



# Generated at 2022-06-21 01:00:18.883288
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    # create a mock plugin object
    plugin = type('plugin_mock', (), {
        'get_option': lambda self, option: option
    })()

    # set ansible variables
    context.CLIARGS = { 'host_key_checking': True }

    # create a task
    task = type('task_mock', (), {
        'connection': 'local',
        'delegate_to': None
    })()

    # create a play
    play = type('play_mock', (), {
        'force_handlers': False
    })()

    # create variables

# Generated at 2022-06-21 01:00:25.253544
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    p = Play()
    p.connection = "local"
    pc = PlayContext(play=p)
    pc.set_attributes_from_play(p)
    assert pc.force_handlers == False
    assert pc.connection == "local"


# Generated at 2022-06-21 01:00:38.283362
# Unit test for constructor of class PlayContext
def test_PlayContext():
    config_args = dict(
        host_list='myinventory',
        module_path=None,
        forks=5,
        become=False,
        become_method='sudo',
        become_user='root',
        verbosity=3,
        check=False,
        diff=False,
        syntax=None,
        start_at_task=None,
        private_key_file=None,
    )

    def args(**kwargs):
        """
        Return a dict with all keys from config_args updated with the
        keys/values passed in as keyword args.
        """
        return dict(config_args, **kwargs)

    # Define common inventory data.

# Generated at 2022-06-21 01:00:40.406848
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    p = PlayContext()
    # FIXME
    p.set_attributes_from_plugin(None)


# Generated at 2022-06-21 01:00:50.125937
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    # Run unit test for method set_become_plugin of class PlayContext
    import ansible.config
    from ansible.inventory.host import Host

    # Test connection plugin, wait for timeout and return test result
    class TestConnectionPlugin(ConnectionBase):
        transport = "test"

        def connect(self, port=None, key_filename=None, timeout=None):
            # connect method
            return True

        def exec_command(self, cmd, in_data=None, sudoable=True):
            # exec_command method
            pass

        def put_file(self, in_path, out_path):
            # put_file method
            pass

        def fetch_file(self, in_path, out_path):
            # fetch_file method
            pass

        def close(self):
            # close method
            pass

       

# Generated at 2022-06-21 01:00:56.393306
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play = Play().load({
        'hosts': 'all',
        'tasks': [
            {'action': {'module': 'setup'}},
        ],
    }, variable_manager=VariableManager(), loader=DataLoader())
    play_context = PlayContext(play=play)



# Generated at 2022-06-21 01:01:06.895366
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context = PlayContext()
    data = play_context.serialize()
    assert data['network_os'] == None
    data['network_os'] = 'eos'
    play_context.deserialize(data)
    assert play_context._network_os == 'eos'
    play_context.network_os = 'junos'
    assert play_context._network_os == 'junos'
    play_context._docker_extra_args = 'test'
    assert play_context._docker_extra_args == 'test'




# Generated at 2022-06-21 01:01:13.666506
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pb = ansible_mitogen.plugins.connection.ConnectionModule
    pc = PlayContext()
    pc.set_attributes_from_plugin(pb)
    assert pc.port == 22
    assert pc.timeout == 10
    assert pc.user == None


# Generated at 2022-06-21 01:01:18.330365
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    # given
    play_context = PlayContext()

    # when
    play_context.set_become_plugin('hacked_plugin')

    # then
    assert play_context._become_plugin == 'hacked_plugin'

