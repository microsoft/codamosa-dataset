

# Generated at 2022-06-21 00:53:42.526809
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    from ansible.utils.plugin_docs import get_docstring
    from ansible.parsing.plugin_docs import read_docstings

    read_docstings()
    conn = MagicMock()
    play = MagicMock()
    plobj = PlayContext(play, dict())
    plobj.set_become_plugin(conn)


# Generated at 2022-06-21 00:53:43.612515
# Unit test for constructor of class PlayContext
def test_PlayContext():
    '''
    Unit test for constructor of class PlayContext
    '''
    play_context = PlayContext()

# Generated at 2022-06-21 00:53:55.844157
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    """
    Test class PlayContext, method set_attributes_from_cli
    """
    play = MagicMock()
    passwords = MagicMock()
    connection_lockfd = MagicMock()
    context.CLIARGS = {
        'timeout': '3000',
        'private_key_file': "/path/to/private_key",
        'verbosity': '5',
        'start_at_task': None
    }
    obj = PlayContext(play, passwords, connection_lockfd)
    expected = {
        'timeout': '3000',
        'private_key_file': "/path/to/private_key",
        'verbosity': '5',
        'start_at_task': None
    }
    obj.set_attributes_from_cli()

# Generated at 2022-06-21 00:54:08.094736
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    # Prepare test data
    playbook_vars = dict()
    task_vars = dict(ansible_port=5005)
    #unsupported_var = dict(ansible_port=5005)
    #unsupported_var = dict(ansible_become_password='password')
    #unsupported_var = dict(ansible_shell_type='csh')
    
    # Execute the code to be tested
    pc = PlayContext()
    pc.update_vars(task_vars)
    pc.update_vars(playbook_vars)

    # Verify the results
    assert pc.port == 5005
    #assert pc.become_pass == 'password'
    #assert pc.executable == '/bin/csh'
    assert not pc.become_pass
    assert not pc.executable

# Generated at 2022-06-21 00:54:13.008457
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    fp = '.../ansibullbot/ansibullbot/utils/is_executable'
    spec = importlib.machinery.ModuleSpec(..., loader=None, origin=fp, submodule_search_locations=[])
    module = types.ModuleType(spec.name)
    spec.loader.exec_module(module)
    
    fp = '.../ansibullbot/ansibullbot/utils/is_hostname'
    spec = importlib.machinery.ModuleSpec(..., loader=None, origin=fp, submodule_search_locations=[])
    module = types.ModuleType(spec.name)
    spec.loader.exec_module(module)
    
    fp = '.../ansibullbot/ansibullbot/utils/crypt_string'
    spec = importlib

# Generated at 2022-06-21 00:54:19.957024
# Unit test for constructor of class PlayContext
def test_PlayContext():
    '''Unit test for constructor of class PlayContext'''
    play_context = PlayContext()
    assert play_context.become_method == 'sudo'
    assert play_context.become_user == 'root'
    assert play_context.connection == 'smart'
    assert play_context.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert play_context.verbosity == 0
    assert play_context.pipelining == C.ANSIBLE_PIPELINING

# Generated at 2022-06-21 00:54:27.722884
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    assertion_statements = [
        "timeout = int(context.CLIARGS['timeout'])",
        "private_key_file = context.CLIARGS.get('private_key_file')",
        "verbosity = context.CLIARGS.get('verbosity')",
        "start_at_task = context.CLIARGS.get('start_at_task', None)"
        ]
    for assertion in assertion_statements:
        assert assertion in PlayContext.set_attributes_from_cli.__func__.__code__.co_code.__str__()


# Generated at 2022-06-21 00:54:39.076693
# Unit test for constructor of class PlayContext
def test_PlayContext():
    empty_passwords = {}
    pc = PlayContext(passwords=empty_passwords)
    assert isinstance(pc.timeout, int)
    assert isinstance(pc.step, bool)
    assert isinstance(pc.serial, int)
    assert isinstance(pc.remote_user, string_types)
    assert isinstance(pc.remote_addr, string_types)
    assert isinstance(pc.connection, string_types)
    assert isinstance(pc.no_log, bool)
    assert isinstance(pc.port, int)
    assert isinstance(pc.private_key_file, string_types)
    assert isinstance(pc.verbosity, int)
    assert isinstance(pc.start_at_task, string_types)
    assert isinstance(pc.force_handlers, bool)
    assert isinstance

# Generated at 2022-06-21 00:54:50.223144
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    from ansible.playbook.play import BasePlay

    class TestPlay(BasePlay):
        def __init__(self):
            BasePlay.__init__(self)
            self.vars = dict()
            self.connection = 'local'

    play = TestPlay()

    play_context = PlayContext()

    # Test set_attributes_from_plugin with connection plugin
    play_context.set_attributes_from_plugin('local')
    assert play_context.executable == '/bin/sh'

    # Test set_attributes_from_play
    play_context.set_attributes_from_play(play)
    assert play_context.force_handlers == False

    # Test set_attributes_from_cli
    play_context.set_attributes_from_cli()
    assert play_context.timeout

# Generated at 2022-06-21 00:54:54.672528
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():

    play_context = PlayContext()

    play_context.verbosity = 0

    play_context.set_attributes_from_cli()

    assert play_context.timeout == 300

    assert play_context.private_key_file == "~/.ssh/ansible_rsa"

    assert play_context.verbosity == 0


# Generated at 2022-06-21 00:55:19.180230
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    p = PlayContext(play=None, passwords=None)
    new_info = p.set_task_and_variable_override(task=None, variables=None, templar=None)
    p.connection_lockfd = 59
    p.become_pass = None
    p.prompt = ''
    p.success_key = ''
    p.set_attributes_from_plugin(None)
    p.set_attributes_from_play(None)
    b = p.set_attributes_from_cli()
    if b is None:
        print('test_PlayContext_set_attributes_from_cli')
    p.set_become_plugin(None)
    variables = p.update_vars(None)

# Generated at 2022-06-21 00:55:21.974961
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    # FIXME: something to check here?
    pass


# Generated at 2022-06-21 00:55:33.315811
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # Hack to make sure result is same on any system
    C.DEFAULT_REMOTE_PORT = 2222
    # Hack to make sure result is same on any system
    C.LOCALHOST = C.LOCALHOST + ('::1',)


# Generated at 2022-06-21 00:55:34.869569
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    play_context = PlayContext()
    play_context.update_vars({})



# Generated at 2022-06-21 00:55:44.373925
# Unit test for constructor of class PlayContext
def test_PlayContext():
    '''
    what we'll do here is create a PlayContext instance with no params, and
    then fill it in with various data.  The result should be a PlayContext
    that can be used for testing purposes.
    '''

    # FIXME: this test should be run with both a local transport and network
    # transport, and we should also validate that the appropriate attributes
    # are getting set

    # create the instance and fill in some fake data
    pc = PlayContext()

    # fill in the rest of the data
    pc.connection = 'test'
    pc.remote_addr = '127.0.0.1'
    pc.remote_user = 'test'
    pc.password = 'test'
    pc.port = 42
    pc.timeout = 1337
    pc.connection_user = 'test'
    pc.private_key

# Generated at 2022-06-21 00:55:52.951076
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    play_context = PlayContext()
    play_context.update_vars({"test": 123})

    # Verify if the connections magic variables were successfully added to the variables list
    assert 'ansible_ssh_host' in play_context.__dict__
    assert 'ansible_ssh_port' in play_context.__dict__
    assert 'ansible_ssh_user' in play_context.__dict__
    assert 'ansible_ssh_pass' in play_context.__dict__
    assert 'ansible_ssh_private_key_file' in play_context.__dict__
    assert 'ansible_ssh_common_args' in play_context.__dict__



# Generated at 2022-06-21 00:56:02.828215
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    assert PlayContext()._timeout == 5
    assert PlayContext()._private_key_file == "/path/to/file"
    assert PlayContext()._ssh_common_args == ""
    assert PlayContext()._sftp_extra_args == ""
    assert PlayContext()._scp_extra_args == ""
    assert PlayContext()._ssh_extra_args == ""
    assert PlayContext()._ssh_executable == None
    assert PlayContext()._become == False
    assert PlayContext()._become_method == 'sudo'
    assert PlayContext()._become_user == 'root'
    assert PlayContext()._verbosity == 0
    assert PlayContext()._only_tags == set()
    assert PlayContext()._step == False
    assert PlayContext()._start_at_task == None
    assert PlayContext()._force_

# Generated at 2022-06-21 00:56:08.263182
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = DummyPlay()
    play.set_attribute('force_handlers', False)
    play_context = PlayContext(play=play)
    assert play_context.force_handlers == False


# Generated at 2022-06-21 00:56:20.564359
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    p = PlayContext()
    variables = {}
    p.update_vars(variables)
    assert variables == {
                         'ansible_ssh_user': 'root',
                         'ansible_ssh_port': p.port,
                         'ansible_ssh_host': p.remote_addr,
                         'ansible_connection': 'ssh'
                         }
    # import pdb; pdb.set_trace()
    p.connection = 'local'
    variables = {}
    p.update_vars(variables)
    assert variables == {
                         'ansible_connection': 'local',
                         'ansible_ssh_user': 'root',
                         'ansible_ssh_port': p.port,
                         'ansible_ssh_host': p.remote_addr,
                         }
    p.connection = 'paramiko'

# Generated at 2022-06-21 00:56:27.008206
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = MagicMock(name='play')
    pc = PlayContext()
    pc.set_attributes_from_play(play)
    assert ['force_handlers'] == pc._attributes.keys()
    assert pc.force_handlers is play.force_handlers


# Generated at 2022-06-21 00:56:47.251929
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    from ansible.module_utils.common.removed import removed_class
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_plugin_class

    fake_play = got = None
    context = PlayContext()
    context.set_attributes_from_cli()

# Generated at 2022-06-21 00:56:54.937054
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    p = PlayContext()
    def m(p,plugin):
        options = C.config.get_configuration_definitions(get_plugin_class(plugin), plugin._load_name)
        for option in options:
            if option:
                flag = options[option].get('name')
                if flag:
                    setattr(p, flag, plugin.get_option(flag))
    p.set_attributes_from_plugin = MethodType(m, p)
    plugin = C.CLIConfigParser.get_config_ini_value("plugin", "connection", "smart")
    p.set_attributes_from_plugin(plugin)
    assert p._attributes['connection'] == "ssh"


# Generated at 2022-06-21 00:57:03.934299
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    from ansible.plugins.loader import become_loader
    from ansible.plugins.become import BecomeBase

    def find_class(name):
        for i in [BecomeBase]:
            if i.__name__ == name:
                return i
        return None

    # setUp
    i = PlayContext()
    i.become = False
    i.become_pass = True
    i.prompt = 'prompt'
    i.become_user = True
    i.become_method = 'su'
    i.success_key = 'success_key'
    i.set_become_plugin(become_loader.get('su', class_only=True))
    # Test: normal case
    i.set_become_plugin(become_loader.get('su', class_only=True))


# Generated at 2022-06-21 00:57:14.887539
# Unit test for constructor of class PlayContext
def test_PlayContext():
    '''
    >>> p = PlayContext()
    >>> p.port
    22
    >>> p.remote_addr
    '''

    # Test setting the attributes from a plugin, by setting _options on the 'plugin'
    # then calling set_attributes_from_plugin to do the magic.
    # This is a bit hacky, I suppose, but trying to make things as close to the
    # actual use case of this method
    class MockPlugin:
        _load_name = 'mock'

        def __init__(self):
            self._options = dict()

        def get_option(self, option):
            return self._options[option]

    plugin = MockPlugin()
    local_vars = dict()

    # Setting up the plugin with some options, then testing that the local_vars have
    # been updated as expected.

# Generated at 2022-06-21 00:57:23.376564
# Unit test for constructor of class PlayContext
def test_PlayContext():
    a = PlayContext()
    assert isinstance(a, PlayContext)
    assert not a.prompt
    assert not a.success_key
    assert not a.password
    assert not a.become_pass
    assert a.pipelining
    assert not a.connection_lockfd

    a = PlayContext(passwords={'conn_pass': 'test'})
    assert a.password == 'test'
    assert not a.become_pass

# Generated at 2022-06-21 00:57:35.515112
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    mock_task = create_autospec(Task)
    mock_template = create_autospec(VariableManager)
    mock_task.delegate_to = None
    mock_task.check_mode = True

    mock_task.connection.__get__ = Mock(return_value=None)
    mock_task.remote_user.__get__ = Mock(return_value=None)
    mock_task.port.__get__ = Mock(return_value=None)
    mock_task.no_log.__get__ = Mock(return_value=None)
    mock_task.become.__get__ = Mock(return_value=None)
    mock_task.become_method.__get__ = Mock(return_value=None)

    play = Play()
    play.force_handlers = True

# Generated at 2022-06-21 00:57:41.029423
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    # Setup
    play = MagicMock(spec=Play)
    passwords = {}

    # Exercise
    pc = PlayContext(play, passwords)
    pc.update_vars({})
    # Verify
    # Nothing to verify
    # Cleanup


# Generated at 2022-06-21 00:57:54.420638
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.constants import C
    from ansible.module_utils.six import string_types
    import ansible.cli.adhoc
    import ansible.cli.playbook
    import types

    # The global config for testing needs to be a class.  There isn't
    # one in constants.py, so create it here.
    C.CONFIG = type('', (), {})()
    C.CONFIG.private_key_file = ''
    C.CONFIG.verbosity = 0
    C.CONFIG.timeout = 10
    C.CONFIG.connect_timeout = 10
    C.CONFIG.network_group = ''
    C.CONFIG.remote_addr = ''
    C.CONFIG.remote_user = ''


# Generated at 2022-06-21 00:57:56.465264
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
  # set_become_plugin(self, plugin)
  pass


# Generated at 2022-06-21 00:58:07.155133
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    import os
    import tempfile
    from ansible.context import AnsibleContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    # Tested code
    # self.set_become_plugin(plugin)

    # Fixtures
    context = AnsibleContext()

    tmp_dir = os.path.join(tempfile.gettempdir(), 'ansible_test_PlayContext_set_become_plugin_')
    os.makedirs(tmp_dir)

    config_file = '/etc/ansible/ansible.cfg'

    inventory = InventoryManager(
        loader=None,
        sources=None,
    )


# Generated at 2022-06-21 00:58:34.478236
# Unit test for constructor of class PlayContext
def test_PlayContext():

    connection_info = PlayContext()
    assert connection_info is not None
    assert connection_info._attributes == {}
    assert connection_info.password is None

# Generated at 2022-06-21 00:58:35.738599
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pass


# Generated at 2022-06-21 00:58:45.838083
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    import ansible.parsing.dataloader
    import ansible.vars.manager

    new_info = return_basic_info()
    loader = ansible.parsing.dataloader.DataLoader()
    variables = ansible.vars.manager.VariableManager(loader=loader)
    setattr(new_info, 'remote_addr', 'localhost')
    setattr(new_info, 'remote_user', 'root')
    assert new_info.port == 22
    assert new_info.remote_addr == 'localhost'
    assert new_info.remote_user == 'root'
    assert new_info.timeout == 10
    assert new_info.verbosity == 0
    assert new_info.connection == 'ssh'
    setattr(new_info, 'port', None)

# Generated at 2022-06-21 00:58:53.505095
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    play_ctx = PlayContext()
    variables = {}
    play_ctx.update_vars(variables)
    assert variables == {'ansible_port': 22, 'ansible_user': 'root', 'ansible_ssh_port': 22, 'ansible_connection': 'smart'}


# Generated at 2022-06-21 00:59:01.306785
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """
    Test function set_attributes_from_plugin of class PlayContext
    """
    myTestPlay = Play()
    myTestPlayContext = PlayContext(myTestPlay)

    myPipePlugin = myTestPlayContext.set_attributes_from_plugin('test_plugin')
    assert myPipePlugin is None



# Generated at 2022-06-21 00:59:07.475448
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pc = PlayContext()
    pc.set_attributes_from_play(play=None)
    pc.set_attributes_from_cli()
    pc.set_task_and_variable_override(task=None, variables=None, templar=None)
    pc.set_become_plugin(plugin=None)
    pc.update_vars(variables=None)
    assert pc._get_attr_connection() == 'ssh'
    print('Test set_attributes_from_plugin of class PlayContext Done !')


# Generated at 2022-06-21 00:59:16.028176
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context = PlayContext()
    play_context.set_attributes_from_cli()
    assert play_context._timeout == 300
    assert play_context._private_key_file == '~/.ssh/id_rsa'
    assert play_context._verbosity == 0
    assert play_context._start_at_task == None
    assert play_context._step == False
    assert play_context._force_handlers == False



# Generated at 2022-06-21 00:59:27.562477
# Unit test for constructor of class PlayContext
def test_PlayContext():
    display.display("TESTING PLAYCONTEXT")

    p = PlayContext()

    assert(set(p._attributes.keys()) == set(['remote_addr', 'remote_user', 'port', 'password', 'private_key_file',
                                             'timeout', 'connection', 'network_os', 'become', 'become_method', 'become_user',
                                             'become_pass', 'become_exe', 'become_flags', 'verbosity', 'only_tags',
                                             'skip_tags', 'start_at_task', 'host_vars', 'step', 'prompt', 'success_key',
                                             'force_handlers', 'azure_rm_resource_group', 'network_os']))

    assert(p.remote_addr == '127.0.0.1')

# Generated at 2022-06-21 00:59:28.078374
# Unit test for constructor of class PlayContext
def test_PlayContext():
    pass

# Generated at 2022-06-21 00:59:28.666833
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pass

# Generated at 2022-06-21 01:00:27.169524
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
  '''
  Test set_become_plugin method of class PlayContext
  '''
  play = Play()
  passwords = {'conn_pass': 'secret', 'become_pass': 'secret'}
  connection_lockfd = None
  pc = PlayContext(play, passwords, connection_lockfd)
  plugin = get_plugin_class('become')()
  pc.set_become_plugin(plugin)
  assert pc._become_plugin == plugin

# Generated at 2022-06-21 01:00:36.769665
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    '''
    Unit test for method set_become_plugin of class PlayContext.
    '''
    play = Play()
    passwords = {}
    connection_lockfd = None
    play_context = PlayContext(play, passwords, connection_lockfd)
    become_plugin = 'any_become_plugin'
    play_context.set_become_plugin(become_plugin)
    assert play_context._become_plugin == become_plugin

# Generated at 2022-06-21 01:00:40.901576
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    context.CLIARGS = {'verbosity': 3}
    play_context = PlayContext()
    # We expect that the value of verbosity is set to 3
    assert play_context.verbosity == 3

# Generated at 2022-06-21 01:00:46.846098
# Unit test for constructor of class PlayContext
def test_PlayContext():
    p = PlayContext(play=Play())
    # p._attributes = {"network_os": "junos"}
    print(p.port)
    print(p.timeout)
    print(p.verbosity)
    # p._attributes = {"network_os": "junos"}
    print(getattr(p, 'network_os', None))
    print(p.network_os)

# Generated at 2022-06-21 01:00:53.844177
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pc = PlayContext()
    pc.set_attributes_from_play(play=None)
    task = Task()
    task.set(name="test_task_setup", action="test_action", delegate_to="test_host", loop=True, delegate_host="test_host")
   

# Generated at 2022-06-21 01:01:07.553402
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():

    class MockAnsibleModule(object):
        @property
        def checkpoint(self):
            return None
    #assert Error:isinstance(ansible.module_utils.urls.CLIARGS, dict)
    #assert Error:isinstance(ansible.module_utils.urls.C, dict)
    #assert Error:isinstance(ansible.module_utils.urls.basic.AnsibleModule, type)
    #assert Error:isinstance(ansible.module_utils.urls.cmdb.CLIARGS, dict)
    #assert Error:isinstance(ansible.module_utils.urls.cmdb.C, dict)
    #assert Error:isinstance(ansible.module_utils.urls.cmdb.basic.AnsibleModule, type)
    #assert Error:isinstance(ansible

# Generated at 2022-06-21 01:01:10.830350
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    p = PlayContext()
    p.set_attributes_from_plugin('ssh')
    assert p.connection == 'ssh'

# Generated at 2022-06-21 01:01:20.053149
# Unit test for constructor of class PlayContext
def test_PlayContext():
    '''
    PlayContext - constructor test
    '''
    pci = PlayContext()

    assert not pci._attributes.get('_play')
    assert pci.password == ''

    assert pci._become_plugin is None

    assert pci.timeout == C.DEFAULT_TIMEOUT
    assert pci.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert pci.verbosity == 0

    assert pci.check_mode is None
    assert pci.diff is None



# Generated at 2022-06-21 01:01:31.656030
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # Empty constructor
    context = PlayContext()
    assert isinstance(context, PlayContext)
    assert context.connection == 'smart'
    assert context.remote_addr is None
    assert context.remote_user == 'root'
    assert context.port is None
    assert context.password == ''
    assert isinstance(context.timeout, int)
    assert context.private_key_file == '~/.ssh/id_rsa'
    assert context.verbosity == 0
    assert isinstance(context.only_tags, set)
    assert isinstance(context.skip_tags, set)
    assert context.start_at_task is None
    assert not context.step
    assert context.remote_pass is None
    assert context.no_log is None
    assert context.pipelining is None
    assert context.network_os is None

# Generated at 2022-06-21 01:01:41.800295
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    context.CLIARGS = {
        'verbosity': '99',
        'timeout': '99',
        'private_key_file': '/my/key.pem',
        'start_at_task': 'foobar'
    }
    context.CLIARGS.update(ANSIBLE_CONSTANTS.DEFAULTS)

    pc = PlayContext()
    pc.set_attributes_from_cli()

    assert pc.private_key_file == '/my/key.pem'
    assert pc.verbosity == 99
    assert pc.timeout == 99
    assert pc.start_at_task == 'foobar'