

# Generated at 2022-06-21 00:53:42.665503
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Setup
    test_play_context = PlayContext()
    test_plugin = None
    test_play_context.set_attributes_from_plugin(test_plugin)
    assert test_play_context


# Generated at 2022-06-21 00:53:55.169930
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    def get_vars(dict, key):
        if key in dict:
            return dict[key]
        return None

    The_task = None
    The_variables = {"ansible_ssh_host": "10.20.30.40"}
    The_templar = None
    c = PlayContext(The_task, The_variables, The_templar)
    assert get_vars(c.__dict__, 'remote_addr') == "10.20.30.40"

    The_task = None
    The_variables = {"ansible_host": "10.20.30.40"}
    The_templar = None
    c = PlayContext(The_task, The_variables, The_templar)
    assert get_vars(c.__dict__, 'remote_addr')

# Generated at 2022-06-21 00:54:01.035289
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    play = Mock()
    passwords = {}
    connection_lockfd = None

    play_context = PlayContext(play=play, passwords=passwords, connection_lockfd=connection_lockfd)

    task = Mock()
    variables = {}
    templar = Mock()

    assert play_context.set_task_and_variable_override(task=task, variables=variables, templar=templar)

# Generated at 2022-06-21 00:54:04.173622
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    p = PlayContext()
    c = PlayContext()
    assert c.set_become_plugin(p) is None
    assert c._become_plugin is p


# Generated at 2022-06-21 00:54:06.368828
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    playcontext = PlayContext()
    playcontext.set_attributes_from_cli()


# Generated at 2022-06-21 00:54:10.901921
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    context._init_global_context(config=dict(config_path='test/ansible.cfg'))
    context.CLIARGS = dict(timeout=30)
    play_context = PlayContext()
    assert play_context.timeout == 30


# Generated at 2022-06-21 00:54:15.834020
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from swampyer import templates
    task = PlayContext()
    variables = {}
    templar = templates.Templar(loader=None, variables={})
    task.set_task_and_variable_override(task, variables, templar)


# Generated at 2022-06-21 00:54:24.982614
# Unit test for constructor of class PlayContext

# Generated at 2022-06-21 00:54:28.212717
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # create a new instance of the PlayContext class
    play_context = PlayContext()

    # call the set_attributes_from_cli() method
    play_context.set_attributes_from_cli()



# Generated at 2022-06-21 00:54:39.267429
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    yaml_instance = get_import_loader()
    testinventory = yaml_instance.load(dedent("""
            testhost:
                vars:
                    testvar1: 'hello'
                    testvar3: '{{ testvar2 }}'
                    testvar2: '{{ testvar1 }}'
                    testvar4: '{{ testvar1 }}'
                host_vars:
                    testhost2:
                        testvar2: 'goodbye'
    """))
    # task will be used in update_vars
    task = Task()
    task.action = 'test'
    task.become = False
    task.become_method = 'sudo'
    task.become_user = 'testuser'
    task.delegate_to = None
    task.delegate_facts = None
    task.ignore_

# Generated at 2022-06-21 00:55:07.206089
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    my_PlayContext = PlayContext()
    my_PlayContext.set_attributes_from_plugin(None)

# Generated at 2022-06-21 00:55:17.526240
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # set options before play to allow play to override them
    if context.CLIARGS:
        PlayContext.set_attributes_from_cli(PlayContext())

    plugin = 'network_cli'
    # get options for plugins
    options = C.config.get_configuration_definitions(get_plugin_class(plugin), plugin._load_name)
    for option in options:
        if option:
            flag = options[option].get('name')
            if flag:
                setattr(PlayContext, flag, plugin.get_option(flag))


# Generated at 2022-06-21 00:55:20.893538
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    assert PlayContext().set_attributes_from_plugin(None) == None


# Generated at 2022-06-21 00:55:27.412494
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    class Dummy:
        cliargs = dict(timeout=2)

    context.CLIARGS = Dummy()
    p = PlayContext()
    p.set_attributes_from_cli()
    assert p.timeout == 2
    context.CLIARGS = None


# Generated at 2022-06-21 00:55:37.336549
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plugin = new_fake_plugin()
    connection = new_fake_connection(plugin)

    # create a play to set and set connection
    play_context = PlayContext(play=new_fake_play(), passwords={'conn_pass': 'conn_pass'})
    play_context.set_attributes_from_plugin(plugin)
    play_context.set_attributes_from_connection(connection)

    # override connection credentials from connection plugin
    # Generic fields
    assert play_context.remote_addr == plugin.get_option('remote_addr')
    assert play_context.password == plugin.get_option('password')
    assert play_context.no_log == plugin.get_option('no_log')

    # Networking fields
    assert play_context.network_os == plugin.get_option('network_os')

    #

# Generated at 2022-06-21 00:55:45.821466
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from copy import deepcopy

    cli_args = {'start_at_task': 'foobar', 'verbosity': 1}
    context_ = deepcopy(context)
    context_.CLIARGS = cli_args

    info = PlayContext()
    task = MagicMock()
    task.delegate_to = None

    variables = dict(
        ansible_ssh_foo = 'bar',
        ansible_ssh_bar = 'baz',
    )

    play_context = PlayContext()
    play_context.set_attributes_from_cli()

    play_context.set_task_and_variable_override(task, variables, None)

    assert play_context.start_at_task == 'foobar'
    assert play_context.verbosity == 1

# Generated at 2022-06-21 00:55:54.886082
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pc = PlayContext()
    plugin = 'raw'
    pc.set_attributes_from_plugin(plugin)
    assert pc._attributes.get('network_os')
    assert pc._attributes.get('_use_persistent_connection')
    assert pc._attributes.get('_shell_type')
    assert pc._attributes.get('_connection_lockfd')
    assert pc._attributes.get('_ansible_shell_type')
    assert pc._attributes.get('_ansible_delegated_vars')
    assert pc._attributes.get('_ansible_debug')
    assert pc._attributes.get('_ansible_verbosity')
    assert pc._attributes.get('_ansible_no_log')
    assert pc._attributes.get('_ansible_check_mode')

# Generated at 2022-06-21 00:56:02.870805
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    '''
    unit test for method "set_become_plugin" of class PlayContext
    '''
    # unit test for method "set_become_plugin" of class PlayContext
    play = Play()
    play.become_method = 'sudo'
    play.become_user = 'root'
    passwords = None
    connection_lockfd = None
    play_context = PlayContext(play, passwords, connection_lockfd)
    plugin_name = 'sudo'
    plugin = PluginLoader.get(plugin_name, 'become_plugin')
    play_context.set_become_plugin(plugin)
    assert plugin == play_context._become_plugin


# Generated at 2022-06-21 00:56:12.956218
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    class MockTask(object):
        def __init__(self):
            self.hosts = []
            self.remote_user = None
            self.delegate_to = None

    class MockPlay(object):
        def __init__(self):
            self.force_handlers = False

    class MockTemplar(object):
        def template(self, data):
            return data

    pc = PlayContext()
    pc.set_attributes_from_cli()
    task = MockTask()
    play = MockPlay()
    templar = MockTemplar()
    variables = {'ansible_ssh_port': 24}
    pc.set_attributes_from_play(play)
    pc.set_task_and_variable_override(task, variables, templar)
    assert pc.port == 24

# Generated at 2022-06-21 00:56:22.857626
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    variables = {}
    play = C.DataLoader().load(fixtures_path + '/play_context_play.yml')
    play = play[0]
    play_context = PlayContext(play, connection_lockfd=None)

    var_mapping = C.MAGIC_VARIABLE_MAPPING.copy()
    var_mapping.pop('become_pass', None)
    for prop, var_list in var_mapping.items():
        for var_opt in var_list:
            variables[var_opt] = 'foo'

    play_context.update_vars(variables)

# Generated at 2022-06-21 00:57:04.947455
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    '''
    Test the update_vars method of the PlayContext class
    '''
    play_context = PlayContext(play=None, passwords=None, connection_lockfd=None)
    variables = {}
    play_context.update_vars(variables)
    # setattr() is not actually used here, only to pass the linter.
    setattr(play_context, 'host_name', 'host_name')
    variables = {}
    play_context.update_vars(variables)
    # from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    # del(C.MAGIC_VARIABLE_MAPPING['connection'])
    # setattr(play_context, 'connection', 'connection')
    # variables = {}
    # play_context.update_vars(variables)

# Generated at 2022-06-21 00:57:09.956688
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    v = PlayContext()
    v._attributes = {}
    v.set_attributes_from_cli()
    assert v._attributes['verbosity'] == 0
    assert v._attributes['timeout'] == C.DEFAULT_TIMEOUT

# Generated at 2022-06-21 00:57:18.157436
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Test PlayContext.set_attributes_from_plugin()
    '''
    # initialize a PlayContext object
    pc = PlayContext()
    # set values to properties
    pc._attributes['verbosity'] = ''
    pc.set_attributes_from_plugin('connection')
    # test assertion
    assert pc.verbosity is None


# Generated at 2022-06-21 00:57:20.466397
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # additional test cases can be added here
    pass


# Generated at 2022-06-21 00:57:33.729917
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    p = PlayContext()
    p.port = 22
    p.remote_addr = '10.10.10.10'
    p.remote_user = 'ec2-user'
    p.connection_user = 'ec2-user'
    p.timeout = 10
    p.connection = 'local'
    p.check_mode = False
    p.become = True

    vars = {}
    p.update_vars(vars)

    assert_equals(22, vars.get('ansible_port'))
    assert_equals('ec2-user', vars.get('ansible_user'))
    assert_equals('10.10.10.10', vars.get('ansible_host'))
    assert_equals(10, vars.get('ansible_timeout'))


# Generated at 2022-06-21 00:57:41.843692
# Unit test for constructor of class PlayContext
def test_PlayContext():
    '''
    Constructor of class PlayContext
    '''
    # Test empty constructor
    # test_play = Play()
    test_ctx = PlayContext()
    # Constructor with a play
    # play.set_connection()
    # test_ctx_with_play = PlayContext(test_play)
    # Constructor with a passwords
    # passwords = dict(conn_pass='pass')
    # test_ctx_with_passwords = PlayContext(test_play, passwords)
    # Constructor with a play and connection_lockfd
    # test_ctx_with_play_and_lockfd = PlayContext(test_play, passwords, 12)

# Generated at 2022-06-21 00:57:54.706252
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    # Create a PlayContext object
    obj = PlayContext()
    # Testing if the PlayContext is a PlayContext object
    assert isinstance(obj, PlayContext)
    # Testing if the PlayContext is a BaseObject object
    assert isinstance(obj, BaseObject)
    # Testing if the PlayContext is a ConfigBaseObject object
    assert isinstance(obj, ConfigBaseObject)
    # Testing if the set_become_plugin method is callable
    assert callable(obj.set_become_plugin)
    # Call the set_become_plugin method
    obj.set_become_plugin('foo')
    # Testing if the set_become_plugin method returned a object of the class PlayContext
    assert isinstance(obj.set_become_plugin('foo'), PlayContext)
    # Testing if the set_become_plugin method returned

# Generated at 2022-06-21 00:58:06.437493
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    from ansible.module_utils._text import to_bytes

    # Test with valid passwords
    pc = PlayContext(play=None, passwords=dict(conn_pass='connpass', become_pass='becomepass'))
    pc.set_become_plugin()

    # Test with invalid passwords
    pc = PlayContext(play=None, passwords=dict(conn_pass='connpass'))
    try:
        pc.set_become_plugin()
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('should raise an exception')

    # Test with valid passwords
    pc = PlayContext(play=None, passwords=dict(conn_pass='connpass', become_pass='becomepass'))
    pc.prompt = to_bytes('BECOME')
    pc.success_key = to_

# Generated at 2022-06-21 00:58:13.370374
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    import unittest
    from units.compat import mock

    play = mock.MagicMock()

    play.force_handlers = True

    pc = PlayContext(play=play)

    pc.set_attributes_from_play(play)

    assert pc._force_handlers == play.force_handlers


# Generated at 2022-06-21 00:58:17.328163
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context = PlayContext(play=dict())
    assert isinstance(play_context, PlayContext)

# Generated at 2022-06-21 00:58:59.576424
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    set_module_args({'hosts': 'localhost', 'gather_subset': ['!all', '!min'], 
        'gather_timeout': 30, 'gather_facts': 'no'})
    p = BasicModuleParser(load_DS=['setup'])
    p = p.load_module_source('setup', 'localhost')
    assert isinstance(p, PlayContext), "Returned object is not an instance of PlayContext"
    assert p.remote_user == getpass.getuser(), "remote_user should be equal to user running the test, instead it's " + str(p.remote_user)
    assert p.port == 22, "port should be 22, instead it's " + str(p.port)

# Generated at 2022-06-21 00:59:03.173744
# Unit test for constructor of class PlayContext
def test_PlayContext():
    pc = PlayContext()
    #assert pc.remote_addr == None
    assert pc.port == C.DEFAULT_REMOTE_PORT
    assert pc.remote_user == os.environ['USER']
    assert pc.connection == 'smart'
    assert pc.timeout == C.DEFAULT_TIMEOUT

# Generated at 2022-06-21 00:59:10.415972
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.connection.local \
        import Connection as LocalPlugin
    from ansible.plugins.connection.paramiko_ssh \
        import Connection as ParamikoConnection

    class TestTask:
        _attributes = dict()

        def __init__(self, attrs):
            self._attributes = attrs

        def __getattr__(self, name):
            return self._attributes[name]

    class TestPlay:
        def __init__(self, force_handlers):
            self.force_handlers = force_handlers

    # Test with two different classes of plugins
    # local plugin & paramiko plugin
    # and check the overrides set by PlayContext
    for plugin in (LocalPlugin(), ParamikoConnection()):
        play_context = PlayContext

# Generated at 2022-06-21 00:59:23.549634
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # execute_mock_exception_handle
    mock_execute_exception_handle = MagicMock(name='execute_exception_handle')
    mocked_execute_exception_handle = patch('ansible.executor.play_context.PlayContext.execute_exception_handle', new=mock_execute_exception_handle)
    mocked_execute_exception_handle.start()

    # task_vars_template
    mock_task_vars_template = MagicMock(name='task_vars_template')
    mocked_task_vars_template = patch('ansible.executor.play_context.PlayContext.task_vars_template', new=mock_task_vars_template)
    mocked_task_vars_template.start()

    # task_vars_template_wrap
    mock_

# Generated at 2022-06-21 00:59:29.039976
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = play_context.Play()
    obj = play_context.PlayContext(play=play)
    obj.set_attributes_from_play(play)
    assert obj.force_handlers == False


# Generated at 2022-06-21 00:59:35.014822
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    '''
    unit test for method set_attributes_from_play of class PlayContext
    '''
    play_context=PlayContext()
    play_context.set_attributes_from_play('play_context')

# Method set_attributes_from_cli of class PlayContext

# Generated at 2022-06-21 00:59:40.320894
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    playbook_vars = dict()
    templar = Templar(loader=None)
    task = Task()
    task.delegate_to = None
    task.check_mode = None
    task.diff = None
    task.connection = 'ssh'
    task.remote_user = 'root'
    task.no_log = False
    task.port = 22
    task.timeout = 10
    context = PlayContext()

    # running this test with no overrides should not raise any errors
    assert context.set_task_and_variable_override(task, playbook_vars, templar)

    # now set delegation and make sure the local connection properties are removed
    task.delegate_to = 'foo'

# Generated at 2022-06-21 00:59:46.355530
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():

    # TODO: remove CLIARGS
    monkeypatch = MonkeyPatch()
    monkeypatch.setattr(context, 'CLIARGS', {'timeout': '300'}, raising=False)

    pc = PlayContext()
    pc.set_attributes_from_cli()

    assert pc.timeout == 300
    assert pc.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert pc.start_at_task == None

# Generated at 2022-06-21 00:59:54.088024
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    # test defaults
    for prop, var_list in C.MAGIC_VARIABLE_MAPPING.items():
        try:
            if 'become' in prop:
                continue
            var_val = getattr(PlayContext(), prop)
            for var_opt in var_list:
                if var_opt not in variables and var_val is not None:
                    variables[var_opt] = var_val
        except AttributeError:
            continue

    # test specifics of a plugin
    plugin = module_loader.get_all_plugin_loaders()[0]
    pc = PlayContext()
    pc.set_attributes_from_plugin(plugin)

# Generated at 2022-06-21 01:00:06.458859
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    # Dummy variables
    variables = {
        'ansible_ssh_user': 'user1',
        'ansible_connection': 'ssh',
        'ansible_shell_type': 'csh',
    }

    # Test for valid execution
    import jinja2
    task = Task()
    task.remote_user = 'user2'
    task.become_user = 'user3'
    templar = jinja2.Template("{{ ansible_user }}")
    pc = PlayContext()
    result = pc.set_task_and_variable_override(task, variables, templar)
    assert result is not None
    assert result.remote_user == 'user2'
    assert result.become_user == 'user3'
    assert result.shell_type == 'csh'

# Generated at 2022-06-21 01:01:22.404171
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    # test object instantiation
    pc = PlayContext()

    # mock_play = Mock(play_uuid='', playbook_basedir='', path_depth=0, playbook='', ignore_errors=False, force_handlers=False)
    
    # password and become_pass set from main
    # pc = PlayContext(mock_play, dict({'conn_pass': '', 'become_pass': ''}), None)
    pc.set_task_and_variable_override('mock_task', dict({'ansible_become_pass': 'test'}), 'templar')
    pc.set_become_plugin('test_become')
    
    # test_PlayContext_set_become_plugin.test_PlayContext_set_become_plugin.test_PlayContext_set_become_plugin

# Generated at 2022-06-21 01:01:27.549285
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    play_context = PlayContext()
    var_dict = {}
    play_context.update_vars(var_dict)
    assert 'ansible_port' in var_dict
    assert 'ansible_user' in var_dict



# Generated at 2022-06-21 01:01:37.765939
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Arrange
    task = MagicMock()
    variables = {"ansible_ssh_host":[]}
    templar = MagicMock()
    
    # Act
    context = PlayContext()
    context.set_task_and_variable_override(task, variables, templar)

    # Assert
    assert context.remote_addr[0] is variables["ansible_ssh_host"]
# Method definition to test method _get_attr_connection of class PlayContext

# Generated at 2022-06-21 01:01:49.345817
# Unit test for constructor of class PlayContext
def test_PlayContext():
    '''
    This is an example of how to write a unit test for a PlayContext class
    You can use this as a reference to test other class constructors
    '''

    # First, we'll create an instance of the PlayContext class
    play_context = PlayContext()

    # Then, we'll compare the results we get when calling the different accessors
    # to what we expect
    assert play_context.remote_addr == '127.0.0.1'
    assert play_context.remote_port == 22
    assert play_context.remote_user == 'root'
    assert play_context.remote_pass == ''
    assert play_context.timeout == C.DEFAULT_TIMEOUT
    assert play_context.connection == 'ssh'
    assert play_context.pipelining == C.ANSIBLE_PIPELINING

# Generated at 2022-06-21 01:01:54.743249
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Set up mock objects
    mock_CLIARGS = {}

    # Invoke method
    PlayContext.set_attributes_from_cli(mock_CLIARGS)


# Generated at 2022-06-21 01:01:59.041886
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    task = Mock()
    variables = Mock()
    templar = Mock()
    expected_result = {}
    p = PlayContext(None, None)
    result = p.set_task_and_variable_override(task, variables, templar)

    assert result.__dict__ == expected_result

# Generated at 2022-06-21 01:02:11.913205
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    testPlayContext = PlayContext()
    testVar = dict()
    testTask = Task()
    testTask.remote_user = 'testuser'
    testTask.delegate_to = 'testhost'
    testTask.delegate_facts = True
    testTask.become = False
    testTask.become_user = 'testuser'
    testTask.check_mode = False
    testTask.diff = None
    
    testVar['ansible_connection'] = 'ssh'
    testVar['ansible_ssh_user'] = 'testuser'
    testVar['ansible_delegated_vars'] = dict()
    
    
    testResult = testPlayContext.set_task_and_variable_override(testTask, testVar, 'test')

# Generated at 2022-06-21 01:02:16.546964
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    from ansible.playbook.play import Play

    # NOTE: Implicitly tested by test_PlayContext_init_attr_set()
    pass


# Generated at 2022-06-21 01:02:19.525665
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
  # This test is not written as other tests as it would need to mock
  # class ConnectionInfo, which would not be worth the time
  pass


# Generated at 2022-06-21 01:02:23.299069
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    conn_info = PlayContext()
    conn_info.set_attributes_from_cli()
    assert_equal(conn_info.timeout, 0)
