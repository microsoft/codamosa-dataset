

# Generated at 2022-06-21 00:53:38.284612
# Unit test for constructor of class PlayContext

# Generated at 2022-06-21 00:53:39.017057
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
  pass

# Generated at 2022-06-21 00:53:48.193071
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    """
    This is a temporary unit test for the issue noted in
    https://github.com/ansible/ansible-modules-core/issues/4492

    Ideally this will be replaced by the method working correctly,
    so there is no need for the test.

    """
    play_context = PlayContext(play=None, passwords=None, connection_lockfd=None)
    play = MockPlay()
    play.force_handlers = False
    play_context.set_attributes_from_play(play)
    assert play_context.force_handlers is False


# Generated at 2022-06-21 00:53:58.584935
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    variable_manager = VariableManager()
    loader = DataLoader()
    variables = variable_manager.get_vars(loader=loader, play=Play.load(loader=loader, variable_manager=variable_manager, play_context=PlayContext()))
    play_context = PlayContext(play=Play.load(loader=loader, variable_manager=variable_manager, play_context=PlayContext()), passwords={'conn_pass': '', 'become_pass': ''})
    play_context.update_vars(variables)
    assert variables['ansible_ssh_common_args'] == '-o ControlMaster=auto -o ControlPersist=60s'
    assert variables

# Generated at 2022-06-21 00:54:01.035914
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    set_attributes_from_play()



# Generated at 2022-06-21 00:54:13.930653
# Unit test for method set_become_plugin of class PlayContext

# Generated at 2022-06-21 00:54:22.931199
# Unit test for constructor of class PlayContext
def test_PlayContext():
    p = PlayContext()
    assert p.remote_address is None
    assert p.remote_user is None
    assert p.port is None
    assert p.remote_port is None
    assert p.password is None
    assert p.private_key_file is None
    assert p.timeout is None
    assert p.connection is None
    assert p.network_os is None
    assert p.is_connection_encrypted is False
    assert p.become is False
    assert p.become_method is None
    assert p.become_user is None
    assert p.become_pass is None
    assert p.sudo_flags is None
    assert p.verbosity is None
    assert p.only_tags is None
    assert p.skip_tags is None


if __name__ == "__main__":
    import doct

# Generated at 2022-06-21 00:54:23.904224
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    # Call method
    pass

# Generated at 2022-06-21 00:54:34.036616
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    config = ARA_CONFIG
    # mock_unresolved_lookup_result = {
    #         'hostname': 'controller1',
    #         'password': '',
    #         'username': 'ara_user',
    # }

    # mock_unresolved_lookup_result = {
    #         'hostname': '127.0.0.1',
    #         'password': '1234',
    # }

    # mock_unresolved_lookup_result = {
    #         'hostname': 'controller1',
    #         'password': '',
    #         'username': 'ara_user',
    #         'plugin': 'netconf',
    #         'port': 1830,
    #         'timeout': 20,
    # }

    mock_unresolved_lookup_

# Generated at 2022-06-21 00:54:38.974971
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    playbook_setup()
    pc = PlayContext()
    play = PlaybookInclude.load('../../../../../ansible_collections/ansible/builtin/tasks/include_tasks_test.yml', loader, variable_manager)
    try:
        pc.set_attributes_from_play(play)
    except Exception as e:
        assert False
# Unit tests for class TaskExecutor

# Generated at 2022-06-21 00:54:52.927367
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = Play()
    play.force_handlers = True
    playcontext = PlayContext(play)
    assert playcontext.force_handlers == play.force_handlers


# Generated at 2022-06-21 00:54:55.193111
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    ####################################################################
    #
    #
    ####################################################################
    pc = PlayContext()
    pc.set_become_plugin(None)




# Generated at 2022-06-21 00:55:07.810401
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    a = Ansible()
    b = AnsibleOptions()
    c = AnsibleRunner(a, b)
    c.run()
    variables = c.result
    connection = c.result.get('ansible_connection')
    new_play_context = PlayContext(play=c, passwords=c.result, connection_lockfd=c.result)
    task = c.result
    templar = Templar(loader=None)
    new_play_context.set_task_and_variable_override(task=task, variables=variables, templar=templar)
    new_play_context.update_vars(variables=variables)
    cmd = 'ansible-playbook --version > /dev/null'
    os.system(cmd)

# Generated at 2022-06-21 00:55:16.767583
# Unit test for constructor of class PlayContext

# Generated at 2022-06-21 00:55:22.055213
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    context._init_global_context(None)
    new_info = PlayContext()
    new_info.set_become_plugin(None)
    assert new_info._become_plugin is None



# Generated at 2022-06-21 00:55:33.353296
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
  #save old config
  old_config = C.config
  C.config = ConfigParser.ConfigParser()

  play_context = PlayContext()
  plugin = Mock()
  plugin.get_option.return_value = None
  play_context.set_attributes_from_plugin(plugin)
  # set again to test that it's not appending
  play_context.set_attributes_from_plugin(plugin)
  assert play_context._attributes == {}


  # set option to be returned from get_option
  plugin.get_option.return_value = 'test_value'
  play_context.set_attributes_from_plugin(plugin)

  # add other attr to options, expect it to be set as well
  plugin.options = {'other_attr': 'other_value'}
  play_context

# Generated at 2022-06-21 00:55:43.064867
# Unit test for constructor of class PlayContext
def test_PlayContext():
    def test_attrs():
        for attr in (
            'timeout', 'port', 'remote_user', 'remote_addr', 'connection',
            'password', 'private_key_file', 'verbosity', 'other_user',
            'other_pass', 'other_port', 'current_user', 'accelerate',
            'start_at_task', 'step', 'become', 'become_method', 'become_user',
            'become_pass', 'become_exe', 'become_flags',
            'prompt'
        ):
            # print getattr(pc, attr)
            assert getattr(pc, attr) == getattr(pc_default_attrs, attr)

    passwords = dict(conn_pass='conn_pass', become_pass='become_pass')

# Generated at 2022-06-21 00:55:50.097686
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    '''
    Tests that the set_become_plugin method of the PlayContext class works
    as expected.
    '''
    # Things that we'll need
    play = Mock(spec=Play())
    passwords = {}
    connection_lockfd = None
    # Instantiating a PlayContext object
    p_con = PlayContext(play, passwords, connection_lockfd)
    mock_plugin = Mock(spec=BecomePlugin())
    p_con.set_become_plugin(mock_plugin)
    assert mock_plugin == p_con.become_plugin

# Generated at 2022-06-21 00:55:52.617874
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    PlayContext(play=None, passwords=None, connection_lockfd=None)


# Generated at 2022-06-21 00:56:00.560900
# Unit test for method set_attributes_from_plugin of class PlayContext

# Generated at 2022-06-21 00:56:29.101041
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    variables = {
        'inventory_hostname': '127.0.0.1'
    }

    play_context = PlayContext()
    play_context.update_vars(variables)

    assert 'ansible_ssh_host' in variables
    assert 'ansible_host' in variables
    assert 'ansible_port' in variables
    assert 'ansible_user' in variables


# Generated at 2022-06-21 00:56:41.103633
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    context.CLIARGS = dict()
    # VERIFY ARGUMENTS
    assert set(['become_method', 'become_user', 'become', 'diff', 'verbosity', 'remote_user', 'private_key_file', 'timeout', 'start_at_task', 'step']) == set(PlayContext(play=None, passwords=None, connection_lockfd=None)._fields)
    # BEGIN UNIT TEST
    c = PlayContext(
        play=dict(),
        passwords=None,
        connection_lockfd=None
    )
    # Verify that the fields are set to the defaults
    for attr in c._fields:
        assert getattr(c, attr) == getattr(PlayContext, attr).default

    context.CLIARGS['timeout'] = 1
    # Test that time

# Generated at 2022-06-21 00:56:48.278616
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Setup test object
    obj = PlayContext(play=None, passwords=None, connection_lockfd=None)
    # Setup test variables
    plugin = "arg"
    # Invoke method
    obj.set_attributes_from_plugin(plugin)
    return obj.__dict__


# @add_metaclass(PlayContextMeta)

# Generated at 2022-06-21 00:57:00.508012
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    # g_module is a object of class FakeModule
    g_module.params = dict(
        ansible_user='m_user',
        ansible_become=True,
        ansible_become_method='su',
        ansible_become_user='root',
        ansible_become_pass='password'
    )
    # ansible_module is a object of class PythonModule
    ansible_module.params = g_module.params
    # connection_lockfd = 0
    play_context = PlayContext(play=play_ds, passwords=dict(), connection_lockfd=0)
    become_plugin = Become()
    play_context.set_become_plugin(become_plugin)
    assert play_context._become_plugin == become_plugin



# Generated at 2022-06-21 00:57:08.473121
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    runner = Runner()
    play = runner.play

    pc = PlayContext()

    pc.set_attributes_from_play(play)
    pc.set_attributes_from_cli()

    assert pc.timeout == C.ANSIBLE_TIMEOUT
    assert pc.verbosity == 0


# Generated at 2022-06-21 00:57:17.075778
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    from ansible.playbook.play import Play
    
    fake_play = Play().load({'name': 'test-play', 'hosts': 'all',
                          'gather_facts': 'no',
                          'tasks': []},
                         variable_manager=None, loader=None)
    fake_play = Play().load({'name': 'test-play', 'hosts': 'all',
                          'gather_facts': 'no',
                          'tasks': []},
                         variable_manager=None, loader=None)
    fake_play._included_files = []
    pc = PlayContext(play=fake_play)
    fake_play.force_handlers = True
    pc.set_attributes_from_play(fake_play)
    # This should be in the __init__ and not needed in the

# Generated at 2022-06-21 00:57:22.013892
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = MagicMock()
    play.force_handlers = False
    play_context = PlayContext(play)
    # test that PlayContext has force_handlers attribute set to False
    assert play_context.force_handlers == False

# Generated at 2022-06-21 00:57:34.568142
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    class DummyModule:
        def __init__(self, connection = "network_cli", **kwargs):
            self._options = kwargs

        def get_option(self, key):
            return self._options.get(key)

    def get_plugin_class(plugin):
        class_name = 'network_cli'
        return getattr(sys.modules[__name__], class_name, None)

    play = None
    passwords = {'conn_pass': "passwd", 'become_pass': "rootpasswd"}
    connection_lockfd = 4321
    pc = PlayContext(play=play, passwords=passwords, connection_lockfd=connection_lockfd)

# Generated at 2022-06-21 00:57:43.697324
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    # Set up mock inventory and play
    mock_inventory = {}
    mock_play = type('mock_play', (object,), {'force_handlers': False})

    # Create instance to test
    instance_to_test = PlayContext(play=mock_play)

    # Make assertions about created instance
    assert instance_to_test._force_handlers == False

    # Call method to test and make assertions
    instance_to_test.set_attributes_from_play(mock_play)
    assert instance_to_test._force_handlers == False
    mock_play.force_handlers = True
    instance_to_test.set_attributes_from_play(mock_play)
    assert instance_to_test._force_handlers == True


# Generated at 2022-06-21 00:57:55.323773
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play = get_play_context()
    # test with timeout
    setattr(context.CLIARGS, 'timeout', 5)
    play.set_attributes_from_cli()
    assert play.timeout == 5, "failed to set timeout from CLI"
    # test with private_key_file
    setattr(context.CLIARGS, 'private_key_file', '/path/to/key')
    play.set_attributes_from_cli()
    assert play.private_key_file == '/path/to/key', "failed to set private_key_file from CLI"
    # test with verbosity
    setattr(context.CLIARGS, 'verbosity', 0)
    play.set_attributes_from_cli()
    assert play.verbosity == 0, "failed to set verbosity from CLI"


# Generated at 2022-06-21 00:58:44.652211
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    obj = PlayContext()
    plugin = 'plugin'
    check = obj.set_become_plugin(plugin)
    assert check == None, "Setting of PlayContext's become plugin failed"
    assert obj._become_plugin == 'plugin', "Setting of PlayContext's become plugin failed"


# Generated at 2022-06-21 00:58:55.972713
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play = mock.Mock()
    play.force_handlers = False
    pc = PlayContext(play)

    task = mock.Mock()
    pc.set_task_and_variable_override(task, None, None)
    assert pc.force_handlers == False

    task.force_handlers = True
    pc.set_task_and_variable_override(task, None, None)
    assert pc.force_handlers == True

    task.force_handlers = False
    pc.set_task_and_variable_override(task, None, None)
    assert pc.force_handlers == False



# Generated at 2022-06-21 00:59:04.433410
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():

    # Test using a mock for play
    play = mock.MagicMock()
    play.serialize.return_value = dict()
    play.hosts = "hosts_mock"
    play.connection = "connection_mock"
    play.remote_user = "remote_user_mock"
    play.port = "port_mock"
    play.remote_addr = "remote_addr_mock"
    play.environment = "environment_mock"
    play.no_log = "no_log_mock"
    play.accelerate_port = "accelerate_port_mock"
    play.accelerate_ipv6 = "accelerate_ipv6_mock"
    play.accelerate_wait_timeout = "accelerate_wait_timeout_mock"
   

# Generated at 2022-06-21 00:59:18.366741
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    import os

    # Create context (with playbook)
    playbook = Playbook()
    task = Task().load(dict(action='ping', delegate_to='localhost'))
    play_context = PlayContext.load(task, dict(), dict())

    # Save (and remove) ansible_ssh_private_key_file from env
    keyfile = os.environ.get('ANSIBLE_SSH_PRIVATE_KEY_FILE', '')
    if keyfile:
        del os.environ['ANSIBLE_SSH_PRIVATE_KEY_FILE']

    # Create variables
    variables = dict()
    variables['ansible_ssh_private_key_file'] = keyfile
    variables['ansible_ssh_common_args'] = '-o arg1'

# Generated at 2022-06-21 00:59:24.557418
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Unit test for method set_attributes_from_plugin of class PlayContext
    '''
    # Initialize class to test
    PlayContext_obj = PlayContext()
    # TODO: Add tests of set_attributes_from_plugin and its expected exceptions
    assert False, "Test that attributes are correctly set"


# Generated at 2022-06-21 00:59:38.237581
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    p = PlayContext()
    p.update_vars = lambda x: None
    p.set_attributes_from_cli_args = lambda x: None
    p.set_attributes_from_play = lambda x: None
    p.set_attributes_from_plugin = lambda x: None

    task = Task()
    task.delegate_to = 'localhost'
    task.become = None
    task.remote_user = 'local_user'
    task.delegate_facts = True
    task.become_method = None
    task.become_user = None
    task.environment = dict()
    task.no_log = None
    task.check_mode = None
    task.diff = None
    task.port = None
    task.remote_port = None
    task.ssh_extra_args

# Generated at 2022-06-21 00:59:46.197773
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    p = Play()
    pc = PlayContext(play=p)
    plugin = PluginLoader(
        'become',
        'become_plugins.sudo',
        'BecomeModule',
        'become_plugin',
        'become_fragment',
        terms=dict(sudo='sudo', su='su', pbrun='pbrun', pfexec='pfexec'),
        config=dict(SUDOABLE_FILTERS=C.SUDOABLE_FILTERS)
    )
    pc.set_become_plugin(plugin)
    assert pc._become_plugin == plugin


# Generated at 2022-06-21 00:59:58.674931
# Unit test for constructor of class PlayContext
def test_PlayContext():
    parameters = {
        'port': "22",
        'timeout': "10",
        'connection': "paramiko",
        'remote_user': "neha",
        'remote_addr': "127.0.0.1",
        'password': "xyz",
        'private_key_file': "/home/neha/.ssh/id_rsa",
        'verbosity': "v",
        'start_at_task': "uptime",
        'force_handlers': "no",
    }
    passwords = {'become_pass': 'xyz'}
    play = {
        'become': 'yes',
        'become_method' : 'sudo',
        'become_user': 'root',
    }

# Generated at 2022-06-21 01:00:04.979473
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    play_context = PlayContext()

    class MockAnsiblePlugin(object):
        def __init__(self):
            self.get_option = MagicMock(return_value=None)

    plugin = MockAnsiblePlugin()
    play_context.set_become_plugin(plugin)
    plugin.get_option.assert_called_with('prompt')


# Generated at 2022-06-21 01:00:17.456366
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
        '''
        This demonstrates how to set up and run a python unit test using the unittest library.
        '''
        # Create an instance of the PlayContext class
        play_context = PlayContext()

        # Create a unittest TestCase
        testcase = unittest.TestCase('__init__')

        # Set the values of some of the members of the PlayContext object
        play_context._attributes = { 'connection_lockfd': None }
        play_context.set_attributes_from_plugin("paramiko")
        # If the test doesn't raise an exception, it passes; otherwise, it fails
        testcase.assertIsNotNone(play_context)

# Generated at 2022-06-21 01:01:52.443272
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = {
            'force_handlers' : True,
            }
    result = PlayContext(play)
    assert result.force_handlers == True


# Generated at 2022-06-21 01:02:00.769378
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    class Struct:
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class TestModule(object):
        def __init__(self):
            self.params = Struct(**{'ansible_host': 'host_1',
                                    'ansible_port': 'port_1',
                                    'ansible_user': 'user_1',
                                    'ansible_password': 'pass_1',
                                    'ansible_ssh_private_key_file': 'ssh_pri_key_file_1',
                                    'ansible_become_user': 'become_user',
                                    'ansible_become_password': 'become_password'})
        def get_option(self, key):
            return self.params.__dict__.get(key)

# Generated at 2022-06-21 01:02:12.645490
# Unit test for constructor of class PlayContext
def test_PlayContext():

    class TestPlay1:

        def __init__(self, host_list, roles, vars):
            self.hosts = host_list
            self.vars = vars
            self.serialized_data = {
                "force_handlers": True,
                "become_user": "user1",
                "become_method": "become",
                "verbosity": 3,
                "timeout": 123
            }

        def __getattr__(self, item):
            if item in self.serialized_data:
                return self.serialized_data[item]
            else:
                raise AttributeError

        def __getitem__(self, item):
            return self.vars[item]


# Generated at 2022-06-21 01:02:24.679330
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    class TestClass:
        def __init__(self):
            self.play_context = PlayContext()
            self.vars = {}
            self.task = Task()
            self.vars['ansible_python_interpreter'] = '/usr/bin/python'
            self.task.remote_user = 'ansible-user'
            self.task.delegate_to = 'localhost'

        def test(self):
            self.play_context.set_task_and_variable_override(self.task, self.vars, Templar())
            self.play_context.set_become_plugin('')
            return True
    test_class = TestClass()
    assert test_class.test() == True, 'Test  PlayContext set_become_plugin method Failed !'

# Generated at 2022-06-21 01:02:27.989502
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = dict2obj({'force_handlers': True})
    test_PlayContext = PlayContext(play)
    assert test_PlayContext.force_handlers is True


# Generated at 2022-06-21 01:02:40.604479
# Unit test for method update_vars of class PlayContext
def test_PlayContext_update_vars():
    result = PlayContext_update_vars()
    assert result['ansible_host'] == 'test_host'
    assert result['ansible_port'] == '22'
    assert result['ansible_user'] == 'test_user'
    assert result['ansible_connection'] == 'test_connection'
    assert result['ansible_ssh_host'] == 'test_ssh_host'
    assert result['ansible_ssh_user'] == 'test_ssh_user'
    assert result['ansible_ssh_port'] == '3'
    assert result['ansible_ssh_private_key_file'] is None
    assert result['ansible_ssh_pass'] == 'test_ssh_pass'
    assert result['ansible_password'] == 'test_password'

# Generated at 2022-06-21 01:02:42.033224
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    play = Play()
    play.force_handlers = True

    pc = PlayContext()

    pc.set_attributes_from_play(play)
    assert pc.force_handlers == True



# Generated at 2022-06-21 01:02:42.778650
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    assert False # TODO: implement your test here


# Generated at 2022-06-21 01:02:48.852427
# Unit test for method set_attributes_from_play of class PlayContext
def test_PlayContext_set_attributes_from_play():
    # setting up fixtures for test
    play = mock.MagicMock()
    obj = PlayContext(play=play)
    obj.set_attributes_from_play(play)
    assert obj.force_handlers == play.force_handlers


# Generated at 2022-06-21 01:03:02.284281
# Unit test for method set_become_plugin of class PlayContext
def test_PlayContext_set_become_plugin():
    # set_become_plugin() update become from plugin, therefore we mock a plugin object
    class MockedPlugin (object):
        def __init__(self, become_method, become_pass, become_user):
            self.become_method = become_method
            self.nolog_passwords = become_pass


        def get_option(self, flag):
            if flag == 'become_method':
                return self.become_method
            elif flag == 'become_pass':
                return self.nolog_passwords
            elif flag == 'become_user':
                return self.become_user

    play = None
    passwords = {}
    connection_lockfd = None

    play_context = PlayContext(play, passwords, connection_lockfd)

    # init data