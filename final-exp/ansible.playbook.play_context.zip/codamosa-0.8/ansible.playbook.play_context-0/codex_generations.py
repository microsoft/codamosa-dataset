

# Generated at 2022-06-11 10:18:54.600219
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, shared_loader_obj=loader, variables=dict())

    old_play_context = PlayContext()
    old_play_context.become = True
    old_play_context.become_method = 'sudo'
    old_play_context.become_user = 'root'
    old_play_context.check_mode = True
    old_play_context.connection = 'smart'
    old_play_context.diff = False
    old_play_context.executable = '/bin/bash'
    old_play_context.no_log = False
    old_play_context.password = 'secret'

# Generated at 2022-06-11 10:19:07.483983
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    '''
    Test PlayContext.set_attributes_from_cli
    '''

    # setup
    play = Play()
    passwords = dict(conn_pass='pass1', become_pass='pass2')
    connection_lockfd = 1
    context.CLIARGS = dict(timeout=10, private_key_file="/tmp/test", verbosity=5, start_at_task=None)

    # test call
    play_context = PlayContext(play, passwords, connection_lockfd)
    play_context.set_attributes_from_cli()

    # assert
    assert play_context.timeout == 10
    assert play_context.private_key_file == "/tmp/test"
    assert play_context.verbosity == 5
    # not tested
    # if context.CLIARGS:
    #     self

# Generated at 2022-06-11 10:19:14.495337
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Test specific setup
    context.CLIARGS = None

    plugin = ConnectionBase()

    with patch.object(plugin, 'get_option') as mock_plugin_get_option:

        # Execute the code to be tested
        play_context = PlayContext(play = None)
        play_context.set_attributes_from_plugin(plugin)

        # Test assertions
        assert not mock_plugin_get_option.called



# Generated at 2022-06-11 10:19:29.176930
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    my_task = Task()
    my_task.delegate_to = 'localhost'
    my_task.remote_user = 'root'
    my_task.check_mode = True
    my_task.diff = False

    my_vars = dict()
    my_vars['ansible_connection'] = 'paramiko'
    my_vars['ansible_user'] = 'root'
    my_vars['ansible_host'] = 'localhost'
    my_vars['ansible_port'] = '22'
    my_vars['ansible_become'] = True
    my_vars['ansible_become_method'] = 'sudo'
    my_vars['ansible_become_user'] = 'root'

# Generated at 2022-06-11 10:19:40.144018
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play = Play()
    connection = Connection()
    connection.set_options({
        'ansible_connection': 'winrm',
        'ansible_winrm_server_cert_validation': 'ignore',
        'ansible_winrm_scheme': 'http',
        'ansible_winrm_transport': 'kerberos',
        'ansible_winrm_kinit_mode': 'managed',
        'ansible_winrm_kinit_cmd': 'kinit',
        'ansible_winrm_kerberos_delegation': False,
        'ansible_winrm_kerberos_hostname_override': '',
        'ansible_port': 5986,
    })
    play_context = PlayContext(play, passwords=None, connection_lockfd=None)

# Generated at 2022-06-11 10:19:49.459014
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    hosts = [
        Host(name='example.com')
    ]
    variable_manager = VariableManager(loader=None, inventory=Inventory(hosts=hosts))
    variable_manager._extra_vars = {}
    templar = Templar(loader=None, variables=variable_manager.get_vars(loader=None, play=None, host=None))

    passwords = {'conn_pass': 'pass', 'become_pass': 'pass'}
    play_context = PlayContext(play=None, passwords=passwords)

    task = Task()
    task.action = 'shell'
    task.args = {'_raw_params': 'uname -a'}
    task.delegate_to = None

    all_vars = dict(C.MAGIC_VARIABLE_MAPPING)
   

# Generated at 2022-06-11 10:19:59.847428
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    class Task():
        def __init__(self):
            self.delegate_to = None
            self.check_mode = None

    play = Play()
    passwd = {'conn_pass':'conn_pass', 'become_pass':'become_pass'}
    con_lockfd = None

    pl_context = PlayContext(play=play, passwords=passwd, connection_lockfd=con_lockfd)
    task = Task()
    vars_dict = {}
    templar =  MagicMock()


# Generated at 2022-06-11 10:20:08.464348
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    """
    TESTING:
    1. The value returned by set_task_and_variable_override
    2. The value returned by set_task_and_variable_override is the expected one
    """
    #testing via test_utils
    assert isinstance(test_utils.play_context.copy(), PlayContext)
    assert test_utils.play_context.set_task_and_variable_override(test_utils.task, test_utils.variables, None) == PlayContext(C.DEFAULT_TRANSPORT)


# Generated at 2022-06-11 10:20:17.317380
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    class TaskMock(object):
        name = 'tock'
    templar = Mock(Templar)
    variables = {'ansible_port': 22, 'ansible_user': 'root'}

    pc = PlayContext()

    pc.set_attributes_from_play(TaskMock())

    for attr in TASK_ATTRIBUTE_OVERRIDES:
        setattr(TaskMock, attr, None)

    play_context = pc.set_task_and_variable_override(TaskMock(), variables, templar)

    assert play_context.remote_addr is None
    assert play_context.remote_user == 'root'
    assert play_context.network_os is None
    assert play_context.port == 22

# Generated at 2022-06-11 10:20:20.523013
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    context = PlayContext()
    context.set_attributes_from_plugin("test.test_connection_info")

    assert isinstance(context.new_attr, bool)


# Generated at 2022-06-11 10:20:56.547771
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Test 1: functional test with task and variables from file
    # make object of Task and add values in task object
    task1 = Task()
    task1.name = 'testtask'
    task1.connection = 'local'
    task1.remote_user = 'testuser'
    task1.delegate_to = 'localhost'
    task1.check_mode = False
    task1.diff = False

    # make object of PlayContext
    pc = PlayContext()

    # make a dictionary of variables and add the variables used in testcase
    variables = dict()
    variables['ansible_connection'] = 'ssh'
    variables['ansible_ssh_port'] = 2222
    variables['ansible_ssh_user'] = 'user1'
    variables['ansible_user'] = 'user1'

# Generated at 2022-06-11 10:21:04.897342
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    print("test_PlayContext_set_task_and_variable_override")
    play = Play()
    passwords = {}

    # Case1: test property is not set
    play_context = PlayContext(play, passwords, None)
    task = Mock()
    task.become = None
    variables = {}
    play_context.set_task_and_variable_override(task, variables, None)

    # Case2: test property is set
    play_context = PlayContext(play, passwords, None)
    task = Mock()
    task.become = False
    variables = {}
    play_context.set_task_and_variable_override(task, variables, None)


if __name__ == '__main__':
    test_PlayContext_set_task_and_variable_override()

# Generated at 2022-06-11 10:21:12.862232
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()
    # self.play_context.set_attributes_from_plugin(None)
    # self.play_context.set_attributes_from_plugin('connection')
    # self.play_context.set_attributes_from_plugin('become')
    # self.test_runner.set_attributes_from_plugin('nobody_plugin')
    # self.test_runner.set_attributes_from_plugin('ec2')
    play_context.set_attributes_from_plugin('smart')


# Generated at 2022-06-11 10:21:26.109151
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    #
    # Function:
    #  PlayContext.set_task_and_variable_override
    #
    # Description:
    #  Test case for PlayContext.set_task_and_variable_override
    #
    # Parameters:
    #  None
    #
    # Return:
    #  None
    #
    """
    Test case for PlayContext.set_task_and_variable_override
    """
    # Create the task object
    task_obj = Task()

    # Test for normal use case
    task_obj.become = True
    task_obj.become_method = 'sudo'
    task_obj.become_user = 'wheel'
    task_obj.check_mode = False
    task_obj.connection = 'smart'

# Generated at 2022-06-11 10:21:34.909145
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    p = PlayContext()
    p.set_attributes_from_cli()
    assert p.remote_addr == None
    assert p.remote_user == None
    assert p.password == None
    assert p.port == None
    assert p.private_key_file == None
    assert p.timeout == 10
    assert p.connection == 'smart'
    assert p.network_os == None
    assert p.remote_tmp == None
    assert p.executable == None
    assert p.verbosity == None
    assert p.become == False
    assert p.become_method == None
    assert p.become_user == None
    assert p.become_pass == None
    assert p.prompt == None
    assert p.success_key == None
    assert p.connection_lockfd == None
    assert p

# Generated at 2022-06-11 10:21:44.101860
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """Check for correct value of attributes after applying set_attributes_from_plugin() function
    """
    mock_plugin = Mock()
    mock_plugin._load_name = "MethodName"
    c = PlayContext()
    c.set_attributes_from_plugin(mock_plugin)
    assert c.timeout == C.DEFAULT_TIMEOUT
    assert c.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert c.verbosity == 0
    assert c.start_at_task == None
    assert c.step == False
    assert c.force_handlers == False
    assert c.become_plugin == None

# Generated at 2022-06-11 10:21:56.548930
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    playbook = AnsiblePlaybook()
    play = AnsiblePlay()
    task = AnsibleTask()
    play._ds = dict(connection="smart", remote_user="user")
    task._ds = dict(remote_user="taskuser", delegate_to="test")
    playbook._ds = dict(remote_user="playbookuser", serial=1)
    pc = PlayContext(play=play, passwords={})
    pc.set_attributes_from_plugin('local')
    pc.set_attributes_from_plugin('winrm')
    pc.set_attributes_from_play(play)
    pc.set_attributes_from_cli()

# Generated at 2022-06-11 10:22:00.431906
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # play_context = PlayContext(play=None, passwords=None, connection_lockfd=None)
    play_context = PlayContext()
    cliarg = {'timeout':'1'}
    context.CLIARGS = cliarg
    play_context.set_attributes_from_cli()


# Generated at 2022-06-11 10:22:04.365324
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    c = PlayContext(play=None, passwords=None, connection_lockfd=None)
    c.set_attributes_from_plugin(BaseConnection())
    assert c._attributes.get('connection') == 'smart' # default value

# Generated at 2022-06-11 10:22:13.537648
# Unit test for constructor of class PlayContext
def test_PlayContext():

    assert PlayContext(play=None)

    context = PlayContext(play=Mock())

    context.vars.update({'ansible_ssh_pass': 'foo', 'ansible_become_pass': 'bar'})

    context.set_task_and_variable_override(Mock(), context.vars, None)

    passwords = dict(conn_pass='foo', become_pass='bar')

    context2 = PlayContext(play=Mock(), passwords=passwords)

    assert context2.vars['ansible_ssh_pass'] == 'foo'
    assert context2.vars['ansible_become_pass'] == 'bar'

# Generated at 2022-06-11 10:22:39.624376
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context = PlayContext()
    play_context.set_attributes_from_cli()
    assert play_context.private_key_file == 'test_value_for_default_private_key_file'
    assert play_context.verbosity == 10

if __name__ == '__main__':
    test_PlayContext_set_attributes_from_cli()

# Generated at 2022-06-11 10:22:46.295726
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    hostvars = {"ansible_host": "192.168.1.1"}
    task = Task()
    task.delegate_to = "myhost"
    task.connection = "local"
    task.become = True
    pc = PlayContext()
    pc2 = pc.set_task_and_variable_override(task, hostvars, MagicMock())

    assert pc2.connection == "local"
    assert pc2.become == True


# Generated at 2022-06-11 10:22:47.431536
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    assert 0


# Generated at 2022-06-11 10:22:58.268238
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    test_host = Host("test_host")
    test_host.vars['ssh_port'] = 22
    test_host.vars['ansible_ssh_port'] = 23
    test_host.vars['ansible_port'] = 24
    test_host_vars = test_host.vars

    test_delegate_to = "test_delegate_to"
    test_delegated_host = Host("test_delegated_host")
    test_delegated_host.vars['ansible_ssh_port'] = 25
    test_delegated_host.vars['ansible_port'] = 26
    test_delegated_vars = {"test_delegated_host": test_delegated_host.vars}


# Generated at 2022-06-11 10:23:01.347059
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # FIXME: not implemented
    #assert isinstance(PlayContext().set_attributes_from_plugin(arg='value'), PlayContext)
    assert True



# Generated at 2022-06-11 10:23:13.082555
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """
    Test case to test the PlayContext's set_attributes_from_plugin() method
    PlayContext's set_attributes_from_plugin() method adds the options
    specified in the plugin class to the PlayContext instance.
    :return: None
    """
    # Create a mock object of the class object and return the object
    # to the original class object.
    test_dict = {
            "module_utils":
                {
                    "common.collections": Mock(),
                    "common.validation": Mock()
                },
            "common.collections": Mock(),
            "common.validation": Mock()
            }
    original_module = sys.modules[__name__]
    sys.modules[__name__] = Mock(**test_dict)

    # Create a PlayContext object
    pc = PlayContext()
    cl

# Generated at 2022-06-11 10:23:23.325043
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
  # Testing for method set_attributes_from_plugin(self, plugin)
  # Testing expected exceptions
  import os
  import random
  import tempfile
  from ansible.errors import AnsibleError
  from ansible.playbook.play_context import PlayContext
  from ansible.plugins.loader import connection_loader, lookup_loader
  try:
    pc = PlayContext()
    connection_plugin = connection_loader.get('local')
    pc.set_attributes_from_plugin(connection_plugin)
    lookup_plugins = lookup_loader.all()
    for plugin_name in lookup_plugins:
      try:
        pc.set_attributes_from_plugin(lookup_plugins[plugin_name])
      except Exception as e:
        pass
  except Exception as e:
    pass

# Generated at 2022-06-11 10:23:35.220296
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    variables = dict()
    templar = MagicMock()
    host_connection_info = PlayContext(play=MagicMock())
    task = MagicMock()
    task.delegate_to = None
    host_connection_info.remote_addr = str()
    host_connection_info.port = None
    host_connection_info.remote_user = str()

    play_context = PlayContext()
    # test with no parameter
    new_play_context = play_context.set_task_and_variable_override(task, variables, templar)
    assert new_play_context.executable is None
    # test with parameters
    task2 = MagicMock()
    task2.delegate_to = ''

# Generated at 2022-06-11 10:23:47.030759
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    data = base64.b64encode(b'k8s: ENC[k8s_auth_apiVersion, v1] ENC[k8s_auth_args, {'
                           b'"inCluster":true,"asUser":true,"asGroup":null}]')
    os.environ['KUBECONFIG'] = 'foo'
    os.environ['K8S_AUTH_KUBECONFIG'] = 'bar'
    os.environ['K8S_AUTH_DATA'] = data
    assert PlayContext()._kubeconfig == 'foo'
    del os.environ['KUBECONFIG']
    assert PlayContext()._kubeconfig == 'bar'
    del os.environ['K8S_AUTH_KUBECONFIG']
    assert PlayContext

# Generated at 2022-06-11 10:23:58.266035
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.plugins.loader import get_plugin_class
    instance = PlayContext(play=None, passwords=None, connection_lockfd=None)

    plugin = get_plugin_class('connection_plugins/smart').plugin_class('/usr/bin/ssh', '/usr/bin/ssh', 'smart')
    plugin.set_option('private_key_file', 'ansible.private_key_file')
    plugin.set_option('verbosity', 'ansible.verbosity')
    plugin.set_option('timeout', 'ansible.timeout')
    plugin.set_option('pipelining', 'ansible.pipelining')
    plugin.set_option('start_at_task', 'ansible.start_at_task')
    plugin.set_option('connection_lockfd', 'ansible.connection_lockfd')
   

# Generated at 2022-06-11 10:24:23.615219
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # test set_attributes_from_plugin(self, plugin):
    info = PlayContext()
    info.set_attributes_from_plugin(plugin=None)
            

# Generated at 2022-06-11 10:24:34.372366
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from collections import namedtuple
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.template import Templar
    play_context = PlayContext()
    play_context.set_attributes_from_play(play=namedtuple('play', 'force_handlers')(force_handlers=False))
    play_context.set_attributes_from_cli()

# Generated at 2022-06-11 10:24:44.925486
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    templar = Templar(loader=DictDataLoader({}))
    variables = {}

    # setup test PlayContext instance
    # PlayContext.set_task_and_variable_override() tests
    def _connection_variable_expansion(task_c, variable_c, task_v, variable_v):
        '''
        Unit test for method set_task_and_variable_override of class PlayContext
        :return:
        '''
        pc = PlayContext(play=None, passwords=None, connection_lockfd=None)
        pc._attributes[task_c] = task_v
        variables[variable_c] = variable_v

        new_info = pc.set_task_and_variable_override(task=None, variables=variables, templar=templar)

# Generated at 2022-06-11 10:24:50.145699
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    task = Mock()
    host = Mock()
    variables = dict()
    assert play_context.set_task_and_variable_override(task, variables, host) == None

test_PlayContext_set_task_and_variable_override()



# Generated at 2022-06-11 10:24:50.595658
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    pass

# Generated at 2022-06-11 10:24:59.085644
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    context.CLIARGS = {'timeout': '5',
                       'private_key_file': 'filename',
                       'verbosity': '0',
                       'start_at_task': 'task1'}
    context.CLIARGS.update({'connection': 'smart'})

    play_context = PlayContext()
    play_context.set_attributes_from_cli()

    assert play_context.timeout == 5
    assert play_context.private_key_file == 'filename'
    assert play_context.verbosity == 0
    assert play_context.start_at_task == 'task1'
    assert play_context.connection == 'ssh'



# Generated at 2022-06-11 10:25:03.513606
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    fixture_obj = PlayContext(play=None, passwords=None, connection_lockfd=None)
    fixture_plugin = fixture_obj.set_attributes_from_plugin(plugin=None)
    assert fixture_plugin is None



# Generated at 2022-06-11 10:25:06.178811
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context_obj = PlayContext(play=None, passwords=None, connection_lockfd=None)



# Generated at 2022-06-11 10:25:12.926808
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pc = PlayContext()
    pc.set_attributes_from_plugin('Mock')
    assert pc.connection == 'mock_connection'
    assert pc.remote_addr == 'mock_remote_addr'
    assert pc.remote_user == 'mock_remote_user'
    assert pc.password == 'mock_password'
    assert pc.port == 8888



# Generated at 2022-06-11 10:25:15.102204
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pc = PlayContext()
    pc.set_attributes_from_plugin("git")


# Generated at 2022-06-11 10:26:08.523756
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """Unit test for PlayContext.set_attributes_from_plugin()."""
    # Set up mocks
    plugin = Mock()  # noqa
    # Call the method
    play_context = PlayContext()
    play_context.set_attributes_from_plugin(plugin)



# Generated at 2022-06-11 10:26:14.141882
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    attrs_dict = dict(
        timeout=10,
        verbosity=5,
        start_at_task=None,
    )
    example_plugin = MOCK_PLUGIN_CONFIG

    context = PlayContext()
    context.set_attributes_from_plugin(example_plugin)
    for k, v in attrs_dict.items():
        assert getattr(context, k) == v



# Generated at 2022-06-11 10:26:14.551854
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    pass

# Generated at 2022-06-11 10:26:22.995207
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    non_ascii_utf8_data = "utf-8 文字列".encode("utf-8")
    non_ascii_utf8_data_len = 11
    non_ascii_ascii8bit_data = "ascii8bit 文字列".encode("utf-8").decode("utf-8")
    non_ascii_ascii8bit_data_len = 11

    import ansible.plugins.loader as plugin_loader

    # test_set_attributes_from_plugin_no_plugin
    pc = PlayContext()
    assert pc.network_os is None
    assert pc.become_method is None
    assert pc.become_user is None
    assert pc.become_pass is None
    assert pc.become_exe

# Generated at 2022-06-11 10:26:26.483071
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play = Mock()
    passwords = {}
    connection_lockfd = None
    pc = PlayContext(play=play, passwords=passwords, connection_lockfd=connection_lockfd)
    plugin = Mock()
    pc.set_attributes_from_plugin(plugin)


# Generated at 2022-06-11 10:26:35.400135
# Unit test for constructor of class PlayContext
def test_PlayContext():

    p = Playbook()
    host = Host('example')
    t = Task(host=host)
    t._role_name = "test_role"
    pl = Play(hosts=[host], tasks=[t])
    p.add_play(pl)

    # Create a PlayContext object with a reference to the Play object
    pc = PlayContext(play=pl)

    # Now, try to access the fields of PlayContext object pc
    assert pc.remote_addr == host
    assert pc.remote_user == C.DEFAULT_REMOTE_USER
    assert pc.port == C.DEFAULT_REMOTE_PORT
    assert pc.timeout == C.DEFAULT_TIMEOUT

    # Check that the '_delegate_to' field is passed from Task object to PlayContext object

# Generated at 2022-06-11 10:26:40.912847
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    set_module_args({'remote_user': 'johnd',
                     'become': True,
                     'connection': 'winrm',
                     'network_os': 'eos'})
    pc = PlayContext()
    pc.become = True
    pc.set_attributes_from_cli()
    assert pc.connection == 'winrm'
    assert pc.network_os == 'eos'


# Generated at 2022-06-11 10:26:51.251552
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-11 10:27:02.210737
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    # Setup test vars for input.
    test_host = Host(name="testhost")
    test_variable_manager = VariableManager(loader="test",hosts=[test_host])
    test_task = Task()

    test_task.remote_user = "testuser"
    test_task.become = False
    test_task.become_user = "testuser"
    test_task.become_method = "sudo"

    # Set the task and any variables
    test_context = PlayContext(task=test_task)

# Generated at 2022-06-11 10:27:10.598319
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """
    This function is for testing PlayContext.set_attributes_from_plugin()
    """
    print("<<start test PlayContext.set_attributes_from_plugin>>")

    test_target = 'test'
    test_value = 'test_value'

    play = dict(become=True, become_user='become_user_value', become_method='become_method_value',
                connection='connection_value', remote_user='remote_user_value', become_pass=None,
                check=True, diff=False, force_handlers=True, any_errors_fatal=False, no_log=False,
                serial=1)

    p = PlayContext(play)
    assert p.become == True
    assert p.become_user == 'become_user_value'
    assert p