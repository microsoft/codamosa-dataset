

# Generated at 2022-06-11 10:18:52.179831
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pass


# Generated at 2022-06-11 10:18:56.357030
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    print("({})".format(test_PlayContext_set_attributes_from_plugin.__name__), end=' ')
    pass
    # TODO: assert
    print("pass")



# Generated at 2022-06-11 10:19:09.190652
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play = Play()
    play.force_handlers = True

    passwords = dict(
        conn_pass = 'conn_pass',
        become_pass = 'become_pass'
    )

    connection_lockfd = 3

    play_context = PlayContext(play, passwords, connection_lockfd)
    task = Task()

    task.check_mode = True
    task.diff = False
    task.delegate_to = 'delegate_to'


# Generated at 2022-06-11 10:19:16.017618
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    class MyPlayContext(PlayContext):
        def set_attributes_from_play(self, play):
            self._attributes['connection'] = 'smart'
            self._attributes['remote_user'] = 'test_remote_user'
            self._attributes['connection_user'] = 'test_connection_user'

    class MyTask(object):
        def __init__(self):
            self.connection = 'test_connection'
            self.remote_user = 'test_task_remote_user'
            self.connection_user = 'test_task_connection_user'
            self.force_handlers = True
            self.delegate_to = 'test_delegate_to'

    class MyTemplar(object):
        def __init__(self, delegated_host_name):
            self.delegated_host

# Generated at 2022-06-11 10:19:30.782456
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # mock a data source
    class source:
        def __init__(self):
            self.data = dict()
        
        def get_option(self, option):
            return self.data.get(option)

        def set_option(self, option, value):
            self.data[option] = value
    
    # create object
    obj = PlayContext(play = None)

    # set attribs from plugin 
    plugin = source()
    plugin.set_option('connection', 'ssh')
    obj.set_attributes_from_plugin(plugin)

    # set attribs from play
    play = source()
    play.set_option('remote_user', 'test')
    obj.set_attributes_from_play(play)

    # set attribs from cli
    obj.set_att

# Generated at 2022-06-11 10:19:41.857609
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    t = Task()
    t.remote_user = 'test_remote_user'
    t.ansible_user = 'test_ansible_user'
    t.ansible_connection = 'local'

    pc = PlayContext()
    pc.connection = 'local'
    pc.remote_user = 'test_remote_user'

    vars = dict()
    vars['ansible_connection'] = 'network_cli'
    vars['ansible_user'] = 'test_ansible_user'
    vars['ansible_port'] = 22
    vars['ansible_host'] = 'test_ansible_host'
    vars['ansible_network_os'] = 'iosxr'


# Generated at 2022-06-11 10:19:50.157074
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import vault_loader
    from ansible.cli.playbook.play_context import PlayContext

    import json
    import os

    loader = DataLoader()
    test_hosts = "./tests/fixtures/hosts.yaml"
    inv_objs = InventoryManager(loader=loader, sources=test_hosts)
    inv_objs.set_inventory()
    inventory = inv_objs.get_inventory()


# Generated at 2022-06-11 10:20:00.617471
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    hostvars = {'ansible_ssh_port':22,'ansible_host':'testhostname'}
    play = Play()
    play.connection = 'paramiko'
    play_context = PlayContext(play = play)
    # case 1: when task.delegate_to has a value
    task = Task()
    task.delegate_to = 'testdelegated'
    task.remote_user = 'testuser'
    task.connection = 'winrm'
    task.ssh_extra_args = '-C'
    delegated_host_name = 'testhostname'
    delegated_vars = {'ansible_host':'testhostname','ansible_winrm_port':5986,'ansible_user':'testdelegateuser','ansible_password':'testpassword'}

# Generated at 2022-06-11 10:20:12.397077
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.playbook import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    # create inventory object
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_vars=HostVars(loader=loader, inventory=inventory))
    task = Task()
    task.name = 'test_task'

    # set few play parameters
    task.force_handlers = False
    task.delegate_to = 'localhost'

    # set few task parameters
    task.gather_facts = 'no'
    task.any_errors_fatal = False

   

# Generated at 2022-06-11 10:20:17.990137
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    p = PlayContext(None)
    p.set_attributes_from_plugin(p)
    with pytest.raises(Exception) as excinfo:
      p.set_attributes_from_plugin(None)
    assert 'the plugin is empty.' in str(excinfo.value)
    p.set_attributes_from_plugin(FakePlugin())
    p.private_key_file = 'test.pem'
    p.verbosity = 2
    assert p.private_key_file == 'test.pem'
    assert p.verbosity == 2


# Generated at 2022-06-11 10:20:45.803513
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    import unittest

    import ansible.constants as C
    import ansible.module_utils.urls as urls
    import ansible.parsing.dataloader as dataloader
    import ansible.playbook.play_context as play_context
    import ansible.template as template
    import ansible.utils.vars as vars
    import ansible.plugins.loader as plugin_loader
    import ansible.inventory.host as host
    import ansible.inventory.manager as inventory_manager
    import ansible.vars.manager as var_manager
    import ansible.vars.hostvars as hostvars

    from ansible.plugins.loader import connection_loader
    from ansible.template import Templar
    from ansible.playbook.task import Task

# Generated at 2022-06-11 10:20:57.875411
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    context._init_global_context()
    host = 'hostname'
    self = dict()
    self['play'] = dict()
    self['play']['remote_user'] = 'remote_user'
    self['play']['verbosity'] = 'verbosity'
    self['play']['force_handlers'] = 'force_handlers'
    self['task'] = dict()
    self['task']['delegate_to'] = 'delegate_to'
    self['task']['remote_user'] = 'remote_user'
    self['task']['port'] = 'port'
    self['task']['gather_facts'] = 'gather_facts'
    self['task']['no_log'] = 'no_log'
    self['task']['register'] = 'register'

# Generated at 2022-06-11 10:21:05.533052
# Unit test for constructor of class PlayContext
def test_PlayContext():

    # pylint: disable=too-many-branches,too-many-statements,too-many-locals
    def assert_member_equals_default_value(member, default_value=None):
        if isinstance(default_value, dict):
            for k, v in iteritems(default_value):
                assert getattr(play_context, member)[k] == v
        else:
            assert getattr(play_context, member) == default_value

    def assert_member_equals_expected_value(member, expected_value):
        assert getattr(play_context, member) == expected_value

    def assert_member_equals_updated_value(member, updated_value):
        assert getattr(play_context, member) == updated_value

    ##########################################################################################################
    # Test PlayContext()

# Generated at 2022-06-11 10:21:16.678981
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    PlayContext._valid_attrs.update(TASK_ATTRIBUTE_OVERRIDES)
    variable_manager = VariableManager()

    play_context = PlayContext(host='host_name', port=22, remote_user='remote_user',
                               connection='paramiko', remote_addr='remote_addr')
    play_context.set_task_and_variable_override(Task(), variable_manager, Templar())

    # set_task_and_variable_override should return a new object
    assert play_context.host != play_context._attributes['host']

    # set_task_and_variable

# Generated at 2022-06-11 10:21:29.804010
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-11 10:21:36.565994
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # test the PlayContext() constructor
    play = Play()
    play_context = PlayContext(play=play)

    # it would be nice to have automatic validation that the K/V attributes put in _attributes exist on the class as _foo
    # (and also that they are correct type, using FieldAttribute)
    # also that they are complete, meaning any top level field attribute of the class is defined
    assert play_context.connection == 'smart'
    assert play_context.timeout == C.DEFAULT_TIMEOUT
    assert play_context.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert play_context.verbosity == 0

    # now run the method we're actually testing
    play_context.set_attributes_from_cli()

    # Now, pretend we ran the command line as follows:
    #

# Generated at 2022-06-11 10:21:46.628312
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    # test object initialization
    # ansible.playbook.play.PlayContext object at 0x7f4b7c2f4e10
    
    outcome = {}
    
    
    # execute method with arguments
    # required arguments:
    #  parameter: plugin
    #  parameter: self
    outcome['execute'] = execute()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # check for positive outcomes
    if outcome['execute'] ==  "":
        return 1
    
    # catch Exception
    if outcome['execute'] ==  "":
        return 1
    
    else:
        return 0

# Generated at 2022-06-11 10:21:58.597945
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import PlaySerializer
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    import yaml

    class TestPlay(Play):
        pass


# Generated at 2022-06-11 10:22:01.278851
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    c_obj = PlayContext(None, None)
    set_attributes_from_plugin(c_obj, None)
    assert c_obj._attributes == {}

# Generated at 2022-06-11 10:22:12.845532
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    with patch("ansible.executor.module_common.Connection") as Connection, \
         patch("ansible.plugins.loader.connection_loader.get", return_value=Connection):

        p = PlayContext()

        # emulate CLI options
        p.set_attributes_from_cli()

        task = mock.Mock()
        task.vars = dict(
            ansible_connection=dict(),
            ansible_port=dict(),
            ansible_host=dict(),
        )
        task.transport = 'ssh'
        task.connection = 'ssh'

        p.set_task_and_variable_override(task, dict(), None)

        assert p.connection == 'ssh'
        assert p.port == 2222
        assert p.host == 'xyzzy'


# Generated at 2022-06-11 10:22:44.526791
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    p = Play()
    task = Task()
    task._role = None
    task.delegate_to = None
    task.delegate_facts = None
    task.name = 'setup'
    task.loop = None
    task.action = 'setup'
    task.async_val = None
    task.async_jid = None
    task.any_errors_fatal = None
    task.block = None
    task.when = None
    task.loop_control = None
    task.local_action = None
    task.run_once = None
    task.notify = None
    task.meta = None
    task.role_name = None
    task.tags = None
    task.force_handlers = None
    task.always_run = None
    task.environment = None
    task.no

# Generated at 2022-06-11 10:22:45.221671
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pass

# Generated at 2022-06-11 10:22:55.997776
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    # Arrange: Create a PlayContext object, setting remote_user and
    # network_os attributes to None
    pc = PlayContext()
    pc.remote_user = None
    pc.network_os = None

    # Arrange: Create a dict 'options', setting the name
    # of the flags to be tested, 'ansible_network_os' and
    # 'ansible_user', and their corresponding value,
    # 'test_network_os' and 'test_user'
    options = {'ansible_network_os': 'test_network_os',
               'ansible_user': 'test_user'}

    # Arrange: Create a MockNetwork object
    plugin = MockNetwork()
    plugin._options = options

    # Act: Invoke the method set_attributes_from_plugin with the
    # MockNetwork object as

# Generated at 2022-06-11 10:23:02.219096
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.plugins.loader import get_plugin_class
    pp = get_plugin_class('shell')
    p = pp()
    p._load_name = 'shell'
    p.set_options(dict(executable='/bin/bash'))
    pc = PlayContext()
    pc.set_attributes_from_plugin(p)
    assert pc.executable == '/bin/bash'


# Generated at 2022-06-11 10:23:14.243787
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    hosts_object=Hosts.load(filename="inventory")
    hosts_variable=VariableManager(loader=DataLoader(),host_list=hosts_object)
    pb=Playbook().load([],loader=DataLoader(),variable_manager=hosts_variable)
    play = Play().load(data=dict(name = "Ansible Play"), variable_manager=hosts_variable, loader=DataLoader())
    play._play_hosts = list(hosts_object.get_hosts().keys())
    task = Task().load(dict(action='ping'), play=play)
    task_host = task.get_task_host(hosts_object.get_hosts().keys()[0])
    pb.tasks.append(task)
    play_context=PlayContext(play=play)
    play_context.update_

# Generated at 2022-06-11 10:23:16.040817
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Test setting attributes from plugin set_attributes_from_plugin(plugin)
    assert False

# Generated at 2022-06-11 10:23:23.626382
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    class TestContext():
        def get(self, attr, default=None):
            return default

    mock_args = TestContext()
    mock_play = MagicMock()
    test_playcontext = PlayContext(play=mock_play, passwords=None, connection_lockfd=None)
    test_playcontext.set_attributes_from_cli()
    assert test_playcontext.timeout == 0
    assert test_playcontext.private_key_file == None
    assert test_playcontext.verbosity == 0
    assert test_playcontext.start_at_task == None


# Generated at 2022-06-11 10:23:29.402879
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    class Mock(object):
        def __init__(self):
            self._load_name = 'plugin_name'
        def get_option(self, *args):
            return None

    plugin = Mock()
    test_instance = PlayContext(play=None, passwords=None, connection_lockfd=None)
    test_instance.set_attributes_from_plugin(plugin)


# Generated at 2022-06-11 10:23:39.301592
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """
    Test module for the method PlayContext.set_attributes_from_plugin.
    """
    from ansible.plugins import connection_loader
    from ansible.plugins.loader import connection_loader as plugin_loader
    conn_plugin = plugin_loader.get('network_cli')
    pc = PlayContext()
    pc.set_attributes_from_plugin(conn_plugin)
    for option in conn_plugin.options:
        assert hasattr(pc, option)

# unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-11 10:23:42.242448
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # PlayContext has no set_attributes_from_cli method
    assert False, "PlayContext has no set_attributes_from_cli method"

# Generated at 2022-06-11 10:24:36.392490
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    print("In test_PlayContext_set_task_and_variable_override")

    # Setup
    class MockPlay:
        def __init__(self, data):
            self.__dict__ = data
    play = MockPlay({'force_handlers': False})

    class MockTask:
        def __init__(self):
            self.force_handlers = None

    task = MockTask()

    pc1 = PlayContext()

    pc1.set_attributes_from_play(play)

    # Expected Output
    expectedOutput = {'force_handlers': False}

    # Actual Output
    actualOutput = pc1.get_attrs()

    # Test
    assert actualOutput == expectedOutput

    # Setup
    class MockTemplar:
        def template(self, val):
            return val
    tem

# Generated at 2022-06-11 10:24:47.345757
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # set up a non-empty inventory
    inventory = Inventory("test/test_inventory")

    # set up a non-empty variable manager
    variable_manager = VariableManager()

    # set up a non-empty variable manager
    variable_manager.set_inventory(inventory)

    # set up PlayContext()
    pc = PlayContext()
    assert pc.remote_addr is None
    assert pc.remote_user == C.DEFAULT_REMOTE_USER
    assert pc.password == ''
    assert pc.timeout == C.DEFAULT_TIMEOUT
    assert pc.connection == 'ssh'
    assert pc.socket_path is None
    assert pc.network_os is None
    assert pc.su is False
    assert pc.su_user is None
    assert pc.sudo is False
    assert pc.sudo_user is None
    assert pc

# Generated at 2022-06-11 10:24:50.303488
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()
    # TODO
    play_context.set_attributes_from_plugin(plugin)


# Generated at 2022-06-11 10:24:55.439574
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    class MyTask:
        pass
    task = MyTask()
    task.delegate_to = 'delegated_host'
    task.remote_user = 'remote_user'
    pc = PlayContext(play=None, passwords=None, connection_lockfd=None)

    # Test special case: task.delegate_to is None
    task.delegate_to = None
    pc.set_task_and_variable_override(task=task, variables=None, templar=None)


# Generated at 2022-06-11 10:25:07.312274
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.playbook.task import Task
    #from ansible.playbook.play import Play
    from ansible.vars import load_extra_vars, VariableManager
    #from ansible.inventory.manager import InventoryManager
    #from ansible.inventory.host import Host
    #from ansible.inventory.group import Group
    #from ansible.utils.display import Display
    #from ansible.parsing.dataloader import DataLoader
    #from ansible.module_utils._text import to_text
    #import json

    #display = Display()
    #loader = DataLoader()
    variable_manager = VariableManager()

    #inventory = InventoryManager(loader=loader, sources=["host_vars/hosts"])
    #host = inventory.get_host('test_host')
    #host.set

# Generated at 2022-06-11 10:25:17.859370
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():

    #  Assert no Exceptions are thrown in initialization
    PlayContext()

    #  Assert no Exceptions are thrown in initialization
    PlayContext(play=object)

    #  Assert no Exceptions are thrown in initialization
    PlayContext(passwords=dict())

    #  Assert no Exceptions are thrown in initialization
    PlayContext(play=object, passwords=dict())

    #  Assert no Exceptions are thrown in initialization
    PlayContext(play=object, connection_lockfd=0)

    #  Assert no Exceptions are thrown in initialization
    PlayContext(play=object, passwords=dict(), connection_lockfd=0)


# Generated at 2022-06-11 10:25:27.702098
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    my_config = dict()

    my_plugin = dict()
    my_plugin['conf'] = dict()

    my_plugin['conf']['port'] = "my_port"
    my_plugin['conf']['network_os'] = "my_network_os"
    my_plugin['conf']['network_os'] = "my_network_os"
    my_plugin['conf']['force_handlers'] = "true"
    my_plugin['conf']['docker_extra_args'] = "my_docker_extra_args"
    my_plugin['conf']['connection'] = "my_connection"
    my_plugin['conf']['verbosity'] = "my_verbosity"
    my_plugin['conf']['timeout'] = "my_timeout"

# Generated at 2022-06-11 10:25:32.397584
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    con = PlayContext(play=None, passwords=None, connection_lockfd=None)
    task = Task()
    variables = dict()
    templar = Templar()
    con.set_task_and_variable_override(task,variables,templar)


# Generated at 2022-06-11 10:25:45.097917
# Unit test for method set_attributes_from_cli of class PlayContext

# Generated at 2022-06-11 10:25:50.522904
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():

    cli_args = dict(timeout=2)
    context.CLIARGS = cli_args

    play = Play()
    context.CLIARGS = dict()
    test_PlayContext = PlayContext(play=play)

    assert test_PlayContext.timeout == 2
    assert test_PlayContext.verbosity == 0
    assert test_PlayContext.start_at_task is None
    assert test_PlayContext.force_handlers is False


# Generated at 2022-06-11 10:27:43.374676
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context = PlayContext()
    assert play_context._connection == 'smart'
    assert play_context._remote_addr == '127.0.0.1'
    assert play_context._remote_user == 'root'
    assert play_context._timeout == 10
    assert play_context._port == 22
    assert play_context._password == ''
    assert play_context._private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert play_context._pipelining == C.ANSIBLE_PIPELINING
    assert play_context._network_os == None
    assert play_context._docker_extra_args == None
    assert play_context._connection_lockfd == None
    assert play_context._become == False
    assert play_context._become_method == 'sudo'
    assert play

# Generated at 2022-06-11 10:27:54.265293
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Creating objects
    _task = Task()
    _variables = {'var1': 'variable1'}
    _templar = MagicMock()
    _playcontext = PlayContext()
    
    # Calling method
    _playcontext.set_task_and_variable_override(_task, _variables, _templar)
    
    # Verifying attributes
    assert _playcontext.start_at_task is None
    assert _playcontext.transport == "smart"
    assert _playcontext.no_log is None
    assert _playcontext.check_mode is None
    assert _playcontext.network_os is None
    assert _playcontext.connection_lockfd is None
    assert _playcontext.remote_addr is None
    assert _playcontext.port is None

# Generated at 2022-06-11 10:27:58.147507
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Unit test for method set_attributes_from_plugin of class PlayContext
    '''
    my_PlayContext = PlayContext()
    my_plugin = None
    my_PlayContext.set_attributes_from_plugin(my_plugin)

# Generated at 2022-06-11 10:27:59.146607
# Unit test for constructor of class PlayContext
def test_PlayContext():
    assert isinstance(PlayContext(), PlayContext)

# Generated at 2022-06-11 10:28:05.613847
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # setup
    cliargs = dict()
    cliargs['timeout'] = 42
    cliargs['private_key_file'] = 'test_value'
    context.CLIARGS = cliargs
    play = None
    passwords = None

    test_instance = PlayContext(play, passwords)
    test_instance.set_attributes_from_cli()

    # assert
    assert test_instance.timeout == int(cliargs['timeout'])
    assert test_instance.private_key_file == cliargs['private_key_file']

