

# Generated at 2022-06-11 10:18:28.775937
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    task = mock.create_autospec(Task)
    task.no_log = True
    task.remote_user = 'fred'
    task.delegate_to = None
    task.delegate_facts = False
    task.check_mode = None
    task.diff = None


# Generated at 2022-06-11 10:18:33.584170
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # set_attributes_from_plugin(self, plugin):
    # Configures this connection information instance with data from
    # attributes on the plugin.
    fake='''
    TODO
    '''
    raise Exception(fake)

# Generated at 2022-06-11 10:18:45.625509
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    attr_name = 'test_attr_name'
    task_name = 'test_task_name'
    variables = {'test_variable_name': 'test_value'}
    
    # test 1
    task = Task()
    task.name = task_name
    task.register = 'test_register'
    task.run_once = 'test_run_once'
    task.any_errors_fatal = 'test_any_errors_fatal'
    task.delegate_to = 'test_delegate_to'
    task.remote_user = 'test_remote_user'
    task.transport = 'test_transport'
    task.sudo = 'test_sudo'
    task.sudo_user = 'test_sudo_user'
    task.become = 'test_become'
   

# Generated at 2022-06-11 10:18:48.384222
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    #test PlayContext.set_task_and_variable_override 
    pass
    #
    #test PlayContext.set_task_and_variable_override 
    pass

# Generated at 2022-06-11 10:18:51.100856
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    play_context.set_attributes_from_cli()
    play_context.set_attributes_from_play()
    task = {}


###
# Play
###


# Generated at 2022-06-11 10:18:58.019231
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Missing parameters
    play = None
    passwords = None
    connection_lockfd = None
    playcontext = PlayContext(play, passwords, connection_lockfd)

    # Proper parameters
    play = None
    passwords = {"conn_pass":"conn_pass","become_pass":"become_pass"}
    connection_lockfd = None
    playcontext = PlayContext(play, passwords, connection_lockfd)



# Generated at 2022-06-11 10:19:00.384372
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    PlayContext.set_task_and_variable_override(PlayContext, )


# Generated at 2022-06-11 10:19:08.609224
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    context.CLIARGS = {'timeout':'', 'verbosity':'', 'inventory':'', 'private_key_file':''}

    # playcontext = PlayContext(play=None, passwords=None, connection_lockfd=None)
    playcontext = PlayContext()

    # playcontext.set_attributes_from_cli()
    playcontext.set_attributes_from_cli()


# Utility methods that are used by the PlayContext class, but don't have to be
# instance-specific.


# Generated at 2022-06-11 10:19:19.087785
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    print('In test_PlayContext_set_task_and_variable_override')

    # test_case_1
    play_context = PlayContext()
    task, variables, templar = None, None, None
    # Case: when task is None
    print('- Case: when task is None')
    play_context.set_task_and_variable_override(task, variables, templar)
    assert play_context

    # test_case_2
    play_context = PlayContext()
    variables = {}
    templar = MagicMock()
    # Case: when variables is None
    print('- Case: when variables is None')
    task = MagicMock()
    new_play_context = play_context.set_task_and_variable_override(task, variables, templar)

# Generated at 2022-06-11 10:19:22.894789
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    raise SkipTest('test_PlayContext_set_task_and_variable_override() is not implemented yet')


# Generated at 2022-06-11 10:19:49.246803
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    from ansible.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    cliargs = base.parse((
        '-i {0}/inventory_test -m ping -T 10 -M {0}/library'.format(fixture_path),
        '--extra-vars', '"@{0}/vars.yml"'.format(fixture_path),
    ))
    context.CLIARGS = cliargs
    context.CLIARGS._ansible_version = '2.9.0'
    context.CLIARGS._ansible_git_commit = 'devel'


# Generated at 2022-06-11 10:19:53.892434
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    from ansible.plugins.loader import connection_loader

    # given
    pc = PlayContext()
    plugin_name = 'local'
    plugin = connection_loader.get(plugin_name)

    # when
    pc.set_attributes_from_plugin(plugin)

    # then
    assert pc.connection == 'local'



# Generated at 2022-06-11 10:20:05.502147
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    connection1 = 'ssh'
    connection2 = 'local'
    port1 = '22'
    port2 = '23'
    remote_user1 = 'user1'
    remote_user2 = 'user2'
    delegate_to = 'user3'
    remote_addr = '127.0.0.1'
    executable = '/usr/bin/python3'
    no_log = True
    remote_port = 5986
    become_pass = 'become_pass'
    become_method = 'sudo'
    become_exe = 'sudo_exe'
    become_flags = 'sudo_flags'
    become_user = 'sudo_user'
    prompt = 'sudo_prompt'
    success_key = 'sudo_success_key'
    network_os = 'ios'

# Generated at 2022-06-11 10:20:09.442276
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Call the method
    host_connection = PlayContext()
    host_connection.set_attributes_from_plugin('ssh')
    # Checks
    assert host_connection._attributes['connection'] == 'ssh'

# Generated at 2022-06-11 10:20:17.857796
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play = Play()
    _host = Host('testhost')
    _play_context = PlayContext()

    # Test with bad delegation
    task = Task()
    task.delegate_to = 'bad_delegate_to'
    variables = dict()
    templar = Templar(loader=Mock())
    play_context = _play_context.set_task_and_variable_override(task, variables, templar)
    assert play_context == _play_context

    # Test with good delegation
    task = Task()
    task.delegate_to = True
    variables = dict(ansible_delegated_vars=dict(testhost=dict(ansible_host='1.1.1.1')))
    templar = Templar(loader=Mock())

# Generated at 2022-06-11 10:20:25.017411
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    task_name = "test_task"
    task = Task.load(None, task_name=task_name)
    playbook = Playbook.load(None, None)
    play = Play().load(playbook, VALID_PLAY_SOURCE1, variable_manager=VariableManager(), loader=playbook._loader)
    passwords = dict()
    connection_lockfd = 42
    pc = PlayContext(play, passwords, connection_lockfd)

    pc.set_attributes_from_cli()

# Generated at 2022-06-11 10:20:25.670831
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pass

# Generated at 2022-06-11 10:20:34.049667
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    unit test for function PlayContext.set_attributes_from_plugin of class PlayContext
    '''
    pc = PlayContext()
    assert not pc._attributes
    # set_attributes_from_plugin returns None, so we use assertTrue to check if it worked
    assertTrue(pc.set_attributes_from_plugin("paramiko"))
    assert "connection_user" in pc._attributes
    assert "remote_user" in pc._attributes
    assert "private_key_file" in pc._attributes
    assert "verbosity" in pc._attributes



# Generated at 2022-06-11 10:20:37.967084
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    c = PlayContext()
    c.set_attributes_from_plugin(ArgvCLI({
        'ask_sudo_pass': False,
        'become':False
    }))
    assert c.ask_sudo_pass is False
    assert c.become is False

# Generated at 2022-06-11 10:20:40.111839
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():

    context.CLIARGS = dict(timeout = 15)
    a = PlayContext()
    assert a.timeout == 15


# Generated at 2022-06-11 10:21:15.140997
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    variables = {}
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="")
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader, variables, variable_manager)
    play = Play()
    task = Task()
    task.delegate_to = 'test_host'
    task.remote_user = 'test_remote_user'
    conn_pass = 'test_pass'
    become_pass = 'test_become_pass'
    passwords = {'conn_pass': conn_pass, 'become_pass': become_pass}

# Generated at 2022-06-11 10:21:28.522559
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.plugins.connection.ssh import Connection as ConnectionSSH
    from ansible.plugins.connection.docker import Connection as ConnectionDocker
    from ansible.plugins.connection.chroot import Connection as ConnectionChroot
    from ansible.plugins.connection.jail import Connection as ConnectionJail
    from ansible.plugins.connection.nxos_ssh import Connection as ConnectionNxosSSH
    from ansible.plugins.connection.netconf import Connection as ConnectionNetconf
    from ansible.plugins.connection.network_cli import Connection as ConnectionNetworkCli
    from ansible.plugins.connection.winrm import Connection as ConnectionWinRM
    from ansible.plugins.connection.local import Connection as ConnectionLocal

    from ansible.plugins.shell.bash import ShellModule as ShellModuleBash
    from ansible.plugins.shell.csh import ShellModule

# Generated at 2022-06-11 10:21:29.946512
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    instance = PlayContext()
    assert isinstance(instance, PlayContext)


# Generated at 2022-06-11 10:21:39.671526
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # create a fake task
    fake_task = Task()
    fake_task.no_log = True
    fake_task.delegate_to = None
    fake_task.become = True

    # create an instance of PlayContext
    pc = PlayContext()

    # call set_task_and_variable_override
    pc.update_vars(variables={'ansible_python_interpreter': '/usr/bin/python'})
    pc = pc.set_task_and_variable_override(fake_task, variables={'ansible_python_interpreter': '/usr/bin/python'}, templar=None)
    # check for None
    assert pc is not None
    # FIXME: test other attributes
    assert pc.no_log, "object.no_log was not True as expected"
   

# Generated at 2022-06-11 10:21:52.121175
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    new_info = dict()
    # test module
    new_info['module_name'] = 'shell'
    # test args
    new_info['module_args'] = 'ls'
    # test remote_user
    new_info['remote_user'] = 'foo'
    # test port
    new_info['port'] = 2222
    # test connection
    new_info['connection'] = 'winrm'
    # test no_log
    new_info['no_log'] = True
    # test run_once
    new_info['run_once'] = True
    obj = PlayContext()
    t = Task()
    t.action = 'shell'
    # test host
    t.hosts = [InventoryHost(name='foo.example.com')]
    t.delegate_to = 'localhost'


# Generated at 2022-06-11 10:21:57.122181
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    pass

# Generated at 2022-06-11 10:22:03.248453
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    inventory_path = 'inventory/hosts'
    inventory = InventoryManager(loader=DataLoader(), sources=inventory_path)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    result = True
    for h in inventory.hosts.keys():
        #print(h)
        variable_manager.set_host_variable(h, 'ansible_connection', 'local')
    variable_manager.set_host_variable('localhost', 'ansible_user', 'root')
    variable_manager.set_host_variable('localhost', 'ansible_password', 'root')

    play = Play()
    play.hosts = 'localhost'
    play.vars = { "ansible_user" : "root" }

# Generated at 2022-06-11 10:22:06.422081
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    PlayContext_test = PlayContext()
    PlayContext_test.set_attributes_from_plugin()
    assert PlayContext_test._attributes is not None


# Generated at 2022-06-11 10:22:17.267520
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    temp_stdout = StringIO()
    temp_stdin = StringIO()
    path = os.path.dirname(os.path.abspath(__file__))
    path = path.replace('/lib/ansible/modules/cloud/cloudscale', '')
    path = path.replace('/lib/ansible/modules/cloud/openstack', '')
    path = path.replace('/lib/ansible/modules/cloud/scaleway', '')
    path = path.replace('/lib/ansible/modules/cloud/aws', '')
    path = path.replace('/lib/ansible/modules/cloud/gcp', '')
    path = path.replace('/lib/ansible/modules/cloud/azure', '')

# Generated at 2022-06-11 10:22:21.405013
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Unit test for method set_attributes_from_plugin of class PlayContext
    '''
    # FIXME: set_attributes_from_plugin has a generic call to config.get_configuration_definitions
    pass

# Generated at 2022-06-11 10:23:15.900455
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    pc = PlayContext()
    pc.set_attributes_from_cli()
    assert pc.timeout == C.DEFAULT_TIMEOUT
    assert pc.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert pc.verbosity == 0
    assert pc.start_at_task == None
    assert pc.step == False
    assert pc.force_handlers == False


# Generated at 2022-06-11 10:23:24.430906
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # A test case for PlayContext.set_attributes_from_cli
    # Returns the value of an attribute of PlayContext set by method set_attributes_from_cli

    # Arrange
    play = Play()
    play.force_handlers = False
    connection = PlayContext(play)
    connection.set_attributes_from_cli()

    # Act
    ret = connection._attributes

    # Assert
    assert ret.get('timeout') == 15
    assert ret.get('verbosity') == 0
    if hasattr(connection, '_start_at_task'):
        assert ret.get('start_at_task') == None


# Generated at 2022-06-11 10:23:36.540206
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    fake_loader = DictDataLoader({"hosts": {"host1": {"ansible_connection": "local"}, "host2": {"ansible_connection": "local"}}})
    fake_inventory = Inventory(loader=fake_loader, variable_manager=VariableManager(loader=fake_loader), host_list='hosts')
    fake_task = Task()
    fake_task._role = None
    fake_play_context = PlayContext(play=fake_play)
    fake_play_context.update_vars(fake_variables)
    fake_result = fake_play_context.set_task_and_variable_override(task=fake_task, variables=fake_variables, templar=fake_templar)
    assert fake_result._attributes["connection"] == "local"
# unit test

# Generated at 2022-06-11 10:23:44.969763
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Setup test objects
    from ansible.plugins.loader import get_plugin_class

    class Mock:
        def __init__(self, **kwargs):
            for key in kwargs:
                setattr(self, key, kwargs[key])
    pc = PlayContext()
    pc.set_play_context = Mock()
    # Set test values
    plugin = get_plugin_class("connection")("dummy", "c2")
    # Call method (include assertion calls)
    pc.set_attributes_from_plugin(plugin)


# Generated at 2022-06-11 10:23:47.457981
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    PlayContext_instance = PlayContext()
    PlayContext_instance.set_attributes_from_plugin(['fakes'])


# Generated at 2022-06-11 10:23:49.718227
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    print("in test_PlayContext_set_attributes_from_plugin")

    pc = PlayContext()

# Generated at 2022-06-11 10:24:00.987239
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Initialize a PlayContext object.
    # Initialize a PlayContext object.
    from ansible.playbook import Play
    import ansible.playbook.play
    from ansible.playbook.play import PlaybookIterator

    from ansible.executor.playbook_iterator import PlaybookIterator

    # load plugins for connection detection
    from ansible.plugins import connection_loader, callback_loader
    connection_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/connections'))

    my_play = Play()

# Generated at 2022-06-11 10:24:11.808763
# Unit test for constructor of class PlayContext
def test_PlayContext():
    def run_test(expected_attrs, playbook, task_vars=dict(), passwords=dict(), cliargs=dict()):
        pc = PlayContext(play=playbook, task_vars=task_vars, passwords=passwords)
        assert isinstance(pc, PlayContext)
        for attr, value in iteritems(expected_attrs):
            assert getattr(pc, attr) == value
    # Test with empty playbook
    play = dict(hosts='all', gather_facts='no', become=False)

# Generated at 2022-06-11 10:24:22.818923
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    '''
    Test set_task_and_variable_override method of class PlayContext
    '''
    import ansible.playbook
    import ansible.vars.manager
    import os
    PY3 = sys.version_info[0] == 3

    # Set demonstration variables

# Generated at 2022-06-11 10:24:33.740007
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.plugins.loader import get_plugin_class
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    context.CLIARGS = {}
    import sys
    if sys.version_info >= (3, 0):
        unicode = str
    p = Play()
    p.vars = {}
    h = Host(name="test")
    h.vars = {'ansible_ssh_user': 'root'}
    t = Task()
    t.action = "shell"
    t.short_description = ""
    t.set_loader(p._loader)
    t.vars = {}

# Generated at 2022-06-11 10:26:17.508554
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play = Play()
    passwords = dict()
    connection_lockfd = None

    pc=PlayContext(play,passwords,connection_lockfd)

    # Call the method under test
    pc.set_attributes_from_plugin(Plugin())

    # Check the results
    assert isinstance(pc._attributes['connection'], str)

# Generated at 2022-06-11 10:26:18.509267
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # FIXME
    return None


# Generated at 2022-06-11 10:26:22.071708
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context_obj = PlayContext()
    assert ('connection' in play_context_obj._attributes.keys()) == False
    play_context_obj.set_attributes_from_plugin(None)
    assert play_context_obj._attributes['connection'] == 'ssh'

# Generated at 2022-06-11 10:26:31.041866
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    from ansible.playbook.play import Play
    from ansible.playbook.play import PlayContext as PlayContext_pb

    context.CLIARGS = dict()
    context.CLIARGS['timeout'] = False
    context.CLIARGS['private_key_file'] = ''
    context.CLIARGS['verbosity'] = ''
    context.CLIARGS['start_at_task'] = None

    pb = Playbook()
    play = Play()
    acontext = PlayContext()
    acontext.set_attributes_from_cli()

    pb = Playbook()
    play = Play()
    acontext = PlayContext()
    acontext.set_attributes_from_cli()

    pb = Playbook()
    play = Play()
    acontext = PlayContext

# Generated at 2022-06-11 10:26:40.344274
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # test if argument is correct
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    class FakeTemplar(object):
        def template(self,v):
            return v
    class FakePlay(object):
        def __init__(self):
            self.force_handlers = False
    class FakeLoader(object):
        def __init__(self):
            self.password = ''
            self.become_pass = ''
    class FakeVault(object):
        def __init__(self):
            pass
        def decrypt(self, txt, trash):
            return txt
    fake_loader = FakeLoader()
    fake_vault = FakeVault()
    fake_templ

# Generated at 2022-06-11 10:26:40.969716
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    assert True == True

# Generated at 2022-06-11 10:26:51.293909
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    global context
    '''
    class Test_Paramiko_Connection:

        def __init__(self, define_plugin_options, tmpdir):
            class OptionModule:
                def __init__(self, define_plugin_options):
                    self.parser = define_plugin_options

            paramiko.SSHClient()
            if define_plugin_options:
                self.options = OptionModule(define_plugin_options)
            if tmpdir:
                self.socket_path = tmpdir
    '''
    from collections import namedtuple
    
    test_params = []
    test_params.append(({'DEFAULT_PARAMIKO_RECORD_HOST_KEYS':True,'ANSIBLE_PARAMIKO_RECORD_HOST_KEYS':True},False))

# Generated at 2022-06-11 10:26:54.046052
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # FIXME: mock 'PlayContext.set_attributes_from_plugin' method, mock 'PlayContext.set_attributes_from_play' method
    assert True


# Generated at 2022-06-11 10:27:04.717804
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    context.CLIARGS = {'timeout':'10'}
    passwords = {'conn_pass': '', 'become_pass': ''}
    connection_lockfd = None
    play = play_context.Play()
    play.force_handlers = False
    task = play_context.Task()
    variables = {'ansible_host': '192.168.0.1', 'ansible_port': '5443', 'ansible_user': 'test_user'}
    templar = Templar()
    pc = PlayContext(play, passwords, connection_lockfd)
    pc.set_attributes_from_cli()
    pc.set_attributes_from_play(play)
    new_pc = pc.set_task_and_variable_override(task, variables, templar)
    assert new

# Generated at 2022-06-11 10:27:12.061208
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Create an instance of a dummy subclass of AnsibleOptions
    # with a bunch of options pre-set to their default values.
    # The dict keys have an initial underscore so that we don't
    # accidentally set a real PlayContext attribute.
    class Options(object):
        def __init__(i):
            i._connection = 'smart'
            i._timeout = C.DEFAULT_TIMEOUT
            i._private_key_file = C.DEFAULT_PRIVATE_KEY_FILE
            i._verbosity = 0
            i._start_at_task = None
            i._force_handlers = False

            i._docker_extra_args = None

        def __getattr__(i, attr):
            return getattr(i, '_' + attr)
