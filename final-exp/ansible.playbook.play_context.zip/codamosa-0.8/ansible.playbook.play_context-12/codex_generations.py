

# Generated at 2022-06-11 10:18:45.623863
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Player
    my_player = Player()

    # PlayContext
    my_PlayContext = PlayContext()

    # Connection plugin
    hello_connection = Connection(play_context=my_PlayContext)
    hello_connection.set_options(['option1=value1', 'option2=value2'])
    my_PlayContext.set_attributes_from_plugin(hello_connection)

    # Assert equal
    assert my_PlayContext.option1 == 'value1'
    assert my_PlayContext.option2 == 'value2'


# Generated at 2022-06-11 10:18:51.124752
# Unit test for constructor of class PlayContext
def test_PlayContext():
    # PlayContext implements an abstract method
    # pylint: disable=abstract-method
    host = object()
    play = object()
    play_context = PlayContext(play, dict())
    assert play_context._play == play
    assert play_context._host == host
    assert play_context._task == None
    assert play_context._ds == None
    assert play_context._play_ds == None
    assert play_context._task == None
    assert play_context._is_local_play == False



# Generated at 2022-06-11 10:18:57.093160
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    variables = {}
    task = type('', (), {})()

    try:
        new_info = play_context.set_task_and_variable_override(task, variables, templar)
    except AttributeError:
        assert True
    else:
        assert False


# Generated at 2022-06-11 10:19:09.818744
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Unit test for PlayContext.set_attributes_from_plugin
    '''

    # create mock object
    mock_plugin = unittest.mock.Mock()
    mock_plugin.get_option.return_value = 'mock_option'
    mock_plugin._load_name = 'mock_plugin_load_name'

    # get options for mock_plugin
    options = C.config.get_configuration_definitions(get_plugin_class(mock_plugin),
                                                     mock_plugin._load_name)
    for option in options:
        if option:
            if options[option].get('name') == 'mock_plugin_option_name':
                break
    else:
        raise AssertionError

    # test PlayContext.set_attributes_from_plugin
    play

# Generated at 2022-06-11 10:19:10.551446
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pass

# Generated at 2022-06-11 10:19:14.957226
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    context = PlayContext(
                            play=None,
                            passwords=None,
                            connection_lockfd=None
                        )
    plugin = 'null'
    context.set_attributes_from_plugin(plugin)
    assert plugin == 'null'

# Generated at 2022-06-11 10:19:16.742256
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()
    play_context.set_attributes_from_plugin(plugin)


# Generated at 2022-06-11 10:19:31.716035
# Unit test for constructor of class PlayContext
def test_PlayContext():

    class TestPlay(object):
        def __init__(self):
            self.vars_files = ["/path/to/file1", "/path/to/file2"]
            self.remote_user = "bogus_user"
            self.become = True
            self.become_user = "bogus_become_user"
            self.become_method = "bogus_become_method"
            self.sudo_user = "bogus_sudo_user"
            self.sudo = True
            self.sudo_pass = True
            self.transport = "bogus_transport"
            self.connection = "bogus_connection"
            self.remote_addr = "bogus_remote_addr"
            self.remote_port = "bogus_remote_port"


# Generated at 2022-06-11 10:19:33.132228
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Test our class.
    PlayContext.test_class()


# Generated at 2022-06-11 10:19:44.405962
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    context.CLIARGS = ImmutableDict()
    context.CLIARGS['inventory'] = 'inventory'
    context.CLIARGS['verbosity'] = 'verbosity'
    context.CLIARGS['timeout'] = 'timeout'
    context.CLIARGS['private_key_file'] = 'private_key_file'
    context.CLIARGS['start_at_task'] = 'start_at_task'
    play = Play()
    play._attributes['force_handlers'] = 'force_handlers'
    passwords = dict()
    passwords['conn_pass'] = 'conn_pass'
    passwords['become_pass'] = 'become_pass'
    connection_lockfd = 'connection_lockfd'
    playcontext = PlayContext(play, passwords, connection_lockfd)
   

# Generated at 2022-06-11 10:20:18.515218
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    mock_task = MagicMock(name='Mock task for PlayContext._set_task_and_variable_override')
    mock_vars = MagicMock(name='Mock variables for PlayContext._set_task_and_variable_override')
    mock_templar = MagicMock(name='Mock templar for PlayContext._set_task_and_variable_override')
    test_context = PlayContext()

    # Test that the method returns a PlayContext
    mock_task.delegate_to = None
    assert test_context.set_task_and_variable_override(mock_task, mock_vars, mock_templar) is not None

# Generated at 2022-06-11 10:20:25.232113
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()

    hostvars = {'ansible_connection': 'winrm'}
    task = Mock()
    task.delegate_to = None
    task.remote_user = None
    task.become_user = None
    task.check_mode = None
    task.diff = None

    play_context.set_task_and_variable_override(task, hostvars, None)



# Generated at 2022-06-11 10:20:25.922270
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pass

# Generated at 2022-06-11 10:20:30.092620
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    task = Task()
    variables = {}
    templar = Templar()
    play_context = PlayContext()
    check_var = play_context.set_task_and_variable_override(task, variables, templar)
    assert check_var


# Generated at 2022-06-11 10:20:40.420518
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-11 10:20:41.838341
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
  pass # TODO: implement your test here


# Generated at 2022-06-11 10:20:43.797323
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    PlayContext_instance = PlayContext(play=None, passwords=None, connection_lockfd=None)



# Generated at 2022-06-11 10:20:47.863634
# Unit test for constructor of class PlayContext
def test_PlayContext():
    context.CLIARGS = {
        'timeout': 30
    }

    pc = PlayContext()
    assert pc.timeout == 30

    pc = PlayContext(dict(
        become_method='sudo',
        become_user='joe',
        connection='local',
        remote_user='bob',
        private_key_file='/path/to/private_key',
        timeout=10
    ))

    assert pc.become_user == 'joe'
    assert pc.become_method == 'sudo'

    assert pc.connection == 'local'
    assert pc.remote_user == 'bob'
    assert pc.private_key_file == '/path/to/private_key'
    assert pc.timeout == 10

# Generated at 2022-06-11 10:20:59.691542
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play = Play()
    play.force_handlers = 'yes'

    pc = PlayContext(play)
    pc.set_attributes_from_cli()
    pc.set_attributes_from_play(play)
    pc.set_attributes_from_plugin('ssh')

    # Ensure that all values set by user/play/plugin are correct
    assert pc.timeout == C.DEFAULT_TIMEOUT
    assert pc.verbosity == 0

    assert pc.start_at_task is None
    assert pc.step is False
    assert pc.force_handlers == 'yes'

    assert pc.executable == '/bin/sh'
    assert pc.port == 22
    assert pc.user == ''
    assert pc.password == ""
    assert pc.connection == "ssh"

# Generated at 2022-06-11 10:21:02.617536
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    task = MagicMock()
    variables = dict()
    templar = MagicMock()
    play_context = PlayContext()
    play_context.set_task_and_variable_override(task, variables, templar)



# Generated at 2022-06-11 10:21:50.902361
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # set up some dummy plugin
    class DummyPlugin:
        def __init__(self):
            self.option1 = "opt1"
            self.option2 = "opt2"

        def get_option(self, option):
            return getattr(self, option)

    plugin = DummyPlugin()
    # PlayContext constructor
    pc = PlayContext()
    # call the method under test
    pc.set_attributes_from_plugin(plugin)
    # assertions
    assert pc.option1 == plugin.option1, "PlayContext.set_attributes_from_plugin() did not set the right value for 'option1' in pc"
    assert pc.option2 == plugin.option2, "PlayContext.set_attributes_from_plugin() did not set the right value for 'option2' in pc"

# Unit test

# Generated at 2022-06-11 10:21:55.343428
# Unit test for constructor of class PlayContext
def test_PlayContext():
    from ansible.playbook.play import Play

    p = Play()
    play_context = PlayContext(play=p)
    play_context.serialize()
    play_context.deserialize(data=play_context.serialize())

# Generated at 2022-06-11 10:22:04.848387
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # The tests are disabled due to requring AnsibleCoreCI code
    raise SkipTest

    # Initialization of a global object
    global_object = {
        'get_plugin_class': get_plugin_class
    }

    # Examples of 'options' to set within Mock

# Generated at 2022-06-11 10:22:15.960661
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    my_spec = {}
    my_spec['custom_type'] = dict(
        argspec=dict(
            verbosity=dict(choices=[1, 2, 3], required=True),
            custom_f=dict(required=False),
            custom_s=dict(required=False)
        )
    )
    # FIXME: need better way to mock classes/objects
    # FIXME: add missing tests for remaining types:
    # bool, string, int, list, bool, dict

    class TestPlugin(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_option(self, option):
            if option == 'verbosity':
                return 3
            elif option == 'custom_f':
                return False

# Generated at 2022-06-11 10:22:26.494738
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Test the functionality of the method set_attributes_from_plugin of class PlayContext
    '''
    # Set up test objects
    play = Play()
    passwords = None
    connection_lockfd = None
    play_context = PlayContext(play, passwords, connection_lockfd)
    plugin = get_plugin_class('connection', 'ssh')()

    # Test the method
    play_context.set_attributes_from_plugin(plugin)

    # Verify the result
    assert play_context.connection == 'ssh'
    assert play_context.scp_if_ssh == True
    assert play_context.ssh_executable == None
    assert play_context.ssh_common_args == None
    assert play_context.ssh_extra_args == None

# Generated at 2022-06-11 10:22:36.994094
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    """
    Test set_task_and_variable_override
    """    
    def mocked_get_inventory_hostname(host):
        """
        Mocked get_inventory_hostname
        """
        return host
    original_get_inventory_hostname = Base.get_inventory_hostname
    Base.get_inventory_hostname = mocked_get_inventory_hostname


# Generated at 2022-06-11 10:22:37.714973
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pass



# Generated at 2022-06-11 10:22:48.543825
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts({"ansible_ssh_user": "ubuntu", "ansible_ssh_pass": "secret", "ansible_connection": "ssh", "ansible_port": 22, "ansible_host": "10.0.0.1"})
    play_context = PlayContext()
    play_context.set_attributes_from_plugin(variable_manager)
    task = Task()
    task.connection = 'local'
    play_context = play_context.set_task_and_variable_override(task, variable_manager._fact_cache, None)
    assert play_context.connection

# Generated at 2022-06-11 10:22:59.409128
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from datetime import datetime
    from ansible.local import LocalTask
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader, connection_loader
    from ansible.plugins.loader import connection_loader, module_loader
    from ansible.plugins.connection import local
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from asyncio.test_utils import TestLoop
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import ResultCallbackForAsync
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 10:23:11.203467
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-11 10:23:57.558733
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    my_task = Task()
    my_task.delegate_to = None
    my_task.remote_user = None
    my_task.check_mode = None
    my_task.diff = None
    my_variables = {}
    my_templar = Templar(variables=my_variables)
    my_play_context = PlayContext(play=None, passwords=None, connection_lockfd=None)
    my_play_context.connection_user = None
    my_play_context.remote_addr = None
    my_play_context.remote_user = None
    my_play_context.port = None
    my_play_context.timeout = None
    my_play_context.connection = 'smart'
    my_play_context.network_os = 'default'

# Generated at 2022-06-11 10:24:01.989335
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    (_, args) = parse_args()
    context.CLIARGS = args

    play_context = PlayContext()
    play_context.set_attributes_from_plugin(ssh.Connection(play_context), None)

    assert play_context.connection == 'ssh'

# Generated at 2022-06-11 10:24:12.839246
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # get the class to test
    cls = PlayContext.get_class_to_test()

    # build mocks
    class MockedContext(object):
        class MockedCLIARGS(object):
            def __init__(self):
                self.verbosity = 1
                self.timeout = 3
    # create instance of mock for use by test
    m_context = MockedContext()

    # create an instance of the class to test
    x = cls()
    x.set_attributes_from_cli()

    assert hasattr(x, 'timeout')
    assert hasattr(x, 'verbosity')
    assert x.timeout is None
    assert x.verbosity is 0

    m_context.CLIARGS = MockedContext.MockedCLIARGS()
    x.set_attributes_from_

# Generated at 2022-06-11 10:24:23.440467
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    my_obj = PlayContext()
    my_obj.set_attributes_from_cli()
    attrs = my_obj._attributes
    assert attrs.get('timeout') == C.DEFAULT_TIMEOUT
    assert attrs.get('private_key_file') == C.DEFAULT_PRIVATE_KEY_FILE
    assert attrs.get('verbosity') == C.DEFAULT_VERBOSITY
    assert attrs.get('pipelining') == C.ANSIBLE_PIPELINING
    assert attrs.get('start_at_task') is None
    assert attrs.get('step') == C.DEFAULT_STEP
    assert attrs.get('force_handlers') == C.DEFAULT_FORCE_HANDLERS

# Generated at 2022-06-11 10:24:28.354248
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    for task in [dict(), None]:
        for variables in [dict(), None]:
            for templar in [Mock(), None]:
                new_info = PlayContext.set_task_and_variable_override(task, variables, templar)
                assert new_info is not None

# Generated at 2022-06-11 10:24:36.769396
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.plugins.connections import ConnectionBase
    class test_play(object):
        def __init__(self):
            self.force_handlers = False
    class Connection(ConnectionBase):
        pass
    p = test_play()
    c = Connection(p)
    pc = PlayContext(p)
    pc.set_attributes_from_plugin(c)
    assert pc.connection == 'paramiko'
    assert pc.network_os == 'default'
    assert pc.timeout == 10
    assert pc.remote_user == 'default'
    assert pc.private_key_file == 'default'
    assert not pc.pipelining
    assert not pc.verbosity
    assert not pc.only_tags
    assert not pc.skip_tags
    assert not pc.start_at_task
    assert not pc

# Generated at 2022-06-11 10:24:47.720069
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    test_variable_manager = VariableManager()
    test_loader = DataLoader()
    test_play = Play().load({'name': 'Test Play',
                             'hosts': 'localhost',
                             'gather_facts': 'no'},
                            variable_manager=test_variable_manager, loader=test_loader)

    test_task = Task()
    test_host = HostVars(hostname='localhost')


# Generated at 2022-06-11 10:24:58.767253
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    module = AnsibleModule(argument_spec={})

    # First test: No parameters defined
    play = Play()
    play._included_roles = [Role(), Role()]
    play.connection = None
    play.remote_user = None
    play.become = None
    play.become_user = None
    play.become_method = None
    play.environment = dict()
    play.transport = "local"
    play.ansible_connection = "local"
    play.user = "ansible"

    role = Role()
    role._role_name = 'test_role'
    role._task_blocks = [dict(action=dict(environment=dict()))]
    role._role_path = '/fake/path/%s' % role._role_name


# Generated at 2022-06-11 10:25:12.086371
# Unit test for constructor of class PlayContext
def test_PlayContext():
    p = PlayContext()

    assert p.remote_user == C.DEFAULT_REMOTE_USER
    assert p.remote_addr == C.DEFAULT_REMOTE_ADDR
    assert p.connection == C.DEFAULT_TRANSPORT
    assert p.port == None
    assert p.remote_pass == ''
    assert p.timeout == C.DEFAULT_TIMEOUT
    assert p.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert p.connection_user == None
    assert p.network_os == None
    assert p.docker_extra_args == None
    assert p.command_timeout == None

    assert p.become is False
    assert p.become_method == C.DEFAULT_BECOME_METHOD
    assert p.become_user == C.DEFAULT

# Generated at 2022-06-11 10:25:24.194026
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-11 10:26:55.247443
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    t = Task()
    t.set_loader(Mock())
    t.action = 'setup'
    t.args = dict()
    t.register = 'registered'
    t.name = 'setup'
    t.delegate_to = 'vagrant'
    t.no_log = False
    t.tags = ['vagrant']
    t.run_once = False
    t.remote_user = 'vagrant'

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    v = VariableManager()

# Generated at 2022-06-11 10:26:57.928339
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """
    Test set_attributes_from_plugin method
    """
    # FIXME: remove this once we fix this method
    pass

# Generated at 2022-06-11 10:27:07.596125
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play = Mock(spec=Play)
    task = Mock(spec=Task)
    task.delegate_to=None
    task.remote_user='root'
    variables = dict()
    templar = Mock(Templar)
    c = PlayContext(play, dict(), None)
    c.set_attributes_from_cli()
    c.set_attributes_from_play(play)
    c.set_attributes_from_plugin('')
    c.set_task_and_variable_override(task, variables, templar)
    c.set_become_plugin('')
    c.update_vars(variables)
    assert isinstance(c.copy(), PlayContext)

# Generated at 2022-06-11 10:27:16.758502
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    from unit.conftest import FakeCliArgs
    from unit.conftest import FakeOptions
    from unittest import TestCase
    class TestPlayContext(TestCase):
        def test_instance_attribute(self):
            context.CLIARGS = FakeCliArgs()
            context.CLIARGS.timeout = 60
            context.CLIARGS.verbosity = 4
            context.CLIARGS.private_key_file = "/home/user/.ssh/id_rsa"
            play_context = PlayContext()
            play_context.set_attributes_from_cli()
            assert play_context.timeout == 60
            assert play_context.private_key_file == "/home/user/.ssh/id_rsa"
            assert play_context.verbosity == 4
            context.CLIARGS = Fake

# Generated at 2022-06-11 10:27:26.340187
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    from collections import namedtuple
    FakeTask = namedtuple('Task', ['delegate_to', 'remote_user'])
    FakeVariables = namedtuple('Variables', ['get'])

    # Preparing test data
    play_context = PlayContext()
    play_context_remote_user = 'nested'
    play_context.remote_user = play_context_remote_user
    remote_user_from_variables = 'from_variables'
    mock_task = FakeTask(delegate_to=None, remote_user=None)
    mock_variables = FakeVariables(get=lambda key: remote_user_from_variables if key == 'ansible_user' else None)

    # Executing tested code

# Generated at 2022-06-11 10:27:32.039889
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # TODO: update test

    p = PlayContext()
    p.set_attributes_from_plugin('ssh')
    assert p.host == 'ssh'
    assert p.port == 22
    assert p.remote_user == None

    p = PlayContext()
    p.set_attributes_from_plugin('local')
    assert p.connection == 'local'
    assert p.remote_user == 'root'


# Generated at 2022-06-11 10:27:33.050963
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    assert 0


# Generated at 2022-06-11 10:27:42.399033
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # set_task_and_variable_override: Task, VariableManager -> PlayContext
    # This method has two parameters
    # The first parameter is the task object with the parameters that were set on it
    # The second parameter is variables from inventory
    # The return value is the new PlayContext

    # Create a task object
    task_one = Task()
    task_one._role = None
    task_one._parent = None
    task_one._block = None
    task_one._local_action = False
    task_one._always_run = False
    task_one._loop = None
    task_one._first_available_file = None
    task_one._tags = None
    task_one._run_once = False
    task_one._post_validate = None
    task_one._name = "test task"
   

# Generated at 2022-06-11 10:27:47.935562
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    ctx = PlayContext()
    ctx.set_attributes_from_plugin(Mock(spec_set=ConnectionBase, **{'toggle_tls': False, 'get_option.return_value': 'option_value'}))
    assert ctx._toggle_tls == False
    assert ctx._connection_port == 'option_value'


# Generated at 2022-06-11 10:27:58.296574
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    set_module_args({
        'remote_user': 'user',
        'connection': 'ssh',
        'inventory': './test/ansible_hosts',
        'module_path': './library',
        'host_pattern': 'host1',
        'become': 'yes'
    })
    task = dict(
        action=dict(
            module='net_ping',
            args=dict()
        ),
        delegate_to='host2',
        become=True,
        become_user='user1',
        become_method='sudo'
    )