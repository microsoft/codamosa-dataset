

# Generated at 2022-06-11 10:18:35.012053
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    pass


# Generated at 2022-06-11 10:18:41.197790
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    context.CLIARGS = ImmutableDict()
    play_context = PlayContext()
    task = Mock()
    task.delegate_to = None
    task.remote_user = None
    templar = Mock()
    templar.template = lambda x: x

    play_context.set_task_and_variable_override(task, {}, templar)

# Generated at 2022-06-11 10:18:51.062821
# Unit test for method set_task_and_variable_override of class PlayContext

# Generated at 2022-06-11 10:18:59.124363
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
        pc = PlayContext()
        task = Task()
        task.delegate_to = "delegated-to-host"
        task.remote_user = "delegated-to-user"
        variables = { "ansible_delegated_vars":{ "delegated-to-host": {"ansible_host":"delegated-to-host-ip"}}}
        pc.set_task_and_variable_override(task, variables, { "template": lambda a: a})

# Generated at 2022-06-11 10:19:11.622339
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    host = MagicMock()
    pc = PlayContext(host)
    assert pc.timeout == C.DEFAULT_TIMEOUT
    assert pc.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert pc.verbosity == 0
    assert pc.start_at_task == None
    assert pc.step == False
    assert pc.force_handlers == False
    # Test if the attributes are properly set
    pc.set_attributes_from_cli()
    assert pc.timeout == context.CLIARGS['timeout']
    assert pc.private_key_file == context.CLIARGS['private_key_file']
    assert pc.verbosity == context.CLIARGS['verbosity']
    assert pc.start_at_task == context.CLIARGS['start_at_task']


# Generated at 2022-06-11 10:19:23.567712
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    cli_args = {
        'timeout' : True,
        'private_key_file' : 'test_private_key_file',
        'verbosity' : 1,
        'start_at_task' : 'test_start_at_task'
    }
    context.CLIARGS = Namespace(**cli_args)
    play = Play()
    play_context = PlayContext(play)
    assert play_context.timeout == int(context.CLIARGS['timeout'])
    assert play_context.private_key_file == context.CLIARGS['private_key_file']
    assert play_context.verbosity == context.CLIARGS['verbosity']
    assert play_context.start_at_task == context.CLIARGS['start_at_task']


# Generated at 2022-06-11 10:19:36.028169
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    '''
    Test the PlayContext set_attributes_from_cli() method
    '''

    # Arrange
    context.CLIARGS = dict(
        timeout=120,
        verbosity=3,
        start_at_task=None,
        private_key_file=None,
        connection=None
    )
    play = Play()
    passwords = {}
    connection_lockfd = None
    ctx = PlayContext(play, passwords, connection_lockfd)

    # Act
    ctx.set_attributes_from_cli()

    # Assert
    assert ctx.timeout == 120
    assert ctx.verbosity == 3
    assert ctx.private_key_file is None
    assert ctx.start_at_task is None
    assert ctx.connection == 'smart'



#

# Generated at 2022-06-11 10:19:46.714094
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    mock_task = MagicMock()
    mock_task.delegate_to = None
    mock_task.remote_user = "REMOTE_USER"
    mock_task.run_once = False
    mock_task.connection = None
    mock_task.sudo = False
    mock_task.sudo_user = None
    mock_task.become = False
    mock_task.become_user = None
    mock_task.become_method = None
    mock_task.extra_vars = dict()
    mock_task.transport = None
    mock_task.no_log = False
    mock_task.check_mode = None,
    mock_task.diff = None,

    mock_templar = MagicMock()
    mock_variables = dict()

# Generated at 2022-06-11 10:19:54.684430
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
	from copy import deepcopy

	context.CLIARGS = dict(private_key_file='./test/ansible_ssh_private_key',verbosity=5,timeout=60)
	temp_context = deepcopy(context)
	context.CLIARGS = {}
	
	pc = PlayContext(connection_lockfd=1)
	# get options for plugins
	plugin = Mock()
	plugin.get_option.return_value = "ssh"
	pc.set_attributes_from_plugin(plugin)
	assert pc.connection == 'ssh'
	assert pc.verbosity == 0
	assert pc.private_key_file == None
	assert pc.timeout == None



# Generated at 2022-06-11 10:20:06.497883
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    task = MagicMock()
    variables = {}
    templar = MagicMock(_loader=None)
    pc = PlayContext()
    pc.set_attributes_from_cli = MagicMock()
    pc.set_attributes_from_play = MagicMock()
    pc.set_become_plugin = MagicMock()
    pc.copy = MagicMock()
    pc.copy.return_value = pc
    pc.copy.__str__ = MagicMock()
    pc.copy.__str__.return_value = "copy"
    pc.set_task_and_variable_override(task, variables, templar)
    pc.set_attributes_from_cli.assert_called_once_with()

# Generated at 2022-06-11 10:20:37.630701
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    import jinja2
    pc = PlayContext()
    pc.set_attributes_from_cli()
    pc.set_attributes_from_play(Play())
    #test cli args
    pc.set_task_and_variable_override(Task(), {}, jinja2.Environment)

# Generated at 2022-06-11 10:20:43.648211
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Macros:
    
    inventory = FakeInventory()
    play = FakePlay()

    # Setup test objects
    p = PlayContext()

    # Test conditions
    # Test 1:
    plugin = FakePlugin()

    p.set_attributes_from_plugin(plugin)

    # Assertions
    # Test 1:
    assert len(p.attributes()) == len(C.config.get_configuration_definitions(FakeBaseClass, None))


# Generated at 2022-06-11 10:20:56.650633
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    """
    set_attributes_from_cli
    """

    context.CLIARGS = {
        'verbosity': 2,
        'timeout': 10,
        'private_key_file': '/path/to/key',
        'host_key_checking': False,
        'no_log': False,
        'diff': True,
        'start_at_task': 'some_task',
        'force_pipelining': True
    }

    p = PlayContext()
    p.set_attributes_from_cli()
    assert p.timeout == 10
    assert p.private_key_file == "/path/to/key"
    assert p.verbosity == 2
    assert p.link_tree_depth == 5
    assert p.start_at_task == "some_task"
    assert p.force

# Generated at 2022-06-11 10:21:03.474091
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    task = dict(
        action=dict(
            become=True,
            become_user='become_user_task',
            become_method='become_method_task',
            become_pass='become_pass_task'
        ),
        delegate_to='delegate_to_task',
        remote_user='remote_user_task',
        check_mode=True,
        diff=True
    )

# Generated at 2022-06-11 10:21:14.391499
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    provider = AnsibleConnectionProvider()
    connection_loader.connection_loader.get = MagicMock(return_value=provider)
    connection_loader.connection_loader.get.get = MagicMock(return_value=provider)

    def init_connection(self):
        self.connection = MagicMock()

    provider.init_connection = MagicMock(side_effect=init_connection)

    play = MagicMock()
    play.force_handlers = False
    play_context = PlayContext(play)
    play_context.set_attributes_from_cli()

    templar = Templar(loader=Mock())  # FIXME: do we need to mock?
    task = Mock()
    task.become = False
    task.become_method = False
    task.become_user = False
   

# Generated at 2022-06-11 10:21:27.648675
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play_context = PlayContext(play=None, passwords=None, connection_lockfd=None)
    assert play_context.connection == 'ssh'
    assert play_context.connection_user == 'remote_user'
    assert play_context.remote_addr == 'remote_addr'
    assert play_context.remote_user == 'remote_user'
    assert play_context.password == ''
    assert play_context.port == None
    assert play_context.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert play_context.timeout == C.DEFAULT_TIMEOUT
    assert play_context.network_os == None
    assert play_context.become == False
    assert play_context.become_method == 'sudo'
    assert play_context.become_user == None
    assert play

# Generated at 2022-06-11 10:21:36.912454
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            Task().load(dict(action=dict(module='setup', args=dict())))
        ]
    ), variable_manager=VariableManager())
    play._variable_manager.extra_vars=dict(ansible_connection='local')
    pc = PlayContext(play=play)

# Generated at 2022-06-11 10:21:47.819891
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Set up mock objects
    task_object               = MagicMock(spec=Task)
    variable_object           = MagicMock(spec=dict)
    templar_object            = MagicMock(spec=J2Template)
    ansible_connection        = MagicMock(spec=str)

    # Set up test object
    new_test_object           = PlayContext()

    # Test with mock objects
    new_test_object.connection         = "connection_local_1"
    new_test_object.remote_addr        = "local_ip_1"
    new_test_object.remote_user        = "local_user_1"
    new_test_object.port               = "port_1"
    new_test_object.executable         = "executable_1"
    new_test_object.network_

# Generated at 2022-06-11 10:21:55.695482
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """Unit test for PlayContext.set_attributes_from_plugin"""

    from ansible.cli.arguments import option_helpers as opt_help

    test_info = PlayContext()

    # Test that set_attributes_from_plugin() was called with a valid plugin
    opt_help.set_plugin_options('raw', test_info, 'type', 'raw')
    assert test_info.network_os == 'default'


# Generated at 2022-06-11 10:21:57.088953
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    PlayContext.set_attributes_from_plugin('test')

# Generated at 2022-06-11 10:22:35.398196
# Unit test for constructor of class PlayContext
def test_PlayContext():
    assert Play() == Play(dict())
    assert PlayContext().__class__.__name__ == 'PlayContext'

# Generated at 2022-06-11 10:22:36.101022
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    pass

# Generated at 2022-06-11 10:22:46.796098
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.plugins.connection.network_cli import Connection
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import MercenaryVariableManager
    from ansible.vars.manager import VaultAwareVariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

# Generated at 2022-06-11 10:22:57.553594
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.playbook.play import Play
    from ansible.plugins.connection.local import Connection as LocalConnection
    from ansible.plugins.connection.ssh import Connection as SSHConnection
    from ansible.plugins.connection.paramiko_ssh import Connection as ParamikoConnection

    plugin = LocalConnection()
    play = Play()
    passwords = {}
    play_context = PlayContext(play=play, passwords=passwords)
    play_context.set_attributes_from_plugin(plugin)
    assert play_context.connection == plugin.get_option('connection')

    plugin = SSHConnection()
    play = Play()
    passwords = {}
    play_context = PlayContext(play=play, passwords=passwords)
    play_context.set_attributes_from_plugin(plugin)
    assert play_context.connection == plugin.get_

# Generated at 2022-06-11 10:23:01.117450
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play = create_ansible_module_mock()
    p = PlayContext(play)
    p.set_attributes_from_plugin(p)
    assert p.password == 'conn_pass'



# Generated at 2022-06-11 10:23:12.825617
# Unit test for constructor of class PlayContext
def test_PlayContext():
    '''
    This does some basic tests for the constructor (__init__) of the class PlayContext.
    This is NOT a complete unit test for all the methods of the class.
    '''

    from ansible.inventory import Host
    from ansible.parsing.dataloader import DataLoader

    def _get_loader(vars_manager):
        return DataLoader()

    def _get_variable_manager(inventory):
        return VariableManager(loader=_get_loader(None), inventory=inventory)

    # Create an instance of the PlayContext class
    play_context = PlayContext(play = None, passwords = None)

    # Using the instance, call the constructor of the PlayContext class

    # Create a Host object that is used in the constructor
    a_host = Host(name = "some_host")

    # Create a VariableManager

# Generated at 2022-06-11 10:23:23.038196
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Ensure C.MAGIC_VARIABLE_MAPPING is not None
    assert C.MAGIC_VARIABLE_MAPPING is not None

    # Ensure C.DEFAULT_TRANSPORT is not None
    assert C.DEFAULT_TRANSPORT is not None

    pc = PlayContext()

    # Ensure C.DEFAULT_REMOTE_PORT is not None
    assert C.DEFAULT_REMOTE_PORT is not None

    task = Task()
    variables = dict()
    templar = J2Template()

    # Ensure pc.executable is not None
    assert pc.executable is not None

    # Ensure pc.remote_user is not None
    assert pc.remote_user is not None

    # Ensure pc.remote_addr is not None
    assert pc.remote_addr is not None

    #

# Generated at 2022-06-11 10:23:30.085272
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # set_task_and_variable_override(task, variables, templar)
    #TODO: This test is not currently working, the tests need to be redone using newer ansible code
    # It is currently commented out of the tests.
    test_object = PlayContext()
    task = None
    variables = {}
    templar = None
    print(test_object.set_task_and_variable_override(task, variables, templar))
    return True


# Generated at 2022-06-11 10:23:43.050161
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # Python2 does not recognize nonlocal keyword, so variables scope is bound to inner function
    # and we need to use globals to access them
    task_vars_global = {}
    variables = {}
    play_context_global = PlayContext()

    def encode_for_read(*args):
        # in the test, it is ok to pass arguments as-is
        return args[0]

    # Python2 does not recognize nonlocal keyword, so variables scope is bound to inner function
    # and we need to use globals to access them
    def lookup_plugin(name):
        if name == 'template':
            return encode_for_read
        return None


# Generated at 2022-06-11 10:23:50.734474
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # import needed modules
    import ansible.plugins.action.normal as action_plugin
    C = config.Config(parser=FakeCLIArgsParser({'verbosity': 2, 'timeout': 5}))
    task_vars = {}
    fake_class = FakePlayContextClass('test_host_1', task_vars)
    setattr(fake_class, 'play', fake_class)
    play_context = PlayContext(play=fake_class)
    assert play_context.verbosity == 2
    assert play_context.timeout == 5

# Generated at 2022-06-11 10:24:35.967063
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    class MockCLIArgs(object):
        ''' A mock class representing the context.CLIARGS dictionary. '''

        def items(self):
            return self.__dict__.items()

        def get(self, key, default=None):
            return getattr(self, key, default)

    context.CLIARGS = MockCLIArgs()
    context.CLIARGS.timeout = '4'
    context.CLIARGS.verbosity = '1'
    context.CLIARGS.private_key_file = 'foo'

    p = PlayContext()
    p.set_attributes_from_cli()

    assert p.timeout == 4
    assert p.verbosity == 1
    assert p.private_key_file == 'foo'


# Generated at 2022-06-11 10:24:44.396766
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    plu = PlayContext()
    assert plu.update_vars({}) == None
    assert plu.set_attributes_from_plugin({}) == None
    pcc = PlayContext()
    assert pcc.set('connection_lockfd', 5) == None
    assert pcc.set_attributes_from_play({}) == None
    assert pcc.set_attributes_from_cli() == None
    assert pcc.update_vars({}) == None
    assert pcc.set_attributes_from_plugin({}) == None
    assert pcc.set_task_and_variable_override({}, {}, {}) == None


# Generated at 2022-06-11 10:24:47.857329
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    # play = None
    # passwords = None
    # connection_lockfd = None

    # PlayContext(play=play, passwords=passwords, connection_lockfd=connection_lockfd)
    pass


# Generated at 2022-06-11 10:24:56.456437
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    data = dict(
        a=u'a_value',
        b=u'b_value',
        c=u'c_value',
    )

    class PluginClass(object):
        def get_option(self, option):
            return data[option]
    p = PluginClass()
    pc = PlayContext()
    pc.set_attributes_from_plugin(p)
    assert pc.a == u'a_value'
    assert pc.b == u'b_value'
    assert pc.c == u'c_value'


# Generated at 2022-06-11 10:25:09.524236
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # setup test
    class DummyTask():
        def __init__(self):
            self.remote_user = 'user'
            self.delegate_to = None
            self.check_mode = False
            self.diff = True

    task = DummyTask()
    play_context = PlayContext(None)

    # testing
    play_context.set_task_and_variable_override(task, {}, None)

    # assertions
    assert play_context.remote_user == 'user'
    # TODO(skrulcik) play_context.prompt is empty?
    # assert play_context.prompt
    assert not play_context.force_handlers
    assert not play_context.check_mode
    assert play_context.diff



# Generated at 2022-06-11 10:25:21.730159
# Unit test for constructor of class PlayContext
def test_PlayContext():
    def check_PlayContext(result_data, except_data):
        assert result_data['connection'] == except_data['connection']
        assert result_data['remote_addr'] == except_data['remote_addr']
        assert result_data['remote_user'] == except_data['remote_user']
        assert result_data['port'] == except_data['port']
        assert result_data['password'] == except_data['password']
        assert result_data['private_key_file'] == except_data['private_key_file']
        assert result_data['timeout'] == except_data['timeout']
        assert result_data['connection_user'] == except_data['connection_user']
        assert result_data['become'] == except_data['become']

# Generated at 2022-06-11 10:25:29.730969
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
  '''
  Unit test for set_task_and_variable_override of class PlayContext
  '''
  print("")
  print("##### In test_PlayContext_set_task_and_variable_override #####")
  print("")
  new_info = PlayContext()
  task = Task()
  variables = {}
  templar = Templar()
  print("Set task parameters")
  setattr(task, 'remote_user', 'test_user')
  setattr(task, 'no_log', True)
  setattr(task, 'delegate_to', 'check_delegate_to')
  setattr(task, 'port', 2222)
  setattr(task, 'check_mode', True)
  setattr(task, 'diff', True)

# Generated at 2022-06-11 10:25:43.281608
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # Unit test for method set_attributes_from_cli of class PlayContext

    # Setup an instance of PlayContext, and mock the options specifed on the command line
    play_context = PlayContext()
    context.CLIARGS = {'timeout':'10'}

    # set_attributes_from_cli should set the timeout to the value of the timeout option, and private_key_file to the value specified
    play_context.set_attributes_from_cli()
    assert play_context.timeout == 10
    assert play_context.private_key_file == 'None'

    # Set the verbosity of the PlayContext object to an integer, and test that it was set properly
    context.CLIARGS['verbosity'] = 1
    play_context.set_attributes_from_cli()
    assert play_context.verb

# Generated at 2022-06-11 10:25:48.661352
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    set_attributes_from_plugin_arg1 = ''
    set_attributes_from_plugin_arg2 = {}

    # Test normal execution
    set_attributes_from_plugin_arg1 = 'vagrant'
    set_attributes_from_plugin_arg2 = {'connection': 'ssh'}
    set_attributes_from_plugin_arg3 = {'connection': 'paramiko'}



# Generated at 2022-06-11 10:25:54.448737
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    class MockTask:
        delegate_to = None
        check_mode = False
        diff = 'dummyDiff'
    task = MockTask()
    variables = {}
    templar = MagicMock()
    templar.template.return_value = 'delegated_host'
    pc = PlayContext()
    pc.set_task_and_variable_override(task,variables,templar)
    assert pc.diff
    assert pc.check_mode == False
    assert pc.delegate_to == None
    pc.connection = 'smart'
    assert pc.connection == 'ssh'
    pc.connection = 'persistent'
    assert pc.connection == 'paramiko'
    class MockTask2:
        delegate_to = 'delegated_host'
        check_mode = False

# Generated at 2022-06-11 10:27:22.549486
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()
    play_context.set_attributes_from_plugin(None)


# Generated at 2022-06-11 10:27:32.388981
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Tests set_attributes_from_plugin of class PlayContext
    '''
    # Test with no options
    display.display = MagicMock()
    C.CLIARGS = {'timeout': False}

    A = PlayContext()
    A.set_attributes_from_cli()
    A.set_attributes_from_plugin("ping")

    assert A.timeout == 5
    assert A.verbosity == 0
    assert A.start_at_task is None
    assert A.private_key_file == '~/.ssh/id_rsa'
    assert A.executable is None
    assert A.network_os == 'default'
    assert A.network_os_override is None

    # Test with options
    C.CLIARGS = {'timeout': '6'}
    display

# Generated at 2022-06-11 10:27:37.444424
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Create a mock connection plugin
    plugin = Mock()
    # Mock the options
    plugin._options = {'foo': 'bar'}
    # Instantiate a PlayContext
    pc = PlayContext()
    # Execute the method
    pc.set_attributes_from_plugin(plugin)
    # Check that the plugin's options have been set in PlayContext attributes
    assert pc.foo == 'bar'



# Generated at 2022-06-11 10:27:39.482063
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    unit test for method set_attributes_from_plugin of class PlayContext
    '''
    pass



# Generated at 2022-06-11 10:27:49.993914
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """ Unit test for method set_attributes_from_plugin of class PlayContext """
    # imports
    import os
    import yaml
    from ansible.parsing.dataloader import DataLoader

    # prepare data
    file_name = 'test.yaml'
    test_data = 's_command_timeout: 10'
    file_path = os.path.join(os.path.splitext(__file__)[0], file_name)

    # prepare connection plugin
    plugin = 'shell'
    play_context = PlayContext()

    # prepare DataLoader class
    data_loader = DataLoader()

    # call the method

# Generated at 2022-06-11 10:27:57.001343
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    myPlayContext = PlayContext(play=None, passwords=None, connection_lockfd=None)
    myPlayContext.set_attributes_from_play(play=None)
    myTask = Task(play=None)
    myVariables = {}
    myTemplar = Templar(loader=None, variables=None)
    myPlayContext.set_task_and_variable_override(task=myTask, variables=myVariables, templar=myTemplar)
    assert(myPlayContext.__class__ == PlayContext)


# Generated at 2022-06-11 10:28:00.969759
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    """Unit test for method set_attributes_from_plugin of class PlayContext"""
    fixture = PlayContext()
    # test with a plugin
    plugin = 'nxos_facts'
    fixture.set_attributes_from_plugin(plugin)
    assert fixture.verbosity == 0


# Generated at 2022-06-11 10:28:03.012371
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    instance = PlayContext()
    plugin = 'connection_plugins.network_cli'
    instance.set_attributes_from_plugin(plugin)