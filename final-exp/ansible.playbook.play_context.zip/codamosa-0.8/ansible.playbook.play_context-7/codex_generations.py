

# Generated at 2022-06-11 10:18:24.832461
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    """
        PlayContext
        Test set_attributes_from_cli
    """
    runner = Runner()

    # Create a play context and set attributes from cli
    play_context = PlayContext()
    play_context.set_attributes_from_cli()
    assert play_context.timeout == C.DEFAULT_TIMEOUT
    assert play_context.verbosity == 0
    assert play_context.start_at_task == None
    assert play_context.failed_when_contains == None
    assert play_context.changed_when_contains == None
    assert play_context.fail_on_lookup_errors == True
    assert play_context.stdout_callback == C.DEFAULT_STDOUT_CALLBACK
    assert play_context.bin_ansible_callbacks == C.DEFAULT_BIN_ANSIBLE_

# Generated at 2022-06-11 10:18:38.704851
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    """Unit test for method set_task_and_variable_override() of class PlayContext."""
    from ansible.vars.hostvars import HostVars
    from jinja2.environment import Environment
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.template.template import Templar

    play = Play()
    play.force_handlers = True

    pc = PlayContext(play)


# Generated at 2022-06-11 10:18:49.606601
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play1 = Play()
    play1._variable_manager = VariableManager()
    play1._variable_manager._extra_vars = dict(
            ansible_connection="foo",
            ansible_port=100,
            ansible_host="bar",
            remote_user="baz")

    play2 = Play()
    play2._variable_manager = VariableManager()
    play2._variable_manager._extra_vars = dict(
            ansible_connection="foo",
            ansible_port=100,
            ansible_host="bar",
            remote_user="baz")

    play1.connection = "local"
    play2.connection = "haha"

    play1.force_handlers = True
    play2.force_handlers = False

    play1.become = True
    play2.bec

# Generated at 2022-06-11 10:18:50.922990
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    test_object = PlayContext()
    assert test_object



# Generated at 2022-06-11 10:19:03.762174
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    # set up some constants
    # set local variables
    cli_args = dict()
    cli_args['timeout'] = '10'
    cli_args['private_key_file'] = '/path/to/sshkey.pem'
    cli_args['verbosity'] = 3
    cli_args['start_at_task'] = 'my-task'

    # set context.CLIARGS
    context.CLIARGS = cli_args

    # initialize a PlayContext
    play_context = PlayContext()
    play_context.set_attributes_from_cli()

    assert play_context.timeout == 10
    assert play_context.private_key_file == '/path/to/sshkey.pem'
    assert play_context.verbosity == 3
    assert play_context.start_at

# Generated at 2022-06-11 10:19:09.709113
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    play_context = PlayContext()
    plugin = 'paramiko'
    play_context.set_attributes_from_plugin(plugin)
    assert play_context._port == 22
    assert play_context._timeout == 10
    assert play_context._connection == 'ssh'

test_PlayContext_set_attributes_from_plugin()


# Generated at 2022-06-11 10:19:19.736935
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Unit test for method set_attributes_from_plugin of class PlayContext
    '''
    import os
    import sys
    from mock import patch, Mock

    from ansible.mock import patch, mock_open
    from ansible import context
    from ansible.module_utils import basic
    from ansible.cli import CLI
    from ansible.module_utils._text import to_native
    from ansible.executor.play_iterator import PlayIterator


    attrs = PlayContext._get_attributes()
    context._init_global_context(CLI.base_parser(constants.BaseCLI))
    # config = ConfigurationManager(os.path.join('test', 'ansible.cfg'))
    config = ConfigurationManager(mock_open(read_data=''))

# Generated at 2022-06-11 10:19:33.436656
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    hostvars = dict()
    task = dict()
    task['delegate_to'] = '127.0.0.1'
    task['remote_user'] = 'root'
    task['delegated_vars'] = dict()
    task['delegated_vars']['ansible_host'] = "127.0.0.1"
    task['delegated_vars']['ansible_port'] = "22"
    task['delegated_vars']['ansible_ssh_user'] = "root"
    variables = dict()
    variables['ansible_ssh_user'] = "root"
    variables['ansible_port'] = "22"
    variables['ansible_host'] = "127.0.0.1"
    play = dict()

# Generated at 2022-06-11 10:19:44.589818
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    config = ConfigParser()
    config.add_section('defaults')
    config.set('defaults', 'become', 'no')
    config.set('defaults', 'become_method', 'sudo')
    config.set('defaults', 'become_user', 'root')
    config.set('defaults', 'transport', 'paramiko')
    config.set('defaults', 'executable', '/bin/sh')

    # Connection is set to paramiko in set_attributes_from_play
    # this is a temporary fix, at some point it should not be set in connection

# Generated at 2022-06-11 10:19:45.892396
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    play_context.set_task_and_variable_override(task, variables, templar)

# Generated at 2022-06-11 10:20:31.601597
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # fake a plugin object
    fake_plugin = FakePlugin()
    fake_plugin.set_option('test_option_name', ['test_option_value'])
    fake_plugin.set_option('test_option_name_none', None)

    # test values for verifying results
    test_option_value = ['test_option_value']
    test_option_name_none = None

    __play_context__ = PlayContext()

    # set attriburtes from the fake plugin
    __play_context__.set_attributes_from_plugin(fake_plugin)

    # check that options from plugin are correctly set in play context
    assert __play_context__._test_option_name == test_option_value
    assert __play_context__._test_option_name_none == test_option_name_none


# Unit

# Generated at 2022-06-11 10:20:33.702620
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    x = PlayContext()
    x.set_attributes_from_plugin()

# Generated at 2022-06-11 10:20:43.688226
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # generate a test play
    play = Play()
    play.vars = dict()
    play.vars['magic_bar'] = "magic_bar"
    play.vars['magic_baz'] = "magic_baz"
    play.vars['magic_foo'] = "magic_foo"
    # generate a test task
    task = Task()
    task.name = "dump_vars"
    task.hosts = 'host1'
    task.vars = dict()
    task.vars['magic_bar'] = "task_magic_bar"
    task.vars['magic_tar'] = "task_magic_tar"
    # generate a test inventory
    inventory = Inventory(loader=None)
    host1 = Host(name='host1')

# Generated at 2022-06-11 10:20:47.495443
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    context.CLIARGS = ImmutableDict({'verbosity': 4})
    play_context = PlayContext()
    assert play_context._verbosity == 4

# Generated at 2022-06-11 10:20:59.432858
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import get_plugin_class
    test_instance = PlayContext()
    # conn_pass and become_pass are strings
    password_dict = {'conn_pass' : 'secret', 'become_pass' : 'secret'}
    # connection_lockfd is an int
    connection_lockfd = 1
    test_play = Play.load(dict(name='test_play', hosts='localhost',
                               gather_facts='no'))
    test_instance.set_attributes_from_play(test_play)
    try:
        test_instance.set_attributes_from_plugin('ssh')
    except AnsibleError:
        pass

# Generated at 2022-06-11 10:21:05.791671
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # create an instance of the PlayContext class without arguments
    my_obj = PlayContext()

    # TODO: Add tests for the set_attributes_from_plugin method of PlayContext.
    #
    # For example:
    #
    # my_obj.set_attributes_from_plugin(plugin)
    #
    # assert(my_obj.attribute == expected_value)
    #
    # assert_raises(ExceptionType, my_obj.attribute, *args, **kwargs)
    pass


# Generated at 2022-06-11 10:21:15.195385
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    conn_plugin = Connection(load_name='network_cli')
    pc = PlayContext(None)

    # set_attributes_from_plugin should get the options for the plugin
    # and set options for the play_context
    pc.set_attributes_from_plugin(conn_plugin)

    assert isinstance(pc.remote_addr, str)
    assert pc.remote_addr == '127.0.0.1'
    assert isinstance(pc.connection, str)
    assert pc.connection == 'network_cli'
    assert isinstance(pc.become, bool)
    assert pc.become is False
    assert hasattr(pc, "network_os")


# Generated at 2022-06-11 10:21:28.571730
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # Setup:
    # Need to create a loader and fake an inventory so the PlayContext init can pass.
    # we append a block to it, so we'll have something to grab in set_attributes_from_plugin.
    test_loader = DataLoader()
    test_inventory = Inventory(loader=test_loader, variable_manager=VariableManager())
    test_inventory.add_group('test_group')
    test_inventory.add_host(Host('test_host', groups=['test_group']))

    test_module = 'setup'
    test_class = 'setup'
    test_name = 'setup'
    test_args = dict()


# Generated at 2022-06-11 10:21:30.948552
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    context = PlayContext(play=None, passwords=None, connection_lockfd=None)
    context.set_attributes_from_plugin(context)


# Generated at 2022-06-11 10:21:35.304294
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():

    fake_task = 'fake_task'
    fake_variables = 'fake_variables'
    fake_templar = 'fake_templar'
    play_context = PlayContext()
    play_context.set_task_and_variable_override(fake_task, fake_variables, fake_templar)

# Generated at 2022-06-11 10:22:05.286048
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # FIXME: Add unit test
    pass

# Generated at 2022-06-11 10:22:16.331097
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    # path to the 'fake' inventory file used by unit tests
    inventory_path = os.path.join(os.path.dirname(__file__), 'test_utils/inventory')
    # path to the 'fake' vault file used by unit tests
    vault_password_path = os.path.join(os.path.dirname(__file__), 'test_utils/vault_password.txt')

    # Initialize some variables that we will use in tests
    faketask = Task()
    fake_vars = {}
    templar = Templar(loader=DataLoader())

    # Create a PlayContext object, but don't call the set_task_and_variable_override method yet
    pc = PlayContext()

    # Ensure that the play context object is created properly
    assert pc.become is False
    assert pc.bec

# Generated at 2022-06-11 10:22:26.826161
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    display.screen("test_PlayContext_set_task_and_variable_override")
    # test the set_task_and_variable_override() method of PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.template.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.clean import module_response_deepcopy

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    templar = Templar(loader=loader, variables=variable_manager)

    pc = PlayContext()
    # create a test task
    task = Task()
    task.delegate_to = 'mydelegatehost'
    task.remote_user

# Generated at 2022-06-11 10:22:32.195047
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from units.mock.executor.task_result import TaskResult
    from ansible.plugins.loader import action_loader

    mock_loader = DictDataLoader({
        "test_hostname.yaml": """
            task1:
              local_action:
                module: shell
                args: echo 'hello'
                delegate_to: test_hostname_42
              delegate_to: test_hostname_42
              become: yes
              become_user: root
            """,
    })


# Generated at 2022-06-11 10:22:40.978218
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    PlayContext_instance = PlayContext()
    PlayContext_instance.set_attributes_from_cli()
    PlayContext_instance.get_remote_user = lambda : 'root'
    PlayContext_instance.remote_port = 22
    task = MagicMock()
    variables = {}
    templar = MagicMock()
    templar.template = lambda x : 'localhost'
    PlayContext_instance.set_task_and_variable_override(task, variables, templar)
    assert PlayContext_instance.connection == 'local'
    assert PlayContext_instance.remote_user == 'root'
    assert PlayContext_instance.remote_port == 22


# Generated at 2022-06-11 10:22:42.903237
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    context = PlayContext()
    context.set_attributes_from_plugin(None)


# Generated at 2022-06-11 10:22:46.235990
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    fake_plugin = 'fake plugin'
    context = PlayContext()
    context.set_attributes_from_plugin(fake_plugin)
    assert 'fake plugin' is fake_plugin

# Generated at 2022-06-11 10:22:47.780540
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    #  Tested when running tests for ansible
    pass
                    

# Generated at 2022-06-11 10:22:51.266693
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    play_context.set_task_and_variable_override(task, variables, templar)
    # TODO: So far, we skip this unit test.
    pass


# Generated at 2022-06-11 10:22:54.520432
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    client = docker.from_env()
    myclass = PlayContext()
    myclass.set_attributes_from_cli()
    myclass.set_attributes_from_play(play)

# Generated at 2022-06-11 10:23:21.686375
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
  pass

# Generated at 2022-06-11 10:23:24.017398
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    playContext = PlayContext()
    playContext.set_attributes_from_plugin(None)
    assert playContext is not None



# Generated at 2022-06-11 10:23:27.666227
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    my_ctx = PlayContext()
    my_plugin = my_ctx.set_attributes_from_plugin(my_ctx)
    assert my_plugin is None, 'Value should be None, got %s' % my_plugin


# Generated at 2022-06-11 10:23:30.579018
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    for cls_name in filter(lambda n: n.endswith("TestCase"), vars(PlayContextTestCase).keys()):
        yield run_test, cls_name


# Generated at 2022-06-11 10:23:43.413874
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():

    variables = dict()

    play_context = PlayContext(variables)

    conn_pass = 'conn_pass'
    become_pass = 'become_pass'
    prompt = 'prompt'
    success_key = 'success_key'
    timeout = 1
    network_os = 'network_os'
    connection_lockfd = 2
    force_handlers = False
    start_at_task = 'start_at_task'
    step = False
    verbosity = 2
    remote_user = 'remote_user'
    private_key_file = 'private_key_file'
    pipelining = False
    ssh_common_args = ''
    ssh_extra_args = ''
    sftp_extra_args = ''
    scp_extra_args = ''
    ssh_executable = ''
   

# Generated at 2022-06-11 10:23:54.322142
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    print ('In test_PlayContext_set_task_and_variable_override')
    pc = PlayContext()
    task = mock.Mock(
        become_pass=None, no_log=None, check_mode=None, delegate_to=None,
        remote_user=None, connection=None, port=None, environment=None,
        ssh_common_args=None, ssh_extra_args=None, sftp_extra_args=None,
        scp_extra_args=None, ssh_executable=None,
        timeout=None, shell=None, sudo=None,
        sudo_user=None, become=None, become_method=None, become_exe=None,
        verbosity=None,
    )
    variables = {}

# Generated at 2022-06-11 10:23:54.966537
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    pass

# Generated at 2022-06-11 10:24:07.050163
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    '''
    Unit test for set_attributes_from_plugin()
    '''

    # from ansible.plugins.connection.local import Connection as local_Connection
    import ansible.plugins.connection.paramiko_ssh as paramiko_ssh
    import types
    ''' Note: set_attributes_from_plugin takes plugin as its argument but 
        uses only plugin._load_name variable. So we create a dummy_class and
        set its _load_name variable
    '''
    dummy_class = types.ClassType('paramiko_ssh')
    dummy_class._load_name = 'paramiko_ssh'
    test_connection_plugin = dummy_class()
    test_connection_plugin.get_option = paramiko_ssh.Connection.get_option
    test_connection_plugin.set_option = paramiko_ssh.Connection

# Generated at 2022-06-11 10:24:17.251929
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    #//////////////////////////////////////////////////////////////////////////////////////////////////
    # PlayContext.set_task_and_variable_override
    #//////////////////////////////////////////////////////////////////////////////////////////////////

    # Check what happens when task.delegate_to -> delegated_host_name differs from delegated_host_name in inventory
    # Which should be the case if a loop variable is used to set the delegate_to host.
    # See https://github.com/ansible/ansible/issues/18723
    task = dict(delegate_to='{{ hostvars[item]["inventory_hostname"] }}')
    play = dict()
    host = dict()

    pc = PlayContext(task=task, play=play, connection_lockfd=None)
    pc.set_attributes_from_play(play)
    pc.set_attributes_from_cli()
    pc.set_attributes_from_plugin

# Generated at 2022-06-11 10:24:23.616128
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    PlayContext._create_global_lockfd()
    PlayContext._global_lockfd = -3
    PlayContext._global_lockfd_used = 0
    fake_play = FakePlay()
    passwords = {}
    connection_lockfd = -3
    obj = PlayContext(play = fake_play, passwords = passwords, connection_lockfd = connection_lockfd)
    obj.set_attributes_from_plugin('mock_plugin')



# Generated at 2022-06-11 10:25:01.599319
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    task = Task()
    task.delegate_to = 'test_delegate_to'
    task.remote_user = 'test_remote_user'
    task.become_user = 'test_become_user'
    task.become = True
    task.become_method = 'test_become_method'
    task.check_mode = True
    task.diff = True
    playContext = PlayContext()
    setattr(playContext, 'connection', 'test_connection')
    setattr(playContext, 'remote_addr', 'test_remote_addr')
    setattr(playContext, 'remote_user', 'test_remote_user')
    setattr(playContext, 'port', None)
    setattr(playContext, 'connection_user', None)

# Generated at 2022-06-11 10:25:04.477180
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    assert False, "Unit tests are not yet implemented for test_PlayContext_set_task_and_variable_override"



# Generated at 2022-06-11 10:25:17.861406
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    context._init_global_context(['ansible-playbook','-i','tests/integration/inventory', 'play.yml','-vvvv'])
    context.CLIARGS = ImmutableDict(verbosity=4, inventory='tests/integration/inventory',extra_vars='{"foo":"bar"}')
    inventory = InventoryManager(loader=get_loader(), sources='tests/integration/inventory')
    variables = VariableManager(loader=get_loader(), inventory=inventory)
    templar = Templar(loader=get_loader(), variables=variables)
    pc = PlayContext(task=None, play=None, options=None, passwords=None)
    pc.set_attributes_from_plugin("yaml")
    all_attributes = pc._get_attributes()

# Generated at 2022-06-11 10:25:27.703028
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    play_context = PlayContext(None)
    play_context.set_attributes_from_plugin(module)

    assert play_context._network_os == None
    assert play_context.remote_addr == None
    assert play_context.verbosity == None
    assert play_context._connection == None
    assert play_context.check_mode == None
    assert play_context.become == None
    assert play_context.become_user == None
    assert play_context.become_method == None
    assert play_context.diff == None
    assert play_context.no_log == None
    assert play_context.timeout == None
    assert play_context.remote_user == None
    assert play_context

# Generated at 2022-06-11 10:25:40.991685
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    host_part = dict()
    host_part.setdefault('host', 'localhost')
    host_part.setdefault('group', 'test')
    hosts_name = ["host1","host2", "host3"]
    hosts = dict()
    for host_name in hosts_name:
        host_part.setdefault('name', host_name)
        hosts[host_name] = Host(host_part)

    inventory = Inventory(hosts)
    # group
    group1 = Group(inventory,name='test')
    group1._vars = dict()
    inventory.add_group(group1)

    # variablemanager
    variable_manager = VariableManager(inventory)

    # options
    defaults = dict()
    defaults.setdefault('timeout', 10)
    defaults.setdefault('connection', 'ssh')

# Generated at 2022-06-11 10:25:49.369335
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    # test on modules
    # FIXME: how to check variable value?
    # FIXME: need add test case for network modules
    target = PlayContext()

    # test on paramiko and ssh
    # FIXME: how to check variable value?
    target.set_attributes_from_plugin('paramiko')
    target.set_attributes_from_plugin('ssh')

    # test on docker_module
    target.set_attributes_from_plugin('docker')
    assert target._docker_extra_args == None

    # test on uri
    target.set_attributes_from_plugin('uri')
    assert target._body_format == None



# Generated at 2022-06-11 10:25:50.922658
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    play_context_obj = PlayContext()
    assert not play_context_obj.become


# Generated at 2022-06-11 10:26:01.717210
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    '''
      unit test for PlayContext.set_task_and_variable_override
    '''
    task = Task()
    templar = Templar()
    variables = {"ansible_ssh_port": "22", "ansible_ssh_host": "localhost"}
    play_context = PlayContext()
    assert play_context.port == 22
    assert play_context.remote_addr == "localhost"
    new_play_context = play_context.set_task_and_variable_override(task, variables, templar)
    assert new_play_context.port == 22
    assert new_play_context.remote_addr == "localhost"

    variables = {"ansible_ssh_port": "25", "ansible_ssh_host": "remote_host"}
    play_context = new_play_context

# Generated at 2022-06-11 10:26:13.374204
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    from ansible.plugins.connection.ssh import Connection
    # fixtures
    fake_plugin_options = dict()
    fake_plugin_options['test1'] = dict(name='test1',default="test1")
    fake_plugin_options['test2'] = dict(name='test2',default="test2")
    play_context = PlayContext()
    # run tests
    with patch('ansible.config.definition.ConfigDefinition.safe_load_spec', return_value = fake_plugin_options):
        plugin = Connection()
        assert plugin.get_option("test1") == "test1"
        assert plugin.get_option("test2") == "test2"
        play_context.set_attributes_from_plugin(plugin)
        assert play_context.test1 == "test1"
        assert play_context.test2

# Generated at 2022-06-11 10:26:14.372162
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
    assert True

# Generated at 2022-06-11 10:27:22.211609
# Unit test for constructor of class PlayContext
def test_PlayContext():
    play = object()

    pc = PlayContext(play)

    # tests against FieldAttribute constructor
    attr = [['host_list', 'list'], ['force_handlers', 'bool']]
    for (key, value) in attr:
        if pc._attributes[key] is not value:
            raise AssertionError()

    assert pc.extra_vars == {}, pc.extra_vars
    assert pc.only_tags == set(), pc.only_tags
    assert pc.skip_tags == set(), pc.skip_tags

# Generated at 2022-06-11 10:27:31.995484
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    play_context = PlayContext()
    play_context.set_attributes_from_cli()

    import ansible.playbook.task_include as task_include
    task = task_include.TaskInclude()
    task.include = 'magic_include.yaml'
    task.tags = ['tag1', 'tag2']
    task.when = "ansible_os_family == 'Debian'"
    task.loop = '{{ some_variable }}'
    task.delegate_to = 'host_delegate_to.example.com'
    task.check_mode = True
    task.diff = True

    variables = dict(ansible_connection='local', ansible_user='guest', ansible_port='1234', ansible_host='localhost')

    from ansible.template import Templar
    templar = Templar

# Generated at 2022-06-11 10:27:41.318641
# Unit test for method set_task_and_variable_override of class PlayContext
def test_PlayContext_set_task_and_variable_override():
    mem_play = Play()
    mem_play._included_file = "./ansible/test/units/modules/utility/copy/copy.yml"
    mem_play.hosts = ["localhost"]
    mem_play.connection = "smart"
    mem_play.remote_user = "user"
    mem_play.roles.append(Role())
    mem_play.roles[-1]._role_path = "/home/user/ansible/test/test/test/"
    mem_play.roles[-1].name = "test"
    mem_play.roles[-1]._parent_dir = "/home/user/ansible/test/test"
    mem_play.roles[-1].tasks.append(Task())

# Generated at 2022-06-11 10:27:52.071346
# Unit test for method set_attributes_from_cli of class PlayContext
def test_PlayContext_set_attributes_from_cli():
  """
  Tests the behaviour of the PlayContext.set_attributes_from_cli method.
  """
  # Inputs
  # context.CLIARGS - dictionary
  context.CLIARGS = {}
  
  # Initialise a PlayContext object
  pc = PlayContext()

  # Call the PlayContext.set_attributes_from_cli method
  pc.set_attributes_from_cli()

  # Ensure that the expected attributes are set
  attrs = ("private_key_file", "verbosity")
  for attr in attrs:
    assert getattr(pc, attr) == getattr(C, f"DEFAULT_{attr.upper()}")

  # Ensure that the expected attributes are set to None
  attrs = ("start_at_task",)

# Generated at 2022-06-11 10:27:59.364693
# Unit test for method set_attributes_from_plugin of class PlayContext
def test_PlayContext_set_attributes_from_plugin():
    class TestPlugin(object):
        def __init__(self):
            self._load_name = 'test_plugin_name'
            return

    # Testing normal case: Test when all expected parameters are provided
    test_plugin = TestPlugin()
    test_plugin.get_option = lambda flag: 'test_attr'
    test_play_context = PlayContext()
    test_play_context.set_attributes_from_plugin(test_plugin)
    assert test_play_context.test_plugin_name == 'test_attr'
    return
