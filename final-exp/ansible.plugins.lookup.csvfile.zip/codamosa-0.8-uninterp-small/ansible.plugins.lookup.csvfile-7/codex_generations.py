

# Generated at 2022-06-25 10:22:30.008560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False


# Generated at 2022-06-25 10:22:33.252192
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    test_case_0()
    test_LookupModule_read_csv_0()
    test_LookupModule_read_csv_1()



# Generated at 2022-06-25 10:22:42.000906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l_m_0 = LookupModule()
    l_m_0.set_options(paramvals={})
    l_m_1 = LookupModule()
    l_m_1.set_options(paramvals={})
    l_m_1.set_options(variables={})
    l_m_1.set_options(direct={})
    l_m_2 = LookupModule()
    l_m_2.set_options(paramvals={})
    l_m_2.set_options(variables={})
    l_m_2.set_options(direct={})
    l_m_2.run(terms=['abc'], variables=None)
    l_m_2.run(terms=None, variables=None)
    l_m_3 = LookupModule()
    l_

# Generated at 2022-06-25 10:22:46.904939
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    assert isinstance(LookupModule._read_csv('a_var_0', 'a_var_1', 'a_var_2', 'a_var_3', 'a_var_4', 'a_var_5'), str)
    assert isinstance(LookupModule._read_csv('a_var_6', 'a_var_7', 'a_var_8', 'a_var_9', 'a_var_10', 'a_var_11'), str)


# Generated at 2022-06-25 10:22:57.234496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.values = {}
    lookup_module_0.variables = {}
    lookup_module_0.params = {}
    lookup_module_0.basedir = None
    lookup_module_1 = LookupModule()
    lookup_module_1.values = {}
    lookup_module_1.variables = {}
    lookup_module_1.params = {}
    lookup_module_1.basedir = None
    terms_1 = []
    terms_0 = [terms_1]
    variables_1 = {}
    variables_0 = [variables_1]
    paramvals_1 = {}
    paramvals_0 = [paramvals_1]
    kv_1 = {}
    kv_0 = [kv_1]
    name_0

# Generated at 2022-06-25 10:23:07.407924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'test_value'
    str_1 = 'test_value'
    int_0 = 0
    lookup_module_0 = LookupModule()
    int_1 = 1
    str_2 = 'test_value'
    dict_0 = dict()
    dict_0['file'] = str_0
    dict_0['delimiter'] = str_1
    dict_0['col'] = int_0
    dict_0['encoding'] = str_2
    dict_0['default'] = str_0
    dict_0['_ansible_no_log'] = False
    dict_0['_ansible_ignore_errors'] = False
    lookup_module_0.run((str_0,), dict_0)
    int_2 = 2
    dict_1 = dict()
    dict_

# Generated at 2022-06-25 10:23:11.917790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_0 = LookupModule()
    str_0 = 'UA\x0c?'
    c_s_v_recoder_0 = CSVRecoder(str_0)
    var_0 = c_s_v_recoder_0.__iter__()
    var_0 = lookup_0.run(var_0)
    print('result:' + str(var_0))

# Generated at 2022-06-25 10:23:15.738633
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_0 = 'UA\x0c?'
    c_s_v_recoder_0 = CSVRecoder(str_0)
    c_s_v_reader_0 = CSVReader(c_s_v_recoder_0.__iter__())
    var_0 = c_s_v_reader_0.__next__()


# Generated at 2022-06-25 10:23:21.214975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {}
    args['variables'] = {}
    args['key'] = {}
    args['key']['encoding'] = {}
    args['key']['delimiter'] = {}
    args['key']['encoding'] = 'utf-8'
    args['key']['delimiter'] = '\t'
    args['key']['file'] = 'ansible.csv'
    args['key']['default'] = 'None'
    args['key']['col'] = '1'
    args['terms'] = 'UA'
    args['variables'] = {}
    args['kwargs'] = {}
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(**args)
    assert ret_0 == ['\x0c?']

# Generated at 2022-06-25 10:23:31.485489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'G\xfe\xa0v\xc0\x15\x8d\x1b\xe4\x07\xe4\x8c\xd4\xea\xc4\x0b\xb8\xfd\x04Z\x7f'

# Generated at 2022-06-25 10:23:38.191130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # For method run of class LookupModule
    # This testcase is not applicable - Iterator next is not implemented.  To verify this code, please manually test this code.
    pass


# Generated at 2022-06-25 10:23:46.919087
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    import sys
    import io
    test_file_name = 'tests/integration/lookup_plugins/csvfile/test.csv'
    python_version = sys.version_info[0]
    if python_version == 2:
        f = open(test_file_name, 'rb')
    else:
        f = open(test_file_name, 'r', encoding='utf-8')

    delimiter = ','
    paramvals = {}
    paramvals['encoding'] = 'utf-8'
    paramvals['col'] = '2'
    paramvals['default'] = None
    paramvals['delimiter'] = delimiter
    paramvals['file'] = 'test.csv'
    test_key = 'Routers'
    key = test_key
    lookupfile = test_file_name
    lookup

# Generated at 2022-06-25 10:23:55.110621
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    term = '_raw_params'
    variables = 'key'
    delimiter = 'key'
    encoding = 'utf-8'
    dflt = 'default'
    col = 'col'
    filename = 'filename'
    name = 'name'
    value = 'value'
    index = 'index'
    kv = parse_kv(term)
    assert kv[index] == term
    obj_LookupModule = LookupModule()
    obj_LookupModule.read_csv(filename, key, delimiter, encoding, dflt, col)

# Generated at 2022-06-25 10:24:03.754910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for proper exceptions with empty file
    test_file = open("./_test_delete.csv", "w+b")
    test_file.close()

    test_terms = ['foo', 'bar']
    test_kv = {
        'file': './_test_delete.csv',
        'default': 'N/A',
        'delimiter': 'TAB',
        'col': '1',
    }

    test_obj = LookupModule()
    test_obj.set_options(var_options=None, direct=test_kv)

    try:
        test_obj.run(test_terms, variables=None)
    except AnsibleError:
        pass
    else:
        assert False, 'AnsibleError not raised'

    # Write test file

# Generated at 2022-06-25 10:24:13.519864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    parameters = {
      "paramvals": {
      "delimiter": "TAB",
      "encoding": "utf-8",
      "default": "default_value",
      "file": "ansible.csv",
      "col": "1"
      },
      "variables": {
      "lookup_file_search_path": [
      "/home/travis/build/ansible/ansible/test/units/lookup/files"
      ]
      },
      "kwargs": {},
      "terms": [
      "key"
      ]
      }

# Generated at 2022-06-25 10:24:19.279831
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module = LookupModule()
    # Positional argument(s)
    csv_file_0 = 'data_file'
    search_key_0 = 'test_key'
    delimiter_0 = 'test_delimiter'
    encoding_0 = 'test_encoding'
    default_0 = 'test_default'
    column_0 = 1
    lookup_module.read_csv(csv_file_0, search_key_0, delimiter_0, encoding_0, default_0, column_0)


# Generated at 2022-06-25 10:24:24.390069
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_0 = 'UA\x0c?'
    c_s_v_recoder_0 = CSVRecoder(str_0)
    c_s_v_reader_0 = CSVReader(c_s_v_recoder_0)
    var_0 = c_s_v_reader_0.__next__()
    print(var_0)


# Generated at 2022-06-25 10:24:33.672722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ansible_gather_facts_0 = {
        'gather_subset': 'all',
    }
    ansible_play_0 = {
        'playbook_dir': '.',
    }
    ansible_play_1 = {
        'playbook_dir': '.',
    }
    ansible_play_2 = {
        'playbook_dir': '.',
    }
    ansible_play_3 = {
        'playbook_dir': '.',
    }
    ansible_play_4 = {
        'playbook_dir': '.',
    }
    ansible_play_5 = {
        'playbook_dir': '.',
    }
    ansible_version_0 = '2.9.1'

# Generated at 2022-06-25 10:24:38.682746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    search_0 = ['key1']
    variables_0 = {'file': 'csv.txt'}
    paramvals_0 = lookup_module_0.get_options()
    paramvals_0['_raw_params'] = search_0[0]

    lookup_module_0.run(search_0, variables_0)

# Generated at 2022-06-25 10:24:48.614446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'bar',
        'foo'
    ]
    variables = None

    kwargs = dict(
        delimiter='TAB',
        encoding='utf-8',
        file='ansible.csv',
        col='1',
        default=None
    )

    # Read csv
    csv_reader_0 = CSVReader(None)
    # Get csv from reader
    csv_0 = csv_reader_0.__iter__()
    # Get next from csv
    csv_row_0 = csv_reader_0.__next__()

    # Perform lookup operation
    lu = LookupModule()
    ret = lu.run(terms, variables, **kwargs)

    assert c_s_v_recoder_0 in ret
    assert csv_reader_0

# Generated at 2022-06-25 10:24:55.029988
# Unit test for constructor of class CSVReader
def test_CSVReader():
    c_s_v_reader_0 = CSVReader(str)
    assert isinstance(c_s_v_reader_0, object) == True


# Generated at 2022-06-25 10:24:59.340952
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_1 = 'UA\x0c?'
    cSVReader_0 = CSVReader(str_1)
    var_0 = cSVReader_0.__next__()
    print(var_0)


if __name__ == '__main__':
    test_case_0()
    test_CSVReader___next__()

# Generated at 2022-06-25 10:25:01.711571
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    c_s_v_reader_0 = CSVReader(str_0)
    var_1 = c_s_v_reader_0.__next__()


# Generated at 2022-06-25 10:25:06.920428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule_0 = LookupModule()

    # line 365, col 1
    assert lookupModule_0.run(terms, variables=None) == ret

    # line 366, col 1
    assert lookupModule_0.run(terms, variables=None) == ret

    # line 366, col 1
    assert lookupModule_0.run(terms, variables=None) == ret

    # line 367, col 1
    assert lookupModule_0.run(terms, variables=None) == ret

    # line 368, col 1
    assert lookupModule_0.run(terms, variables=None) == ret

    # line 369, col 1
    assert lookupModule_0.run(terms, variables=None) == ret

    # line 370, col 1
    assert lookupModule_0.run(terms, variables=None) == ret

    # line 371, col

# Generated at 2022-06-25 10:25:10.813397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals_0 = dict()
    paramvals_0['file'] = 'file'
    paramvals_0['delimiter'] = 'delimiter'
    paramvals_0['default'] = 'default'
    paramvals_0['col'] = 'col'
    paramvals_0['encoding'] = 'encoding'
    LookupModule.run(paramvals_0)

# Generated at 2022-06-25 10:25:13.246189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #self = LookupModule()
    terms = ['HA', 'HB']
    variables = None
    kwargs = {'delimiter': "TAB", 'col': '1', 'default': '1', 'file': 'dgsdfgs'}
    #self.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:25:20.204540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # paramvals is a dict with the following keys:
    #     {'file', 'col', 'delimiter', 'default'}
    paramvals = dict()
    # variables is a dict with the following keys:
    #     {'ansible_play_hosts_all'}
    variables = dict()
    # kwargs is a dict with the following keys:
    #     {}
    kwargs = dict()

    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(paramvals, variables, **kwargs)
    terms_0 = list()

    lookup_module_0.run(terms_0, variables)

# Generated at 2022-06-25 10:25:22.330928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin.set_options({'1':'1', '2':'2', '3':'3'})


# Generated at 2022-06-25 10:25:31.040836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["The atomic number of Lithium is {{ lookup('csvfile', 'Li', file='elements.csv', delimiter=',') }}"]
    variables = ["The atomic number of Lithium is {{ lookup('csvfile', 'Li', file='elements.csv', delimiter=',') }}"]
    lookup._lag_per_term = 1
    lookup.keys_for_enocean_msg = 0
    lookup._ret = ["The atomic number of Lithium is 3"]
    lookup.run(terms,variables)
if __name__ == '__main__':
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 10:25:32.414574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == False, "Test not implemented"


# Generated at 2022-06-25 10:25:45.106426
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookupmodule = LookupModule()
    str_0 = 'UA\x0c?'
    csvreader_0 = CSVReader(str_0)
    var_0 = lookupmodule.read_csv(csvreader_0, '\xdf\x8b\x0f', '\x9a\xf3\x05')


# Generated at 2022-06-25 10:25:50.497452
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    with open('../test/test_data/test_csv.csv') as c_s_v_reader_0:
        c_s_v_reader_0 = c_s_v_reader_0.read()
        c_s_v_reader_1 = CSVReader(c_s_v_reader_0)
        var_1 = c_s_v_reader_1.__next__()

# Generated at 2022-06-25 10:25:56.656186
# Unit test for constructor of class CSVReader
def test_CSVReader():
    str_0 = 'ua\x0c?'
    c_s_v_reader_0 = CSVReader(str_0)
    c_s_v_reader_1 = CSVReader(str_0)
    c_s_v_reader_2 = CSVReader(str_0)
    c_s_v_reader_3 = CSVReader(str_0, doublequote=True)
    c_s_v_reader_4 = CSVReader(str_0, doublequote=True)
    c_s_v_reader_5 = CSVReader(str_0, doublequote=True)
    c_s_v_reader_6 = CSVReader(str_0, delimiter='\x0c', encoding='cp936')

# Generated at 2022-06-25 10:26:01.628221
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_0 = 'UA\x0c?'
    c_s_v_recoder_0 = CSVRecoder(str_0)
    c_s_v_reader_0 = CSVReader(c_s_v_recoder_0)
    var_0 = c_s_v_reader_0.__next__()


# Generated at 2022-06-25 10:26:11.848654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_0 = LookupModule()

    str_0 = 'UA\x0c?'
    c_s_v_recoder_0 = CSVRecoder(str_0)
    var_0 = c_s_v_recoder_0.__iter__()
    str_1 = '+\x00'
    dict_0 = dict()
    dict_0['delimiter'] = 'TAB'
    dict_0['default'] = 'default'
    dict_0['file'] = 'ansible.csv'
    dict_0['col'] = '1'
    dict_0['encoding'] = 'utf-8'
    dict_0['_raw_params'] = str_1
    var_1 = lookup_0.run([str_1], dict_0)


# Generated at 2022-06-25 10:26:20.924768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj_LookupModule_0 = LookupModule()
    set_options_0 = obj_LookupModule_0.set_options(var_options=None, direct=None)
    get_options_0 = obj_LookupModule_0.get_options()
    _deprecate_inline_kv_0 = obj_LookupModule_0._deprecate_inline_kv()

# Generated at 2022-06-25 10:26:25.090971
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    file_0 = open('file.csv', 'rb')
    c_s_v_reader_0 = CSVReader(file_0)
    var_0 = c_s_v_reader_0.__next__()


# Generated at 2022-06-25 10:26:32.998716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookupModule_0 = LookupModule()
   str_0 = 'test_ansible_modules.csv'
   dict_0 = dict()
   dict_0['encoding'] = 'utf-8'
   dict_0['col'] = '1'
   dict_0['file'] = 'test_ansible_modules.csv'
   dict_0['delimiter'] = 'TAB'
   dict_0['default'] = '1'
   list_0 = list()
   str_1 = 'copy'
   list_0.append(str_1)
   list_1 = lookupModule_0.run(list_0, dict_0)

# Generated at 2022-06-25 10:26:36.218141
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
  try:
    str_0 = 'UA\x0c?'
    c_s_v_reader_0 = CSVReader(str_0)
    var_0 = c_s_v_reader_0.__next__
    var_0()
  except Exception as var_1:
    print(var_1)



# Generated at 2022-06-25 10:26:46.765686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import csv
    file_0 = csv.reader(open('/home/karolis/Downloads/csv_for_test.csv', 'r'))
    t_0 = file_0.__iter__()
    t_1 = t_0.__next__()
    t_2 = t_1.__iter__()
    t_3 = t_2.__next__()
    file_1 = open('/home/karolis/Downloads/csv_for_test.csv', 'r')
    t_4 = file_1.__next__()
    t_5 = t_4.__iter__()
    t_6 = t_5.__next__()
    t_7 = LookupModule()

# Generated at 2022-06-25 10:26:57.604670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    assert var_0.run(None, None) == [], 'var_0.run(None, None) is wrong'


if __name__ == '__main__':

    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:27:04.032413
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_0 = 'UA\x0c?'
    c_s_v_recoder_0 = CSVRecoder(str_0)
    c_s_v_reader_0 = CSVReader(c_s_v_recoder_0)
    # Variables
    var_0 = c_s_v_reader_0.__next__()
    var_1 = c_s_v_recoder_0.__next__()


# Generated at 2022-06-25 10:27:14.071266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'test_0'
    kwargs_0 = {'var_options': str_0, 'direct': str_0}
    str_1 = 'test_1'
    list_0 = [str_1]
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
   

# Generated at 2022-06-25 10:27:17.297871
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    csv_file_0 = None
    var_1 = LookupModule()
    var_2 = var_1.read_csv(csv_file_0, 1, 10, 'ascii', 9, 8)

# Generated at 2022-06-25 10:27:28.468677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    csvfile_0 = LookupModule()
    csvfile_1 = LookupModule()
    csvfile_2 = LookupModule()
    csvfile_3 = LookupModule()
    csvfile_4 = LookupModule()
    csvfile_5 = LookupModule()
    csvfile_6 = LookupModule()
    csvfile_7 = LookupModule()
    csvfile_8 = LookupModule()
    csvfile_9 = LookupModule()
    csvfile_10 = LookupModule()
    csvfile_11 = LookupModule()
    csvfile_12 = LookupModule()
    csvfile_13 = LookupModule()
    csvfile_14 = LookupModule()
    csvfile_15 = LookupModule()

# Generated at 2022-06-25 10:27:31.859730
# Unit test for constructor of class CSVReader
def test_CSVReader():
    str_0 = 'UA\x0c?'
    c_s_v_recoder_0 = CSVRecoder(str_0)
    c_s_v_reader_0 = CSVReader(c_s_v_recoder_0)
    var_0 = c_s_v_reader_0.__next__()


# Generated at 2022-06-25 10:27:40.310353
# Unit test for method __next__ of class CSVReader

# Generated at 2022-06-25 10:27:43.024292
# Unit test for constructor of class CSVReader
def test_CSVReader():
    if PY2:
        str_0 = 'UA\x0c?'
        c_s_v_recoder_0 = CSVRecoder(str_0)
        var_0 = c_s_v_recoder_0.__iter__()
        c_s_v_reader_0 = CSVReader(var_0)

test_case_0()
test_CSVReader()

# Generated at 2022-06-25 10:27:49.691674
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_0 = 'UA\x0c?'
    str_1 = '\x0c'
    str_2 = 'UA\u0003?'
    csv_reader_0 = CSVReader(str_0, delimiter=(str_1))
    var_0 = csv_reader_0.__next__()
    assert var_0 == str_2


# Generated at 2022-06-25 10:27:57.124917
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    filename_0 = 'f.G.Pj)i.|]Q7\u0014/j\u0006\r-'

# Generated at 2022-06-25 10:28:17.946560
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # expected
    expected = ['']
    # Init
    lookup_module = LookupModule()
    terms = ['']
    variables = None
    kwargs = { }
    # run
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == expected


# Generated at 2022-06-25 10:28:28.473999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:28:30.127416
# Unit test for constructor of class CSVReader
def test_CSVReader():
    c_s_v_reader_0 = CSVReader('FBlFJ\x0cZny$=]0')


# Generated at 2022-06-25 10:28:36.922974
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    # test for a case when the file is not in the path
    # expected result is an exception being raised
    try:
       ret = LookupModule().read_csv('/tmp/foobar.csv', 'username', ',')
       assert False, "The filename was not found in the path provided"
    except Exception as e:
       assert True
    # test for a case when the file is in the path
    # expected result is the value of the field that matches the key
    ret = LookupModule().read_csv('test/unit/test_files/test.csv', 'first_name', ',')
    assert ret == 'John'
    # test for a case when the file is in the path
    # expected result is the value of the field that matches the key and column number

# Generated at 2022-06-25 10:28:46.380150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f_updater_0 = LookupModule()
    str_0 = 'GsU^O#H\x0ekeZ-`rQ:='
    str_1 = ','
    str_2 = 'uadYX&\x01\x0fCy-7V$)'
    list_0 = ['c<Nj#1\n', 'Xt]2-o!\x0fz/', 'P8mwH|@yj+4m2b', '9*Jv1b]5S5S5']

# Generated at 2022-06-25 10:28:50.244715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule_0 = LookupModule()
    terms_0 = ''
    variables_0 = {}
    
    # AssertionError is thrown if an error is encountered
    try:
        lookupModule_0.run(terms_0, variables_0)
    except AssertionError as e:
        pass


# Generated at 2022-06-25 10:28:59.827674
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    # Subject to change
    csv_file_0 = CSVReader(b'\x01\n\x00\x00\x00\x00\n\x00\x00\x00\x00\n')
    csv_file_1 = CSVReader(b'\x01\n\x00\x00\x00\x00\n\x00\x00\x00\x00\n')
    csv_file_2 = CSVReader(b'\x01\n\x00\x00\x00\x00\n\x00\x00\x00\x00\n')
    csv_file_3 = CSVReader(b'\x01\n\x00\x00\x00\x00\n\x00\x00\x00\x00\n')
   

# Generated at 2022-06-25 10:29:05.906904
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    options = {
        "file": "ansible.csv",
        "default": None,
        "delimiter": "TAB",
        "col": "1"
    }

    # Test with the following options:
    # file: ansible.csv
    # default: None
    # delimiter: TAB
    # col: 1
    # args:
    # terms:
    terms = [ "Hello" ]
    result = lookup.run(terms, options)

    assert result == [ "World" ]


# Generated at 2022-06-25 10:29:12.668666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals = {}
    paramvals['delimiter'] = 'TAB'
    paramvals['file'] = 'ansible.csv'
    paramvals['col'] = 1
    paramvals['default'] = None
    paramvals['encoding'] = 'utc-8'
    lookup = LookupModule()
    lookup.get_options = mock.MagicMock(return_value = paramvals)
    assert lookup.run(terms = ['vmbl']) == None
    assert lookup.run(terms = ['vm']) == 'val1'


# Generated at 2022-06-25 10:29:20.306823
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookupModule_0 = LookupModule()

    # subtest: test_0:

    # variables
    terms_0 = [0]
    variables = None
    kwargs = {}
    lookupModule_0.set_options(var_options=variables, direct=kwargs)

    # parameters override per term using k/v
    kv_0 = {}
    for name, value in kv_0.items():
        if name == '_raw_params':
            continue
        if name not in paramvals:
            raise AnsibleAssertionError('%s is not a valid option' % name)

        self._deprecate_inline_kv()
        paramvals[name] = value

    # default is just placeholder for real tab

# Generated at 2022-06-25 10:29:46.398914
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_0 = '\n8Hv\x1e\x7f\x0b\x7f\x0b\r\r\r\r\r'
    c_s_v_reader_0 = CSVReader(str_0)
    str_1 = '\t\t\t|\x0f\x1a\x1a\x1a\x1a\n\t\t\t\t'
    str_1 = str_1.encode('utf-8')
    str_2 = '\r\r\r\r\r\r\r\r\r\r\r'
    str_3 = '\n\n\n\n\n\n\n'
    str_4 = c_s_v_reader_0.__next__()


# Unit

# Generated at 2022-06-25 10:29:51.785608
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    path = 'ansible_module_csvfile.py'

    # Create mock object of LookupBase class
    lookup_base_0 = LookupBase()

    # Create mock object of CSVReader class
    c_s_v_reader_0 = CSVReader(path)

    # Mock method __init__ of CSVReader class
    def __init__(mocker, filename, dialect=csv.excel, encoding='utf-8', **kwds):
        # Create mock object of LookupBase class
        lookup_base_0 = LookupBase()

    # Mock method __init__ of CSVReader class
    def __init__(mocker, filename, dialect=csv.excel, encoding='utf-8', **kwds):

        return c_s_v_reader_0

    # Mock method __init__ of CSVReader class

# Generated at 2022-06-25 10:29:53.486705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
 
    lookup_module = LookupModule()
    lookup_module.run()


# Generated at 2022-06-25 10:29:56.502247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0
    lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:29:58.672895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["test"]) == []

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:30:07.679442
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    assert lookup_module_0.run([]) == []
    # test for option: delimiter
    lookup_module_0.set_options()
    assert lookup_module_0.run([]) == []
    # test for option: default
    lookup_module_0.set_options()
    assert lookup_module_0.run([]) == []
    # test for option: encoding
    lookup_module_0.set_options()
    assert lookup_module_0.run([]) == []
    # test for option: col
    lookup_module_0.set_options()
    assert lookup_module_0.run([]) == []
    # test for option: file
    lookup_module_0.set_options()
    assert lookup_

# Generated at 2022-06-25 10:30:13.984118
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    csv_reader_0 = CSVReader("FBlFJ\x0cZny$=]0")
    csv_reader_1 = CSVReader("FBlFJ\x0cZny$=]0")
    c_s_v_reader_0 = CSVRecoder("FBlFJ\x0cZny$=]0")
    c_s_v_reader_1 = CSVRecoder("FBlFJ\x0cZny$=]0")
    c_s_v_reader_2 = CSVRecoder("FBlFJ\x0cZny$=]0", 'UTF-8')
    c_s_v_reader_3 = CSVRecoder("FBlFJ\x0cZny$=]0", 'UTF-8')

# Generated at 2022-06-25 10:30:15.188460
# Unit test for constructor of class CSVReader
def test_CSVReader():
    test_case_0()

# Generated at 2022-06-25 10:30:20.603585
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    # match is true only if the search key is found in the first column of the file
    # and the column number specified by 'col' is returned
    file = "test/test.csv"
    assert(LookupModule().read_csv(file, "3", ",", "1") == "4")

if __name__ == '__main__':
    print('Testing')
    #test_case_0()
    test_LookupModule_read_csv()
    print('Test OK')

# Generated at 2022-06-25 10:30:30.005639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    d_0 = dict()
    d_1 = dict()
    d_0['a'] = 'a'
    d_0['b'] = 'b'
    d_1['a'] = 'a'
    d_1['b'] = 'b'
    d_0['_raw_params'] = 'name'
    d_1['_raw_params'] = 'name'
    d_1['default'] = 'a'
    l_0 = [d_0, d_1]
    l_1 = list()
    l_1.append('test/test_lookup_plugins/data/test_file.csv')
    l_1.append('test/test_lookup_plugins/data/test_file.csv')

# Generated at 2022-06-25 10:30:59.517634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case of a successful read
    str_0 = 'T\x0f\x12\x14\x11H\x1aXFBlFJ\x0cZny$=]0'
    str_1 = '\x12\x17\x0b\x1b\x01\x1f,\x14\x0b\x13\x1d\x1b\x0c\x1a\x03\x0e\x0e\x1f,\x1e\x16\x15\x00\x0b\x0f\x03\x1d\x09'
    str_2 = '\x1aXFBlFJ\x0cZny$=]0'

# Generated at 2022-06-25 10:31:00.411230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# System test for method run of class LookupModule

# Generated at 2022-06-25 10:31:08.672916
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_0 = 'FBlFJ\x0cZny$=]0'
    c_s_v_reader_0 = CSVReader(str_0)
    try:
        assert c_s_v_reader_0.__next__() is None
    except StopIteration:
        pass
    try:
        assert c_s_v_reader_0.__next__() is None
    except StopIteration:
        pass
    try:
        assert c_s_v_reader_0.__next__() is None
    except StopIteration:
        pass
    try:
        assert c_s_v_reader_0.__next__() is None
    except StopIteration:
        pass

# Generated at 2022-06-25 10:31:18.007814
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module_0 = LookupModule()
    str_0 = 'FBlFJ\x0cZny$=]0'
    str_1 = 'P\\\x0c\x1aB/2\x1a]\x18G\x08>b&\x19N|\x1b'
    str_2 = 'g'
    str_3 = '\x0bYY%&|\x18d\x1a\x1bO\x0c]\x0eI[\x15G'
    str_4 = '\x0bYY%&|\x18d\x1a\x1bO\x0c]\x0eI[\x15G'
    str_5 = 'g'
    str_6 = 'g'

# Generated at 2022-06-25 10:31:27.283700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    c_s_v_reader_0 = CSVReader('\n', encoding='utf-8') # var_args -> kwargs
    # Case 1 - ValueError
    test_run_0 = None
    try:
        lookup_module_0.run(c_s_v_reader_0)
    except ValueError as e:
        test_run_0 = e
    # Case 2 - ValueError
    test_run_1 = None
    try:
        lookup_module_0.run(c_s_v_reader_0)
    except ValueError as e:
        test_run_1 = e
    # Case 3 - ValueError
    test_run_2 = None

# Generated at 2022-06-25 10:31:34.052841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['_raw_params']
    variables = None
    kwargs = {'col': 1, 'delimiter': '\x0c', 'file': 'FBlFJ\x0cZny$=]0',
              'encoding': 'utf-8', 'default': c_s_v_reader_0}
    lookup = LookupModule()
    assert lookup.run(terms, variables, kwargs) == [c_s_v_reader_0]

# Generated at 2022-06-25 10:31:40.281488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_base_0 = LookupBase()
    lookup_module_0 = LookupModule(lookup_base_0)
    lookup_module_0.set_options()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()


# Generated at 2022-06-25 10:31:44.089481
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    filename = 'test_filename'
    key = 'test_key'
    delimiter = 'test_delimiter'
    encoding = 'test_encoding'
    dflt = 'test_dflt'
    col = 1
    obj = LookupModule()
    result = obj.read_csv(filename, key, delimiter, encoding, dflt, col)

# Generated at 2022-06-25 10:31:54.492279
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    class FileMock():
        def iter(self, value = None):
            yield 'test_value_0'
        def close(self):
            pass
    class CSVReaderMock():
        def __init__(self, value = None):
            pass
        def __iter__(self):
            yield 'test_value_0'
        def __next__(self):
            yield 'test_value_0'

    filename = 'test_value_0'
    key = 'test_value_0'
    delimiter = 'test_value_0'
    encoding = 'test_value_0'
    dflt = 'test_value_0'
    col = 1

    return_value = LookupModule.read_csv(filename, key, delimiter, encoding, dflt, col)

# Generated at 2022-06-25 10:32:01.571265
# Unit test for method read_csv of class LookupModule