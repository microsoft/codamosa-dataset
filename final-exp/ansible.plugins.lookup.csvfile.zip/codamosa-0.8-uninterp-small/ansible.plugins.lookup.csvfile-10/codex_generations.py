

# Generated at 2022-06-25 10:22:40.071371
# Unit test for method read_csv of class LookupModule

# Generated at 2022-06-25 10:22:42.751778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_14 = LookupModule()

    # Test case for method load of class CSVRecoder
    def test_CSVRecoder_load():
        csv_recoder_0 = CSVRecoder(f)


# Generated at 2022-06-25 10:22:46.314093
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    bytes_0 = b'\t\x00\x00\x00\x00'
    c_s_v_reader_0 = CSVReader(bytes_0)
    assert c_s_v_reader_0.__next__() == ['\x00', '\x00', '\x00', '\x00']

# Generated at 2022-06-25 10:22:56.500509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Ansible AssertionError raises when terms contain key except _raw_params
    terms_empty_dict = [dict()]
    with pytest.raises(AnsibleError) as ansible_error:
        LookupModule().run(terms_empty_dict)
    assert 'Search key is required but was not found' in str(ansible_error)

    # AnsibleAssertionError raises when kv[name] not in options
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct={})

    with mock.patch('ansible.plugins.lookup.csvfile.LookupBase.get_options', return_value={'foo': 'bar'}):
        with pytest.raises(AnsibleError) as ansible_error:
            lookup_

# Generated at 2022-06-25 10:22:58.763905
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    c_s_v_reader_0 = CSVReader(b'T\x9a\xd7\x83\xa4\x95\xf3')
    c_s_v_reader_0.__next__()
    c_s_v_reader_0.__next__()
    c_s_v_reader_0.__next__()


# Generated at 2022-06-25 10:23:09.623539
# Unit test for method __next__ of class CSVReader

# Generated at 2022-06-25 10:23:11.877333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m_p_cvs_lookupmodule = LookupModule()
    m_p_cvs_lookupmodule.run(terms=None)


# Generated at 2022-06-25 10:23:14.553299
# Unit test for constructor of class CSVReader
def test_CSVReader():
    bytes_0 = b'K\xc6]'
    delimiter_0 = "TAB"

    c_s_v_reader_0 = CSVReader(bytes_0,delimiter=to_native(delimiter_0))


# Generated at 2022-06-25 10:23:20.663998
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    csv_input = b'test1\ttest2\ttest3'
    delimiter = b'\t'
    fh = open(to_bytes('/tmp/test.csv'), 'wb')
    fh.write(csv_input)
    fh.close()

    lookup = LookupModule()
    assert 'test2' == lookup.read_csv('/tmp/test.csv', 'test1', delimiter)

# Generated at 2022-06-25 10:23:21.310253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 10:23:29.003586
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    csv_reader_0 = CSVReader(b'\xc6', csv.excel, 'utf-8')
    str_0 = csv_reader_0.__next__()
    assert(str_0 == '\xc6')


# Generated at 2022-06-25 10:23:30.677390
# Unit test for constructor of class CSVReader
def test_CSVReader():
    assert type(CSVReader('s', encoding='s')) == CSVReader


# Generated at 2022-06-25 10:23:31.934676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing method run...')

    for i in range(0,10):
        pass

# Generated at 2022-06-25 10:23:40.317910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupmodule_run_0 = LookupModule()
    lookupmodule_run_1 = LookupModule()
    lookupmodule_run_2 = LookupModule()
    lookupmodule_run_3 = LookupModule()
    lookupmodule_run_4 = LookupModule()
    lookupmodule_run_5 = LookupModule()
    lookupmodule_run_6 = LookupModule()
    lookupmodule_run_7 = LookupModule()
    lookupmodule_run_8 = LookupModule()
    lookupmodule_run_9 = LookupModule()
    lookupmodule_run_10 = LookupModule()
    lookupmodule_run_11 = LookupModule()
    lookupmodule_run_12 = LookupModule()
    lookupmodule_run_13 = LookupModule()
    lookupmodule_run_14 = LookupModule()
    lookupmodule_

# Generated at 2022-06-25 10:23:43.515563
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    bytes_0 = b'\xe5'
    c_s_v_reader_0 = CSVReader(bytes_0)
    str_0 = c_s_v_reader_0.__next__()
    assert str_0 == 'å'


# Generated at 2022-06-25 10:23:46.624772
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    bytes_0 = b'K\xc6]'
    c_s_v_recoder_0 = CSVRecoder(bytes_0)
    assert c_s_v_recoder_0.__next__() == b'K\xc3\x86]'


# Generated at 2022-06-25 10:23:49.774480
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    with open(__file__, 'rb') as f:
        c_s_v_reader_0 = CSVReader(f)
        s_0 = next(c_s_v_reader_0)


# Generated at 2022-06-25 10:24:00.365520
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    args = {}
    args['filename'] = 'filename_here'
    args['key'] = 'key_here'
    args['delimiter'] = 'delimiter_here'
    args['encoding'] = 'encoding_here'
    args['dflt'] = 'dflt_here'
    args['col'] = 'col_here'

    # c_0 = csv.reader(args['f'])
    # args['reader'] = c_0
    for k, v in args.items():
        if v is None:
            args[k] = k
    l_c_0 = LookupModule()
    ret = l_c_0.read_csv(**args)
    assert ret
    # assert ret == 'some return value'


# Generated at 2022-06-25 10:24:10.598044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule_0 = LookupModule()
    lookupModule_1 = LookupModule()
    lookupModule_2 = LookupModule()
    lookupModule_3 = LookupModule()
    lookupModule_4 = LookupModule()
    lookupModule_5 = LookupModule()
    lookupModule_6 = LookupModule()
    lookupModule_7 = LookupModule()
    lookupModule_8 = LookupModule()
    lookupModule_9 = LookupModule()
    lookupModule_10 = LookupModule()
    lookupModule_11 = LookupModule()
    lookupModule_12 = LookupModule()
    lookupModule_13 = LookupModule()
    lookupModule_14 = LookupModule()
    lookupModule_15 = LookupModule()
    lookupModule_17 = LookupModule()
    lookupModule_18 = LookupModule()
   

# Generated at 2022-06-25 10:24:14.060114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize object
    lookup_module_0 = LookupModule()

    # Verify first index of "key_0" equals "value_0"
    ret_0 = lookup_module_0.run(["key_0=value_0"])
    assert ret_0[0] == "value_0"

# Generated at 2022-06-25 10:24:24.674678
# Unit test for constructor of class CSVReader
def test_CSVReader():
    c_s_v_reader_0 = CSVReader(b'5', b'5', b'5')
    c_s_v_reader_0.__next__()
    c_s_v_reader_0.next()
    assert c_s_v_reader_0.__iter__() is c_s_v_reader_0

if __name__ == '__main__':
    test_case_0()
    test_CSVReader()

# Generated at 2022-06-25 10:24:33.834794
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:24:38.868848
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    with open('../files/test1.csv', 'r') as file_0:
        c_s_v_reader_0 = CSVReader(file_0, encoding='utf-8')
        iteration_0 = next(c_s_v_reader_0)
        __next___0 = c_s_v_reader_0.__next__()


# Generated at 2022-06-25 10:24:41.323237
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    reader = CSVReader(b'foo')
    row = reader.__next__()
    assert row == ['foo']


# Generated at 2022-06-25 10:24:50.611355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    fake_self_0 = lookup_module_0

# Generated at 2022-06-25 10:24:55.777675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with most basic case
    terms = "dummy"
    variables = "dummy"
    kwargs = "dummy"
    LookupModule().run(terms, variables, **kwargs)
    # Test with a more complex case
    terms = "dummy"
    variables = "dummy"
    kwargs = "dummy"
    LookupModule().run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:25:04.947090
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():

    # read in the test file
    f = open(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test.csv'), 'rb')

    # strip all nul bytes
    f.seek(0)
    test_data = f.read()
    test_data = test_data.replace(b'\x00', b'')
    f = BytesIO(test_data)

    creader = CSVReader(f, delimiter=';')

    assert creader.next() == [u'name', u'value']
    assert creader.next() == [u'x', u'y']
    assert creader.next() == [u'1', u'2']



# Generated at 2022-06-25 10:25:06.120066
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookupmodule_0 = LookupModule()


# Generated at 2022-06-25 10:25:13.493632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'8W0F\xcd\x92\x1f\xa3\x9f\xdc\xcf\xf7\xfd\xa1\x0f\x0e\x11O\x8d\xad"\x03\x7f\xcd\xb9\xef'

# Generated at 2022-06-25 10:25:19.800335
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookupmodule_0 = LookupModule()
    # Define arguments for method read_csv of class LookupModule.
    filename = 'ansible.csv'
    key = 'X'
    delimiter = ','
    # Invoke method read_csv of class LookupModule with arguments of above.
    ret_val = lookupmodule_0.read_csv(filename, key, delimiter)
    print("Returned value of method read_csv: " + str(ret_val))

test_case_0()
test_LookupModule_read_csv()

# Generated at 2022-06-25 10:25:35.407853
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of LookupModule
    lookup_module_0 = LookupModule()

    # Create an instance of a class for lookup results
    lookup_result_0 = dict()

    # Create an instance of a class for variable options
    variable_options_0 = dict()

    # Create an instance of a class for variables
    variables_0 = dict()

    # Create an instance of a class for kwargs
    kwargs_0 = dict()

    # Create an instance of a class for terms
    terms_1 = ['K\xc6]', "b'G\xf6del'"]

    # The path of lookupfile
    lookup_path_0 = '/etc/ansible/files'
    # The name of lookupfile
    lookup_file_0 = 'k\xc6]_g\xf6del.csv'
    #

# Generated at 2022-06-25 10:25:39.805333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals = {}
    paramvals['file'] = "file.txt"
    lookupmodule_0 = LookupModule()
    lookupmodule_0.set_options(var_options=None, direct=paramvals)
    lookupmodule_0._deprecate_inline_kv()
    lookupmodule_0.run(terms=[], variables=None, **paramvals)

# Generated at 2022-06-25 10:25:42.132190
# Unit test for constructor of class CSVReader
def test_CSVReader():
    bytes_0 = b'K\xc6]'
    c_s_v_recoder_0 = CSVRecoder(bytes_0)
    CSVReader(c_s_v_recoder_0)

# Generated at 2022-06-25 10:25:44.222457
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    bytes_0 = b'K\xc6]'
    c_s_v_recoder_0 = CSVRecoder(bytes_0)


# Generated at 2022-06-25 10:25:53.154846
# Unit test for constructor of class CSVReader

# Generated at 2022-06-25 10:25:55.358886
# Unit test for constructor of class CSVReader
def test_CSVReader():
    f = open(bytes(1), 'rb')
    c_s_v_reader_0 = CSVReader(f, delimiter="\'", encoding='utf-8')


# Generated at 2022-06-25 10:25:58.102982
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    if PY2:
        c_s_v_recoder_0 = CSVRecoder('f')
        c_s_v_reader_0 = CSVReader(c_s_v_recoder_0)
        assert c_s_v_reader_0.__next__() == 'K\xc3\x86]'
    else:
        assert True

# Generated at 2022-06-25 10:26:08.272352
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Variables set by the user
    variable_0 = '\t'
    variable_1 = '\t'
    variable_2 = '\t'
    variable_3 = '\t'
    variable_4 = '\t'
    variable_5 = '\t'

    # Variables set by the program
    variable_6 = '\t'
    variable_7 = '\t'

    # Variables set by the program, but the user can override them
    variable_8 = '\t'
    variable_9 = '\t'

    # Variables set by the program only, the user cannot override them
    variable_10 = '\t'

    # Setup
    lookupModule_0 = LookupModule()

# Generated at 2022-06-25 10:26:18.579851
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    bytes_0 = b'\xd1\xe0\xe4\xe4\xf6'
    bytes_1 = b'\xd1\xe0\xe4\xe4\xf6'
    bytes_2 = b'\xd1\xe0\xe4\xe4\xf6'
    bytes_3 = b'\xd1\xe0\xe4\xe4\xf6'
    bytes_4 = b'\xd1\xe0\xe4\xe4\xf6'
    file_name_0 = to_bytes('./test_csvlookup.csv')
    file_0 = open(file_name_0, 'rb')
    file_1 = open(file_name_0, 'rb')
    file_2 = open(file_name_0, 'rb')
    file_3 = open

# Generated at 2022-06-25 10:26:20.062358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l_m_0 = LookupModule()
    l_m_0.run(terms=[])


# Generated at 2022-06-25 10:26:34.265198
# Unit test for method read_csv of class LookupModule

# Generated at 2022-06-25 10:26:45.039030
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module_0 = LookupModule()
    csv_reader_0 = CSVReader()
    csv_reader_1 = CSVReader(csv_reader_0)
    c_s_v_reader_0 = CSVReader(csv_reader_1)
    dict_0 = dict()
    dict_0['file'] = 'ansible.csv'
    dict_0['delimiter'] = ','
    dict_0['encoding'] = 'utf-8'
    dict_0['default'] = 'TAB'
    dict_0['col'] = '1'
    dict_0['_raw_params'] = 'Li'
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_

# Generated at 2022-06-25 10:26:49.643460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "g\t\x96\xce\xfd\x8c\xc4\x9e\xee\x8c\xeb\x97\xe2"
    variables = ("O\xbb\xc2\xba\xb6\xbf")
    try:
        lookup_module_0.run(terms_0, variables)
    except AssertionError as e:
        print(str(e))


# Generated at 2022-06-25 10:26:53.944681
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    from ansible.plugins.lookup.csvfile import LookupModule
    lookup_module_0 = LookupModule()

    # No exception should be raised by this call.
    assert lookup_module_0.read_csv(None, None, None)

# Generated at 2022-06-25 10:27:03.812825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input params
    p_terms = [test_case_0()]

    # Output params
    p_ret = None
    m_csv_reader_0 = CSVReader(test_case_0())
    m_csv_reader_1 = CSVReader(test_case_0())

    # Set up mock
    lookupbase_0 = LookupBase()
    lookupbase_0.set_options = Mock(return_value=None)
    lookupbase_0.get_options = Mock(return_value=None)
    lookupbase_0.find_file_in_search_path = Mock(return_value=None)
    lookupbase_0.read_csv = Mock(return_value=None)

    # Perform the test
    ret = lookupbase_0.run(p_terms)

    # Check the results

# Generated at 2022-06-25 10:27:13.878238
# Unit test for method __next__ of class CSVReader

# Generated at 2022-06-25 10:27:19.582655
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    delimiter = "/"
    c_s_v_reader_0 = CSVReader(delimiter)
    filename = '<^BHf1'
    key = 'k'
    dflt = 'z.x'
    col = 1
    lookup_module_0 = LookupModule()
    lookup_module_0.read_csv(filename, key, delimiter, dflt, col)


# Generated at 2022-06-25 10:27:23.933807
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    bytes_0 = b'{'
    c_s_v_reader_0 = CSVReader(bytes_0, )
    result = c_s_v_reader_0.__next__()
# unit test for method read_csv of class LookupModule

# Generated at 2022-06-25 10:27:32.738436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    csvfile_0 = LookupModule()
    csvfile_0.find_file_in_search_path = lambda variables, search_path, path: path
    paramvals = {'col': '1', 'default': None, 'delimiter': 'TAB', 'file': 'ansible.csv', 'encoding': 'utf-8'}
    csvfile_0.get_options = lambda: paramvals
    csvfile_0.set_options = lambda var_options, direct: None
    terms = ['term 0'];
    assert csvfile_0.run(terms) == []
    paramvals['default'] = ['value 2', 'value 2']
    assert csvfile_0.run(terms) == ['value 2', 'value 2']
    paramvals['delimiter'] = 'TAB'

# Generated at 2022-06-25 10:27:36.672276
# Unit test for constructor of class CSVReader
def test_CSVReader():
    import io
    s = "a b c"
    f = io.StringIO(s)
    c_s_v_reader_0 = CSVReader(f)
    assert(c_s_v_reader_0.reader != None)
    assert(c_s_v_reader_0.reader.dialect == 'excel')


# Generated at 2022-06-25 10:27:53.047160
# Unit test for method read_csv of class LookupModule

# Generated at 2022-06-25 10:27:54.660793
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    c_s_v_reader_0 = CSVReader('')


# Generated at 2022-06-25 10:28:05.066090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test variables
    # Test cases
    # run() without params should fail
    with pytest.raises(TypeError):
        lookup_module_0.run()
    # Should fail with correct params
    with pytest.raises(AnsibleError):
        lookup_module_0.run(terms="")
    # Should fail with correct params
    with pytest.raises(AnsibleError):
        lookup_module_0.run(terms=[""])
    # Should fail with correct params
    with pytest.raises(AnsibleError):
        lookup_module_0.run(terms=[])
    # Should fail with correct params
    with pytest.raises(AnsibleError):
        lookup_module_0.run(terms=[""])
    #

# Generated at 2022-06-25 10:28:15.584008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ""
    variables = get_variables()
    kwargs = get_kwargs()

    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, variables, **kwargs)

    assert result == list()

    # Test with valid values.
    terms = "/jqg/f8G,iO/pp5,q44h\tSHg,E\tQHX\n-h71,RzVW\tK\xc6],\tT,TTA\n,\t\n"
    variables = get_variables()
    kwargs = get_kwargs()

    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:28:18.388423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['first']) == ['1']
    assert lookup_module_0.run(terms=['second']) == ['2']
    assert lookup_module_0.run(terms=['third']) == ['3']


# Generated at 2022-06-25 10:28:22.141375
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    def test_0():
        c_s_v_reader_0 = CSVReader(csv.reader)
        assert c_s_v_reader_0.__next__() == None, 'CSVReader.__next__ returned None, expected a value'

    test_0()


# Generated at 2022-06-25 10:28:26.162798
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookupmodule_0 = LookupModule()
    lookupmodule_0.read_csv(bytes_0, bytes_0, to_native(delimiter))

# Generated at 2022-06-25 10:28:33.377162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create lookup module instance
    lookup_module_0 = LookupModule()
    # Pass a proper value as paramater
    assert lookup_module_0.run(terms=['_raw_params=test_value'], variables=None, **{'file': 'test_value', 'delimiter': '\\t'}) is None
    # Pass a proper value as paramater
    assert lookup_module_0.run(terms=['_raw_params=test_value'], variables=None, **{'file': 'test_value', 'delimiter': 'TAB'}) is None
    # Pass a proper value as paramater
    assert lookup_module_0.run(terms=['_raw_params=test_value'], variables=None, **{'file': 'test_value'}) is None


# Generated at 2022-06-25 10:28:38.039123
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookupmodule_0 = LookupModule()
    str_filename = "test_filename"
    str_key = "test_key"
    str_delimiter = "TAB"
    str_encoding = "utf-8"
    str_dflt = "test_default"
    str_col = "1"
    lookupmodule_0.read_csv(str_filename, str_key, str_delimiter, str_encoding, str_dflt, str_col)


# Generated at 2022-06-25 10:28:38.504097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:28:46.361257
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    file_0 = 'asd'
    key_0 = 'asd'
    delimiter_0 = 'asd'
    l_m_0 = LookupModule()
    col_0 = 1
    encoding_0 = 'asd'
    dflt_0 = 'asd'
    l_m_0.read_csv(file_0, key_0, delimiter_0, encoding_0, dflt_0, col_0)


# Generated at 2022-06-25 10:28:55.086382
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():

    # this is a hack for testing ... it is not called by Ansible
    module = LookupModule()

    # TEST: test on columns not existing
    csvline = module.read_csv(filename=None, key='Li', delimiter=',', encoding='utf-8', dflt=None, col=2)
    assert csvline == None

    # TEST: test on columns not existing
    csvline = module.read_csv(filename=None, key='Li', delimiter=',', encoding='utf-8', dflt=None, col=9999999)
    assert csvline == None

    # TEST: test on columns not existing
    csvline = module.read_csv(filename=None, key='Li', delimiter=',', encoding='utf-8', dflt="default", col=9999999)

# Generated at 2022-06-25 10:28:57.710618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('test_string')

# Generated at 2022-06-25 10:29:00.085420
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    # Test with an instance of CSVReader using mock.patch('csvfile.csv').
    csv_reader_0 = CSVReader(None)
    result = csv_reader_0.__next__()
    

# Generated at 2022-06-25 10:29:07.811179
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    test_buffer = 'word\n'
    test_encoding = 'utf-8'

    # Test with a valid binary file stream
    with open(test_buffer, 'b') as f:
        c_s_v_reader_0 = CSVReader(f, encoding=test_encoding)
        c_s_v_reader_0.__next__()

    # Test with byte string as file input
    c_s_v_reader_1 = CSVReader(test_buffer, encoding=test_encoding)
    c_s_v_reader_1.__next__()

    # Replace undefined var 'f' with defined var 'f'
    f = open(test_buffer, 'r')
    c_s_v_reader_2 = CSVReader(f, encoding=test_encoding)
    c_s_v_

# Generated at 2022-06-25 10:29:13.677180
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Case 0 - test case where CSVReader is called with an encoding that is not default utf-8
    csv_reader_0 = CSVReader(test_case_0(),encoding='utf-8')
    assert isinstance(csv_reader_0,CSVReader)

    # Case 1 - test case where CSVReader is called with an encoding that is default utf-8
    csv_reader_1 = CSVReader(test_case_0())
    assert isinstance(csv_reader_1,CSVReader)

# Generated at 2022-06-25 10:29:20.990058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    bool_0 = False
    list_0 = []
    list_1 = []
    str_7 = ''
    str_8 = ''
    str_9 = ''
    str_10 = ''
    str_11 = ''
    str_12 = ''
    str_13 = ''
    list_2 = []
    # str -> list
    def transform(arg):
        return list(arg)

    # list -> None; (list, function) -> list
    def reduce(arg0, arg1):
        return arg1(arg0)

    # str -> Object; (

# Generated at 2022-06-25 10:29:24.799388
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.read_csv("string_0", "string_0", "string_0") == None
    assert lookup_module_0.read_csv("string_1", "string_0", "string_0") == None
    assert lookup_module_0.read_csv("string_0", "string_1", "string_0") == None
    assert lookup_module_0.read_csv("string_0", "string_0", "string_1") == None


# Generated at 2022-06-25 10:29:28.959577
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    c_s_v_reader_0 = CSVReader(b'\xc6\x89\xa0\xfa\x0b\x8a\xfe\xa5\x00')
    str_0 = c_s_v_reader_0.__next__()
    assert str_0 == '\xc6\x89\xa0\xfa\x0b\x8a\xfe\xa5\x00'


# Generated at 2022-06-25 10:29:33.543727
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    file_name = "file_name"
    search = "search"
    tab_0 = "\t"
    dflt_0 = None
    col_0 = "1"
    lookup_module_0 = LookupModule()
    lookup_module_0.read_csv(file_name, search, tab_0, "utf-8", dflt_0, col_0)


# Generated at 2022-06-25 10:29:46.766694
# Unit test for constructor of class CSVReader
def test_CSVReader():
    f_0 = open('test.csv', 'rb')
    c_s_v_reader_0 = CSVReader(f_0)
    c_s_v_reader_0.__del__()
    f_0.close()

if __name__ == '__main__':
    test_case_0()
    test_CSVReader()

# Generated at 2022-06-25 10:29:51.388282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_mock_0 = mock.mock_open(read_data='hi')
    with mock.patch('ansible.plugins.lookup.csvfile.open', file_mock_0):
        with mock.patch('os.path.exists', return_value=True):
            lookup_module_0 = LookupModule()
            terms_0 = ['a', 'b', 'c']
            variables_0 = { }
            result = lookup_module_0.run(terms_0, variables_0)
            file_mock_0.assert_called_once_with('test/test_data/test_file.csv')
            assert result == [ ]

# Generated at 2022-06-25 10:29:55.665313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ['California']
    variables = None
    l_u_m_0 = LookupModule()
    result = l_u_m_0.run(terms_0, variables)
    assert result == ['Sacramento']


# Generated at 2022-06-25 10:30:02.382813
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    try:
        lookup_module_0 = LookupModule()
        try:
            exception_0 = OSError()
            exception_0.winerror = 0
            exception_0.errno = 0
            exception_0.strerror = 'error'
            raise exception_0
        except OSError as exception_0:
            open_0 = exception_0
        lookup_module_0.read_csv('E', 'E', '=')
    except AnsibleError as exception_0:
        assert exception_0.message == 'csvfile: error'


# Generated at 2022-06-25 10:30:04.182353
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    f = None
    c_s_v_reader_0 = CSVReader(f)


# Generated at 2022-06-25 10:30:06.281192
# Unit test for constructor of class CSVReader
def test_CSVReader():
    try:
        CSVReader(1)
    except TypeError:
        pass
    else:
        raise Exception("Expected TypeError but didn't get one")


# Generated at 2022-06-25 10:30:12.017861
# Unit test for constructor of class CSVReader
def test_CSVReader():
    # Testing CSVReader constructor with file type object, csv.excel
    # dialect, encoding and **kwds as parameters
    # **kwds is a dict type object
    f_0 = open('bgp_neighbors.csv', 'r')
    kwds_0 = {'delimiter': ',', 'quotechar': '"'}
    c_s_v_reader_0 = CSVReader(f_0, csv.excel, 'utf-8', **kwds_0)
    # Reading from the file
    c_s_v_reader_0.__next__()
    # Closing the file
    f_0.close()



# Generated at 2022-06-25 10:30:18.239604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'encoding': 'utf-8', 'col': '1', 'file': 'ansible.csv', 'default': None, 'delimiter': 'TAB'})
    assert lookup_module_0.run(['keyname']) == ['value']
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([]) == []
    lookup_module_2 = LookupModule()
    assert lookup_module_2.run([('key', 1)]) == []

# Generated at 2022-06-25 10:30:26.018097
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    csv_reader_0 = CSVReader()
    c_s_v_reader_0 = CSVReader()
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_1.run(b'')
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_3.run(b'')
    lookup_module_4 = LookupModule()

    # Test with python 2.7.12 and 3.5.2 fails on windows, but passes on linux
    #assert b'' == lookup_module_0.read_csv(b'', b'', b'', b'', b'', b'')

# Generated at 2022-06-25 10:30:30.196091
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    bytes_0 = b'K\xc6]'
    c_s_v_reader_0 = CSVReader(bytes_0)
    assert c_s_v_reader_0.__next__() == [to_text('K\xc6')]


# Generated at 2022-06-25 10:31:02.282188
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    tsvfile_0 = '"apple","orange","watermelon","banana"\n"green","orange","","yellow"\n"","","yellow",""\n'
    bytes_0 = to_bytes(tsvfile_0)
    f_0 = open(bytes_0, 'rb')
    c_s_v_reader_0 = CSVReader(f_0)

    # Test method __next__
    assert c_s_v_reader_0.__next__() == ["apple", "orange", "watermelon", "banana"]
    assert c_s_v_reader_0.__next__() == ["green", "orange", "", "yellow"]
    assert c_s_v_reader_0.__next__() == ["", "", "yellow", ""]


# Generated at 2022-06-25 10:31:08.165591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialization
    lookup_module_0 = LookupModule()
    kwargs = {'encoding': 'utf-8', 'delimiter': 'TAB'}
    terms = ['Li']
    variables = {'file': 'ansible.csv'}

    # Execution of the method
    res = lookup_module_0.run(terms, variables, **kwargs)

    # Implementation check
    #  - for the return type: list
    assert isinstance(res, list)



# Generated at 2022-06-25 10:31:09.928445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms_0 = ['']
    lookup_module_0 = LookupModule()
    lookup_module_0.run(test_terms_0)

# Generated at 2022-06-25 10:31:13.912210
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    bytes_0 = b'K\xc6]'
    c_s_v_recoder_0 = CSVRecoder(bytes_0)

# Generated at 2022-06-25 10:31:16.252153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_instance = LookupModule()
    try:
        lookup_module_instance.run(["test_0"])
    except AnsibleError:
        pass


# Generated at 2022-06-25 10:31:24.084111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule_0 = LookupModule()
    bytes_0 = b'\xc6'
    kv_0 = {'_raw_params': bytes_0}
    kwargs_0 = {'encoding': 'utf-8', 'delimiter': 'TAB', 'file': None, 'col': '1', 'default': None}
    try:
        lookupModule_0.run(kv_0, **kwargs_0)
    except AnsibleError as exc:
        assert exc.message == 'Search key is required but was not found'

# Generated at 2022-06-25 10:31:32.702152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:31:35.921384
# Unit test for constructor of class CSVReader
def test_CSVReader():
    bytes_0 = b'K\xc6]'
    c_s_v_reader_0 = CSVReader(bytes_0)


# Generated at 2022-06-25 10:31:39.787323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleError) as excinfo:
        LookupModule_inst = LookupModule()
        LookupModule_inst.run([])
    assert "Search key is required but was not found" in str(excinfo.value)


# Generated at 2022-06-25 10:31:44.906857
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    byte_0 = b'CZ\xb7\x9f\xa6\x84\x00\x00\x00\x1c\x11\x00\x00\x00\x00p\x00\x00\x00\x00\x14\x00\x00\x00 \x02\x00\x00'
    byte_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00@\x00\x00\x00\x00'
    bytes_0 = '\u5fb5'
    bytes_1 = b'\xd5\xbe\xb5'
    c_s_v_reader_0 = CSVReader(bytes_0, bytes_1)


# Generated at 2022-06-25 10:32:10.487166
# Unit test for method __next__ of class CSVReader

# Generated at 2022-06-25 10:32:12.345701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(['']), list) == True


# Generated at 2022-06-25 10:32:21.388720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'K\xc6]'
    bytes_1 = b"lookup('csvfile', 'key', file='file')"
    bytes_2 = b'file'
    bytes_3 = b'K\xc6]'
    bytes_4 = b'\xc6]'
    bytes_5 = b'\xc6]'
    bytes_6 = b'\xc6]'
    bytes_7 = b'\xc6]'
    bytes_8 = b'\xc6]'
    bytes_9 = b"lookup('csvfile', 'key', file='file')"
    bytes_10 = b'file'

# Generated at 2022-06-25 10:32:29.084114
# Unit test for constructor of class CSVReader
def test_CSVReader():
    csvFile = 'test.csv'
    delimiter = ','
    encoding = 'utf-8'
    file_0 = open(csvFile, 'rb')
    csvReader_0 = CSVReader(file_0, delimiter=to_native(delimiter), encoding=encoding)
    next(csvReader_0)
    # Unit test for method CSVReader.__next__
    next(csvReader_0)
    # Unit test for method CSVReader.__iter__
    iter(csvReader_0)
    csvReader_0.reader