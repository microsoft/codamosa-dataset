

# Generated at 2022-06-25 10:22:34.058591
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:22:42.551572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = "ansible"
    str_1 = "__main__"
    str_2 = "ansible"
    str_3 = "elements.csv"
    str_4 = "TAB"
    str_5 = "utf-8"
    #str_6 = "default"
    #str_7 = "col"
    str_8 = "1"
    str_9 = "file"
    str_10 = "delimiter"
    str_11 = "encoding"
    list_0 = [str_0, str_1, str_2, str_3, str_4, str_5, str_8, str_9, str_10, str_11]
    lookup_module_

# Generated at 2022-06-25 10:22:48.765986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [ '_raw_params=ansible.csv; delimiter=TAB; encoding=utf-8; col=1', '_raw_params=ansible.csv; delimiter=TAB; encoding=utf-8; col=2']
    variables_0 = {}
    kwargs_0 = { 'variables': variables_0}
    lookup_module_0 = LookupModule(**kwargs_0)
    try:
        result_0 = lookup_module_0.run(terms_0, variables_0)
    except Exception as e:
        print(e)
    assert (len(lookup_module_0.file_params) == 0)


# Generated at 2022-06-25 10:22:56.781823
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module_0 = LookupModule()
    str_arg_0 = ''
    str_arg_1 = ''
    str_arg_2 = ''
    str_arg_3 = ''
    str_arg_4 = ''
    str_arg_5 = ''
    str_arg_6 = ''
    var_0 = lookup_module_0.read_csv(str_arg_0, str_arg_1, str_arg_2, str_arg_3, str_arg_4, str_arg_5, str_arg_6)



# Generated at 2022-06-25 10:22:57.650129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:23:07.582813
# Unit test for constructor of class CSVReader
def test_CSVReader():
    test_CSVReader_f = (open('/etc/passwd', 'rb'))
    test_CSVReader_dialect = (csv.excel)
    test_CSVReader_encoding = ('utf-8')
    test_CSVReader_kwds = {}
    test_CSVReader_kwds['delimiter'] = None
    test_CSVReader_kwds['doublequote'] = None
    test_CSVReader_kwds['escapechar'] = None
    test_CSVReader_kwds['lineterminator'] = None
    test_CSVReader_kwds['quotechar'] = None
    test_CSVReader_kwds['quoting'] = None
    test_CSVReader_kwds['skipinitialspace'] = None

# Generated at 2022-06-25 10:23:12.073371
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module_0 = LookupModule(**{})
    csv_file = "test_files/test.csv"
    line_number = 2
    result = lookup_module_0.read_csv(csv_file, "test2", ",", encoding="utf-8", dflt="", col=line_number)
    assert result == "testdata2"


# Generated at 2022-06-25 10:23:15.475945
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.read_csv(filename='filename', key='key', delimiter='delimiter', encoding='encoding', dflt='dflt', col='col')
    except Exception as inst:
        assert False



# Generated at 2022-06-25 10:23:27.238980
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    # Create some test data
    key = "testkey"
    lookupfile = "temp.csv"
    delimiter = ","
    encoding = "utf-8"
    dflt = "not found"
    col = 1

    # Create a lookup module
    lookup_module_0 = LookupModule()

    # Create a CSV file for looking up the given key
    f = open(lookupfile, 'w')
    f.write("mykey,mycolumn\n")
    f.write("testkey,testcolumn\n")
    f.close()

    # Read the CSV file
    ret = lookup_module_0.read_csv(lookupfile, key, delimiter, encoding, dflt, col)

    # Check if the column value for the given key is returned
    assert ret == "testcolumn"

# Generated at 2022-06-25 10:23:30.342575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = 'search key'
    variables_0 = None
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(term_0, variables_0), list)


# Generated at 2022-06-25 10:23:37.351717
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    c_s_v_reader_0 = CSVReader(1)
    c_s_v_reader_0.reader = 1
    assert c_s_v_reader_0 is not None


# Generated at 2022-06-25 10:23:40.627887
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookupModule_0 = LookupModule()
    str_0 = 'DuE/t*O'
    str_1 = 'f\'|>j'
    str_2 = 'h'
    lookupModule_0.read_csv(str_0, str_1, str_2)

# Generated at 2022-06-25 10:23:43.986637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    cs = CSVReader('')
    csv_recorder_0 = cs.__iter__

    lm = LookupModule()
    options = {'lookup_class': 'lookup module class'}
    lm.set_options(var_options=options)


# Generated at 2022-06-25 10:23:45.493369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert_equal(len(LookupModule.run('csvfile','terms','variables')), 0)

# Generated at 2022-06-25 10:23:47.690239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = {'DuE/t*O'}
    result = LookupModule.run(terms, variables={'DuE/t*O', 100})
    assert result == None


# Generated at 2022-06-25 10:23:49.679928
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_0 = 'DuE/t*O'
    csv_reader_0 = CSVReader(str_0)
    list_0 = list(csv_reader_0)


# Generated at 2022-06-25 10:24:00.637719
# Unit test for constructor of class CSVReader
def test_CSVReader():
    test_case_0()
    # calling function read_csv at index -2, should get Answer: 0
    str_0 = 'gdf'
    str_1 = 'sd'
    str_2 = 'dff'
    str_3 = 'dff'
    str_4 = 'dfd'
    c_s_v_reader_0 = CSVReader(str_0, delimiter=str_1, encoding=str_2)
    c_s_v_reader_1 = CSVReader(str_0, encoding=str_2)
    c_s_v_reader_2 = CSVReader(str_0, delimiter=str_1)
    c_s_v_reader_3 = CSVReader(str_0, delimiter=str_1, encoding=str_2, dialect=str_3)
    c_

# Generated at 2022-06-25 10:24:03.314241
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_0 = '%tB'
    c_s_v_reader_0 = CSVReader(str_0)
    assert c_s_v_reader_0.__next__() == ['%tB']

# Generated at 2022-06-25 10:24:07.475886
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    # Parameters
    filename = '/etc/ansible/hosts'
    key = 'localhost'
    delimiter = ' '
    encoding = 'utf-8'
    dflt = 'na'
    col = 1
    # LookupModule_0 = LookupModule()


# Generated at 2022-06-25 10:24:10.011769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    csv_recorder_0 = CSVRecoder()
    assert type(csv_recorder_0.reader) is codecs.StreamReaderWriter


# Generated at 2022-06-25 10:24:19.633153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = open('test.csv')
    c_s_v_reader_0 = CSVReader(f)
    lookup_module_0 = LookupModule()
    variables = None
    kwargs = {'delimiter': 'TAB'}
    lookup_module_0.set_options(var_options=variables, direct=kwargs)
    lookup_module_0.get_options()
    lookup_module_0.find_file_in_search_path(variables, 'files', 'file')
    lookup_module_0.read_csv('test.csv', 'test', 'TAB')
    lookup_module_0.run([], variables, **kwargs)

# Generated at 2022-06-25 10:24:30.475609
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    global var
    global col
    global key
    global file
    global default
    global delimiter

    lookupmodule_obj = LookupModule()
    global var

    # parse_kv(term)
    # test_case_0()

    # parameters

    key = '_raw_params'
    file = 'file'
    delimiter = 'delimiter'
    col = 'col'
    default = 'default'

    # parameters
    key = '_raw_params'
    file = 'file'
    delimiter = 'delimiter'
    col = 'col'
    default = 'default'

    # parameters
    key = '_raw_params'
    file = 'file'
    delimiter = 'delimiter'
    col = 'col'
    default = 'default'

    # parameters
   

# Generated at 2022-06-25 10:24:34.129280
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_0 = 'b,i'
    str_1 = 'M'
    c_s_v_reader_0 = CSVReader(str_0)
    c_s_v_reader_0.__next__()


# Generated at 2022-06-25 10:24:35.051721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False


# Generated at 2022-06-25 10:24:45.543084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['9', '7', '8', '1', '6']
    variables = 'M<i'
    direct = dict()
    lookupModule_obj_0 = LookupModule()
    set_options_ret_val_0 = lookupModule_obj_0.set_options(var_options=variables, direct=direct)
    get_options_ret_val_0 = lookupModule_obj_0.get_options()
    if None in get_options_ret_val_0:
        raise AssertionError('options is not valid')
    # get_options_ret_val_0['delimiter']
    # get_options_ret_val_0['file']
    # get_options_ret_val_0['encoding']
    # get_options_ret_val_0['col']
    # get_

# Generated at 2022-06-25 10:24:53.576375
# Unit test for constructor of class CSVReader
def test_CSVReader():
    # create an instance of class CSVReader
    c_csv_reader_0 = CSVReader(str_0)
    # verify a__next__ exists
    assert hasattr(c_csv_reader_0, '__next__')
    # verify a__iter__ exists
    assert hasattr(c_csv_reader_0, '__iter__')
    # verify a__init__ exists
    assert hasattr(c_csv_reader_0, '__init__')
    # verify a__init__ supports multiple arguments
    # There will be a TypeError if the test has issue
    try:
        c_csv_reader_1 = CSVReader('7Zp8Wd', str_0)
    except TypeError:
        raise Exception("There is a TypeError in CSVReader.__init__")
    # verify a__init__ supports one argument


# Generated at 2022-06-25 10:25:00.915989
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    ansible_hash_0 = {u'encoding': u'utf-8', u'col': 1, u'file': u'ansible.csv', u'default': None, u'delimiter': u'TAB'}
    csv_reader_0 = CSVReader(u'ansible.csv')
    lookup_module_0 = LookupModule()
    assert lookup_module_0.read_csv(u'ansible.csv', u'Li', u'TAB', ansible_hash_0['encoding'], ansible_hash_0['default'], ansible_hash_0['col']) == u'3'


# Generated at 2022-06-25 10:25:09.864335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    file_0= 'ansible.csv'
    var_0 = LookupModule()
    options_0 = {'col': '1', 'file': file_0, 'default': None, 'delimiter': 'TAB', 'encoding': 'utf-8'}
    terms_0 = 'Li'
    variables_0 = None
    var_0.set_options(var_options=variables_0, direct=options_0)

    lookupfile_0 = var_0.find_file_in_search_path(variables_0, 'files', options_0['file'])
    var_1 = var_0.read_csv(lookupfile_0, terms_0, options_0['delimiter'], options_0['encoding'], options_0['default'], options_0['col'])
   

# Generated at 2022-06-25 10:25:14.336593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a new instance of LookupModule
    # arguments: None
    # keyword arguments: None
    lookup_module_0 = LookupModule()
    # Test the method run
    # arguments: terms, variables=None, **kwargs
    # keyword arguments:
    # terms:
    str_0 = 'CYD2B\\0X*#'
    # variables:
    c_s_v_recoder_0 = CSVRecoder(str_0)
    # kwargs:
    # Return type: list
    print(lookup_module_0.run(str_0, c_s_v_recoder_0))


# Generated at 2022-06-25 10:25:19.144182
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():

    str_0 = 'DuE/t*O'
    c_s_v_reader_0 = CSVReader(str_0)

    # Test with a normal value
    int_0 = 0
    str_1 = 'DuE/t*O'
    str_2 = c_s_v_reader_0.__next__()
    assert str_1 == str_2



# Generated at 2022-06-25 10:25:37.295745
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:25:47.609744
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    # csvfile: csvfile-0.csv
    # This test is used to check the return value of read_csv method in LookupModule class. Expected return value is 'value1'
    # The test will find the value of 'key1' in the first column of csvfile-0.csv.
    assert LookupModule.read_csv('csvfile', 'key1', 'TAB') == 'value1'
    # csvfile: csvfile-1.csv
    # This test is used to check the return value of read_csv method in LookupModule class. Expected return value is 'value2'
    # The test will find the value of 'key1' in the first column of csvfile-1.csv.
    assert LookupModule.read_csv('csvfile', 'key1', ',') == 'value2'


# Generated at 2022-06-25 10:25:49.165578
# Unit test for method run of class LookupModule
def test_LookupModule_run():

	# TODO: implement test
	assert True == True

# Generated at 2022-06-25 10:25:53.237192
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookupmodule_0 = LookupModule()
    str_0 = 'DuE/t*O'
    str_1 = 'Q#]O[f$*'
    str_2 = 'Pdw!p'
    str_3 = ';7:c|v\u0000_W8J'
    assert(True == lookupmodule_0.read_csv(str_0, str_1, str_2, str_3) == None)


# Generated at 2022-06-25 10:25:58.012666
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    filename = '/etc/ansible/hosts'
    key = 'node1'
    delimiter = 'TAB'
    default = '/etc/ansible/hosts'
    col = 1
    lm_ins = LookupModule()
    assert lm_ins.read_csv(filename,key,delimiter,default,col) == '/etc/ansible/hosts'


# Generated at 2022-06-25 10:25:59.184777
# Unit test for constructor of class CSVReader
def test_CSVReader():
    str_0 = 'DuE/t*O'
    c_s_v_reader_0 = CSVReader(str_0)


# Generated at 2022-06-25 10:26:02.148619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test: LookupModule.run")
    
    lookupmodule_obj = LookupModule()
    lookupmodule_obj.run(terms, variables, direct)


# Generated at 2022-06-25 10:26:02.709695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:26:13.523762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-25 10:26:20.714280
# Unit test for constructor of class CSVReader
def test_CSVReader():
    import sys
    import io
    import csv
    if sys.version_info[0] == 3:
        import io
        import csv
        f = io.StringIO('a,b,c\n1,2,3\n4,5,6\n')
        c_s_v_reader_0 = CSVReader(f)
        next(c_s_v_reader_0)
    elif sys.version_info[0] == 2:
        f = open('./py2_test.csv', 'rb')
        c_s_v_reader_1 = CSVReader(f)
        next(c_s_v_reader_1)

# Generated at 2022-06-25 10:26:37.028849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals_0 = dict()
    paramvals_0['col'] = None
    paramvals_0['default'] = None
    paramvals_0['delimiter'] = None
    paramvals_0['file'] = None
    paramvals_0['encoding'] = None

    terms_0 = [None]

    variables_0 = {'file': 'file_0', 'col': 'num_0', 'key': 'txt_0', 'delimiter': 'char_0', 'default': 'var_0', 'encoding': 'charset_0'}
    variables_0['file'] = test_case_0
    variables_0['col'] = 'num_0'
    variables_0['key'] = 'txt_0'
    variables_0['delimiter'] = 'char_0'
    variables_0

# Generated at 2022-06-25 10:26:40.512884
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    f_0 = 'r_s'
    encoding_0 = 'rouge'
    csv_reader_0 = CSVReader(f_0, encoding=encoding_0)
    next(csv_reader_0)


# Generated at 2022-06-25 10:26:42.680162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert read_csv('test.dat', 'string', 'example', 'example', 'example', 1) == 'test_value'

# Generated at 2022-06-25 10:26:47.299007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = 'mT3qrM9X6WNsU6'
    terms_0 = [term_0]
    variables_0 = 'T1q3r2X9WNsU6'
    lookupmodule_0 = LookupModule()
    try:
        ret_0 = lookupmodule_0.run(terms_0, variables_0)
    finally:
        pass


# Generated at 2022-06-25 10:26:48.296515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule_run_0()


# Generated at 2022-06-25 10:26:50.816011
# Unit test for constructor of class CSVReader
def test_CSVReader():

    file_object = open('ansible.csv', 'r')
    c_s_v_reader_0 = CSVReader(file_object)

    assert len(c_s_v_reader_0) == 0

    return

# Generated at 2022-06-25 10:26:59.916100
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    filename_0 = 'a\x00Dd\x00EFU\x00E4'
    key_0 = 'a\x00Dd\x00EFU\x00E4'
    delimiter_0 = '\x00'
    encoding_0 = 'utf-8'
    dflt_0 = '@'
    col_0 = 1
    paramvals_0 = {'file': filename_0, 'col': col_0, 'delimiter': delimiter_0, 'default': dflt_0, 'encoding': encoding_0}
    lookupfile_0 = filename_0
    var_0 = paramvals_0
    assert var_0 == paramvals_0


# Generated at 2022-06-25 10:27:11.104329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals = {'default': '', 'col': '1', 'delimiter': 'TAB', 'file': 'ansible.csv'}
    paramvals['default'] = ''
    paramvals['col'] = '1'
    paramvals['delimiter'] = 'TAB'
    paramvals['file'] = 'ansible.csv'
    terms = ['_raw_params']
    terms[:] = []
    terms.append('_raw_params')
    lookup_base_0 = LookupBase()
    lookup_base_1 = lookup_base_0
    lookup_base_0.set_options(var_options=None, direct={})
    lookup_base_0.get_options()
    lookup_base_0.find_file_in_search_path(None, 'files', paramvals['file'])


# Generated at 2022-06-25 10:27:16.957735
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    # No exception expected

    reader_0 = CSVReader("8d9zZ")

    def check_next(p_0, p_1):
        return p_0 == p_1

    for i in range(0, 3):
        try:
            p_1 = next(reader_0)
            p_0 = "8d9zZ"
            assert check_next(p_0, p_1) == True
        except StopIteration:
            pass



# Generated at 2022-06-25 10:27:23.648766
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_0 = 'DuE/t*O'
    csvreader_0 = CSVReader(str_0)
    assert_equal(csvreader_0.__next__(), 'DuE/t*O')

if __name__ == '__main__':
    from ansible.utils.pytest import assert_equal

    test_case_0()

    # Unit test for method read_csv
    # Unit test for method run
    test_case_0()

# Generated at 2022-06-25 10:27:43.743843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    parameter = {"_raw_params": "test_key_0", "col": "test_value_0", "default": "test_value_1",
        "delimiter": "test_value_2", "file": "test_value_3", "encoding": "test_value_4"}
    csv_reader_0 = CSVReader('test_0')
    c_s_v_reader_0 = CSVReader(csv_reader_0, delimiter='test_value_2', encoding='test_value_4')
    assert c_s_v_reader_0 != None

# Generated at 2022-06-25 10:27:54.708610
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module_obj = LookupModule()

    # Assertions
    # Assertion 1
    assert_equal(lookup_module_obj.read_csv(str_0, str_1, str_2, str_3, str_4, int_0), str_5)
    # Assertion 2
    assert_equal(lookup_module_obj.read_csv(str_6, str_7, str_8, str_9, str_5, None), None)
    # Assertion 3
    assert_equal(lookup_module_obj.read_csv(str_10, str_11, str_12, str_13, str_14, str_15), str_16)
    # Assertion 4

# Generated at 2022-06-25 10:27:58.723455
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_0 = '<r0mJ'
    c_s_v_reader_0 = CSVReader(str_0)
    result___next__ = c_s_v_reader_0.__next__()


# Generated at 2022-06-25 10:28:07.880663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile

    temp_file = tempfile.mkstemp()
    open(temp_file[1], 'w').write("""\
key,col0,col1
key0,value00,value01
key1,value10,value11
""")
    terms = {'_raw_params': 'key0', 'file': temp_file[1]}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables=None)
    assert result == ['value01']
    open(temp_file[1], 'w').write("""\
key,col0,col1
key0,value00,value01
key1,value10,value11
""")
    terms = {'_raw_params': 'key1', 'file': temp_file[1]}
    lookup_module = Look

# Generated at 2022-06-25 10:28:14.047784
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    name = 'csvfile'
    file = 'ansible.csv'
    delimiter = 'TAB'
    encoding = 'utf-8'
    dflt = None
    col = 1
    lookup_module = LookupModule()
    lookup_module.read_csv(name, file, delimiter, encoding, dflt, col)

# Generated at 2022-06-25 10:28:15.667232
# Unit test for constructor of class CSVReader
def test_CSVReader():
    str_0 = '{zQ,<'
    assert CSVReader(str_0)


# Generated at 2022-06-25 10:28:21.577927
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    to_text_0 = to_text('l;{&')
    to_text_1 = to_text('=YO,du')
    to_text_2 = to_text('[')
    to_text_3 = to_text(',')
    to_text_4 = to_text('G')
    to_text_5 = to_text('R')
    to_text_6 = to_text('#')
    to_text_7 = to_text('c')
    to_text_8 = to_text('s')
    str_0 = 'DuE/t*O'
    csvreader_0 = CSVReader(str_0, delimiter=to_native(to_text_0))

# Generated at 2022-06-25 10:28:25.773834
# Unit test for constructor of class CSVReader
def test_CSVReader():
    str_0 = 'DuE/t*O'
    c_s_v_reader_0 = CSVReader(str_0, dialect=csv.excel)

# Generated at 2022-06-25 10:28:30.554757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    with open('temp', 'w') as f_out:
        f_out.write('abc\n')
        f_out.write('bcd\n')
        f_out.write('def\n')
        f_out.write('ehi\n')
    lookup = LookupModule()
    res = lookup.run(terms=['abc'], variables=dict(file='temp'))
    assert res[0] == 'bcd'

test_LookupModule_run()
#test_case_0()

# Generated at 2022-06-25 10:28:32.729669
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    c_s_v_reader_0 = CSVReader(c_s_v_recoder_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:29:09.555343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create object LookupModule
    lookups_0 = LookupModule()

    # call method run
    lookups_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:29:11.527341
# Unit test for constructor of class CSVReader
def test_CSVReader():
    str_0 = 'DuE/t*O'
    c_s_v_reader_0 = CSVReader(str_0)

# Generated at 2022-06-25 10:29:14.134908
# Unit test for constructor of class CSVReader
def test_CSVReader():
    str_0 = '&\n\n'
    c_s_v_reader_0 = CSVReader(str_0)
    assert c_s_v_reader_0.reader is not None


# Generated at 2022-06-25 10:29:15.911071
# Unit test for constructor of class CSVReader
def test_CSVReader():
    try:
        c_s_v_reader_0 = CSVReader('abc', 'xyz')
# raise exception is the case
    except:
        pass
    else:
        assert False


# Generated at 2022-06-25 10:29:16.555500
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    pass


# Generated at 2022-06-25 10:29:23.019768
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():

    # Test case for method read_csv of class LookupModule
    # read_csv
    # param: [filename, key, delimiter, encoding='utf-8', dflt=None, col=1]
    # return: [value]
    print("Testing method read_csv of class LookupModule")
    print("Test case 0: ")
    filename_0 = 'DuE/t*O'
    key_0 = 'DuE/t*O'
    delimiter_0 = 'DuE/t*O'
    encoding_0 = 'DuE/t*O'
    dflt_0 = 'DuE/t*O'
    col_0 = 'DuE/t*O'
    l_m_0 = LookupModule()

# Generated at 2022-06-25 10:29:28.635297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import csv, codecs
    import ansible.plugins.lookup.csvfile as csvfile
    csvfile_lookup_base_0 = LookupBase()
    str_0 = 'DuE/t*O'
    c_s_v_recoder_0 = CSVRecoder(str_0)
    csvfile_lookup_base_0.set_options()
    str_1 = 'K>@a+&f'
    c_s_v_recoder_1 = CSVRecoder(str_1)
    csvfile_lookup_base_0.run()
    csvfile_lookup_base_0.test_case_0()
    csvfile.test_case_0()
    csvfile_lookup_base_0.read_csv()



# Generated at 2022-06-25 10:29:34.255167
# Unit test for constructor of class CSVReader
def test_CSVReader():
    f_0 = '>F}(pA=yJ'
    dialect_0 = 't9z{7'
    encoding_0 = 'Vu"e:=&'
    kwds_0 = {
        'quoting': None,
        'dialect': dialect_0,
        'lineterminator': '\n',
        'skipinitialspace': False
    }
    c_s_v_reader_0 = CSVReader(f_0, dialect_0, encoding_0, **kwds_0)
    c_s_v_reader_0.__next__()
    c_s_v_reader_0.next()


# Generated at 2022-06-25 10:29:43.602041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '/home/vincent/project/ansible/playbooks/ansible/lookup_plugins/csvfile'
    str_1 = 'fiche_de_poste.csv'
    str_2 = '''first_position_on_form'''
    bytes_0 = b'/home/vincent/project/ansible/playbooks/ansible/lookup_plugins/csvfile'
    bytes_1 = b'fiche_de_poste.csv'
    int_0 = 0
    test_LookupModule_run_0 = lookup_module_0.run([str_0, str_1, str_2], int_0)
    str_3 = str(test_LookupModule_run_0)

# Generated at 2022-06-25 10:29:49.847471
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    # Test cases
    look_up_module_0 = LookupModule()
    filename_0 = 'DuE/t*O'
    k_0 = 'f:<'
    delimiter_0 = '\x06'
    encoding_0 = 'utf-8'
    dflt_0 = False
    col_0 = 3
    n_0 = look_up_module_0.read_csv(filename_0, k_0, delimiter_0, encoding_0, dflt_0, col_0)
    _m_0 = __import__('sys')
    setattr(_m_0, 'stdout', _m_0.__stdout__)
    setattr(_m_0, 'stderr', _m_0.__stderr__)
    print((n_0))
    # Test case

# Generated at 2022-06-25 10:30:28.942250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupmodule_0 = LookupModule()
    lookupmodule_0.run('terms', 'variables')


# Generated at 2022-06-25 10:30:30.826588
# Unit test for constructor of class CSVReader
def test_CSVReader():
    with open('test/test.csv', 'r') as f:
        c_s_v_reader_0 = CSVReader(f)


# Generated at 2022-06-25 10:30:39.517638
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    str_1 = 'DuE/t*O'
    str_2 = 'DuE/t*O'
    c_s_v_reader_0 = CSVReader(str_1, delimiter=str_2)
    str_3 = 'DuE/t*O'
    c_s_v_reader_1 = CSVReader(str_3, delimiter=str_2, encoding='DuE/t*O')
    str_4 = 'DuE/t*O'
    str_5 = 'DuE/t*O'
    str_6 = 'DuE/t*O'
    str_7 = 'DuE/t*O'
    str_8 = 'DuE/t*O'
    str_9 = 'DuE/t*O'

# Generated at 2022-06-25 10:30:41.179167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupmodule_0 = LookupModule()
    assert isinstance(lookupmodule_0.run([]), list)


# Generated at 2022-06-25 10:30:48.194838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_base0 = LookupModule()
    lookup_base1 = LookupModule()
    lookup_base2 = LookupModule()
    lookup_base3 = LookupModule()
    lookup_base4 = LookupModule()
    lookup_base5 = LookupModule()
    lookup_base6 = LookupModule()
    lookup_base7 = LookupModule()
    lookup_base8 = LookupModule()
    lookup_base9 = LookupModule()
    lookup_base10 = LookupModule()
    lookup_base11 = LookupModule()
    lookup_base12 = LookupModule()
    lookup_base13 = LookupModule()
    lookup_base14 = LookupModule()
    lookup_base15 = LookupModule()
    lookup_base16 = LookupModule()
    lookup_base17 = LookupModule()
   

# Generated at 2022-06-25 10:30:51.088716
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_0 = 'DuE/t*O'
    c_s_v_recoder_0 = CSVRecoder(str_0)

    result = CSVReader.__next__(c_s_v_recoder_0)
    assert 'DuE/t*O' == result


# Generated at 2022-06-25 10:30:57.674267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ansible_options = {'file': 'ansible_file', 'encoding': 'utf-8', 'col': '1', 'default': 'value'}
    terms = {'_raw_params': 'value'}
    lookup_module_0 = LookupModule(loader=1)
    lookup_module_1 = LookupModule(loader=1, templar=1)
    lookup_module_2 = LookupModule(loader=1, templar=1, variables=ansible_options)
    lookup_module_3 = LookupModule(loader=1, templar=1, variables=ansible_options, **ansible_options)
    lookup_module_0.run(terms)
    lookup_module_1.run(terms)
    lookup_module_2.run(terms)

# Generated at 2022-06-25 10:31:03.273344
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    str_7 = 'Yz@qgyp'
    str_8 = 'ns_o}'
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    str_9 = 'utf-8'
    c_s_v_reader_0 = CSVReader(str_7, encoding=str_8, dialect=str_9)
    c_s_v_reader_0.__next__()


# Generated at 2022-06-25 10:31:07.820794
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookupmodule_obj = LookupModule()
    assert lookupmodule_obj.read_csv('/var/log/syslog', '30', 'TAB')
    assert not lookupmodule_obj.read_csv('/var/log/syslog', '30', 'TAB', None, None, None)

# Generated at 2022-06-25 10:31:10.555899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'DuE/t*O'
    c_s_v_recoder_0 = CSVRecoder(str_0)
    str_1 = 'Y_!g'
    delimiter = 'T~}s'
    encoding = 'DuE/t*O'
    terms = str_0
    assert LookupModule.run(terms, encoding=encoding, delimiter=delimiter) == None
