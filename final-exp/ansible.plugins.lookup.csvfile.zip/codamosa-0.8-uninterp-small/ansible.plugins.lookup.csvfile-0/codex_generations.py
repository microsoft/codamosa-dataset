

# Generated at 2022-06-25 10:22:27.910704
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module_0 = LookupModule()
    int_0 = -1004
    str_0 = lookup_module_0.read_csv(int_0, int_0, int_0, int_0)



# Generated at 2022-06-25 10:22:38.088566
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    from ansible.errors import AnsibleError

    filename_0 = "/usr/bin/lesspipe.sh"
    key_0 = """~'+5}_K^1R'=x(WXgUUz@Mde&K;u,n^KK:BV<Y&e={@{:"~"""
    delimiter_0 = ','
    encoding_0 = "utf-8"
    dflt_0 = -5
    col_0 = 0

    lookup_module_0 = LookupModule()
    try:
        read_csv_ret_0 = lookup_module_0.read_csv(filename_0, key_0, delimiter_0, encoding_0, dflt_0, col_0)
    except AnsibleError as exception_ret_0:
        read_csv_ret_0 = exception_

# Generated at 2022-06-25 10:22:40.081753
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    look = LookupModule()
    assert look.read_csv('f', 'k', 'd', 'e', 'df', 'c') == None


# Generated at 2022-06-25 10:22:45.090418
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module_0 = LookupModule()
    filename_0 = '/dev/null'
    key_0 = 'foo'
    delimiter_0 = ','
    encoding_0 = 'utf-8'
    dflt_0 = 'foo'
    col_0 = 1
    lookup_module_0.read_csv(filename_0, key_0, delimiter_0, encoding_0, dflt_0, col_0)


# Generated at 2022-06-25 10:22:49.689915
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    int_0 = -940
    c_s_v_reader_0 = CSVReader(int_0)
    try:
        c_s_v_reader_0.__next__
        assert False
    except TypeError as raised_exception:
        assert str(raised_exception) == "'CSVReader' object is not iterable"
    except Exception as raised_exception:
        assert False


# Generated at 2022-06-25 10:22:59.465265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = -890
    str_0 = '{}'
    terms_0 = [str_0]
    variables_0 = 'qe'
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = '{}'
    str_7 = ''
    str_8 = '{}'
    str_9 = ''
    ret_0 = lookup_module_0.run(terms_0, variables_0, file=str_1, delimiter=str_2, col=int_0, encoding=str_3, default=str_4)
    assert not ret_0

# Generated at 2022-06-25 10:23:07.408284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Here we assert that we get the correct result for an example case.
    # It would be nice to have some more test cases.
    lookup_module_0 = LookupModule()
    int_0 = -940
    c_s_v_reader_0 = CSVReader(int_0)
    terms_0 = ['', '-940']
    variables_0 = {}
    ret_val_0 = lookup_module_0.run(terms_0, variables_0)
    assert(ret_val_0 == [])

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:23:10.248103
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():

    obj_LookupModule = LookupModule()

    # Run test case 0
    res = obj_LookupModule.read_csv(-940,',',utf-8,0,1)

    return res


# Generated at 2022-06-25 10:23:19.160920
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    """Check method read_csv of class LookupModule"""
    print("Testing method read_csv...")
    str_0 = 'E]jKSA.Z&_'
    int_0 = -940
    list_0 = []
    dict_0 = {}
    str_1 = 'l[0$.s]Gk3'
    str_2 = '#>|x'
    str_3 = '}Y&'
    str_4 = 'oMf*xx'
    str_5 = '$W/BV'
    str_6 = '7>g/'
    str_7 = 'PX9N'
    str_8 = 'V,*`O'
    dict_0['col'] = str_0
    dict_0['file'] = int_0
    dict_0['encoding']

# Generated at 2022-06-25 10:23:26.310601
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    # Parameters
    filename = 'filename'
    key = 'key'
    delimiter = 'delimiter'
    encoding = 'encoding'
    dflt = 'default'
    col = 1

    # Return value tests
    expected_result_0 = 'expected_result_0'

    # Invoke method
    result = LookupModule.read_csv(filename, key, delimiter, encoding, dflt, col)
    assert(result == expected_result_0)



# Generated at 2022-06-25 10:23:34.753349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # call method with required and optional arguments
    lookup_module_0 = LookupModule()
    terms = ['aaa', 'bbb']
    variables = {'a': '1'}
    ret = lookup_module_0.run(terms, variables)

    # assert
    assert ret[0] == 'key1'
    assert ret[1] == 'key2'



# Generated at 2022-06-25 10:23:35.562228
# Unit test for constructor of class CSVReader
def test_CSVReader():
    CSVReader(None)


# Generated at 2022-06-25 10:23:44.127724
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():

    filename_0 = 'bgp_neighbors.csv'
    delimiter_0 = ','
    encoding_0 = 'utf-8'

    expected_list_0 = ['192.0.2.1', '172.16.0.1', '255.255.255.0', 'lo0', '65000', '65000', '192.0.2.2']
    expected_list_1 = ['192.0.2.1', '172.16.0.1', '255.255.255.0', 'lo0', '65000', '65000', '192.0.2.3']

    f_0 = open(filename_0, 'r')
    creader_0 = CSVReader(f_0, delimiter=delimiter_0, encoding=encoding_0)
    actual_list_0

# Generated at 2022-06-25 10:23:50.588271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_result = LookupModule().run(terms=['"Li"'], variables={'bgp_neighbor_ip':'"Li"'}, **{'delimiter':'TAB', 'encoding':'utf-8', 'col':'1', 'default':'None', 'file':'elements.csv'})
    assert lookup_result == ['"6.941"'], 'test_LookupModule_run: lookup_result should be ['"6.941"'], but was {}'.format(lookup_result)

# Generated at 2022-06-25 10:23:54.189429
# Unit test for constructor of class CSVReader
def test_CSVReader():
    lookup_module_1 = LookupModule()

    # Test with invalid file
    try:
        lookup_module_1.CSVReader("file_name")
    except Exception:
        pass



# Generated at 2022-06-25 10:24:03.169869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # set up parameters
    term_0 = "localhost"

# Generated at 2022-06-25 10:24:05.789398
# Unit test for constructor of class CSVReader
def test_CSVReader():
    reader = CSVReader(None, dialect=csv.excel, encoding='utf-8')
    assert reader is not None


# Generated at 2022-06-25 10:24:08.913640
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    csvreader_obj = CSVReader(f=None, dialect='csv.excel', encoding='utf-8')
    assert csvreader_obj.__next__() == None


# Generated at 2022-06-25 10:24:12.244002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['key_name']
    variables_0 = None
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) is None

# Generated at 2022-06-25 10:24:16.447536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['Li']
    variables_0 = {'csvfile_file': '../ansible/test/unit/lookup_plugins/files/elements.csv', 'csvfile_col': 1, 'csvfile_default': '', 'csvfile_delimiter': "\t"}
    lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 10:24:28.568421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    req_0 = [u'C1.1', u'C1.2', u'C1.3', u'C1.4', u'C1.5']
    req_1 = {}
    req_2 = {}
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(req_0, req_1, **req_2)
    assert result == [u'V1.1', u'V1.2', u'V1.3', u'V1.4', u'V1.5']


# Generated at 2022-06-25 10:24:31.741800
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    csv_reader_0 = CSVReader(f, delimiter=to_native(delimiter), encoding=encoding)
    try:
        row = csv_reader_0.__next__()
        return row
    except StopIteration:
        return StopIteration


# Generated at 2022-06-25 10:24:41.052141
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    lookup_module_0 = LookupModule()
    file_1 = mock.Mock()
    file_1.read.return_value = 'line1\nline2'
    input_f = file_1
    if PY2:
        reader_2 = CSVReader(input_f)
        result_1 = next(reader_2)
    else:
        file_3 = mock.Mock()
        file_3.read.return_value = 'line1\nline2'
        input_f = file_3
        reader_2 = CSVReader(input_f)
        result_1 = next(reader_2)


# Generated at 2022-06-25 10:24:44.572353
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module_0 = LookupModule()
    lookup_module_0.read_csv("test.csv", "test_key1", "test_delimiter1", "test_encoding1", "test_dflt1", "test_col1")

# Generated at 2022-06-25 10:24:53.162360
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()

    # Test case # 1, basic test
    lookup_module_0.read_csv('elements.csv', 'Li', ',', 'utf-8', '3', 1)

    # Test case # 2, empty file
    try:
        lookup_module_1.read_csv('elements.csv', 'Li', ',', 'utf-8', '3', 1)
    except IOError as e:
        print(e)

    # Test case # 3, wrong file name
    try:
        lookup_module_1.read_csv('elements.csv', 'Li', ',', 'utf-8', '3', 1)
    except IOError as e:
        print(e)


# Generated at 2022-06-25 10:25:02.873356
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    test_data = [['test', 'xyz'], ['test1', 'abc'], ['test2', 'def'], ]
    try:
        with open("test.tsv", 'wb') as f:
            wr = csv.writer(f, dialect='excel', delimiter='\t')
            wr.writerows(test_data)
        f.close()
        key = 'test2'
        filename = "test.tsv"
        col = 1
        value = lookup_module_0.read_csv(filename, key, delimiter='\t', dflt=None, col=1)
        print("Key: " + key + " Value: " + value)
        assert value == test_data[2][1]
    except Exception as e:
        print("Error in read_csv method of lookup module class")


# Generated at 2022-06-25 10:25:07.107955
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    lookup_module_0 = LookupModule()
    csvreader_0 = CSVReader([])
    csvreader___next___0_retval = csvreader_0.__next__()
    assert csvreader___next___0_retval == (), 'expected empty tuple, got %s' % repr(csvreader___next___0_retval)


# Generated at 2022-06-25 10:25:08.871617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms=terms, variables=variables, **kwargs)


# Generated at 2022-06-25 10:25:12.278396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lookup_module_3 = LookupModule()

    # Call method run of LookupModule with arguments:
    # (['american'], {})
    ret_run_4 = lookup_module_3.run(['american'], {})
    print("ret_run_4 = %r" % (ret_run_4,))

    # Output:
    # ret_run_4 = ['americano', 'americano']

    assert ret_run_4 == ['americano', 'americano']

# Generated at 2022-06-25 10:25:17.930136
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    # Reads some data and get the value that is in the column 2.
    lookup_module = LookupModule()

    # Reads some data
    filename = "test.csv"
    key = "Li"
    delimiter = ","
    encoding = 'utf-8'
    dflt = None
    col = 1

    # Get the value that is in the column 2.
    try:
        assert lookup_module.read_csv(filename, key, delimiter, encoding, dflt, col) == "6.941"
    except AssertionError as e:
        print("Test Failure: The atomic mass of Lithium is not correct.")
        print("Exception: ", e)

if __name__ == '__main__':
    test_LookupModule_read_csv()

# Generated at 2022-06-25 10:25:39.966268
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module_0 = LookupModule()
    lookupfile = 'test_csv_file.csv'
    key = 'Li'
    delimiter = ','
    encoding = 'utf-8'
    dflt = None
    col = '1'
    result = lookup_module_0.read_csv(lookupfile, key, delimiter, encoding, dflt, col)
    assert result == '3'


# Generated at 2022-06-25 10:25:46.362011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ['Li']
  variables = {'general_use': {'csv': {'file': 'elements.csv', 'delimiter': ',', 'col': '1'}}, 'hostvars': {'hostvars_test': {'hostvars_test':'hostvars_test'}}, 'omit_token': True, 'play_hosts': ['localhost'], 'play_hosts_all': [], 'play_hosts_count': 1, 'play_hosts_reached': [], 'play_hosts_remaining': set(), 'playbook_dir': '/Users/ansible/workarea/ansible'}

  ret = lookup_module_0.run(terms,variables)
  assert ret

# Generated at 2022-06-25 10:25:50.804543
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    import os
    lookup_module_1 = LookupModule()
    filename = 'sample.csv'
    key = 'S'
    delimiter = ','
    encoding = 'utf-8'
    dflt = None
    col = '0'
    actual_output = lookup_module_1.read_csv(filename, key, delimiter, encoding, dflt, col)
    expected_output = '1'

    assert(expected_output == actual_output)


# Generated at 2022-06-25 10:25:59.728255
# Unit test for constructor of class CSVReader
def test_CSVReader():
    # Open test_csvfile.csv to get an object of the class 'file'
    file = open("./test_csvfile.csv", "r")
    # Check if the object is of file type
    assert type(file) == file
    # Create an instance of the class CSVReader and check the type
    csv_reader = CSVReader(file)
    assert type(csv_reader) == CSVReader
    # Go through the csv_reader instance and check for the each value
    for row in csv_reader:
        assert row[0] == "Site"
        assert row[1] == "WAN 1"
        assert row[2] == "WAN 2"
        assert row[3] == "LAN"
    # Close the file
    file.close()


# Generated at 2022-06-25 10:26:02.818091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    filename = "filename"
    key = "key"
    delimiter = "delimiter"
    encoding = "encoding"
    dflt = "default"
    col = "column"
    terms = "terms"
    variables = "variables"
    kwargs = "kwargs"
    lookup_module = LookupModule()
    lookup_module.run(terms = terms, variables = variables, filename = filename, key = key, delimiter = delimiter, encoding = encoding, default = dflt, col = col)


# Generated at 2022-06-25 10:26:12.613039
# Unit test for constructor of class CSVReader
def test_CSVReader():
    try:
        lookup_module = LookupModule()
        (f,filename) = tempfile.mkstemp()
        with open(filename, 'w') as fp:
            fp.write('first, second, third\n')
            fp.write('"test,test",test,test')
        with open(filename, 'r') as f:
            creader = CSVReader(f, delimiter=",")
            rows = list(creader)
        assert len(rows) == 2
        assert rows[0] == ['first', ' second', ' third']
        assert rows[1] == ['test,test', 'test', 'test']
    finally:
        if filename:
            os.unlink(filename)


# Generated at 2022-06-25 10:26:15.931442
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = {}
    variables_0 = {}
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert ret_0 == []

# Generated at 2022-06-25 10:26:21.934996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    paramvals = {}
    paramvals['file'] = 'test_csv_file'
    paramvals['delimiter'] = ','
    paramvals['default'] = 'NoValue'
    paramvals['encoding'] = 'utf-8'
    key = 'value'
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    result = lookup_module.run([':'.join([key,paramvals['file'],paramvals['delimiter'],paramvals['default'],paramvals['encoding']])])
    assert result == [key]

# Generated at 2022-06-25 10:26:24.882507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = ['']
    variables = None
    kwargs = {}
    lookup_module_1.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:26:30.757919
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    params = {
        'filename': 'tsv.txt',
        'key': 'b',
        'delimiter': '\t',
        'encoding': 'utf-8',
        'dflt': None,
        'col': 0
    }

    expected_result = 'b1'
    lookup_module = LookupModule()
    result = lookup_module.read_csv(**params)

    assert result == expected_result



# Generated at 2022-06-25 10:27:06.169533
# Unit test for constructor of class CSVReader
def test_CSVReader():
    reader = CSVReader(open('csvfile/test.csv', 'rb'))
    return next(reader)


# Generated at 2022-06-25 10:27:15.608766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of arguments
    argspec = inspect.getfullargspec(LookupModule.run)
    argspec_dict = argspec.__dict__
    del argspec_dict['__kwdefaults__']
    args = mock.create_autospec(argspec)
    args.terms = 'test_terms'
    args.variables = 'test_variables'
    args_dict = deepcopy(args.__dict__)

    # Create an instance of LookupModule
    lookup_module_2 = LookupModule()

    # Use monkeypatch to mock the built in open function

# Generated at 2022-06-25 10:27:22.236802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Replace with your test code
    lookup_module_1 = LookupModule()

    terms_2 = ["key_3"]
    ret_4 = lookup_module_1.run(terms_2)

    # Check against expected result
    expected_result_5 = []
    assert ret_4 == expected_result_5


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-25 10:27:28.347319
# Unit test for constructor of class CSVReader
def test_CSVReader():
    test_file_path = '/Users/mingye/Documents/Projects/Ansible/PythonPlaybook/test_file'
    test_file_name = 'test.csv'
    test_file_full_path = test_file_path + '/' + test_file_name

    f = open(test_file_full_path, 'rb')
    csv_reader = CSVReader(f)
    print(csv_reader)


# Generated at 2022-06-25 10:27:30.431375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run("one_line")
    lookup_module.run("Multi-word string")


# Generated at 2022-06-25 10:27:36.131050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    if PY2:
        lookupfile_0 = open(b'ansible.csv', 'rb')
    else:
        lookupfile_0 = open('ansible.csv', 'rb')
    creader_0 = CSVReader(lookupfile_0, delimiter='tab', encoding='utf-8')
    run_0 = lookup_module_0.run('some_task_0', creader_0)
    return run_0

# Generated at 2022-06-25 10:27:37.249511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run('user')

# Generated at 2022-06-25 10:27:42.864026
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    with open("file_0", "w") as fileH:
        fileH.write("key_0 key_1 key_2 key_3\n")
        fileH.write("val_00 val_01 val_02 val_03\n")
        fileH.write("val_10 val_11 val_12 val_13\n")
        fileH.write("val_20 val_21 val_22 val_23\n")
        fileH.write("val_30 val_31 val_32 val_33\n")

# Test(s) for class LookupModule

# Generated at 2022-06-25 10:27:50.690787
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    print('Testing read_csv')
    lookup_module_0 = LookupModule()
    assert lookup_module_0.read_csv('test_files/test.csv', '0', 'TAB', 'utf-8', '1', '3') == '3'
    assert lookup_module_0.read_csv('test_files/test.csv', '0', 'TAB', 'utf-8', '2', '3') == '2'


# Generated at 2022-06-25 10:27:55.509314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    test_run = lookup_module_obj.run(terms=["key1","key2"],variables=None, file="file_name",encoding='utf-8',delimiter="delimiter_value")
    assert len(test_run) == 2
    assert test_run[0] == 'value1'
    assert test_run[1] == 'value2'


# Generated at 2022-06-25 10:29:10.757543
# Unit test for constructor of class CSVReader
def test_CSVReader():
    #Reads the csvfile and returns the file
    reader = CSVReader(open('csvfile.py', 'rb'))
    reader.__init__(open('csvfile.py', 'rb'), delimiter=',', encoding='utf-8')


# Generated at 2022-06-25 10:29:13.385304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    try:
        lookup_module.run(['test'])
    except Exception as e:
        assert(str(e) == "Search key is required but was not found")

# Generated at 2022-06-25 10:29:17.365854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["one"]
    variables_0 = {'language': 'Python'}
    kwargs_0 = {"author": "Ansible Core Team"}
    r = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    print(r)
    assert r == ['one']

# Generated at 2022-06-25 10:29:19.602628
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module = LookupModule()
    ret_value = lookup_module.read_csv("test_file.csv", "key", ",", "utf-8")
    assert ret_value == "value"


# Generated at 2022-06-25 10:29:25.754717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = '''
    lines:
        -   key: "test_case"
            _raw_params: "test"
            delimiter: ","
            col: 1
            file: "./test.csv"
    '''
    terms = [{'_raw_params': 'test', 'delimiter': ',', 'col': '1', 'file': './test.csv'}]
    variables = {}
    paramvals = {'file': 'ansible.csv', 'col': '1', 'default': None, 'delimiter': 'TAB'}
    parameters = {'file': './test.csv', 'col': '1', 'delimiter': ','}
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables) == ['match']
    assert lookup_module.run

# Generated at 2022-06-25 10:29:31.084026
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup_module = LookupModule()
    lookup_module_file = lookup_module.find_file_in_search_path(None, 'files', 'test_data.csv')
    assert type(lookup_module.read_csv(lookup_module_file, 'test-1', ',')) is str
    assert type(lookup_module.read_csv(lookup_module_file, 'test-3', ',')) is str
    assert type(lookup_module.read_csv(lookup_module_file, 'test-3', ',')) is str


# Generated at 2022-06-25 10:29:34.157257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert [] != lookup_module_0.run(terms=['test-case-0'], variables=dict())


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:29:35.725584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Assert no error occurs if the paramvals have no key 'default'
    assert LookupModule.run(kwargs={'paramvals':{'file':'test'}})

# Generated at 2022-06-25 10:29:40.096808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Unit test for method run of class LookupModule')
    LookupModule_run('test/unit_test_data/test_csvfile_LookupModule/csv_file_for_testing.csv', '', '', '', '', '', '')


# Generated at 2022-06-25 10:29:41.664121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run() == 'None'
