

# Generated at 2022-06-21 05:43:09.824087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile
    from ansible.utils.vars import combine_vars

    fp = tempfile.NamedTemporaryFile(mode='w+t')
    fp.write(u'''key1,val1,val2
key2,val3,val4
''')
    fp.seek(0)

    lookup = LookupModule()
    variables = combine_vars(dict(ansible_csv_file=fp.name))
    result = lookup.run([u'key1'], variables)
    assert result == [u'val1']
    result = lookup.run([u'key1'], variables, col=2)
    assert result == [u'val2']
    result = lookup.run([u'key2'], variables)
    assert result == [u'val3']

# Generated at 2022-06-21 05:43:10.281965
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 05:43:14.651467
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    reader = CSVReader(iter(['1,2,3\n']), delimiter=',')
    assert reader.__next__() == ['1', '2', '3']



# Generated at 2022-06-21 05:43:26.180084
# Unit test for method __iter__ of class CSVReader
def test_CSVReader___iter__():

    # read a input data by CSVReader
    csvreader = CSVReader(['a,b,c\nd,e,f'])

    # run the iter() method of CSVReader
    for row in csvreader:
        # assert the result of csvreader iter method
        assert row[0] == 'a'
        assert row[1] == 'b'
        assert row[2] == 'c'

    # run the iter() method of CSVReader
    for row in csvreader:
        # assert the result of csvreader iter method
        assert row[0] == 'd'
        assert row[1] == 'e'
        assert row[2] == 'f'

# Generated at 2022-06-21 05:43:29.403521
# Unit test for constructor of class CSVRecoder
def test_CSVRecoder():
    recoder = CSVRecoder('test')
    assert isinstance(recoder, CSVRecoder)

# Generated at 2022-06-21 05:43:35.632657
# Unit test for constructor of class CSVRecoder
def test_CSVRecoder():
    from io import StringIO
    import unittest

    class TestCSVRecoder(unittest.TestCase):
        def setUp(self):
            self.s = u"hello world"
            self.io = StringIO(self.s)

        def tearDown(self):
            pass

        def test_constructor(self):
            f = CSVRecoder(self.io)
            #f.__init__()
            self.assertTrue(f.reader)
            self.assertEqual(f.reader.encoding, 'utf-8')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestCSVRecoder)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 05:43:44.134942
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from collections import namedtuple
    from io import StringIO
    lookup = LookupModule()
    f = StringIO("1,2,3,4\n5,6,7,8")
    assert lookup.read_csv(f, '1', ',') == '2'
    f = StringIO("1,2,3,4\n5,6,7,8")
    assert lookup.read_csv(f, '5', ',') == '6'
    f = StringIO("1,2,3,4\n5,6,7,8")
    assert lookup.read_csv(f, '1', ',') == '2'

# Generated at 2022-06-21 05:43:54.987782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    import tempfile
    import unittest

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file_path = os.path.join(self.test_dir, 'test.csv')
            self.csv_contents = u"key,value\nfoo,foo_value\nbar,bar_value"
            with open(self.test_file_path, 'w') as f:
                f.write(self.csv_contents)

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_read_key_value(self):
            lookup = LookupModule()
            expected = u'bar_value'

# Generated at 2022-06-21 05:44:04.672323
# Unit test for method __iter__ of class CSVRecoder
def test_CSVRecoder___iter__():
    import io
    from csvfile import CSVRecoder
    f = io.StringIO("""key,"value"
apple,Y
banana,N
""")
    recoder = CSVRecoder(f, encoding='utf-8')
    for i, s in enumerate(recoder):
        assert type(s) == bytes
        if i == 0:
            assert s == b'"key","value"\r\n'
        elif i == 1:
            assert s == b'apple,Y\r\n'
        elif i == 2:
            assert s == b'banana,N\r\n'


# Generated at 2022-06-21 05:44:11.956483
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    path = os.path.join(os.path.dirname(__file__), 'lookup_plugins')
    sys.path.insert(0, path)

    from csvfile import LookupModule

    # Create ansible var
    csv_str = "a,b\n1,2"
    inventory_file = '/tmp/test.csv'
    open(inventory_file, "w").write(csv_str)


# Generated at 2022-06-21 05:44:18.388486
# Unit test for constructor of class LookupModule
def test_LookupModule():
    csvfile_lookup_class = LookupModule()
    assert csvfile_lookup_class is not None


# Generated at 2022-06-21 05:44:30.091063
# Unit test for method __iter__ of class CSVReader
def test_CSVReader___iter__():
    # TODO(laggardkernel) There should be a simpler way to produce this edge case
    with open('test_CSVReader___iter__.csv', 'w') as f:
        def line_generator():
            yield b"\xE4"
            yield b'\n'
        f.writelines(line_generator())
    # CSVReader needs the file handle to be in binary mode
    with open('test_CSVReader___iter__.csv', 'rb') as f:
        reader = CSVReader(f)
        for row in reader:
            assert row[0] == u'ä'


# Generated at 2022-06-21 05:44:35.944150
# Unit test for method __iter__ of class CSVRecoder
def test_CSVRecoder___iter__():

    inputstream = ['abc', 'def', 'ghi']
    encstream = [u'abc', u'def', u'ghi']

    f = CSVRecoder(iter(inputstream), encoding='ascii')
    assert list(f) == encstream


# Generated at 2022-06-21 05:44:43.844843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.plugins.lookup.csvfile import LookupModule
    lookup_plugin = LookupModule()
    basedir = os.path.dirname(os.path.realpath(__file__))
    fixtures = os.path.join(basedir, 'fixtures', 'lookup_plugins')
    terms = [
        'foo',
        'bar',
    ]
    variables = [
        'file=' + os.path.join(fixtures, 'test.csv'),
        'delimiter=$',
        'encoding=utf-8',
    ]
    results = lookup_plugin.run(terms, variables)
    assert results == [
        '1',
        '2',
    ]

# Generated at 2022-06-21 05:44:54.238534
# Unit test for method __iter__ of class CSVReader
def test_CSVReader___iter__():
    if PY2:
        from StringIO import StringIO
        from StringIO import StringIO
    else:
        from io import StringIO

    csv_str = StringIO('a,b,c\n"a,b",c,d\n')

    creader = CSVReader(csv_str)

    assert next(creader) == ['a', 'b', 'c']
    assert next(creader) == ['a,b', 'c', 'd']

# Generated at 2022-06-21 05:45:02.205636
# Unit test for method __next__ of class CSVRecoder
def test_CSVRecoder___next__():
    # This test should handle non-string types as input
    delimiter = ','
    encoding = 'utf-8'
    f = 'testdata/test_CSVReader.csv'
    expected = [u'column1', u'column2', u'column3']
    fmt = '%s' + delimiter + '%s' + delimiter + '%s\n'
    data = [
        (123, 1.23, True),
        (456, 4.56, False)
    ]

# Generated at 2022-06-21 05:45:15.517510
# Unit test for constructor of class CSVReader
def test_CSVReader():
    if PY2:
        f = open('asciistuff', 'r')
        creader = CSVReader(f, delimiter=' ', encoding='ascii')
        for row in creader:
            print(row)
            if len(row) and row[0] == 'c':
                assert(row[1] == 'd')
                assert(row[2] == 'e')
                return
        assert(False)
    else:
        f = open('asciistuff', 'r')
        creader = CSVReader(f, delimiter=' ', encoding='ascii')
        for row in creader:
            print(row)
            if len(row) and row[0] == 'c':
                assert(row[1] == 'd')
                assert(row[2] == 'e')
                return


# Generated at 2022-06-21 05:45:19.017193
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 05:45:28.040313
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    """
    Test method __next__ of class CSVReader
    """

    tests = [
        {
            'f': 'Li\t3\nBe\t4',
            'dialect': csv.excel,
            'encoding': 'ascii',
            'kwds': {},
            'result': [['Li', '3'], ['Be', '4']],
        },
        {
            'f': 'Li\t3\nBe\t4',
            'dialect': csv.excel_tab,
            'encoding': 'ascii',
            'kwds': {},
            'result': [['Li', '3'], ['Be', '4']],
        },
    ]

    for test in tests:
        f = six.StringIO(test['f'])
        creader

# Generated at 2022-06-21 05:45:35.078185
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    # stream where columns are separated by a non standard delimiter
    stream = 'a|b|c\n1|2|3\n2|3|4\n'

    f = open(to_bytes(filename), 'rb')
    creader = CSVReader(f, delimiter=to_native('|'))

    assert creader.__next__() == ['a', 'b', 'c']
    assert creader.__next__() == ['1', '2', '3']
    assert creader.__next__() == ['2', '3', '4']

# Generated at 2022-06-21 05:45:46.173249
# Unit test for method __iter__ of class CSVReader
def test_CSVReader___iter__():

    with open('unit_test_data.csv', 'r') as f:
        creader = CSVReader(f, delimiter=',')

        result = [ ]
        for row in creader:
            result.append(row)

        assert result == [
            [u'wordA', u'wordB', u'wordC'],
            [u'1', u'2', u'3'],
            [u'4', u'5', u'6'],
            [u'7', u'8', u'9'],
            [u'10', u'11', u'12'],
        ]

# Generated at 2022-06-21 05:45:58.521630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyVars(dict):
        def __init__(self):
            dict.__init__(self)
            self['ansible_syslog_facility'] = 'daemon'
    class ModuleDummy():
        def __init__(self):
            self.params = {}
            self.params['listkeys'] = False
            self.params['extended'] = False
            self.params['convert_data'] = True
    class RunnerDummy():
        #
        # The trick: all those lookups are registered in the
        # pexpect_runner._lookup_plugins dict. This dict is used to
        # lookup the correct lookup plugin.
        #
        def __init__(self):
            pass
        def _plugins(self):
            self.lookup_plugins = {}

# Generated at 2022-06-21 05:46:08.269012
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():

    # Test input data
    f = to_bytes("a,b,c\nd,e,f\ng,h,i", encoding='utf-8')

    # CSVReader initialization
    creader = CSVReader(f)

    # csv.reader usage
    reader = csv.reader(f.splitlines())

    # Assert results
    for i in range(0, 2):
        assert next(creader) == next(reader)

    # Assert exception for bad input data
    # creader = CSVReader(f, delimiter=';')
    # creader.next()

# Generated at 2022-06-21 05:46:10.254753
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run([], variables=None, **{})

# Generated at 2022-06-21 05:46:21.153831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1 (read entry in a csv file)
    terms = ['jpmens']
    variables = {'csvfile_file': '../../lookup_plugins/test/test.csv', 'csvfile_default': 'not_found', 'csvfile_delimiter': ','}
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, variables=variables, col='1')
    assert result == ['Gent, Belgium']

    # Test 2 (read entry in a csv file with a default set)
    terms = ['unknown']
    variables = {'csvfile_file': '../../lookup_plugins/test/test.csv', 'csvfile_default': 'not_found', 'csvfile_delimiter': ','}

# Generated at 2022-06-21 05:46:27.890714
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create dictionary in 'module_utils/csv_lookup.py'
    terms = 'test1'
    variables = None
    kwargs = {'file':'test_csv', 'delimiter':":", 'col':1}

    # Create a test object
    obj = LookupModule()
    obj.run(terms, variables, **kwargs)

# Generated at 2022-06-21 05:46:30.630262
# Unit test for method __next__ of class CSVRecoder
def test_CSVRecoder___next__():
    f = open('test_data.csv', 'r')
    creader = CSVRecoder(f)
    assert creader.__next__() == b'Li,3,6.941\n'

# Generated at 2022-06-21 05:46:39.639310
# Unit test for constructor of class CSVReader
def test_CSVReader():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    # Open one file for test
    with patch('io.open', create=True) as mock_file:
        mock_file.return_value = MagicMock(spec=file)
        mock_file.return_value.__iter__.return_value = ['first_column,second_column\n',
            '1,2\n']
        mock_file.return_value.__enter__.return_value = mock_file.return_value

        reader = CSVReader(mock_file.return_value)
        result = reader.__next__()
        assert result == ['first_column', 'second_column']
        result = reader.__next__()

# Generated at 2022-06-21 05:46:47.870380
# Unit test for method __next__ of class CSVRecoder
def test_CSVRecoder___next__():
    from ansible.plugins.lookup.csvfile import CSVRecoder

    f = open('test_CSVRecoder___next__.csv', 'w')
    f.write('abc def\nghi jkl\n')
    f.close()

    recoder = CSVRecoder(open('test_CSVRecoder___next__.csv', 'rb'))
    assert next(recoder) == b'abc def\n'
    assert next(recoder) == b'ghi jkl\n'


# Generated at 2022-06-21 05:47:01.733537
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.read_csv(lookup_module.find_file_in_search_path(None, 'files', "elements.csv"), "Li", "\t") == " 3"
    assert lookup_module.read_csv(lookup_module.find_file_in_search_path(None, 'files', "elements.csv"), "Li", "\t", 2) == " 6.941"

    test = "Li\t3\t6.941\tLithium\t1s2 2s1\talkali metal"
    assert test.split() == lookup_module.read_csv(lookup_module.find_file_in_search_path(None, 'files', "elements.csv"), "Li", "\t", col=0).split()

# Generated at 2022-06-21 05:47:13.663075
# Unit test for constructor of class CSVReader
def test_CSVReader():
    if PY2:
        # Running under Python 2.
        import io
        fp = io.TextIOWrapper(io.BytesIO("""one,two,three
a,b,c
aa,bb,cc""".encode("utf-8")))
    else:
        # Running under Python 3.
        fp = open("/dev/null", "r", encoding="utf-8")
    reader = CSVReader(fp)
    assert ['one', 'two', 'three'] == next(reader)
    assert ['a', 'b', 'c'] == next(reader)
    assert ['aa', 'bb', 'cc'] == next(reader)

# Generated at 2022-06-21 05:47:20.429266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    import sys, os
    import tempfile
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import shutil
    lookup_args = dict(file='test.csv', delimiter='\t', default='default', encodinf='utf-8', col='1')


# Generated at 2022-06-21 05:47:33.614592
# Unit test for method read_csv of class LookupModule

# Generated at 2022-06-21 05:47:36.123292
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    test_csv = 'foo,bar\n1,2\n3,4'
    test_csv_file = LookupModule.read_csv(None, test_csv, '1', dflt=None, col=1)
    assert test_csv_file == '2'

# Generated at 2022-06-21 05:47:41.965474
# Unit test for method __next__ of class CSVRecoder
def test_CSVRecoder___next__():
    from io import StringIO
    test_string = "test"
    test_file = StringIO(test_string)
    recoder = CSVRecoder(test_file)
    assert next(recoder) == to_bytes(test_string)


# Generated at 2022-06-21 05:47:53.839034
# Unit test for method __next__ of class CSVRecoder
def test_CSVRecoder___next__():
    # Create CSVRecoder object and get the iterator on it
    f = open('./test.csv', 'rb')
    creader = CSVRecoder(f)
    it = iter(creader)

    # Get one item from iterator
    item = next(it)
    assert item == b'my_key\tmessage\n'

    # Get second item from iterator
    item = next(it)
    assert item == b'mykey\tmyvalue\n'

    # Get third item from iterator
    item = next(it)
    assert item == b'mykey2\tmyvalue2\n'

    # Get fourth item from iterator
    item = next(it)
    assert item == b'my_key3\tmy_value3\n'

# Generated at 2022-06-21 05:48:00.347916
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    import io
    f = io.StringIO(u'1\n2\n3')
    f.seek(0)
    obj = CSVReader(f)

    next(obj)
    next(obj)
    next(obj)

    f.close()


# Generated at 2022-06-21 05:48:04.751059
# Unit test for constructor of class CSVRecoder
def test_CSVRecoder():
    import io
    recoder = CSVRecoder(io.StringIO('this is a test'), encoding='latin-1')
    recoder_list = list(recoder)
    assert recoder_list == [b'this is a test']

# Generated at 2022-06-21 05:48:15.908931
# Unit test for method __iter__ of class CSVRecoder
def test_CSVRecoder___iter__():
    import codecs
    from io import StringIO
    from ansible.plugins.lookup.csvfile import CSVRecoder

    sio = StringIO(u'test1,test2')
    csv_recoder = CSVRecoder(sio, encoding='utf-8')

    assert isinstance(csv_recoder.reader, codecs.StreamReader)
    assert isinstance(csv_recoder, CSVRecoder)

    assert isinstance(csv_recoder.__next__(), str)
    assert isinstance(csv_recoder.next(), str)


# Generated at 2022-06-21 05:48:27.143694
# Unit test for method __iter__ of class CSVRecoder
def test_CSVRecoder___iter__():
    from io import BytesIO
    import sys
    if sys.version_info >= (3, 0):
        f = BytesIO(b"\xc3\xab\xc2\xbb")
    else:
        f = BytesIO(b"\xc3\xab\xc2\xbb")
    csv = CSVRecoder(f)
    s = ""
    for c in csv:
        s += c
    assert(s == b"\xef\xbb\xbf\xc3\xab\xc2\xbb")



# Generated at 2022-06-21 05:48:48.802856
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test result for key 'Li' using 'elements.csv' file
    test_file = open('./test/unit/files/elements.csv', 'rb')
    creader = CSVReader(test_file, delimiter=",")
    for row in creader:
        if len(row) and row[0] == "Li":
            test_result_elem_Li = row[1]
            break

    # Test result for key 'B' using 'elements.csv' file
    test_file = open('./test/unit/files/elements.csv', 'rb')
    creader = CSVReader(test_file, delimiter=",")
    for row in creader:
        if len(row) and row[0] == "B":
            test_result_elem_B = row[1]


# Generated at 2022-06-21 05:48:55.911438
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class RunResults(object):
        def __init__(self, results):
            self.results = results
            self.exception_msg = ''
            self.traceback = None

    class Runner(object):
        def __init__(self, results):
            self.results = results

        def run(self, terms, variables=None, **kwargs):
            try:
                return self.results.results
            except Exception as e:
                self.results.exception_msg = to_native(e)

    test = LookupModule()

# Generated at 2022-06-21 05:49:08.118854
# Unit test for method __next__ of class CSVRecoder
def test_CSVRecoder___next__():
    # build stream with utf-8 data
    stream = codecs.open('tests/test_data/test_data_utf8.csv', 'r', 'utf-8')
    # build CSVRecoder object
    recoder = CSVRecoder(stream)
    # call __next__ method and check value
    data = recoder.__next__()
    # utf-8 is the default encoding, so data must be equal to the
    # content of the read file
    assert data == 'utf8,\xc3\xa4\xc3\xb6\xc3\xbc\xc3\x84\xc3\x96\xc3\x9c\n'


# Generated at 2022-06-21 05:49:20.325755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return_null_term = LookupModule()
    return_null_terms = LookupModule()
    return_null_paramvals = LookupModule()
    return_value_column_1_of_file_elements_csv = LookupModule()
    return_value_column_2_of_file_elements_csv = LookupModule()
    return_value_column_1_of_file_bgp_neighbors_csv = LookupModule()

    terms = []

    terms.append('Li')
    terms.append('H')
    terms.append('Li H')

    paramvals = {'col': ['1'], 'default': [None], 'delimiter': [u'TAB'], 'file': ['elements.csv'], 'encoding': ['utf-8']}

    test_func_elements_

# Generated at 2022-06-21 05:49:31.762136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit test for the method run of class LookupModule '''
    # Initialize a LookupModule object
    test_lookup_module = LookupModule()
    # Initialize a list of test terms
    test_terms = ['key1', 'key2']
    # Initialize a list of test variables
    test_variables = {'ANSIBLE_LOOKUP_PLUGINS': '/home/myuser/.ansible/plugins/lookup',
                      'col': 1,
                      'delimiter': 'TAB',
                      'file': 'test_file.csv',
                      'encoding': 'utf-8',
                      'default': 'default'}
    # Initialize a list of test kwargs
    test_kwargs = {}
    # Call the run method of the LookupModule class and save as a list of variables
   

# Generated at 2022-06-21 05:49:43.001713
# Unit test for method __iter__ of class CSVReader
def test_CSVReader___iter__():
    import io
    import ansible.plugins.lookup.csvfile

    # test_tuples is the list of test tuples.
    # Each test tuple has following elements:
    #     0. string to be passed as 'f' to CSVReader constructor
    #     1. expected value of 'reader' attribute
    #     2. expected value of 'iter' attribute

# Generated at 2022-06-21 05:49:44.509956
# Unit test for constructor of class LookupModule
def test_LookupModule():

    l = LookupModule()


# Generated at 2022-06-21 05:49:55.438735
# Unit test for method read_csv of class LookupModule
def test_LookupModule_read_csv():
    lookup = LookupModule()

    # file is empty and the key is empty
    assert lookup.read_csv('tests/files/empty.csv', '', ',') == None

    # file is empty and the key is not empty
    assert lookup.read_csv('tests/files/empty.csv', 'c', ',') == None

    # file is not empty and the key is empty
    assert lookup.read_csv('tests/files/test.csv', '', ',') == None

    # file is not empty and the key is not empty
    assert lookup.read_csv('tests/files/test.csv', 'a', ',') == None

    # file is not empty, the key is not empty and the key is found
    assert lookup.read_csv('tests/files/test.csv', 'a', ',') == None


# Generated at 2022-06-21 05:50:01.045759
# Unit test for constructor of class CSVRecoder
def test_CSVRecoder():
    # construct a fake file with the content
    in_str = "1,2,3\n4,5,6\n"
    in_file = to_bytes(in_str)

    # create a StringIO to handle the String
    if PY2:
        import StringIO
        fp = StringIO.StringIO(in_file)
    else:
        from io import StringIO
        fp = StringIO(in_file.decode())

    csv_reader = CSVRecoder(fp, encoding="ascii")
    line = next(csv_reader)
    assert line == to_bytes("1,2,3\n"), "read line 1: '%s'" % line
    line = next(csv_reader)

# Generated at 2022-06-21 05:50:08.383844
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Currently, common test runs this file for all Lookup plugins,
    # but CSV format file is unique for CSV plugin.
    # So, just return from other platform.
    if not LookupBase.lookup_type == 'csvfile':
        return

    module = LookupModule()

    # Prepare file
    #  -- elements.csv --
    # name, atomic number, atomic mass,category
    # Hydrogen, 1, 1.00794, nonmetal
    # Helium, 2, 4.002602, noble gas
    # Lithium, 3, 6.941, alkali metal
    # Beryllium, 4, 9.012182, alkaline earth metal

    # Run test
    # elements.csv file is located in same directory of this file.
    # In the test, current directory of running test process is tests/lib/
   

# Generated at 2022-06-21 05:50:32.067728
# Unit test for method __iter__ of class CSVRecoder
def test_CSVRecoder___iter__():
    s = 'a\nb\nc\n'
    f = io.StringIO(s)
    csv_recoder = CSVRecoder(f)
    reader = csv.reader(csv_recoder)
    row1 = next(reader)
    row2 = next(reader)
    row3 = next(reader)
    row4 = next(reader)
    
    assert(row1 == ['a'])
    assert(row2 == ['b'])
    assert(row3 == ['c'])
    assert(row4 == None)
    

# Generated at 2022-06-21 05:50:45.371366
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    import os

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    test_file = os.path.join(os.path.dirname(__file__), '../../../', 'test/units/module_utils/test_csv.tsv')
    variable_manager.extra_vars = {'ansible_csv_file_path': os.path.dirname(test_file)}


# Generated at 2022-06-21 05:50:54.558654
# Unit test for method __iter__ of class CSVReader
def test_CSVReader___iter__():

    class CSVReader_mock():

        def __init__(self, f, dialect=csv.excel, encoding='utf-8', **kwds):
            pass

        def __next__(self):
            return ["42", "21"]

        next = __next__  # For Python 2

    reader = CSVReader(True, dialect=csv.excel, encoding='utf-8')
    reader.reader = CSVReader_mock(True, dialect=csv.excel, encoding='utf-8')
    assert list(reader) == [["42", "21"]]

# Generated at 2022-06-21 05:50:57.359122
# Unit test for constructor of class CSVReader
def test_CSVReader():
    import io
    f = io.StringIO("test1\ttest2\ntest3\ttest4")
    dialect=csv.excel
    reader = CSVReader(f, dialect)
    for row in reader:
        assert row == ['test1', 'test2']
        break

# Generated at 2022-06-21 05:50:58.386192
# Unit test for method __iter__ of class CSVRecoder
def test_CSVRecoder___iter__():
    recoder = CSVRecoder(True)
    assert recoder.__iter__() == recoder


# Generated at 2022-06-21 05:51:05.892638
# Unit test for constructor of class CSVRecoder
def test_CSVRecoder():
    import io
    sample = io.StringIO(u"Column1,Column2,Column3\nRow1,Value1,Value2")
    csvfile = CSVRecoder(sample, encoding='utf-8')
    next(csvfile)
    next(csvfile)
    row_one = next(csvfile)
    assert row_one == b'Row1,Value1,Value2'

# Generated at 2022-06-21 05:51:19.130894
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Parameter list for LookupModule.run
    term_tests = []

    # Test 1 : one file as parameter
    term1 = dict(
        search='one',
        file='one_file.csv',
        delimiter=';',
        col='1',
        default='default',
        test_str='file_name=one_file.csv delimiter=; col=1 default=default'
    )
    term_tests.append(term1)

    # Test 2 : two files as parameter

# Generated at 2022-06-21 05:51:25.787584
# Unit test for method __next__ of class CSVRecoder
def test_CSVRecoder___next__():
    from cStringIO import StringIO
    import sys
    if sys.version_info < (3, 0):
        # Nothing to test in Python 2
        return

    f = StringIO(u'\n')
    r = CSVRecoder(f)
    result = next(r)
    assert result == b''



# Generated at 2022-06-21 05:51:27.997931
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.run([],{})



# Generated at 2022-06-21 05:51:37.696109
# Unit test for method __next__ of class CSVRecoder
def test_CSVRecoder___next__():
    from io import StringIO
    from ansible.module_utils._text import to_text
    result1 = CSVRecoder(StringIO('abc\nabc\\nabc\nabc\tdef\nabc\tdef\tghi'), 'ascii').__next__()
    result2 = CSVRecoder(StringIO('abc\nabc\\nabc\nabc\tdef\nabc\tdef\tghi'), 'utf-8').__next__()
    assert result1 == to_bytes('abc\n')
    assert result2 == to_bytes('abc\n')


# Generated at 2022-06-21 05:52:22.681260
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    import io
    import mock
    import sys

    f = io.StringIO(u'a,"b","c","d",e\n"f","g","h","i",j\n')

    creader = CSVReader(f, encoding='utf-8')
    creader.reader = mock.Mock(return_value=['a', '"b"', '"c"', '"d"', 'e'])

    assert creader.__next__() == ['a', '"b"', '"c"', '"d"', 'e']
    assert creader.__next__() == ['a', 'b', 'c', 'd', 'e']


# Generated at 2022-06-21 05:52:32.242786
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    import io

    # test with Python 3
    if not PY2:
        fp = io.StringIO('a!b!c\nd!e!f\ng!h!i\n')

        def testcase_1():
            """CSVReader should decode string in input stream."""
            creader = CSVReader(fp, delimiter='!')

            exp = ['a', 'b', 'c']
            act = next(creader)

            assert type(act[0]) == str
            assert act == exp

        def testcase_2():
            """CSVReader should ignore Unicode BOM in input stream."""
            fp.seek(0)
            fp.write('\ufeffa!b!c\nd!e!f\ng!h!i\n')
            fp.seek(0)

            exp

# Generated at 2022-06-21 05:52:43.077457
# Unit test for method __next__ of class CSVReader
def test_CSVReader___next__():
    # pylint: disable=import-error,attribute-defined-outside-init
    from io import BytesIO
    import sys

    # Test with file for Python 2
    if PY2:
        reader_file = BytesIO(b'1,2,3,4\n"a","b","c","d"\n')
    else:
        reader_file = BytesIO(b'1,2,3,4\r\n"a","b","c","d"\r\n')
    csv_reader = CSVReader(reader_file)
    assert [u'1', u'2', u'3', u'4'] == csv_reader.__next__()
    assert [u'a', u'b', u'c', u'd'] == csv_reader.__next__()

    # Test with

# Generated at 2022-06-21 05:52:53.046621
# Unit test for method __next__ of class CSVRecoder
def test_CSVRecoder___next__():
    import io
    import sys
    import codecs
    if sys.version_info[0] == 2:
        # Python 2
        old_stdin = sys.stdin
        try:
            # sys.stdin = io.StringIO(unicode('a,b\n1,2','utf-8'))
            sys.stdin = codecs.getreader('utf-8')(io.BytesIO(b'a,b\n1,2'))
            cr = CSVRecoder(sys.stdin)
            assert next(cr) == b'a,b'
            assert next(cr) == b'1,2'
        finally:
            sys.stdin = old_stdin
