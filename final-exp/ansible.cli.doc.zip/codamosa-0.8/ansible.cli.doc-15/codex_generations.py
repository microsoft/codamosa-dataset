

# Generated at 2022-06-10 22:11:50.785337
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.module_utils import basic

    # noinspection PyTypeChecker
    class FakeModule(object):
        def __init__(self):
            self.argument_spec = {}

        def run_command(self, args, check_rc=True):
            return 0, '', ''

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            pass

    m = FakeModule()
    # noinspection PyTypeChecker
    if not hasattr(basic, 'AnsibleModule'):
        setattr(basic, 'AnsibleModule', FakeModule)

    args = {}
    doc = DocCLI.format_plugin_doc(m, 'test_module', args, False)
    assert doc is not None, "Failed to parse test doc"

# Generated at 2022-06-10 22:12:02.137710
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
  DocCLI_obj = DocCLI(context=None)
  test_cases = [{"mock_path": "/path/to/module", "mock_name": "module_name", "mock_doc": "module documentation", "expected": {"filename": "/path/to/module/module_name", "doc": "module documentation"}}]

# Generated at 2022-06-10 22:12:13.257185
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc_cli = DocCLI()
    display_plugin_list = doc_cli.display_plugin_list
    items = ['action', 'aggregator', 'callbacks', 'cache', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'module', 'netconf', 'shell', 'strategy', 'terminal', 'test', 'vars']
    assert display_plugin_list(items) == "The valid plugin types are: action, aggregator, callbacks, cache, cliconf, connection, httpapi, inventory, lookup, module, netconf, shell, strategy, terminal, test and vars."
    items = ['action', 'aggregator', 'callbacks', 'cache', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'module']
    assert display_plugin_list(items)

# Generated at 2022-06-10 22:12:28.056669
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    import json
    import os
    import glob

    module_name = 'command'
    plugin_name = module_name
    plugin_type = 'module'
    plugin_json = {module_name: {'name': module_name, 'filename': plugin_name}}
    plugin_doc = {
        'description': "description",
        'version_added': "version_added",
        'options': {"state": {"default": "present", "description": "description", "choices": ["present", "absent", "latest"], "type": "str"}}}
    plugin_json[module_name]['doc'] = plugin_doc

    # To run on the local machine, set this to the directory containing ansible/base/plugins/module
    #plugin_root = os.path.join(os.path.dirname(os.path.dirname

# Generated at 2022-06-10 22:12:31.869127
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    from ansible.cli.doc import DocCLI
    assert DocCLI.format_snippet(dict(A="A", B="B")) == "A=A B=B"


# Generated at 2022-06-10 22:12:32.948205
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    assert True

# Generated at 2022-06-10 22:12:46.372004
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    TESTCASE = [
        'foo/bar/baz/test_plugin.py',
        'foo/bar/baz/test_plugin.py',
        'foo/bar/baz/test_plugin.py',
        'foo/bar/baz/test_plugin.py',
    ]
    EXPECT = [
        'ansible.collections.bar.baz.test_plugin',
        'ansible.collections.foo.bar.baz.test_plugin',
        'ansible.collections.foo.bar.baz.test_plugin',
        'ansible.collections.foo.bar.baz.test_plugin',
    ]
    plugin_loaders = []

# Generated at 2022-06-10 22:12:54.170956
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    from ansible.utils.display import Display
    display = Display()
    context._init_global_context(cliargs={})

    cli = DocCLI(None, None)
    cli.get_plugin_metadata(display)

    assert(cli.plugin_type == u'')
    assert(cli.collection_name == u'')

    try:
        cli.get_plugin_metadata(display, 'module_utils', 'test_module_utils')
    except (SystemExit, AnsibleError) as e:
        pass

    assert(cli.plugin_type == u'module_utils')
    assert(cli.collection_name == u'test_module_utils')


# Generated at 2022-06-10 22:12:55.889850
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.plugins.loader import module_loader
    DocCLI.format_plugin_doc(module_loader.find_plugin('setup'), True, 'module', 'setup')

# Generated at 2022-06-10 22:12:59.122748
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    DocCLI = doc_fragments.DocCLI()
    assert DocCLI.get_plugin_metadata('/tmp/my_test_plugin.py')



# Generated at 2022-06-10 22:14:50.403156
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'action'
    coll_filter = 'ansible.builtin'
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list != {}



# Generated at 2022-06-10 22:14:53.243119
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    assert DocCLI.format_snippet("example") == "**EXAMPLES**\n\n  example"


# Generated at 2022-06-10 22:15:01.966308
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    import sys

    # Test with required arguments.
    text = []
    opt_indent = "        "
    limit = 70
    return_values = True
    option_indent = 6 * ' '
    opt = {'required': True, 'type': 'list', 'version_added': '==2.5', 'version_added_collection': 'community.general'}
    DocCLI.add_fields(text, opt, limit, option_indent, return_values, opt_indent)
    assert text == ['                  aliases: ', '                  choices: ', '                  default: (null)', '                  [Default: (null)]', '                  required: yes', '                  type: list', '                  added in: Ansible 2.5 (community.general)', ''], \
        "test_DocCLI_add_fields - Failed"

   

# Generated at 2022-06-10 22:15:08.685201
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-10 22:15:19.577597
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    MOCK_CLI_ARGS = dict(
        ref=False,
        type='module',
        connection='local',
        module='some_module',
        chunk_size=10,
        forks=10,
        verbosity=1,
        tags=[],
        skip_tags=[],
        subset='',
        limit='',
        extra_vars=[],
        syntax=False,
        diff=False,
        check=False,
        listhosts=False,
        listtags=False,
        listtasks=False,
        step=False,
        start_at_task=None,
    )


# Generated at 2022-06-10 22:15:32.339841
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 100
    DocCLI.add_fields(text, {'test': 'value'}, limit, '        ')
    assert text == ["        test: value"]
    text = []
    DocCLI.add_fields(text, {'test': 'value', 'test2': 'value2'}, limit, '        ')
    assert text == ["        test: value", "        test2: value2"]
    text = []
    DocCLI.add_fields(text, {'test': 'value', 'test2': 'value2', 'test3': {'version_added': '1.0', 'default': 'whatever'}}, limit, '        ')

# Generated at 2022-06-10 22:15:34.826333
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    """Test if all collections are added as plugins"""
    plugin_list = {}
    coll_filter = None
    plugin_type = 'lookup'
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert len(plugin_list) > 0



# Generated at 2022-06-10 22:15:37.192822
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    doc.get_all_plugins_of_type()
    return doc


# Generated at 2022-06-10 22:15:42.928310
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    ''' Test namespace_from_plugin_filepath method. '''
    CLI = DocCLI()
    result = CLI.namespace_from_plugin_filepath("/usr/lib/python2.7/site-packages/ansible_collections/ansible/os_ironic/plugins/modules/ironic_port.py")
    assert result == "os_ironic.plugins.modules"


# Generated at 2022-06-10 22:15:52.278093
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-10 22:16:50.906409
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # Given a plugin filepath
    plugin_filepath = "ansible/plugins/action/synchronize.py"

    # When I get the namespace from that filepath
    result = DocCLI.namespace_from_plugin_filepath(plugin_filepath)

    # Then I should get the expected namespace
    assert result == "action"

# Generated at 2022-06-10 22:16:52.792482
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    a = Doc()
    c = DocCLI()
    c.get_plugin_metadata(a)


# Generated at 2022-06-10 22:16:59.872152
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    assert DocCLI.tty_ify('\n') == ' '
    assert DocCLI.tty_ify('\n\n') == '  '
    assert DocCLI.tty_ify('module: name\nversion_added: groupname\n') == 'module: name  version_added: groupname  '
    assert DocCLI.tty_ify('module: name\nversion_added: groupname\n') == 'module: name  version_added: groupname  '


# Generated at 2022-06-10 22:17:09.520050
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
  text = []
  text.append("%s\n" % ("".center(display.columns, "=")))
  text.append("MODULE DOCS \n")
  text.append("%s\n" % "".center(display.columns, "-"))
  text.append("Use 'ansible-doc -t FILTER_TYPE MODULE_NAME' to view documentation.\n")
  text.append("User contributed modules are listed in red.\n")
  text.append("%s\n" % "".center(display.columns, "-"))

# Generated at 2022-06-10 22:17:11.777322
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    collection_dirs = ['test_dir']
    plugin_type = 'action'
    coll_filter = None
    plugin_list = {}
    DocCLI.find_plugins = Mock(return_value={'test_plugin': 'test_plugin_path'})
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list == {'test_plugin': 'test_plugin_path'}



# Generated at 2022-06-10 22:17:21.568662
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    import json
    import os

    # Capture 'ansible --version' in a variable
    nblock = ''
    with open(os.devnull, 'w') as fp:
        nblock = subprocess.check_output(["ansible --version"], stderr=fp).decode('utf-8')

    # This unittest is not supposed to run at python2, because it needs Python3's string fomatting
    if sys.version_info[0] < 3:
        print('This unittest is only used by Python3')
        return

    # The 'nblock' is supposed to be in the below format
    # ansible 2.9.1
    #   config file = /etc/ansible/ansible.cfg
    #   configured module search path = ['/home/david/.ansible/plugins/modules',

# Generated at 2022-06-10 22:17:25.718591
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    test_plugin_list = {'my_plugin': ('plugins/my_plugin', None)}
    test_plugin_type = 'lookup'
    test_coll_filter = 'test_collection*'
    add_collection_plugins(test_plugin_list, test_plugin_type, test_coll_filter)
    assert 'test_collection.my_plugin' in test_plugin_list

# Generated at 2022-06-10 22:17:34.652653
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Setup for unit test
    # Uncomment the next line and set the correct path for the test
    #DocCLI.COLLECTIONS_PATHS = ['/Users/rodrigues/Personal/ansible-2.7.0/lib/ansible/collections']
    DocCLI.COLLECTIONS_PATHS = ['/Users/rodrigues/Personal/ansible-2.7.0/lib/ansible/collections/ansible_collections/mycollection/mynetwork']
    # Run the unit test
    # Type of the plugin
    plugin_type = 'action'
    # Type of plugin to return
    out_type = 'module'
    loader, all_plugins, paths = DocCLI.get_all_plugins_of_type(plugin_type, out_type)

# Generated at 2022-06-10 22:17:44.388640
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
  try:
    import __builtin__ as builtins
  except ImportError:
    import builtins
  builtins.__dict__['_'] = lambda x: x

  doc_cli = DocCLI()
  doc_cli.display_plugin_list()
  text = ''
  text += '  Action plugins:'
  text += '\n    AGENT   Ansibles internal remote management system'
  text += '\n    ASYNC   Execute tasks asynchronously'
  text += '\n    BLOCKD  Shutdown the connection to a host, but allow to run'
  text += '\n            additional tasks on other hosts'
  text += '\n    CAPTURE Capture the output of a command'
  text += '\n    CLUSTER Manage a cluster of like hosts'

# Generated at 2022-06-10 22:17:55.494254
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    import os
    import tempfile

    c = DocCLI()
    c.options = context.CLIARGS

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary plugin directory to be searched
    plugdir = os.path.join(tmpdir, PLUGIN_PATH)
    os.mkdir(plugdir)

    # Create a text module plugin
    text_module_path = os.path.join(plugdir, "my_module.py")

# Generated at 2022-06-10 22:18:56.777111
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # TODO: Need to first write a test for the plugins.get_all_plugins_of_type() method
    pass

# Generated at 2022-06-10 22:19:07.354700
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    temp_config = tempfile.NamedTemporaryFile()