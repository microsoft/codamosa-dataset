

# Generated at 2022-06-10 22:11:11.181152
# Unit test for function jdump
def test_jdump():
    text = {'foo': 'bar'}
    jdump(text)
    assert json.loads(text)


# Generated at 2022-06-10 22:11:17.151104
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    import pytest

    # Test settings
    test_doc = {
        'description': 'This is the description',
        'version_added': '2.1',
        'options': 'This is the options',
        'seealso': 'This is the see also'
    }
    test_collection_name = 'test_collection_name'
    test_plugin_type = 'test_plugin_type'
    test_plugins_name = 'test_plugins_name'

    # Setup
    doc_cli = DocCLI()
    doc = Doc()

    # Test expections
    with pytest.raises(TypeError):
        # Test with unexpected type for param plugin_type
        doc_cli.get_man_text(doc, collection_name=test_collection_name, plugin_type=doc)

# Generated at 2022-06-10 22:11:23.720554
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    '''doccli_test_get_man_text
    '''
    doc_cli = DocCLI()
    plugin_type = 'plugin_type'
    plugin_name = 'plugin_name'
    filename = 'filename'
    description = 'description'
    version_added = 'version_added'
    options = {
        'option' : {
            'description' : 'description of option',
            'required' : True 
        }
    }
    attributes = {
        'attributes' : {
            'description' : 'description of attributes',
            'required' : False 
        }
    }
    notes = [
        'notes'
    ]

# Generated at 2022-06-10 22:11:29.987427
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = DocCLIArgs()
    args.type = 'module'
    args.path = scope.get_collection_directories()[0]
    args.name = 'file'
    doc_cli = DocCLI(args)

    assert doc_cli.run() == 0


# Generated at 2022-06-10 22:11:34.578007
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    cli = DocCLI()
    role = 'myrole'
    role_json = {}
    assert cli.get_role_man_text(role, role_json) == []


# Generated at 2022-06-10 22:11:37.057542
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Test the argument count of function get_role_man_text
    try:
        func = eval('DocCLI.get_role_man_text')
        arg_count = len(inspect.getargspec(func).args)
        assert arg_count == 3
    except Exception as e:
        raise AssertionError('%s' % e)

# Generated at 2022-06-10 22:11:47.583157
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    doc = {
        "key": "value",
        "key1": [
            "subkey1",
            "subkey2"
        ],
        "key2": [
            {
                "subkey1": "value1",
                "subkey2": "value2"
            }
        ]
    }
    text = []
    DocCLI.add_fields(text, doc, 80, "        ")
    assert text == [
        'KEY: value',
        '',
        'KEY1: subkey1, subkey2',
        '',
        'KEY2:',
        '        subkey1: value1',
        '        subkey2: value2'
    ]

    # negative case

# Generated at 2022-06-10 22:11:59.068961
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    class AnsibleDocCLI(DocCLI):
        """AnsibleDocCLI"""

    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_text

    ansible_doc_cli = AnsibleDocCLI()

# Generated at 2022-06-10 22:12:03.218511
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    spec = dict(
        path='lib/ansible/modules/network/cumulus/cnos_vlan.py',
        namespace='cumulus'
    )

    assert DocCLI._namespace_from_plugin_filepath(spec['path']) == spec['namespace']

# Generated at 2022-06-10 22:12:13.933940
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    class MockPluginLoader(object):
        def get_all_plugin_loaders(self):
            return {'lookup': action_loader, 'module': action_loader}
        def get_plugin_loader(self, t):
            return {'lookup': action_loader, 'module': action_loader}[t]
    class MockAction(object):
        def get_loader(self, t):
            return {'lookup': action_loader, 'module': action_loader}[t]
    class MockCLI(object):
        def __init__(self):
            self.args = ['ansible-doc', '-t', 'lookup']
            plugin_loader.add_directory(os.path.join(os.getcwd(), 'lib'))

# Generated at 2022-06-10 22:13:35.088733
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    plugin_loader = PluginLoader(
        'Core',
        'callback',
        C.DEFAULT_CALLBACK_PLUGIN_PATH,
        'callback_plugins',
    )
    option_parser = parser()
    options, args = option_parser.parse_args()
    loader = DocCLI(args, options)
    assert len(loader.find_plugins()) > 0


# Generated at 2022-06-10 22:13:42.602903
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-10 22:13:49.804464
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    from ansible.module_utils.six import StringIO
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 3

    sys.stdout = StringIO()
    sys.stderr = StringIO()

    dc = DocCLI()

    plugin_type = context.CLIARGS['type']

# Generated at 2022-06-10 22:14:00.556556
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-10 22:14:02.792846
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    assert type(DocCLI().get_all_plugins_of_type('become'))== dict


# Generated at 2022-06-10 22:14:05.137682
# Unit test for method namespace_from_plugin_filepath of class DocCLI

# Generated at 2022-06-10 22:14:09.311126
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    test_path = os.path.join('home','test','test.py')
    DocCLI.IGNORE = ['test']
    dc = DocCLI()
    # No platform specified
    assert dc.namespace_from_plugin_filepath(test_path) == ('home','test')
    # Platform specified
    context.CLIARGS['force_collection'] = True
    assert dc.namespace_from_plugin_filepath(test_path) == 'home.test'


# Generated at 2022-06-10 22:14:21.113049
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    '''Test the DocCLI.namespace_from_plugin_filepath method'''
    pwd = os.getcwd()
    display.display("pwd: %s" % pwd)

    # 1. filepath not a string
    # 1.1 filepath not a list
    display.display("1.1 filepath not a list")
    t = Template('{{ cli.namespace_from_plugin_filepath(p) }}')
    d = dict(cli=DocCLI, p=None)
    assert t.render(d) == '', "pwd: %s" % pwd

    # 1.2 filepath is a list
    display.display("1.2 filepath is a list")
    t = Template('{{ cli.namespace_from_plugin_filepath(p) }}')
    d

# Generated at 2022-06-10 22:14:29.853963
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Tests that the plugins array is populated correctly
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible_collections.ansible.builtin.plugins.action import file_tree
    from ansible_collections.ansible.builtin.plugins.action.file_tree import ActionModule
    from ansible.plugins.action.file_tree import ActionModule as ActionModule_base
    collection_config = AnsibleCollectionConfig(paths=[file_tree.__path__[0]])
    collection_manager = CollectionManager(collections=[collection_config], installed=True)
    collection_manager._populate_collections()
    tw = DocCLI()
    tw.collection_manager = collection_manager
    tw.collection_loader = collection_manager.collection_loader
    tw.set(ignore_certs=True)


# Generated at 2022-06-10 22:14:37.543052
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = DocCLI(context.CLIARGS)
    def _test_alter_spec(spec):
        spec['Test1'] = 'foo'
        spec['Test2'] = 'bar'
        return spec
    try:
        context.CLIARGS = {
            'type': 'foo',
            'paths': []
        }
        res = doc.get_plugin_metadata()
        assert res[0]['foo']['Test1'] == 'foo'
        assert res[0]['foo']['Test2'] == 'bar'
        assert res[0]['foo']['actions'] == []
        assert res[0]['foo']['options'] == {}
    finally:
        context.CLIARGS = {
            'type': 'module',
            'paths': []
        }


# Generated at 2022-06-10 22:18:39.005678
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []

# Generated at 2022-06-10 22:18:46.651561
# Unit test for method format_snippet of class DocCLI

# Generated at 2022-06-10 22:18:47.444987
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    pass


# Generated at 2022-06-10 22:18:58.623241
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    #
    # This method needs to be better tested. It's easy to test it as a whole,
    # but we should be testing the various pieces, rather than the method as a
    # whole.
    #
    DocCLIObj = DocCLI()
    DocCLIObj.plugin_type = 'test'

    #
    # We're testing a single module, so we can have the results be different
    # depending on the module, but we could also have it be the same regardless
    # of module.
    #
    def test_module_info(module_name, expected_result):
        class FakeDisplayObj(object):
            columns = 80
        display = FakeDisplayObj()
        #
        # Create a fake plugin loader to test
        #