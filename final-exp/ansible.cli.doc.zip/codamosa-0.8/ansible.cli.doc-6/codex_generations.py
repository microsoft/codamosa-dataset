

# Generated at 2022-06-10 22:11:07.200908
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    '''Unit test for method get_man_text of class DocCLI'''
    sys.modules['ansible.utils'] = ansible.utils
    sys.modules['ansible.plugins'] = ansible.plugins


# Generated at 2022-06-10 22:11:14.156171
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # initialize the instance first
    test_cli = DocCLI()
    # pass the test args for preparing the test-data for asserting the output

# Generated at 2022-06-10 22:11:15.229512
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # TODO: Add unit tests
    pass


# Generated at 2022-06-10 22:11:21.631109
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Testing function name
    print("Testing function name: %s" % inspect.currentframe().f_code.co_name)
    # Dummy data

# Generated at 2022-06-10 22:11:33.783061
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    cli = DocCLI()
    expected = {'filename': 'test_DocCLI_format_plugin_doc', 'description': 'Test DocCLI format_plugin_doc method'}
    result = cli.format_plugin_doc('test_DocCLI', expected)
    assert result == expected, "format_plugin_doc returns the same dict it's passed if it doesn't contain 'plainexamples' and 'returndocs'"
    expected_with_returndocs = {'filename': 'test_DocCLI_format_plugin_doc', 'description': 'Test DocCLI format_plugin_doc method', 'returndocs': 'some_return_values'}

# Generated at 2022-06-10 22:11:35.716353
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    cli_obj = DocCLI()
    plugin_type = "action"
    plugin_name = "ping"
    with pytest.raises(AnsibleError):
        cli_obj.format_plugin_doc(plugin_name, plugin_type)


# Generated at 2022-06-10 22:11:40.992673
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    r = DocCLI()

# Generated at 2022-06-10 22:11:49.150945
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Finding ansible-modules-core
    my_object = DocCLI([], "ansible-doc")
    # List of plugins after ansible-modules-core plugin
    my_plugins = my_object._find_plugins()
    expected_plugins = [['Module', 'filename', 'name', 'module_name'],
                        ['Module', 'core/cloud/amazon/ec2.py', 'ec2',
                         'ansible.modules.cloud.amazon.ec2'],
                        ['Module', 'core/cloud/amazon/ecs_task_definition.py', 'ecs_task_definition',
                         'ansible.modules.cloud.amazon.ecs_task_definition'],
                        ['Module', 'core/cloud/amazon/ecs.py', 'ecs',
                         'ansible.modules.cloud.amazon.ecs']]

# Generated at 2022-06-10 22:12:00.541389
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.cli.argparse import parse_cli_args
    from ansible_doc.doccli import get_plugin_collection
    from ansible_doc.doccli import DocCLI
    from ansible_doc.shared import AnsibleDocCLI
    module_doc = {
        'description': 'This is a test module',
        'options': {
            'name': {
                'default': 'Test',
                'description': 'Name',
                'type': 'str',
                'version_added': '2.9'
            }
        }
    }
    context.CLIARGS = parse_cli_args(['ansible-doc', '-t', 'module', 'testmodule'])

# Generated at 2022-06-10 22:12:03.814485
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = []
    ans_coll = AnsibleCollectionConfig.default_collection_path()
    add_collection_plugins(plugin_list, 'module', coll_filter=ans_coll)
    assert len(plugin_list) > 0



# Generated at 2022-06-10 22:12:58.925828
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    config = load_config_file()

    config['ANSIBLE_CONFIG_MODULE_PATH'] = '.'
    config['ANSIBLE_CONFIG_MODULE_PATH'] = config['ANSIBLE_CONFIG_MODULE_PATH'].split(os.path.pathsep)

    config['ansible_config_file'] = os.devnull
    config['ANSIBLE_LIBRARY'] = os.devnull
    config['ANSIBLE_ROLES_PATH'] = os.devnull
    config['ANSIBLE_MODULE_UTILS'] = os.devnull
    config['ANSIBLE_FILTER_PLUGINS'] = './filter_plugins'
    config['ANSIBLE_LIBRARY'] = './plugins/action:./plugins/modules'

# Generated at 2022-06-10 22:13:09.009601
# Unit test for method get_plugin_metadata of class DocCLI

# Generated at 2022-06-10 22:13:19.748460
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    def test(plugin_type, plugin_list, output, width=80):
        display = Mock()
        display.columns = width
        with patch.object(DocCLI, 'get_section_data', return_value=plugin_list):
            DocCLI.display_plugin_list(display, plugin_type, 'foo')
            display.display.assert_called_with(output)

    with pytest.raises(DocCLI.AnsibleOptionsError):
        DocCLI.display_plugin_list(None, 'foo', 'bar')

    test(
        'module',
        [
            {'name': 'shell'},
            {'name': 'command'},
        ],
        '''\
  * shell
  * command
''',
    )


# Generated at 2022-06-10 22:13:28.026097
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Testing case when required args are given.
    # Execute the function under test
    args = {'type':'filter', 'path':'/usr/lib/python2.7/site-packages/ansible/plugins/filter/'}
    DocCLI(args).display_plugin_list()

    # Testing case when required args are not given.
    args = {'path':'/usr/lib/python2.7/site-packages/ansible/plugins/filter/'}
    with pytest.raises(SystemExit):
        DocCLI(args).display_plugin_list()

    args = {'type':'filter'}
    with pytest.raises(SystemExit):
        DocCLI(args).display_plugin_list()

    # Testing case when we provide non-existing path.

# Generated at 2022-06-10 22:13:29.798466
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = DocCLI('')
    doc.get_plugin_metadata('test/test_doc.py')
    assert doc.metadata['short_description'] == 'This module does foo.'

# Generated at 2022-06-10 22:13:31.845593
# Unit test for method run of class DocCLI
def test_DocCLI_run():
  '''Unit test for method run of class DocCLI.'''
  pass # TODO: implement your test here


# Generated at 2022-06-10 22:13:40.172994
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.plugins.loader import cli_docs as cli_doc_loader

    with mock.patch('ansible.cli.doc.display.columns', 150):
        plugins = [cli_doc_loader.get_doc_module(plugin_name) for plugin_name in cli_doc_loader.get_all_plugin_names()]

        # Test all plugins
        for plugin in plugins:
            text = DocCLI.format_plugin_doc(plugin.DOCUMENTATION, plugin_name=plugin.__name__)
            assert text is not None
            assert len(text.splitlines()) > 0

        # Test single plugin
        plugin = cli_docs.AdHocCLI(mock.Mock())

# Generated at 2022-06-10 22:13:47.833450
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    collection = 'ansible_collections/test_collections'
    # collection = 'ansible/test'

# Generated at 2022-06-10 22:13:57.120799
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    from ansible.utils.display import Display
    from ansible.utils.context import CLIContext

# Generated at 2022-06-10 22:14:08.763552
# Unit test for method get_all_plugins_of_type of class DocCLI

# Generated at 2022-06-10 22:15:16.802319
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc_cli = DocCLI()
    doc_cli.run()


# Generated at 2022-06-10 22:15:17.383401
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    pass



# Generated at 2022-06-10 22:15:27.650478
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    module_json = {
        'description': ['description ' * 10],
        'version_added': '1.2.3',
        'options': {
            'name': {
                'description': ['description ' * 10],
                'required': True,
                'type': 'str'
            }
        },
        'seealso': [
            {
                'name': 'title',
                'description': ['description ' * 10],
                'link': 'docs/doc.html'
            }
        ]
    }
    cli = DocCLI(module_name='', module_path='', module_args=[], check_syntax='')
    result = cli.get_man_text(module_json)
    assert not isinstance(result, dict)
    assert isinstance(result, string_types)
   

# Generated at 2022-06-10 22:15:33.664987
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()
    result = doc.display_plugin_list([{'NAME': 'test1', 'PATH': 'test1'}, {'NAME': 'test2', 'PATH': 'test2'}], '/doc/test1', '/doc/test2')
    assert result == None


# Generated at 2022-06-10 22:15:41.524515
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    fixtures_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'lib', 'ansible', 'module_utils', 'module_docs_fragments')
    path = fixtures_path + "/test_doc_fragments.py"
    result = DocCLI.get_plugin_metadata(path)
    assert result == {"doc": ["This is a test fragment"], "version_added": "2.9"}


# Generated at 2022-06-10 22:15:49.415873
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
   DocCLI_obj = DocCLI()
   role = "ansible-role-mailhog"

# Generated at 2022-06-10 22:16:00.067183
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    test_module = {'module': 'unit_test_module',
                   'doc': {'module': {'module_name': 'unit_test_module'},
                           'doc': ['Unit test document header', 'Unit test document body'],
                           'docopt': {'name': 'unit_test_module'}},
                   'filename': './lib/ansible/modules/cloud/amazon/unit_test_module.py'}

# Generated at 2022-06-10 22:16:03.016475
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    c = DocCLI()
    c.display_plugin_list(['action_plugin', 'filter_plugin'])
    assert True # TODO: implement your test here


# Generated at 2022-06-10 22:16:13.980324
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.cli.doc import DocCLI
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    if PY3:
        unicode = str
    # Test DocCLI.format_plugin_doc() with a module as arg
    doc = DocCLI.format_plugin_doc(['module', 'setup'], 'module')
    if PY3:
        assert isinstance(doc, unicode)
    else:
        assert isinstance(doc, str)
    # Test DocCLI.format_plugin_doc() with a callback as arg
    doc = DocCLI.format_plugin_doc(['callback', 'mail'], 'callback')
    if PY3:
        assert isinstance(doc, unicode)

# Generated at 2022-06-10 22:16:15.744842
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    assert DocCLI.format_snippet([{'description': 'test'}], 'connection') == [{'description': 'test'}]
