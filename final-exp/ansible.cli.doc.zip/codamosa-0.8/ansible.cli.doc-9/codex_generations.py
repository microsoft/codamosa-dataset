

# Generated at 2022-06-10 22:12:11.075757
# Unit test for method find_plugins of class DocCLI

# Generated at 2022-06-10 22:12:17.959290
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    _doc = dict(doc,
        options = dict(
            free_form = dict(_txt='free form, any string goes'),
            required = dict(required=True),
            a_boolean = dict(options=dict(true=True, false=False)),
            a_string = dict(options=['A', 'B', 'C']),
            a_number = dict(options=dict(one=1, two=2))
        )
    )
    DocCLI.add_fields(text, _doc['options'], limit, '    ')

# Generated at 2022-06-10 22:12:20.987148
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    result = DocCLI.print_paths(paths=['a', 'b'])
    assert result == 'a, b'


# Generated at 2022-06-10 22:12:30.945652
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    cli = DocCLI()
    import pkgutil
    from ansible.module_utils import basic

    result = cli.namespace_from_plugin_filepath('%s/action_plugins/copy.py' % pkgutil.get_loader('ansible').get_filename())
    assert result == 'ansible.plugins.action'
    result = cli.namespace_from_plugin_filepath('%s/modules/basic.py' % pkgutil.get_loader(basic).get_filename())
    assert result == 'ansible.module_utils.basic'

# Generated at 2022-06-10 22:12:37.098012
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Set up mocks
    mock_module_name=MagicMock()
    mock_module_name.module_name=MagicMock(return_value='module_name')
    mock_module_name.collection=MagicMock(return_value='collection')
    mock_module_name.plain=MagicMock(return_value='plain')
    mock_module_name.full_name=MagicMock(return_value='full_name')
    mock_module_name.j2_name=MagicMock(return_value='j2_name')
    mock_module_name.is_action_plugin=MagicMock(return_value=True)
    mock_module_name.is_module=MagicMock(return_value=True)

# Generated at 2022-06-10 22:12:49.424454
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    '''Unit test for method find_plugins of class DocCLI

    :returns: bool

    '''
    # Test with a dummy plugin_type
    doc_manager = DocCLI()
    DocCLI.plugin_type = 'foo'
    DocCLI.list_dirs = lambda: ['foo']
    collected = doc_manager.find_plugins('/tmp/')
    assert isinstance(collected, tuple)
    assert collected == ('/tmp/foo', 'foo')

    # Test with a real plugin_type
    doc_manager = DocCLI()
    DocCLI.plugin_type = 'shell'
    collected = doc_manager.find_plugins('/tmp/')
    assert isinstance(collected, tuple)
    assert collected == ('/tmp/shell', 'shell')


# Generated at 2022-06-10 22:12:50.517903
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc = DocCLI()
    doc.run()


# Generated at 2022-06-10 22:12:59.085619
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    test_class = DocCLI()
    test_class._display_plugin_list(['ansible.module_utils.basic', 'ansible.module_utils.cli', 'ansible.module_utils.common.dict'],
                                    'MODULE UTILS')
    test_class._display_plugin_list(['ansible.plugins.action'], 'ACTION PLUGINS')
    test_class._display_plugin_list(['ansible.plugins.cache'], 'CACHE PLUGINS')
    test_class._display_plugin_list(['ansible.plugins.callback'], 'CALLBACK PLUGINS')
    test_class._display_plugin_list(['ansible.plugins.connection'], 'CONNECTION PLUGINS')

# Generated at 2022-06-10 22:12:59.711368
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    pass

# Generated at 2022-06-10 22:13:10.634766
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    cli = DocCLI()
    # Test with module option
    context.CLIARGS = {'type': 'module', 'all': False, 'paths': [], 'name': '', 'exclude_search': ''}
    assert cli.run() == 0
    context.CLIARGS = {'type': 'module', 'all': True, 'paths': [], 'name': '', 'exclude_search': ''}
    assert cli.run() == 0

    # Test with module_path option
    context.CLIARGS = {'type': 'module_path', 'all': False, 'paths': [], 'name': '', 'exclude_search': ''}
    assert cli.run() == 0

# Generated at 2022-06-10 22:16:28.207158
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        "name": "copy",
        "description": [
            "Copies files to remote locations."
        ],
        "options": {
            "freeze": {
                "description": "Do not use with --diff"
            }
        }
    }
    doc_text = DocCLI.get_man_text(doc)
    assert('> COPY    ()\n' == doc_text.splitlines()[0] + '\n')


# Generated at 2022-06-10 22:16:34.812670
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
  DocCLI = ansible.module_utils.basic.AnsibleModuleUtils.DocCLI
  # Test missing params
  try:
    DocCLI.get_all_plugins_of_type()
    assert False, "An exception should have been raised"
  except TypeError as e:
    assert "get_all_plugins_of_type() missing 1 required positional argument: 'plugin_type'" in str(e), "The exception message does not match"

  # Test empty params
  assert DocCLi.get_all_plugins_of_type('test') == [], "The result does not match"


# Generated at 2022-06-10 22:16:48.083892
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    '''
    unit test for run() method of class DocCLI
    '''
    # Testing with invalid module
    doc = DocCLI()
    doc.run()
    assert Utility.tabulate(doc.find_name('unsupported')) == []

    # Testing with invalid module type
    doc = DocCLI()
    doc.run('dummy')
    assert Utility.tabulate(doc.find_name('unsupported')) == []

    # Testing with invalid module type
    doc = DocCLI()
    doc.run('dummy1')
    assert Utility.tabulate(doc.find_name('dummy')) == [
        {'name': 'dummy'}
    ]

    # Testing with invalid module type
    doc = DocCLI()
    doc.run('dummy2')
    assert Utility.tabulate

# Generated at 2022-06-10 22:16:58.835145
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('some/test/path/test_plugin.py') == 'test'
    assert DocCLI.namespace_from_plugin_filepath('some/test/path/test.py') == 'test'
    assert DocCLI.namespace_from_plugin_filepath('some/test/path/test_plugin_name.py') == 'test_plugin_name'
    assert DocCLI.namespace_from_plugin_filepath('some/test/path/__init__.py') is False
    assert DocCLI.namespace_from_plugin_filepath('some/test/path/test_foo.py') == 'test'
    assert DocCLI.namespace_from_plugin_filepath('some/test/path/testfoo.py') == 'testfoo'

# Generated at 2022-06-10 22:17:08.746914
# Unit test for method display_plugin_list of class DocCLI

# Generated at 2022-06-10 22:17:15.610933
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    plugin_list = [
        {
            'name': 'my_list1',
            'doc': {'description': 'Test module 1'}
        },
        {
            'name': 'my_list2',
            'doc': {'description': 'Test module 2'}
        },
        {
            'name': 'my_list3',
            'doc': {'description': 'Test module 3'}
        }
    ]
    context.CLIARGS = {'type': 'module'}

# Generated at 2022-06-10 22:17:23.818597
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    display.columns = 110
    display.display("\n\n")
    display.display("\n\n  Example of function call:\n")
    display.display("    def add_fields(text, data, width, opt_indent, return_values=False, parent_indent='', argspec=None):\n\n")
    display.display("    DocCLI.add_fields(text, returndocs, display.columns, opt_indent, return_values=True)\n\n")

    DocCLI.add_fields(text, returndocs, display.columns, opt_indent, return_values=True)

# Generated at 2022-06-10 22:17:32.572778
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    docparser = DocCLI()
    
    # Get data for test
    test_data_path = os.path.abspath(os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_test_get_role_man_text'))
    
    if not os.path.isdir(test_data_path):
        os.mkdir(test_data_path)
    temp_dir_path = tempfile.mkdtemp(dir=test_data_path)
    
    # Create test data in temp dir
    # Write content to file

# Generated at 2022-06-10 22:17:41.743868
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc = {'entry_points':
                {'main': {'description': '',
                          'short_description': '',
                          'version_added_collection': None,
                          'version_added': '',
                          'options':
                              {'not_a_valid_option':
                                   {'version_added_collection': None,
                                    'aliases': [],
                                    'default': 'test',
                                    'required': False,
                                    'type': 'str',
                                    'version_added': ''}}}},
           'filename': '/home/scott/ansible/my_role/'}
    actual = DocCLI.get_role_man_text('my_role', doc)

# Generated at 2022-06-10 22:17:52.078554
# Unit test for method add_fields of class DocCLI