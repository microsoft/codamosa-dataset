

# Generated at 2022-06-10 22:11:06.913228
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-10 22:11:13.881650
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    from ansible.utils.display import Display
    text = []
    # Test for one normal case
    doc = {
        'option': {
            'type': 'str',
            'required': True,
            'choices': [
                'all'
            ],
            'default': 'all',
            'aliases': [
                'adapter'
            ],
            'version_added': '2.8'
        }
    }
    DocCLI.add_fields(text, doc, 100, '    ')

# Generated at 2022-06-10 22:11:15.838108
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    is_equal = mock.MagicMock(return_value=True)
    cli = DocCLI()
    cli.get_role_man_text("role", "data")

# Generated at 2022-06-10 22:11:22.352723
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    """
    Unit test for method format_plugin_doc of class DocCLI
    """

    # Test #1: test output of module 'copy'
    # Invoke function with valid arguments
    results = DocCLI.format_plugin_doc('copy')

    # Assertions
    assert type(results) is str
    assert '> COPY' in results

    # Test #2: test output with module 'win_acl'
    # Invoke function with valid arguments
    results = DocCLI.format_plugin_doc('win_acl')

    # Assertions
    assert type(results) is str
    assert '> WIN_ACL' in results

    # Test #3: test if exception is raised with module that does not exist
    # Invoke function with wrong module name

# Generated at 2022-06-10 22:11:24.152042
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = DocCLI.parser().parse_args(['module', '-l'])
    cli = DocCLI(args)
    cli.run()

# Generated at 2022-06-10 22:11:31.580776
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    options = AnsibleOptions({})
    plugin_list = []
    plugin_list.append({'name': 'foo', 'version_added': '2.0.0.0'})
    plugin_list.append({'name': 'bar', 'version_added': '2.2.0.0'})
    plugin_list.append({'name': 'baz', 'version_added': '2.4.0.0'})
    doc_cli = DocCLI(options)

# Generated at 2022-06-10 22:11:44.976434
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-10 22:11:46.521910
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doccli = DocCLI()
    rc, out, err = doccli.run()

# Generated at 2022-06-10 22:11:58.687472
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # Tests the following:
    #   DocCLI.namespace_from_plugin_filepath(filepath, check_aliases=False, collection_name=None)
    #       filepath:
    #            - validated entry point file
    #            - invalid entry point file
    #            - core plugin file
    #            - collection plugin file
    #       check_aliases:
    #            - True
    #            - False
    #       collection_name:
    #            - valid collection name
    #            - invalid collection name
    #            - None

    # Create test instance - not needed for testing static methods
    test_cli = DocCLI()

    # Create files for testing with
    entry_point_filename = "test_namespace_file"
    create_valid_plugin_meta(entry_point_filename)
    entry_

# Generated at 2022-06-10 22:11:59.438997
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    pass



# Generated at 2022-06-10 22:13:50.678466
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    """
    Test display_plugin_list method of DocCLI class
    """
    with pytest.raises(CLIError) as exc:
        DocCLI.display_plugin_list({}, "connection")
    assert "connection" in to_text(exc.value)



# Generated at 2022-06-10 22:14:01.668776
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    """
    Test for method run of class DocCLI
    """

    doc = DocCLI()
    # Modules
    # Situations:
    # 1. The specified module exists.
    # 2. The specified module does not exist.
    arguments = [
        'ansible-doc',
        'module_name'
    ]
    parser = doc.create_parser(arguments[1:])
    if 'module_name' in context.CLIARGS['module_name']:
        with pytest.raises(SystemExit):
            opts = parser.parse_args(doc._get_opts_args(parser, arguments), namespace=context.CLIARGS)
            doc.run()

# Generated at 2022-06-10 22:14:11.434906
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    cli = DocCLI('--snippet')
    assert cli.format_snippet('') == ''
    YAML_DOC = {
        'hosts': 'localhost',
        'vars': {
            'a': 1,
            'b': {'c': 3, 'd': 4}
        },
        'vars_prompt': {
            'prompt_default': {
                'var': 'prompted_var',
                'default': 'Foo',
                'prompt': 'Bar',
            }
        }
    }

# Generated at 2022-06-10 22:14:20.652312
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    test_cli=DocCLI()
    test_cli.doc_fragment_plugins = {'test1': 'test1'}
    test_cli.doc_plugins = {'test2': 'test2'}
    test_cli.module_common_arguments = {'test3': 'test3'}
    test_cli.module_mapping = {'test4': 'test4'}
    assert test_cli.get_plugin_metadata() == {'test1': 'test1', 'test2': 'test2', 'test3': 'test3', 'test4': 'test4'}

# Generated at 2022-06-10 22:14:22.596613
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
  display_plugin_list_obj = DocCLI()

# Generated at 2022-06-10 22:14:23.593703
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():

    assert True == True


# Generated at 2022-06-10 22:14:25.617972
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    assert DocCLI.format_plugin_doc('name', 'description') == ""


# Generated at 2022-06-10 22:14:33.917300
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    from ansiblelint import RulesCollection
    from ansiblelint import Runner
    rulesdir = 'test/rules'
    collection = RulesCollection.create_from_directories(rulesdir)
    runner = Runner(collection, None, [], [], [])
    doc = DocCLI(runner)
    doc.IGNORE = doc.IGNORE + ['type', 'filename']
    # In a real program, these might come from a module.

# Generated at 2022-06-10 22:14:40.477365
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():

    import ansible.module_utils.facts
    from ansible.module_utils._text import to_native

    test_module = ansible.module_utils.facts.cpuinfo.cpuinfo

    #
    # Test module is working properly
    #
    # noinspection PyProtectedMember
    module_display_name = test_module._load_name()
    # noinspection PyProtectedMember
    module_version = test_module._load_version()
    # noinspection PyProtectedMember
    module_doc = test_module._load_documentation().get('description', 'No description')
    try:
        # noinspection PyUnresolvedReferences
        test_module.main()
        module_working = True
    except Exception:
        module_working = False

    #
    # Extract module documentation
    #
    result

# Generated at 2022-06-10 22:14:42.287323
# Unit test for function jdump
def test_jdump():
    jdump({u'foo': u'bar'})



# Generated at 2022-06-10 22:16:07.875283
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    expected_result = [
        "> DUMMY_ROLE    (dummy_role_path)",
        "ENTRY POINT: meta - define variables for app1",
        "        This is the first entry point",
        "OPTIONS (= is mandatory):",
        "        some_var:",
        "                description: some description",
        "                required: yes",
        "                type: string",
        "                default: [Default: abc]",
        "        some_list:",
        "                description: some description",
        "                required: yes",
        "                type: list",
        "                default: [Default: [abc, def]]",
        "",
        "ATTRIBUTES:",
        "        msg: 'Hi, there!'",
    ]


# Generated at 2022-06-10 22:16:16.112541
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test case 1: no plugins found
    plugins_found = []
    version = None
    display_rest = 0
    type = "module"
    list_type = "all"
    path = ''

    # Construct DocCLI object
    doccli = DocCLI()
    # Call display_plugin_list using parameters above
    result = doccli.display_plugin_list(plugins_found, version, display_rest=0,
                                        type=type, list_type="all", path='')
    ans = True
    assert result is ans

    # Test case 2: no plugins found

# Generated at 2022-06-10 22:16:18.446196
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc_cli = DocCLI()
    doc_cli.get_plugin_metadata()

# Generated at 2022-06-10 22:16:28.204292
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    import json
    args = Mock()
    args.type = 'truth'
    context.CLIARGS = vars(args)
    module_doc = json.load(open('/Users/daniel/Documents/GitHub/ansible-modules-core/lib/ansible/modules/system/setup.py'))
    h = DocCLI()
    #print(" ", h.get_man_text(module_doc))
    print(" ", h.get_man_text(module_doc,'ansible_collections.ansible.cloudscale_mx.plugins.modules','module'))


# Generated at 2022-06-10 22:16:36.025579
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []

# Generated at 2022-06-10 22:16:48.521946
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    from ansible.utils.color import stringc
    r = {}
    r['name'] = 'nginx'
    r['path'] = '/home/user/ansible/library/nginx'
    r['partial_name'] = 'nginx'
    r['summary'] = 'Install and configure nginx'
    r['version'] = 'v1.2.1'
    r['license'] = ['GPLv2', 'MIT']
    r['author'] = 'Ansible Core Team'
    r['description'] = ['Configure settings for nginx', '', 'This module is maintained by the Ansible Community']
    r['min_ansible_version'] = '2.0'
    r['platforms'] = {'Debian': ['jessie', 'wheezy']}

# Generated at 2022-06-10 22:16:51.414309
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    DocCLI = ansible.utils.plugin_docs.DocCLI()
    DocCLI.get_plugin_metadata()


# Generated at 2022-06-10 22:16:53.556621
# Unit test for method format_snippet of class DocCLI

# Generated at 2022-06-10 22:17:04.040810
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Testcase 1
    testcase1 = yaml.load(dedent("""
    [
        {
            'key1': {
                'options': {
                    'subkey1': 'subvalue1',
                    'subkey2': 'subvalue2',
                    'subkey3': 'subvalue3'
                }
            }
        },
        {
            'key2': {
                'options': {
                    'subkey1': 'subvalue1',
                    'subkey2': 'subvalue2',
                    'subkey3': 'subvalue3'
                }
            }
        }
    ]
    """))
    test_text = []
    text = []
    DocCLI.add_fields(text, testcase1, 80)
    assert text == test_text

    # Testcase 2
    test

# Generated at 2022-06-10 22:17:12.620833
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Test index creation
    os.environ["ANSIBLE_COLLECTIONS_PATHS"] = 'test/unit/cli/data/test_v1_collections-path'
    cli1 = DocCLI([])
    cli1.run()
    assert os.path.isfile('index_modules.yaml')
    assert os.path.isfile('index_plugins.yaml')
    assert os.path.isfile('index_roles.yaml')
    assert os.path.isfile('index_inventories.yaml')
    os.remove('index_modules.yaml')
    os.remove('index_plugins.yaml')
    os.remove('index_roles.yaml')
    os.remove('index_inventories.yaml')