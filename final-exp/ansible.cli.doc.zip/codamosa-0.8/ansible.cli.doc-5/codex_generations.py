

# Generated at 2022-06-10 22:11:04.097424
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-10 22:11:11.853594
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-10 22:11:17.660807
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    """
    Test case for add_fields
    """
    doc = dict(
        description =   "The M(community.general.slack) module sends notifications to U(https: //slack.com) channels. These notifications can be received by Slack (via the Slack channel) users."
    )
    text = []
    limit = 70
    opt_indent = "        "
    DocCLI.add_fields(text, doc, limit, opt_indent)

    assert text == [
        'description: ',
        '        The M(community.general.slack) module sends notifications to',
        '        U(https: //slack.com) channels. These notifications can be',
        '        received by Slack (via the Slack channel) users.'
    ]


# Generated at 2022-06-10 22:11:19.504156
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    cmd = 'ansible-doc --list'
    parser = DocCLI()
    result = parser.run(cmd.split())

    assert result == 0

# Generated at 2022-06-10 22:11:21.180907
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    module = AnsibleModule(argument_spec=dict())
    cli = DocCLI(module)
    cli.run()

# Generated at 2022-06-10 22:11:25.948051
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    assert add_collection_plugins(["mysql", "ping", "win_ping"], "module", coll_filter='community') == \
           ["ansible_collections.community.mysql.plugins.module", "ansible_collections.community.ping.plugins.module", "ansible_collections.community.win_ping.plugins.module"]


# Generated at 2022-06-10 22:11:41.120649
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    cli = DocCLI()
    display = Display()
    cli.pager('')
    cli.run([])
    cli.run([''])
    cli.run(['-h'])
    cli.run(['ansible-doc', '-h'])
    cli.run(['ansible-doc', '-l'])
    cli.run(['ansible-doc', '-s'])
    cli.run(['ansible-doc', '-t'])
    cli.run(['ansible-doc', '-l', '-s', '-t'])
    cli.run(['ansible-doc', 'localhost', '-t', 'connection'])

# Generated at 2022-06-10 22:11:42.063981
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    assert len(DocCLI().find_plugins()) > 0


# Generated at 2022-06-10 22:11:49.247030
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import get_docstring

    from ansible.config.manager import ConfigManager
    from ansible.plugins.loader import module_loader, fragment_loader

    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.manager
    import ansible.inventory.script

    # This would probably be a lot easier with pytest, but I don't want to force that dependency
    # on everyone just yet.

    fake_display = Display()
    fake_cm = ConfigManager(['fake/ansible.cfg'])

    import doctest
    doctest.ELLIPSIS

# Generated at 2022-06-10 22:11:57.571265
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():

    doc_cli = DocCLI()
    # Testing when docs is empty, expected ouput is ''
    assert doc_cli.display_plugin_list() == ''

    # Testing when docs is not empty, expected ouput is '''Column 1: abc
    #                                                      Column 2: xyz'''
    docs = [['abc', 'xyz']]
    doc_cli.docs = docs
    assert doc_cli.display_plugin_list() == '''Column 1: abc
                                               Column 2: xyz'''


# Generated at 2022-06-10 22:12:43.241267
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    assert len(DocCLI.get_plugin_metadata()) > 0


# Generated at 2022-06-10 22:12:46.957188
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Create instance of class DocCLI
    doc = DocCLI()
    # assert_equal(expected, DocCLI.find_plugins(self, path))
    raise SkipTest 


# Generated at 2022-06-10 22:12:54.476868
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    run_init_call(['--help'], collection_name='test_collection_name_display_plugin_list', plugin_type='test_plugin_type_display_plugin_list', verbosity=-1)

    def test_get_plugin_list():
        return DocCLI.get_plugin_list()

    def test_display_plugin_list(objs):
        DocCLI.display_plugin_list(objs)

    def mock_get_plugin_list():
        return {
            'test_list_name_display_plugin_list': ['test_list_item1', 'test_list_item2']
        }


# Generated at 2022-06-10 22:13:04.094844
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Testcase 1:
    text = []
    limit = '70'
    opt_indent = "    "
    opt = {'keyword_a': 'value_a', 'keyword_b': 'value_b'}
    return_values = False
    DocCLI.add_fields(text, opt, limit, opt_indent, return_values)
    assert len(text) == 3
    assert text[0].startswith('    KEYWORD_A')

    # Testcase 2:
    text = []
    limit = '70'
    opt_indent = "    "
    opt = {'keyword_a': 'value_a', 'keyword_b': 'value_b', '_aliases': ['aliases_a', 'aliases_b']}
    return_values = False
    Doc

# Generated at 2022-06-10 22:13:08.262360
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    """Unit test for method display_plugin_list of class DocCLI
    """
    DocCLI.display_plugin_list(plugin_list=display_plugin_list, plugin_type='module')



# Generated at 2022-06-10 22:13:10.354159
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
  doc = DocCLI()
  doc.display_plugin_list()


# Generated at 2022-06-10 22:13:20.362122
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    """
    Test DocCLI._get_plugins_of_type
    """
    # get_all_plugins_of_type()
    # result = DocCLI._get_plugins_of_type()

    doc = DocCLI()
    result = doc.get_all_plugins_of_type(['lookup'], '', 'all', False)
    assert('redact' in result)
    assert('win_chocolatey' in result)

    result = doc.get_all_plugins_of_type(['win_chocolatey'], '', 'all', False)
    assert('win_chocolatey' in result)

    result = doc.get_all_plugins_of_type(['win_chocolatey'], '', 'newest', False)

# Generated at 2022-06-10 22:13:31.862289
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    make_dirs(os.path.join(self.test_dir, 'collection_root'))
    make_dirs(os.path.join(self.test_dir, 'collection_root/namespace'))
    make_dirs(os.path.join(self.test_dir, 'collection_root/namespace/collection'))
    make_dirs(os.path.join(self.test_dir, 'collection_root/namespace/collection/plugins/modules'))
    make_dirs(os.path.join(self.test_dir, 'collection_root/namespace/collection/plugins/modules/subdir'))
    make_dirs(os.path.join(self.test_dir, 'collection_root/namespace/collection/plugins/module_utils'))

# Generated at 2022-06-10 22:13:40.172818
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Invalid role_json input
    role, role_json = 'generic', {}
    with pytest.raises(Exception) as excinfo:
        DocCLI.get_role_man_text(role, role_json)
    assert 'role_json has a invalid structure' in str(excinfo.value)

    # Invalid role_json input
    role, role_json = 'generic', {'entry_points': {'main': {}}}
    with pytest.raises(Exception) as excinfo:
        DocCLI.get_role_man_text(role, role_json)
    assert 'role_json should contain a description key' in str(excinfo.value)

    # Invalid role_json input
    role, role_json = 'generic', {'entry_points': {'main': {'description': 'role'}}}


# Generated at 2022-06-10 22:13:47.931686
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-10 22:14:58.194570
# Unit test for function add_collection_plugins
def test_add_collection_plugins():

    class FakeModule(object):
        """Fake module for tests."""
        def __init__(self):
            self.params = {}

    class FakeConnection(object):
        """Fake connection for tests."""
        def __init__(self):
            self.module = FakeModule()

    plugin_list = []
    plugin_type = 'image'
    coll_filter = 'fake_collection'
    b_colldirs = list_collection_dirs(coll_filter=coll_filter)
    for b_path in b_colldirs:
        path = to_text(b_path, errors='surrogate_or_strict')
        collname = _get_collection_name_from_path(b_path)

# Generated at 2022-06-10 22:14:59.121391
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    pass



# Generated at 2022-06-10 22:15:05.802846
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    from ansible.cli.arguments import options as cli_options
    from ansible.module_utils.common.text.text import CLIFactory
    # setup for testing
    CLIFactory(['', '', '', '', '', ''])
    cli_options['explain'] = True
    cli_options['type'] = 'roles'

# Generated at 2022-06-10 22:15:16.268626
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Create a dummy ansible.plugins.loader.PluginLoader object and add it to the context
    class DummyPluginLoader(object):
        pass
    context.CLIARGS = {'type': 'action_plugins'}
    context.CLIARGS['type'] = 'action_plugins'
    dummy_plugin_loader = DummyPluginLoader()
    dummy_plugin_loader.all = {'action_plugins': ['test_action', 'test_action2']}
    dummy_plugin_loader.all_with_origin = {'action_plugins': [{'name': 'test_action'}, {'name': 'test_action2'}]}
    context.CLIARGS['pylint'] = False
    context.CLIARGS['count'] = False
    context.CLIARGS['filter'] = 'None'
   

# Generated at 2022-06-10 22:15:23.520260
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    # Set up test environment
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    ansible_path = os.path.dirname(importlib.import_module('ansible').__file__)
    plugin_dir = os.path.join(ansible_path, 'plugins', 'action')
    copy_dir = os.path.join(tmpdir, 'plugins', 'action')

    os.makedirs(copy_dir)
    for plugin in os.listdir(plugin_dir):
        if plugin != '__init__.py':
            shutil.copy(os.path.join(plugin_dir, plugin), os.path.join(copy_dir, plugin))

    # Test
    plugin_list = {}
    add_collection_plugins(plugin_list, 'action')

    shutil

# Generated at 2022-06-10 22:15:41.704150
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    module, source, source_type, source_list = DocCLI.format_snippet("bash")
    assert module.__name__ == "bash"
    assert source_type == "bash"
    module, source, source_type, source_list = DocCLI.format_snippet("bash,python")
    assert module.__name__ == "bash"
    assert source_type == "bash"
    assert len(source_list) == 2
    assert source_list[0].__name__ == "bash"
    assert source_list[1].__name__ == "python"
    module, source, source_type, source_list = DocCLI.format_snippet("my/path/bash")
    assert source == "my/path/bash"
    assert source_type == "bash"


# Generated at 2022-06-10 22:15:50.450124
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc_cli = DocCLI()
    doc_cli._display_skipped = True

    display.verbosity = 4
    plugin_list = doc_cli.get_plugin_list()
    if len(plugin_list) == 0:
        raise AssertionError("No plugins found")

    plugins = plugin_list[:2]

    # Test Tested core plugins
    test_type = 'module'
    plugin_name = plugins[0]
    test_output = doc_cli.get_plugin_metadata(plugin_name, test_type, True)

    # Verify the output of the first plugin
    if (not test_output) or (not 'options' in test_output) or (not 'name' in test_output):
        raise AssertionError(u"Error in get_plugin_metadata")

    # Test Tested core

# Generated at 2022-06-10 22:16:01.446426
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doccli = DocCLI()
    doccli._load_plugin_docs()

    assert doccli.get_all_plugins_of_type('module')
    assert doccli.get_all_plugins_of_type('lookup')
    assert doccli.get_all_plugins_of_type('filter')
    assert doccli.get_all_plugins_of_type('callback')
    assert doccli.get_all_plugins_of_type('shell')
    assert doccli.get_all_plugins_of_type('connection')
    assert doccli.get_all_plugins_of_type('httpapi')
    assert doccli.get_all_plugins_of_type('inventory')
    assert doccli.get_all_plugins_of_type('vars')
    assert doccli.get_all_plugins_of_type

# Generated at 2022-06-10 22:16:13.067608
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    plugin_type = 'module'
    collection_name = 'community.general'
    filename = '/Users/asu/Downloads/ansible-2.9.2/lib/ansible/modules/cloud/azure/azure_rm_postgresqlfirewallrule.py'
    entry_points = {}

# Generated at 2022-06-10 22:16:26.202917
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    config_mock = MagicMock()
    config_mock.collect_roles = True
    config_mock.config_file = 'test-config'
    config_mock.roles_path = 'test-path'
    config_mock.defaults = 'test-defaults'
    config_mock.action_plugins = 'test-action'
    config_mock.connection_plugins = 'test-connection'
    config_mock.callback_plugins = 'test-callback'
    config_mock.lookup_plugins = 'test-lookup'
    config_mock.filter_plugins = 'test-filter'
    config_mock.test_plugins = 'test-test'
    config_mock.module_path = '/ansible/module_utils'
    config_mock.module_utils