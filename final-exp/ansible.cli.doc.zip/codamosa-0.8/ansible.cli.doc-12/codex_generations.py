

# Generated at 2022-06-10 22:11:18.824991
# Unit test for function jdump
def test_jdump():
    text='test'
    jdump(text)


# Generated at 2022-06-10 22:11:27.349940
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-10 22:11:33.429393
# Unit test for method run of class DocCLI
def test_DocCLI_run():
  doc = {'filename': 'my_filename', 'docuri': 'my_docuri', 'docformat': 'my_docformat'}
  mock_list = {}
  mock_list['doc'] = doc
  cli = DocCLI(mock_list)
  cli.run()


# Generated at 2022-06-10 22:11:46.013470
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-10 22:11:58.594442
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    coll_filter = AnsibleCollectionConfig(coll_names=['col1', 'col2'])
    add_collection_plugins(plugin_list, 'module', coll_filter=coll_filter)
    # check if col1 is present
    assert "col1" in plugin_list
    # check if col2 is present
    assert "col2" in plugin_list
    # check if col1 doesn't contain more than module plugins
    assert len([item for item in plugin_list['col1'] if item.endswith(".py")]) == len(plugin_list['col1'])
    # check if col2 doesn't contain more than module plugins
    assert len([item for item in plugin_list['col2'] if item.endswith(".py")]) == len(plugin_list['col2'])
#

# Generated at 2022-06-10 22:12:03.917146
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # TODO: set up test environment
    d = DocCLI()
    arguments = {}
    named_arguments = {}
    Ignore= ()
    from ansible.errors import AnsibleError
    try:
        out = d.get_plugin_metadata(arguments, named_arguments, Ignore)
        # TODO: check that correct result is returned
    except AnsibleError as e:
        pass

# Generated at 2022-06-10 22:12:11.863631
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    doc = DocCLI()
    doc.collection_name = 'somename'
    doc.directories = 'somelocation'
    plugin_filepath = 'somename/somelocation/somename.py'
    expected = 'somename.somelocation.somename.py'
    actual = DocCLI.namespace_from_plugin_filepath(plugin_filepath, doc.collection_name, doc.directories)
    assert expected == actual

# Generated at 2022-06-10 22:12:18.848631
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {
        'extends_documentation_fragment': ['doc2'],
        'description': 'First line of description\n\nAdditional description',
        'version_added': '2.1',
        'author': 'John Doe',
        'notes': ['First note.', 'Second note.'],
        'options': {
            'name': {
                'type': 'string',
                'description': 'First line of description\n\nAdditional description'
            },
            'new': {
                'type': 'boolean',
                'default': False,
                'description': 'Create a new object'
            }
        }
    }

    result = DocCLI.format_plugin_doc(doc, '', None)

# Generated at 2022-06-10 22:12:32.005739
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    import sys

    import pytest

    from ansible.module_utils._text import to_text

    from units.mock.conf import TestConfig
    from units.mock.env import Env
    from units.mock.loader import DictDataLoader

    env = Env({})
    config = TestConfig(loader=DictDataLoader({}), env=env)

    doc = {
        'options': {
            'alt': {
                'default': True,
                'description': 'If yes, uses the alternative function',
                'required': False
            },
            'name': {
                'type': 'str',
                'description': "The name of the new file, if omitted it'll be based on the source file.",
                'required': True
            }
        }
    }
    assert DocCLI.format_plugin

# Generated at 2022-06-10 22:12:45.229872
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-10 22:15:22.782115
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    snippet = '- name: Configure fail2ban service via systemd\n\n' \
              '  include_vars:\n' \
              '    file: "{{ item }}"\n\n' \
              '  with_fileglob:\n' \
              '  - "{{ role_path }}/vars/main.yml"\n\n' \
              '  - "{{ role_path }}/{{ ansible_distribution_major_version }}/main.yml"\n\n' \
              '  - "{{ role_path }}/{{ ansible_distribution | lower }}/main.yml"\n\n' \
              '  - "{{ role_path }}/{{ ansible_distribution_major_version }}/{{ ansible_distribution | lower }}/main.yml"\n'

# Generated at 2022-06-10 22:15:29.637808
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    param = DocCLI()
    param.run()



# Generated at 2022-06-10 22:15:31.280765
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    pass




# Generated at 2022-06-10 22:15:34.283622
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    import __main__  # pylint: disable=unused-variable
    doc = DocCLI()
    assert isinstance(doc.get_plugin_metadata(os.path.join(os.path.dirname(__file__), 'fixtures', 'doc_fragments', 'win_command.py')), dict)


# Generated at 2022-06-10 22:15:45.023320
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    d = DocCLI()
    module_options = {
        'signal': {
            'type': 'string',
            'default': 'TERM',
        },
        'timeout': {
            'type': 'int',
            'default': 10,
        }
    }
    # case 1
    module_name = 'shell'
    test_snippet = "- name: test with a message\n  shell: echo {{ foo }}"
    output = d.format_snippet(test_snippet, module_name, module_options)
    assert output == "  - name: test with a message\n    shell: echo {{ foo }}\n"
    # case 2
    module_name = 'shell'

# Generated at 2022-06-10 22:15:47.614825
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    argv = ['ansible-doc','-t','module','-l']
    cli = DocCLI(args=argv)

    assert cli.run() is None


# Generated at 2022-06-10 22:15:50.412766
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    method = DocCLI.get_man_text

    assert len(method({'description': 'This module is maintained by the Ansible Community'})) > 100


# Generated at 2022-06-10 22:16:01.332259
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    cli_args = json.loads('''{"type":"module","json_file":"docs.json",
    "directory":"./lib/ansible/modules","force":false,
    "verbosity":0,"refresh_cache":false,"output_dir":"./docs"}''')

    context.CLIARGS = cli_args
    doc_cli = DocCLI()

    # unit test for get_all_plugins_of_type for 'module'
    res = doc_cli.get_all_plugins_of_type('module')
    assert len(res) == 1596

    # unit test for get_all_plugins_of_type for 'module_util'
    res = doc_cli.get_all_plugins_of_type('module_util')
    assert len(res) == 8

    # unit test for get

# Generated at 2022-06-10 22:16:04.439342
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    cli = DocCLI()
    assert cli.get_plugin_metadata("foo") == {u'foo': {'name':u'foo'}}



# Generated at 2022-06-10 22:16:09.777563
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    display.verbosity = 4
    plugin_list = {}
    add_collection_plugins(plugin_list, 'module')
    assert len(plugin_list) > 0
    assert 'ping' in plugin_list
    assert '/home/travis/virtualenv/python' in plugin_list['ping']



# Generated at 2022-06-10 22:17:45.394795
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    opt_indent = "        "
    limit = 80
    return_values = []

    doc = dict(
        description = "foobar",
        options = dict(
            foobar = dict(
                description = "foobar",
                required = True,
                default = None,
                choices = [ "foo", "bar"]
            )
        ),
        requirements = ["foobar"]
    )

    ansible.cli.docs.doc_base.DocCLI.add_fields(text, doc, limit, opt_indent, return_values)

# Generated at 2022-06-10 22:17:47.545832
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
   try:
      add_collection_plugins()
   except TypeError:
      print('pass')

# Generated at 2022-06-10 22:17:50.955559
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI(args=['ansible-doc', '-l'])
    doc.display_plugin_list()


# Generated at 2022-06-10 22:17:59.709472
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Init ansible module
    import ansible.module_utils.basic
    ansible.module_utils.basic._ANSIBLE_ARGS = namedtuple('_ANSIBLE_ARGS', ['connection','forks','remote_user','private_key_file','ssh_common_args','ssh_extra_args','sftp_extra_args','scp_extra_args','become','become_method','become_user','verbosity','check'])

    # Assume a role json file

# Generated at 2022-06-10 22:18:07.927713
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-10 22:18:18.449527
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Resets the instances
    DocCLI.ALL_PLUGINS = {}
    assert DocCLI.ALL_PLUGINS == {}

    # Create an instance of class DocCLI
    doc_instance = DocCLI()

    # Sets the command line arguments
    context.CLIARGS = {'type' : 'action', 'path' : 'plugins/modules/cloud/amazon/strategy_action.py', 'tree' : False}
    context.docs_module = False

    # Call the method run with the above created object and command line arguments
    doc_instance.run()

    # Check if the all_plugins dict is non-empty
    assert len(DocCLI.ALL_PLUGINS) > 0

if __name__ == "__main__":
    test_DocCLI_run()

# Generated at 2022-06-10 22:18:19.210306
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    pass

# Generated at 2022-06-10 22:18:24.025002
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():

    current_dir = os.getcwd()
    os.chdir('../library/')

    # self.assertEqual(
    #     'namespace',
    #     DocCLI.namespace_from_plugin_filepath('/full/path/to/files/library/file.py')
    # )
    os.chdir(current_dir)


# Generated at 2022-06-10 22:18:30.329549
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    with patch.multiple(display, columns=10) as display_patch:
        # Input parameters
        role = 'test_role'
        role_json = {
            'path': 'some_path',
            'entry_points': {
                'test_entry_point': {
                    'options': {
                        'test_option': {
                            'type': 'str',
                            'default': 'default_value',
                            'short_description': 'test_short_description',
                            'description': 'test_description'
                        }
                    },
                    'attributes': {
                        'test_attribute': {
                            'some_attr': 'some_attr_val'
                        }
                    }
                }
            }
        }

        # Expected results

# Generated at 2022-06-10 22:18:38.288173
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    commands_to_test = set(['module', 'shell', 'inventory', 'lookup', 'callback', 'test', 'strategy', 'vars', 'filter', 'connection'])
    commands_in_doc = set(DocCLI.get_all_plugins_of_type())
    assert commands_to_test == commands_in_doc
    unknown_command = 'unknown'
    assert unknown_command not in DocCLI.get_all_plugins_of_type()