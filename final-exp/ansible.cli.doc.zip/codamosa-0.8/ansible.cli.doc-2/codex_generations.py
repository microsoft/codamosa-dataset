

# Generated at 2022-06-10 22:11:50.605272
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = DocCLI._get_parser().parse_args(['all', 'test/test_runner/test_collections/'] )
    plugin_loader = PluginLoader('./test/test_runner/test_collections/')
    test_collect = plugin_loader.all(subdirs=True)
    for test_plugin in test_collect:
        doc = DocCLI._create_plugin_doc(None, test_plugin)
        doc = DocCLI.get_man_text(doc, collection_name='test_collections')
        display.display(doc)
    plugin = './test/test_runner/test_collections/collection.ansible_collections.test_ns.sub1/plugins/modules/sub1_sub1_sub1_echo.py'
    doc = DocCLI._create_plugin_doc

# Generated at 2022-06-10 22:12:02.035018
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():

    # Test description
    #
    # Test if the format_snippet method with the following conditions:
    #     'module_name' is not empty
    #     'action_name' is not empty
    #     'option_name' is not empty
    #     'option_value' is not empty
    #     'action_aliases' is not empty
    #     'option_aliases' is not empty
    #     'action_default' is not empty
    #     'option_default' is not empty
    #     'yaml_filename' is not empty
    #
    # After execution, the following assertions must be true:
    #     'output' is not equal to empty string
    #     'output' is equal to expected string

    # Using the following input data:
    module_name = 'ping'
    action_name

# Generated at 2022-06-10 22:12:10.412173
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    from ansible.cli.doc import DocCLI

    # Test with empty collection name
    DocCLI.display_plugin_list([""], "", "")

    # Test with collection name and plugin type
    DocCLI.display_plugin_list(["ansible_test.test1 ansible_test.test2 ansible_test.test3"], "test", "plugin")

    # Test with collection name and plugin type
    DocCLI.display_plugin_list(["test1 test2 test3"], "test", "plugin")



# Generated at 2022-06-10 22:12:17.383772
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    opt = {"type": "action",
           "default": "bytes",
           "description": "What to return.  If this is 'str', the resulting data will be decoded to a string using the 'errors' and 'encoding' options.  If this is 'bytes', return the raw data.",
           "required": False,
           "options": ["bytes", "str"],
           "aliases": ["return_content"],
           "version_added": "1.8",
           "_aliases": ["return_content"],
           "_merge": False,
           "_return_type": "dict(raw: bool, msg: str)"}

    # create a instance DocCLI
    cli = DocCLI()

    # test the method get_man_text

# Generated at 2022-06-10 22:12:25.129436
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    snippet = '{"test_key_one":"test_value_one", "test_key_two": "test_value_two"}'
    snippet_expected_result = '{\n  "test_key_one": "test_value_one",\n  "test_key_two": "test_value_two"\n}'
    assert DocCLI.format_snippet(snippet) == snippet_expected_result

# Generated at 2022-06-10 22:12:34.916773
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    from ansible.utils.display import Display
    from ansible.module_utils.six import StringIO
    display = Display()
    display.columns = 80
    DocCLI.tty_ify = lambda x: x # required for pylint
    test_doc = {
        'description': 'This is a test',
        'options': {
          'test_option': {
            'description': [
              'This is a test option'
            ],
            'required': True,
            'type': 'str'
          }
        }
    }
    output = DocCLI.get_man_text(test_doc)

    # Test output

# Generated at 2022-06-10 22:12:47.754691
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # Test with a roles/module filepath
    test_filepath = '/foo/bar/baz/roles/module.py'
    expected_namespace = 'module'
    result_namespace = DocCLI.namespace_from_plugin_filepath(test_filepath)
    assert result_namespace == expected_namespace

    # Test with a roles/module filepath
    test_filepath = '/foo/bar/baz/roles/module_bar.py'
    expected_namespace = 'module_bar'
    result_namespace = DocCLI.namespace_from_plugin_filepath(test_filepath)
    assert result_namespace == expected_namespace

    # Test with an action plugin filepath

# Generated at 2022-06-10 22:12:52.125097
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    from ansible.cli.doc import DocCLI
    from ansible.module_utils._text import to_bytes
    from unit.mock import patch, mock_open

# Generated at 2022-06-10 22:12:57.147008
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-10 22:13:07.627373
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doccli = DocCLI()
    all_plugins = doccli.get_all_plugins_of_type()
    # Test Ansible Modules
    assert 'actionlib' in all_plugins
    assert 'accelerate' in all_plugins
    assert 'accelerate' in all_plugins
    assert 'acme_certificate' in all_plugins

    # Test Ansible Module Utils
    assert 'acid' in all_plugins

    # Test Ansible Plugins
    assert 'action' in all_plugins
    assert 'alias' in all_plugins
    assert 'apt' in all_plugins

    # Test Ansible Modules deprecated
    assert 'acme_account' in all_plugins

    # Test Ansible Collections
    assert 'nsxt_ansible_plugins' in all_plugins


# Generated at 2022-06-10 22:14:03.362823
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    test_dict = dict()
    test_dict['doc'] = "test string"
    test_dict['filename'] = "filename"
    assert doc.get_all_plugins_of_type('str')[0] == test_dict


# Generated at 2022-06-10 22:14:12.292715
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    cli_doc = '''
    #!ansible
    - name: myname
      short_description: myshortdesc
      description:
        - mydesc
      version_added: "2.5"
      author:
        - "myauthor"
      notes:
        - mynote
      seealso:
        - module: mymodule
          description: mydesc
      options:
        myopt:
          description: mydesc
          choices: [mychoice]
        myopt2:
          description: mydesc
          required: true
      attributes:
        myatt: myattdesc
      examples:
        - path: /path/to/examples
      returndocs:
        myreturn: myreturndesc
    '''
    cli_args = {'type': 'module'}
    # Workaround https

# Generated at 2022-06-10 22:14:20.811350
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    '''test_DocCLI_display_plugin_list'''
    from ansible.cli import CLI
    from ansible.utils.display import Display
    from ansible.utils.color import stringc

    display = Display()
    display.columns = 80
    display.verbosity = 3
    display.color = 1

    cli = CLI(args=['ansible-doc', '-l'], display=display)
    assert cli is not None
    DocCLI.display_plugin_list(cli)


# Generated at 2022-06-10 22:14:29.568010
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    DOC = copy.deepcopy(DOCUMENTATION)
    EXAMPLES = copy.deepcopy(EXAMPLES)
    RETURNS = copy.deepcopy(RETURNS)
    enumerate_callback = enumerate
    open_mock = mock.mock_open()
    with mock.patch.dict('sys.modules', {'six.moves': mock.Mock()}):
        mocked_enumerate = mock.Mock()
        mocked_enumerate.return_value = enumerate_callback
        setattr(mocked_enumerate, '__getitem__', lambda x, y: enumerate_callback)
        sys.modules['six.moves'].enumerate = mocked_enumerate
        with mock.patch('__builtin__.open', open_mock, create=True):
            set

# Generated at 2022-06-10 22:14:37.087137
# Unit test for method run of class DocCLI
def test_DocCLI_run():
  src = '''
module: win_module
version_added: "1.0.0"
short_description: Manage a windows module
options:
  src_path:
    description:
      - "The location of the module to be installed"
    required: true
    default: "{{ module_path }}"
    version_added: "1.0.0"
  dest:
    description:
      - "Where the module will be installed"
    required: false
    default: "{{ module_path }}\\{{ src }}"
    version_added: "1.0.0"
'''
  with patch('ansible.cli.doc.open', mock_open(read_data=src), create=True):
    doc_cli = DocCLI()
    doc_cli.run()

# Generated at 2022-06-10 22:14:47.464477
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-10 22:14:50.223683
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    DocCLI(name="doc").display_plugin_list(constants.DOCUMENTABLE)
    # Test shouldn't actually test anything, just ensure the method runs.
    # It was written to test behavior with no plugins loaded.
    assert True == True


# Generated at 2022-06-10 22:15:00.460601
# Unit test for method display_plugin_list of class DocCLI

# Generated at 2022-06-10 22:15:06.996670
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    assert set(doc.get_all_plugins_of_type('module')) == set(['copy'])
    assert set(doc.get_all_plugins_of_type('module', include_aliases=True)) == set(['copy'])
    assert set(doc.get_all_plugins_of_type('module', include_aliases=False)) == set(['copy'])
    assert set(doc.get_all_plugins_of_type('module', include_deprecated=True)) == set(['copy'])
    assert set(doc.get_all_plugins_of_type('module', include_deprecated=False)) == set(['copy'])
    assert set(doc.get_all_plugins_of_type('module', preload_content=False)) == set(['copy'])

# Generated at 2022-06-10 22:15:13.896915
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    for test_path in ('', '..', '../..', os.path.dirname(__file__)):
        test_paths = DocCLI.perms_paths([test_path])
        assert isinstance(test_paths, list)
        assert isinstance(test_paths[0], string_types)
# Unit tests for method get_role_man_text of class DocCLI

# Generated at 2022-06-10 22:16:00.273086
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    """Test for ansible.utils.display.DocCLI.format_snippet"""
    result = DocCLI.format_snippet(['some_options'])
    assert result == 'some_options'


# Generated at 2022-06-10 22:16:01.746717
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    cli = DocCLI()
    cli.run()

# Generated at 2022-06-10 22:16:13.212564
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    import json
    import os

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.dirname(test_dir)
    test_dir = os.path.join(test_dir, 'lib')
    test_dir = os.path.join(test_dir, 'ansible')
    test_dir = os.path.join(test_dir, 'modules')
    test_dir = os.path.join(test_dir, 'windows')

    doc_filename = "win_group.json"

    with open(os.path.join(test_dir, doc_filename), 'rb') as f:
        doc = json.load(f)

    test_doc = DocCLI.get_man_text(doc)
    #print(test_doc

# Generated at 2022-06-10 22:16:18.056400
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    add_collection_plugins(plugin_list,'shell')
    assert type(plugin_list) == dict
    assert len(plugin_list) == 0 # No collections installed


# Generated at 2022-06-10 22:16:29.874636
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []

# Generated at 2022-06-10 22:16:36.777985
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    _test_data_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    # test with a alias plugin
    alias = DocCLI.get_plugin_metadata(_test_data_path, "alias")
    assert_equal(alias.get('name'), 'alias')
    assert_equal(alias.get('version_added'), '2.6')
    assert_equal(alias.get('aliases'), ['existing'])
    # test with a module plugin
    libvirt_volume_info = DocCLI.get_plugin_metadata(_test_data_path, "libvirt_volume_info")
    assert_equal(libvirt_volume_info.get('name'), 'libvirt_volume_info')

# Generated at 2022-06-10 22:16:49.317081
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    from ansible.utils.display import Display
    display = Display()
    display.columns = 80

# Generated at 2022-06-10 22:17:00.148145
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    plugin_doc = DocCLI()
    plugin_doc.content = dict(_raw_params='_raw_params',
                              aliases='aliases',
                              author='author',
                              choices='choices',
                              deprecated='deprecated',
                              description='description',
                              filename='filename',
                              has_action='has_action',
                              notes='notes',
                              options='options',
                              plainexamples='plainexamples',
                              requirements='requirements',
                              returndocs='returndocs',
                              seealso='seealso',
                              version_added='version_added',
                              version_added_collection='version_added_collection')
    plugin_doc.plugin_type = 'plugin_type'
    text = plugin_doc.format_plugin_doc()
   

# Generated at 2022-06-10 22:17:08.896994
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    data = DocCLI().get_plugin_metadata()
    assert type(data) is dict
    assert data.get('name')
    assert data.get('description')
    assert data.get('description_fr')
    assert data.get('short_description')
    assert data.get('version')
    assert data.get('supports_check_mode')
    assert data.get('deprecated')
    assert data.get('deprecated_options')
    assert data.get('options')
    assert data.get('required_if')
    assert data.get('required_one_of')
    assert data.get('required_together')
    assert data.get('invalid_if')
    assert data.get('aliases')



# Generated at 2022-06-10 22:17:13.859000
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    class Test_DocCLI(DocCLI):
        pass
    mod = {'name': 'Test', 'doc': 'This is a test', 'arguments': ['a', 'b'], 'filename': 'foo'}
    result = Test_DocCLI.get_man_text(mod)
    output = "> TEST    (foo)\nThis is a test\n\nOPTIONS (= is mandatory):\n        A\n        B\n"
    assert result == output


# Generated at 2022-06-10 22:18:22.980177
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():

    from ansible.cli.doc import DocCLI
    from test.support.unit import skipIf
    from sys import version_info

    display = Display()
    display.columns = 80

    if version_info.major == 2:
        assert_equal(DocCLI.format_snippet("echo hello world", "Bash"), u"echo '{{ ansible_managed }}'\necho hello world")

        assert_equal(DocCLI.format_snippet("echo hello world", "PowerShell"), u"Write-Output '{{ ansible_managed }}'\nWrite-Output 'hello'\nWrite-Output 'world'")

        assert_equal(DocCLI.format_snippet("echo hello world", "Python"), u"print '{{ ansible_managed }}'\nprint 'hello'\nprint 'world'")



# Generated at 2022-06-10 22:18:28.430340
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    import unittest

    class TestDocCLI(unittest.TestCase):
        def setUp(self):
            context._init_global_context(['ansible', '-m', 'wait_for', '-a', 'port=22', 'localhost'])

        def tearDown(self):
            context._clear_global_context()

        def test_get_all_plugins_of_type(self):
            cls = DocCLI()
            cls.get_all_plugins_of_type()

    unittest.main()


# Generated at 2022-06-10 22:18:40.542442
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    options = yaml.load('''
    - option1:
        type: string
        description:
            - This is test description.
        default: default value
        suboptions:
            - option1_1:
                type: string
                description:
                    - This is test description.
                default: default value
    ''')
    limit = 60
    opt_indent = '    '
    DocCLI.IGNORE = []
    DocCLI.add_fields(text, options, limit, opt_indent, return_values=False, ret_indent='')

# Generated at 2022-06-10 22:18:47.046979
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # obj arguments
    obj_args = None
    # obj expected
    obj_expected = True
    obj_expected_output = True
    # Run module
    with pytest.raises(SystemExit):
        DocCLI.display_plugin_list(obj_args)
    # Verify
    assert obj_expected == obj_expected_output
    # Return
    return


# Generated at 2022-06-10 22:18:58.476475
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    DocCLI.IGNORE = DocCLI.IGNORE + (context.CLIARGS['type'],)
    text = []
    pad = display.columns * 0.20
    limit = max(display.columns - int(pad), 70)
    doc = dict()
    opt_indent = "        "

    # test for method add_fields, where there is a parameter passed to 
    # method add_fields.
    # test for method add_fields, where there is a parameter passed to 
    # method add_fields.
    # test for method add_fields, where there is a parameter passed to 
    # method add_fields.
    # test for method add_fields, where there is a parameter passed to 
    # method add_fields.
    # test for method add_fields, where there is a parameter passed to 