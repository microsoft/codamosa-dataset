

# Generated at 2022-06-10 22:11:23.998090
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    my_doc_cli = DocCLI()

# Generated at 2022-06-10 22:11:39.203794
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    doc = DocCLI(context.CLIARGS)
    if os.path.isdir(C.DEFAULT_LOCAL_TMP):
        shutil.rmtree(C.DEFAULT_LOCAL_TMP)
        os.makedirs(C.DEFAULT_LOCAL_TMP, mode=0o700)

    for plugin in ('module', 'lookup', 'filter', 'callback', 'test', 'doc_fragments', 'connection'):
        plugin_dir = os.path.join(C.DEFAULT_LOCAL_TMP, plugin)
        os.makedirs(plugin_dir, mode=0o700)

        with open(os.path.join(plugin_dir, '__init__.py'), 'w') as f:
            f.write('#')


# Generated at 2022-06-10 22:11:48.502230
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    required_params = ['module_name']
    optional_params = ['delay', 'host', 'port', 'timeout', 'username']

# Generated at 2022-06-10 22:11:50.383681
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc_cli = DocCLI(args=[])
    assert doc_cli.run() is None


# Generated at 2022-06-10 22:12:01.724680
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-10 22:12:09.040714
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'filter'
    coll_filter = None
    ptype = C.COLLECTION_PTYPE_COMPAT.get(plugin_type, plugin_type)
    assert DocCLI.find_plugins(os.path.join('path', 'plugins', ptype), False, plugin_type, collection='collname')
    assert plugin_list.update()
    assert collname == _get_collection_name_from_path('path')


# Generated at 2022-06-10 22:12:16.733235
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    """
    DocCLI.find_plugins
    """
    cli = DocCLI()
    cli.parser = FakeParser()
    # No plugin_type or collection_name
    with patch('os.path.isfile', MagicMock(return_value=True)):
        cli.find_plugins()
    # With plugin_type and no collection_name
    with patch('os.path.isfile', MagicMock(return_value=True)):
        cli.find_plugins(plugin_type='action')
    # With collection_name
    with patch('os.path.isfile', MagicMock(return_value=True)):
        cli.find_plugins(collection_name='cloud.amazon')
    # With module

# Generated at 2022-06-10 22:12:22.347632
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    try:
        # This test is currently not supported, as it requires a real file
        # system.
        raise AssertionError("Test not supported")
        doc_cli = DocCLI()
        doc_cli.get_role_man_text("test", None)
    except Exception:
        assert False

# Generated at 2022-06-10 22:12:28.373063
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    class TestObject(object):
        args = {'type': 'module'}
        display = {'verbosity': 0}

    obj = TestObject()
    doc_cli = DocCLI(obj)
    plugins = doc_cli.find_plugins()
    for plugin in plugins:
        assert isinstance(plugin, Mapping)
        assert 'plugin_type' in plugin
        assert isinstance(plugin['plugin_type'], string_types)
        assert 'name' in plugin
        assert isinstance(plugin['name'], string_types)
        assert 'path' in plugin
        assert isinstance(plugin['path'], string_types)



# Generated at 2022-06-10 22:12:36.157462
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.utils.display import Display
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text, to_bytes
    display = Display()


# Generated at 2022-06-10 22:14:54.069416
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Setup
    plugin_type = 'foo'
    name_match = 'bar'

    collection_filter = None
    collection_filter_name = None
    display_snippet = True
    display_metadata = True
    display_all = True
    display_collections = False

    cli_plugin_filter = DocCLI.PluginFilter(plugin_type=plugin_type,
                                            name_match=name_match,
                                            collection_filter=collection_filter,
                                            collection_filter_name=collection_filter_name,
                                            display_snippet=display_snippet,
                                            display_all=display_all,
                                            display_metadata=display_metadata,
                                            display_collections=display_collections)

    display_document = False
    search_paths

# Generated at 2022-06-10 22:15:02.449832
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    if not os.path.isdir(DocCLI.explore_path):
        raise AssertionError("DocCLI.explore_path %s does not exist" % DocCLI.explore_path)

    plugins = DocCLI.find_plugins(os.path.realpath(DocCLI.explore_path))

    assert len(plugins) > 0, "found plugins"

    for plugin in plugins:
        test_aliases = plugin.pop('aliases', [])
        test_shortdesc = plugin.pop('short_description', '')
        test_version = plugin.pop('version_added', '')
        test_version_collection = plugin.pop('version_added_collection', '')

        if test_version_collection is None:
            test_version_collection = ''

        test_deprecated = plugin.pop

# Generated at 2022-06-10 22:15:04.087207
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = DocCLI()
    with pytest.raises(AnsibleError):
        doc.get_plugin_metadata('mymodule', 'module')

# Generated at 2022-06-10 22:15:09.080511
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Create test object
    _object = DocCLI()
    # Create text list
    text = []
    # Create test data
    test_data = {'test_option': {"required": True, "type": "bool"}}
    # Execute tested method
    _object.add_fields(text, test_data)
    # Check result
    assert(text == ['        TEST_OPTION: [boolean] [Required]', u'        Indicates if a value is required.'])

test_DocCLI_add_fields()


# Generated at 2022-06-10 22:15:13.461082
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():

    import pprint
    display = Display()
    display.columns = 80
    ##############################################################################
    # There are 3 steps to add a unit test to this method:
    # 1) Add a doc_input dictionary to be passed to add_fields
    # 2) Add a expected_text string to hold the expected string to be returned
    # 3) Add the information to the unit_test_data dictionary
    ##############################################################################

    # Step 1: Add a doc_input dictionary to be passed to add_fields

# Generated at 2022-06-10 22:15:15.608825
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    test_list = {}
    add_collection_plugins(test_list, 'cliconf')
    assert test_list is not None


# Generated at 2022-06-10 22:15:24.001137
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-10 22:15:40.038599
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():

    # Create an instance of the DocCLI class
    doc_obj = DocCLI()

    # A list of plugins to be documented
    plugin_list = [
        "doccli.py",
        "doc_fragments",
        "module_utils",
        "modules",
        "callback",
        "cliconf",
        "cloud",
        "connection",
        "httpapi",
        "inventory",
        "lookup",
        "shell",
        "test",
        "vars",
        "windows"
    ]
    assert doc_obj.find_plugins(plugin_list) == plugin_list


# Generated at 2022-06-10 22:15:45.923432
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    with open('test/test_docs_fragments/test_docs_cli_get_man_text.json', 'r') as fh:
        module_json = json.load(fh)
    module_json["filename"] = "test/test_docs_fragments/test_docs_cli_get_man_text.py"
    ansible_doc = DocCLI()
    ansible_doc.get_man_text(module_json, collection_name='cloud.azure')
    assert False


# Generated at 2022-06-10 22:15:55.855319
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    output = DocCLI.format_snippet(True)
    assert output == 'True'
    output = DocCLI.format_snippet(False)
    assert output == 'False'
    output = DocCLI.format_snippet('a string')
    assert output == '"a string"'
    output = DocCLI.format_snippet('a string with double quotes"')
    assert output == '"a string with double quotes""'
    output = DocCLI.format_snippet(1)
    assert output == '1'
    output = DocCLI.format_snippet(123)
    assert output == '123'
    output = DocCLI.format_snippet(1234567890)
    assert output == '1234567890L'
    output = DocCLI.format_sn

# Generated at 2022-06-10 22:18:13.289286
# Unit test for function jdump
def test_jdump():
    # Test Dumper for Syntax
    display.display(json.dumps(None, cls=AnsibleJSONEncoder, sort_keys=True, indent=4))
# ----



# Generated at 2022-06-10 22:18:21.348942
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'module'
    import ansible.constants as constants
    print(constants.__file__)
    print(plugin_list)
    add_collection_plugins(plugin_list, plugin_type)
    assert isinstance(plugin_list, dict)
    for k, v in plugin_list.items():
        assert isinstance(k, str)
        assert isinstance(v, list)
        assert isinstance(v[0], str)
        assert v[0].startswith('/')
    print(plugin_list)
# Unit tests for function add_collection_plugins



# Generated at 2022-06-10 22:18:23.902271
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI(args={})
    doc.display_plugin_list()
    assert os.path.exists("plugins.rst")


# Generated at 2022-06-10 22:18:27.408225
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    result = DocCLI.format_snippet("tasks:", "      - name: this is a task", "        debug:", "          msg: 'this is a message'")
    assert result == """tasks:
      - name: this is a task
        debug:
          msg: 'this is a message'"""


# Generated at 2022-06-10 22:18:40.005823
# Unit test for method get_all_plugins_of_type of class DocCLI

# Generated at 2022-06-10 22:18:51.115180
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    import imp
    from ansible.module_utils.six import PY2
    if PY2:
        from ansible.plugins import module_loader
    else:
        from ansible.plugins import module_loader3 as module_loader

    doc = DocCLI()

    # The plugin_modules directory is not populated during a tox run
    dirs, _ = module_loader.find_plugins(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), 'plugins', 'modules'), '', imp)

    for p in dirs:
        doc.get_all_plugins_of_type('module', p)

# Generated at 2022-06-10 22:18:57.154364
# Unit test for method get_man_text of class DocCLI