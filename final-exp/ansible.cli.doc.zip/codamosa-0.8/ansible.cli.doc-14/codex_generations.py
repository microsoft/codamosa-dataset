

# Generated at 2022-06-10 22:11:23.006615
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    class AnsibleOptions():
        verbosity = 0
        show_snippets = False
        show_deprecated = False
        collection_name = ''

    collection_name='ansible.builtin'
    cmd='lookup'
    module_name='to_nice_yaml'
    module_path='/usr/lib/python3.6/site-packages/ansible/plugins/lookup'
    name='to_nice_yaml'

    context.CLIARGS = AnsibleOptions()

    log.has_logger = True

    # Create doc to pass to DocCLI.get_role_man_text
    # create_doc()
    # test_loader.load_module()
    # test_module._load_params()
    # test_module.get_parsed_docs()
    # test_module

# Generated at 2022-06-10 22:11:37.120434
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Unit: Return help text for a module
    # Setup
    from .connection_info import get_connection_info, ConnectionInformation
    from .config import get_config as get_std_config
    from .config import get_config
    self = Mock()
    self.config = get_std_config()
    self.config.load_config_file(None)
    self.config.get_config_value = get_config
    self.args = Mock()
    self.args.args = list()
    self.args.extra_vars = list()
    self.args.host_pattern = None
    self.args.check = False
    self.args.syntax = False
    self.args.connection = 'ssh'
    self.args.module_path = None
    self.args.forks = None
    self.args

# Generated at 2022-06-10 22:11:42.504788
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    from ansible.cli.doc import DocCLI
    from ansible import constants as C
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.loader import module_loader

    cli_args = {'type': 'module', 'list_dirs': True}
    #this will add all the default paths to C.DEFAULT_ANSIBLE_COLLECTIONS_PATHS
    ac = AnsibleCollectionLoader()
    paths = ac.get_collection_paths()
    docs = DocCLI(args=cli_args)
    docs.get_plugin_metadata(paths, C.DEFAULT_MODULE_PATH, 'module')
    docs.get_plugin_metadata(paths, C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugin')
    docs.get_plugin_

# Generated at 2022-06-10 22:11:43.620627
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = get_plugin_metadata('apt')
    assert doc['name'] == 'apt'


# Generated at 2022-06-10 22:11:44.236363
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    pass

# Generated at 2022-06-10 22:11:48.078128
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    # unit test for add_collection_plugins

    plugin_list = {}
    plugin_type = 'module'
    coll_filter = None
    coll_filter = 'mycollection'
    coll_filter = 'othercollection'
    # add plugins from collections
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert len(plugin_list) > 0


# Generated at 2022-06-10 22:11:49.574877
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()
    doc.display_plugin_list()


# Generated at 2022-06-10 22:12:00.990190
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    '''Test function get_man_text of class DocCLI
    '''

    # mock an options doc
    options = OrderedDict()
    options['constant_value'] = {
        'default': 'foo',
        'description': 'This is a constant value.',
        'type': 'str',
        'choices': ['foo', 'bar'],
        'version_added': '2.4'
    }
    options['required_key'] = {
        'default': '',
        'description': 'This value must be provided.',
        'required': True,
        'type': 'str'
    }
    options['other_key'] = {
        'default': '',
        'description': 'This value is not required.',
        'required': False,
        'type': 'str'
    }

# Generated at 2022-06-10 22:12:03.996678
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    """Test for display_plugin_list."""

    with pytest.raises(AssertionError):
        DocCLI().display_plugin_list('asd', 'asd')

# Generated at 2022-06-10 22:12:13.507630
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    DocCLI = DocCLI()
    category = 'Network'
    if category:
        text.append("%s\n" % category)

    for (module, doc) in get_doc(coverage=coverage, directory=directory):
        if 'module' in doc:  # otherwise its a aliase
            if category and doc['module'].rsplit('_', 1)[0].lower() != category.lower():
                continue

            if not only_names or module in only_names:
                text.append(DocCLI.get_man_text(doc))
    print(text)
test_DocCLI_get_man_text()


# Generated at 2022-06-10 22:13:25.065814
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    class options:
        plain = True
        roles = False
    context.CLIARGS = options
    text = DocCLI.format_plugin_doc('meta.py')
    if text.count('\n') != 3:
        return False

    context.CLIARGS = {}
    text = DocCLI.format_plugin_doc('cronvar.py')
    if text.count('\n') != 6:
        return False

    context.CLIARGS = {}
    text = DocCLI.format_plugin_doc('copy.py')
    # space around colon add one more newline
    if text.count('\n') != 114:
        return False

    context.CLIARGS = {}
    text = DocCLI.format_plugin_doc('uri.py')

# Generated at 2022-06-10 22:13:34.944675
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 70
    opt_indent = "        "
    return_values = False
    options = {
        'cluster_id': {
            'description': ["The ID of the cluster which the VMs will be created."],
            'required': True,
            'type': 'str'
        },
        'cluster_name': {
            'description': ["The name of the cluster which the VMs will be created."],
            'required': True,
            'type': 'str'
        }
    }
    DocCLI.add_fields(text, options, limit, opt_indent, return_values)
    print(text)



# Generated at 2022-06-10 22:13:36.081995
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Needs to be implemented!
    raise Exception('Test not implemented!')

# Generated at 2022-06-10 22:13:43.599554
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    import json
    import os
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import string_types
    DocCLI.IGNORE = DocCLI.IGNORE + (context.CLIARGS['type'],)
    pad = display.columns * 0.20
    limit = max(display.columns - int(pad), 70)


# Generated at 2022-06-10 22:13:47.189554
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    # TODO: test with non-empty collection filter
    add_collection_plugins(plugin_list, 'action_plugin', None)
    # TODO: test with non-empty plugin_list
    assert len(plugin_list) > 0
    assert 'letme_add_one' in plugin_list


# Generated at 2022-06-10 22:13:55.688328
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    from collections import defaultdict
    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    def make_module_doc(name, description, version_added=None, version_added_collection=None):
        return {
            'name': name,
            'description': description,
            'version_added': version_added,
            'version_added_collection': version_added_collection
        }

    class MockContext(object):
        def __init__(self):
            self.CLIARGS = defaultdict(lambda: '')

    class MockDisplay(object):
        columns = 80

    # These tests assume a particular display width
    assert display.columns == 80, 'display.columns must be 80 to run the tests'

# Generated at 2022-06-10 22:14:02.227407
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = max(display.columns - int(display.columns * 0.2), 70)
    opt_indent = "        "
    return_values = False
    DocCLI.add_fields(text, {}, limit, opt_indent, return_values, opt_indent)
    assert "" == "\n".join(text)



# Generated at 2022-06-10 22:14:11.722811
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
  # arg1: text, must be a list
  # arg2: opt, a dict to be added to text
  # arg3: limit, an int for text limit
  # arg4: optional, opt_indent, a string to be added to text
  # arg5: optional, return_values, a boolean to indicate values will be returned
  # arg6: optional, root_indent, a string to be added to text
  #
  # This function will add opt to text, and return the text
  # The return-value part is not tested
  #
  # Test for empty opt
  text1=[]
  opt1=[]
  result1=DocCLI.add_fields(text1,opt1,80)
  assert(result1==[])
  text1=["first line"]
  opt1=[]
  result1

# Generated at 2022-06-10 22:14:17.481904
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    snippet = 'this is a test'
    result = DocCLI._format_snippet(snippet, True)
    expected_result = '``` this is a test```'
    assert result == expected_result, 'Generated snippet differs from expected result'

# Generated at 2022-06-10 22:14:20.898809
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # No such path in docs/
    with pytest.raises(SystemExit):
        DocCLI.find_plugins("module_utils", "the_great_gatsby")
    # Test when module_utils is not empty
    DocCLI.find_plugins("module_utils", "lib/ansible/module_utils/")
    DocCLI.find_plugins("module_utils", "module_utils")
    # Test when module_utils is empty
    DocCLI.find_plugins("module_utils", "")
