

# Generated at 2022-06-10 22:11:44.350221
# Unit test for method run of class DocCLI

# Generated at 2022-06-10 22:11:47.875743
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Create instance of class DocCLI
    doc_cli_obj = DocCLI( {}, [])
    # Get result using method get_all_plugins_of_type
    # TODO: Add parameters
    result = doc_cli_obj.get_all_plugins_of_type()
    # Verify result
    assert result is None

# Generated at 2022-06-10 22:11:51.781721
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    opts = DocCLI()
    metadata = opts.get_plugin_metadata("copy")
    if metadata is None:
        raise AssertionError("Failed: DocCLI.get_plugin_metadata()")


# Generated at 2022-06-10 22:12:02.774828
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    fake_args = ['ansible-doc', '--list', '--dir', '..']
    # First check that it works with the function that it actually invokes
    with patch.object(BaseCLI, 'get_plugin_list', return_value={'modules': [], 'plugins': [], 'module_utils': [], 'doc_fragments': []}):
        with patch.object(DocCLI, 'pager'):
            assert DocCLI(args=fake_args).run() == 0
    # Then check that it works with the function that it invokes (which invokes get_plugin_list)

# Generated at 2022-06-10 22:12:13.741503
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():

    assert [] == DocCLI.get_all_plugins_of_type(plugin_type='module')
    assert [] == DocCLI.get_all_plugins_of_type(plugin_type='module', paths=['doesnotexist'])
    assert [] == DocCLI.get_all_plugins_of_type(plugin_type='module', paths=[os.path.dirname(__file__)])

    # get_all_plugins_of_type does not find all paths containing modules, hence the need for a custom module path
    custom_module_path = os.path.join(os.path.dirname(__file__), 'data/modules_with_multiple_paths')
    paths = [custom_module_path]

# Generated at 2022-06-10 22:12:28.119560
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():

    # Test module type
    argv = ['ansible-doc', '-t', 'module']
    context.CLIARGS = DocCLI.parse()
    doc = DocCLI()
    assert context.CLIARGS['type'] == 'module'
    assert doc.get_plugin_metadata('setup')

    # Test connection type
    argv = ['ansible-doc', '-t', 'connection']
    context.CLIARGS = DocCLI.parse()
    doc = DocCLI()
    assert context.CLIARGS['type'] == 'connection'
    assert doc.get_plugin_metadata('local')

    # Test lookup type
    argv = ['ansible-doc', '-t', 'lookup']
    context.CLIARGS = DocCLI.parse()
    doc = DocCLI()

# Generated at 2022-06-10 22:12:30.622355
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'lookup'
    # Test without a coll_filter
    add_collection_plugins(plugin_list, plugin_type)
    assert plugin_list
    for k, v in plugin_list.items():
        #test that the paths are absolute
        assert os.path.isabs(v)



# This class is exposed for testing purposes, since it does not need to be
# instantiated for each test and also provides a common set of helper methods
# for test cases.

# Generated at 2022-06-10 22:12:37.019250
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    from copy import deepcopy
    from ansibledocgen.plugins.module_utils.module_docs import DOCUMENTATION

    ansible_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))

    context.CLIARGS = {'list_dir': os.path.join(ansible_path, 'lib/ansible/modules/cloud/amazon/'),
                       'list_only': True,
                       'type': 'module',
                       'metadata': os.path.join(ansible_path, 'lib/ansible/modules/cloud/amazon/ec2_vpc_igw.py'),
                       'output': "add_fields_test.md",
                       'verbosity': None}

    doc = DOCUM

# Generated at 2022-06-10 22:12:49.333056
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    actual = DocCLI.format_plugin_doc('sample_doc', 'sample_type')

# Generated at 2022-06-10 22:12:50.965641
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    cli = DocCLI(args=['ansible-doc', 'doc.txt'])
    cli.run()



# Generated at 2022-06-10 22:13:49.309695
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    import sys
    import tempfile
    import textwrap
    import ansible.utils.display as display
    import ansible.module_utils.basic as basic
    import ansible.module_utils.common as common
    import ansible.constants as constants
    import ansible.utils.unsafe_proxy as unsafe_proxy
    import ansible.compat.six as six
    
    class TestDocCLI_add_fields(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_DocCLI_add_fields(self):
            #initialize the test data
            one_str = "test"
            one_list = ["test1", "test2"]
            test_list = ["test1", "test2"]

# Generated at 2022-06-10 22:13:54.160563
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    doc = {'a':{'options':{'b':{},'c':{},'d':{},'e':{},'f':{}}}}
    DocCLI.add_fields(doc, 'a')
    assert doc == {'a':{'options':{'b':{},'c':{},'d':{},'e':{},'f':{}}}}


# Generated at 2022-06-10 22:14:04.548237
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # create an instance of the Ansible class
    ans = Ansible()
    # create an instance of the DocCLI class
    doc_cli = DocCLI(ans)

    plugin_type = 'module'

    # retrieve the modules
    modules = [module for module in C.MODULE_PATH]

    # retrieve the list of all the plugins from the get_all_plugins_of_type method
    get_all_plugins_of_type = [item for item in doc_cli.get_all_plugins_of_type(plugin_type)]

    # compare the content of the list with the content of the modules
    assert sorted(get_all_plugins_of_type) == sorted(modules)


# Generated at 2022-06-10 22:14:07.535560
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    DocCLI.add_fields(text, [], 1, '', False, '')
    assert text == ['']

# Generated at 2022-06-10 22:14:12.159454
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'Sample description',
        'options': {
            'dir_name': {
                'description': 'Directory name',
                'required': True,
                'type': 'str'
            }
        }
    }

    text = DocCLI.get_man_text(doc)

    assert text == """
>  (None)

Sample description

OPTIONS (= is mandatory):
    dir_name (=): Directory name

""".strip()

# Generated at 2022-06-10 22:14:22.365132
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    docCLI = DocCLI()
    plugin_type = 'test_plugin_type'
    # Default to ansible_directory
    expected_result = list(docCLI._get_plugins_path_by_type(plugin_type))
    result = docCLI.find_plugins(plugin_type)
    assert (expected_result == result)

    # Default to custom_directory
    custom_directory = "test_custom_directory"
    expected_result = list(docCLI._get_plugins_path_by_type(plugin_type, custom_directory))
    result = docCLI.find_plugins(plugin_type, custom_directory)
    assert (expected_result == result)

# Generated at 2022-06-10 22:14:26.155920
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    '''test: format_snippet of class DocCLI'''
    snippet = "this is a test"
    f = DocCLI.format_snippet(snippet)
    assert f.strip() == snippet.strip()
    assert display.columns in f


# Generated at 2022-06-10 22:14:27.839052
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    print(DocCLI.find_plugins())

test_DocCLI_find_plugins()


# Generated at 2022-06-10 22:14:30.622670
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Setup
    doc = DocCLI({})
    # Exercise
    doc.run()
    # Verify
    # Shouldn't get here as DocCLI.run() exits.
    assert False

# Generated at 2022-06-10 22:14:32.457666
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    display_plugin_list_output = DocCLI().display_plugin_list()
    assert display_plugin_list_output == None


# Generated at 2022-06-10 22:15:31.306223
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    doc.get_all_plugins_of_type('become')

# Generated at 2022-06-10 22:15:40.693258
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
  # Unit: test the DocCLI instance
  doccli = DocCLI()
  # Unit: test to retrieve the metadata of the ping module
  metadata = doccli.get_plugin_metadata('ping')
  # Unit: basic test, each new module must have a name
  assert 'name' in metadata
  # Unit: basic test, each new module must have a 'version_added'
  assert 'version_added' in metadata
  # Unit: basic test, each new module must have a 'description'
  assert 'description' in metadata



# Generated at 2022-06-10 22:15:48.822251
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():

    # Test with EXAMPLE_FILENAME_FORMATS_MODULE_PACKAGE_TRUE
    for t in EXAMPLE_FILENAME_FORMATS_MODULE_PACKAGE_TRUE:
        expected_namespace = os.path.dirname(t)
        expected_namespace = expected_namespace.split(os.path.sep)
        expected_namespace.pop()
        expected_namespace = ".".join(expected_namespace)
        result = DocCLI.namespace_from_plugin_filepath(t)
        assert expected_namespace == result, (
            "expected %s but got %s" % (expected_namespace, result)
        )

    # Test with EXAMPLE_FILENAME_FORMATS_MODULE_PACKAGE_FALSE

# Generated at 2022-06-10 22:15:59.292667
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-10 22:16:05.667607
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    subdirs = [""]
    # Test with find_plugins() as a classmethod
    plugins = DocCLI.find_plugins(subdirs)

    assert isinstance(plugins, list)
    assert len(plugins) > 0

    # Test with find_plugins() as a staticmethod
    plugins = DocCLI.find_plugins(subdirs)

    assert isinstance(plugins, list)
    assert len(plugins) > 0



# Generated at 2022-06-10 22:16:15.366308
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    import six
    expected_plugins = {'ansible.posix.copy': 'copy.py'}
    plugins_list = {}
    # Several functions are called in add_collections_plugins which is not covered by unit tests. 
    # get_all_plugin_loaders and load_plugin_terms functions are called in find_plugins
    # This function is called for each plugin in plugin_loader.all sorted by short name
    # find_plugin_loader_duplicates and get_plugin_path need more mocks to run, so use real funcions
    # plugin_loader.plugin_path is a class variable, so we need to mock it
    plugin_loader.plugin_path = ["/home/awx/.ansible/collections/ansible_collections/testcoll/plugins/modules"]

# Generated at 2022-06-10 22:16:20.002423
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {'description': 'test description', 'parameters': {'foo': {'description': 'test description'}}}
    assert DocCLI.format_plugin_doc(doc) == 'test description\n\n  foo:\n      test description'


# Generated at 2022-06-10 22:16:23.179867
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    my_obj = DocCLI()
    assert my_obj.display_plugin_list(doc) == 'plugin_names'

# Generated at 2022-06-10 22:16:26.373209
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    "Unit test for method get_role_man_text of class DocCLI"
    doccli = DocCLI()
    assert doccli.get_role_man_text == DocCLI.get_role_man_text

# Generated at 2022-06-10 22:16:33.469277
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    from ansible.cli.doc import DocCLI
    from ansible.utils.display import Display
    from ansible.plugins.loader import module_loader
    from ansible.plugins.doc_fragments import DOCUMENTABLE_PLUGINS
    answers = module_loader._load_plugins(DOCUMENTABLE_PLUGINS)
    display = Display()
    display.columns = 100
    dc = DocCLI(['-M', 'tests/lib/ansible/modules/cloud/amazon'], display)
    result = dc.get_all_plugins_of_type('module')
    assert result == ansible.utils.filter_list(answers['module'])


# Generated at 2022-06-10 22:17:59.709125
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test defaults
    text=[]
    doc={'short_description': 'short description'}
    DocCLI.add_fields(text, doc, 50)
    assert text == ['', 'SHORT DESCRIPTION:', '    short description']
    # Test with long initial indent
    text=[]
    DocCLI.add_fields(text, doc, 50, '    ')
    assert text == ['', '    SHORT DESCRIPTION:', '        short description']
    # Test with initial indent and subsequent indent
    text=[]
    DocCLI.add_fields(text, doc, 50, '    {0}'.format(display.columns - 10), ' ' * 20)
    assert text == ['', '    SHORT DESCRIPTION:', '                    short description']
    # Test with initial indent and subsequent indent
    text=[]
   

# Generated at 2022-06-10 22:18:00.718964
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
	pass

# Generated at 2022-06-10 22:18:10.826463
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    from ansible.cli.doc import DocCLI
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.utils.loader import load_list_of_roles
    mm = load_list_of_roles(['/Users/shiv/MyStuff/ansible/roles/ArangoDB/'])[1]
    aa = action_loader.get('service_facts', class_only=True)
    assert isinstance(aa, ActionBase)
    dd = DocCLI._create_role_doc(mm, 'service_facts')
    assert isinstance(dd, dict)
    tt = DocCLI.get_role_man_text('service_facts', dd)
    assert isinstance(tt, list)
    #print(tt)




# Generated at 2022-06-10 22:18:21.055793
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    from ansible.utils.display import Display

    display = Display()
    display.columns = 160

    parser = argparse.ArgumentParser(description="test")
    parser.add_argument('--type', default='module', choices=['module', 'doc', 'deprecated', 'fragment', 'lookup_plugin', 'callback', 'action_plugin', 'inventory_plugin', 'shell_plugin', 'become_plugin'])
    parser.add_argument('name', help='the name of the plugin to show')

    args = parser.parse_args(['--type', 'module', 'x'])
    DocCLI.IGNORE = ("name",)


# Generated at 2022-06-10 22:18:24.203597
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # Case 1: No text given
    assert "No text given" == DocCLI.format_snippet("")
    # Case 2: Text given
    assert "Test" == DocCLI.format_snippet("Test")


# Generated at 2022-06-10 22:18:30.430493
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    field = {
        'description': 'description',
        'choices': ['choice'],
        'version_added': None,
        'version_added_collection': None,
        'aliases': ['alias'],
        'default': None,
        'required': True,
        'options': {
            'description': {
                'description': 'options description',
                'choices': ['choice'],
                'version_added': None,
                'version_added_collection': None,
                'aliases': ['alias'],
                'default': None,
                'required': True
            }
        }
    }
    text = []
    DocCLI.add_fields(text, field, 80)

# Generated at 2022-06-10 22:18:42.081180
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Case 1 ###################
    #########################################################################################################
    #@unittest.skip("reason for skipping")
    def get_role_man_text_1(self, role, role_json):
        role = role['role']
        role_json = role_json['role_json']
        text = []
        opt_indent = "        "
        pad = display.columns * 0.20
        limit = max(display.columns - int(pad), 70)

        text.append("> %s    (%s)\n" % (role.upper(), role_json.get('path')))

        for entry_point in role_json['entry_points']:
            doc = role_json['entry_points'][entry_point]


# Generated at 2022-06-10 22:18:48.165647
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    for cls_name in DocCLI.get_plugin_types():
        m = DocCLI(cls_name)
        m.display_plugin_list(False)
        m.display_plugin_list(True)
        m.display_plugin_list(False, 'foo')
        m.display_plugin_list(True, 'foo')


# Generated at 2022-06-10 22:18:58.975910
# Unit test for method add_fields of class DocCLI