

# Generated at 2022-06-10 22:11:06.202855
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():

    class MockCLI(object):
        def __init__(self):
            self.args = []
            self.options = {'type': 'module'}

    cli = MockCLI()
    format_plugin_doc(cli, 'ping')


# Generated at 2022-06-10 22:11:13.277124
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # test that the module and/or plugin doc can be loaded by format_plugin_doc()
    system_lib_dir = os.path.join(os.path.dirname(__file__), '..',
                                  'lib/ansible/plugins/actions')
    module_dirs = [system_lib_dir]

    for module_dir in module_dirs:
        for module in os.listdir(module_dir):
            if not module.endswith('.py'):
                continue
            if module == '__init__.py':
                continue
            if C.IGNORE_FILES and C.IGNORE_FILES.match(module):
                continue
            module_name = module.replace('.py', '')
            if module_name in DocCLI.DOCUMENTABLE_MODULES:
                module_

# Generated at 2022-06-10 22:11:19.442464
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-10 22:11:28.945154
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # Create an instance of DocCLI
    obj = DocCLI()
    # Unit test for method format_snippet

# Generated at 2022-06-10 22:11:33.280410
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc = DocCLI()
    collection_name = "ansible_collections.jctanner.scaffold"
    collection_dir = os.path.join(os.path.dirname(__file__), "..", "test_data", "roles")
    doc.find_plugins(collection_name, collection_dir)
    assert doc.collection_name == collection_name
    assert doc.plugin_type == "roles"
    assert doc.collection_path == collection_dir
    assert len(doc.plugins) == 3



# Generated at 2022-06-10 22:11:45.899263
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    from ansible.module_utils._text import to_text
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.utils.sentinel import Sentinel
    import contextlib
    from contextlib import contextmanager
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import text_type

    @contextmanager
    def capture(command, *args, **kwargs):
        _stdout = sys.stdout
        try:
            sys.stdout = StringIO()
            command(*args, **kwargs)
            sys.stdout.seek(0)
            yield sys.stdout.read()
        finally:
            sys.stdout = _stdout


# Generated at 2022-06-10 22:11:50.584266
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    f = 'ansible/plugins/modules/network/nxos/nxos_lldp.py'
    assert DocCLI.namespace_from_plugin_filepath(f) == 'network.nxos'

# Generated at 2022-06-10 22:11:55.258225
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI(['module_utils/basic.py'])
    doc.find_plugins()
    text = doc.display_plugin_list(doc.module_list, category='module')
    assert "module" in text
    assert "module_utils" in text


# Generated at 2022-06-10 22:12:04.982399
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    '''Unit test for method get_plugin_metadata of class DocCLI'''
    # Find the full path in the stubs cache
    collection_loader = C.DEFAULT_COLLECTION_PATH
    file_name = os.path.join(collection_loader, 'b_collection', 'plugins', 'action', 'my_action.py')
    fake_loader = Mock(spec_set=PluginLoaderObj)
    fake_loader.get_source.return_value = [None, file_name]
    # Create a fake doc object for testing
    test_obj = DocCLI(loader=fake_loader)
    # Run the method, get_plugin_metadata()
    test_obj.get_plugin_metadata('my_action', collection_loader)


# Generated at 2022-06-10 22:12:15.087029
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = display.columns

    # Test case 1: 'default' is a dictionary
    opt = {'foo': 'bar', 'default': {'a': 'b'}}
    DocCLI.add_fields(text, [opt], limit)
    assert text[-1] == "        default: {     a: b }"

    # Test case 2: 'default' is a list.
    opt = {'foo': 'bar', 'default': ['a', 'b']}
    DocCLI.add_fields(text, [opt], limit)
    assert text[-1] == "        default: a, b"

    # Test case 3: 'options'
    opt = {'options': {'options': {'name': 'k', 'description': "description:\ndescription2"}}}

# Generated at 2022-06-10 22:12:59.074161
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-10 22:13:09.206852
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-10 22:13:12.607588
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = ''
    coll_filter = ''
    DocCLI.add_collection_plugins(plugin_list, plugin_type, coll_filter)



# Generated at 2022-06-10 22:13:13.538133
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    pass

# Generated at 2022-06-10 22:13:23.957777
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    args = ["ansible-doc", '-t', 'action', 'scp']
    cwd = os.path.join(os.path.dirname(__file__), 'test/unit/doc_loader')

    # check for correct usage (options -s and -v in combination)
    with pytest.raises(SystemExit):
        args.append('-s')
        args.append('-v')
        DocCLI(args, cwd)

    # check for correct usage (option -s in combinatin with a non-connection plugin)
    with pytest.raises(SystemExit):
        args = ["ansible-doc", '-t', 'action', 'scp', '-s']
        DocCLI(args, cwd)

    # check for correct usage (option -s in combination with a filter plugin)
   

# Generated at 2022-06-10 22:13:35.433073
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    DocCLI.IGNORE = DocCLI.IGNORE + (context.CLIARGS['type'],)
    opt_indent = "        "
    limit = 70
    ansible_dirs = dict(
        roles=[],
        plugins=[],
        filters=[],
        modules=[],
        lookup_plugins=[],
        module_utils=[],
        callback_plugins=[],
        inventory_plugins=[],
        test_plugins=[],
        test_loader_plugins=[],
    )
    # Test for method when 'collection' is not None
    collection = dict(name='my_collection', docs='', version='1.0.0', files=['/some/file', '/another/file'])

# Generated at 2022-06-10 22:13:40.306302
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    assert "  name: 'the test'" in DocCLI.format_snippet('- name: the test')
    assert "    name: 'the test'" in DocCLI.format_snippet('  - name: the test')
    assert "  name: 'this'" in DocCLI.format_snippet('- name: this\n  other: that')
    assert 'test-test' in DocCLI.format_snippet('[test-test test]')


# Generated at 2022-06-10 22:13:48.027397
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Create a mock module object
    mock_module = create_autospec(ModuleDoc)
    # Create a mock plugin loader object
    mock_plugin_loader = create_autospec(PluginLoader)
    # Create a DocCLI object with the mock module and plugin loader objects
    docCLI = DocCLI(module_docs=mock_module, plugin_loader=mock_plugin_loader)
    # Create a mock doc object

# Generated at 2022-06-10 22:13:57.520187
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    module_name = 'test_module'
    doc = dict()
    doc[context.CLIARGS['type']] = module_name
    doc['filename'] = 'test_filename'
    doc['description'] = 'test description'
    doc['options'] = dict()
    doc['options']['test_param1'] = dict()
    doc['options']['test_param1']['description'] = 'test param1 description'
    doc['options']['test_param1']['required'] = False
    doc['options']['test_param1']['type'] = 'bool'
    doc['options']['test_param1']['aliases'] = ['param1', 'p1']
    doc['options']['test_param1']['version_added'] = '1.0'


# Generated at 2022-06-10 22:14:04.009504
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    for snippet in constants.SNIPPET_CLASS_METHODS:
        snippet = snippet[0]
        parts = snippet.split('.')
        snippet = {"%s.%s" % (plugin_type, snippet): ''}
        snippet_text = DocCLI.format_snippet(parts[0], parts[1], snippet)
        assert snippet_text is not None
        assert snippet_text != ''



# Generated at 2022-06-10 22:15:43.462349
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-10 22:15:50.436667
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
  print('Testing test_DocCLI_get_all_plugins_of_type ...', end=' ')
  doc = DocCLI()
  ansible_path = get_config(CLIConfig, 'ANSIBLE_LIBRARY', None, value_type='path')
  play_plugins_path = os.path.join(ansible_path, "plugins", "action")
  results = doc.get_all_plugins_of_type(play_plugins_path)['options']
  if len(results) != len(get_all_plugin_loaders('action')):
    print('FAILED')
    return
  for item in results:
    if item['name'] not in get_all_plugin_loaders('action'):
      print('FAILED')
      return
  print('PASSED')


# Unit test

# Generated at 2022-06-10 22:16:01.447368
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    class MockDocCLI:
        # Mock method __init__ of class DocCLI
        def __init__(self):
            pass
    class MockAnsibleModule:
        # Mock method __init__ of class AnsibleModule
        def __init__(self):
            pass

    import ansible.module_utils.basic
    ansible.module_utils.basic.AnsibleModule = MockAnsibleModule


# Generated at 2022-06-10 22:16:13.067820
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    m = DocCLI()
    role = 'libselinux.boolean' 
    role_json = '{"entry_points": {"role_data": {"plugin_type": "docs", "description": ["Manage SELinux boolean values.", "", "This module manages SELinux boolean values, these are simple '

# Generated at 2022-06-10 22:16:20.334428
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = DocCLI()
    module_name = "setup"
    collection_name = "ansible.builtin"
    plugin_type = "module"
    try:
        doc.get_plugin_metadata(module_name, collection_name, plugin_type)
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-10 22:16:31.524652
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 70
    opt_indent = "        "

# Generated at 2022-06-10 22:16:43.811824
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Define expected results
    expected_result = {'newkey1': 'val1', 'newkey2': 'val2', 'newkey3': 'val3'}
    expected_result2 = {'newkey1': 'val1', 'newkey2': 'val2', 'newkey3': 'val3', 'newkey4': 'val4'}

    # Test various combinations of arguments with get_plugin_metadata
    data = DocCLI.get_plugin_metadata(['newkey1'])
    assert data == {'newkey1': 'val1'}, "test_DocCLI_doc_fragment: Expected data: %s, Received data: %s" % (expected_result, data)
    data = DocCLI.get_plugin_metadata(['newkey1', 'newkey2'])
    assert data

# Generated at 2022-06-10 22:16:55.435852
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doccli = DocCLI()

# Generated at 2022-06-10 22:17:06.059250
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    import tempfile
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    with tempfile.NamedTemporaryFile() as foo:
        foo.write(to_bytes(
'''
module: foo
author:
  - Foo
short_description: Foo is foo for foo.
description:
  - Foo is foo for foo.
version_added_collection: ansible.builtin
version_added: "2.3"
options:
  bar:
    description: Foo bar.
    required: True
    type: str
'''))
        foo.flush()
        DocCLI(['-M', foo.name, '-f', 'ansible.builtin.foo']).run()

# Generated at 2022-06-10 22:17:13.917619
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    expected_results = """CLUBS
  > CARDACHE

  > EC2

  > EBS

  > EIP

  > IAM

  > RDS
DIAMONDS
  > CARDACHE

  > EC2

  > EBS

  > EIP

  > IAM

  > RDS
HEARTS
  > CARDACHE

  > EC2

  > EBS

  > EIP

  > IAM

  > RDS
SPADES
  > CARDACHE

  > EC2

  > EBS

  > EIP

  > IAM

  > RDS
"""
    plugin_list = ["CARDACHE", "EC2", "EBS", "EIP", "IAM", "RDS"]