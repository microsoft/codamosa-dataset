

# Generated at 2022-06-10 22:11:07.493617
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():

    d = DocCLI()
    role = {}
    role_json = {}
    expected_output = ["> {}    ()\n"]

    # Unit test for method get_role_man_text of class DocCLI
    # with input "role" is Dictionary and "role_json" is Dictionary.
    # Expected output  is Array.
    actual_output=d.get_role_man_text(role,role_json)
    assert expected_output == actual_output
    print("\nExpected output:", expected_output)
    print("Actual output:", actual_output)

    # Unit test for method get_role_man_text of class DocCLI
    # with input "role" is Dictionary and "role_json" is None.
    # Expected output  is Array.
    actual_output=d.get_

# Generated at 2022-06-10 22:11:11.078526
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
  doc = DocCLI()
  # test_get_all_plugins_of_type and test_get_all_plugins_of_type_with_arg
  assert doc.get_all_plugins_of_type() == doc.get_all_plugins_of_type('lookup')


# Generated at 2022-06-10 22:11:12.372812
# Unit test for function jdump
def test_jdump():
    jdump([1, 2, 3])
    jdump('some string')



# Generated at 2022-06-10 22:11:16.746958
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(type='path'),
            type = dict(type='str', default='module')
        )
    )
    doc = {}
    doc['foo'] = 'bar'
    result = {}
    result['ansible_module_generated_yaml'] = yaml.dump(doc, indent=4, width=1000, Dumper=OrderedDumper)
    testobj = DocCLI(module)
    test_result = testobj.run()
    assert test_result == result


# Generated at 2022-06-10 22:11:23.343267
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
   with tempfile.NamedTemporaryFile() as tf:
       tf.write(b'TEST')
       tf.flush()
       role = DocCLI(tf.name)
       role_json = {'entry_points': {'main': {'options': {'a': '10'}, 'short_description': 'This is a test'}}}
       role_man_text = role.get_role_man_text('test_role', role_json)

# Generated at 2022-06-10 22:11:37.904993
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # ansible modules.
    doc = DocCLI()
    doc.find_plugins()
    assert 'yum' in doc.modules, "could not find yum module"
    assert 'win_disk_facts' in doc.modules, "could not find win_disk_facts module"
    assert 'win_package' in doc.modules, "could not find win_package module"
    assert 'win_dism_features' not in doc.modules, "win_dism_features module found"
    assert '_win_dsc_version' not in doc.modules, "_win_dsc_version module found"
    assert '_win_smbclient' not in doc.modules, "_win_smbclient module found"

    doc = DocCLI(as_module=False)
    doc.find_plugins()

# Generated at 2022-06-10 22:11:40.019103
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # TODO: implement unit test
    return True


# Generated at 2022-06-10 22:11:43.833826
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    '''
    This function returns the metadata of all plugins.
    '''
    get_plugins_metadata = DocCLI().get_plugins_metadata()
    print(get_plugins_metadata)



# Generated at 2022-06-10 22:11:50.553781
# Unit test for method run of class DocCLI

# Generated at 2022-06-10 22:11:51.727762
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
  pass

# Generated at 2022-06-10 22:13:37.754871
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    display.columns = 80
    json_file_path = os.path.join(os.path.dirname(__file__), "../test/unit/plugins/test_ansible_doc/roles/test_role_jst_j2_mixed/role_jst_j2_mixed.json")
    with open(json_file_path) as f:
        doc_json = json.load(f)
    cli = DocCLI(module_list=None)
    man_text = cli.get_role_man_text("role_jst_j2_mixed", doc_json)
    man_text = "\n".join(man_text)
    assert 'role_jst_j2_mixed' in man_text

# Generated at 2022-06-10 22:13:39.249826
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc_cli = DocCLI()
    assert doc_cli.find_plugins() is None


# Generated at 2022-06-10 22:13:40.408363
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # TODO: Make unit tests to test the output of method add_fields
    pass

# Generated at 2022-06-10 22:13:48.200191
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Injecting arguments into context.CLIARGS to fool the method
    context._init_global_context(dict(output_file=None,
                                      verbosity=0,
                                      fetch_content_type="",
                                      type='modules',
                                      exclude_plugins=[]))
    doc = DocCLI()

    # Initializing a list that will contain the names of the plugins returned by find_plugins
    plugins = []
    for plugin in doc.find_plugins():
        plugins.append(to_native(os.path.basename(plugin)))
    # Check if the list of plugins returned by find_plugins is the same as the list of plugins in the 'modules' folder

# Generated at 2022-06-10 22:13:49.470686
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI(None)
    doc.display('collection')

# Generated at 2022-06-10 22:13:59.202109
# Unit test for function jdump
def test_jdump():
    assert json.loads(jdump([{"example": [{"args": {}}]}])) == [{"example": [{"args": {}}]}]
    assert json.loads(jdump([{"example": [{"args": {"test": {"key": "something"}}}]}])) == [{"example": [{"args": {"test": {"key": "something"}}}]}]
    assert json.loads(jdump({"example": [{"args": {"test": {"key": "something"}}}]})) == {"example": [{"args": {"test": {"key": "something"}}}]}
    assert json.loads(jdump([{"example": [{"args": "something"}]}])) == [{"example": [{"args": "something"}]}]

# Generated at 2022-06-10 22:14:04.681768
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    import ansible.plugins
    plugin_list = {}
    plugin_type = 'module'
    coll_filter = 'space'  # collection name
    add_collection_plugins(plugin_list, plugin_type, coll_filter=coll_filter)
    assert(plugin_list.keys() == ['space.plugin'])



# Generated at 2022-06-10 22:14:07.958272
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    configuration.settings._config = None
    context._init_global_context(["ansible-doc"])
    DocCLI.get_plugin_metadata()

# Generated at 2022-06-10 22:14:13.833396
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    options = {
        'action': 'store',
        'choices': ['bar', 'baz', 'qux'],
        'default': 'bar',
        'version_added': '2.3',
    }
    text = "  - foo"
    tty_method = None
    text_formatted = DocCLI.format_snippet(text, options, tty_method)
    assert text_formatted == text
    expected = text + "         (choices: bar, baz, qux) [Default: bar]\n"
    text_formatted = DocCLI.format_snippet(text, options, tty_method, True)
    assert text_formatted == expected


# Generated at 2022-06-10 22:14:18.623606
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    doc = DocCLI()
    snippet = "\"\"\"\nThis is a multiline docstring.\n\"\"\""
    result = '\n    This is a multiline docstring.\n'
    assert doc.format_snippet(snippet) == result

# Generated at 2022-06-10 22:15:16.578175
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    DocCLI().run()


# Generated at 2022-06-10 22:15:19.133816
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    import doctest
    failure_count, test_count = doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)
    assert failure_count == 0
# end unit test


# Generated at 2022-06-10 22:15:31.596834
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-10 22:15:32.592942
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    data = DocCLI.get_plugin_metadata()
    assert data is not None

# Generated at 2022-06-10 22:15:36.094244
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    text = "    - debug: msg='hello'"
    result = DocCLI.format_snippet(text, 'yaml')
    assert result == text



# Generated at 2022-06-10 22:15:46.116878
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    import sys
    text = []
    limit = int(sys.argv[1])
    opt_indent = "    "
    doc = dict(
        name="name",
        description="description",
        version_added="2.2",
        version_added_collection="ansible.builtin",
        author="author",
        options=dict(
            option_name={
                "description": "description",
                "required": True,
                "type": "type",
                "default": "default",
                "choices": ["one", "two"],
                "version_added": "3.1",
                "version_added_collection": "ansible.builtin",
                "aliases": ["alias1", "alias2"]
            }
        )
    )

# Generated at 2022-06-10 22:15:53.530900
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'action'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert(plugin_list is not None)

plugin_list = DocCLI.find_plugins(C.DEFAULT_ACTION_PLUGIN_PATH, False, 'action')
add_collection_plugins(plugin_list, 'action')

plugin_list.update(DocCLI.find_plugins(C.DEFAULT_LOOKUP_PLUGIN_PATH, False, 'lookup'))
add_collection_plugins(plugin_list, 'lookup')


# Generated at 2022-06-10 22:16:04.902558
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-10 22:16:15.045056
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    """
    DocCLI
    format_plugin_doc() method unit tests
    """
    def _test(doc_format, result,
              collection_name=None,
              plugin_type='',
              fail_on_error=True):
        doc = DocCLI.format_plugin_doc(context.CLIARGS['doc_fragment'], doc_format, plugin_type=plugin_type, collection_name=collection_name)
        return assertEqual(doc, result,
                           "Invalid result for doc_format %s, plugin_type %s, collection_name %s" % (doc_format, plugin_type, collection_name))

    # test - doc_format='plain'

# Generated at 2022-06-10 22:16:27.268488
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test failure when plugin is invalid
    with pytest.raises(AnsibleError):
        DocCLI.get_plugin_metadata('invalid', 'module')

    # Test failure with invalid plugin type
    with pytest.raises(AnsibleError):
        DocCLI.get_plugin_metadata('copy', 'invalid')

    # Test success obtaining module plugin metadata
    plugin_meta = DocCLI.get_plugin_metadata('copy', 'module')
    assert plugin_meta
    assert 'name' in plugin_meta
    assert 'filename' in plugin_meta
    assert plugin_meta['name'] == 'copy'
    assert 'module' in plugin_meta
    assert plugin_meta['module'] == 'copy'

    # Test success obtaining connection plugin metadata

# Generated at 2022-06-10 22:17:17.274805
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Create a module and class to check DocCLI class from cli.py
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    check = DocCLI(module, [])

    # Test DocCLI.print_paths() with invalid options
    fail_msg = check.print_paths(invalid={})
    assert fail_msg[0] == 'invalid_option'
    assert fail_msg[1] == 'The supplied options are invalid'

    # Test DocCLI.print_paths() with valid options
    success = check.print_paths(valid=['ansible-doc', 'all', 'module'])
    assert success == 0

# Generated at 2022-06-10 22:17:26.936791
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    doccli = DocCLI()
    assert doccli.namespace_from_plugin_filepath('/Users/danielkberg/Code/Ansible/ansible/lib/ansible/plugins/action/ping.py') == 'ping'
    assert doccli.namespace_from_plugin_filepath('/Users/danielkberg/Code/Ansible/ansible/lib/ansible/modules/network/f5/bigip_user.py') == 'network.f5.bigip_user'
    assert doccli.namespace_from_plugin_filepath('/Users/danielkberg/Code/Ansible/ansible/lib/ansible/modules/system/os_server_facts.py') == 'os_server_facts'

# Generated at 2022-06-10 22:17:35.826447
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    fake_plugin_type = 'test_plugin_type'
    fake_coll_filter = '*test*'
    plugin_list = {}

    add_collection_plugins(plugin_list, fake_plugin_type, coll_filter=fake_coll_filter)
    assert len(plugin_list) > 0
    my_first_collection_name = list(plugin_list.keys())[0]
    my_first_collection_path = plugin_list[my_first_collection_name]
    assert my_first_collection_name.startswith('my_first.collection')
    assert my_first_collection_path.startswith(C.DEFAULT_COLLECTIONS_PATH)
    first_plugin_in_list = list(plugin_list[my_first_collection_name].keys())[0]
    assert first_plugin_

# Generated at 2022-06-10 22:17:45.274392
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    module = MockModule()
    display = MockDisplay()


# Generated at 2022-06-10 22:17:51.163669
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Try all existing plugin types
    import ansible
    for ptype in ansible.plugins.__all__:
        DocCLI().get_all_plugins_of_type(ptype)

    # Try the non-existing plugin type 'invalid'
    DocCLI().get_all_plugins_of_type('invalid')


# Generated at 2022-06-10 22:17:59.412711
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.cli.arguments import CLIArgumentParser
    from ansible.parsing.dataloader import DataLoader

    p = CLIArgumentParser(
        usage='%(prog)s [options]',
        description='Show Ansible plugin documentation.',
    )

    p.add_argument('plugin', metavar='plugin', help='plugin name to document')
    p.add_argument('--version', action='version', version=__version__)
    p.add_argument('-v', '--verbose', dest='verbose', action='store_true', default=C.DEFAULT_VERBOSITY, help='verbose mode (-vvv for more, -vvvv to enable connection debugging)')


# Generated at 2022-06-10 22:18:03.548208
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_type = 'module'
    coll_filter = 'community.general'
    plugin_list = {}
    assert not plugin_list
    add_collection_plugins(plugin_list, plugin_type, coll_filter=coll_filter)
    assert plugin_list



# Generated at 2022-06-10 22:18:13.453422
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {
        'DOCUMENTATION': 'fake',
        'version_added': '2.4',
        'options': {
            'key': {
                'choices': ['foo', 'bar'],
                'default': 'foo',
                'description': 'fake',
                'aliases': ['a', 'b', 'c'],
            }
        },
    }
    expected_result = '''
> FAKE    (fake)

ADDED IN: Ansible 2.4

OPTIONS (= is mandatory):

        key:
            - required: False
            - choices:
                - foo
                - bar
            - default: foo
            - description: fake
            - aliases:
                - a
                - b
                - c'''

# Generated at 2022-06-10 22:18:23.412791
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    if os.path.exists('/tmp/yaml'):
        shutil.rmtree('/tmp/yaml')
    from ansible.cli.doc import DocCLI
    doccli = DocCLI()
    doc = doccli.get_plugin_metadata('/usr/lib/python2.7/site-packages/ansible_collections/ansible/fortios/plugins/modules/fortios_system_vdom_dns.py')

    assert doc.get('name') == 'fortios_system_vdom_dns'
    assert doc.get('metadata') == {'collection': 'ansible.fortios', 'collection_name': 'ansible.fortios', 'status': ['preview'], 'supported_by': 'community'}

# Generated at 2022-06-10 22:18:29.048790
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # plugin doc dict
    plugin_doc = dict(
        name='foo',
        short_description='module foo',
        description='long description foo',
        author=['Fred Smith', 'Jane Doe'],
        version_added='2.4',
        options=dict(foo=dict(required=False, description='coolness value for foo'),
                     bar=dict(required=True, description='coolness value for bar'))
    )
    result = DocCLI.format_plugin_doc(plugin_doc)
    assert isinstance(result, string_types)
    assert "module foo" in result
    assert "coolness value for foo" in result

