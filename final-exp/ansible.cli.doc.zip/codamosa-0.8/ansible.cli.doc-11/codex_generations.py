

# Generated at 2022-06-10 22:11:19.001737
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    import sys
    import doctest
    sys.exit(doctest.testmod(sys.modules[__name__])[0])

if __name__ == '__main__':
    context.CLIARGS = {}
    context.CLIARGS['type'] = 'module'
    context.CLIARGS['subtype'] = 'core'

    plugins = DocCLI().load_plugins()
    DocCLI().display_plugin_list(plugins)

    print("UNIT TESTS for class DocCLI")
    test_DocCLI_display_plugin_list()

# Generated at 2022-06-10 22:11:27.700704
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    import sys
    import os

    for module in sys.modules.keys():
        if module.startswith('ansible.plugins.'):
            del sys.modules[module]

    loader = DataLoader()
    callback_loader = PluginLoader(
        'CallbackModule',
        'ansible.plugins.callback',
        C.DEFAULT_CALLBACK_PLUGIN_PATH,
        'callback_plugins',
        C.CALLBACK_PLUGINS_FILENAME,
    )
    callback_loader.all()

    db = DocCLI(loader, callback_loader, './lib/ansible/modules', [], [])

    fh, temppath = tempfile.mkstemp()
    os.write(fh, b'---')
    os.close(fh)


# Generated at 2022-06-10 22:11:33.868304
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    """
    docCLI#test_DocCLI_get_plugin_metadata:

    Tests for:
        <docCLI.DocCLI.get_plugin_metadata>
    """
    from ansible.module_utils.ansible_release import __version__
    from ansible.utils.plugin_docs import _get_doc_dir

    _get_doc_dir()
    d = DocCLI(runas=False)
    result = d.get_plugin_metadata('module')
    assert 'version' in result['example_one'].keys()
    assert 'parameters' in result['example_one'].keys()
    assert 'supported_by' in result['example_one'].keys()
    assert 'version' in result['example_two'].keys()

# Generated at 2022-06-10 22:11:35.536297
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugins = {}
    # TODO add test for new runtime.yml once implemented
    add_collection_plugins(plugins, 'action')
    assert plugins is not None



# Generated at 2022-06-10 22:11:39.051711
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('/something/interesting/the/name/of/the/plugin_name.py') == 'name.of.the'
    assert DocCLI.namespace_from_plugin_filepath('/something/interesting/the/name/of/the/plugin_name.ps1') == 'name.of.the'
    assert DocCLI.namespace_from_plugin_filepath('/something/interesting/the/name/of/the/the_plugin_name.py') == 'name'

# Generated at 2022-06-10 22:11:43.325426
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    m = DocCLI()
    assert os.path.exists(m.get_all_plugins_of_type('fragment', 'ansible.builtin')[0])

# Generated at 2022-06-10 22:11:46.092522
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {'description': 'Test module', 'metadata_version': '1.1', 'version_added': '', 'plainexamples': 'test'}
    print(DocCLI.format_plugin_doc('test', doc))

# Generated at 2022-06-10 22:11:58.644882
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    p = DocCLI()
    metadata_file_path = "../lib/ansible/modules/notification/mail.py"
    actual_result = p.get_plugin_metadata(metadata_file_path)

# Generated at 2022-06-10 22:12:10.024370
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    snippet = textwrap.dedent("""\
        - name: This is a new task that does something
          debug: msg="Hello world!"

        - name: This is a new task that does something
          debug: msg="This one is a longer example that shows
                       some additional things that can be done
                       with format_snippet()."
          """)

    actual = DocCLI.format_snippet(snippet)

# Generated at 2022-06-10 22:12:10.526259
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    pass

# Generated at 2022-06-10 22:13:14.764090
# Unit test for method run of class DocCLI
def test_DocCLI_run():
  # Ensures if args are not passed then program exits
  with pytest.raises(SystemExit):
      doc = DocCLI(args=None)
      doc.run()
  # Ensures if there is no function defined then program exits
  with pytest.raises(SystemExit):
      doc = DocCLI(args=[])
      doc.run()
  # Ensures if doc is not found then program exits
  with pytest.raises(SystemExit) as e:
      doc = DocCLI(args=["blah", "some_method"])
      doc.run()
  assert e.value.code == 1


# Generated at 2022-06-10 22:13:18.226448
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    home = 'home/'
    plugin = 'plugin'
    # Add code for testing here.
    #cli = DocCLI()
    #cli.display_plugin_list(home, plugin)


# Generated at 2022-06-10 22:13:26.814978
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    """Test format_plugin_doc() method."""
    # Test a valid plugin
    plugin_type = 'module'
    plugin_name = 'copy'
    args = DocCLI.ArgumentParser()
    args.type = plugin_type
    args.name = plugin_name
    args.refresh_cache = True
    context.CLIARGS = args.parse_args()
    doc = DocCLI.format_plugin_doc(plugin_type=plugin_type, plugin_name=plugin_name)
    assert doc
    # Test an invalid plugin
    plugin_type = 'module'
    plugin_name = 'foobarbaz'
    args = DocCLI.ArgumentParser()
    args.type = plugin_type
    args.name = plugin_name
    args.refresh_cache = True
    context.CL

# Generated at 2022-06-10 22:13:31.109055
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    cli = DocCLI()
    result = cli.get_all_plugins_of_type('action')
    assert isinstance(result, list)
    assert len(result) > 1
    assert 'copy' in result


# Generated at 2022-06-10 22:13:39.499247
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Initializing a DocCLI object
    docCli_obj = DocCLI()

    # Loading plugin_docs into a plugin_docs object
    plugin_docs = {'action': [], 'become': [], 'cache': [], 'callback': [], 'cliconf': [], 'connection': [], 'filter': [], 'httpapi': [], 'inventory': [], 'lookup': [], 'module': [], 'netconf': [], 'shell': [], 'strategy': [], 'terminal': [], 'test': [], 'vars': []}
    # Test-1: test for plugin_docs with no plugins

# Generated at 2022-06-10 22:13:47.245261
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-10 22:13:48.111982
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    DocCLI.run()


# Generated at 2022-06-10 22:13:57.653815
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.cli.doc import DocCLI
    from ansible.plugins.loader import module_loader
    from ansible.utils.display import Display
    import tempfile

    config = {}
    config['ANSIBLE_DOCUMENTATION_SKIP_DEPRECATED'] = True
    tmpfd, tmpfn = tempfile.mkstemp()
    os.close(tmpfd)
    display = Display()
    display.verbosity = 3
    display.columns = 80
    # Since the module is not installed at the usual path,
    # we need to create a mock loader object
    loader = module_loader._create_mock_loader(config)
    # Modules are not actually loaded here, so this is fine
    loader.add_directory(os.getcwd())

# Generated at 2022-06-10 22:14:05.035226
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
   cli_args = {'module_path':None,'pattern':['*'], 'type':'module', 'list_dir':None, 'tree':None, 'list_extras':None, 'list_deprecated':None, 'list_extra_dir':None, 'list_filter':None}
   context.CLIARGS = cli_args
   doc = DocCLI()
   find_plugins = doc.find_plugins()
   return find_plugins


# Generated at 2022-06-10 22:14:06.766204
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
  # TODO: Implement
  pass

# Generated at 2022-06-10 22:16:15.593203
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {'description': ["# Test Module\n", "This is a test module\n"], 'short_description': 'A test module', 'version_added': 'historical', 'author': ['John Doe', 'Jane Doe']}
    collection_name = ''
    plugin_type = ''
    # Run code
    result = DocCLI.get_man_text(doc, collection_name, plugin_type)
    # Verify Result
    assert result



# Generated at 2022-06-10 22:16:28.419925
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    test_parser = DocCLI(
        ['ansible-doc', '--type=module', 'copy'],
        'ansible', '', '',
    )

# Generated at 2022-06-10 22:16:36.141835
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    opts = {
        'name': 'foobar',
        'description': 'This is a description',
        'required': True,
        'choices': ['one', 'two', 'three'],
        'default': 'test',
        'aliases': ['barfoo'],
        'options': [
            {
                'name': 'something',
                'description': 'something description'
            }
        ],
        'suboptions': [
            {
                'name': 'another',
                'description': 'another description'
            }
        ],
        'spec': [
            {
                'name': 'spec',
                'description': 'spec description'
            }
        ]
    }
    text = []
    DocCLI.add_fields(text, opts, 80, "        ")
    print(text)

# Generated at 2022-06-10 22:16:43.910365
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    doc = {'options': {},
           'description': 'This module is maintained by the Ansible Community'}
    DocCLI.add_fields(doc, "This module is maintained by the Ansible Community", limit=70, opt_indent="        ", return_values=False, opt_indent=None)
    assert doc == {'options': {},
                   'description': 'This module is maintained by the Ansible Community'}


# Generated at 2022-06-10 22:16:52.488620
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    assert DocCLI.get_all_plugins_of_type('.PluginLoader') == [
        'action.PluginLoader',
        'cache.PluginLoader',
        'callback.PluginLoader',
        'connection.PluginLoader',
        'doc_fragments.PluginLoader',
        'filter.PluginLoader',
        'httpapi.PluginLoader',
        'inventory.PluginLoader',
        'lookup.PluginLoader',
        'netconf.PluginLoader',
        'shell.PluginLoader'
    ]


# Generated at 2022-06-10 22:17:03.266524
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    import ansible.utils.shlex
    from ansible.cli import CLI

    cli = CLI([])
    cli.options = cli.base_parser.parse_args([])
    cli.parser = cli._get_parser()

    action_plugins_paths = [os.path.join(os.path.dirname(__file__), 'data', 'docs_data', 'action_plugins')]

# Generated at 2022-06-10 22:17:12.074595
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    import random
    from ansible.module_utils.common._collections_compat import MutableSequence, MutableMapping, MutableSet


# Generated at 2022-06-10 22:17:13.473410
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doccli = DocCLI()
    doccli._create_doc = MagicMock()



# Generated at 2022-06-10 22:17:14.976262
# Unit test for function jdump
def test_jdump():
    jdump(["one"])



# Generated at 2022-06-10 22:17:22.203230
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    '''Unit test for format_snippet'''

    # Unittest env
    class AnsibleOptions:
        '''AnsibleOptions stub'''

    doc_cli = DocCLI()
    doc_cli.options = AnsibleOptions()
    doc_cli.options.tags = ['always']
    doc_cli.options.skip_tags = ['never']
    # End of unittest env

    assert doc_cli.format_snippet("  - debug: msg=\"Hello world\"") == "  - debug: msg=\"Hello world\""

