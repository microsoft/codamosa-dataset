

# Generated at 2022-06-24 17:47:20.132022
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    doc_c_l_i_0.get_man_text(doc_c_l_i_0._create_doc(path_to_file, sample_args))


# Generated at 2022-06-24 17:47:29.050416
# Unit test for method get_plugin_metadata of class DocCLI

# Generated at 2022-06-24 17:47:35.349378
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)

    doc = {
        'plainexamples': '''\
- name: Ansible ping
  hosts: all
  tasks:
    - name: ping
      ping:
- name: Ansible ping
  hosts: all
  tasks:
    - ping:
- name: Ansible ping
  hosts: all
  tasks:
    - action: ping
''',
        'platforms': [
            'Platform 1',
            'Platform 2'
        ]
    }

    try:
        doc_c_l_i_0.format_plugin_doc(doc)
    except:
        assert False, "Unhandled exception when calling format_plugin_doc of class DocCLI"



# Generated at 2022-06-24 17:47:48.698369
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc_c_l_i_0 = DocCLI()
    plugin_name = 'ping'
    plugin_type = None

    # Test for no doc
    collected_doc = {}
    result = doc_c_l_i_0.format_plugin_doc(collected_doc, plugin_name, plugin_type)
    assert result == "No documentation found for %(type)s %(name)s" % {"type": plugin_type, "name": plugin_name}

    # Test for regular doc
    collected_doc = {'module': True, 'plainexamples': 'plainexamples', 'description': ["a module to ping hosts"], 'version_added': '2.0', 'filename': 'playbooks/lib/ansible/modules/system/ping.py', 'options': {}}
    result = doc_c_l_i

# Generated at 2022-06-24 17:48:01.300572
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    role_0 = 'role_0'
    role_json_0 = {'entry_points': {'entry_point': 'entry_point'}, 'path': 'path'}
    list_0 = doc_c_l_i_0.get_role_man_text(role_0, role_json_0)
    assert len(list_0) > 0


# Generated at 2022-06-24 17:48:10.121761
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:48:22.199194
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    plugin_name = 'copy'
    # Compute the value with no cache
    doc_c_l_i_0.ANALYZED = False
    # This will compute the value and cache it
    metadata_0 = doc_c_l_i_0.get_plugin_metadata(plugin_name)
    # Check the cache
    if doc_c_l_i_0.ANALYZED:
        # Get the value from the cache
        metadata_0 = doc_c_l_i_0.get_plugin_metadata(plugin_name)
    elif metadata_0:
        display.display(metadata_0)

# Generated at 2022-06-24 17:48:23.674600
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # TODO: Add a test for this feature
    pass


# Generated at 2022-06-24 17:48:34.580590
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Initialize object of class RoleMixin
    role_mixin_1 = RoleMixin()
    # Initialize object of class DocCLI
    doc_c_l_i_1 = DocCLI(role_mixin_1)
    assert isinstance(doc_c_l_i_1, DocCLI)

    # Get the text for display for the given module

# Generated at 2022-06-24 17:48:44.400545
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    from UnitTest.arg_spec import arg_spec
    from UnitTest.action_plugin.action_plugin import ActionModule
    from UnitTest.cache_plugins.cache_plugin import CacheModule
    from UnitTest.cliconf_plugins.cliconf_plugin import CliConf
    from UnitTest.connection_plugins.connection_plugin import ConnectionModule
    from UnitTest.facts_plugins.facts_plugin import FactsModule
    from UnitTest.filter_plugins.filter_plugin import FilterModule
    from UnitTest.httpapi_plugins.httpapi_plugin import HttpApiModule
    from UnitTest.inventory_plugins.inventory_plugin import InventoryModule
    from UnitTest.lookup_plugins.lookup_plugin import LookupModule
    from UnitTest.strategy_plugins.strategy_plugin import StrategyModule

# Generated at 2022-06-24 17:49:49.357333
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    import mock
    from ansible.plugins.loader import module_loader


# Generated at 2022-06-24 17:49:57.895989
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    expected = {'cloudformation': {'key': 'cloudformation', 'value': 'Amazon CloudFormation module'}, 'ec2': {'key': 'ec2', 'value': 'Amazon Elastic Compute Cloud (EC2). This module has a corresponding action plugin'}}
    for elem in expected:
        if elem not in doc_c_l_i_0.get_all_plugins_of_type('module'):
            return False
    return True


# Generated at 2022-06-24 17:50:03.097729
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    role_mixin_1 = RoleMixin()
    doc_c_l_i_1 = DocCLI(role_mixin_1)

    # Call the method DocCLI.format_plugin_doc
    doc_c_l_i_1.format_plugin_doc({'ANSIBLE_MODULE_ARGS': {}})


# Generated at 2022-06-24 17:50:10.139664
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)

    class LoaderCLI(CLI):
        pass

    ansible_loader_2 = AnsibleLoader(None, None, './mock_path_2/', LoaderCLI())
    try:
        doc_c_l_i_0.get_all_plugins_of_type(ansible_loader_2)
    except Exception:
        pass


# Generated at 2022-06-24 17:50:22.098254
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    # Test with correct path
    filepath = '/etc/ansible/roles/foo/library'
    namespace = doc_c_l_i_0.namespace_from_plugin_filepath(filepath)
    assert namespace == 'foo', "namespace_from_plugin_filepath returned incorrect namespace"

    # Test with incorrect path
    filepath = '/etc/ansible/roles/library'
    with pytest.raises(AnsibleOptionsError) as exec_info:
        # Test with incorrect path
        doc_c_l_i_0.namespace_from_plugin_filepath(filepath)
    # Test if exec_info.value is an AnsibleOptions

# Generated at 2022-06-24 17:50:29.817562
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    doc_c_l_i_0.options = mock.Mock()
    doc_c_l_i_0.options.listtype = 'action'
    doc_c_l_i_0.options.path = None
    doc_c_l_i_0.options.ignore_errors = None
    doc_c_l_i_0.options.connection = None
    doc_c_l_i_0.options.filter = None
    doc_c_l_i_0.options.extra_vars = None
    doc_c_l_i_0.options.module_path = None

    # Call method find_plugins of class DocCLI
    #

# Generated at 2022-06-24 17:50:34.372940
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    with pytest.raises(Exception):
        doc_c_l_i_0.get_man_text(role_mixin_0)


# Generated at 2022-06-24 17:50:42.047858
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    role_mixin_1 = RoleMixin()
    doc_c_l_i_1 = DocCLI(role_mixin_1)

    text = []
    doc_c_l_i_1.add_fields(text, [1, 2, 3], 100, "  ")
    text = '\n'.join(text)

    assert text == "    - 1\n    - 2\n    - 3\n", "Incorrect return value from DocCLI::add_fields()."


# Generated at 2022-06-24 17:50:50.690570
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Create mock object for module 'ansible.utils.display' with mock_object
    mock_display_fixtures_0 = TestFixtures.create_ansible_utils_display_mock()
    with mock.patch.dict(sys.modules, {'ansible.utils.display': mock_display_fixtures_0}):
        # Create mock object for class 'RoleMixin' with mock_object
        mock_role_mixin_0 = RoleMixin()
        # Create mock object for module 'ansible.cli.doc' with mock_object
        mock_doc_fixtures_0 = TestFixtures.create_ansible_cli_doc_mock()

# Generated at 2022-06-24 17:50:59.558903
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    role_0 = "role"
    role_json_0 = {"entry_points": {"module_utils": {"description": "module_utils"}, "handlers": {"description": "handlers"}, "tests": {"description": "tests"}}}
    text_0 = doc_c_l_i_0.get_role_man_text(role_0, role_json_0)
    assert len(text_0) == 12


# Generated at 2022-06-24 17:51:59.636158
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    # Create the first parameter
    data_0 = {"6.2": "2", ".6.2.6.6": "5", "abcd": "0"}
    # Get the class name
    # conv_0 = vars(__import__('%s.%s' % (data_0['abcd'], data_0['abcd']), fromlist=[data_0['.6.2.6.6']]))
    # Create the second parameter
    path_0 = data_0['6.2']
    # Get class object
    # conv_1 = getattr(conv_0, '%s' % (data_0['6.2']))
    # Instantiate

# Generated at 2022-06-24 17:52:06.837319
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    collection_namespace = 'namespace.plugin_name'
    plugin_filepath = 'path/to/file.py'
    expected = 'namespace'
    actual = DocCLI.namespace_from_plugin_filepath(collection_namespace, plugin_filepath)
    assert expected == actual


# Integration test for method namespace_from_plugin_filepath of class DocCLI

# Generated at 2022-06-24 17:52:19.444893
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Set up mock input and mock output

    # The object we are testing
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)

    # The parameters we are going to send
    # text is type 'list'
    text = []
    # opts is type 'dict'
    opts = {}
    # limits is type 'int'
    limits = 0
    # opt_indent is type 'str'
    opt_indent = ''
    # return_values is type 'bool'
    return_values = True
    # suboptions_indent is type 'str'
    suboptions_indent = ''

    # Invoke method
    # Parameter: text, opts, limits, opt_indent, return_values, suboptions_ind

# Generated at 2022-06-24 17:52:27.601034
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    text_0 = test_data.load_json_to_dict("module_docs_json")['doc']['options']
    result = doc_c_l_i_0.format_snippet(text_0)
    assert result == '''  b: Boolean
  c:
    default: 5
    description: >
      d
  e:
    choices: [/a, /b/c]
    description: f'''


# Generated at 2022-06-24 17:52:40.052383
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    role_mixin_1 = RoleMixin()
    doc_c_l_i_1 = DocCLI(role_mixin_1)
    # pkg_resources is a module and is not a file, we create a temporary file path and pass it to the method get_man_text of class DocCLI
    filename = os.path.join(tempfile.gettempdir(), 'pkg_resources.py')

# Generated at 2022-06-24 17:52:47.495847
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # TEST FILE READ
    print('\n')
    print('TEST FILE READ')
    print('\n')

# Generated at 2022-06-24 17:52:53.640901
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    doc_0 = dict()
    collection_name_0 = ''
    plugin_type_0 = 'yum'
    var_0 = doc_c_l_i_0.get_man_text(doc_0, collection_name_0, plugin_type_0)
    print(var_0)

if __name__ == '__main__':
    test_DocCLI_get_man_text()

# Generated at 2022-06-24 17:53:04.868097
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    # Test with a role.
    role_json_0 = dict()
    role_json_0['path'] = 'path'
    role_json_0['entry_points'] = dict()
    doc_0 = dict()
    doc_0['description'] = 'description'
    role_json_0['entry_points']['key_0'] = doc_0
    doc_1 = dict()
    doc_1['short_description'] = 'short_description'
    doc_1['description'] = 'description'
    doc_1['options'] = dict()
    option_0 = dict()
    option_0['description'] = 'description'

# Generated at 2022-06-24 17:53:15.126880
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    text_0 = []
    limit_0 = 100
    opt_indent_0 = "        "
    return_values_0 = '__ansible_return_value__'

    doc_c_l_i_0.add_fields(text_0, opt_indent_0, return_values_0, limit_0, return_values_0)
    text_1 = []
    limit_1 = 100
    opt_indent_1 = "        "
    return_values_1 = '__ansible_return_value__'


# Generated at 2022-06-24 17:53:19.561645
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    role_mixin_0 = RoleMixin()
    doc_c_l_i_0 = DocCLI(role_mixin_0)
    result = doc_c_l_i_0.format_snippet(None)
