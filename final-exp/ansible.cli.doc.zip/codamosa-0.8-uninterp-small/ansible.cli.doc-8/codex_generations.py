

# Generated at 2022-06-24 17:46:25.256888
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # TODO: Implement this unit test
    pass


# Generated at 2022-06-24 17:46:30.990722
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():

    # This is the list that will be diplayed
    plugin_list = [
        {
            'name' : 'Plugin1',
            'description' : 'description text 1',
            'filename' : 'filename1'
        },
        {
            'name' : 'Plugin2',
            'description' : 'description text 2',
            'filename' : 'filename2'
        }
    ]

    # This is the expected output
    expected = """
> PLUGIN1    (filename1)
  description text 1

> PLUGIN2    (filename2)
  description text 2"""

    with patch('ansible.cli.doc.display.display'):
        # Call the method
        DocCLI.display_plugin_list(plugin_list)

        # Assert it was called with the correct arguments

# Generated at 2022-06-24 17:46:35.324221
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = []
    options = {}
    doc = DocCLI(args, **options)


# Generated at 2022-06-24 17:46:46.421798
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    test_list = {}

    add_collection_plugins(test_list, 'action')
    assert len(test_list) == 1
    assert 'core' in test_list

    add_collection_plugins(test_list, 'action', coll_filter='geerlingguy.dns')
    assert len(test_list) == 2
    assert 'core' in test_list
    assert 'geerlingguy.dns' in test_list

    add_collection_plugins(test_list, 'action', coll_filter='inexistent')
    assert len(test_list) == 2
    assert 'core' in test_list
    assert 'geerlingguy.dns' in test_list

    add_collection_plugins(test_list, 'nonexistent')
    assert len(test_list) == 2

# Generated at 2022-06-24 17:46:58.615084
# Unit test for method namespace_from_plugin_filepath of class DocCLI

# Generated at 2022-06-24 17:47:06.015858
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Load data from ARA_DATA_DIR/plugin_doc/action_plugins/copy.json
    copy_doc = json.load(open(os.path.join(ARA_DATA_DIR, 'plugin_doc', 'action_plugins', 'copy.json')))
    # Generate man text for role 'copy' using copy_doc
    man_text = DocCLI().get_man_text(copy_doc, 'test_collection', 'action')
    # Test that man_text contains expected number of lines
    assert 57 == len(man_text.split("\n"))


# Generated at 2022-06-24 17:47:09.566339
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    test_obj = DocCLI()
    assert test_obj.get_all_plugins_of_type('module') == []
    assert test_obj.get_all_plugins_of_type('foo') == []


# Generated at 2022-06-24 17:47:18.894151
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # create a test JSON file (to be deleted after test is done)
    json_file_path = create_test_json_file()
    json_data = read_test_json_file(json_file_path)

    # TODO: Parameterize the following
    role = 'testRole'
    doc = DocCLI()
    text = doc.get_role_man_text(role, json_data)
    pprint(text)

    # delete the test JSON file
    os.remove(json_file_path)


# Generated at 2022-06-24 17:47:32.351335
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    from ansible.module_utils.common.collections import ImmutableDict
    # Create an instance of DocCLI
    doc_cli_obj = DocCLI()

    # create a mock role json

# Generated at 2022-06-24 17:47:46.752382
# Unit test for method find_plugins of class DocCLI

# Generated at 2022-06-24 17:49:03.855044
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    try:
        obj_0 = DocCLI()
        obj_0.get_man_text()
        obj_4 = DocCLI()
        obj_4.get_man_text(collection_name='f')
        obj_1 = DocCLI()
        obj_1.get_man_text(plugin_type='t')
        obj_3 = DocCLI()
        obj_3.get_man_text(collection_name='value', plugin_type='value')
        obj_2 = DocCLI()
        obj_2.get_man_text(int_0, int_1)
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-24 17:49:08.391685
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc_0 = DocCLI()
    res_0 = doc_0.get_all_plugins_of_type()
    assert res_0 is None


# Generated at 2022-06-24 17:49:20.356733
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    passed = 0
    failed = 0
    uid = 0
    name = 'get_man_text'
    arguments = (
        ("foo", "bar",),
    )
    for args in arguments:
        for func_args, func_kwargs in zip(args[:-1], args[-1]):
            uid += 1
            # setup
            doccl = DocCLI()

            # Try to call the function
            # In some cases there will be an exception, in others not.
            try:
                result = doccl.get_man_text(*func_args, **func_kwargs)
            except KeyboardInterrupt:
                raise
            except Exception as e:
                result = str(e)

            # Compare the result obtained to the expected one
            # If there is no assertion error, the function succeeded

# Generated at 2022-06-24 17:49:24.622779
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    my_cli = DocCLI()


# Generated at 2022-06-24 17:49:39.298293
# Unit test for method get_plugin_metadata of class DocCLI

# Generated at 2022-06-24 17:49:49.815119
# Unit test for method run of class DocCLI
def test_DocCLI_run():

    # Simple format test
    doc_0 = {
        'description': ['Generic comment'],
        'options': {
            'arg_1': {'type': 'str', 'description': 'Comment for argument 1'},
            'arg_2': {'type': ['str', 'bool'], 'description': 'Comment for argument 2'},
            'arg_3': {'description': 'Comment for argument 3'},
            'arg_4': {'description': 'Comment for argument 4', 'choices': ['one', 'two', 'three']},
            'arg_5': {'description': 'Comment for argument 5'}
        }
    }
    text_0 = DocCLI.run(doc_0, 'arg_4')
    assert(len(text_0) > 0)

# Generated at 2022-06-24 17:49:52.379026
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Create an object of the class DocCLI
    obj = DocCLI()
    obj.get_all_plugins_of_type()


# Generated at 2022-06-24 17:50:00.682511
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    test_file = '/tmp/ansible_module_DocCLI_test_0.txt'
    with open(test_file, 'w') as testfh:
        testfh.write('  tasks:\n')
        testfh.write('    - name: Create the container\n')
        testfh.write('      lxc_container:\n')
        testfh.write('        name: web01\n')
        testfh.write('        template: ubuntu\n')
        testfh.write('        template_opts: >-\n')
        testfh.write('          -r xenial --arch amd64\n')
        testfh.write('        cpuset: 0,1\n')
        testfh.write('        memory: 1024MB\n')

# Generated at 2022-06-24 17:50:05.233291
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    plugin_type = 'vars'
    loader = 'all'
    test_instance_0 = DocCLI()
    result_0 = test_instance_0.get_all_plugins_of_type(plugin_type, loader)


# Generated at 2022-06-24 17:50:10.986720
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    docs = DocCLI()
    (metadata, error) = docs.get_plugin_metadata('gce_common')
    assert metadata
    assert isinstance(metadata, dict)
    assert metadata['version_added']
    assert 'json' in metadata['requirements']
    (metadata, error) = docs.get_plugin_metadata('not_here')
    assert not metadata
    assert error
    assert "not found" in error


# Generated at 2022-06-24 17:52:44.113257
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = jload(open('./test/doc_files/gce_facts.json', 'r'))
    ut = DocCLI.get_man_text(doc, 'gce_compute')

# Generated at 2022-06-24 17:52:53.246993
# Unit test for method format_snippet of class DocCLI

# Generated at 2022-06-24 17:52:55.922503
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Run the method
    DocCLI.run()


# Generated at 2022-06-24 17:53:05.816199
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    int_0 = -2984
    str_0 = u'0.0'
    dict_0 = {}
    dict_1 = {'compiled': False, 'test': {'test': 'test', 'test2': 1}, 
				'int': int_0, 'float': 0.0, 'bool': False, 'list': [], 
				'none': None, 'complex': complex(1j), 'str': str_0, 'tuple': tuple()}
    list_0 = ['', '', '', '', '', '', '']
    dict_2 = dict()
    dict_2['parameter_skeletons'] = list_0
    dict_2['entry_point_skeletons'] = list()
    dict_2['deprecated'] = False
    dict_2

# Generated at 2022-06-24 17:53:15.431007
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Test Case 0 - Normal Case
    # Test Case 0 - Normal Case
    print_test_header("test_0_get_role_man_text - Normal Case")
    d = DocCLI()

# Generated at 2022-06-24 17:53:18.353247
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # test case for 0
    int_0 = -2984
    var_0 = jdump(int_0)


# Generated at 2022-06-24 17:53:21.623664
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    assert True == isinstance(DocCLI().add_fields(text, doc.pop('options'), limit, opt_indent), )


# Generated at 2022-06-24 17:53:28.329305
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    root = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible')
    module_path = os.path.join(root, 'modules')

    doc = DocCLI.get_plugin_metadata('system', module_path)
    assert doc['module'] == 'system'
    assert doc['version_added'] == 'historical'

    doc = DocCLI.get_plugin_metadata('system', plugin_type='module')
    assert doc['module'] == 'system'
    assert doc['version_added'] == 'historical'


# Generated at 2022-06-24 17:53:31.938170
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:53:34.901030
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    print("doc_cli.py:add_collection_plugins:testcase_0")
    test_case_0()
