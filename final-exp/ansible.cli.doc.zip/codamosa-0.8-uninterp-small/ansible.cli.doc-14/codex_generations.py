

# Generated at 2022-06-24 17:47:00.360346
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Create an instance of DocCLI
    doccli_0 = DocCLI()

    # Execute the run method
    doccli_0.run()

# Generated at 2022-06-24 17:47:01.713314
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc_cli = DocCLI()
    doc = {}
    doc_cli.get_man_text(doc)


# Generated at 2022-06-24 17:47:03.224515
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():

    # Test case 0
    test_case_0()


# Generated at 2022-06-24 17:47:08.288845
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = dict()
    plugin_type = 'action'
    coll_filter = 'cloud'
    add_collection_plugins(plugin_list, plugin_type, coll_filter)


# Generated at 2022-06-24 17:47:15.617384
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role_mixin_0 = RoleMixin()
    role_path_0 = './lib/ansible/modules/cloud/azure'
    role_man_text_0 = role_mixin_0.get_role_man_text(role_path_0)

# Generated at 2022-06-24 17:47:17.738062
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    test_doc_cli_0 = DocCLI()
    test_doc_cli_0.run()


# Generated at 2022-06-24 17:47:22.245802
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    plugin_loader = PluginLoader(
        'Action',
        'ansible.plugins.action',
        C.DEFAULT_ACTION_PLUGIN_PATH,
        'action_plugins',
        required_base_class=ActionBase
    )
    DocCLI_0 = DocCLI(None, walk_through_plugin_list(plugin_loader._package_paths, ''))
    # Test passing 0 as argument:
    metadata_0 = DocCLI_0.get_plugin_metadata(0)
    assert isinstance(metadata_0, dict)



# Generated at 2022-06-24 17:47:30.419809
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # with ansible-doc installed under roles folder, expected to raise exception
    # with message 'fail to load plugins for type'
    plugin_type = 'modules'
    with doc_test_module_path():
        try:
            DocCLI.get_all_plugins_of_type(plugin_type)
        except AnsibleError as e:
            assert 'fail to load plugins for type' in to_text(e)


# Generated at 2022-06-24 17:47:37.831500
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    docs = [
        {'name': 'shell'},
        {'name': 'command'}
    ]

    doc_clid = DocCLI()
    doc_clid.display_plugin_list(docs)

if __name__ == "__main__":
    test_case_0()
    test_DocCLI_display_plugin_list()

# Generated at 2022-06-24 17:47:41.075815
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role_mixin_0 = RoleMixin()
    role = ''
    role_json = {}
    ansible_module_name = ''
    ansible_module_type = ''
    with pytest.raises(AnsibleAssertionError):
        DocCLI.get_man_text(doc={}, collection_name=ansible_module_name, plugin_type=ansible_module_type)

# Generated at 2022-06-24 17:48:39.447726
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {'description': 'This is a sample module print_msg',
           'new_field': 'A new field for test',
           'extended_description': 'Extended description for the module',
           'author': 'an author',
           'options': {'msg': {'type': 'str', 'description': 'A message'}},
           'seealso': {'module': 'foo', 'description': 'A description'}}

    # this is what the output looks like

# Generated at 2022-06-24 17:48:49.972623
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    """
    doc_generator.DocCLI.get_man_text
    """
    # DocCLI.get_man_text without any parameters
    try:
        DocCLI.get_man_text()
    except TypeError:
        pass
    # Test with non-dict objects as parameters
    non_dict_objects = ["hello", 1, 1.0, True, False, None, (1, 2, 3), [1, 2, 3], set([1,2,3]), frozenset([1,2,3])]
    for item in non_dict_objects:
        try:
            DocCLI.get_man_text(doc=item)
        except TypeError:
            pass
    # Test so that the method works if all parameters are None

# Generated at 2022-06-24 17:48:57.262862
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:49:09.724365
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    try:
        output = io.StringIO()
        p = DocCLI(args=['-t', 'module', 'ping'], stdout=output)
        result = p.run()

        # Test assertions
        assert (result == 0)

    except SystemExit as e:
        assert (e.code == 0)

    except Exception as e:
        print('Caught exception: ' + str(e))
        print(traceback.format_exc(e))

        # Test exception assertions
        # This should not happen
        raise AssertionError("Exception when testing DocCLI.run()")

if __name__ == "__main__":
    test_case_0()
    test_DocCLI_run()

# Generated at 2022-06-24 17:49:17.123735
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():

    # Initialize a ansible module
    module = AnsibleModule(
        argument_spec = dict(
        )
    )

    role_mixin_0 = RoleMixin()
    role_mixin_0.ansible_module = module

    # test case 1
    # The path is invalid: there is no such file or directory
    result = role_mixin_0.get_role_man_text("foo", "bar")
    print(result)

    # test case 2
    # The path is valid, but the role cannot be found
    result = role_mixin_0.get_role_man_text("foo", "/usr/local/lib/python2.7/dist-packages/")
    print(result)

    # test case 3
    # The path is valid, but the role cannot be found

# Generated at 2022-06-24 17:49:19.850619
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = set()
    plugin_type = 'module'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)


# Generated at 2022-06-24 17:49:33.901097
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    test_collection_name_0 = 'test_collection_name_0'
    test_collection_name_1 = 'test_collection_name_1'
    coll_filter_0 = [test_collection_name_0]
    display.verbosity = 4

    # TODO: refactor this test to respect runtime.yml once implemented
    b_colldirs = list_collection_dirs(coll_filter=coll_filter_0)
    for b_path in b_colldirs:
        path = to_text(b_path, errors='surrogate_or_strict')
        collname = _get_collection_name_from_path(b_path)

# Generated at 2022-06-24 17:49:42.202979
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # Case 1 - Test namespace_from_plugin_filepath() call with a valid module file. The method should return a valid plugin type
    # Expected Result: One of the valid plugin types (i.e. module, shell, etc.)
    result = DocCLI.namespace_from_plugin_filepath('lib/ansible/modules/packaging/os/pip.py')
    assert(result in DocCLI.PLUGIN_TYPES)


# Generated at 2022-06-24 17:49:49.892072
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = DocCLI()
    print("doc.get_plugin_metadata()\n")
    print(doc.get_plugin_metadata())


# Generated at 2022-06-24 17:49:59.141108
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    DocCLI_obj = DocCLI()
    # test for valid path
    plugin_path = "./test/test_data/test_module_doc.py"
    module_list = DocCLI_obj.get_plugin_metadata(plugin_path)
    assert isinstance(module_list, list)
    assert len(module_list) == 1
    assert isinstance(module_list[0], dict)

    # test for invalid path
    plugin_path = "./test/test_data/test_module_doc_non_existent.py"
    module_list = DocCLI_obj.get_plugin_metadata(plugin_path)
    assert isinstance(module_list, list)
    assert len(module_list) == 0


# Generated at 2022-06-24 17:51:32.977578
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    module_path = 'library/cloud/amazon/ec2_vpc_subnet.py'
    doc_text = DocCLI.get_man_text(DocCLI.get_doc(module_path))
    print(doc_text)

# Test Suite
test_case_0()
#test_DocCLI_get_man_text()

# Generated at 2022-06-24 17:51:34.554149
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    DocCLI.print_paths()


# Generated at 2022-06-24 17:51:44.198323
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-24 17:51:55.614959
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    role_mixin_0 = RoleMixin()
    plugin_type_0 = 'action'
    plugin_name_0 = 'assert'
    plugin_metadata_0 = role_mixin_0.get_plugin_metadata(plugin_type_0, plugin_name_0)
    # metadata_0 was generated using the following code.
    # metadata_0 = {
    #     'description': 'assert something is true\n\nThis module asserts that a condition is true with an optional error message.\n',
    #     'env': [
    #         {
    #             'name': 'ANSIBLE_ASSERT_MODULE_PATH'
    #         }
    #     ],
    #     'filename': '/home/qe/vmchecker-work/ansible/lib/ansible/modules/utilities/logic/assert

# Generated at 2022-06-24 17:52:02.717751
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Test method get_man_text of class DocCLI
    # for index out of range
    doc = {'description': 'Set system hostname'}
    # by default, the collection name is empty
    # the plugin type is module
    Collection.resolve_all()
    print(DocCLI.get_man_text(doc))
    print(DocCLI.get_man_text(doc, 'core', 'module'))


# Generated at 2022-06-24 17:52:10.333730
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc_object = DocCLI()
    role_name = "test_role"
    role_json = {"entry_points": {"main": {"description": "Main Function of the role", "short_description": "Main Function"}}}
    man_text = doc_object.get_role_man_text(role_name, role_json)
    assert "[> TEST_ROLE]\nENTRY POINT: main - Main Function\n    Main Function of the role\n" == man_text


# Generated at 2022-06-24 17:52:16.963161
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    '''
    Create a DocCLI object and attempt to use get_man_text to retrieve
    documentation on the file module
    '''
    doc_cli = DocCLI()
    output = doc_cli.get_man_text(doc_cli.module_loader.get_docstring(os.path.basename(__file__)))
    print(output)


# Generated at 2022-06-24 17:52:24.062597
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    docCLI_0 = DocCLI()
    # Normal case: plugin_type=None.
    # Return type: dict.
    assert isinstance(docCLI_0.find_plugins(), dict), "Return type of DocCLI.find_plugins does not match"
    # Normal case: plugin_type="module".
    # Return type: dict.
    plugin_type = "module"
    assert isinstance(docCLI_0.find_plugins(plugin_type), dict), "Return type of DocCLI.find_plugins does not match"


# Generated at 2022-06-24 17:52:36.227300
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Test parameters
    p = dict(
        in_dir = '/in_dir',
        in_dir_filenames = ['/in_dir/a', '/in_dir/b', '/in_dir/c'],
        force = True,
        module_dir = '/module_dir',
        module_dir_filenames = ['/module_dir/a', '/module_dir/b', '/module_dir/c'],
        in_dir_filenames_plugin_type = '_in_dir_filenames_plugin_type',
        module_dir_filenames_plugin_type = '_module_dir_filenames_plugin_type',
        plugin_type = 'module'
    )

    # Test mocks

# Generated at 2022-06-24 17:52:38.979161
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = dict()
    plugin_type = 'connection'
    coll_filter = 'collection*'
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list.get('vmware_guest') is not None



# Generated at 2022-06-24 17:53:21.578872
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    with patch('sys.stdout', new=StringIO()) as fake_stdout:
        DocCLI.display_plugin_list()

    # Test assert
    assert 'callback' in fake_stdout.getvalue()
    assert 'deprecated' not in fake_stdout.getvalue()


# Generated at 2022-06-24 17:53:25.660184
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():

    # Test with all parameters (plugins, type)
    doc_cli_0 = DocCLI({}, 'testtype')

    # Test with mandatory (plugins) and optional (type) parameters
    doc_cli_1 = DocCLI({}, 'testtype')


# Generated at 2022-06-24 17:53:32.701168
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'action'
    coll_filter = 'test-collection-1.0'
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert 'test_plugin' in plugin_list
    assert 'test_plugin' in plugin_list['test_plugin'].keys()
    assert 'test-collection-1.0/test_plugin' in plugin_list['test_plugin']['test_plugin']
    assert 'test_plugin' in plugin_list['test_plugin']['test_plugin']['test-collection-1.0/test_plugin']

# Adding the log_module deprecation test case here

# Generated at 2022-06-24 17:53:42.975245
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    plugin_type_0 = 'module'
    plugin_list_0 = {
        'ansible.posix': 'ansible.posix.cliconf',
        'ansible.posix': 'ansible.posix.debug.fireball',
        'ansible.posix': 'ansible.posix.debug.login'
    }
    cmd_0 = ('ansible-doc',
             '-t',
             plugin_type_0)

    with pytest.raises(SystemExit) as cm:
        arg_0 = DocCLI.parse()
        arg_0.run(cmd_0)

    assert cm.type == SystemExit

    arg_0 = DocCLI.parse()
    arg_0.run(cmd_0)
    args_0 = arg_0.args
    collection_loader_0

# Generated at 2022-06-24 17:53:54.249024
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():

    # Test case 1
    test_case_1 = DocCLI()
    snippet_1 = ['- name: Create config file',
                 '  template:',
                 '    src: config.j2',
                 '    dest: /etc/foo.conf']
    snippet_2 = ['    src: config.j2', '    dest: /etc/foo.conf']
    snippet_3 = ['  template:',
                 '    src: config.j2',
                 '    dest: /etc/foo.conf']
    snippet_4 = ['    src: config.j2', '  dest: /etc/foo.conf']
    snippet_5 = ['- name: Create config file',
                 '  template:',
                 '    src: config.j2',
                 '  dest: /etc/foo.conf']
    snippet_6