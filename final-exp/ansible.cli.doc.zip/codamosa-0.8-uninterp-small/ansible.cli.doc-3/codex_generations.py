

# Generated at 2022-06-24 17:46:51.902413
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = dict()
    doc['author'] = "Alan Smithee"
    doc['author'] = ["Alan Smithee", "Anita Bath"]
    doc['description'] = "Do something"
    doc['description'] = ["Do something", "Do something else"]
    doc['deprecated'] = False
    doc['deprecated'] = "deprecated is a string"
    doc['deprecated'] = dict()
    doc['deprecated'] = {'reason': "deprecated"}
    doc['deprecated'] = {'reason': "deprecated", 'version': "2.6"}
    doc['deprecated'] = {'reason': "deprecated", 'version': "2.6", 'why': "because"}

# Generated at 2022-06-24 17:46:54.127956
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc_cli = DocCLI()
    doc_cli.find_plugins()
    doc_cli.print_man()

if __name__ == '__main__':
    test_DocCLI_find_plugins()

# Generated at 2022-06-24 17:47:00.273100
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    root=os.path.dirname(os.path.dirname(__file__))
    plugin_dir = os.path.join(root, 'lib', 'ansible', 'plugins')
    plugin_filepath = os.path.join(plugin_dir, 'connection', '__init__.py')

    expected = 'connection'
    result = DocCLI.namespace_from_plugin_filepath(plugin_filepath)
    assert result == expected, "Got %s instead of %s" % (result, expected)


# Generated at 2022-06-24 17:47:09.397979
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.utils.display import Display
    from ansible.cli.arguments import option_helpers as coh

    display = Display()
    doc = DocCLI(display)

    test_module_name = "ansible.module_utils.basic"
    test_plugin_name = "ansible_test"
    test_plugin_type = "module"

    # call format_plugin_doc
    # check the value returned
    ans = doc.format_plugin_doc(
        test_module_name,
        test_plugin_name,
        test_plugin_type,
        False,
        False
    )


# Generated at 2022-06-24 17:47:14.848726
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc_cli_obj = DocCLI()
    plugin_list = [('test_plugin0', 'test_type0', 'test_desc0'), ('test_plugin1', 'test_type1', 'test_desc1'), ('test_plugin2', 'test_type2', 'test_desc2')]
    for i in plugin_list:
        doc_cli_obj.display_plugin_list(i)


# Generated at 2022-06-24 17:47:22.784253
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Prepare data
    plugin_name = "copy"
    collection_name = "mylib"


# Generated at 2022-06-24 17:47:33.837838
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    opt_indent = "    "
    limit = 20
    return_values = False

    # Create a copy of dict to avoid modifying original dict
    data = dict()
    data["name"] = "name"
    data["type"] = "dict"
    data["default"] = "default"
    data["required"] = True
    data["aliases"] = ["alias1", "alias2"]
    data["choices"] = "choices"
    data["description"] = "description"
    data["minimum"] = "minimum"
    data["version_added"] = "2.10"
    data["version_added_collection"] = "3.0"

    DocCLI.add_fields(text, data, limit, opt_indent, return_values, opt_indent)


# Generated at 2022-06-24 17:47:43.228010
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    class MockTerminalWriter():
        def __init__(self):
            self.output = ''

        def write(self, string, color=None, stderr=False, screen_only=False):
            self.output += string

    terminal_writer = MockTerminalWriter()
    doc_obj = DocCLI(terminal_writer)
    plugin_type = 'action'
    doc_obj._role_entry_points = False
    doc_obj.display_plugin_list(plugin_type, [])
    assert 'action' in terminal_writer.output


# Generated at 2022-06-24 17:48:00.173547
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-24 17:48:14.472452
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    cli_doc_0 = DocCLI()
    snippet_0 = {'version_added': 'historical', 'description': 'description'}
    snippet_0 = dict(snippet_0)
    assert cli_doc_0.format_snippet(snippet_0, 0) == '[historical] description'

    snippet_1 = {'description': 'description'}
    snippet_1 = dict(snippet_1)
    assert cli_doc_0.format_snippet(snippet_1, 0) == 'description'

    with pytest.raises(AnsibleError):
        cli_doc_0.format_snippet(snippet_1)


# Generated at 2022-06-24 17:52:06.798946
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test empty folder
    cli_doc = DocCLI()
    folder_name_0 = 'ansible/empty_folder'
    data_0 = cli_doc.get_plugin_metadata(folder_name_0)
    assert data_0 is None
    # Test type filter
    folder_name_1 = 'ansible/lib/ansible/modules/network/aos'
    data_1 = cli_doc.get_plugin_metadata(folder_name_1, 'module')
    assert data_1 is not None
    data_2 = cli_doc.get_plugin_metadata(folder_name_1, 'module', 'test')
    assert data_2 is None
    # Test filter name
    folder_name_2 = 'ansible/test/units/modules/network/aos'
    data_3 = cl

# Generated at 2022-06-24 17:52:09.870233
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    role_mixin_0 = RoleMixin()
    plugin_list = {}
    plugin_type = 'module'
    add_collection_plugins(plugin_list, plugin_type)
    assert len(plugin_list) > 0


# Generated at 2022-06-24 17:52:18.991482
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    doc = {"key1":"val1","key2":"val2"}
    DocCLI.add_fields(text, doc)
    for item in text:
        if "key1:" in item and "val1" in item:
            assert True
        elif "key2:" in item and "val2" in item:
            assert True
        else:
            assert False, "Some unexpected fields parsed"

if __name__ == "__main__":
    test_case_0()
    test_DocCLI_add_fields()
    print("All tests passed!")

# Generated at 2022-06-24 17:52:29.151572
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    opt_indent = "        "
    return_values = False
    limit = 70
    role_json = ''

    with open('../../../../../lib/ansible/modules/system/setup.py', 'r') as stream:
        doc = parse_docstring(stream.read())
        DocCLI.add_fields(text, doc, limit, opt_indent, return_values, opt_indent)
        assert len(text) > 0
        assert text[0] == "OPTIONS (= is mandatory):"

    with open('../../../../../../test/units/modules/utilities/run_playbook.py', 'r') as stream:
        doc = parse_docstring(stream.read())

# Generated at 2022-06-24 17:52:40.318001
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():

    if not os.path.exists('tests/data/role_mixin/example_role/meta/main.yml'):
        raise Exception('Does not exist meta/main.yml file.')

    if not os.path.exists('tests/data/role_mixin/example_role/tasks/main.yml'):
        raise Exception('Does not exist tasks/main.yml file.')

    if not os.path.exists('tests/data/role_mixin/example_role/README.md'):
        raise Exception('Does not exist README.md file.')

    role_mixin_0 = RoleMixin()

    # Call method get_role_man_text()
    doc = role_mixin_0.get_role_doc('tests/data/role_mixin/example_role')

# Generated at 2022-06-24 17:52:47.584705
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role_mixin_0 = RoleMixin()
    role_mixin_1 = RoleMixin()
    doc = {}
    doc['filename'] = 'a'
    doc['description'] = 'a'
    doc['entry_points'] = {}
    ep0 = {}
    ep0['filename'] = 'a'
    ep0['short_description'] = 'a'
    ep0['description'] = 'a'
    ep0['options'] = {'action':{'env':[{'name': 'ANSIBLE_NET_AUTHORIZE'}, {'name': 'ANSIBLE_NET_AUTH_PASS'}]}}

# Generated at 2022-06-24 17:52:55.570630
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    from ansible.utils.context import display, CLIContext
    display = display.Display()
    context = CLIContext()
    context.CLIARGS = {
        'type': context.CLIARGS['type']
    }
    DocCLI_obj = DocCLI()
    DocCLI_obj.display = display
    DocCLI_obj.context = context
    # default case
    plugin_filepath = './lib/ansible/modules/cloud/azure/azure_rm_appserviceplan_facts.py'
    namespace = DocCLI_obj.namespace_from_plugin_filepath(plugin_filepath)
    assert namespace == "cloud.azure.azure_rm_appserviceplan"

    # Case for collect_all

# Generated at 2022-06-24 17:53:05.612504
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Get the AnsiblePlugin class's Meta class
    ansible_plugin_class = get_ansible_plugin_class()
    if ansible_plugin_class:
        plugin_metaclass = ansible_plugin_class.Meta
        test_doc_cli_instance = DocCLI()

        # Get the plugin metadata from AnsiblePlugin class's Meta class
        plugin_metadata = test_doc_cli_instance.get_plugin_metadata(plugin_metaclass)
        assert True == isinstance(plugin_metadata, dict)

        plugin_info = plugin_metadata.get('plugin_info')
        assert True == isinstance(plugin_info, dict)

        plugin_fields = plugin_metadata.get('plugin_fields')
        assert True == isinstance(plugin_fields, list)


# Generated at 2022-06-24 17:53:08.374876
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    docCLI_0 = DocCLI()
    docCLI_0.run()


# Generated at 2022-06-24 17:53:14.099560
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Create an instance of class DocCLI
    docCLI_instance_0 = DocCLI()
    # Get the list of plugins
    plugin_list = plugin_finder.find_plugin_specs()
    # Check if display_plugin_list(plugin_list) raises any exceptions
    docCLI_instance_0.display_plugin_list(plugin_list)


