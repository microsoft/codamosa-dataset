

# Generated at 2022-06-24 17:45:23.080852
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc_c_l_i_0 = DocCLI(arg1)
    str_0 = '''
    - name: Heading one
      description: |
        Here is the first line of the description.
        Here is the first line of the description.
        Line #3.
        Line #4.
      author: Spencer Herzberg
'''
    doc_c_l_i_0.import_doc_text(str_0)
    dict_0 = doc_c_l_i_0.get_plugin_metadata()

# Generated at 2022-06-24 17:45:34.128365
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    str_0 = '\n    This is a Darwin macOS User manipulation class.\n    Main differences are that Darwin:-\n      - Handles accounts in a database managed by dscl(1)\n      - Has no useradd/groupadd\n      - Does not create home directories\n      - User password must be cleartext\n      - UID must be given\n      - System users must ben under 500\n\n    This overrides the following methods from the generic class:-\n      - user_exists()\n      - create_user()\n      - remove_user()\n      - modify_user()\n    '

# Generated at 2022-06-24 17:45:45.710102
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    str_0 = '\n    This is a Darwin macOS User manipulation class.\n    Main differences are that Darwin:-\n      - Handles accounts in a database managed by dscl(1)\n      - Has no useradd/groupadd\n      - Does not create home directories\n      - User password must be cleartext\n      - UID must be given\n      - System users must ben under 500\n\n    This overrides the following methods from the generic class:-\n      - user_exists()\n      - create_user()\n      - remove_user()\n      - modify_user()\n    '
    doc_c_l_i_0 = DocCLI(str_0)

# Generated at 2022-06-24 17:45:48.481542
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    assert doc_c_l_i_0.find_plugins() == ['']


# Generated at 2022-06-24 17:45:51.899555
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    test_case_0()


# Generated at 2022-06-24 17:46:02.209863
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    str_0 = '\n    This is a Darwin macOS User manipulation class.\n    Main differences are that Darwin:-\n      - Handles accounts in a database managed by dscl(1)\n      - Has no useradd/groupadd\n      - Does not create home directories\n      - User password must be cleartext\n      - UID must be given\n      - System users must ben under 500\n\n    This overrides the following methods from the generic class:-\n      - user_exists()\n      - create_user()\n      - remove_user()\n      - modify_user()\n    '
    doc_c_l_i_0 = DocCLI(str_0)
    plugin_type_0 = 'python'

# Generated at 2022-06-24 17:46:11.380588
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    str_0 = '\n    This is a Darwin macOS User manipulation class.\n    Main differences are that Darwin:-\n      - Handles accounts in a database managed by dscl(1)\n      - Has no useradd/groupadd\n      - Does not create home directories\n      - User password must be cleartext\n      - UID must be given\n      - System users must ben under 500\n\n    This overrides the following methods from the generic class:-\n      - user_exists()\n      - create_user()\n      - remove_user()\n      - modify_user()\n    '

    # Adding docstring to the instance
    doc_c_l_i_0 = DocCLI(str_0)

    # Creating a list of options to pass to the method under test
    #
    # Value to be passed

# Generated at 2022-06-24 17:46:17.389249
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    found_error = False
    msg = ""

    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.cli.doc import display_plugin_list, setup_yaml, parse_doc, _get_doc

    # Test for bug https://github.com/ansible/ansible/issues/48828
    with patch.object(display, 'display', autospec=True) as mock_display:
        with patch.object(display, 'columns', 0):
            try:
                display_plugin_list([], 'connection', 'module')
            except ValueError as e:
                if 'line too long' in to_text(e):
                    msg = "display_plugin_list() raised ValueError when columns==0 (expected)"
                else:
                    found_error = True


# Generated at 2022-06-24 17:46:28.150184
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    str_0 = '\n    This is a Darwin macOS User manipulation class.\n    Main differences are that Darwin:-\n      - Handles accounts in a database managed by dscl(1)\n      - Has no useradd/groupadd\n      - Does not create home directories\n      - User password must be cleartext\n      - UID must be given\n      - System users must ben under 500\n\n    This overrides the following methods from the generic class:-\n      - user_exists()\n      - create_user()\n      - remove_user()\n      - modify_user()\n    '
    doc_c_l_i_0 = DocCLI(str_0)

# Generated at 2022-06-24 17:46:29.369151
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    with pytest.raises(SystemExit):
        # call the run method
        DocCLI.run()

# Generated at 2022-06-24 17:48:42.882049
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doccli = DocCLI(context_args={'username':'ci-ansible-bot', 'password':'123456'})


# Generated at 2022-06-24 17:48:44.764085
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test for method add_fields(0args) of class DocCLI
    assert True


# Generated at 2022-06-24 17:48:53.254891
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {}
    doc['description'] = [str_0, '    CHANGELOG\n    0.1 - Initial module\n']
    doc['short_description'] = 'Manage Mac OS X Users'
    doc['options'] = {}
    doc['options']['gid'] = {}
    doc['options']['gid']['description'] = ['The gid to set as the user\'s primary id.', 'This also sets the user\'s login group.', 'If no group exists by the name of C(gid), the module will fail.', 'Required if C(uid) is set.']
    doc['options']['gid']['type'] = 'int'
    doc['options']['gid']['version_added'] = '2.4'

# Generated at 2022-06-24 17:49:02.362112
# Unit test for method run of class DocCLI
def test_DocCLI_run():

    # test for method run with arguments: module, collection_name
    # test for method run with arguments: module, collection_name, plugin_type
    # test for method run with arguments: module, collection_name, plugin_type, verbose
    module = 'test'
    collection_name = 'test'
    plugin_type = 'test'
    verbose = False
    ret_obj = DocCLI(module, collection_name, plugin_type, verbose)
    ret_obj.run()

    # test for method run with arguments: module, collection_name
    # test for method run with arguments: module, collection_name, plugin_type
    # test for method run with arguments: module, collection_name, plugin_type, verbose
    module = 'test'
    collection_name = 'test'
    plugin_type = 'test'


# Generated at 2022-06-24 17:49:18.539678
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-24 17:49:33.249387
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-24 17:49:37.500222
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    doc = DocCLI()
    test = "a/b/c"
    expected = "c"
    actual = doc.namespace_from_plugin_filepath(test)
    assert expected == actual, "DocCLI.namespace_from_plugin_filepath(): Expected %s actual %s" % (expected, actual)


# Generated at 2022-06-24 17:49:49.003136
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    print("test_DocCLI_get_plugin_metadata")


# Generated at 2022-06-24 17:49:50.386814
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    assert True



# Generated at 2022-06-24 17:50:05.759526
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:51:00.844515
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    str_0 = '-  name: Create a new user with a different shell and home directory\n    user:\n      name: bob\n      uid: 1001\n      shell: /bin/zsh\n      home: /usr/bob\n'
    str_1 = '-  name: Add the user to a number of groups\n    user:\n      name: bob\n      groups: sudo, kmem, dialout\n      append: yes\n'
    str_2 = '-  name: Create a new group\n    group:\n      name: foo\n      state: present\n'
    str_3 = '-  name: Remove a user\n    user:\n      name: bob\n      state: absent\n'

# Generated at 2022-06-24 17:51:12.106520
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    str_0 = '\n    This is a Darwin macOS User manipulation class.\n    Main differences are that Darwin:-\n      - Handles accounts in a database managed by dscl(1)\n      - Has no useradd/groupadd\n      - Does not create home directories\n      - User password must be cleartext\n      - UID must be given\n      - System users must ben under 500\n\n    This overrides the following methods from the generic class:-\n      - user_exists()\n      - create_user()\n      - remove_user()\n      - modify_user()\n    '
    doc_c_l_i_0 = DocCLI(str_0)


# Generated at 2022-06-24 17:51:17.071590
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    str_0 = '\n    ' + str(content_0) + '\n    '
    doc_c_l_i_0 = DocCLI(str_0)
    role_0 = str(role_0)
    role_json_0 = yaml_load(yaml_0)
    result_get_role_man_text_0 = doc_c_l_i_0.get_role_man_text(role_0, role_json_0)
    assert (str(result_get_role_man_text_0) == "> " + str(role_man_result_0) + "\n")


# Generated at 2022-06-24 17:51:23.167321
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    str_0 = '\n    This is a Darwin macOS User manipulation class.\n    Main differences are that Darwin:-\n      - Handles accounts in a database managed by dscl(1)\n      - Has no useradd/groupadd\n      - Does not create home directories\n      - User password must be cleartext\n      - UID must be given\n      - System users must ben under 500\n\n    This overrides the following methods from the generic class:-\n      - user_exists()\n      - create_user()\n      - remove_user()\n      - modify_user()\n    '
    doc_c_l_i_0 = DocCLI(str_0)

# Generated at 2022-06-24 17:51:28.141661
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc_c_l_i_0 = DocCLI()
    module_list_0 = doc_c_l_i_0.get_all_plugins_of_type(context.CLIARGS['type'])
    assert module_list_0 is not None
    assert len(module_list_0) > 0

    for m in module_list_0:
        assert 'PATH' in m



# Generated at 2022-06-24 17:51:39.449191
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    str_0 = '\n    This is a Darwin macOS User manipulation class.\n    Main differences are that Darwin:-\n      - Handles accounts in a database managed by dscl(1)\n      - Has no useradd/groupadd\n      - Does not create home directories\n      - User password must be cleartext\n      - UID must be given\n      - System users must ben under 500\n\n    This overrides the following methods from the generic class:-\n      - user_exists()\n      - create_user()\n      - remove_user()\n      - modify_user()\n    '
    # Create a doc cli
    doc_c_l_i_0 = DocCLI(str_0)

    # Create a test string as the plugin filepath

# Generated at 2022-06-24 17:51:46.775046
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc_c_l_i_0 = DocCLI('\n    This is a Darwin macOS User manipulation class.\n    Main differences are that Darwin:-\n      - Handles accounts in a database managed by dscl(1)\n      - Has no useradd/groupadd\n      - Does not create home directories\n      - User password must be cleartext\n      - UID must be given\n      - System users must ben under 500\n\n    This overrides the following methods from the generic class:-\n      - user_exists()\n      - create_user()\n      - remove_user()\n      - modify_user()\n    ')

# Generated at 2022-06-24 17:51:58.227000
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    str_0 = '''
    - name: Fetch the latest example
      get_url:
        url: https://raw.github.com/ansible/ansible-examples/master/language_features/template_src_dest.j2
        dest: /etc/config.j2
        version_added: "1.3"
    - name: Apply example configuration
      template:
        src: /etc/config.j2
        dest: /etc/config
'''
    str_1 = '''
    - name: Fetch the latest example
    - name: Apply example configuration
'''

# Generated at 2022-06-24 17:52:06.820735
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    str_0 = '\n    This is a Darwin macOS User manipulation class.\n    Main differences are that Darwin:-\n      - Handles accounts in a database managed by dscl(1)\n      - Has no useradd/groupadd\n      - Does not create home directories\n      - User password must be cleartext\n      - UID must be given\n      - System users must ben under 500\n\n    This overrides the following methods from the generic class:-\n      - user_exists()\n      - create_user()\n      - remove_user()\n      - modify_user()\n    '
    doc_c_l_i_0 = DocCLI(str_0)
    # Call the get_man_text method.
    # No assertions are possible, because this method writes the docstring to STDOUT
    #doc

# Generated at 2022-06-24 17:52:18.272225
# Unit test for method display_plugin_list of class DocCLI

# Generated at 2022-06-24 17:53:23.183428
# Unit test for method run of class DocCLI
def test_DocCLI_run():
  str_0 = '\n    This is a Darwin macOS User manipulation class.\n    Main differences are that Darwin:-\n      - Handles accounts in a database managed by dscl(1)\n      - Has no useradd/groupadd\n      - Does not create home directories\n      - User password must be cleartext\n      - UID must be given\n      - System users must ben under 500\n\n    This overrides the following methods from the generic class:-\n      - user_exists()\n      - create_user()\n      - remove_user()\n      - modify_user()\n    '
  doc_c_l_i_0 = DocCLI(str_0)
  str_1 = 'darwin.plugins.user.user'

# Generated at 2022-06-24 17:53:31.833414
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    str_0 = '\n    This is a Darwin macOS User manipulation class.\n    Main differences are that Darwin:-\n      - Handles accounts in a database managed by dscl(1)\n      - Has no useradd/groupadd\n      - Does not create home directories\n      - User password must be cleartext\n      - UID must be given\n      - System users must ben under 500\n\n    This overrides the following methods from the generic class:-\n      - user_exists()\n      - create_user()\n      - remove_user()\n      - modify_user()\n    '
    obj_0 = DocCLI(str_0)

# Generated at 2022-06-24 17:53:42.674269
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc_c_l_i_0 = DocCLI()
    str_0 = '\n    This is a Darwin macOS User manipulation class.\n    Main differences are that Darwin:-\n      - Handles accounts in a database managed by dscl(1)\n      - Has no useradd/groupadd\n      - Does not create home directories\n      - User password must be cleartext\n      - UID must be given\n      - System users must ben under 500\n\n    This overrides the following methods from the generic class:-\n      - user_exists()\n      - create_user()\n      - remove_user()\n      - modify_user()\n    '

# Generated at 2022-06-24 17:53:52.476166
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc_c_l_i_0 = DocCLI('')
    str_0 = 'new_user'
    str_1 = 'user.py'
    dest_0 = doc_c_l_i_0.get_plugin_metadata(str_0, str_1)
    # assert len(dest_0) == 2
    # assert dest_0[0] == 'new_user'
    # assert dest_0[1] == 'user'
