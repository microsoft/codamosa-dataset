

# Generated at 2022-06-24 17:47:20.815831
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():

    # Unit test description
    print("\nTest test_DocCLI_format_snippet")
    print("===============================")
    print("Tests the DocCLI.format_snippet method code path.")

    # Test case description
    print("\nTest case 1: output a list of valid items")
    print("---------------------------------------------------")

    # Test setup
    snippet_list = ['hello world', '# comment line', 'ansible = 2.9.0', 'ansible == 2.9.0']
    snippet_prefix = 'ansible'

    # Expectation
    expected_result = """
hello world
ansible = 2.9.0
ansible == 2.9.0"""

    # Unit test execution
    result = DocCLI.format_snippet(snippet_list, snippet_prefix)

   

# Generated at 2022-06-24 17:47:24.745534
# Unit test for method find_plugins of class DocCLI

# Generated at 2022-06-24 17:47:33.316685
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    backup_doc = None
    backup_entry = None
    backup_short_desc = None
    backup_full_doc = None
    backup_options = None
    backup_attrs = None
    backup_notes = None
    backup_seealso = None
    backup_path = None
    backup_author = None
    backup_deprecated = None
    role_mixin = RoleMixin()
    doc = {}
    doc_entry = {}
    doc_entry_options = {}
    options = {}
    options_contains = {}
    options_contains_options = {}
    options_contains_options_choices = {}
    options_contains_options_contains = {}
    doc_entry_attributes = {}
    doc_entry_notes = {}
    doc_entry_seealso = {}
    doc_

# Generated at 2022-06-24 17:47:37.766697
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Execute DocCLI.run()
    # Check the number of arguments received by the method
    assert len(inspect.getargspec(DocCLI.run).args) == 2


# Generated at 2022-06-24 17:47:49.616841
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    test_case_0()

    test_data_0 = {}
    test_data_0['name'] = 'test'
    test_data_0['version_added'] = '2.2'
    test_data_0['short_description'] = 'Test'
    test_data_0['description'] = ['Test']
    test_data_0['options'] = {
        'test': {
            'description': 'Test',
            'type': 'str',
            'default': 'test'
        }
    }
    test_data_0['has_action'] = True
    test_data_1 = {}
    test_data_1['name'] = 'test'
    test_data_1['version_added'] = '2.2'
    test_data_1['version_added_collection'] = 'test'

# Generated at 2022-06-24 17:48:06.324815
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    instance = DocCLI()
    path = 'ansible/plugins/connection_plugins/netconf.py'
    expected_result = 'ansible.plugins.connection'
    result = instance.namespace_from_plugin_filepath(path)
    assert result == expected_result
    print("DocCLI.namespace_from_plugin_filepath() successful.")

if __name__ == "__main__":
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-24 17:48:16.724106
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.utils.display import Display
    display = Display()

    # Test case 1
    # Check if output is in true color

# Generated at 2022-06-24 17:48:20.835510
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc_cli_0 = DocCLI()
    doc_cli_0.IGNORE = ('deprecated_aliases',)

if __name__ == '__main__':
    test_case_0()
    test_DocCLI_get_man_text()

# Generated at 2022-06-24 17:48:26.667451
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    doc_cli_0 = DocCLI()
    exc = None
    # Provide correct argument to format_snippet
    try:
        doc_cli_0.format_snippet("test_text", "test_word", "test_color_theme", "test_color")
    except Exception as err:
        exc = err

    assert exc is None


# Generated at 2022-06-24 17:48:35.391393
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    r = C.data.get_plugin_data('doc_fragments', 'role_napalm_install')
    role_json = DocCLI._create_role_doc(r)
    text = DocCLI().get_role_man_text('role_napalm_install', role_json)
    assert len(text) == 14
    assert text[0].startswith('> ROLE_NAPALM_INSTALL')


# Generated at 2022-06-24 17:49:20.470784
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    plugins = DocCLI.get_plugin_metadata()

    # Do we have the expected number of plugins?
    assert_equal(len(plugins), 12)

    # Do we have the expected number of attributes?
    assert_equal(len(plugins['action']['copy']), 17)
    # Do we have the expected value for one of them?
    assert_equal(plugins['action']['copy']['filename'], 'action/copy.py')


# Generated at 2022-06-24 17:49:26.699711
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Create an instance of class DocCLI
    doc_cli_0 = DocCLI()

    # Create an example plugin doc
    plugin_doc = {
        'name': 'test',
        'description': 'This this is a description'
    }

    # We expect plugin name, description and filename to be printed (with some formatting)
    # We don't expect the other key:value pairs in the plugin_doc to be printed
    expected_output = (
        "> TEST    (filename)\n"
        "  This this is a description\n"
    )
    result = doc_cli_0.format_plugin_doc(plugin_doc, 'filename')
    assert result == expected_output


# Generated at 2022-06-24 17:49:37.199405
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    test_1_role_json=yaml.safe_load("""
        name: test
        description: a test role
        dependencies: []
        galaxy_info:
            author: admin
            company: Red Hat
            license: GPL
        entry_points:
            main:
                description: does a thing
                options:
                    test_option:
                        description: description of test_option
                        default: default_value
                        choices:
                            - first
                            - second
                        required: false
                        type: str
                        aliases:
                            - first_alias
                            - second_alias
        """)
    test_1_text = DocCLI.get_role_man_text('test', test_1_role_json)

# Generated at 2022-06-24 17:49:48.605095
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    file_name = "/home/yueqiu/rvm/gems/ruby-2.3.0/gems/ansible-2.4.2.0/lib/ansible/module_utils/facts/virtual/phyp.py"
    doc = {"description": "Adds a new virtual disk to a virtual server", "options": {"state": "description of state", "device": "description of device"}, "filename": file_name}
    assert(DocCLI.get_man_text(doc) == '''
> MODULE NAME    (file_name)
description
OPTIONS (= is mandatory):
        option: option_name
                description
        option: option_name
                description
'''[1:])

test_case_0()
test_DocCLI_get_man_text()

# Generated at 2022-06-24 17:49:52.897987
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    mod_name = "test_module"
    label = "label"
    label_type = "module"
    doc_cli = DocCLI(mod_name, label, label_type)

    doc_cli.run()


# Generated at 2022-06-24 17:49:54.528179
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    d = DocCLI()
    d.print_paths()


# Generated at 2022-06-24 17:50:01.416530
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role_mixin_0 = RoleMixin()
    role_0 = 'role_0'
    role_json_0 = {}
    role_json_0['path'] = 'path_0'
    entry_points_0 = {}
    option_0 = {}
    option_0['name'] = 'name_0'
    option_0['default'] = 'default_0'
    option_0['version_added'] = 'version_added_0'
    option_0['version_added_collection'] = 'version_added_collection_0'
    option_0['type'] = 'type_0'
    option_0['choices'] = 'choices_0'
    option_0['aliases'] = 'aliases_0'
    option_0['description'] = 'description_0'

# Generated at 2022-06-24 17:50:11.692385
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    cli = DocCLI()

    assert cli.find_plugins(['action_plugins', 'callback_plugins', 'connection_plugins', 'doc_fragments', 'filter_plugins', 'httpapi_plugins', 'inventory_plugins', 'lookup_plugins', 'shell_plugins', 'strategy_plugins', 'test_plugins', 'vars_plugins'])
    assert cli.find_plugins(['action_plugins', 'callback_plugins', 'connection_plugins', 'doc_fragments', 'filter_plugins', 'httpapi_plugins', 'inventory_plugins', 'lookup_plugins', 'shell_plugins', 'strategy_plugins', 'test_plugins', 'vars_plugins'], os.environ['ANSIBLE_COLLECTIONS_PATHS'])


# Generated at 2022-06-24 17:50:18.477609
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Make sure the mocking is setup
    setup_mock_ansible_module(MockCLI, None)

    # Test the method call with args
    # Test the method call with return value and args
    # Test the method call with return value, args and kwargs
    # Test the method call with return value, args, kwargs and side-effects
    # Test the method call with return value, args, kwargs, side-effects and a mock for the called method
    # Test the method call with return value, args, kwargs, side-effects, a mock for the called method and a mock of the class
    cls = DocCLI()
    mock_type = "mock_type"
    result = cls.get_all_plugins_of_type(mock_type)
    assert result is not None

# Unit test

# Generated at 2022-06-24 17:50:22.162983
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc_cli_0 = DocCLI()
    # doc_cli_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:51:40.687903
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:51:47.636514
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():

    DC = DocCLI()

    # Test with doc
    role = 'test_role'
    role_json = {
        'entry_points': {
            'main': {
                'short_description': 'Do something',
                'description': 'Do something',
                'options': {
                    'test_option_1': {
                        'description': 'first option'
                    },
                    'test_option_2': {
                        'description': 'the second option'
                    }
                },
                'attributes': {
                    'attr_1': 'The first attribute'
                }
            },
        }
    }
    text = DC.get_role_man_text(role, role_json)

# Generated at 2022-06-24 17:51:50.298025
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    src_list = []
    plugin_type = 'module'
    coll_filter = None
    add_collection_plugins(src_list, plugin_type, coll_filter)

    print(src_list)


# Generated at 2022-06-24 17:52:01.692994
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Set expected values
    # Create a mock cli args
    cli_args = Mock()
    cli_args.all = None
    cli_args.collection = None
    cli_args.one = None
    cli_args.type = 'module'
    cli_args.refresh_cache = False
    cli_args.list_modules = None
    cli_args.list_deprecated = False

    # Create a mock display object
    display = Mock()
    display.columns = 80

    # Create the mocks
    doc = Mock()

    # Call the method
    doccli = DocCLI()
    doccli.run(args=cli_args, doc=doc, display=display)


# Generated at 2022-06-24 17:52:12.575909
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    print ()
    print (">>> Executing test case for DocCLI.get_man_text method")
    print (">>> Verifying for valid input ...")
    doc_dict = {
        "module": "ping",
        "options": {
            "data": {
                "choices": [
                    "",
                    "hello",
                    "ciao",
                    "bonjour"
                ],
                "description":
                "Package payload data to send.  Default='' (no data).",
                "required": "no"
            }
        }
    }
    doc_cli_obj = DocCLI()
    print (">>> Verifying for valid input ...")

# Generated at 2022-06-24 17:52:17.749477
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    display_plugin_list_0 = DocCLI(['DocCLI', 'display_plugin_list'])._display_plugin_list()
    # (0, None, None)
    assert display_plugin_list_0 == (0, None, None)


# Generated at 2022-06-24 17:52:21.385300
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = dict()
    plugin_type = 'module'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert 'win_copy' in plugin_list


# Generated at 2022-06-24 17:52:25.965374
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # test with an empty doc. No error is raised.
    doc={}
    d = DocCLI.get_man_text(doc)
    assert d == ''


# Generated at 2022-06-24 17:52:39.998741
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():

    path = '..'
    search_paths = [path]
    collection_info = get_collection_info(search_paths, "ansible-test")

    import ansible.plugins.action.synchronize  # noqa
    action_plugin = ansible.plugins.action.synchronize.ActionModule(None, None, None, {})

    module = AnsibleModule()

    doc = action_plugin.get_doc()

    print('')
    print('--------------------------------------------------------------')
    print('')

    print(DocCLI.get_man_text(doc, collection_info.collection_name, module.name, None))

    print('')
    print('--------------------------------------------------------------')
    print('')

if __name__ == '__main__':
    test_case_0()
    test_DocCLI

# Generated at 2022-06-24 17:52:42.415180
# Unit test for function jdump
def test_jdump():
    try:
        jdump(test_case_0)
        # if expected output is true, then it returns the passed test case
        return test_case_0
    except AnsibleError as e:
        # if exception is thrown, then it returns the thrown exception
        return e


# Generated at 2022-06-24 17:53:29.824010
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    file_list = [os.path.join(MYDIR, '../../../lib/ansible/plugins/cliconf/ios.py')]
    expected_output = {'content_version': '1.1.1', 'deprecated': False, 'filename': 'ios.py', 'has_action': False, 'label': 'ios', 'name': 'ios', 'namespace': 'cliconf', 'short_description': 'ios', 'type': 'cliconf', 'version_added': '2.5'}
    doc = {}

    actual_output = cli.DocCLI.get_plugin_metadata(doc, file_list[0])
    # Add key 'filename' as we don't care about it
    actual_output['filename'] = expected_output['filename']


# Generated at 2022-06-24 17:53:41.925579
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc_cli_0 = DocCLI()
    plugin_list_0 = {'module': {'module1': 'module1'}, 'action': {'action1': 'action1'}}
    plugin_type_0 = 'module'
    doc_cli_0.display_plugin_list(plugin_list_0, plugin_type_0)
    plugin_list_1 = {'module': {'module1': 'module1'}, 'action': {'action1': 'action1'}}
    plugin_type_1 = 'module'
    doc_cli_0.display_plugin_list(plugin_list_1, plugin_type_1)
    plugin_list_2 = {'module': {'module1': 'module1'}, 'action': {'action1': 'action1'}}

# Generated at 2022-06-24 17:53:51.742890
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    with open("test/unit/modules/test_module_noplaybook.py", "r", encoding='utf-8') as f:
        test_module = f.read()
    test_module_dict = compile_module_docstring(test_module)
    test_module_dict['name'] = 'test_module_noplaybook'
    test_module_dict['docuri'] = 'test_module_noplaybook'
    test_module_dict['filename'] = 'test/unit/modules/test_module_noplaybook.py'
    test_module_dict['docuri'] = test_module_dict['name']
    doc = DocCLI()
    text = doc.get_man_text(test_module_dict)