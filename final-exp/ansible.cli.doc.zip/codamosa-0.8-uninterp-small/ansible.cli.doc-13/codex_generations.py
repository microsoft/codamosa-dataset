

# Generated at 2022-06-24 17:46:11.441269
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    c_l_i_elements_0 = ['connection', 'action']
    c_l_i_elements_1 = ['connection', 'action']
    c_l_i_elements_2 = ['lookup']
    c_l_i_elements_3 = ['connection', 'action']
    c_l_i_elements_4 = ['lookup']

    # Test exception raise of get_all_plugins_of_type method

# Generated at 2022-06-24 17:46:18.127975
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    '''
    Unit test for method DocCLI.format_plugin_doc
    '''
    bool_0 = True
    doc_c_l_i_0 = DocCLI(bool_0)

    bool_0 = True
    str_0 = '1'
    dict_0 = {'1': bool_0, '0': str_0, '2': str_0, '3': str_0, '4': bool_0, '5': str_0, '6': str_0, '7': str_0, '8': str_0}
    str_1 = doc_c_l_i_0.format_plugin_doc(dict_0)
    return str_1


# Generated at 2022-06-24 17:46:23.706690
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    bool_0 = True
    doc_c_l_i_0 = DocCLI(bool_0)
    module_name_0 = None
    doc_0 = DocCLI.get_man_text(module_name_0)
    assert doc_0 != None


# Generated at 2022-06-24 17:46:26.447929
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role_0 = 'role_0'
    role_json_0 = 'role_json_0'
    DocCLI.get_role_man_text(role_0, role_json_0)


# Generated at 2022-06-24 17:46:29.703075
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    bool_0 = True
    plugin_lists_0 = []
    plugin_lists_0.append(['', '', ''])
    opt_indent_0 = '        '
    doc_c_l_i_0 = DocCLI(bool_0)
    doc_c_l_i_0.display_plugin_list(plugin_lists_0, opt_indent_0)


# Generated at 2022-06-24 17:46:33.919358
# Unit test for function jdump
def test_jdump():
    msg_0 = 'Test'
    result = jdump(msg_0)
    assert result is None



# Generated at 2022-06-24 17:46:44.679993
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    if platform.python_implementation() != 'Jython': # requires jre >= 8u60
        return
    bool_0 = True
    doc_c_l_i_0 = DocCLI(bool_0)
    str_0 = 'foo.py'
    plugin_0 = AnsibleModule(str_0)
    result = doc_c_l_i_0.get_plugin_metadata(plugin_0)
    assert result

if __name__ == "__main__":
    test_case_0()
    test_DocCLI_get_plugin_metadata()

# Generated at 2022-06-24 17:46:53.055217
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:46:58.208626
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    bool_0 = True
    doc_c_l_i_0 = DocCLI(bool_0)
    # Iterate through all the elements of the list

# Generated at 2022-06-24 17:47:03.831376
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    bool_0 = True
    doc_c_l_i_0 = DocCLI(bool_0)
    str_0 = ''
    dict_0 = collections.OrderedDict()
    dict_0['version_added'] = None
    dict_0['aliases'] = collections.OrderedDict()
    dict_0['aliases']['host'] = None
    dict_0['aliases']['connection'] = None
    dict_0['aliases']['ansible_host'] = None
    dict_0['aliases']['ansible_connection'] = None
    dict_0['description'] = ['Hostname or address of the remote host.']
    dict_0['description'].append(None)
    str_1 = 'string'
    dict_0['type'] = str_1
    dict_

# Generated at 2022-06-24 17:47:49.017619
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc_c_l_i_0 = DocCLI(None)
    doc_c_l_i_1 = DocCLI(None)
    # Options are required, testing a failure case
    with pytest.raises(SystemExit):
        doc_c_l_i_1.run()
    # Tests that DocCLI.run can return 1
    assert doc_c_l_i_1.run() == 1
    # Tests that DocCLI.run can return None
    assert doc_c_l_i_0.run() is None
    # Tests that DocCLI.run can return None
    assert doc_c_l_i_0.run() is None
    # Tests that DocCLI.run can return None
    assert doc_c_l_i_0.run() is None
    # Tests that DocCL

# Generated at 2022-06-24 17:48:06.097418
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:48:15.155879
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    if os.getcwd().endswith('ansible_collections/ansible/builtin/plugins/modules'):
        filename = 'foo_module.py'
    else:
        filename = 'ansible_collections.ansible.builtin.plugins.modules.foo_module.py'

    doc_c_l_i_0 = DocCLI('.')
    retval_0 = doc_c_l_i_0.namespace_from_plugin_filepath(filename)
    assert retval_0 == 'ansible.builtin'


# Generated at 2022-06-24 17:48:29.868495
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc_c_l_i_0 = DocCLI(False)
    str_0 = 'package'
    bool_0 = True

# Generated at 2022-06-24 17:48:34.546137
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    bool_0 = True
    bool_1 = True
    dict_0 = {}
    dict_0['foo'] = 1


    doc_c_l_i_0 = DocCLI(bool_0)
    dict_1 = doc_c_l_i_0.get_all_plugins_of_type('foo', dict_0, bool_1)
    assert dict_1 == {}


# Generated at 2022-06-24 17:48:41.410943
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Examining only one plugin which is of type filter
    plugins = ['consul']
    plugin_type = 'filter'
    collection_name = 'community.general'
    doc_c_l_i_1 = DocCLI(True)
    doc_c_l_i_1.display_plugin_list(plugins, plugin_type, collection_name)


# Generated at 2022-06-24 17:48:51.124634
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Deserialize inter_api_json to inter_api using eval()
    inter_api_json = '{"name": "ut_name", "description": "ut_description", "version_added": "ut_version_added", "version_added_collection": "ut_version_added_collection", "options": {}, "notes": []}'
    inter_api = eval(inter_api_json)
    # Test by calling DocCLI.get_man_text()
    assert hasattr(DocCLI, 'get_man_text'), "Class `DocCLI` does not implement function `get_man_text`"
    out = DocCLI.get_man_text(inter_api)
    # Test the return type is str
    assert isinstance(out, str), "Out value is of type %s, expected type str" % type

# Generated at 2022-06-24 17:49:07.502336
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # test case 1
    bool_0 = True
    doc_c_l_i_0 = DocCLI(bool_0)
    str_0 = ''
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    str_1 = ''
    tuple_0 = ()
    tuple_1 = ()
    str_2 = ''
    tuple_2 = ()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15

# Generated at 2022-06-24 17:49:15.809871
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role = "role"
    role_json = { "path": "", "entry_points": "" }
    bool_0 = True
    doc_c_l_i_0 = DocCLI(bool_0)
    doc_c_l_i_0.get_role_man_text(role, role_json)


# Generated at 2022-06-24 17:49:25.108645
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    print("Starting test_DocCLI_get_man_text")
    doc_c_l_i_0 = DocCLI()

    if NOT_HAS_PYTHON_YAML:
        print("The python-yaml package is required to run this unit test")
        return
        

# Generated at 2022-06-24 17:50:12.180057
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Setup
    doc_cli_0 = DocCLI()

    # Invoke method
    plugin_type_0 = 'action'
    result_0 = doc_cli_0.get_all_plugins_of_type(plugin_type_0)
    assert (result_0 is not None)
    assert (isinstance(result_0, list))
    assert (result_0 != [])
    # Verify that all elements of result_0 are dictionaries
    for element in result_0:
        assert (isinstance(element, dict))

    plugin_type_1 = 'connection'
    result_1 = doc_cli_0.get_all_plugins_of_type(plugin_type_1)
    assert (result_1 is not None)
    assert (isinstance(result_1, list))

# Generated at 2022-06-24 17:50:18.679242
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    for file in os.listdir("../../lib/ansible/plugins/doc_fragments"):
        index = file.rfind(".")
        if index != -1:
            extension = file[index + 1:]

# Generated at 2022-06-24 17:50:20.644651
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    dc = DocCLI()
    dc.display_plugin_list()


# Generated at 2022-06-24 17:50:27.089872
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # First test
    doc = {}
    plugin_type = 'foo'
    result = DocCLI.format_plugin_doc(doc, plugin_type=plugin_type)
    assert result == 'foo    (None)\n'

    # Second test
    doc = {
        'filename': 'bar.py'
    }
    plugin_type = 'foo'
    result = DocCLI.format_plugin_doc(doc, plugin_type=plugin_type)
    assert result == 'foo    (bar.py)\n'


# Generated at 2022-06-24 17:50:33.648186
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Dict for test
    test_dict = {
        "doc": "test",
        "version_added": "test",
        "version_added_collection": "test"
    }
    # Test for DocCLI.format_plugin_doc
    assert "ADDED IN: test" in DocCLI.format_plugin_doc(test_dict)


# Generated at 2022-06-24 17:50:42.614365
# Unit test for method namespace_from_plugin_filepath of class DocCLI

# Generated at 2022-06-24 17:50:55.965284
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    role_mixin_0 = RoleMixin()
    ansible_doc_0 = AnsibleDocCLI()

# Generated at 2022-06-24 17:50:57.882733
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    DocCLI_0 = DocCLI()

    plugin_exists_return_value_0 = DocCLI_0.get_plugin_metadata(context.CLIARGS['type'], 'setup')

    # TODO


# Generated at 2022-06-24 17:51:04.116478
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Create a DocCLI object
    doc_cli = DocCLI()
    # Call the find_plugins method to find the plugins
    find_ans_plugin_result = doc_cli.find_plugins()
    # Assert isinstance of the object find_ans_plugin_result is equal to list
    assert isinstance(find_ans_plugin_result, list)
    # Assert the length of the list find_ans_plugin_result is greater than 0
    assert len(find_ans_plugin_result) > 0
    # Assert find_ans_plugin_result is not empty
    assert find_ans_plugin_result
    # Assert isinstance of the object at index 0 of find_ans_plugin_result is equal to str
   # assert isinstance(find_ans_plugin_result[0], str)


# Generated at 2022-06-24 17:51:14.352226
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    '''
    name:
      DocCLI.find_plugins
    type:
      assert
    tags:
      - documentation
    '''
    role_mixin_1 = RoleMixin()
    dc1 = DocCLI()
    find_plugins_str = '''
- name: assert find_plugins
  assert: {equals: {the: {'cloud.amazon.aws.%s' % name: 'docs'} }}
'''

# Generated at 2022-06-24 17:52:12.900629
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    text1 = []
    text2 = []
    opt_indent = "        "
    pad = display.columns * 0.20
    limit = max(display.columns - int(pad), 70)
    # test case 1
    options = {"options" : [{"name": "test", "type": "str", "description": "this is a test"}]}
    DocCLI.add_fields(text, options, limit, opt_indent)
    assert_equal(text, ["        OPTIONS (= is mandatory):",
                        "            test (=) - this is a test\n"])
    # test case 2

# Generated at 2022-06-24 17:52:22.538015
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    cli_doc_0 = DocCLI()
    man_text_0 = cli_doc_0.get_man_text({
        'description': 'Something',
        'options': {
            'something':{
                'description': 'Something',
                'aliases': ['such'],
                'version_added': '2.1',
            },
            'something else': {
                'description': 'Something else',
                'version_added': '2.2'
            },
            'such': {
                'description': 'Many something',
                'choices': ['very', 'many'],
                'default': 'very',
            }
        },
    })
    assert man_text_0 == "> "

    cli_doc_1 = DocCLI()
    assert cli_doc_1.get_

# Generated at 2022-06-24 17:52:35.271541
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Create test object
    doc_cli_0 = DocCLI()

    # Get role name
    role_name = 'salt'

    # Get role JSON

# Generated at 2022-06-24 17:52:39.188500
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    docCLI_test_0 = DocCLI()
    result = docCLI_test_0.display_plugin_list(['module'])
    if result < 0:
        print("[ERROR] display_plugin_list() test failed")
        sys.exit(1)
    else:
        print("[SUCCESS] display_plugin_list() test passed")


# Generated at 2022-06-24 17:52:40.173863
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    DocCLI.get_role_man_text()


# Generated at 2022-06-24 17:52:44.871185
# Unit test for function jdump
def test_jdump():
    display.verbosity = 100
    jdump(None)
    jdump({
        "metadata": {
            "supported_by": "core",
            "import_version": 1,
            "description": "This is a test module",
            "short_description": "Test module",
            "version_added": "1.0",
        }
    })
    display.verbosity = 1


# Generated at 2022-06-24 17:52:47.015612
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    doc = None
    text = None
    # Return Value
    assert DocCLI.add_fields(text, doc) == None


# Generated at 2022-06-24 17:52:53.281151
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    """
        Test for method get_all_plugins_of_type
        Test to get a list of all plugin modules of a given type
    """
    doccli_0 = DocCLI()
    plugin_finder_0 = PluginFinder('')
    # group_by_type to group the modules by type
    modules = {'cache': doccli_0._get_all_plugins_of_type(plugin_finder_0)}

    assert 'cache' in modules
    assert 'la' in modules['cache']
    assert 'rules' in modules['cache']


# Generated at 2022-06-24 17:52:55.922789
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    pass

# Unit test method run of class RoleMixin

# Generated at 2022-06-24 17:53:05.784509
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    ansible_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    fake_loader = DictDataLoader({
        'foo.py': '#!/usr/bin/python',
        'foo/__init__.py': '',
        'bar.py': '#!/usr/bin/python',
        'bar/__init__.py': '',
        'baz.ps1': '#!/usr/bin/python',
    })
    fake_inv = InventoryManager(loader=fake_loader, variants=C.DEFAULT_LOADED_VARS_PLUGINS)
    fake_inv.set_inventory(Host('localhost'))