

# Generated at 2022-06-24 17:45:34.201468
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    str_1 = 'L'
    doc_c_l_i_1 = DocCLI(str_1)
    
    # test 1
    str_1 = 'L'
    doc_c_l_i_2 = DocCLI(str_1)
    str_3 = 'L'
    doc_c_l_i_2 = DocCLI(str_3)
    str_4 = 'L'
    doc_c_l_i_2 = DocCLI(str_4)
    doc_c_l_i_1.add_fields(text, doc.pop('options'), limit, opt_indent)
    doc_c_l_i_1.add_fields(text, doc.pop('options'), limit, opt_indent)
    doc_c_l_i_1.add_fields

# Generated at 2022-06-24 17:45:41.529804
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc_c_l_i_0 = DocCLI('L')
    role_0 = 'role'
    role_json_0 = {}
    ret_0 = doc_c_l_i_0.get_role_man_text(role_0, role_json_0)
    return ret_0


# Generated at 2022-06-24 17:45:47.046962
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    plugin_path = 'lib/ansible/modules/cloud/amazon/ec2_elb_lb.py'
    assert DocCLI.namespace_from_plugin_filepath(plugin_path) == 'cloud.amazon'


# Generated at 2022-06-24 17:45:56.258005
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    str_0 = 'L'
    list_0 = ['file']
    # Testing branch: If_Expression__for_item_in_list_0
    # Testing branch: If_Expression__for_item_in_list_0
    str_1 = 'L'
    list_1 = ['file']
    # Testing branch: If_Expression__for_item_in_list_0
    # Testing branch: If_Expression__for_item_in_list_0
    str_2 = 'L'
    list_2 = ['file']
    # Testing branch: If_Expression__for_item_in_list_0
    str_3 = 'L'
    list_3 = ['file']
    # Testing branch: If_Expression__for_item_in_list_0

# Generated at 2022-06-24 17:46:02.635176
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc_c_l_i_0 = DocCLI()
    tries = []
    outputs = []
    returns = []

    try:
        tries.append("doc_c_l_i_0.find_plugins('%s')" % context.CLIARGS['type'])
        tmp = (doc_c_l_i_0.find_plugins(context.CLIARGS['type']))
        returns.append(tmp)
        outputs.append("Plugin type: %(type)s   name: %(name)s" % context.CLIARGS)
    except:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        error_string = str(exc_type) + str(exc_value) + str(traceback.format_exc(exc_traceback))
        outputs

# Generated at 2022-06-24 17:46:15.975333
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    str_0 = 'L'
    doc_c_l_i_0 = DocCLI(str_0)
    t = []
    text_wrap_0 = textwrap.TextWrapper(initial_indent='', subsequent_indent='')
    text_wrap_0.max_lines = None
    text_wrap_0.subsequent_indent = ''

# Generated at 2022-06-24 17:46:21.460072
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    doc_c_l_i_0 = DocCLI('L')
    dict_0 = {}
    add_collection_plugins(dict_0, 'modules')
    assert(dict_0 != {})



# Generated at 2022-06-24 17:46:30.903089
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    str_0 = 'L'
    str_1 = 'L'
    str_2 = 'L'
    doc_c_l_i_0 = DocCLI(str_0)
    str_3 = 'L'
    str_4 = 'L'
    str_5 = 'L'
    str_6 = 'L'
    str_7 = 'L'
    str_8 = 'L'
    str_9 = 'L'
    str_10 = 'L'
    str_11 = 'L'
    str_12 = 'L'
    str_13 = 'L'
    str_14 = 'L'
    str_15 = 'L'
    str_16 = 'L'
    str_17 = 'L'
    str_18 = 'L'
    str_19 = 'L'

# Generated at 2022-06-24 17:46:45.432837
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc_c_l_i_0 = DocCLI()
    str_0 = 'L'
    M_0_0 = 'module'
    str_1 = 'f'
    dict_0_0 = {'description': ['some', 'description'], 'short_description': 'some description', 'version_added': '2.6', 'options': {'name': {'description': 'some description', 'required': True}}}
    assert doc_c_l_i_0.format_plugin_doc(str_0, M_0_0, str_1, dict_0_0) == '''> MODULE.F    (module.f)
some description

ADDED IN: 2.6

OPTIONS (= is mandatory):
    name:
        description: some description
        required: yes
'''


# Generated at 2022-06-24 17:46:50.870779
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc_c_l_i_0 = DocCLI('w')
    doc_c_l_i_0.display_plugin_list(('action', 'connection', 'lookup'))

# test case for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:47:35.403431
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    test_case_0()


# Generated at 2022-06-24 17:47:41.835851
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    test_case_0()

# Generated at 2022-06-24 17:47:47.131919
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    docCli = DocCLI()
    docCli.run()

if __name__ == '__main__':
    test_case_0()
    test_DocCLI_run()

# Generated at 2022-06-24 17:47:51.906590
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    display.columns = 80
    display_plugin_list('./lib/ansible/modules/cloud/amazon/ec2_elb_lb.py')

# Generated at 2022-06-24 17:47:53.436650
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    print()


# Generated at 2022-06-24 17:48:07.309955
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = dict(description='description', options=None, filename='filename')
    collection_name='collection_name'
    plugin_type='plugin_type'
    # print DocCLI().get_man_text(doc, collection_name, plugin_type)
    pass

if __name__ == '__main__':
    from ansible.module_utils.basic import *
    from ansible.cli import CLI
    cli = CLI(sys.argv)
    os.environ['ANSIBLE_CONFIG'] = "/home/tacc/code/ansible_cfg_dir/ansible.cfg"
    os.environ['LIB'] = "ansible/library"
    os.environ['ANSIBLE_LIBRARY'] = os.environ['LIB']

# Generated at 2022-06-24 17:48:12.878357
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 0
    opt_indent = ""
    return_values = 0
    DocCLI.add_fields(text, opt, limit, opt_indent, return_values)
    pass


# Generated at 2022-06-24 17:48:21.805351
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-24 17:48:23.221940
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    assert callable(DocCLI.display_plugin_list)


# Generated at 2022-06-24 17:48:28.762668
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Set up test case input
    str_0 = 'lib/ansible/modules/cloud/amazon/ec2_elb_lb.py'

    # Run method to test
    DocCLI.find_plugins(str_0)

    # Verify results



# Generated at 2022-06-24 17:49:14.366997
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:49:24.195278
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = DocCLI.get_plugin_metadata('ec2_elb_lb.py')

# Generated at 2022-06-24 17:49:32.556081
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Call function to test
    if True:
        str_0 = 'lib/ansible/modules/cloud/amazon/ec2_elb_lb.py'
        doc_0 = get_doc(str_0)
        # Test the return code
        if True:
            # Call function to test
            DocCLI.get_man_text(doc_0)

# Generated at 2022-06-24 17:49:36.511217
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    str_0 = 'lib/ansible/modules/cloud/amazon/ec2_elb_lb.py'
    try:
        text = [None]
        DocCLI.add_fields(text, str_0, None, None)
    except SystemExit as exception:
        assert exception.code == 1

# Generated at 2022-06-24 17:49:39.501850
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc_cli = DocCLI()
    str_0 = 'lib/ansible/modules/cloud/amazon/ec2_elb_lb.py'
    var_0 = doc_cli.get_plugin_metadata(str_0)
    print(str(var_0))


# Generated at 2022-06-24 17:49:49.891623
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.cli.doc import DocCLI
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    import json
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import queue
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import find_plugin
    import ansible.utils.display
    from ansible.utils.display import Display

# Generated at 2022-06-24 17:49:59.547788
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:50:04.357680
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    doc = {}
    limit = 200
    opt_indent = "        "
    return_values = 0

    DocCLI.add_fields(text, doc, limit, opt_indent, return_values)  # expected no error



# Generated at 2022-06-24 17:50:07.636754
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    runner = CliRunner()
    result = runner.invoke(DocCLI, [])
    assert not result.exception
    assert result.exit_code == 0
    assert result.output == ''


# Generated at 2022-06-24 17:50:15.696484
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    ansible_module_generated_snippet = '''
"ec2_elb_lb"
        ec2_elb_lb:
            deregister_unused_instances: "no"
            instances: "{{ instance_ids }}"
            internal: "no"
            listener:
                - instance_port: "80"
                  instance_protocol: "HTTP"
                  lb_port: "80"
                  lb_protocol: "HTTP"
            name: "elb_test"
            region: "us-east-1"
            security_groups: sg-59432123
            subnets: subnet-12345678
            wait: "no"
            wait_timeout: "300"
        register: elb
    '''


# Generated at 2022-06-24 17:51:03.152037
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = [1, 2, 3]
    add_collection_plugins(plugin_list, 'cache', None)
    assert plugin_list == [1, 2, 3]

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:51:07.481073
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    plugin_type = 'action'
    ignore_deprecated = False
    _ = DocCLI.get_all_plugins_of_type(plugin_type, ignore_deprecated)



# Generated at 2022-06-24 17:51:17.583533
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role_0 = 'myrole'
    role_json_0 = jload(
    """{
        "dependencies": {},
        "description": "My role description",
        "license": "MIT",
        "entry_points": {
            "main": {
                "description": "",
                "options": {
                    "a_task": {
                        "description": "",
                        "required": false,
                        "type": "list",
                        "default": [
                            "rhel"
                        ]
                    }
                }
            }
        },
        "tags": [],
        "id": "d3e3f61a79ed",
        "path": "/myrole"
    }"""
    )
    doccli_0 = DocCLI()
    result = doccli_0.get_role_man

# Generated at 2022-06-24 17:51:29.286339
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    doc_cli_0 = DocCLI()
    text_0 = []
    limit_0 = 103
    opt_indent_0 = "        "
    doc_0 = {'description': 'description', 'options': {}}
    return_values_0 = False
    DocCLI.add_fields(text_0, doc_0, limit_0, opt_indent_0, return_values_0)
    var_0 = DocCLI.tty_ify(doc_0['description'])
    var_1 = textwrap.fill(var_0, limit_0, initial_indent=opt_indent_0, subsequent_indent=opt_indent_0)
    assert var_1 == ''
    var_2 = text_0[0]
    assert var_2 == ''


# Generated at 2022-06-24 17:51:39.790268
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.cli.doc import DocCLI

    assert not DocCLI(
        args=[
            'doc', '-t', 'my_module'
        ],
        display_args=[
            'doc', '-t', 'my_module'
        ],
        parser=opt_help.create_parser(DocCLI, None, None)
    ).run()

    assert not DocCLI(
        args=[
            'doc', '-t', 'my_module', '-l'
        ],
        display_args=[
            'doc', '-t', 'my_module', '-l'
        ],
        parser=opt_help.create_parser(DocCLI, None, None)
    ).run()

    # For tasks,

# Generated at 2022-06-24 17:51:42.397569
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doccli_0 = DocCLI()
    ansible_mock_0 = mock.MagicMock()
    role_mixin_0 = RoleMixin()
    var_0 = doccli_0.get_plugin_metadata(ansible_mock_0, role_mixin_0)
    assert var_0 is None


# Generated at 2022-06-24 17:51:54.193243
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text_0 = ''
    limit_0 = 0
    opt_indent_0 = ''
    return_values_0 = bool()
    initial_indent_0 = ''
    opt_0 = {}
    opt_1 = {}
    text_1 = ''
    limit_1 = 0
    opt_indent_1 = ''
    return_values_1 = bool()
    initial_indent_1 = ''

# Generated at 2022-06-24 17:52:01.342368
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doccli_0 = DocCLI()
    var_0 = doccli_0.get_role_man_text(['curl', 'yaml'], 'yaml')
    var_1 = doccli_0.get_role_man_text(['dummy_role'], 'yaml')
    var_2 = doccli_0.get_role_man_text(['dummy_role', 'notfound'], 'yaml')

# Generated at 2022-06-24 17:52:04.006694
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # TODO: Add test for method DocCLI.get_plugin_metadata
    pass


# Generated at 2022-06-24 17:52:14.871442
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-24 17:53:01.224653
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc_cli_0 = DocCLI()
    var_0 = cmd_0 = doc_cli_0.run()


# Generated at 2022-06-24 17:53:13.134966
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    data = ""
    limit = None
    opt_indent = "        "
    return_values = False
    DocCLI.add_fields(text, data, limit, opt_indent, return_values)
    assert text == []
    return_values = True
    DocCLI.add_fields(text, data, limit, opt_indent, return_values)
    assert text == []
    text = []
    data = ""
    limit = None
    opt_indent = "        "
    return_values = False
    DocCLI.add_fields(text, data, limit, opt_indent, return_values)
    assert text == []
    return_values = True
    DocCLI.add_fields(text, data, limit, opt_indent, return_values)
    assert text

# Generated at 2022-06-24 17:53:25.698190
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    ''' test list of args from json file '''
    module_path = 'lib/ansible/modules/system/setup.py'
    argspec = None  # argspec = [(arg, val_type), ...]

    # Create a jload object to load given json file
    f = open(module_path + '.json', 'rb')
    jload_obj = jload(f)
    # argspec = [(arg, val_type), ...]
    argspec = jload_obj['options']
    f.close()

    text = []
    limit = 80
    DocCLI.IGNORE = []
    opt_indent = "        "

    for opt in argspec:
        aliases = ''
        default = ''
        choices = ''
        if opt.get('required', False):
            aliases += "="

# Generated at 2022-06-24 17:53:36.444844
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role_data_0 = dict(
        description=['This is a sample role'],
        entry_points=dict(
            main=dict(
                description=['This is a sample role entry point'],
                options=dict(
                    name=dict(
                        description=['Name of the key in the dictionary of variables'],
                        required=True,
                        default=None,
                    ),
                    dict_variable=dict(
                        description=['The dictionary of variables to set'],
                        required=True,
                        default=None,
                    ),
                ),
            ),
        ),
        attributes=dict(
            name=dict(
                description=['Name of the key in the dictionary of variables'],
                required=True,
                default=None,
            ),
        ),
    )

# Generated at 2022-06-24 17:53:48.635106
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = []
    plugin_type = 'action'
    coll_filter = None
    b_colldirs = list_collection_dirs(coll_filter=coll_filter)
    for b_path in b_colldirs:
        path = to_text(b_path, errors='surrogate_or_strict')
        collname = _get_collection_name_from_path(b_path)
        ptype = C.COLLECTION_PTYPE_COMPAT.get(plugin_type, plugin_type)
        plugin_list.update(DocCLI.find_plugins(os.path.join(path, 'plugins', ptype), False, plugin_type, collection=collname))
