

# Generated at 2022-06-24 17:47:30.303687
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    d = DocCLI()
    role = 'role'
    role_json = {'path': '/path/to/roles', 'entry_points': {
        'test_entry_point': {'short_description': 'Test short description', 'description': 'Test description', 'options': {
            'test_option': {'default': False, 'description': 'Test option description', 'required': True, 'choices': ['test_choice']}
        }, 'attributes': {
            'test_attribute': {'description': 'Test attribute description'}
        }
        }
    }}

# Generated at 2022-06-24 17:47:34.359017
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    plugin_data = DocCLI().get_plugin_metadata(dict(type='foo'))
    assert plugin_data['plugin_type'] == 'foo'


# Generated at 2022-06-24 17:47:48.252327
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    test_data_0 = {
        'author': ['Brian Coca (@bcoca)'],
        'version_added': 'historical',
        'group': 'not_found'
    }
    test_data_1 = {
        'short_description': 'A test of DocCLI._get_plugin_metadata()'
    }
    test_data_2 = {
        'get_plugin_metadata': ['name', 'version_added']
    }
    test_data_3 = {
        'get_plugin_metadata': ['author'],
        'author': 'Test'
    }
    test_data_4 = {
        'get_plugin_metadata': ['author'],
        'author': {'not_a_string': ['Test']}
    }

    dc = DocCLI(None)

    test_case_

# Generated at 2022-06-24 17:47:53.202774
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = DocCLI()
    assert doc.get_plugin_metadata('copy', True)


# Generated at 2022-06-24 17:48:07.250825
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-24 17:48:14.790892
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    dc = DocCLI()
    msg = dc.display_plugin_list(['test_plugin', 'test_plugin_with_long_name'])
    assert 'test_plugin' in msg
    assert 'test_plugin_with_long_name' in msg


# Generated at 2022-06-24 17:48:23.592425
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc = DocCLI()

# Generated at 2022-06-24 17:48:27.902578
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    options = DocCLI()
    options.find_plugins()
    assert len(options.modules) == 205
    assert len(options.plugins) == 4


# Generated at 2022-06-24 17:48:36.341934
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    '''Unit test for method get_plugin_metadata of class DocCLI
    '''

    # Test get_plugin_metadata() with plugin type 'module'
    # Identify ansible core plugin dir
    test_tmp_dir = tempfile.mkdtemp()
    test_plugin_dir = os.path.join(test_tmp_dir, 'ansible')
    test_doc_dir = os.path.join(test_plugin_dir, 'doc')
    os.mkdir(test_plugin_dir)
    os.mkdir(test_doc_dir)
    plugin_type = 'module'
    test_module_doc_path = os.path.join(test_doc_dir, '%s_meta.json' % plugin_type)


# Generated at 2022-06-24 17:48:44.588037
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    t = DocCLI()

    # test_case_0:
    # return_values is False and doc is (list/dict)
    doc = [{'name': 'foo', 'description': 'this is foo', 'type': 'str',
            'required': False},
           {'name': 'bar', 'description': 'this is bar', 'type': 'dict',
            'required': True, 'aliases': ['baz', 'qux'],
            'options': {'bam': {'description': 'this is bam', 'type': 'int',
                                'required': False},
                        'baz': {'description': 'this is baz', 'type': 'str',
                                'required': True, 'version_added': '2.7'}}}]
    text = []
    limit = 20
    opt_ind

# Generated at 2022-06-24 17:49:34.702720
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-24 17:49:42.474785
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Initialize a DocCLI object
    doc_cli_0 = DocCLI()

    # Add some params to argument_spec
    argument_spec = dict()
    argument_spec['content'] = dict()
    argument_spec['content']['choices'] = ({}, 'some_from_list')
    argument_spec['content']['default'] = 'some_default'
    argument_spec['start_time'] = dict()
    argument_spec['start_time']['default'] = 1766725836
    argument_spec['start_time']['type'] = 'int'
    argument_spec['type'] = dict()
    argument_spec['type']['default'] = 'module'
    argument_spec['type']['choices'] = ['module', 'plugin', 'doc']

# Generated at 2022-06-24 17:49:51.363717
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    snippet_0 = dict(module='ec2', body='ec2', summary='some-summary', description='some-description')
    snippet_1 = dict(module='ec2', body='ec2', summary='some-summary', description='some-description')

    # Test case 0
    try:
        DocCLI.format_snippet(None)
    except TypeError:
        pass
    else:
        raise AssertionError()

    # Test case 1

# Generated at 2022-06-24 17:50:06.177109
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # no plugin
    try:
        test_case_0()
    except SystemExit:
        pass
    # invalid plugin type
    with pytest.raises(PluginNotFound):
        DocCLI.get_doc(['ansible-doc', '-t', 'invalid', 'win_package'], 'win_package')
    # invalid plugin
    with pytest.raises(PluginNotFound):
        DocCLI.get_doc(['ansible-doc', 'win_invalid'], 'win_invalid')
    # valid plugin
    doc, collection_name, plugin_name, plugin_type, plugin_use = DocCLI.get_doc(['ansible-doc', 'win_package'], 'win_package')
    assert DocCLI.get_man_text(doc, collection_name, plugin_type)

# Generated at 2022-06-24 17:50:11.111072
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():

    v1 = DocCLI.format_plugin_doc(test_case_0, type='test_case_0')
    assert v1 == "No documentation found for: test_case_0"

    v2 = DocCLI.format_plugin_doc(test_case_0, type='module')
    assert v2 == "No documentation found for: test_case_0"



# Generated at 2022-06-24 17:50:23.011190
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc = DocCLI()
    # Testing doc.run()

# Generated at 2022-06-24 17:50:30.207712
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    ''' unit tests for Ansible module DocCLI '''
    # Find the path to the directory containing lib/ansible:
    test_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    list_filt = 'module'
    list_top = test_dir + '/lib/ansible'
    list_path = test_dir + '/lib/ansible/modules'
    list_module = None
    list_type = list_filt
    list_strippath = False
    list_show_snippet = False
    list_show_examples = False
    list_show_all = True
    list_min = False
    list_dir = False
    list_collections = True
    list_collection = None
    list_pattern = None
    list

# Generated at 2022-06-24 17:50:33.272988
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    pass

if __name__ == '__main__':
    import sys
    import doctest
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-24 17:50:44.348586
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    assert DocCLI.format_snippet(None) == ''
    assert DocCLI.format_snippet([]) == ''
    assert DocCLI.format_snippet('') == ''
    assert DocCLI.format_snippet('fragment') == 'fragment'
    assert DocCLI.format_snippet({'from_file': 'file.name'}) == 'file.name'
    assert DocCLi.format_snippet({'from_file': 'file.name', '_ansible_lineage': ['name', 'parent']}) == '{file: file.name, parent: name}'
    assert DocCLI.format_snippet({'from_file': 'file.name', 'from_line': 1}) == 'file.name:1'

# Generated at 2022-06-24 17:50:47.501373
# Unit test for function jdump
def test_jdump():
    try:
        jdump({'test': 'testdata'})
        assert True
    except:
        assert False


# Generated at 2022-06-24 17:51:36.980239
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    bool_0 = True
    doc_c_l_i_0 = DocCLI(bool_0)
    bool_0 = False
    plugin_type_0 = 'module'
    result = doc_c_l_i_0.get_all_plugins_of_type(plugin_type_0, bool_0)
    assert result == []


# Generated at 2022-06-24 17:51:40.884940
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    check_class(DocCLI)

    # Test with default args
    doc_c_l_i_0 = DocCLI()
    # Test return type(s) and value(s)
    check_return_set_type(list, doc_c_l_i_0, doc_c_l_i_0.find_plugins())



# Generated at 2022-06-24 17:51:44.744942
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    plugins = get_all_plugins_of_type('action')
    assert plugins

    plugins = get_all_plugins_of_type('connection')
    assert plugins

    plugins = get_all_plugins_of_type('cliconf')
    assert plugins

    plugins = get_all_plugins_of_type('netconf')
    assert plugins


# Generated at 2022-06-24 17:51:48.853887
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    bool_0 = True
    dict_0 = dict()
    dict_0['__ansible_module__'] = 'yaml'
    dict_0 = DocCLI(bool_0).get_man_text(dict_0)


# Generated at 2022-06-24 17:51:54.737913
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    bool_0 = True
    doc_c_l_i_0 = DocCLI(bool_0)
    str_0 = 'plainexamples'

    try:
        doc_c_l_i_0.format_snippet(str_0)

    except TypeError:
        pass

    # TODO: Add programmatic check here
    return 'Passed'


# Generated at 2022-06-24 17:51:56.095172
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    test_case_0()


# Generated at 2022-06-24 17:52:01.795027
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    import sys

    # Set up object
    bool_0 = True
    doc_c_l_i_0 = DocCLI(bool_0)

    # Function to be tested
    str_0 = "ansible-doc -t {0} --list".format(context.CLIARGS['type'])
    str_1 = "usage: {0} [-h] [-M MODULE_PATH] [-l] [-s] [-v] [-V] [-T {1}] [module]\n".format(os.path.basename(sys.argv[0]), context.CLIARGS['type']) -1
    str_2 = "  -h, --help            show this help message and exit\n" -1
    str_3 = "  -M MODULE_PATH, --module-path MODULE_PATH\n" -1


# Generated at 2022-06-24 17:52:08.964709
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    bool_0 = True
    doc_c_l_i_0 = DocCLI(bool_0)

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()


# Generated at 2022-06-24 17:52:10.276512
# Unit test for function jdump
def test_jdump():
    assert True


# Generated at 2022-06-24 17:52:21.264341
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    bool_0 = True
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['filename'] = '/home/james/ansible-source/lib/ansible/plugins/action/debug.py'
    dict_2['description'] = ['Print statements during execution']
    dict_2['version_added'] = 'historic'
    dict_2['options'] = dict()
    dict_2['options']['msg'] = dict()
    dict_2['options']['msg']['default'] = 'Hello world!'
    dict_2['options']['var'] = dict()
    dict_2['options']['var']['default'] = 'Hello world!'
    str_0 = '%s'
    str_1 = 'filename'
    dict_2

# Generated at 2022-06-24 17:53:05.347352
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Access an Ansible module with a name and a path
    # This test case is not applicable to shell so we skip it
    # Test case will not be executed, and will be marked as 'skipped' in report
    if C.DEFAULT_MODULE_PATH is None:
        pytest.skip("Missing DEFAULT_MODULE_PATH")

    # Access an Ansible plugin with a name and a path
    # This test case is not applicable to shell so we skip it
    # Test case will not be executed, and will be marked as 'skipped' in report
    if C.DEFAULT_ACTION_PLUGIN_PATH is None:
        pytest.skip("Missing DEFAULT_ACTION_PLUGIN_PATH")

    # Access an Ansible plugin with a name and a path
    # This test case is not applicable to shell so we skip it
    #

# Generated at 2022-06-24 17:53:10.720285
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list1 = {}
    plugin_type2 = "some_plugin_type"
    coll_filter3 = None

    ret4 = add_collection_plugins(plugin_list1, plugin_type2, coll_filter3)
    assert ret4 is None



# Generated at 2022-06-24 17:53:23.270385
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    import ansible.constants as C
    doc_c_l_i_0 = DocCLI(C.DEFAULT_MODULE_PATH)
    ptrn_0 = "*"
    path_0 = C.DEFAULT_MODULE_PATH
    ext_0 = '.py'
    bool_0 = doc_c_l_i_0.find_plugins(ptrn_0, path_0, ext_0)
    # Test for false values for for boolean variables
    assert bool_0 is not False
    # Test for value equality
    assert ptrn_0 == "*"
    # Test for value equality
    assert path_0 == C.DEFAULT_MODULE_PATH
    # Test for value equality
    assert ext_0 == '.py'


# Generated at 2022-06-24 17:53:26.442984
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'module'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    # Assertion
    assert (plugin_list['module_defaults'])


# Generated at 2022-06-24 17:53:29.527559
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    bool_0 = True
    doc_c_l_i_0 = DocCLI(bool_0)
    # you cannot test this method natively without calling the other methods of
    # the class and the plugin class it depends on


# Generated at 2022-06-24 17:53:41.741716
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    bool_0 = True
    dict_0 = dict()
    dict_0['positionals'] = dict()
    dict_0['muted'] = dict()
    dict_0['attrs'] = dict()
    dict_0['attrs']['SHORT'] = '-s'
    dict_0['attrs']['SEP'] = '='
    dict_0['attrs']['USAGE'] = 'The name to report'
    dict_0['attrs']['VERSION'] = '1.0'
    dict_0['attrs']['LONG'] = '--name'
    dict_0['attrs']['OPTIONAL'] = True
    dict_0['attrs']['REQUIRED'] = False
    dict_0['attrs']['DEFAULT'] = 'default name'


# Generated at 2022-06-24 17:53:51.634744
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # check that find_plugins is not producing any error
    plugin_type = 'action'
    (list_of_list_0, list_of_list_1) = DocCLI.find_plugins(plugin_type)
    assert_match(list_of_list_0, list_of_list_1)
