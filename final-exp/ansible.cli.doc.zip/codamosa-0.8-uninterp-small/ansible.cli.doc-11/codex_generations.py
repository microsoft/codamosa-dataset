

# Generated at 2022-06-24 17:45:47.680549
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():

    str_0 = "86R2=_qT'z\n5EPsKY\x0c"
    doc_c_l_i_0 = DocCLI(str_0)

    str_1 = "ufn\x1b9p\n~q\x13\x7f_e\x14"
    dict_0 = {str_1: True}
    str_2 = 't\x17)*%\x11^'
    dict_1 = {str_2: True}
    dict_2 = {str_2: dict_1}
    dict_3 = {str_1: dict_0, str_2: dict_2}
    str_3 = '*\x0b-\x1a'
    str_4 = 'n#X'

# Generated at 2022-06-24 17:45:56.985711
# Unit test for function add_collection_plugins

# Generated at 2022-06-24 17:46:08.328764
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    print("Testing DocCLI::format_plugin_doc()")
    str_1 = "86R2=_qT'z\n5EPsKY\x0c"
    doc_c_l_i_1 = DocCLI(str_1)
    str_2 = ""
    str_3 = ""
    str_4 = "I(#+'mtmXs"
    str_5 = ""
    str_6 = "as_doc"
    test_case_1 = doc_c_l_i_1.format_plugin_doc(str_2, str_3, str_4, str_5, str_6)
    print("    Test case returned: %s" % test_case_1)
    if test_case_1:
        print("    Test case passed")
    else:
        print

# Generated at 2022-06-24 17:46:15.783072
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    str_0 = "\x7f\x80\xa0\x9f\x14{\x8d\xe2Z\x17\x1a\x8f\xaa"
    doc_c_l_i_0 = DocCLI(str_0)
    str_1 = "{'removed_in': '2.9', 'why': u'BECOME-PROMPT.', 'alternative': u'Use become_ask_pass instead.'}"
    doc_c_l_i_0.get_man_text(str_1)


# Generated at 2022-06-24 17:46:25.256358
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    str_0 = "86R2=_qT'z\n5EPsKY\x0c"
    DocCLI_0 = DocCLI(str_0)
    str_1 = "doc"
    str_2 = "plugin_name"
    str_3 = "module"
    str_4 = "action"
    result = DocCLI_0.format_snippet(str_1, str_2, str_3, str_4)
    assert result is None


# Generated at 2022-06-24 17:46:29.499694
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    str_0 = "86R2=_qT'z\n5EPsKY\x0c"
    doc_c_l_i_0 = DocCLI(str_0)
    str_1 = "86R2=_qT'z\n5EPsKY\x0c"
    str_2 = ""
    str_3 = ""
    result_str = doc_c_l_i_0.get_man_text(str_1, str_2, str_3)
    assert_true(result_str == "")


# Generated at 2022-06-24 17:46:42.116555
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    opt_indent = "        "
    return_values = False
    limit = 70
    doc_c_l_i_0 = DocCLI("")
    options = {"required": True, "type": "bool", "default": True, "aliases": [], "description": "enable or disable"}
    doc_c_l_i_0.add_fields(text, options, limit, opt_indent, return_values, opt_indent)
    print("text: ", text)


# Generated at 2022-06-24 17:46:53.563672
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    str_0 = "86R2=_qT'z\n5EPsKY\x0c"
    doc_c_l_i_0 = DocCLI(str_0)
    str_1 = "    \n\nw)E"
    dict_1 = {"description": str_1}
    int_0 = 0
    str_2 = ""
    str_3 = ""
    result_str = doc_c_l_i_0.get_man_text(dict_1, str_2, str_3)
    str_4 = "> CLOUDINIT    (    \n\nw)E\n"
    str_5 = "ADDED IN: \n"
    str_6 = "OPTIONS (= is mandatory):\n"
    int_1 = 71
    int_2 = 0

# Generated at 2022-06-24 17:47:01.767344
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # test case for empty plugin and empty collection
    # expected result
    expected_0 = ''
    # actual result
    actual_0 = DocCLI.format_plugin_doc({}, '')
    # show result
    print("\nTest for empty plugin and empty collection:")
    print("Expected: %s" % expected_0)
    print("Actual: %s" % actual_0)
    assert actual_0 == expected_0

    # test case for non-empty plugin and empty collection
    # expected result

# Generated at 2022-06-24 17:47:05.624019
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    str_0 = "86R2=_qT'z\n5EPsKY\x0c"
    doc_c_l_i_0 = DocCLI(str_0)
    doc_c_l_i_0.run()


# Generated at 2022-06-24 17:47:50.956746
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    str_0 = "86R2=_qT'z\n5EPsKY\x0c"
    doc_c_l_i_0 = DocCLI(str_0)
    list_0 = []
    list_0.append(('module', '$/<'))
    list_0.append(('lookup', 'CEb_78'))
    list_0.append(('filter', 'T=@<'))
    list_0.append(('test', 'xQn|40'))
    list_0.append(('action', 'vH.N'))
    list_0.append(('vars', '5}f>'))
    list_1 = []
    list_1.append('$/<')
    list_1.append('CEb_78')
    list_

# Generated at 2022-06-24 17:47:55.341369
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc_c_l_i_0 = DocCLI('yaml')
    str_0 = "g,~%-h*$_iW\n".upper()
    str_1 = "lL8i^(T\x0f#\n".upper()
    dict_2 = {str_0: str_1}
    dict_3 = {'name': 'ansible.builtin.debug', str_0: str_1}
    doc_c_l_i_0.run(dict_2, dict_3)


# Generated at 2022-06-24 17:48:03.693832
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    str_0 = "1W8eB;x\x17\x0cSbPk\x13`"
    doc_c_l_i_0 = DocCLI(str_0)
    str_1 = "(D[2$B\x0b\x05JZ\x00XG"
    doc_c_l_i_1 = DocCLI(str_1)
    str_2 = "Ay\x1eN\x1b\x1e\x16"
    doc_c_l_i_2 = DocCLI(str_2)
    str_3 = "\\$[\\6\x0c\\B\x0c"
    doc_c_l_i_3 = DocCLI(str_3)

# Generated at 2022-06-24 17:48:18.719094
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    str_0 = "D\t9\x0fYl"
    plugin_name_0 = "hostname"
    cache_0 = C.DataCache()
    try:
        cache_0._get_plugin_docstring_fragment(plugin_name_0)
    except:
        # Catch the exception
        pass
    doc_c_l_i_0 = DocCLI(str_0)
    doc_c_l_i_0._format_plugin_doc(plugin_name_0, cache_0, True)


# Generated at 2022-06-24 17:48:31.783962
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():

    str_0 = "86R2=_qT'z\n5EPsKY\x0c"
    str_1 = "%j'5n\x0c\x11\x03\x12\x0b\x16\x0b\x0c\x04\x17\x0b\x18\x00\x19\x0c\x1a\x11\x1b\x0b\x02\x1c\x1d\x1e\x1f \x0c!\"#\x04$%&'()*+,\x0c-./010234"

# Generated at 2022-06-24 17:48:33.260103
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    array_0 = list()
    add_collection_plugins(array_0, ['GNF'])


# Generated at 2022-06-24 17:48:39.505952
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
  # Initialize test
  # Set up test data
  str_0 = "86R2=_qT'z\n5EPsKY\x0c"
  list_0 = list()
  str_1 = ''
  int_0 = 75
  str_2 = '    '
  # Invoke method
  test_case_0()
  # Verify and assert results



# Generated at 2022-06-24 17:48:42.141767
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    # Initialization
    doc_c_l_i_0 = DocCLI('test0')
    plugin_list = dict
    plugin_type = 'action'

    # Calling method
    add_collection_plugins(plugin_list, plugin_type)



# Generated at 2022-06-24 17:48:52.678790
# Unit test for method get_plugin_metadata of class DocCLI

# Generated at 2022-06-24 17:49:08.852965
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    str_0 = "zO:D\n"
    doc_c_l_i_0 = DocCLI(str_0)
    tuple_0 = ('yj\x0e', 'lJ', 'e', 'H')
    str_1 = "%s://%s:%s@%s:%d/%s" % (tuple_0[3], tuple_0[0], tuple_0[1], tuple_0[2], random.randint(1, 65535), random.choice(string.ascii_letters))
    str_2 = doc_c_l_i_0.namespace_from_plugin_filepath(str_1)

# Generated at 2022-06-24 17:49:58.000748
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    str_0 = "86R2=_qT'z\n5EPsKY\x0c"
    doc_c_l_i_0 = DocCLI(str_0)
    str_1 = "n|~{h\n_gE:H+"
    list_0 = [str_1]
    int_0 = 5
    int_1 = 2
    int_2 = 9
    str_2 = "}*g8t^\n$X+&{?J\r"
    str_3 = "N\x0c4\x16\x0c3\n"
    # Run the test
    doc_c_l_i_0.add_fields(list_0, str_1, int_0, str_2, int_1, int_2, str_3)


# Generated at 2022-06-24 17:50:08.430954
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    str_0 = "86R2=_qT'z\n5EPsKY\x0c"
    doc_c_l_i_0 = DocCLI(str_0)
    str_1 = "]'f-\x7flY\nE8WZ1a"
    dict_0 = {'a': 1, 'b': 2, 'c': 3}
    list_0 = [int, '10', '32', '68', '75', '45']
    value_0 = doc_c_l_i_0.add_fields(list_0, dict_0, 10, str_1)
    assert value_0 == (), "add_fields returned unexpected value: %s" % value_0


# Generated at 2022-06-24 17:50:11.221643
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    test_case_0()


# Generated at 2022-06-24 17:50:14.002965
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # TODO: input parameters generation
    # TODO: check for exception and error cases

    # Run the test
    test_case_0()


# Generated at 2022-06-24 17:50:20.786292
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {'plugins': '', 'collections': '', 'modules': ''}
    plugin_type = 'plugins'
    coll_filter = {'collections': '', 'modules': ''}
    assert plugin_list.update(DocCLI.find_plugins(os.path.join(path, 'plugins', ptype), False, plugin_type, collection=collname)) == add_collection_plugins(plugin_list, plugin_type, coll_filter)


# Generated at 2022-06-24 17:50:25.279717
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc_c_l_i_0 = DocCLI("n")
    doc_c_l_i_0.method_run_0()

if __name__ == '__main__':
    test_case_0()
    test_DocCLI_run()

# Generated at 2022-06-24 17:50:26.786433
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    pass


# Generated at 2022-06-24 17:50:35.428627
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    str_0 = "S6o/"
    module_list_0 = build_module_list(str_0)
    doc_c_l_i_0 = DocCLI(str_0)
    str_0 = "    "
    str_1 = "    "
    str_2 = "    "
    str_3 = "    "
    str_4 = "    "
    doc_c_l_i_0.display_plugin_list(module_list_0, str_0, str_1, str_2, str_3, str_4)


# Generated at 2022-06-24 17:50:38.663536
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    """ Tests DocCLI.display_plugin_list on valid input """
    assert True


# Generated at 2022-06-24 17:50:49.202016
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    str_0 = "MZCFA^a0p|<\t"
    str_1 = "yOY}t"
    dict_0 = {str_0: str_1}
    doc_c_l_i_0 = DocCLI(str_0)
    doc_c_l_i_0.get_role_man_text(str_1, dict_0)
    str_2 = "!@/"
    dict_1 = {str_2: dict_0}
    dict_0[str_1] = dict_1
    doc_c_l_i_0.get_role_man_text(str_0, dict_1)
    str_3 = "5KZ^,\t"
    dict_0[str_1] = str_1

# Generated at 2022-06-24 17:51:54.058374
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    for i in range(1):
        str_0 = ""
        doc_c_l_i_0 = DocCLI(str_0)
        add_collection_plugins(doc_c_l_i_0)


# Generated at 2022-06-24 17:52:05.090050
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    str_0 = "86R2=_qT'z\n5EPsKY\x0c"
    doc_c_l_i_0 = DocCLI(str_0)
    str_1 = ">Tz9\r6'\"\x0b\x0f\x1e"
    list_1 = doc_c_l_i_0.find_plugins(str_1)
    assert len(list_1) == 0
    str_2 = "z_\x10\x17\x11\x15\x17\x10C"
    list_2 = doc_c_l_i_0.find_plugins(str_2)
    assert len(list_2) == 0

# Generated at 2022-06-24 17:52:18.070421
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    str_0 = ":\x0bD\aUl\x0f\x0b\x1f\x0e\x00\x04\x1e\x18\x0cQh\x0b5"
    doc_c_l_i_0 = DocCLI(str_0)
    dict_0 = dict()
    dict_0['description'] = "h\x1d\x01q\a\x15\x06\x03\x0c\x0b-\x10\x1d}\x0c"
    dict_0['keyword2'] = True

# Generated at 2022-06-24 17:52:28.678588
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    doc_c_l_i_0 = DocCLI(str_0)
    str_0 = "86R2=_qT'z\n5EPsKY\x0c"
    return_value_0 = doc_c_l_i_0.format_snippet(str_0)
    assert return_value_0 == ("", False, 0)

    return_value_1 = doc_c_l_i_0.format_snippet("")
    assert return_value_1 == ("", True, 0)

    return_value_2 = doc_c_l_i_0.format_snippet("a")
    assert return_value_2 == ("a", True, 0)

    # This example will fail to run in windows because the CL-editor is responsible for the formatting.
    # Without a CL

# Generated at 2022-06-24 17:52:40.204021
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    str_0 = "86R2=_qT'z\n5EPsKY\x0c"
    doc_c_l_i_1 = DocCLI(str_0)

# Generated at 2022-06-24 17:52:46.325063
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    str_0 = ''
    str_1 = '\x00U6\x7f\x1dO'
    list_0 = [str_1]
    list_1 = ['\x00U6\x7f\x1dO']
    num_0 = 7
    str_2 = '\x00U6\x7f\x1dO'
    list_2 = [str_2]
    num_1 = 7
    str_3 = 'H\r\x1b\x1d\n\x00O\x02\x0f\x1d\x1b'
    list_3 = [str_3]
    doc_c_l_i_0 = DocCLI(str_0)

# Generated at 2022-06-24 17:52:54.750788
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    str_0 = "tC5\tE"
    doc_c_l_i_0 = DocCLI(str_0)
    str_1 = "~$\x0c(m\tX\x1dm\x1d?b\x1e\n\n(m\tX\x1dm\x1d?b\x1e\x00\x00"
    dict_0 = {}
    dict_1 = doc_c_l_i_0.get_plugin_metadata(str_1, dict_0)
    dict_1 = doc_c_l_i_0.get_plugin_metadata(str_1, dict_0)
    dict_1 = doc_c_l_i_0.get_plugin_metadata(str_1, dict_0)
    dict_1 = doc

# Generated at 2022-06-24 17:53:05.386021
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    param_list = []
    str_0 = "pGTw,^d_\x12\x06\x15"
    str_1 = "H0\r"
    dict_0 = {'description': ['Test module for showing how to write _load_plugins', 'module docs.']}
    dict_1 = {'description': ['Test module for showing how to write _load_plugins', 'module docs.']}
    doc_c_l_i_0 = DocCLI(str_0)
    param_list.append(dict_0)
    param_list.append(str_1)
    param_list.append(dict_1)

# Generated at 2022-06-24 17:53:15.312843
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Case 0
    str_0 = "86R2=_qT'z\n5EPsKY\x0c"

# Generated at 2022-06-24 17:53:26.849316
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    str_0 = "86R2=_qT'z\n5EPsKY\x0c"
    # str_0 should be a string
    doc_c_l_i_0 = DocCLI(str_0)
    str_0 = "/8:nWU`2sTZT9PZo[-p\x1b\x1e"
    # str_0 should be a string
    doc_c_l_i_0.run(str_0)

if __name__ == '__main__':
    import sys, os, traceback, types
    from optparse import OptionParser

    try:
        import coverage
        cov = coverage.coverage(data_suffix=True)
        cov.start()
    except:
        pass

    test_case_0()
    test_Doc