

# Generated at 2022-06-24 17:46:24.656733
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    bool_0 = False
    doc_c_l_i_0 = DocCLI(bool_0)
    bool_1 = bool_0
    str_0 = 'filter'
    list_0 = []
    return doc_c_l_i_0.get_all_plugins_of_type(bool_1, str_0, list_0)


# Generated at 2022-06-24 17:46:30.318964
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    bool_0 = False
    doc_c_l_i_0 = DocCLI(bool_0)
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_8 = ''
    str_9 = ''
    str_10 = ''
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}

# Generated at 2022-06-24 17:46:38.513667
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role = ""
    role_json = {}
    bool_1 = False
    doc_c_l_i_1 = DocCLI(bool_1)
    doc_c_l_i_1.get_role_man_text(role, role_json)


# Generated at 2022-06-24 17:46:43.580588
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
  doc_c_l_i_0 = DocCLI(False)
  # No exception thrown
  try:
    doc_c_l_i_0.format_plugin_doc("", "", "")
  except:
    DocTestSuite.fail("DocCLI.format_plugin_doc()")



# Generated at 2022-06-24 17:46:47.016543
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    plugin = MockPlugin()
    doc_c_l_i_0 = DocCLI(plugin)
    doc_c_l_i_0.print_paths()


# Generated at 2022-06-24 17:46:49.049739
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # TODO: Make test cases
    #assert False, "No test cases defined."
    test_case_0()


# Generated at 2022-06-24 17:46:53.800130
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():

    # Calling get_man_text method of the class DocCLI
    test_case_0()

if __name__ == '__main__':
    test_DocCLI_get_man_text()



# Generated at 2022-06-24 17:47:01.839788
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    bool_0 = False
    doc_c_l_i_0 = DocCLI(bool_0)
    str_0 = "test_postgresql_role"

# Generated at 2022-06-24 17:47:06.619607
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    bool_0 = True
    doc_c_l_i_0 = DocCLI(bool_0)
    dict_0 = dict()
    dict_0['description'] = list()
    dict_0['description'].append('The Ansible network_cli connection plugin')
    dict_0['description'].append('allows ansible to speak to network devices')
    dict_0['description'].append('using the CLI over SSH or a text console.')
    dict_0['description'].append('This plugin will typically be used by those')
    dict_0['description'].append('who have console access to their network devices')
    dict_0['description'].append('and are familiar with CLI operations.')
    dict_0['description'].append('Other plugins may be more appropriate for network')

# Generated at 2022-06-24 17:47:15.405822
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    doc_c_l_i_0 = DocCLI()
    plugin_list = {}
    plugin_type = "action"
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)



# Generated at 2022-06-24 17:47:56.772301
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    assert True


# Generated at 2022-06-24 17:47:59.836324
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    pass


# Generated at 2022-06-24 17:48:14.839180
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Tests the functionality of the method get_man_text of the class DocCLI

    # Create an object of the class DocCLI
    my_doc_c_l_i = DocCLI(False)
    assert_is_instance(my_doc_c_l_i, DocCLI)

    # Testing by providing a valid set of parameters
    my_test_doc = {
        'name': 'service',
        'description': 'This is a test module for DocCLI',
        'options': {
            'name': {
                'description': 'The name of the service.',
                'required': False,
                'aliases': ['service']
            }
        }
    }

# Generated at 2022-06-24 17:48:18.777967
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    bool_0 = False
    doc_c_l_i_0 = DocCLI(bool_0)
    doc_0 = dict()
    str_0 = doc_c_l_i_0.get_man_text(doc_0)


# Generated at 2022-06-24 17:48:27.467844
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    bool_0 = False
    doc_c_l_i_0 = DocCLI(bool_0)
    display_args_0 = {}
    bool_0 = doc_c_l_i_0.run(display_args_0, {})


if __name__ == "__main__":
    test_prog_name = sys.argv[0]
    test_case_0()
    test_DocCLI_run()

# Generated at 2022-06-24 17:48:36.140461
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # setup
    bool_0 = False
    doc_c_l_i_0 = DocCLI(bool_0)

    if "pylint" in sys.modules:
        # pylint: disable=protected-access
        assert doc_c_l_i_0._get_field_data("name", "", "") is None
        doc_c_l_i_0._field_data = {"name": "test_var"}
        assert doc_c_l_i_0._get_field_data("name", "", "") == "test_var"
        # pylint: enable=protected-access
    else:
        assert doc_c_l_i_0._DocCLI__get_field_data("name", "", "") is None
        doc_c_l_i_0._DocCLI

# Generated at 2022-06-24 17:48:44.477148
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():

    import os, sys
    from ansible.utils.display import Display, DisplayOptions
    # Init a display for tests.
    display = Display(verbosity=4, options=DisplayOptions())

    # Init a doc_c_l_i object for tests.
    doc_c_l_i = DocCLI(False)

    # Test the different scenarios.

# Generated at 2022-06-24 17:48:53.067464
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    manual_link_0 = 'https://docs.ansible.com/ansible/latest/modules/ansible_managed_module.html'
    int_0 = display.columns
    str_0 = context.CLIARGS['type']
    doc_c_l_i_0 = DocCLI(False)
    str_1 = (str_0 + '_module.html')
    str_2 = context.CLIARGS['type']
    str_3 = (str_2 + '_module.html')
    str_4 = context.CLIARGS['type']
    str_5 = (str_4 + '_module.html')
    # Call method get_man_text of class DocCLI with the following parameters: {'seealso': [{'description': 'The official documentation on the ansible_managed module

# Generated at 2022-06-24 17:49:02.319545
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # There is a error in function named format_snippet of class DocCLI.
    # the method can merge two lines of the path in first line,
    # if there are new line in the path.
    # The path is not same as the path in ansible.
    bool_0 = False
    str_0 = '{{inventory_dir}}/any_module.py'
    str_1 = '{{inventory_dir}}/\nany_module.py'
    doc_c_l_i_0 = DocCLI(bool_0)
    str_2 = doc_c_l_i_0.format_snippet(str_0)
    str_3 = doc_c_l_i_0.format_snippet(str_1)
    str_4 = str_2 == str_3

# Generated at 2022-06-24 17:49:04.429638
# Unit test for method get_plugin_metadata of class DocCLI

# Generated at 2022-06-24 17:49:58.650429
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-24 17:50:09.894479
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    argv_tuple = (os.getcwd(), 'ansible-doc', 'ACME.windows',)
    try:
        if sys.version_info >= (3, 0):
            from io import StringIO
        else:
            from StringIO import StringIO

        stdout_backup = sys.stdout
        doc_c_l_i_run_stdout = StringIO()
        stdout = sys.stdout = doc_c_l_i_run_stdout
        doc_c_l_i_run_0 = DocCLI(argv=argv_tuple)
        doc_c_l_i_run_0.run()
        sys.stdout = stdout_backup
    finally:
        sys.stdout = stdout_backup


# Generated at 2022-06-24 17:50:16.490693
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    doc_c_l_i_0 = DocCLI()
    opt_0 = {}
    limit_0 = 0
    opt_indent_0 = "4 "
    return_values_0 = False
    opt_indent_1 = "    "
    doc_c_l_i_0.add_fields(text_0, opt_0, limit_0, opt_indent_0, return_values_0, opt_indent_1)


# Generated at 2022-06-24 17:50:27.233695
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with empty plugins
    plugins = {}
    doc_c_l_i_0 = DocCLI(True)
    text = doc_c_l_i_0.display_plugin_list(plugins)
    print(text)

    # Test with a non-empty plugins
    plugins = {'mod': {}, 'doc': {}}
    doc_c_l_i_1 = DocCLI(False)
    text = doc_c_l_i_1.display_plugin_list(plugins)
    print(text)

    # Test with a non-empty plugins
    plugins = {'mod': {}, 'doc': {}}
    doc_c_l_i_2 = DocCLI(True)
    text = doc_c_l_i_2.display_plugin_list(plugins)
    print(text)

# Generated at 2022-06-24 17:50:37.558124
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    bool_0 = True  # Default value
    doc_c_l_i_0 = DocCLI(bool_0)
    str_0 = 'tests/unit/doc_fragments/cli/declare_command.yml'
    str_1 = 'DOCUMENTATION:'
    str_2 = 'options:'
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_1['dest'] = 'test'
    dict_1['env'] = [dict_2]
    dict_2['name'] = 'ANSIBLE_TEST_VALUE'
    dict_1['meta'] = 'single value'
    dict_1['config'] = 'test_value'
    dict_1['name'] = 'value'
    dict_0['value'] = dict_1
   

# Generated at 2022-06-24 17:50:41.094496
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    bool_0 = False
    doc_c_l_i_0 = DocCLI(bool_0)
    # Template: {% sort items %}
    # item_0 is the template placeholder
    list_0 = ['c', 'b', 'a']
    list_1 = list_0
    list_1.sort()
    assert list_1 == ['a', 'b', 'c']


# Generated at 2022-06-24 17:50:44.624767
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list_0 = dict()
    plugin_list_0.clear()
    plugin_list_1 = dict()
    plugin_list_1.clear()
    assert add_collection_plugins(plugin_list_0, 'connection') == add_collection_plugins(plugin_list_1, 'connection')


# Generated at 2022-06-24 17:50:58.600530
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    print('Testing get_plugin_metadata()')
    bool_0 = False
    doc_c_l_i_0 = DocCLI(bool_0)
    basestring_0 = 'action'
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_1['filename'] = 'plugins/modules/complex_module.py'
    dict_1['docuri'] = 'module-complex_module'
    dict_1['module'] = 'complex_module'
    dict_2['docuri'] = 'module-complex_module'
    dict_2['module'] = 'complex_module'
    dict_0['complex_module'] = dict_2
    dict_1['docuri'] = 'module-complex_module'

# Generated at 2022-06-24 17:51:03.921108
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    bool_0 = False
    doc_c_l_i_0 = DocCLI(bool_0)
    # Call method find_plugins of class DocCLI
    doc_c_l_i_0.find_plugins()

if __name__ == '__main__':
    test_case_0()
    test_DocCLI_find_plugins()

# Generated at 2022-06-24 17:51:09.244068
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    bool_0 = False
    doc_c_l_i_0 = DocCLI(bool_0)
    bool_0 = hasattr(doc_c_l_i_0, 'get_man_text')
    assert( bool_0 == True )



# Generated at 2022-06-24 17:52:11.240336
# Unit test for method get_all_plugins_of_type of class DocCLI

# Generated at 2022-06-24 17:52:21.782462
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Boolean: False
    bool_0 = False
    doc_c_l_i_0 = DocCLI(bool_0)
    str_0 = '''action_plugins/copy.py'''
    plugin_name_0 = 'action_plugins'
    plugin_type_0 = 'action'
    str_1 = '''action plugins'''
    str_2 = '''return the plugin metadata for a given plugin'''
    common_globals_1 = copy.copy(common_globals)
    common_globals_1['__name__'] = '__main__'
    common_globals_1['__file__'] = 'action_plugins/copy.py'
    common_globals_1['__package__'] = 'ansible'

# Generated at 2022-06-24 17:52:31.314905
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc_c_l_i_0 = DocCLI()
    plugin_type_0 = "json"
    plugin_data_0 = {"name": "test", "short_description": "test", "version_added": "test", "version_added_collection": "test", "author": "test", "options": {"test": {"description": "test", "required": "test", "_terms": "test", "_aliases": "test"}}}
    bool_0 = False
    man_text_0 = doc_c_l_i_0.format_plugin_doc(plugin_type_0, plugin_data_0, bool_0)
    assert man_text_0 is not None


# Generated at 2022-06-24 17:52:36.387368
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc_c_l_i_0 = DocCLI(False)
    doc_c_l_i_0.get_man_text("CN", "role_json", "plugin_type")


# Generated at 2022-06-24 17:52:45.920820
# Unit test for method run of class DocCLI

# Generated at 2022-06-24 17:52:50.268927
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc_c_l_i_run_0 = DocCLI(None)
    with pytest.raises(AnsibleOptionsError) as excinfo:
        doc_c_l_i_run_0.run()
    assert 'No subcommand passed to ansible-doc' in to_native(excinfo.value)


# Generated at 2022-06-24 17:53:03.133340
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    bool_0 = False
    bool_1 = True
    dict_0 = dict()
    dict_0['filename'] = 'filename'
    dict_0['version_added'] = 'version_added'
    dict_0['short_description'] = 'short_description'
    dict_1 = dict()
    dict_1['desc'] = 'desc'
    dict_1['aliases'] = 'aliases'
    dict_1['version_added'] = 'version_added'
    dict_1['default'] = 'default'
    dict_2 = dict()
    dict_2['filename'] = 'filename'
    dict_2['version_added'] = 'version_added'
    dict_2['short_description'] = 'short_description'
    dict_2['options'] = dict_1
    dict_3 = dict()

# Generated at 2022-06-24 17:53:04.783577
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    test_case_0()


# Generated at 2022-06-24 17:53:15.088039
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:53:23.845818
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    ansible_vars = get_ansible_version()

    if ansible_vars is not None:
        expected_result = ":%s" % ansible_vars['revision']

        if DocCLI.format_snippet("%(revision)s") != expected_result:
            print("ERROR in test_DocCLI_format_snippet()")
            exit(-1)
        else:
            print("test_DocCLI_format_snippet() passed")

