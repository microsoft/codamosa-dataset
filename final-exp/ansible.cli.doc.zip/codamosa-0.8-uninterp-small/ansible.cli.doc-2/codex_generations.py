

# Generated at 2022-06-24 17:45:38.574227
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    print("test_DocCLI_format_snippet START")

    doc_cli_0 = DocCLI()

    snippet_0 = '''    - example of
        multiline text'''
    snippet_1 = '''    - example of
        multiline text
      other: text'''
    snippet_2 = '''    - example of
        multiline text
    other:
        list'''
    snippet_3 = '''    - example of
      multiline text
    other:
      list'''
    snippet_4 = '''    - example of
      multiline text
    other:
        list'''
    snippet_5 = '''    - example of
        multiline text
      other:
        list'''

    print("\t%s" % snippet_0)

# Generated at 2022-06-24 17:45:44.919284
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc_cli_obj = DocCLI()
    doc_cli_obj.get_man_text({"name":"test_DocCLI_get_man_text", "version":"0.0.1", "filename":"test_DocCLI_get_man_text.py", "description":"Test case for DocCLI_get_man_text", "short_description":"Test case for DocCLI_get_man_text"})

if __name__ == "__main__":
    test_case_0()
    test_DocCLI_get_man_text()

# Generated at 2022-06-24 17:45:57.321936
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc_cli = DocCLI()

# Generated at 2022-06-24 17:46:01.753994
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc_cli = DocCLI()
    plugins = []
    roles = None
    collection_name = "skippy"
    plugin_type = "module"
    doc_cli.run(plugins, roles, collection_name, plugin_type)

# Generated at 2022-06-24 17:46:11.107292
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-24 17:46:17.147772
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    docCLI = DocCLI()
    assert docCLI.get_plugin_metadata('./../../../lib/ansible/plugins/action/setup.py') != None


# Generated at 2022-06-24 17:46:19.320088
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Case
    cli = DocCLI()
    cli.run()
    # TODO
    assert 1 == 2

if __name__ == '__main__':
    test_case_0()
    test_class_0()
    test_DocCLI_run()

# Generated at 2022-06-24 17:46:23.873109
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    for plugin_type in ('module', 'lookup'):
        doc = DocCLI.format_plugin_doc(plugin_type, 'mymodule', 'mymodule.py')
        assert doc == (
            "mymodule - A short description of the module\n"
            "    (%s/mymodule)\n\n"
            "Options (= is mandatory):\n\n"
            "    Return Values:" % plugin_type
        )

    doc = DocCLI.format_plugin_doc('module', 'mymodule', 'mymodule.py', desc='A new description')
    assert 'A new description' in doc


# Generated at 2022-06-24 17:46:26.766617
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = {'plugins': []}
    DocCLI.display_plugin_list(doc)

if __name__ == '__main__':
    test_case_0()
    test_DocCLI_display_plugin_list()

# Generated at 2022-06-24 17:46:31.723108
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    argspec = inspect.getargspec(DocCLI.get_plugin_metadata)
    assert argspec.args == ['self', 'filename', 'metadata', 'callback']
    assert argspec.keywords == None
    assert argspec.defaults == (None, )

    doc = DocCLI()
    filename = get_data_path('units', 'modules', 'system', 'ping.py')
    metadata = {}
    result = doc.get_plugin_metadata(filename, metadata, None)
    assert result == True

    assert metadata == {
        'version_added': 'historical',
        'deprecated': False,
        'supported_by': 'core'
    }


# Generated at 2022-06-24 17:47:53.148888
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    add_collection_plugins(plugin_list, 'module')
    print("add_collection_plugins: plugin_list:  %s" % plugin_list)
    assert plugin_list != {}



# Generated at 2022-06-24 17:48:07.252152
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    parser = argparse.ArgumentParser()
    parser.add_argument('setup.py', help='Path to ansible git checkout')
    parser.add_argument('--type', choices=['action', 'callback', 'cliconf', 'connection', 'filter', 'inventory', 'lookup', 'module_utils', 'modules', 'shell', 'strategy', 'test', 'vars'], default=None, help='Filter by plugin type')
    parser.add_argument('--version_added', default=None, help='Filter by version_added value')
    parser.add_argument('--version_added_collection', default=None, help='Filter by version_added_collection value')
    parser.add_argument('--listdeps', action='store_true', help='List dependencies for a plugin type')

# Generated at 2022-06-24 17:48:09.521960
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    docCLI = DocCLI()
    docCLI.find_plugins()


# Generated at 2022-06-24 17:48:22.116296
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-24 17:48:27.521650
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    pprint(DocCLI.get_all_plugins_of_type(context.CLIARGS['type'], collection_name = 'test.test_collection'))
    # pprint(DocCLI.get_all_plugins_of_type('module'))


# Generated at 2022-06-24 17:48:29.828948
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    dc = DocCLI()
    dc.find_plugins()
    dc.find_plugin_roles()


# Generated at 2022-06-24 17:48:33.656220
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    for tmpdir, mock_cli in get_mock_dirs():
        DocCLI_obj = DocCLI(mock_cli, tmpdir)
        moduledoc = DocCLI_obj.format_plugin_doc()
        assert_equal(moduledoc, '\n')


# Generated at 2022-06-24 17:48:46.652017
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    role_mixin_1 = RoleMixin()
    text = []
    opt_indent = "    "
    limit = 100

# Generated at 2022-06-24 17:48:52.202371
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role_mixin_1 = RoleMixin()
    role_mixin_1.get_role_man_text('test_role',{})

if __name__ == '__main__':
    """
    When this script is executed from the command line, it will run the tests above
    """
    import sys
    import time
    import datetime

    ansible_test_start_time = int(time.time())

    print('--- Running tests for: DocCLI ---')
    test_DocCLI_get_role_man_text()
    test_case_0()

    ansible_test_finish_time=int(time.time())
    print('--- Finished tests for: DocCLI ---')

# Generated at 2022-06-24 17:49:01.162082
# Unit test for function jdump
def test_jdump():
    data = {
        "name": "John Doe",
        "age": 43,
        "spouse": {
            "name": "Jane Doe",
            "age": 39
        },
        "children": [
            {"name": "Alice Doe", "age": 6},
            {"name": "Bob Doe", "age": 8}
        ]
    }
    jdump(data)


# Generated at 2022-06-24 17:49:59.110385
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc_CLI = DocCLI()
    result_object = doc_CLI.get_all_plugins_of_type(
        'module', os.path.join(sys.prefix, 'lib/python2.7/site-packages/ansible/modules'))
    assert isinstance(result_object, dict)


# Generated at 2022-06-24 17:50:02.376161
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    test_cli = DocCLI()
    results = test_cli.run(['ansible-doc', '-l'])
    assert len(results) > 0


# Generated at 2022-06-24 17:50:12.623244
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():

    # Stub AnsibleModule
    class PluginStub(object):
        def __init__(self, *args, **kwargs):
            pass
    ansible_module = PluginStub()
    ansible_module._name = 'zippy'

    # Stub AnsibleModuleUtils
    module_utils = PluginStub()
    module_utils.ANSIBLE_RETURN = PluginStub()

    # Stub AnsibleFileUtils
    class PluginStub(object):
        def __init__(self, *args, **kwargs):
            pass
    ansible_file_utils = PluginStub()

    # Stub AnsibleModuleDeprecation
    class PluginStub(object):
        def __init__(self, *args, **kwargs):
            pass
    ansible_module_deprecation = PluginStub()

    #

# Generated at 2022-06-24 17:50:16.646175
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    from ansible.plugins.loader import fragment_loader
    plugin_list = set()
    plugin_type = 'test_plugin_type'
    test_coll_path = './test_collection'
    add_collection_plugins(plugin_list, plugin_type, coll_filter=test_coll_path)
    # Assert that the plugin_list is updated atleast once
    assert len(plugin_list) > 0



# Generated at 2022-06-24 17:50:27.343722
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = DocCLI()
    result = doc.get_plugin_metadata("lookup_plugins", "aws_ssm")

# Generated at 2022-06-24 17:50:37.558372
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # pylint: disable=protected-access
    plugin_loader = PluginLoader(os.path.join(os.path.dirname(__file__), '../../../lib/ansible/plugins/doc_fragments'), '', '', 'doc_fragments')
    DocCLI._get_fragment_plugins = lambda x: plugin_loader.all(class_only=True).values()
    DocCLI._get_all_collection_names = lambda x: ['collection_0']
    DocCLI._get_modules_in_collections = lambda x: {'collection_0': ['module_0', 'module_1', 'module_2']}

# Generated at 2022-06-24 17:50:42.166561
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    test_args = ['--type', 'module', '-l', 'system']
    with patch.object(sys, 'argv', test_args):
        test_doc = DocCLI()
        test_doc.run()


# Generated at 2022-06-24 17:50:45.683505
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Instantiate class
    doc_cli_1 = DocCLI()
    for plugin_type in ['module', 'lookup', 'callback', 'strategy', 'filter']:
        # Invoke method
        plugin_list=doc_cli_1.find_plugins(plugin_type)
        # Test boolean assertions
        assert plugin_list
        # Test type assertions
        assert isinstance(plugin_list, (tuple,list))


# Generated at 2022-06-24 17:50:59.433979
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    doc_cli = DocCLI()

    code = "    # start"
    code += "\n"
    code += "    foo: bar"
    code += "\n"
    code += "    # end"
    result = doc_cli.format_snippet(code)
    assert result == '\n...\nfoo: bar\n...\n'

    code = "#!/usr/bin/python"
    code += "\n"
    code += "    # start"
    code += "\n"
    code += "    foo: bar"
    code += "\n"
    code += "    # end"
    result = doc_cli.format_snippet(code)
    assert result == '\n...\nfoo: bar\n...\n'

    code = "    # start"

# Generated at 2022-06-24 17:51:05.778174
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    '''
        Unit test for method add_fields of class DocCLI
    '''

    # Create an instance of class DocCLI and call add_fields function
    doc_cli_0 = DocCLI()
    text_ptr_0 = []
    limit = 0
    opt_indent = ""
    role_mixin_0 = RoleMixin()
    return_values = False
    opt_indent_0 = ""
    DocCLI.add_fields(text_ptr_0, role_mixin_0.module_args, limit, opt_indent, return_values, opt_indent_0)


# Generated at 2022-06-24 17:51:56.681728
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    result = DocCLI.format_snippet('''
            - action: ping
              register: pong''')
    assert result == '''
    - action: ping
      register: pong'''


# Generated at 2022-06-24 17:52:00.719229
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():

    doc_cli_0 = DocCLI()
    doc_0 = {"version_added": "1.6"}
    plugin_type_0 = "action"
    expected = "ADDED IN: Ansible v1.6\n"
    try:
        result = doc_cli_0.format_plugin_doc(doc_0, plugin_type_0)
        assert result == expected
    except AssertionError:
        print("Testcase failed. Expected: %s, Got: %s" % (expected, result))
        raise



# Generated at 2022-06-24 17:52:04.998387
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Initialize the class
    docCli = DocCLI()
    text = []
    doc = {}
    limit = 70
    opt_indent = "        "
    return_values = True
    # Call the method
    docCli.add_fields(text,doc, limit, opt_indent,return_values)


# Generated at 2022-06-24 17:52:13.986175
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # setup
    args = {}
    opt_indent = "args"
    limit = 15
    return_values = False
    role_mixin_0 = RoleMixin()
    doc = {'module': 'testmodule', 'path': './testmodule', 'entry_points': {'main': {'description': 'test', 'options': {'action': {'spec': 'boolean', 'aliases': ['enable', 'disable'], 'default': True, 'env_fallback': ['test'], 'ini_fallback': ['test'], 'vars_fallback': ['test'], 'keywords': ['test'], 'choices': ['yes', 'no'], 'required': True}}}}}

# Generated at 2022-06-24 17:52:17.592923
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = dict()
    plugin_type = 'module'
    coll_filter = ['test.ansible_collections.testns2.testcoll3']

    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert 'testcoll3.testcoll3.test' in plugin_list
    assert 'testcoll3.testcoll3.test2' in plugin_list
    assert 'testcoll3.testcoll3.test3' in plugin_list


# Generated at 2022-06-24 17:52:21.695433
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc_cli_0 = DocCLI()
    doc_cli_0.display_plugin_list('')

    doc_cli_0.display_plugin_list('copy')
    doc_cli_0.display_plugin_list('action')


# Generated at 2022-06-24 17:52:35.095734
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    method = 'get_all_plugins_of_type'
    plugin_loader = PluginLoader(
        class_name='ModuleUtil',
        package='ansible.plugins.test.units.module_utils',
        config=None,
        subdir=os.path.join('module_utils'),
        package_errors={},
    )
    all_plugins = plugin_loader.all(class_only=False)
    module_plugins_path = plugin_loader.find_plugin(class_name='MyModuleUtil', subdir=os.path.join('module_utils'), ignore_deprecated=True)

    docCLI_0 = DocCLI()
    (result,) = docCLI_0.get_all_plugins_of_type(all_plugins, module_plugins_path)

# Generated at 2022-06-24 17:52:46.861380
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test 1
    desc = 'Test 1: Test case with empty options'
    opt_indent = '        '
    text = []
    limit = 70
    options = {'my_option': {}}
    DocCLI.add_fields(text, options, limit, opt_indent)
    assert text == ['']
    display.display(desc, color='green')
    # Test 2
    desc = 'Test 2: Test case with empty option name'
    text = []
    options = {'': {'choices': ['abc', 'bcd']}}
    DocCLI.add_fields(text, options, limit, opt_indent)
    assert text == ['        CHOICES: abc, bcd\n', '', '']
    display.display(desc, color='green')
    # Test 3
    desc

# Generated at 2022-06-24 17:52:50.754324
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    DocCLI_obj = DocCLI()
    # Call method
    DocCLI_obj.format_plugin_doc(file_name='/Users/mehaboob/Documents/workspaces/redhat/ansible/lib/ansible/plugins/inventory/vmware.py', verbosity=3)


# Generated at 2022-06-24 17:53:01.975716
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # initialise the module
    module = DocCLI()
    
    # initialise the test data
    plugin_list = {'test': {'test1': 'test1', 'test2': 'test2'}}
    names = 'test'
    enabled_plugins = {'test': 'Test', 'test1': 'Test1'}
    
    # Create test object
    test_obj = DocCLI()
    
    # Run the test
    result = test_obj.display_plugin_list(plugin_list, names, enabled_plugins)
    
    # Log the result
    logger.info(result)
    

# Generated at 2022-06-24 17:53:47.106200
# Unit test for method get_role_man_text of class DocCLI