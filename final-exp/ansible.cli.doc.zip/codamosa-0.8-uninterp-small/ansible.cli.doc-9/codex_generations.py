

# Generated at 2022-06-24 17:46:50.472117
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc_cli_0 = DocCLI()
    result_0 = doc_cli_0.get_plugin_metadata(('action', 'copy'))


# Generated at 2022-06-24 17:47:00.330082
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:47:03.866415
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    test_case_DocCLI_get_man_text_0()
    test_case_DocCLI_get_man_text_1()

# Test for method get_man_text of class DocCLI
# Test #0 - Normal Test

# Generated at 2022-06-24 17:47:14.114860
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    opt_indent = "        "
    text = []
    pad = display.columns * 0.20
    limit = max(display.columns - int(pad), 70)

    DocCLI.add_fields(text, [{"test_case_1_a": "test_case_1_b"}], limit, opt_indent)
    assert text == ["        TEST_CASE_1_A: test_case_1_b\n"], \
        "Error in add_fields, when text is a list of a list of a dict"
    text = []
    DocCLI.add_fields(text, {"test_case_2_a": "test_case_2_b"}, limit, opt_indent)

# Generated at 2022-06-24 17:47:21.713958
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    ''' Unit test for method find_plugins of class DocCLI '''
    # Initialize
    # Instantiate the object
    doc_cli_obj = DocCLI()
    # Instantiate the arguments object
    args_obj = []
    # Instantiate the parser object
    parser = argparse.ArgumentParser()
    # Initialize the doc type
    doc_type = None
    # Invoke the class method
    result = doc_cli_obj.find_plugins(args_obj, parser, doc_type)
    # Assertion
    assert result


# Generated at 2022-06-24 17:47:32.851479
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    test_case = TestCase()
    plugin_doc = dict()
    plugin_doc['DOCUMENTATION'] = test_case.DOCUMENTATION_content
    plugin_doc['EXAMPLES'] = test_case.EXAMPLES_content
    plugin_doc['RETURN'] = test_case.RETURN_content
    plugin_doc['description'] = test_case.description
    plugin_doc['author'] = test_case.author
    plugin_doc['version_added'] = test_case.version_added
    plugin_doc['notes'] = test_case.notes
    plugin_doc['seealso'] = test_case.seealso
    plugin_doc['requirements'] = test_case.requirements
    module_name = test_case.module_name
    plugin_type = test_case.plugin_type


# Generated at 2022-06-24 17:47:41.944105
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doccli_obj = DocCLI()
    role = "win_ping"
    role_json = {"entry_points": {
        "main": {
            "options": {
                "msg": {
                    "default": "hello world",
                    "description": "a required message"
                    }
                }
            }
        }
    }
    ret_val = doccli_obj.get_role_man_text(role, role_json)
    print(ret_val)

if __name__ == '__main__':
    test_case_0()
    test_DocCLI_get_role_man_text()

# Generated at 2022-06-24 17:47:52.241522
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc_cli_0 = DocCLI()
    role_mixin_0 = RoleMixin()
    #assert doc_cli_0.get_all_plugins_of_type(('action', 'lookup'))
    #assert doc_cli_0.get_all_plugins_of_type(('action', 'lookup'), want_all=True)
    #assert doc_cli_0.get_all_plugins_of_type(('action', 'lookup'), strip_directory=True)
    #assert doc_cli_0.get_all_plugins_of_type(('action', 'lookup'), dirstop=role_mixin_0.collection_dir)
    #assert doc_cli_0.get_all_plugins_of_type(('action', 'lookup'), ignore_dirs=[])
    #assert doc_

# Generated at 2022-06-24 17:47:57.694258
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Positive testing of method get_plugin_metadata of class DocCLI
    # with a valid argument
    doc = DocCLI.get_plugin_metadata(
        'uri',
        'library/modules/web_infrastructure/apigee/apigee_apis.py',
        C.DEFAULT_MODULE_PATH
    )
    assert doc['name'] == 'apigee_apis'



# Generated at 2022-06-24 17:48:05.965900
# Unit test for method run of class DocCLI
def test_DocCLI_run():

    # setup
    doc_cli_obj = DocCLI()
    doc_cli_obj._display.columns = 80
    DocCLI.IGNORE = ()

    #######################################################################################################
    # Test vars:
    #######################################################################################################

# Generated at 2022-06-24 17:48:51.366514
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc_cli_0 = DocCLI()
    role_0 = 'os_server_group'

# Generated at 2022-06-24 17:49:07.599489
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}

    add_collection_plugins(plugin_list, 'callback', coll_filter='f5')
    assert 'f5.bigip' in plugin_list
    assert 'f5.bigip_gtm_wide_ip' in plugin_list

    add_collection_plugins(plugin_list, 'strategy')
    assert 'ansible_collections.community.general.strategy' not in plugin_list  # test that it's not added twice
    assert 'ansible_collections.netapp.filer' in plugin_list

    add_collection_plugins(plugin_list, 'httpapi')
    assert 'ansible_collections.cnos.cnos' in plugin_list

    add_collection_plugins(plugin_list, 'filter')

# Generated at 2022-06-24 17:49:20.304563
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # Test with directory-based lookup
    with tempfile.NamedTemporaryFile(prefix='/tmp/ansible_namespace_from_plugin_filepath_test_DocCLI_namespace_from_plugin_filepath') as tmp_file:
        tmp_file.write('empty')
        tmp_file.flush()
        plugin_path = os.path.dirname(tmp_file.name)
        assert DocCLI.namespace_from_plugin_filepath(plugin_path) == 'empty'
        plugin_path += '/'
        assert DocCLI.namespace_from_plugin_filepath(plugin_path) == 'empty'
        tmp_file.close()

    # Test with file-based lookup

# Generated at 2022-06-24 17:49:25.958595
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    DocCLI_0 = DocCLI()
    DocCLI_0.namespace_from_plugin_filepath()


# Generated at 2022-06-24 17:49:28.635698
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role_mixin_1 = RoleMixin()
    role_mixin_1.get_role_man_text(role='test_role', role_json={})


# Generated at 2022-06-24 17:49:33.813102
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    plugin_loader = PluginLoader()
    cli_doc = DocCLI()
    cli_doc.print_paths(get_collection_name(), ['module.yml'], plugin_loader)
    cli_doc.print_paths(get_collection_name(), ['module'], plugin_loader)


# Generated at 2022-06-24 17:49:36.454572
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    test_DocCLI_add_fields_case_0()
    test_DocCLI_add_fields_case_1()



# Generated at 2022-06-24 17:49:48.477544
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role_mixin_0 = RoleMixin()
    role = 'test_get_role_man_text'
    role_json_0 = dict(
        author={
            'name': 'test_author_name_0'
        },
        description='test_description_0',
        filename='test_filename_0',
        name=role,
        options={
            'test_option_name_0': {
                'default': 'test_default_0',
                'description': 'test_description_0',
                'required': False,
                'type': 'str'
            }
        },
        path='test_path_0',
        version_added='test_version_added_0'
    )
    # Call the target method

# Generated at 2022-06-24 17:49:57.449969
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    DocCLI_obj_0 = DocCLI()
    text_0 = []
    opt_0 = {"aliases": [], "description": "Option Description", "required": False, "type": ""}
    DocCLI_obj_0.add_fields(text_0, opt_0, 80, "        ")
    assert text_0 == ['        Option Description']


# Generated at 2022-06-24 17:50:08.663377
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc_cli_0 = DocCLI()
    doc_0 = {'description': 'This is a test', 'short_description': 'short desc', 'examples': ['example1', 'example2'], 'plainexamples': 'plain examples',
             'options': {'option_1': {'description': 'description 1'}, 'option_2': {'description': 'description 2'},
             'option_3': {'description': 'description 3'}}, 'attributes': {'attr1': {'description': 'desc1'}, 'attr2': {'description': 'desc2'},
             'attr3': {'description': 'desc3'}}}
    display.columns = 80
    result_dict_0 = doc_cli_0.get_man_text(doc_0)

# Generated at 2022-06-24 17:51:54.679025
# Unit test for method display_plugin_list of class DocCLI

# Generated at 2022-06-24 17:52:05.363172
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.common.collections import ImmutableDict
    class DocCLI_obj(DocCLI):
        def __init__(self, module_name, **kwargs):
            self.module_name = module_name
            super(DocCLI_obj, self).__init__(**kwargs)
        def get_option_dict(self, option_info, name, aliases=[]):
            return dict()
        def get_path(self, name):
            return ""
        def _get_versioned_doclink(self, doc_name):
            return ""
        def get_collection_name(self, path):
            return ""

    doc_cli = DocCLI_obj('test')


# Generated at 2022-06-24 17:52:14.421560
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:52:23.180344
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role_mixin_1 = RoleMixin()
    role_json = {
        'description': 'This is a test',
        'entry_points': {
            'main': {
                'description': 'This is a test',
                'short_description': 'This is a test'
            }
        },
        'name': 'test',
        'path': "{}/ansible/test/roles/test/meta/main.yaml".format(os.getcwd())
    }
    ret = role_mixin_1.get_role_man_text("test", role_json)

# Generated at 2022-06-24 17:52:35.716378
# Unit test for method get_plugin_metadata of class DocCLI

# Generated at 2022-06-24 17:52:37.454647
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # FIXME: Add unit test for DocCLI class method get_plugin_metadata
    pass


# Generated at 2022-06-24 17:52:38.498153
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    test_doc_cli = DocCLI()


# Generated at 2022-06-24 17:52:46.942280
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-24 17:52:55.118645
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    display.columns = 80

    dirname = os.path.dirname(__file__)
    # Get the content of the test case we are using to verify this method
    plugindir = os.path.join(dirname, 'test_plugin_dir')

    # Loop over all files in the test case
    for filename in os.listdir(plugindir):
        # Skip directories
        if os.path.isdir(os.path.join(plugindir, filename)):
            continue

        test_case = os.path.join(plugindir, filename)
        # Get the plugin type and name
        plugin_type, plugin_name = os.path.splitext(filename)
        plugin_type = plugin_type.split('_', 1)[-1]
        if plugin_name == '.py':
            plugin_name

# Generated at 2022-06-24 17:53:05.577213
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # Test format_snippet() method of class DocCLI
    for parser in (DocCLI, CLI):

        res = parser.format_snippet('module', 'module_name', {'option': 'value'})
        assert res == "- name: module_name\n  module_name:\n    option: value\n"

        res = parser.format_snippet('role', 'role_name', {'option': 'value'})
        assert res == "- name: role_name\n  role_name:\n    option: value\n"

        res = parser.format_snippet('action', 'action_name', {'option': 'value'})
        assert res == "  - name: action_name\n    action_name:\n      option: value\n"

        res = parser.format_snippet