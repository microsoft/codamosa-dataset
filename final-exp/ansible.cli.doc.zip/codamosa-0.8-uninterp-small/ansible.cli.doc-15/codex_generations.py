

# Generated at 2022-06-24 17:45:57.249857
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc_0 = DocCLI.get_man_text()
    return doc_0


# Generated at 2022-06-24 17:46:08.573532
# Unit test for method run of class DocCLI

# Generated at 2022-06-24 17:46:10.671342
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'action'
    coll_filter = None
    assert add_collection_plugins(plugin_list, plugin_type, coll_filter) == None


# Generated at 2022-06-24 17:46:17.147199
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    plug_0 = DocCLI()
    result_0 = plug_0.get_all_plugins_of_type(context.CLIARGS['type'])
    assert result_0 is not None


# Generated at 2022-06-24 17:46:23.583709
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    import ansible.cli.doc
    doc = ansible.cli.doc.DocCLI()
    p = list(doc.print_paths(ansible.constants.DEFAULT_MODULE_PATH))
    assert(p[0].find('ansible_module_') != -1)


# Generated at 2022-06-24 17:46:27.397943
# Unit test for function jdump
def test_jdump():
    try:
        test_case_0()
    except (AnsibleError, Exception) as e:
        display.display('Exception during jdump unit test: %s' % to_native(e), color='red')
        display.display(traceback.format_exc(), color='red')
        assert False
    else:
        assert True



# Generated at 2022-06-24 17:46:32.113604
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    options = [{
        'name': 'module_1',
        'description': 'description_1',
        'required': True,
        'default': 'default_1'},
        {
        'name': 'module_2',
        'description': 'description_2',
        'required': True,
        'default': 'default_2'}]
    limit = 70
    opt_indent = '        '
    return_values = False
    text = []
    DocCLI.add_fields(text, options, limit, opt_indent, return_values)
    assert len(text) == 6


# Generated at 2022-06-24 17:46:38.148316
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc_cli_0 = DocCLI(['ansible-doc', '-l'])
    var_0 = doc_cli_0.run()


# Generated at 2022-06-24 17:46:47.637088
# Unit test for method run of class DocCLI
def test_DocCLI_run():

    # A utility class to provide attributes for object DocCLI
    class Bunch(dict):
        def __init__(self, *args, **kwargs):
            dict.__init__(self, *args, **kwargs)
            self.__dict__ = self

    # Define arguments and context
    args = Bunch({'one_liner': False, 'type': 'module', 'module_path': None, 't': None, 'module_name': None})
    context = Bunch({'CLIARGS': args, 'NOW': True})

    # Instantiate DocCLI with args and context
    instance = DocCLI(args, context)

    # Call method run of a DocCLI instance
    cmd_output = instance.run()

    # Assert no error is raised and print "Success" if test passes

# Generated at 2022-06-24 17:46:59.063588
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    try:
        import pytest
        from pytest import raises
    except:
        print("pytest is not installed, please install it in order to run unit tests")
    plugin_list_0 = {}
    plugin_type_0 = "action"
    coll_filter_0 = None
    var_0 = add_collection_plugins(plugin_list_0, plugin_type_0, coll_filter_0)
    with raises(AnsibleOptionsError) as excinfo:
        plugin_list_1 = {}
        plugin_type_1 = "bad_plugin_type"
        coll_filter_1 = None
        var_1 = add_collection_plugins(plugin_list_1, plugin_type_1, coll_filter_1)

# Generated at 2022-06-24 17:47:37.896413
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():

    doc_cli_0 = DocCLI(docsite=False)
    plugins = doc_cli_0.get_all_plugins_of_type()
    assert type(plugins) == list and len(plugins) > 0


# Generated at 2022-06-24 17:47:49.661721
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    from ansible.constants import DEFAULT_ROLES_PATH
    # Get module name from the command line or input file
    module_name = 'win_ping'
    # Generate the documentation for the module
    module = DocCLI()
    title = module.get_title(module_name)
    doc_json = module.create_doc(module_name)

    # Print the text
    print(title)
    print(module.get_plugin_man_text(doc_json, plugin_type='modules'))
    role_mixin_0 = RoleMixin()
    role_mixin_0._load_roles()
    # Get a list of all of the roles
    all_roles = role_mixin_0.get_roles()

# Generated at 2022-06-24 17:48:06.323929
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    doc_cli_0 = DocCLI()
    exps = ['', '', '', '', '']
    exps[0] = "        - vlan_id: 99"
    exps[1] = "              vlan_id: 99"
    exps[2] = "              vlan_id: 99"
    exps[3] = "              vlan_id: 99"
    exps[4] = "        - action: create"
    exps.append('')
    for exp in exps:
        assert doc_cli_0.format_snippet(exp) == ''

    exps[5] = """- name: create vlan
  vlan:
    vlan_id: 99
    vlan_name: foo
    state: present"""

# Generated at 2022-06-24 17:48:09.136249
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doccli_0 = DocCLI()
    print(doccli_0.get_plugin_metadata())
    # test_case_0()


# Generated at 2022-06-24 17:48:21.969259
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('/home/konradm/.ansible/plugins/modules/aix_user') == 'aix'
    assert DocCLI.namespace_from_plugin_filepath('/home/konradm/.ansible/plugins/modules/blockinfile') == None
    assert DocCLI.namespace_from_plugin_filepath('/home/konradm/.ansible/plugins/modules/cloud/interactive/gcp') == 'gcp'
    assert DocCLI.namespace_from_plugin_filepath('/home/konradm/.ansible/plugins/modules/clc_') == None

# Generated at 2022-06-24 17:48:26.557342
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    app_0 = CLI(args=['ansible-doc', '-t', 'module'])
    DocCLI.add_collection_plugins(app_0.all_plugins, 'module')
    assert len(app_0.all_plugins) > 0


# Generated at 2022-06-24 17:48:35.870286
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-24 17:48:44.453971
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    # TODO: implement more test cases
    host_patterns_0 = ['#', '?', '*']
    plugin_list_0 = {}
    plugin_type_0 = 'none'
    add_collection_plugins(plugin_list_0, plugin_type_0)
    assert plugin_list_0 == {}

    plugin_list_1 = {}
    plugin_type_1 = 'module'
    add_collection_plugins(plugin_list_1, plugin_type_1)
    assert plugin_list_1 == {}


# Generated at 2022-06-24 17:48:53.004430
# Unit test for method namespace_from_plugin_filepath of class DocCLI

# Generated at 2022-06-24 17:48:55.222332
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    DOC = DocCLI()
    DOC.run()


# Generated at 2022-06-24 17:50:12.656898
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # DocCLI.get_role_man_text must return an array of text suitable for displaying to screen.
    # This is similar to get_man_text(), but roles are different enough that we have a separate method for formatting their display.
    role_mixin_1 = RoleMixin()
    role_json = {
            'entry_points': 'test_entry_points',
            'path': 'test_path'
        }
    # Create a copy so we don't modify the original
    result = role_mixin_1.get_role_man_text('test_role', dict(role_json))
    assert isinstance(result, list)

# Generated at 2022-06-24 17:50:18.735920
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # No docstring
    assert_raises(AnsibleOptionsError, _display_plugin_list,
                  ['/path/to/roles'], 'role', 'roles', 'ansible-doc', 'role',
                  ['some', 'name'])
    # No entry point
    assert_raises(AnsibleOptionsError, _display_plugin_list,
                  ['/path/to/roles'], 'role', 'roles', 'ansible-doc', 'role',
                  ['some', 'name'], doc=dict())
    # No plugin_type
    #assert_raises(AnsibleOptionsError, display_plugin_list,
    #            ['/path/to/roles'], 'role', 'roles', 'ansible-doc', 'role',
    #            ['some', 'name'], doc=

# Generated at 2022-06-24 17:50:28.041771
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-24 17:50:36.690941
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    test_doc = {'description': 'Add a user',
                'options': dict(name=dict(description='The name of the new user.'),
                                uid=dict(description='The user id. If not specified, a user id will be automatically selected.', default=0),
                                home=dict(description='The path of the user\'s home directory.'),
                                shell=dict(description='The path of the user\'s login shell.')),
                'extends_documentation_fragment': ['user_common']}
    output = DocCLI.get_man_text(test_doc)
    print(output)


test_case_0()

# Generated at 2022-06-24 17:50:43.060577
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    plugin_type = 'doc_fragments'
    doc_cli_obj = DocCLI()

# Generated at 2022-06-24 17:50:51.187421
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    print("Testing method format_snippet of class DocCLI")
    doc_cli = DocCLI()
    snippet_0 = "assert:\n"
    snippet_1 = "- one\n- two"
    snippet_2 = "- one\n- two\n- not_this\n- not_this"
    snippet_3 = "- one\n- two\n- not_this\n- not_this\n- three"
    snippet_4 = "assert:\n- one\n- two"
    snippet_5 = "assert:\n- one\n- two\n- not_this\n- not_this"
    snippet_6 = "assert:\n- one\n- two\n- not_this\n- not_this\n- three"

# Generated at 2022-06-24 17:51:01.393784
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:51:13.229507
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    d = DocCLI()

# Generated at 2022-06-24 17:51:14.634889
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doccli_0 = DocCLI()
    doccli_0.display_plugin_list()


# Generated at 2022-06-24 17:51:19.210395
# Unit test for function jdump
def test_jdump():
    text = dict(
        a=1,
        b=2,
        c=3,
        d=4,
    )
    jdump(text)


# Generated at 2022-06-24 17:52:44.483507
# Unit test for method get_plugin_metadata of class DocCLI

# Generated at 2022-06-24 17:52:53.349633
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc_cli = DocCLI()
    plugin_type = 'module'
    plugin_name_0 = 'setup'
    expected_0 = {'filename': '../../lib/ansible/modules/system/setup.py', 'docuri': 'DOCUMENTATION', 'docuri_section': 'DOCUMENTATION', 'docuri_alias': 'DOCUMENTATION', 'aliases': ['setup'], 'name': 'setup', 'module': 'setup', 'version_added_collection': None, 'version_added': 'historical', 'plugin_type': 'module'}
    actual_0 = doc_cli.get_plugin_metadata(plugin_type, plugin_name_0)
    diff_0 = set(expected_0.items())^set(actual_0.items())

# Generated at 2022-06-24 17:53:01.975405
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Access the public attributes of the test class
    role_mixin_0 = RoleMixin()
    # Create a new object of the test class
    doc_cli_0 = DocCLI()
    # Test the private attributes of the test class
    # Test the method get_role_man_text of class DocCLI
    assert doc_cli_0.get_role_man_text(role_mixin_0.name, role_mixin_0.json) is not None


# Generated at 2022-06-24 17:53:13.681630
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc_cli_0 = DocCLI()
    test_var_0 = {'module_utils': {'win_lmi_module': {'__ansible_module__': True}}}
    test_var_1 = {'module_utils': {'win_lmi_module': {'__ansible_module__': True, '__augment_doc__': ["augment_doc"]}}}
    test_var_2 = {'module_utils': {'win_lmi_module': {'__ansible_module__': False}}}
    test_var_3 = {}
    doc_cli_0.get_all_plugins_of_type(test_var_0)
    doc_cli_0.get_all_plugins_of_type(test_var_1)
    doc_cli_0.get_all_plugins_

# Generated at 2022-06-24 17:53:25.974950
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    plugin_type = 'cliconf'
    plugin_name = 'dellos9'
    doc_obj_0 = DocCLI()
    path_0 = 'cliconf/dellos9.py'

    plugin_doc_0 = doc_obj_0.format_plugin_doc(plugin_type, plugin_name, path_0)
    print('\n=== plugin_doc_0 ===')
    print(plugin_doc_0)


if __name__ == "__main__":
    import sys
    import os
    import unittest

    sys.path.insert(0, os.path.abspath(__file__ + "/../../../"))

    print('Testing ansible.cli.doc CLI functionality')
    test_case_0()

    # Unit test for method format_plugin_doc of class DocCL

# Generated at 2022-06-24 17:53:32.347049
# Unit test for method namespace_from_plugin_filepath of class DocCLI

# Generated at 2022-06-24 17:53:36.615411
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    DocCLI_obj = DocCLI()
    test_file = "invalid_file.py"
    result = DocCLI_obj.get_plugin_metadata(test_file)
    assert len(result) == 0


# Generated at 2022-06-24 17:53:44.114128
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    print("test_DocCLI_run")
    # Create object DocCLI
    docCLI = DocCLI()

    # Check that module ansible.modules.system.setup exists
    module_name = "setup"
    module = None
    try:
        module = module_loader.find_plugin(module_name, 'modules')
    except Exception as e:
        print("test_DocCLI_run: module_loader.find_plugin(%s, 'modules') raised %s" % (module_name, str(e)))
        module = None
    assert module is not None
    assert hasattr(module, '__doc__')

    # Check that method add_fields of class DocCLI exists
    assert hasattr(docCLI, "add_fields") and callable(getattr(docCLI, "add_fields"))

# Generated at 2022-06-24 17:53:54.268932
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc_cli_0 = DocCLI()
    plugin_0 = [{'short_description': 'Short description of list of dict', 'description': 'Description of list of dict', 'version_added': '1.0'}, {'short_description': 'Short description of list of dict'}]
    plugin_1 = {'short_description': 'Short description of dict', 'description': 'Description of dict', 'version_added': '1.0'}
    plugin_2 = {'description': 'Description of dict', 'version_added': '1.0'}
    print("Pass: doc_cli_0.get_plugin_metadata(plugin_0) returned " + str(doc_cli_0.get_plugin_metadata(plugin_0)))