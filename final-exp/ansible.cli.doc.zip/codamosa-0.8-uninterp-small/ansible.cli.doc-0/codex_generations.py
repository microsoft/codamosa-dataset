

# Generated at 2022-06-24 17:47:32.851350
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    def get_plugin_mock(name, *args, **kwargs):
        if name == 'json':
            return get_doc_fragment_mock(
                'json_runner.py',
                '#!/usr/bin/env python\n# This is a fake module for testing.',
                'def run(self,tmp=None,task_vars=None):\n return {}'
            )

    # Test for no arguments
    try:
        # This should fail since we have not specified mandatory arguments
        DocCLI().run()
    except SystemExit as ex:
        assert ex.code == 1
    else:
        assert False, "Test case 0 passed unexpectedly"

    # Test for no arguments

# Generated at 2022-06-24 17:47:47.637527
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    test_text = []
    test_data_0 = {'test_field': 'initial_text'}
    limit = 100
    opt_indent = "    "
    DocCLI.add_fields(test_text, test_data_0, limit, opt_indent)
    assert test_text[0] == 'test_field: initial_text'
    assert len(test_text) == 1

    test_text.clear()
    test_data_2 = {'test_field': {'description': 'test_description'}}
    DocCLI.add_fields(test_text, test_data_2, limit, opt_indent)
    assert test_text[0] == 'test_field:'
    assert test_text[1] == '{description: test_description}'

# Generated at 2022-06-24 17:48:01.136783
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    import os
    try:
        # This test will fail only if the env variable test_basepath is not defined
        basepath = os.environ['test_basepath']
        test_file = os.path.join(basepath, os.environ['test_file'])
    except Exception as e:
        raise unittest.SkipTest("Skipping Test TestDocCLI.test_case_DocCLI_get_plugin_metadata : %s" % e)
    try:
        doc = DocCLI.get_plugin_metadata(test_file)
        assert doc == 'test'
    except Exception as e:
        raise AssertionError("Failed Test TestDocCLI.test_case_DocCLI_get_plugin_metadata : %s" % e)


# Generated at 2022-06-24 17:48:08.135125
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test case for list of plugins (to be displayed in long format) as list of list

    plugin_list = [
        ['action', 'command', 'doc'],
        ['action_a', 'action_a', 'action_a_doc'],
        ['action_b', 'action_b', 'action_b_doc']
    ]
    target = sys.stdout

    dcli = DocCLI()
    dcli.display_plugin_list(plugin_list, target)



# Generated at 2022-06-24 17:48:17.420108
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    command = DocCLI()

    # Call method get_man_text of class DocCLI

# Generated at 2022-06-24 17:48:21.471784
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = []
    coll_filter='test'
    add_collection_plugins(plugin_list, '', coll_filter)


# Generated at 2022-06-24 17:48:23.631524
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    docs = DocCLI()
    with pytest.raises(PluginNotFound):
        docs.run()


# Generated at 2022-06-24 17:48:34.511775
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:48:46.986608
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    display.columns = 80
    plugin_type = 'test'
    doc = {}
    doc['module'] = 'foobar'
    doc['short_description'] = 'I am the short description.'
    doc['description'] = 'I am the long description'
    doc['filename'] = '/path/to/foobar.py'
    doc['options'] = {}
    doc['options']['foo'] = {}
    text = DocCLI.get_man_text(doc, plugin_type=plugin_type)
    assert(text.find('FOOBAR') != -1)
    assert(text.find('(/path/to/foobar.py)') != -1)
    assert(text.find('I am the short description') != -1)
    assert(text.find('I am the long description') != -1)

# Generated at 2022-06-24 17:48:54.456185
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-24 17:50:50.358701
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    test_module_doc_1 = {
        'description': ['Manage stanzas in the Ansible inventory file.'],
        'deprecated': {
            'version': '2.13',
            'why': 'Use the \'preferences\' plugin instead.',
            'removed_in': '2.14',
            'alternative': 'preferences',
        },
        'seealso': [{
            'module': 'preferences',
            'description': "Modify ansible configuration via 'ansible.cfg' settings.",
        }],
    }


# Generated at 2022-06-24 17:50:53.610455
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    add_collection_plugins(plugin_list, plugin_type='filter')
    print(plugin_list)
    print(type(plugin_list))


# Generated at 2022-06-24 17:50:56.723495
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Test for no parameters
    man_text = DocCLI.get_man_text({})
    assert isinstance(man_text, str)


# Generated at 2022-06-24 17:51:00.177722
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    filepath = "/home/docs/dir1/dir2/dir3/my_module.py"
    expected_result = "dir1.dir2.dir3"
    assert DocCLI.namespace_from_plugin_filepath(filepath) == expected_result


# Generated at 2022-06-24 17:51:11.565065
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # test normal case
    doc = {}
    display.columns = 80
    DocCLI.tty_ify = mock.Mock()
    text = DocCLI.get_man_text(doc)
    assert text == '>                     ()\n\n\n\n\n\n\n\n'

    # test error case
    doc = {}
    display.columns = 80
    DocCLI.tty_ify = mock.Mock(side_effect=Exception('exception'))
    text = DocCLI.get_man_text(doc)
    assert text == '>                     ()\n\n\n\n\n\n\n\n'



# Generated at 2022-06-24 17:51:17.641940
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    plugin_not_found_1 = PluginNotFound()
    namespace = plugin_not_found_1.namespace_from_plugin_filepath('/home/ansible/ansible/modules/cloud/ovirt4.py')
    assert namespace == 'cloud.ovirt4'

    plugin_not_found_2 = PluginNotFound()
    namespace = plugin_not_found_2.namespace_from_plugin_filepath('/home/ansible/ansible/modules/network/fortios/fortios_system_mac_address_table.py')
    assert namespace == 'network.fortios_system_mac_address_table'

    plugin_not_found_3 = PluginNotFound()

# Generated at 2022-06-24 17:51:20.046347
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role = "tester"
    role_json = {}
    doc = DocCLI()
    # legacy
    if hasattr(doc, 'get_role_man_text'):
        doc.get_role_man_text(role, role_json)


# Generated at 2022-06-24 17:51:22.727912
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():

    # create an empty list
    list = []

    # invoke the method to display plugin list
    DocCLI.display_plugin_list(list)


# Generated at 2022-06-24 17:51:32.272283
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    plugin_list_0 = DocCLI.run()
    plugin_list_1 = DocCLI.run(['ansible.builtin.template_module'])
    plugin_list_2 = DocCLI.run(['ansible.builtin.template_module'], list_dir=True)
    plugin_list_3 = DocCLI.run(['ansible.builtin.template_module'], list_dir=True, list_files=True)
    plugin_list_4 = DocCLI.run(['ansible.builtin.template_module'], list_dir=True, list_files=True, list_module_groups=True)

# Generated at 2022-06-24 17:51:39.928609
# Unit test for function add_collection_plugins
def test_add_collection_plugins():

    #path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'collections', collname, 'plugins', ptype)
    collname = 'community.general'

    # Get the base path of a sample collection in the Ansible source code
    path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'collections', collname)

    # Store the original ansible.cfg
    original_cfg = C.CONFIG_FILE


# Generated at 2022-06-24 17:52:36.135138
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    from ansible.executor.pod.doc.display import Display

    display = Display()
    plugin_list = ['test_plugin_0', 'test_plugin_1', 'test_plugin_2']
    DocCLI.display_plugin_list(plugin_list, display)


# Generated at 2022-06-24 17:52:45.729070
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    test_cases = []
    test_cases.append(("""
The list of available plugins is not cached. Requesting plugins.
""",
            ['None', 'None', 'None'],
            ("display_plugin_list",),
            {} ))

# Generated at 2022-06-24 17:52:54.169918
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test call to DocCLI.add_fields() with the following arguments:
    #   text = [u'block: >', u'    Block device mappings to volumes. Default is empty.']
    #   limit = 120
    #   indent = u'                '
    #   opt_indent = u'   '
    #   return_values = False
    # For example:
    DocCLI.add_fields(['block: >', '    Block device mappings to volumes. Default is empty.'], 120, '                ', '   ', False)
    # Expected Output:
    #   ['                block: >',
    #    '                    Block device mappings to volumes. Default is empty.']
    #   ['                aliases: ',
    #    '                    - volume_ids',
    #    '                    - instance_volumes',
   

# Generated at 2022-06-24 17:53:05.053096
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc_cli = DocCLI()
    collection_name = 'F5.common'
    role = 'redhat'

# Generated at 2022-06-24 17:53:11.493877
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test when module metadata is not found
    try:
        DocCLI().get_plugin_metadata()
    except PluginNotFound:
        pass

    plugin_name = 'setup'
    doc_cli = DocCLI()
    metadata = doc_cli.get_plugin_metadata(plugin_name)
    # Test if metadata is returned
    assert metadata


# Generated at 2022-06-24 17:53:16.271389
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    display.display(os.getcwd(), newline=False)
    display.display('test')
    read_path = [os.getcwd()]
    doc_cli = DocCLI()
    doc_cli.print_paths(read_path)


# Generated at 2022-06-24 17:53:17.784214
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    test_case_0()

# Generated at 2022-06-24 17:53:22.309963
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    line = '- name: This is a task'
    expected_result = '    - name: This is a task'
    result = DocCLI.format_snippet(line, indent=4)
    assert result == expected_result


# Generated at 2022-06-24 17:53:30.107836
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    from ansible.module_utils.six import string_types

    # Unit test for method get_man_text of class DocCLI
    # Note: If open_file does not return a object, this test case is useless.
    open_file = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'action_plugins', 'commandline', '__init__.py'), 'rb')
    # The file open_file.txt should be a readable file.
    assert os.access(open_file.name, os.R_OK) == True

    # The function get_plugin_docstring should return type str
    # If get_plugin_docstring does not return a string, this assert fails

# Generated at 2022-06-24 17:53:42.013209
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    '''
    Test DocCLI.format_snippet
    '''
    snippet = '''  - debug:
      msg: "msg1"'''
    formatted_snippet = '{0:>12}debug:{0:>11}msg:\n{0:>16}"msg1"'.format('')
    assert DocCLI.format_snippet(snippet) == formatted_snippet

    snippet = '''  - debug:
        msg: "msg1"
      with_items:
        - "1"
        - "2"'''