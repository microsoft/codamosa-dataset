

# Generated at 2022-06-24 17:46:46.421883
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    int_0 = 1221
    doc_c_l_i_0 = DocCLI(int_0)
    str_0 = 'ansible.module_utils.six'
    str_1 = 'x'
    tuple_0 = (str_0, str_1)

# Generated at 2022-06-24 17:46:53.742723
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    int_0 = 1221
    doc_c_l_i_0 = DocCLI(int_0)
    str_0 = 'pdn1tlfvso8ibxf2eypy0r5r'
    str_1 = '8l0dyb9rukpvjdmv38hss0w5w'
    str_2 = 'qpkm8pk5z5d0aaa5vspz0i5c8'
    str_3 = '7vn1gajb8zfcdmgdz9cn3qkvu'
    tup_0 = (str_0, str_1, str_2, str_3)
    str_4 = 'n0yp8yctdzpr19buuys6umz8f'
    int_1 = 6519
    str_

# Generated at 2022-06-24 17:46:57.194257
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    '''DocCLI(1221).format_plugin_doc()
    '''
    int_0 = 1221
    doc_c_l_i_0 = DocCLI(int_0)
    plugin_name = ''
    try:
        doc_c_l_i_0.format_plugin_doc(plugin_name)
    except ValueError:
        print("test_DocCLI_format_plugin_doc threw ValueError")
        exit(1)


# Generated at 2022-06-24 17:46:58.206075
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    test_case_0()


# Generated at 2022-06-24 17:47:08.604642
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    obj_0 = DocCLI()
    obj_0.module_docs('module')
    obj_0.module_docs('module')
    obj_0.module_docs('module')
    obj_0.module_docs('module')
    obj_0.module_docs('module')
    obj_0.module_docs('module')
    int_0 = 1221
    obj_0 = DocCLI(int_0)
    obj_0.module_docs('module')
    obj_0.module_docs('module')
    obj_0.module_docs('module')
    obj_0.module_docs('module')
    obj_0.module_docs('module')
    obj_0.module_docs('module')
# Commented out for now--foo and modules are not in the test runner
#    obj_0 =

# Generated at 2022-06-24 17:47:14.347064
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    int_0 = 1221
    doc_c_l_i_0 = DocCLI(int_0)
    str_0 = 'test'
    str_1 = 'module_documentation'
    dict_0 = doc_c_l_i_0.find_plugins(str_0, str_1)
    print(dict_0)
    #assert dict_0 == True


# Generated at 2022-06-24 17:47:20.439916
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Unit test for method get_plugin_metadata of class DocCLI
    # set up
    #
    # test
    #
    # teardown
    plugin_metadata_dict_0 = DocCLI.get_plugin_metadata()
    assert(isinstance(plugin_metadata_dict_0, dict))
    assert(len(plugin_metadata_dict_0) > 0)


# Generated at 2022-06-24 17:47:29.226473
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc_c_l_i_0 = DocCLI()

    # Case when the argument is of type str
    str_0 = "AI"
    doc_c_l_i_0.find_plugins(str_0)

    # Case when the argument is of type str
    str_0 = "AI"
    doc_c_l_i_0.find_plugins(str_0)

    # Case when the argument is of type str
    str_0 = "AI"
    doc_c_l_i_0.find_plugins(str_0)

    # Case when the argument is of type str
    str_0 = "AI"
    doc_c_l_i_0.find_plugins(str_0)

    # Case when the argument is of type str
    str_0 = "AI"
    doc_

# Generated at 2022-06-24 17:47:31.670683
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    my_array = [1, 2, 3]
    my_value = 3
    result = doc_c_l_i_0.add_fields(my_array, my_value, 80, "        ")
    # verify the result


# Generated at 2022-06-24 17:47:46.388723
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    int_0 = 80
    doc_c_l_i_0 = DocCLI(int_0)
    str_0 = '''
- name: Wait for all instances to be tagged
  ec2_tag:
    region: "{{ region }}"
    resource: "{{ item }}"
    state: present
    tags:
      Name: "{{ name }}"
  with_items: "{{ reservations.instances }}"
  register: ec2
  until: ec2 is success
  retries: 10
  delay: 10
'''
    str_1 = doc_c_l_i_0.format_snippet(str_0)
    #assert str_1 == '''\
#- name: Wait for all instances to be tagged
#  ec2_tag:
#    region: "{{ region }}"
#

# Generated at 2022-06-24 17:50:24.665052
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test for get_plugin_metadata
    int_0 = 1221
    doc_c_l_i_0 = DocCLI(int_0)
    plugin_name_0 = "ansible/module_utils/dummy.py"

    # get_plugin_metadata with path [plugin_name_0], force_scan [False], entity_type [None]
    dict_0 = doc_c_l_i_0.get_plugin_metadata(path=plugin_name_0, entity_type=None, force_scan=False)
    # basic assertions
    if dict_0["short_description"] != 'this is a dumb module':
        raise AssertionError("'short_description' is empty in dict_0")


# Generated at 2022-06-24 17:50:30.497388
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # Reference: https://stackoverflow.com/questions/8915393/mocking-filesystem-in-python
    # To avoid "FileNotFoundError: /etc/python3.6/sitecustomize.py"
    class ReplacedModule(object):
        @staticmethod
        def _find_module(fullname, path=None):
            if fullname == 'ansible_collections':
                raise ModuleNotFoundError("{}".format(fullname))
    ReplacedModule.__name__ = 'ansible_collections'
    import sys
    sys.modules['ansible_collections'] = ReplacedModule


# Generated at 2022-06-24 17:50:36.815525
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    sequence_0 = []
    dict_0 = {'spec': {'suboptions': {'choices': ['user', 'group', 'mode', 'owner', 'secontext']}, 'description': 'The attribute to be set on files/directories.'}}
    int_0 = 70
    str_0 = '        '
    bool_0 = False
    str_1 = '        '
    DocCLI.add_fields(sequence_0, dict_0, int_0, str_0, bool_0, str_1)


# Generated at 2022-06-24 17:50:39.829273
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    int_0 = 1221
    doc_c_l_i_0 = DocCLI(int_0)



# Generated at 2022-06-24 17:50:48.524604
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-24 17:50:52.877585
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = "action"
    coll_filter = None
    add_collection_plugins(plugin_list,plugin_type,coll_filter)
    assert(plugin_list != {})


# Generated at 2022-06-24 17:50:54.625582
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():

    assert True


# Generated at 2022-06-24 17:50:58.193449
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    # Test if the function runs with add_collection_plugins() == None
    # If it runs as expected then test should be successfull.
    assert add_collection_plugins() == None


# Generated at 2022-06-24 17:51:01.712636
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    print("==================")
    print("Testing method DocCLI::get_man_text")
    test_case_0()



# Generated at 2022-06-24 17:51:13.411282
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    int_0 = 1221
    doc_c_l_i_0 = DocCLI(int_0)
    plugin_type_0 = 'example.com'
    role_0 = 'example.com'

# Generated at 2022-06-24 17:53:28.480023
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-24 17:53:35.760023
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    int_0 = 1224
    doc_c_l_i_0 = DocCLI(int_0)
    list_0 = [
        'not_a_dir',
        'one_dir',
        'second_dir'
    ]
    int_1 = 1
    doc_c_l_i_0.print_paths(list_0, int_1)


# Generated at 2022-06-24 17:53:43.826007
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Case 0
    doc_c_l_i_0 = DocCLI()
    plugin_type_0 = "module"
    plugin_name_0 = "synchronize"