

# Generated at 2022-06-16 19:54:03.523457
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    expected_result = """
> TEST_MODULE    (None)
This is a test module

OPTIONS (= is mandatory):
        test_option: This is a test option
                required: True
                type: str
"""
    assert DocCLI.get_man_text(doc) == expected_result


# Generated at 2022-06-16 19:54:12.742929
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test for method add_fields(text, data, limit, opt_indent, return_values=False, parent_indent='')
    # of class DocCLI
    # Create a copy so we don't modify the original
    data = dict(dict(name='test', description='test', options=dict(name=dict(description='test', required=True, choices=['test1', 'test2']))))
    text = []
    DocCLI.add_fields(text, data, 70, "        ")
    assert text == ['        name: test', '        description: test', '        options:', '            name:', '                description: test', '                required: True', '                choices:', '                    - test1', '                    - test2']


# Generated at 2022-06-16 19:54:13.934588
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()
    doc.display_plugin_list()


# Generated at 2022-06-16 19:54:18.201880
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'action'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list != {}


# Generated at 2022-06-16 19:54:20.580108
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    doc.get_all_plugins_of_type()


# Generated at 2022-06-16 19:54:33.665910
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Test with a module
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    output = DocCLI.format_plugin_doc(doc, 'test_module')
    assert '> TEST_MODULE' in output
    assert 'DESCRIPTION' in output
    assert 'OPTIONS' in output
    assert 'test_option' in output
    assert 'This is a test option' in output
    assert 'REQUIRED: yes' in output
    assert 'TYPE: str' in output

    # Test with a module and a collection

# Generated at 2022-06-16 19:54:45.676259
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        },
        'notes': ['This is a test note'],
        'seealso': [
            {
                'module': 'test_module',
                'description': 'This is a test seealso'
            }
        ]
    }

# Generated at 2022-06-16 19:54:56.912710
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    assert DocCLI.format_snippet('foo') == 'foo'
    assert DocCLI.format_snippet('foo\nbar') == 'foo\nbar'
    assert DocCLI.format_snippet('foo\nbar\n') == 'foo\nbar'
    assert DocCLI.format_snippet('foo\nbar\n\n') == 'foo\nbar'
    assert DocCLI.format_snippet('foo\nbar\n\n\n') == 'foo\nbar'
    assert DocCLI.format_snippet('foo\nbar\n\n\n\n') == 'foo\nbar'
    assert DocCLI.format_snippet('foo\nbar\n\n\n\n\n') == 'foo\nbar'


# Generated at 2022-06-16 19:55:09.134537
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('/home/user/ansible/lib/ansible/modules/cloud/amazon/ec2_vpc_subnet.py') == 'cloud.amazon'
    assert DocCLI.namespace_from_plugin_filepath('/home/user/ansible/lib/ansible/modules/cloud/amazon/ec2_vpc_subnet.py', 'module') == 'cloud.amazon'
    assert DocCLI.namespace_from_plugin_filepath('/home/user/ansible/lib/ansible/modules/cloud/amazon/ec2_vpc_subnet.py', 'module', 'ansible.modules') == 'cloud.amazon'

# Generated at 2022-06-16 19:55:10.096617
# Unit test for function jdump
def test_jdump():
    jdump({'foo': 'bar'})



# Generated at 2022-06-16 19:57:03.156178
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    assert DocCLI.get_man_text(doc) == '> TEST MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                required: True\n                type: str'


# Generated at 2022-06-16 19:57:13.030144
# Unit test for method run of class DocCLI

# Generated at 2022-06-16 19:57:25.234384
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test with no arguments
    cli = DocCLI()
    cli.find_plugins()
    assert cli.collection_name is None
    assert cli.plugin_type is None
    assert cli.plugin_name is None
    assert cli.plugin_args == []
    assert cli.plugin_kwargs == {}
    assert cli.plugin_list == []
    assert cli.plugin_list_name is None
    assert cli.plugin_list_type is None
    assert cli.plugin_list_path is None
    assert cli.plugin_list_collection is None
    assert cli.plugin_list_collection_name is None
    assert cli.plugin_list_collection_version is None
    assert cli.plugin_list_collection_path is None
    assert cli.plugin_list_collection

# Generated at 2022-06-16 19:57:31.727498
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    plugins = []
    DocCLI.display_plugin_list(plugins)
    # Test with one plugin
    plugins = [{'name': 'ping'}]
    DocCLI.display_plugin_list(plugins)
    # Test with multiple plugins
    plugins = [{'name': 'ping'}, {'name': 'setup'}]
    DocCLI.display_plugin_list(plugins)


# Generated at 2022-06-16 19:57:39.370799
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with empty list
    assert DocCLI.display_plugin_list([]) == None

    # Test with list of plugins
    plugins = [
        {
            'name': 'test',
            'filename': 'test.py',
            'description': 'Test plugin',
            'version_added': '2.0',
            'version_added_collection': 'test.collection'
        },
        {
            'name': 'test2',
            'filename': 'test2.py',
            'description': 'Test plugin 2',
            'version_added': '2.0'
        }
    ]
    assert DocCLI.display_plugin_list(plugins) == None


# Generated at 2022-06-16 19:57:52.101269
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test with a simple dict
    text = []
    DocCLI.add_fields(text, {'name': 'test'}, 80, '    ')
    assert text == ['    name: test']

    # Test with a dict with a list
    text = []
    DocCLI.add_fields(text, {'name': ['test1', 'test2']}, 80, '    ')
    assert text == ['    name: test1, test2']

    # Test with a dict with a dict
    text = []
    DocCLI.add_fields(text, {'name': {'test': 'test'}}, 80, '    ')
    assert text == ['    name:', '        test: test']

    # Test with a dict with a dict and a list
    text = []
    DocCLI.add_fields

# Generated at 2022-06-16 19:58:01.699888
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a module
    doc = DocCLI.get_plugin_metadata('ping')
    assert doc['name'] == 'ping'
    assert doc['filename'] == 'ping'
    assert doc['description'] == 'This module attempts to connect to the remote device and return pong on success.'
    assert doc['version_added'] == 'historical'
    assert doc['options']['data']['description'] == 'Data to return for ping.'
    assert doc['options']['data']['required'] is False
    assert doc['options']['data']['default'] == 'pong'
    assert doc['options']['data']['aliases'] == ['msg']
    assert doc['options']['data']['version_added'] == '2.0'

# Generated at 2022-06-16 19:58:05.957671
# Unit test for function jdump
def test_jdump():
    assert jdump({"a": 1, "b": 2}) == '{\n    "a": 1, \n    "b": 2\n}'



# Generated at 2022-06-16 19:58:09.172391
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    display_plugin_list(None, None)
    # Test with plugins
    display_plugin_list(None, [{'name': 'test'}])


# Generated at 2022-06-16 19:58:18.737158
# Unit test for method run of class DocCLI

# Generated at 2022-06-16 20:01:04.888439
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        },
        'return': {
            'changed': {
                'description': 'This is a test return value',
                'type': 'bool'
            }
        }
    }
    expected = """
> TEST_MODULE    (None)

This is a test module

OPTIONS (= is mandatory):
        test_option: This is a test option
                required: True
                type: str

RETURN VALUES:
        changed: This is a test return value
                type: bool
"""

# Generated at 2022-06-16 20:01:13.197294
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-16 20:01:18.190209
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test for method add_fields(text, data, limit, opt_indent, return_values=False, parent_indent='')
    # of class DocCLI
    text = []
    data = {'name': 'test', 'description': 'test description', 'options': {'name': 'test', 'description': 'test description', 'required': True, 'default': 'test', 'choices': ['test1', 'test2'], 'aliases': ['test3', 'test4']}}
    limit = 70
    opt_indent = "        "
    return_values = False
    parent_indent = ''
    DocCLI.add_fields(text, data, limit, opt_indent, return_values, parent_indent)

# Generated at 2022-06-16 20:01:26.395560
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {'description': 'This is a test module',
           'options': {'test_option': {'description': 'This is a test option',
                                       'required': True,
                                       'type': 'str'}}}
    assert DocCLI.get_man_text(doc) == '> UNKNOWN    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                required: True\n                type: str\n'


# Generated at 2022-06-16 20:01:37.759393
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Test with no args
    doc = {'description': 'This is a test', 'filename': 'test.py'}
    assert DocCLI.get_man_text(doc) == '> TEST.PY    (test.py)\nThis is a test\n'

    # Test with args
    doc = {'description': 'This is a test', 'filename': 'test.py', 'options': {'test': {'description': 'This is a test'}}}
    assert DocCLI.get_man_text(doc) == '> TEST.PY    (test.py)\nThis is a test\n\nOPTIONS (= is mandatory):\n        test: This is a test\n'

    # Test with args and collection