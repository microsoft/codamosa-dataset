

# Generated at 2022-06-16 19:54:37.791170
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = DocCLI()
    assert doc.get_plugin_metadata('module', 'setup') == {
        'name': 'setup',
        'description': 'Gather facts about remote hosts',
        'filename': 'setup.py',
        'version_added': 'historical',
        'options': {
            'filter': {
                'description': 'when supplied, only facts containing the given string will be returned',
                'required': False,
                'type': 'str'
            },
            'gather_subset': {
                'description': 'when supplied, this limits the facts returned to a given subset',
                'required': False,
                'type': 'list'
            }
        }
    }


# Generated at 2022-06-16 19:54:42.399137
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test with no args
    doc = DocCLI()
    assert doc.find_plugins() == []
    # Test with args
    doc = DocCLI(args=['-t', 'module'])
    assert doc.find_plugins() == []


# Generated at 2022-06-16 19:54:51.130777
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    doc.get_all_plugins_of_type('module')
    doc.get_all_plugins_of_type('module', 'network')
    doc.get_all_plugins_of_type('module', 'network', 'ios')
    doc.get_all_plugins_of_type('module', 'network', 'ios', 'ios_config')
    doc.get_all_plugins_of_type('module', 'network', 'ios', 'ios_config', 'ios_config.py')
    doc.get_all_plugins_of_type('module', 'network', 'ios', 'ios_config', 'ios_config.py', 'ios_config')

# Generated at 2022-06-16 19:55:03.586235
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Create a mock of class AnsibleOptions
    mock_ansible_options = mock.Mock(spec=AnsibleOptions)
    # Create a mock of class Display
    mock_display = mock.Mock(spec=Display)
    # Create a mock of class DocCLI
    mock_doc_cli = mock.Mock(spec=DocCLI)
    # Create a mock of class DocCLI
    mock_doc_cli.run.return_value = None
    # Create a mock of class DocCLI
    mock_doc_cli.run.return_value = None
    # Create a mock of class DocCLI
    mock_doc_cli.run.return_value = None
    # Create a mock of class DocCLI
    mock_doc_cli.run.return_value = None
    # Create a mock of class DocCL

# Generated at 2022-06-16 19:55:06.886353
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'module'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list != {}


# Generated at 2022-06-16 19:55:15.158119
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE


# Generated at 2022-06-16 19:55:19.105640
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'module'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list != {}



# Generated at 2022-06-16 19:55:23.068864
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'module'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list != {}


# Generated at 2022-06-16 19:55:32.816991
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 100
    opt_indent = "        "
    return_values = False

# Generated at 2022-06-16 19:55:39.805260
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    doc.get_all_plugins_of_type('module')
    doc.get_all_plugins_of_type('module', 'network')
    doc.get_all_plugins_of_type('module', 'network', 'ios')
    doc.get_all_plugins_of_type('module', 'network', 'ios', 'ios_command')
    doc.get_all_plugins_of_type('module', 'network', 'ios', 'ios_command', 'ios_command')
    doc.get_all_plugins_of_type('module', 'network', 'ios', 'ios_command', 'ios_command', 'ios_command')

# Generated at 2022-06-16 19:58:18.553408
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test with no arguments
    doc_cli = DocCLI()
    doc_cli.find_plugins()
    assert doc_cli.plugins == []
    assert doc_cli.collection_plugins == []
    assert doc_cli.roles == []
    assert doc_cli.collections == []

    # Test with a single argument
    doc_cli = DocCLI()
    doc_cli.find_plugins(['module'])
    assert doc_cli.plugins == []
    assert doc_cli.collection_plugins == []
    assert doc_cli.roles == []
    assert doc_cli.collections == []

    # Test with a single argument
    doc_cli = DocCLI()
    doc_cli.find_plugins(['module', 'ping'])
    assert doc_cli.plugins == ['ping']
    assert doc_cli

# Generated at 2022-06-16 19:58:26.807160
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Test case 1
    doc = {
        'entry_points': {
            'main': {
                'description': 'This is a test role',
                'short_description': 'This is a test role',
                'options': {
                    'test_option': {
                        'description': 'This is a test option',
                        'required': True,
                        'type': 'str'
                    }
                },
                'attributes': {
                    'test_attribute': {
                        'description': 'This is a test attribute',
                        'required': True,
                        'type': 'str'
                    }
                }
            }
        }
    }
    role = 'test_role'
    role_json = doc

# Generated at 2022-06-16 19:58:37.915313
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test with no arguments
    doc = DocCLI()
    assert doc.find_plugins() == []

    # Test with a single argument
    assert doc.find_plugins('module') == ['module']

    # Test with multiple arguments
    assert doc.find_plugins('module', 'module') == ['module']

    # Test with a single argument that is not a string
    assert doc.find_plugins(1) == []

    # Test with multiple arguments that are not strings
    assert doc.find_plugins(1, 2) == []

    # Test with a single argument that is not a valid plugin type
    assert doc.find_plugins('invalid') == []

    # Test with multiple arguments that are not valid plugin types
    assert doc.find_plugins('invalid', 'invalid') == []

    # Test with a single argument that is a valid plugin type

# Generated at 2022-06-16 19:58:40.592589
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'module'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list != {}



# Generated at 2022-06-16 19:58:43.215987
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    doc.get_all_plugins_of_type()


# Generated at 2022-06-16 19:58:51.180109
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-16 19:58:59.179306
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    assert DocCLI.format_plugin_doc(doc) == '''
> TEST_MODULE    (None)

This is a test module

OPTIONS (= is mandatory):
    test_option: This is a test option
        required: True
        type: str
'''


# Generated at 2022-06-16 19:59:02.669511
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    assert DocCLI.get_man_text(doc) == '''> TEST MODULE    (None)
This is a test module

OPTIONS (= is mandatory):
        test_option: This is a test option
            required: True
            type: str
'''


# Generated at 2022-06-16 19:59:08.032281
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    text = []
    DocCLI.add_fields(text, doc['options'], 80, '        ')
    assert text == [
        '        TEST_OPTION:',
        '            description: This is a test option',
            '            required: True',
            '            type: str'
    ]


# Generated at 2022-06-16 19:59:20.072436
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-16 20:00:28.746092
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Test for format_plugin_doc method of class DocCLI
    # Arrange
    doc = {
        'description': 'This is a test module',
        'options': {
            'name': {
                'description': 'The name of the thing'
            }
        }
    }
    expected_result = '''> TEST_MODULE    (test_module)
DESCRIPTION:
        This is a test module
OPTIONS (= is mandatory):
        name: The name of the thing
'''
    # Act
    result = DocCLI.format_plugin_doc(doc, 'test_module')
    # Assert
    assert result == expected_result


# Generated at 2022-06-16 20:00:41.094485
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a module
    module_name = 'setup'
    module_path = 'library/setup.py'
    module_doc = DocCLI.get_plugin_metadata(module_name, module_path)
    assert module_doc['name'] == module_name
    assert module_doc['filename'] == module_path
    assert module_doc['description'] == 'Gather facts about remote hosts.'
    assert module_doc['options']['filter']['description'] == 'When supplied, this argument will restrict the facts collected to a given subset.'
    assert module_doc['options']['filter']['required'] == False
    assert module_doc['options']['filter']['default'] == '*'
    assert module_doc['options']['filter']['choices'] == ['*']

# Generated at 2022-06-16 20:00:51.388716
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 80
    opt_indent = "        "
    return_values = False

# Generated at 2022-06-16 20:00:55.865140
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    plugins = []
    DocCLI.display_plugin_list(plugins)
    # Test with plugins
    plugins = [{'name': 'ping', 'filename': 'ping.py'}]
    DocCLI.display_plugin_list(plugins)


# Generated at 2022-06-16 20:01:02.620003
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    plugins = []
    DocCLI.display_plugin_list(plugins)
    # Test with plugins
    plugins = [
        {'name': 'ping', 'filename': 'ping.py'},
        {'name': 'copy', 'filename': 'copy.py'},
        {'name': 'service', 'filename': 'service.py'}
    ]
    DocCLI.display_plugin_list(plugins)


# Generated at 2022-06-16 20:01:09.671131
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc = {
        'description': 'This is a test role',
        'entry_points': {
            'main': {
                'short_description': 'This is the main entry point',
                'description': 'This is the main entry point description',
                'options': {
                    'test_option': {
                        'description': 'This is a test option',
                        'required': True,
                        'type': 'str'
                    }
                },
                'attributes': {
                    'test_attribute': {
                        'description': 'This is a test attribute',
                        'type': 'str'
                    }
                }
            }
        }
    }
    role = 'test_role'

# Generated at 2022-06-16 20:01:15.490868
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('/path/to/plugins/action/foo.py') == 'action'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/plugins/action/foo/bar.py') == 'action'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/plugins/action/foo/bar/baz.py') == 'action'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/plugins/action/foo/bar/baz/qux.py') == 'action'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/plugins/action/foo/bar/baz/qux/quux.py') == 'action'
    assert Doc

# Generated at 2022-06-16 20:01:25.132664
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    assert DocCLI.get_man_text(doc) == '> TEST MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                type: str\n                required: True\n'


# Generated at 2022-06-16 20:01:26.296510
# Unit test for function jdump
def test_jdump():
    assert jdump(dict(a=1, b=2)) == '{\n    "a": 1,\n    "b": 2\n}'

