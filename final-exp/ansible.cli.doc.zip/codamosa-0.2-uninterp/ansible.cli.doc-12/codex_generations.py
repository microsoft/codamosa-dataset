

# Generated at 2022-06-16 19:53:28.289879
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-16 19:53:39.602078
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Test with a module
    doc = {
        'module': 'test_module',
        'short_description': 'Test module',
        'description': 'Test module',
        'options': {
            'test_option': {
                'description': 'Test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    expected = '''
> TEST_MODULE    (test_module)

Test module

OPTIONS (= is mandatory):

        test_option:
                description: Test option
                required: True
                type: str
'''
    assert DocCLI.format_plugin_doc(doc) == expected

    # Test with a module and a collection

# Generated at 2022-06-16 19:53:46.529365
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Test with a module
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    result = DocCLI.format_plugin_doc(doc, 'test_module')
    assert result == '''> TEST_MODULE    (None)
DESCRIPTION:
    This is a test module
OPTIONS (= is mandatory):
    test_option:
        description: This is a test option
        required: True
        type: str
'''

    # Test with a module and a collection

# Generated at 2022-06-16 19:53:48.891076
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = DocCLI()
    doc.get_plugin_metadata()


# Generated at 2022-06-16 19:53:59.480670
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    """
    Test get_plugin_metadata
    """
    # Test with a module
    plugin_type = 'module'
    plugin_name = 'copy'
    plugin_path = 'lib/ansible/modules/files/copy.py'
    plugin_data = DocCLI.get_plugin_metadata(plugin_type, plugin_name, plugin_path)
    assert plugin_data['name'] == 'copy'
    assert plugin_data['filename'] == 'lib/ansible/modules/files/copy.py'
    assert plugin_data['docuri'] == 'doc/modules/copy_module.html'
    assert plugin_data['doc'] == 'Copies files to remote locations.'
    assert plugin_data['version_added'] == '1.1'
    assert plugin_data['version_added_collection'] is None
    assert plugin

# Generated at 2022-06-16 19:54:06.798014
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    plugins = []
    DocCLI.display_plugin_list(plugins)
    # Test with plugins
    plugins = [
        {
            'name': 'test_plugin',
            'filename': 'test_plugin.py',
            'description': 'Test plugin',
            'version_added': '2.0',
            'version_added_collection': 'ansible.builtin',
        }
    ]
    DocCLI.display_plugin_list(plugins)


# Generated at 2022-06-16 19:54:13.329046
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    assert DocCLI.get_man_text(doc) == '> TEST MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                required: True\n                type: str\n'


# Generated at 2022-06-16 19:54:22.043184
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    plugins = []
    DocCLI.display_plugin_list(plugins)
    # Test with plugins
    plugins = [
        {
            "name": "test_plugin",
            "filename": "test_plugin.py",
            "description": "Test plugin",
            "version_added": "2.4"
        }
    ]
    DocCLI.display_plugin_list(plugins)


# Generated at 2022-06-16 19:54:35.189143
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Create a mock object for the class DocCLI
    mock_DocCLI = mock.Mock(spec=DocCLI)
    # Create a mock object for the class display
    mock_display = mock.Mock(spec=display)
    # Assign the mock object to the class display
    DocCLI.display = mock_display
    # Create a mock object for the class DocCLI.get_man_text
    mock_DocCLI_get_man_text = mock.Mock(spec=DocCLI.get_man_text)
    # Assign the mock object to the class DocCLI.get_man_text
    DocCLI.get_man_text = mock_DocCLI_get_man_text
    # Create a mock object for the class DocCLI.get_role_man_text
    mock_Doc

# Generated at 2022-06-16 19:54:42.820920
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test with no arguments
    assert DocCLI.find_plugins() == []
    # Test with an invalid argument
    assert DocCLI.find_plugins(module_name='invalid') == []
    # Test with a valid argument
    assert DocCLI.find_plugins(module_name='setup') == [
        {'filename': 'setup.py', 'name': 'setup', 'path': 'lib/ansible/modules/system/setup.py'}
    ]


# Generated at 2022-06-16 19:56:43.317889
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # Test with empty string
    assert DocCLI.format_snippet('') == ''

    # Test with simple string
    assert DocCLI.format_snippet('Hello') == 'Hello'

    # Test with string containing newline
    assert DocCLI.format_snippet('Hello\nWorld') == 'Hello\nWorld'

    # Test with string containing tab
    assert DocCLI.format_snippet('Hello\tWorld') == 'Hello\tWorld'

    # Test with string containing backslash
    assert DocCLI.format_snippet('Hello\\World') == 'Hello\\World'

    # Test with string containing backslash and newline
    assert DocCLI.format_snippet('Hello\\\nWorld') == 'Hello\\\nWorld'

    # Test with string containing backslash

# Generated at 2022-06-16 19:56:51.118569
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Test with no arguments
    args = []
    with pytest.raises(SystemExit):
        DocCLI(args).run()

    # Test with invalid module
    args = ['invalid_module']
    with pytest.raises(SystemExit):
        DocCLI(args).run()

    # Test with valid module
    args = ['setup']
    DocCLI(args).run()

    # Test with valid module and --help
    args = ['setup', '--help']
    DocCLI(args).run()

    # Test with valid module and -h
    args = ['setup', '-h']
    DocCLI(args).run()

    # Test with valid module and --version
    args = ['setup', '--version']
    DocCLI(args).run()

    # Test with valid module and -v

# Generated at 2022-06-16 19:57:03.358925
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 80
    opt_indent = "        "
    return_values = False

# Generated at 2022-06-16 19:57:11.664772
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    assert DocCLI.get_man_text(doc) == '> TEST MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                Choices: (null)\n                Default: (null)\n                Required: True\n                Type: str\n'

# Generated at 2022-06-16 19:57:24.397326
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Test with no arguments
    with pytest.raises(SystemExit):
        DocCLI(args=['ansible-doc']).run()

    # Test with an invalid plugin type
    with pytest.raises(SystemExit):
        DocCLI(args=['ansible-doc', '-t', 'invalid']).run()

    # Test with an invalid plugin name
    with pytest.raises(SystemExit):
        DocCLI(args=['ansible-doc', 'invalid']).run()

    # Test with a valid plugin name
    with pytest.raises(SystemExit):
        DocCLI(args=['ansible-doc', 'ping']).run()

    # Test with a valid plugin name and type

# Generated at 2022-06-16 19:57:34.875602
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Test with a role that has no entry points
    role_json = {
        'path': '/path/to/role',
        'entry_points': {},
    }
    assert DocCLI.get_role_man_text('role_name', role_json) == [
        '> ROLE_NAME    (/path/to/role)',
    ]

    # Test with a role that has entry points

# Generated at 2022-06-16 19:57:42.071083
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('/path/to/plugins/module_utils/foo.py') == 'module_utils.foo'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/plugins/modules/foo.py') == 'modules.foo'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/plugins/modules/foo/bar.py') == 'modules.foo.bar'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/plugins/modules/foo/bar/baz.py') == 'modules.foo.bar.baz'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/plugins/modules/foo/bar/baz/quux.py')

# Generated at 2022-06-16 19:57:43.395273
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    DocCLI.find_plugins()


# Generated at 2022-06-16 19:57:55.537038
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc = {
        "name": "test",
        "path": "test",
        "entry_points": {
            "main": {
                "short_description": "test",
                "description": "test",
                "options": {
                    "test": {
                        "description": "test",
                        "required": True,
                        "type": "str"
                    }
                },
                "attributes": {
                    "test": {
                        "description": "test",
                        "required": True,
                        "type": "str"
                    }
                }
            }
        }
    }

# Generated at 2022-06-16 19:58:02.312974
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Test with no arguments
    with pytest.raises(SystemExit):
        DocCLI().run()

    # Test with --help
    with pytest.raises(SystemExit):
        DocCLI(['--help']).run()

    # Test with --version
    with pytest.raises(SystemExit):
        DocCLI(['--version']).run()

    # Test with --help-json
    with pytest.raises(SystemExit):
        DocCLI(['--help-json']).run()

    # Test with --man
    with pytest.raises(SystemExit):
        DocCLI(['--man']).run()

    # Test with --man-json
    with pytest.raises(SystemExit):
        DocCLI(['--man-json']).run()

    # Test with