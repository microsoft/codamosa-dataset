

# Generated at 2022-06-16 19:54:36.852349
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Test with empty plugin_type
    with pytest.raises(AnsibleOptionsError):
        DocCLI.get_all_plugins_of_type('')

    # Test with invalid plugin_type
    with pytest.raises(AnsibleOptionsError):
        DocCLI.get_all_plugins_of_type('invalid')

    # Test with valid plugin_type
    assert DocCLI.get_all_plugins_of_type('module')


# Generated at 2022-06-16 19:54:45.520846
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    text = DocCLI.get_man_text(doc)
    assert text == '> TEST MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                required: True\n                type: str\n'


# Generated at 2022-06-16 19:54:48.263313
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'action'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list != {}



# Generated at 2022-06-16 19:54:55.691525
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-16 19:55:03.265467
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    doc = DocCLI()
    doc.display_plugin_list([])
    assert True

    # Test with one plugin
    doc = DocCLI()
    doc.display_plugin_list(['ping'])
    assert True

    # Test with multiple plugins
    doc = DocCLI()
    doc.display_plugin_list(['ping', 'setup'])
    assert True


# Generated at 2022-06-16 19:55:13.108536
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc = {
        'description': 'This is a test',
        'entry_points': {
            'main': {
                'short_description': 'This is a test',
                'description': 'This is a test',
                'options': {
                    'test': {
                        'description': 'This is a test',
                        'required': True,
                        'type': 'str'
                    }
                },
                'attributes': {
                    'test': {
                        'description': 'This is a test',
                        'required': True,
                        'type': 'str'
                    }
                }
            }
        }
    }

# Generated at 2022-06-16 19:55:26.674821
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()

# Generated at 2022-06-16 19:55:35.093381
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # Test with a filepath that should return a namespace
    filepath = 'lib/ansible/modules/cloud/amazon/ec2_vpc_subnet.py'
    expected = 'cloud.amazon'
    actual = DocCLI.namespace_from_plugin_filepath(filepath)
    assert actual == expected
    # Test with a filepath that should return None
    filepath = 'lib/ansible/modules/cloud/amazon/__init__.py'
    expected = None
    actual = DocCLI.namespace_from_plugin_filepath(filepath)
    assert actual == expected


# Generated at 2022-06-16 19:55:37.330732
# Unit test for function jdump
def test_jdump():
    assert jdump({'a': 'b'}) == '{\n    "a": "b"\n}'



# Generated at 2022-06-16 19:55:41.858785
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Test with a valid plugin type
    assert DocCLI.get_all_plugins_of_type('action')
    # Test with an invalid plugin type
    assert not DocCLI.get_all_plugins_of_type('invalid_plugin_type')


# Generated at 2022-06-16 19:56:44.242150
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {'description': 'This is a test module', 'options': {'test_option': {'description': 'This is a test option', 'required': True}}}
    assert DocCLI.get_man_text(doc) == '> TEST MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                required: True'


# Generated at 2022-06-16 19:56:51.612775
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Test with no options
    args = []
    options = DocCLI.parse()
    assert DocCLI.run(args, options) == 0
    # Test with --help
    args = ['--help']
    options = DocCLI.parse()
    assert DocCLI.run(args, options) == 0
    # Test with --version
    args = ['--version']
    options = DocCLI.parse()
    assert DocCLI.run(args, options) == 0
    # Test with --help-json
    args = ['--help-json']
    options = DocCLI.parse()
    assert DocCLI.run(args, options) == 0
    # Test with --help-yaml
    args = ['--help-yaml']
    options = DocCLI.parse()
    assert DocCLI.run

# Generated at 2022-06-16 19:57:03.457861
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test with no arguments
    result = DocCLI.find_plugins()
    assert result is not None
    assert isinstance(result, list)
    assert len(result) > 0
    assert isinstance(result[0], dict)
    assert 'name' in result[0]
    assert 'path' in result[0]
    assert 'doc' in result[0]
    assert 'docuri' in result[0]
    assert 'type' in result[0]
    assert 'version_added' in result[0]
    assert 'version_added_collection' in result[0]
    assert 'deprecated' in result[0]
    assert 'removed_at_date' in result[0]
    assert 'removed_in' in result[0]
    assert 'why' in result[0]

# Generated at 2022-06-16 19:57:13.191757
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS

# Generated at 2022-06-16 19:57:25.457699
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Test 1
    doc = {
        "name": "test",
        "path": "/path/to/test",
        "entry_points": {
            "main": {
                "short_description": "test",
                "description": "test",
                "options": {
                    "test_option": {
                        "description": "test",
                        "required": True,
                        "type": "str",
                        "default": "test"
                    }
                },
                "attributes": {
                    "test_attribute": {
                        "description": "test",
                        "type": "str",
                        "default": "test"
                    }
                }
            }
        }
    }

# Generated at 2022-06-16 19:57:29.079409
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    from ansible.utils.display import Display
    display = Display()
    display.columns = 80
    doc = DocCLI(display)
    doc.display_plugin_list(['ping'], 'module', 'ping')


# Generated at 2022-06-16 19:57:34.017050
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no args
    doc = DocCLI()
    with pytest.raises(SystemExit):
        doc.display_plugin_list()
    # Test with args
    doc = DocCLI(args=['-l'])
    with pytest.raises(SystemExit):
        doc.display_plugin_list()


# Generated at 2022-06-16 19:57:41.561099
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Test with a role that has no entry points
    role_json = {
        'path': 'test_path',
        'entry_points': {}
    }
    text = DocCLI.get_role_man_text('test_role', role_json)
    assert text == ['> TEST_ROLE    (test_path)\n']

    # Test with a role that has entry points

# Generated at 2022-06-16 19:57:45.501262
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'module'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list != {}


# Generated at 2022-06-16 19:57:56.928726
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-16 19:59:53.167101
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a module
    module_name = 'setup'
    module_path = 'library/setup.py'
    module_doc = DocCLI.get_plugin_metadata(module_name, module_path)
    assert module_doc['name'] == 'setup'
    assert module_doc['filename'] == 'library/setup.py'
    assert module_doc['description'] == 'Gather facts about remote hosts.'
    assert module_doc['version_added'] == 'historical'

# Generated at 2022-06-16 19:59:56.802513
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'module'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list != {}



# Generated at 2022-06-16 20:00:06.689974
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test with no arguments
    text = []
    DocCLI.add_fields(text)
    assert text == []

    # Test with empty options
    text = []
    DocCLI.add_fields(text, {})
    assert text == []

    # Test with options
    text = []
    DocCLI.add_fields(text, {'test': {'description': 'Test description'}})
    assert text == ['        test: Test description']

    # Test with options and suboptions
    text = []
    DocCLI.add_fields(text, {'test': {'description': 'Test description', 'suboptions': {'test2': {'description': 'Test2 description'}}}})

# Generated at 2022-06-16 20:00:10.557415
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test for method add_fields(text, data, limit, opt_indent, return_values=False, parent_indent='')
    # This method is not unit tested as it is a static method and it is not possible to mock input parameters
    pass


# Generated at 2022-06-16 20:00:17.670508
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a module
    module_name = 'copy'
    module_path = '%s/%s.py' % (os.path.dirname(__file__), module_name)
    module_doc = DocCLI.get_plugin_metadata(module_path, 'module')
    assert module_doc['name'] == module_name
    assert module_doc['filename'] == module_path
    assert module_doc['description'] == 'Copies files to remote locations.'
    assert module_doc['options']['dest']['description'] == 'Remote absolute path where the file should be copied to.'
    assert module_doc['options']['dest']['required'] is True
    assert module_doc['options']['dest']['type'] == 'path'

# Generated at 2022-06-16 20:00:25.282274
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    assert DocCLI.get_man_text(doc) == '> TEST MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                required: True\n                type: str\n'


# Generated at 2022-06-16 20:00:31.754685
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Test with a module
    doc = {
        'module': 'test',
        'description': 'This is a test module',
        'options': {
            'test': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        },
        'return': {
            'changed': {
                'description': 'This is a test return value',
                'type': 'bool'
            }
        }
    }
    text = DocCLI.get_man_text(doc)

# Generated at 2022-06-16 20:00:43.080326
# Unit test for method find_plugins of class DocCLI

# Generated at 2022-06-16 20:00:48.563453
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test with no args
    assert DocCLI.find_plugins() == []
    # Test with invalid args
    assert DocCLI.find_plugins(['invalid']) == []
    # Test with valid args
    assert DocCLI.find_plugins(['action']) == ['setup']
    # Test with valid args
    assert DocCLI.find_plugins(['module']) == ['ping']


# Generated at 2022-06-16 20:00:56.847925
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    assert DocCLI.get_man_text(doc) == '> TEST_MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                required: True\n                type: str\n'
