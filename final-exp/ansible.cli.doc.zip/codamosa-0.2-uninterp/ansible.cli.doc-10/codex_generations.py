

# Generated at 2022-06-16 19:54:48.623043
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Test with no arguments
    with pytest.raises(SystemExit):
        DocCLI(args=['ansible-doc']).run()

    # Test with invalid argument
    with pytest.raises(SystemExit):
        DocCLI(args=['ansible-doc', 'invalid']).run()

    # Test with invalid module
    with pytest.raises(SystemExit):
        DocCLI(args=['ansible-doc', 'invalid_module']).run()

    # Test with invalid module
    with pytest.raises(SystemExit):
        DocCLI(args=['ansible-doc', 'invalid_module']).run()

    # Test with invalid module

# Generated at 2022-06-16 19:55:00.349754
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Test with a module
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    result = DocCLI.format_plugin_doc(doc, 'module', 'test_module')
    assert result == '''
> TEST_MODULE    (None)

This is a test module

OPTIONS (= is mandatory):
    test_option:
        description: This is a test option
        required: True
        type: str
'''

    # Test with a module and a collection

# Generated at 2022-06-16 19:55:11.569981
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test with no arguments
    assert DocCLI.find_plugins() == []
    # Test with a single argument
    assert DocCLI.find_plugins('module') == []
    # Test with a single argument
    assert DocCLI.find_plugins('module', 'ping') == []
    # Test with a single argument
    assert DocCLI.find_plugins('module', 'ping', 'ping') == []
    # Test with a single argument
    assert DocCLI.find_plugins('module', 'ping', 'ping', 'ping') == []
    # Test with a single argument
    assert DocCLI.find_plugins('module', 'ping', 'ping', 'ping', 'ping') == []
    # Test with a single argument

# Generated at 2022-06-16 19:55:24.353585
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc = {
        'description': 'This is a test role',
        'entry_points': {
            'main': {
                'short_description': 'This is a test role',
                'description': 'This is a test role',
                'options': {
                    'test_option': {
                        'description': 'This is a test option',
                        'required': True,
                        'type': 'str'
                    }
                },
                'attributes': {
                    'test_attribute': {
                        'description': 'This is a test attribute',
                        'required': True,
                        'type': 'str'
                    }
                }
            }
        }
    }
    role = 'test_role'

# Generated at 2022-06-16 19:55:31.741916
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    assert DocCLI.get_man_text(doc) == '> TEST MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                required: True\n                type: str'


# Generated at 2022-06-16 19:55:33.634506
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    doc.get_all_plugins_of_type()


# Generated at 2022-06-16 19:55:38.484409
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with a valid plugin list
    plugin_list = ['module_utils', 'modules', 'callback_plugins', 'connection_plugins', 'filter_plugins', 'inventory_plugins', 'lookup_plugins', 'shell_plugins', 'strategy_plugins', 'test_plugins', 'vars_plugins']
    DocCLI.display_plugin_list(plugin_list)
    # Test with an empty plugin list
    plugin_list = []
    DocCLI.display_plugin_list(plugin_list)


# Generated at 2022-06-16 19:55:51.610544
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Test with valid plugin type
    plugin_type = 'action'
    plugins = DocCLI.get_all_plugins_of_type(plugin_type)
    assert len(plugins) > 0
    assert isinstance(plugins, list)
    assert isinstance(plugins[0], string_types)
    # Test with invalid plugin type
    plugin_type = 'invalid'
    plugins = DocCLI.get_all_plugins_of_type(plugin_type)
    assert len(plugins) == 0
    assert isinstance(plugins, list)
    # Test with None plugin type
    plugin_type = None
    plugins = DocCLI.get_all_plugins_of_type(plugin_type)
    assert len(plugins) == 0
    assert isinstance(plugins, list)


# Generated at 2022-06-16 19:56:01.167906
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    expected_output = """
> TEST MODULE    (None)
This is a test module

OPTIONS (= is mandatory):
    test_option: This is a test option
        required: True
        type: str
"""
    assert DocCLI.get_man_text(doc) == expected_output


# Generated at 2022-06-16 19:56:05.277539
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    plugins = {}
    DocCLI.display_plugin_list(plugins)
    # Test with plugins
    plugins = {'module': {'test': {'filename': 'test.py', 'name': 'test'}}}
    DocCLI.display_plugin_list(plugins)


# Generated at 2022-06-16 19:57:33.675494
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 70
    opt_indent = "        "
    return_values = False
    opt = {'description': 'The name of the user to create',
           'required': True,
           'aliases': ['name'],
           'version_added': '2.4',
           'version_added_collection': 'community.general'}
    DocCLI.add_fields(text, opt, limit, opt_indent, return_values)
    assert text == ['        description: The name of the user to create',
                    '        required: True',
                    '        aliases: [name]',
                    '        added in: Ansible 2.4 (community.general)']


# Generated at 2022-06-16 19:57:41.401995
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Test with no args
    args = []
    doc = DocCLI(args)
    doc.run()
    assert doc.args == []
    assert doc.options == {'type': 'module'}
    assert doc.collection_name is None
    assert doc.plugin_type is None
    assert doc.plugin_name is None
    assert doc.plugin_list is None
    assert doc.plugin_list_type is None
    assert doc.plugin_list_name is None
    assert doc.plugin_list_path is None
    assert doc.plugin_list_version is None
    assert doc.plugin_list_author is None
    assert doc.plugin_list_license is None
    assert doc.plugin_list_description is None
    assert doc.plugin_list_short_description is None
    assert doc.plugin_list_deprecated

# Generated at 2022-06-16 19:57:47.061418
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    plugins = []
    DocCLI.display_plugin_list(plugins)
    # Test with plugins
    plugins = [{'name': 'ping', 'filename': 'ping.py'}]
    DocCLI.display_plugin_list(plugins)


# Generated at 2022-06-16 19:57:55.504484
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    plugins = []
    DocCLI.display_plugin_list(plugins)
    # Test with one plugin
    plugins = [{'name': 'ping', 'path': 'path/to/ping'}]
    DocCLI.display_plugin_list(plugins)
    # Test with multiple plugins
    plugins = [{'name': 'ping', 'path': 'path/to/ping'}, {'name': 'ping', 'path': 'path/to/ping'}]
    DocCLI.display_plugin_list(plugins)


# Generated at 2022-06-16 19:58:02.083118
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    expected_output = '''> TEST MODULE    (None)
        This is a test module

OPTIONS (= is mandatory):
        test_option: This is a test option
            required: yes
            type: str
'''
    assert DocCLI.get_man_text(doc) == expected_output


# Generated at 2022-06-16 19:58:08.905236
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    plugins = []
    DocCLI.display_plugin_list(plugins)
    # Test with plugins
    plugins = [
        {'name': 'ping', 'filename': 'ping.py'},
        {'name': 'setup', 'filename': 'setup.py'}
    ]
    DocCLI.display_plugin_list(plugins)


# Generated at 2022-06-16 19:58:16.609788
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test with no arguments
    # This should return a list of all plugins
    assert DocCLI.find_plugins()

    # Test with a single argument
    # This should return a list of all plugins of the specified type
    assert DocCLI.find_plugins('module')

    # Test with a list of arguments
    # This should return a list of all plugins of the specified types
    assert DocCLI.find_plugins(['module', 'lookup'])

    # Test with an invalid argument
    # This should return an empty list
    assert not DocCLI.find_plugins('invalid')


# Generated at 2022-06-16 19:58:19.931361
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    assert doc.get_all_plugins_of_type('module') == ['ping', 'setup', 'user']


# Generated at 2022-06-16 19:58:27.148324
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-16 19:58:35.884860
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    assert DocCLI.get_man_text(doc) == '> TEST MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                required: True\n                type: str\n'


# Generated at 2022-06-16 19:59:46.307199
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-16 19:59:53.757458
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('/home/user/ansible/lib/ansible/modules/cloud/amazon/ec2_vpc_subnet.py') == 'cloud.amazon'
    assert DocCLI.namespace_from_plugin_filepath('/home/user/ansible/lib/ansible/modules/cloud/amazon/ec2_vpc_subnet.py', 'module') == 'cloud.amazon.ec2_vpc_subnet'
    assert DocCLI.namespace_from_plugin_filepath('/home/user/ansible/lib/ansible/modules/cloud/amazon/ec2_vpc_subnet.py', 'module', 'ansible.modules') == 'cloud.amazon.ec2_vpc_subnet'
    assert DocCLI.namespace_from

# Generated at 2022-06-16 20:00:02.841737
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Test with valid plugin type
    plugins_of_type = DocCLI.get_all_plugins_of_type('module')
    assert plugins_of_type
    assert isinstance(plugins_of_type, list)
    assert len(plugins_of_type) > 0
    assert isinstance(plugins_of_type[0], string_types)

    # Test with invalid plugin type
    plugins_of_type = DocCLI.get_all_plugins_of_type('invalid_plugin_type')
    assert not plugins_of_type
    assert isinstance(plugins_of_type, list)
    assert len(plugins_of_type) == 0


# Generated at 2022-06-16 20:00:04.085882
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()
    doc.display_plugin_list()


# Generated at 2022-06-16 20:00:06.487222
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    doc.get_all_plugins_of_type('module')


# Generated at 2022-06-16 20:00:15.264238
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a valid plugin type
    plugin_type = 'action'
    plugin_name = 'setup'
    plugin_path = 'setup'
    plugin_metadata = DocCLI.get_plugin_metadata(plugin_type, plugin_name, plugin_path)
    assert plugin_metadata['name'] == 'setup'
    assert plugin_metadata['type'] == 'action'
    assert plugin_metadata['path'] == 'setup'
    assert plugin_metadata['filename'] == 'setup.py'
    assert plugin_metadata['docuri'] == 'action_plugin.html#setup'
    assert plugin_metadata['doc'] == 'setup'
    assert plugin_metadata['doclink'] == 'http://docs.ansible.com/ansible/latest/action_plugin.html#setup'

# Generated at 2022-06-16 20:00:24.047455
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True
            }
        }
    }
    text = DocCLI.get_man_text(doc)
    assert text == '> TEST MODULE    (None)\n\nThis is a test module\n\nOPTIONS (= is mandatory):\n\n        test_option\n            This is a test option\n            required: True\n'

# Generated at 2022-06-16 20:00:35.443172
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-16 20:00:47.195109
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Test with no arguments
    with pytest.raises(SystemExit):
        DocCLI(args=['ansible-doc']).run()

    # Test with an invalid module
    with pytest.raises(SystemExit):
        DocCLI(args=['ansible-doc', 'invalid_module']).run()

    # Test with a valid module
    DocCLI(args=['ansible-doc', 'ping']).run()

    # Test with a valid module and a collection
    DocCLI(args=['ansible-doc', 'ping', 'ansible.builtin']).run()

    # Test with a valid module and an invalid collection
    with pytest.raises(SystemExit):
        DocCLI(args=['ansible-doc', 'ping', 'invalid_collection']).run()

    # Test with

# Generated at 2022-06-16 20:00:56.000406
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Test with a valid plugin type
    plugin_type = 'action'
    plugins = DocCLI.get_all_plugins_of_type(plugin_type)
    assert len(plugins) > 0
    assert isinstance(plugins, list)
    assert all(isinstance(plugin, string_types) for plugin in plugins)

    # Test with an invalid plugin type
    plugin_type = 'invalid'
    plugins = DocCLI.get_all_plugins_of_type(plugin_type)
    assert len(plugins) == 0
    assert isinstance(plugins, list)
