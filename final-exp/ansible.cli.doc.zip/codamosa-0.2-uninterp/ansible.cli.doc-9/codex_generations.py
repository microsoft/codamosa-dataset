

# Generated at 2022-06-16 19:54:26.257760
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Test with no arguments
    DocCLI.print_paths()
    # Test with arguments
    DocCLI.print_paths(['/path/to/ansible/modules/', '/path/to/ansible/plugins/'])


# Generated at 2022-06-16 19:54:38.752306
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    cli = DocCLI()
    role = 'test_role'
    role_json = {
        'entry_points': {
            'main': {
                'short_description': 'Test role',
                'description': 'Test role description',
                'options': {
                    'test_option': {
                        'description': 'Test option description',
                        'required': True,
                        'type': 'str'
                    }
                },
                'attributes': {
                    'test_attribute': {
                        'description': 'Test attribute description',
                        'type': 'str'
                    }
                }
            }
        }
    }

# Generated at 2022-06-16 19:54:47.496157
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    expected = '''> TEST_MODULE    (None)
DESCRIPTION:
    This is a test module
OPTIONS (= is mandatory):
    test_option:
        description: This is a test option
        required: True
        type: str
'''
    assert DocCLI.format_plugin_doc(doc, 'test_module') == expected


# Generated at 2022-06-16 19:54:59.041630
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Test with empty doc
    doc = {}
    assert DocCLI.format_plugin_doc(doc) == ''

    # Test with doc containing only name
    doc = {'name': 'test_module'}
    assert DocCLI.format_plugin_doc(doc) == ''

    # Test with doc containing name and description
    doc = {'name': 'test_module', 'description': 'Test module'}
    assert DocCLI.format_plugin_doc(doc) == 'Test module'

    # Test with doc containing name, description and options
    doc = {'name': 'test_module', 'description': 'Test module', 'options': {'test_option': {'description': 'Test option'}}}

# Generated at 2022-06-16 19:55:01.336999
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc_cli = DocCLI()
    doc_cli.display_plugin_list()


# Generated at 2022-06-16 19:55:12.231950
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc = {
        'description': 'This is a test role',
        'entry_points': {
            'main': {
                'description': 'This is a test entry point',
                'options': {
                    'foo': {
                        'description': 'This is a test option',
                        'required': True,
                        'type': 'str'
                    }
                }
            }
        }
    }

# Generated at 2022-06-16 19:55:16.228237
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'action'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list != {}


# Generated at 2022-06-16 19:55:27.769862
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    assert DocCLI.format_snippet('foo') == 'foo'
    assert DocCLI.format_snippet('foo\nbar') == 'foo\nbar'
    assert DocCLI.format_snippet('foo\nbar\nbaz') == 'foo\nbar\nbaz'
    assert DocCLI.format_snippet('foo\nbar\nbaz\n') == 'foo\nbar\nbaz\n'
    assert DocCLI.format_snippet('foo\nbar\nbaz\n\n') == 'foo\nbar\nbaz\n\n'
    assert DocCLI.format_snippet('foo\nbar\nbaz\n\n\n') == 'foo\nbar\nbaz\n\n\n'
    assert DocCLI.format

# Generated at 2022-06-16 19:55:33.407604
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    plugins = []
    DocCLI.display_plugin_list(plugins)
    # Test with one plugin
    plugins = [{'name': 'test_plugin'}]
    DocCLI.display_plugin_list(plugins)
    # Test with multiple plugins
    plugins = [{'name': 'test_plugin1'}, {'name': 'test_plugin2'}]
    DocCLI.display_plugin_list(plugins)

# Generated at 2022-06-16 19:55:39.038934
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }

    expected = """
> TEST_MODULE    (None)

This is a test module

OPTIONS (= is mandatory):
        test_option:
            description: This is a test option
            required: True
            type: str
"""
    assert DocCLI.format_plugin_doc('test_module', doc) == expected


# Generated at 2022-06-16 19:56:42.993054
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test with no args
    doc = DocCLI()
    assert doc.find_plugins() == []

    # Test with args
    doc = DocCLI(['-t', 'module'])
    assert doc.find_plugins() == []

    # Test with args
    doc = DocCLI(['-t', 'module', '-l'])
    assert doc.find_plugins() == []

    # Test with args
    doc = DocCLI(['-t', 'module', '-l', '-F'])
    assert doc.find_plugins() == []

    # Test with args
    doc = DocCLI(['-t', 'module', '-l', '-F', '-v'])
    assert doc.find_plugins() == []

    # Test with args

# Generated at 2022-06-16 19:56:50.919523
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 80
    opt_indent = "        "
    return_values = False
    opt = {'description': 'This is a description',
           'required': True,
           'choices': ['one', 'two', 'three'],
           'aliases': ['alias1', 'alias2'],
           'default': 'default value',
           'version_added': '2.4',
           'version_added_collection': 'ansible.builtin'}
    DocCLI.add_fields(text, opt, limit, opt_indent, return_values)

# Generated at 2022-06-16 19:56:53.398869
# Unit test for function jdump
def test_jdump():
    assert jdump({"a": "b"}) == '{\n    "a": "b"\n}'



# Generated at 2022-06-16 19:56:55.392917
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    doc.get_all_plugins_of_type()


# Generated at 2022-06-16 19:57:08.102561
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-16 19:57:09.783979
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    doc.get_all_plugins_of_type()

# Generated at 2022-06-16 19:57:21.322486
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a module
    module_name = 'setup'
    module_path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'modules', module_name + '.py')
    module_doc = DocCLI.get_plugin_metadata(module_path, 'module')
    assert module_doc['name'] == module_name
    assert module_doc['filename'] == module_path
    assert module_doc['docuri'] == 'modules/setup_module.html'
    assert module_doc['version_added'] == 'historical'
    assert module_doc['version_added_collection'] is None

    # Test with a module from a collection
    module_name = 'setup'

# Generated at 2022-06-16 19:57:32.705119
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a module
    doc = DocCLI.get_plugin_metadata('setup')
    assert doc['module'] == 'setup'
    assert doc['filename'] == 'setup.py'
    assert doc['name'] == 'setup'
    assert doc['description'] == 'Gather facts about remote hosts'
    assert doc['version_added'] == 'historical'
    assert doc['deprecated'] == False
    assert doc['has_action'] == False

# Generated at 2022-06-16 19:57:39.474778
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    text = DocCLI.get_man_text(doc)
    assert text == '> TEST MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                Choices: None\n                Required: True\n                Type: str\n'


# Generated at 2022-06-16 19:57:52.223098
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Test with no arguments
    with pytest.raises(SystemExit):
        DocCLI().run()

    # Test with an invalid module
    with pytest.raises(SystemExit):
        DocCLI(['invalid_module']).run()

    # Test with an invalid plugin type
    with pytest.raises(SystemExit):
        DocCLI(['-t', 'invalid_plugin_type']).run()

    # Test with an invalid collection
    with pytest.raises(SystemExit):
        DocCLI(['-t', 'module', 'invalid_collection.invalid_module']).run()

    # Test with an invalid collection
    with pytest.raises(SystemExit):
        DocCLI(['-t', 'module', 'invalid_collection.invalid_module']).run()

   

# Generated at 2022-06-16 20:00:00.769952
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    result = DocCLI.format_plugin_doc(doc)
    assert result == '''> TEST_MODULE    (None)
DESCRIPTION
        This is a test module
OPTIONS (= is mandatory):
        test_option:
            description: This is a test option
            required: True
            type: str
'''


# Generated at 2022-06-16 20:00:10.355335
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a module
    plugin_type = 'module'
    plugin_name = 'setup'
    plugin_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'modules', 'system', 'setup.py')
    plugin_data = DocCLI.get_plugin_metadata(plugin_type, plugin_name, plugin_path)
    assert plugin_data['name'] == 'setup'
    assert plugin_data['filename'] == plugin_path
    assert plugin_data['description'] == 'Gathers facts about remote hosts'
    assert plugin_data['version_added'] == 'historical'

# Generated at 2022-06-16 20:00:17.552736
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-16 20:00:22.678190
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Test with a module
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        },
        'extends_documentation_fragment': ['test_fragment']
    }
    expected_output = '''
> TEST_MODULE    (test_module)
This is a test module

OPTIONS (= is mandatory):
        test_option: This is a test option
            required: True
            type: str

EXTENDS_DOCUMENTATION_FRAGMENT:
        - test_fragment
'''
    assert DocCLI.format_plugin_doc(doc, 'test_module') == expected_output

# Generated at 2022-06-16 20:00:27.337806
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    plugins = []
    DocCLI.display_plugin_list(plugins)
    # Test with plugins
    plugins = [
        {'name': 'test1', 'filename': 'test1.py'},
        {'name': 'test2', 'filename': 'test2.py'}
    ]
    DocCLI.display_plugin_list(plugins)


# Generated at 2022-06-16 20:00:40.122458
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # Test with a simple string
    assert DocCLI.format_snippet('test') == 'test'
    # Test with a string containing a newline
    assert DocCLI.format_snippet('test\n') == 'test'
    # Test with a string containing a newline and a carriage return
    assert DocCLI.format_snippet('test\r\n') == 'test'
    # Test with a string containing a newline and a carriage return
    assert DocCLI.format_snippet('test\r\n') == 'test'
    # Test with a string containing a newline and a carriage return
    assert DocCLI.format_snippet('test\r\n') == 'test'
    # Test with a string containing a newline and a carriage return
    assert DocCLI.format_snippet

# Generated at 2022-06-16 20:00:44.422439
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with empty list
    assert DocCLI.display_plugin_list([]) == ''
    # Test with list of plugins
    assert DocCLI.display_plugin_list(['plugin1', 'plugin2']) == 'plugin1, plugin2'


# Generated at 2022-06-16 20:00:52.398813
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a module
    module_name = 'setup'
    module_path = 'library/setup.py'
    module_doc = DocCLI.get_plugin_metadata(module_name, module_path)
    assert module_doc['name'] == module_name
    assert module_doc['filename'] == module_path
    assert module_doc['description'] == 'Gather facts about remote hosts'
    assert module_doc['options']['filter']['description'] == 'when supplied, only return facts that match this shell-style (fnmatch) wildcard.'
    assert module_doc['options']['filter']['required'] == False
    assert module_doc['options']['filter']['default'] == '*'
    assert module_doc['options']['filter']['choices'] == []
    assert module_

# Generated at 2022-06-16 20:01:03.102722
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a module
    plugin_type = 'module'
    plugin_name = 'setup'
    plugin_metadata = DocCLI.get_plugin_metadata(plugin_type, plugin_name)
    assert plugin_metadata['name'] == plugin_name
    assert plugin_metadata['type'] == plugin_type
    assert plugin_metadata['filename'] == 'setup.py'
    assert plugin_metadata['path'] == 'lib/ansible/modules/system/setup.py'
    assert plugin_metadata['docuri'] == 'doc/modules/system/setup.html'
    assert plugin_metadata['docfragment'] == 'module_setup'

    # Test with a module from a collection
    plugin_type = 'module'
    plugin_name = 'ansible.netcommon.network_cli'

# Generated at 2022-06-16 20:01:10.577063
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no arguments
    try:
        DocCLI.display_plugin_list()
    except SystemExit as e:
        assert e.code == 0
    # Test with invalid plugin_type
    try:
        DocCLI.display_plugin_list(plugin_type='invalid')
    except SystemExit as e:
        assert e.code == 1
    # Test with valid plugin_type
    try:
        DocCLI.display_plugin_list(plugin_type='module')
    except SystemExit as e:
        assert e.code == 0
