

# Generated at 2022-06-16 19:54:48.791674
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with a list of plugins
    plugins = [
        {'name': 'ping', 'path': '/path/to/ping'},
        {'name': 'setup', 'path': '/path/to/setup'},
        {'name': 'shell', 'path': '/path/to/shell'},
    ]
    display_plugin_list(plugins)
    # Test with a list of plugins and a list of collections
    collections = [
        {'name': 'my_collection', 'path': '/path/to/my_collection'},
        {'name': 'my_other_collection', 'path': '/path/to/my_other_collection'},
    ]
    display_plugin_list(plugins, collections)


# Generated at 2022-06-16 19:54:50.750685
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Create a mock of class DocCLI
    doc_cli = DocCLI()
    # Create a mock of class DocCLI
    doc_cli.run()


# Generated at 2022-06-16 19:55:03.160255
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test with no args
    plugins = DocCLI.find_plugins()
    assert isinstance(plugins, dict)
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins
    assert 'module' in plugins

# Generated at 2022-06-16 19:55:13.036691
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Test with a module
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    result = DocCLI.format_plugin_doc(doc, 'module')
    assert result == '''
> TEST_MODULE    (None)

This is a test module

OPTIONS (= is mandatory):
    test_option: This is a test option
        required: True
        type: str
'''

    # Test with a module and a collection

# Generated at 2022-06-16 19:55:26.591438
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test case 1
    text = []
    opt_indent = "        "
    limit = max(display.columns - int(pad), 70)
    DocCLI.add_fields(text, doc.pop('options'), limit, opt_indent)

# Generated at 2022-06-16 19:55:37.926966
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test case 1
    text = []
    limit = 80
    opt_indent = "        "
    return_values = False
    opt = {
        'description': 'The name of the user to create',
        'required': True,
        'aliases': ['name'],
        'version_added': '2.4',
        'version_added_collection': 'ansible.builtin'
    }
    DocCLI.add_fields(text, opt, limit, opt_indent, return_values)
    assert text == ['        description: The name of the user to create', '        required: True', '        aliases: name', '        added in: Ansible 2.4 (ansible.builtin collection)', '']

    # Test case 2
    text = []
    limit = 80

# Generated at 2022-06-16 19:55:50.927623
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a module
    module_path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'modules', 'system', 'setup.py')

# Generated at 2022-06-16 19:55:53.988576
# Unit test for function jdump
def test_jdump():
    assert jdump(dict(a=1, b=2)) == '{\n    "a": 1, \n    "b": 2\n}'



# Generated at 2022-06-16 19:56:02.455168
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    assert DocCLI.get_man_text(doc) == """
> TEST MODULE    (None)
This is a test module

OPTIONS (= is mandatory):
        test_option: This is a test option
            required: True
            type: str
"""


# Generated at 2022-06-16 19:56:10.248447
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        },
        'entry_points': {
            'main': {
                'description': 'This is a test entry point',
                'options': {
                    'test_option': {
                        'description': 'This is a test option',
                        'required': True,
                        'type': 'str'
                    }
                }
            }
        }
    }

# Generated at 2022-06-16 19:58:23.756960
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    doc_cli = DocCLI()
    doc_cli.display_plugin_list(None)
    # Test with plugins
    doc_cli.display_plugin_list([{'name': 'test'}])


# Generated at 2022-06-16 19:58:36.429931
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Test with a module
    test_module = {
        'name': 'test_module',
        'description': 'Test module',
        'version_added': '2.4',
        'options': {
            'test_option': {
                'description': 'Test option',
                'required': True,
                'type': 'bool',
                'default': False,
                'aliases': ['test_alias'],
                'choices': ['yes', 'no'],
                'version_added': '2.5',
                'version_added_collection': 'test_collection'
            }
        }
    }

# Generated at 2022-06-16 19:58:43.783323
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    assert DocCLI.get_man_text(doc) == '> TEST MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                required: True\n                type: str\n'


# Generated at 2022-06-16 19:58:49.728074
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test for method add_fields(text, data, limit, opt_indent, return_values=False, parent_indent='')
    # of class DocCLI
    text = []
    data = {'name': 'test', 'description': 'test description', 'version_added': '2.4'}
    DocCLI.add_fields(text, data, limit=70, opt_indent='    ')
    assert text == ['    name: test', '    description: test description', '    added in: 2.4']



# Generated at 2022-06-16 19:59:00.731800
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    assert DocCLI.format_snippet('- name: test', 'yaml') == '- name: test'
    assert DocCLI.format_snippet('- name: test', 'json') == '- name: test'
    assert DocCLI.format_snippet('- name: test', 'sh') == '- name: test'
    assert DocCLI.format_snippet('- name: test', 'powershell') == '- name: test'
    assert DocCLI.format_snippet('- name: test', 'python') == '- name: test'
    assert DocCLI.format_snippet('- name: test', 'ruby') == '- name: test'
    assert DocCLI.format_snippet('- name: test', 'perl') == '- name: test'


# Generated at 2022-06-16 19:59:10.028061
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc = {
        'name': 'test_role',
        'path': '/path/to/test_role',
        'entry_points': {
            'main': {
                'short_description': 'Test role',
                'description': 'Test role description',
                'options': {
                    'test_option': {
                        'description': 'Test option description',
                        'required': True,
                        'type': 'str'
                    }
                },
                'attributes': {
                    'test_attribute': {
                        'description': 'Test attribute description',
                        'required': True,
                        'type': 'str'
                    }
                }
            }
        }
    }


# Generated at 2022-06-16 19:59:11.401352
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()
    doc.display_plugin_list()
    assert True


# Generated at 2022-06-16 19:59:23.445702
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-16 19:59:25.672518
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()
    doc.display_plugin_list()


# Generated at 2022-06-16 19:59:31.303373
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    expected = '> TEST MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                required: True\n                type: str\n'
    assert DocCLI.get_man_text(doc) == expected
