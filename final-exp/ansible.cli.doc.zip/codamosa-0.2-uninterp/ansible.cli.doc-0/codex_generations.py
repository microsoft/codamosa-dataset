

# Generated at 2022-06-16 19:54:44.524070
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test with no arguments
    doc = DocCLI()
    assert doc.find_plugins() == []

    # Test with a single argument
    assert doc.find_plugins('ping') == [('ping', 'ping')]

    # Test with a single argument and a collection
    assert doc.find_plugins('ping', 'ansible.builtin') == [('ping', 'ansible.builtin.ping')]

    # Test with a single argument and a collection that doesn't exist
    assert doc.find_plugins('ping', 'ansible.builtin.foo') == []

    # Test with a single argument and a collection that doesn't exist
    assert doc.find_plugins('ping', 'ansible.builtin.foo') == []

    # Test with a single argument and a collection that doesn't exist

# Generated at 2022-06-16 19:54:47.497085
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'module'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list != {}


# Generated at 2022-06-16 19:54:54.993666
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        },
        'plainexamples': 'This is a test example',
        'returndocs': {
            'test_return': {
                'description': 'This is a test return'
            }
        }
    }
    expected = """
> TEST    (None)
This is a test module

OPTIONS (= is mandatory):
        test_option: This is a test option

EXAMPLES:

This is a test example

RETURN VALUES:
        test_return: This is a test return
"""
    assert DocCLI.get_man_

# Generated at 2022-06-16 19:55:07.513472
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a module
    doc = DocCLI.get_plugin_metadata('setup')
    assert doc['name'] == 'setup'
    assert doc['filename'] == 'setup.py'
    assert doc['version_added'] == 'historical'
    assert doc['description'] == 'Gather facts about remote hosts'
    assert doc['options']['filter']['description'] == 'when supplied, only return facts that match this shell-style (fnmatch) wildcard.'
    assert doc['options']['filter']['required'] == False
    assert doc['options']['filter']['default'] == '*'
    assert doc['options']['filter']['version_added'] == '1.6'
    assert doc['options']['filter']['aliases'] == ['fact_path']

# Generated at 2022-06-16 19:55:15.461714
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Test with no arguments
    try:
        DocCLI.print_paths()
    except SystemExit:
        pass
    else:
        raise AssertionError("DocCLI.print_paths() did not raise SystemExit when called with no arguments")

    # Test with an invalid argument
    try:
        DocCLI.print_paths(['invalid_argument'])
    except SystemExit:
        pass
    else:
        raise AssertionError("DocCLI.print_paths() did not raise SystemExit when called with an invalid argument")

    # Test with a valid argument
    try:
        DocCLI.print_paths(['action_plugins'])
    except SystemExit:
        pass

# Generated at 2022-06-16 19:55:17.261939
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()
    doc.display_plugin_list()


# Generated at 2022-06-16 19:55:28.669139
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # Test with a valid path
    path = '/home/user/ansible/lib/ansible/modules/cloud/amazon/ec2_vpc_subnet.py'
    assert DocCLI.namespace_from_plugin_filepath(path) == 'cloud.amazon'
    # Test with a invalid path
    path = '/home/user/ansible/lib/ansible/modules/cloud/amazon/ec2_vpc_subnet'
    assert DocCLI.namespace_from_plugin_filepath(path) == 'cloud.amazon'
    # Test with a invalid path
    path = '/home/user/ansible/lib/ansible/modules/cloud/amazon/ec2_vpc_subnet.pyc'
    assert DocCLI.namespace_from_plugin_filepath(path) == 'cloud.amazon'

# Generated at 2022-06-16 19:55:40.360276
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    assert DocCLI.format_snippet('foo') == 'foo'
    assert DocCLI.format_snippet('foo\nbar') == 'foo\nbar'
    assert DocCLI.format_snippet('foo\nbar\n') == 'foo\nbar'
    assert DocCLI.format_snippet('foo\nbar\n\n') == 'foo\nbar'
    assert DocCLI.format_snippet('foo\nbar\n\n\n') == 'foo\nbar'
    assert DocCLI.format_snippet('foo\nbar\n\n\n\n') == 'foo\nbar'
    assert DocCLI.format_snippet('foo\nbar\n\n\n\n\n') == 'foo\nbar'


# Generated at 2022-06-16 19:55:53.074573
# Unit test for method find_plugins of class DocCLI

# Generated at 2022-06-16 19:56:04.665669
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a module
    plugin_type = 'module'
    plugin_name = 'setup'
    plugin_path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'modules', plugin_name + '.py')
    metadata = DocCLI.get_plugin_metadata(plugin_type, plugin_name, plugin_path)
    assert metadata['name'] == plugin_name
    assert metadata['filename'] == plugin_path
    assert metadata['version_added'] == 'historical'
    assert metadata['version_added_collection'] is None
    assert metadata['deprecated'] is False
    assert metadata['has_action'] is False
    assert metadata['options'] == {}
    assert metadata['attributes'] == {}
    assert metadata['notes'] == []

# Generated at 2022-06-16 19:58:07.692546
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    doc = DocCLI()
    doc.display_plugin_list([])
    assert True

    # Test with plugins
    doc = DocCLI()
    doc.display_plugin_list([{'name': 'test_plugin'}])
    assert True


# Generated at 2022-06-16 19:58:17.565178
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test with empty doc
    doc = {}
    text = []
    DocCLI.add_fields(text, doc, 80, '    ')
    assert text == []

    # Test with doc with only one option
    doc = {'name': {'description': 'The name of the thing', 'required': True, 'type': 'str'}}
    text = []
    DocCLI.add_fields(text, doc, 80, '    ')
    assert text == ['    name: The name of the thing', '', '    required: True', '', '    type: str', '']

    # Test with doc with multiple options

# Generated at 2022-06-16 19:58:26.365801
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Test with no args
    with pytest.raises(SystemExit):
        DocCLI().run()

    # Test with a module name
    with pytest.raises(SystemExit):
        DocCLI(args=['ping']).run()

    # Test with a module name and a type
    with pytest.raises(SystemExit):
        DocCLI(args=['ping', 'module']).run()

    # Test with a module name and a type and a collection
    with pytest.raises(SystemExit):
        DocCLI(args=['ping', 'module', 'collection']).run()

    # Test with a module name and a type and a collection and a collection version

# Generated at 2022-06-16 19:58:28.527017
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    add_collection_plugins(plugin_list, 'action')
    assert plugin_list



# Generated at 2022-06-16 19:58:39.444488
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'action'
    coll_filter = 'ansible.builtin'
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list.get('setup') is not None
    assert plugin_list.get('debug') is not None
    assert plugin_list.get('pause') is not None
    assert plugin_list.get('include') is not None
    assert plugin_list.get('include_tasks') is not None
    assert plugin_list.get('include_role') is not None
    assert plugin_list.get('include_vars') is not None
    assert plugin_list.get('meta') is not None
    assert plugin_list.get('wait_for') is not None
    assert plugin_list.get('wait_for_connection')

# Generated at 2022-06-16 19:58:46.932227
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    assert DocCLI.format_plugin_doc(doc) == '''
> TEST_MODULE    (None)

This is a test module

OPTIONS (= is mandatory):
        test_option: This is a test option
            required: True
            type: str
'''


# Generated at 2022-06-16 19:58:50.339081
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'module'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list != {}


# Generated at 2022-06-16 19:58:57.407317
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test with no plugins
    plugins = []
    DocCLI.display_plugin_list(plugins)
    # Test with one plugin
    plugins = [{'name': 'ping'}]
    DocCLI.display_plugin_list(plugins)
    # Test with multiple plugins
    plugins = [{'name': 'ping'}, {'name': 'setup'}]
    DocCLI.display_plugin_list(plugins)


# Generated at 2022-06-16 19:59:04.709586
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a test module',
        'options': {
            'test_option': {
                'description': 'This is a test option',
                'required': True,
                'type': 'str'
            }
        }
    }
    text = DocCLI.get_man_text(doc)
    assert text == '> TEST MODULE    (None)\nThis is a test module\n\nOPTIONS (= is mandatory):\n        test_option\n                This is a test option\n                required: True\n                type: str\n'


# Generated at 2022-06-16 19:59:06.382910
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc_cli = DocCLI()
    doc_cli.run()
