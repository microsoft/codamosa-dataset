

# Generated at 2022-06-20 13:05:06.051249
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    assert '> NAME    (filename)' == DocCLI.format_plugin_doc({'name': 'name', 'filename': 'filename'})

# Generated at 2022-06-20 13:05:17.420700
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    DocCLI_instance = DocCLI()

    # Test using generated args
    args = DocCLI_instance.post_process_args(None)
    assert args.output_format == 'json'
    assert args.collection is None
    assert args.all == False
    assert args.verbosity == 0

    # Test using provided args
    args = DocCLI_instance.post_process_args(['-c', 'my_collection', '-t', 'my_plugin type',
                                              '-a', 'my_plugin_name'])
    assert args.output_format == 'json'
    assert args.collection == 'my_collection'
    assert args.all == False
    assert args.verbosity == 0

    # Test using provided args

# Generated at 2022-06-20 13:05:19.946806
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc_cli = DocCLI()
    # Implement-DocCli-instance-display_plugin_list
    assert True, "Test for method display_plugin_list of class DocCLI"

# Generated at 2022-06-20 13:05:31.905713
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    ansible_config = {'DEFAULT_MODULE_PATH': '~/ansible/lib/ansible/modules'}
    doc_cli = DocCLI(ansible_config = ansible_config)
    plugin_metadata = doc_cli.get_plugin_metadata('~/ansible/lib/ansible/modules/system')
    if not plugin_metadata:
        raise AssertionError("Expected plugin_metadata to be not empty")
    expected_plugin_metadata_keys = ['newest_module_version', 'modules']
    if plugin_metadata.keys() != expected_plugin_metadata_keys:
        raise AssertionError("Expected plugin_metadata keys to be %s but actual is %s" % (expected_plugin_metadata_keys, plugin_metadata.keys()))
    expected_module_name = "uptime"


# Generated at 2022-06-20 13:05:33.812687
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    options = dict(
        type='module',
        commands=[],
        no_headers=False,
        colwidth=75,
        display_common=False)
    display_ret = _display_plugin_list(options)
    assert display_ret.startswith('\nPLUGINS')



# Generated at 2022-06-20 13:05:50.270958
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    options = dict(
        type='module',
        version=False,
        version_added=False,
        version_added_collection=False,
        verbosity=0,
        fetch_content=True
    )
    cli = DocCLI(args=[], options=options)
    assert cli.args == []
    assert cli.options == options
    cli.post_process_args()
    assert cli.args == []
    assert cli.options == dict(
        type='module',
        version=False,
        version_added=False,
        version_added_collection=False,
        verbosity=0,
        fetch_content=True
    )
    cli = DocCLI(args=['all'], options=options)
    assert cli.args == ['all']

# Generated at 2022-06-20 13:05:53.699008
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    '''DocCLI: Unit test for method find_plugins of class DocCLI.
    '''
    # setup for test
    doc = DocCLI()
    doc.run(args=[])


# Generated at 2022-06-20 13:06:09.600199
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    cli = DocCLI(
        ['ansible-doc', 'doccli'],
        ['ANSIBLEDOCCLI_MODULE_PATH', os.path.join(os.path.dirname(__file__), "../../lib/ansible/module_utils/"),
         'ANSIBLE_COLLECTIONS_PATHS',
         os.path.join(os.path.dirname(__file__), "../../test/units/modules/test_collections/")])
    doccli = DocCLI._find_plugins(cli)
    assert('doccli' in doccli)
    for mod in doccli['doccli']:
        assert('name' in mod)
        assert('doc' in mod)
        assert('docuri' in mod)
        assert('filename' in mod)

# Generated at 2022-06-20 13:06:18.486985
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    test_data = ['', 'help', '--help', '-h', 'help --help', 'help -h', 'version', '--version', '-v', 'version --version', 'version -v',
                 'autocomplete', '--autocomplete', '-a', 'autocomplete --autocomplete', 'autocomplete -a', 'setup', '--setup', '-s', 'setup --setup', 'setup -s',
                 'plugins', '--plugins', '-p', 'plugins --plugins', 'plugins -p', 'inventory', '--inventory', '-i', 'inventory --inventory', 'inventory -i']

    for data in test_data:
        iconsole = DocCLI()
        parser = iconsole.init_parser(None, data.split())
        assert parser is not None


# Generated at 2022-06-20 13:06:23.026944
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Test calling with parameters: role='', role_json=''
    # Returned value should be of type list
    assert isinstance(DocCLI.get_role_man_text(role='', role_json=''), list)

# Generated at 2022-06-20 13:08:17.423113
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    mixin = RoleMixin()
    assert mixin.ROLE_ARGSPEC_FILES == [
        'argument_specs.yml', 'argument_specs.yaml',
        'main.yml', 'main.yaml'
    ]
    # no role paths
    assert mixin._find_all_normal_roles([], None) == set()
    assert mixin._find_all_collection_roles(None) == set()
    assert mixin._create_role_list([]) == {}
    assert mixin._create_role_doc([], []) == {}



# Generated at 2022-06-20 13:08:23.566572
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc = DocCLI()
    assert isinstance(doc, DocCLI), "A DocCLI object was not created"


# Generated at 2022-06-20 13:08:33.646805
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    import ansible.plugins
    import ansible.utils.plugins
    import ansibles.cli.doc

    runner_path = ansibles.cli.doc.__path__[0]
    docs_path = os.path.join(runner_path, 'docs')
    plugins_path = os.path.join(runner_path, 'plugins')

    subpaths = [docs_path, plugins_path]
    for subpath in subpaths:
        if subpath not in sys.path:
            sys.path.insert(0, subpath)

    ansible.utils.display._AVAILABLE_ERRORS = None

    module_loader = ModuleLoader()
    if not module_loader._module_cache:
        module_loader.find_plugins()

    ansible.plugins.module_loader = module_loader

    cli = Doc

# Generated at 2022-06-20 13:08:34.473777
# Unit test for constructor of class DocCLI
def test_DocCLI():
    DocCLI()


# Generated at 2022-06-20 13:08:40.489761
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound()
    except PluginNotFound as e:
        assert str(e)
    assert issubclass(PluginNotFound, Exception)


# Generated at 2022-06-20 13:08:41.760630
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    print('Foo')


# Generated at 2022-06-20 13:08:54.451205
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-20 13:09:00.253014
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    cli = DocCLI()
    cli.args = mock.MagicMock()
    cli.args.module = True
    cli.args.json = True
    cli.args.type = "module"
    cli.args.path = ["/home/user/Current_project/path/to/module"]

    with pytest.raises(SystemExit):
        cli.post_process_args()

# Generated at 2022-06-20 13:09:01.865890
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    assert str(PluginNotFound('foo')) == 'foo'



# Generated at 2022-06-20 13:09:16.521870
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    '''Unit test for method get_man_text of class DocCLI'''

# Generated at 2022-06-20 13:10:33.590058
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    """Tests for the constructor of the RoleMixin class."""
    # Create an empty class for testing
    class TestDocCLI(RoleMixin):
        def __init__(self):
            pass

    # Create an instance of the class
    doccli = TestDocCLI()

    # We cannot use the setup_tmp_directory() method here, as that creates its own instance
    # of the DocCLI class. So we create the temp directory ourselves.
    # The following directory structure will be created:
    # /tmp/ansible_test/roles/roleA/meta/argument_specs.yml
    # /tmp/ansible_test/roles/roleB/meta/argument_specs.yml
    # /tmp/ansible_test/roles/roleC/meta/main.yml
    # /tmp/

# Generated at 2022-06-20 13:10:40.077115
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    test_instance = RoleMixin()
    assert hasattr(test_instance, '_load_argspec'), "_load_argspec is not in class RoleMixin"
    assert hasattr(test_instance, '_find_all_normal_roles'), "_find_all_normal_roles is not in class RoleMixin"
    assert hasattr(test_instance, '_find_all_collection_roles'), "_find_all_collection_roles is not in class RoleMixin"
    assert hasattr(test_instance, '_build_role_list'), "_build_role_list is not in class RoleMixin"
    assert hasattr(test_instance, '_build_role_doc'), "_build_role_doc is not in class RoleMixin"


# Generated at 2022-06-20 13:10:41.964547
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    DocCLI.run()

# Generated at 2022-06-20 13:10:51.720206
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    doc = RoleMixin()

    # Test _load_argspec, including empty case
    try:
        doc._load_argspec('test')
        raise
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert str(e).startswith("A path is required to load argument specs for role 'test'")

    my_path = os.path.dirname(os.path.abspath(__file__))
    test_role_path = os.path.join(my_path, 'data', 'test_roles')

    # Test loading argument specs for a normal (non-collection) role
    argspec_normal = doc._load_argspec('argspec_normal', role_path=test_role_path)

# Generated at 2022-06-20 13:11:06.264892
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a lookup plugin
    doc, plugin_type = DocCLI.get_plugin_metadata(os.path.join(os.path.dirname(__file__), '../../../lib/ansible/plugins/lookup/matching.py'))
    assert doc['author'] == ['Ansible Core Team']
    assert doc['description'] == ['Returns the value for a given key from a dictionary']
    assert doc['license'] == ['GPLv3']
    assert doc['version_added'] == '2.4'
    assert plugin_type == 'lookup'

    # Test with an action plugin

# Generated at 2022-06-20 13:11:10.284326
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    DocCLI.parse([''])
    assert DocCLI.post_process_args() == {'one_liner': False, 'help': False, 'type': 'modules', 'search': '', 'output_dir': None, 'version': False}


# Generated at 2022-06-20 13:11:16.662917
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    from ansible.plugins.loader import find_plugin_files
    from ansible.module_utils._text import to_text
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    t = DocCLI(
        doc=dict(
            type='module'
        ),
        subcommand='test',
        aliases=[],
        display=display
        )
    # Confirm we get a list of plugins.
    # Note: We need to use list() here to resolve any generators
    assert isinstance(list(t.find_plugins(['system'])), list)
    # Confirm that plugins are case insensitive
    assert len(list(t.find_plugins(['SYSTEM']))) > 0
    # Confirm that plugins are case insensitive

# Generated at 2022-06-20 13:11:22.155736
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    plugins = DocCLI.get_all_plugins_of_type('action')
    assert plugins
    assert isinstance(plugins, list)
    assert '/usr/lib/python2.7/dist-packages/ansible/plugins/action' in plugins[0]

# Generated at 2022-06-20 13:11:30.100788
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-20 13:11:42.175020
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    mock_collections = [
        {'plugins': {'foo': mock_module}},
        {'plugins': {'foo': mock_module}}
    ]
    mock_module.name = 'foo'
    mock_module.__doc__ = """
    Ansible module for foo

    This module does things for foo
    """
    mock_module.argspec = AnsibleModule._load_params(mock_module.__doc__)
    mock_module.__dict__ = dict(
        _ansible_version="",
        _ansible_version_full_info=(0, 0, 0),
        _ansible_version_info=(0, 0, 0),
    )
    doccli = DocCLI()
    doccli._collection_finder = Mock(return_value=mock_collections)
    doccli._create