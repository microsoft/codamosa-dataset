

# Generated at 2022-06-20 13:04:39.865564
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    import os
    import tempfile
    import ansible.utils.display
    from ansible.module_utils._text import to_text
    with tempfile.TemporaryDirectory() as tmp_dirname_plugin:
        with tempfile.TemporaryDirectory() as tmp_dirname_role:
            original_display_columns = ansible.utils.display.columns
            original_display_file = ansible.utils.display.Display._file

# Generated at 2022-06-20 13:04:49.067688
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    role_names = ['roleA', 'community.general.roleB', 'community.general.roleC']
    role_paths = ['/dev/null/non-existent-a', '/dev/null/non-existent-b']
    entry_point = 'main'
    rmix = RoleMixin()
    rmix._find_all_collection_roles = Mock()
    rmix._find_all_collection_roles.return_value = [('roleA', 'community.general', '/dev/null/collections')]
    rmix._find_all_normal_roles = Mock()
    rmix._find_all_normal_roles.return_value = [('roleA', '/dev/null/ansible/roles')]
    rmix._load_argspec = Mock()

# Generated at 2022-06-20 13:04:51.802065
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    plugins = ['foo', 'bar']
    details = "plugin foo not found"
    exc = PluginNotFound("plugin foo not found")
    assert exc.args == (details,)



# Generated at 2022-06-20 13:04:55.300477
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    assert DocCLI.format_plugin_doc({}) == ''
    assert DocCLI.format_plugin_doc({'foo': {}}) == ''
    assert DocCLI.format_plugin_doc({'foo': [{'bar': "baz"}]}) == 'baz'
    assert DocCLI.format_plugin_doc({'foo': 'bar'}) == 'bar'

# Generated at 2022-06-20 13:05:00.345299
# Unit test for function jdump
def test_jdump():
    from ansible.utils.path import unfrackpath
    from ansible.utils.hashing import checksum_s

    test_dict = {'a': '123', 'b': [1, 2, 3], 'c': {'d': '456', 'e': {'f': ['789']}}}
    jdump_output = json.dumps(test_dict, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)
    assert checksum_s(unfrackpath(jdump_output)) == 'f6e95cddffb74c9eae6b1ac6b17e4127'



# Generated at 2022-06-20 13:05:07.459609
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Input params
    args = ''

    # Expected result
    expected_result = '''    roles   The directory containing Ansible roles.
    library The directory containing Ansible modules.
'''

    # Execute the tested code
    result = DocCLI.print_paths(args)

    # Verify the result
    assert result == expected_result


# Generated at 2022-06-20 13:05:11.531017
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    import sys
    import inspect
    import unittest

    if sys.version_info >= (3, 4):
        import importlib
        importlib.reload(importlib.import_module('ansible.utils.collection_loader'))

    from ansible.errors import AnsibleError
    from ansible.plugins.loader import find_plugin, get_all_plugin_loaders

    class TestDocCLI(unittest.TestCase):
        def _makeOne(self):
            class Dummy(RoleMixin):
                pass
            return Dummy()

        def _make_dummy_roles_path(self, roles_data=None):
            """Create a temp directory containing dummy roles."""
            roles_path = tempfile.mkdtemp(prefix='ansible-doc-')

# Generated at 2022-06-20 13:05:20.875312
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {
        'author': 'Fake Author',
        'description': 'This is a fake description',
        'version_added': '0.1',
        'options': {
            'hostname': {
                'description': 'IP or hostname to connect to.',
                'choices': ['1.1.1.1', '2.2.2.2']
            }
        }
    }
    plugin_type = 'Fake Plugin Type'
    expected_result = """
> FAKE PLUGIN TYPE    ( )

This is a fake description

ADDED IN: Ansible 0.1

OPTIONS (= is mandatory):
        hostname: IP or hostname to connect to.
                choices: 1.1.1.1, 2.2.2.2
        author: Fake Author
"""
    result = Doc

# Generated at 2022-06-20 13:05:31.718250
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = "module"
    coll_name = "test_collection"
    coll_path = "./test_collection"
    coll_filter = [coll_name]
    open(coll_path, 'a').close()
    plugin_file_name = "test_collection_collection_plugin.py"
    plugin_file = os.path.join(coll_path, 'plugins', 'module', plugin_file_name)
    open(plugin_file, 'a').close()
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert (plugin_file_name in plugin_list)
    os.remove(plugin_path)
    os.remove(coll_path)



# Generated at 2022-06-20 13:05:35.099273
# Unit test for constructor of class DocCLI
def test_DocCLI():
    def test_for_none_args():
        '''
        Instantiate a DocCLI object.
        '''
        doc = DocCLI()
        assert doc is not None
    test_for_none_args()



# Generated at 2022-06-20 13:06:32.092194
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {}

# Generated at 2022-06-20 13:06:39.458620
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    cli = DocCLI()
    text = []
    DocCLI.add_fields(text, {
        'foo': {
            'type': 'list',
            'required': True,
            'choices': ['bar', 'baz'],
            'default': [],
            'description': 'foo is a list of stuff'
        }
    })
    assert text == ['']
    # FIXME: looks like the output isn't formatted exactly the same
    # assert text == [u'        choices: [bar, baz]', u'        default: []', u'        description: foo is a list of stuff', u'        required: yes', u'        type: list']
    text = []

# Generated at 2022-06-20 13:06:44.971273
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    
    # set up object
    doc = DocCLI()
    
    test_input = '/Users/ralph/repos/ansible/lib/ansible/plugins/lookup/hiera.py'
    
    test_output = doc.namespace_from_plugin_filepath(test_input)
    
    assert test_output == 'lookup'


# Generated at 2022-06-20 13:06:51.784830
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    JSONFILE = "%s.json" % os.path.join(DATA_PATH, 'plugins')
    items = []
    with open(JSONFILE, 'r') as json_file:
        items = json.load(json_file)

    for item in items:
        for plugin in item['plugins']:
            for type in plugin['types']:
                plugins = DocCLI.get_all_plugins_of_type(type)
                assert plugins is not None
                assert isinstance(plugins, dict)
                assert len(plugins) >= 1
                assert plugin['name'] in plugins
                assert plugins[plugin['name']] == plugin



# Generated at 2022-06-20 13:07:04.348960
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    from ansible import context
    from ansible.cli import CLI
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.module_utils.six import PY3

    context._init_global_context(CLI)
    if PY3:
        context._init_global_context(doc_fragment=['module', 'command', 'config'])
    else:
        context._init_global_context(doc_fragment=['module', 'command', 'config'])

    parser = context.CLIARGS['parser']
    opt_help.core_opts(parser)

    options = parser.parse_args(
        ['--version', 'connection'])
    plugin = DocCLI(args=options.args, options=options)

    assert plugin.run() == 0

# Generated at 2022-06-20 13:07:05.550010
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
	pass


# Generated at 2022-06-20 13:07:17.517276
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    assert '> DUMMY    (plugins/doc_fragments/doc_CLI.py)' in DocCLI.format_plugin_doc(
        {"filename": "plugins/doc_fragments/doc_CLI.py", "DOCUMENTATION": "foo"})
    assert '> DUMMY    (plugins/doc_fragments/doc_CLI.py)' in DocCLI.format_plugin_doc(
        {"filename": "plugins/doc_fragments/doc_CLI.py", "DOCUMENTATION": "foo"},
        collection_name='test')


# Generated at 2022-06-20 13:07:30.031281
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    """Unit test for method namespace_from_plugin_filepath of class DocCLI"""
    # Unit test for ansible-doc -t foo
    plugin_filepath = '/path/to/plugins/foo.py'
    plugin_type = 'foo'
    namespace = DocCLI.namespace_from_plugin_filepath(plugin_filepath, plugin_type)
    assert namespace == 'ansible_collections.namespace.collection.plugins.modules.foo'
    # Unit test for ansible-doc -t bal_baz
    plugin_filepath = '/path/to/plugins/bal/baz.py'
    plugin_type = 'bal_baz'
    namespace = DocCLI.namespace_from_plugin_filepath(plugin_filepath, plugin_type)

# Generated at 2022-06-20 13:07:37.608987
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    """
    Placeholder for future unit tests
    """
    # test for regex for "ansible localhost"
    cmd = "ansible localhost -m ping -a"
    test_cmd = DocCLI.format_snippet(cmd)
    local_cmd = "ansible localhost -m %s -a" % module_name
    assert(test_cmd == local_cmd)
    # test for regex for "ansible -m"
    cmd = "ansible -m ping -a"
    test_cmd = DocCLI.format_snippet(cmd)
    local_cmd = "ansible -m %s -a" % module_name
    assert(test_cmd == local_cmd)


# Generated at 2022-06-20 13:07:43.989380
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    args = dict(
        plugin_type='module',
        collection_list=[],
        subdirs=[
            'plugins/action/azure_rm_resource',
            'plugins/modules/azure_rm_resource',
        ],
    )
    plugin_path = 'plugins/modules/azure_rm_resource/example.py'
    namespace = DocCLI.namespace_from_plugin_filepath(plugin_path, **args)
    assert namespace == 'azure.azure_rm_resource'

    args = dict(
        plugin_type='module',
        collection_list=[],
        subdirs=[
            'plugins/action/azure_rm_resource',
            'plugins/modules/azure_rm_resource',
        ],
    )

# Generated at 2022-06-20 13:08:41.418214
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    cli = DocCLI()
    cli.print_paths()
    cli.print_paths(extra_paths=['/tmp/foo', '/tmp/bar', '/tmp/zip'])


# Generated at 2022-06-20 13:08:54.302567
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {}
    doc['description'] = "This module provides an implementation for working with Paloalto software configuration sections in a deterministic way.It provides a set of arguments for loading and downloading configuration data from devices.This module is able to configure a wide range of device settings using provided arguments.Configuration data can be sent from files or directly from variables.\\nThis module works with connection parameters smartly.It connects to the remote device and detects the platform variant.So there is no need of specifying the platform variant."
    doc['version_added'] = '2.5'

# Generated at 2022-06-20 13:09:08.414901
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    ''' test_DocCLI_format_plugin_doc()

    This is a unit test for method format_plugin_doc of class DocCLI.
    '''

    for item in ['module', 'module_utils']:
        loader = DataLoader()
        collection = 'ansible_collections.ansible.builtin'
        plugin_name = 'setup'
        collection_name = None
        doc_type = 'module'
        # plugins/cache/setup.py
        # plugins/modules/setup.py
        # plugins/module_utils/setup.py
        # plugins/lookup/setup.py
        fqcn = 'ansible_collections.ansible.builtin.module_utils.setup'

# Generated at 2022-06-20 13:09:23.012532
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    d = DocCLI()
    role = "test_role"
    role_json = {'entry_points': {'main':
                                      {'description': 'Test module for unit test of get_role_man_text method of DocCLI class.',
                                       'options': {
                                           'test_option': {'aliases': [],
                                                           'description': 'test_description',
                                                           'required': True,
                                                           'type': 'str'}
                                       },
                                       'short_description': 'This test module is for unit test of get_role_man_text method of DocCLI class.'
                                       }},
                 'filename': 'test_filename'
                 }
    text = d.get_role_man_text(role, role_json)

# Generated at 2022-06-20 13:09:28.488082
# Unit test for constructor of class DocCLI
def test_DocCLI():
    # Test 1. Test valid values for verbosity
    ansible_doc = DocCLI(verbosity=0)
    assert ansible_doc.verbosity == 0

    ansible_doc = DocCLI(verbosity=1)
    assert ansible_doc.verbosity == 1

    # Test 2. Test invalid values for verbosity
    try:
        ansible_doc = DocCLI(verbosity=2)
        assert False
    except SystemExit as e:
        assert e.args[0] == 1


# Load module documentation

# Generated at 2022-06-20 13:09:31.296817
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    pass


# Generated at 2022-06-20 13:09:40.621510
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Test with no paths, should throw error
    sys.argv = ['']
    with pytest.raises(AnsibleOptionsError):
        cli = DocCLI()
        cli.parse()
        cli.print_paths()
    # Test with no valid paths, should throw error
    sys.argv = ['', '-M', 'file1']
    with pytest.raises(AnsibleOptionsError):
        cli = DocCLI()
        cli.parse()
        cli.print_paths()


# Generated at 2022-06-20 13:09:45.606503
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = dict()
    plugin_type = 'action'
    coll_filter = ['ansible_collections.general.plugins']
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    if plugin_list is None:
        print ('There are no plugins found in the collection:')
    else:
        print ('collection plugin list:', plugin_list)



# Generated at 2022-06-20 13:09:48.639500
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    cli_args = DocCLI.parse()
    cli_args['type'] = 'module'
    context.CLIARGS = cli_args
    display = Display()
    d = DocCLI(cli_args, display)
    d.run()

# Generated at 2022-06-20 13:09:51.246628
# Unit test for function jdump
def test_jdump():
    assert jdump({"foo": "bar"}) == '{\n    "foo": "bar"\n}', "jdump didn't produce the expected output"



# Generated at 2022-06-20 13:11:26.313828
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():

    DocCLI.reset()

    # Return "None" if no args are provided
    # This is the expected value if no args are provided

    # Check if the function throws an error if something other than an argparse.Namespace is provided to args
    namespaced = lambda: 0
    try:
        post_process_args(namespaced)
    except TypeError:
        pass
    else:
        assert False

    # Check if the function throws an error if a non-empty argparse.Namespace is provided
    args = lambda: 0
    args.type = 'foo'
    try:
        post_process_args(args)
    except AttributeError:
        pass
    else:
        assert False

    # Check if the function adds "module" to the argparse.Namespace if a module is provided and "module" is not already in the arg

# Generated at 2022-06-20 13:11:30.565530
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    sample = DocCLI()
    assert not sample.init_parser(), 'Unit test failed'


# Generated at 2022-06-20 13:11:42.462398
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    temp_dir = tempfile.mkdtemp(prefix='ansible-tmp')
    paths = C.DEFAULT_LOCAL_TMP
    paths.append(temp_dir)
    C.config = ConfigParser.ConfigParser()
    C.config.add_section('defaults')
    C.config.set('defaults', 'action_plugins', '')
    C.config.set('defaults', 'library', '')
    C.config.set('defaults', 'module_utils', '')
    C.config.set('defaults', 'roles_path', '')
    C.config.set('defaults', 'filter_plugins', '')
    C.config.set('defaults', 'local_tmp', paths)

    # Create a plugin

# Generated at 2022-06-20 13:11:49.163927
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-20 13:12:01.928116
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    print('Testing method get_all_plugins_of_type of class DocCLI')
    class DocCLItest:
        def __init__(self):
            print('Testing...')
    #declaration of variables
    result1 = False
    result2 = False
    #functional code
    #Testing for exceptions
    # Calling the method
    try:
        get_all_plugins_of_type(DocCLItest(), "modules")
    except Exception as error:
        print('Exception: ', str(error))
        result1 = True
    try:
        get_all_plugins_of_type(DocCLItest(), "moduless")
    except Exception as error:
        print('Exception: ', str(error))
        result2 = True
    #unittest.main()
    #print("Result1:" + result1