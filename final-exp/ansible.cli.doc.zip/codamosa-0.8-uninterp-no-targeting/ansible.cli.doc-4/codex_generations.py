

# Generated at 2022-06-20 13:04:09.624328
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    doc = AnsibleModuleCLI('name')

    # test empty snippet
    assert doc.format_snippet('') == ''

    # test snippet without any indentation
    snippet = '- name: Check free space\n  command: df -h\n'
    assert doc.format_snippet(snippet) == snippet

    # test snippet with tabs as indentation
    snippet = '\t- name: Check free space\n\t  command: df -h\n'
    assert doc.format_snippet(snippet) == '- name: Check free space\n  command: df -h\n'

    # test snippet with spaces as indentation
    snippet = '    - name: Check free space\n      command: df -h\n'

# Generated at 2022-06-20 13:04:10.893684
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    result = DocCLI.find_plugins('module', all_plugins=True, include_deprecated=True, check_aliases=True)


# Generated at 2022-06-20 13:04:16.953882
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    ''' 
    Test get_role_man_text
    '''

    fixture = load_fixture('role_doc.json')
    argspec = {'_ansible_version': StrictVersion("2.9.0"),
               'name': 'saltstack.salt'}

    text = DocCLI.get_role_man_text(argspec['name'], fixture)

    assert len(text) == 15
    assert text[0] == "> SALTSTACK.SALT    (saltstack.salt)\n"
    assert text[1] == "ENTRY POINT: minion - Configure a salt minion\n"
    assert text[2] == '        This role will configure a salt minion.  It takes about 10\n'
    assert text[3] == '        minutes to run.\n'


# Generated at 2022-06-20 13:04:23.103573
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_list.update(DocCLI.find_plugins("/usr/share/ansible_plugins/action", False, "action"))
    plugin_list.update(DocCLI.find_plugins("/usr/share/ansible_plugins/connection", False, "connection"))
    plugin_list.update(DocCLI.find_plugins("/usr/share/ansible_plugins/lookup", False, "lookup"))
    plugin_list.update(DocCLI.find_plugins("/usr/share/ansible_plugins/shell", False, "shell"))
    plugin_list.update(DocCLI.find_plugins("/usr/share/ansible_plugins/strategy", False, "strategy"))

# Generated at 2022-06-20 13:04:24.364607
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    test_cli = DocCLI()
    parser = test_cli.init_parser()
    assert parser is not None


# Generated at 2022-06-20 13:04:34.113352
# Unit test for function jdump
def test_jdump():
    """
    :return: Pass if ``jdump()`` function works as expected, else fail
    :rtype: unicode
    """
    j1 = {'a': 2, 'b': 3, 'd': 5, 'c': 4}
    assert jdump(j1) == b'{\n    "a": 2,\n    "b": 3,\n    "c": 4,\n    "d": 5\n}'
    j2 = ['a', 'b', 'c', 'd']
    assert jdump(j2) == b'[\n    "a",\n    "b",\n    "c",\n    "d"\n]'
    j3 = [('a', 'b'), ('c', 'd')]

# Generated at 2022-06-20 13:04:37.755014
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    path = '/path/to/lib/ansible/modules/cloud/amazon/_ec2_key.py'
    ns = DocCLI.namespace_from_plugin_filepath(path)
    assert ns == ('lib', 'ansible', 'modules', 'cloud', 'amazon', 'ec2_key')


# Generated at 2022-06-20 13:04:44.598826
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    from ansible.cli.doc import DocCLI
    from ansible.utils.display import Display
    from ansible.utils.plugins import PluginLoader
    from ansible.cli import CLI
    import os
    import sys
    from collections import namedtuple
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.errors import AnsibleOptionsError


# Generated at 2022-06-20 13:04:46.971101
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound("Testing PluginNotFound")
    except Exception as ex:
        display.display(ex)
        display.display(ex.args)



# Generated at 2022-06-20 13:04:52.655622
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    cli = DocCLI()
    cli.get_all_plugins_of_type("shell")
    cli.get_all_plugins_of_type("module")
    cli.get_all_plugins_of_type("lookup")
    cli.get_all_plugins_of_type("inventory")
    cli.get_all_plugins_of_type("vars")
    cli.get_all_plugins_of_type("action")
    cli.get_all_plugins_of_type("filter")
    cli.get_all_plugins_of_type("callback")
    cli.get_all_plugins_of_type("test")
    cli.get_all_plugins_of_type("connection")

# Generated at 2022-06-20 13:05:51.837573
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Test the argument count of print_paths method.
    with pytest.raises(TypeError):
        DocCLI.print_paths()
    # Test the argument count of print_paths method if we pass more than 3 arguments
    with pytest.raises(TypeError):
        DocCLI.print_paths("", "", "", "")

    #Check for return value for print_paths method.
    rtn = DocCLI.print_paths("", "", "")
    assert rtn == 0


# Find plugin(s) by name and display their documentation.

# Generated at 2022-06-20 13:05:59.711694
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    """
    DocCLI: test method format_plugin_doc

    """


# Generated at 2022-06-20 13:06:01.198110
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    pass


# Generated at 2022-06-20 13:06:13.306300
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    snippet_formatted = """
    - name: This is the first task
      copy:
        src: /path/to/file
        dest: /path/to/dest
        mode: 0600

    - name: This is the second task
      copy:
        src: /path/to/other/file
        dest: /path/to/dest/other
        mode: 0600
    """

    snippet = """
- name: This is the first task
  copy:
    src: /path/to/file
    dest: /path/to/dest
    mode: 0600

- name: This is the second task
  copy:
    src: /path/to/other/file
    dest: /path/to/dest/other
    mode: 0600
"""
    doc = DocCLI()
    assert snippet_formatted

# Generated at 2022-06-20 13:06:21.068044
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    doc = DocCLI([])
    plugin_list = {}
    plugin_type = 'lookup'
    coll_filter = ['ansible.netcommon']
    try:
        add_collection_plugins(plugin_list, plugin_type, coll_filter)
    except:
        assert False



# Generated at 2022-06-20 13:06:24.317648
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    args = ['action', 'ansible.builtin']
    ans = AnsibleActionModule()
    ans.display_plugin_list(args)
    assert True

# Generated at 2022-06-20 13:06:28.744803
# Unit test for constructor of class DocCLI
def test_DocCLI():
    # Test to create an object of class DocCLI with empty argument
    doc_obj = DocCLI()
    assert doc_obj._docs_dir == os.path.join(os.path.dirname(__file__), '..', '..', 'docs', 'docsite')


# Generated at 2022-06-20 13:06:37.650993
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # this is a unit-test function, function name starts from 'test_'
    d = DocCLI()
    # following line is needed to 'print lookups' in the result
    setattr(d, 'get_command_path', lambda x: ['lookups'])
    setattr(d, 'get_module_path', lambda x: ['module_utils'])
    setattr(d, 'get_action_path', lambda x: ['actions'])
    setattr(d, 'get_lookup_path', lambda x: ['lookups'])
    setattr(d, 'get_filter_path', lambda x: ['filters'])
    setattr(d, 'get_module_utils_path', lambda x: ['module_utils'])

# Generated at 2022-06-20 13:06:42.680642
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # test hook
    now = time.time()
    last_update = now - 60

    # if last_updated is true, the dict will be wrapped with a list
    c = DocCLI()
    c.display_plugin_list({'module': {'sub1': {'sub2': {'last_updated': last_update}}}})



# Generated at 2022-06-20 13:06:51.659227
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Tests simple plugins
    filename = "plugins/action/ping.py"
    name = "ping"

    # Test dict returned by DocCLI.plugin_list()
    plugin1 = {
        "filename" : filename,
        "name" : name
    }

    # Test empty dict returned by DocCLI.plugin_list()
    plugin2 = {}

    # Test empty line returned by DocCLI.plugin_list()
    plugin3 = ""

    # Test empty list
    plugin_list1 = []

    # Test list with one valid plugin
    plugin_list2 = [plugin1]

    # Test list with one invalid plugin (dict)
    plugin_list3 = [plugin2]

    # Test list with one invalid plugin (empty line)
    plugin_list4 = [plugin3]

    # Test list with one valid and one

# Generated at 2022-06-20 13:08:03.257681
# Unit test for function jdump
def test_jdump():
    import json
    import copy
    out = json.loads(jdump({'a': 1, 'b': {'c':2}}))
    assert out == {u'a': 1, u'b': {u'c':2}}
    out = json.loads(jdump({'a': 1, 'b': {'c':2}, 'd': copy.deepcopy(to_text)}))
    assert out == {u'a': 1, u'b': {u'c':2}, u'd': '<function to_text at 0x%x>' % id(to_text)}
    jdump(copy.deepcopy(to_text))
    import ansible.parsing.utils.yaml
    jdump(copy.deepcopy(ansible.parsing.utils.yaml))
    from ansible import module_utils

# Generated at 2022-06-20 13:08:07.360442
# Unit test for function jdump
def test_jdump():
    text = """We could not convert all the documentation into JSON as there was a conversion issue: {}"""
    assert 'We could not convert all the documentation into JSON as there was a conversion issue: {}' in jdump(text)



# Generated at 2022-06-20 13:08:09.472596
# Unit test for function jdump
def test_jdump():
    doc = {'key': 'value'}
    assert json.loads(jdump(doc)) == doc



# Generated at 2022-06-20 13:08:20.312612
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Testing for absolute path
    module = to_text(os.path.abspath(__file__))
    m_name = to_text(os.path.basename(__file__))
    a = DocCLI.format_plugin_doc(None, module, m_name, 'ansible-doc')
    assert(a[0] == '> ANSIBLE-DOC    (%s)' % module)
    assert(a[-1] == '> ANSIBLE-DOC    (%s)' % module)
    assert('author:  Ansible, Inc. and others' in a)

# Generated at 2022-06-20 13:08:28.952850
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()
    doc.display_plugin_list(
        [{'module': 'helloworld', 'title': 'Hello World'}],
        'modules',
        'module'
    )
    doc.display_plugin_list(
        [{'module': 'helloworld', 'title': 'Hello World'}],
        'modules',
        'module',
        per_page=1
    )
    doc.display_plugin_list(
        [{'module': 'helloworld', 'title': 'Hello World'}],
        'modules',
        'module',
        search='helloworld'
    )

# Generated at 2022-06-20 13:08:33.026158
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # instantiate class
    Cli = DocCLI()

    # find_plugins()
    cli_help_plugins = Cli.find_plugins()

    # assert we have the expected number of plugins
    assert len(cli_help_plugins) == 119, 'expected plugins count does not match'


# Generated at 2022-06-20 13:08:34.179593
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc = DocCLI()
    doc.find_plugins('')

# Generated at 2022-06-20 13:08:39.621073
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    cli_instance = DocCLI()
    cli_instance.display_plugin_list()
    pass

# Generated at 2022-06-20 13:08:42.968577
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    DocCLI.ansible_version = ""
    DocCLI.tty_ify = ""
    assert DocCLI.get_man_text("") == ""

# Generated at 2022-06-20 13:08:51.677923
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    display_plugin_list_ins = DocCLI()
    ansible_playbook_ins = AnsiblePlaybookCLI(['-i', 'localhost,'])
    inventory_loader_ins = ansible_playbook_ins._inventory_loader()
    display_plugin_list_ins.get_all_plugin_loaders(inventory_loader_ins)
    display_plugin_list_ins.display_plugin_list("lookup", C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)