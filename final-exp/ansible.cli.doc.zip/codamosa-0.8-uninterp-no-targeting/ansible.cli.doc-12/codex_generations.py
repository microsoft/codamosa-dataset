

# Generated at 2022-06-20 13:03:33.838497
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    runner = Runner(
        module_name='test',
        module_args='',
        become=False,
        become_method=None,
        become_user=None,
        check=False,
        description=None,
        diff=False,
        verbosity=3,
        force_handlers=False,
        start_at_task=None
    )

    display = Display()
    context = CLIContext('all', color=False)

    doc = DocCLI(runner, display, context)

    assert doc.run() == None

# Generated at 2022-06-20 13:03:36.959419
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    test_instance = DocCLI()
    with pytest.raises(Exception):
        test_instance.run()

# Generated at 2022-06-20 13:03:46.577114
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc = DocCLI()
    # Get the path of this file
    test_file_path = os.path.dirname(os.path.abspath(__file__))
    # Get the path of the inventory file
    parent_path = os.path.dirname(test_file_path)
    inventory_file = os.path.join(parent_path, "inventory")
    # Create the inventory object
    inv = InventoryManager(loader=DataLoader(), sources=inventory_file)
    # Create a TaskExecutor for lookup plugin tests
    te = TaskExecutor(inventory=inv, variable_manager=VariableManager(loader=DataLoader(), inventory=inv))
    # Create the lookup_plugin obj

# Generated at 2022-06-20 13:03:52.136660
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    DocCLI.IGNORE = tuple()
    expected_results = ['action', 'become', 'cache', 'callback', 'cliconf', 'connection', 'doc_fragments', 'filter', 'httpapi', 'inventory', 'lookup', 'module_utils', 'netconf', 'shell', 'terminal', 'test', 'vars']
    obj = DocCLI()
    actual_results = obj.get_all_plugins_of_type()
    assert set(expected_results) == set(actual_results)


# Generated at 2022-06-20 13:03:57.292980
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # set context
    context.CLIARGS = ImmutableDict(tags={'some_tags':True}, listtasks=False, listtags=False, listhosts=False, subset=None)
 
    # set params
    plugin_dir = 'plugins/action'
    package = 'ansible.plugins'
    exclude_packages = []
    exclude_modules = []

    # call method
    return_value = DocCLI.get_all_plugins_of_type(plugin_dir, package, exclude_packages, exclude_modules)

    # check results
    # FIXME: This test is returning different results every time it is run on Python3.6, Python3.7 and Python3.8
    #        Remove this known failure when fixed
    # ~ assert_equal(return_value, ['accelerate', 'add_host', '

# Generated at 2022-06-20 13:03:59.000604
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():

    try:
        raise PluginNotFound('Test message')
    except PluginNotFound as e:
        assert to_text(e).startswith('Test message')



# Generated at 2022-06-20 13:04:00.794398
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    parser = DocCLI(None).init_parser()
    doc_type = parser.get_default('type')
    assert doc_type == 'module', 'DocCLI().type should be "module"'
    assert parser.description, 'DocCLI().description should be set'


# Generated at 2022-06-20 13:04:07.149496
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    from collections import OrderedDict


# Generated at 2022-06-20 13:04:10.430013
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # DocCLI.add_fields(text, doc.pop('options'), limit, opt_indent)
    # DocCLI.add_fields(text, subdata, limit, opt_indent + '    ', return_values, opt_indent)
    # DocCLI.add_fields(text, doc.pop('returndocs'), limit, opt_indent, return_values=True)
    pass
# === end of testing  method DocCLI.add_fields ===



# Generated at 2022-06-20 13:04:11.858333
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath("lib/ansible/modules/system/yum.py") == "system"


# Generated at 2022-06-20 13:05:23.954714
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    # Set up mock objects

    # Initialise the class
    cli_obj = DocCLI(args=[])
    cli_obj.init_parser()


# Generated at 2022-06-20 13:05:35.316569
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-20 13:05:41.267200
# Unit test for method print_paths of class DocCLI

# Generated at 2022-06-20 13:05:46.171872
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {
        'author': 'somebody@redhat.com',
        'deprecated': {
            'why': 'Because I said so',
            'alternative': 'foo module',
            'removed_in': '2.9',
            'version': '2.8',
        },
        'description': 'This module does something.',
        'extends_documentation_fragment': ['other_plugin'],
    }
    output = DocCLI.format_plugin_doc(doc, 'module')
    assert output == u"""DOCUMENTATION:
module foo
    short_description: This module does something.
AUTHOR: somebody@redhat.com
DEPRECATED:
    Reason: Because I said so
    Will be removed in: Ansible 2.9
    Alternatives: foo module
"""
# Unit

# Generated at 2022-06-20 13:05:56.673121
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    doc = yaml.safe_load("""
        options:
          - name: test_boolean
            ini:
              - key: test boolean
                section: test_section
            default: true
            type: boolean
            description: test_boolean_description
            env:
              - name: TEST_BOOLEAN
            choices:
              - true
              - false
          - name: test_string
            ini:
              - key: test string
                section: test_section
            required: true
            description: test_string_description
            env:
              - name: TEST_STRING
        """)
    text = []
    DocCLI.add_fields(text, doc['options'], 80, "        ")

# Generated at 2022-06-20 13:06:01.604695
# Unit test for function jdump
def test_jdump():
    o = {'test': 'it worked', 'objects': ['1', '2', '3']}
    jdump(o)
    assert(True) # we are just ensuring the function doesn't raise an error



# Generated at 2022-06-20 13:06:13.626621
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-20 13:06:15.079126
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound()
    except PluginNotFound:
        pass



# Generated at 2022-06-20 13:06:28.268058
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    """
    Unit test for method get_man_text of class DocCLI
    """
    # import needed (for test) libs
    import sys

    # set display columns ... this is needed to make the test run on terminals with a different geometry
    display.columns = 80

    # get the doc data
    #    the json file was created from the doc in the module "file"
    #    with the following command:
    #
    #        python -c 'import ansible.module_utils.basic; import json; module = ansible.module_utils.basic.AnsibleModule(argument_spec={}); json.dump(module.DOCUMENTATION, file("file_DOCUMENTATION.json", "w"))'

# Generated at 2022-06-20 13:06:37.315006
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    instance = DocCLI(module_name='mymodule_name')
    assert instance.get_role_man_text('myrolename', {}) == ["> MYROLENAME    ()\n"]
    assert instance.get_role_man_text('myrolename', {'entry_points': {}, 'path': 'mypath'}) == ["> MYROLENAME    (mypath)\n"]
    assert instance.get_role_man_text('myrolename', {'entry_points': {'myentry_point': {}}, 'path': 'mypath'}) == ["> MYROLENAME    (mypath)\n", 'ENTRY POINT: myentry_point\n']

# Generated at 2022-06-20 13:07:55.082857
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():

    # Set up some fixtures - We create the DocCLI object and set up its '_doc_folder' attribute
    # to point to a fake 'modules' folder with fake module folders in it.
    # The '_doc_folder' attribute is used to invoke the method find_plugins.
    # This should return the names of the fake module folders.
    from shutil import rmtree
    from tempfile import mkdtemp

    # Create a fake 'modules' folder and its contents
    tempDir = mkdtemp()
    modulesDir = tempDir + '/library'
    os.makedirs(modulesDir)
    for plugin in ("lookup_plugins", "module_utils", "callback_plugins", "filter_plugins", "test_plugins"):
        pluginDir = tempDir + '/' + plugin
        os.makedirs(pluginDir)
    os

# Generated at 2022-06-20 13:07:59.532115
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {'description': 'This is a test module\ninitialized from class DocCLI', 'filename': '../test_DocCLI.py'}
    assert DocCLI.get_man_text(doc, '', 'bs4') == '> BS4    (../test_DocCLI.py)\nThis is a test module\ninitialized from class DocCLI'
    doc = {'description': 'This is a test module\ninitialized from class DocCLI.', 'filename': '../test_DocCLI.py', 'options': {'description': 'This option is mandatory', 'type': 'str', 'required': True}}

# Generated at 2022-06-20 13:08:06.869144
# Unit test for function jdump
def test_jdump():
    '''jdump test'''
    assert jdump({ "test" : "test string" }) == json.dumps({ "test" : "test string" }, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)


# Generated at 2022-06-20 13:08:18.723343
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # Test for format_snippet method of DocCLI class
    # create a temporary file descriptor for testing
    cwd = os.path.dirname(os.path.realpath(__file__))
    # module_name is the value of the --type argument
    module_name = 'copy'
    # set the AnsibleModule class and AnsibleModuleBase class
    doc = DocCLI(args=dict(type=module_name))
    # doc.get_doc() is the dict object that would be returned by create_module_docs() of module_docs.py
    # create_module_docs() method is called by get_doc() method of DocCLI class
    # create_module_docs() is a method of module_docs.py
    doc.get_doc()
    # call the _format_snippet() method, which we

# Generated at 2022-06-20 13:08:32.581488
# Unit test for method display_plugin_list of class DocCLI

# Generated at 2022-06-20 13:08:37.824053
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    doccli = DocCLI()
    source = '''
- name: unit test 
  hosts: localhost
  tasks:
  - name: foo
    debug: msg=bar
      # FIXME: this is a task
'''
    wanted = '''
- name: unit test 
  hosts: localhost
  tasks:
  - name: foo
    debug: msg=bar
      # FIXME: this is a task
'''
    got = doccli.format_snippet(source) 
    assert got == wanted


# Generated at 2022-06-20 13:08:40.048859
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    CLItest = DocCLI()
    CLItest.get_all_plugins_of_type()


# Generated at 2022-06-20 13:08:53.482310
# Unit test for method namespace_from_plugin_filepath of class DocCLI

# Generated at 2022-06-20 13:09:08.416186
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role = {"name":"test_role","deprecated":{},"entry_points":{"main":{"module_path":"test_module.py","attributes":{"test_attr":{"test_default_value":"default_value"},"version":{"description":"The version of something."}},"options":{"test_option":{"description":"The description of the test option","required":True}}},"another":{"module_path":"another_test_module.py","attributes":{},"options":{}}},"path":"test_role","description":"A test role."}

# Generated at 2022-06-20 13:09:10.033007
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc=DocCLI()
    doc.display_plugin_list()

# Generated at 2022-06-20 13:11:10.223043
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    AnsibleCollectionConfig.set_collection_playbook_paths(["/tmp/collections"])
    coll_filter = {"names": [u"ansible.builtin"]}

    path = os.path.join(os.path.dirname(__file__), "test_add_collection_plugins_collection")
    os.mkdir(path)
    os.mkdir(os.path.join(path, "plugins"))
    os.mkdir(os.path.join(path, "plugins", "action"))
    open(os.path.join(path, "plugins", "action", "my_action.py"), "a").close()
    open(os.path.join(path, "plugins", "action", "my_action.py.orig"), "a").close()

# Generated at 2022-06-20 13:11:15.092072
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # expand verbose output to stderr
    _h = logging.StreamHandler(sys.stderr)
    _h.setLevel(logging.DEBUG)

    logging.getLogger('ansible').addHandler(_h)
    # quiet output to stdout
    logging.getLogger('ansible').setLevel(logging.CRITICAL)

    ansible_doc = DocCLI()
    cli_arguments = AnsibleCLI(args=['ansible-doc', '--version'], )
    ansible_doc.options = cli_arguments.parse()
    # Load docstring from module documentation
    plugin = None
    plugin_type = ""
    collection = None
    docs = ansible_doc._load_docstring(plugin=plugin, plugin_type=plugin_type, collection=collection)
    # print

# Generated at 2022-06-20 13:11:26.574919
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    doccli_parser = argparse.ArgumentParser()
    doccli_parser.add_argument('--type', default='module', dest='type', help='Type of documentation to display, '
                                                                             'one of: {0}'.format(
                                                                                 ', '.join(DocCLI.DOCUMENTABLE)))
    doccli_parser.add_argument('--path', default=None, dest='path', help='Specify path to look for plugins of the '
                                                                          'specified type '
                                                                          '(useful when working on a development, '
                                                                          'uninstalled, version of Ansible)')
    doccli_parser.add_argument('--parseable', default=False, dest='parseable', action='store_true',
                               help='show parseable output instead of text')


# Generated at 2022-06-20 13:11:28.398321
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound("message")
    except PluginNotFound as e:
        assert e.message == "message"



# Generated at 2022-06-20 13:11:30.808259
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc = DocCLI()
    plugins = doc.find_plugins()
    assert isinstance(plugins, dict)



# Generated at 2022-06-20 13:11:34.882034
# Unit test for function jdump
def test_jdump():
    text = {'foo':[{}, {}]}
    try:
        jdump(text)
    except TypeError as e:
        raise AssertionError('TypeError was raised.')


# Generated at 2022-06-20 13:11:39.975912
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound('plugin_type', 'plugin_name', 'collection', 'path')
    except PluginNotFound as e:
        assert e.plugin_type == 'plugin_type'
        assert e.plugin_name == 'plugin_name'
        assert e.collection == 'collection'
        assert e.path == 'path'



# Generated at 2022-06-20 13:11:47.774424
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    tty = mock.patch('ansible.cli.doc.DocCLI.is_tty', return_value=True)
    tty.start()
    display = mock.patch('ansible.cli.doc.display', columns=100)
    display.start()

# Generated at 2022-06-20 13:11:53.145327
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    cli = DocCLI()
    args = {'refresh_cache': False}
    expected = {'refresh_cache': False}
    actual = cli.post_process_args(args)
    assert actual == expected, 'Expected: %s, Actual: %s' % (expected, actual)


# Generated at 2022-06-20 13:12:05.425556
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    '''Unit test for method print_paths of class DocCLI'''
    from ansible.cli.doc import DocCLI
    from ansible.utils.display import Display
    from ansible.utils.color import stringc

    # Patch the _get_collection_name method of the DocCLI class (it's a private
    # method, so we need to replace the name with a leading underscore)
    def mock_get_collection_name(name, collection_list):
        return name
    DocCLI._get_collection_name = mock_get_collection_name

    # Patch the display methods to suppress output
    Display.display = lambda self, data, *args, **kwargs: None
    Display.display_v2 = lambda self, data, *args, **kwargs: None