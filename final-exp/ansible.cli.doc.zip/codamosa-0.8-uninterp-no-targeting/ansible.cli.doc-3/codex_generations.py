

# Generated at 2022-06-20 13:07:04.800966
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # A example of a Valid instance of DocCLI
    myDocCli = DocCLI()

    # Testing instance add_field method with no suboptions
    opt = {'description': ['A ``string`` value containing the number of'], 'required': True, 'type': 'str', 'version_added': '2.1'}
    text = []
    DocCLI.add_fields(text, opt, 100, '')
    assert text == ['description: A ``string`` value containing the number of', 'required: True', 'type: str', 'version_added: 2.1']

    # Testing instance add_field method with suboptions

# Generated at 2022-06-20 13:07:11.709254
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    test_c = DocCLI()
    mock_display = MagicMock(display)
    test_c.display = mock_display
    test_c.C.DEFAULT_MODULE_PATH = ['foo', 'bar']
    test_c.C.DEFAULT_ROLES_PATH = ['baz']
    test_c.print_paths()

# Generated at 2022-06-20 13:07:15.639041
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    import doctest
    failure_count, test_count = doctest.testmod(verbose=True)
    sys.exit(failure_count)

# Generated at 2022-06-20 13:07:19.930264
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    '''
    Unit test for method run of class DocCLI
    '''
    ans_obj = DocCLI()
    result = ans_obj.run()
    print(result)

# Generated at 2022-06-20 13:07:31.468200
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Create a copy so we don't modify the original
    doc = {'description': 'Some description', 'seealso': [{'description': 'Sample description', 'link': 'Sample link', 'name': 'Sample name'}]}
    doc = dict(doc)
    opt_indent = "        "
    text = []
    pad = display.columns * 0.20
    limit = max(display.columns - int(pad), 70)
    DocCLI.add_fields(text, doc, limit, opt_indent)

# Generated at 2022-06-20 13:07:39.683794
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Test the method get_man_text of class DocCLI
    test_doc = {'DOCUMENT_ARGUMENTS': """
        options:
            description: Module options
            suboptions:
                foo:
                    description: |
                        This is a really long description because
                        it's important to be verbose.

                        We should wrap this to be sure it's legible.
                    required: yes
                    choices:
                        - option1
                        - option2
                bar:
                    description: This is a short description
                    required: yes
                    choices:
                        - option1
                        - option2
            baz:
                description: This is a short description
                required: yes
                choices:
                    - option1
                    - option2
        seealso:
        - module: yum"""
    }
    # A complete test is not possible

# Generated at 2022-06-20 13:07:54.559493
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    d = DocCLI()
    d._get_collection_name = mock.Mock(return_value='collection')
    d._create_plugin_docs = mock.Mock(return_value={'doc': 'text'})

    mock_stdout = mock.Mock()
    mock_stdout.write = mock.Mock()

    with mock.patch('sys.stdout', mock_stdout):
        d.print_paths(["name"], "Module", "Documentation")

    assert mock_stdout.write.call_count == 2
    mock_stdout.write.assert_has_calls([
        mock.call("========================================\n"),
        mock.call("collection.name (./collection/name/__init__.py) (DOCUMENTATION)\n"),
    ])


# Generated at 2022-06-20 13:08:03.219636
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    with open('../../../../test/units/doccli/data/example_mods.yml', 'rb') as example_mods:
        example_mods = yaml.safe_load(example_mods)

    with open('../../../../test/units/doccli/data/example_roles.yml', 'rb') as example_roles:
        example_roles = yaml.safe_load(example_roles)

    for entry_point, doc in example_mods['modules'].items():
        doc_clier = DocCLI(entry_point, doc)
        text = doc_clier.get_man_text(doc)
        assert isinstance(text, string_types)


# Generated at 2022-06-20 13:08:04.403193
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    assert callable(DocCLI.post_process_args)


# Generated at 2022-06-20 13:08:08.528098
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    assert DocCLI(None).get_plugin_metadata(None) == []

if __name__ == "__main__":
    print(DocCLI(None).get_plugin_metadata(None))

# Generated at 2022-06-20 13:11:23.241523
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.errors import AnsibleError
    loader = AnsibleCollectionLoader()

    doc = DocCLI()
    collection_name = 'ansible_collections.collection1.ns1'
    plugin_type = 'module'
    # Testing with the path to a collection
    plugins = doc.find_plugins(collection_name, plugin_type, loader=loader)
    assert isinstance(plugins, list)
    assert len(plugins) == 1
    assert isinstance(plugins[0], string_types)

    plugin_type = 'cliconf'
    # Testing with the path to a collection
    plugins = doc.find_plugins(collection_name, plugin_type, loader=loader)
    assert isinstance(plugins, list)
    assert len(plugins) == 0



# Generated at 2022-06-20 13:11:25.773221
# Unit test for constructor of class DocCLI
def test_DocCLI():
    '''Unit test for constructor of class DocCLI'''
    print('')
    colorama.init()
    test_object = DocCLI()
    print(test_object)

# Generated at 2022-06-20 13:11:32.567373
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    paths_to_find = ['lib/ansible/plugins/inventory']
    result = "inventory\n"
    cli_instance = DocCLI()
    assert cli_instance.print_paths(paths_to_find) == result

# Generated at 2022-06-20 13:11:43.699052
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    DocCLI.IGNORE = DocCLI.IGNORE + (context.CLIARGS['type'],)
    opt_indent = "        "
    text = []
    pad = display.columns * 0.20
    limit = max(display.columns - int(pad), 70)
    doc = {}
    
    # Add doc['description']
    doc['description'] = 'This will copy a file from the local or remote machine to a location on the remote machine.\nThis module is also supported for Windows targets.'
    text.append("%s\n" % textwrap.fill(DocCLI.tty_ify(desc), limit, initial_indent=opt_indent, subsequent_indent=opt_indent))

    # Add doc['version_added']
    doc['version_added'] = '0.1'
   

# Generated at 2022-06-20 13:11:47.007287
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    cli_doc = DocCLI()
    result = cli_doc.get_all_plugins_of_type('module')
    assert isinstance(result, dict)
    assert 'copy' in result
    assert result['copy']['plain_summary'] == 'copies a file from local to remote'


# Generated at 2022-06-20 13:11:48.590054
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    assert DocCLI.get_all_plugins_of_type('modules')

# Generated at 2022-06-20 13:11:52.858184
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    DocCLI.init_parser(top_parser)
    assert isinstance(DocCLI.parser, AnsibleParser)
    assert DocCLI.parser.option_help != ''
    assert DocCLI.parser.usage != ''


# Generated at 2022-06-20 13:11:54.865989
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    _plugins = DocCLI.find_plugins()
    assert isinstance( _plugins, set )
    assert len(_plugins) > 0
