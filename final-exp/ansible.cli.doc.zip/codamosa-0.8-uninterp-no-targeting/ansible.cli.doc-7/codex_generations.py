

# Generated at 2022-06-20 13:04:46.265027
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    with mock.patch('ansible.plugins.loader.find_all_matching_plugins', side_effect=_test_find_plugins):
        cli = DocCLI()
        cli.setup()
        plugin_results = cli.find_plugins()

        assert plugin_results['alias'] == ['plugins/action/dummy.py']
        assert plugin_results['become'] == ['plugins/become/dummy.py']
        assert plugin_results['callback'] == ['plugins/callback/dummy.py']
        assert plugin_results['cliconf'] == ['plugins/cliconf/dummy.py']
        assert plugin_results['connection'] == ['plugins/connection/dummy.py']
        assert plugin_results['httpapi'] == ['plugins/httpapi/dummy.py']
        assert plugin_results['filter']

# Generated at 2022-06-20 13:04:48.080350
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    assert PluginNotFound('test')
    assert PluginNotFound('test').args == ('test',)



# Generated at 2022-06-20 13:04:49.923351
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    module_json = None
    cli_doc = DocCLI()
    man_text = cli_doc.get_man_text(module_json)
    assert man_text == None

# Generated at 2022-06-20 13:04:56.316232
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.common._collections_compat import Mapping

    cli = DocCLI('foo')
    cli.module_finder = DummyModuleFinder()

    cli.options = {'type': 'action'}
    p1 = cli.find_plugins()
    assert isinstance(p1, Mapping)
    assert len(p1) == 1
    assert sorted(list(p1.keys())) == ['foo_action']

    cli.options = {'type': 'cache'}
    p2 = cli.find_plugins()
    assert isinstance(p2, Mapping)
    assert len(p2) == 1
    assert sorted(list(p2.keys())) == ['foo_cache']

    cli

# Generated at 2022-06-20 13:05:05.875941
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Input parameters for the method
    section_name = 'base'
    display_paths = ['base/roles/testrole/defaults']

    # Execution of the method
    result = DocCLI.print_paths(section_name, display_paths)

    # Verification of the method output
    assert not result



# Generated at 2022-06-20 13:05:17.398566
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-20 13:05:21.813684
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():

    # set up
    argv = ['ansible-doc']
    context._init_global_context(args=argv)

    # run code to be tested
    d = DocCLI()
    f = d.find_plugins()

    # check results
    assert isinstance(f, sortedcontainers.SortedList)
    assert f[0] == "one_module"


# Unit test code for method get_man_text of class DocCLI

# Generated at 2022-06-20 13:05:33.582254
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # TODO: fix these tests to not require network IO
    try:
        from six.moves import urllib_request as urllib
    except ImportError:
        from six.moves import urllib
    # TODO: check this path
    snapshot_path = os.path.join(os.path.dirname(__file__), 'data', 'module_docs_snapshot.json')
    # TODO: figure out how to run the module_utils tests
    # if os.path.exists(snapshot_path):
    #     data = open(snapshot_path, 'rb').read()
    # else:
    data = urllib.urlopen("http://docs.ansible.com/ansible/modules.json").read()
    module_docs = json.loads(data)
    # if not os.

# Generated at 2022-06-20 13:05:41.675784
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    """test the constructor of class PluginNotFound"""
    obj = PluginNotFound(plugin_type='mod', plugin_name='foo')
    assert obj.plugin_type == 'mod' and obj.plugin_name == 'foo'


# Generated at 2022-06-20 13:05:47.731508
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = DocCLIArgs()
    args.type = "module"
    args.all = True
    args.output_format = "json"
    args.action = "show"
    doc = DocCLI(args=args)
    doc.run()

DocCLI.run = test_DocCLI_run


# Generated at 2022-06-20 13:07:22.431977
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = AnsibleDocCLI(["-t", "module", "-l"])
    doc.find_plugins()
    doc.display_plugin_list()


# Generated at 2022-06-20 13:07:25.039363
# Unit test for constructor of class DocCLI
def test_DocCLI():
    # A simple test to check whether the DocCLI constructor works
    doc_cli = DocCLI()
    assert isinstance(doc_cli, DocCLI)


# Generated at 2022-06-20 13:07:35.402249
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    doc = {}
    doc['foo'] = "bar"
    doc['bar'] = "foo"
    text = []
    DocCLI.add_fields(text, doc, 200, '')
    text = "\n".join(text)
    assert text == "bar: foo\nfoo: bar"

    doc = {}
    doc['foo'] = "bar"
    doc['bar'] = {}
    doc['bar']['foo1'] = "bar1"
    doc['bar']['foo2'] = "bar2"
    text = []
    DocCLI.add_fields(text, doc, 200, '')
    text = "\n".join(text)
    assert text == "bar:\n  foo1: bar1\n  foo2: bar2\nfoo: bar"

    doc = {}
    doc

# Generated at 2022-06-20 13:07:37.611027
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc_cli = DocCLI()
    result = doc_cli.find_plugins(['foo', 'bar'], 'modules')
    assert result == []


# Generated at 2022-06-20 13:07:44.016050
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.plugins.loader import module_loader
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import get_docstring

    display = Display()
    module_name = 'group'
    collection_name = 'core'
    plugin_type = 'module'
    doc, plainexamples, returndocs, metadata = get_docstring(module_loader,
            module_name=module_name,
            collection_name=collection_name,
            plugin_type=plugin_type)
    text = DocCLI.get_man_text(doc, collection_name=collection_name, plugin_type=plugin_type)
    assert display.columns == 262
    assert 'REMOVE_HOST_FROM_GROUP' in text

# Generated at 2022-06-20 13:07:48.932247
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    def mock_get_all_plugin_paths(plugin_type):
        return {'lookup': {'foo.bar': '/lookup', 'bar.bar': '/lookup'}}

    paths_map = {
        'module': {'foo.bar': '/module', 'bar.bar': '/module'},
        'lookup': {'foo.bar': '/lookup', 'bar.bar': '/lookup'},
    }

    with patch('ansible.cli.doc.get_all_plugin_paths', mock_get_all_plugin_paths):
        doccli = DocCLI()
        with patch('ansible.cli.doc.display') as display:
            doccli.print_paths('module', paths_map)
            assert display.columns == 100
            module_display = display.display.call_

# Generated at 2022-06-20 13:08:00.251088
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    display = Display()

# Generated at 2022-06-20 13:08:02.510947
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    args = DocCLI.post_process_args(['gather_facts', 'setup', 'ping'])
    assert args.module_list == ['command', 'setup', 'ping']

# Generated at 2022-06-20 13:08:09.969884
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    import __builtin__
    __builtin__._ = lambda x: x
    setattr(__builtin__, 'N_(', lambda x: x)
    setattr(__builtin__, 'N_PLURAL', lambda x: x)

    from ansible.cli.doc import DocCLI
    from ansible.plugins import module_loader, module_utils_loader
    from collections import namedtuple
    from ansible.module_utils import basic
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.utils.display import Display
    from ansible.plugins.loader import all as all_plugins, get_all_plugin_loaders

# Generated at 2022-06-20 13:08:10.858817
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    pass

# Generated at 2022-06-20 13:09:36.306773
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    command = ['ansible-doc']
    args = DocCLI.parse(command)
    DocCLI.post_process_args(args)

    assert args.type == 'module'
    assert args.version is False
    assert args.fragment == ''
    assert args.output_file == ''


# Generated at 2022-06-20 13:09:38.447763
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    assert DocCLI.get_plugin_metadata('uri') == 'A connection plugin for working with uris.'


# Generated at 2022-06-20 13:09:40.810276
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    assert doc.get_all_plugins_of_type() is not None


# Generated at 2022-06-20 13:09:49.267560
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    # Passing a bunch of args to a method would be difficult to read as a unittest...
    module_args = dict(
        type=None,
        all=False,
        listt=False,
        search=None,
        path=None,
        collection_name=None,
        collection_paths=False,
        plugin_type=None,
        output_file=None,
        one_liner=False,
        docs_fragment=None,
        index_only=None,
        rewrite=False,
    )
    cli_args = dict(
        module_collection_paths=[]
    )
    doc_cli = DocCLI(None, None)
    actual_result = doc_cli.post_process_args(**dict(module_args, **cli_args))
    expected_result = dict

# Generated at 2022-06-20 13:10:00.960117
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    mixin = RoleMixin()
    assert mixin

    # inject a faux role path for testing
    role_path = '/dev/null/roles'
    role1_path = os.path.join(role_path, 'role1')
    os.makedirs(role1_path)
    os.makedirs(os.path.join(role1_path, 'meta'))
    spec_file = os.path.join(role1_path, 'meta', 'argument_specs.yml')
    spec_main_file = os.path.join(role1_path, 'meta', 'main.yml')
    with open(spec_file, 'w') as f:
        f.write('argument_specs:\n  myarg: {}')

# Generated at 2022-06-20 13:10:07.535586
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    test_file = 'plugins/action/synchronize.py'
    expected = 'action'
    output = DocCLI.namespace_from_plugin_filepath(test_file)
    assert output == expected

    test_file = 'plugins/lookup/network.py'
    expected = 'lookup'
    output = DocCLI.namespace_from_plugin_filepath(test_file)
    assert output == expected

    test_file = 'plugins/connection/file.py'
    expected = 'connection'
    output = DocCLI.namespace_from_plugin_filepath(test_file)
    assert output == expected

    #Paths which are not correct 
    test_file = 'plugins/ansible/modules/network/nxos/nxos_vpc.py'

# Generated at 2022-06-20 13:10:11.099036
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = set()
    plugin_type = 'action'
    coll_filter = None
    add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list



# Generated at 2022-06-20 13:10:12.921558
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    pl = {}
    add_collection_plugins(pl, 'filter')
    assert 'json_query' in pl



# Generated at 2022-06-20 13:10:16.204072
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc = DocCLI()
    with pytest.raises(AnsibleOptionsError):
        options = doc.parse()
        doc.run(options)

    options = doc.parse(args=['--all'])
    doc.run(options)

# Generated at 2022-06-20 13:10:31.848765
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test cases in the form:
    # (input, expected)
    test_cases = [
        ('action', {'full_name': 'action'}),
        ('connection', {'full_name': 'connection'}),
        ('shell', {'full_name': 'shell'}),
        ('modules/system/pkgmgr', {'full_name': 'pkgmgr', 'type': 'modules', 'path': 'system'}),
        ('action/user', {'full_name': 'user', 'type': 'action', 'path': 'user'}),
    ]

    for idx, test_case in enumerate(test_cases):
        input = test_case[0]
        expected = test_case[1]

        p1 = DocCLI()