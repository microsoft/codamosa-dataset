

# Generated at 2022-06-20 13:03:48.013310
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    pass  # TODO

# Generated at 2022-06-20 13:03:50.358034
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    cli = DocCLI()
    args = []
    cli.post_process_args(args)


# Generated at 2022-06-20 13:03:57.572023
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    def test_snippet(snippet, eargs, ekwargs):
        new_kwargs = copy.deepcopy(kwargs)
        show_snippet(new_kwargs, snippet)
        assert new_kwargs == ekwargs
        assert args == eargs

    args = None

    kwargs = dict(
        indicators=['+++'],
        indent=8,
        merge=False,
        max_width=display.columns,
        separators=[': '],
        wordsep=' ',
    )


# Generated at 2022-06-20 13:04:00.554581
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    test_args = {
        'module_name': 'test',
    }
    assert(not 'module_name' in DocCLI.post_process_args(test_args))



# Generated at 2022-06-20 13:04:06.962672
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():

    # Store command line arguments so we can restore them after running this unit test
    argv = sys.argv
    sys.argv = ["DocCLI"]

    # Create a new plugin loader and check for Ansible action plugins
    loader = plugin_loader.ActionModuleLoader('./test/functional/plugins/action/', './test/functional/plugins/action/', C.DEFAULT_ACTION_PLUGIN_PATH)

    # Create a new DocCLI object, passing in the plugin loader.
    cli = DocCLI(loader)

    # Pass in the action plugin type to get_all_plugins_of_type
    plugins = cli.get_all_plugins_of_type('action')

    # Check that the all action plugins were loaded.
    assert len(plugins.keys()) > 0

    # Check that an action plugin was loaded named

# Generated at 2022-06-20 13:04:11.079494
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    # this function only tests the constructor, because that is all we need to
    # run the class methods.
    unit_test_helper(RoleMixin, 'roles', 'roles_path')



# Generated at 2022-06-20 13:04:14.038956
# Unit test for function jdump
def test_jdump():
    display.verbosity = 4
    text = [{1: [1, 2, 3], 2: {1: 'foo', 2: 'bar'}}, [1, 2, 3, 4, 5], 'string']
    jdump(text)

# Generated at 2022-06-20 13:04:17.695327
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    # Set the command line arguments so that they will be picked up when creating the parser object
    sys.argv = ['ansible-doc', 'net_template']
    cmdline = DocCLI.parser().parse_args()
    assert cmdline.module.lower() == 'net_template', 'Module name should be "net_template"'
    assert cmdline.verbosity == 0, 'verbosity should be 0'


# Generated at 2022-06-20 13:04:22.421147
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-20 13:04:23.096309
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # TODO: Implement
    pass

# Generated at 2022-06-20 13:06:02.193921
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    args = ["-h"]
    args = params.parse_args(args, None)
    doctool = DocCLI()
    doctool.init_parser(args)



# Generated at 2022-06-20 13:06:14.003161
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    from ansible.cli.doc import DocCLI
    from ansible.module_utils._text import to_native
    import shutil
    import os
    import sys

    temp_dir = os.path.join(os.path.dirname(__file__), 'test_ansible_doc')
    temp_sys_path = temp_dir + os.pathsep + os.path.pathsep.join(sys.path)
    # generating role test data
    role_name = "test_role"

# Generated at 2022-06-20 13:06:19.144148
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    cmd = DocCLI(
        runas_opts=runas_opts,
        module_opts=module_opts,
        async_opts=async_opts
    )

    # TODO: This test case needs to be updated
    command = '-M'
    module_list = frozenset(['core', 'extras', 'foo'])
    module_path = 'core'
    result = cmd.print_paths(command, module_list, module_path)


# Generated at 2022-06-20 13:06:22.336369
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    # set up object
    doc = DocCLI()
    # call the method
    r = doc.init_parser()
    assert r == True


# Generated at 2022-06-20 13:06:24.096769
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    pass


# Generated at 2022-06-20 13:06:27.896317
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    doc = dict()
    text = []
    limit = 2
    opt_indent = "        "
    DocCLI.add_fields(text, doc, limit, opt_indent, return_values=True)
    assert(text == [])

# Generated at 2022-06-20 13:06:31.057957
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
  command_args = ['ansible-doc']
  doc_CLI = DocCLI()
  parser = doc_CLI.init_parser(command_args)
  parser.print_help()

# Generated at 2022-06-20 13:06:40.018976
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    doc = DocCLI(
        args = None,
        collected_data = None,
        callback = None,
        loader = None,
        inventory = None,
        variable_manager = None,
        nocolor = None,
        verbosity = 0,
        version = None
    )

    assert doc.parser is not None
    assert isinstance(doc.parser, argparse.ArgumentParser)



# Generated at 2022-06-20 13:06:49.576542
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():

    import sys
    import unittest

    # disable command line splits in order to test.
    setattr(sys, 'split_args_with_spaces', False)

    # Mocking and monkey patching are used so that we can test
    # the print_paths method without explicitly verifying the
    # order of printed paths, which is non-deterministic.
    # We are able to test the printed paths by using a
    # StringIO object and asserting that the output matches
    # what we expect.
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    from unittest.mock import patch
    from ansible.cli.doc import DocCLI

    def mock_title(self, s):
        return s


# Generated at 2022-06-20 13:07:02.824960
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
	mock_role = 'mockrole'
	mock_entrypoint_name = 'main'
	mock_entrypoint_description = 'this is just a description'
	mock_return = ["""
		> MOCKROLE    (path)
		ENTRY POINT: main - this is just a description
		
		OPTIONS (= is mandatory):
		
		ATTRIBUTES:
		
		"""]

	mock_role_json = {
		'path': 'path',
		'entry_points': {
			mock_entrypoint_name: {
				'short_description': mock_entrypoint_description
			}
		}
	}
	
	mock_self = mock.Mock()
	mock_

# Generated at 2022-06-20 13:08:45.069938
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    DocCLI.init_parser(parser=None)
    assert True


# Generated at 2022-06-20 13:08:55.346486
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc = DocCLI('.')
    plugin_dirs = (
        './lib/ansible/modules/network/fortios',
        './lib/ansible/modules/network/panos',
        './lib/ansible/modules/cloud/amazon',
        './lib/ansible/modules/system/linux',
        './lib/ansible/modules/not_a_dir'
    )
    collection_dirs = (
        './lib/ansible/collections/fortinet/fortios',
        './lib/ansible/collections/ansible_collections/fortinet/fortios',
        './lib/ansible/collections/not_a_dir'
    )

# Generated at 2022-06-20 13:08:57.801995
# Unit test for method run of class DocCLI
def test_DocCLI_run():
  # Create a DocCLI object
  doc_cli_instance = DocCLI(["ansible-doc"])
  doc_cli_instance.run()


# Generated at 2022-06-20 13:09:09.797609
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Assert that the get_man_text method of DocCLI class prints the
    # value of doc['plainexamples'] in the output
    doc = {'plainexamples': 'example'}
    assert "EXAMPLES:\nexample" in DocCLI.get_man_text(doc)
    
    # Assert that the get_man_text method of DocCLI class prints the
    # value of doc['description'] in the output
    doc = {'description': 'description'}
    assert 'description' in DocCLI.get_man_text(doc)
    
    # Assert that the get_man_text method of DocCLI class prints the
    # value of doc['author'] in the output
    doc = {'author': 'author'}
    assert 'Author: author' in DocCLI.get_man

# Generated at 2022-06-20 13:09:13.903309
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    # The code below tests that the constructor of the class RoleMixin
    # throws no errors and returns an instance of RoleMixin().

    # Create collection directory
    collection_name = 'ansible_collections.namespace.test'
    collection_path = os.path.join(tempfile.gettempdir(), 'ansible_collections', 'namespace', 'test')
    os.makedirs(collection_path)

    # Create first role
    role1_path = os.path.join(collection_path, 'roles', 'role1')
    os.makedirs(role1_path)
    with open(os.path.join(role1_path, 'meta', 'main.yml'), 'w') as f:
        f.write('---\n')
        f.write('argument_specs:\n')
       

# Generated at 2022-06-20 13:09:18.971672
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    snippet = "test"
    extra_vars = None
    print(DocCLI.format_snippet(snippet, extra_vars))

if __name__ == '__main__':
    test_DocCLI_format_snippet()

# Generated at 2022-06-20 13:09:26.826707
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    import sys
    import tempfile
    temp_fd, temp_path = tempfile.mkstemp()
    with open(__file__, 'r') as f:
        src = f.read()
        with os.fdopen(temp_fd, 'w') as fp:
            fp.write(src)

    # create an instance of the class
    if not sys.stdout.isatty():
        display = Display()
        display.display("skipping pager test: stdout is not a tty")
    else:
        c = DocCLI()
        c.parse()
        c.run()

    os.remove(temp_path)

# Generated at 2022-06-20 13:09:42.064259
# Unit test for function jdump
def test_jdump():
    data = {1: 2, 'a': 'b'}
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    class Test(unittest.TestCase):
        def test_jdump(self):
            self.assertEqual(jdump(data), '{\n    "1": 2, \n    "a": "b"\n}')
        def test_None(self):
            self.assertRaises(AnsibleError, jdump, None)
        def test_str(self):
            self.assertRaises(AnsibleError, jdump, 'test')
        def test_int(self):
            self.assertRaises(AnsibleError, jdump, 1)

# Generated at 2022-06-20 13:09:44.508237
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    exception = PluginNotFound('module', 'non-existent')
    assert exception.module == 'module'
    assert exception.name == 'non-existent'


# Generated at 2022-06-20 13:09:48.894146
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    test_args = {
        "paths": []
    }
    DocCLI._print_paths(test_args)
    with pytest.raises(AnsibleError) as excinfo:
        test_args["paths"] = ['docs']
        DocCLI._print_paths(test_args)
    assert excinfo.value.args[0] == 'Unable to open docs'
