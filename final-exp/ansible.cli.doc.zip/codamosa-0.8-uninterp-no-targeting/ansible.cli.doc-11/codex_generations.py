

# Generated at 2022-06-20 13:03:36.698029
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    d = DocCLI()
    d.display_plugin_list()


# Generated at 2022-06-20 13:03:37.427710
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    pass

# Generated at 2022-06-20 13:03:46.927960
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-20 13:03:48.250576
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    cliargs = {}
    doccli = DocCLI(cliargs)
    doccli.post_process_args()

# Generated at 2022-06-20 13:03:50.708830
# Unit test for function jdump
def test_jdump():
    try:
        jdump(None)
        assert(False)
    except AnsibleError as e:
        assert('We could not convert' in to_native(e))



# Generated at 2022-06-20 13:03:57.206673
# Unit test for constructor of class DocCLI
def test_DocCLI():
    '''Unit test for constructor of class DocCLI'''
    obj = DocCLI()
    assert obj._docopt is not None
    assert obj.definitions is not None
    assert obj.base_dir is not None
    #assert obj.plugin_type is not None
    assert obj.plugin_type == ''
    assert obj.force is not None

    obj = DocCLI(['ansible-doc', '-t', 'module', '-l'])
    assert obj._docopt is not None
    assert obj.definitions is not None
    assert obj.base_dir is not None
    assert obj.plugin_type == 'module'
    assert obj.force is not None



# Generated at 2022-06-20 13:04:04.913218
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Setup
    inventory_file = tempfile.mktemp()
    testcase_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'testcase', 'test_plugin.yml')
    with open(testcase_file, 'rb') as testcase_fd:
        testcase_string = testcase_fd.read()
    with open(inventory_file, 'wb') as inventory_fd:
        inventory_fd.write(testcase_string)
    env = {'ANSIBLE_INVENTORY_ENABLED': 'yaml', 'ANSIBLE_INVENTORY': inventory_file}
    # Test

# Generated at 2022-06-20 13:04:09.277746
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    import ansible.plugins
    d = DocCLI()
    paths = [ansible.plugins.__path__[0]]
    # Test for module with complex documentation
    data = d.format_plugin_doc('command', paths)
    assert isinstance(data, dict)
    # Test for module with empty documentation
    assert d.format_plugin_doc('no_documentation', paths) == dict()
    assert d.format_plugin_doc('not_a_valid_module_name', paths) == dict()



# Generated at 2022-06-20 13:04:11.410986
# Unit test for constructor of class DocCLI
def test_DocCLI():
    (option_list, args) = DocCLI.parse()
    doc = DocCLI(option_list, args)
    print('doc = %s' % doc)
    assert doc.options.list == False
    assert doc.options.all == False
    assert len(doc.args) == 0


# Generated at 2022-06-20 13:04:17.608244
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    from ansible.cli.doc import DocCLI
    doc = {'plainexamples': 'test plain examples', 'short_description': 'test short description', 'description': 'test description', 'ansible_facts': {'collection_name': 'test collection name'}, 'version_added': '2.4', 'options': {'new_attribute': {'version_added': '2.4'}, 'existing_attribute': {'version_added': '2.4'}}, 'extends_documentation_fragment': ['test_module', 'another_module'], 'seealso': [{'module': 'test module', 'description': 'test description'}, {'module': 'another module', 'description': 'another description'}, {'module': 'yet_another_module', 'description': 'yet another description'}]}

# Generated at 2022-06-20 13:05:12.588790
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    assert isinstance(DocCLI().find_plugins(), type(None))


# Generated at 2022-06-20 13:05:18.334004
# Unit test for function jdump
def test_jdump():
    sample = {'foo': 'bar'}
    try:
        display.display(json.dumps(sample, cls=AnsibleJSONEncoder, sort_keys=True, indent=4))
    except TypeError as e:
        display.vvv(traceback.format_exc())
        raise AnsibleError('We could not convert all the documentation into JSON as there was a conversion issue: %s' % to_native(e))


# Generated at 2022-06-20 13:05:24.711535
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():

    # Remove the previously dumped file
    filename = os.path.join(os.path.expanduser('~'), '.ansible', 'tmp', '%s_%s.txt' % (socket.gethostname(), os.getpid()))
    if os.path.exists(filename):
        os.remove(filename)

    # Prepare the test opts

# Generated at 2022-06-20 13:05:35.931228
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    import json
    import tempfile
    temp_dir = tempfile.mkdtemp()
    temp_file = temp_dir + "/test.json"

# Generated at 2022-06-20 13:05:37.190752
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound
    except PluginNotFound:
        pass



# Generated at 2022-06-20 13:05:38.691021
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
	assert True


# Generated at 2022-06-20 13:05:51.744729
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Test with CLI args
    with mock.patch.dict(os.environ, {'ANSIBLE_COLLECTIONS_PATHS': '/home/user/.ansible/collections'}, clear=True):
        context.CLIARGS = {'type': 'action', 'subdir': None, 'url': 'something-random', 'directory': False, 'tree': True, 'verbosity': 0, 'refresh': False, 'source': False, 'help': False}

# Generated at 2022-06-20 13:05:59.636078
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    '''
    Test that DocCLI.get_plugin_metadata is properly extracting metadata
    '''

    def test_extraction(json_file, options, metadata_dict):

        # Test for valid extraction
        extracted_dict = DocCLI.get_plugin_metadata(json_file, options)

        assert extracted_dict.keys().sort() == metadata_dict.keys().sort()

        for key in extracted_dict.keys():
            assert extracted_dict[key] == metadata_dict[key]

    # Define metadata to be extracted

# Generated at 2022-06-20 13:06:12.063894
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    from ansible.utils.args import parse_kv

    assert DocCLI.post_process_args(parse_kv("foo=bar")) == {'foo': 'bar'}
    assert DocCLI.post_process_args(parse_kv(":foo=bar")) == {'foo': 'bar'}
    assert DocCLI.post_process_args(parse_kv("foo={'bar': 'baz'}")) == {'foo': {'bar': 'baz'}}
    assert DocCLI.post_process_args(parse_kv("foo:bar")) == {'foo': 'bar'}
    assert DocCLI.post_process_args(parse_kv("bar")) == {'bar': True}
    assert DocCLI.post_process_args(parse_kv("-a bar"))

# Generated at 2022-06-20 13:06:20.180322
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():  assert DocCLI.namespace_from_plugin_filepath("/Users/student/GitHub/ansible/lib/ansible/modules/cloud/cloudscale/cloudscale_floating_ip.py") == "cloud:cloudscale"



# Generated at 2022-06-20 13:07:09.154474
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc = DocCLI(args=["ansible-doc", "-M", "modules", "-l"],
                 callback=None,
                 stdin=None)
    # TODO: use mock to verify the call from output.
    doc.run()

    doc = DocCLI(args=["ansible-doc", "-M", "plugins", "-l"],
                 callback=None,
                 stdin=None)
    # TODO: use mock to verify the call from output.
    doc.run()


# Generated at 2022-06-20 13:07:12.359620
# Unit test for function jdump
def test_jdump():
    a = {u'name': u'foo', u'bar': u'baz'}
    jdump(a)

_COLLECTION_VERSION_CACHE = {}



# Generated at 2022-06-20 13:07:25.417326
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Try passing invalid values for required parameters and check if the right exceptions are raised
    with pytest.raises(TypeError):
        DocCLI.get_plugin_metadata()
    with pytest.raises(TypeError):
        DocCLI.get_plugin_metadata(plugin_type='text')
    with pytest.raises(AnsibleOptionsError):
        DocCLI.get_plugin_metadata(plugin_type='text', plugin='text')

    # Try passing invalid values for optional parameters and check if the right exceptions are raised
    with pytest.raises(TypeError):
        DocCLI.get_plugin_metadata(plugin_type='text', plugin='text', versioned=0)

    # Try passing invalid values for the show_ignore parameter and check if the right exceptions are raised

# Generated at 2022-06-20 13:07:32.885145
# Unit test for function jdump
def test_jdump():
    jdump(dict(a=1))
    jdump(dict(a="a"))
    jdump(dict(a=True))
    jdump(dict(a=[]))
    jdump(dict(a=dict()))
    jdump(dict(a={1, 2, 3}))
    assert True



# Generated at 2022-06-20 13:07:36.065227
# Unit test for method print_paths of class DocCLI

# Generated at 2022-06-20 13:07:40.222954
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # str -> str
    assert DocCLI.format_plugin_doc('abcd') == '> ABCD\n  '
    assert DocCLI.format_plugin_doc('abcd\n') == '> ABCD\n  '
    assert DocCLI.format_plugin_doc('a\nb\nc\n\n') == '> A\n  B\n  C'


# Generated at 2022-06-20 13:07:55.591880
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    ################################################################################################################
    # Test with no command-line arguments
    ################################################################################################################
    from ansible.cli import CLI as TestCLI
    cli = TestCLI(args=[])

    # Check with no command-line arguments
    cli.options.doc_fragments_paths = []
    cli.options.roles_paths = []
    cli.options.squash_actions = True
    cli.options.subcommand = None
    cli.parser = CLI.base_parser(cli.options, None)
    cli.subparsers = cli.parser.add_subparsers(metavar='{%s}' % ','.join(DocCLI.DOCUMENTABLE_PLUGINS))
    cli.load()

    # Set up the

# Generated at 2022-06-20 13:08:00.159297
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    r = DocCLI.format_snippet({'description': ['test'], 'return': {'type': 'str'}, 'options': {'desc': {'description': ['test']}}, 'metadata': {'notes': ['test']}})
    assert r == ['test', 'str', 'DESC:', '  test', 'NOTES:', '  test']


# Generated at 2022-06-20 13:08:07.193775
# Unit test for function jdump
def test_jdump():
    assert jdump({'key': 'value'}) == json.dumps({'key': 'value'}, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)

# Generated at 2022-06-20 13:08:18.903574
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    cli = DocCLI()

    # Test normalize_param_dict()
    assert cli.normalize_param_dict({}) == {'choice_map': {}, 'choices': [], 'default': '', 'description': '', 'name': '', 'suboptions': {}}
    assert cli.normalize_param_dict({'name': 'foo'}) == {'choice_map': {}, 'choices': [], 'default': '', 'description': '', 'name': 'foo', 'suboptions': {}}

# Generated at 2022-06-20 13:10:24.232252
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    doc = DocCLI()
    assert doc.print_paths() == "OK"


# Generated at 2022-06-20 13:10:35.024828
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    import json
    import os
    import sys
    import yaml

    _dir = os.path.dirname(os.path.realpath(__file__))

    with open(os.path.join(_dir, 'data', 'module_json.json')) as x:
        json_doc = json.load(x)

    with open(os.path.join(_dir, 'data', 'module_doc.yml')) as x:
        yaml_doc = yaml.safe_load(x)


# Generated at 2022-06-20 13:10:40.177336
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc_obj = DocCLI()
    assert isinstance(doc_obj, DocCLI)


# Generated at 2022-06-20 13:10:42.209161
# Unit test for constructor of class DocCLI
def test_DocCLI():
    import ansible.cli.doc
    doc = ansible.cli.doc.DocCLI([])

    assert isinstance(doc, cli_common.CLI)

# Constructor of class DocCLI
cli = DocCLI()



# Generated at 2022-06-20 13:10:52.361128
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    result = doc.get_all_plugins_of_type(core=True)

# Generated at 2022-06-20 13:11:06.264311
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    import os
    import tempfile
    import json

    test_data = u"""---
module: test
short_description: test module
deprecated:
    why: it is done
    alternative: use the new one
version_added: '1.0.0'
description: this is a test module
options:
    name:
        description: description
"""
    with tempfile.NamedTemporaryFile(mode='wt', encoding='utf-8') as f:
        f.write(test_data)
        f.flush()
        meta = DocCLI.get_plugin_metadata(file_name=f.name, file_type='module')
        assert meta['name'] == 'test'
        assert meta['deprecated'] == {'why': 'it is done', 'alternative': 'use the new one'}

# Generated at 2022-06-20 13:11:12.614723
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    import ansible.cli.doc
    x = ansible.cli.doc.DocCLI()
    list1 = ["abc1", "abc2", "abc3"]
    list2 = ["xyz1", "xyz2", "xyz3"]
    list3 = ["pqr1", "pqr2", "pqr3"]
    x.display_plugin_list(list1, list2, list3)
    x.display_plugin_list(list1, list2)
    x.display_plugin_list([])

# Generated at 2022-06-20 13:11:24.835345
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    class Fake_Display:
        columns = 100
    display = Fake_Display()
    opt_indent = '        '
    limit = display.columns - 1

    return_values = False
    text = []

# Generated at 2022-06-20 13:11:31.612334
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Currently testing for only one plugin (command module) as it returns a nested dict
    command_plugin_path = '%s/plugins/action/command.py' % os.path.dirname(os.path.dirname(__file__))
    DocCLI.plugins = {}
    collector = load_plugins()
    DocCLI._find_plugins(collector, command_plugin_path)
    result = DocCLI.get_all_plugins_of_type('action')

# Generated at 2022-06-20 13:11:43.230420
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    # Setup test case
    mock_parser = Mock(add_option=Mock())
    doc_cli = DocCLI()

    # Perform test
    doc_cli.init_parser(mock_parser)

    # Verify results