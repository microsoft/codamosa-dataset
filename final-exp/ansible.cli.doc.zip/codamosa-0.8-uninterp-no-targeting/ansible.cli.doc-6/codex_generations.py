

# Generated at 2022-06-20 13:04:43.080720
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    from ansible_collections.core.plugins.module_utils._text import to_text
    from ansible_collections.core.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.core.plugins.modules import get_config

    DocCLI = DocCLIBase
    module = AnsibleModule(
        argument_spec=dict(
            module=dict(type='str', required=True)
        ),
        supports_check_mode=True
    )

    docs = DocCLI("config", "network", "arista.eos", get_config, module_path="/path/to/ansible_collections/arista/eos/plugins/modules/get_config.py")
    DocCLI._doc_modules[docs.module_name] = docs
    assert "module" in docs.module

# Generated at 2022-06-20 13:04:51.970175
# Unit test for function jdump
def test_jdump():
    """This is a test for jdump"""
    from ansible.module_utils.common.json import AnsibleJSONEncoder

    data = {
        '_ansible_module_generated': datetime.datetime(2015, 3, 9, 5, 8, 44, 945213),
        '_ansible_no_log': False,
        'changed': False,
        'invocation': {
            'module_args': {'some': 'complex object',
                            'and': 'or'}
        }
    }

    obj = AnsibleJSONEncoder()
    test = json.dumps(data, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)

# Generated at 2022-06-20 13:04:55.510619
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    example_ansible_cli_args = DocCLI.example_ansible_cli_args()
    context.CLIARGS = example_ansible_cli_args
    parser = DocCLI.init_parser(example_ansible_cli_args, ['ansible-doc'])
    assert isinstance(parser, argparse.ArgumentParser)
    assert parser.prog == 'ansible-doc'

# Generated at 2022-06-20 13:04:59.312409
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # Test with a simple filepath
    assert DocCLI.namespace_from_plugin_filepath('/a/b/c/d/e.py') == 'a.b.c.d'
    # Test with an Ansible collection
    assert DocCLI.namespace_from_plugin_filepath('/a/b/c/d.c/e/f.py') == 'c.d.e'



# Generated at 2022-06-20 13:05:05.747997
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    print("Method get_all_plugins_of_type() of class DocCLI")
    doc = DocCLI([])
    doc.all_docs = {}
    doc.find_plugin_docs('module')
    print("Method test_DocCLI_get_all_plugins_of_type succeeded!")


# Generated at 2022-06-20 13:05:17.252581
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():

    # Test with no argument
    assert DocCLI.namespace_from_plugin_filepath() == (None, None)

    # Test with non-string argument
    assert DocCLI.namespace_from_plugin_filepath(['plugin_path']) == (None, None)
    assert DocCLI.namespace_from_plugin_filepath(None) == (None, None)

    # Test with invalid file path
    assert DocCLI.namespace_from_plugin_filepath("/this/is/not/a/valid/path") == (None, None)

    # Test with valid cli plugin path
    assert DocCLI.namespace_from_plugin_filepath("/usr/share/ansible/plugins/modules/ping.py") == \
            ("modules", "ping.py")

    # Test with valid collection plugin

# Generated at 2022-06-20 13:05:20.436367
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    # Given
    argv = ['ansible-doc', '--version']
    # When
    parser = DocCLI.init_parser()
    parser_args = parser.parse_args(argv)
    # Then
    assert parser_args.version is True

# Generated at 2022-06-20 13:05:25.715725
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    doc = DocCLI()
    snippet = [
        {'foo': 'bar'},
        {'baz': 'foo'}
    ]
    expected = "    foo: bar\n\n    baz: foo\n"
    actual = doc.format_snippet(snippet)
    assert actual == expected


# Generated at 2022-06-20 13:05:36.497879
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    here = os.path.realpath(os.path.dirname(__file__))
    plugin_dir = os.path.join(here, '../../../lib/ansible/plugins/')

# Generated at 2022-06-20 13:05:50.320190
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'action'
    coll_filter = 'awx_test_collections'
    b_colldirs = list_collection_dirs(coll_filter=coll_filter)
    collname = 'awx_test_collections.network'
#    display.display("b_path: %s" % b_colldirs)
    for b_path in b_colldirs:
        path = to_text(b_path, errors='surrogate_or_strict')
        ptype = C.COLLECTION_PTYPE_COMPAT.get(plugin_type, plugin_type)
        item = DocCLI.find_plugins(os.path.join(path, 'plugins', ptype), False, plugin_type, collection=collname)

# Generated at 2022-06-20 13:06:53.674634
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    from collections import namedtuple
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.config.manager import ConfigManager
    config_manager = ConfigManager()
    config_manager.setup(DataLoader(), '.')
    display = Display(verbosity=3)
    cli_args = namedtuple('namedtuple', 'type version connection')
    cli_args.type = 'module'
    cli_args.version = None
    cli_args.connection = 'ssh'
    with context.CLIARGS(cli_args):
        DocCLI([], display=display)
    display.display('', color='blue')


# Generated at 2022-06-20 13:07:05.645008
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    import test.support as support
    from test.support.config import ANSIBLE_CONFIG
    from test.support.config import ROOT_PATH
    from test.support.helpers import mock

    # Set up context
    context._init_global_context(str(ROOT_PATH))
    context.CLIARGS = {}

    config_file = "%s/%s" % (ROOT_PATH, ANSIBLE_CONFIG)

    config = ConfigParser.ConfigParser()
    config.read(config_file)
    module_paths = config.get('defaults', 'library')

    module_args = DocCLI.process_cli_args(module_paths, context.CLIARGS)
    assert module_args == [module_paths]
    assert context.CLIARGS['type'] == 'module'

# Generated at 2022-06-20 13:07:20.856523
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    class Object(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    import ansible.utils.vars
    module_name = 'ansible.utils.vars.combine_vars'


# Generated at 2022-06-20 13:07:22.863598
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    # Initialize an argument parser
    parser = argparse.ArgumentParser()

    # Testing all arguments
    with pytest.raises(SystemExit):
        DocCLI.init_parser(parser)


# Generated at 2022-06-20 13:07:24.254483
# Unit test for function jdump
def test_jdump():
    assert jdump.__name__ == 'jdump'



# Generated at 2022-06-20 13:07:35.732951
# Unit test for function jdump
def test_jdump():
    # This is a unit test, not a functional test.
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle as pickle
    if PY3:
        import pickle
        raise Exception('This is not supported in python3')
    obj = AnsibleJSONEncoder.default(None, object())
    buf = pickle.dumps(obj)
    jdump(buf)



# Generated at 2022-06-20 13:07:42.680707
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # get_man_text() method of class DocCLI
    doc = {
        'foo': 'bar',
        'description': 'Unit test for method get_man_text of class DocCLI',
        'options': [
            {
                'bar': 'baz',
                'version_added': 1,
                'default': 'zab',
                'choices': ['a', 'b', 'c'],
                'spec': [{
                    'zab': 'zab',
                    'default': 'zab',
                    'choices': ['a', 'b', 'c'],
                }],
            },
        ],
        'notes': ['blah blah blah'],
        'requirements': ['baz'],
    }
    result = DocCLI.get_man_text(doc)
    #print(

# Generated at 2022-06-20 13:07:57.996539
# Unit test for function add_collection_plugins
def test_add_collection_plugins():

    collection_name = 'my_collection'
    mock_plugin_type = 'filter'
    mock_collection_filter = ['my_collection']
    mock_plugin_type = 'filter'

    mock_plugin_list = []

    mock_collpath = os.path.join(C.DEFAULT_COLLECTIONS_PATH[0], collection_name)
    mock_plugin_path = os.path.join(mock_collpath, 'plugins', 'filter')
    os.makedirs(mock_plugin_path)
    mock_plugin_name = 'msdos_line'
    with open(os.path.join(mock_plugin_path, mock_plugin_name), 'w') as f:
        f.write('def msdos_line():\n    return True')

# Generated at 2022-06-20 13:08:06.325549
# Unit test for function jdump
def test_jdump():
    text = {"a": 1, "b": ["b1", "b2"], "c": {"ca": "ca1", "cb": "cb1"}}
    try:
        assert jdump(text) == json.dumps(text, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)
    except AssertionError:
        raise AssertionError('JSON dump failed')



# Generated at 2022-06-20 13:08:18.351880
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    """
    Test the DocCLI class for class attributes, init, and all methods in _create_collection_list, _create_collection_doc, _create_module_list, _create_plugin_doc.
    """
    DocCLI._create_collection_list()
    assert DocCLI.IGNORE == ('module', 'module', 'collection')
    assert DocCLI._format_version_added('2.0') == '2.0'
    with pytest.raises(AnsibleError):
        DocCLI.add_fields()
    assert DocCLI._dump_yaml({"a":1}) == 'a: 1'
    assert DocCLI.tty_ify('\x001b[1K\n') == ''

# Generated at 2022-06-20 13:09:44.224331
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
  import collections
  import sys
  import textwrap
  import types
  import unittest
  import yaml
  
  from ansible import constants as C

  from ansible.cli.doc import DocCLI
  from ansible.module_utils._text import to_bytes, to_text
  from ansible.module_utils.common._collections_compat import Mapping, MutableMapping, Sequence

  from ansible.playbook.play_context import PlayContext
  from ansible.utils.collection_loader import AnsibleCollectionLoader

  from units.mock.loader import DictDataLoader

  def test_dump(self, *args):
    return yaml.safe_dump(*args, default_flow_style=False, width=1000)

  ######################################################################
  ##
  ## BEGIN TESTS


# Generated at 2022-06-20 13:09:48.847710
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc_cli = DocCLI()
    result = doc_cli.get_role_man_text()
    assert result is not None


# Generated at 2022-06-20 13:10:00.389573
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()

    xml_plugins = [
        ('dummy1', 'some_plugin', 'dummy'),
        ('dummy2', 'some_plugin', 'dummy'),
        ('dummy3', 'some_plugin', 'dummy'),
        ('dummy4', 'some_plugin', 'dummy'),
        ('dummy5', 'some_plugin', 'dummy'),
        ('dummy6', 'some_plugin', 'dummy'),
        ('dummy7', 'some_plugin', 'dummy'),
        ('dummy8', 'some_plugin', 'dummy'),
        ('dummy9', 'some_plugin', 'dummy'),
    ]

    filter_type = 'action'


# Generated at 2022-06-20 13:10:04.803180
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    collection_name = 'ansible.builtin'
    plugin = 'add_host'
    doc = DocCLI.load_plugin_doc(collection_name, plugin)
    text = DocCLI.get_man_text(doc, collection_name)

    assert re.search(r"ADDED IN", text)
    assert re.search(r"OPTIONS", text)
    assert re.search(r"ATTRIBUTES", text)

# Generated at 2022-06-20 13:10:15.804794
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    kwargs = {}
    func_name = 'cliconfig'
    parsed_args = {'foo': 'bar'}
    include_module_args=True
    include_restrictions=False
    include_local_vars=False

    kwargs['_extras'] = {}

    res = DocCLI.format_snippet(func_name, parsed_args, kwargs, include_module_args=include_module_args, include_restrictions=include_restrictions, include_local_vars=include_local_vars)
    assert res == "ansible localhost -m cliconfig -a \"foo=bar\""

    include_module_args=False

# Generated at 2022-06-20 13:10:23.049014
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc = dict()

# Generated at 2022-06-20 13:10:34.285739
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    '''Unit test for method print_paths of class DocCLI'''
    # Setup mocks
    temp_stdout = io.StringIO()
    mock_stdout = MockedStringIO(temp_stdout)
    mocker.patch('sys.stdout', mock_stdout)
    mocker.patch('ansible.module_utils.basic.AnsibleModule.exit_json')
    api = mocker.MagicMock()
    api.get_collections_doc_fragment_paths.return_value = ['a', 'b', 'c']
    api.get_builtin_doc_fragments_paths.return_value = ['d', 'e', 'f']
    api.get_deprecated_doc_fragments_paths.return_value = ['g', 'h', 'i']

# Generated at 2022-06-20 13:10:42.122680
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    '''Test the format_plugin_doc method of class DocCLI'''
    docCLI = DocCLI()
    docCLI.format_plugin_doc('')
"""
Tests for clone_dir
"""

# Generated at 2022-06-20 13:10:45.596721
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test that the DocCLI.find_plugins() works correctly
    result = DocCLI.find_plugins()
    assert isinstance(result, list)

# Generated at 2022-06-20 13:10:53.551238
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # For testing we need to fake the following:
    # - option C.config.parser
    # - option C.config.data

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.cli.arguments import options as cli_options
    from ansible.utils.display import Display
    from ansible.config.manager import ConfigManager
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader, lookup_loader, cache_loader, callback_loader, connection_loader, shell_loader, strategy_