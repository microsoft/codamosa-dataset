

# Generated at 2022-06-20 13:05:36.723964
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = list()
    if sys.version_info[0] > 2:
        args.append(bytes(__file__, 'utf-8'))
    else:
        args.append(__file__)
    args.append('--type=connection')
    if sys.version_info[0] > 2:
        args.append(bytes('--path', 'utf-8'))
    else:
        args.append('--path')
    args.append(C.DEFAULT_CONNECTION_PLUGIN_PATH)
    if sys.version_info[0] > 2:
        args.append(bytes('--all', 'utf-8'))
    else:
        args.append('--all')
    args.append('-v')
    cli = DocCLI(args)
    cli.parse()


# Generated at 2022-06-20 13:05:50.319529
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
	doc = DocCLI(verbosity=0)
	# No plugins of module_loader
	assert doc.get_all_plugins_of_type('module_loader') == []

	# 1 plugin of connection
	connection_plugins = doc.get_all_plugins_of_type('connection')
	assert len(connection_plugins) == 1
	assert connection_plugins[0][0] == 'local'
	assert connection_plugins[0][1] == 'connection'
	assert connection_plugins[0][2] == 'local'

	# 2 modules of shell
	shell_plugins = doc.get_all_plugins_of_type('shell')
	assert len(shell_plugins) == 2
	assert shell_plugins[0][0] == 'cmd'
	assert shell_plugins[0][1] == 'shell'
	assert shell_plugins

# Generated at 2022-06-20 13:05:59.019889
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-20 13:06:04.007861
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    RESULT = '- name: Debugging generated vars\n  debug: var=hostvars[inventory_hostname]'
    assert RESULT == DocCLI.format_snippet(EXAMPLE_SNIPPET)



# Generated at 2022-06-20 13:06:10.553260
# Unit test for function jdump
def test_jdump():
    assert json.loads(jdump({'a': 'b'})) == {'a': 'b'}
    assert json.loads(jdump({'a': 'b', 'c': 'd'})) == {'a': 'b', 'c': 'd'}
    assert json.loads(jdump({'a': {'c': 'd'}})) == {'a': {'c': 'd'}}



# Generated at 2022-06-20 13:06:13.631819
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound('test')
    except PluginNotFound as e:
        assert e.args[0] == 'test'
        assert str(e) == 'test'



# Generated at 2022-06-20 13:06:15.493416
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
	assert DocCLI.namespace_from_plugin_filepath('plugins/modules/module_utils_text') == 'module_utils'

# Generated at 2022-06-20 13:06:23.582358
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # Test for 'file' is of type string
    assert (DocCLI.namespace_from_plugin_filepath('lib/ansible/plugins/action/fireball.py') == 'ansible.plugins.action')
    # Test for 'file' is of type string
    assert (DocCLI.namespace_from_plugin_filepath('ansible/modules/commands/command.py') == 'ansible.modules.commands')


# Generated at 2022-06-20 13:06:34.388952
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    """Unit test for method print_paths of class DocCLI"""
    doc_cli = DocCLI(MockCLI([]))
    mock_separator = Mock()
    mock_columnize = Mock(return_value='fake_columnize')
    mock_display = Mock()
    display = Mock()
    display.columns = 20
    mock_get_plugins = Mock(return_value=['foo', 'bar'])

# Generated at 2022-06-20 13:06:38.558078
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    cmd = DocCLI()
    import pprint
    try:
        data = cmd.get_all_plugins_of_type(None, None)
        pprint.pprint(data)
    except SystemExit:
        pass


# Generated at 2022-06-20 13:07:25.415659
# Unit test for constructor of class DocCLI
def test_DocCLI():
    test_dir = os.path.dirname(__file__)
    d = DocCLI(os.path.join(test_dir, 'plugins'), os.path.join(test_dir, 'modules'), os.path.join(test_dir, 'module_utils'))
    assert isinstance(d, DocCLI)

# Generated at 2022-06-20 13:07:26.067855
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    pass

# Generated at 2022-06-20 13:07:29.389906
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    plugin_not_found = PluginNotFound('test_message')
    assert plugin_not_found.message == 'test_message'



# Generated at 2022-06-20 13:07:38.008071
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    """ DocCLI method format_snippet """
    # Testing empty
    def empty():
        results = DocCLI.tty_ify('')
        assert results == ''

    # Testing single line
    def single_line():
        results = DocCLI.tty_ify('aaa')
        assert results == 'aaa'

    # Testing single line, multi chars
    def single_line_multi_chars():
        results = DocCLI.tty_ify('   aaa   ')
        assert results == 'aaa'

    # Testing single line, multi chars, multi lines
    def single_line_multi_chars_multi_lines():
        results = DocCLI.tty_ify('   aaa   \n  bbb  ')
        assert results == 'aaa\nbbb'

    # Testing multi lines, multi chars
   

# Generated at 2022-06-20 13:07:40.808152
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # initializing an instance of DocCLI class
    test_obj = DocCLI()
    # finding plugins
    test_obj.find_plugins()
    # checking whether the type of returned object is list
    assert isinstance(test_obj.all_docs, list)


# Generated at 2022-06-20 13:07:45.692794
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
	DocCLI().print_paths(['/tmp/1','/tmp/2','/tmp/3'])


# Generated at 2022-06-20 13:07:58.636112
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.ping import ActionModule as PingActionModule
    from ansible.module_utils.facts.system.bsd import OpenBSD, FreeBSD, NetBSD
    ns = DocCLI.namespace_from_plugin_filepath(PingActionModule._load_name, ActionBase, PingActionModule)
    assert ns == ['actionplugins']
    ns = DocCLI.namespace_from_plugin_filepath(NetBSD.__name__, AnsibleModule, NetBSD)
    assert ns == ['ansible_collections', 'community.general.plugins', 'modules', 'system', 'bsd']
test_DocCLI_namespace_from_plugin_filepath.skip = 'Requires ansible-base'
#

# Generated at 2022-06-20 13:07:59.924029
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc = DocCLI(sys.argv)
    assert doc.options

# Generated at 2022-06-20 13:08:04.793441
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.common.removed import removed_module
    from ansible.plugins.cache import module_loader
    assert(isinstance(removed, removed_module))
    module_loader.add_directory(BASE_DIR)
    dcli = DocCLI(command_line="".split())
    for module in dcli.find_plugins(all=True):
        assert(isinstance(module, string_types))


# Generated at 2022-06-20 13:08:11.693742
# Unit test for function jdump
def test_jdump():
    from ansible.module_utils.common.text.converters import to_bytes

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO
    test_dict = {
        "foobar": b'{"json": "this should not be interpreted as json"}',
        "tests": [
            {
                "name": "value",
                "unicode_val": u"unicöde",
            }
        ]
    }

    json_text = to_bytes(json.dumps(test_dict, cls=AnsibleJSONEncoder, sort_keys=True, indent=4))
    jdump_text = to_bytes(jdump(test_dict))
    assert jdump_text == json_text



# Generated at 2022-06-20 13:09:17.139878
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    display.verbosity = 3
    results = [{'name': 'test1.yml', 'path': '/path/to/test1.yml'}, {'name': 'test2.yml', 'path': '/path/to/test2.yml'}]
    DocCLI.print_paths(results)


# Generated at 2022-06-20 13:09:27.176822
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    obj = DocCLI()

    # Test case 1
    role = 'check_disk'

# Generated at 2022-06-20 13:09:37.779101
# Unit test for constructor of class DocCLI
def test_DocCLI():
    with patch("shutil.which", return_value="/usr/bin/less"):
        cli = DocCLI(args=dict(type="module"))
        assert dict == type(cli.subsubsub)
        assert not cli.subsubsub

        cli = DocCLI(args=dict(type="module", all=True))
        assert dict == type(cli.subsubsub)
        assert cli.subsubsub


# Generated at 2022-06-20 13:09:45.821565
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    # Create a new DocCLI object
    doc = DocCLI()

    assert doc.post_process_args(['-h']) == ['-h']
    assert doc.post_process_args(['-h', '-v']) == ['-h', '-v']
    assert doc.post_process_args(['-h', '-v', '-v']) == ['-h', '-v', '-v']
    assert doc.post_process_args(['-h', '-v', '-v', '-v']) == ['-h', '-v', '-v', '-v']
    assert doc.post_process_args(['-h', '-vvv']) == ['-h', '-v', '-v', '-v']

# Generated at 2022-06-20 13:09:51.363492
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    rval = DocCLI().get_all_plugins_of_type('module')
    assert isinstance(rval, doc_fragment.DocFragment)
    # rval is DocFragment instance
    assert hasattr(rval, 'list_all')
    # list_all is property of DocFragment
    assert isinstance(rval.list_all, list)
    # list_all is a list
    assert len(rval.list_all) > 0
    # list_all has at least one item
    assert isinstance(rval.list_all[0], string_types)
    # list_all[0] is a string


# Generated at 2022-06-20 13:09:58.458238
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # test with bad plugin_type
    plugin_type = 'test'
    filename = 'test_filename'
    docstring = 'test_docstring'
    collection_list = ["test_collection1", "test_collection2"]
    result = DocCLI._get_plugin_metadata(plugin_type, filename, docstring, collection_list)
    assert result == None


# Generated at 2022-06-20 13:10:13.043773
# Unit test for method format_snippet of class DocCLI

# Generated at 2022-06-20 13:10:16.710696
# Unit test for function jdump
def test_jdump():
    d = {'a': 1, 'b': 'c'}
    json_data = json.dumps(d)
    ansible_json_data = json.dumps(d, cls=AnsibleJSONEncoder)
    assert jdump(d) == display.display(ansible_json_data)


# Generated at 2022-06-20 13:10:29.181234
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    cli = DocCLI(args=['ansible-doc', '-t', 'module', 'copy'])
    test_plugin = 'copy'
    # test when plugin_type is set to module
    plugin_type = 'module'
    # create an instance of MockDisplay
    display = MockDisplay()
    cli_display = CLIDisplay(display)
    cli.display.columns = 80
    cli.find_plugins([test_plugin], collection_list=MockCollectionFinder())
    assert test_plugin in [plugin.name for plugin in cli.all_plugins]



# Generated at 2022-06-20 13:10:35.216513
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    plugin_list = [
        {
            'name': 'local_action',
            'path': '/tmp/foo/plugins/action/local_action.py',
            'class': 'ActionModule'
        },
        {
            'name': 'shipit',
            'path': '/tmp/foo/plugins/bank/shipit.py',
            'class': 'LookupModule'
        }
    ]
    DocCLI.print_paths(plugin_list)



# Generated at 2022-06-20 13:11:49.046758
# Unit test for method init_parser of class DocCLI

# Generated at 2022-06-20 13:12:01.826232
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    import emitter

    text = []
    limit = 10
    role_json = {
        'entry_points': {
            'main': {
                'options': {
                    'opt1': 'opt1 desc',
                    'opt2': {
                        'version_added': 'opt2 desc'
                    },
                    'opt3': [
                        {
                            'version_added': 'opt3 desc1'
                        },
                        {
                            'version_added': 'opt3 desc2'
                        }
                    ],
                    'opt4': {
                        'version_added': 'opt4 desc',
                        'suboptions': {
                            'subopt1': 'subopt1 desc'
                        }
                    }
                }
            }
        }
    }

    def console_write(msg):
        print(msg)

   