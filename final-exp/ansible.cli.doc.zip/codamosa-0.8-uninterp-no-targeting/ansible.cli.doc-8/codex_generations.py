

# Generated at 2022-06-20 13:04:54.872707
# Unit test for constructor of class DocCLI
def test_DocCLI():
    from ansible.cli.doc import DocCLI

    parser = DocCLI(
        ['ansible-doc', '-t', 'module', 'auto_aix_vmo'],
        'ansible-doc',
    )
    options = parser.parse()
    assert options.type == 'module'
    assert options.name == 'auto_aix_vmo'


# Generated at 2022-06-20 13:05:01.074978
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    test = DocCLI()
    assert test.post_process_args(['get-collection'])                                                                               == ([['get-collection']], ['ansible.cli.doc'])
    assert test.post_process_args(['get-modules'])                                                                                 == ([['get-modules']], ['ansible.cli.doc'])
    assert test.post_process_args(['get-module-length'])                                                                           == ([['get-module-length']], ['ansible.cli.doc'])
    assert test.post_process_args(['get-module-doc'])                                                                              == ([['get-module-doc']], ['ansible.cli.doc'])

# Generated at 2022-06-20 13:05:04.533049
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    cli = DocCLI()
    assert cli.init_parser(None) is not None


# Generated at 2022-06-20 13:05:16.102212
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    # get the calling instance.
    doc = DocCLI()
    parser = doc.init_parser()

    # define the args to be passed to the parser.

# Generated at 2022-06-20 13:05:23.905414
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    '''
    Test to return namespace of the plugin
    '''
    doc = DocCLI()
    filepath = "lib/ansible/modules/cloud/amazon/ec2_vpc_subnet.py"
    assert doc.namespace_from_plugin_filepath(filepath) == "cloud.amazon.ec2"

# Generated at 2022-06-20 13:05:35.289488
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    options = DocCLI.init_parser()
    assert options.module == '', 'The module attribute of the options object should be empty'
    assert options.playbook == '', 'The playbook attribute of the options object should be empty'
    assert options.snippet == False, 'The snippet attribute of the options object should be False'
    assert options.connection == '', 'The connection attribute of the options object should be empty'
    assert options.network == '', 'The network attribute of the options object should be empty'
    assert options.storage == '', 'The storage attribute of the options object should be empty'
    assert options.windows == '', 'The windows attribute of the options object should be empty'
    assert options.filter == '', 'The filter attribute of the options object should be empty'

# Generated at 2022-06-20 13:05:41.286229
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Test whether the format_plugin_doc function shows the correct return value
    # when all the parameters are correct.
    # The function is called with the following parameter:
    # 1. ''' This is a test for ansible plugin documentation. '''
    # The expected return value is:
    # 1. ''' This is a test for ansible plugin documentation. '''
    # For example:
    # 1. DocCLI.format_plugin_doc(''' This is a test for ansible plugin documentation. ''')
    assert DocCLI.format_plugin_doc(''' This is a test for ansible plugin documentation. ''') == \
    ''' This is a test for ansible plugin documentation. '''

    # Test whether the format_plugin_doc function shows the correct return value
    # when all the parameters are correct.
    # The function

# Generated at 2022-06-20 13:05:43.022648
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    cli = DocCLI()
    assert cli is not None

# Generated at 2022-06-20 13:05:54.543202
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    plugins = PluginLoader('./', '', package='ansibleplugin')
    p = plugins.get('copy', 'copy')
    assert p is not None
    assert 'has_action' in p
    assert p['has_action'] is True
    p = plugins.get('setup', 'setup')
    assert p is not None
    assert 'has_action' in p
    assert p['has_action'] is False
    plugins = PluginLoader('./', '', package='ansiblerole')
    p = plugins.get('common', '')
    assert p is not None
    assert 'has_action' in p
    assert p['has_action'] is False
    p = plugins.get('cloudfront', 'cloudfront')
    assert p is not None
    assert 'has_action' in p
    assert p['has_action']

# Generated at 2022-06-20 13:06:01.430123
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    def mock_get_config(key, convert, default, value_type):
        config = dict(
            ansible_config_collection_path='/root/collections',
            ansible_config_module_path='/root/ansible',
            ansible_config_plugins_path='/root/ansible/plugins'
        )
        return config[key]

    class MockedPluginLoader:
        def __init__(self):
            self.module_utils = {}
            self.module_utils['ansible.module_utils.basic'] = None

    class MockedPluginSpec:
        def __init__(self, plugin_spec_name='TestSpec'):
            self.name = plugin_spec_name

    class MockedDocCLI:
        def __init__(self):
            self.plugin_loader = MockedPlugin

# Generated at 2022-06-20 13:06:51.833341
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    DocCLI.init_parser(get_parser())

# Generated at 2022-06-20 13:06:58.544219
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    cli = DocCLI()
    cli._doc_fragments = []
    cli.module_list = []
    cli.collection_list = []
    from ansible.parsing.dataloader import DataLoader
    cli.loader = DataLoader()
    cli.display_plugin_list([], '', '', '', '')


# Generated at 2022-06-20 13:07:07.711672
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc_string = '''---
- hosts: ans-test
  gather_facts: no
  tasks:
    - name: test module name
      ansible.builtin.debug:
        msg: "you've installed Ansible"
'''
    from ansible.compat.tests.mock import patch

# Generated at 2022-06-20 13:07:21.561408
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-20 13:07:23.646110
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc = DocCLI(docsite_info=None)
    assert doc.docsite_info == None


# Generated at 2022-06-20 13:07:34.087861
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    result = DocCLI.get_role_man_text('role_name', {
        "entry_points": {
            "main": {
                "short_description": "short description",
                "description": "description",
                "options": {
                    "path": {
                        "required": False,
                        "default": True,
                        "description": "description"
                    }
                },
                "attributes": {
                    "attribute_name": {
                        "type": "dict",
                        "default": "{}"
                    }
                }
            }
        }
    })

# Generated at 2022-06-20 13:07:41.519245
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    DocCLI.options = []
    DocCLI.module = [s for s in sys.argv[0].split('/') if s.endswith('.py')][0][:-3]

# Generated at 2022-06-20 13:07:57.605567
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-20 13:07:59.963470
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    assert DocCLI().post_process_args(['--help'])
    assert DocCLI().post_process_args(['--help', 'test.test'])

# Generated at 2022-06-20 13:08:07.495172
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    test_data = DocCLI()

    test_data.base_command = 'ansible-doc'
    test_data.myoptions = {'verbose': 'v'}
    test_data.myoptions['all'] = 'a'
    test_data.myoptions['version'] = 'V'
    test_data.myoptions['help'] = 'h'
    test_data.myoptions['output'] = 'o'

    def check_subcommand(subcommand, arg_spec, type=None):
        argspec_obj = argparse.ArgumentParser(prog='ansible-doc', add_help=False,
                usage=argparse.SUPPRESS)
        test_data._add_subcommand_options(subcommand, argspec_obj)

# Generated at 2022-06-20 13:09:16.518618
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    pass


# Generated at 2022-06-20 13:09:21.261455
# Unit test for function jdump
def test_jdump():
    jdump({"baz" : "quux", "foo" : "bar"})
    with open(__file__, 'rb') as f:
        try:
            jdump({"foo" : "bar", "baz" : f.read()})
        except TypeError:
            pass



# Generated at 2022-06-20 13:09:29.161658
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    import collections
    from units.compat.unittest import TestCase, mock
    from units.compat.mock import patch
    # setup
    DocCLI.IGNORE = ["filename", "_returns", "_options", "min_ansible_version",
                     "max_ansible_version", "metadata_version", "_aliases",
                     "_anonymous_plugin", "action", "default_action", "action_plugin",
                     "aliases", "action_mapper", "action_min_args", "action_stderr",
                     "action_stdout", "action_args_spec", "_accelerate_port",
                     "_accelerate_timeout", "deprecated", "has_action",
                     "_accelerate_daemon_timeout", "version_added_collection"]

# Generated at 2022-06-20 13:09:35.328479
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # initialize DocCLI class
    doc_cli = DocCLI()
    # initialize module_loader class
    module_loader = AnsibleModuleLoader(module_paths=[], class_only=True)
    # test with module
    module_loader.add_directory(MODULE_PATH)
    # module plugins
    plugins = module_loader.all(class_only=True)
    response = doc_cli.get_all_plugins_of_type(plugins, 'module')
    #assert response['netbox_device']['name'] == 'netbox_device'
    # assert response['netbox_device']['doc']['version_added'] == '2.9'
    # assert response['netbox_device']['doc']['short_description'] == 'creates or removes devices from Netbox'
    # assert response

# Generated at 2022-06-20 13:09:36.734215
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    DocCLI.get_all_plugins_of_type()
    assert True


# Generated at 2022-06-20 13:09:39.073190
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    x = PluginNotFound('test')
    assert str(x) == 'test'


# Generated at 2022-06-20 13:09:46.226261
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 80
    opt_indent = "        "

# Generated at 2022-06-20 13:09:52.328753
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    import ansible.plugins.loader
    doc = DocCLI()

    # Valid plugins
    assert doc.namespace_from_plugin_filepath('/home/username/.ansible/plugins/modules/mymodule.py') == 'ansible.modules.mymodule'
    assert doc.namespace_from_plugin_filepath('/home/username/.ansible/plugins/module_utils/mymodule.py') == 'ansible.module_utils.mymodule'

    # Invalid plugins
    with pytest.raises(ansible.plugins.loader.PluginError):
        doc.namespace_from_plugin_filepath('/home/username/.ansible/plugins/modules/mymodule.txt', 'module')
    with pytest.raises(ansible.plugins.loader.PluginError):
        doc.namespace_from_plugin_filepath

# Generated at 2022-06-20 13:09:56.236440
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    argspec = doctest.FauxArv(version="1.2.3")
    mod = DocCLI(argspec)
    assert mod.display_plugin_list(None) == '\n'


# Generated at 2022-06-20 13:10:04.745403
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    ''' Unit test of method find_plugins of class DocCLI '''
    class TestArgs(object):
        def __init__(self, type='module', path=None, list=[], output=None):
            self.type = type
            self.path = path
            self.list = list
            self.output = output
    test_args = TestArgs()

# Generated at 2022-06-20 13:11:46.917295
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-20 13:11:56.078933
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Set up mock input and output
    monkeypatch.setattr(builtins, 'input', lambda x: 'y')
    mock_stdout = StringIO()
    monkeypatch.setattr(sys, 'stdout', mock_stdout)

    # Call the function under test
    paths = DocCLI.print_paths(context.CLIARGS)

    # For now, just assume that paths is a dictionary containing exactly
    # the same keys as ANSIBLE_CALLABLES and that the values are lists
    # of strings containing file names (names of files that exist)
    assert all([os.path.isfile(item) for item in list(chain(*list(paths.values())))])


# Generated at 2022-06-20 13:12:11.114724
# Unit test for method run of class DocCLI
def test_DocCLI_run():

    import argparse
    import sys
    import os

    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action='version', version='%(prog)s 0.0.0')

    args = parser.parse_args(["-v"])
    args.help = True
    if '-v' in sys.argv:
        args.verbosity = 1
    else:
        args.verbosity = 0

    test_cases = [
        # format: (return_value, expected)
        (0, 0),
        (1, 1),
    ]

    for return_value, expected in test_cases:
        module = AnsibleModule(
            argument_spec=dict()
        )
        DocCLI.run = MagicMock(return_value=return_value)