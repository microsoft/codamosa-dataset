

# Generated at 2022-06-20 13:04:35.289457
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # 1. Arrange
    ansible_plugins_path = 'ansible/plugins'
    plugin_type = 'callback'

    # 2. Act
    ansible_plugins = DocCLI.get_all_plugins_of_type(plugin_type)

    # 3. Assert
    assert len(ansible_plugins) > 0


# Generated at 2022-06-20 13:04:36.489866
# Unit test for function jdump
def test_jdump():
    doc = {'key': True}
    assert jdump(doc) == ''



# Generated at 2022-06-20 13:04:41.018920
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Test for missing filename
    doc = {}
    text = DocCLI.format_plugin_doc(doc)
    assert text.startswith("ERROR: Module %s was not found" % text[27:])

    # Test for missing module
    doc = {'filename': 'test.file'}
    text = DocCLI.format_plugin_doc(doc)
    assert text.startswith("ERROR: Module %s was not found" % text[27:])

    # Test for missing description
    doc = {'filename': 'test.file', 'module': 'test.module'}
    text = DocCLI.format_plugin_doc(doc)
    assert text.startswith("ERROR: Module %s was not found" % text[27:])

    # Test for valid case

# Generated at 2022-06-20 13:04:46.242525
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    args = DocCLI.init_parser(None)
    assert args.module is None
    assert args.module_path is None
    assert args.module_paths is None
    assert args.type == 'module'
    assert args.plugins is None
    assert args.roles is None
    assert args.inventory is None
    assert args.playbook is None
    assert args.name is None
    assert args.refresh is False
    assert args.role_paths == [
        to_text(os.path.join(ansible_base_path, 'lib/ansible/roles')),
        to_text(os.path.expanduser('~/.ansible/roles'))
    ]


# Generated at 2022-06-20 13:04:49.708659
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    test_data = {
        'role_paths': [],
        'collection_paths': [],
    }
    d = DocCLI(args=dict(
        type='module',
        verbosity=2,
        output_type=None
    ))
    doc, name, path, display_name, subdir = d.find_plugins(test_data)
    assert doc is None
    assert name is None
    assert path is None
    assert display_name is None
    assert subdir is None

# Generated at 2022-06-20 13:04:57.574625
# Unit test for constructor of class RoleMixin
def test_RoleMixin():

    # pylint: disable=unused-variable,unused-argument
    class TestDocCLI(RoleMixin):
        def __init__(self, args,**kwargs):
            self.args = args

    args = Namespace()
    args.verbosity = 2
    args.roles_path = ['./test/unit/data/role_argspec_main',
                       './test/unit/data/role_argspec_argspec',
                       './test/unit/data/role_argspec_none']
    args.output = None
    test_cli = TestDocCLI(args)

    # Test normal role results
    roles = args.roles_path[:-1]
    result = test_cli._create_role_list(roles)
    assert len(result) == 2

# Generated at 2022-06-20 13:05:12.688304
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    cli = DocCLI()
    cli.options = FakeOptParser()
    cli.options.listall = False
    cli.options.force_collection = False
    cli.options.tree = False
    cli.options.type = 'modules'
    cli.options.metadata = None
    cli.options.snippet = None
    cli.options.action_snippets = False

    assert cli.find_plugins() == ['system', 'wait_for', 'win_acl']

    cli.options.type = 'lookup_plugins'
    assert cli.find_plugins() == ['gce_eip']

    cli.options.type = 'modules'
    cli.options.tree = True
    assert cli.find_plugins() == []

    cli.options.type

# Generated at 2022-06-20 13:05:20.998228
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    '''Generate documentation for an Ansible plugin.
    :param plugin: The plugin object.  This is normally a module, but can
    also be a module_utils or anything with a doc string.  This is
    also passed to pydoc.getdoc which does not use it and so it can
    be None for those plugins for which pydoc.getdoc does not work.
    :param plugin_type: A string indicating the type of plugin.
    :param plugin_name: The name of the plugin.
    :param collection_name: The name of the collection that contains
    this plugin.
    :returns: A string containing the documentation for plugin.
    '''



# Generated at 2022-06-20 13:05:31.904979
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Ensure static directory is set to test dir
    ansible_path = os.path.dirname(os.path.dirname(__file__))
    if ansible_path not in sys.path:
        sys.path.append(ansible_path)

    cli = DocCLI()
    cli.parse()
    # Test that module listings include all of the directories
    # that should be in the test module_utils attachment
    expected_dirs = (
        'module_utils/urls',
        'module_utils/facts',
        'module_utils/basic',
        'module_utils/other',
    )
    for path in expected_dirs:
        assert path in cli.find_plugins()


# Generated at 2022-06-20 13:05:36.114996
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    inventory = ['/home/ubuntu/Dev/demo-ansible/ansible/plugins/modules/system/ping.py','/home/ubuntu/Dev/demo-ansible/ansible/plugins/modules/system/setup.py']
    my_obj=DocCLI()
    print(my_obj.print_paths(inventory))


# Generated at 2022-06-20 13:06:45.128768
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    import os 
    import sys 
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..')) 
    from lib.core_ci import is_shippable
    # ansible-base 2.9.5
    plugins = DocCLI.get_all_plugins_of_type(None, 'modules')
    assert 'setup' in plugins
    assert isinstance(plugins['setup'], list)

    plugins = DocCLI.get_all_plugins_of_type(None, 'modules', True)
    assert 'setup' in plugins
    assert isinstance(plugins['setup'], list)

    plugins = DocCLI.get_all_plugins_of_type(None, 'modules', False)
    assert 'setup' in plugins

# Generated at 2022-06-20 13:06:48.405930
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    candidate = './lib/ansible/modules/cloud/amazon/ec2_vpc_peering_facts.py'
    expected = 'cloud.amazon'
    assert DocCLI.namespace_from_plugin_filepath(candidate) == expected


# Generated at 2022-06-20 13:06:50.382033
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    return None

DocCLI.display_plugin_list(b_c_w=None)


# Generated at 2022-06-20 13:06:53.367169
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    test_p = PluginNotFound("test message")
    assert test_p.args[0] == "test message"



# Generated at 2022-06-20 13:06:58.771438
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Testing method get_plugin_metadata of class DocCLI
    # Setup test environment prior to testing method
    # Call method get_plugin_metadata to test
    # Check result of called method get_plugin_metadata
    # Teardown test environment after testing method
    pass


# Generated at 2022-06-20 13:07:07.792829
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Generated 1/27/2019 by blackdagger
    # Unit test for method display_plugin_list of class DocCLI
    from argparse import Namespace
    from ansible_collections.foo.bar.plugins.module_utils._text import to_text

    arg_line = 'ansible-doc'
    plugin_type = 'module'
    options = Namespace()
    options.type = 'module'
    options.all = False
    options.snippet = False
    options.verbosity = 0
    options.metadata = False
    options.more = False

    # This is the original code I am testing, I am using the try except to catch any errors
    #     def display_plugin_list(self, plugins, subdir, objects):
    #         # type: (List[str], str, dict) -> None
   

# Generated at 2022-06-20 13:07:21.616756
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    class TestDocCLI(DocCLI):
        def __new__(cls):
            return DocCLI()

    result1 = TestDocCLI().get_role_man_text('test-role', {
        'entry_points': {
            'main': {
                'short_description': 'Create ELK stack on a Debian/Ubuntu host.',
                'description': 'This role can be used to deploy ELK stack on any Debian/Ubuntu host.',
                'options': { 'elasticsearch_bind_host': {
                    'description': 'Host IP on which Elasticsearch should bind to.',
                    'default': 'localhost'}},
                'attributes': { 'hello': 'world'}}}})


# Generated at 2022-06-20 13:07:28.366363
# Unit test for function jdump
def test_jdump():
    test_list = [1, 2, 3, 4]
    test_dict = {'1': 'a', '2': 'b', '3': 'c'}
    assert jdump(test_list) == json.dumps(test_list, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)
    assert jdump(test_dict) == json.dumps(test_dict, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)



# Generated at 2022-06-20 13:07:37.744106
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    import unittest

    class TestCase(unittest.TestCase):

        def setUp(self):
            self.fixture = DocCLI()

        def tearDown(self):
            pass


# Generated at 2022-06-20 13:07:44.090784
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
  # Load this file's docstring as JSON
  doc = json.loads(AnsibleModule.__doc__)

  # `doc` is a dictionary. Its top-level keys are the modules/plugins for which docstrings have been extracted.
  # The value of each of these keys is another dictionary with 3 keys:
  #   - 'doc': The docstring contents for that module/plugin.
  #   - 'filename': The full path of the file with the module/plugin code.
  #   - 'lineno': The line at which the module/plugin code starts.

  # The names of all modules/plugins for which we have docstrings can be obtained by:
  #   doc.keys()

  # Examples:
  # 1) Let's say we want to print the documentation for the 'AnsibleModule' module:
  #    The name key in the dictionary

# Generated at 2022-06-20 13:09:46.244419
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    """
    Test print_paths method of class DocCLI
    """
    doc_cli = DocCLI()
    results = doc_cli.print_paths
    assert results == None


# Generated at 2022-06-20 13:09:47.438184
# Unit test for function jdump
def test_jdump():
    jdump({'hi': 'there'})
    assert False



# Generated at 2022-06-20 13:09:53.588805
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    '''Test method find_plugins'''
    docs_path = './docs/docsite/rst/dev_guide/plugins/lookup'
    os.chdir(docs_path)
    plugins = DocCLI.find_plugins()
    assert isinstance(plugins, dict)
    assert 'environment' in plugins



# Generated at 2022-06-20 13:09:56.433184
# Unit test for function jdump
def test_jdump():
    from decimal import Decimal
    jdump({'ignore': Decimal('2.0')})
# end unit test for function jdump
test_jdump()



# Generated at 2022-06-20 13:10:04.930799
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    display = Display()
    dummy_type = 'dummytype'
    dummy_paths = ['dummypaths']
    dummy_name = 'dummyname'
    dummy_plugin_type = 'dummyplugin'
    DocCLI.get_all_plugins_of_type(display, dummy_type, dummy_paths, dummy_name, dummy_plugin_type)


# Generated at 2022-06-20 13:10:07.475191
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    with pytest.raises(PluginNotFound):
        raise PluginNotFound("It is PluginNotFound Exception")


# Generated at 2022-06-20 13:10:17.345740
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    cli = DocCLI()
    assert cli.format_snippet('module_name', dict(
        fallback=dict(description='a description',
                      examples=["foo: bar"]),
        linux=dict(description='a description',
                   options=dict(foo=dict(description='a bar',
                                         required=True)),
                   examples=["bar: foo"]))) == '''
module_name

- name: a description
  foo: bar

- name: a description
  foo:
    description: a bar
    required: True
  bar: foo

'''.strip()


# Generated at 2022-06-20 13:10:18.945631
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    doc = DocCLI(subcommand="")
    parser = doc.init_parser()
    assert parser is not None


# Generated at 2022-06-20 13:10:31.947541
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
     doc = dict()
     doc['ansible.builtin.raw'] = dict()
     doc['ansible.builtin.raw']['short_description'] = "Executes a low-down and dirty SSH command"
     doc['ansible.builtin.raw']['description'] = ["This module allows one to execute a command in " +
                                                  "raw ssh mode on a remote host that has ansible " +
                                                  "installed. This is useful and should only be used " +
                                                  "as a last resort."]

# Generated at 2022-06-20 13:10:38.541455
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    import os

    os.environ['ANSIBLE_DEBUG'] = '1'
    doc = DocCLI()
    args = doc.parse()
    args = doc.post_process_args(args)
    assert args.type == 'module'
    assert args.all is True
    assert args.output == 'yaml'
    assert args.name == 'systemd'
    assert args.directory == os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib', 'ansible', 'modules')
    assert args.snippet is False

