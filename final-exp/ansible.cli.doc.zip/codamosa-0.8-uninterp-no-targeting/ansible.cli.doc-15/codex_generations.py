

# Generated at 2022-06-20 13:05:08.166782
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    import ansible.plugins.doc_fragments
    from ansible.cli.doc import DocCLI
    mock_options = MagicMock()
    DocCLI_obj = DocCLI(mock_options)
    category_selectors = ["connection", "database", "delegation", "inventory", "network", "package", "source", "storage", "system", "vars"]
    type_selectors = ['action', 'argument', 'asset', 'cache', 'callback', 'cliconf', 'connection', 'doc_fragment', 'inventory', 'lookup', 'module', 'module_utils', 'netconf', 'shell', 'strategy', 'test', 'vars']
    for category in DocCLI_obj.CATEGORIES:
        assert category in category_selectors

# Generated at 2022-06-20 13:05:15.231245
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():

    # test_DocCLI_get_man_text()

    doc = dict(
        description="",
        filename="",
        options=dict(),
        returndocs=dict()
    )

    collection_name = "test_collection_name"

    plugin_type = "test_plugin_type"

    output = DocCLI.get_man_text(doc, collection_name, plugin_type)

    assert output == ""



# Generated at 2022-06-20 13:05:16.661586
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    DocCLI.print_paths()


# Generated at 2022-06-20 13:05:23.822012
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-20 13:05:35.169912
# Unit test for constructor of class DocCLI

# Generated at 2022-06-20 13:05:36.476108
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    x = DocCLI()
    assert isinstance(x.parser, object)


# Generated at 2022-06-20 13:05:49.946357
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    # make a copy of the context and add our plugin_dir
    mycontext = context.CLIARGS.copy()
    mycontext['plugins'] = '/path/to/plugins'

    # initialize cli
    mycli = DocCLI(args={}, context=mycontext)

    # create some fake arguments
    myargs = SimpleNamespace(
        list_all=False,
        list_dirs=False,
        list_files=False,
        list_collections=False,
        list_toplevels=False,
        search=None,
        path=[],
        verbose=True,
        type='module',
    )

    # cannot test this in isolation, but we can test it exists
    assert callable(mycli.post_process_args)


# Generated at 2022-06-20 13:05:58.823930
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    from unittest import mock

    from ansible.utils.path import unfrackpath

    # Patching out the `isatty` method of `sys.stdout` so that all of the
    # print statements in the `run` method of `DocCLI` are treated as a
    # TTY in the unit tests

# Generated at 2022-06-20 13:06:02.251321
# Unit test for constructor of class DocCLI
def test_DocCLI():
    """
    Unit test for constructor of class DocCLI
    """

    doc = DocCLI()
    assert isinstance(doc, DocCLI)


# Generated at 2022-06-20 13:06:09.733305
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    cli = DocCLI()
    assert isinstance(cli.get_plugin_metadata('system'), PluginDoc)
    assert isinstance(cli.get_plugin_metadata('system', 'module'), PluginDoc)
    assert isinstance(cli.get_plugin_metadata('system', 'module', 'ping'), PluginDoc)
    assert cli.get_plugin_metadata('system', 'module', 'ping').metadata['NAME'] == 'ping'

# Generated at 2022-06-20 13:07:16.105985
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    doc_cli = DocCLI()
    sample_snippet = "test"
    assert sample_snippet == doc_cli.format_snippet(sample_snippet)

# Generated at 2022-06-20 13:07:17.356423
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    assert PluginNotFound(Exception())



# Generated at 2022-06-20 13:07:22.326903
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    path = 'lib/ansible/plugins/connection/chroot.py'
    DocCLI.namespace_from_plugin_filepath(path)
    assert path == 'lib/ansible/plugins/connection/chroot.py'



# Generated at 2022-06-20 13:07:33.055415
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    t = DocCLI()
    snip = '''- name: Test with a message\n  debug:\n    msg: ok\n- name: Test with a message\n  debug:\n    msg: still ok\n    verbosity: 2\n'''
    text = []
    text.append('EXAMPLES:')
    text.append('')
    text.append('- name: Test with a message')
    text.append('  debug:')
    text.append('    msg: ok')
    text.append('- name: Test with a message')
    text.append('  debug:')
    text.append('    msg: still ok')
    text.append('    verbosity: 2')
    text.append('')
    text.append('')
    text = "\n".join(text)
   

# Generated at 2022-06-20 13:07:40.839865
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    from ansible.module_utils._text import to_bytes, to_text
    # Using the example documentation from the Ansible docs.

# Generated at 2022-06-20 13:07:56.504457
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    utils = builtin_module_collection.module_utils
    utils['foo'] = ''
    utils['bar'] = ''
    utils['foobar'] = ''
    utils['barfoo'] = ''
    utils['ansible_doc_barfoo'] = ''

    argv = ['ansible-doc', '--module-path', './lib/ansible/modules/', '--module-utils', './lib/ansible/module_utils/',
            'foo', 'bar', 'Foobar', 'barfoo', 'ansible_doc_barfoo']
    context.CLIARGS = DocCLI.parse()
    doc = DocCLI(argv)
    res = doc.post_process_args(doc.args)


# Generated at 2022-06-20 13:07:57.842551
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    """
    Test the DocCLI class method run
    """
    DocCLI_obj = DocCLI()
    DocCLI_obj.run([''])


# Generated at 2022-06-20 13:07:59.228211
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    result = DocCLI.print_paths()



# Generated at 2022-06-20 13:08:01.025642
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    doc = RoleMixin()
    # not a directory
    roles_path = ('/dne',)
    assert doc._create_role_list(roles_path) == {}
    assert doc._create_role_doc(['dne'], roles_path) == {}
    return True


# Generated at 2022-06-20 13:08:08.536369
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    def run_module(module_name, *args):
        # For use in unit tests to run these as if they were on the command line
        module_args = ''
        if args:
            module_args = ' '.join(args)
        cmd = '%s %s %s' % (sys.executable, module_name, module_args)

        return subprocess.check_output(cmd, shell=True)

    # First load our test data set (if available)
    data = DocCLI._load_test_data_files()

    # Now we'll load up the actual modules under test (if available)
    plugin_loader = ModuleLoader()
    all_plugins = plugin_loader.all(class_only=False)


# Generated at 2022-06-20 13:09:54.394326
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    doc_data = [{"options": {
            "name": {
                "required": True,
                "type": "string",
                "aliases": ["instance"],
                "description": {
                    "required": True,
                    "type": "string",
                    "aliases": ["instance"],
                    "description": "Name of the instance to connect to.",
                    "choices": ["instance1", "instance2"]
                }
            }
        }}]


# Generated at 2022-06-20 13:10:02.181925
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    '''Unit tests for find_plugins method of class DocCLI'''
    collection_name=''
    plugin_type='module'
    DocCLI.IGNORE = []
    assert DocCLI().find_plugins(collection_name, plugin_type)
    collection_name='windows'
    assert DocCLI().find_plugins(collection_name, plugin_type)
    plugin_type='module_utils'
    assert DocCLI().find_plugins(collection_name, plugin_type)
    collection_name=''
    assert DocCLI().find_plugins(collection_name, plugin_type)

# Generated at 2022-06-20 13:10:13.977790
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    doc = {
        "type": "dict",
        "options": {
            "name": {
                "type": "str",
                "required": True,
                "aliases": ["name"]
            }
        }
    }
    expected = [
        '        OPTIONS (= is mandatory):',
        '        name: str',
        '            [Default: null]',
        '            required: yes',
        '            aliases: name',
        '\n        options:',
        '            name:',
        '                aliases: name',
        '                required: yes',
        '                type: str']
    opt_indent = "        "
    text = []
    limit = max(display.columns - int(display.columns * 0.20), 70)

# Generated at 2022-06-20 13:10:17.312067
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doccli = DocCLI()
    plugin_list = [('plugin_name1', 'doc_string for plugin_name1'), ('plugin_name2', 'doc_string for plugin_name2')]
    assert doccli.display_plugin_list(plugin_list) is None


# Generated at 2022-06-20 13:10:18.126349
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    doc = DocCLI()


# Generated at 2022-06-20 13:10:22.932732
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    from ansible import context
    from ansible.cli import CLI
    options = CLI.base_parser(
        runas_opts   = True,
        meta_opts    = True,
        runtask_opts = True,
        vault_opts   = True,
        async_opts   = True,
        connect_opts = True,
        subset_opts  = True,
        check_opts   = True,
        diff_opts    = True,
    ).parse_args()
    context._init_global_context(options)
    cli = DocCLI()
    cli.post_process_args([])


# Generated at 2022-06-20 13:10:34.214093
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('/path/to/module_utils/module_utils.py') == 'module_utils'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/action/module_utils/module_utils.py') == 'module_utils'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/action/modules.py') == 'action'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/action/modules') == 'action'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/lookup/plugins') is None
    assert DocCLI.namespace_from_plugin_filepath('/path/to/module_utils') is None

# Generated at 2022-06-20 13:10:39.843801
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    cli = DocCLI()
    cli.find_plugins()
    assert isinstance(cli, DocCLI) is True


# Generated at 2022-06-20 13:10:44.307989
# Unit test for constructor of class DocCLI
def test_DocCLI():
    """
    Test creation of DocCLI object.

    :return: DocCLI object
    """
    doc_obj = DocCLI()

    return doc_obj


# Generated at 2022-06-20 13:10:52.781381
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    report = []
    def test_format_plugin(doc, expected):
        result = DocCLI.get_man_text(doc)
        failed = result != expected
        report.append((failed, 'testing %s' % doc['name'], result, expected))