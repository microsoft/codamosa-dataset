

# Generated at 2022-06-22 18:48:51.994089
# Unit test for function jdump
def test_jdump():
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    display = Display()
    encoder = AnsibleJSONEncoder(sort_keys=True, indent=4)
    display.display(encoder.encode(dict(k=['v'], k2=dict(a='a', b='b'))))
    display.display(encoder.encode(dict(k=['v'], k2=dict(a='a', b='b'))))



# Generated at 2022-06-22 18:49:03.094067
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    cli = DocCLI()
    cli.display.verbosity = 2
    cli.options.verbosity = 2

    cli.env.collect_ignore = ["ignore"]
    cli.env.roledefs = {}
    cli.options = Fakes.options

    cli.options.connection = None
    cli.options.become = None
    cli.options.become_method = None
    cli.options.become_user = None
    cli.options.module_path = None
    cli.options.forks = None
    cli.options.remote_user = None
    cli.options.private_key_file = None
    cli.options.ssh_common_args = None
    cli.options.ssh_extra_args = None

# Generated at 2022-06-22 18:49:14.408344
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Setup test
    class DocCLI_mock:

        @staticmethod
        def add_fields(the_list, the_doc, limit, opt_indent, return_values = False, parent_indent = ''):
            for k, v in the_doc.items():
                if isinstance(v, (list, tuple)):
                    the_list.append('%s%s: %s' % (opt_indent, k, ', '.join(v)))
                else:
                    the_list.append('%s%s: %s' % (opt_indent, k, v))

    role_json = {'entry_points': [{'entry_point': {'description': 'description1', 'options': {'foo': 'bar'}, 'attributes': {'foo1': 'bar1'}}}]}
    cl

# Generated at 2022-06-22 18:49:17.205803
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound()
    except PluginNotFound as e:
        print("test_PluginNotFound {}".format(e))


# Generated at 2022-06-22 18:49:26.643495
# Unit test for function jdump
def test_jdump():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    test_dict = {}
    test_dict['testkey'] = 'value'
    test_dict['vaultedkey'] = AnsibleVaultEncryptedUnicode('vaultedvalue')
    # This doesn't work because jdump doesn't use AnsibleJSONEncoder
    # assert jdump(test_dict) == json.dumps(test_dict, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)



# Generated at 2022-06-22 18:49:37.733181
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    a = {
        'name': 'test_Role',
        'filename': 'test_Role',
        'entry_points': {
            'main': {
                'short_description': 'The test role',
                'options': {'name': 'entry_point'},
                'version_added': '2.4',
                'description': [
                    'The short description',
                    'The long description'
                ],
                'attributes': {'name': 'attributes'}
            }
        },
        'path': 'test_Role'
    }


# Generated at 2022-06-22 18:49:50.175280
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    import sys
    from collections import namedtuple

    DocCLI_plugins = namedtuple('Plugin',
                                'filename name description')


# Generated at 2022-06-22 18:49:51.573425
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doccli = DocCLI()
    assert doccli
    assert DocCLI

# Generated at 2022-06-22 18:49:56.992052
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    assert DocCLI.format_plugin_doc(dict(name='test', short_description='test desc', version_added=2.2)) == 'test      (unknown version)\n\nDESCRIPTION\n  test desc\n\nADDED IN: 2.2\n'
    assert DocCLI.format_plugin_doc(dict(name='test', short_description='test desc', version_added=2.2, version_added_collection='ansible.builtin')) == 'test      (unknown version)\n\nDESCRIPTION\n  test desc\n\nADDED IN: Ansible Collection 2.2\n'

# Generated at 2022-06-22 18:49:58.416031
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    assert True


# Generated at 2022-06-22 18:50:01.992997
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    # DocCLI.post_process_args(plugin_type, module_list, api_version, collection_list, selected_collection)
    # FIXME: not yet implemented
    return



# Generated at 2022-06-22 18:50:15.555848
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    name = "test_DocCLI_post_process_args"

    parser = DocCLI()
    parser.parser = Mock()
    parser.parse()

    parser.post_process_args(vars(parser.optparser.parse_args(['-L'])), "")
    assert parser.pager is not None

    parser.post_process_args(vars(parser.optparser.parse_args(['-h'])), "")
    assert parser.function == DocCLI.get_doc
    assert parser.module_index == False

    parser.post_process_args(vars(parser.optparser.parse_args(['--help'])), "")
    assert parser.function == DocCLI.get_doc
    assert parser.module_index == False

    parser.parser = Mock()
    parser.parse

# Generated at 2022-06-22 18:50:19.334823
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    assert DocCLI._get_all_plugins_of_type('action') == ['action', 'net_tools']


# Generated at 2022-06-22 18:50:31.013298
# Unit test for method format_snippet of class DocCLI

# Generated at 2022-06-22 18:50:35.217255
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'action'
    coll_filter = None
    DocCLI.add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert len(plugin_list) > 0



# Generated at 2022-06-22 18:50:37.307478
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    doc = DocCLI()
    parser = doc.init_parser()
    assert isinstance(parser, argparse.ArgumentParser)



# Generated at 2022-06-22 18:50:49.440534
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    from ansible.module_utils.six import StringIO

    args = DocCLI.parse(['ansible-doc', '-l'])
    assert not args.get('show_snippet'), "Unexpected value for 'show_snippet' argument"
    assert not args.get('show_deprecated'), "Unexpected value for 'show_deprecated' argument"

    args = DocCLI.parse(['ansible-doc', '--snippet'])
    assert args.get('show_snippet'), "Unexpected value for 'show_snippet' argument"
    assert not args.get('show_deprecated'), "Unexpected value for 'show_deprecated' argument"

    args = DocCLI.parse(['ansible-doc', '-s'])

# Generated at 2022-06-22 18:50:57.759395
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc_cli = DocCLI()
    assert doc_cli.get_role_man_text('test_role', {'entry_points':{'test_entry':{}}})[0] == '> TEST_ROLE    ()\n'
    assert doc_cli.get_role_man_text('test_role', {'path':'/test', 'entry_points':{'test_entry':{}}})[0] == '> TEST_ROLE    (/test)\n'
    assert doc_cli.get_role_man_text('test_role', {'path':'/test', 'entry_points':{'test_entry':{'short_description':'test_summary'}}})[0] == '> TEST_ROLE    (/test)\n'

# Generated at 2022-06-22 18:51:05.953088
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # set up role json and verify that it is set
    module_name = 'copy'
    doc = utils.module_docs.get_docstring(module_name, verbose=False)
    assert doc is not None
    # get text for the copy module and verify that it is not None.
    text = DocCLI.get_man_text(doc)
    assert text is not None


# Generated at 2022-06-22 18:51:09.013537
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    '''
    Unit test for method get_plugin_metadata of class DocCLI.
    '''
    # TODO: Implement tests
    pass


# Generated at 2022-06-22 18:51:12.837476
# Unit test for function jdump
def test_jdump():
    res = jdump(dict(key1='val1', key2='val2'))
    assert res == '{\n    "key1": "val1", \n    "key2": "val2"\n}\n'



# Generated at 2022-06-22 18:51:15.889682
# Unit test for function jdump
def test_jdump():
    assert jdump([1, 2, 'a', {'k': 'v'}]) == '[\n    1,\n    2,\n    "a",\n    {\n        "k": "v"\n    }\n]'



# Generated at 2022-06-22 18:51:18.540223
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    """Unit test for constructor of class PluginNotFound"""
    assert PluginNotFound('path_to_plugin', 'full_or_partial_name')



# Generated at 2022-06-22 18:51:25.345583
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Create a new DocCLI object
    # Arguments:
    #     cli_options: A dictionary of command line options for the doc CLI
    #     find_default_inc: Should we search for default includes?
    #     collection_list: A list of collections
    doc = DocCLI(None, False, None)
    # Uncomment this line to see the test run
    # doc.print_paths("ansible")


# Generated at 2022-06-22 18:51:38.664971
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    doccli_obj = DocCLI()

# Generated at 2022-06-22 18:51:50.737569
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    cliDoc = DocCLI()
    path = "/home/ansible/ansible/lib/ansible/plugins/action/cloudformation.py"
    result = cliDoc.namespace_from_plugin_filepath(path)
    #assert result == 'ec2', "result should be {}, but is {}".format('ec2', result)
    assert result == 'cloudformation', "result should be {}, but is {}".format('cloudformation', result)

    path = "/home/ansible/ansible/lib/ansible/plugins/module/config_template.py"
    result = cliDoc.namespace_from_plugin_filepath(path)
    assert result == 'config_template', "result should be {}, but is {}".format('config_template', result)


# Generated at 2022-06-22 18:52:02.301588
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # Short-circuit DocCLI.IGNORE by re-creating it
    DocCLI.IGNORE = set(("plainexamples", "returndocs", "metadata", "options", "requirements"))
    # Avoid dict order dependency in test
    example = dict()
    example['text'] = '''
    # Example from Ansible Playbooks
    - name: This is a basic example to use the module
      ping:
    '''
    example['type'] = 'ansible'
    example['options'] = dict()
    example['options']['ANSIBLE_PING_HOSTS'] = dict(default='localhost')
    example['options']['ANSIBLE_PING_USER'] = dict(default='dummy_user')
    example['options']['ANSIBLE_PING_PASSSWORD'] = dict

# Generated at 2022-06-22 18:52:05.584277
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    from ansible import constants as C
    from ansible.cli import CLI
    from ansible.utils.display import Display

    cli = CLI(args=[])
    cli.options.type = 'module'
    cli.options.tree = None
    display = Display()

    doc_cli = DocCLI(cli, display)
    doc_cli.get_all_plugins_of_type()

# Generated at 2022-06-22 18:52:12.999807
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    display = Options(columns=80)
    cli_args = Options(type='module')
    doc_obj = DocCLI(display, cli_args)

# Generated at 2022-06-22 18:52:15.838979
# Unit test for function jdump
def test_jdump():
    mock = "{'key': 'value'}"
    jdump(mock)



# Generated at 2022-06-22 18:52:26.345371
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    arg_spec = dict(
        module=dict(type='str', required=False),
        pattern=dict(type='str', required=False)
    )

    module_args = dict(
        module=['setup', 'template'],
        pattern='*'
    )

    p = Mock(**{'_get_plugin_files.return_value': []})
    with patch.object(DocCLI, '_find_plugins', return_value=[p]):
        with pytest.raises(AnsibleExitJson):
            cli = DocCLI(None, {'module_args': module_args})
            cli._get_module_args = lambda : module_args
            cli._get_arg_spec = lambda: arg_spec
            cli.run()

# Generated at 2022-06-22 18:52:32.353301
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'module'
    coll_filter = 'canjs'
    add_collection_plugins(plugin_list, plugin_type, coll_filter=coll_filter)
    assert len(plugin_list) > 0
    assert plugin_list['canjs'] == 'canjs.core.system_info'



# Generated at 2022-06-22 18:52:37.080890
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    '''Unit test for method display_plugin_list of class DocCLI'''
    from ansible.utils.display import Display
    d = Display()
    DocCLI.display_plugin_list(d)

# Generated at 2022-06-22 18:52:47.461004
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    md = DocCLI().get_plugin_metadata()
    out = {}
    for element in ['module', 'module_utils', 'callback', 'doc_fragments', 'lookup_plugin', 'vars', 'filter', 'test', 'shell']:
        out[element] = {}
        for plugin, plugin_data in md[element].items():
            out[element][plugin] = {
                "name": plugin_data["name"],
                "path": plugin_data["path"],
                "filename": plugin_data["filename"],
            }
    # print(json.dumps(out))

# Generated at 2022-06-22 18:52:58.568646
# Unit test for function jdump

# Generated at 2022-06-22 18:53:01.950488
# Unit test for function jdump
def test_jdump():
    text = {'a': 'b'}
    try:
        json.dumps(text, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)
        return True
    except TypeError:
        return False

# Generated at 2022-06-22 18:53:10.494494
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    with display.override_verbosity(3):
        try:
            raise PluginNotFound(r"no plugin found for: \<module 'ansible.plugins.doc_fragments.submodules_core' from '/usr/lib/python3.6/site-packages/ansible/plugins/doc_fragments/subm\odules_core.py'\>")
        except PluginNotFound as e:
            display.display(to_text(e))
test_PluginNotFound()



# Generated at 2022-06-22 18:53:21.022318
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    doc = DocCLI()
    assert doc.namespace_from_plugin_filepath('/Users/username/Library/Python/2.7/lib/python/site-packages/ansible/module_utils/fortios.py') == 'module_utils'
    assert doc.namespace_from_plugin_filepath('/Users/username/Library/Python/2.7/lib/python/site-packages/ansible/modules/cloud/vmware/vmware_guest_network_facts.py') == 'cloud.vmware'
    assert doc.namespace_from_plugin_filepath('/Users/username/Library/Python/2.7/lib/python/site-packages/ansible/modules/monitoring/grafana/grafana_api.py') == 'monitoring.grafana'
    assert doc.namespace_

# Generated at 2022-06-22 18:53:28.723249
# Unit test for function jdump
def test_jdump():
    input_raw = '{"text": "Congrats for reading this in a text file"}'
    input_obj = {"text": "Congrats for reading this in a text file"}
    output_raw = json.dumps(input_obj, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)
    assert jdump(input_obj) == output_raw
    assert jdump(input_raw) == output_raw



# Generated at 2022-06-22 18:53:40.803438
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    reg = RoleMixin()

    # These sample arg specs are stripped-down role arg specs
    spec_file_one = """
        argument_specs:
            main:
                short_description: A main entry point
    """

    spec_file_two = """
        argument_specs:
            secondary:
                short_description: A secondary entry point
                description: |
                    A secondary entry point that supports
                    multiline descriptions
    """

    # A role with no actual argument specs still has a meta/main.yml
    spec_file_three = """
        not_argument_specs:
            foo: bar
    """

    # This entry point is missing the short_description

# Generated at 2022-06-22 18:53:44.917324
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc_cli = DocCLI()
    path = 'path'
    plugin_type = 'lookup'
    plugins = doc_cli.get_all_plugins_of_type(path, plugin_type)
    assert plugins['test'] is not None

# Generated at 2022-06-22 18:53:53.831293
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    mixin = RoleMixin()
    roles = ['roleA', 'roleB', 'roleC']
    for role in roles:
        roles_path = [os.path.join(os.path.dirname(__file__), 'test_collections', 'test_ns', 'collection_argspec_listing_data', role)]
        role_listing = mixin._create_role_list(roles_path)
        assert role in role_listing
        role_doc = mixin._create_role_doc([role], roles_path)
        assert role in role_doc


# Generated at 2022-06-22 18:54:04.312010
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():

    # Create parameters
    # Dictionary containing information of option
    opt = dict()
    opt['option'] = 'ansible'
    opt['description'] = 'Ansible playbook automatic testing'
    opt['options'] = dict()
    opt['options']['name'] = 'ansible'
    opt['options']['description'] = 'Ansible playbook automatic testing'
    opt['options']['type'] = 'str'
    opt['options']['default'] = 'test'
    opt['options']['choices'] = ['test', 'test1', 'test2']
    limit = 20
    opt_indent = '        '

    # Set the return value of the method

# Generated at 2022-06-22 18:54:09.828772
# Unit test for method get_plugin_metadata of class DocCLI

# Generated at 2022-06-22 18:54:11.101333
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    DocCLI._find_plugins()

# Generated at 2022-06-22 18:54:24.102064
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    from ansible.module_utils.common._collections_compat import Mapping

    m = RoleMixin()

    # Test role with no argument spec data
    role_path = './test/data/plugins/modules/role_no_argdata'
    argspec = m._load_argspec('role_no_argdata', role_path=role_path)
    assert isinstance(argspec, dict)
    assert len(argspec) == 0

    # Test role with argument spec data
    role_path = './test/data/plugins/modules/role_have_argdata'
    argspec = m._load_argspec('role_have_argdata', role_path=role_path)
    assert isinstance(argspec, dict)
    assert len(argspec) == 2
    assert 'main' in argspec
   

# Generated at 2022-06-22 18:54:29.270975
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Check that any field starting with _ is ignored
    subdata = {'_field1':'val1', 'field2':'val2'}
    tdata = ['/* field2 */', 'field2: val2']
    text = []
    DocCLI.add_fields(text, subdata, 90, '    ', opt_indent='    ')
    assert text == tdata


# Generated at 2022-06-22 18:54:39.228622
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    doc_cli = DocCLI()
    options = doc_cli.options
    plugin = 'action'
    args = []
    doc_cli.post_process_args(options, plugin, args)
    assert options['type'] == 'action'
    assert options['name'] == None
    with pytest.raises(SystemExit):
        doc_cli.post_process_args(options, plugin, ["bad_input"])
    with pytest.raises(SystemExit):
        doc_cli.post_process_args(options, plugin, [])


# Generated at 2022-06-22 18:54:46.794883
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    snippet = '- name : do something'
    assert DocCLI.format_snippet(snippet).strip() == '- name: do something'
    assert DocCLI.format_snippet("\n".join([snippet, snippet])).strip() == "- name: do something\n- name: do something"



# Generated at 2022-06-22 18:54:57.133841
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    try:
        os.makedirs(atc)
    except OSError as e:
        if e.errno == errno.EEXIST:
            pass


# Generated at 2022-06-22 18:55:03.446412
# Unit test for constructor of class DocCLI
def test_DocCLI():
    myobj = DocCLI()
    assert isinstance(myobj, object)

    # Test for the constructor with default value of pager
    test_myobj = DocCLI('/bin/more')
    assert isinstance(test_myobj, object)

# Test for method list_doc()

# Generated at 2022-06-22 18:55:07.902840
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = dict(
        type='module',
        all=True,
        plain=True,
        output=True
    )
    ansible.cli.doc.DocCLI(args).run()

if __name__ == '__main__':
    test_DocCLI_run()

# Generated at 2022-06-22 18:55:17.242586
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    from unittest import TestCase, makeSuite, TextTestRunner
    cli = DocCLI()

    # test single line example:
    text = cli.post_process_args("This is a test.")
    assert text == "This is a test.", "General example: %s" % text

    # test multiline example:
    text = cli.post_process_args("""This is a test.
    With another line.""")
    assert text == "This is a test. With another line.", "Multiline example: %s" % text

    # test multiline example with diag:
    text = cli.post_process_args("""This is a test.
    With another line.
    "Another line with diag quotes."
    """)

# Generated at 2022-06-22 18:55:20.216603
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    d = DocCLI()
    res = d.print_paths(None)
    assert res is None


# Generated at 2022-06-22 18:55:32.206212
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc_path = 'lib/ansible/modules/cloud/amazon/aws_lambda.py'
    display_json = False
    filter_fqcn = False
    filter_tags = None
    filter_version = None
    subcategory = ''
    type_name = 'module'
    # method_display_plugin_list_obj = DocCLI(doc_path, type_name)
    method_display_plugin_list_obj = DocCLI(doc_path)
    assert method_display_plugin_list_obj is not None
    result = method_display_plugin_list_obj.display_plugin_list(
        type_name, subcategory, filter_tags, filter_version, filter_fqcn, display_json)
    assert result is True


# Generated at 2022-06-22 18:55:42.681355
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():

    # tests that normal plugins will be formatted as expected
    class MyPluginTest(MyBase):
        def __init__(self):
            self._test_my_plugin_test_ = 'test'
            self._test_my_plugin_test_2 = 'test2'
            self._test_my_plugin_test_3 = 'test3'
            self._test_my_plugin_test_dict = {'test': 'dict'}
            self._test_my_plugin_test_list = ['test', 'list']

            self._test_my_plugin_test_seq = "['test', 'seq']"
            self._test_my_plugin_test_quotes = "\"test\""

            self._test_my_plugin_test_boolean = True
            self._test_my_plugin_test_int = 2

       

# Generated at 2022-06-22 18:55:50.561851
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
  # Test if subcommand 'help' creates a subparser named 'help'
  parser = DocCLI.init_parser()
  assert('help' in parser._subparsers._group_actions[0].choices)
  # Check for commands
  for command in ['list', 'print']:
    assert(command in parser._subparsers._group_actions[0].choices)
    # Check for options
    for option in ['list', 'print', 'roles']:
      assert(option in parser._option_string_actions)
    # Check for action 'extend_help'
    assert('print' in parser._option_string_actions['print']._choices_actions[0].choices)



# Generated at 2022-06-22 18:55:55.470203
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    expected = 'ansible.modules.network.fortios'
    actual = DocCLI.namespace_from_plugin_filepath('/a/b/c/lib/ansible/modules/network/fortios.py')

    assert expected == actual


# Generated at 2022-06-22 18:55:59.645628
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc = DocCLI()
    doc.find_plugins()
    ansible_plugins.module_finder.PluginLoader.add_directory = Mock(return_value=None)
    doc.find_plugins()


# Generated at 2022-06-22 18:56:06.957175
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    for doc in '''- name: Ansible get Apache user
      become: yes
      become_user: apache
      become_method: su
      gather_facts: False
      hosts: all
      tasks:
        - get_user:
      register: result
      vars:
           names: "{{ some_var }}"
           apache_user: 'apache'
      when: result != 'success'
      with_items:
        - "{{ apache_user }}"
    ''':
        print(DocCLI.format_plugin_doc(doc).rstrip())


# Generated at 2022-06-22 18:56:18.073960
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():

    # From test/integration/inventory/test_dynamic_includes.py:InventoryTests.test_dynamic_includes
    # This is a list of all the plugin types that are loaded during a normal
    # 'ansible-playbook' run.
    cli = DocCLI()
    plugin_types = [
        'action_plugin', 'connection_plugin',
        'cache_plugin', 'callback_plugin', 'become_plugin',
        'filter_plugin', 'inventory_plugin', 'shell_plugin',
        'test_plugin', 'vars_plugin', 'terminal_plugin'
    ]

    for plugin_type in plugin_types:
        found_plugins = cli.find_plugins(plugin_type=plugin_type)
        assert found_plugins is not None
        # FIXME: This may be a bug with the

# Generated at 2022-06-22 18:56:25.456032
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    import tempfile
    from ansible.module_utils.six import StringIO
    out = StringIO()
    sys.stdout = out
    temp_dir=tempfile.mkdtemp()
    cmd = DocCLI(["-c",temp_dir,"helloworld"])
    cmd.parse()
    out.seek(0)
    text = out.read()
    # Assert if the content of output text is as expected

# Generated at 2022-06-22 18:56:29.600578
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
	doc = DocCLI(context={}, plugin_type='module')
	doc.display_plugin_list('module')
test_DocCLI_display_plugin_list()

# Generated at 2022-06-22 18:56:38.997170
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-22 18:56:47.937453
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    c = DocCLI()
    c.parser = c.init_parser()
    assert_equal(c.parser.description, "Creates a CLI manual from a JSON doc file.")
    assert_equal(c.parser.prog, "ansible-doc")

    assert isinstance(c.parser._subparsers, argparse._SubParsersAction)

    # test that the correct subcommands are created
    subcommands = [subcommand._name_parser_map.keys()[0] for subcommand in c.parser._subparsers._actions]
    assert_in("module", subcommands)
    assert_in("module_path", subcommands)
    assert_in("modules", subcommands)
    assert_in("modules_fragment", subcommands)

# Generated at 2022-06-22 18:56:51.337113
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    p = PluginNotFound("plugin_name", "plugin_type")
    assert p.plugin_name == "plugin_name"
    assert p.plugin_type == "plugin_type"



# Generated at 2022-06-22 18:57:02.170307
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    listOfPlugins = DocCLI.get_all_plugins_of_type('module')
    assert listOfPlugins is not None, 'Test Failed: get_all_plugins_of_type(): returning None for modules'
    assert len(listOfPlugins) == 1888, 'Test Failed: get_all_plugins_of_type(): ' + str(len(listOfPlugins)) + \
                                       ' is the number of plugins returned for modules instead of 1888'

    listOfPlugins = DocCLI.get_all_plugins_of_type('action')
    assert listOfPlugins is not None, 'Test Failed: get_all_plugins_of_type(): returning None for actions'
    assert len(listOfPlugins) == 13, 'Test Failed: get_all_plugins_of_type(): ' + str(len(listOfPlugins))

# Generated at 2022-06-22 18:57:13.744329
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    test = TestModule()
    DocCLI.IGNORE = DocCLI.IGNORE + (context.CLIARGS['type'],)
    module_name = 'test'
    filename = '/home/dinesh/anil_python/ansible-master/lib/ansible/modules/network/test.py'

# Generated at 2022-06-22 18:57:27.158194
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    roleMixinObj = RoleMixin()
    roleMixinObj._load_argspec()
    roleMixinObj._find_all_normal_roles()
    roleMixinObj._find_all_collection_roles()
    roleMixinObj._build_summary()
    roleMixinObj._build_doc()
    roleMixinObj._create_role_list()
    roleMixinObj._create_role_doc()
# --------------------------------------------------------------------------------------------------

# --------------------------------------------------------------------------------------------------
# The Code below was written using the Data returned by the RoleMixin Class Methods
# --------------------------------------------------------------------------------------------------

    # def _create_role_tree(self, role_names, roles_path, entry_point=None):
    #     """Create a tree of roles.
    #
    #     :param role_names: A tuple of one or more role names.
    #

# Generated at 2022-06-22 18:57:30.461342
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    assert issubclass(PluginNotFound, Exception)
    assert PluginNotFound.__name__ == 'PluginNotFound'



# Generated at 2022-06-22 18:57:33.305412
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    pnf = PluginNotFound("Plugin not found.")
    assert pnf.args[0] == "Plugin not found."



# Generated at 2022-06-22 18:57:40.629597
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    # Test for init_parser method of DocCLI class
    # Mock args
    args = mock.MagicMock()
    # Create object of class DocCLI
    doc = DocCLI(args)
    # Create mock object of class argparse.ArgumentParser
    arg_parser = argparse.ArgumentParser()
    # Call method init_parser
    doc.init_parser(arg_parser)
    # Assert that arg_parser.add_argument is called
    args.assert_has_calls([mock.call.add_argument('action', choices=['list', 'show'])])


# Generated at 2022-06-22 18:57:42.365208
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound("Should raise an exception")
    except PluginNotFound as e:
        assert isinstance(e, PluginNotFound)



# Generated at 2022-06-22 18:57:44.307838
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # FIXME: This seems to be a difficult class to test
    assert False



# Generated at 2022-06-22 18:57:54.847756
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    """Test the method DocCLI.add_fields()."""

    text = []
    limit = max(display.columns - int(20), 70)

    options = {'name': 'test', 'description': 'test description', 'required': True}
    DocCLI.add_fields(text, options, limit)
    assert ''.join(text) == "        NAME: test\n        DESCRIPTION:\n            test description\n        REQUIRED: True"

    text = []
    options = {'name': {'type': 'string', 'default': 'test_default_value'}, 'description': 'test description', 'required': True}
    DocCLI.add_fields(text, options, limit)

# Generated at 2022-06-22 18:57:58.616322
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound("PluginNotFound exception")
    except PluginNotFound as e:
        assert "PluginNotFound exception" in repr(e)
        assert "PluginNotFound exception" in str(e)



# Generated at 2022-06-22 18:57:59.611563
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    pass

# Generated at 2022-06-22 18:58:05.175317
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    doc = DocCLI()
    assert not doc.namespace_from_plugin_filepath("lookup/test.py")
    assert doc.namespace_from_plugin_filepath("lookup_plugins/test.py") == "test"
    assert not doc.namespace_from_plugin_filepath("test.py")
    assert doc.namespace_from_plugin_filepath("plugins/test.py") == "test"

# Generated at 2022-06-22 18:58:08.305128
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound()
    except PluginNotFound:
        pass
    except Exception:
        assert False, 'Exception raised was not a PluginNotFound'



# Generated at 2022-06-22 18:58:16.132649
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    docs = DocCLI()
    data = docs.get_plugin_metadata(os.path.join(fixtures_path, 'plugins', 'test_include_role.py'))
    assert data['docuri'] == 'doc'
    assert data['version_added'] == '2.2'
    assert data['type'] == 'role_include'


# Generated at 2022-06-22 18:58:19.500623
# Unit test for function jdump
def test_jdump():
    a = {"Foo": "Bar", "list": [{"Baz": [1, 2, 3]}, {"Boz": [1, 2, 3]}]}
    assert json.dumps(a, cls=AnsibleJSONEncoder, sort_keys=True, indent=4) == jdump(a)



# Generated at 2022-06-22 18:58:22.042507
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    with pytest.raises(Exception):
        raise PluginNotFound('test message')



# Generated at 2022-06-22 18:58:31.630166
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'description': 'This is a description',
        'options': {
            'foo': {
                'description': 'This is a description of an option',
                'required': True,
                'default': 'bar'
            }
        },
        'notes': [
            'This is a note.',
            'This is another note.'
        ],
        'seealso': [
            {
                'module': 'foo',
                'description': 'This module does the same thing'
            }
        ],
        'requirements': [
            'foo',
            'bar'
        ],
        'author': 'Me <you@example.com>',
    }
    results = DocCLI.get_man_text(doc)
    assert type(results) == str

# Generated at 2022-06-22 18:58:33.402954
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound
    except PluginNotFound as e:
        if str(e) != 'Ansible Plugin Not Found':
            raise AssertionError('There was an error in the Error message for PluginNotFound were not the same.')



# Generated at 2022-06-22 18:58:45.490678
# Unit test for function jdump
def test_jdump():
    import datetime
    test_data = dict(
        a=['b', 'c', 'd', 'e'],
        b=dict(a=5, b=dict(a=5, b=dict(a=5, b=dict(a=5)))),
        c=datetime.datetime.now().isoformat(),
    )

    from ansible.module_utils.six import PY3
    if PY3:
        import io

        class TestStr(io.StringIO):
            def __init__(self):
                io.StringIO.__init__(self)

            def read(self):
                return self.getvalue()

        output = TestStr()
    else:
        import StringIO

        class TestStr(StringIO.StringIO):
            def __init__(self):
                StringIO.String

# Generated at 2022-06-22 18:58:53.600495
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        u'description': u'Tells the module to run in check mode',
        u'options': {
            u'CHECKMODE': {
                u'type': u'bool',
                u'description': [
                    u'Describes the type of value that the option accepts.',
                    u'In this case, the user can specify a boolean value.',
                    u'The default value is False.'],
                u'default': u'False'}},
        u'plainexamples': u'# Fail if the check mode is not enabled\n- name: Ensure check mode is on\n  assert: { that: ansible_check_mode }'}