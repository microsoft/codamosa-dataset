

# Generated at 2022-06-22 18:48:57.006625
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    '''Test unit for method add_fields of class DocCLI
    '''
    # Test for case with no options
    no_options = {}
    opt_indent = "        "
    limit = 80
    text = []
    DocCLI.add_fields(text, no_options, limit, opt_indent)
    assert text == []
    # Test for case with options
    options = {
        'state': {
            'description': "Whether to create or remove the user."
        }
    }
    DocCLI.add_fields(text, options, limit, opt_indent)
    assert text == ['        - state: Whether to create or remove the '
                    'user.']


# Generated at 2022-06-22 18:48:58.269541
# Unit test for constructor of class DocCLI
def test_DocCLI():
    DocCLI()


# Generated at 2022-06-22 18:49:06.341670
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    print('Testing get_man_text of DocCLI.')
    # Creating an instance of class DocCLI
    doc_cli_instance = DocCLI()
    doc = dict()
    doc['name'] = 'ping'
    doc['description'] = "This module makes sure the remote you want to connect is available."
    collection_name = 'ping'
    plugin_type = 'module'

# Generated at 2022-06-22 18:49:11.795470
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    d = DocCLI('Module')
    paths = ['/a/b/c', '/a/b/d']
    d._print_paths(paths)
    assert(d.stdout == '[\x1b[0;32m/a/b/c\x1b[0m, \x1b[0;32m/a/b/d\x1b[0m]')

# Generated at 2022-06-22 18:49:16.612305
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = DocCLIArgs()
    args.type = 'module'
    context.CLIARGS = args
    doc = DocCLI()
    test_result = doc.run()
    assert test_result == 0


# Generated at 2022-06-22 18:49:29.399501
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {
        'description': [],
        'options': {},
        'seealso': None,
        'extends_documentation_fragment': ['basic_auth', 'ssl_connection'],
        'version_added': None,
        'default_options': {
            'force_basic_auth': True,
            'auth_pass': 'NULL'
        },
        'short_description': 'usage: ansible-doc [-h] [-v] [-M MODULE_PATH] [-t MODULE_TYPE] [-V] module [module ...]',
        'description': 'usage: ansible-doc [-h] [-v] [-M MODULE_PATH] [-t MODULE_TYPE] [-V] module [module ...]\n\nShow Ansible module documentation'
    }

# Generated at 2022-06-22 18:49:30.731120
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    pass


# Generated at 2022-06-22 18:49:42.792115
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # DocCLI.get_man_text()
    with pytest.raises(AnsibleParserError):
        DocCLI.get_man_text({})

    with pytest.raises(AnsibleParserError):
        DocCLI.get_man_text({
            'description': ''
        })

    with pytest.raises(AnsibleParserError):
        DocCLI.get_man_text({
            'description': 'test description'
        })

    print("test_DocCLI_get_man_text")

# Generated at 2022-06-22 18:49:43.436611
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    pass



# Generated at 2022-06-22 18:49:47.737648
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    from ansible.utils.collection_loader import list_collections
    plugin_list = []
    add_collection_plugins(plugin_list, 'module')
    for p in plugin_list:
        assert p['type'] == 'module'



# Generated at 2022-06-22 18:49:48.760728
# Unit test for function jdump
def test_jdump():
    jdump({'key': 'value'})



# Generated at 2022-06-22 18:49:51.659258
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    test_instance = DocCLI()
    assert test_instance.post_process_args(['arg1', 'arg2']) == ['arg1', 'arg2']


# Generated at 2022-06-22 18:49:53.801214
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = []
    plugin_type = 'shell'
    assert not add_collection_plugins(plugin_list, plugin_type)



# Generated at 2022-06-22 18:49:54.322732
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    pass


# Generated at 2022-06-22 18:50:00.831343
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    '''
    Run a sanity test on RoleMixin
    '''
    mixin = RoleMixin()
    assert isinstance(mixin, RoleMixin)

    # Test the _find_all_normal_roles method

    # Test a normal case: search for a role in a normal role directory
    role_path = os.path.join(ROLE_DIRS[0], 'cloudformation')
    result = mixin._find_all_normal_roles(ROLE_DIRS, name_filters=('cloudformation',))
    # Check for the role and collection
    role, role_path = result.pop()
    assert role == 'cloudformation'
    assert os.path.exists(role_path) is True

    # Test the case where the name filter is not applied
    result = mixin._find_all_normal_

# Generated at 2022-06-22 18:50:06.658326
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    mixin = RoleMixin()
    assert mixin.ROLE_ARGSPEC_FILES == ['argument_specs' + e for e in C.YAML_FILENAME_EXTENSIONS] + ["main" + e for e in C.YAML_FILENAME_EXTENSIONS]


# Generated at 2022-06-22 18:50:18.301921
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    d = DocCLI()

    snippet = textwrap.dedent('''
    # snippet of python code
    def foo():
        bar()
    ''')
    actual = d.format_snippet(snippet, dedent=True)
    expected = textwrap.dedent(u'''
    \u001b[7m# snippet of python code\u001b[0m
    def foo():
        bar()
    ''')
    assert actual == expected

    snippet = textwrap.dedent('''
    # snippet of python code
    def foo():
        :description: test description
        :param url: url
        :param method: method
        :returns: return value
        :rtype: list
        bar()
    ''')

# Generated at 2022-06-22 18:50:24.582166
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = DocCLI()
    data = doc.get_plugin_metadata()
    pprint.pprint(data)

    assert isinstance(data, dict)
    assert data['core_plugins']
    assert data['core_plugins']['modules']['ping']['short_description'] == 'Returns C(pong) on successful contact'


# Generated at 2022-06-22 18:50:25.963177
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    import doctest
    doctest.testmod(RoleMixin)


# Generated at 2022-06-22 18:50:29.381380
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    assert DocCLI.format_snippet('foo.yml', 'bar', 'yaml') == 'foo.yml\n' + '''
<BLANKLINE>
bar
<BLANKLINE>
'''


# Generated at 2022-06-22 18:50:41.976206
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    args = DocCLI()
    assert args.post_process_args([]) == []
    assert args.post_process_args(['foo']) == ['foo']
    assert args.post_process_args(['foo', 'bar']) == ['foo', 'bar']
    assert args.post_process_args(['-M', 'foo']) == ['--modulepath', 'foo']
    assert args.post_process_args(['-M', 'foo', '-M', 'bar']) == ['--modulepath', 'foo', '--modulepath', 'bar']
    assert args.post_process_args(['-m', 'foo']) == ['--module', 'foo']
    assert args.post_process_args(['-a', 'foo']) == ['--args', 'foo']
    assert args.post_process_

# Generated at 2022-06-22 18:50:52.376954
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    mock_list_of_topics = MagicMock(return_value=['core', 'database', 'packaging', 'source_control', 'web_infrastructure', 'cloud', 'net_tools', 'windows', 'notification', 'storage', 'messaging', 'monitoring', 'network', 'database', 'web', 'windows', 'source_control', 'cloud', 'messaging', 'monitoring', 'net_tools', 'notification', 'packaging', 'storage', 'network', 'web_infrastructure', 'windows'])

# Generated at 2022-06-22 18:50:53.523193
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    assert DocCLI.find_plugins()

# Generated at 2022-06-22 18:50:54.026632
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    return



# Generated at 2022-06-22 18:51:01.499732
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    #
    # Test method init_parser of class DocCLI
    #

    # Define some input and output arguments
    args = {'type': 'module', 'format': 'yaml', 'path': './../../lib/ansible/modules/commands', 'version': 'v2_0_0_2_g7ec967d'}

    # Run init_parser
    DocCLI().init_parser(args)

# Generated at 2022-06-22 18:51:14.430057
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Set up the mock input arguments
    DocCLI.return_value = False
    DocCLI.short = False
    DocCLI.version = False
    DocCLI.help = False
    DocCLI.man = False
    DocCLI.type = False
    DocCLI.action = False
    DocCLI.extension = False
    DocCLI.metadata = False
    DocCLI.listt = False
    DocCLI.listb = False
    DocCLI.listdocs = False
    DocCLI.listcollections = False
    DocCLI.path = False
    DocCLI.reflect = False
    DocCLI.expandvars = False

    # Mock the function dependant on LogicalModuleRegistry

# Generated at 2022-06-22 18:51:17.747368
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    obj = DocCLI()
    assert type(obj.get_all_plugins_of_type()) == list


# Generated at 2022-06-22 18:51:22.786987
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    pnf = PluginNotFound('test_msg')
    assert pnf.args[0] == 'test_msg', "PluginNotFound constructor expected to set message 'test_msg'"


# This class is based on AnsibleCLI but with a lot of changes and some simplification

# Generated at 2022-06-22 18:51:31.530163
# Unit test for constructor of class DocCLI
def test_DocCLI():

    # test for ansible.cli.doc
    plugin = DocCLI(['doc', '-t', 'module'])
    assert plugin.options.type == 'module'

    # test for ansible.cli.role
    plugin = DocCLI(['doc', '-t', 'role'])
    assert plugin.options.type == 'role'

    # test for ansible.cli.collection
    plugin = DocCLI(['doc', '-t', 'collection'])
    assert plugin.options.type == 'collection'


# Generated at 2022-06-22 18:51:42.674986
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-22 18:51:49.326396
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    doc_cli = DocCLI()
    plugins = {}
    plugin_type = 'module'
    add_collection_plugins(plugins, plugin_type)

    plugin_list = plugin_loader.get_all_plugin_loaders()
    plugin_names = [plugin.name for plugin in plugin_list]
    assert set(plugins.keys()).issubset(set(plugin_names))



# Generated at 2022-06-22 18:51:57.698013
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    try:
        import mock
    except ImportError:
        import unittest.mock as mock
    from ansible.plugins.loader import plugin_loader, fragment_loader, cache
    from ansible.module_utils.common._collections_compat import Mapping
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.utils.collection_loader._collection_finder import get_collection_name_from_path

    import ansible.plugins.loader.doc_fragments
    import ansible.plugins.doc_fragments.legacy

    def _clearPluginLists():
        fragment_loader._get_available_fragment_plugins.clear()
        plugin_loader._get_available_plugins.clear()
        plugin_loader._plugins.clear()
        cache.clear()
        cache.ch

# Generated at 2022-06-22 18:52:04.556705
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {"description": "This is a test description", "options": {"first_name": {"description": "first_name"}, "last_name": {"description": "last_name"}}}
    assert DocCLI.get_man_text(doc)=='> TESTCLI    (None)\nThis is a test description\n\nOPTIONS (= is mandatory):\n    > first_name\n        first_name\n\n    > last_name\n        last_name\n'


# Generated at 2022-06-22 18:52:12.250082
# Unit test for method namespace_from_plugin_filepath of class DocCLI

# Generated at 2022-06-22 18:52:13.540519
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI()
    doc.get_all_plugins_of_type()

# Generated at 2022-06-22 18:52:26.131996
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI._namespace_from_plugin_filepath("/usr/lib/ansible/collections/ansible_collections/acmeinc/acme_lib/plugins/action/acme_module.py") == "acmeinc.acme_lib.acme_module"
    assert DocCLI._namespace_from_plugin_filepath("/usr/lib/ansible/collections/ansible_collections/acmeinc/acme_lib/plugins/action/acme_module") == "acmeinc.acme_lib.acme_module"

# Generated at 2022-06-22 18:52:30.115024
# Unit test for function jdump
def test_jdump():
    assert jdump('{"a": ["b", "c"]}') == '{\n    "a": [\n        "b", \n        "c"\n    ]\n}'



# Generated at 2022-06-22 18:52:41.149950
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 70
    opt_indent = "        "
    return_values = False
    opt = {'description': 'the description', 'required': 'True', 'default': 'present', 'choices': ['present', 'absent'], 'aliases': ['foo', 'bar']}
    DocCLI.add_fields(text, opt, limit, opt_indent, return_values)

# Generated at 2022-06-22 18:52:46.168736
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
  ansible_module = AnsibleModule(
      argument_spec = dict(
          type = dict(type='str', required=True),
          path = dict(type='str', required=True),
          collection = dict(type='str', required=True),
      ),
      supports_check_mode=True,
  )
  doc = DocCLI()
  doc.find_plugins(ansible_module.params)



# Generated at 2022-06-22 18:52:49.982721
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    dc = DocCLI()
    # Exercise the code
    dc.print_paths()

# Generated at 2022-06-22 18:53:00.714424
# Unit test for function jdump
def test_jdump():
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    data = {
        "module": {
            "name": "debug",
            "version_added": "historical",
            "short_description": "Print statements during execution",
            "description": "The debug module prints statements during execution and can be useful for debugging variables or expressions without necessarily halting the playbook. If you want to print the value of a variable, you may use the 'msg' module.",
            "options": {
                "msg": {
                    "type": "str",
                    "required": True,
                    "description": "Message to print."
                }
            },
            "notes": "",
            "examples": ""
        }
    }

# Generated at 2022-06-22 18:53:04.159938
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    import doctest
    results = doctest.testmod(DocCLI)
    assert results.failed == 0


# Generated at 2022-06-22 18:53:15.727225
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # No arguments
    assert DocCLI.format_snippet() == 'FAIL'

    # No arguments on Windows -- return returned-value instead
    assert DocCLI.format_snippet(shell='windows') == '/usr/bin/ansible-doc-module return returned-value'

    # One argumnet
    assert DocCLI.format_snippet('echo') == "FAIL"

    # Two arguments
    assert DocCLI.format_snippet('echo', 'Hello World') == "FAIL"

    # More than two arguments
    assert DocCLI.format_snippet('echo', 'Hello World', 'echo') == "FAIL"

    # Specify shell to be bash

# Generated at 2022-06-22 18:53:27.763978
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Instanciate a new DocCLI object
    doc_object = DocCLI()
    # The decription of the role
    role = 'Ansible Role for Tomcat'
    # The json that will be used to generate the text
    role_json = {
        'description': 'Ansible Role for Tomcat',
        'path': 'roles/tomcat/README.md',
        'entry_points': {
            'main': {
                'short_description': 'Main'.upper()
            },
            'pre_tasks': {
                'short_description': 'Pre Tasks'.upper()
            }
        }
    }
    # The expected text for the role

# Generated at 2022-06-22 18:53:36.464578
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Setup
    def cwd():
        return '.'
    DocCLI.cwd = cwd
    def list_collection_names(path):
        collection_names = [
            'my_collection',
            'my_other_collection',
        ]
        return collection_names
    DocCLI.list_collection_names = list_collection_names
    def find_plugins(path, with_info=False):
        if path == 'my_collection':
            plugins = [
                'my_plugin',
                'my_other_plugin',
            ]
        else:
            plugins = []
        return plugins
    DocCLI.find_plugins = find_plugins
    def get_docstring(obj, verbose=False, follow_symlinks=True):
        docstring = "my simple docstring"
        return docstring


# Generated at 2022-06-22 18:53:39.760809
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    """Tests the functionality of the method get_plugin_metadata of class DocCLI."""
    pass

# Generated at 2022-06-22 18:53:43.858158
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    doc = RoleMixin(None)

    assert doc._load_argspec('roleA') == {}


####################################################
# HELPER FUNCTIONS
####################################################

# FIXME: not used?

# Generated at 2022-06-22 18:53:48.096375
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    # TODO: remove this line once we find some way to test class constructors
    raise NotImplementedError("Tests for the constructor of class PluginNotFound are not implemented yet")


# Generated at 2022-06-22 18:53:57.195558
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():

    filename_list = [
        "/ansible/lib/ansible/modules/cloud/rackspace/rax_cbs.py",
        "/ansible/lib/ansible/modules/cloud/amazon/ec2_ami_search.py",
        "/ansible/lib/ansible/modules/cloud/amazon/ec2_ami.py",
        "/ansible/lib/ansible/modules/cloud/amazon/ec2_ami_copy.py",
        "/ansible/lib/ansible/modules/cloud/amazon/ec2_ami_info.py",
    ]
    expected_result_list = [
        "cloud.rackspace",
        "cloud.amazon",
        "cloud.amazon",
        "cloud.amazon",
        "cloud.amazon",
    ]


# Generated at 2022-06-22 18:54:00.376783
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()
    doc.display_plugin_list(['module'], display=True)
    doc.display_plugin_list(['module'], display=False)


# Generated at 2022-06-22 18:54:01.650187
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    obj = DocCLI()
    assert obj is not None


# Generated at 2022-06-22 18:54:03.689650
# Unit test for constructor of class DocCLI
def test_DocCLI():
    dc = DocCLI()
    assert dc is not None


# Generated at 2022-06-22 18:54:16.188675
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # DocCLI.get_role_man_text(role, role_json)
    FAC = "DocCLI.get_role_man_text"
    DOC = {}
    DOC['description'] = ["description"]
    DOC['seealso'] = []
    DOC['entry_points'] = {}
    DOC['entry_points']['main'] = {}
    DOC['entry_points']['main']['description'] = []
    DOC['entry_points']['main']['options'] = {}
    DOC['entry_points']['main']['options']['key1'] = {}
    DOC['entry_points']['main']['options']['key1']['description'] = ["description"]
    DOC['entry_points']['main']['options']['key1']['required']

# Generated at 2022-06-22 18:54:27.977123
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():

    # Documentation lookup for a load_callback_plugin using the callback name.
    #
    # Expected result:
    #    A dictionary containing plugin documentation.
    args = ('core', 'callback')
    with patch.object(DocCLI, '_get_doc_data', return_value=C.data_template('unit/modules/DocCLI_results/callback_loader.json')):
        with patch.object(builtins, 'open', mock_open(read_data=C.load_resource('unit/modules/DocCLI_results/callback_loader.py'))):
            result = DocCLI.get_plugin_metadata(*args)
            expected = C.data_template('unit/modules/DocCLI_results/callback_loader.yaml')
    assert result == expected

    # Documentation lookup for a callback plugin using the module name

# Generated at 2022-06-22 18:54:29.577728
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound
    except PluginNotFound:
        pass



# Generated at 2022-06-22 18:54:36.651171
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # First, create a DocCLI object
    doccli = DocCLI()

    role = 'role_name'

# Generated at 2022-06-22 18:54:39.971804
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    from ansible.cli.doc import DocCLI
    options = DocCLI(args=[])
    assert options.args == []
    assert options.base_parser is not None


# Generated at 2022-06-22 18:54:52.658997
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    module_name = 'setup'
    doc = {}
    doc['module'] = 'setup'
    doc['short_description'] = 'Gathers facts about remote hosts'
    doc['description'] = 'This module is automatically called by playbooks to gather information about remote hosts.'
    doc['version_added'] = 'historical'
    doc['options'] = []
    dict1={}
    dict1['name'] = 'filter'
    dict1['default'] = '*'
    dict1['description'] = 'If supplied, only return facts that match this shell style wildcard.'
    doc['options'].append(dict1)
    dict2={}
    dict2['name'] = 'gather_subset'
    dict2['default'] = 'all'

# Generated at 2022-06-22 18:55:00.644574
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    paths = [
        "/home/me/ansible/mymodule.py",
        "/home/me/ansible/mymodule.ps1",
        "/home/me/ansible/mymodule.bat",
        "/home/me/ansible/mymodule.sh",
        "/home/me/ansible/mymodule.php",
        "/home/me/ansible/mymodule",
        "/home/me/ansible/mymodule.KSH",
        "/home/me/ansible/mymodule.PL",
        "/home/me/ansible/mymodule.RUBY",
        "/home/me/ansible/mymodule.EXE",
    ]
    display.verbosity = 0  # Disable DeprecationWarnings
    returned = DocCLI.print_paths(paths)
    assert returned is None

# Generated at 2022-06-22 18:55:05.724133
# Unit test for function jdump
def test_jdump():
    ''' jdump is used to pretty-print json, returns None
    '''
    d = {"name": "sample", "dict": {"id": "GUID"}, "list": ["string", "string2"]}
    # Test the json.dumps function when passed a simple dict
    assert jdump(d) is None


# Generated at 2022-06-22 18:55:13.536992
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    DocCLI.IGNORE = DocCLI.IGNORE + (context.CLIARGS['type'],)
    doc = copy.deepcopy(plugin_docs[context.CLIARGS['type']]['plugins'][0])
    text = DocCLI.format_plugin_doc(doc, False, False)
    assert isinstance(text, string_types)
    assert text.startswith('> COMMAND')
    assert text.endswith(' SEE ALSO:\n')


# Generated at 2022-06-22 18:55:25.462037
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    """
    Test module documentation generation for roles

    """
    docs = DocCLI()

# Generated at 2022-06-22 18:55:28.076974
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    pass


# Generated at 2022-06-22 18:55:35.055233
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Test for config file not found
    excercise_disk_I_O_errors(False)
    # Test for config file is not a config file
    excercise_disk_I_O_errors(True)

    # Test for no module found
    excercise_network_I_O_errors(False)
    # Test for no plugin found
    excercise_network_I_O_errors(True)


# Generated at 2022-06-22 18:55:47.547770
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-22 18:56:00.069369
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_utils_loader
    from ansible.plugins.loader import modules_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    class MockCLI(object):

        def __init__(self, args=None):
            if args is None:
                args = {}

# Generated at 2022-06-22 18:56:10.876556
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    mock_display = MagicMock()
    mock_context = MagicMock()
    mock_context.CLIARGS = {'type': 'module', 'list': True}
    mock_plugins = ['module_1', 'module_2']
    mock_plugin_list = ['plugin_1', 'plugin_2']
    with patch.multiple(CLI, display=mock_display, context=mock_context):
        CLI.display_plugin_list(plugins=mock_plugins, plugin_list=mock_plugin_list)
        mock_display.display.assert_called_once_with(mock_plugins, mock_plugin_list)



# Generated at 2022-06-22 18:56:12.026628
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():

    object = DocCLI()
    module = object.get_plugin_metadata()
    assert(module == None)


# Generated at 2022-06-22 18:56:13.542787
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    assert add_collection_plugins('plugin_list', 'module')



# Generated at 2022-06-22 18:56:15.961091
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    d = DocCLI()
    d.display_plugin_list('test.test.test', "foobar")


# Generated at 2022-06-22 18:56:24.450148
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    from ansible import constants as C
    # C.DEFAULT_MODULE_PATH = '/path/to/ansible/lib/ansible/modules/'
    cli = DocCLI()
    # Test the raw argument
    results = cli.get_plugin_metadata('setup', raw=True)
    # The result should contain the following keys
    assert '_plugin_type' in results
    assert '_raw_params' in results
    # Test the non-raw argument
    results = cli.get_plugin_metadata('setup')
    # The result should contain the following keys
    assert 'name' in results
    assert 'following items' in results
    # Test non-exist plugin
    results = cli.get_plugin_metadata('fake_plugin')
    # The result should be empty
    assert not results

# Generated at 2022-06-22 18:56:28.174790
# Unit test for function jdump
def test_jdump():
    jdump('{ "a": 1, "b": "1", "c": [1,2,3] }')


# Generated at 2022-06-22 18:56:38.487720
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():

    class MockContext():
        _display = display

    context._setup_context(MockContext())


# Generated at 2022-06-22 18:56:40.090261
# Unit test for constructor of class DocCLI
def test_DocCLI():
    d_obj = DocCLI()
    return d_obj


# Generated at 2022-06-22 18:56:50.245531
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    role_mixin = RoleMixin()

    test_roles_path = ['test/roles']
    role_list = role_mixin._create_role_list(test_roles_path)
    assert isinstance(role_list, dict)
    assert isinstance(role_list, Mapping)

    test_roles_path = ['test/roles']
    test_role_names = ['test_role_name']
    role_doc = role_mixin._create_role_doc(test_role_names, test_roles_path)
    assert isinstance(role_doc, dict)
    assert isinstance(role_doc, Mapping)


# Generated at 2022-06-22 18:56:52.369662
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    
    for i in range(5):
        yield check_DocCLI_get_plugin_metadata, i
        

# Generated at 2022-06-22 18:57:03.976190
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # create DummyDocCLI
    class DummyDocCLI(DocCLI):
        def __init__(self):
            self.tty_ify = lambda x: x

    # create DummyInputArgs
    class DummyInputArgs:
        def __init__(self, type):
            self.type = type
        def tty_ify(self, x):
            return x

    # run test
    c = DummyDocCLI()
    cliargs = DummyInputArgs("module")
    opt_indent = '        '
    text = []
    limit = 80
    DocCLI.add_fields(text, dict(), limit, opt_indent)
    text = DocCLI.get_man_text(doc=dict(), plugin_type="module")

# Generated at 2022-06-22 18:57:13.377016
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = {
        'filename': 'common/foo',
        'docuri': 'uri/foobar',
        'name': 'foobar',
        'module': 'foobar.py',
        'short_description': 'Something very short',
        'description': '''Some must longer description of module foobar.
The following special variables are available: ...'''
    }
    doc = DocCLI.add_man_fields(doc)
    text = DocCLI.get_man_text(doc)
    assert text == '''> FOOBAR    (common/foo)

Some must longer description of module foobar. The following special variables
are available: ...
'''


# Generated at 2022-06-22 18:57:25.540249
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    expected_collections = {'ansible.posix': 'ansible.posix'}
    expected_plugins = {'ansible.posix.group': 'ansible.posix.group', 'ansible.posix.user': 'ansible.posix.user'}

    collection_paths = DocCLI.find_collections(['/etc/ansible/ansible.cfg', '/etc/ansible/roles'])
    plugin_paths = DocCLI.find_plugins(['/etc/ansible/ansible.cfg', '/etc/ansible/roles'])

    assert expected_collections == collection_paths
    assert expected_plugins == plugin_paths

# Generated at 2022-06-22 18:57:37.724318
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # this function returns a namespace (nested dict) with the structure of an Ansible Collection
    # Data is fake and not part of a collection
    # this method is called by _get_plugin_metadata_path
    filename = "/usr/lib/python2.7/site-packages/ansible/plugins/modules/system/date.py"
    nsp = DocCLI.namespace_from_plugin_filepath(filename)
    assert nsp == {
        'ansible': {
            'plugins': {
                'modules': {
                    'system': {
                        'date.py': '.'
                    }
                }
            }
        }
    }
    return


# Generated at 2022-06-22 18:57:49.827090
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # Instance the class to test
    doc = DocCLI()
    # Test cases

# Generated at 2022-06-22 18:58:01.778573
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    snippet = None
    # Test with snippet equals None
    result = DocCLI.format_snippet(snippet)
    assert result is None
    # Test with snippet equals string
    snippet = "this is a snippet"
    result = DocCLI.format_snippet(snippet)
    assert result == "this is a snippet\n"
    # Test with snippet equals list
    snippet = ["this is a snippet","this is a snippet too"]
    result = DocCLI.format_snippet(snippet)
    assert result == "this is a snippet\n\nthis is a snippet too\n\n"
    # Test with snippet equals dict
    snippet = {"key":"value"}
    result = DocCLI.format_snippet(snippet)
    assert result == "key: value\n"


# Generated at 2022-06-22 18:58:14.328902
# Unit test for method namespace_from_plugin_filepath of class DocCLI

# Generated at 2022-06-22 18:58:18.108634
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    from ansible.cli.doc import DocCLI

    # Test with empty argument list
    with pytest.raises(AnsibleOptionsError) as excinfo:
        DocCLI([])
    assert "You must specify the type of documentation you want to display" in str(excinfo.value)



# Generated at 2022-06-22 18:58:22.872336
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    metadata = DocCLI.get_plugin_metadata("./lib/ansible/modules/network/nxos/nxos_l2_interface.py", "./")
    assert 'description' in metadata.keys()


# Generated at 2022-06-22 18:58:26.292044
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    # Just for coverage
    cli = DocCLI()
    args = cli.post_process_args(args, None)
    assert isinstance(args, Namespace)
    assert isinstance(args, object)


# Generated at 2022-06-22 18:58:34.593692
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    result = DocCLI.get_role_man_text({}, {'entry_points': {'main': {'description': [], 'options': {}}}})
    assert result == [
        '> None    (None)\n',
        'ENTRY POINT: main\n',
        '        OPTIONS (= is mandatory):\n',
        '        \n',
    ]
    result = DocCLI.get_role_man_text('role', {'entry_points': {'main': {'description': [], 'options': {}}}})
    assert result == [
        '> ROLE    (None)\n',
        'ENTRY POINT: main\n',
        '        OPTIONS (= is mandatory):\n',
        '        \n',
    ]
    result = DocCLI.get_role_man_

# Generated at 2022-06-22 18:58:42.087059
# Unit test for constructor of class RoleMixin
def test_RoleMixin():

    # Create an instance of an object that uses RoleMixin.
    class RoleMixinTest(RoleMixin):
        """A test class for unit testing the RoleMixin."""

        def __init__(self):
            self.name = 'RoleMixinTest'

    message = 'Create an instance of RoleMixinTest.'
    test_object = RoleMixinTest()
    assert test_object.name == 'RoleMixinTest', message



# Generated at 2022-06-22 18:58:51.945561
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    doc = '''
author:
  - Ansible Core Team
  - Michael DeHaan
description:
  - Start, stop and restart services.
options:
  name:
    description:
      - Name of the service.
    required: true
    type: str
  state:
    choices:
      - started
      - stopped
      - restarted
    default: started
    description:
      - C(started)/C(stopped) are idempotent actions that will not run commands
        unless necessary.  C(restarted) will always bounce the service.
        (use C(state=restarted) to bounce a service if its config or flags
        have changed)
    required: false
    type: str
'''

    doc_json = yaml.safe_load(doc)
    assert isinstance(doc_json, dict)