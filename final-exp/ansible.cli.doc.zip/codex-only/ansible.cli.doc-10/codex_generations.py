

# Generated at 2022-06-22 18:48:50.019203
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    options = dict()
    options['list_dir'] = 'mkdir'
    DocCLI.print_paths(options)


# Generated at 2022-06-22 18:49:00.854279
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    class TestPlaybookExecutorOptions(object):

        class connection(object):  # pylint: disable=C0103
            ansible_connection = 'smart'

    class TestOptions(object):

        class _attribute_class(object):  # pylint: disable=C0103
            foo = "bar"

        inventory = 'hosts'
        connection = TestPlaybookExecutorOptions.connection()

    class TestRunnerCLI(object):

        def get_optparser(self):
            return getattr(self, '_parser', None)

    class TestCLI(object):

        display = display
        options = TestOptions()
        runner_cli = TestRunnerCLI()

    test_cli = TestCLI()

    test_doc = DocCLI(test_cli)

# Generated at 2022-06-22 18:49:11.332326
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('/home/tres/.ansible/plugins/modules/git.py') == 'git'
    assert DocCLI.namespace_from_plugin_filepath('/home/tres/.ansible/plugins/modules/git/__init__.py') == 'git'
    assert DocCLI.namespace_from_plugin_filepath('/home/tres/.ansible/plugins/modules/git.ps1') == 'git'
    assert DocCLI.namespace_from_plugin_filepath('/home/tres/ansible/lib/ansible/modules/windows/win_iis_virtualdirectory.ps1') == 'win_iis_virtualdirectory'

# Generated at 2022-06-22 18:49:25.286495
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-22 18:49:31.294112
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    test_name = 'test_collections.namespace.test_collection.test_plugins.test_test_plugin'
    test_path = os.path.join(os.path.dirname(__file__), 'test_data', 'collections', 'namespace', 'test_collection', 'plugins', 'test_plugin')

    ptype = 'lookup'
    test_list = set()
    test_list.update(DocCLI.find_plugins(test_path, False, ptype))

    assert test_name in test_list



# Generated at 2022-06-22 18:49:33.640184
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    assert DocCLI.find_plugins() == [], 'ansible-doc DocCLI.find_plugins'


# Generated at 2022-06-22 18:49:45.839890
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    """
        Unit test for method get_plugin_metadata of class DocCLI
        """
    parser = CLI.base_parser('')
    args = parser.parse_args([])
    cli_options = DocCLI(args, tty=False)
    module_path = '/Users/tianyating/Documents/Ansible-2.2.2.0-1/lib/ansible/modules/'
    collection_path = '/Users/tianyating/Documents/Ansible-2.2.2.0-1/lib/ansible/galaxy/collection/'
    plugin_name = 'get_url'
    big_plugin_name = 'bigip_selfip'
    collection_name = 'my_collection'
    plugin_name_without_type = 'my_collection.my_role'
   

# Generated at 2022-06-22 18:49:47.781097
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    DocCLI.add_fields(text, dict(), 0, indent ='')
    assert(text == [])


# Generated at 2022-06-22 18:49:54.759521
# Unit test for constructor of class DocCLI
def test_DocCLI():
    tty_ify_test_data = '\x1b[01;32mok=\x1b[0m\r\n\x1b[01;32mchanged=\x1b[0m'
    tty_ify_expected = '\\[01;32mok=\\[0m\\r\\n\\[01;32mchanged=\\[0m'
    tty_ified = DocCLI.tty_ify(tty_ify_test_data)
    assert tty_ified == tty_ify_expected


# Generated at 2022-06-22 18:50:00.605912
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    doc = DocCLI()
    doc.post_process_args({})

    # Test All : True all
    context._init_global_context(args={
        'all':  True
    })
    doc.post_process_args({})
    assert context.CLIARGS['type'] == 'all'



# Generated at 2022-06-22 18:50:04.268752
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    tester = DocCLI()
    args = tester.post_process_args(None)
    assert args.module == '' and args.module_path == '' and args.module_args == '' and args.module_usage == '' and args.module_arg_spec == '' and args.module_options == '' and args.module_extras == '' and args.module_examples == '' and args.listall == '' and args.description == '' and args.search == '' and args.type == '' and args.module_find == '' and args.module_find_value == '' and args.changed_when == '' and args.failed_when == ''

# Generated at 2022-06-22 18:50:08.272022
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    """
    >>> coll_filter = None
    >>> plugin_list = {}
    >>> plugin_type = 'module'
    >>> add_collection_plugins(plugin_list, plugin_type, coll_filter)
    """


# Generated at 2022-06-22 18:50:19.224633
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():

    from ansible.module_utils.common.collections import ImmutableDict

    collection_name = 'dummy_col'
    collection_path = os.path.join(ROOT_DIR, 'test/unit/utils/doc_files/dummy_col')
    file_name = 'dummy.py'
    file_path = os.path.join(collection_path, file_name)

    _parser = DocCLI.get_parser(collection_name, is_collection=True)
    _doc_gen = DocCLI(_parser)
    _doc_gen._is_collection = True
    _doc_gen._collection_name = collection_name
    _doc_gen._collection_path = collection_path
    _doc_gen._files = ImmutableDict()

# Generated at 2022-06-22 18:50:21.009870
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    assert issubclass(PluginNotFound, Exception)



# Generated at 2022-06-22 18:50:27.569834
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = dict(
        all=False,
        collection=False,
        extra_vars=[],
        extra_vars_file=[],
        filter='',
        limit='',
        list_dir=[],
        list_files=False,
        output='',
        pattern='',
        roles_path=[],
        tags='',
        type='',
    )

    with pytest.raises(SystemExit):
        DocCLI(args).run()

# Generated at 2022-06-22 18:50:39.591617
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    # Test with a collection role
    ansible_test_dir = tempfile.mkdtemp(dir=C.DEFAULT_LOCAL_TMP, prefix='ansible_test_rolespec_')
    plugin_dir = os.path.join(ansible_test_dir, 'test_namespace', 'test_collection', 'plugins', 'roles')
    os.makedirs(plugin_dir)
    with open(os.path.join(plugin_dir, 'roleA', 'meta', 'main.yml'), 'w') as f:
        f.write("argument_specs:\n")
        f.write("  main:\n")
        f.write("    short_description: 'Short description'\n")
        f.write("    description: 'Long description'\n")

# Generated at 2022-06-22 18:50:40.805049
# Unit test for function jdump
def test_jdump():
    jdump({'a': 'A'})


# Generated at 2022-06-22 18:50:42.131689
# Unit test for constructor of class DocCLI
def test_DocCLI():
    text = DocCLI()
    assert text.__class__.__name__ == 'DocCLI'


# Generated at 2022-06-22 18:50:49.259804
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    import io
    import sys

    myio = io.StringIO()
    mystd = sys.stdout
    sys.stdout = myio

    class_instance = DocCLI()

    class_instance.add_fields(["a","b","c"],[{"name":["d","e"],"option":"f","type":4,"Default":"g"}],"h","i")
    assert myio.getvalue() == "a\nb\nc\n"

    myio.close()
    sys.stdout = mystd

# Generated at 2022-06-22 18:51:01.077532
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    from ansible.config import defaults
    import tempfile

    mock_plugin_path = os.path.join(defaults._ROOT, 'lib/ansible/plugins/doc_fragments')
    mock_role_path = os.path.join(defaults._ROOT, 'lib/ansible/modules/network/nxos')
    mock_role_path_fake = os.path.join(defaults._ROOT, 'tests/unit/plugins/modules/fake_module')
    # We need to temporarily modify the DISPLAY_SKIPPED_HOSTS setting,
    # otherwise the role path we create will not be found.
    original_setting = defaults.DISPLAY_SKIPPED_HOSTS
    defaults.DISPLAY_SKIPPED_HOSTS = True


# Generated at 2022-06-22 18:51:03.488378
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound
    except PluginNotFound:
        pass



# Generated at 2022-06-22 18:51:09.481226
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    plugin_name = "foo"
    plugin_type = "bar"
    try:
        raise PluginNotFound(plugin_name, plugin_type)
    except PluginNotFound as e:
        assert e.args[0] == plugin_name
        assert e.args[1] == plugin_type
        print('test_PluginNotFound passed')


# Generated at 2022-06-22 18:51:16.341106
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    root = os.path.dirname(__file__)
    #
    # Format a snippet for action plugin
    #
    doc = {
        'filename': 'test/action_plugins/action_test.py',
        'name': 'test',
        'version_added': '2.9',
    }
    expected = '> %s    (%s)\n' % (doc['name'].upper(), doc['filename']) + 'ADDED IN: Ansible v2.9\n'
    assert DocCLI.get_man_text(doc, plugin_type='action') == expected

    #
    # Format a snippet for action plugin with extra param
    #

# Generated at 2022-06-22 18:51:27.131561
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    test_json = {'entry_points': {'main': {'description': 'This is a test role',
                                           'options': {'test_option': {'choices': ['one', 'two'],
                                                                       'description': 'This is a test option'},
                                                       'test_option_two': {'default': 'default',
                                                                           'description': 'This is a test option',
                                                                           'required': False}},
                                           'short_description': 'This is a test role'}},
                 'name': 'test-role',
                 'path': '/tmp',
                 'version': '1.0.0'}

# Generated at 2022-06-22 18:51:32.531297
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    # class under test
    class Test(RoleMixin):
        def __init__(self):
            pass
    # instances
    t = Test()
    # test code
    assert isinstance(t, RoleMixin)


# Generated at 2022-06-22 18:51:41.274395
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    if not hasattr(DocCLI, 'namespace_from_plugin_filepath'):
        raise ImportError("Cannot test module DocCLI as function 'namespace_from_plugin_filepath' is missing")
    test_filepath = "/path/to/my/actionplugin.py"
    test_expected = "my"
    test_result = DocCLI.namespace_from_plugin_filepath(test_filepath)
    if test_result != test_expected:
        raise AssertionError("Expected namespace: %s. Got namespace: %s" % (test_expected, test_result))

# Generated at 2022-06-22 18:51:45.946947
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    role_mixin = RoleMixin()
    role_names = ['foo', 'bar']
    roles_path = ['roles_path1', 'roles_path2']

    listing = role_mixin._create_role_list(roles_path)
    docs = role_mixin._create_role_doc(role_names, roles_path)

    assert listing
    assert docs



# Generated at 2022-06-22 18:51:48.954219
# Unit test for constructor of class DocCLI
def test_DocCLI():
    output = str(DocCLI())
    print("output: " + output)
    assert output == "This is a test"

if __name__ == '__main__':
    test_DocCLI()

# Generated at 2022-06-22 18:52:01.203341
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    r = RoleMixin()

    # test utility methods
    assert r._find_all_normal_roles(('/not-a-dir/',), name_filters=('not-a-role',)) == set()


# Generated at 2022-06-22 18:52:01.895828
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    doc_cli = DocCLI()
    assert True

# Generated at 2022-06-22 18:52:04.273988
# Unit test for function jdump
def test_jdump():
    try:
        data = {"keyword": {"subkeyword": "value"}}
        jdump(data)
    except Exception:
        raise AssertionError



# Generated at 2022-06-22 18:52:10.694480
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    class DocCLI():
        @staticmethod
        def tty_ify(data):
            return data

        @staticmethod
        def _dump_yaml(data, opt_indent):
            return ''

        @staticmethod
        def _format_version_added(version_added, version_added_collection):
            return '0.0'


# Generated at 2022-06-22 18:52:13.661048
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = dict(filename='/path/to/module.py', description='some test', foo='bar')
    assert DocCLI.format_plugin_doc('name', doc, 'plugin_type') == "> NAME    (/path/to/module.py)\n\nsome test\n\nFOO: bar\n"


# Generated at 2022-06-22 18:52:16.740335
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    cli.test_args = ['ansible-doc', '-M', './test/units/modules/test_plugin_docs.py', '-l']
    cli.post_process_args()
    assert cli.args.listt


# Generated at 2022-06-22 18:52:22.271363
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.utils.display import Display
    from ansible.plugins.loader import find_plugin_files
    import os
    import sys
    import stat

    tty_mode = True if os.isatty(sys.stdout.fileno()) else False
    display = Display(verbosity=1, log_only=False, color=None, tty_only=tty_mode)
    # my fake plugin path
    plugin_path = os.path.join(os.path.dirname(__file__), 'plugins', 'doc_files')
    # get plugin docs paths
    plugin_files = find_plugin_files(plugin_path)
    docs = DocCLI.format_plugin_doc(plugin_files, display)
    assert(len(docs) == 1)

# Generated at 2022-06-22 18:52:34.147827
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    expected_result = '''
> APACHE2_MODULE    (/path/to/ansible/lib/ansible/modules/extras/web_infrastructure/apache2_module.py)
Manage Apache2 modules. Note that some modules need to be enabled in the apache2.conf configuration file as well.

OPTIONS (= is mandatory):

        name: Name of the module.
                * This is a required option.

        state: Whether the module should be present or absent.

                * [Default: present]

                * present
                * absent
        use: Whether the module should be enabled or disabled.

                * [Default: enabled]

                * enabled
                * disabled
    '''
    #https://github.com/ansible/ansible/blob/devel/lib/ansible/modules/extras/web_infrastructure/

# Generated at 2022-06-22 18:52:44.929737
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    from ansible.cli.help import DocCLI
    from collections import OrderedDict
    opt = OrderedDict()
    opt['test'] = {'aliases':  ['alias', 'ali'],
                   'choices': ['choice1', 'choice2'],
                   'default': 'default value',
                   'description': 'Test Description'}
    text = []
    limit = 20
    opt_indent = "        "
    return_values = False
    DocCLI.add_fields(text, opt, limit, opt_indent, return_values)

# Generated at 2022-06-22 18:52:50.260441
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():

    cli = DocCLI()
    parser = cli.init_parser()

    assert parser.prog == 'ansible-doc'
    assert parser.description == 'shows documentation for Ansible modules, plugins and playbooks'

    action = parser.add_argument('module', help='the module/plugin/action/playbook to show the documentation for')
    assert action.help == 'the module/plugin/action/playbook to show the documentation for'


# Generated at 2022-06-22 18:52:51.290551
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    rm = RoleMixin()
    assert rm is not None


# Generated at 2022-06-22 18:52:56.172243
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    assert DocCLI.display_plugin_list(context.CLIARGS) is None
    assert DocCLI.display_plugin_list(context.CLIARGS) is None


# Generated at 2022-06-22 18:53:04.227347
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    from ansible.utils.unicode import to_str
    from ansible.utils.display import Display
    display = Display()

    doccli = DocCLI([])
    text = []
    limit = 80
    opt_indent = "        "
    snippet = """<Connection ref="localhost">
  <Actions>
    <Action id="1" ref="foo">
    </Action>
  </Actions>
</Connection>"""
    text.append(textwrap.fill(DocCLI.tty_ify(snippet), limit,
                              initial_indent=opt_indent, subsequent_indent=opt_indent))

    assert to_str(doccli.get_man_text({"snippet": snippet}, 'snippet')) == text



# Generated at 2022-06-22 18:53:11.626548
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath("/home/user/.ansible/collection/parent.child/module_plugins/module_utils/module_a.py") == "module_utils"
    assert DocCLI.namespace_from_plugin_filepath("/home/user/my/plugins/module_utils/module_a.py") == "module_utils"
    assert DocCLI.namespace_from_plugin_filepath("/home/user/.ansible/plugins/callback/module_a.py") == "callback"

# Generated at 2022-06-22 18:53:21.892766
# Unit test for method run of class DocCLI

# Generated at 2022-06-22 18:53:24.957617
# Unit test for constructor of class DocCLI
def test_DocCLI():
    cli = DocCLI()

    assert cli is not None, "Unable to create instance of class DocCLI"


# Generated at 2022-06-22 18:53:34.708916
# Unit test for method namespace_from_plugin_filepath of class DocCLI

# Generated at 2022-06-22 18:53:36.722106
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    assert DocCLI().post_process_args(['module']) == ['module']

# Generated at 2022-06-22 18:53:49.238435
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    '''Unit test for method format_snippet of class DocCLI'''

    test_snippet = "This is  a test   snippet."
    snippet_text = DocCLI.format_snippet('text', test_snippet)
    expected =  '\n'.join([
        '.. code-block:: text',
        '',
        '  This is a test snippet.',
        '',
    ])
    assert snippet_text == expected

    snippet_json = DocCLI.format_snippet('json', test_snippet)
    expected =  '\n'.join([
        '.. code-block:: json',
        '',
        '    \"This is a test snippet.\"',
        '',
    ])
    assert snippet_json == expected


# Generated at 2022-06-22 18:53:58.305672
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    import tempfile

    plugin_type = 'action'
    path = [tempfile.mkdtemp()]

    # We need a valid plugin to test
    filename = os.path.join(path[0], 'foo.py')
    fd, fcntl = None, None

# Generated at 2022-06-22 18:54:10.622750
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    import json
    from ansible.module_utils._text import to_bytes

    # /Users/abu/PycharmProjects/ansible/cover/ansible/cli/doc.py:731 -- 1

# Generated at 2022-06-22 18:54:23.567940
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    plugin_type = 'module'
    plugin_name = 'setup'
    doc = dict()
    doc['filename'] = '/home/travis/build/ansible/ansible/lib/ansible/modules/system/setup.py'
    doc['description'] = ['Gathers facts about remote hosts']
    doc['options'] = dict()
    doc['options']['f'] = dict()
    doc['options']['f']['description'] = ['Option description']
    doc['options']['f']['short_description'] = [
        'Specify a list of comma-separated facts to collect\n'
        'or "all" to collect all facts.'
    ]

# Generated at 2022-06-22 18:54:29.577788
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # DocCLI.get_all_plugins_of_type(self, plugin_type)
    # Be sure that the plugin type you want to look for is passed as an argument.
    # If no argument is passed, then it should return an empty dictionary.
    assert DocCLI.get_all_plugins_of_type({}) == {}


# Generated at 2022-06-22 18:54:42.002692
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI._namespace_from_plugin_filepath('/tmp/AnsibleActions/lib/ansible/plugins/action/module.py') == 'plugins.action'
    assert DocCLI._namespace_from_plugin_filepath('/tmp/AnsibleActions/lib/ansible/plugins/module_utils/module.py') == 'plugins.module_utils'
    assert DocCLI._namespace_from_plugin_filepath('/tmp/AnsibleActions/lib/ansible/plugins/module/module.py') == 'plugins.modules'
    assert DocCLI._namespace_from_plugin_filepath('/tmp/AnsibleActions/lib/ansible/module_utils/module.py') == 'module_utils'
    assert DocCLI._namespace_from_plugin_filepath

# Generated at 2022-06-22 18:54:53.642770
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    mock_cli = get_mock_CLI()
    doc = DocCLI(mock_cli)
    sample_mock_loader_dict = {'action': ['mock_action.py', 'mock_action2.py'], 'cache': ['mock_cache.py'], 'callback': ['mock_callback.py'], 'connection': ['mock_connection.py']}
    mock_loader = get_mock_loader(sample_mock_loader_dict)
    doc._get_loader(mock_cli)
    doc.loader = mock_loader
    modules, plugins, docs = doc.get_all_plugins_of_type()
    assert modules == ['mock_action2.py', 'mock_action.py']

# Generated at 2022-06-22 18:55:07.706263
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = dict()
    args['module_name'] = None
    args['module_path'] = None
    args['module_args'] = None
    args['subthing'] = None
    args['type'] = None
    args['output_format'] = 'json'
    args['forcecolor'] = False
    args['colorize_errors'] = True
    args['output_dir'] = None
    args['output_file'] = None
    args['verbosity'] = 0
    args['no_log'] = False
    args['no_log_params'] = False
    args['inventory'] = None
    args['listhosts'] = 'listhosts' in C.CLI_OPTIONS
    args['subset'] = None

# Generated at 2022-06-22 18:55:12.102624
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # Test function with a single type of argument
    # Bug found during Travis test:
    #   https://travis-ci.org/ansible/ansible/jobs/73956020
    actual_ansi_text = DocCLI.format_snippet(
        ANSI_TOKENS,
        DocCLI.SnippetArgumentFormat.ANSIBLE_COMPLETE
    )
    assert ANSI_TOKENS_COMPLETE_TEST_OUTPUT == actual_ansi_text

# Generated at 2022-06-22 18:55:18.688557
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    opt_indent = "        "
    text = []
    limit = max(display.columns - int(display.columns * 0.20), 70)
    success = True
    try:
        DocCLI.add_fields(text, {"opt1": "val1", "opt2": "val2"}, limit, opt_indent, return_values=True)
    except:
        success = False
    finally:
        assert success

# Generated at 2022-06-22 18:55:24.385466
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    c = DocCLI()
    c.setup()
    data = c.get_all_plugins_of_type()
    plugins = ['become_plugin', 'callback_plugin', 'cache_plugin', 'cliconf_plugin', 'doc_fragments', 'inventory_plugin', 'lookup_plugin', 'module_utils', 'netconf_plugin', 'shell_plugin', 'terminal_plugin', 'vars_plugin']
    assert sorted(data.keys()) == plugins



# Generated at 2022-06-22 18:55:28.138477
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Create a test object of DocCLI
    test_obj = DocCLI()

    # Try to get all plugins of type 'module'
    assert_equal(type(test_obj.get_all_plugins_of_type('module')), type({}))


# Generated at 2022-06-22 18:55:29.927926
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    ANSIBLE_DOCTEST = [
        'foo'
    ]
    raise PluginNotFound(ANSIBLE_DOCTEST)


# Generated at 2022-06-22 18:55:32.196232
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
  x = DocCLI()
  assert x.print_paths() == None

# Generated at 2022-06-22 18:55:45.445165
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    self = DocCLI()
    role = 'role'
    role_json = {
        'entry_points': {
            'main': {
                'description': 'some description',
                'options': {
                    'some_option': {
                        'description': 'option description',
                        'required': True
                    }
                },
                'attributes': {
                    'some_attribute': {
                        'description': 'atribute description',
                        'required': True
                    }
                }
            }
        },
        'path': 'test/path'
    }
    result = self.get_role_man_text(role, role_json)
    assert len(result) == 6

# Generated at 2022-06-22 18:55:59.138085
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():

    def __create_doc(doc):
        return [doc] if isinstance(doc, string_types) else doc

    assert DocCLI.format_snippet('module', 'see_also') == 'module: see_also'
    assert DocCLI.format_snippet('module: see_also') == 'module: see_also'
    assert DocCLI.format_snippet('aliases', '-a') == 'aliases: -a'
    assert DocCLI.format_snippet('aliases', ['-a', '-b']) == 'aliases: -a -b'
    assert DocCLI.format_snippet('required', True) == 'required: True'

# Generated at 2022-06-22 18:56:09.614284
# Unit test for constructor of class DocCLI
def test_DocCLI():
    '''Unit test for constructor of class DocCLI'''

    doccli = DocCLI()
    assert isinstance(doccli, object)
    # Should not have the DEFAULT_MODULE_PATH set
    assert not hasattr(doccli, 'DEFAULT_MODULE_PATH')

    doccli = DocCLI(None, '/tmp')
    assert isinstance(doccli, object)
    # Should have the DEFAULT_MODULE_PATH set
    assert hasattr(doccli, 'DEFAULT_MODULE_PATH') and doccli.DEFAULT_MODULE_PATH is '/tmp'


# Generated at 2022-06-22 18:56:11.739507
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc_obj = DocCLI()
    doc_obj.find_plugins()


# Generated at 2022-06-22 18:56:21.796734
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    '''test_DocCLI_find_plugins is a unit test for the method DocCLI.find_plugins()
    It will run DocCLI.find_plugins() with a variety of parameters and check the
    output against a number of test cases, ultimately ensuring it functions as
    expected.
    '''

    def run_test(**kwargs):
        '''run_test is a helper function to run a test with a given set of parameters
        and ensure the output is what we expect.
        '''
        # Save the current command line arguments
        old_args = dict(context.CLIARGS)

# Generated at 2022-06-22 18:56:24.175006
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    cli = DocCLI()
    cli.cliargs = dict(
        type='action_plugin',
    )
    plugins = cli.get_all_plugins_of_type()
    assert len(plugins) > 1

# Generated at 2022-06-22 18:56:36.749938
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    class TestRoleMixin(RoleMixin):
        pass
    test_role_paths = ("/path/to/roles",)
    role_mixin = TestRoleMixin()
    role_list = role_mixin._create_role_list(test_role_paths)
    assert isinstance(role_list, dict)
    assert isinstance(role_list.keys()[0], str)
    assert isinstance(role_list.values()[0], dict)

    assert len(role_list.keys()[0].split('.')) == 1 or len(role_list.keys()[0].split('.')) == 3
    assert isinstance(role_list.values()[0]['collection'], str)

# Generated at 2022-06-22 18:56:39.713084
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Instantiate args
    args = DocCLIArgs()
    # Instantiate DocCLI
    doc = DocCLI(args)
    # Call method run
    doc.run()

# Generated at 2022-06-22 18:56:50.245520
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Initialize empty list for text
    text = []
    # Initialize data object
    data = {'options': {'key1': {'default': 'null',
                                 'choices': ['hard', 'soft'],
                                 'type': 'choice',
                                 'desc': 'Specifies the type of refresh'}}}
    # Initialize opt_indent
    opt_indent = "        "
    # Call method
    DocCLI.add_fields(text, data, limit=70, opt_indent=opt_indent)
    # Call method
    assert text == ['        key1 (string): Specifies the type of refresh\n                 [Default: null]\n                 Choices: hard, soft']

# Generated at 2022-06-22 18:56:51.906439
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    assert 6 == len(C.COLLECTION_PTYPE_COMPAT)



# Generated at 2022-06-22 18:56:54.198481
# Unit test for constructor of class DocCLI
def test_DocCLI():
    dc = DocCLI()
    assert isinstance(dc, DocCLI)


# Generated at 2022-06-22 18:57:05.566969
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Create DocCLI object so we can test static method get_man_text
    DocCLI = DocCLI()
    patch = mock.patch('ansible.cli.doc.get_versioned_doclink')
    mock_get_versioned_doclink = patch.start()
    mock_get_versioned_doclink.return_value = 'https://docs.ansible.com/ansible/2.9/modules/module_name.html'


# Generated at 2022-06-22 18:57:09.208857
# Unit test for constructor of class DocCLI
def test_DocCLI():
    cli = DocCLI()
    assert cli._plugin_type == 'modules'
    assert cli.filter_plugins == DocCLI.filter_plugins



# Generated at 2022-06-22 18:57:12.177743
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    '''Test to ensure that we can get a list of all plugins of a given type.'''
    output = DocCLI.get_all_plugins_of_type('module')
    assert len(output) > 0


# Generated at 2022-06-22 18:57:25.146723
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # TODO: Although this is a unit test, it can be a functional test in the future.
    role = Role()
    role.module = 'docker_service'
    role.shell = 'powershell'
    cmd = DocCLI(obj={}, next_action=role)

# Generated at 2022-06-22 18:57:30.257535
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    doc = DocCLI()
    x = doc.print_paths(['a', 'b', 'c'])
    assert x == "a, b, c"


# Generated at 2022-06-22 18:57:40.590206
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    import os
    import shutil
    import json
    from ansible.module_utils._text import to_bytes, to_text

    plugin_root = u'/tmp/test_find_plugins'
    config_root = os.path.join(plugin_root, 'config')
    collections_config_root = os.path.join(plugin_root, 'config', 'collections')
    collections_loader_root = os.path.join(plugin_root, 'lib', 'ansible', 'collections', 'ansible_collections')
    core_lib_plugins_root = os.path.join(plugin_root, 'lib', 'ansible', 'plugins')
    core_module_utils_root = os.path.join(plugin_root, 'lib', 'ansible', 'module_utils')


# Generated at 2022-06-22 18:57:45.661207
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    cli = DocCLI(args=['ansible-doc', '-M', 'test/units/modules', '-t', 'module', 'ping'])
    cli.parser = cli.create_parser()
    cli.run()


# Generated at 2022-06-22 18:57:52.455960
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    r_test = {'test_name': 'fake_plugin_name', 'test_type': 'connection', 'test_path': 'some_fake_path'}
    assert r_test == DocCLI.get_plugin_metadata('some_fake_path/fake_plugin_name.py', 'connection')
    assert r_test == DocCLI.get_plugin_metadata('some_fake_path/fake_plugin_name', 'connection')


# Generated at 2022-06-22 18:57:55.495549
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound('Not found')
    except PluginNotFound as error:
        assert error.args[0] == 'Not found'



# Generated at 2022-06-22 18:58:05.682008
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
  # Try to load ansible.cfg
  ansible_cfg_path = os.path.expanduser(os.path.join('~', '.ansible.cfg'))
  # Prompt
  if os.path.isfile(ansible_cfg_path):
    ansible_cfg = ConfigParser.ConfigParser()
    ansible_cfg.read(ansible_cfg_path)
    config = dict(ansible_cfg.items('defaults'))
  else:
    config = {}

  parser = argparse.ArgumentParser(description='Generates Ansible module documentation in JSON, Markdown, or plaintext.', formatter_class=argparse.RawDescriptionHelpFormatter)

# Generated at 2022-06-22 18:58:08.801650
# Unit test for constructor of class RoleMixin
def test_RoleMixin():

    class TestRoleMixin(RoleMixin):
        """See http://stackoverflow.com/a/68496"""
        pass

    r = TestRoleMixin()



# Generated at 2022-06-22 18:58:15.399043
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # test for the case where plugin_list is None and a list
    # test for the case where plugin_list is None and not a list
    # test for the case where plugin_list is a list
    # test for the case where plugin_list is not a list
    raise NotImplementedError


# Generated at 2022-06-22 18:58:25.137064
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    doc = DocCLI()
    res = doc.format_snippet("#!/usr/bin/python", os.path.join(os.path.expanduser("~"), "foo"), "#!/usr/bin/python")
    assert res == "#!/usr/bin/python"
    res = doc.format_snippet("#!/usr/bin/python", os.path.join(os.path.expanduser("~"), "foo"), "#!/usr/bin/python", "#!/usr/bin/python")
    assert res == "#!/usr/bin/python"


# Generated at 2022-06-22 18:58:28.021233
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    assert os.path.isdir('docs/docsite/api/') == True
    assert os.path.isfile('docs/docsite/api/includes/text.json') == True


# Generated at 2022-06-22 18:58:30.734618
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    rm = RoleMixin()
    assert_equal(rm._ROLE_ARGSPEC_FILES, ['argument_specs.yml', 'argument_specs.yaml', 'main.yml', 'main.yaml'])


# Generated at 2022-06-22 18:58:37.818900
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    doc_cli = DocCLI()
    assert doc_cli.post_process_args(['-v']) == (0, None)
    assert doc_cli.post_process_args(['-c', 'ansible/config', '-T', 'yaml']) == (0, None)
    assert doc_cli.post_process_args(['-c', 'ansible/config', '-T', 'json']) == (0, None)
    assert doc_cli.post_process_args(['-c', 'ansible/config', '-T', 'markdown']) == (0, None)
    assert doc_cli.post_process_args(['-c', 'ansible/config', '-T', 'rst']) == (0, None)

# Generated at 2022-06-22 18:58:45.347423
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = max(display.columns - int(10), 70)
    c = dict(type='common',
             description="Test for DocCLI",
             bydefault=True,
             version_added="1.2.3.4")
    DocCLI.add_fields(text, c, limit, opt_indent)
    assert text == ["        BYDEFAULT: True", "        DESCRIPTION: Test for DocCLI", "        VERSION-ADDED: 1.2.3.4"]


# Generated at 2022-06-22 18:58:53.554130
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
	assert DocCLI.namespace_from_plugin_filepath('/Users/roopasreed/ansible/lib/ansible/modules/notification/hipchat.py') == 'notification'
	assert DocCLI.namespace_from_plugin_filepath('/Users/roopasreed/ansible/lib/ansible/modules/notification/') == 'notification'
	assert DocCLI.namespace_from_plugin_filepath('/Users/roopasreed/ansible/lib/ansible/modules/notification') == 'notification'
	assert DocCLI.namespace_from_plugin_filepath('/Users/roopasreed/ansible/lib/ansible/modules/notification/__init__.py') == 'notification'
	assert DocCLI.namespace_from_plugin_filepath