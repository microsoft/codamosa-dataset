

# Generated at 2022-06-22 18:48:54.216420
# Unit test for function jdump
def test_jdump():
    # Test that jdump can convert a string into JSON
    assert jdump('test') == '"test"'
    # Test that jdump can convert a dict into JSON
    assert jdump({'test':'test'}) == '{\n    "test": "test"\n}'
    # Test that jdump can convert a list into JSON
    assert jdump(['test','test2']) == '[\n    "test", \n    "test2"\n]'
    # Test that jdump can convert a integer into JSON
    assert jdump(1) == '1'
    # Test that jdump can convert a boolean into JSON
    assert jdump(True) == 'true'
    # Test that jdump can convert a AnsibleModule into JSON

# Generated at 2022-06-22 18:48:57.232299
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    cmdline = DocCLI()
    parser = cmdline.init_parser()
    assert parser is not None


# Generated at 2022-06-22 18:49:02.135685
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    '''
    DocCLI - run
    '''
    # initialize
    DocCLIObj = DocCLI()
    # DocCLI needs a subcommand to run, so argv needs a subcommand
    argv = ["program", "subcommand"]
    with pytest.raises(AnsibleOptionsError) as excinfo:
        # Execute the run function
        DocCLIObj.run(argv)

    # DocCLI needs a module name to run with --help option, so argv needs a module name and --help
    argv = ["program", "module", "--help"]
    # Execute the run function
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        DocCLIObj.run(argv)
    assert pytest_wrapped_e.type == SystemExit


# Generated at 2022-06-22 18:49:11.433036
# Unit test for function jdump
def test_jdump():
    '''
    Test the jdump function
    '''
    test_data = {
        "help": "Displays a list of all the hosts in the inventory that match a given pattern.",
        "options": {
            "pattern": {
                "type": "string",
                "required": True,
            },
            "flat": {
                "type": "boolean",
                "default": False,
            },
            "variables": {
                "type": "dict",
                "required": False,
            },
        }
    }
    if json.loads(jdump(test_data)) != test_data:
        return False
    return True



# Generated at 2022-06-22 18:49:20.892588
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    TEST_DIRS = os.path.join(sys._MEIPASS, 'clilib')
    for name, cls in get_all_plugin_loaders().items():
        if DocCLI.SUPPORTED_PLUGINS and name not in DocCLI.SUPPORTED_PLUGINS:
            continue

        docs = DocCLI.find_plugins(TEST_DIRS, name)
        assert len(docs) > 10
        assert docs[0]['plugin_type'] == name

# Generated at 2022-06-22 18:49:28.725679
# Unit test for function jdump
def test_jdump():
    obj = {
        'a' : 'b',
        'c' : 1337,
        'd' : ['foo', 'bar'],
        'e' : ['foo', 'bar', 1337],
        'f' : {
            'g' : 'h',
            'i' : 'j',
        },
    }

    dumper = AnsibleJSONEncoder()
    assert dumper.encode(obj) == json.dumps(obj, sort_keys=True, indent=4)



# Generated at 2022-06-22 18:49:35.601594
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    assert type(RoleMixin())

# unit test for find_plugins() - needs more work
#def test_find_plugins():
#    DocCLI._clear(None, 'test')
#    plugins = DocCLI.find_plugins('/Users/alikins/src/ansible/lib/ansible/plugins')
#    assert plugins['module']['copy']
#    assert plugins['module']['copy']['ANSIBLE_MODULE_ARGS']


# Generated at 2022-06-22 18:49:36.692932
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    # Need to add unit test
    return



# Generated at 2022-06-22 18:49:49.010730
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    """
    Test function DocCLI.find_plugins
    """

    from ansible.plugins.loader import all as plugin_loader
    from ansible.module_utils import basic
    import types
    import os

    test_invocation = lambda: {
        'module_name': 'test_module',
        'module_args': '',
        'module_vars': {},
    }

    plugin_loader.add(test_invocation(), 'test_module', os.path.join(os.path.dirname(basic.__file__), 'test_utils.py'), False, False, False)
    plugin_loader.add(test_invocation(), 'test_module', os.path.join(os.path.dirname(basic.__file__), 'test_utils.py'), False, False, False)

    plugins = Doc

# Generated at 2022-06-22 18:49:54.078206
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    dc = DocCLI(None)
    assert dc.find_plugins('vars') == dict(
        _load_plugins(
            os.path.dirname(ansible.modules.action.__file__),
            '_vars',
            package='ansible.modules.action',
            require_init=False
        )
    )


# Generated at 2022-06-22 18:49:59.802643
# Unit test for constructor of class DocCLI
def test_DocCLI():
    # Create the instance of DocCLI
    doc = DocCLI()

    # Check the attributes of class object
    assert doc.skip == ('author',)

    # Check the methods of class object
    assert doc.create_plugin_doc_text('', '').startswith('> MODULE DOCUMENTATION')

# Generated at 2022-06-22 18:50:02.669546
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    result = add_collection_plugins(plugin_list=[], plugin_type='action', coll_filter='ansible.builtin')
    assert result is not None, 'Test not implemented'



# Generated at 2022-06-22 18:50:07.813971
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    cli = DocCLI()
    doc = cli.init_parser()
    assert doc._subcommands['listplugins'].func == cli.list_plugins
    assert doc.format_help().startswith('usage:')


# Generated at 2022-06-22 18:50:16.735443
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # The test object
    test_obj = cli.create_cli_inner([])
    # Test print_paths
    args = cli.parse([])
    test_obj.parse(args)
    test_obj.print_paths()

    # Test print_paths with unknown arg
    args = cli.parse(['--unknown'])
    test_obj.parse(args)
    with pytest.raises(cli.AnsibleOptionsError):
        test_obj.print_paths()


# Generated at 2022-06-22 18:50:20.240025
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    assert isinstance(DocCLI.find_plugins()[0], tuple)
    assert isinstance(DocCLI.find_plugins()[0][1], tuple)

# Generated at 2022-06-22 18:50:31.126452
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    class Object:
        def __init__(self, _doc):
            self._doc = _doc

    doc = {
        'version_added': '2.7',
        'aliases': ['tasks'],
        'description': ["A list of Ansible tasks to be executed against the remote hosts.",
                        "This parameter is required and must be specified as a list."],
        'options': {
            'name': {
                'description': "The name of the task.",
                'required': True,
                'aliases': ['task']
            },
            'foo': {
                'description': "The name of the task.",
                'required': True,
                'aliases': ['task']
            }
        }
    }
    doc_obj = Object(doc)

    text = []

# Generated at 2022-06-22 18:50:40.746160
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Modify context.CLIARGS to set 'type' to 'module'
    context.CLIARGS = {'type': 'module'}
    # Modify Display.columns to get useful output
    display.Display.columns = 80
    # Create DocCLI object
    dc = DocCLI()
    # Instantiate empty module_list
    module_list = []
    # Call get_all_plugins_of_type
    dc.get_all_plugins_of_type(module_list)
    assert len(module_list) == 0



# Generated at 2022-06-22 18:50:42.860438
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    obj = DocCLI()
    result = obj.print_paths()
    assert result is None

# Generated at 2022-06-22 18:50:44.906755
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    assert DocCLI.add_fields(text, doc.pop('options')) == "None"

# Generated at 2022-06-22 18:50:47.633272
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
  doc={'name': 'current_user', 'options': {'name': {'type': 'str'}}, 'short_description': 'returns the current user'}
  assert (str(type(DocCLI.get_man_text(doc)))=="<class 'str'>")


# Generated at 2022-06-22 18:50:56.494491
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    instance = DocCLI()
    instance.tty_ify = lambda text: text
    text1 = []
    text2 = []
    DocCLI.add_fields(text1, {'key1': 'value1'}, 100, ' ')
    DocCLI.add_fields(text2, {'key1': 'value1'}, 80, ' ')
    assert text1 == ['key1: value1']
    assert text2 == ['    key1: value1']
    text1 = []
    text2 = []
    DocCLI.add_fields(text1, {'key1': 'value1', 'key2': 'value2'}, 100, ' ')
    DocCLI.add_fields(text2, {'key1': 'value1', 'key2': 'value2'}, 80, ' ')


# Generated at 2022-06-22 18:51:00.894626
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    class TestRoleMixin(RoleMixin):
        def __init__(self):
            super(TestRoleMixin, self).__init__()

    obj = TestRoleMixin()



# Generated at 2022-06-22 18:51:13.771690
# Unit test for function add_collection_plugins
def test_add_collection_plugins():

    plugin_list = {}
    add_collection_plugins(plugin_list, 'action')
    assert 'ping' in plugin_list
    assert plugin_list['ping'].get('collection', None) is not None
    assert plugin_list['ping'].get('path', None) is not None

    plugin_list = {}
    add_collection_plugins(plugin_list, 'connection')
    assert 'winrm' in plugin_list
    assert plugin_list['winrm'].get('collection', None) is not None
    assert plugin_list['winrm'].get('path', None) is not None

    plugin_list = {}
    add_collection_plugins(plugin_list, 'vars')
    assert 'group_vars' in plugin_list

# Generated at 2022-06-22 18:51:26.062778
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    import sys
    import json
    from ansible.module_utils._text import to_bytes

    # eliminate display
    display = None

    # save arguments
    sys_argv = sys.argv
    sys_stdin = sys.stdin

    # eliminate side effect of argument parsing
    sys.stdout = open(os.devnull, 'w')

    # argument parsing must still work
    # for module name we simply use os
    # for no other reason than it is a valid module that is distributed with Python.
    testargs = ["ansible-doc", "os"]

# Generated at 2022-06-22 18:51:39.127280
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    expected_output = {'plugins': {'action': {'acme.foo': 'acme/foo/test.py'},
                                   'connection': {'acme.bar': 'acme/bar/test.py'}}}
    expected_output_json = json.dumps(expected_output, indent=4)
    mocked_coll_dir = 'acme/test/test.tar.gz'
    coll_filter = 'acme.test'
    with context.CLIARGS as cli_args:
        cli_args['collections'] = [coll_filter]
        plugin_list = {}
        add_collection_plugins(plugin_list, "action")
        cli_args['collections'] = []
        add_collection_plugins(plugin_list, "connection")

# Generated at 2022-06-22 18:51:51.897918
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():

    # This is an example extracted from a module
    test_str = '''
    required: true
    default: null
    choices:
      - http
      - https
      - ssh
      - snmp
      - agent
    ini:
      - key: username
        section: defaults
    env:
      - name: ANSIBLE_NET_USERNAME
    type: str
    version_added: "1.9"
    '''

    expected = '''
    required: true
    default: null
    choices:
      - http
      - https
      - ssh
      - snmp
      - agent
    set_via:
      ini:
        - name: username
          section: defaults
      env:
        - name: ANSIBLE_NET_USERNAME
    type: str
    '''

    # Get

# Generated at 2022-06-22 18:52:02.943202
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    # Test for DocCLI().post_process_args()
    args = DocCLI().post_process_args(Mock())
    assert args is not None
    # Test for DocCLI().post_process_args()
    args = DocCLI().post_process_args(Mock(module=1))
    assert args is not None
    # Test for DocCLI().post_process_args()
    args = DocCLI().post_process_args(Mock(module=1, module_type='module'))
    assert args is not None
    # Test for DocCLI().post_process_args()
    args = DocCLI().post_process_args(Mock(module=1, module_type='module', show_snippet=True, join_snippet=True))
    assert args is not None
    #

# Generated at 2022-06-22 18:52:11.109300
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():

    # Create an instance of the DocCLI class
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=[], display=display)



    # Try with a combination of options
    cli.base_parser.add_argument('-m', '--module', dest='module', help='show documentation on a module')
    cli.base_parser.add_argument('-a', '--action', dest='action', help='show documentation on an action plugin')
    cli.base_parser.add_argument('-v', '--verbose', dest='verbose', action='store_true', default=CLI.verbosity, help='show all documentation except action plugins')

# Generated at 2022-06-22 18:52:47.419321
# Unit test for method get_plugin_metadata of class DocCLI

# Generated at 2022-06-22 18:52:49.983113
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    assert callable(DocCLI.get_role_man_text)



# Generated at 2022-06-22 18:53:00.797706
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():

    # DocCLI.namespace_from_plugin_filepath with args and keyword args
    kwargs = {
        'plugin_filepath': 'ansible/plugins/action/setup.py',
    }
    if 'plugins/action' != DocCLI.namespace_from_plugin_filepath(**kwargs):
        raise AssertionError("DocCLI.namespace_from_plugin_filepath() did not return expected value for given kwargs")

    # DocCLI.namespace_from_plugin_filepath with args and keyword args
    kwargs = {
        'plugin_filepath': 'ansible/plugins/login/docker_machine.py',
    }

# Generated at 2022-06-22 18:53:06.542905
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    n = DocCLI.namespace_from_plugin_filepath("/path/to/my_collection/my_collection/module_utils/module_utils_module1.py")
    assert n == "my_collection.module_utils.module_utils_module1"


# Generated at 2022-06-22 18:53:15.547745
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # When argument description is present
    description = "description"
    plugin_name = "plugin_name"

    plugin_doc = {
        'description': description,
        'name': plugin_name
    }

    assert DocCLI.format_plugin_doc(plugin_doc).split('\n')[0] == "> %s" % plugin_name.upper()

    # When argument description is not present
    plugin_doc = {
        'name': plugin_name
    }

    assert DocCLI.format_plugin_doc(plugin_doc).split('\n')[0] == "> %s" % plugin_name.upper()

# Generated at 2022-06-22 18:53:18.887491
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    doc = DocCLI()
    doc.init_parser()
    assert doc.parser._optionals.title == 'Options'
    assert doc.parser._positionals.title == 'Parameters'


# Generated at 2022-06-22 18:53:31.420089
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    kwargs = {}
    kwargs['plugin'] = 'ping'
    kwargs['versioned'] = False
    kwargs['versioned_formats'] = ['rst', 'yaml', 'json']
    kwargs['output_format'] = 'rst'
    kwargs['force'] = False
    kwargs['collection_name'] = None
    kwargs['collection_list'] = None
    kwargs['role_name'] = None
    kwargs['role_path'] = None
    kwargs['roles_path'] = None
    tempdir = tempfile.mkdtemp()
    prefix = os.path.join(tempdir, 'test_DocCLI_format_plugin_doc-')
    paths = context.CLIARGS['paths']
    context.CLIAR

# Generated at 2022-06-22 18:53:32.836944
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    DocCLI.init_parser()



# Generated at 2022-06-22 18:53:41.288068
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    from ansible.utils.plugin_docs import read_docstub
    from ansible.plugins import doc_fragments

    mod_path = doc_fragments.get_docstub_path('localhost', 'get_url')
    if mod_path:
        mod_doc = read_docstub(mod_path)
        doc_text = DocCLI.get_man_text(mod_doc)
        assert isinstance(doc_text, string_types)



# Generated at 2022-06-22 18:53:44.023688
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    c = DocCLI()
    argv = ['ansible-doc', '--list']
    c.parse(argv)
    c.post_process_args()
    assert 'ANSIBLE_DOCS' in os.environ
    assert os.environ['ANSIBLE_DOCS'] == '1'

# Generated at 2022-06-22 18:53:55.146371
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    plugins = DocCLI().find_plugins()
    assert isinstance(plugins, dict)
    assert 'action' in plugins
    assert 'cache' in plugins
    assert 'callback' in plugins
    assert 'cliconf' in plugins
    assert 'connection' in plugins
    assert 'doc_fragments' in plugins
    assert 'filter' in plugins
    assert 'httpapi' in plugins
    assert 'inventory' in plugins
    assert 'lookup' in plugins
    assert 'modules' in plugins
    assert 'module_utils' in plugins
    assert 'netconf' in plugins
    assert 'shell' in plugins
    assert 'test' in plugins
    assert 'terminal' in plugins
    assert 'vars' in plugins
    assert 'windows' in plugins



# Generated at 2022-06-22 18:53:59.384786
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    rlist = _RoleMixin()._create_role_list([])

    # This must be a dict and it must not be None
    assert isinstance(rlist, dict)
    assert rlist is not None

    # The dict must not be empty
    assert len(rlist) > 0




# Generated at 2022-06-22 18:54:02.627690
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    # Exception.__init__ takes an argument, so test it.
    class PluginNotFound_test(PluginNotFound):
        pass
    PluginNotFound_test('myplugin')


# Generated at 2022-06-22 18:54:08.439969
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_text

    for doc in (None, {}, {'fields': None}, {'fields': []}, {'fields': ()}):
        assert DocCLI.add_fields([], doc) == []

    # Test add_fields without suboptions
    doc = {'fields': [{'name': 'remote_user', 'description': "The remote user account", 'type': 'str', 'required': True, 'aliases': ['user']}]}
    assert DocCLI.add_fields([], doc) == ['REMOTE_USER (=): The remote user account',
                                          '    type: str',
                                          '    aliases: [user]',
                                          '    required: True',
                                          '']

    #

# Generated at 2022-06-22 18:54:21.322117
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    class TestClass(RoleMixin):
        pass

    test_obj = TestClass()

    # Tests for normal role spec file data
    role_data = {
        'argument_specs': {
            'main': {
                'description': 'Main description',
                'options': {
                    'optionA': {
                        'description': 'Description for optionA',
                        'required': True,
                    },
                    'optionB': {
                        'description': 'Description for optionB',
                        'default': 'a value',
                    },
                },
            },
            'alternate': {
                'description': 'Alternate description'
            }
        }
    }

    # Tests for role spec file data with empty argument_specs
    empty_role_data = {
        'argument_specs': {}
    }

    # Test normal

# Generated at 2022-06-22 18:54:26.765091
# Unit test for function jdump
def test_jdump():
    from ansible.module_utils.six import iteritems

    class testobj(object):
        def __init__(self):
            self.a = 1
            self.b = "hi"

        def __iter__(self):
            for name,value in iteritems(self.__dict__):
                yield name, value

    o = testobj()
    jdump(o)



# Generated at 2022-06-22 18:54:36.453528
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    args = {'type': 'module'}
    doc = DocCLI()
    plugin_name = 'fetch'
    plugin_type = 'module'
    path = os.path.dirname(os.path.dirname(__file__))
    plugin_dir = os.path.join(path, 'lib', 'ansible', 'modules')
    plugin_files = doc._get_plugin_files(args, plugin_name, plugin_type, plugin_dir)
    metadata = doc.get_plugin_metadata(args, plugin_name, plugin_type, plugin_files)
    assert metadata['name'] == 'ansible.module_utils.basic.json_dict'
    plugin_name = 'yaml'
    plugin_type = 'module'

# Generated at 2022-06-22 18:54:46.433325
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    try:
        import ansible.utils.display
    except ImportError:
        pass
    else:
        ansible_display = ansible.utils.display
    import ansible.cli.doc
    import json
    doccli = ansible.cli.doc.DocCLI()

    test_role_name = 'role_name'

# Generated at 2022-06-22 18:54:47.855623
# Unit test for constructor of class DocCLI
def test_DocCLI():
    DocCLI(None)


# Generated at 2022-06-22 18:54:58.143316
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    import ansible.module_utils.basic
    import ansible.modules.system
    import sys

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    current_stdout = sys.stdout
    test_obj = DocCLI()
    test_module = "ping"
    doc = test_obj.get_doc(test_module)

# Generated at 2022-06-22 18:55:11.493220
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    m = DocCLI()
    assert m.format_snippet("  - name: Patch system before rebooting the host") == "  - name: Patch system before rebooting the host"
    try:
        m.format_snippet("  - name: ") is not None
        assert False, "Should have raised exception"
    except AnsibleOptionsError as e:
        assert "Error parsing snippet" in str(e)
    assert m.format_snippet("- name: Patch system before rebooting the host") == "  - name: Patch system before rebooting the host"
    assert m.format_snippet("- name: Patch system before rebooting the host\n  hosts: localhost") == "  - name: Patch system before rebooting the host\n    hosts: localhost"



# Generated at 2022-06-22 18:55:16.473635
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # create argv
    context.CLIARGS = {'type': 'module'}
    # load plugin list
    DocCLI.get_all_plugins_of_type(context.CLIARGS['type'])
    # test if plugin list is not empty
    assert DocCLI.PLUGIN_LIST.get('module') is not None


# Generated at 2022-06-22 18:55:25.415120
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    fake_program_name = 'test_program_name'
    fake_usage = 'test_usage'
    fake_epilog = 'test_epilog'
    test_cli = DocCLI(program_name=fake_program_name, usage=fake_usage, epilog=fake_epilog)
    result = test_cli.init_parser()
    assert result._prog == fake_program_name
    assert result.usage == fake_usage
    assert result.epilog == fake_epilog


# Generated at 2022-06-22 18:55:28.998355
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    cli = DocCLI()
    cli.parse(["ansible-doc", "--type", "module", "ansible.builtin.debug"])
    assert cli.get_all_plugins_of_type() == ['ansible.builtin.debug']

# Generated at 2022-06-22 18:55:32.313674
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    PLUGINS = set()
    add_collection_plugins(PLUGINS, 'action', coll_filter='acme')
    assert 'acme' in PLUGINS


# Generated at 2022-06-22 18:55:39.675412
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    call_DocCLI_post_process_args = DocCLI.post_process_args(None, {})
    assert call_DocCLI_post_process_args == {
        'module_name': '',
        'module_path': '',
        'collection_name': '',
        'collection_list': [],
        'roles_path': [],
        'type': 'module'     # 'module' or 'plugin' or 'cliconf' or 'netconf'
    }

# Generated at 2022-06-22 18:55:51.568828
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    def add_test_modules(test_path, search_paths):
        for root, dirs, files in os.walk(test_path):
            for item in files:
                if item.endswith('.py') and item != '__init__.py':
                    try:
                        # This test checks the various command line options
                        # for generating documentation, so we add the paths
                        # for the test files directly to the search_paths
                        # dict.
                        search_paths.append(test_path)
                        break
                    except UnicodeDecodeError:
                        display.warning("Unable to read %s" % item)

    # We only want to test the module arg, so we need to override the other
    # args.
    args = DocCLI.init_parser().parse_args([])

# Generated at 2022-06-22 18:55:53.564843
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    plugin_filepath = "./lib/ansible/plugins/action/library.py"
    assert DocCLI.namespace_from_plugin_filepath(plugin_filepath) == "library"


# Generated at 2022-06-22 18:56:00.818669
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    options = ['what=5', 'the=6', 'hell=7']
    limit = 16
    opt_indent = "        "
    DocCLI.add_fields(text, options, limit, opt_indent)
    assert text == ['        WHAT=5, THE=6, HELL=7']

# Unit tests for method get_man_text of class DocCLI
# Test with a doc as a string for description

# Generated at 2022-06-22 18:56:09.380603
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    cli = DocCLI()
    cli.run(None)
    cli.run(['ansible-doc'])
    cli.run(['ansible-doc', '-l'])
    cli.run(['ansible-doc', 'ansible.builtin.debug'])
    cli.run(['ansible-doc', '-H'])
    cli.run(['ansible-doc', '-t', 'module'])
    cli.run(['ansible-doc', '-v'])

# Generated at 2022-06-22 18:56:20.061442
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    """
    Test format_snippet method of class DocCLI
    """
    from ansible.module_utils.basic import AnsibleModule

    # Note: this test method must be called from the directory where it is located

# Generated at 2022-06-22 18:56:33.224812
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    """Test the run() method of class DocCLI.
    """
    args = {
        'module' : 'iam',
        'type' : 'module',
        'output' : None,
        'extra' : None
    }

    parser = create_parser()
    parser.parse_args = lambda : args

    display.verbosity = 3
    display.columns = 80


# Generated at 2022-06-22 18:56:37.031909
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound('Dummy exception for testing')
    except PluginNotFound as ex:
        assert 'Dummy exception for testing' == ex.args[0]



# Generated at 2022-06-22 18:56:43.110293
# Unit test for method run of class DocCLI
def test_DocCLI_run():
  args = dict(
    type = 'module',
    all = False,
    annotation = False,
    listt = False,
    output = '',
    search_paths = [
      '/home/leonardo/.ansible/collections/ansible_collections/juniper/junos/plugins/modules'
    ],
    timestamp = False,
    verbosity = 0,
  )
  doc = DocCLI(args)
  doc.run()

# Generated at 2022-06-22 18:56:50.214129
# Unit test for constructor of class DocCLI
def test_DocCLI(): # pylint: disable=too-many-return-statements
    '''Unit test for constructor of class DocCLI'''
    # no type
    cli = DocCLI()
    assert cli.stderr == ''
    assert cli.stdout == '', cli.stdout

    # type is module
    cli = DocCLI(['ansible-doc', '--help'])
    assert cli.stderr == ''
    assert 'ansible-doc - show documentation of Ansible modules' in cli.stdout, cli.stdout
    assert cli.parsed.module == 'help'
    assert cli.parsed.type == 'module'

    # type is module
    cli = DocCLI(['ansible-doc', 'yum'])
    assert cli.stder

# Generated at 2022-06-22 18:57:01.771090
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    '''
    Unit test for method run of class DocCLI
    '''

    import tempfile, shutil
    from ansible.playbook.play_context import PlayContext
    from ansible.cli.doc import DocCLI
    from ansible.cli.doc import core
    args = ['ansible-doc', '-t', 'action', 'ping', '--verbose', '--caching']
    p = DocCLI(args)
    cache_dir = tempfile.mkdtemp(prefix='ansible-test-cache-for-doc')
    core.plugins.module_finder._PLUGIN_PATH_CACHE = {}
    core.plugins.module_finder._PLUGIN_PATH_CACHE_PLUGINS = {}
    core.plugins.module_finder._PLUGIN_PATH_CACHE_F

# Generated at 2022-06-22 18:57:05.074690
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    pnf = PluginNotFound('foo', 'bar')
    assert isinstance(pnf, Exception)
    assert pnf.plugin == 'foo'
    assert pnf.resolved == 'bar'



# Generated at 2022-06-22 18:57:06.681409
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    pass


# Generated at 2022-06-22 18:57:09.360803
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    doc_cli = cli.DocCLI()
    doc_cli.post_process_args()
    assert True


# Generated at 2022-06-22 18:57:15.507046
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.module_utils.six import PY3
    from ansible.utils.unicode import to_bytes

    if PY3:
        module_json = to_bytes(b'{}', errors='strict')
        module_name = to_bytes(b'', errors='strict')
    else:
        module_json = '{}'
        module_name = ''

    print(DocCLI.format_plugin_doc(module_json, module_name))



# Generated at 2022-06-22 18:57:25.494362
# Unit test for function jdump
def test_jdump():
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    json_data = {'test':'success','date':datetime.datetime(2018, 12, 31, 19, 26, 0, 0)}
    json_out = json.dumps(json_data, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)
    assert json_out == '{\n    "date": "2018-12-31T19:26:00", \n    "test": "success"\n}'


# Generated at 2022-06-22 18:57:34.569752
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    print('Testing get_plugin_metadata')
    assert DocCLI().get_plugin_metadata('Copy') == {u'source': u'command', u'full': u'copy.ps1', u'path': u'C:\\Users\\bob\\.ansible\\plugins\\modules\\windows\\win_copy.ps1', u'ext': u'.ps1', u'name': u'copy', u'force': u'copy.ps1'}

# Generated at 2022-06-22 18:57:44.409474
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.module_utils._text import to_text

    def search_paths(search_paths=None):
        return search_paths or [os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'modules', 'extras')]

    doc = DocCLI()
    search_paths = search_paths()
    found_modules = {}
    loader = AnsibleCollectionLoader()

    # _get_all_plugins_of_type returns a list of tuples of (module_name, file_path)
    module_names = [name for (name, _) in doc._get_all_plugins_of_type('modules', search_paths=search_paths)]

# Generated at 2022-06-22 18:57:47.560049
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    DocCLI.find_plugins(doc.CLI.base_parser)

# Generated at 2022-06-22 18:57:59.753126
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-22 18:58:01.679367
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    msg = 'foo'
    e = PluginNotFound(msg)
    assert msg in str(e)


# Generated at 2022-06-22 18:58:09.214128
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    collname = 'abc.xyz'
    plugins = {}
    expected_path = os.path.join('/some/path/to/collection',
                                 collname, 'plugins', 'filter')
    plugin = ansible.module_utils.common.importlib.import_module('yum')
    expected_plugins = {expected_path: plugin}
    def _mock_list_collection_dirs(coll_filter=None):
        if coll_filter == collname:
            return [to_text(expected_path)]
        else:
            return []
    def _mock_find_plugins(plugin_dir, all_plugins, plugin_type, collection=None, filter=None):
        return expected_plugins

# Generated at 2022-06-22 18:58:13.980638
# Unit test for constructor of class DocCLI
def test_DocCLI():
    # Create a DocCLI object
    module = DocCLI()

    # Check the DocCLI object
    assert isinstance(module, DocCLI)



# Generated at 2022-06-22 18:58:24.381989
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    from ansible.module_utils import basic
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    doc_one = {"options": {"option_a": {"type": int,
                "default": 1,
                "choices": [1, 2, 3, 4],
                "aliases": ["a"]}}}
    doc_one["options"]["option_a"]["type"] = basic.AnsibleUnsafeText("<ansible_unsafe_text>")
    doc_two = {"plainexamples": ["# This is an example of plain example",
                u"# 我是一个超级好的例子"]}
    doc_two["plainexamples"][0] = basic.AnsibleUnsafeText("<ansible_unsafe_text>")
   

# Generated at 2022-06-22 18:58:27.160998
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    DocCLI_inst = DocCLI()
    parser = DocCLI_inst.init_parser()
    assert type(parser) == argparse.ArgumentParser



# Generated at 2022-06-22 18:58:35.147687
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    from ansible.plugins.action.normal import ActionModule as action_normal
    from ansible.plugins.connection.local import Connection as connection_local
    from ansible.plugins.lookup.dns import LookupModule as lookup_dns
    from ansible.plugins.shell.bash import ShellModule as shell_bash
    from ansible.plugins.strategy.linear import StrategyModule as strategy_linear

    # Test 1
    doc = DocCLI(connection_local())
    result = doc.get_all_plugins_of_type()
    assert result[0] == 'local'

    # Test 2
    doc = DocCLI(action_normal())
    result = doc.get_all_plugins_of_type()
    assert result[0] == 'normal'

    # Test 3

# Generated at 2022-06-22 18:58:39.334348
# Unit test for constructor of class DocCLI
def test_DocCLI():
    plugins = DocCLI.find_documents('modules')
    doc = DocCLI(plugins)
    print(doc)

# Execute unit test for class DocCLI
#test_DocCLI()

# Generated at 2022-06-22 18:58:46.739084
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 79
    opt_indent = "        "
    doc = {'description': 'Descritption', 'type': 'string'}
    DocCLI.add_fields(text, doc, limit, opt_indent)
    expected_text = [
        'DESCRIPTION:',
        '    Descritption',
        '',
        'TYPE:',
        '    string'
    ]
    return text == expected_text
