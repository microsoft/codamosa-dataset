

# Generated at 2022-06-22 18:48:54.199249
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    '''
    This test generates documentation for all plugins and roles
    '''

    docs = DocCLI()
    collection_name = 'ansible_collections.namespace.collection_name'
    plugin_types = ('action', 'become', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'module', 'netconf', 'terminal', 'test', 'vars')
    docs.run([collection_name])
    # check that the files exist before and after generating
    # documentation
    doc_path_start = os.path.join(docs.output_dir, 'collections', 'namespace', 'collection_name')
    doc_path_end = os.path.join(docs.output_dir, 'collections', 'namespace', 'collection_name-modules')

# Generated at 2022-06-22 18:49:00.710184
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # Case no - 1:
    from ansible.utils.collection_loader import get_collection_name
    plugin_filepath = get_collection_name('name', 'module_name')
    return_value = DocCLI.namespace_from_plugin_filepath(plugin_filepath)
    assert type(return_value) is str
    assert return_value == 'name'


# Generated at 2022-06-22 18:49:11.986004
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    result = DocCLI.namespace_from_plugin_filepath('/home/foo/bar/library/baz.py')
    assert result == 'foo.bar.library.baz'

    result = DocCLI.namespace_from_plugin_filepath('/home/foo/bar/modules/baz.py')
    assert result == 'foo.bar.modules.baz'

    result = DocCLI.namespace_from_plugin_filepath('/home/foo/bar/module_utils/baz.py')
    assert result == 'foo.bar.module_utils.baz'

    result = DocCLI.namespace_from_plugin_filepath('/home/foo/bar/roles/baz/tasks/main.yml')

# Generated at 2022-06-22 18:49:26.169192
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    module_finder = MockModuleFinder()
    doc = DocCLI(module_finder, '/bogus/path')

    # in lieu of actually loading a plugin, we just create the dicts with the
    # needed information.

    # create a 'core' module with no managing collection
    module_info = {
        'module_utils': ['AnsibleModule'],
        'name': 'core_module',
        'filename': 'core_module',
        'short_description': 'This is a core module',
    }
    module_finder.modules['core_module'] = module_info

    # create a collection module with no managing collection

# Generated at 2022-06-22 18:49:35.601556
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    dcli = AnsibleDocCLI([])
    dcli._load_argspec_data()
    assert dcli.role_list == {
        'collection.roleA': {
            'collection': u'collection',
            'entry_points': {
                'main': u'Main description for roleA',
                'other': u''
            }
        },
        'roleA': {
            'collection': u'',
            'entry_points': {
                'main': u'Main description for roleA',
                'other': u'Other description for roleA'
            }
        }
    }


# Generated at 2022-06-22 18:49:39.398569
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    s = DocCLI
    filepath = 'lib/ansible/modules/system/setup.py'
    assert s.namespace_from_plugin_filepath(filepath) == 'system'

# Generated at 2022-06-22 18:49:51.221288
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():

    result = DocCLI.namespace_from_plugin_filepath('/foo/bar/library/iam_roles.py')
    assert result == 'iam_roles', \
        "namespace_from_plugin_filepath returned '%s', expected 'iam_roles'" % result

    result = DocCLI.namespace_from_plugin_filepath('/foo/bar/module/dmidecode.py')
    assert result == 'dmidecode', \
        "namespace_from_plugin_filepath returned '%s', expected 'dmidecode'" % result

    result = DocCLI.namespace_from_plugin_filepath('/foo/bar/module/foo.py')
    assert result == 'foo', \
        "namespace_from_plugin_filepath returned '%s', expected 'foo'" % result

   

# Generated at 2022-06-22 18:49:53.504258
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    my_DocCLI = DocCLI()
    plugin_type = 'command'
    # TODO
    pass


# Generated at 2022-06-22 18:49:56.308432
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doccli = DocCLI()
    doccli.get_all_plugins_of_type()


# Generated at 2022-06-22 18:50:09.529719
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-22 18:50:20.700295
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Test the output of DocCLI.print_paths with getting a pprint result first and compare it with expected result
    mock_display = MagicMock()
    with patch("ansible.cli.doc.display", mock_display):
        from ansible.cli.doc import DocCLI
        cli = DocCLI(args=['ansible-doc', '--paths'])
        cli.parse()
        paths = cli.print_paths()

# Generated at 2022-06-22 18:50:22.694982
# Unit test for constructor of class DocCLI
def test_DocCLI():
    DocCLI(doc=None, verbosity=None)


# Generated at 2022-06-22 18:50:26.278452
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Create an instance of class DocCLI
    obj = DocCLI()
    # Call the method print_paths of obj
    # No return value
    obj.print_paths()


# Generated at 2022-06-22 18:50:30.489322
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    from ansible.cli import CLI
    from ansible.cli.doc import DocCLI

    mycli = DocCLI(['list', 'roles'])
    assert(isinstance(mycli, RoleMixin))
    assert(hasattr(mycli, '_load_argspec'))


# Generated at 2022-06-22 18:50:43.492274
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    ''' print_paths() for DocCLI class. '''

    import tempfile
    import sys
    import json
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file under that directory
    tmppath = os.path.join(tmpdir, 'stdout')
    with open(tmppath, 'w') as outfile:
        outfile.write('[{"json": 1}]')

    # Capture stdout.
    captured = io.StringIO()                 # Create StringIO object
    stdout_ = sys.stdout                     # Save previous value.
    sys.stdout = captured                    # and redirect stdout.
    # Execute the function to be tested

# Generated at 2022-06-22 18:50:46.006617
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    result = DocCLI.get_man_text(doc_example)
    assert result == doc_man_text


# Generated at 2022-06-22 18:50:50.124279
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    e = PluginNotFound('file', 'plugin', 'alias')

    assert e.file == 'file'
    assert e.plugin == 'plugin'
    assert e.alias == 'alias'
    assert e.message == "Plugin file: 'plugin' not found, did you mean one of: alias"



# Generated at 2022-06-22 18:51:01.613712
# Unit test for method run of class DocCLI
def test_DocCLI_run():

    args = collections.namedtuple('args', 'output collection', defaults=[[], []])('txt', [])
    doc_doc = DocCLI()

    try:
        doc_doc.run('/non/existing/file', args, 'doc')
    except SystemExit:
        pass


    existing_file = os.path.join(os.path.dirname(__file__), '..', 'lib', 'ansible', 'modules', 'network', 'cloudengine', 'ce_command.py')
    args = collections.namedtuple('args', 'output collection', defaults=[[], []])('txt', [])
    ansible_module_doc = DocCLI()
    ansible_module_doc.run(existing_file, args, 'doc')

# Generated at 2022-06-22 18:51:04.457063
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    exception = PluginNotFound('test_message')
    assert exception.message == 'test_message'



# Generated at 2022-06-22 18:51:17.409666
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    options_data = {
        'name': 'ansible',
        'description': 'This is description for ansible',
        'aliases': ['ans'],
        'required': True,
        'choices': ['choice 1', 'choice 2'],
        'options': {
            'name': 'test',
            'description': 'This is description for test',
            'required': True,
        }
    }

    text = []
    DocCLI.add_fields(text, options_data, 80, '', return_values=False, opt_indent='   ')
    text_as_string = "\n".join(text)

# Generated at 2022-06-22 18:51:27.256453
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    text = DocCLI.format_snippet([
        dict(host=dict(hostname=['host1'], port=[80, 443]),
             vars=dict(http_port=80, https_port=443)),
        dict(host=dict(hostname=['host2'], port=[80, 443]),
             vars=dict(http_port=80, https_port=443))
    ])
    assert text == '# BEGIN ANSIBLE MANAGED BLOCK\n[all:vars]\nhttp_port=80\nhttps_port=443\n\n[host1]\nhost1\nhost1\nhost2\nhost2\n# END ANSIBLE MANAGED BLOCK\n'


# Generated at 2022-06-22 18:51:32.131161
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    coll_filter=''
    plugin_type='module'
    add_collection_plugins(plugin_list, plugin_type, coll_filter=coll_filter)



# Generated at 2022-06-22 18:51:34.082065
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    r = RoleMixin()
    assert r is not None



# Generated at 2022-06-22 18:51:36.725797
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    args = DocCLI.parse()
    context.CLIARGS = args
    doc = DocCLI()
    doc_path = os.path.join(os.path.dirname(__file__), '..', '..', 'plugins', 'modules')
    if args.type in ['module', 'modules']:
        result = doc.get_plugin_metadata(doc_path)
        assert len(result) == 3005



# Generated at 2022-06-22 18:51:46.116488
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    from ansible import constants
    from ansible.module_utils.six import string_types

    results = DocCLI().get_all_plugins_of_type('modules')
    for k, v in results.items():
        assert isinstance(k, string_types)
        assert isinstance(v, DocCLI)
        assert os.path.isfile(v.filename)

        # Test that we only display options that are actually present
        # in the code.
        # (we are only testing a single module here, but it should be
        # sufficient to test that the methods works.)
        if k == 'group_by':
            assert 'key' in v.options
            assert 'version_added' in v.options['key']
            assert 'key_name' in v.options

            assert 'overlap' not in v.options
   

# Generated at 2022-06-22 18:51:58.898376
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    def eq(actual, expected):
        assert actual == expected

    eq(DocCLI.get_all_plugins_of_type('action'),
        ['setup', 'configure_logging', 'meta', 'wait_for', 'wait_for_connection', 'raw',
         'include', 'include_role', 'set_fact', 'import_role', 'include_tasks', 'add_host',
         'group_by', 'block', 'include_vars', 'meta', 'pause', 'async_status', 'async_wait',
         'debug', 'pre_tasks', 'post_tasks', 'role_paths', 'set_stats', 'slurp', 'stat',
         'uri', 'wait_for_connection', 'wait_for', 'wait_until', 'register', 'assert'])

# Generated at 2022-06-22 18:52:08.297131
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {"description": "This is a description", "short_description": "This is a short description"}
    # Test that a format exception is raised if there is a plugin with an invalid name
    plugin_name = "invalid_plugin_name"
    if not plugin_name.startswith(display_common.DOCUMENT_ENTRY_POINT_PREFIX):
        assert_raises(AssertionError, DocCLI.format_plugin_doc, plugin_name, doc, None)
    # Test that a format exception is raised if there is a plugin with a name that does not end with _module
    plugin_name = "something_else"

# Generated at 2022-06-22 18:52:09.945151
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    module = DocCLI()
    assert module.init_parser() is not None, "Return value of method init_parser is not as expected."
    

# Generated at 2022-06-22 18:52:17.050569
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    import ansible.utils.display
    b_roles_path = (to_bytes(os.path.expanduser('~/ansible-role-test'), errors='surrogate_or_strict'),)
    class RoleMixinTest(RoleMixin):
        def __init__(self, b_roles_path):
            super(RoleMixinTest, self).__init__()
            self.b_roles_path = b_roles_path

    rmt = RoleMixinTest(b_roles_path)

    roles = rmt._find_all_normal_roles(b_roles_path)
    assert len(roles) == 2
    assert ('test-role-1', to_text(b_roles_path[0], errors='surrogate_or_strict')) in roles


# Generated at 2022-06-22 18:52:28.275436
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    host = DocCLI()
    doc = {
        'options': {
            'src': {
                'description': 'path to the file being transferred',
                'required': True,
                'aliases': ['dest'],
                'choices': ['one', 'two'],
                'default': 'default',
                'suboptions': {
                    'suboption': {
                        'description': 'suboption description',
                    }
                }
            },
        }
    }

    text = []
    host.add_fields(text, doc['options'], 100, '', False, '        ')


# Generated at 2022-06-22 18:52:39.871990
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    Files.create_temp_directory()
    os.mkdir('/tmp/ansible_collections/foo_bar/bar_collection')
    os.mkdir('/tmp/ansible_collections/foo_bar/bar_collection/plugins/modules')
    os.mkdir('/tmp/ansible_collections/foo_bar/bar_collection/plugins/action')
    os.mkdir('/tmp/ansible_collections/foo_bar/bar_collection/plugins/inventory')
    os.mkdir('/tmp/ansible_collections/foo_bar/bar_collection/plugins/cliconf')
    os.mkdir('/tmp/ansible_collections/foo_bar/bar_collection/plugins/connection')


# Generated at 2022-06-22 18:52:50.900063
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-22 18:53:01.496228
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    '''
    Unit test for method find_plugins of class DocCLI
    '''
    def test_method(ansible_path, plugin_type):
        return DocCLI.find_plugins(ansible_path, plugin_type)

    # base class from which we should get valid plugin paths
    from ansible import constants as C
    import re

    # all plugins should be found for each plugin type
    for plugin_type in C.DEFAULT_MODULE_PATH:
        plugin_files = test_method('', plugin_type)
        if C.DEFAULT_MODULE_PATH[plugin_type]:
            assert len(plugin_files) > 0
            assert plugin_files[0].startswith('/')
        else:
            assert len(plugin_files) == 0

    # passing an empty string or None to ansible_path

# Generated at 2022-06-22 18:53:14.046419
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
  from ansible.module_utils.six import StringIO
  import sys
  f_in = StringIO()
  out = StringIO()
  err = StringIO()
  sys.stdout = out
  sys.stderr = err
  doccli = DocCLI()
  try:
    doccli.post_process_args('test')
  except SystemExit as e:
    pass
  if sys.exc_info()[0] is not SystemExit:
    raise
  sys.stdout = sys.__stdout__
  sys.stderr = sys.__stderr__
  assert out.getvalue() == ''
  assert err.getvalue() != ''
  sys.stdout = out
  sys.stderr = err

# Generated at 2022-06-22 18:53:23.400629
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    class MockDocCLI:
        IGNORE = []
        @staticmethod
        def tty_ify(data):
            return data
        @staticmethod
        def _dump_yaml(data, key):
            return yaml_dump(data, indent=2, default_flow_style=False)
    ModulesDocCLI = DocCLI()
    ModulesDocCLI.IGNORE = MockDocCLI.IGNORE
    ModulesDocCLI.dump_yaml = MockDocCLI._dump_yaml
    ModulesDocCLI.tty_ify = MockDocCLI.tty_ify

# Generated at 2022-06-22 18:53:33.946913
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    doc = dict(description='foo', options=dict(host=dict(description='host to connect to', required=True)))
    argspec = dict(host=dict(type='str', required=True), debug=dict(type='bool', default=False))
    cli = DocCLI(doc, argspec=argspec)
    parser = cli.init_parser()
    assert isinstance(parser, ArgumentParser)
    assert parser.description == 'foo'
    assert parser.prog == 'ansible-doc'
    assert parser._optionals.title == 'optional arguments'
    assert 'debug' in parser._option_string_actions
    assert 'D' in parser._option_string_actions['debug'].option_strings
    assert '--debug' in parser._option_string_actions['debug'].option_strings
    assert 'host'

# Generated at 2022-06-22 18:53:46.711513
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc = DocCLI()
    role = "myrole"

# Generated at 2022-06-22 18:53:56.293806
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Creating a DocCLI object
    doccli = DocCLI()
    
    paths = collections.OrderedDict()
    paths['/etc/ansible/'] = {'plugin_type': 'config'}
    paths['/etc/ansible/ansible.cfg'] = {'plugin_type': 'config', 'filename': '/etc/ansible/ansible.cfg'}
    paths['/etc/ansible/ansible.cfg'] = {'plugin_type': 'config', 'filename': '/etc/ansible/ansible.cfg'}
    paths['/usr/share/ansible'] = {'plugin_type': 'module'}
    paths['/usr/share/ansible/modules/extras/network/cloudengine'] = {'plugin_type': 'module'}

# Generated at 2022-06-22 18:54:03.040171
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    assert DocCLI.find_plugins('action') == [ 'assert', 'pause', 'meta', 'wait_for', 'meta', 'raw',
                                              'uri', 'script', 'meta', 'debug', 'ping', 'shell',
                                              'fail', 'add_host', 'group_by', 'include_vars',
                                              'meta', 'set_fact', 'meta', 'setup', 'meta', 'command',
                                              'meta', 'include', 'meta', 'set_stats', 'meta' ]


# Generated at 2022-06-22 18:54:04.287238
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    raise SkipTest("no cli")


# Generated at 2022-06-22 18:54:09.394665
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc_cli = ("  -action\n"
               "  -vars\n"
               "  -filter\n"
               "  -shell\n" 
               "  -test")
    result = doc_cli.split()
    assert DocCLI.find_plugins('') == result


# Generated at 2022-06-22 18:54:16.129611
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    check_list = {'plugins/': {'group_by': './plugins/action',
                               'include_role': './plugins/action'}}
    plugin_list = {}
    DocCLI.add_collection_plugins(plugin_list, 'action')
    assert plugin_list == check_list, "Failed to add collection-plugins with " \
                                      "plugin-type 'action' in the list"



# Generated at 2022-06-22 18:54:24.374039
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    def test_filter(name):
        return name.startswith('test_')

    b_colldirs = list_collection_dirs(coll_filter=test_filter)
    assert len(b_colldirs) == 1

    plugin_list = {}
    add_collection_plugins(plugin_list,'action')
    assert plugin_list['test_collection.test_action']['collection'] == 'test_collection'
    assert 'test_collection.test_action' in plugin_list



# Generated at 2022-06-22 18:54:34.272704
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {
        'version_added': '',
        'aliases': {
            's1': [],
            's1c': [],
            's2': [],
            's3': []
        },
        'options': {
            'param1': {
                'aliases': [
                    's4',
                    's4c'
                ],
                'default': False
            }
        },
        'short_description': 'Short description'
    }
    cli = DocCLI()
    #print(cli.format_plugin_doc(doc))


if __name__ == '__main__':
    test_DocCLI_format_plugin_doc()

# Generated at 2022-06-22 18:54:39.836940
# Unit test for constructor of class DocCLI
def test_DocCLI():
    DocCLI(
        doc,
        section='options',
        title='OPTIONS (= is mandatory)',
        base_indent=4,
        max_width=80,
        indent_size=4,
        ignore_options=('module',),
    )

    assert 1 == 1


# Generated at 2022-06-22 18:54:52.659446
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    _plugin_name = "Not a plugin"
    _description = "Some description"
    _metadata = {'version_added': "2.5"}
    DocCLI._format_plugin_doc(_plugin_name, _description, _metadata)
    DocCLI._format_plugin_doc.__dict__.__setitem__('stypy_call_defaults', {'metadata': _metadata})
    DocCLI._format_plugin_doc(_plugin_name, _description)
    DocCLI._format_plugin_doc.__dict__.__setitem__('stypy_call_varargs', varargs=_plugin_name)
    DocCLI._format_plugin_doc.__dict__.__setitem__('stypy_call_kwargs', kwargs={'metadata': _metadata})
    arguments = process_argument

# Generated at 2022-06-22 18:55:06.286203
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    '''Test with simple json data'''


# Generated at 2022-06-22 18:55:09.486684
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    test_args = []
    expected_args = ["-v", "--list", "-K","-C","-T","-v"]
    test_args = ["-v", "-K", "-l", "all", "-C", "test1,test2", "-T","-v"]
    doc = DocCLI(test_args)
    actual_args = doc.post_process_args()
    assert(expected_args == actual_args)


# Generated at 2022-06-22 18:55:17.433715
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    DocCLI = ansible.utils.plugin_docs.DocCLI
    # No args, invalid verbosity
    with pytest.raises(SystemExit):
        DocCLI._print_paths(None, None, None, None)
    # No args, valid verbosity
    with pytest.raises(SystemExit):
        DocCLI._print_paths(None, None, None, 1)
    # args, invalid verbosity
    with pytest.raises(SystemExit):
        DocCLI._print_paths([""], None, None, None)
    # args, valid verbosity
    with pytest.raises(SystemExit):
        DocCLI._print_paths([""], None, None, 1)


# Generated at 2022-06-22 18:55:28.669765
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    monkeypatch = MonkeyPatch()
    context.CLIARGS = {'ignore_autogenerated': True}
    monkeypatch.setattr(C, 'get_collection_name', lambda x: 'collection.name')
    monkeypatch.setattr(DocCLI, 'no_log', lambda x: x)
    monkeypatch.setattr(DocCLI, '_print_paths', lambda x, y: x)
    text = "text"
    matches = {text: {'plugin_type': 'mod', 'path': 'path', 'name': 'a'},
               'collection.name.a': {'plugin_type': 'mod', 'path': 'path', 'name': 'a'}}
    path = 'path'

    DocCLI.print_paths(path, matches, text)

    monkeypatch.undo()


# Generated at 2022-06-22 18:55:40.415735
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc_cli = DocCLI()

# Generated at 2022-06-22 18:55:50.391243
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    """Unit test for method run of class DocCLI"""
    a = None
    with pytest.raises(AnsibleOptionsError) as excinfo:
        DocCLI(a).parse()

    args = {'type': 'foo'}
    b = AnsibleOptions(args)
    with pytest.raises(AnsibleOptionsError) as excinfo:
        DocCLI(b).parse()

    args = {'type': 'module', 'extension': 'foo', 'module': 'test_module'}
    c = AnsibleOptions(args)
    with pytest.raises(AnsibleOptionsError) as excinfo:
        DocCLI(c).parse()

    args = {'type': 'module', 'path': 'foo', 'module': 'test_module'}

# Generated at 2022-06-22 18:56:02.876747
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    cli = DocCLI()

# Generated at 2022-06-22 18:56:06.076714
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    doc_cli = DocCLI()
    doc_cli.args = []
    doc_cli.init_parser()


# Generated at 2022-06-22 18:56:10.588552
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = C.DEFAULT_MODULE_MULTIPLE_COMPATIBLE_PLUGIN_TYPE
    coll_filter = None
    DocCLI.add_collection_plugins(plugin_list, plugin_type, coll_filter)
    assert plugin_list != {}



# Generated at 2022-06-22 18:56:15.510125
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    '''Unit test for DocCLI format_plugin_doc'''

    args = {'type': 'module',
            'path': '../lib/ansible/modules/cloud/amazon/ec2_group.py'}
    dc = DocCLI(args)
    output = dc.format_plugin_doc()
    assert output


# Generated at 2022-06-22 18:56:24.204008
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-22 18:56:36.817724
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    dummy_path = "/path/to/plugins"

    dummy_module_list = [
        'module1',
        'module2',
        'module3'
    ]

    dummy_default_module_list = [
        'module4',
        'module5',
        'module6'
    ]

    dummy_plugin_list = [
        'plugin1',
        'plugin2',
        'plugin3'
    ]

    dummy_module_doc = {
        "module1": "module1 doc",
        "module3": "module3 doc"
    }

    dummy_plugin_doc = {
        "plugin1": "plugin1 doc",
        "plugin3": "plugin3 doc"
    }

    # Set up mocks

# Generated at 2022-06-22 18:56:38.982225
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc = DocCLI()
    assert_equals(doc.find_plugins(), [])

# Generated at 2022-06-22 18:56:41.071967
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
  DocCLI.display_plugin_list(None, None, None, None)


# Generated at 2022-06-22 18:56:53.570907
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    cli = DocCLI()
    # modules
    assert cli.get_all_plugins_of_type(os.path.join(os.path.dirname(__file__), '../../lib/ansible/modules/commands'),'module')
    assert cli.get_all_plugins_of_type(os.path.join(os.path.dirname(__file__), '../../lib/ansible/modules/files'),'module')
    assert cli.get_all_plugins_of_type(os.path.join(os.path.dirname(__file__), '../../lib/ansible/modules/net_tools'),'module')

# Generated at 2022-06-22 18:56:55.916698
# Unit test for function jdump
def test_jdump():
    a = 1
    b = {'a': a}
    c = [b]
    jdump(c)


# Generated at 2022-06-22 18:57:07.775988
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # test 1
    # unit test for display_plugin_list
    temp_data = {'action': {'ping': [{'has_action': True, 'name': 'ping', 'filename': 'c:\\ansible\\lib\\ansible\\modules\\system\\ping.py'}]}, 'connection': {'netconf': [{'has_action': False, 'name': 'netconf', 'filename': 'c:\\ansible\\lib\\ansible\\plugins\\connection\\netconf.py'}], 'httpapi': [{'has_action': False, 'name': 'httpapi', 'filename': 'c:\\ansible\\lib\\ansible\\plugins\\connection\\httpapi.py'}]}}
    display.display(temp_data)
    # test 2
    # unit test for display_plugin_list

# Generated at 2022-06-22 18:57:08.219492
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    assert True


# Generated at 2022-06-22 18:57:11.302385
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    DocCLI.display_plugin_list(None, None, None, "units", None)
    DocCLI.display_plugin_list("units", None, "units", "units", "units")

# Generated at 2022-06-22 18:57:19.641739
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    cli = DocCLI(args=[])
    cli.post_process_args()
    assert cli.options.index == 'auto'
    assert cli.options.refresh_cache is False
    assert cli.options.verbosity == 0

    cli = DocCLI(args=['-r', '-v', '-v'])
    cli.post_process_args()
    assert cli.options.index == 'auto'
    assert cli.options.refresh_cache is True
    assert cli.options.verbosity == 2

    cli = DocCLI(args=['-i', 'foo', '-r'])
    cli.post_process_args()
    assert cli.options.index == 'foo'
    assert cli.options.refresh_cache is True

# Generated at 2022-06-22 18:57:32.002463
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    result = {}
    result['name'] = 'ping'
    result['path'] = '/Users/david/Library/Python/2.7/lib/python/site-packages/ansible/modules/system/ping.py'
    result['collection'] = 'ansible.builtin'
    result['filename'] = 'ping.py'
    result['module'] = True
    result['common'] = False
    result['action'] = False
    result['module_utils'] = False
    result['deprecated'] = False
    result['has_action'] = False

    plugin = {}
    plugin['name'] = 'ping'
    plugin['path'] = '/Users/david/Library/Python/2.7/lib/python/site-packages/ansible/modules/system/ping.py'

# Generated at 2022-06-22 18:57:33.547460
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
  pass


# Generated at 2022-06-22 18:57:42.304436
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # Create instance
    doc_cli = DocCLI()

    # No arguments, run with defaults
    output = doc_cli.format_snippet([])
    assert output == []

    # One argument, run with defaults
    output = doc_cli.format_snippet(["toto"])
    assert output == ['toto']

    # One argument, run with defaults
    output = doc_cli.format_snippet(["toto", "tata"])
    assert output == ['toto', 'tata']

    # One argument, run with defaults
    output = doc_cli.format_snippet(["toto", "tata", "titi"])
    assert output == ['toto', 'tata', 'titi']

    # One argument, run with defaults
    output = doc_cli.format_sn

# Generated at 2022-06-22 18:57:52.782260
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Initialize arguments used for creating a DocCLI object
    args = CLI.base_parser('').parse_args(args=[])

    # Call method
    result = DocCLI.find_plugins(args)

    # AssertionError if function returns None
    assert result is not None, "The function 'find_plugins()' should return a value."

    # Assertion if result is a dictionary
    assert type(result) is dict, "The function 'find_plugins()' should return a dictionary."

    # Assertion if dictionary values are not empty
    assert result.values() is not None, "The function 'find_plugins()' should return a dict with non-empty values."



# Generated at 2022-06-22 18:58:03.815855
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    cls = DocCLI()
    actual = cls.has_field_doc('version_added')
    assert actual == 'version_added', f"expected: version_added, actual: {actual}"
    actual = cls.has_field_doc('version_added', 'version_added_collection')
    assert actual == 'version_added', f"expected: version_added, actual: {actual}"
    actual = cls.has_field_doc('version_added', 'version_added_collections')
    assert actual == 'version_added', f"expected: version_added, actual: {actual}"
    actual = cls.has_field_doc('version_added', 'version_added_collectionss')
    assert actual == '', f"expected: '', actual: {actual}"
    actual = cls.has_field_doc

# Generated at 2022-06-22 18:58:13.060299
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    ''' test_DocCLI_display_plugin_list():
    '''
    if sys.version_info[0] == 2:
        fixtures = [
            {'name': 'test', 'collections': ['first', 'second']},
            {'name': 'test2', 'collections': ['third']},
        ]
    else:
        fixtures = [
            {'name': 'test', 'collections': ['first', 'second']},
            {'name': 'test2', 'collections': ['third']},
        ]

    x = DocCLI()
    x._display_plugin_list(fixtures)
    assert True

# Generated at 2022-06-22 18:58:15.926097
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    DocCLI.display_plugin_list(plugins.lookup_loader(context.CLIARGS['type']), context.CLIARGS['type'])
    assert True

# Generated at 2022-06-22 18:58:27.935804
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    config = ("{{\n"
        "  'foo': {},\n"
        "  'bar': [],\n"
        "  'baz': 'qux',\n"
        "  'quux': 'quuz',\n"
        "  'corge': 'grault'}\n"
        "}")
    expected_output = ("        bar: []\n"
        "        baz: qux\n"
        "        corge: grault\n"
        "        foo: {}\n"
        "        quux: quuz")
    text_list = []
    DocCLI.add_fields(text_list, yaml.safe_load(config), 80, "        ")
    assert "\n".join(text_list) == expected_output



# Generated at 2022-06-22 18:58:29.955212
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # DocCLI.print_paths() is a private method that doesn't need to be tested directly
    pass



# Generated at 2022-06-22 18:58:31.589940
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    mycli = DocCLI(args={})
    mycli.run()



# Generated at 2022-06-22 18:58:37.818615
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    """
    Assumes that the tests/collections directory is included in the ansible.cfg. Also assumes
    that the ansible-doc executable is also in the path.

    # TODO: maybe better to use the CollectionsCLI directly here, but don't want to duplicate
    # logic in unit tests
    """
    fake_env = {
        b'ANSIBLE_COLLECTIONS_PATHS': b'build,../ansible_collections/collections',
        b'ANSIBLE_ROLES_PATH': b'../ansible_collections/collections/ns/collA/roles'
    }
    argspec = RoleMixin()

    # 1. Assert that valid roles show up
    result = argspec._create_role_list(("build",), "ns.collA")

# Generated at 2022-06-22 18:58:48.161598
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    #import pdb;pdb.set_trace()
    newDocCli = DocCLI()
    newDocCli.tty_ify = lambda txt:txt
    newDocCli.IGNORE=('meta',)
    text = ["> MODULE(S)\n"]
    #doc = {}