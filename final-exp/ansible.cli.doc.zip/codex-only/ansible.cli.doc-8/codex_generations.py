

# Generated at 2022-06-22 18:48:50.837414
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
  try:
    dc = DocCLI()
  except Exception as e:
    ansible_fail_json(msg=e)
    
  parser = dc.init_parser()
  assert parser is not None

# Generated at 2022-06-22 18:49:01.685555
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-22 18:49:09.017022
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
  from pathlib import Path
  from ansible.utils import plugin_docs as plugin_docs
  test_doc_loader = plugin_docs.load_plugin_docs(all_plugins=False)
  test_plugin_path = Path('./tests/unit/plugins/doc_fragments/foo.py')
  plugin_namespace = DocCLI.namespace_from_plugin_filepath(test_plugin_path)
  assert plugin_namespace == 'foo'

# Generated at 2022-06-22 18:49:22.574481
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    doc = DocCLI()

    with pytest.raises(AnsibleOptionsError) as execinfo:
        doc.print_paths()
    assert '--type-path option must be specified' in to_bytes(execinfo.value)

    with pytest.raises(AnsibleOptionsError) as execinfo:
        doc.print_paths(type_path="invalid_path")
    assert '--type-path must be a valid path' in to_bytes(execinfo.value)

    with pytest.raises(AnsibleOptionsError) as execinfo:
        doc.print_paths(type_path="")
    assert '--type-path must be a valid path' in to_bytes(execinfo.value)


# Generated at 2022-06-22 18:49:31.851627
# Unit test for constructor of class DocCLI
def test_DocCLI():
    '''Unit test for the DocCLI class constructor.

    Usage:
    python -c "import ansible.cli.doc; ansible.cli.doc.test_DocCLI()"
    '''

    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager

    display = Display()
    inventory = InventoryManager(loader=None, sources=['localhost,'], vault_ids=[])

    # Test constructor with only the required argument display
    doc_obj = DocCLI(display)
    assert doc_obj.display == display

    # Test constructor with optional arguments inventory and parser
    doc_obj = DocCLI(display, inventory, parser=parser)
    assert doc_obj.display == display
    assert doc_obj.inventory == inventory
    assert doc_obj.parser == parser



# Generated at 2022-06-22 18:49:37.128625
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    test_plugin_list = {}
    out_collection_plugins = ansible.plugins.loader.get_all_plugin_loaders() 
    # The function calls add_collection_plugins which calls find_plugins which calls get_all_plugin_loaders
    # We are checking if the output of get_all_plugin_loaders is not empty to check if we were able to load plugins for collections
    assert out_collection_plugins



# Generated at 2022-06-22 18:49:39.657909
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # @todo: add unit test for method display_plugin_list of class DocCLI
    pass

# Generated at 2022-06-22 18:49:42.525652
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = [
        'ansible-doc'
    ]
    p = DocCLI(args)
    p.run()

# Generated at 2022-06-22 18:49:53.504931
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role = "an_important_role"
    role_json = {"entry_points": {"normal": {"description": "This is a description",
                                             "options": {"option_name": {"default": True,
                                                                         "description": "An option",
                                                                         "required": True,
                                                                         "type": "bool"}}}}}
    expected = "> AN_IMPORTANT_ROLE    ()\nENTRY POINT: normal - This is a description\nOPTIONS (= is mandatory):\n        option_name\n                [Type: boolean]\n                [Required: True]\n                An option\n                [Default: True]"
    assert expected == "\n".join(DocCLI().get_role_man_text(role, role_json))


# Generated at 2022-06-22 18:49:57.717104
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    ansible_module_args = {'version': '1.2.3', 'foo': 'bar'}
    filter_result = set(['version', 'foo'])
    DocCLI.DocCLI.post_process_args(ansible_module_args)
    check_result = set(ansible_module_args.keys())
    assert filter_result == check_result


# Generated at 2022-06-22 18:50:01.336634
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    doc_cli = DocCLI()
    try:
        raise PluginNotFound('not found')
    except PluginNotFound as ex:
        assert ex.args[0] == 'not found'



# Generated at 2022-06-22 18:50:04.439566
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
   doc_cli = DocCLI()
   doc_cli.get_all_plugins_of_type()



# Generated at 2022-06-22 18:50:16.991888
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    doc = {
        'description': 'test',
        'options': {
            'msg': {
                'description': 'The message to send.  May be a string or a dict.',
                'required': True,
                'aliases': ['message'],
                'choices': ['green', 'blue', 'red'],
                'default': 'green',
            },
            'topic': {
                'description': 'The topic of the message.',
                'required': True,
            },
            'value': {
                'description': 'The value to use in the message.',
                'required': False,
            },
        },
    }
    text = []
    DocCLI.add_fields(text, doc['options'], 78, '    ', False, '')
    # compare two string

# Generated at 2022-06-22 18:50:23.859961
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    module = MiniModule()
    module.params = dict(
        path = '/Users/maren/src/ansible/ansible/lib/ansible/modules/network/eos/eos_facts.py',
        filter = 'network/eos/eos_facts',
        directive = None,
    )
    cli_doc = DocCLI([module], 'module')
    print(cli_doc.get_plugin_metadata())


# Generated at 2022-06-22 18:50:25.011194
# Unit test for function jdump
def test_jdump():
    assert jdump(None) == None

# Generated at 2022-06-22 18:50:26.049881
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    assert True

# Generated at 2022-06-22 18:50:28.324325
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    from ansible.module_utils.six import StringIO
    out = StringIO()
    obj = DocCLI()
    pass



# Generated at 2022-06-22 18:50:40.577079
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Initialize a mock display object
    display = Display()
    # Initialize a mock parser object
    parser = argparse.ArgumentParser(add_help=False, description="Show Ansible module documentation")
    parser.add_argument("--version", action="store_true", help="Show program's version number and exit")
    doc = DocCLI(parser, display)
    # Get plugin list
    plugin_list = [
        'action',
        'become',
        'cache',
        'callback',
        'cliconf',
        'connection',
        'doc_fragments',
        'filter',
        'httpapi',
        'inventory',
        'lookup',
        'netconf',
        'shell',
        'strategy',
        'terminal'
    ]
    # Call the display_plugin_

# Generated at 2022-06-22 18:50:43.810411
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound('test')
    except PluginNotFound as e:
        if str(e) != 'test':
            raise AssertionError



# Generated at 2022-06-22 18:50:46.341480
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    role = "role1"
    role_json = _create_role_doc(role)
    doc_utils = DocCLI()
    text = doc_utils.get_role_man_text(role, role_json)
    for line in text:
        print(line)

# Generated at 2022-06-22 18:50:53.953582
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    doc_paths = []
    for path in ['action_plugins', 'filter_plugins', 'lookup_plugins', 'module_utils', 'become_plugins', 'callback_plugins', 'vars_plugins']:
        for subpath in rc.get_plugin_paths(path):
            doc_paths.append(subpath)

    # test with empty searchpath
    with pytest.raises(Exception) as exc:
        DocCLI().print_paths([])

    assert 'no doc paths' in str(exc.value)
    # test with valid searchpath
    DocCLI().print_paths(doc_paths)

# Generated at 2022-06-22 18:50:56.821246
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    result = []
    add_collection_plugins(result, 'action')
    assert isinstance(result, list)
    assert len(result) > 0



# Generated at 2022-06-22 18:51:00.504465
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    test_DocCLI = DocCLI()
    mock_dirs = collections.namedtuple('dirs', ['ansible', 'action'])
    plugins_dirs = mock_dirs(ansible='/path/to/ansible', action='/path/to/action')
    assert test_DocCLI._get_all_plugins_of_type(plugins_dirs, 'module') == '/path/to/ansible/modules'



# Generated at 2022-06-22 18:51:03.499774
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    doc_cli = DocCLI()
    doc_cli.print_paths()

# Generated at 2022-06-22 18:51:06.058359
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    args = DocCLI().post_process_args([])
    assert args.type == 'modules'


# Generated at 2022-06-22 18:51:11.271426
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc_cli = DocCLI({'type': 'module'})
    for plugin in doc_cli.get_all_plugins_of_type():
        if 'CREATE_DIRECTORY' in plugin:
            assert 'module_utils/basic.py' in plugin, "module_utils/basic.py module is not in the plugin"

# Generated at 2022-06-22 18:51:20.721485
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    r = RoleMixin()
    assert r is not None
    assert hasattr(r, '_load_argspec')
    assert hasattr(r, '_find_all_normal_roles')
    assert hasattr(r, '_find_all_collection_roles')
    assert hasattr(r, '_build_summary')
    assert hasattr(r, '_build_doc')
    assert hasattr(r, '_create_role_list')
    assert hasattr(r, '_create_role_doc')



# Generated at 2022-06-22 18:51:23.159716
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    doc = DocCLI()
    doc._print_paths("module")


# Generated at 2022-06-22 18:51:25.636194
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    DocCLI.run()

if __name__ == "__main__":
    test_DocCLI_run()

# Generated at 2022-06-22 18:51:27.249011
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    assert True == False # TODO: implement your test here



# Generated at 2022-06-22 18:51:32.246683
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    cli_doc_tools = DocCLI(args=[])
    cli_doc_tools.init_parser()
    assert '--version' in cli_doc_tools.parser._option_string_actions

# Generated at 2022-06-22 18:51:34.907995
# Unit test for constructor of class DocCLI
def test_DocCLI():
    result = DocCLI("/path/to/foo")
    assert result is not None


# Generated at 2022-06-22 18:51:44.362908
# Unit test for method get_plugin_metadata of class DocCLI

# Generated at 2022-06-22 18:51:47.590631
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    class Test(object):

        def _find_plugins(self):
            return None

    test = Test()
    assert test._find_plugins() == None


# Generated at 2022-06-22 18:52:00.508605
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.utils.plugin_docs import get_docstring

    def _get_docs(obj, verbose=False):
        all_default_args = {} if verbose else None
        docstring = get_docstring(obj, verbose=verbose)
        return (docstring._entries, docstring.get_doc())

    display = Display()
    display.colorize = lambda role, msg: msg

    def test_method(item=None, table=None, exclude=None, collection_list=None, filter_examples=False):
        if item is None:
            item = 'all'
        if exclude is None:
            exclude = ()


# Generated at 2022-06-22 18:52:02.749962
# Unit test for function jdump
def test_jdump():
    assert jdump(None) == None


# Generated at 2022-06-22 18:52:03.398281
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    assert True == True

# Generated at 2022-06-22 18:52:11.367803
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    rm = RoleMixin()

    # Test normal role arg spec
    role = 'foobar'
    role_path = '/opt/ansible/collections/ansible_namespace/foobar'
    argspec = rm._load_argspec(role, role_path=role_path)
    assert argspec['main']['short_description'] == 'Ansible foobar role'

    # Test collection role arg spec
    role = 'foobar'
    collection = 'ansible_namespace.barfoo'
    collection_path = '/opt/ansible/collections/ansible_namespace/barfoo'
    argspec = rm._load_argspec(role, collection_path=collection_path)
    assert argspec['main']['short_description'] == 'Ansible foobar role'

    # Test role role list/

# Generated at 2022-06-22 18:52:15.666235
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    expected_value="test"
    actual_value=PluginNotFound(expected_value)
    assert actual_value.args[0] == expected_value



# Generated at 2022-06-22 18:52:26.616719
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # creating a mock data to pass for the method
    real_ansible_module_argument_spec = {
        'argument_spec': {
            'free_form': {'type': 'bool', 'required': False},
            'verbatim': {'type': 'bool', 'required': False}
            },
        'supports_check_mode': True
        }
    real_ansible_argument_spec = {
        'argument_spec': {
            'free_form': {'type': 'bool', 'required': False},
            'verbatim': {'type': 'bool', 'required': False}
            },
        'supports_check_mode': True
        }
    real_ansible_module_name = 'test_module'
    real_ansible_module_doc = 'test_doc'
    real_

# Generated at 2022-06-22 18:52:38.962529
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    file_path = 'collection/path/to/module_utils/module_name.py'
    assert DocCLI.namespace_from_plugin_filepath(file_path) == 'collection.path.to.module_utils.module_name'
    file_path = 'collection/path/to/module_utils/sub/sub_module_name.py'
    assert DocCLI.namespace_from_plugin_filepath(file_path) == 'collection.path.to.module_utils.sub.sub_module_name'
    file_path = 'collection/path/to/module_utils/sub/sub_module_name'
    assert DocCLI.namespace_from_plugin_filepath(file_path) == 'collection.path.to.module_utils.sub.sub_module_name'

# Generated at 2022-06-22 18:52:40.464830
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    display.display(PluginNotFound(display).args[0])


# Generated at 2022-06-22 18:52:44.132034
# Unit test for constructor of class DocCLI
def test_DocCLI():
    # Create an instance of class DocCLI
    clidocs = DocCLI()

    # Verify constructor creates instance of class DocCLI as expected
    assert isinstance(clidocs, DocCLI)


# Generated at 2022-06-22 18:52:52.477505
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():

    from ansible.module_utils.six.moves import shlex_quote

    # list of dicts with inputs and expected results for testcases, supported for filter_*

# Generated at 2022-06-22 18:53:01.978841
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    '''Unit test for method add_fields of class DocCLI'''
    class TestDocCLI(DocCLI):
        '''Test class for DocCLI'''
        def __init__(self):
            '''Test constructor'''
            self.tty_width = 80


# Generated at 2022-06-22 18:53:08.590779
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    """
    Test of method display_plugin_list of class DocCLI
    """
    args = dict()
    args['args'] = ['uri', 'ping',]
    args['type'] = 'module'
    args['verbosity'] = 0
    args['tree'] = False
    args['snippet'] = False
    args['show_snippet'] = False
    args['no_headers'] = False
    args['blacklist'] = None
    args['list_dir'] = False
    args['list_dir_path'] = None
    args['list_deprecated'] = False
    args['list_hidden'] = False
    args['list_toplevel'] = False
    args['list_extras'] = None
    args['scenarios'] = False
    args['scenarios_path'] = None
    args

# Generated at 2022-06-22 18:53:15.780975
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    arg_spec = dict(
        no_log=dict(),
        version=dict(default=False),
        roles_path=dict(default=list()),
        collections_paths=dict(default=list()),
    )
    mock_args = MagicMock(spec=argparse.Namespace)
    parser = DocCLI(arg_spec=arg_spec)
    parser.init_parser()
    parser.init_args(mock_args)
    parser.run()



# Generated at 2022-06-22 18:53:24.901644
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    cli = DocCLI()
    plugins = {
        'admin': ['vars', 'setup', 'command'],
        'cloud': ['vars', 'setup', 'command'],
        'clustering': ['vars', 'setup', 'command']
    }
    assert(cli.display_plugin_list(plugins) == (
        '\n    Plugins\n    -------\n    admin: command, setup, vars\n    cloud: command, setup, vars\n    clustering: command, setup, vars\n'))


# Generated at 2022-06-22 18:53:28.551627
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():

    import os

    doc_cli = DocCLI()
    doc_cli._get_doc('')
    doc_cli.get_man_text('')
    doc_cli.get_role_man_text('')
    doc_cli.get_filter_man_text('')


# Generated at 2022-06-22 18:53:36.375820
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    cls = DocCLI()
    cmdline = 'ansible-doc --json yum'
    command = cls.post_process_args(cmdline.split())
    assert '--json' in command.split()
    assert 'yum' in command.split()
    assert 'ansible-doc' in command.split()
    cmdline = 'ansible-doc --type action --name crm'
    command = cls.post_process_args(cmdline.split())
    assert '--type' in command.split()
    assert 'action' in command.split()
    assert 'ansible-doc' in command.split()
    assert '--name' in command.split()
    assert 'crm' in command.split()


# Generated at 2022-06-22 18:53:49.003075
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    from ansible.cli.doc import DocCLI
    
    doc_cli = DocCLI(None)
    options, args = doc_cli.post_process_args(None, {'module': [], 'module_path': [], 'module_paths': [], 'filter': [], 'check_conditional': []})
    assert options == {}
    assert args == []

    options, args = doc_cli.post_process_args(None, {'module': None, 'module_path': [], 'module_paths': [], 'filter': [], 'check_conditional': []})
    assert options == {}
    assert args == []


# Generated at 2022-06-22 18:53:54.488061
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Setup a dictionary argspec to call a method

    mock_runner = Mock()

    # Build an instance of a DocCLI object
    doc_cli = DocCLI(mock_runner, [])
    doc_cli.run()



# Generated at 2022-06-22 18:54:04.521528
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    import os
    import sys
    import tempfile
    import contextlib
    import shutil
    import ansible.utils.path
    import ansible.module_utils.facts.system.distribution

    # Since we are modifying the module path, we need to force the
    # module cache to be cleared.
    # pylint: disable=protected-access
    ansible.module_utils._MODULE_CACHE.clear()

    @contextlib.contextmanager
    def _tempdir():
        '''
        Return a temporary directory path and clean it up when done.
        Equivalent to tempfile.mkdtemp() with a context manager.
        '''
        tempdir = tempfile.mkdtemp()
        try:
            yield tempdir
        finally:
            shutil.rmtree(tempdir, ignore_errors=True)

# Generated at 2022-06-22 18:54:17.106413
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    import os
    import tempfile
    from collections import namedtuple

    FakeModule = namedtuple('FakeModule', 'ANSIBLE_METADATA')

    class FakeLoader():
        def get_basedir(self, path):
            base = os.path.dirname(path)
            if not base:
                base = '.'
            return base

        def get_real_filename(self, name):
            if name.startswith('/'):
                return name
            else:
                return os.path.dirname(pkg_resources.resource_filename(__name__, '__init__.py')) + '/../../' + name

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-22 18:54:28.669055
# Unit test for method run of class DocCLI

# Generated at 2022-06-22 18:54:37.129669
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Create mock for yaml_safe_load
    yaml_safe_load_mock = MagicMock()
    yaml_safe_load_mock.side_effect = lambda x: x
    # Replace static method yaml_safe_load with mock
    DocCLI.yaml_safe_load = yaml_safe_load_mock

    # Create mock for yaml_safe_dump
    yaml_safe_dump_mock = MagicMock()
    yaml_safe_dump_mock.side_effect = lambda x: x
    # Replace static method yaml_safe_dump with mock
    DocCLI.yaml_safe_dump = yaml_safe_dump_mock

    # Create mock for get_versioned_doclink
    get_versioned_doclink_mock = MagicMock()
   

# Generated at 2022-06-22 18:54:45.922030
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    hero = create_mocked_hero()
    DocCLI.init_parser(hero)

    # Check that the init_parser method iterate over all subclasses of BaseCLI
    for cli_class in BaseCLI.__subclasses__():
        cli_class_name = cli_class.__name__
        module_name = str(cli_class.__module__)
        module_name = module_name.replace('.', '_')

        assert hasattr(hero.parser, f"cmd_{module_name}_{cli_class_name}"), (
            f"missing command parser cmd_{module_name}_{cli_class_name} in init_parser method"
        )


# Generated at 2022-06-22 18:54:56.409167
# Unit test for function jdump
def test_jdump():
    from ansible.module_utils.six import PY3
    from io import BytesIO, StringIO

    for obj in [{'a': 1, 'b': [2, 3], 'c': ['d', {'e': 5}]},
                'test', 1, True, None]:
        out = BytesIO() if PY3 else StringIO()
        display.verbosity = 4
        display.set_b_meta('stdout')
        display.set_b_meta(out)
        jdump(obj)
        display.set_b_meta(None)
        display.set_b_meta('stdout')
        result = json.loads(out.getvalue().decode('utf-8')) if PY3 else json.loads(out.getvalue())
        assert result == obj



# Generated at 2022-06-22 18:55:01.420144
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound('There is no plugin with name %s' % "test")
    except PluginNotFound as e:
        assert e.args[0] == "There is no plugin with name %s" % "test"



# Generated at 2022-06-22 18:55:08.213388
# Unit test for function jdump
def test_jdump():
    import ansible.module_utils.facts
    test_data = ['some string', ansible.module_utils.facts.get_distribution]
    assert jdump(test_data) == '["some string", "ansible.module_utils.facts"]'
    test_data = [ansible.module_utils.facts.Distribution]
    assert jdump(test_data) == '["ansible.module_utils.facts.Distribution"]'



# Generated at 2022-06-22 18:55:10.999464
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc_obj = DocCLI()
    assert isinstance(doc_obj, DocCLI)


# Generated at 2022-06-22 18:55:14.282837
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    DocCLIObj = DocCLI()
    plugin_type = 'action'
    assert DocCLIObj.get_all_plugins_of_type(plugin_type) is None

# Generated at 2022-06-22 18:55:26.142585
# Unit test for function jdump
def test_jdump():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common.json import AnsibleJSONEncoder

    # Create a new stdout parameter and set it to a string.io object
    old_stdout = display.display._stdout
    display.display._stdout = StringIO()
    jdump({'test': 'list'})
    display.display._stdout.seek(0)
    stdout_buffer = display.display._stdout.read()
    display.display._stdout = old_stdout

    assert type(stdout_buffer) == str
    assert len(stdout_buffer) > 0
    assert stdout_buffer == json.dumps({'test': 'list'}, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)



# Generated at 2022-06-22 18:55:38.880258
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    if PY3:
        module_data = b'#!/usr/bin/python\n# This is an ansible module\n{\'version\': 1, \'msg\': \'foo\'}\n'
    else:
        module_data = '#!/usr/bin/python\n# This is an ansible module\n{\'version\': 1, \'msg\': \'foo\'}\n'

    plugin = DocCLI()
    io = StringIO(module_data)
    metadata = plugin.get_plugin_metadata(io, path='fake_module', name='fake_module.py')
    assert metadata.pop('filename') == 'fake_module.py'

# Generated at 2022-06-22 18:55:50.611699
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    display.verbosity = 3
    DocCLI.IGNORE = DocCLI.IGNORE + (context.CLIARGS['type'],)
    opt_indent = "        "
    text = []
    pad = display.columns * 0.20
    limit = max(display.columns - int(pad), 70)

    plugin_name = "helloworld"
    text.append("> %s    (%s)\n" % (plugin_name.upper(), ""))

    # Description
    if isinstance(text, list):
        desc = " ".join(text)
    else:
        desc = text

# Generated at 2022-06-22 18:55:56.097085
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    text = DocCLI.format_snippet([dict(a=1, b=2), dict(a=3, b=4, c=5)])
    assert_equal(text, '''- a: 1
  b: 2
- a: 3
  b: 4
  c: 5''')



# Generated at 2022-06-22 18:56:00.640182
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
	# Create instance of DocCLI
	doc_cli = DocCLI()
	# Test get_plugin_metadata(self, plugin_name, plugin_type, collection_name=None)
	# TODO: Test not implemented
	pass


# Generated at 2022-06-22 18:56:08.682135
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    from ansible.utils.color import stringc
    from ansible.cli import CLI
    from ansible.cli.arguments import optparse_helpers as opt_help
    DocCLI._return_parser = True
    cli = DocCLI()
    cli.init_parser()
    assert cli._parser.version == cli._version, "DocCLI.init_parser is broken for version"
    assert cli._parser._long_opt["version"] == cli._version, "DocCLI.init_parser is broken for version's value"
    assert cli._parser._short_opt["v"] == cli._version, "DocCLI.init_parser is broken for version's value"

# Generated at 2022-06-22 18:56:19.556614
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():

    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.module_utils._text import to_bytes

    # Create an object of class DocCLI
    doc = DocCLI()


# Generated at 2022-06-22 18:56:20.376431
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    DocCLI.init_parser()

# Generated at 2022-06-22 18:56:34.265935
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    from ansible.cli.doc import DocCLI
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_text
    s = DocCLI()
    # A base case
    assert "\n".join(s.get_role_man_text("ansible_role_foo", {'entry_points': {'main': {'options': {'bar': {'description': 'HELLO', 'required': False, 'choices': ['y', 'n']}}, 'description': 'An example role'}}})) == "> ANSIBLE_ROLE_FOO    ()\nENTRY POINT: main - An example role\n        \nOPTIONS (= is mandatory):\n        bar: HELLO (Default: null)\n"
    # A recursion case

# Generated at 2022-06-22 18:56:38.834397
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    plugin_filepath = 'my_awesome_plugin'
    expected_namespace = 'my_awesome'
    actual_namespace = DocCLI.namespace_from_plugin_filepath(plugin_filepath)
    assert actual_namespace == expected_namespace


# Generated at 2022-06-22 18:56:47.875521
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    from ansible.utils.plugin_docs import collect_plugin_docs
    docs = collect_plugin_docs()

# Generated at 2022-06-22 18:56:48.969771
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    add_collection_plugins(plugin_list, 'module')
    assert plugin_list



# Generated at 2022-06-22 18:56:52.177272
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    doc = DocCLI()
    parser = doc.init_parser()
    assert isinstance(parser, ArgumentParser)
    

# Generated at 2022-06-22 18:56:59.741464
# Unit test for function jdump
def test_jdump():
    # json.dumps() is a builtin, mock it to get full branch coverage
    import ansible.plugins.module_loader
    jdump_json_dumps = ansible.plugins.module_loader.json.dumps
    ansible.plugins.module_loader.json.dumps = lambda *args, **kwargs: "JSON_DUMPS_CALLED"
    assert jdump("test string") == "JSON_DUMPS_CALLED"
    ansible.plugins.module_loader.json.dumps = jdump_json_dumps



# Generated at 2022-06-22 18:57:11.953418
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():

    assert DocCLI.namespace_from_plugin_filepath('path/to/lib/ansible/module_utils/commoncloud/openstack/common.py') == 'module_utils.commoncloud'
    assert DocCLI.namespace_from_plugin_filepath('path/to/lib/ansible/modules/cloud/amazon/ec2_ami.py') == 'cloud.amazon'
    assert DocCLI.namespace_from_plugin_filepath('path/to/lib/ansible/modules/cloud/amazon/ec2_ami.py') == 'cloud.amazon'
    assert DocCLI.namespace_from_plugin_filepath('path/to/lib/ansible_collections/cloud/amazon/plugins/clients/ec2_client.py') == None
    assert DocCLI.namespace_from_plugin_

# Generated at 2022-06-22 18:57:20.107758
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # TODO: make sure not to write to the filesystem during unit testing (see #828)
    g = docs_fragment()

    ansible_module_doc = g.ansible_module_doc
    ansible_module_doc['doc'] = DocCLI.format_plugin_doc(ansible_module_doc['doc'])

# Generated at 2022-06-22 18:57:24.441983
# Unit test for constructor of class DocCLI
def test_DocCLI():
    my_cli = DocCLI()
    assert 'doc-ascii' == my_cli.doc_format
    _ = my_cli.pager()



# Generated at 2022-06-22 18:57:28.469421
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # Initialize object
    ansible_doc_obj = DocCLI()
    # Call method under test
    ansible_doc_obj.get_role_man_text("ansible-doc","ansible-doc")
    # Check results
    assert True

# Generated at 2022-06-22 18:57:34.169320
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with parameter: plugin_type, plugin_name
    plugin_type = 'lookup'
    plugin_name = 'vault'
    metadata = DocCLI.get_plugin_metadata(plugin_type, plugin_name)
    assert isinstance(metadata, dict) and metadata.get('author') == [u'Ansible Core Team']


# Generated at 2022-06-22 18:57:42.631562
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()

# Generated at 2022-06-22 18:57:53.955129
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    out = DocCLI.format_plugin_doc({"description": "This is the description.\nMore description to follow.\n",
                                    "options": {"test_opt": {"description": "This is the description of test_opt."}}})
    assert out == '''DESCRIPTION
  This is the description.
  More description to follow.
OPTIONS (= is mandatory)
  test_opt: This is the description of test_opt.
'''
    out = DocCLI.format_plugin_doc({"description": ["This is the description.\n", "\n", "More description to follow.\n"],
                                    "options": {"test_opt": {"description": "This is the description of test_opt."}}})

# Generated at 2022-06-22 18:57:56.494601
# Unit test for function jdump
def test_jdump():
    assert jdump('test') == json.dumps('test', cls=AnsibleJSONEncoder, sort_keys=True, indent=4)


# Generated at 2022-06-22 18:58:04.842491
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.utils.display import Display
    from ansible.utils.color import stringc

    display = Display()
    display.columns = 80

    path = os.path.join(os.path.dirname(__file__), 'cli', 'ansible-doc.txt')
    cli_plugin_doc = parse_docstring(path)
    cli_doc = DocCLI()
    cli_doc.get_doc(cli_plugin_doc)
    assert stringc('', cli_doc.get_doc(cli_plugin_doc), False).startswith('> ANSIBLE-DOC')


# Generated at 2022-06-22 18:58:11.341098
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc = {}

    spec_doc = {}
    # spec_doc['description'] = "Create, destroy, start and stop an instance in EC2."
    # spec_doc['options'] = {'wait': {'description': 'wait for the instance to be in state \'running\''},
    #                        'wait_timeout': {'description': 'how long before wait gives up', 'default': 300}}
    # doc['ec2'] = spec_doc

    spec_doc = {}
    spec_doc['description'] = 'Manage Elastic Block Store volumes.'
    doc['ec2_vol'] = spec_doc

    spec_doc = {}
    spec_doc['description'] = 'Manage elastic network interfaces.'

# Generated at 2022-06-22 18:58:21.939734
# Unit test for method run of class DocCLI

# Generated at 2022-06-22 18:58:31.549580
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    from .. import config
    from .. import constants
    from . import cliconfig
    import sys
    import os
    cliconfig.config = config.Config()
    DocCLI.base_parser(cliconfig.config.base_parser)
    DocCLI.base_parser(DocCLI.base_parser)
    DocCLI.base_parser(DocCLI.base_parser)
    DocCLI.get_man_text({})
    DocCLI.get_man_text({"description": "test", "options":{"foo":{"description":"test"}}})
    DocCLI.get_role_man_text("",{})
    DocCLI.add_fields([], {"description":"test"}, 70)
    DocCLI.add_fields([], {"description":"test"}, 70, "", return_values=False)


# Generated at 2022-06-22 18:58:42.517980
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 80
    opt_indent = "        "
    return_values = False
    options = OrderedDict()
    options['string_opt'] = OrderedDict()
    options['string_opt']['description'] = 'This is a string option.'
    text.append('%s%s: %s' % (opt_indent, 'string_opt',
                              textwrap.fill(DocCLI.tty_ify('This is a string option.'),
                                            limit - (len('string_opt') + 2),
                                            subsequent_indent=opt_indent)))
    options['list_opt'] = OrderedDict()
    options['list_opt']['description'] = 'This is a list option'

# Generated at 2022-06-22 18:58:52.176692
# Unit test for method add_fields of class DocCLI