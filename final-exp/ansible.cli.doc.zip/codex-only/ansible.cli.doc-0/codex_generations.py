

# Generated at 2022-06-22 18:48:54.309836
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    dc = DocCLI()
    data = {}
    dc.post_process_args(data)
    assert data == {}, 'Data unchanged'

    data = {'name': 'a_name'}
    dc.post_process_args(data)
    assert data == {'name': 'a_name'}

    data = {'name': 'a_name', 'doc': {'author': 'Test Author'}}
    dc.post_process_args(data)
    assert data == {'name': 'a_name', 'doc': {'author': 'Test Author'}}

    data = {'name': 'a_name', 'doc': {'author': 'Test Author'}, 'options': {'a_option': {'description': 'a_description', 'type': 'int'}}}

# Generated at 2022-06-22 18:49:06.678062
# Unit test for method format_snippet of class DocCLI

# Generated at 2022-06-22 18:49:08.078686
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    rm = RoleMixin()
    assert rm is not None


# Generated at 2022-06-22 18:49:12.402010
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    plugin_name = 'test_repo/roles/test_role/tasks/main.yml'
    assert DocCLI.namespace_from_plugin_filepath(plugin_name)[2] == 'tasks', 'Test for namespace_from_plugin_filepath fail'


# Generated at 2022-06-22 18:49:26.293461
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    from collections import namedtuple
    temp_args = namedtuple('args', ['type', 'url', 'list_dir', 'path', 'list_deprecated', 'list_collections', 'list_plugins', 'list_roles', 'list_all', 'list', 'search'])
    setattr(temp_args, 'path', 'path')
    setattr(temp_args, 'type', 'type')
    temp_args.type = 'type'
    temp_args.url = 'url'
    temp_args.list_dir = 'list_dir'
    temp_args.list = 'list'
    temp_args.search = 'search'
    temp_args.list_deprecated = 'list_deprecated'
    temp_args.list_collections = 'list_collections'
    # Call method
    doc

# Generated at 2022-06-22 18:49:37.653915
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    display.columns = 80
    doc = {'options': {'a': {'default': 'a', 'description': "This is a brief description.", 'version_added': '2.4'}}}
    displayed = DocCLI.get_man_text(doc, collection_name='', plugin_type='')
    assert displayed == """
\x1b[1m\x1b[37m>    ()\x1b[0m

\x1b[1m  OPTIONS (= is mandatory):\x1b[0m
        \x1b[1m* a\x1b[0m
          [Default: a]
          This is a brief description.
          added in: Ansible 2.4

\x1b[1m  RETURN VALUES:\x1b[0m
""".strip()



# Generated at 2022-06-22 18:49:50.058619
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # Test case 1
    text_data = []
    limit_value = 120
    opt_indent_value = '        '
    text_expected = []
    DocCLI.add_fields(text_data, [], limit_value, opt_indent_value, return_values=True)
    assert(text_expected == text_data)
    # Test case 2
    text_data = []
    limit_value = 120
    opt_indent_value = '        '
    text_expected = ['        > BASIC:']
    DocCLI.add_fields(text_data, [{'name': 'basic', 'required': True}], limit_value, opt_indent_value, return_values=True)
    assert(text_expected == text_data)
    # Test case 3
    text_data = []


# Generated at 2022-06-22 18:49:55.405050
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    """
    Test method 'get_plugin_metadata' of class 'DocCLI'
    """

    plugin = 'copy'
    type = C.DEFAULT_MODULE_PATH
    DocCLI.get_plugin_metadata(plugin, type)


if __name__ == '__main__':
    import sys

    if sys.argv[1] == 'get_plugin_metadata':
        DocCLI.get_plugin_metadata('copy','module')

# Generated at 2022-06-22 18:50:00.560163
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Prevent for function to display error: -e on the terminal
    context._init_global_context(['-T', 'doc'])
    # Get all plugins of type, if type is module
    plugins = DocCLI._get_all_plugins_of_type('module')
    assert type(plugins) == list

# Generated at 2022-06-22 18:50:01.624216
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()
    doc.display_plugin_list()
    assert(True)



# Generated at 2022-06-22 18:50:03.913207
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    pass



# Generated at 2022-06-22 18:50:16.556786
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    p = DocCLI()

# Generated at 2022-06-22 18:50:24.044052
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    docs = DocCLI()
    ansible_type = 'become_plugin'
    path_to_plugindir = pkg_resources.resource_filename("ansible", "plugins/%s" % ansible_type)
    (all_fqp_list, all_p_list) = docs.get_all_plugins_of_type(path_to_plugindir)
    assert all_fqp_list
    assert all_p_list

# Generated at 2022-06-22 18:50:34.127398
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    cli = DocCLI([])
    cli.base_parser = Mock()
    cli.base_parser.options = None
    cli.base_parser.args = None
    cli.base_parser.parser.get_prog_name = Mock()
    cli.base_parser.parser.get_prog_name.return_value = 'ansible'
    
    #Call the method
    cli.print_paths()
    
    #Check if the paths are correct
    ansible_module_data_path_default = 'PATH/TO/ansible_module_data'
    ansible_module_utils_path_default = 'PATH/TO/ansible_module_utils'
    ansible_module_plugins_path_default = 'PATH/TO/ansible_module_plugins'
    ansible_

# Generated at 2022-06-22 18:50:36.610743
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
  cli = DocCLI()
  assert cli.display_plugin_list( ) == None, 'Could not display the list of plugins'

# Generated at 2022-06-22 18:50:48.844877
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    module = AnsibleModule(
        argument_spec = dict(
            module = dict(required=False, type='str'),
            collection = dict(required=False, type='str'),
        ),
        supports_check_mode=True
    )

    # Create an instance of DocCLI
    doc_cli = DocCLI()
    # Execute the run() method of the DocCLI Class with the above args
    result = doc_cli.run(module.params)

    # Fail the module if the version was not set
    if not result.get('ansible_facts', {}).get('ansible_version'):
        module.fail_json(msg="ansible_version fact missing", ansible_facts=result['ansible_facts'])

    # Apply the exit JSON
    module.exit_json(**result)

# import module

# Generated at 2022-06-22 18:50:51.023604
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound('test')
    except PluginNotFound as e:
        assert str(e) == 'test'



# Generated at 2022-06-22 18:51:03.885788
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    doc_obj = object.__new__(RoleMixin)
    role_paths = [roles_path()]
    collection_paths = list_collection_dirs()
    all_roles = doc_obj._find_all_normal_roles(role_paths) | doc_obj._find_all_collection_roles(collection_filter=collection_paths)
    role_argspecs = {}
    for role in all_roles:
        if isinstance(role, tuple):
            if len(role) == 3:
                # collection roles
                role_argspecs[role[0]] = doc_obj._load_argspec(role[0], collection_path=role[2])
            else:
                # normal roles
                role_argspecs[role[0]] = doc_obj._load_argspec

# Generated at 2022-06-22 18:51:07.141497
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    class_rolemixin = RoleMixin()
    class_rolemixin._create_role_list()
    class_rolemixin._create_role_doc()


# Generated at 2022-06-22 18:51:20.062708
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # global return_values
    # global meta_docs
    # global module_docs
    # global role_docs
    # global is_collection
    # global cache_docs
    # global collection_name
    # global module_search_paths
    
    CLIRunner = CLIRunner(DocCLI())
    CLIRunner.test(['ansible-doc', '-l'])
    CLIRunner.test(['ansible-doc', '-M', '/tmp/ansible_test'])
    CLIRunner.test(['ansible-doc', '-M', '/tmp/ansible_test', 'ansible-test'])
    CLIRunner.test(['ansible-doc', '-M', '/tmp/ansible_test', 'ansible-test', '-L'])
    CL

# Generated at 2022-06-22 18:51:29.483596
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with a file that doesn't exist, only filename is provided
    results = DocCLI.get_plugin_metadata('does_not_exists.py')
    assert len(results) == 0

    # Test with a non-plugin module, expect empty dictionary
    results = DocCLI.get_plugin_metadata('DocCLI.py')
    assert len(results) == 0
    assert results == {}
    
    # Test with a module that has a docstring that doesn't meet the requirements
    # Expect empty dictionary
    results = DocCLI.get_plugin_metadata('pymysql/init.py')
    assert len(results) == 0
    assert results == {}

    # Test with a working module, expect results
    # Set context.CLIARGS to a dummy value. Otherwise a KeyError will be raised
    # Expect 6 elements

# Generated at 2022-06-22 18:51:39.893227
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    class Dummy():
        def __init__(self):
            self.foo = 'bar'
            self.bar = 'baz'
            self.baz = 'baz'
    dummy = Dummy()

    x = DocCLI()
    # Set dummy as parser
    x.parser = dummy
    # Call method
    x.init_parser()
    # Check if parser is a ArgumentParser
    assert isinstance(x.parser, ArgumentParser)
    # Check if all values are still set
    assert x.parser.bar == 'baz'
    assert x.parser.baz == 'baz'
    assert x.parser.foo == 'bar'

# Generated at 2022-06-22 18:51:52.869788
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # load test data
    with open(os.path.join(os.path.dirname(__file__), 'fixtures', 'DocCLI_find_plugins.yml')) as data_fp:
        data = yaml.load(data_fp)

    # test_DocCLI_find_modules(DocCLI(), data)
    dc = DocCLI()
    n = 0
    for item in data:
        n += 1
        uri = item.get('uri')
        if uri:
            dc.args = [uri]
        else:
            dc.args = []
        if not 'exception' in item:
            dc.find_plugins()
            # dc._display_plugins(dc.collection_name, dc.plugin_type, dc.plugins)

# Generated at 2022-06-22 18:51:56.675800
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    result = {}
    # assert or verify attribute
    assert result == ('Module %s' % item['module'])
    # assert or verify attribute
    assert result == ('Ansible documentation [%s]' % item['ref'])

# Generated at 2022-06-22 18:52:06.665185
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('/path/to/plugins/action/collections/ansible_collections/foo/bar.py') == 'ansible_collections.foo.bar'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/plugins/action/collections/ansible_collections/foo/bar/baz.py') == 'ansible_collections.foo.bar.baz'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/plugins/lookup/collections/ansible_collections/foo/bar/baz.py') == 'ansible_collections.foo.bar.baz'

# Generated at 2022-06-22 18:52:12.952945
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    from ansible.utils.collection_loader._collection_finder import get_collection_role_data
    test_coll = get_collection_role_data('test_collection_2')
    coll = test_coll['test_collection_2']
    coll_plugins = {}
    add_collection_plugins(coll_plugins, 'module')
    assert len(coll_plugins) == 1
    assert 'file' in coll_plugins



# Generated at 2022-06-22 18:52:16.508462
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    dcli = DocCLI()
    assert DocCLI.format_snippet(dcli.tty_ify('test with space')) == 'test with space\n'
    assert DocCLI.format_snippet(dcli.tty_ify('test with space'), True) == '    test with space\n'
    


# Generated at 2022-06-22 18:52:47.369254
# Unit test for method find_plugins of class DocCLI

# Generated at 2022-06-22 18:52:54.171527
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    test_plugins = [
        {'module': 'testmodule1'},
        {'module': 'testmodule2'},
        {'module': 'testmodule3'},
    ]
    assert 'testmodule1\ntestmodule2\ntestmodule3' == '\n'.join(DocCLI.display_plugin_list(test_plugins))


# Generated at 2022-06-22 18:52:57.452852
# Unit test for function jdump
def test_jdump():
    assert jdump('thing') == '"thing"'
    # This will fail, expected.
    assert jdump(object()) == '"thing"'



# Generated at 2022-06-22 18:53:03.123170
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    for type in ('action', 'become', 'cache', 'callback', 'connection', 'lookup', 'shell'):
        test_data = DocCLI.get_plugin_metadata(type)
        assert test_data.get('doc')
        assert test_data.get('filename')
        assert test_data.get('metadata')
        assert test_data.get('plainexamples')


# Generated at 2022-06-22 18:53:12.528970
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # prepare data
    plugin_type = 'action'
    plugins_collection = ['test.test_a', 'test.test_b']
    plugins_with_doc = ['test.test_a']
    columns = 10

    # prepare result
    expected_result = "\n".join(["  test.test_a    (Test A)", "  test.test_b    (Test B)", ""])

    # execute function
    doc_cli = DocCLI(display)
    result = doc_cli.display_plugin_list(plugin_type, plugins_collection, plugins_with_doc, columns)

    assert result == expected_result

# Generated at 2022-06-22 18:53:14.474955
# Unit test for function jdump
def test_jdump():
    jdump({'a': 'b'})
    jdump({'a': u'b'})



# Generated at 2022-06-22 18:53:16.303144
# Unit test for function jdump
def test_jdump():
    import json, sys
    try:
        json.dumps(sys, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)
    except TypeError:
        assert True



# Generated at 2022-06-22 18:53:19.558983
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    unittest.main(module='lib.doc_fragments', exit=False)

if __name__ == '__main__':
#    test_DocCLI_get_man_text()
    pass

# Generated at 2022-06-22 18:53:22.510331
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc_cli = DocCLI()
    assert doc_cli


# Generated at 2022-06-22 18:53:28.996674
# Unit test for function jdump
def test_jdump():
    '''
    Test that the jdump exits with a non-zero exit code when AnsibleError is raised
    '''
    from ansible.errors import AnsibleError
    try:
        jdump(None)
    except AnsibleError as e:
        if to_native(e).startswith('We could not convert all the documentation into JSON'):
            pass
        else:
            raise



# Generated at 2022-06-22 18:53:36.576865
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    filters = ['ansible_debug']
    plugin_list = {}

    plugin_list.update({'test': 'test'})
    plugin_list.update(DocCLI.find_plugins('test', False, 'lookup', collection='collection_test'))
    assert plugin_list['test'] == 'test'
    assert plugin_list['collection_test.lookup.test'] == 'test'
    add_collection_plugins(plugin_list, 'lookup', coll_filter=filters)


# This class uses a lot of instance and class variables, as we wanted to try to keep the
# code DRY with the modules/ and cli/ code bases.  We have a few tests, but they don't
# test everything.


# Generated at 2022-06-22 18:53:49.144546
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    argspec = argparse.ArgumentParser()
    DocCLI.setup_parser(argspec)
    argspec = argspec.parse_args([])

    context._init_global_context(args=argspec)
    pluginpath = utils.plugins.find_plugin(context.CLIARGS['type'], '', '', '', context.CLIARGS['name'])

    doc = DocCLI.load_plugin_doc(context.CLIARGS['type'], context.CLIARGS['name'], pluginpath)
    assert isinstance(doc, dict)
    plugin_type = doc.get('doc_type')
    assert isinstance(plugin_type, string_types)
    assert plugin_type == 'plugin'
    plugin_list = doc.get('plugin_list')

# Generated at 2022-06-22 18:53:58.246830
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    doc = """
    usage: ansible-doc [-h] [-M MODULE_PATH] [-l] [-s] [-t {action,become,cache,cliconf,connection,copy,database,debug,delegation,doc_fragments,inventory,lookup,network,packaging,parser,porting_guides,precedence,shell,strategy,test,web_infrastructure,windows,windows_compatibility,cloud,cloud_infrastructure,system,modules_extra,deprecated,galaxy,galaxy_deprecated,cli,collections,zoomba] | -d [-va] [name ...]]
        """

    parser = DocCLI.init_parser()
    assert parser is not None
    actual_usage = parser.format_usage()
    assert actual_usage == doc


# Generated at 2022-06-22 18:54:10.566258
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    import os
    import tempfile
    from ansibullbot.utils.path import get_ansible_base_path

    temp_dir = tempfile.mkdtemp(prefix='ansible_test_')
    ansible_base_path = ansible_base_dir = os.path.dirname(os.path.dirname(get_ansible_base_path()))

    # 1. Create the temp directory with empty files
    test_cmd = ('touch %s%s%s' % (temp_dir, os.sep, 'test2')).split()
    cmd_result = subprocess.run(test_cmd, stdout=subprocess.PIPE)

    test_cmd = ('touch {}/test1'.format(temp_dir)).split()

# Generated at 2022-06-22 18:54:23.512911
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    args = context.CLIARGS
    test_cli = DocCLI(args)

    # Test with doc_type as 'module'
    # test_cli.display_plugin_list(plugin_type='module', plugin_list=[])
    # test_cli.display_plugin_list(plugin_type='module', plugin_list=['uri', 'wait_for'])
    with pytest.raises(SystemExit):
        test_cli.display_plugin_list(plugin_type='module', plugin_list=['await', 'ssh'])

    # Test with doc_type as 'callback'
    # test_cli.display_plugin_list(plugin_type='callback', plugin_list=[])
    # test_cli.display_plugin_list(plugin_type='callback', plugin_list=['mail', 'log'])
   

# Generated at 2022-06-22 18:54:34.556119
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-22 18:54:39.748535
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    snippet = {'name': 'default_name',
        'description': 'A description',
        'plugin_type': 'action|modules'}
    assert DocCLI.format_snippet(snippet) == 'default_name (action/modules)\nA description'

# Generated at 2022-06-22 18:54:53.158395
# Unit test for method run of class DocCLI
def test_DocCLI_run():  # lgtm [py/test-only]
    doc = DocCLI(args=['ansible.builtin.debug', '--verbose'])
    doc.run()
    doc = DocCLI(args=['ansible.builtin.debug'])
    doc.run()
    doc = DocCLI(args=['ansible.builtin.ping', '--no-verbose'])
    doc.run()
    doc = DocCLI(args=['ansible.builtin.ping', '--no-verbose', '--version'])
    doc.run()
    doc = DocCLI(args=['ansible.builtin.ping', '--no-verbose', '--help'])
    doc.run()

# Generated at 2022-06-22 18:54:56.772995
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    test_plugin_name = 'module'
    test_error_string = 'No plugin named module was found in any of the configured plugin paths'

    try:
        raise PluginNotFound(test_plugin_name)
    except PluginNotFound as e:
        assert str(e) == test_error_string



# Generated at 2022-06-22 18:54:57.466392
# Unit test for constructor of class DocCLI
def test_DocCLI():
    assert DocCLI()

# Generated at 2022-06-22 18:55:11.058168
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-22 18:55:13.604920
# Unit test for function jdump
def test_jdump():
    assert json.loads(jdump({u'foo': u'bar'})) == {u'foo': u'bar'}



# Generated at 2022-06-22 18:55:20.115549
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    from ansible.utils.display import Display
    display = Display()
    display.columns = 80

    type_cache = TypeCache()
    doc_cli = DocCLI([], 'doc', {}, [], [], [], False, False, False, False, False, type_cache, display)
    doc_cli.find_plugins()

    # FIXME: This should really be a unit test.


# Generated at 2022-06-22 18:55:32.846064
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    #
    # Create a new instance of DocCLI
    dc = DocCLI()
    # Values for testing method format_snippet
    text = '- name: Create file\n\n  # This example is missing a hyphen.  It should be ignored.\n\n  template: src=somefile.j2 dest=/etc/foo.conf\n\n'
    regexp = re.compile(r'^\s*-\s')
    lines = text.splitlines()
    results = []
    # Execute method format_snippet
    results.append(dc.format_snippet(text, 'yaml', regexp, 4, lines))
    results.append(dc.format_snippet(text, 'json', regexp, 4, lines))
    # Check for expected results

# Generated at 2022-06-22 18:55:45.571735
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # The path to a plugin file
    plugin_filepath = u'/var/lib/awx/venv/ansible/lib/python3.6/site-packages/ansible/plugins/inventory/yaml.py'
    # We expect the namespace of the file to be 'inventory'
    expected_namespace = u'inventory'
    # Namespace of the plugin file
    actual_namespace = DocCLI.namespace_from_plugin_filepath(plugin_filepath)
    # Check if both are same
    assert expected_namespace == actual_namespace
    # If everything went OK
    print('OK')

if __name__ == '__main__':
    # Get and store the CLI arguments
    context.CLIARGS = DocCLI().parse()
    # Unit test for method namespace_from_plugin_filepath of

# Generated at 2022-06-22 18:55:59.191592
# Unit test for constructor of class DocCLI
def test_DocCLI():
    from ansible.module_utils.six import StringIO
    from ast import literal_eval
    from collections import defaultdict

    # Process arguments
    argument_spec = dict(
        format=dict(default='man', choices=['json', 'yaml', 'md', 'rst', 'txt', 'man']),
        all=dict(type='bool', default=False),
        collection=dict(default="ansible_collections.ansible.builtin"),
        source=dict(default=''),
        type=dict(choices=['module', 'plugin', 'doc_fragments', 'module_utils'], default='module'),
        name=dict(default=''),
        docs=dict(type='bool', default=False)
    )

    # Use the doc_fragments fixture instead of collection.ansible_collections.ans

# Generated at 2022-06-22 18:56:08.001687
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    from ansible import context
    from ansible.module_utils.six import StringIO
    from ansible.utils.display import Display
    from ansible.cli import CLI
    from ansible.cli.doc import DocCLI
    cli = CLI(
        ["ansible-doc", "-t", "module", "nginx"],
        None,
        'ansible-doc',
        None
    )
    context.CLIARGS = cli.parse()
    display = Display()
    display.verbosity = 3
    doccli = DocCLI(cli, display)
    doccli.get_doc()
    orig_stdout = sys.stdout
    try:
        sys.stdout = StringIO()
        doccli.display_plugin_list()
    except Exception as my_exception:
        traceback.print_

# Generated at 2022-06-22 18:56:13.442930
# Unit test for function jdump
def test_jdump():
    try:
        test_hash = {'test': '1234', 'abc': 'xyz'}
        assert json.loads(jdump(test_hash)) == test_hash
    except (TypeError, AssertionError):
        pytest.fail('jdump did not process the test hash correctly')



# Generated at 2022-06-22 18:56:21.233480
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    lib_path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/modules')
    modules = DocCLI.find_plugins(lib_path, True, 'module')
    assert isinstance(modules.popitem()[0], tuple)
    assert modules.popitem()[0] == ('meta', 'meta')

    lib_path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/action')
    modules = DocCLI.find_plugins(lib_path, True, 'action')
    assert isinstance(modules.popitem()[0], tuple)
    assert modules.popitem()[0] == ('meta', 'meta')


# Generated at 2022-06-22 18:56:31.055065
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    plugin_name = 'module'
    assert type(DocCLI.get_all_plugins_of_type(plugin_name)) ==  list
    plugin_name = 'module'
    assert type(DocCLI.get_all_plugins_of_type(plugin_name, show_hidden=False)) ==  list
    plugin_name = 'module'
    assert type(DocCLI.get_all_plugins_of_type(plugin_name, collection_name='ansible.builtin')) ==  list

# Generated at 2022-06-22 18:56:33.134543
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc = DocCLI()
    assert True == doc.run()

# Generated at 2022-06-22 18:56:39.221005
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
  # Test is currently skipped as it is known to fail until the function is finished
  # See https://github.com/ansible/ansible/issues/63537
  # remove this line when the function is finished
  raise NotImplementedError
  list = {}
  DocCLI.add_collection_plugins(list, 'module')


# Generated at 2022-06-22 18:56:48.087839
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import add_all_plugin_dirs, find_plugin
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.display import Display
    import ansible.core.collection_loader
    import ansible.core.collection
    import ansible.core.plugins.loader
    import ansible.core.plugins.action
    import ansible.core.plugins.cliconf
    import ansible.core.plugins.connection
    import ansible.core.plugins.filter
    import ansible.core.plugins.lookup
    import ansible.core.plugins.module_build_utils
    import ansible.core.plugins.module_utils
    import ansible.core.plugins.vars

    add

# Generated at 2022-06-22 18:56:49.703265
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    paths = ['hello', 'world']
    #
    output = DocCLI.print_paths(paths)
    assert output == 'hello\nworld'


# Generated at 2022-06-22 18:56:54.093183
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    r = RoleMixin()
    assert r._ROLE_ARGSPEC_FILES == ['argument_specs' + e for e in C.YAML_FILENAME_EXTENSIONS] + ["main" + e for e in C.YAML_FILENAME_EXTENSIONS]



# Generated at 2022-06-22 18:56:54.686120
# Unit test for constructor of class DocCLI
def test_DocCLI():
    d = DocCLI()


# Generated at 2022-06-22 18:57:06.402822
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-22 18:57:16.442018
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():

    # [{'name': 'action', 'doc': '', 'required': True, 'type': 'str', 'choices': ['add', 'remove'], 'default': 'add'}, {'name': 'src', 'doc': '', 'required': True, 'type': 'str'}, {'name': 'local', 'doc': '', 'type': 'bool', 'default': False}, {'name': 'remote', 'doc': '', 'type': 'bool', 'default': False}]
    # [{'name': 'src', 'doc': '', 'required': True, 'type': 'str'}]

    # Arrange
    doccli_instance = DocCLI()
    result = list()

    # Act

# Generated at 2022-06-22 18:57:17.134756
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    pass



# Generated at 2022-06-22 18:57:22.092022
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-22 18:57:34.211082
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    # Testing with an invalid sub command
    # Commented out since we don't want the docs to show up in -vvvv mode
    # assert(DocCLI(args=['ansible-doc', '-vvvv', 'foobar', '--list'], output_dir='./test/testout', verbosity=4).post_process_args() is False)

    # Testing with valid sub commands
    assert(DocCLI(args=['ansible-doc', '-vvvv', '--', 'foobar', '--list'], output_dir='./test/testout', verbosity=4).post_process_args() is True)

# Generated at 2022-06-22 18:57:43.857333
# Unit test for method get_plugin_metadata of class DocCLI

# Generated at 2022-06-22 18:57:50.525811
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    class Tester(RoleMixin):
        pass
    t = Tester()
    assert t.ROLE_ARGSPEC_FILES == ['argument_specs' + e for e in C.YAML_FILENAME_EXTENSIONS] + ["main" + e for e in C.YAML_FILENAME_EXTENSIONS]



# Generated at 2022-06-22 18:58:02.103628
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    assert DocCLI.post_process_args('foo') == 'foo'
    assert DocCLI.post_process_args('foo', '--other') == 'foo'
    assert DocCLI.post_process_args('foo', '--other', '--type') == 'foo'
    assert DocCLI.post_process_args('foo', '--type', 'module') == 'foo'
    assert DocCLI.post_process_args('foo', '--type', 'module', '--other') == 'foo'
    assert DocCLI.post_process_args('foo', '--type', 'module', '--action-plugin') == 'foo.action'
    assert DocCLI.post_process_args('foo', '--type', 'module', '--action-plugin', '--other') == 'foo.action'

# Generated at 2022-06-22 18:58:14.366022
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-22 18:58:27.207220
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Unit test for method get_plugin_metadata of class DocCLI
    # Example of dictionary data to be passed to the plugin
    # The data is in the format of key value pairs
    # The return value is expected to be of type string
    data = {"path": "library/cloud/amazon/aws.py",
            "name": "aws",
            "version_added": "2.4"}
    # expected output
    expected_output = "{'aws': {'version_added': '2.4', 'path': 'library/cloud/amazon/aws.py'}}"
    # Create an object DocCLI class
    session_object = DocCLI()

    # Invoke the function get_plugin_metadata of class DocCLI with the data and return value
    actual_output = session_object.get_plugin_metadata(data)

    #

# Generated at 2022-06-22 18:58:34.640688
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    '''test function for post_process_args of class DocCLI'''

    # Function to test DocCLI.post_process_args
    # test fixture
    # initialise DocCLI with `arg_data` as args
    # expected output is
    # 1. validate `output` data with `expected_data`
    # 2. test for `exception` (if any)
    # 3. validate the output args with `output_args` data

    # test fixture: testcases
    # testcases is an array of objects
    # Each object has a 'name', 'input', 'expection' and 'output'
    # 'name' is the name of the testcase,
    # 'input' is the input arguments to function,
    # 'expection' is the expected exceptions in running the testcase,
    # 'output' is the expected

# Generated at 2022-06-22 18:58:45.535553
# Unit test for method run of class DocCLI
def test_DocCLI_run():

    # Case:
    #  No arguments

    # Desired result:
    #  print doc for modules and min_ansible_version

    # Arrangement:
    #  create DocCLI

    # Action:
    #  call run of DocCLI

    # Assert:
    #  assertion function is called with 'doc_fragment', 'min_ansible_version'

    with patch.object(DocCLI,'_get_doc') as mock_get_doc:
        DocCLI().run()

    mock_get_doc.assert_any_call('doc_fragment')
    mock_get_doc.assert_any_call('min_ansible_version')
