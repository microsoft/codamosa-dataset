

# Generated at 2022-06-22 18:48:57.991770
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    role_mixin = RoleMixin()

    test_data = {'test_role': {'description': 'Test Role Description',
                               'entry_points': {
                                    'main': {
                                        'description': 'Help text for main entry point',
                                        'required_one_of': ['arg1']
                                    },
                                    'alternate': {
                                        'description': 'Help text for alternate entry point',
                                        'required_one_of': ['arg2', 'arg3']
                                    }
                                }}}

    class TestRole(Role):
        pass

    TestRole.__init__ = lambda s: 0
    TestRole._load_role_data = lambda s, p: test_data


# Generated at 2022-06-22 18:48:58.734645
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    assert False



# Generated at 2022-06-22 18:49:04.075984
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    field_list = ['notes', 'seealso', 'requirements', 'options', 'extends_documentation_fragment', 'plainexamples',
                  'returndocs', 'version_added', 'version_added_collection']
    return True



# Generated at 2022-06-22 18:49:11.532459
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    module_name = 'set_fact'
    # Load the plugin
    plugin_loader = PluginLoader(
        'ActionModule',
        '_',
        C.DEFAULT_INVENTORY_PLUGINS_PATH,
        'inventory',
    )

    module = plugin_loader.get(module_name)

    # Call the format_plugin_doc method
    formatted_plugin_doc = DocCLI.format_plugin_doc(module)

    # Test the newly formatted doc
    assert module_name in formatted_plugin_doc, "Module name not in new doc"

# Generated at 2022-06-22 18:49:25.699115
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    # Setup argument strings
    args = [
        '--version',
        '--help',
        '--list',
        '--extract-documentation',
        '-vvvv',
        '-vvvvv',
        '--path',
        '-h',
        '-t',
        '-p',
        '-l',
        '-x',
        'docs',
        'MyModule',
        '-k',
        '-f',
        '-v',
        '-vv',
        '-vvv',
        '-vvvv',
    ]

    # Run test
    # This is more to test for bad input and make sure an exception
    # isn't raised.
    result = DocCLI.post_process_args(args)
    assert isinstance(result, list)

# Unit

# Generated at 2022-06-22 18:49:37.733348
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    def testcase(desc, arguments, expected):
        actual = DocCLI().init_parser(arguments.split())
        assert actual == expected, '%s failed: %s != %s' % (desc, actual, expected)
    #
    # Basic test
    testcase('Basic', '', {})

    #
    # Simple test
    testcase('Simple', '-M.', {'module_dir': '.'})
    testcase('Simple', '-M .', {'module_dir': '.'})
    testcase('Simple', '-M ./foo', {'module_dir': './foo'})

    #
    # Long test
    testcase('Long', '--module-dir=.', {'module_dir': '.'})

# Generated at 2022-06-22 18:49:50.124661
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    parser = DocCLI(
        ['ansible-doc', '--version'],
        prog='ansible-doc',
        module=None,  # needed
        usage="""ansible-doc [options] module ...""",
    )

    parser.setup_parser()
    parser.read_cli_args()
    context.CLIARGS = parser.options

    doc = parser._load_doc(
        os.path.join(fixture_path, 'modules', 'ping.py'),
        'ping',
        ['ping.py', None]
    )

    assert DocCLI.format_snippet(doc, 'BAD_FLAG') == '<SKIPPED: unsupported>'


# Generated at 2022-06-22 18:50:00.658497
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'action'
    coll_filter = ['testcollect', 'testcollect2']

    # TODO: take into account runtime.yml once implemented
    b_colldirs = list_collection_dirs(coll_filter=coll_filter)
    for b_path in b_colldirs:
        path = to_text(b_path, errors='surrogate_or_strict')
        collname = _get_collection_name_from_path(b_path)
        ptype = C.COLLECTION_PTYPE_COMPAT.get(plugin_type, plugin_type)
        plugin_list.update(DocCLI.find_plugins(os.path.join(path, 'plugins', ptype), False, plugin_type, collection=collname))

# Generated at 2022-06-22 18:50:10.230266
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # Remove the if statement when we extend the test case to include collections
    if os.path.exists('../test/units/test_utils/test_doc_files/test_doc_modules.py'):
        doc, name, plugin_type, collection_name, _ = DocCLI._load_doc('../test/units/test_utils/test_doc_files/test_doc_modules.py')
        display.display(DocCLI.get_man_text(doc, collection_name=collection_name, plugin_type=plugin_type))

# Generated at 2022-06-22 18:50:21.478490
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    plugin_type = "action"
    options = {'_load_plugins': mock.Mock(return_value=['win_acl'])}
    with mock.patch.object(plugin_loader, 'PluginLoader',
                           spec=plugin_loader.PluginLoader) as MockedClass:
        instance = MockedClass.return_value
        instance.all.return_value = {}
        instance.is_subclass.return_value = True
        instance.has_plugin.return_value = True
        c = DocCLI(options, plugin_type)
        res = c.find_plugins()
        instance.is_subclass.assert_called_with(action_loader.ActionModule)
        instance.has_plugin.assert_called_with('win_acl')
        assert instance.all.call_count == 1

# Generated at 2022-06-22 18:50:24.044330
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound('foo')
    except PluginNotFound as e:
        assert str(e) == 'foo'



# Generated at 2022-06-22 18:50:27.815316
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    # instantiate module
    doc = DocCLI()
    # init_parser()

    with pytest.raises(SystemExit) as cm:
        doc.init_parser()


# Generated at 2022-06-22 18:50:29.663087
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc = DocCLI()
    assert isinstance(doc, DocCLI)


# Generated at 2022-06-22 18:50:35.976564
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    assert "CHECKOUT:   <\u001b[m" in DocCLI.add_fields(None, [{'choices': ['normal', '<', '>'], 'default': 'normal', 'description': ['Checkout mode to use'], 'name': 'mode', 'required': False}], max(display.columns - int(display.columns * 0.20), 70), '    ')



# Generated at 2022-06-22 18:50:45.902759
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    a = DocCLI()
    b = DocCLI()

    try:
        a.get_role_man_text(b, b)
        assert False, "No exception thrown"
    except DocCLIError as e:
        assert "Invalid parameters provided" in to_text(e)

    a = {'a': 'b'}
    b = DocCLI()
    try:
        b.get_role_man_text(a, a)
        assert False, "No exception thrown"
    except DocCLIError as e:
        assert "Invalid parameters provided" in to_text(e)



# Generated at 2022-06-22 18:50:48.982425
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    cli_args = DocCLI.post_process_args(['-M', 'no_exist'])
    assert cli_args == {'module_path': 'no_exist'}



# Generated at 2022-06-22 18:51:00.770225
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    '''test_DocCLI_format_plugin_doc()'''

    # Man page formatting
    try:
        # pylint: disable=unused-import
        import manpages
    except ImportError:
        pass
    else:
        # pylint: disable=protected-access
        # pylint: disable=bare-except
        # pylint: disable=no-member
        try:
            import manpages1
        except:
            import manpages2
        else:
            core_manpages = manpages1
        # pylint: enable=no-member
        # pylint: enable=bare-except
        # pylint: enable=protected-access
        # pylint: enable=unused-import
        doc_generator = DocCLI(None, None)
        # pylint:

# Generated at 2022-06-22 18:51:04.624328
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('/test/test/test/test/test.py') == 'test.test.test.test'

# Generated at 2022-06-22 18:51:17.469716
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    ansible_doc = """
    - name: This is a name
      description: This is a description
      author: Me
      version_added: "2.8"
      options:
        name:
            required: true
            default: default_value
            choices:
                - choice1
                - choice2
                - choice3
                - choice4
            aliases: [ 'alias1', 'alias2', 'alias3' ]
            description:
                - This is a description
      plainexamples: |
            Here are some examples
    """
    doc = DocCLI.format_plugin_doc(ansible_doc)

    assert doc['name'] == 'This is a name'
    assert doc['description'] == 'This is a description'
    assert doc['author'] == 'Me'

# Generated at 2022-06-22 18:51:18.711090
# Unit test for constructor of class DocCLI
def test_DocCLI():
    pass


# Generated at 2022-06-22 18:51:28.901663
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    snippet = DocCLI.format_snippet('vars', {
        'title': 'Insert a snippet from a file',
        'description': ['This is a sample description for the snippet'],
        'arguments': {
            'path': {
                'type': 'path',
                'description': 'The path to the file to read',
                'required': True
            },
            'section': {
                'type': 'string',
                'description': 'The section of the file to return',
                'required': False
            }
        },
        'examples': [
            'path: foo.csv',
            'section: bar'
        ]
    }, True)

# Generated at 2022-06-22 18:51:34.685573
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugins = {}
    coll_filter = AnsibleCollectionRef('foo.bar')
    add_collection_plugins(plugins, 'action', coll_filter)
    assert placements.collection_local_path(coll_filter) in to_text(plugins.values())



# Generated at 2022-06-22 18:51:44.212657
# Unit test for method namespace_from_plugin_filepath of class DocCLI

# Generated at 2022-06-22 18:51:45.429179
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    assert PluginNotFound('')



# Generated at 2022-06-22 18:51:57.950531
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    module_choices = {'1': 'module', 'action': 'action', '2': 'CLI', 'connection': 'connection', '3': 'lookup', '4': 'callback', '5': 'filter', '6': 'shell', '7': 'test', '8': 'strategy', '9': 'inventory', '10': 'vars', '11': 'netconf', '12': 'terminal', '13': 'vault'}
    doc_obj = DocCLI(module_choices)

# Generated at 2022-06-22 18:52:08.672552
# Unit test for function add_collection_plugins
def test_add_collection_plugins():

    # Create test collection directory
    path = '/tmp/test_collection'
    os.mkdir(path)
    os.mkdir(os.path.join(path, 'plugins'))
    os.mkdir(os.path.join(path, 'plugins', 'module_utils'))

    # Create test module
    os.mkdir(os.path.join(path, 'plugins', 'modules', 'win'))
    with open(os.path.join(path, 'plugins', 'modules', 'win', 'dummy.ps1'), 'w') as f:
        pass

    # Create test module_utils
    os.mkdir(os.path.join(path, 'plugins', 'module_utils', 'win_dummy_module_utils'))

# Generated at 2022-06-22 18:52:13.416319
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc = {
        'module': 'test',
        'short_description': 'test module',
        'description': 'This is a test module',
        'version_added': '2.5',
        'options': {
            'testarg': {
                'description': 'This is a test argument',
                'required': True,
                'type': 'bool'
            }
        },
        'extends_documentation_fragment': [ 'boolean_options', 'arguments_as' ]
    }
    result = DocCLI().get_man_text(doc)
    print(result)


# Generated at 2022-06-22 18:52:17.591982
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound()
    except PluginNotFound as e:
        assert isinstance(e, PluginNotFound)


# Generated at 2022-06-22 18:52:26.434600
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    fixture = DocCLI()
    fixture.args = {'yaml': False, 'aliases': False, 'no_log': False, 'simple': False, 'role': False, 'collections': False, 'deprecated': False, 'changelogs': True, 'changelog': True}
    expected = {'yaml': False, 'aliases': False, 'no_log': False, 'simple': False, 'role': False, 'collections': False, 'deprecated': False, 'changelogs': True, 'changelog': True}
    result = fixture.post_process_args()
    assert isinstance(result, dict)
    assert result == expected


# Generated at 2022-06-22 18:52:34.975829
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'connection'
    coll_filter = './ansible_collections/santosh_s'
    out = add_collection_plugins(plugin_list, plugin_type, coll_filter=None)
    assert out == None
    expected = {
        'ansible_collections.santosh_s.plugins.connection.network_os': 'ansible_collections/santosh_s/plugins/connection/network_os.py',
    }
    assert expected == out


# Generated at 2022-06-22 18:52:40.018158
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    class RoleMixinTester(RoleMixin):
        def __init__(self):
            super(RoleMixinTester, self).__init__()
    try:
        RoleMixinTester()
    except TypeError:
        raise Exception('RoleMixinTester: unexpected constructor exception')
test_RoleMixin()



# Generated at 2022-06-22 18:52:47.448852
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    doc = DocCLI()

    # Make sure empty plugin_list will be updated
    plugin_list = {}
    doc.add_collection_plugins(plugin_list, 'module')
    assert plugin_list

    # Make sure invalid plugin_type won't be appended
    plugin_list = {}
    doc.add_collection_plugins(plugin_list, 'keyword')
    assert not plugin_list


# FIXME: merge with doc/module_utils/module_docs_fragments/common.py
#        and doc/module_utils/module_docs_fragments/module.py

# Generated at 2022-06-22 18:52:50.038903
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    DocCLI.add_fields([""], {'m':'module'}, 80, "        ")
    assert "> MODULE    (filename)\n" in text
    assert "OPTIONS (= is mandatory):\n" in text
    assert "m: module" in text
    assert "ATTRIBUTES:\n" in text
    assert len(text) == 4


# Generated at 2022-06-22 18:52:52.685822
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
  # Testing the add_fields method of class DocCLI
    DocCLI.add_fields()

# Generated at 2022-06-22 18:52:56.119293
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound
    except PluginNotFound:
        pass



# Generated at 2022-06-22 18:52:59.228071
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    class RoleMixinSubclass(RoleMixin):
        pass
    r = RoleMixinSubclass()
    assert r  # just need to create it to verify it doesn't blow up


# Generated at 2022-06-22 18:53:06.856958
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    from ansible.utils.display import Display
    display = Display()
    display.columns = 80

    d = DocCLI()

# Generated at 2022-06-22 18:53:10.090142
# Unit test for function jdump
def test_jdump():
    assert jdump({'x':['hello', 'world']}) == '{\n    "x": [\n        "hello", \n        "world"\n    ]\n}'

# Generated at 2022-06-22 18:53:12.094645
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():

    doccli = DocCLI()

    test_parser = doccli.init_parser()

    assert isinstance(test_parser, argparse.ArgumentParser)


# Generated at 2022-06-22 18:53:22.260314
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doccli = DocCLI()
    opt_indent = "        "

    # test aws_ec2 module

# Generated at 2022-06-22 18:53:29.282188
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test if exception is raised when there are any arguments.
    # The method display_plugin_list of class DocCLI accepts no arguments.
    with pytest.raises(TypeError):
        DocCLI.display_plugin_list("foo")

    # Test for valid call without arguments.
    # Call method display_plugin_list of class DocCLI without arguments.
    DocCLI.display_plugin_list()


# Generated at 2022-06-22 18:53:35.589099
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Create a test object
    doc_obj = DocCLI()
    # Get a plugin type
    plugin_type = 'connection'
    # Get the metadata for the plugin
    plugin_meta = doc_obj.get_plugin_metadata(plugin_type)
    # Check that the returned value is correct
    assert plugin_meta['name'] == 'local'
    assert plugin_meta['collection_name'] == 'ansible.builtin'


# Generated at 2022-06-22 18:53:40.926970
# Unit test for constructor of class DocCLI
def test_DocCLI():
    '''Unit test for constructor of class DocCLI.'''
    # Test creation of instance DocCLI
    test_doccli_object = DocCLI()
    assert isinstance(test_doccli_object, DocCLI)



# Generated at 2022-06-22 18:53:44.497753
# Unit test for function jdump
def test_jdump():
    assert jdump(dict(key = "value")) == json.dumps(dict(key = "value"), cls=AnsibleJSONEncoder, sort_keys=True, indent=4)



# Generated at 2022-06-22 18:53:50.997974
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = {'description': 'This is a test', 'options': 'This is also a test'}
    cli = DocCLI()
    assert cli.get_man_text(doc) == '> THIS IS A TEST    ( )\nThis is a test\n\nOPTIONS (= is mandatory):\n        This is also a test\n\n'
    

# Generated at 2022-06-22 18:53:58.531418
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    assert DocCLI.format_snippet('abc') == 'abc'
    assert DocCLI.format_snippet('    abc') == '    abc'
    assert DocCLI.format_snippet('abc', '    ') == '    abc'
    assert DocCLI.format_snippet('    abc', '    ') == '        abc'


# Generated at 2022-06-22 18:54:03.798249
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    """
    DocCLI.print_paths() unit test
    """
    temp_config = context.CLIARGS
    temp_config.update({
            'type': 'collection',
            'paths': [],
            'paths_extended': [],
        })
    doc = DocCLI(temp_config)
    doc.print_paths()

# Generated at 2022-06-22 18:54:16.307559
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():

    # Establish docParser object
    docParser = DocCLI()

    # Create test parser object
    test_parser = argparse.ArgumentParser(
        prog='test_prog',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=__doc__
    )

    # Run method to test
    test_parser = docParser.init_parser(test_parser)

    # Assert that test_parser.description is set
    assert test_parser.description is not None

    # Assert that test_parser contains format option
    assert '--format' in vars(test_parser.parse_args([]))

    # Assert that test_parser contains no_log option
    assert '--no-log' in vars(test_parser.parse_args([]))

    # Assert that test_parser contains

# Generated at 2022-06-22 18:54:28.025117
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():

    # Test for '#' in content and use a dict as input to format_snippet
    content = [
        {
            'description': 'Gets a list of resources',
            'snippet': [
                '# Gets a list of resources',
                'az resource list --resource-group myresourcegroup'
            ]
        },
        {
            'description': 'Gets a list of resource groups',
            'snippet': [
                '# Gets a list of resource groups',
                'az group list'
            ]
        }
    ]
    result = DocCLI.format_snippet(content)

# Generated at 2022-06-22 18:54:33.396474
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    res = DocCLI.print_paths(['win_ping'], json=True)
    assert isinstance(res, dict)
    assert res['win_ping'].endswith('.win_ping')

    res = DocCLI.print_paths('win_ping')
    assert isinstance(res, string_types)
    assert res.endswith('.win_ping')


# Generated at 2022-06-22 18:54:38.002835
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list={'a':'A'}
    origin_list=plugin_list.copy()
    add_collection_plugins(plugin_list, 'action')
    assert plugin_list != origin_list



# Generated at 2022-06-22 18:54:49.021557
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    '''
    Unit test for method run of class DocCLI
    '''
    print("Testing method run of class DocCLI")
    mock = MagicMock(return_value = None)
    with patch.object(DocCLI, '_doc_fragment', mock) as me:
        with patch.object(display, 'columns', 80) as display_columns:
            obj = DocCLI(args=['--help'])
            obj.run()
            mock.assert_called_with(plugin_type='module', mod_type=None)
            assert display_columns == 80


# Generated at 2022-06-22 18:54:58.833828
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():

    # Create a mock for the required input parameters
    argv = ['ansible-doc', '-t', 'module']
    # Set up object
    doc = DocCLI(args=argv)

    # Test actual function
    import os
    import glob
    plugin_type = 'module'
    base_path = os.path.dirname(os.path.realpath(__file__))
    exclude = os.path.join(base_path, 'docsite', 'rst', 'modules')
    plugins = [os.path.basename(f) for f in glob.iglob(os.path.join(base_path, '**', '*.py'), recursive=True) if f != exclude]

# Generated at 2022-06-22 18:55:02.200484
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()
    assert doc.display_plugin_list(["123", "456"], "action", "*") == ""


# Generated at 2022-06-22 18:55:04.417824
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    emt = []
    add_collection_plugins(emt, 'action')
    assert emt != []



# Generated at 2022-06-22 18:55:13.247248
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    import ansible.module_utils.basic
    import ansible.modules.cloud.amazon.ec2_module

    # For testing purposes, set the context.CLIARGS['type'] attribute.
    DocCLI.IGNORE = DocCLI.IGNORE + ('ec2',)
    doc_json = AnsibleModuleDocGen(ansible.modules.cloud.amazon.ec2_module).get_doc_json()
    text = DocCLI().get_man_text(doc_json)
    assert text, "Empty text"
    # print(text)


# Generated at 2022-06-22 18:55:16.520679
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    cli = DocCLI('/usr/bin/ansible', '/etc/ansible', '/var/log/ansible', '/var/lib/ansible')
    assert cli.get_plugin_metadata()



# Generated at 2022-06-22 18:55:18.745075
# Unit test for constructor of class DocCLI
def test_DocCLI():
    """
    Test class DocCLI.
    """
    pass

# Generated at 2022-06-22 18:55:29.418217
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    h = RoleMixin()
    role_path = '/Users/mtoomey/ansible/test/roles'
    names = ('test_role',)
    roles = h._find_all_normal_roles((role_path,), name_filters=names)
    argspecs = [h._load_argspec(role, role_path=role_path) for role, role_path in roles]
    summaries = [h._build_summary(role, '', argspec) for role, argspec in zip(names, argspecs)]
    doc = h._create_role_doc(names, (role_path,), entry_point='main')
    assert doc['test_role']['collection'] == ''
    assert 'test_role' in doc.keys()

# Generated at 2022-06-22 18:55:40.805133
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    filename, namespace = DocCLI.namespace_from_plugin_filepath('/path/to/plugins/module_utils/network/vyos/vyos.py')
    assert filename == '/path/to/plugins/module_utils/network/vyos/vyos.py' and namespace == 'vyos'

    filename, namespace = DocCLI.namespace_from_plugin_filepath('/path/to/plugins/module_utils/network/vyos/vyos.py', True)
    assert filename == '/path/to/plugins/module_utils/network/vyos/vyos.py' and namespace == 'module_utils.network.vyos.vyos'

    filename, namespace = DocCLI.namespace_from_plugin_filepath('/path/to/plugins/connection/__init__.py')

# Generated at 2022-06-22 18:55:43.835189
# Unit test for method run of class DocCLI

# Generated at 2022-06-22 18:55:57.536739
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-22 18:56:05.387870
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # Instantiate DocCLI object
    doc = DocCLI()
    # Call function
    lines = doc.format_snippet(['line1', 'line2'])
    assert lines == ['CLI Example::', '', '    line1', '    line2', '']



# Generated at 2022-06-22 18:56:16.320583
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    import os
    import shutil
    import tempfile
    from ansible.module_utils._text import to_bytes

    # Make a temporary directory
    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-22 18:56:19.162505
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doccli = DocCLI()
    doccli.display_plugin_list(['cliconf', 'connection', 'module_utils'])
    assert True

# Generated at 2022-06-22 18:56:20.159753
# Unit test for constructor of class DocCLI
def test_DocCLI():
    D = DocCLI()
    assert D != None


# Generated at 2022-06-22 18:56:20.934423
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    rm = RoleMixin()
    assert True


# Generated at 2022-06-22 18:56:34.671720
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # pylint: disable=too-few-public-methods
    class MockConfig(object):
        ''' A dummy class to mock the config object'''
        pass

    config = MockConfig()
    config.def_file_path = '<Path to default file>'

    # Calling DocCLI.format_plugin_doc() with valid parameter
    # Expected: The text in the doc should be returned.
    out = DocCLI.format_plugin_doc(config, mod_name=' <module name> ')
    out = out.strip()
    assert out == '> MODULE NAME    (<Path to default file>)', out

    # Calling DocCLI.format_plugin_doc() with valid parameter
    # Expected: The text in the doc should be returned.

# Generated at 2022-06-22 18:56:38.017118
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    msg = "Fake error"
    pfn = PluginNotFound(msg)
    msg_from_plugin = pfn.args[0]
    assert msg == msg_from_plugin


# Generated at 2022-06-22 18:56:46.281453
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    from UnitTest.fixtures04 import Fixtures04

    p = Fixtures04.get_sample_data()


    for d in p:
        content = d['content']
        kind = d['kind']
        plugin_type = d['plugin_type']
        path = d['path']
        expected = d['expected']
        actual = DocCLI.get_all_plugins_of_type(content, kind, path, plugin_type)
        if expected != actual:
            print("actual: %s" % actual)
            print("expected: %s" % expected)
            print("path: %s" % path)
            raise AssertionError()

# Generated at 2022-06-22 18:56:48.795539
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    plugins = DocCLI.get_plugin_metadata('module', True)
    assert isinstance(plugins, dict)

# Generated at 2022-06-22 18:56:52.504652
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-22 18:56:59.145594
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    c = DocCLI()
    c._listdir = lambda _: [
        'file1',
        'file2',
        '__pycache__',
        'subdir'
    ]
    c._load_plugins = lambda x, y: {'route': {'payload': {'mod': 'mod'}}}
    res = c.get_plugin_metadata()
    assert res == {'route': {'payload': {'mod': 'mod'}}}



# Generated at 2022-06-22 18:57:00.669331
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    exc = PluginNotFound()
    assert exc.args[0] == ''



# Generated at 2022-06-22 18:57:05.309883
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    snippet = "- hosts: localhost"
    output = "- hosts: localhost\n"
    assert output == DocCLI.format_snippet(snippet)

#  Unit test for method doc_fragments of class DocCLI

# Generated at 2022-06-22 18:57:09.216618
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = dict()
    c = dict()

    a = DocCLI(args, c)
    assert a.run() == None, "Instance of class DocCLI - run"
    return 0


# Generated at 2022-06-22 18:57:18.153907
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
  from ansible.parsing.yaml.strings import to_native
  from ansible.module_utils.six import PY3
  from ansible.module_utils.six.moves import StringIO

  # Create a data structure with a YAML dict for the following YAML doc:
  # ---
  # - hosts: all
  #   tasks:
  #     - name: this is a task
  #       debug:
  #         msg: "{{inventory_hostname}}"
  #
  #       vars:
  #         foo: bar
  #         bam:
  #           - a: 1
  #             b: 2
  #           - c: 3
  #             d: 4
  #
  #       tags:
  #         - always
  #
  # - hosts: webservers

# Generated at 2022-06-22 18:57:31.026479
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    def testit(code, result, **kwargs):
        actual = "\n".join(DocCLI.format_snippet(code, **kwargs))
        assert actual == result, "Expected:\n%s\nGot:\n%s" % (result, actual)

    testit("- shell: |\n    echo \"$HOME\"\n",
           "- shell: |\n            echo \"$HOME\"\n")

    testit("shell: |\n    echo \"$HOME\"\n",
           "shell: |\n            echo \"$HOME\"\n")

    testit("shell: |\n    echo '$HOME'\n",
           "shell: |\n            echo '$HOME'\n")

    testit("- debug: var=foo",
           "- debug: var=foo")

    test

# Generated at 2022-06-22 18:57:34.990935
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    args = "doc"
    test_DocCLI = DocCLI(args.split())
    test_DocCLI._setup_parser()
    test_DocCLI.parse()
    test_DocCLI.find_plugins()


# Generated at 2022-06-22 18:57:40.629785
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    DocCLI_obj = DocCLI()
    args = mock.MagicMock()
    args.module_path = None
    args.extra_path = None
    args.collection_path = None
    args.type = 'action'
    args.all = False
    args.verbose = None
    args.metadata_list = None
    result = DocCLI.find_plugins(DocCLI_obj, args)
    assert type(result) == list


# Generated at 2022-06-22 18:57:53.161420
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Setup a plugin with all known options
    plugin = mock.Mock()
    plugin.DOCUMENTATION = '''
module: test
description: Here is a test
options:
    - a: this is a
    - b: this is b
    - c:
        - d: this is a d
        - e: this is an e
        - f: this is a f
    - g: this is g
'''
    plugin.RETURN = dict(
        x=dict(
            description="x is x",
            returned="If x is x"),
        y=dict(
            description="y is y",
            returned="If y is y"),
    )

    # Assert that the format_plugin_doc() method returns a string
    assert isinstance(DocCLI.format_plugin_doc(plugin), string_types)

# Generated at 2022-06-22 18:57:54.629142
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
        return


# Generated at 2022-06-22 18:58:02.918363
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    import ansible.utils.collections_loader._collection_finder as collection_finder
    monkeypatch = MonkeyPatch()
    monkeypatch.setattr("ansible.utils.collections_loader._collection_finder.list_collection_dirs", lambda x:["/path/to/collection"])
    plugin_list = dict()
    DocCLI.add_collection_plugins(plugin_list, "filter")
    assert(len(plugin_list) == 1)
    assert(plugin_list["collection.testcoll.filters.testfilter"] == {"type": "filter", "options": dict()})
    monkeypatch.undo()



# Generated at 2022-06-22 18:58:14.612139
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    assert DocCLI.format_snippet(code_snippets[0]) == code_snippets[0]['result']
    assert DocCLI.format_snippet(code_snippets[1]) == code_snippets[1]['result']
    assert DocCLI.format_snippet(code_snippets[2]) == code_snippets[2]['result']
    assert DocCLI.format_snippet(code_snippets[3]) == code_snippets[3]['result']
    assert DocCLI.format_snippet(code_snippets[4]) == code_snippets[4]['result']
    assert DocCLI.format_snippet(code_snippets[5]) == code_snippets[5]['result']
   

# Generated at 2022-06-22 18:58:16.848188
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound
    except Exception as e:
        assert isinstance(e, PluginNotFound)



# Generated at 2022-06-22 18:58:18.086465
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    assert True


# Generated at 2022-06-22 18:58:21.103526
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    DocCLI(['module', 'gather_facts', '-F'])
    


# Generated at 2022-06-22 18:58:22.224546
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():

    try:
        raise PluginNotFound
    except PluginNotFound:
        pass


# Generated at 2022-06-22 18:58:31.779288
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    from ansible.utils.collection_loader import get_collection_loader


# Generated at 2022-06-22 18:58:43.087477
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    '''Unit test for add_fields of class DocCLI'''
    # Test: accept a list of options and generate help text for it.
    # Test: a list of options with empty items should be ignored
    # Test: several options with non-trivial elements (choices, list of strings, ...) should be rendered
    # Test: options with multiple subelements should be rendered
    # Test: option descriptions should be wrapped
    # Test: option descriptions which are lists should be rendered as multi-line output
    # Test: options with a version_added field should be rendered
    # Test: options with a version_added_collection field should be rendered
    # Test: options with a config field should be rendered
    # Test: options with a config field and a cli section should be rendered
    # Test: options with a config field and a cli section which has a single

# Generated at 2022-06-22 18:58:49.014809
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Make the instance
    doc_cli = DocCLI()

    # Give the input data
    plugin_type = "module"
    plugin_name = "ping"

    # Run the method
    ### This is a private method and is not being tested as it is not necessary.
    #result = doc_cli._format_plugin_doc(plugin_type, plugin_name)

    # Assert the result
    #assert result == expected_result
    assert True
