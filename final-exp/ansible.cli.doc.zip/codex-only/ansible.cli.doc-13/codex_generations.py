

# Generated at 2022-06-22 18:48:54.289625
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    data = {
        'filters': [],
        'options': [],
        'action': []
    }
    doc = DocCLI([''], data)
    doc.post_process_args(data)

    data = {
        'filters': [{'aliases': ['f'], 'name': 'filter'}],
        'options': [{'aliases': ['o'], 'name': 'option1'}],
        'action': [{'aliases': ['a'], 'name': 'action1'}]
    }
    doc = DocCLI([''], data)
    doc.post_process_args(data)
    assert data['filters'][0]['name'] == 'filter'
    assert data['options'][0]['name'] == 'option1'

# Generated at 2022-06-22 18:49:04.284893
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    DocCLI._instances.clear()

    # Construct argparse mock object.
    args = ArgparseMock()
    args.pattern = None
    args.type_name = 'module'
    args.include_extras = None

    # Construct DocCLI object
    cli = DocCLI(args)

    # Call method find_plugins
    result = cli.find_plugins()

    # Check that result is correct
    assert isinstance(result, list)
    assert len(result) > 0
    assert 'copy' in result
    assert 'ansible.module_utils.basic' in result


# Generated at 2022-06-22 18:49:09.363167
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    plugins = DocCLI.get_all_plugins_of_type('lookup')
    # Test the requirement: plugins is a 'list'
    try:
        assert isinstance(plugins, types.ListType)
    except AssertionError:
        raise AssertionError("plugins should be a 'list', got: %s" % type(plugins))

# Generated at 2022-06-22 18:49:15.673598
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    '''Test method post_process_args of class DocCLI.'''

    my_args = ['-t', 'doc', '-M', 'test/ansible/modules']
    my_args = DocCLI.post_process_args(my_args)
    assert my_args == ['-t', 'doc', '-M', 'test/ansible/modules']


# Generated at 2022-06-22 18:49:16.855077
# Unit test for constructor of class DocCLI
def test_DocCLI():
    d = DocCLI()
    assert d is not None

# Generated at 2022-06-22 18:49:21.009827
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    err = PluginNotFound('No plugin found for extension {0}'.format('test_extension'))
    assert str(err) == 'No plugin found for extension test_extension'



# Generated at 2022-06-22 18:49:27.883696
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
  # running test using nose
  # If you want to run it using command line
  # comment nose.run and uncomment unittest.main.
  # run the command in command line: python -m unittest test_DocCLI.py

  #nose.run(argv=[__file__, '-v', '-s'])
  #unittest.main()

  # define the class
  class DocCLI_mock(DocCLI):
    def __init__(self):
      pass
  
  # initialize the class
  doc_cli_mock = DocCLI_mock()
  
  # define role_json

# Generated at 2022-06-22 18:49:30.825290
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound("Hello world")
    except PluginNotFound as e:
        print(e)
        assert e.args[0] == "Hello world"



# Generated at 2022-06-22 18:49:42.790179
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    doc_to_test = DocCLI()

    # Try without any arguments
    try:
        doc_to_test.init_parser(None)
    except SystemExit:
        pass
    else:
        raise AssertionError("init_parser: did not raise SystemExit when no parser provided")

    # Try with a valid argument but with a default which is not one of 'module', 'module_setup', 'module_deprecation'
    try:
        doc_to_test.init_parser(None, 'test_module')
    except SystemExit:
        pass
    else:
        raise AssertionError("init_parser: did not raise SystemExit when invalid default provided")

    # Try with no optional argument
    parser = doc_to_test.init_parser(None, 'module')
    # verify parser

# Generated at 2022-06-22 18:49:45.436071
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    """Unit test for the constructor of the :class:`RoleMixin` class.
    """
    my_instance = RoleMixin()
#
# end test_RoleMixin



# Generated at 2022-06-22 18:49:56.094383
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    doc_obj = DocCLI()

    arguments = ['--type=module', '--index', 'mkdir', '-v']
    doc_obj.post_process_args(arguments)
    assert (doc_obj.context['type'] == 'module' and
            doc_obj.context['index'] == 'mkdir' and
            doc_obj.context['verbosity'] == 1)

    arguments = ['--type=module', '--index', '--verbose', 'mkdir']
    doc_obj.post_process_args(arguments)
    assert (doc_obj.context['type'] == 'module' and
            doc_obj.context['index'] == 'mkdir' and
            doc_obj.context['verbosity'] == 1)


# Generated at 2022-06-22 18:50:09.403148
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():

    # Test post_process_args, as this method is complex
    # and has many code paths.
    #
    # The ideal would be to write unit tests for each logically grouped
    # method in the class, but post-process args is the only one that
    # calls functions in other classes, so going through the class
    # is the only way to do this.

    dc = DocCLI()

    # When we're allowed to fetch from the internet, this works
    dc.args = dc.parser.parse_args(['ansible-doc', '-M',
                                    'https://github.com/ansible/ansible/tree/devel/lib/ansible/modules/network/vcenter'])
    assert dc.post_process_args()

    # This can't run on the CI account since it isn't allowed to fetch from the internet.


# Generated at 2022-06-22 18:50:12.755239
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    pnf = PluginNotFound('mymessage')
    assert pnf.__str__() == 'mymessage'



# Generated at 2022-06-22 18:50:26.092521
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    fields = {}
    fields["option"] = {}
    fields["option"]["description"] = ""
    fields["option"]["required"] = True
    fields["option"]["default"] = ""
    fields["option"]["choices"] = []
    fields["option"]["aliases"] = []
    fields["option"]["version_added"] = ""
    fields["option"]["type"] = ""
    fields["option"]["suboptions"] = {}
    fields["option"]["spec"] = {}
    fields["option"]["spec"]["version_added"] = ""
    fields["option"]["spec"]["choices"] = []
    fields["option"]["spec"]["aliases"] = []
    fields["option"]["spec"]["default"] = ""

# Generated at 2022-06-22 18:50:28.681114
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    plugin_name = 'testing'
    try:
        raise PluginNotFound(plugin_name)
    except PluginNotFound as e:
        assert plugin_name in str(e)



# Generated at 2022-06-22 18:50:31.301355
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    t, d = DocCLI.get_all_plugins_of_type('module')
    assert type(dict()) == type(d)
    assert "shell" in t

# Generated at 2022-06-22 18:50:37.892753
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    test_list = {}
    coll_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test_collections', 'test_collections_d_00')
    add_collection_plugins(test_list, "action", coll_filter=coll_path)
    assert 'package' in test_list



# Generated at 2022-06-22 18:50:45.721682
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    cli = DocCLI(['ansible-doc', 'test'], None, None)

    # Test data is JSON format

# Generated at 2022-06-22 18:50:55.119406
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-22 18:50:56.768406
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    assert add_collection_plugins('plugin_list', 'action') == {}



# Generated at 2022-06-22 18:51:02.868845
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
  class FakeDisplay:
    def __init__(self):
      self.columns = 80
  display = FakeDisplay()
  doc = {'options': {'force': {'name': 'force', 'aliases': ['force'], 'default': False, 'choices': [True, False], 'type': 'bool', 'version_added': '2.0', 'description': 'By default there are some situations where Ansible will warn you if it appears that you may have made a mistake. This option will cause Ansible to proceed with the specified operation. '}}}
  text = []
  opt_indent = "        "
  limit = max(display.columns - int(display.columns * 0.20), 70)
  suboptions = []
  return_values = False

# Generated at 2022-06-22 18:51:09.176330
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc = DocCLI()
    plugins = doc.get_plugins()
    command = 'ansible-doc -t module aws_s3'
    args = shlex.split(command)
    with pytest.raises(SystemExit) as excinfo:
        doc.run(args)
    assert excinfo.value.code == 0
# end unit test


# Generated at 2022-06-22 18:51:22.503140
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    from ansible.utils.display import Display
    from ansible.parsing.yaml.dumper import AnsibleDumper
    # Testing 2 different logic branches in this method
    # branch 1
    snippet = {'desc': '', 'options': {'host': {'host': 'host', 'desc': '', 'required': None, 'choices': None, 'type': 'string', 'version_added': None, 'aliases': [], 'default': 'default', 'suboptions': {}, 'suboptions_description': None}}, 'short_description': 'short_description'}
    (are, ce) = (always_read_from_file, never_read_from_file)
    display = Display()
    display.columns = 80
    doccli = DocCLI(snippet, display)
    ret = doccli.format

# Generated at 2022-06-22 18:51:30.367950
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    print('In test_DocCLI_run()')
    # Test cli_opts['help_cmd'] = 'search'
    cli_opts = dict()
    cli_opts['help_cmd'] = 'search'
    cli_opts['list_type'] = ''
    cli_opts['list_order'] = 'name'
    cli_opts['roles_path'] = ''
    cli_opts['plugins'] = ['/etc/ansible/roles/pytest-ansible.pkgng/library']
    cli_opts['type'] = 'module'
    DocCLI(cli_opts).run()
    # Test cli_opts['help_cmd'] = 'list'
    cli_opts = dict()

# Generated at 2022-06-22 18:51:42.118112
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    test_file = os.path.join(os.path.dirname(__file__), 'test_docs.py')
    doc_path = os.path.join(os.path.dirname(__file__), 'docs/docsite')
    test_module = AnsibleModule(argument_spec={})

    test_doc = DocCLI.format_plugin_doc(test_module, test_file, doc_path)

# Generated at 2022-06-22 18:51:53.580226
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Preparing test data
    cmds = [{'action': 'help', 'aliases': ['h']}, {'action': 'fetch', 'aliases': ['f']}]
    class_name = 'DocCLI'
    method_name = 'get_plugin_metadata'

    # Variables locally defined in this method
    _paths = []

    # Define the test case data

# Generated at 2022-06-22 18:51:58.294877
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    assert DocCLI.format_snippet('hello world') == 'hello world'
    assert DocCLI.format_snippet(['hello', 'world']) == 'hello world'
    assert DocCLI.format_snippet(['hello', 'world'], indent=4) == '    hello world'
    assert DocCLI.format_snippet(['hello', 'world'], indent=4, separator='\n') == '    hello\n    world'


# Generated at 2022-06-22 18:52:06.984268
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    assert DocCLI.display_plugin_list([{'name': 'foo'}], 'module') == '''
  foo - ( An Ansible module )
'''
    assert DocCLI.display_plugin_list([{'name': 'foo', '_load': False}], 'module') == '''
  foo - ( An Ansible module )
    * Note: This module is not maintained by the Ansible Core Team
'''
    assert DocCLI.display_plugin_list([{'name': 'foo', 'deprecated': 'foobar'}], 'module') == '''
  foo - ( An Ansible module )
    * DEPRECATED:
      Reason: foobar
'''

# Generated at 2022-06-22 18:52:13.985295
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    # we need to set up parameters for roles_path
    from ansible.config.manager import ConfigManager
    from ansible.cli.playbook import PlaybookCLI
    from ansible.playbook import Playbook
    from ansible.utils.plugins import PluginLoader
    from ansible.plugins.callback.default import CallbackModule
    from ansible.plugins.loader import module_loader
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    b_module_loader = PluginLoader('ModuleUtil', 'module_utils', C.MODULE_UTILS_PATH, '', '', class_only=True)
    module_loader.add_directory(C.MODULE_UTILS_PATH)

# Generated at 2022-06-22 18:52:26.175768
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a sample role file

# Generated at 2022-06-22 18:52:32.300436
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    doc = DocCLI()
    text = doc.get_man_text({"plainexamples": "example: hello"})
    result = textwrap.indent(text, ' ' * 2)
    assert result.startswith('  EXAMPLES:')
    assert result.endswith('hello')


# Generated at 2022-06-22 18:52:34.147006
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    add_collection_plugins(plugin_list, 'filter')
    assert plugin_list


# Generated at 2022-06-22 18:52:44.931612
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Stub of path to be tested. Can be absolute or relative.
    path = '../lib/ansible/modules/packaging/os/'

    # Arguments which will be passed to the stubbed method.
    args = []

    # A record of all calls made to the stubbed path.
    call_record = []


    # Stub method to replace the actual method for the duration of this test.
    # Replaces the method of the same name in the class to be tested.
    def stub_print(msg):
        call_record.append(msg)

    # Insert the stub method into class DocCLI.
    DocCLI.print = stub_print

    # Call the method from the class under test with the stubbed path.
    DocCLI(args).print_paths(path)

    # Ensure that the method from the class under test

# Generated at 2022-06-22 18:52:56.846598
# Unit test for method display_plugin_list of class DocCLI

# Generated at 2022-06-22 18:53:00.002361
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    """
    # from ansible.cli.doc import DocCLI
    # doc_cli = DocCLI()
    # doc_cli.run()
    """


# Generated at 2022-06-22 18:53:03.997612
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    plugin_not_found = PluginNotFound('plugin not found')
    assert plugin_not_found.args == ('plugin not found',)
    assert str(plugin_not_found) == "('plugin not found',)"



# Generated at 2022-06-22 18:53:09.613631
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    mixin = RoleMixin()

    empty = mixin._load_argspec("roleA", "/tmp/foo/bar")
    assert empty == {}

    roles = []
    mixin._find_all_normal_roles(roles)
    assert roles == []

    # TODO: Test collection roles, too



# Generated at 2022-06-22 18:53:20.376864
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    def test_type_help():
        with patch.object(display, 'columns', return_value=77):
            with patch.object(display, 'term_size', return_value=(24, 80)):
                with patch('os.path.dirname', return_value='ansible/modules/'):
                    doc = DocCLI('cloud/gce')
                    assert type(doc.init_parser()) == argparse.ArgumentParser
                    assert doc.parsed_args.module_path == 'cloud/gce'
                    assert doc.parsed_args.module_path2 == None
                    assert doc.parsed_args.role_name == None
                    assert doc.parsed_args.role_path == None


# Generated at 2022-06-22 18:53:22.910224
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    assert False, 'TODO'



# Generated at 2022-06-22 18:53:33.710013
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():

    # Test with simple snippet
    test_snippet = '''
- name: The task
  block:
    - name: demo block task
      debug:
        msg: 'hello world'
      when: b_var
  rescue:
    - name: demo rescue task
      debug:
        msg: 'rescue hello world'
  always:
    - name: demo always task
      debug:
        msg: 'always hello world'
  when: a_var
'''
    test_snippet_name = 'test_snippet'

# Generated at 2022-06-22 18:53:46.509919
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():

    # Test 1
    text = []
    doc_json = {
        "name": "modulename",
        "short_description": "short desc",
        "description": [
            "description",
            "description"
        ],
        "version_added": "2.4"
    }

    DocCLI.add_fields(text, doc_json, limit=80, opt_indent=4)
    assert text == ['    name: modulename', '    short_description: short desc', '    description:      description', '                      description', '']

    # Test 2
    text = []
    doc_json = {
        "name": [
            "modulename",
            "extras",
            "values"
        ]
    }


# Generated at 2022-06-22 18:53:49.602185
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 70
    opt_indent = "        "
    options = {}
    DocCLI.add_fields(text, options, limit, opt_indent)


# Generated at 2022-06-22 18:53:51.673796
# Unit test for constructor of class DocCLI
def test_DocCLI():
    my_doc = DocCLI()
    assert isinstance(my_doc, DocCLI)


# Generated at 2022-06-22 18:54:02.308762
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    from ansible.utils.display import Display
    display = Display()

    # With empty options, None
    text = []
    assert DocCLI.add_fields(text, []) is None
    assert text == []

    # With empty options, default text
    text = []
    assert DocCLI.add_fields(text, [], return_values=True) is None
    assert text == ['RETURN VALUES:']

    # With single option, data if present
    text = []
    assert DocCLI.add_fields(text, [{'name': 'test'}]) is None
    assert text == ['        test: \n']

    # With single option, data if present, description
    text = []

# Generated at 2022-06-22 18:54:06.902968
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    """Test DocCLI.print_paths method with several examples."""
    objects = [
        # Empty DocCLI class
        DocCLI(),
        # DocCLI with PATH()
        DocCLI(initialized=True, paths=[('PATH', 'a path')]),
        # DocCLI with overloaded PATH('')
        DocCLI(initialized=True, paths=[('PATH', 'a path'), (context.CLIARGS['type'], 'a plugin')])
    ]

    for obj in objects:
        obj.print_paths()
        assert True

# Generated at 2022-06-22 18:54:12.252629
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    def get_expected(lines, opt=u'    ', strip_opt=False): # pylint: disable=missing-docstring
        if isinstance(lines, string_types):
            return lines

        rval = []
        for line in lines:
            if isinstance(line, string_types):
                rval.append(line)
            elif isinstance(line, dict):
                if 'snippet' in line and isinstance(line['snippet'], string_types):
                    newlines = line.pop('snippet').rstrip().splitlines()

                    if line:
                        rval.append({})

                    for item in line:
                        if isinstance(line[item], string_types):
                            rval.append(u"%s%s: %s" % (opt, item, line[item]))

# Generated at 2022-06-22 18:54:25.072186
# Unit test for method format_plugin_doc of class DocCLI

# Generated at 2022-06-22 18:54:33.522104
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc = {}
    doc['entry_points'] = {}
    doc['entry_points']['main'] = {}
    doc['entry_points']['main']['short_description'] = 'This is a short description.'
    doc['entry_points']['main']['options'] = {'var1': {'description': 'A description.'}}
    doc['entry_points']['main']['attributes'] = {'var1': {'description': 'A description.'}}

    # Test the output of the function get_role_man_text of class DocCLI

# Generated at 2022-06-22 18:54:34.572936
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    pass

# Generated at 2022-06-22 18:54:45.689618
# Unit test for function jdump
def test_jdump():
    test_hash = {1: 'one', 2: 'two' }
    test_list = ['one', 'two', 'three' ]
    test_str = 'just a string'
    test_none = None
    expected_str = '''{
    "1": "one",
    "2": "two"
}
'''
    expected_list = '''[
    "one",
    "two",
    "three"
]
'''
    expected_str2 = '"just a string"\n'
    expected_none = 'null\n'
    # test_hash
    jhash = jdump(test_hash)
    assert jhash == expected_str
    # test_list
    jlist = jdump(test_list)
    assert jlist == expected_list
    # test_str
   

# Generated at 2022-06-22 18:54:51.145750
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    text=DocCLI.get_man_text(doc)
    text=DocCLI.tty_ify(text)
    print(text)
    print(display.columns)
# doc: the doc you get from get_doc


if __name__ == "__main__":
    test_DocCLI_get_man_text()

# Generated at 2022-06-22 18:54:59.610244
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    plugin_type = context.CLIARGS['type']
    doc_type = context.CLIARGS['type']
    if plugin_type == 'all':
        doc_type = 'modules'
    elif plugin_type == 'connection':
        doc_type = 'connection_plugins'
    elif plugin_type == 'shell':
        doc_type = 'shell_plugins'
    elif plugin_type == 'httpapi':
        doc_type = 'httpapi_plugins'
    elif plugin_type == 'lookup':
        doc_type = 'lookup_plugins'
    elif plugin_type == 'inventory':
        doc_type = 'inventory_plugins'
    elif plugin_type == 'filter':
        doc_type = 'filter_plugins'
    elif plugin_type == 'netconf':
        doc

# Generated at 2022-06-22 18:55:12.434815
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    # pylint: disable=unused-variable
    # pylint: disable=protected-access
    class TestClass(RoleMixin):
        pass

    testobj = TestClass()
    r = {"argument_specs": {"foo": {"description": "Fooing bar to baz."}}}
    assert r == testobj._load_argspec("test", role_path="test")
    r = {"argument_specs": {"foo": {"description": "Fooing bar to baz."}}}
    assert r == testobj._load_argspec("test", collection_path="test")

    assert ["argument_specs.yml", "argument_specs.yaml", "main.yml", "main.yaml"] == testobj.ROLE_ARGSPEC_FILES

    # _build_summary

# Generated at 2022-06-22 18:55:15.110066
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    class TestRoleMixin(RoleMixin):
        pass
    test_obj = TestRoleMixin()
    assert not test_obj._find_all_collection_roles()



# Generated at 2022-06-22 18:55:25.176552
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc = DocCLI()
    # Test with empty argv
    DocCLI.run(doc, [])
    # Test with search
    DocCLI.run(doc, ['search', 'module_name'])
    # Test with show
    DocCLI.run(doc, ['show', 'module_name'])
    # Test with get_doc
    DocCLI.run(doc, ['show', 'module_name', '-F', 'get_doc'])
    # Test with get_doc
    DocCLI.run(doc, ['show', 'module_name', '-F', 'extended_help'])


# Generated at 2022-06-22 18:55:30.078976
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    def mock_do_cli(self):
        pass
    mocked_do_cli = Mock(side_effect=mock_do_cli)
    with patch.object(DocCLI, 'do_cli', mocked_do_cli):
        with patch.object(DocCLI, 'run') as mock_run:
            DocCLI().run()

        mock_run.assert_called_with()


# Generated at 2022-06-22 18:55:31.512496
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc = DocCLI(type="module")
    assert doc.type == "module"


# Generated at 2022-06-22 18:55:33.599290
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Arrange
    doc_cli = DocCLI()
    # Act
    modules = doc_cli.find_plugins()
    # Assert
    assert 'ACCESS_KEY' in modules['aws_access_key']['description']


# Generated at 2022-06-22 18:55:46.455888
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()
    doc.display_plugin_list(['module', 'module1', 'module2'], 'module', 'test', 'test')

    doc.display_plugin_list(['module', 'module1', 'module2'], 'module')

    doc.display_plugin_list(['module', 'module1', 'module2'], 'module', 'test')

    doc.display_plugin_list(['module', 'module1', 'module2'], 'module', 'test', 'test', False)

    doc.display_plugin_list(['module', 'module1', 'module2'], 'module', 'test', 'test')

    doc.display_plugin_list(['module', 'module1', 'module2'], 'module', 'test', 'test')


# Generated at 2022-06-22 18:55:48.264256
# Unit test for constructor of class DocCLI
def test_DocCLI():
    # construct a class object
    doc = DocCLI()
    assert doc is not None, 'DocCLI object is None'



# Generated at 2022-06-22 18:55:52.885287
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath("lib/ansible/plugins/modules/functools.py") == "none"
    assert DocCLI.namespace_from_plugin_filepath("lib/ansible/plugins/modules/datacom/datacom_obj.py") == "datacom"
    assert DocCLI.namespace_from_plugin_filepath("lib/ansible/plugins/modules/system/service.py") == "system"



# Generated at 2022-06-22 18:55:58.452371
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    argspec = mock.MagicMock(spec=argument_spec)
    cli = DocCLI(None)
    cli.parser = cli.init_parser(doc_fragment=argspec)
    assert isinstance(cli.parser, argparse.ArgumentParser)

# Generated at 2022-06-22 18:56:05.696371
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    arg = ['--version']
    options=DocCLI.pre_process_args(arg)
    options=DocCLI.post_process_args(options)
    assert options==Namespace(version=True),'DocCLI_post_process_args expected True to return, instead got False'

# Generated at 2022-06-22 18:56:09.382156
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc = DocCLI(
        None,
        context.CLIARGS,
    )

    assert isinstance(doc, DocCLI)
    assert doc.get_all_plugins_of_type('lookup')



# Generated at 2022-06-22 18:56:16.121148
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    class DummyCLI(object):
        def __init__(self):
            self.args = ''
            self.command = 'setup'
    cli = DummyCLI()
    cli.collection = None
    cli.module = 'setup'
    cli.subcommand = None

    plugin_loader = None

    plugin_loader = DocCLI(cli, 'setup').format_plugin_doc(plugin_loader)
    assert plugin_loader



# Generated at 2022-06-22 18:56:18.978941
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    cli = DocCLI(args=["ansible-doc"])
    parser = cli.init_parser()
    assert parser is not None


# Generated at 2022-06-22 18:56:24.086794
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    from units.compat import StringIO

    cli = DocCLI()
    cli.parse()

    args = [
        '-h', 'bogus',
        '--type', 'module',
        '--listt',
        'module', 'system'
    ]

    args = cli.post_process_args(args, None)

    assert not args.get('help'), 'help parameter should have been cleared'
    assert args.get('listt') == 'plugins', 'list'



# Generated at 2022-06-22 18:56:33.181928
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    my_class = DocCLI()
    plugin_type = 'modules'
    paths = ['/Users/ansible/git/ansible/lib/ansible/modules']
    ignore_hidden = True
    my_class.find_plugins(plugin_type, paths, ignore_hidden)
    assert my_class.plugins['modules'][0][0] == ('script', '/Users/ansible/git/ansible/lib/ansible/modules/extras/monitoring/nagios.py')



# Generated at 2022-06-22 18:56:44.580726
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    cwd = os.getcwd()
    if cwd.endswith('/test/units/cli'):
        cwd = cwd[:-len('/test/units/cli')]
    os.chdir(cwd)

    assert DocCLI.namespace_from_plugin_filepath('/foo/bar/baz/ansible/modules/network/cloud/aerohive/ah_vrf.py') == 'network.cloud.aerohive'
    assert DocCLI.namespace_from_plugin_filepath('/foo/bar/baz/ansible/modules/network/cloud/aerohive/__init__.py') == 'network.cloud.aerohive'

# Generated at 2022-06-22 18:56:48.848043
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    from ansible.plugins.loader import find_plugin
    plugin_filepath = find_plugin('action')
    assert DocCLI.namespace_from_plugin_filepath(plugin_filepath) == 'action'


# Generated at 2022-06-22 18:57:00.447019
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    test_args = {'type': 'module', 'module': 'setup', 'module_path': None, 'roles_path': [],
                 'collections_path': [], 'role': False, 'verbosity': 1, 'tree': [],
                 'metadata': False, 'collection_name': False, 'tree_path': None}
    DocCLI.post_process_args(test_args)
    assert test_args['format'] == 'cli'
    assert test_args['type'] == 'module'
    assert test_args['module'] == 'setup'
    assert test_args['role'] == False
    assert test_args['metadata'] == False
    assert test_args['collection_name'] == False
    assert test_args['tree_path'] == None
    assert test_args['tree'] == []


# Unit test

# Generated at 2022-06-22 18:57:12.192345
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    src = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data', 'role_arg_specs')
    from ansible.cli.doc import DocCLI
    d = DocCLI()
    assert d is not None
    d.options = d.base_parser.parse_args([])
    d.options.cache_path = C.DEFAULT_CACHE_PLUGIN_PATH

    # summarize all roles, including those in a collection
    all_roles = d._create_role_list(roles_path=(src,))
    assert len(all_roles) == 4

    # summarize just the roles from a particular collection

# Generated at 2022-06-22 18:57:25.146755
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # DocCLI.format_plugin_doc(doc, collection_name='', plugin_type='', name_only=False):
    from ansible.cli.doc import DocCLI
    from ansible.module_utils.six import PY3
    doc = {'version_added': '1.0.0', 'name': 'test_name', 'author': ['test_author'], 'description': ['test_desc']}

# Generated at 2022-06-22 18:57:38.200157
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    from ansible.utils.display import Display
    from ansible.cli.doc import DocCLI
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.plugins.loader import module_loader
    import sys

    # From line 806 of module_utils/common/text/converters.py
    if sys.version_info[0] < 3:
        unicode = unicode
    else:
        unicode = str

    display = Display()
    doccli = DocCLI()

    role_name = 'test_role_1'

# Generated at 2022-06-22 18:57:51.019917
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    snippet = "name: docker_login\nBecome: yes\nConnection: local\nHost: localhost\nno_log: 'yes'\nNote: this playbook is deprecated\nTasks:\n  - name: docker login\n    docker_login:\n      username: '{{ username }}'\n      password: '{{ password }}'\n      registry: '{{ registry }}'"

# Generated at 2022-06-22 18:58:01.428175
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    '''test_DocCLI_run()'''
    from ansible.cli.arguments import Options as _DocCLIOptions
    mock_options = _DocCLIOptions()
    mock_options.type = 'module'
    mock_options.format = 'json'
    mock_options.paths = []
    cli = DocCLI(mock_options)
    assert cli.run() is None # make sure we don't error

    mock_options.type = 'module'
    mock_options.format = 'text'
    mock_options.paths = []
    cli = DocCLI(mock_options)
    assert cli.run() is None # make sure we don't error


# Generated at 2022-06-22 18:58:05.479473
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    DocCLI.print_paths(None, None, None)
    DocCLI.print_paths('', {}, {})

# Generated at 2022-06-22 18:58:15.597761
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doc_cli = DocCLI()
    role_name = "test_role_doc"

# Generated at 2022-06-22 18:58:20.511223
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # The method get_plugin_metadata of class DocCLI returns only the description
    result = DocCLI().get_plugin_metadata("docker_image", "description")
    assert result,"description" in result


# Generated at 2022-06-22 18:58:29.536454
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    from ansible.cli.doc import DocCLI
    rolespath = os.path.join(os.path.dirname(__file__), '../../../test/units/modules/test_meta_role')
    role = 'testrole'
    role_with_coll = 'c.b.a.testrole'
    entry_point = 'alternate'
    doc = DocCLI(args=[role, '--roles-path', rolespath])
    assert len(doc.doc.keys()) == 3
    assert entry_point in doc.doc[role]['entry_points'].keys()
    assert entry_point in doc.doc[role_with_coll]['entry_points'].keys()



# Generated at 2022-06-22 18:58:34.625414
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    #file_path  = 'plugins/modules/cloud/amazon/ecs_taskdefinition_facts.py'
    #expected_value = 'cloud.amazon.ecs_taskdefinition_facts'
    file_path  = 'plugins/modules/cloud/os_user_facts.py'
    expected_value = 'cloud.os_user_facts'
    observed_value = DocCLI.namespace_from_plugin_filepath(file_path)
    assert observed_value == expected_value


# Generated at 2022-06-22 18:58:46.753450
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    from ansible.plugins.doc_fragments import get_doc_fragment_keywords
    doc, plainexamples, returndocs, metadata = get_doc_fragment_keywords('service')
    test_DocCLI = DocCLI()
    success = True

    # Get text of the doc
    try:
        man_text = test_DocCLI.get_man_text(doc, plainexamples, returndocs, metadata)
        man_text = man_text.strip()
    except Exception as e:
        success = False
        raise AssertionError("Could not get man text of the doc of service module: %s " % to_text(e))
    # Check if text of