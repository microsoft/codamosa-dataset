

# Generated at 2022-06-22 18:48:56.417753
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    """Unit test for method get_role_man_text of class DocCLI."""
    args = context.CLIARGS
    cli = DocCLI(args)
    role = "test_role"
    role_json = {"path":"path/to/role","entry_points":{"role-name":{"short_description":"Short Description", "description":"Longer Description"}}}
    result = cli.get_role_man_text(role, role_json)
    expected = "> TEST_ROLE    (path/to/role)\nENTRY POINT: role-name - Short Description\n        Longer Description\n"
    assert result == expected



# Generated at 2022-06-22 18:49:05.346609
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    mock_doc = {'description': ['Manages the configuration of the Nginx web'], 'options': {'config_file': {'env': [{'name': 'ANSIBLE_NGINX_CONFIG_FILE'}], 'type': 'path', 'required': False, 'default': '/etc/nginx/nginx.conf', 'aliases': ['ini_path'], 'version_added': '2.7'}}, 'name': 'nginx', 'version_added': '2.1'}

# Generated at 2022-06-22 18:49:10.846691
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
   # NOTE add removal of leading and trailing whitespace for all returned data
   cli = DocCLI()
   result = cli.format_snippet('    line1\n    line2\n',False)
   assert result == 'line1\n    line2'
   result = cli.format_snippet(['    line1\n    line2\n'],False)
   assert result == 'line1\n    line2'
   result = cli.format_snippet(['    line1\n    line2\n'],True)
   assert result == '    line1\n    line2'
   result = cli.format_snippet('    line1\n    line2\n',True)
   assert result == '    line1\n    line2'


# Generated at 2022-06-22 18:49:24.758355
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    import copy
    import os
    import io
    import json
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionFinder

    collection_loader = AnsibleCollectionLoader()
    collection_finder = AnsibleCollectionFinder(collection_loader)
    collection_paths = [os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'lib', 'ansible', 'collections', 'ansible_collections/', 'yamllint', 'ansible_collections/yamllint')]
    collection_finder.find(only_collections=True, collection_paths=collection_paths)

# Generated at 2022-06-22 18:49:25.381695
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    assert True



# Generated at 2022-06-22 18:49:30.300685
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    '''Test method DocCLI.init_parser()'''

    # TODO: test the code to make sure it matches the functionality
    # TODO: test the error cases
    # TODO: test the no error cases
    pass

# Generated at 2022-06-22 18:49:42.439752
# Unit test for constructor of class DocCLI
def test_DocCLI():
    # test instantiation of class
    cli_args = DocCLI()

    # test printing of class variables
    assert hasattr(cli_args, 'IGNORE')
    assert hasattr(cli_args, 'collections_human_map')
    assert hasattr(cli_args, 'collection_names')
    assert hasattr(cli_args, 'collections')

    # test printing of functions
    assert hasattr(cli_args, 'get_module_list')
    assert hasattr(cli_args, '_show_deprecated')
    assert hasattr(cli_args, '_show_removed')
    assert hasattr(cli_args, '_get_doc_fragment')
    assert hasattr(cli_args, '_find_plugin')

# Generated at 2022-06-22 18:49:44.637906
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound("The requested plugin was not found")
    except PluginNotFound:
        assert True



# Generated at 2022-06-22 18:49:48.708225
# Unit test for method run of class DocCLI
def test_DocCLI_run():
  doc_file = 'roles/myrole/meta/main.yaml'
  collection_name = 'mycollection'

  d = DocCLI()
  d.run(doc_file, collection_name)

# Generated at 2022-06-22 18:49:51.932518
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    test_list = {}
    add_collection_plugins(test_list, 'module')
    assert isinstance(test_list, dict)
    assert len(test_list) > 0


# Generated at 2022-06-22 18:49:59.535470
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    plugin = {
        'module': True,
        'args_option_names': [],
        'metadata': {
            'description': [],
            'short_description': 'This is a test module'
        },
        'name': 'test',
        'doc': {
            'description': 'This is the module documentation',
            'short_description': 'This is a test module',
            'options': {
                'name': {
                    'description': 'The name of the host to connect',
                    'required': True,
                    'default': 'localhost'
                }
            }
        }
    }


# Generated at 2022-06-22 18:50:02.178560
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    # Try to create a PluginNotFound object without any parameter specified
    try:
        PluginNotFound()
    except TypeError:
        pass



# Generated at 2022-06-22 18:50:04.322296
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    assert add_collection_plugins is not None



# Generated at 2022-06-22 18:50:16.908801
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-22 18:50:21.840895
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # DocCLI does not provide a constructor.
    # Initialize the class
    doc_cli = DocCLI()
    # Get the list of all plugins of type 'action'
    plugins = doc_cli.get_all_plugins_of_type('action')
    assert plugins


# Generated at 2022-06-22 18:50:26.944985
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    import os.path

    doc_cli = DocCLI()
    plugin_type = 'module'

    result = doc_cli.get_all_plugins_of_type(plugin_type)
    assert type(result) == list
    for plugin in result:
        assert os.path.exists(plugin)



# Generated at 2022-06-22 18:50:38.160431
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    doc = """
    author:
        - Ansible Core Team
        - Michael DeHaan
    """
    d = yaml.safe_load(doc)
    assert 'author' in d
    assert isinstance(d['author'], list)
    assert d['author'] == [u'Ansible Core Team', u'Michael DeHaan']

    doc = """
    author:
        name: Ansible Core Team
        email: ansible-devel@lists.ansible.com
    """
    d = yaml.safe_load(doc)
    assert 'author' in d
    assert isinstance(d['author'], dict)
    assert d['author'] == {u'name': u'Ansible Core Team', u'email': u'ansible-devel@lists.ansible.com'}


# Generated at 2022-06-22 18:50:48.935715
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    argv = []
    doc = DocCLI(args=argv)
    assert doc.parser._actions[1].choices == ['all', 'modules', 'module', 'lookup_plugins', 'lookup_plugin', 'action_plugins', 'action_plugin', 'callback_plugins', 'callback_plugin', 'fragments', 'fragment', 'filter_plugins', 'filter_plugin', 'deprecated', 'deprecated_facts', 'deprecated_modules', 'deprecated_modules_options', 'deprecated_plugins', 'deprecated_actions', 'deprecated_return_values', 'deprecated_options', 'deprecated_env_var', 'deprecated_ini_setting', 'deprecated_facts_plugins']


# Generated at 2022-06-22 18:50:57.398704
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = {
        'name': 'Ansible-TEST-Plugin',
        'filename': 'ansible/plugins/test/test.py',
        'description': 'It works!',
        'version_added': '2.5',
        'version_added_collection': 'ansible.posix',
        'options': {
            'foo': {
                'description': 'An Ansible-TEST-Plugin option',
                'default': False,
                'type': 'bool'
            }
        }
    }

    cli = DocCLI()
    cli.format_plugin_doc(doc)


# Generated at 2022-06-22 18:51:10.983306
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    import ansible.utils.module_docs as module_docs
    import ansible.module_utils.facts as module_facts
    import ansible.module_utils.basic as module_basic
    import ansible.plugins.action as action_plugins
    import ansible.plugins.callback as callback_plugins
    import ansible.plugins.connection as connection_plugins
    import ansible.plugins.shell as shell_plugins
    import ansible.plugins.lookup as lookup_plugins
    import ansible.plugins.strategy as strategy_plugins
    import ansible.plugins.vars as vars_plugins
    import ansible.plugins.filter as filter_plugins
    import ansible.plugins.test as test_plugins
    import ansible.plugins.doc_fragments as doc_fragments
    import ansible.plugins.cliconf as cliconf

# Generated at 2022-06-22 18:51:24.156232
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    from ansible.parsing.utils.extract_constants import namespace_from_plugin_filepath

# Generated at 2022-06-22 18:51:27.057186
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
  cli = DocCLI()
  DocCLI.display_plugin_list(cli, TEXT, plugin_type='module')


# Generated at 2022-06-22 18:51:32.304844
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'conf'
    add_collection_plugins(plugin_list, plugin_type)
    assert plugin_list.has_key('stdlib.config')


# TODO: move to utils

# Generated at 2022-06-22 18:51:35.973666
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('/abspath/Modules/net_tools.py') == 'net_tools'


# Generated at 2022-06-22 18:51:41.319393
# Unit test for function jdump
def test_jdump():
    from ansible.module_utils.common.json import from_json
    yaml_data = """
some_key: some value
"""
    json_data = jdump(yaml_data)
    data = from_json(json_data)
    assert data == {'some_key': 'some value'}
    jdump('test')


# TODO: this should be in a common-utility lib:

# Generated at 2022-06-22 18:51:48.629850
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    c = DocCLI()
    c.doc = {'name': 'test-name'}
    c.collection_name = 'test-collection'
    c.plugin_type = 'test-type'
    metadata = c.get_plugin_metadata()
    assert metadata == {'name': 'test-name', 'collection': 'test-collection', 'type': 'test-type'}



# Generated at 2022-06-22 18:52:00.901332
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    role_names = ('test_role',)
    roles_path = ('test_path/roles',)
    entry_point = None

    # 1. no match
    roles = []
    collroles = []

    result = {}

    for role, role_path in roles:
        argspec = {}
        fqcn, doc = _build_doc(role, role_path, '', argspec, entry_point)
        if doc:
            result[fqcn] = doc

    for role, collection, collection_path in collroles:
        argspec = {}
        fqcn, doc = _build_doc(role, collection_path, collection, argspec, entry_point)
        if doc:
            result[fqcn] = doc

    # 2. some match, one role exists

# Generated at 2022-06-22 18:52:06.542195
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    e = DocCLI()
    assert 'test' == e.namespace_from_plugin_filepath('/test/test.py')
    assert 'test' == e.namespace_from_plugin_filepath('/test/test/test.py')
    assert 'test' == e.namespace_from_plugin_filepath('/test/test/test/test.py')
    assert '' == e.namespace_from_plugin_filepath('/test.py')


# Generated at 2022-06-22 18:52:13.715582
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    try:
        from tests import test_utils
    except:
        # ansible-doc should be able to run with or without ansible present
        # We can't test module arg parsing without ansible, so skip this test
        pass
    else:
        # create a fake module
        plugin_name = 'napalm_get_arp'

# Generated at 2022-06-22 18:52:15.419691
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    doccli = DocCLI()
    # str, dict -> str
    pass


# Generated at 2022-06-22 18:52:16.760099
# Unit test for constructor of class DocCLI
def test_DocCLI():
    pass


# Generated at 2022-06-22 18:52:27.544459
# Unit test for method find_plugins of class DocCLI

# Generated at 2022-06-22 18:52:33.570188
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc = DocCLI()
    test = doc._find_plugins(plugin_type = 'module', paths = ['/Users/mjmiller/Documents/Ansible/ansible/lib/ansible/modules/core'])
    assert '/Users/mjmiller/Documents/Ansible/ansible/lib/ansible/modules/core/copy.py' in test

# Generated at 2022-06-22 18:52:34.297178
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    pass

# Generated at 2022-06-22 18:52:41.626759
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('./collection/ansible_namespace/plugins/module_utils/foo.py') == 'ansible_namespace'
    assert DocCLI.namespace_from_plugin_filepath('/path/to/collection/ansible_namespace/plugins/module_utils/foo.py') == 'ansible_namespace'
    assert DocCLI.namespace_from_plugin_filepath('/path/with/no/collection/plugins/module_utils/foo.py') == ''

# Generated at 2022-06-22 18:52:53.348117
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    # Initialize module and call method directly.
    DOC = DocCLI()
    def mock_method():
        return DOC.print_paths()

    # Set mocks
    DOC.find_collection_names = mock.Mock(return_value=(['ansible_namespace.my_collection', 'my_namespace.my_collection'], ['ansible_namespace', 'my_namespace']))
    DOC.print_paths_for_namespace = mock.Mock(return_value=True)
    DOC.print_paths_for_collection = mock.Mock(return_value=True)
    DOC.print_collections = mock.Mock(return_value=True)

    # Call method
    mock_method()

    # Assert that mocks were called.
    DOC.find_collection_names.assert_

# Generated at 2022-06-22 18:53:04.453150
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    #from ansible.module_utils import basic
    run_from_path("ansible-doc")
    run_from_path("ansible-doc --module-name system")

if __name__ == '__main__':
    # Test method run of class DocCLI:
    test_DocCLI_run()

# ansible-doc import 'core.basic'
import abc
from ansible.module_utils.six import with_metaclass

try:
    from __main__ import display
except ImportError:
    from ansible.utils.display import Display
    display = Display()

import codecs
import fcntl
import glob
import grp
import json
import os
import pwd
import re
import shutil
import stat
import sys
import tempfile
import textwrap
import time



#

# Generated at 2022-06-22 18:53:08.061536
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    cmd = DocCLI()
    parser = cmd.init_parser()

    assert isinstance(parser, argparse.ArgumentParser)
    assert len(parser._actions) == 5



# Generated at 2022-06-22 18:53:10.934168
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    cli = DocCLI()
    parser = cli.init_parser()
    assert isinstance(parser, argparse.ArgumentParser) == True

# Generated at 2022-06-22 18:53:11.569504
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    pass

# Generated at 2022-06-22 18:53:21.823091
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = max(display.columns - 6, 70)
    collections = get_collection_name()
    mod_name = 'ec2_vpc'
    data = load_documentation_file(collections, mod_name)
    return_values = []
    return_values.append(data['doc']['return'])
    DocCLI.add_fields(text, data['doc']['options'], limit, "        ", return_values)
    assert text[0] == "        by_default               Choices: [yes, no]"
    assert text[3] == "        domain                   Nested dictionary with values dependant on I(action)"
    assert text[4] == "            id                   The id of the domain."

# Generated at 2022-06-22 18:53:25.012887
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    d = DocCLI()
    ret = d.get_all_plugins_of_type()
    assert(ret is not None)


# Generated at 2022-06-22 18:53:28.395216
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    import doctest
    failed, tests = doctest.testmod(DocCLI, optionflags=doctest.NORMALIZE_WHITESPACE)
    assert failed == 0


# Generated at 2022-06-22 18:53:30.880896
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound("foo")
    except PluginNotFound as e:
        assert str(e) == "foo"
    else:
        assert False



# Generated at 2022-06-22 18:53:33.135194
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    assert DocCLI.find_plugins() == 1, "DocCLI.find_plugins should return 1"


# Generated at 2022-06-22 18:53:46.080898
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    from ansible.cli.arguments import options as cli_options
    from ansible.module_utils.six import string_types

    def test_file_help_txt(filename):
        doc_file = os.path.join(os.path.dirname(__file__), 'doc_files', filename)
        # read the doc file
        with open(doc_file, "r") as f:
            doc = json.load(f)
            # Now generate the text
            help_txt = DocCLI.get_man_text(doc, collection_name=filename.split('.')[0])
            # validate the output text
            assert isinstance(help_txt, string_types)
            assert len(help_txt) > 0


# Generated at 2022-06-22 18:53:50.853412
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    code = '@property\n    def get_snippet(self,):\n        "foo"'
    snippet = DocCLI.format_snippet(code)
    assert snippet == '@property\n  def get_snippet(self,):\n      "foo"'


# Generated at 2022-06-22 18:54:01.262689
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    doc = collections.namedtuple('D', ['doc', 'version_added', 'version_added_collection', 'collection_name'])
    doc.doc = {'version_added': 1, 'version_added_collection': 2}

    display_options = [('Author', 'author'), ('Short Description', 'description'), ('Description', 'long_description')]
    docopt = """\
ANSIBLE DOCUMENTATION

Usage:
  ansible-doc -t <type> <plugin>
  ansible-doc -l
  ansible-doc -e <error>
  ansible-doc -s [<module> ...]
  ansible-doc -h

Options:
  -h --help  Show this screen.
"""
    import os

# Generated at 2022-06-22 18:54:07.797240
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-22 18:54:20.628429
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Tests the ansible-doc utility in a dummy environment
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import MutableMapping

    for module in (get_module_path('meta'), get_module_path('test_doc')):
        # Create a dummy module for testing
        name = module.split('/')[-1]
        if name in ('test_doc.py', 'meta.py'):
            continue
        if name == 'meta':
            name = 'meta.py'

        # Create a dummy module for testing
        dummy_module = AnsibleModule(
            argument_spec=dict()
        )
        module_name = name.rsplit('.py')[0].replace('_', ' ')

        # Create a dummy module for

# Generated at 2022-06-22 18:54:22.896007
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc = DocCLI(args=dict())
    assert doc is not None
    doc.run()

# Generated at 2022-06-22 18:54:24.267036
# Unit test for constructor of class DocCLI
def test_DocCLI():
    assert DocCLI()


# Generated at 2022-06-22 18:54:30.959330
# Unit test for constructor of class DocCLI
def test_DocCLI():
    # Test load_doc option
    cli_doc = DocCLI({'load_doc': True})
    assert cli_doc is not None, 'DocCLI object creation failed'
    assert cli_doc.options['load_doc'] is True, 'DocCLI object creation failed'

    # Test no option
    cli_doc = DocCLI()
    assert cli_doc is not None, 'DocCLI object creation failed'
    assert cli_doc.options.get('load_doc', False) is False, 'DocCLI object creation failed'



# Generated at 2022-06-22 18:54:43.768961
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    args = Mock()
    args.doc_format = None
    args.module = None
    args.module_path = None
    args.module_paths = []
    args.name = None
    args.resource = None
    args.role = None
    args.checkout = None
    args.directory = None
    args.type = "module"
    args.ref_branch = None
    args.commit = None
    args.diff = None
    args.network_depth = 1
    args.fetch_depth = 1
    args.verbosity = 0
    result = DocCLI.post_process_args(args, 'module')
    assert(result == (None, None, None, 'module', None, None, None, False, False, False, False, None, None, None, 1, 1, 0))



# Generated at 2022-06-22 18:54:47.733401
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():

    dc = DocCLI()
    # This is a dict.
    plugins = dc.get_all_plugins_of_type(None, 'action')

    assert type(plugins) == dict
    assert len(plugins) > 0


# Generated at 2022-06-22 18:54:51.135467
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    text = DocCLI.display_plugin_list(['noop'], 'action')
    assert isinstance(text, string_types)


# Generated at 2022-06-22 18:54:55.864444
# Unit test for method run of class DocCLI
def test_DocCLI_run():
  doc = {}
  cli = CliRunner()
  result = cli.invoke(DocCLI.run, ['module', 'shell'], obj=doc)
  assert result.exit_code == 0
  assert result.output == "TODO"

# Generated at 2022-06-22 18:55:09.128780
# Unit test for method find_plugins of class DocCLI

# Generated at 2022-06-22 18:55:17.678896
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # noqa: F821 undefined name
    opt_indent = "        "

    # Test that the get_role_man_text() method will print the role name
    # in uppercase
    role = 'testrole'
    role_json = {'path': 'path/to/testrole',
                 'entry_points': {
                     'main': {
                         'description': 'The description for this role.'
                     },
                     'alternate': {
                         'description': 'Another description.'
                     }
                 }}
    text = DocCLI.get_role_man_text(role, role_json)
    assert text[0:1] == ["> TESTROLE    (path/to/testrole)\n"]

    # Test that the get_role_man_text() method will print the first
    # entry point in

# Generated at 2022-06-22 18:55:28.455984
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Test that a string is returned for a non-boolean value of the option list
    params_are_boolean = False
    res = DocCLI.from_yaml("plugins/action/copy.py").format_plugin_doc("plugins/action/copy.py", params_are_boolean)
    assert isinstance(res, string_types)

    # Test that a list of strings is returned for a boolean value of the option list
    params_are_boolean = True
    res = DocCLI.from_yaml("plugins/action/copy.py").format_plugin_doc("plugins/action/copy.py", params_are_boolean)
    assert isinstance(res, list)
    assert isinstance(res[0], string_types)


# Generated at 2022-06-22 18:55:40.281401
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-22 18:55:50.248658
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    rolemixin = RoleMixin()
    assert rolemixin._ROLE_ARGSPEC_FILES == ['argument_specs' + e for e in C.YAML_FILENAME_EXTENSIONS] + ["main" + e for e in C.YAML_FILENAME_EXTENSIONS]
    assert RoleMixin.ROLE_ARGSPEC_FILES == ['argument_specs' + e for e in C.YAML_FILENAME_EXTENSIONS] + ["main" + e for e in C.YAML_FILENAME_EXTENSIONS]
    assert rolemixin._ROLE_ARGSPEC_FILES == RoleMixin.ROLE_ARGSPEC_FILES
    assert rolemixin._load_argspec('role', None, None) == {}


# Generated at 2022-06-22 18:56:01.755154
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    args = Mock()
    args.type = None
    args.versioned = False

    cli = DocCLI(args)

    metadata = cli.get_plugin_metadata('key_to_value')

    assert metadata
    assert type(metadata) is dict

    class_obj = type('', (), {})
    class_obj_mock = Mock()
    class_obj_mock.metadata.return_value = class_obj
    class_obj_mock.get_filename.return_value = "/path/to/file/key_to_value.py"
    metadata = cli.get_plugin_metadata(class_obj_mock)

    assert metadata
    assert type(metadata) is dict


# Generated at 2022-06-22 18:56:07.674352
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    args = mock.MagicMock()
    args.get_one.side_effect = lambda x: None
    args.plugin_type = 'module'
    assert DocCLI().post_process_args(args) is None
    args.get_one.assert_called_once_with('type')


# Generated at 2022-06-22 18:56:18.673962
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc = DocCLI('')
    assert doc
    doc.get_man_text({'name': 'ping', 'doc': {'short_description': 'this is the module', 'description': 'this is a description of the module'}})
    doc.get_man_text({'name': 'ping', 'doc': {'short_description': 'this is the module', 'Description': 'this is a description of the module'}})
    doc.get_man_text({'name': 'ping', 'doc': {'short_description': 'this is the module', 'Description': '', 'options': ''}})
    doc.get_man_text({'name': 'ping', 'doc': {'short_description': 'this is the module', 'Description': '', 'options': '', 'notes': ''}})
    doc.get_man

# Generated at 2022-06-22 18:56:31.065003
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Create temporary file for testing
    stdout = sys.stdout
    stdin = sys.stdin
    stderr = sys.stderr
    temp_fd, temp_path = tempfile.mkstemp()

# Generated at 2022-06-22 18:56:41.523373
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc_cli = DocCLI()
    assert doc_cli.get_all_plugins_of_type(
        ['doc_fragments'], 'doc_fragments', 'doc_fragments'
    ) == {}

    # Not sure if it's worth testing methods
    # get_plugin_man_dir, get_doc, get_man_text,
    # get_all_plugins, get_man_text, get_man_entry,
    # get_man_text, get_man_text, get_role_man_text, and
    # get_man_text as they call os and other external modules



# Generated at 2022-06-22 18:56:54.049457
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    print('Test: DocCLI.get_role_man_text')
    test_cli = DocCLI()
    # there's a big difference between 'doc' and 'doc_fragment' when it comes to role metadata
    # so we'll test both here

# Generated at 2022-06-22 18:57:05.356176
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    opts = DocCLIOptionParser()
    options, args = opts.parse_args([])
    doc = DocCLI(options=context.CLIARGS, doc=None)

    assert doc.namespace_from_plugin_filepath('/home/foo/bar/baz/collection/ns/module/a.py') == 'collection.ns.module.a'
    assert doc.namespace_from_plugin_filepath('/home/foo/bar/baz/collection/ns/module/a.py', collection_namespace='collection') == 'ns.module.a'
    assert doc.namespace_from_plugin_filepath('/home/foo/bar/baz/collection/ns/module/a.py', collection_namespace='ns') == 'module.a'
    assert doc.namespace_from_plugin

# Generated at 2022-06-22 18:57:15.906980
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    limit = 70
    opt_indent = "        "
    return_values = False

# Generated at 2022-06-22 18:57:22.568737
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    """Unit tests for method print_paths of class DocCLI"""
    import json
    import os
    import sys
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.utils.path import unfrackpath
    from ansible.parsing.utils.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.display import Display
    display = Display()

    # Test 1
    display.verbosity = 3
    fd = None
    paths = {'foo': 'bar'}

# Generated at 2022-06-22 18:57:31.873007
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    _create_test_dirs_and_files(['callback', 'lookup', 'shell', 'vars'])
    context.CLIARGS = {}
    context.CLIARGS['verbosity'] = 0
    plugins_paths = ('callback_plugins', 'lookup_plugins', 'shell_plugins', 'vars_plugins')
    for plugin_type in plugins_paths:
        plugins = DocCLI.get_all_plugins_of_type(plugin_type)
        assert len(plugins) == 1
    _remove_test_dirs_and_files(['callback', 'lookup', 'shell', 'vars'])


# Generated at 2022-06-22 18:57:34.661083
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    DocCLI_obj = DocCLI()
    DocCLI_obj.get_all_plugins_of_type()


# Generated at 2022-06-22 18:57:44.458220
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    from ansible.plugins.loader import find_plugin_files
    from ansible.config.manager import ConfigManager
    # Assign to class variable ANSIBULL_DATA_DIR
    DocCLI.ANSIBULL_DATA_DIR = './ansibullbot'
    # create a DocCLI instance
    context.CLIARGS = {'type': 'module'}
    dc = DocCLI()
    # Execute method
    modules, _ = dc.get_all_plugins_of_type('module')
    # Check number of plugins
    assert len(modules) == len(list(find_plugin_files(ConfigManager.instance().extra_module_paths, 'module')))
    # Check existence of a module
    assert 'win_acl' in modules, "win_acl module does not exist"
    # Check a module's

# Generated at 2022-06-22 18:57:48.840330
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    doc_cli = DocCLI()
    doc_cli.format_snippet('short_name','filename', 'long_name','snippet')


# Generated at 2022-06-22 18:58:00.723740
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    doc = DocCLI.format_plugin_doc(dict(autoflush=False, binary_file=False, supports_check_mode=True, required_if=['a', 'b', 'c']))
    assert doc == "autoflush: if this is True, the output will automatically\n    be flushed each time a new line is\n    produced.\nbinary_file: This will be set to True if the output of\n    the command being run will be binary\n    in nature.\nsupports_check_mode: If this is set to True, the module will be able\n    to report if changes were made or not\n    when the check mode is specified.\nrequired_if:\n    - a\n    - b\n    - c\n"


# Generated at 2022-06-22 18:58:03.449689
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    plugins = DocCLI.find_plugins()
    assert len(plugins) > 0


# Generated at 2022-06-22 18:58:14.959045
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    print("\n*** Begin testing DocCLI.namespace_from_plugin_filepath() ***")
    
    # Create some test data

# Generated at 2022-06-22 18:58:27.745010
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    my_doc_cli = DocCLI()
    my_doc_cli.pager = False
    my_doc_cli.docsite = "https://docs.ansible.com/"
    my_doc_cli.version = '2.9.9'
    my_doc_cli.module_path = '<ansible:module_path>'
    my_doc_cli.collection_path = ['/fake_collection/plugins/modules']
    plugin_loaders._find_plugins()
    matches = my_doc_cli.find_plugins(['fake_module'])
    assert len(matches) == 1, \
        'len(%s) == 1 failed' % (matches)
    assert matches[0] == 'module', \
        "%s == 'module' failed" % (matches[0])
    matches = my

# Generated at 2022-06-22 18:58:30.379865
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    error = PluginNotFound('some error')
    assert isinstance(error, PluginNotFound)
    assert isinstance(error, Exception)
    assert str(error) == 'some error'



# Generated at 2022-06-22 18:58:33.954427
# Unit test for function jdump
def test_jdump():
    ''' This function is for testing jdump() '''
    # pylint: disable=unused-argument
    from ansible.utils.display import Display
    fake_display = Display()
    fake_display.verbosity = 4
    display = fake_display
    assert jdump({'abc': 'def'}) == None
    # pylint: enable=unused-argument



# Generated at 2022-06-22 18:58:46.345527
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    from ansible.cli.doc import DocCLI