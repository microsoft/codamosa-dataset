

# Generated at 2022-06-22 18:48:54.289798
# Unit test for constructor of class DocCLI
def test_DocCLI():
    class ModuleMock(object):
        def __init__(self, examples):
            self.examples = examples

    class DisplayMock(object):
        def __init__(self, columns):
            self.columns = columns

    display = DisplayMock(80)
    doc = {
        "description": "This is a short description.",
        "options": {},
        "examples": "this is the only example"
    }
    module = ModuleMock("these examples should be ignored")
    assert(DocCLI.get_man_text(doc, module=module) == '> UNNAMED    (null)\nThis is a short description.\n\nEXAMPLES:\n\nthis is the only example\n\n')

    doc['examples'] = ['']

# Generated at 2022-06-22 18:49:01.181480
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    from .compat import to_bytes

    doc = {'foo': 'bar'}
    metadata = DocCLI.get_plugin_metadata(doc)

    assert metadata == {
        b'search': {
            b'path': [b'bar'],
            b'name': [b'bar'],
        },
        b'keywords': [b'bar'],
        b'foo': b'bar',
    }

# Generated at 2022-06-22 18:49:03.821377
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    doc = DocCLI()
    doc.find_plugins()


# Generated at 2022-06-22 18:49:04.760944
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    pass

# Generated at 2022-06-22 18:49:06.217893
# Unit test for constructor of class DocCLI
def test_DocCLI():
    display = Display()
    DocCLI(display)
    assert True


# Generated at 2022-06-22 18:49:09.610059
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    cli = DocCLI()
    cli.options = {'type': 'module'}
    cli.parse(['ansible-doc', '-t', 'module', 'core'])
    cli.find_plugins()


# Generated at 2022-06-22 18:49:18.599499
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    from ansible import context
    from ansible.cli.doc import DocCLI
    from ansible.module_utils._text import to_text

    context.CLIARGS = DocCLI.base_parser(constants=constants, runas_opts=True, output_opts=True)

    docer = DocCLI(args=[])

    assert docer.role_names == []
    assert docer.roles_paths == (to_text(C.DEFAULT_ROLES_PATH),)



# Generated at 2022-06-22 18:49:22.844031
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    from ansible import context
    from ansible.cli import CLI
    from ansible.cli.galaxy import GalaxyCLI
    from ansible.module_utils.six.moves import configparser
    rmix = RoleMixin()
    results = rmix._create_role_list(('/development/ansible/roles',))
    print('Role list: %s' % results)
    results = rmix._create_role_doc(('testrole',), ('/development/ansible/roles',))
    print('Role doc: %s' % results)


# Generated at 2022-06-22 18:49:31.943555
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    """
    Test the method format_snippet of class DocCLI
    :return: None
    """

    print(DocCLI.format_snippet(['arg1', 'arg2'], indent=1))
    print(DocCLI.format_snippet('arg1 arg2', indent=1))
    print(DocCLI.format_snippet('arg1\narg2', indent=1))

    # test that wrapping works
    display.columns = 10

    # neither scheme will work given the above
    print(DocCLI.format_snippet('a b c d e f g h i j k l', indent=0))

# Generated at 2022-06-22 18:49:34.238849
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('roles/common/library/mymodule.py') == 'mymodule'


# Generated at 2022-06-22 18:49:46.874148
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []

# Generated at 2022-06-22 18:49:57.108169
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    from ansible.module_utils.six import BytesIO

    class Test:
        # For testing, Mock this
        @staticmethod
        def load_file(path):
            return None

    t = Test()
    r = RoleMixin()
    t.load_file = r._load_argspec
    a = r._load_argspec('test')
    a = r._load_argspec('test', '/tmp')
    a = r._load_argspec('test', None, '/tmp')
    b = r._find_all_normal_roles(('/tmp', ))
    b = r._find_all_collection_roles()
    b = r._build_doc('a', '/tmp', '', {}, 'main')
    b = r._build_doc('a', '/tmp', 'c', {}, None)

# Generated at 2022-06-22 18:50:00.463161
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound('My Message')
    except PluginNotFound as e:
        assert e
        assert str(e) == 'My Message'



# Generated at 2022-06-22 18:50:05.757273
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # Configure
    lib_path = 'lib/ansible/modules/indevelopment'

    # Invoke
    result = DocCLI.namespace_from_plugin_filepath(lib_path)

    # Verify
    assert result == 'indevelopment'


# Generated at 2022-06-22 18:50:15.861116
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Tests run if module is called in stand alone mode
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    doc = DocCLI(None, module, None)
    doc.run()

if __name__ == '__main__':
    # Import doctest for unit testing
    import doctest

    # Run unit tests
    doctest.testmod()

    # Run unit test for method run of class DocCLI
    test_DocCLI_run()

    # Run unit test for method get_man_text of class DocCLI
    test_DocCLI_get_man_text()

# Generated at 2022-06-22 18:50:20.529418
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    cmd = DocCLI(args = ['ansible-doc', 'moduletest1'])
    cmd.parse()
    cmd_result = cmd.get_plugin_metadata()
    assert cmd_result == True

# Generated at 2022-06-22 18:50:21.933550
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc = DocCLI()
    assert True


# Generated at 2022-06-22 18:50:25.189196
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = DocCLI()
    with pytest.raises(AnsibleError):
        doc.get_plugin_metadata(None, 'module', 'FooModule')


# Generated at 2022-06-22 18:50:26.566657
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    cli = DocCLI()
    return cli.find_plugins()

# Generated at 2022-06-22 18:50:28.418427
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    """Constructor for role mixin - does nothing but required for tests to run properly
    """
    pass


# Generated at 2022-06-22 18:50:30.619785
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    plugins = DocCLI.get_all_plugins_of_type('action')
    assert 'command' in plugins

# Generated at 2022-06-22 18:50:43.600569
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    from ansible.cli import CLI
    from ansible.utils.debug import disable_debug_logging
    from ansible.utils.display import Display
    from ansible.plugins.loader import cli_plugins
    display = Display()
    doc = DocCLI(display)
    args = CLI.base_parser(usage='test usage', runas_opts=False).parse_args(['-v'])
    del args.verbosity
    setattr(args, 'connection', 'local')
    setattr(args, 'force_handlers', False)
    setattr(args, 'module_path', None)
    setattr(args, 'new_vault_password_file', None)
    setattr(args, 'one_line', False)
    setattr(args, 'output_path', None)

# Generated at 2022-06-22 18:50:53.488488
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Create mock objects
    module_finder = AnsibleModuleFinder()
    doc_loader = ModuleDocRetriever(module_finder)

    # Test run method for 1st if condition where args['subcommand'] == 'list' and args['extensions'] is list
    doc_obj = DocCLI(['ansible-doc', '-l'], doc_loader)
    doc_obj.run()
    assert True

    # Test run method for 2nd if condition where args['subcommand'] == 'list'
    doc_obj = DocCLI(['ansible-doc', '-l', '--version'], doc_loader)
    doc_obj.run()
    assert True

    # Test run method for 4th if condition where args['subcommand'] == 'network'

# Generated at 2022-06-22 18:50:59.854947
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    r = RoleMixin()
    assert r._role_argspec_files == [
        'meta/argument_spec.yml', 'meta/argument_spec.yaml', 'meta/argument_specs.yml', 'meta/argument_specs.yaml',
        'meta/main.yml', 'meta/main.yaml'
    ]



# Generated at 2022-06-22 18:51:12.785283
# Unit test for constructor of class DocCLI
def test_DocCLI():
    module.params = {}
    # Test get_doc_bases_to_search and _extract_docstrings functions
    cli = DocCLI('setup')
    assert cli.files and len(cli.files) > 0
    # Test parse_doc function and write_man function
    for doc in cli.docs:
        cli.parse_doc(doc)
        cli.write_man({doc: cli.man[doc]}, 'module', 'setup')
    # Test get_man_text and get_role_man_text functions
    cli = DocCLI('meta', 'editor')
    for doc in cli.docs:
        cli.parse_doc(doc)
        cli.write_man({doc: cli.man[doc]}, 'role')

# Generated at 2022-06-22 18:51:19.541494
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    DocCLI_object = DocCLI()
    plugins = ['docsite_generator.py', '__init__.py']
    collection_name = ''
    plugin_type = ''
    result = DocCLI_object.find_plugins(plugins, collection_name, plugin_type)
    assert result['docsite_generator.py']['filename'].__contains__('/docsite_generator.py')
    assert result['docsite_generator.py']['filename'].__contains__('plugins')
    assert result['docsite_generator.py']['has_action'].__eq__(False)
    assert result['__init__.py']['filename'].__contains__('/__init__.py')
    assert result['__init__.py']['filename'].__contains

# Generated at 2022-06-22 18:51:21.730182
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc = DocCLI()
    assert doc is not None


# Generated at 2022-06-22 18:51:30.060795
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    logger = logging.getLogger('test_DocCLI_get_plugin_metadata')
    logger.info("+++ START +++")
    # Workflow

# Generated at 2022-06-22 18:51:41.914814
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    doc = DocCLI()
    result = doc.format_snippet('echo', 'Echo a message')
    assert result == 'Echo a message'

    result = doc.format_snippet('echo', 'Echo a message\non multiple\nlines')
    assert result == 'Echo a message on multiple lines'

    result = doc.format_snippet('echo', 'Echo a message\n\n    on multiple\n    lines with indentation')
    assert result == 'Echo a message\n\non multiple lines with indentation'

    result = doc.format_snippet('echo', 'Echo a message\n\n    on multiple\n    lines\n\nand two new lines')
    assert result == 'Echo a message\n\non multiple lines\n\nand two new lines'

   

# Generated at 2022-06-22 18:51:46.696348
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    test_obj = DocCLI()
    assert(test_obj.get_all_plugins_of_type()) == 'Deprecated, as of Ansible 2.7. Please use ansible-doc -t instead.'

# Generated at 2022-06-22 18:51:59.596972
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    run_function = lambda function: plugins.module_loader._load_plugins([''])(function)()
    run_function(lambda: setattr(DocCLI, 'IGNORE', DocCLI.IGNORE + ('ignore',)))
    run_function(lambda: setattr(DocCLI, 'IGNORE', DocCLI.IGNORE + ('alsoignore',)))
    assert ('ignore' not in DocCLI.IGNORE and 'alsoignore' not in DocCLI.IGNORE) == True
    text = run_function(lambda: DocCLI.format_snippet('gce.py', 'GCE', 'module', 'test/gce.py'))
    assert 'test/gce.py' in text
    assert 'Options' in text
    assert 'Vars' in text
    assert 'Return values' in text

# Generated at 2022-06-22 18:52:02.440694
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    '''
    Unit test for method post_process_args of class DocCLI
    '''
    DocCLI.post_process_args('')



# Generated at 2022-06-22 18:52:06.510732
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {'foo': {'bar': {}}}
    add_collection_plugins(plugin_list, 'module')
    assert isinstance(plugin_list, dict)
    assert isinstance(plugin_list['foo'], dict)
    assert isinstance(plugin_list['foo']['bar'], dict)

# Generated at 2022-06-22 18:52:08.987462
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    arguments = ['ansible-doc', 'ping']
    test_cli = DocCLI(args=arguments)
    result = test_cli.run()
    assert result == 0

# Generated at 2022-06-22 18:52:15.498684
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    from ansible.module_utils.basic import AnsibleModule, MissingModuleHookException
    from ansible.plugins.action import ActionBase
    from ansible import constants as C
    import ansible.utils.plugin_docs as plugin_docs
    from ansible.utils.display import Display

    C.DEFAULT_MODULE_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'modules'))

    doc = DocCLI()
    # Set display to terminal size of 100x40
    display = Display()
    display.columns = 100
    display.lines = 40
    display.screen_test = None

    class TestAction(ActionBase):
        TRANSFERS_FILES = False


# Generated at 2022-06-22 18:52:47.510993
# Unit test for constructor of class RoleMixin

# Generated at 2022-06-22 18:52:50.425215
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Get metadata for all plugins of type 
    for name in ('module', 'lookup', 'callback', 'filter', 'role_template'):
        docs = get_plugin_metadata(name, DocCLI.collect_doc).values()
        good = any([doc.get('metadata_version') for doc in docs])
        if not good:
            raise AssertionError('doc_fragments collect_doc does not appear to be working')

# Generated at 2022-06-22 18:52:51.273283
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    print('Not implemented')

# Generated at 2022-06-22 18:53:03.386145
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-22 18:53:04.275050
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
  pass


# Generated at 2022-06-22 18:53:13.368978
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    """
    Fake environment for doctest property testing
    """
    import doctest
    from ansible.tests.unit.utils import set_module_args

    class FakeEnvironment(object):
        def __init__(self, items):
            self._env = {}
            for k in items:
                self._env[k] = None

        def get(self, k, v=None):
            return self._env.get(k, v)

        def __contains__(self, k):
            return k in self._env

    # This not actually used in add_collection_plugins but it is used in the
    # syspath testing, which is in the same test_add_collection_plugins
    class FakeCLI(object):

        def __init__(self):
            self.args = None
            self.parser = None


# Generated at 2022-06-22 18:53:17.918306
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    doccli = DocCLI()
    plugin_path = "/lib/ansible/modules/system/ping.py"
    answer = "system.ping"
    assert doccli.namespace_from_plugin_filepath(plugin_path) == answer

# Generated at 2022-06-22 18:53:25.701039
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    cli = DocCLI()

# Generated at 2022-06-22 18:53:26.887144
# Unit test for constructor of class DocCLI
def test_DocCLI():
    DocCLI()
    assert True


# Generated at 2022-06-22 18:53:35.932066
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    import io
    import sys

    def test_format_snippet_output(test):
        f = io.BytesIO()
        orig_stdout = sys.stdout
        try:
            sys.stdout = f
            DocCLI.format_snippet(test['command'], test['snip'])
            sys.stdout.flush()
            return f.getvalue().decode('utf-8')
        finally:
            sys.stdout = orig_stdout
        return None


# Generated at 2022-06-22 18:53:43.975807
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    # create an instance of the class to be tested
    source = DocCLI()

    # template test case
    args = ["foo", "bar"]
    kwargs = {
        "baz": "qux"
    }
    expected = ["foo", "bar"]
    actual = source.post_process_args(*args, **kwargs)

    assert actual == expected
    # end of template test case



# Generated at 2022-06-22 18:53:47.896454
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    with pytest.raises(AnsibleError):
        cli = DocCLI(['--help'])
        cli.find_plugins()

# Generated at 2022-06-22 18:53:49.364508
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    text = DocCLI.get_man_text(text)


# Generated at 2022-06-22 18:53:58.534542
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    plugin_doc = _create_clidoc_from_doc(CLIModule().DOCUMENTATION)
    plugin_name = plugin_doc['name']
    del plugin_doc['name']
    opt_indent = "        "
    pad = display.columns * 0.20
    limit = max(display.columns - int(pad), 70)

    text = []

    text.append("> %s    (%s)\n" % (plugin_name.upper(), plugin_doc.pop('filename')))

    if isinstance(plugin_doc['description'], list):
        desc = " ".join(plugin_doc.pop('description'))
    else:
        desc = plugin_doc.pop('description')


# Generated at 2022-06-22 18:54:00.807847
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = DocCLI.parse()
    ret = DocCLI().run()
# class DeprecatedCLI

# Generated at 2022-06-22 18:54:13.409960
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    ns, fname = DocCLI.namespace_from_plugin_filepath('/path/to/collection/plugins/action/plugins/file.py')
    assert ns == 'collection.plugins.action.plugins'
    assert fname == 'file'
    ns, fname = DocCLI.namespace_from_plugin_filepath('/path/to/ansible/lib/ansible/plugins/action/file.py')
    assert ns == 'ansible.plugins.action'
    assert fname == 'file'
    ns, fname = DocCLI.namespace_from_plugin_filepath('/path/to/ansible/lib/ansible/plugins/action/__init__.py')
    assert ns == 'ansible.plugins.action'
    assert fname == ''

# Generated at 2022-06-22 18:54:25.885712
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # create a test C to test both methods
    test_C = DocCLI()
    data = {}
    data['name'] = 'ping'
    data['filename'] = 'ping.py'
    data['aliases'] = ['testing']
    data['module_name'] = 'ping'
    data['module_fullpath'] = 'ansible/modules/core/ping.py'
    data['module_args'] = 'data={"a": "b"}'
    data['docuri'] = '/doc/ping_module.html'
    data['description'] = 'Test module for testing'
    data['docuri'] = '/doc/ping_module.html'
    data['module'] = 'ping'
    data['params'] = ['data']
    data['requirements'] = ['requirements']

# Generated at 2022-06-22 18:54:27.635414
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    assert add_collection_plugins([], 'lookup') == []


# Generated at 2022-06-22 18:54:35.980339
# Unit test for function jdump
def test_jdump():
    import json
    import random
    test_obj = {}
    test_obj['id'] = random.randint(1, 1000)
    test_obj['text'] = 'This is a test'
    test_obj['test_obj'] = {'id': random.randint(1, 1000), 'text': 'This is a test'}
    test_obj['test_array'] = [random.randint(1, 1000), 'This is a test']
    obj_dump = json.dumps(test_obj, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)
    jdump(test_obj)
    assert obj_dump == display.display_variable


# Generated at 2022-06-22 18:54:38.402515
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    coll_filter = None
    plugin_type = 'module'
    plugin_list.update(DocCLI.find_plugins(os.path.join('path', 'plugins', 'module'), False, plugin_type, collection=coll_filter))
    


# Generated at 2022-06-22 18:54:52.284086
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    class MockCLI:
        def __init__(self, force_color=None, force_tty=None):
            self.pager = '/bin/cat'
            self.color = None
            self.args = []
            self.common_args = []
            self.force_color = force_color
            self.force_tty = force_tty
    DocCLI.IGNORE = DocCLI.IGNORE + ('foo',)
    cli = MockCLI()
    dc = DocCLI(cli)

    dc.run([])
    assert cli.args == []
    assert 'action' in cli.common_args
    assert cli.common_args['action'].default == 'list'
    assert 'version' in cli.common_args
    assert cli.common_args['version'].default == False

# Generated at 2022-06-22 18:55:00.420898
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Set up mock input and expected output for method
    meta = [
        ['module', 'TestModule'],
        ['author', 'Bobby Tables'],
        ['documenation_fragment', 'True'],
        ['version_added', '2.5'],
        ['options',
         {'foo': {'type': 'string', 'required': 'yes', 'description': 'the frobnozz to use'}},
         {'bar': {'type': 'list', 'required': 'no', 'description': 'list of things', 'options': {'foo': {'type': 'string', 'required': 'yes', 'description': 'the frobnozz to use'}}}}],
        ['extends_documentation_fragment', 'network_common'],
        ['notes', 'These things to note']
    ]


# Generated at 2022-06-22 18:55:07.706068
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    context._init_global_context(None)
    cli = DocCLI(['', '-lt', 'action'])
    cli.get_all_plugins_of_type()
    assert context.CLIARGS['type'] == 'action'
    assert isinstance(context.CLIARGS['pipelining'], bool)
    assert isinstance(context.CLIARGS['listt'], bool)



# Generated at 2022-06-22 18:55:10.067465
# Unit test for constructor of class DocCLI
def test_DocCLI():
    # Create object
    doci = DocCLI()
    assert isinstance(doci, DocCLI)

# Generated at 2022-06-22 18:55:18.035878
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-22 18:55:24.683815
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    assert False, "No tests for this class"
# Unit tests for class DocCLI
import sys
if (sys.version_info[0] > 2) and (not sys.version_info[1] >= 5) or (sys.version_info[0] < 2):
    from ansible.module_utils.six import PY3
else:
    from ansible.module_utils.six import PY3


# Generated at 2022-06-22 18:55:32.845883
# Unit test for function add_collection_plugins

# Generated at 2022-06-22 18:55:41.936264
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    from ansible.utils.import_plugins import namespace_from_plugin_filepath
    # Test with a file path
    filepath = '/home/is/robbertkl/dev/ansible/lib/ansible/modules/foo/bar/baz.py'
    assert namespace_from_plugin_filepath(filepath) == 'foo.bar'
    # Test with a non file path
    filepath = 'foo.py'
    assert namespace_from_plugin_filepath(filepath) == None

# Generated at 2022-06-22 18:55:49.695612
# Unit test for function jdump
def test_jdump():
    snip_out = {'lookup': [{'name': 'fqdn_all', 'doc': None, 'type': ['lookup'],
                            'short_description': 'returns a list of all the fqdns on the system',
                            'version_added': '', 'description': ['By default, this lookup returns a list of all the FQDNs on the system. This can be used in a play to gather the hosts in a play and then pass them to a role, for example.', 'If you pass in a list of names or ips, it will return the fqdn for each item in the list that has one.']}]}
    jdump(snip_out)



# Generated at 2022-06-22 18:55:56.202192
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    path = 'lib/ansible/modules/core/test_module.py'
    expected = {'path': path, 'namespace': 'core'}
    actual = DocCLI.namespace_from_plugin_filepath(path)
    assert actual == expected, 'Expected result %s, not %s' % (expected, actual)

    path = 'lib/ansible/modules/test_module.py'
    expected = {'path': path, 'namespace': 'ansible'}
    actual = DocCLI.namespace_from_plugin_filepath(path)
    assert actual == expected, 'Expected result %s, not %s' % (expected, actual)

    path = 'lib/ansible/modules/core/network/bigswitch/test_role.py'

# Generated at 2022-06-22 18:56:05.919844
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # create a doc_loader collector
    doc_collector = DocCLI.DocCLI([])
    test_dict = dict(
        description="This is a test description.",
        options=dict(
            test_option="This is a test option.",
            another_option="This is another test option."
        )
    )
    # call the function we are testing
    text_returned = doc_collector.get_man_text(test_dict, "", "")
    # the second option should be indented when it is a list
    assert(text_returned.split("\n")[-3] != text_returned.split("\n")[-4])


# Generated at 2022-06-22 18:56:16.821721
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-22 18:56:19.933445
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    output = DocCLI.get_all_plugins_of_type('.*network.*', 'module')
    assert len(output) != 0, 'Ansible modules not found'


# Generated at 2022-06-22 18:56:20.900644
# Unit test for constructor of class DocCLI
def test_DocCLI():
    assert DocCLI(r'')


# Generated at 2022-06-22 18:56:34.672360
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    from ansible.utils.display import Display

    display = Display()


# Generated at 2022-06-22 18:56:37.248167
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
	cls = DocCLI()
	cls.get_all_plugins_of_type()
	assert True

# Generated at 2022-06-22 18:56:40.252710
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc_cli = DocCLI()
    output = doc_cli.get_all_plugins_of_type('lookup')
    assert isinstance(output,list)


# Generated at 2022-06-22 18:56:47.905622
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    ansible_doc = DocCLI('')
    ansible_doc.find_module = MagicMock(return_value=dict(path='my_module_path'))

    with patch.object(DocCLI, '_load_module') as mock_load:
        mock_load.return_value = dict(ANSIBLE_METADATA=dict(DOCUMENTATION='my_new_module_documentation'))
        ansible_doc.run()

    mock_load.assert_called_with('my_module_path')
    assert ansible_doc.module_args == dict(ANSIBLE_METADATA=dict(DOCUMENTATION='my_new_module_documentation'))



# Generated at 2022-06-22 18:56:54.049341
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    cli = DocCLI(['ansible-doc', '--version'])
    # Ensure the value returned by get_all_plugins_of_type method is not empty
    assert not cli._get_all_plugins_of_type() == [], "Unit test for method get_all_plugins_of_type of class DocCLI failed. The get_all_plugins_of_type method of class DocCLI returns an empty value."

# Generated at 2022-06-22 18:57:05.355437
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc = DocCLI()
    #Both are needed to pass the test
    assert doc._create_ansible_metadata('') == doc._create_ansible_metadata('1')
    assert doc._create_ansible_metadata('1') == doc._create_ansible_metadata(1)
    assert doc._create_ansible_metadata(1) == doc._create_ansible_metadata(1.0)
    assert doc._create_ansible_metadata(1.0) == doc._create_ansible_metadata(True)
    assert doc._create_ansible_metadata(True) == doc._create_ansible_metadata(False)
    assert doc._create_ansible_metadata(False) == doc._create_ansible_metadata([])
    assert doc._create_ansible_metadata(False) == doc._create_ansible_metadata

# Generated at 2022-06-22 18:57:09.603630
# Unit test for function jdump
def test_jdump():
    test = {'a': 'a', 'b': 'b'}
    try:
        jdump(test)
    except AnsibleError:
        raise AssertionError('jdump() produced an AnsibleError when it should have not.')


# Generated at 2022-06-22 18:57:14.689900
# Unit test for constructor of class DocCLI
def test_DocCLI():
    desc = "This is test plugin"
    options = {
        'test_option1': dict(description='This is test option 1', required=True),
        'test_option2': dict(description='This is test option 2', required=False, default=True)
    }

    doc = DocCLI(desc, options)
    assert doc.description == desc
    assert doc.options == options



# Generated at 2022-06-22 18:57:28.019108
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    """
    Unit test for method get_man_text of class DocCLI
    """
    # Test 1: Test with IPv6 address as argument
    description = "Gets the MAC address by querying the device."
    doc = {
        'description' : description,
        'options' :
        {
            'dest': {
                'version_added': '1.0',
                'description': 'Device to connect to',
                'required': True
            },
        },
    }

# Generated at 2022-06-22 18:57:38.507272
# Unit test for function jdump
def test_jdump():
    import ansible.module_utils.common.json as json
    from ansible.module_utils.common.json import AnsibleJSONEncoder

    class myclass(object):
        def __init__(self, a=None, b=None, c=None):
            self.a = a
            self.b = b
            self.c = c

    t = myclass(1, 2, 3)
    test1 = jdump(t)
    if not isinstance(test1, str):
        raise AssertionError("test1 did not return a string")
    if not "\"a\": 1" in test1:
        raise AssertionError("test1 did not return a JSON str that contained '\"a\": 1'")



# Generated at 2022-06-22 18:57:41.213702
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    doc = DocCLI()
    assert isinstance(doc.parser, argparse.ArgumentParser)
    assert doc.args == []


# Generated at 2022-06-22 18:57:42.698737
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    doc = DocCLI()
    doc.print_paths()

# Generated at 2022-06-22 18:57:54.013490
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    from ansible.utils.plugin_docs import namespace_from_plugin_filepath
    # assert namespace_from_plugin_filepath(plugin_path) == expected_result
    assert namespace_from_plugin_filepath("/home/user/projects/ansible/lib/ansible/plugins/inventory/awx.py") == ("inventory", "awx")
    assert namespace_from_plugin_filepath("/home/user/projects/ansible/lib/ansible/plugins/filter/core.py") == ("filter", "core")
    assert namespace_from_plugin_filepath("/home/user/projects/ansible/lib/ansible/plugins/action/core.py") == ("action", "core")

# Generated at 2022-06-22 18:58:03.157981
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # Test with fake template
    content = '{{foo}}'
    snippet = dict(module='test', content=content)
    result = DocCLI.format_snippet(snippet)

    assert (content, None) == result

    # Test with real template
    with open(os.path.join(test_docs.fixtures_path, 'test_module_doc.py')) as test_module_fp:
        snippet = dict(module='test', content=test_module_fp.read())
        result = DocCLI.format_snippet(snippet)

    with open(os.path.join(test_docs.fixtures_path, 'test_module_doc_output.rst')) as test_module_output_fp:
        assert (test_module_output_fp.read(), None) == result

# Generated at 2022-06-22 18:58:05.430201
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound
    except PluginNotFound:
        pass



# Generated at 2022-06-22 18:58:15.567840
# Unit test for method get_role_man_text of class DocCLI

# Generated at 2022-06-22 18:58:19.270712
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Run the run method for class DocCLI
    ret = DocCLI.run()
    assert isinstance(ret, DocCLI)

# Generated at 2022-06-22 18:58:29.873257
# Unit test for method display_plugin_list of class DocCLI

# Generated at 2022-06-22 18:58:31.063966
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    import doctest
    doctest.testmod(verbose=False)



# Generated at 2022-06-22 18:58:37.453848
# Unit test for method get_all_plugins_of_type of class DocCLI

# Generated at 2022-06-22 18:58:38.599581
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
  pass # stub method


# Generated at 2022-06-22 18:58:50.014786
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    """Unit test for method run of class DocCLI
    """
    # Testing with 'module' as a type and connection as a module
    doc_cli = DocCLI(mock.Mock(type='module'),
                     ['connection'])
    # The module is connection and it is skipped from the AnsibullbotSkipModules
    # the actual_call will return 0
    assert doc_cli.run() == 0

    # Testing with 'module' as a type and connection as a module and the
    # module is not skipped from the AnsibullbotSkipModules.
    doc_cli = DocCLI(mock.Mock(type='module'),
                     ['somemodule'])
    # The module is not skipped from AnsibullbotSkipModules
    # the actual_call will return 1