

# Generated at 2022-06-22 18:48:57.997532
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():

    # Testing string_types
    result = []
    options = {'description': 'This is a description.'}
    DocCLI.add_fields(result, options, display.columns, '    ')
    assert(result == ['    DESCRIPTION: This is a description.'])

    # Testing Sequence
    result = []
    options = {'aliases': ['This', 'is', 'a', 'sequence']}
    DocCLI.add_fields(result, options, display.columns, '    ')
    assert(result == ['    ALIASES: This, is, a, sequence'])

    # Testing Sequence with empty element
    result = []
    options = {'aliases': ['This', '', '', '', '']}
    DocCLI.add_fields(result, options, display.columns, '    ')


# Generated at 2022-06-22 18:48:59.480755
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    pass


# Generated at 2022-06-22 18:49:10.885774
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    import tempfile
    from ansible.utils.hashing import checksum_s

    # no plugin type
    assert DocCLI.get_plugin_metadata(plugin=None) == {}

    # no plugin found
    assert DocCLI.get_plugin_metadata(plugin='') == {}

    # executable plugin
    with tempfile.NamedTemporaryFile('w', delete=False) as f:
        f.write('#!/usr/bin/env python\n\n')
        f.write('def main():\n')
        f.write('    pass\n\n')
        f.write('if __name__ == "__main__":\n')
        f.write('    main()')

    file_name = f.name
    metadata = DocCLI.get_plugin_metadata(plugin=file_name)

   

# Generated at 2022-06-22 18:49:24.808820
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    '''test_DocCLI_format_snippet'''
    # *** Set up for testing
    # Fails if there is no argument
    if DocCLI.format_snippet() == True:
        raise AssertionError('DocCLI.format_snippet() with no args should return True')

    # Works if all is well
    if DocCLI.format_snippet('ls', '', 0) == False:
        raise AssertionError('DocCLI.format_snippet() with correct args should return False')

    # *** Test edge cases
    # Fails if search string contains a space, but not a comma

# Generated at 2022-06-22 18:49:30.039325
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    '''
    Test method DocCLI.get_role_man_text
    '''
    doc = dict(description='This is a test module')
    ret = DocCLI.get_role_man_text('dummy', doc)
    assert ret == [
        '> DUMMY    ()\n',
        'ENTRY POINT: DUMMY - This is a test module\n'
    ]


# Generated at 2022-06-22 18:49:42.197002
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-22 18:49:43.329516
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    pass


# Generated at 2022-06-22 18:49:51.761685
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # as in: 
    # https://github.com/ansible/ansible-modules-core/blob/devel/cloud/amazon/ec2_asg.py
    plugin_filepath=u'cloud/amazon/ec2_asg.py'
    test_ns=u'cloud.amazon.ec2_asg'
    assert DocCLI._namespace_from_plugin_filepath(plugin_filepath)==test_ns, \
        "Expected plugin filepath to return namespace '{}' as '{}'".format(
            plugin_filepath,test_ns)


# Generated at 2022-06-22 18:49:53.591267
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    r = RoleMixin()
    r._create_role_list(('/bad/path',))


# Generated at 2022-06-22 18:49:57.107443
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc = DocCLI()
    doc.display_plugin_list([{'name': 'test', 'filename': '/test'}])
    assert True


# Generated at 2022-06-22 18:50:10.502160
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Set up mock objects
    mock_display = mock.Mock()
    mock_options = mock.Mock()
    mock_options.verbosity = 0
    mock_options.show_snippet = None
    mock_options.json_indent = None
    mock_args = mock.Mock()
    mock_args.path = None
    mock_args.help = None
    mock_args.connection = None
    mock_args.module_name = None
    mock_args.type = None
    mock_args.name = 'mymodule'
    mock_args.collection_name = 'mycollection'
    mock_args.extras = []
    mock_args.connection_name = None
    mock_args.foo = False

    # Set up the class we are testing

# Generated at 2022-06-22 18:50:21.983013
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    '''Test for method get_all_plugins_of_type of class DocCLI'''
    from ansible.plugins import module_loader, lookup_loader
    from ansible.module_utils.six.moves import builtins
    doc = DocCLI(module_loader, lookup_loader, builtins, context.CLIARGS)

    assert hasattr(doc, 'get_all_plugins_of_type')
    assert callable(getattr(doc, 'get_all_plugins_of_type'))
    assert isinstance(doc.get_all_plugins_of_type('module'), dict)
    assert isinstance(doc.get_all_plugins_of_type('cow'), dict)
    assert doc.get_all_plugins_of_type('module')

# Generated at 2022-06-22 18:50:25.399120
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    runner = CliRunner()
    result = runner.invoke(DocCLI.doccli, ['--help'], catch_exceptions=False)
    assert not result.exception
    assert result.exit_code == 0

# Generated at 2022-06-22 18:50:27.205870
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    DocCLI.find_plugins()


# Generated at 2022-06-22 18:50:28.371986
# Unit test for method run of class DocCLI
def test_DocCLI_run():
  pass


# Generated at 2022-06-22 18:50:34.317161
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        # Create object of class PluginNotFound with random text
        # and call constructor
        pnf = PluginNotFound(to_text(u"random-text"))
        # If exception is not raised, test is passed
        if pnf:
            return
    except:
        # If exception is raised, test is failed
        raise AssertionError(u"PluginNotFound class is failed to call")



# Generated at 2022-06-22 18:50:43.253349
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    from ansible.utils.display import Display
    from ansible.plugins.loader import module_loader
    from ansible.utils.plugin_docs import get_docstring

    display = Display()
    display.columns = 120

    python_version_map = {
        '2.6': 'python2.6',
        '2.7': 'python2.7',
        '3.4': 'python3',
        '3.5': 'python3.5',
        '3.6': 'python3.6',
        '3.7': 'python3.7',
        '3.8': 'python3.8',
    }

    for plugin in module_loader.all(class_only=True):
        if hasattr(plugin, '_original_module'):
            plugin_class = plugin._original_module
       

# Generated at 2022-06-22 18:50:50.679766
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    temp_ini_file = os.path.join(tempfile.gettempdir(), 'ansible.cfg')

    with open(temp_ini_file, 'w') as test_config_file:
        test_config_file.write("[defaults]\n")
        test_config_file.write("roles_path = /some/roles/location")

    # Test to see if we get an error if no arguments are passed
    with pytest.raises(SystemExit):
        DocCLI(args=[],  prog='ansible-doc', ini_file=temp_ini_file).init_parser()

    # Test that we get the ansible version correctly
    version = DocCLI(args=['-v'], prog='ansible-doc', ini_file=temp_ini_file).init_parser()

# Generated at 2022-06-22 18:50:53.379704
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound("This is a test")
    except PluginNotFound as e:
        assert str(e) == "This is a test"


# Generated at 2022-06-22 18:50:54.890618
# Unit test for constructor of class DocCLI
def test_DocCLI():
    module = DocCLI('')
    assert isinstance(module, DocCLI)

# Generated at 2022-06-22 18:51:08.807724
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    myobj = DocCLI()
    role = "test"

# Generated at 2022-06-22 18:51:22.123142
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    """
    Test that module path, module utils path and plugin paths are printed.
    """

# Generated at 2022-06-22 18:51:25.060076
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    exc = PluginNotFound('test message')
    assert isinstance(exc.message, str)
    assert exc.message == 'test message'
    assert exc.__str__() == 'test message'



# Generated at 2022-06-22 18:51:38.476157
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    d = DocCLI()
    doc = {
        'entry_points': {
            'main': {
                'short_description': 'Short desc',
                'description': 'Long desc',
                'options': {
                    'option': {
                        'required': True,
                        'type': 'string',
                        'default': '"foo"'
                    }
                },
                'attributes': {
                    'key': 'value'
                }
            }
        }
    }
    text = d.get_role_man_text("role", doc)
    assert text[:4] == [
        '> ROLE    ()\n',
        'ENTRY POINT: main - Short desc\n',
        '        Long desc\n',
        'OPTIONS (= is mandatory):\n'
    ]


# Unit test

# Generated at 2022-06-22 18:51:40.736699
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    # Check if it is okay to get this parser
    parser = DocCLI.init_parser()
    assert parser is not None


# Generated at 2022-06-22 18:51:45.685604
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    test_pass = True
    test_pass = test_pass and (DocCLI.print_paths(False, False) == None)
    return test_pass

# Generated at 2022-06-22 18:51:58.320413
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    doc = DocCLI()
    # First, no arguments
    args = []
    argspec = None
    try:
        doc.post_process_args(argspec, args)
    except Exception as ex:
        # Ensure that we catch the exception
        assert ex
    # End of First
    # Second,
    args = []
    argspec = None
    try:
        doc.post_process_args(argspec, args)
    except Exception as ex:
        # Ensure that we catch the exception
        assert ex
    # End of Second
    # Third,
    args = []
    argspec = None
    try:
        doc.post_process_args(argspec, args)
    except Exception as ex:
        # Ensure that we catch the exception
        assert ex
    # End of Third

# Generated at 2022-06-22 18:52:02.956512
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    """
    Test the DocCLI.display_plugin_list() method.
    """
    from unittest.mock import Mock, call, patch

    display = Mock()
    DocCLI._display_plugin_list(display, 'Foo', ['a', 'b'])
    assert display.display.call_args_list == [call("Available Foo plugins:", color=None),
                                              call("a", color=None),
                                              call("b", color=None)]

    display.display.reset_mock()
    DocCLI._display_plugin_list(display, 'Foo', [])
    assert display.display.call_args_list == [call("Available Foo plugins:", color=None),
                                              call("(none)", color=None)]



# Generated at 2022-06-22 18:52:09.193496
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    a = RoleMixin()
    # Good case:
    b = a._load_argspec('myrole', role_path="/home/me/myansible/roles/myrole")
    assert b.get('argument_specs')
    assert not b.get('x')
    # Bad case: no role path
    c = a._load_argspec('myrole', collection_path="/home/me/myansible/")
    assert not c.get('argument_specs')
    assert not c.get('x')
    assert c=={}
    # Bad case: no file
    d = a._load_argspec('mynotrolexx', role_path="/home/me/myansible/roles/myrole")
    assert not d.get('argument_specs')
    assert not d.get('x')

# Generated at 2022-06-22 18:52:16.046790
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    '''Dump some basic options for testing.
    '''
    limit = 60
    text = []
    opt_indent = "        "

    test_data = {
        'first': 'This is the first option.',
        'second': 'This option has choices.',
        'choices': ["foo", "bar"],
        'default': "baz",
        'third': 'This option is deprecated and has a suboption.',
        'deprecated': True,
        'suboption': [{'name': 'asdf', 'description': "This is a suboption.", 'default': 'fdsa'}],
    }

    DocCLI.add_fields(text, test_data, limit, opt_indent)


# Generated at 2022-06-22 18:52:47.365722
# Unit test for method format_snippet of class DocCLI

# Generated at 2022-06-22 18:52:53.553409
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    "Testing method get_man_text of class DocCLI"
    doc= {'description': 'foo', 'epilog': 'bar'}
    text = "\n".join(DocCLI.get_man_text(doc))
    assert text.startswith("> FOO    ")
    assert "foo" in text
    assert "bar" in text

DocCLI.IGNORE = ('description', 'epilog', 'filename', 'notes', 'version_added', 'version_added_collection', 'req_one_of', 'req_in', 'metadata_version')

# END UNIT TESTS

if __name__ == '__main__':
    test_DocCLI_get_man_text()
    print("DONE")

# Generated at 2022-06-22 18:53:04.453734
# Unit test for method find_plugins of class DocCLI

# Generated at 2022-06-22 18:53:05.237580
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    assert 1 == 1

# Generated at 2022-06-22 18:53:14.332947
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    # create a sample plugin
    plugin_doc = {
        'name': 'test_module',
        'filename': 'test_module',
        'description': ['This is the test_module'],
        'options': {
            'test_option': {
                'description': ['description of test_option'],
                'choices': ['first', 'second'],
            },
            'test_option2': {
                'description': ['description of test_option2'],
                'choices': ['first', 'second'],
            },
        },
    }

    # create a sample role

# Generated at 2022-06-22 18:53:20.546964
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():

    DocCLI.args = {
        'paths': [
            "/usr/lib/python2.7/dist-packages/ansible",
            "/usr/lib/python2.7/dist-packages/ansible-2.9.13.dist-info",
        ],
        'verbosity': 0,
        'get_all': True,
        'type': 'module',
    }

    DocCLI.print_paths()


# Generated at 2022-06-22 18:53:27.149770
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():

    def remove_env(module_name):
        return DocCLI._add_env.cache_clear()

    # Test nested environment vars

    os.environ["ANSIBLE_MODULE_TEST_FIRST_ARG"] = "first_arg"
    os.environ["ANSIBLE_MODULE_TEST_SECOND_ARG"] = "second_arg=2"
    os.environ["ANSIBLE_MODULE_TEST_FOURTH_ARG"] = "fourth_arg=\"fourth arg\""


# Generated at 2022-06-22 18:53:36.777934
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    from ansible.module_utils.six import PY3

    my_obj = DocCLI([])

    assert my_obj._namespace_from_plugin_filepath('/some/path/on/disk/to/a/directory/with/modules/name.of.the.module.py',
                                                  'modules') == ('name.of.the.module', 'name', 'of', 'the', 'module')
    assert my_obj._namespace_from_plugin_filepath('/some/path/on/disk/to/a/directory/with/modules/name.of.the.module.py',
                                                  'lookup_plugins') == ('name.of.the.module', 'name', 'of', 'the', 'module')

# Generated at 2022-06-22 18:53:45.457098
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    # set up arguments
    role = 'role'
    role_json = {'entry_points': {'main': 'main'}}


    # create test object
    doccli = DocCLI()

    # call method
    text = doccli.get_role_man_text(role, role_json)

    # assert results
    assert text is not None and len(text) == 2, 'should be text'

    # return results for further testing
    return text

# Generated at 2022-06-22 18:53:55.858359
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    context._init_global_context()
    display.verbosity = 2

    # Not supported currently
    with pytest.raises(AnsibleOptionsError) as e:
        DocCLI().find_plugins(context.CLIARGS['type'], '', min_version='a')

    with pytest.raises(AnsibleOptionsError) as e:
        DocCLI().find_plugins(context.CLIARGS['type'], '', max_version='a')

    with pytest.raises(AnsibleOptionsError) as e:
        DocCLI().find_plugins(context.CLIARGS['type'], '', include_dotfiles=True)


# Generated at 2022-06-22 18:54:08.077312
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-22 18:54:09.223209
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    doc_cli = DocCLI()
    doc_cli.display_plugin_list(['action'])


# Generated at 2022-06-22 18:54:13.066709
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    doc=DocCLI(module=None, collection_list=None, options=None)
    result=doc.get_all_plugins_of_type()
    assert len(result) > 0


# Generated at 2022-06-22 18:54:18.619472
# Unit test for method get_role_man_text of class DocCLI
def test_DocCLI_get_role_man_text():
    DocCLI_obj = DocCLI()
    assert DocCLI_obj is not None
    type_spec_str = 'plugin'
    DocCLI_obj.get_role_man_text(DocCLI_obj,type_spec_str)
    
    
    
    

# Generated at 2022-06-22 18:54:23.283181
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    # Initalize the DocCLI object
    task_obj = DocCLI()
    # Create the argument parser object
    parser = task_obj.init_parser()
    # Check the argument parser type
    assert isinstance(parser, ArgumentParser)

# Generated at 2022-06-22 18:54:26.488574
# Unit test for function jdump
def test_jdump():
    mock_text = {'a': 'b'}
    assert json.dumps(mock_text, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)



# Generated at 2022-06-22 18:54:36.331740
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Path may vary based on which source repository is under test.
    # This will make it easier to isolate.
    test_path = None
    for path in ['/usr/share/ansible_collections/',
                 '/usr/share/ansible/']:
        if os.path.exists(path):
            test_path = path
    assert(test_path is not None)
    with patch.dict(os.environ, {'ANSIBLE_CONFIG': os.path.join(test_path, 'ansible.cfg')}):
        # We will want to test for a specific plugin type
        plugin_type = 'module'
        # Temp directory for testing
        temp = tempfile.gettempdir()
        # We will test whether a specific plugin is found.
        # Sources:
        # https://docs.ansible.com

# Generated at 2022-06-22 18:54:46.332479
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    # pylint: disable=unused-variable
    from ansible.cli.doc import DocCLI
    # pylint: enable=unused-variable

    # Define a dummy class that includes the RoleMixin
    class DummyClass(RoleMixin):
        def __init__(self):
            pass

    # Create an instance of the dummy class
    dummy = DummyClass()

    # Define test roles paths to search
    roles_paths = (os.path.join(os.path.dirname(__file__), 'fixtures', 'test_basic_argspec', 'roles'),)

    # Try out the role list method and confirm results
    results = dummy._create_role_list(roles_paths)
    assert 'roleA' in results
    assert 'roleB' in results
    assert results.get

# Generated at 2022-06-22 18:54:47.650353
# Unit test for function jdump
def test_jdump():
    jdump('foo')


# Generated at 2022-06-22 18:54:54.586401
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    path = "/home/user/ansible/lib/ansible/modules/net_tools/net_ping"
    expected = "ansible.modules.net_tools"
    errormsg = "Got " + str(DocCLI.namespace_from_plugin_filepath(path))
    errormsg += " instead of " + str(expected)
    assert DocCLI.namespace_from_plugin_filepath(path) == expected, errormsg


# Generated at 2022-06-22 18:54:56.407345
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc = DocCLI()
    doc.run()

# Generated at 2022-06-22 18:55:03.338940
# Unit test for function jdump
def test_jdump():
    try:
        # Dump a dictionary to JSON
        d = {'name': 'jdoe', 'role': 'admin'}
        jdump(d)
        # Dump a list to JSON
        l = ['jdoe', 'jsmith']
        jdump(l)
    except Exception as e:
        display.error(e, wrap_text=False)



# Generated at 2022-06-22 18:55:07.705798
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    conn = DocCLI()
    plugin = 'uri'
    res = conn.get_plugin_metadata(plugin)
    assert type(res) == dict, '%s is not a dict' % res
    assert res.get('name'), '%s does not have name' % res
    assert res.get('author'), '%s does not have author' % res
    assert res.get('description'), '%s does not have description' % res
    assert res.get('options'), '%s does not have options' % res


# Generated at 2022-06-22 18:55:10.790655
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('/foo/bar/my_module.py') == 'my_module'

# Generated at 2022-06-22 18:55:22.695845
# Unit test for constructor of class RoleMixin
def test_RoleMixin():

    class TestRoleList(RoleMixin):
        def __init__(self, role_paths, collection_filter=None):
            super(TestRoleList, self).__init__()
            self.role_list = self._create_role_list(role_paths, collection_filter)

    class TestRoleDoc(RoleMixin):
        def __init__(self, role_names, role_paths, entry_point=None):
            super(TestRoleDoc, self).__init__()
            self.role_doc = self._create_role_doc(role_names, role_paths, entry_point)

    # test with no roles
    test_roles_path = '/tmp/testroles'

# Generated at 2022-06-22 18:55:31.932139
# Unit test for method init_parser of class DocCLI

# Generated at 2022-06-22 18:55:45.444745
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Test parameters
    plugin_type = 'module'
    collection_name = None

    # Initialization of doc.
    test_json = {}
    test_json['connection'] = {
                'short_description': 'Connect to the remote system',
                'description': [
                    'Connect to the remote system',
                    'The connection type is set as specified by the parameters of the module.',
                    'True always indicates success.'
                ],
                'options': {
                    'none': {}
                },
                'version_added': '2.4',
                'filename': 'plugins/connection/__init__.py',
                'type': 'connection',
                'name': '__init__'
            }

# Generated at 2022-06-22 18:55:59.081942
# Unit test for method get_plugin_metadata of class DocCLI

# Generated at 2022-06-22 18:56:00.482979
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    assert True

# Generated at 2022-06-22 18:56:03.873829
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc = DocCLI()
    assert isinstance(doc, DocCLI)
    assert isinstance(doc.option_parser, parser.CommandParser)


# Generated at 2022-06-22 18:56:15.712917
# Unit test for method display_plugin_list of class DocCLI

# Generated at 2022-06-22 18:56:17.866767
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    doccli = DocCLI([])
    assert doccli.print_paths() is None

# Generated at 2022-06-22 18:56:25.352643
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    from ansible.cli import CLI
    from ansible.plugins.loader import module_loader
    from ansible.module_utils._text import to_bytes

    # Required positional arguments are not provided
    with pytest.raises(TypeError) as e_info:
        DocCLI.get_plugin_metadata()

    # Constructor CLI takes no arguments
    with pytest.raises(TypeError) as e_info:
        cli = CLI('--list-hosts')

    # Constructor DocCLI takes no arguments
    with pytest.raises(TypeError) as e_info:
        cli = DocCLI('--list-hosts')

    # Passing a function as module
    with pytest.raises(AnsibleError) as e_info:
        cli = CLI()
        cli.get_plugin_

# Generated at 2022-06-22 18:56:37.102762
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    # Test case when DocCLI has module_utils
    class TestClass:
        doc = DocCLI()
        def return_true(self):
            return True
        def test_case_1(self):
            docobj = self.doc.get_all_plugins_of_type(["/usr/lib/python2.7/site-packages/ansible/modules/cloud/"], 'module')
            assert isinstance(docobj, dict)

        def test_case_2(self):
            docobj = self.doc.get_all_plugins_of_type(["/usr/lib/python2.7/site-packages/ansible/modules/notification/"], 'module')
            assert isinstance(docobj, dict)
    t = TestClass()
    t.test_case_1()
    t.test_case_

# Generated at 2022-06-22 18:56:46.815506
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    '''
    Test module.
    '''

    # Test data

# Generated at 2022-06-22 18:56:57.872978
# Unit test for constructor of class DocCLI
def test_DocCLI():
    go_to_json_dir()
    # Check whether doc folder exists and
    #   create if it doesn't
    ensure_dir(doc_output)

    # Create a DocCLI Object
    class_doc = DocCLI()

    # Fetch collection details
    collection_details = get_collection_details()

    # Generate plugin documentation
    generate_plugin_docs(collection_details, 'modules', class_doc)
    generate_plugin_docs(collection_details, 'module_utils', class_doc)
    generate_plugin_docs(collection_details, 'lookup', class_doc)
    generate_plugin_docs(collection_details, 'filter', class_doc)
    generate_plugin_docs(collection_details, 'callback', class_doc)
    generate_plugin_docs(collection_details, 'inventory', class_doc)

# Generated at 2022-06-22 18:56:59.386501
# Unit test for function jdump
def test_jdump():
    jdump({'test': 'value'})



# Generated at 2022-06-22 18:57:06.278719
# Unit test for constructor of class RoleMixin

# Generated at 2022-06-22 18:57:15.992722
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Test for default values of arguments
    args = {}
    args['type'] = 'module'
    args['all'] = True
    args['tree'] = True
    args['output'] = 'json'
    args['failure_ok'] = False
    args['one_liner'] = False
    args['metadata'] = False
    args['list_dir'] = None
    args['list_files'] = None
    args['list_names'] = None
    args['list_paths'] = False
    args['module_dir'] = None
    args['roles_path'] = None
    args['list_dirs'] = None
    args['role'] = None
    args['collection'] = None
    result = DocCLI(args).run()
    assert result == []


# Generated at 2022-06-22 18:57:29.225021
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    #
    # Test the the find_plugin method of the DocCLI class
    #

    def _no_collection_path(module_name):
        return os.path.join(os.path.dirname(plugins.__file__), module_name)

    class NoCollectionCLI(DocCLI):
        """A NoCollectionCLI class"""
        pass

    class CLIParams(object):
        """A CLIParams class"""
        def __init__(self):
            self.module_path = []
            self.module_name = []
            self.type = ''
            self.collection = ''

    class TestArgs(object):
        """A TestArgs class"""
        def __init__(self):
            self.type = 'module'
            self.module_name = 'nosetests'


# Generated at 2022-06-22 18:57:34.209883
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    # commands = ['ansible-doc', '-h']
    commands = ['ansible-doc']
    doc = DocCLI(commands)
    doc.init_parser()
    parser = doc.parser
    assert parser.print_help() is None


# Generated at 2022-06-22 18:57:36.061573
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    parser = DocCLI(['--foo'])
    assert parser.parser is not None

# Generated at 2022-06-22 18:57:43.737453
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    """ Test case for method 'get_plugin_metadata' of class DocCLI """

    # Desired output for plugin_metadata[0]:
    # {'name': 'ping' , 'type': 'ping', 'doc': '<doc_string1>' , 'filename': '<file_name1>'}
    plugin_metadata = [
        {'type': 'ping', 'doc': '<doc_string1>', 'filename': '<file_name1>'},
        {'type': 'ansible.builtin.assert', 'doc': '<doc_string2>', 'filename': '<file_name2>'}
    ]
    output = DocCLI.get_plugin_metadata(plugin_metadata)


# Generated at 2022-06-22 18:57:51.607950
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    test_plugin_list = {}
    test_plugin_type = 'lookup'

    # TODO: Remove this test temporarily until runtime.yml is implemented
    # TODO: Add test for runtime.yml once it is implemented
    add_collection_plugins(test_plugin_list, test_plugin_type)
    assert len(test_plugin_list) > 0
    assert test_plugin_list['test_mod'] is not None



# Generated at 2022-06-22 18:57:56.816471
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    class RoleMixinTester(RoleMixin):
        pass
    rmt = RoleMixinTester()
    assert rmt.ROLE_ARGSPEC_FILES == [
        'argument_specs.yml', 'argument_specs.yaml',
        "main.yml", "main.yaml"
    ]



# Generated at 2022-06-22 18:58:06.941211
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # Test with no arg
    try:
        DocCLI.get_plugin_metadata()
    except TypeError as e:
        assert str(e) == "get_plugin_metadata() missing 1 required positional argument: 'plugin_name'"
    else:
        raise AssertionError('ExpectedRaise not raised')

    # Test with invalid plugin_name
    try:
        DocCLI.get_plugin_metadata('invalid_name')
    except AnsibleOptionsError as e:
        assert str(e) == 'No documentation found for invalid_name'
    else:
        raise AssertionError('ExpectedRaise not raised')

    # Test with valid plugin_name
    plugin_type = 'action'

# Generated at 2022-06-22 18:58:10.150237
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    plugin_type = 'inventory'
    coll_filter = '*'
    add_collection_plugins(plugin_list, plugin_type, coll_filter=coll_filter)



# Generated at 2022-06-22 18:58:21.124274
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-22 18:58:26.262536
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    r = RoleMixin()
    r._find_all_normal_roles([])
    r._find_all_collection_roles()
    r._build_summary('new_role', '', {'': {'options': {}}})
    r._build_doc('new_role', '', '', {'': {'options': {}}})


# Generated at 2022-06-22 18:58:30.123973
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Create an instance of DocCLI
    obj = doc_cli.DocCLI(None, display, False, 'playbook', 'all', [], [], [], [])

    # unittest.TestCase.assertEqual(a, b)
    # a -> expected, b -> actual


# Generated at 2022-06-22 18:58:37.818953
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    test = DocCLI()
    # This is a method of a class. Se we need to create an instance of the class before calling.
    plugin_type = 'action_plugins'
    # Let us test this method with and without filters.
    results_without_filters = test.get_all_plugins_of_type(plugin_type)
    # The number of results are supposed to be more than 0.
    assert len(results_without_filters) != 0
    # Let us test with filters.
    filters = ['debug']
    results_with_filters = test.get_all_plugins_of_type(plugin_type, filters)
    # The number of results are supposed to be more than 0.
    assert len(results_with_filters) != 0
    # We can use assertGreaterEqual to pass the test. But we

# Generated at 2022-06-22 18:58:48.151967
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    from ansible import context

    DocCLI.IGNORE = DocCLI.IGNORE + (context.CLIARGS['type'],)
    doc = {'a': 0, 'b': 1}
    # testing default values
    opt_indent = "        "
    text = []
    for k in sorted(doc):
        if k.startswith('_'):
            continue
        if isinstance(doc[k], string_types):
            text.append('%s%s: %s' % (opt_indent, k,
                                      textwrap.fill(DocCLI.tty_ify(doc[k]),
                                                    limit - (len(k) + 2),
                                                    subsequent_indent=opt_indent)))