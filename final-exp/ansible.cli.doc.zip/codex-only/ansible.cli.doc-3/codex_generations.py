

# Generated at 2022-06-22 18:48:51.357146
# Unit test for function jdump
def test_jdump():
    text = {'stdout': 'FAKE_STDOUT', 'stdout_lines': ['FAKE_STDOUT_LINE']}
    try:
        jdump(text)
    except AnsibleError as e:
        assert str(e) == "We could not convert all the documentation into JSON as there was a conversion issue: 'str' object is not callable"


# Generated at 2022-06-22 18:49:03.060778
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    from ansible.module_utils._text import to_text


# Generated at 2022-06-22 18:49:08.401654
# Unit test for constructor of class DocCLI
def test_DocCLI():
    '''Unit test for constructor of class DocCLI'''

    for arg in ('connection', 'module_path', 'forks', 'remote_user',
                'private_key_file', 'ssh_common_args', 'ssh_extra_args',
                'sftp_extra_args', 'scp_extra_args', 'become', 'become_method',
                'become_user', 'verbosity', 'check'):
        # FIXME: The following raises a RuntimeError, so we're ignoring it until it's fixed
        if arg == 'module_path':
            continue
        assert arg in DocCLI(['-m', 'ping', '-t', 'test'])


# Generated at 2022-06-22 18:49:21.869314
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    data = dict(
        foo=dict(
            description='This is some foo',
            type='bool',
            default=True,
            options=dict(
                foo=dict(
                    default='other foo',
                )
            ),
            suboptions=dict(
                bar=dict(
                    default='other bar',
                )
            )
        )
    )
    fields = []
    DocCLI.add_fields(fields, data['foo'])
    assert fields == ['        foo (bool): This is some foo', '                    Options (= is mandatory):', '                    * foo: other foo', '                    Suboptions (= is mandatory):', '                    * bar: other bar', '                    Default: [Default: True]']

    fields = []
    DocCLI.add_fields(fields, data['foo'], return_values=True)


# Generated at 2022-06-22 18:49:24.554288
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    """Test method run of class DocCLI"""
    doc = DocCLI()
    doc.run(["core","sync"])

# Generated at 2022-06-22 18:49:32.791038
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
  fake_coll_name = "fake_collection_name"
  fake_coll_dir = "/tmp/{}".format(fake_coll_name)
  fake_coll_dir_plugins = os.path.join(fake_coll_dir, "plugins")
  fake_coll_dir_plugins_module = os.path.join(fake_coll_dir_plugins, "modules")
  fake_coll_dir_plugins_module_fake_module = os.path.join(fake_coll_dir_plugins_module, "fake_module")
  fake_coll_dir_plugins_module_fake_module_0 = os.path.join(fake_coll_dir_plugins_module_fake_module, "__init__.py")
  os.makedirs(fake_coll_dir_plugins_module_fake_module)

# Generated at 2022-06-22 18:49:37.788843
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    plugin_list = {}
    add_collection_plugins(plugin_list, 'filter')
    plugin_list = plugin_list['filter']
    assert plugin_list['ansible.builtin.compare'] == 'Compare two different versions of a collection module'



# Generated at 2022-06-22 18:49:50.220641
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    import ansible.plugins.loader as loader
    import tests.utils as utils

    test_dir = utils.fixtures_path
    args = DocCLI.parse()
    args['type'] = 'module'
    args['verbosity'] = 1

    module_path = os.path.join(test_dir, 'ansible')
    collection_path = os.path.join(test_dir, 'ansible_collections', 'collection1')

    loader.add_directory(collection_path)
    loader.add_directory(module_path)
    for name, doc in loader.find_plugin_docs(args['type'], collection_name=''):
        if name == 'systemd':
            doc = DocCLI.format_plugin_doc(args, doc, plugin_type=name)
            print(doc)
           

# Generated at 2022-06-22 18:49:54.245082
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Find plugins in current dir
    plugins = DocCLI().find_plugins(["."])
    assert isinstance(plugins, list)
    assert len(plugins) > 0
    # Find plugins with incorrect path
    plugins = DocCLI().find_plugins(["toto"])
    assert isinstance(plugins, list)
    assert len(plugins) == 0


# Generated at 2022-06-22 18:49:55.735870
# Unit test for function jdump
def test_jdump():
    assert jdump({"test": "docs"}) == '{"test": "docs"}'



# Generated at 2022-06-22 18:50:08.621202
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    text = []
    test_options = {
        'one': 'this is a test',
        'two': ['and', 'it', 'works'],
        'three': {'this':'is', 'a':'test'},
        'four': {'this':'is', 'a':'test', 'options':{'a':'test'}},
        'version_added': 'this is a test'
    }
    DocCLI.add_fields(text, test_options, 80)
    test_doc = "".join(text)
    assert '* one:' in test_doc
    assert '* two:' in test_doc
    assert 'and, it, works' in test_doc
    assert '- a: test' in test_doc
    assert '- this: is' in test_doc

# Generated at 2022-06-22 18:50:11.734805
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound('foo')
    except Exception as e:
        assert e.args == ('foo',)


# Generated at 2022-06-22 18:50:22.851139
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    import ansible.cli.doc
    import ansible.utils.module_docs
    import ansible.utils.module_docs as mod_doc
    import ansible.module_utils.common as common

    try:
        import __main__
        __main__.options = []
    except Exception:
        pass
    ansible.cli.doc.options = [{'module': True, 'collection': False, 'filter': []}, {'module': False, 'collection': True, 'filter': []}]

    # first test case:
    # option is a module, we are testing for module name,
    # for example, the module is 'ping', we will call method _find_module_name_match
    # to filter the correct module, which is the element in module_defs whose filename is ping.py.
    # if not, we will return

# Generated at 2022-06-22 18:50:32.134577
# Unit test for function jdump
def test_jdump():
    # If a module is to be tested, it can return a dict: {'result': module_returned_dict, 'failed': False}
    # for a successful run or {'result': '', 'failed': True} for a failed run
    test_text = '{"result": "success"}'
    test_text2 = '{"result": {}, "failed": False}'
    test_text3 = '{"result": "", "failed": True}'
    # First test with a json decoded string
    result = json.loads(jdump(json.loads(test_text)))
    assert 'result' in result and result['result'] == 'success'
    # Then with a dict
    result = json.loads(jdump(json.loads(test_text2)))

# Generated at 2022-06-22 18:50:34.761400
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    assert DocCLI.get_man_text() == ""



# Generated at 2022-06-22 18:50:39.568222
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
	assert DocCLI.find_plugins() == [('../test/test_utils/test_plugins/module_utils/test_foo.py', 'module_utils', 'test_foo', 'TestFoo'), ('../test/test_utils/test_plugins/modules/test_foo.py', 'modules', 'test_foo', 'TestFoo')]


# Generated at 2022-06-22 18:50:48.741789
# Unit test for function jdump
def test_jdump():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    text = {'foo': 'bar', 'baz': 1, 'boo': {'goo': 'doo'}, 'goo': [1, 2, 3], 'boo': AnsibleUnsafeText(u'\xe9')}
    expected = u'''{
    "boo": "\\u00e9", 
    "baz": 1, 
    "foo": "bar", 
    "goo": [
        1, 
        2, 
        3
    ]
}'''
    assert jdump(text) == expected



# Generated at 2022-06-22 18:50:51.024316
# Unit test for constructor of class DocCLI
def test_DocCLI():
    doc_cli_obj = DocCLI()
    assert isinstance(doc_cli_obj, DocCLI)


# Generated at 2022-06-22 18:51:03.950490
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    from nose.tools import assert_equals
    from ansible.cli import CLI
    from ansible.module_utils._text import to_text

    runner = CLI(args=[])
    d = DocCLI(runner)

    # Test alias, action plugin and default module plugin
    d.display_plugin_list(['setup', 'ping'], 'modules')
    assert_equals(d._last_output, to_text(u"\n    setup      (networking.linux.net_info, network.linux.net_info)\n    ping       (ping)\n\n"))

    # Test ansible module doc links
    d.display_plugin_list(['ADHOCTEST1', 'ADHOCTEST2', 'module_utils.module_utils'], 'modules')

# Generated at 2022-06-22 18:51:06.457927
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    current_instance = DocCLI()
    current_instance.find_plugin_metadata('blah')


# Generated at 2022-06-22 18:51:19.296492
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    import ansible.utils.role_utils as role_utils
    rolemix = role_utils.RoleMixin()
    rpaths = ['/tmp/test/roles', '/tmp/test/roles1']
    rdict = rolemix._create_role_list(rpaths)
    assert 'a.b.c.roleA' in rdict
    assert 'a.b.c.roleA' in rdict['a.b.c.roleA']['entry_points']
    assert 'roleA' in rdict
    assert 'main' in rdict['roleA']['entry_points']

# Generated at 2022-06-22 18:51:22.396804
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # TODO: this method is a candidate to be refactored later
    # TODO: implement unit test
    pass


# Generated at 2022-06-22 18:51:27.628079
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # Create a test instance of class DocCLI
    cli = DocCLI()
    # Test for an empty snippet
    result = cli.format_snippet('', '', '', '', '', '')
    assert result == []
    # Test for a non empty snippet
    result = cli.format_snippet('test_module', 'test_name', 'test_before', 'test_snippet', 'test_after', 'test_text')
    assert result == ''

# Generated at 2022-06-22 18:51:33.914106
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    D = DocCLI()
    D.tty_width = 120

    assert D.format_snippet('') == "  "
    assert D.format_snippet('- name: foo') == "  - name: foo"
    assert D.format_snippet('- name: foo\n  with: parameters') == "  - name: foo\n    with: parameters"
    assert D.format_snippet('- name: foo\n      with: parameters') == "  - name: foo\n        with: parameters"

    assert D.format_snippet("\n".join(['  verbose:', '    description: Be verbose during operation.'])) == '  verbose:\n    description: Be verbose during operation.'

# Generated at 2022-06-22 18:51:43.818985
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI('').namespace_from_plugin_filepath('/some/path/to/modules/vars/something.py') == 'vars'
    assert DocCLI('').namespace_from_plugin_filepath('/some/path/to/modules/action/something.py') == 'action'
    assert DocCLI('').namespace_from_plugin_filepath('/some/path/to/modules/connection/something.py') == 'connection'
    assert DocCLI('').namespace_from_plugin_filepath('/some/path/to/modules/become/something.py') == 'become'
    assert DocCLI('').namespace_from_plugin_filepath('/some/path/to/modules/terminal/something.py') == 'terminal'
    assert Doc

# Generated at 2022-06-22 18:51:46.841285
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    dc = DocCLI()
    dc.print_paths(None)


# Generated at 2022-06-22 18:51:53.301919
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
  argspec = inspect.getargspec(DocCLI.get_all_plugins_of_type)
  assert len(argspec.args) == 3
  assert argspec.varargs is None
  assert argspec.keywords is None
  assert argspec.defaults == ('',)


# Generated at 2022-06-22 18:51:59.857463
# Unit test for method add_fields of class DocCLI

# Generated at 2022-06-22 18:52:08.951247
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    # Only one line
    assert DocCLI.format_snippet('This is a test') == 'This is a test'

    # Only one line with a comment
    assert DocCLI.format_snippet('This is a test # comment') == 'This is a test'

    # Two lines with no comment
    assert DocCLI.format_snippet('This is a test\nLine 2') == 'This is a test\nLine 2'

    # Three lines with trailing comments
    assert DocCLI.format_snippet('This is a test # comment\nLine 2 # comment\nLine 3') == 'This is a test\nLine 2\nLine 3'

    # Multiple lines with leading comments

# Generated at 2022-06-22 18:52:21.980589
# Unit test for function add_collection_plugins

# Generated at 2022-06-22 18:52:33.829388
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    # set some test options
    options = {
        'valid': {'required': True, 'choices': ['True', 'False'], 'aliases': ['validate'], 'type': 'bool'},
        'key': {'required': True, 'choices': ['True', 'False'], 'aliases': ['testkey'], 'type': 'str'},
        'test': {'required': False, 'choices': ['True', 'False'], 'aliases': ['keytest'], 'type': 'bool'},
        'version': {'required': True, 'choices': ['True', 'False'], 'aliases': ['ver'], 'default': 'True', 'type': 'str'},
    }
    # get formatted text

# Generated at 2022-06-22 18:52:44.552236
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    argspec = {
        'main': {'short_description': 'Short description for main'},
        'alternate': {'short_description': 'Short description for alternate entry point'}
    }
    r = RoleMixin()
    r._load_argspec = lambda a, b, c: argspec
    expected_list = {
        'roleA': {
            'collection': '',
            'entry_points': {
                'main': 'Short description for main',
                'alternate': 'Short description for alternate entry point'
            }
        }
    }
    r._find_all_normal_roles = lambda a, b: {('roleA', '')}
    r._find_all_collection_roles = lambda a, b: set()

    # Test creating a listing of all roles with arg specs.
    actual_

# Generated at 2022-06-22 18:52:46.903709
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    # class check
    assert issubclass(PluginNotFound, Exception)
    # constructor check
    PluginNotFound()



# Generated at 2022-06-22 18:52:56.244350
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    from units.mock.loader import DictDataLoader, TestDataLoader

    DocCLI.IGNORE = DocCLI.IGNORE + (context.CLIARGS['type'],)
    opt_indent = "        "
    text = []
    pad = display.columns * 0.20
    limit = max(display.columns - int(pad), 70)
    DocCLI.get_all_plugins_of_type()
    assert DocCLI.get_all_plugins_of_type().__class__.__name__ == 'list'


# Generated at 2022-06-22 18:52:57.317170
# Unit test for function jdump
def test_jdump():
    jdump("Test")


# Generated at 2022-06-22 18:53:05.105680
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    # Test with a valid param
    arg_spec = dict(
        type='module',
        all=False,
        output='yaml',
        tree=False,
        config_file='~/.ansible/ansible.cfg',
        ignore_errors=True
    )
    config_file = '~/.ansible/ansible.cfg'
    config_data = (CmdLineParser(arg_spec, usage='%prog [options]').parse_args([]))[0]

    config = Config(config_data, config_file)

    plugin = DocCLI(config)
    result = plugin.find_plugins()
    assert isinstance(result, list)

# Generated at 2022-06-22 18:53:11.196325
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    cli_args = cli_args_fail
    old_stdout = sys.stdout
    sys.stdout = StringIO()  # Capture output for unit test
    new_DocCLI = DocCLI(cli_args)
    new_DocCLI.post_process_args()
    assert cli_args.get('module_dir') == new_DocCLI.module_dir



# Generated at 2022-06-22 18:53:13.785050
# Unit test for function jdump
def test_jdump():
    test_str = 'This is a test of the jdump function'
    test_jdump = jdump(test_str)
    Results = json.dumps(test_str, sort_keys=True, indent=4)
    assert test_jdump == Results


# Generated at 2022-06-22 18:53:16.586369
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    cli = DocCLI(args=dict())
    cli.display_plugin_list()
    assert True


# Generated at 2022-06-22 18:53:18.930241
# Unit test for function jdump
def test_jdump():
    class Jsonable:
        def __repr__(self):
            return 'Jsonable()'
    jdump(Jsonable())

# Generated at 2022-06-22 18:53:23.431511
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    try:
        raise PluginNotFound("Test message")
    except PluginNotFound as e:
        if e.message != "Test message":
            raise AssertionError("PluginNotFound message is not correct")



# Generated at 2022-06-22 18:53:33.267452
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    assert DocCLI({}).post_process_args(['--type', 'module', '-M', '.']) == (['-M', '.'], ['module'])
    assert DocCLI({}).post_process_args(['--type', 'module', '-M', '.', '-l']) == (['-M', '.', '-l'], ['module'])
    with pytest.raises(SystemExit):
        DocCLI({}).post_process_args(['--type', 'module', '-M', '.', 'foo'])
    with pytest.raises(SystemExit):
        DocCLI({}).post_process_args(['--type', 'module', 'foo'])

# Generated at 2022-06-22 18:53:35.432709
# Unit test for method display_plugin_list of class DocCLI

# Generated at 2022-06-22 18:53:47.598452
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    # Arrange
    doc = [
        {
            "filename": "test.py",
            "description": "description",
            "docuri": "docuri",
            "options": {
                "foo": {
                    "description": "description",
                    "required": True
                }
            }
        }
    ]
    # Act
    result = DocCLI.display_plugin_list(doc)
    # Assert
    assert result == [
        "> TEST.PY    (test.py)",
        "description",
        "",
        "OPTIONS (= is mandatory):",
        "    foo (description):",
        "        [Default: (null)]",
        "        [Required]",
        "",
        "        "
        ]


# Generated at 2022-06-22 18:53:56.870873
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    # namespace_from_plugin_filepath is indirectly tested by the testsuite

    # tests for namespace_from_plugin_filepath for jinja
    assert DocCLI.namespace_from_plugin_filepath(
        'lib/ansible/plugins/action/test.py') == 'ansible.builtin.action'
    assert DocCLI.namespace_from_plugin_filepath(
        'lib/ansible/plugins/vars/test.py') == 'ansible.builtin.vars'
    assert DocCLI.namespace_from_plugin_filepath('lib/ansible/test.py') == 'ansible.module_utils.test'
    assert DocCLI.namespace_from_plugin_filepath('test.py') == 'ansible.module_utils.test'

    # tests for namespace_

# Generated at 2022-06-22 18:54:07.011250
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doccli = DocCLI()
    (plugin_name, plugin_type, plugin_dir, plugin_path) = ("setup", "action", "action", "setup.py")
    results = doccli.get_plugin_metadata(plugin_name, plugin_type, plugin_dir, plugin_path)
    assert results["name"] == "setup"
    assert results["action"] == "setup"
    assert results["filename"] == "setup.py"
    assert results["docuri"] == "ansible-doc-setup"
    assert results["status"] == ["stableinterface"]
    assert results["version_added"] == ""


# Generated at 2022-06-22 18:54:10.298617
# Unit test for function jdump
def test_jdump():
    from ansible.module_utils.common._collections_compat import Sequence
    input_data = [{"aiueo": "kakikukeko", "sasisuseso": "tatituteto"}]
    expected_output = json.dumps(input_data, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)
    assert jdump(input_data) == expected_output
# End unit test for function jdump



# Generated at 2022-06-22 18:54:11.724421
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    d = DocCLI()
    d.run()

# Generated at 2022-06-22 18:54:16.643068
# Unit test for method get_all_plugins_of_type of class DocCLI

# Generated at 2022-06-22 18:54:21.261963
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    assert DocCLI.namespace_from_plugin_filepath('/Users/me/repo/ansible/lib/ansible/plugins/action/bigip_facts.py') == 'ansible.plugins.action'

# Generated at 2022-06-22 18:54:31.207407
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    from ansible import constants as C
    from ansible.cli.doc import DocCLI

    assert DocCLI.namespace_from_plugin_filepath('action_plugins/test.py', C.DEFAULT_ACTION_PLUGIN_PATH) == 'action'
    assert DocCLI.namespace_from_plugin_filepath('action_plugins/test.py', '/path/to/another/action_plugins/') == 'action'
    assert DocCLI.namespace_from_plugin_filepath('test.py', C.DEFAULT_ACTION_PLUGIN_PATH) == 'action'

    assert DocCLI.namespace_from_plugin_filepath('cache_plugins/test.py', C.DEFAULT_CACHE_PLUGIN_PATH) == 'cache'
    assert DocCLI.namespace_from_plugin

# Generated at 2022-06-22 18:54:43.769607
# Unit test for function add_collection_plugins
def test_add_collection_plugins():

    plugin_list = {}

    if importlib.util.find_spec('yaml'):
        import yaml
        yaml_loader = yaml.FullLoader

    loaders = {}
    # mock collection plugins dir
    mock_path = '/path/to/collections/plugins/module_utils/foo'
    mock_collname = 'foo.bar'
    # create module_util
    module_util_data = {'DOCUMENTATION': 'bar.bar.bar',
                        'EXAMPLES': 'foo.foo.foo',
                        'RETURN': 'baz.baz.baz'}

# Generated at 2022-06-22 18:54:55.970910
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    args = DocCLI.parse()

    patterndict = {
        'testkey': 'testvalue',
        'testkey2': 'testvalue2',
        'testkey3': 'testvalue3'
    }

    # test when args are all false
    args.roles = False
    args.plugins = False
    args.modules = False
    args.fragments = False
    args.action_plugins = False

    # create new DocCLI object
    cl = DocCLI(args)

    cl.run()
    assert cl.has_pager

    for role in C.DEFAULT_ROLES_PATH:
        if os.path.exists(role):
            shutil.rmtree(role)

    assert patterndict == cl._search_patterns()

    assert True == cl._find

# Generated at 2022-06-22 18:54:59.791453
# Unit test for method print_paths of class DocCLI
def test_DocCLI_print_paths():
    obj = DocCLI()
    data = ["A", "B"]
    result = obj.print_paths(data)
    assert result == None



# Generated at 2022-06-22 18:55:08.695390
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    # mock the input data
    data = '''
#!/usr/bin/python


DOCUMENTATION = '''
    # There is nothing in this string!
    '''
    # There is nothing in this string!

print "Something here"
'''
    # mock the metadata
    metadata = {
        'name': 'ping',
        'filename': 'ping.py'
    }

    # call the method
    result = DocCLI.get_plugin_metadata(data, metadata)

    # check assertions
    # result should be None
    assert result == None


# Generated at 2022-06-22 18:55:17.512674
# Unit test for method add_fields of class DocCLI
def test_DocCLI_add_fields():
    import sys
    import StringIO
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO.StringIO()
    example_doc = [{'choices': [True, False], 'default': True, 'description': ['If C(no), SSL certificates will not be validated.', 'This should only set to C(no) used on personally controlled sites using self-signed certificates.'], 'type': 'bool'}]
    DocCLI.add_fields([], example_doc, 100, "    ")
    sys.stdout = old_stdout
    assert "SHORT DESCRIPTION: If C(no), SSL certificates will not be validated. This should only set to C(no) used on personally controlled sites using self-signed certificates.\n" == mystdout.getvalue().split('\n')[0]
   

# Generated at 2022-06-22 18:55:21.276636
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    # Setup test
    test_instance = DocCLI

    # Action
    test_instance.init_parser()

    # Assertion
    assert isinstance(test_instance.parser, ArgumentParser)


# Generated at 2022-06-22 18:55:31.033445
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    role_test_data = '''---
argument_specs:
  main:
    description: The main entry point.
    required: True
    options:
      foo:
        description: |
          A longer description
          to test with.
        required: True
      bar:
        description: The description for bar
        required: False
        default: 5
        type: list
        elements: string
  alternate:
    description: |
      A description of an alternate
      entry point.
    required: False
    options:
      foo:
        description: The description for entry point foo
        required: True
        default: 5
        type: int
      baz:
        required: True
'''

    # Write test data to a temporary file
    test_file = None

# Generated at 2022-06-22 18:55:33.621432
# Unit test for function jdump
def test_jdump():
    text = {'a': 'value'}

    try:
        jdump(text)
        assert 1
    except:
        assert 0



# Generated at 2022-06-22 18:55:46.486116
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    """
    :avocado: tags=doc_gen
    """
    # It is a string
    output = DocCLI.format_snippet('- hosts: somehost')
    assert isinstance(output, string_types)
    assert output == '- hosts: somehost'
    # It is a list
    output = DocCLI.format_snippet(['- hosts: somehost'])
    assert isinstance(output, string_types)
    assert output == "- hosts: somehost\n"
    # It is a dict

# Generated at 2022-06-22 18:55:53.680258
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    cli = DocCLI()

    assert cli.run(['-h']) == 0
    assert cli.run(['-h', 'plugins']) == 0
    assert cli.run(['-h', 'collections']) == 0
    assert cli.run(['-h', 'module']) == 0
    assert cli.run(['-h', 'modules']) == 0
    assert cli.run(['-h', 'module_recognition']) == 0
    assert cli.run(['-h', 'module_utils']) == 0
    assert cli.run(['-h', 'role']) == 0
    assert cli.run(['-h', 'roles']) == 0
    assert cli.run(['-h', 'test']) == 0
    assert cli.run

# Generated at 2022-06-22 18:56:05.561073
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    """Unit test for find_plugins method of class DocCLI"""
    res_pass = DocCLI.find_plugins()

# Generated at 2022-06-22 18:56:07.855124
# Unit test for constructor of class PluginNotFound
def test_PluginNotFound():
    objPluginNotFound = PluginNotFound('This is a test exception.')
    assert str(objPluginNotFound) == 'This is a test exception.'



# Generated at 2022-06-22 18:56:09.980348
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    commands = []
    DocCLI().display_plugin_list(commands)


# Generated at 2022-06-22 18:56:13.344764
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    parser = DocCLI.DocCLIParser(command_name='test_name')
    cli = DocCLI(parser=parser)
    cli_args = {}
    cli.run(cli_args)

# Generated at 2022-06-22 18:56:15.354335
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    cli = DocCLI()
    cli.display_plugin_list("my_plugin_list")



# Generated at 2022-06-22 18:56:24.116931
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    import ansible.utils.module_docs

    def new_option_parser():
        return DocCLI.init_parser()

    mock_ansible_config = {
        "module_docs_dir": "test module_docs_dir",
        "ansible_module_dirs": ["test ansible_module_dirs"],
        "action_plugins_dirs": ["test action_plugins_dirs"],
        "callback_plugins_dirs": ["test callback_plugins_dirs"],
        "connection_plugins_dirs": ["test connection_plugins_dirs"],
        "filter_plugins_dirs": ["test filter_plugins_dirs"],
        "lookup_plugins_dirs": ["test lookup_plugins_dirs"],
        "vars_plugins_dirs": ["test vars_plugins_dirs"]
    }



# Generated at 2022-06-22 18:56:31.779669
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    class_name = 'DocCLI'
    # Initializing object
    doc_cli = DocCLI()
    # Initializing parameters
    args = None
    # Testing method - run of class DocCLI
    doc_cli.run(args)

if __name__ == '__main__':
    # Unit test
    configure_logging()
    test_DocCLI_run()

# Generated at 2022-06-22 18:56:32.982441
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    assert(True)


# Generated at 2022-06-22 18:56:36.975475
# Unit test for method get_all_plugins_of_type of class DocCLI
def test_DocCLI_get_all_plugins_of_type():
    plugins = DocCLI().get_all_plugins_of_type('lookup')
    assert 'dnstxt' in plugins
    assert 'uri' not in plugins


# Generated at 2022-06-22 18:56:38.967619
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    mydoccli = DocCLI()
    assert mydoccli.find_plugins() is None
    assert mydoccli.find_plugins() is None


# Generated at 2022-06-22 18:56:50.862996
# Unit test for method get_man_text of class DocCLI

# Generated at 2022-06-22 18:56:54.486266
# Unit test for method format_plugin_doc of class DocCLI
def test_DocCLI_format_plugin_doc():
    # Create a DocCLI object
    doccli = DocCLI()

    doccli.format_plugin_doc(**{'module_name': 'setup'})

    return True


# Generated at 2022-06-22 18:57:06.238215
# Unit test for method find_plugins of class DocCLI
def test_DocCLI_find_plugins():
    '''
    :returns: A tuple of True/False if the test passed, and a string describing the test
    :rtype: (bool, str)
    '''
    from ansible.plugins.loader import find_plugin_docstrings
    from ansible.utils.display import Display
    from ansible.utils import plugin_docs
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    ret = True
    msg = ''

# Generated at 2022-06-22 18:57:16.285753
# Unit test for method namespace_from_plugin_filepath of class DocCLI
def test_DocCLI_namespace_from_plugin_filepath():
    """Validate the namespace_from_plugin_filepath() method of
    class DocCLI.
    """

    print('Testing namespace_from_plugin_filepath() of class DocCLI')

    # Test for a core plugin

# Generated at 2022-06-22 18:57:18.883285
# Unit test for method get_plugin_metadata of class DocCLI
def test_DocCLI_get_plugin_metadata():
    doc_cli = DocCLI()
    doc_cli.get_plugin_metadata()


# Generated at 2022-06-22 18:57:31.526474
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    fake_coll_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'unit', 'utils', 'docsite')
    coll_filter = os.path.join(fake_coll_path, 'ansible_collections', 't_ansible_collections_ns')
    test_plist = {}
    test_plist = add_collection_plugins(test_plist, 'connection', coll_filter=coll_filter)
    assert len(test_plist) == 1
    assert 'plugin_name' in test_plist
    assert test_plist['plugin_name']['path'] == os.path.join(fake_coll_path, 'connection_plugins', 'plugin_name.py')
    assert 'collection' in test_pl

# Generated at 2022-06-22 18:57:41.267696
# Unit test for method format_snippet of class DocCLI
def test_DocCLI_format_snippet():
    import os
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "lib", "ansible"))
    import ansible.constants
    ansible.constants.__file__ = os.path.join(os.path.dirname(__file__), "..", "..", "lib", "ansible", "constants.py")
    import ansible.utils
    ansible.utils.__file__ = os.path.join(os.path.dirname(__file__), "..", "..", "lib", "ansible", "utils", "__init__.py")
    os.environ["ANSIBLE_COLLECTIONS_PATHS"] = os.path.join(os.path.dirname(__file__), "data")


# Generated at 2022-06-22 18:57:53.070512
# Unit test for method get_man_text of class DocCLI
def test_DocCLI_get_man_text():
    module = AnsibleModule(
        argument_spec = dict(
            foo = dict(required=True, choices=['bar', 'baz']),
            dict_param = dict(type='dict', default=dict(a='b', c='d')),
            list_param = dict(type='list', default=['a', 'b', 'c']),
        ),
        supports_check_mode=True,
    )

    result = dict(
        ansible_facts=dict(
            ansible_foo='bar',
            apt_packages='zsh',
            python_versions='2.5',
            path='/bin'
        ),
        changed=False
    )

    DocCLI.tty_ify = staticmethod(lambda x: x)
    DocCLI.get_man_text(module._plugin_args)
   

# Generated at 2022-06-22 18:57:55.892829
# Unit test for method init_parser of class DocCLI
def test_DocCLI_init_parser():
    p = DocCLI()
    assert isinstance(p.parser, CLI.base._AnsibleCLI)

# Generated at 2022-06-22 18:58:01.000130
# Unit test for constructor of class RoleMixin
def test_RoleMixin():
    p = RoleMixin()
    assert p.ROLE_ARGSPEC_FILES == ['argument_specs.yml', 'argument_specs.yaml', 'argument_spec.yml', 'argument_spec.yaml', 'main.yml', 'main.yaml'], p.ROLE_ARGSPEC_FILES


# Generated at 2022-06-22 18:58:13.703799
# Unit test for method display_plugin_list of class DocCLI
def test_DocCLI_display_plugin_list():
    class test_DocCLI(DocCLI):
        def __init__(self):
            pass

        def get_plugin_man_text(self, plugin_type, plugin, collection_name):
            plugin_text = dict()
            plugin_text['param_plugin_type'] = plugin_type
            plugin_text['param_plugin'] = plugin
            plugin_text['collection'] = collection_name
            plugin_text['return'] = "test_get_plugin_man_text"
            return plugin_text
    test_doc_cli = test_DocCLI()
    plugin_list = dict()
    plugin_list['module'] = ["module1", "module2"]
    plugin_list['doc_fragment'] = ["doc_fragment1", "doc_fragment2"]

# Generated at 2022-06-22 18:58:15.841374
# Unit test for function add_collection_plugins
def test_add_collection_plugins():
    assert add_collection_plugins(plugin_list=None, plugin_type=None, coll_filter=None) is None



# Generated at 2022-06-22 18:58:17.924642
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # FIXME: Add unit tests for DocCLI.run
    pass


# Generated at 2022-06-22 18:58:29.324980
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    doc = DocCLI()
    doc.run()

    # test actions
    doc = DocCLI(args=['all', 'action'])
    doc.run()
    assert doc.options.module_name == 'action'

    # test roles
    doc = DocCLI(args=['all', 'role'])
    doc.run()
    assert doc.options.module_name == 'role'

    # test module
    doc = DocCLI(args=['all', 'module'])
    doc.run()
    assert doc.options.module_name == 'module'

    # test deprecated
    doc = DocCLI(args=['all', 'deprecated'])
    doc.run()
    assert doc.options.module_name == 'deprecated'

    # test removed

# Generated at 2022-06-22 18:58:36.542693
# Unit test for method run of class DocCLI
def test_DocCLI_run():
    # Imports in this context are mocked to not require any installed dependencies
    from ansible.module_utils.six import PY3

    class MockCLI(object):
        def __init__(self):
            self.args = []
            self.all = False
            self.version_added = False
            self.deprecated = False
            self.extra_action_plugins = []
            self.extra_lookup_plugins = []
            self.collection = None
            self.list_dirs = False
            self.list_deprecated = False
            self.list_news = False
            self.metadata = False
            self.module_dirs = []
            self.tree = None
            self.verbosity = 0

    class MockParser(object):
        def __init__(self):
            self.parser = object()

# Generated at 2022-06-22 18:58:47.301229
# Unit test for method post_process_args of class DocCLI
def test_DocCLI_post_process_args():
    """
    DocCLI post_process_args method
    """
    # test function declarations
    def mock_post_process_args(self, args):
        return (args[0], args[1])

    def mock_post_process_args2(self, args):
        return (args[0], args[1])

    def mock_post_process_args3(self, args):
        args[1] = 'args2'
        return args

    # create instances
    doc_obj = DocCLI()

    # test for one post-process function
    doc_obj.post_process = mock_post_process_args
    doc_obj.post_process_args(['args1', 'args2'])

    # test for two post-process functions