

# Generated at 2022-06-22 19:20:14.104944
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = PluginSetting("setting1", "setting1", "setting1", "setting1")
    config_data.update_setting(setting)
    setting = PluginSetting("setting2", "setting2", "setting2", "setting2")
    config_data.update_setting(setting)
    settings = config_data.get_settings()
    assert len(settings) == 2
    assert settings[0].name == "setting1"
    assert settings[1].name == "setting2"


# Generated at 2022-06-22 19:20:21.992662
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    d1 = {'type': 'connection', 'name': 'local', 'value': 'x', 'version_added': 1}
    d2 = {'type': 'action', 'name': 'ping', 'value': 'x', 'version_added': 1}
    d3 = {'type': 'action', 'name': 'ping', 'value': 'x', 'version_added': 1}

    setting1 = Setting(d1)
    setting2 = Setting(d2)
    setting3 = Setting(d3)

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)

    assert config_data.get_setting('connection', plugin=Plugin('connection', 'local')) is setting1

# Generated at 2022-06-22 19:20:25.332551
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()
    config.update_setting({'name': 'lookup_order', 'value': 'presence_order'})
    assert config.get_setting('lookup_order')['value'] == 'presence_order'


# Generated at 2022-06-22 19:20:36.772746
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    plugin = None

    config_data = ConfigData()
    config_data.update_setting(Setting('fact_caching', 'jsonfile', 'jsonfile'))
    assert config_data.get_setting('fact_caching') is not None
    assert config_data.get_setting('fact_caching', plugin) is not None
    assert config_data.get_setting('fact_caching', plugin).name == 'fact_caching'
    assert config_data.get_setting('fact_caching', plugin).value is None
    assert config_data.get_setting('fact_caching', plugin).section is None
    assert config_data.get_setting('fact_caching', plugin).subsection is None
    assert config_data.get_setting('resource_fact_caching', plugin) is None

    config_data = ConfigData

# Generated at 2022-06-22 19:20:39.686173
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting('a') is None
    assert config_data.get_setting('b') is None
    assert config_data.get_setting('a', 'b') is None


# Generated at 2022-06-22 19:20:51.264606
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    #Test data
    setting_1 = ConfigSetting(name='foo')
    setting_2 = ConfigSetting(name='bar')

    plugin_1 = Plugin(name='plugin_1', type='foo')
    plugin_2 = Plugin(name='plugin_2', type='bar')

    #Test code
    config = ConfigData()
    assert len(config.get_settings()) == 0
    assert len(config.get_settings(plugin=None)) == 0
    assert len(config.get_settings(plugin=plugin_1)) == 0
    assert len(config.get_settings(plugin=plugin_2)) == 0

    config.update_setting(setting_1)
    assert len(config.get_settings()) == 1
    assert len(config.get_settings(plugin=None)) == 1

# Generated at 2022-06-22 19:21:02.296913
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Instantiate a ServersData object
    config_data = ConfigData()

    # Update global settings
    global_setting1 = {"name": "global_setting1", "type": "str", "value": "global_value1"}
    global_setting2 = {"name": "global_setting2", "type": "str", "value": "global_value2"}
    config_data.update_setting(global_setting1)
    config_data.update_setting(global_setting2)

    # Update plugin settings
    plugin1_setting1 = {"name": "plugin1_setting1", "type": "str", "value": "plugin1_value1"}
    plugin1_setting2 = {"name": "plugin1_setting2", "type": "str", "value": "plugin1_value2"}

# Generated at 2022-06-22 19:21:09.541441
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_setting = ConfigSetting(setting_name='debug')
    config_setting_2 = ConfigSetting(setting_name='verbosity')

# Test for global settings
    config_data.update_setting(config_setting)
    config_data.update_setting(config_setting_2)
    assert config_data.get_setting('debug') == config_setting
    assert config_data.get_setting('verbosity') == config_setting_2
    settings = config_data.get_settings()
    assert config_setting in settings
    assert config_setting_2 in settings

# Test for plugin settings
    plugin_type = 'module'
    plugin_name = 'bios_config'

# Generated at 2022-06-22 19:21:16.485320
# Unit test for constructor of class ConfigData
def test_ConfigData():

    from ansiblelint import AnsibleLintRule

    config_data = ConfigData()

    my_plugin = AnsibleLintRule()
    my_plugin.name = "test_plugin"
    my_plugin.type = "test_type"

    # Check for global settings
    global_setting = config_data.get_setting("test_setting")
    assert global_setting is None

    global_setting = config_data.get_setting("test_setting", my_plugin)
    assert global_setting is None

    global_setting = config_data.get_settings()
    assert len(global_setting) == 0

    global_setting = config_data.get_settings(my_plugin)
    assert len(global_setting) == 0

    # Add global setting
    config_data.update_setting("test_setting")

# Generated at 2022-06-22 19:21:19.622619
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:21:21.059730
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    assert cd.get_settings() == []

# Generated at 2022-06-22 19:21:29.576635
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """
    Test to verify the correct use of method update_setting
    """
    plugin1 = PluginDefinition()
    plugin1.type = 'CLI'
    plugin1.name = 'test1'
    config_data = ConfigData()
    setting = SettingEntry()
    setting.name = 'test'
    setting.values = [1,2]
    setting.origin = 'test'
    setting.plugin = plugin1
    config_data.update_setting(setting, plugin1)
    assert config_data._plugins["CLI"].has_key('test1')

    plugin2 = PluginDefinition()
    plugin2.type = 'CLI'
    plugin2.name = 'test2'
    setting = SettingEntry()
    setting.name = 'test'
    setting.values = [3,4]

# Generated at 2022-06-22 19:21:31.244277
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()




# Generated at 2022-06-22 19:21:34.148316
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting(ConfigConstant.SETTING_NAME_DEBUG, value=True))

# Generated at 2022-06-22 19:21:39.616729
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()
    plugin_type = 'typeA'
    plugin_name = 'pluginA'
    configData.update_setting({}, plugin=Plugin(plugin_type, plugin_name))
    assert configData.get_settings(plugin=Plugin(plugin_type, plugin_name)) == []

# Generated at 2022-06-22 19:21:46.916691
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert config_data.get_settings() == [], "Test ConfigData.get_settings : A, config_data.get_settings() == [], but it is incorrect."

    assert config_data.get_settings(None) == [], "Test ConfigData.get_settings : B, config_data.get_settings(None) == [], but it is incorrect."

    setting_A = {'name': 'plugin_dir', 'type': 'path', 'default': '/usr/share/ansible/plugins'}
    plugin_A = {'type': 'cache', 'name': 'redis'}
    config_data.update_setting(setting_A)
    config_data.update_setting(setting_A, plugin_A)


# Generated at 2022-06-22 19:21:49.098514
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert type(config_data._global_settings) is dict
    assert type(config_data._plugins) is dict

# Generated at 2022-06-22 19:21:51.406646
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert config.get_setting('ansible_python_interpreter') is None


# Generated at 2022-06-22 19:22:00.090610
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    cd = ConfigData()

    import string
    import random
    import itertools
    from nornir.core.configuration import Setting

    n_settings = random.randint(10,30)
    n_plugins_by_type = {}

    for t in range(random.randint(1,4)):
        type_name = ''.join(random.choice(string.ascii_lowercase) for _ in range(random.randint(5,15)))
        cd._plugins[type_name] = {}
        n_plugins_by_type[type_name] = random.randint(1,5)

# Generated at 2022-06-22 19:22:03.827782
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert not config_data.get_settings()

    assert not config_data.get_settings(plugin=Plugin(type='lookup', name='ansible.cfg'))

# Generated at 2022-06-22 19:22:06.966386
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert configdata is not None
    assert configdata._global_settings is not None
    assert configdata._plugins is not None


# Generated at 2022-06-22 19:22:16.385710
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    data.update_setting(Setting('var', 'ansible_module_bg'))
    data.update_setting(Setting('var2', 'ansible_module_bg2'))
    print(data.get_settings())
    data.update_setting(Setting('var3', 'ansible_module_bg3', 'module', 'bg'))
    print(data.get_settings())
    data.update_setting(Setting('var4', 'ansible_module_bg4', 'module', 'bg'))
    print(data.get_settings())
    print(data.get_settings(Plugin('module_bg', 'module', 'bg')))


# Generated at 2022-06-22 19:22:17.652598
# Unit test for constructor of class ConfigData
def test_ConfigData():
    conf = ConfigData()
    assert conf._global_settings == {}
    assert conf._plugins == {}


# Generated at 2022-06-22 19:22:25.971945
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()

    plugin_1 = Plugin('abc')
    setting_1 = Setting(name='foo', value='bar')
    setting_2 = Setting(name='foo', value='bar')
    setting_3 = Setting(name='foo', value='bar')

    config.update_setting(setting_1)
    config.update_setting(setting_2)
    config.update_setting(setting_3, plugin_1)

    settings = config.get_settings()
    assert(len(settings) == 1)
    assert(len(settings[0]) == 1)

    settings = config.get_settings(plugin_1)
    assert(len(settings) == 1)
    assert(len(settings[0]) == 1)



# Generated at 2022-06-22 19:22:31.214786
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    wrapper = ConfigData()
    plugin = Plugin('plugin_type','plugin_name','plugin_version','plugin_status','plugin_description')
    wrapper.update_setting(Setting('setting_name','setting_value'), plugin)
    settings = wrapper.get_settings(plugin)
    assert settings[0].name == 'setting_name'
    assert settings[0].value == 'setting_value'


# Generated at 2022-06-22 19:22:35.503554
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    setting = Setting("debug", True, "bool")
    config.update_setting(setting)
    plugin = Plugin("TEST_PLUGIN", "TEST_TYPE")
    config.update_setting(setting, plugin)
    plugin2 = Plugin("TEST_PLUGIN2", "TEST_TYPE")
    config.update_setting(setting, plugin2)
   # print(config.get_settings())


# Generated at 2022-06-22 19:22:46.228207
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = PluginDefinition(name='plugin1', type='plugin_type1')
    setting1 = SettingDefinition(name='setting1', value='foo')
    setting2 = SettingDefinition(name='setting2', value='bar')
    setting3 = SettingDefinition(name='setting3', value='baz')

    config_data.update_setting(setting1)
    assert config_data.get_setting('setting1') == setting1
    assert config_data.get_settings() == [setting1]

    config_data.update_setting(setting2, plugin)
    assert config_data.get_setting('setting2', plugin) == setting2
    assert config_data.get_settings(plugin) == [setting2]

    config_data.update_setting(setting3, plugin)

# Generated at 2022-06-22 19:22:53.244087
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(Setting(name='gsetting1', value=5))
    assert config._global_settings['gsetting1'].value == 5
    config.update_setting(Setting(name='gsetting2', value=6))
    assert config._global_settings['gsetting2'].value == 6
    config.update_setting(Setting(name='gsetting1', value=7))
    assert config._global_settings['gsetting1'].value == 7


# Generated at 2022-06-22 19:22:56.025504
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert(config_data.get_setting(None) is None)
    assert(config_data.get_setting('invalid_setting') is None)


# Generated at 2022-06-22 19:22:57.696023
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert len(config._global_settings) == 0



# Generated at 2022-06-22 19:23:07.308120
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin_1 = Plugin(PluginType.MODULE, 'plugin_1')
    plugin_2 = Plugin(PluginType.ACTION, 'plugin_2')
    plugin_3 = Plugin(PluginType.CACHE, 'plugin_3')
    plugin_4 = Plugin(PluginType.CACHE, 'plugin_4')

    config_data.update_setting(Setting('global_setting_1'))
    config_data.update_setting(Setting('setting_1'), plugin=plugin_1)
    config_data.update_setting(Setting('setting_2'), plugin=plugin_1)
    config_data.update_setting(Setting('setting_3'), plugin=plugin_2)
    config_data.update_setting(Setting('setting_4'), plugin=plugin_2)
    config_data.update

# Generated at 2022-06-22 19:23:10.100421
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('name') is None



# Generated at 2022-06-22 19:23:18.762433
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

#     print("Initialise ConfigData object")
    config_data = ConfigData()

#     print("Create GlobalSetting object")
    global_setting = GlobalSetting("TestGlobalSetting1", "TestValue1")

    config_data.update_setting(global_setting)

#     print("Get global setting")
    assert config_data.get_setting("TestGlobalSetting1") == global_setting

#     print("Create PluginConfig object")
    plugin_config = PluginConfig("TestPluginConfig1", "TestValue1")

#     print("Create Plugin object")
    plugin = Plugin("TestPlugin1", "TestType1", plugin_config)

    config_data.update_setting(plugin_config, plugin)

#     print("Get plugin config")
    assert config_data.get_setting("TestPluginConfig1", plugin) == plugin

# Generated at 2022-06-22 19:23:24.688854
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(setting='setting')
    assert 'setting' in config_data._global_settings
    assert config_data._global_settings['setting'] == 'setting'
    config_data.update_setting(setting='setting1', plugin='plugin')
    assert 'setting1' in config_data._plugins['plugin']['plugin']
    assert config_data._plugins['plugin']['plugin']['setting1'] == 'setting1'

# Generated at 2022-06-22 19:23:25.496463
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    assert True

# Generated at 2022-06-22 19:23:28.531136
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config
    assert config._global_settings == {}
    assert config._plugins == {}



# Generated at 2022-06-22 19:23:36.863146
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    test_config = ConfigData()

    # Test global setting
    test_config.update_setting(Setting('test_string', 'test_value'))
    assert(test_config._global_settings['test_string'].name == 'test_string')
    assert(test_config._global_settings['test_string'].value == 'test_value')

    # Test plugin setting
    plugin = Plugin('test_type', 'test_name')
    test_config.update_setting(Setting('test_string', 'test_value'), plugin)
    assert(test_config._plugins['test_type']['test_name']['test_string'].name == 'test_string')
    assert(test_config._plugins['test_type']['test_name']['test_string'].value == 'test_value')

#

# Generated at 2022-06-22 19:23:44.732315
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansiblelint import AnsibleLintRule

    class MyRule(AnsibleLintRule):
        id = 'TEST1'
        shortdesc = 'TEST SHORT DESC'
        description = 'TEST DESC'
        tags = ['TEST']

    # Test case 1: Add a global setting
    data = ConfigData()

    assert len(data.get_settings()) == 0
    assert data.get_setting('key0') is None

    data.update_setting(Setting(
        'key0', 'value0', 'This is a test', ['key0', 'key0a'], True))
    assert len(data.get_settings()) == 1
    assert data.get_setting('key0').value == 'value0'
    assert data.get_setting('key0').description == 'This is a test'

# Generated at 2022-06-22 19:23:48.937658
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    c.update_setting(Setting('user'))
    c.update_setting(Setting('timeout'))
    assert len(c.get_settings()) == 2


# Generated at 2022-06-22 19:23:51.865745
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert(type(config_data) == ConfigData)


# Generated at 2022-06-22 19:24:04.442767
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    from ansible.plugins.loader import PluginLoader
    from ansible.module_utils import basic
    from collections import namedtuple

    plugin_type = 'module'
    plugin_name = 'shell'
    plugin = basic.AnsibleModule(argument_spec=dict())
    my_setting = namedtuple('setting', ['name', 'value'])('test', 'value')
    new_setting = namedtuple('setting', ['name', 'value'])('test2', 'value2')
    config_data.update_setting(my_setting)
    config_data.update_setting(new_setting, plugin=PluginLoader.get(plugin_type, plugin_name))

    global_settings = config_data.get_settings()

# Generated at 2022-06-22 19:24:13.882883
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    import os
    from ansible.plugins.loader import config_loader
    from ansible.config.manager import ConfigManager, ConfigManagerParser

    config_loader.add(os.path.join(os.path.dirname(__file__), 'data/config_manager/'))

    parser = ConfigManagerParser('')
    parser.add_file(os.path.join(os.path.dirname(__file__), 'data/config_manager/ansible.cfg'))
    parser.read()

    manager = ConfigManager(parser, sources=parser.parsed_files)

    config_data = ConfigData()
    config_data.update_setting(manager.get_setting('ansible_managed'))

    assert config_data.get_setting('ansible_managed').value == 'Ansible managed'

    # Test no

# Generated at 2022-06-22 19:24:17.962277
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from collections import namedtuple
    
    test_data = ConfigData()

    Plugin = namedtuple('Plugin', 'type name')

    test_data.update_setting('val1_global', None)
    test_data.update_setting('val2_global', None)

    test_data.update_setting('val1_plugin1', Plugin('plugin_type1', 'plugin_name1'))
    test_data.update_setting('val2_plugin1', Plugin('plugin_type1', 'plugin_name1'))
    test_data.update_setting('val3_plugin1', Plugin('plugin_type1', 'plugin_name1'))

    test_data.update_setting('val1_plugin2', Plugin('plugin_type1', 'plugin_name2'))

# Generated at 2022-06-22 19:24:23.409000
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    c = ConfigData()
    c._plugins = {
            'action': {
                'plugin1': {'setting1': 'value1', 'setting2': 'value2'},
                'plugin2': {'setting3': 'value3', 'setting4': 'value4'}
            }
    }

    assert c.get_settings(plugin_suffix='action.plugin2') == ['value3', 'value4']

# Generated at 2022-06-22 19:24:32.197413
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin_type = 'type'
    plugin_name = 'name'
    setting1 = ConfigSetting()
    setting1.name = 'name1'
    setting1.value = 'value1'
    setting2 = ConfigSetting()
    setting2.name = 'name2'
    setting2.value = 'value2'
    setting3 = ConfigSetting()
    setting3.name = 'name3'
    setting3.value = 'value3'

    config_data = ConfigData()
    config_data.update_setting(setting1)
    config_data.update_setting(setting2, Plugin(plugin_type, plugin_name))
    config_data.update_setting(setting3, Plugin(plugin_type, plugin_name + '_'))

    assert config_data.get_settings()[0].name == setting1.name

# Generated at 2022-06-22 19:24:38.535523
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    setting = Setting('test_setting', False)
    config.update_setting(setting)

    retval = config.get_setting('not_existing_setting')
    assert retval is None

    retval = config.get_setting('test_setting')
    assert retval == setting


# Generated at 2022-06-22 19:24:46.240808
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    setting = Setting({
        'name': 'test',
        'description': 'test',
        'env': ['ANSIBLE_TEST'],
        'ini': [
            {'key': 'test', 'section': 'defaults'},
            {'key': 'test2', 'section': 'test', 'file': 'test.ini'},
        ],
        'json': {'path': 'test'},
        'yaml': {'path': 'test'},
    })

    # test setting not set
    assert config_data.get_setting('test') is None

    # test plugin setting not set for global
    assert config_data.get_setting('test', Plugin({'type': 'connection', 'name': 'local'})) is None

    # test global get

# Generated at 2022-06-22 19:24:55.890059
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    gs = GlobalSetting(name='X', value='x')
    p1 = Plugin(type='inventory', name='file')
    p2 = Plugin(type='inventory', name='yaml')
    ps1 = PluginSetting(name='X', value='x')
    ps2 = PluginSetting(name='Y', value='y')
    ps3 = PluginSetting(name='Z', value='z')
    cd = ConfigData()
    cd.update_setting(gs)
    cd.update_setting(ps1, p1)
    cd.update_setting(ps2, p2)
    cd.update_setting(ps3, p1)

    assert cd.get_setting('X').value == 'x'
    assert cd.get_setting('X', p1).value == 'x'

# Generated at 2022-06-22 19:25:03.147830
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # define required objects
    config_data = ConfigData()
    setting = Setting('setting1', 'value1', 'global')
    plugin = Plugin('global', 'global', 'global')

    # execute method
    config_data.update_setting(setting, plugin)
    settings = config_data.get_settings()

    # verify return value
    assert len(settings) == 1
    assert settings[0].type == 'global'
    assert settings[0].name == 'setting1'
    assert settings[0].value == 'value1'

# Generated at 2022-06-22 19:25:12.940621
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.config_data import ConfigDataSetting

    config_data = ConfigData()
    settings = [ConfigDataSetting(name='alpha', value=1), ConfigDataSetting(name='beta', value=2)]
    config_data.update_setting(settings[0])

    assert settings[0] == config_data.get_setting(settings[0].name)
    assert settings[0] != config_data.get_setting(settings[1].name)
    assert config_data.get_setting(settings[1].name) is None

    # Test get_setting with settings for both a plugin and a module
    from ansible.module_utils.common.collections import ImmutableDict

    plugin = ImmutableDict(name='myplugin', type='mytype')

# Generated at 2022-06-22 19:25:21.173291
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()

    global_settings = config.get_settings()
    assert(len(global_settings) == 0)

    from yaml import dump
    from ansible.plugins.action import ActionModule
    from ansible.template import Templar
    import ansible.constants as C
    import ansible.module_utils.basic as module_utils
    from ansible.plugins.loader import module_loader

    action_plugin = module_loader.get_all_plugin_loaders()[C.ACTION_PLUGIN_PATH]['debug']
    action_plugin.__dict__['_AnsibleModule__templar'] = Templar(C.DEFAULT_HASH_BEHAVIOUR)
    action_plugin.__dict__['_AnsibleModule__loader'] = module_loader


# Generated at 2022-06-22 19:25:24.497811
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cd = ConfigData()
    assert cd != None
    assert cd._global_settings == {}
    assert cd._plugins == {}



# Generated at 2022-06-22 19:25:34.390423
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.plugins.loader import PluginLoader
    from ansible.utils import plugin_docs

    c = ConfigData()

    i = PluginLoader('action', 'await', 'async_status_poll', callback_module=None, use_implicit_aliases=True)
    assert c.get_setting('enable_async_poll', i) is None
    assert c.get_settings(i) == []

    c.update_setting(ConfigSetting('enable_async_poll', True))
    c.update_setting(ConfigSetting('enable_async_poll', False, plugin=i))
    c.update_setting(ConfigSetting('async_send_interval', 10, plugin=i))

    assert c.get_setting('enable_async_poll') == ConfigSetting('enable_async_poll', True)
   

# Generated at 2022-06-22 19:25:37.623874
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('') is None
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-22 19:25:46.013836
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    config_file = ConfigFile('/etc/ansible/ansible.cfg')
    option = Option('test1', 'test1')
    plugin_type = PluginType('callback')
    plugin_name = PluginName('test')
    plugin = Plugin(plugin_type, plugin_name)
    current_setting = CurrentSetting(option, config_file, plugin)
    cd.update_setting(current_setting)

    assert cd.get_setting('test1', None) == current_setting
    assert cd.get_setting('test1', plugin) == current_setting


# Generated at 2022-06-22 19:25:57.795273
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    
    config = ConfigData()

    # Update global setting
    config.update_setting(Setting(name='global_setting', value='global_value'))

    # Check that global setting is in global settings
    assert config.get_settings()[0] == {'name': 'global_setting', 'value': 'global_value'}

    # Check that global setting is not in plugin settings
    assert config.get_settings(Plugin('test_type', 'test_name')) == []

    # Add some plugins
    config.update_setting(Setting(name='test_setting1', value='test_value1'), Plugin('test_type', 'test_name1'))
    config.update_setting(Setting(name='test_setting2', value='test_value2'), Plugin('test_type', 'test_name2'))

    # Check that

# Generated at 2022-06-22 19:26:06.913004
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import os, tempfile
    from collections import namedtuple
    from imp import load_source
    from shutil import rmtree
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible import context
    from ansible.plugins.action.normal import ActionModule as ActionNormalModule
    from ansible.module_utils.common._text import to_text
    from ansible.config.data import ConfigData
    from ansible.inventory.builtin import InventoryModule

    config_data = ConfigData()
    config_data.update_setting(Setting('hostfile', './hosts'))
    config_data.update_setting(Setting('host_key_checking', True))
    config_data.update_setting(Setting('retries', 5))
    config_data

# Generated at 2022-06-22 19:26:17.697531
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansiblelint.rules import Plugin, Setting, BoolRule

    config_data = ConfigData()

    config_data.update_setting(Setting('ignore_rules', ['9001'], 'path', 'list'))

    data = config_data.get_settings()

    # Assert that there is exactly one setting in the data
    assert(len(data) is 1)

    # Assert that the value of the setting is as expected
    assert(data[0].value is ['9001'])

    plugin = Plugin('TestPlugin', BoolRule)
    config_data.update_setting(Setting('ignore_rules', ['9002'], 'path', 'list'), plugin)

    data = config_data.get_settings(plugin)

    # Assert that there is exactly one setting in the data

# Generated at 2022-06-22 19:26:19.066577
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:26:22.580442
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    result = config_data.get_settings()
    assert result == []


# Generated at 2022-06-22 19:26:29.477721
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from __main__ import ConfigParser
    from ansible.parsing.dataloader import DataLoader

    data = ConfigData()
    data.update_setting(ConfigParser.Setting(key='ansible_managed', value='Ansible managed: Do NOT edit this file manually!'))
    data.update_setting(ConfigParser.Setting(key='log_path', value='/tmp/ansible.log'))
    data.update_setting(ConfigParser.Setting(key='host_key_checking', value='False'))

    data.update_setting(ConfigParser.Setting(key='executable', value='/usr/bin/python2.7'), plugin=ConfigParser.Plugin('action', 'copy'))

# Generated at 2022-06-22 19:26:37.329521
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.plugins.loader import config_loader

    cd = ConfigData()
    setting = config_loader.ConfigSetting("runner_async", "1", "xd")
    cd.update_setting(setting)
    setting = config_loader.ConfigSetting("ssh_args", "-F xd", "xd")
    cd.update_setting(setting,plugin=config_loader.Plugin("connection","local"))

    assert cd.get_setting("runner_async") == config_loader.ConfigSetting("runner_async", "1", "xd")
    assert cd.get_setting("ssh_args",config_loader.Plugin("connection","local")) == config_loader.ConfigSetting("ssh_args", "-F xd", "xd")



# Generated at 2022-06-22 19:26:46.934023
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin_settings = ConfigData()
    plugin_settings.update_setting(ConfigSetting('fake_plugin_name', 'bar', 'fake_plugin_type'))
    plugin_settings.update_setting(ConfigSetting('fake_plugin_name', 'baz', 'fake_plugin_type'))

    global_settings = ConfigData()
    global_settings.update_setting(ConfigSetting('fake_plugin_name', 'foo'))
    global_settings.update_setting(ConfigSetting('not_fake_plugin_name', 'baz'))

    assert plugin_settings.get_setting('fake_plugin_name', PluginConfiguration('fake_plugin_name', 'fake_plugin_type')) is not None
    assert plugin_settings.get_setting('fake_plugin_name') is None

# Generated at 2022-06-22 19:26:49.867793
# Unit test for constructor of class ConfigData
def test_ConfigData():
    # Test constructor
    data_config1 = ConfigData()
    assert data_config1 is not None
    assert data_config1._global_settings == {}
    assert data_config1._plugins == {}


# Generated at 2022-06-22 19:26:56.851080
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    def test_get_settings():
        config_data = ConfigData()
        config_data.update_setting(Setting('source', '/opt/ansible/galaxy/plugins'))
        assert len(config_data.get_settings()) == 1
    test_get_settings()

if __name__ == '__main__':
    # Not run
    test_ConfigData_get_settings()

# Generated at 2022-06-22 19:27:07.318600
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    config.update_setting(Setting('setting_1'))
    config.update_setting(Setting('setting_2', 'global'))
    config.update_setting(Setting('setting_3', 'global'))
    assert config._global_settings['setting_1'] == Setting('setting_1')
    assert config._global_settings['setting_2'] == Setting('setting_2', 'global')
    assert config._global_settings['setting_3'] == Setting('setting_3', 'global')

    config.update_setting(Setting('setting_4', 'parser'))
    config.update_setting(Setting('setting_5', 'parser'))
    assert config._plugins['parser']['default']['setting_4'] == Setting('setting_4', 'parser')

# Generated at 2022-06-22 19:27:11.613480
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('host_key_checking', 'True')
    config_data.update_setting(setting)
    assert config_data._global_settings['host_key_checking'] == setting
    plugin = Plugin('cache', 'memory')
    setting = Setting('timeout', '10')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['cache']['memory']['timeout'] == setting


# Generated at 2022-06-22 19:27:16.469414
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin('action', 'debug')
    debug_setting = Setting('debug', Plugin('action', 'debug'), '1', 0)
    config_data.update_setting(debug_setting, plugin)
    assert config_data.get_setting('debug', plugin) == debug_setting


# Generated at 2022-06-22 19:27:19.540305
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = ConfigData()
    config_data.update_setting(setting)
    assert setting in config_data.get_settings()


# Generated at 2022-06-22 19:27:21.008531
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # TODO: add testing here

# Generated at 2022-06-22 19:27:31.942223
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()
    
    assert (configData.get_settings() == [])

    class Setting():
        def __init__(self, name):
            self.name = name


    setting1 = Setting('setting1')
    # Test the case when there is global setting
    configData.update_setting(setting1)
    assert (configData.get_settings() == [setting1])

    # Test the case when there is no global setting
    assert (configData.get_settings(Setting('role1', 'role')) == [])
    assert (configData.get_settings(Setting('module1', 'module')) == [])
    assert (configData.get_settings(Setting('lookup1', 'lookup')) == [])

# Generated at 2022-06-22 19:27:43.586921
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.deprecation import DeprecationBase

    def _get_simple_deprecation_plugin(name):

        class SimpleDeprecation(DeprecationBase):
            pass

        SimpleDeprecation.type = 'deprecation'
        SimpleDeprecation.name = name
        SimpleDeprecation.path = '/tmp'

        return SimpleDeprecation

    SimpleDeprecationPlugin = _get_simple_deprecation_plugin('simple')
    assert get_plugin_class(SimpleDeprecationPlugin) is DeprecationBase

    # Test behavior when plugin name is None
    c = ConfigData()
    s = get_plugin_class(SimpleDeprecationPlugin).Setting('simple')
    c.update_setting(s, plugin=None)
   

# Generated at 2022-06-22 19:27:45.207575
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata1 = ConfigData()
    assert configdata1


# Generated at 2022-06-22 19:27:47.448250
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    data.update_setting(ConfigSetting())
    assert isinstance(data.get_setting(name='test'),ConfigSetting)


# Generated at 2022-06-22 19:27:57.381509
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    conf = ConfigData()
    setting = Setting('var', 'value', 'docs', 'default')

    assert len(conf.get_settings()) == 0

    conf.update_setting(setting)
    assert len(conf.get_settings()) == 1
    assert next(iter(conf.get_settings())) == setting

    plugin = Plugin('test')
    setting2 = Setting('var2', 'value', 'docs', 'default')
    conf.update_setting(setting2, plugin)
    assert len(conf.get_settings(None)) == 1
    assert len(conf.get_settings(plugin)) == 1
    assert next(iter(conf.get_settings())) == setting
    assert next(iter(conf.get_settings(plugin))) == setting2


# Generated at 2022-06-22 19:28:08.560979
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class Plugin(object):

        def __init__(self, plugin_type, name):
            self.type = plugin_type
            self.name = name

# Default constructor should set the data structure to empty
    data = ConfigData()

    assert len(data._global_settings) == 0
    assert len(data._plugins) == 0

# Update the default setting
    default_setting = Plugin(None, 'display')

    assert data.get_setting('display') is None
    data.update_setting(default_setting)
    assert data.get_setting('display') is not None

# Update the setting covering all the cases
    setting = Plugin('action', 'copy')

    assert data.get_setting('copy', setting) is None
    data.update_setting(setting)

# Generated at 2022-06-22 19:28:15.929641
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import PluginLoader

    plugin_loader = PluginLoader()

    collection_plugin = plugin_loader.get('collection_plugins')
    connection_plugin = plugin_loader.get('connection_plugins')
    shell_plugin = plugin_loader.get('shell_plugins')

    test_setting_name = 'ansible_test_setting'
    test_setting_value = 'ansible_test_setting_value'
    test_setting_default = 'ansible_test_setting_default'

    config_data = ConfigData()

    plugin_setting = _create_plugin_setting_with_default(test_setting_name, test_setting_value)
    config_data.update_setting(plugin_setting)

    # mode for get settings for

# Generated at 2022-06-22 19:28:20.821345
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cs = Setting(name='name', type='str', value='value')
    cd.update_setting(cs, None)
    cd.update_setting(cs, Plugin('program', 'type', 'name'))

    assert cd._global_settings['name'].value == 'value'
    assert cd._plugins['type']['name']['name'].value == 'value'


# Generated at 2022-06-22 19:28:27.801842
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    plugin = Plugin('module', 'copy')
    setting = Setting('ANSIBLE_NET_CONFIG_WARNINGS', 'boolean', 'yes')

    config_data.update_setting(setting)

    assert config_data.get_setting(setting.name).value == setting.value
    assert config_data.get_setting(setting.name, plugin).value == setting.value


# Generated at 2022-06-22 19:28:30.056522
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    print(config)


# Generated at 2022-06-22 19:28:38.682384
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    setting_A = {}
    setting_A['name'] = 'Setting A'
    setting_A['type'] = 'dict'
    setting_A['config_file'] = 'test.cfg'
    setting_A['section'] = 'Section A'
    setting_A['key'] = 'Key A'
    setting_A['value_type'] = 'str'

    config_data.update_setting(setting_A)

    setting_A = config_data.get_setting('Setting A')

    assert setting_A['name'] == 'Setting A'
    assert setting_A['config_file'] == 'test.cfg'


# Generated at 2022-06-22 19:28:51.140879
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    # update global_setting
    assert len(config_data.get_settings()) == 0

    global_setting = ConfigSetting('global_setting1')

    config_data.update_setting(global_setting)
    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0].name == 'global_setting1'

    # update setting for core plugin
    assert config_data.get_settings() != config_data.get_settings('core')
    assert len(config_data.get_settings('core')) == 0

    core_setting = ConfigSetting('core_setting1')

    config_data.update_setting(core_setting, 'core')
    assert len(config_data.get_settings('core')) == 1

# Generated at 2022-06-22 19:28:59.730947
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Initialize ConfigData object
    data = ConfigData()

    # Plugin configurations
    data.update_setting(Setting('setting_1', 'setting_1_value'))
    data.update_setting(Setting('setting_2', 'setting_2_value'))

    # Plugin configuration objects
    data.update_setting(Setting('setting_1', 'plugin_setting_1_value'), Plugin('plugin_1', 'plugin_1_type'))
    data.update_setting(Setting('setting_2', 'plugin_setting_2_value'), Plugin('plugin_1', 'plugin_1_type'))
    data.update_setting(Setting('setting_1', 'plugin_setting_1_value'), Plugin('plugin_2', 'plugin_2_type'))

# Generated at 2022-06-22 19:29:10.214680
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import pytest
    from ansible.plugins.loader import get_plugin_class

    config_data = ConfigData()

    # New setting is created when updating a non-existing setting
    from ansible.config.setting import Setting
    setting = Setting('ANSIBLE_TEST_KEY', 'ANSIBLE_TEST_VALUE')
    config_data.update_setting(setting)
    settings = config_data.get_settings()
    keys = [s.name for s in settings]
    assert len(settings) == 1 and setting.name in keys

    # Existing global setting is updated
    new_setting = Setting('ANSIBLE_TEST_KEY', 'ANSIBLE_TEST_NEW_VALUE')
    config_data.update_setting(new_setting)
    settings = config_data.get_settings()

# Generated at 2022-06-22 19:29:20.582961
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    # create a setting and update it without a plugin
    setting = ConfigSetting()
    setting.type = 'bool'
    setting.name = 'test_setting'
    setting.default = True
    config_data.update_setting(setting)

    # get the setting and check that it is the same as the one created above
    retrieved_setting = config_data.get_setting('test_setting')
    assert setting == retrieved_setting

    # update the setting with a new value and check that it was updated
    setting.default = False
    config_data.update_setting(setting)
    retrieved_setting = config_data.get_setting('test_setting')
    assert setting == retrieved_setting
    assert setting.default == False

    # create another setting with a plugin and update it with a new value
    setting1

# Generated at 2022-06-22 19:29:22.500830
# Unit test for constructor of class ConfigData
def test_ConfigData():

    data = ConfigData()

    assert len(data._global_settings) == 0
    assert len(data._plugins) == 0


# Generated at 2022-06-22 19:29:31.508621
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.ansible_release import __version__ as version

    config_data = ConfigData()
    config_data.update_setting(
        ConfigSetting(
            name='core',
            value={
                'module_name': 'core',
                'version': version
            },
            origin='ansible_release'
        )
    )

    assert (config_data.get_setting('core')).value == {
        'module_name': 'core',
        'version': version
    }
    assert config_data.get_setting('core') == config_data.get_setting('core', None)
    assert config_data.get_setting('core', None) != config_data.get_setting('core', Plugin('not found', 'not found'))

# Generated at 2022-06-22 19:29:37.918525
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin_type = "plugin_type1"
    plugin_name = "plugin_name1"
    name = "setting_name1"
    setting_1 = Setting(name, True)
    config_data.update_setting(setting_1)
    plugin = PluginDefinition(plugin_type, plugin_name)
    setting_2 = Setting(name, True)
    config_data.update_setting(setting_2, plugin)
    settings = config_data.get_settings()
    assert len(settings) == 2
    settings = config_data.get_settings(plugin)
    assert len(settings) == 1


# Generated at 2022-06-22 19:29:39.820073
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata_obj = ConfigData()
    assert configdata_obj
    print("Unit test for method {} in class {} is passed".format("__init__", "ConfigData"))


# Generated at 2022-06-22 19:29:41.228414
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("test") is None



# Generated at 2022-06-22 19:29:48.623458
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    # test when there is no setting
    assert config_data.get_setting('test') is None
    assert config_data.get_setting('test', plugin=None) is None
    # test when config_data has setting
    config_data.update_setting('test')
    assert config_data.get_setting('test') == 'test'
    assert config_data.get_setting('test', plugin=None) == 'test'

# Generated at 2022-06-22 19:29:50.113602
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert not c._global_settings
    assert not c._plugins
    assert c.get_setting('foo', None) == None



# Generated at 2022-06-22 19:30:00.445512
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    c = ConfigData()
    s = ConfigSetting('foo', 'bar', ['baz'])
    c.update_setting(s)
    assert c.get_setting('foo').name == 'foo'
    assert c.get_setting('foo').plugin is None
    assert c.get_setting('foo').plugin_type == 'global_setting'
    assert c.get_setting('foo').get_value() == 'bar'
    assert c.get_setting('foo').choices == ['baz']
    assert c.get_setting('foo').default == None

    t = ConfigPlugin(type='baz', name='qux')
    c.update_setting(s, t)
    assert c.get_setting('foo', t).name == 'foo'
    assert c.get_setting('foo', t).plugin == t
   

# Generated at 2022-06-22 19:30:04.416078
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    setting = Setting('core','ANSIBLE_CONFIG','ansible.cfg','The config file location')
    configData.update_setting(setting)
    settings = configData.get_settings()
    assert settings[0].name == 'ANSIBLE_CONFIG'
    assert settings[0].description == 'The config file location'


# Generated at 2022-06-22 19:30:07.875534
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    cd.update_setting(Setting("ansible_host", "localhost"))
    assert cd.get_setting("ansible_host") is not None
