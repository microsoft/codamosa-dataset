

# Generated at 2022-06-22 19:20:16.360896
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    ansible_path = "an/sible"
    path_name = "path"
    path_value = "/usr/bin"
    plugin_name = "test"
    plugin_type = "module"
    
    config_data = ConfigData()
    # test global setting
    new_setting = Setting(name=path_name,value=path_value)
    config_data.update_setting(new_setting)
    assert config_data._global_settings[path_name] == new_setting
    # test plugin setting
    new_setting = Setting(name=ansible_path,value=path_value)
    plugin = Plugin(name=plugin_name,type=plugin_type)
    config_data.update_setting(new_setting,plugin)

# Generated at 2022-06-22 19:20:25.105496
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0

    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.vars.base import BaseVarsPlugin
    from ansible.errors import AnsibleParserError

    test_dir = os.path.dirname(__file__)

    # Make up a fake plugin
    plugin_name = 'test1_plugin'
    plugin_dir = os.path.join(test_dir, 'test_config_data', 'plugins', 'test1')
    plugin_file = os.path.join(plugin_dir, '%s.py' % plugin_name)
    # create the fake plugin

# Generated at 2022-06-22 19:20:28.482959
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    cd = ConfigData()

    assert cd.get_settings() == []

    assert cd.get_settings('this_doesnt_exist') == []


# Generated at 2022-06-22 19:20:38.775597
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()
    plugin_types = ["foo", "bar", "baz"]
    plugin_names = ["foo1", "foo2", "baz1", "baz2"]
    settings_names = ["valeur1", "valeur2", "valeur3", "valeur4", "valeur5"]

    for plugin_type in plugin_types:
        for plugin_name in plugin_names:
            for settings_name in settings_names:
                type_name = settings_name + "." + plugin_type + "." + plugin_name
                setting = Setting(settings_name, type_name)
                plugin = Plugin(plugin_type, plugin_name)
                configdata.update_setting(setting, plugin)
                assert(type_name == configdata.get_setting(settings_name, plugin).value)


# Generated at 2022-06-22 19:20:41.992130
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting('test')

    assert config.get_setting('test').name == 'test'
    assert config.get_setting('test').default is None
    assert config.get_setting('test').value is None


# Generated at 2022-06-22 19:20:53.081158
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

# Generated at 2022-06-22 19:21:03.975350
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.config.setting import Setting

    config = ConfigData()
    plugin = Plugin('test', 'test')
    config.update_setting(Setting('FOO', 'bar', config_file='ansible.cfg', section='defaults'))
    config.update_setting(Setting('BAR', 'foo', config_file='ansible.cfg', section='defaults'))
    config.update_setting(Setting('FOO', 'bar', config_file='ansible.cfg', section='defaults', plugin=plugin))
    config.update_setting(Setting('BAR', 'foo', config_file='ansible.cfg', section='defaults', plugin=plugin))
    config.update_setting(Setting('FOO', 'bar', config_file='ansible.cfg', section='defaults'))

# Generated at 2022-06-22 19:21:11.296568
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible import constants as C
    from ansible.module_utils.config_data import ConfigData

    config_data = ConfigData()
    config_data.update_setting(StringSetting('module_utils', 'config_data', 'TEST_SETTING_01', 'test_value_01', 'Test string setting 01'))
    config_data.update_setting(StringSetting('module_utils', 'config_data', 'TEST_SETTING_02', 'test_value_02', 'Test string setting 02'))
    config_data.update_setting(StringSetting('plugins', 'lookup', 'TEST_SETTING_01', 'test_value_03', 'Test string setting 03'))

    test_setting_01 = config_data.get_setting('TEST_SETTING_01')
    assert test_setting_01.name

# Generated at 2022-06-22 19:21:21.730015
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = Plugin("action", "shell")
    setting = Setting("shell", "bash", "command module", "string", "default shell")
    setting1 = Setting("log_path", "/tmp/ansible.log", "core", "string", "Path of ansible log file")
    config_data.update_setting(setting1)
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting("shell", plugin) == setting
    assert config_data.get_setting("log_path") == setting1
    assert config_data.get_setting("shell", Plugin("shell", "bash")) is None
    assert config_data.get_setting("shell", "bash") is None


# Generated at 2022-06-22 19:21:26.806327
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    cd = ConfigData()
    # validate when plugin is None
    assert 0 == len(cd.get_settings(None))
    # validate when plugin type and name are not present
    assert 0 == len(cd.get_settings(Plugin(type='foo', name='bar')))


# Generated at 2022-06-22 19:21:34.828320
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class Plugin(object):

        def __init__(self, type, name):
            self.type = type
            self.name = name

    class Setting(object):

        def __init__(self, name, value=None):
            self.name = name
            self.value = value

    config = ConfigData()

    plugin = Plugin('lookup', 'lookup')
    setting = Setting('something_1', 'other')
    config.update_setting(setting, plugin)

    assert config._plugins['lookup']['lookup']['something_1'].value == 'other'



# Generated at 2022-06-22 19:21:44.636332
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    settings = config_data.get_settings()
    assert len(settings) == 0

    class FakePlugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    ansible_plugin = FakePlugin('connection', 'local')

    class FakeConfigSetting(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value

    local_connection_setting = FakeConfigSetting('pipelining', 'True')

    config_data.update_setting(local_connection_setting, ansible_plugin)
    settings = config_data.get_settings(ansible_plugin)

    assert len(settings) == 1
    setting = settings[0]

# Generated at 2022-06-22 19:21:47.844114
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data is not None
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:21:57.674003
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
	
	config_data = ConfigData()
	config_data._global_settings = {'string_setting': 'string', 'list_setting': ['a', 'b'], 'dict_setting': {'dict_key':'dict_value'}}
	config_data._plugins = {'vars': {'host': {'hostname': "localhost", 'port': 22}}}
	
	# Test for get global setting
	assert config_data.get_setting('string_setting').value == 'string'
	assert config_data.get_setting('list_setting').value == ['a', 'b']
	assert config_data.get_setting('dict_setting').value == {'dict_key':'dict_value'}
	
	# Test for get plugin setting
	from ansible.errors import AnsibleError

# Generated at 2022-06-22 19:22:08.917324
# Unit test for constructor of class ConfigData
def test_ConfigData():

    global_setting_1 = ConfigSetting('set_1', 'This is setting 1', 'string', 'global_value_1', 'global_default_1', 'global_origin_1')
    global_setting_2 = ConfigSetting('set_2', 'This is setting 2', 'string', 'global_value_2', 'global_default_2', 'global_origin_2')

    plugin1 = ConfigPlugin('plugin_1', 'action', '/tmp/a/b/c')
    plugin2 = ConfigPlugin('plugin_2', 'connection', '/tmp/a/b/c')

    setting_1_1 = ConfigSetting('set_1', 'This is setting 1', 'string', 'value_1_1', 'default_1_1', 'origin_1_1')

# Generated at 2022-06-22 19:22:15.896944
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    configData._global_settings = {'globalSetting': 'globalSetting'}
    assert 'globalSetting' == configData.get_setting('globalSetting')
    plugin = Plugin(_type='connection', _name='local')
    assert 'globalSetting' == configData.get_setting('globalSetting', plugin)

    configData._plugins = {'connection': {'local': {'local': 'local'}}}
    assert 'local' == configData.get_setting('local', plugin)
    assert 'local' != configData.get_setting('globalSetting', plugin)


# Generated at 2022-06-22 19:22:25.461800
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.cli.config import Setting

    global_settings = {'key': Setting(name='key', origin='config', value='value')}

    plugin_type = 'cache'
    plugin_name = 'memory'
    plugin_settings = {'timeout': Setting(name='timeout', origin='config', value='50')}

    cd = ConfigData()
    cd._global_settings = global_settings
    cd._plugins = {plugin_type: {plugin_name: plugin_settings}}

    # no plugin, global settings used
    assert cd.get_settings() == [global_settings['key']]

    # plugin type not found, global settings used
    assert cd.get_settings(plugin=Setting(type='not_existing', name='')) == [global_settings['key']]

    # plugin name wrong, global settings used

# Generated at 2022-06-22 19:22:35.469273
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.config_data import ConfigData
    from ansible.module_utils.config_data import PluginConfigData

    config = ConfigData()

    # Testing with global setting
    setting = config.get_setting(name="ANSIBLE_DEBUG")
    assert setting is None
    setting = config.get_setting(name="ANSIBLE_DEBUG", plugin=None)
    assert setting is None

    plugin = PluginConfigData(type="INVALID_TYPE", name="")
    setting = config.get_setting(name="ANSIBLE_DEBUG", plugin=plugin)
    assert setting is None

    # Testing with plugin configuration
    plugin = PluginConfigData(type="MODULE_UTILS", name="BASE_MODULE_UTILS")
    setting = config.get_setting(name="ANSIBLE_API_VERSION", plugin=plugin)

# Generated at 2022-06-22 19:22:45.552080
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()

    from ansible.plugins.loader import PluginLoader

    pluginData = PluginLoader('lookup').get('env')
    configData.update_setting({'name': 'some_key', 'value': 'some_value'}, pluginData)
    pluginData = PluginLoader('lookup').get('file')
    configData.update_setting({'name': 'some_other_key', 'value': 'some_other_value'}, pluginData)

    assert configData.get_setting('some_key') is None
    assert configData.get_setting('some_key', pluginData)['name'] == 'some_key'

    setting = configData.get_setting('some_other_key')['name']
    assert setting == 'some_other_key'

# Generated at 2022-06-22 19:22:46.689953
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData()


# Generated at 2022-06-22 19:22:51.242082
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(AnsibleSetting(name='ANSIBLE_CFG'))
    assert config_data.get_setting('ANSIBLE_CFG').name == 'ANSIBLE_CFG'



# Generated at 2022-06-22 19:23:01.566356
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.parsing import PluginLoader

    # setup
    config_data = ConfigData()
    config_data.update_setting(Setting(name='a', value='A'))
    config_data.update_setting(Setting(name='b', value='B'))
    config_data.update_setting(Setting(name='c', value='C'))
    config_data.update_setting(Setting(name='d', value='D'), Plugin('shell', 'test_shell.py'))

    # get_setting for a global setting
    assert config_data.get_setting('a').value == 'A'

    # get_setting for a plugin setting

# Generated at 2022-06-22 19:23:09.148180
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('s1')
    config_data.update_setting(setting, None)
    assert config_data._global_settings.get('s1') is not None
    assert config_data._global_settings['s1'] == setting
    plugin = Plugin('module', 'testmodule')
    setting = Setting('s2')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['module']['testmodule'].get('s2') is not None
    assert config_data._plugins['module']['testmodule']['s2'] == setting
    setting = Setting('s3')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['module']['testmodule'].get('s3') is not None
   

# Generated at 2022-06-22 19:23:10.754378
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    setting = C.Setting("name", "default")
    configData.update_setting(setting)
    assert(configData.get_setting("name") is setting)


# Generated at 2022-06-22 19:23:13.224946
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert(config_data._global_settings=={})
    assert(config_data._plugins=={})


# Generated at 2022-06-22 19:23:14.526567
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()



# Generated at 2022-06-22 19:23:16.311427
# Unit test for constructor of class ConfigData
def test_ConfigData():
    obj = ConfigData()

# unit test for get_setting()

# Generated at 2022-06-22 19:23:21.033158
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

    config_data = ConfigData()
    assert config_data.get_settings() == []

    config_data = ConfigData()
    assert config_data.get_settings() == []

# Generated at 2022-06-22 19:23:34.052191
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    """
    (Unit Test) test the get_setting method
    """
    config_data = ConfigData()

    # GET SETTING (for deprecated setting)
    # Given a config data instance with plugin deprecated setting
    # When I ask for deprecated setting
    # Then I get a deprecated setting object
    config_data.update_setting(PluginSetting(name='deprecated setting',
                                             section='plugin',
                                             defaults=['default_value'],
                                             deprecated_names=['deprecated_name'],
                                             aliases={'alias': 'real_name'}))
    assert config_data.get_setting('deprecated setting') is not None

    # GET SETTING (for non-deprecated setting)
    # Given a config data instance
    # When I ask for non-existing setting
    # Then I get None

# Generated at 2022-06-22 19:23:43.983322
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Create object ConfigData
    config_data = ConfigData()

    # Create object plugin
    from ansible.module_utils.ansible_release.plugin import Plugin

    plugin = Plugin(name='ansible_release', type='role')

    # Create object setting
    from ansible.module_utils.ansible_release.setting import Setting

    setting_1 = Setting(name='ansible_release_version', value='2.7.0')
    setting_2 = Setting(name='configuration_file', value='tests/data/tasks/include.yml')

    # Test method update_setting
    config_data.update_setting(setting_1, plugin)
    config_data.update_setting(setting_2)

    assert config_data.get_setting('configuration_file') == setting_2

# Generated at 2022-06-22 19:23:54.260457
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    class AnsiblePlugin(object):
        def __init__(self, t, n):
            self.type = t
            self.name = n

    class ConfigSetting(object):
        def __init__(self, name, value, plugin):
            self.name = name
            self.value = value
            self.plugin = plugin

    cd = ConfigData()
    ansible_plugin = AnsiblePlugin('hosts', 'localhost')
    ansible_plugin2 = AnsiblePlugin('hosts', 'localhost2')
    setting = ConfigSetting('ANSIBLE_LIBRARY', '~/.ansible/plugins/modules', ansible_plugin)
    cd.update_setting(setting)
    setting2 = ConfigSetting('ANSIBLE_LIBRARY', '~/.ansible/plugins/modules', ansible_plugin2)
    cd.update_setting

# Generated at 2022-06-22 19:24:03.300323
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    # test ConfigData instance
    assert isinstance(config_data, ConfigData)
    # test get_setting with both plugin and global setting fields
    assert config_data.get_setting(name='setting1', plugin='plugin1') == None
    assert config_data.get_setting(name='setting1') == None
    # test get_settings with both plugin and global setting fields
    assert config_data.get_settings(plugin='plugin1') == None
    # test get_settings with plugin
    assert config_data.get_settings() == None


# Generated at 2022-06-22 19:24:12.686297
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin = Plugin('module_utils', 'all')
    config_data = ConfigData()
    setting = Setting('action_plugins', '/usr/lib/python2.7/site-packages/ansible/plugins/action')
    config_data.update_setting(setting)
    config_data.update_setting(setting, plugin=plugin)
    assert config_data.get_settings(plugin=plugin) == ['action_plugins']


if __name__ == '__main__':
    test_ConfigData_get_settings()

# Generated at 2022-06-22 19:24:23.059558
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    assert config_data.get_settings() == []

    config_data._global_settings = {
        'global_setting': 'global'
    }

    assert config_data.get_settings() == ['global']

    plugin_info = PluginInfo('some_type', 'some_name')

    config_data._plugins = {
        'some_type': {
            'some_name': {
                'plugin_setting': 'plugin'
            }
        }
    }

    assert config_data.get_settings() == ['global']
    assert config_data.get_settings(plugin_info) == ['plugin']


# Generated at 2022-06-22 19:24:31.308935
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.config.setting import Setting

    config_data = ConfigData()

    setting = Setting()
    setting.name = 'TEST'
    setting.value = 'FOO'
    setting.origin = 'default'

    # In Scope Global
    config_data.update_setting(setting)

    setting = Setting()
    setting.name = 'TEST2'
    setting.value = 'BAR'
    setting.origin = 'default'

    # In Scope Plugin
    config_data.update_setting(setting, plugin=None)

    assert config_data._global_settings['TEST'].value == 'FOO'
    assert config_data._global_settings['TEST2'].value == 'BAR'


# Generated at 2022-06-22 19:24:37.539170
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    setting = "test_setting"
    plugin = "test_plugin"
    config._global_settings = {setting: {}}
    config._plugins = {plugin: {}}
    assert config.get_setting(setting)
    assert config.get_setting(setting, plugin)

# Generated at 2022-06-22 19:24:43.957181
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import datetime
    from ansible_collections.cisco.nxos.plugins.module_utils.network.nxos.plugins.module_utils.config.setting import Setting

    config_data = ConfigData()
    setting = Setting(name='new_setting', desc='new_setting_desc', value=42, overwrite=False)
    config_data.update_setting(setting)

    assert len(config_data.get_settings('null') ) == 1, "ConfigData get_settings method returned unexpected number of settings."


# Generated at 2022-06-22 19:24:51.140259
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    configdata = ConfigData()
    assert configdata.get_setting('foo') is None

    #plugin = Plugin('testplugin', 'testplugin', 'testplugin', 'testplugin', 'testplugin')
    #setting = Setting('foo', 'bar', None, None, None)
    #configdata.update_setting(setting)
    #assert configdata.get_setting(setting.name) == setting

# Generated at 2022-06-22 19:25:01.088636
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert cd.get_setting("validate_certs") is None

    from ansible.config.setting import Setting
    validate_certs_setting = Setting("validate_certs", "BOOLEAN", False)
    cd.update_setting(validate_certs_setting)
    assert cd.get_setting("validate_certs") == validate_certs_setting

    from ansible.plugins import PluginLoader
    netconf_connection = PluginLoader.load_plugin("connection", "netconf")
    validate_certs_setting = Setting("validate_certs", "BOOLEAN", True, "CONNECTION", netconf_connection, 1)

    cd.update_setting(validate_certs_setting)
    assert cd.get_setting("validate_certs") == validate_cert

# Generated at 2022-06-22 19:25:05.962551
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    setting = ConfigDataSetting("test1", "value1")
    config_data.update_setting(setting)
    assert config_data._global_settings["test1"] == setting

    plugin = ConfigDataPlugin("python", "test1", "test1")
    setting = ConfigDataSetting("test2", "value2")
    config_data.update_setting(setting, plugin)
    assert config_data._plugins["python"]["test1"]["test2"] == setting


# Generated at 2022-06-22 19:25:07.699847
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cd = ConfigData()
    assert cd._global_settings == {}
    assert cd._plugins == {}

# Generated at 2022-06-22 19:25:16.625237
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    cd = ConfigData()

    assert cd.get_setting('a') is None
    assert len(cd.get_settings()) == 0

    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import add_directory
    from ansible.utils.plugin_docs import read_docstring

    class Plugin(object):

        def __init__(self, type, name):
            self.type = type
            self.name = name

    add_directory('./library')
    plugin_loader = PluginLoader('./library')
    plugins = plugin_loader.all()

    config_data = ConfigData()

    doc_on_methods = []
    for plugin in plugins:
        doc_on_methods += read_docstring(plugin_loader._get_docstring(plugin))

# Generated at 2022-06-22 19:25:17.823501
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config


# Generated at 2022-06-22 19:25:23.613914
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('name') == None
    assert config_data.get_setting('name', plugin=None) == None
    assert config_data.get_setting('name', plugin='plugin') == None
    assert config_data.get_setting('name', plugin=['plugin', 'type']) == None

    # Set global setting
    config_data.update_setting('global_name', plugin=None)
    assert config_data.get_setting('global_name') == 'global_name'
    assert config_data.get_setting('global_name', plugin=None) == 'global_name'
    assert config_data.get_setting('global_name', plugin='plugin') == None

# Generated at 2022-06-22 19:25:33.801541
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {"global config": "global value"}
    config_data._plugins = {
        "plugin type": {
            "plugin name": {
                "plugin config": "plugin value"
            }
        }
    }

    # Get global settings
    global_settings = config_data.get_settings()
    assert len(global_settings) == 1, "get_settings returns incorrect number of global settings"
    assert global_settings[0].name == "global config", "get_settings returns incorrect global setting"

    # Get plugin settings
    plugin_settings = config_data.get_settings(Plugin(name="plugin name", type="plugin type"))
    assert len(plugin_settings) == 1, "get_settings returns incorrect number of plugin settings"

# Generated at 2022-06-22 19:25:34.921916
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert c._global_settings == {}
    assert c._plugins == {}


# Generated at 2022-06-22 19:25:44.581260
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    name = 'plugin_name'
    type = 'plugin_type'
    setting_name = 'setting_name'
    setting_value = 'setting_value'
    plugin = Plugin(name, type)
    setting = Setting(setting_name, setting_value)
    cd.update_setting(setting, plugin)
    assert cd.get_setting(setting_name, plugin) == setting
    assert cd.get_setting(setting_name) == None
    assert cd.get_setting(setting_name, type='foo') == None
    assert cd.get_setting(setting_name, name='foo') == None


# Generated at 2022-06-22 19:25:56.698278
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from collections import namedtuple

    config_data = ConfigData()

    Plugin = namedtuple('Plugin', ['type', 'name'])
    plugin = Plugin(type='action', name='test')

    class Setting:
        def __init__(self, name, value, origin):
            self._name = name
            self._value = value
            self._origin = origin

        def __str__(self):
            return self.name

        def __repr__(self):
            return self.name

        @property
        def name(self):
            return self._name

        @property
        def value(self):
            return self._value

        @property
        def origin(self):
            return self._origin

    assert config_data.get_setting('test') == None

# Generated at 2022-06-22 19:25:59.457762
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    setting = Setting('foo', 'bar')

    config_data.update_setting(setting)

    assert config_data.get_setting(setting.name).value == setting.value


# Generated at 2022-06-22 19:26:09.186272
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint.rules.use_shell_default import UseShellDefault
    from ansiblelint.rules.use_blockinfile_default import UseBlockinfileDefaults
    from ansiblelint.rules.use_blockinfile_default import UseBlockinfileDefaults

    cdata = ConfigData()

    cdata.update_setting(UseShellDefault.setting, plugin=UseShellDefault)
    cdata.update_setting(UseBlockinfileDefaults.setting, plugin=UseBlockinfileDefaults)
    assert len(cdata.get_settings(plugin=UseShellDefault)) == 1
    assert len(cdata.get_settings(plugin=UseBlockinfileDefaults)) == 1


# Generated at 2022-06-22 19:26:11.189272
# Unit test for constructor of class ConfigData
def test_ConfigData():
    conData = ConfigData()
    assert conData._global_settings == {}
    assert conData._plugins == {}



# Generated at 2022-06-22 19:26:19.971984
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    new_setting1 = Setting('foo','bar','baz','qux')
    new_setting2 = Setting('bar','baz','qux','foo')
    new_plugin = Plugin('foo','bar','baz')
    config_data.update_setting(new_setting1)
    assert(len(config_data.get_settings()) == 1)
    config_data.update_setting(new_setting2)
    assert(len(config_data.get_settings()) == 2)
    config_data.update_setting(new_setting2,new_plugin)
    assert(len(config_data.get_settings()) == 2)
    assert(len(config_data.get_settings(new_plugin)) == 1)


# Generated at 2022-06-22 19:26:27.297297
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Create object
    config = ConfigData()
    # Create settings
    setting1 = Setting(name='setting1', description='A description for setting1', value=10)
    plugin = Plugin('module', 'Foo')
    setting2 = Setting(name='setting2', description='A description for setting2', value=20)

    # Populate the object
    config.update_setting(setting1)
    config.update_setting(setting2, plugin)

    # Test that the settings are returned properly
    assert config.get_setting('setting1') == setting1
    assert config.get_setting('setting2', plugin) == setting2



# Generated at 2022-06-22 19:26:31.788726
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(utils.ConfigSetting('core', 'strategy_plugins', 'strategy_plugins', 'linear', ''))
    setting = config.get_setting('strategy_plugins')
    assert setting.name == 'strategy_plugins'
    assert setting.value == 'linear'


# Generated at 2022-06-22 19:26:36.556422
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert config_data.get_settings() == []

    config_data.update_setting(ConfigSetting(name="worker_processes", value="1"))

    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0].name == "worker_processes"
    assert config_data.get_settings()[0].value == "1"


# Generated at 2022-06-22 19:26:40.278613
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('log_path', '/var/log/ansible.log'))


# Generated at 2022-06-22 19:26:46.201733
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()

    assert [config.get_settings()] == []
    assert [config.get_settings('module')] == []
    assert [config.get_settings('module', 'foo')] == []
    assert [config.get_settings()] == []



# Generated at 2022-06-22 19:26:54.933598
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting1 = Setting('test')
    setting2 = Setting('test')
    config_data.update_setting(setting1, Plugin('test_plugin', 'test_type'))
    config_data.update_setting(setting2)

    assert config_data.get_setting('test') == setting2
    assert config_data.get_setting('test', Plugin('test_plugin', 'test_type')) == setting1
    assert config_data.get_settings() == [setting2]
    assert config_data.get_settings(Plugin('test_plugin', 'test_type')) == [setting1]



# Generated at 2022-06-22 19:26:57.560117
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    assert cd.get_setting('bar') is None



# Generated at 2022-06-22 19:27:05.784769
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting('setting_1', plugin=None)
    config_data.update_setting('setting_2', plugin=None)

    assert config_data.get_setting('setting_1', plugin=None) == 'setting_1'
    assert config_data.get_setting('setting_2', plugin=None) == 'setting_2'
    assert config_data.get_settings(None) == ['setting_1', 'setting_2']
    assert config_data.get_settings('plugin') == []


# Generated at 2022-06-22 19:27:07.924644
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    assert config_data.get_setting('foo') == None

    from ansible_collections.ansible.community.plugins.module_utils.ansible_release import AnsibleRelease
    plugin = AnsibleRelease('collection.name', 'module_utils.name')

    assert config_data.get_setting('foo', plugin) == None


# Generated at 2022-06-22 19:27:11.927013
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData()._global_settings == {}
    assert ConfigData()._plugins == {}


# Generated at 2022-06-22 19:27:13.943100
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()

    assert data._global_settings == {}
    assert data._plugins == {}

# Generated at 2022-06-22 19:27:18.111632
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    config.update_setting(Setting("foo", None, None, None, None, None, None, None, None, None, None, None, None, "bar"))
    result = config.get_setting("foo")
    assert result.value == "bar"


# Generated at 2022-06-22 19:27:28.296900
# Unit test for constructor of class ConfigData
def test_ConfigData():
    obj = ConfigData()
    assert isinstance(obj, ConfigData)

try:
    import ansible_collections.ansible.misc.plugins.modules.galaxy_role_info as galaxy_role_info
except ImportError:
    import ansible.plugins.modules.galaxy_role_info as galaxy_role_info

test_config_data = ConfigData()
test_plugin = galaxy_role_info.GalaxyRoleInfo(plugin_config_data=test_config_data)
test_setting = galaxy_role_info.ConfigSetting(name="test_setting", default="default_setting_value")
test_config_data.update_setting(test_setting, plugin=test_plugin)

# Test for method get_setting of class ConfigData

# Generated at 2022-06-22 19:27:30.321335
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)


# Generated at 2022-06-22 19:27:34.077694
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin('Module', 'test_module')
    setting = Setting('test_setting')
    config_data.update_setting(setting)
    config_data.update_setting(setting, plugin)
    assert (setting in config_data.get_settings())
    assert (setting in config_data.get_settings(plugin))


# Generated at 2022-06-22 19:27:35.002783
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-22 19:27:44.692756
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    cfg_data = ConfigData()
    assert cfg_data.get_setting(setting.name, plugin) == None

    cfg_data.update_setting(setting)
    assert cfg_data.get_setting(setting.name, plugin) == setting

    cfg_data.update_setting(setting, plugin)
    assert cfg_data.get_setting(setting.name, plugin) == None
    assert cfg_data.get_setting(setting.name, None) == setting
    assert cfg_data.get_setting(setting.name, plugin2) == None
    assert cfg_data.get_setting(setting.name, plugin) == setting

    cfg_data.update_setting(setting, plugin2)
    assert cfg_data.get_setting(setting.name, plugin) == None
    assert cfg

# Generated at 2022-06-22 19:27:52.557361
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('test_name_0', 'test_value_0'))
    config_data.update_setting(ConfigSetting('test_name_1', 'test_value_1'))

    # unit test of method get_settings when input parameter is None
    settings = config_data.get_settings()
    assert 2 == len(settings)

    assert 'test_name_0' == settings[0].name
    assert 'test_value_0' == settings[0].value

    assert 'test_name_1' == settings[1].name
    assert 'test_value_1' == settings[1].value



# Generated at 2022-06-22 19:27:54.214036
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    assert len(cd.get_settings()) == 0



# Generated at 2022-06-22 19:27:58.119518
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    plugin_type = "type"
    plugin_name = "name"
    plugin = PluginDefinition(plugin_type, plugin_name)
    setting = SettingDefinition("setting", "value", default=True)
    config = ConfigData()
    config.update_setting(setting, plugin)
    assert config.get_setting("setting", plugin) == setting
    assert config.get_setting("setting") is None



# Generated at 2022-06-22 19:28:07.451379
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    global_setting = _ConfigSetting('test-setting', 'this is a sample setting')
    config_data = ConfigData()
    config_data.update_setting(global_setting)
    assert(config_data.get_setting('test-setting') == global_setting)

    plugin = _Plugin('plugin_type', 'plugin_name')
    plugin_setting = _ConfigSetting('plugin-setting', 'this is a sample plugin setting')
    config_data.update_setting(plugin_setting, plugin)
    assert(config_data.get_setting('plugin-setting', plugin) == plugin_setting)



# Generated at 2022-06-22 19:28:08.960396
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}

# Generated at 2022-06-22 19:28:15.706413
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_all_plugin_loaders

    config_data = ConfigData()

    # Create plugin setting
    plugin = get_plugin_class('inventory', 'auto')()
    name = 'hostfile'
    description = 'A list of paths to inventory host definition files'
    default = []
    plugin_setting = plugin.add_setting(name, description, default)

    # Update plugin setting
    config_data.update_setting(plugin_setting, plugin)

    # Test global setting
    assert config_data.get_setting('hostfile') is None

    # Test plugin setting
    assert 'hostfile' in config_data.get_settings(plugin)



# Generated at 2022-06-22 19:28:16.892842
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()


# Generated at 2022-06-22 19:28:21.671247
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert config.get_setting(name="__name__") is None
    assert config.get_setting(name="__name__", plugin="__plugin__") is None


# Generated at 2022-06-22 19:28:31.753595
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()

    # Test with global setting
    setting = 'testfound'
    config._global_settings = {'testfound': setting}
    assert config.get_setting('testfound') == setting

    # Test with non-existing plugin
    config._global_settings = {}
    assert config.get_setting('testfound', Plugin('other', 'name')) == None

    # Test with non-existing name for plugin type and name
    plugin = Plugin('module', 'test')
    config._plugins = {'module': {'test': {}}}
    assert config.get_setting('testfound', plugin) == None

    # Test with existing plugin type, name and setting
    setting = 'testfound'
    config._plugins = {'module': {'test': {'testfound': setting}}}

# Generated at 2022-06-22 19:28:32.279513
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # TBD
    pass


# Generated at 2022-06-22 19:28:37.561396
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()

    assert config.get_settings() == []

    config.update_setting(Setting('ANSIBLE_TRANSPORT', 'SSH'))

    settings = config.get_settings()
    assert len(settings) == 1
    assert settings[0].name == 'ANSIBLE_TRANSPORT'
    assert settings[0].value == 'SSH'


# Generated at 2022-06-22 19:28:48.265257
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    new_setting = Setting('setting1')
    new_setting.value = True
    new_setting.scope = ['global']
    new_setting.origin = 'input'
    new_setting.plugin = Plugin('Connection', {'name': 'ssh', 'type': 'connection'})
    config = ConfigData()
    config.update_setting(new_setting)
    assert 'setting1' in config._global_settings
    assert config._global_settings['setting1'] == new_setting
    assert config._global_settings['setting1'].plugin.name == 'ssh'


# Generated at 2022-06-22 19:28:59.387087
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting(name="foo", plugin=Plugin(name="bar", type="baz")))
    config_data.update_setting(Setting(name="boo", plugin=Plugin(name="baz", type="bar")))
    config_data.update_setting(Setting(name="bar"))
    config_data.update_setting(Setting(name="baz"))

    settings = config_data.get_settings(plugin=Plugin(name="boo", type="boo"))
    assert settings == []

    settings = config_data.get_settings(plugin=Plugin(name="bar", type="baz"))
    assert settings == [Setting(name="foo", plugin=Plugin(name="bar", type="baz"))]


# Generated at 2022-06-22 19:29:07.412413
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    setting = Setting(name="test setting 1", value="test_1")
    config.update_setting(setting)
    setting = Setting(name="test setting 2", value="test_2")
    config.update_setting(setting, Plugin("test_plugin", "test_type"))

    assert config.get_setting("test setting 1").value == "test_1"
    assert config.get_setting("test setting 2").value == "test_2"


# Generated at 2022-06-22 19:29:10.681653
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd._plugins == {}
    assert cd._global_settings == {}


# Generated at 2022-06-22 19:29:13.837500
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    assert config_data.get_settings() == []
    assert config_data.get_settings('source') == []

# Generated at 2022-06-22 19:29:16.313974
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert c._global_settings == {}
    assert c._plugins == {}

# Generated at 2022-06-22 19:29:23.771044
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import config_loader

    global_config = config_loader.get(None, None)
    config_data = ConfigData()
    config_data.update_setting(global_config['DEFAULT_MODULE_NAME'])
    config_data.update_setting(global_config['DEFAULT_MODULE_ATTRIBUTES'])
    config_data.update_setting(global_config['DEFAULT_MODULE_ARGS'])

    settings = config_data.get_settings()
    assert len(settings) == len(global_config) - 3

# Generated at 2022-06-22 19:29:26.990720
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {}
    setting["name"] = "config_setting"
    config_data.update_setting(setting)
    assert config_data.get_setting("config_setting") == setting


# Generated at 2022-06-22 19:29:37.856705
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    pluginA = ConfigPlugin("A", "typeA")
    pluginB = ConfigPlugin("B", "typeB")
    config.update_setting(ConfigSetting("setting1", "value1", "descriptionA", pluginA))
    config.update_setting(ConfigSetting("setting2", "value2", "descriptionB", pluginA))
    config.update_setting(ConfigSetting("setting3", "value3", "descriptionC", pluginB))
    config.update_setting(ConfigSetting("setting4", "value4", "descriptionD", None))
    settings = config.get_settings()
    assert len(settings) == 4
    assert settings[0].name == "setting4"


# Generated at 2022-06-22 19:29:40.070306
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    cd.update_setting('Hello')
    cd.update_setting('World')
    assert [s.name for s in cd.get_settings()] == ['Hello', 'World']



# Generated at 2022-06-22 19:29:42.693678
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}


# TODO: Create a unit test for get_setting

# TODO: Create a unit test for get_settings

# TODO: Create a unit test for update_setting

# Generated at 2022-06-22 19:29:51.323419
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    from ansible.plugins.loader import shared_loader
    import ansible.plugins.action as action_plugins
    plugin_loader = shared_loader.PluginLoader('action', action_plugins)

    from ansible.plugins.action.copy import ActionModule
    plugin = plugin_loader.get('copy', ActionModule, {}, None)

    from Model.CSetting import CSetting
    setting = CSetting('setting_name', 'setting_value', plugin)
    config_data.update_setting(setting)

    assert config_data.get_setting('setting_name') == setting



# Generated at 2022-06-22 19:29:52.990498
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data


# Generated at 2022-06-22 19:29:58.641611
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    ansible_setting = Setting('foo', 'bar', 'ansible.cfg')
    plugin = Plugin('callback', 'test')
    config_data.update_setting(ansible_setting, plugin=plugin)
    result = config_data.get_settings(plugin=plugin)
    assert result is not None
    assert result[0] == ansible_setting


# Generated at 2022-06-22 19:30:01.023249
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()
    configdata.update_setting(None)
    assert configdata.get_settings() == configdata._global_settings


# Generated at 2022-06-22 19:30:07.922798
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    # first setting is global
    setting = {'name': 'timeout', 'value': '10'}
    config_data.update_setting(setting)
    assert config_data.get_setting(setting['name']) == setting
    assert config_data.get_setting(setting['name'], plugin={'type': 'connection', 'name': 'smart'}) is None

    # second setting for connection plugin
    setting = {'name': 'timeout', 'value': '20'}
    config_data.update_setting(setting, plugin={'type': 'connection', 'name': 'smart'})
    assert config_data.get_setting(setting['name']) == {'name': 'timeout', 'value': '10'}