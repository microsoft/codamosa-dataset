

# Generated at 2022-06-22 19:20:16.363382
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(Setting(name="foo", value="bar"))
    config.update_setting(Setting(name="bar", value="baz"))
    config.update_setting(Setting(name="baz", value="foo"), plugin=Plugin(name="cool", type="executor"))
    config.update_setting(Setting(name="bar", value="cool"), plugin=Plugin(name="baz", type="executor"))
    assert config.get_setting("foo") == "bar"
    assert config.get_settings() == ["bar", "baz"]
    assert config.get_setting("foo", plugin=Plugin(name="cool", type="executor")) == "bar"
    assert config.get_setting("baz", plugin=Plugin(name="cool", type="executor")) == "foo"

# Generated at 2022-06-22 19:20:17.620309
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert c is not None


# Generated at 2022-06-22 19:20:25.821054
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class Setting:
        def __init__(self, n, v, t, p='', s=''):
            self.name = n
            self.value = v
            self.type = t
            self.plugin = p
            self.src = s

        def is_changed(self):
            return False

        # Emulate ansible.constants.Config
        def _setting(self):
            return self

    class Plugin:
        def __init__(self, t, n):
            self.type = t
            self.name = n

    d = ConfigData()
    assert d.get_settings() == []

    # Update a global setting
    s = Setting('global_setting', 'global_value', 'global', s='/tmp/global.cfg')
    d.update_setting(s)

    assert d.get_

# Generated at 2022-06-22 19:20:28.482233
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()

    assert config._global_settings == {}
    assert config._plugins == {}


# Generated at 2022-06-22 19:20:37.357082
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from config_data import ConfigData

    data = ConfigData()
    assert len(data.get_settings()) == 0

    from setting import Setting

    setting = Setting('', '', '', '', '', '', '')
    data.update_setting(setting)
    assert len(data.get_settings()) == 1
    assert len(data.get_settings(None)) == 1

    from plugin import Plugin

    plugin = Plugin('', '', '', '', '', '')
    data.update_setting(setting, plugin)
    assert len(data.get_settings()) == 1
    assert len(data.get_settings(plugin)) == 1


# Generated at 2022-06-22 19:20:39.917069
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cd.update_setting('0')
    cd.update_setting('1', '2')
    cd.update_setting('3', '4', '5')


# Generated at 2022-06-22 19:20:46.431777
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    config_data._global_settings = {
        "test": "test"
    }

    config_data._plugins = {
        "test_type": {
            "test_plugin": {
                "test": "test"
            }
        }
    }

    print("--- Test get_setting without plugin ---")
    print(config_data.get_setting("test"))

    print("\n--- Test get_setting with plugin ---")
    print(config_data.get_setting("test", "test_type", "test_plugin"))

    print("\n--- Test get_setting with non-existing key ---")
    print(config_data.get_setting("non_existing"))

    print("\n--- Test get_setting without plugin with non-existing key ---")

# Generated at 2022-06-22 19:20:55.069899
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    c = ConfigData()
    s = Setting(name='chdir')
    s.value = '.'
    c.update_setting(s)
    assert c.get_setting('chdir') == s

    s2 = Setting(name='module_arguments')
    s2.value = '-a "b c"'
    c.update_setting(s2)
    assert c.get_setting('module_arguments').value == '-a "b c"'

    s3 = Setting(name='chdir')
    s3.value = "newpath"
    from collections import namedtuple
    Plugin = namedtuple('Plugin', ['name', 'type'])
    plugin = Plugin('plugins.sql', 'strategy')
    c.update_setting(s3, plugin)

# Generated at 2022-06-22 19:21:02.102190
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Arrange
    c = ConfigData()

    # Act
    c.update_setting(Setting("data_source", "local"))
    c.update_setting(Setting("vault_password_file", "~/vault_password"))

    # Assert
    assert c._global_settings[Setting("data_source","local")] == "local"
    assert c._global_settings[Setting("vault_password_file","~/vault_password")] == "~/vault_password"

if __name__ == "__main__":
    test_ConfigData_update_setting()

# Generated at 2022-06-22 19:21:08.706208
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin1 = PluginType('type1', 'name1')
    plugin2 = PluginType('type2', 'name2')
    setting1 = Setting('setting1', 'value1', plugin1)
    setting2 = Setting('setting2', 'value2', plugin1)
    setting3 = Setting('setting3', 'value3', plugin2)

    config_data = ConfigData()
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting3)

    settings = config_data.get_settings(plugin1)

    assert settings[0] == setting1
    assert settings[1] == setting2


# Generated at 2022-06-22 19:21:15.261683
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Test attempt to get non-existent setting
    assert config_data.get_setting('foo_setting') is None
    assert config_data.get_setting(name='foo_setting', plugin=None) is None

    # Update setting
    config_data.update_setting(setting=Setting('foo_setting', 'value1'))

    # Get global setting
    result = config_data.get_setting(name='foo_setting')
    assert result.name == 'foo_setting'
    assert result.value == 'value1'

    # Get global setting with parameterized method call
    result = config_data.get_setting('foo_setting')
    assert result.name == 'foo_setting'
    assert result.value == 'value1'

    # Get global setting with no-arg method call
    result

# Generated at 2022-06-22 19:21:25.196289
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Set up the test
    config_data = ConfigData()
    assert config_data.get_setting("foo", None) is None

    # Update the global setting
    config_data.update_setting("foo=bar", None)
    assert config_data.get_setting("foo", None) == "bar"

    # Update the setting for the connection plugin
    config_data.update_setting("foo=baz", "connection")
    assert config_data.get_setting("foo", "connection") == "baz"

    # The global setting still matches
    assert config_data.get_setting("foo", None) == "bar"

    # Test that invalid plugin type raises exception
    try:
        config_data.get_setting("foo", "invalid")
        raise Exception("Should have raised")
    except InvalidPluginType:
        pass

# Generated at 2022-06-22 19:21:35.740005
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    class Plugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name
    data = ConfigData()

    data.update_setting(ConfigSetting('setting', 'value'))
    data.update_setting(ConfigSetting('setting', 'value2'))
    assert len(data.get_settings(Plugin(None, None))) == 2

    data.update_setting(ConfigSetting('setting', 'value3', Plugin('type', 'name')))
    data.update_setting(ConfigSetting('setting', 'value4', Plugin('type', 'name')))
    data.update_setting(ConfigSetting('setting', 'value4', Plugin('type2', 'name')))
    assert len(data.get_settings(Plugin('type', 'name'))) == 2

# Generated at 2022-06-22 19:21:42.097733
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    python = PluginType('python')
    foo = Plugin('foo', python)
    bar = Plugin('bar', python)
    config_data = ConfigData()
    config_data.update_setting(Setting('test', 'value'))
    config_data.update_setting(Setting('test', 'value'), foo)
    config_data.update_setting(Setting('test', 'value'), bar)
    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings(foo)) == 1
    assert len(config_data.get_settings(bar)) == 1
    assert config_data.get_settings()[0].name == 'test'
    assert config_data.get_settin

# Generated at 2022-06-22 19:21:42.702262
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData()

# Generated at 2022-06-22 19:21:53.263399
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    s = Setting('special_host', '192.168.1.1')

    # Check for the global settings
    settings = cd.get_settings()
    assert len(settings) == 0
    assert not settings

    # Add a global setting
    cd.update_setting(s)
    settings = cd.get_settings()
    assert len(settings) == 1
    s_ = settings[0]
    assert s.name == s_.name
    assert s.value == s_.value

    # Add another global setting
    s2 = Setting('s', 'v', type='Foo')
    cd.update_setting(s2)
    settings = cd.get_settings()
    assert len(settings) == 2
    s2_ = settings[1]
    assert s2.name == s2_.name


# Generated at 2022-06-22 19:22:01.058737
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    
    def get_setting_1():
        '''
        Purpose: Test if the method get_setting returns None if a plugin is not defined.
        '''

        print('Test if the method get_setting returns None if a plugin is not defined:')
        setting = config_data.get_setting('setting1')
        assert setting is None


    def get_setting_2():
        '''
        Purpose: Test if the method get_setting returns the correct setting for a plugin.
        '''

        from ansible.plugins.loader import plugin_loader

        plugin = plugin_loader.get('FilterModule', 'groupby')

        print('Test if the method get_setting returns the correct setting for a plugin:')
        setting = config_data.get_setting('value', plugin)
        assert len(setting)

# Generated at 2022-06-22 19:22:09.953912
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # get setting valid
    plugin1 = Plugin('test', 'type1')
    setting1 = Setting('key', 'test', plugin=plugin1)
    config_data.update_setting(setting1)
    assert(config_data.get_setting('key', plugin1) == setting1)
    assert(config_data.get_setting('key') is None)

    # get setting invalid
    assert(config_data.get_setting('key', plugin1) == setting1)
    assert(config_data.get_setting('key') is None)


# Generated at 2022-06-22 19:22:17.975781
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblelint.rules.ANSIBLE0017 import ConfigData
    from ansiblelint.rules.ANSIBLE0017 import ConfigSetting

    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('nocolor', None, True, False, False, 'ansible.cfg', 1))
    assert config_data.get_setting('nocolor').name == 'nocolor'

    from ansiblelint.rules.ANSIBLE0017 import PluginType
    from ansiblelint.rules.ANSIBLE0017 import Plugin

    plugin = Plugin('core', PluginType.ACTION)
    config_data.update_setting(ConfigSetting('nocolor', None, True, False, False, 'ansible.cfg', 1),
                               plugin)
    assert config_data.get_setting('nocolor', plugin).name

# Generated at 2022-06-22 19:22:19.623169
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-22 19:22:26.131498
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    data.update_setting(Setting('var1', 'string', 'val1'))
    assert data.get_setting('var1').name == 'var1'
    assert data.get_setting('var2') is None
    assert data.get_setting('var1').value == 'val1'
    assert data.get_setting('var1').type == 'string'
    
    data.update_setting(Setting('var1', 'string', 'val2'))
    assert data.get_setting('var1').value == 'val2'



# Generated at 2022-06-22 19:22:34.928360
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from collections import OrderedDict
    config_data = ConfigData()
    # We test the method with a custom C plugin (http://docs.ansible.com/ansible/latest/dev_guide/developing_plugins.html)
    # 'type' is the plugin type, 'name' is the plugin name and 'path' is the
    # path of the plugin (used to load the plugin).
    plugin = OrderedDict([('type', 'lookup'), ('name', 'random'), ('path', 'plugins/lookup/random.py')]) 
    # We test the method with a global setting (http://docs.ansible.com/ansible/latest/intro_configuration.html#setting-the-default-key-value-file)
    # 'setting' is the name of the setting, 'value' is the value of the setting,

# Generated at 2022-06-22 19:22:40.233821
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    data = ConfigData()

    setting = data.get_setting('ansible_user', None)
    assert setting is None

    setting = data.get_setting('ansible_user')
    assert setting is None

    setting = data.get_setting('ansible_user', 'local')
    assert setting is None


# Generated at 2022-06-22 19:22:41.508997
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert isinstance(cd, ConfigData)


# Generated at 2022-06-22 19:22:44.100511
# Unit test for constructor of class ConfigData
def test_ConfigData():
    gs = ConfigData()
    assert len(gs._global_settings) == 0
    assert len(gs._plugins) == 0

# Generated at 2022-06-22 19:22:48.240612
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting(): #TODO
    configData = ConfigData()
    plugin = Plugin('shell', 'script')
    setting = Setting('playbook_path', 'playbook.yml')
    configData.update_setting(setting)
    assert configData.get_setting('playbook_path') == setting
    configData.update_setting(setting, plugin)
    assert configData.get_setting(setting.name, plugin) == setting



# Generated at 2022-06-22 19:22:58.070140
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class TestPlugin(object):
        def __init__(self, name, type):
            self.name = name
            self.type = type

    class TestSetting(object):
        def __init__(self, name):
            self.name = name

    config_data = ConfigData()
    setting1 = TestSetting("test_setting_include")
    setting2 = TestSetting("test_setting_other")
    plugin = TestPlugin("test_plugin", "test_type")

    config_data.update_setting(setting1, plugin)
    config_data.update_setting(setting2)

    assert config_data.get_setting("test_setting_include", plugin) == setting1
    assert config_data.get_setting("test_setting_include") is None

# Generated at 2022-06-22 19:23:07.200541
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    setting1 = Setting('a')
    setting2 = Setting('b')
    setting3 = Setting('c')
    setting4 = Setting('d')
    setting5 = Setting('e')
    config_data = ConfigData()
    config_data.update_setting(setting1)
    config_data.update_setting(setting2, Plugin('C', 'a'))
    config_data.update_setting(setting3, Plugin('C', 'b'))
    config_data.update_setting(setting4, Plugin('D', 'a'))
    config_data.update_setting(setting5, Plugin('D', 'b'))
    assert config_data.get_setting('a') == setting1
    assert config_data.get_setting('b', Plugin('C', 'a')) == setting2
    assert config_data.get_

# Generated at 2022-06-22 19:23:15.136292
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # given
    plugin_name = "plugin_name"
    plugin_path = "plugin_path"
    plugin_type = "plugin_type"
    setting_name = "setting_name"
    values = [1, 2, 3]

    plugin = Plugin(plugin_name, plugin_path, plugin_type)
    setting = Setting(name=setting_name, values=values)
    data = ConfigData(plugin, setting)

    # when
    result = data.get_setting(setting_name)

    # then
    assert result == setting


# Generated at 2022-06-22 19:23:25.694365
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # Test 1: Empty initialization
    config = ConfigData()

    assert len(config._global_settings) == 0
    assert len(config._plugins) == 0

    # Test 2: Test get_setting() and get_settings() with empty initialization
    setting = config.get_setting('setting')
    assert setting is None

    settings = config.get_settings()
    assert len(settings) == 0

    # Test 3: Test get_setting() without setting for plugin
    plugin = Plugin('plugin', 'plugin_type')
    setting = config.get_setting('setting', plugin)
    assert setting is None

    settings = config.get_settings(plugin)
    assert len(settings) == 0

    # Test 4: Test get_setting() with setting for plugin
    config.update_setting(Setting('setting1', 'value1'), plugin)

   

# Generated at 2022-06-22 19:23:27.045673
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()


# Generated at 2022-06-22 19:23:35.579864
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cfg = ConfigData()
    plugin = Plugin('module', 'test')
    setting = Setting('test', 'test', 'test', 'test', 'test', 'test', ['test'], 'test')
    cfg.update_setting(setting, plugin)
    assert(setting == cfg._plugins['module']['test']['test'])
    assert(setting != cfg._plugins['module']['test']['test1'])
    assert(setting != cfg._plugins['module']['test1']['test'])
    assert(setting != cfg._plugins['module1']['test']['test'])



# Generated at 2022-06-22 19:23:37.202984
# Unit test for constructor of class ConfigData
def test_ConfigData():
        config = ConfigData()
        assert config



# Generated at 2022-06-22 19:23:47.507449
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    class Plugin(object):
        # pylint: disable=too-few-public-methods
        def __init__(self, type, name):
            self.type = type
            self.name = name
    class Setting(object):
        # pylint: disable=too-few-public-methods
        def __init__(self, name):
            self.name = name

    # without plugin
    setting = Setting("setting1")
    config_data.update_setting(setting)
    assert config_data.get_setting("setting1") == setting

    # with plugin
    plugin = Plugin("connection", "plugin1")
    setting = Setting("setting2")
    config_data.update_setting(setting, plugin=plugin)

# Generated at 2022-06-22 19:23:55.654608
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class TestType(object):
        pass
    class TestPlugin(object):
        pass

    config_data = ConfigData()

    # Test with plugin
    test_plugin = TestPlugin()
    test_plugin.type = 'mytype'
    test_plugin.name = 'myname'

    test_setting = TestType()
    test_setting.name = 'myname'
    config_data.update_setting(test_setting, test_plugin)

    setting = config_data.get_setting('myname', test_plugin)
    assert setting == test_setting

    setting = config_data.get_setting('myname')
    assert setting is None


# Generated at 2022-06-22 19:23:56.929185
# Unit test for constructor of class ConfigData
def test_ConfigData():
    obj = ConfigData()
    assert isinstance(obj, ConfigData)


# Generated at 2022-06-22 19:24:03.155039
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    s = Setting("source", "test")
    c.update_setting(s)
    assert c.get_setting("source").value == "test"
    s = Setting("source", "test2")
    c.update_setting(s, Plugin('cache', 'redis'))
    assert c.get_setting("source").value == "test"
    assert c.get_setting("source", Plugin('cache', 'redis')).value == "test2"
    assert not c.get_setting("source", Plugin('inventory', 'redis'))



# Generated at 2022-06-22 19:24:15.174787
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {
        'name': 'stdout_callback',
        'category': 'default',
        'default': 'default',
        'env': ['ANSIBLE_STDOUT_CALLBACK'],
        'ini': [
        {'section': 'defaults', 'key': 'stdout_callback'}],
        'version_added': '1.5',
        'vars': [],
        'type': 'string',
        'description': 'Output format',
        'choices': ['debug', 'default', 'oneline', 'json', 'yaml', 'minimal', 'free', 'custom', 'tree']
    }
    config_data.update_setting(setting)
    assert config_data.get_setting(name='stdout_callback') == setting

    # Test with plugin
   

# Generated at 2022-06-22 19:24:24.579026
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible_collections.ansible.community.plugins.module_utils.common._collection_finder import _PluginLoader

    config_data = ConfigData()
    config_data.update_setting(Setting('allow_duplicates', 'true'))
    config_data.update_setting(Setting('allow_hidden', 'false'))

    plugin_loader = _PluginLoader()
    plugin_collection = plugin_loader.create_collection('ansible.posix', 'system')
    plugin_loader.load_collections([plugin_collection])
    module = plugin_collection.plugins.get('cat')
    config_data.update_setting(Setting('allow_duplicates', 'false', plugin_collection, module))
    config_data.update_setting(Setting('allow_hidden', 'true', plugin_collection, module))

# Generated at 2022-06-22 19:24:33.083227
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    from ansible.config.setting import Setting
    setting = Setting('setting_name',
                      'my_setting',
                      ['foo1', 'foo2'],
                      'The value for the setting',
                      'type=string',
                      'A string setting')
    config_data.update_setting(setting)
    assert(len(config_data.get_settings()) == 1)
    assert(config_data.get_setting('setting_name') == setting)

    # test update_setting with plugin
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader.find_plugin('foo', 'bar')
    config_data.update_setting(Setting('baz', 'bax', [], '', '', ''), plugin)

# Generated at 2022-06-22 19:24:42.015975
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    configdata = ConfigData()
    assert(configdata.get_setting('ansible_managed') is None)

    from collections import namedtuple
    from ansible.config.data import ConfigSetting
    Plug = namedtuple('Plug', ['type', 'name'])
    configdata.update_setting(ConfigSetting('ansible_managed', 'value', Plug('type', 'name')))

    from ansible.config.data import ConfigSetting
    assert(configdata.get_setting('ansible_managed') == ConfigSetting('ansible_managed', 'value', Plug('type', 'name')))


# Generated at 2022-06-22 19:24:54.715096
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()

    # Put all the configuration information in this file
    configData.update_setting(Setting(name='config_file', value='/etc/ansible/ansible.cfg'))

    # Put all the plugins in this directory
    configData.update_setting(Setting(name='plugin_dir', value='/usr/share/ansible/plugins'))

    # Make sure the ansible version is at least 2.4
    configData.update_setting(Setting(name='version', value='2.4', plugin=Plugin(type='module', name='version')))

    # If a user has a lot of plugins, the ansible CLI can take a long time
    # to load.  This configuration option allows a user to disable loading
    # all plugins by default.

# Generated at 2022-06-22 19:24:56.306465
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    ws = ConfigData()
    assert ws.get_settings() == []


# Generated at 2022-06-22 19:25:05.627184
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting_1)
    config_data_1.update_setting(Setting_2)
    assert config_data_1.get_settings() == [Setting_1, Setting_2]
    config_data_1.update_setting(Setting_3, Plugin_1)
    assert config_data_1.get_settings() == [Setting_1, Setting_2]
    assert config_data_1.get_settings(Plugin_1) == [Setting_3]
    config_data_1.update_setting(Setting_4, Plugin_1)
    config_data_1.update_setting(Setting_5, Plugin_2)
    assert config_data_1.get_settings(Plugin_1) == [Setting_3, Setting_4]


# Generated at 2022-06-22 19:25:14.100020
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from collections import namedtuple

    ConfigSetting = namedtuple("Setting", "name value")

    config_data = ConfigData()

    setting = ConfigSetting("foo", "bar")

    plugin = namedtuple("Plugin", "name type")
    p = plugin("myplugin", "mytype")

    config_data.update_setting(setting)
    assert config_data.get_setting("foo") == setting
    assert config_data.get_setting("foo", p) == setting

    setting2 = ConfigSetting("foo2", "bar2")
    config_data.update_setting(setting2, p)
    assert config_data.get_setting("foo") == setting
    assert config_data.get_setting("foo2", p) == setting2


# Generated at 2022-06-22 19:25:18.107308
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    global_setting = config_data.get_setting('max_module_retries')
    assert global_setting is not None

    plugin_setting = config_data.get_setting('connection', plugin=ConfigPlugin('connection', 'local'))
    assert plugin_setting is not None

# Generated at 2022-06-22 19:25:26.880205
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(Setting("foo", "bar"))
    config.update_setting(Setting("foo1", "bar", plugin="baz"))
    config.update_setting(Setting("foo1", "bar1", plugin="foo"))
    assert config.get_setting("foo").value == "bar"
    assert config.get_setting("foo1", plugin="foo").value == "bar1"
    assert config.get_setting("foo1", plugin="baz").value == "bar"

# Generated at 2022-06-22 19:25:29.015447
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    cd = ConfigData()
    assert len(cd.get_settings()) == 0
    assert cd.get_settings() == []



# Generated at 2022-06-22 19:25:31.080157
# Unit test for constructor of class ConfigData
def test_ConfigData():
    test_conf = ConfigData()
    assert test_conf._global_settings == {}
    assert test_conf._plugins  == {}


# Generated at 2022-06-22 19:25:41.950835
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    assert config_data.get_setting('test_name', 'test_plugin_type') == None
    assert config_data.get_setting('test_name') == None

    setting1 = Setting('test_name1')
    setting2 = Setting('test_name2')

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)

    setting3 = Plugin('test_plugin_type')
    setting3.update_setting(setting2)

    config_data.update_setting(setting2, setting3)

    assert config_data.get_setting('test_name1') == setting1
    assert config_data.get_setting('test_name2', setting3) == setting2
    assert config_data.get_setting('test_name2') == setting

# Generated at 2022-06-22 19:25:50.576412
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    config._global_settings = {'one': 1, 'two': 2}
    config._plugins = {'action': {'action_first': {'three': 3, 'four': 4}}}

    settings = config.get_settings()
    assert len(settings) == 2
    assert {s.name: s.value for s in settings} == {'one': 1, 'two': 2}

    settings = config.get_settings(Plugin('action', 'action_first'))
    assert len(settings) == 2
    assert {s.name: s.value for s in settings} == {'three': 3, 'four': 4}

    settings = config.get_settings(Plugin('none', 'none_name'))
    assert len(settings) == 0

# A unit test for method get_setting of class Config

# Generated at 2022-06-22 19:26:00.632946
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cfg = ConfigData()
    cfg._global_settings = {
        "a": 1,
        "b": 2,
        "c": 3
    }
    cfg._plugins = {
        "t1": {
            "p1": {
                "d": 4,
                "e": 5,
                "f": 6
            },
            "p2": {
                "g": 7,
                "h": 8,
                "i": 9
            }
        },
        "t2": {
            "p3": {
                "j": 10,
                "k": 11,
                "l": 12
            },
            "p4": {
                "m": 13,
                "n": 14,
                "o": 15
            }
        }
    }

    # Test 1: All global

# Generated at 2022-06-22 19:26:02.052879
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert (config != None)


# Generated at 2022-06-22 19:26:08.063111
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    # Test a global setting
    s = Setting('verbosity', '0', '', 'public')
    config.update_setting(s)
    assert config.get_setting('verbosity') == s
    # Test a callback setting
    s2 = Setting('verbosity', '1', '', 'public')
    config.update_setting(s2, Plugin('callback', 'default'))
    assert config.get_setting('verbosity', Plugin('callback', 'default')) == s2


# Generated at 2022-06-22 19:26:18.464341
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class Plugin(object):
        def __init__(self, type, name, path):
            self.type = type
            self.name = name
            self.path = path

    from ansible.plugins import PluginLoader

    testobj = ConfigData()
    testobj._global_settings = {'const': 'zero'}
    testobj._plugins = {'lookup': {}}

    # test with empty plugin
    assert testobj.get_settings(plugin=Plugin('lookup', '@test1', '')) == []

    # test with existing plugin
    testobj._plugins['lookup']['@test1'] = {'one': 1, 'two': 2}
    assert testobj.get_settings(plugin=Plugin('lookup', '@test1', '')) == [{'one': 1}, {'two': 2}]


# Generated at 2022-06-22 19:26:21.680991
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-22 19:26:29.163535
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    c = ConfigData()
    c.update_setting(setting)
    settings = c.get_settings()
    assert settings[0].name == 'setting1'
    assert settings[0].value == 'value1'

    c.update_setting(setting2, plugin2)
    settings = c.get_settings()
    settings_plugin = c.get_settings(plugin2)
    assert settings[0].name == 'setting1'
    assert settings[0].value == 'value1'
    assert settings_plugin[0].name == 'setting2'
    assert settings_plugin[0].value == 'value2'

    setting3 = Setting('setting3', 'value3')
    c.update_setting(setting3)
    settings = c.get_settings()
    settings_plugin = c.get_settings(plugin2)
   

# Generated at 2022-06-22 19:26:30.911413
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('test') is None

# Generated at 2022-06-22 19:26:38.679328
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test for globals
    global_ini = """
[defaults]
host_key_checking = False
host_key_warning = False
"""
    config = ConfigData()
    ConfigData.update_setting(config, group='defaults', key='host_key_checking', value='False')
    ConfigData.update_setting(config, group='defaults', key='host_key_warning', value='False')
    assert len(config.get_settings()) == 2
    o = config.get_settings()[0]
    assert o.name == 'host_key_warning'
    assert o.value is True
    o = config.get_settings()[1]
    assert o.name == 'host_key_checking'
    assert o.value is False

    # Test for a plugin

# Generated at 2022-06-22 19:26:47.016687
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Test reading global setting
    setting = Setting("example_setting")
    config_data.update_setting(setting)
    assert config_data.get_setting("example_setting") == setting

    # Test reading non-existant global setting
    assert not config_data.get_setting("fake_setting")

    # Test reading non-existant plugin setting with no plugin type
    assert not config_data.get_setting("fake_setting", Plugin("fake_plugin"))

    # Test reading non-existant plugin setting with no plugin type
    plugin = Plugin(type="fake_plugin_type", name="fake_plugin")
    assert not config_data.get_setting("fake_setting", plugin)



# Generated at 2022-06-22 19:26:49.335519
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(None)
    assert config_data


# Generated at 2022-06-22 19:26:56.289292
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblite.plugins.loader import PluginLoader
    from ansiblite.plugins.action import ActionBase
    from ansiblite.plugins.connection import ConnectionBase
    from ansiblite.plugins.lookup import LookupBase
    from ansiblite.plugins.filter import FilterModule
    from ansiblite.plugins.callback import CallbackBase
    from ansiblite.plugins.shell import ShellModule

    import unittest
    import mock

    # Create a test class that derives from the base plugin class
    class TestPlugin(ActionBase):
        pass

    # Create a test class that derives from the base plugin class
    class TestPlugin2(ActionBase):
        pass

    # Mock the get_all method of the plugin loader to return our test classes

# Generated at 2022-06-22 19:27:07.069118
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from collections import namedtuple

    ConfigSetting = namedtuple("ConfigSetting", "name value")
    Plugin = namedtuple("Plugin", "type name")

    config_data = ConfigData()
    assert(config_data.get_settings() == [])
    assert(config_data.get_settings(Plugin("foo", "bar")) == [])

    config_data.update_setting(ConfigSetting("answer", 42))
    settings = config_data.get_settings()
    assert(len(settings) == 1)
    assert(settings[0].name == "answer")
    assert(settings[0].value == 42)

    config_data.update_setting(ConfigSetting("question", "What is the ultimate question?"))
    settings = config_data.get_settings()
    assert(len(settings) == 2)

# Generated at 2022-06-22 19:27:13.297518
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting1 = ConfigSetting(name='TestSetting1', description='Test description for TestSetting1', value='TestValue1',
                             sample='example: TestValue1', section=('test', 'testing', 'tested'),
                             env_var='TEST_SETTING1', ini_file_var='ini_test_setting1',
                             ini_section=('ini_test', 'ini_testing', 'ini_tested'),
                             env_override=True, ini_file_override=True)

    # Test setting with no plugin
    config_data.update_setting(setting1)
    assert config_data.get_setting('TestSetting1') == setting1
    assert config_data.get_setting('TestSetting1', None) == setting1
    assert config_data.get_setting

# Generated at 2022-06-22 19:27:15.150147
# Unit test for constructor of class ConfigData
def test_ConfigData():
    
    config_data = ConfigData()

    assert isinstance(config_data, ConfigData)


# Generated at 2022-06-22 19:27:24.405401
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.connection import Connection
    plugin = get_plugin_class('connection', 'local')()
    plugin.name = 'local'

    assert config_data.get_setting('host_key_auto_add') is None


# Generated at 2022-06-22 19:27:29.720192
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(Setting('federation_directory', 'plugins/', 'Configuration file setting'))
    assert config._global_settings['federation_directory']
    assert config._global_settings['federation_directory'].name == 'federation_directory'
    assert config._global_settings['federation_directory'].value == 'plugins/'


# Generated at 2022-06-22 19:27:36.582940
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    global_setting = Setting('global_setting', 'global_value')
    plugin_type = 'plugin_type'
    plugin_name = 'plugin_name'
    plugin_setting = Setting('plugin_setting', 'plugin_value')
    plugin = Plugin(name=plugin_name, type=plugin_type)
    config = ConfigData()
    config.update_setting(global_setting)
    config.update_setting(plugin_setting, plugin)
    assert config.get_setting('global_setting') == global_setting, '''Failed to get global setting'''
    assert config.get_setting('plugin_setting', plugin) == plugin_setting, '''Failed to get plugin setting'''
    assert config.get_setting('global_setting', plugin) is None, '''Should not get setting for non-global plugin'''
    assert config

# Generated at 2022-06-22 19:27:44.306549
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    setting = Setting('core', None, 'ansible_managed', 'Ansible managed')
    config_data.update_setting(setting)
    assert config_data.get_setting('ansible_managed') == setting

    setting = Setting('callback', 'mail', 'mail_sender', 'sender@domain.com')
    config_data.update_setting(setting)
    assert config_data.get_setting('mail_sender', Plugin('callback', 'mail')) == setting
    assert config_data.get_setting('mail_sender') is None

    print('Unit test ended successfully')


# Generated at 2022-06-22 19:27:53.411331
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = {'name': 'test_setting_name',
               'value': 'test_setting_value',
               'origin': 'test_setting_origin'}
    config_data.update_setting(setting, plugin=None)

    setting = {'name': 'test_setting_name_2',
               'value': 'test_setting_value_2',
               'origin': 'test_setting_origin_2'}
    plugin = {'name': 'test_plugin_name',
              'type': 'test_plugin_type'}
    config_data.update_setting(setting, plugin=plugin)

    assert config_data.get_setting('test_setting_name', plugin=None)['value'] == 'test_setting_value'

# Generated at 2022-06-22 19:27:57.634504
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    data.update_setting(ConfigSetting('test', 'list'))
    data.update_setting(ConfigSetting('test', 'list'))
    print(data.get_settings())
    assert(len(data.get_settings()) == 2)


# Generated at 2022-06-22 19:28:07.879331
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    host = Host('host1')

    setting1 = Setting('setting1')
    setting2 = Setting('setting2')
    setting3 = Setting('setting3')
    setting4 = Setting('setting4')

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting3, host)
    config_data.update_setting(setting4, host)

    settings = config_data.get_settings()
    assert settings == [setting1, setting2]

    settings = config_data.get_settings(host)
    assert settings == [setting3, setting4]


# Generated at 2022-06-22 19:28:14.627605
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data._global_settings = {
        "xyz": {
            "name": "xyz",
            "value": "abc"
        }
    }
    config_data._plugins = {
        "test1": {
            "foo": {
                "a": {
                    "name": "a",
                    "value": "b"
                }
            },
            "bar": {
                "c": {
                    "name": "c",
                    "value": "d"
                }
            }
        }
    }

    assert config_data.get_setting("xyz") == {
        "name": "xyz",
        "value": "abc"
    }


# Generated at 2022-06-22 19:28:17.032736
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    assert len(config.get_settings()) == 0
    assert len(config.get_settings("plugin")) == 0

# Generated at 2022-06-22 19:28:29.639237
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin1 = PluginDetail("test", "test", "test")
    plugin2 = PluginDetail("test", "test", "test")
    plugin3 = PluginDetail("test", "test", "test")
    setting1 = Setting("test1", "test1", "test1")
    setting2 = Setting("test2", "test2", "test2")
    setting3 = Setting("test3", "test3", "test3")
    setting4 = Setting("test4", "test4", "test4")
    setting5 = Setting("test5", "test5", "test5")
    setting6 = Setting("test6", "test6", "test6")
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)

# Generated at 2022-06-22 19:28:35.168234
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import pytest
    from ansible.config.setting import Setting

    config_data = ConfigData()
    config_data.update_setting(Setting('ansible_managed', 'string', 'default'))

    assert config_data.get_setting('ansible_managed') == Setting('ansible_managed', 'string', 'default')

# Generated at 2022-06-22 19:28:41.582344
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    assert config_data.get_setting('test') is None
    assert config_data.get_setting(plugin=Plugin(type='action', name='action_test')) is None

    config_data.update_setting(Setting('test_1', 'default', 1, 'test', "This is the test", 'string'))
    assert config_data.get_setting('test_1').name == 'test_1'
    assert config_data.get_setting('test_1').default == 'default'
    assert config_data.get_setting('test_1').config_level == 1
    assert config_data.get_setting('test_1').description == "This is the test"
    assert config_data.get_setting('test_1').type == 'string'

    config_data.update_setting

# Generated at 2022-06-22 19:28:47.072122
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    assert config._global_settings == {}
    config.update_setting(Setting(name='foo', value='bar'))
    assert config._global_settings == {'foo': Setting(name='foo', value='bar')}


# Generated at 2022-06-22 19:28:59.067964
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Make sure we can get global settings
    debug = ConfigData()
    assert not debug.get_settings()
    # Update setting
    debug.update_setting(Setting('logging_level', 'mentor'))
    # Test setting retrieval
    assert debug.get_setting('logging_level').name == 'logging_level'
    assert debug.get_setting('logging_level').value == 'mentor'
    assert debug.get_settings()[0].name == 'logging_level'
    assert debug.get_settings()[0].value == 'mentor'

    # Make sure we can get plugin settings
    debug = ConfigData()
    # Update setting

# Generated at 2022-06-22 19:29:06.997626
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    assert data.get_settings() == []
    data.update_setting(MockScript(name="example"))
    assert data.get_settings()[0].name == "example"
    data.update_setting(MockScript(name="another_example"))
    assert data.get_settings()[1].name == "another_example"
    assert len(data.get_settings()) == 2


# Generated at 2022-06-22 19:29:09.042483
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config is not None

# Generated at 2022-06-22 19:29:11.848698
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd._global_settings == {}
    assert cd._plugins == {}



# Generated at 2022-06-22 19:29:21.054337
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Tests for global settings
    assert config_data.get_settings() == []

    config_data.update_setting(PluginSetting('foo', 'bar'))
    assert config_data.get_settings() == [PluginSetting('foo', 'bar')]

    config_data.update_setting(PluginSetting('baz', 'qux'))
    assert config_data.get_settings() == [PluginSetting('foo', 'bar'), PluginSetting('baz', 'qux')]

    # Tests for plugins settings
    assert config_data.get_settings(PluginDefinition('fictif', 'fictif', 'fictif')) == []

    config_data.update_setting(PluginSetting('foo', 'bar'), PluginDefinition('fictif', 'fictif', 'fictif'))

# Generated at 2022-06-22 19:29:30.288495
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Given
    config_data = ConfigData()
    setting1 = Setting('server', '192.168.1.1', plugin=Plugin('database', 'mysql'))
    setting2 = Setting('port', '3306', plugin=Plugin('database', 'mysql'))
    setting3 = Setting('env', 'prod', plugin=Plugin('database', 'mysql'))
    setting4 = Setting('server', '192.168.1.2', plugin=Plugin('database', 'mongodb'))
    setting5 = Setting('port', '27018', plugin=Plugin('database', 'mongodb'))
    setting6 = Setting('env', 'prod', plugin=Plugin('database', 'mongodb'))
    setting7 = Setting('expiry_time', '60', plugin=None)


# Generated at 2022-06-22 19:29:33.457217
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    # TODO: test when plugins are defined

# Generated at 2022-06-22 19:29:41.008160
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from config.setting import ConfigSetting
    from config.plugin import Plugin
    from config.plugin_type import PluginType

    config_data = ConfigData()

    # test case: no settings
    assert len(config_data.get_settings()) == 0
    # test case: no settings for plugin
    assert len(config_data.get_settings(Plugin("test", PluginType.CALLBACK))) == 0

    # test case: one setting
    test_setting1 = ConfigSetting("test1", "str")
    test_setting1.value = "test"
    config_data.update_setting(test_setting1)

    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0].name == "test1"

    # test case: one setting for plugin
    test_plugin1 = Plugin

# Generated at 2022-06-22 19:29:45.574500
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin()
    plugin.type = "shell"
    plugin.name = "sh"
    config_data.update_setting(setting, plugin=plugin)
    config_data.get_setting('shell',plugin=plugin)
    

# Generated at 2022-06-22 19:29:51.862880
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin = Plugin(type='lookup', name='password')
    setting = Setting(name='bar', value='barvalue', plugin=plugin, origin='test')
    config_data = ConfigData()
    config_data.update_setting(setting)
    assert config_data._plugins['lookup']['password']['bar'].name == 'bar'
    assert config_data._plugins['lookup']['password']['bar'].value == 'barvalue'



# Generated at 2022-06-22 19:30:02.016063
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    obj = ConfigData()

    # Test global settings
    assert obj.get_setting('string_setting') == None
    assert obj.get_setting('list_setting') == None
    assert obj.get_setting('dict_setting') == None

    obj.update_setting(Setting('name', 'string_setting', 'string'))
    assert obj.get_setting('string_setting').name == 'string_setting'
    assert obj.get_setting('string_setting').value == 'string'
    assert obj.get_setting('string_setting').type == 'string'

    obj.update_setting(Setting('name', 'list_setting', 'string', 'list'))
    assert obj.get_setting('list_setting').name == 'list_setting'
    assert obj.get_setting('list_setting').value == 'string'

# Generated at 2022-06-22 19:30:10.385341
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    plugin = Plugin('connection', 'local')
    plugin.path = 'lib/ansible/plugins/connection/local'

    config_data.update_setting(Setting('executable', 'python3', 'COMMAND', plugin))
    config_data.update_setting(Setting('executable', 'python', 'COMMAND', plugin))

    setting = config_data.get_setting('host')

    assert setting is None
    assert config_data.get_setting('executable', plugin).value == 'python'
