

# Generated at 2022-06-22 19:20:14.391259
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    # Unit test 1
    plugin_type = 'module'
    plugin_name = 'ping'
    setting_name = 'test1'
    setting_value = 'test_value1'
    import ansible.constants as C
    update_setting(setting_name, setting_value, plugin_name, plugin_type)

    # Unit test 2
    setting_name = 'test2'
    setting_value = 'test_value2'
    update_setting(setting_name, setting_value, plugin_name, plugin_type)



# Generated at 2022-06-22 19:20:21.198729
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    #   ConfigData
    #   |
    #   \_Updates a setting in the config data object
    #
    #     Case 1: Update a global setting
    #       Input:  setting  -- GlobalSetting object
    #       Output: None
    #
    #     Case 2: Update a plugin setting
    #       Input:  setting  -- PluginSetting object
    #       Output: None
    #
    # Note:  plugin is a Plugin object
    #
    # 
    # 

    pass



# Generated at 2022-06-22 19:20:24.988193
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('to_mails', 'anadmin@example.com', 'global'))
    assert config_data._global_settings == {'to_mails': Setting('to_mails', 'anadmin@example.com', 'global')}

# Generated at 2022-06-22 19:20:29.568238
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    settings = ConfigData()
    settings.update_setting(setting)
    assert settings._global_settings == {setting.name:setting}
    settings.update_setting(setting, plugin)
    assert settings._plugins == {plugin.type:{plugin.name:{setting.name:setting}}}


# Generated at 2022-06-22 19:20:39.647284
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert config_data.get_settings() == []

    setting_one_global = config_data.get_setting('name_one')
    config_data.update_setting(setting_one_global)
    setting_two_global = config_data.get_setting('name_two')
    config_data.update_setting(setting_two_global)
    assert config_data.get_settings() == [setting_one_global, setting_two_global]

    plugin = "plugin"
    plugin_name = "plugin_name"
    plugin_setting = config_data.get_setting('name_three', plugin)
    config_data.update_setting(plugin_setting, plugin)
    plugin_setting = config_data.get_setting('name_four', plugin)
    config_data.update

# Generated at 2022-06-22 19:20:41.623253
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting1 = 'setting1'
    plugin1 = 'plugin1'
    config_data.update_setting(setting1, plugin1)

# Generated at 2022-06-22 19:20:43.701305
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()
    assert len(config._global_settings) == 0
    assert len(config._plugins) == 0
    config.get_setting('test')
    config.get_settings()



# Generated at 2022-06-22 19:20:46.235913
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    setting = ConfigData().get_setting('something')
    assert setting is None


# Generated at 2022-06-22 19:20:51.468872
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()
    assert len(config.get_settings()) == 0

    config.update_setting(ConfigSetting('confirm_overwrite', 'false', 'BOOLEAN'))
    config.update_setting(ConfigSetting('default_inventory_enabled', 'false', 'BOOLEAN'))
    assert len(config.get_settings()) == 2


# Generated at 2022-06-22 19:20:58.642281
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='lookup_plugins', value='/default/lookup_plugins', priority=100)
    config_data.update_setting(setting)

    assert config_data._global_settings['lookup_plugins'].value == './lookup_plugins'
    assert config_data.get_setting('lookup_plugins').value == './lookup_plugins'



# Generated at 2022-06-22 19:21:01.934983
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    CONFIG_DATA = ConfigData()
    CONFIG_DATA.update_setting("ConfigData")
    CONFIG_DATA.update_setting("ConfigData1", "ConfigPlugin")
    settings = CONFIG_DATA.get_settings("ConfigPlugin")
    assert len(settings) == 1

# Generated at 2022-06-22 19:21:07.858802
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()

    # Check expected empty
    assert len(config.get_settings()) == 0
    assert len(config.get_settings(plugin)) == 0

    # Add global setting
    config.update_setting(Setting('name', 'value'))
    assert len(config.get_settings()) == 1
    assert len(config.get_settings(plugin)) == 0

    # Add plugin setting
    config.update_setting(Setting('name', 'value'), plugin)
    assert len(config.get_settings()) == 1
    assert len(config.get_settings(plugin)) == 1


# Generated at 2022-06-22 19:21:14.292011
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    test_global_setting_1 = test_Setting_default_constructor()
    config_data.update_setting(test_global_setting_1)
    test_plugin_1 = test_Plugin_default_constructor()
    test_plugin_setting_1 = test_Setting_default_constructor()
    config_data.update_setting(test_plugin_setting_1, test_plugin_1)
    assert config_data.get_setting(test_global_setting_1.name) == test_global_setting_1
    assert config_data.get_setting(test_plugin_setting_1.name, test_plugin_1) == test_plugin_setting_1


# Generated at 2022-06-22 19:21:17.076236
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting('test', 'p')
    assert config.get_setting('test') is not None



# Generated at 2022-06-22 19:21:19.721709
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert isinstance(config_data, ConfigData)


# Generated at 2022-06-22 19:21:30.784062
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd.get_setting("strict") is None
    assert cd.get_settings() == []

    cd.update_setting(ConfigSetting(name="strict", value=True, origin="default"))
    assert cd.get_setting("strict") is not None
    assert cd.get_setting("strict").value is True

    assert cd.get_settings() != []

    cd.update_setting(ConfigSetting(name="strict", value=False, origin="default", plugin=Plugin('test', 'action')))
    assert cd.get_setting("strict") is not None
    assert cd.get_setting("strict").value is True
    assert cd.get_setting("strict", Plugin('test', 'action')).value is False


# Generated at 2022-06-22 19:21:40.010623
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import unittest

    class ConfigData_get_settings(unittest.TestCase):

        def setUp(self):

            self.config_data = ConfigData()

        def test_get_settings_without_plugin(self):

            # Add global setting
            self.config_data.update_setting(Setting(name='foo', value='bar'))

            # Get global settings
            settings = self.config_data.get_settings()

            self.assertEqual(len(settings), 1)
            self.assertEqual(settings[0].name, 'foo')
            self.assertEqual(settings[0].value, 'bar')

        def test_get_settings_with_plugin(self):

            # Create plugin
            plugin = Plugin(
                type='module',
                name='foo',
            )

            # Add global

# Generated at 2022-06-22 19:21:44.362372
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data._global_settings == {}

    assert config_data._plugins == {}

    assert config_data.get_setting("foo") is None

    assert config_data.get_settings() == []



# Generated at 2022-06-22 19:21:46.042010
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

# Generated at 2022-06-22 19:21:48.807020
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    new_config_data = ConfigData()
    config_data = ConfigData()

# Generated at 2022-06-22 19:21:58.460498
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    data.update_setting(DataSetting('Test1', 'Test value 1', 'string', 'This is a test string', 'You need to set this to something useful'))
    data.update_setting(DataSetting('Test2', 'Test value 2', 'string', 'This is a test string', 'You need to set this to something useful'), DataPlugin('action', 'testplugin'))

    assert data.get_setting('Test1') is not None
    assert data.get_setting('Test1').name == 'Test1'
    assert data.get_setting('Test1', DataPlugin('action', 'testplugin')) is not None
    assert data.get_setting('Test1', DataPlugin('action', 'testplugin')).name == 'Test1'

    assert data.get_setting('Test2') is None
    assert data

# Generated at 2022-06-22 19:21:59.179503
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    pass

# Generated at 2022-06-22 19:22:10.666732
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    assert config_data.get_setting('a') is None
    assert config_data.get_setting('a', dict(type='b', name='c')) is None

    setting = dict(name='a', value='d')
    config_data.update_setting(setting)

    assert config_data.get_setting('a') == setting
    assert config_data.get_setting('a', dict(type='b', name='c')) is None

    setting = dict(name='a', value='d')
    config_data.update_setting(setting, dict(type='b', name='c'))

    assert config_data.get_setting('a') == setting
    assert config_data.get_setting('a', dict(type='b', name='c')) == setting

# Generated at 2022-06-22 19:22:21.636080
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

    config_data.update_setting(Setting("key", "value", None))
    assert config_data.get_settings() == [Setting("key", "value", None)]

    config_data = ConfigData()
    config_data.update_setting(Setting("key", "value", PluginReference("type", "name")))
    assert config_data.get_settings() == []
    assert config_data.get_settings(PluginReference("type", "name")) == [Setting("key", "value", PluginReference("type", "name"))]
    assert config_data.get_settings(PluginReference("type2", "name")) == []
    assert config_data.get_settings(PluginReference("type", "name2")) == []

    config_data.update_

# Generated at 2022-06-22 19:22:32.168818
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data._global_settings = {
        'ANSIBLE_STDOUT_CALLBACK': {'name': 'ANSIBLE_STDOUT_CALLBACK', 'value': 'default', 'scope': 'global'},
        'ANSIBLE_CALLBACK_WHITELIST': {'name': 'ANSIBLE_CALLBACK_WHITELIST', 'value': 'default', 'scope': 'global'}
    }
    config_data._plugins = {
        'callback': {
            'debug': {
                'short': {'name': 'short', 'value': False, 'scope': 'playbook'}
            },
            'minimal': {
                'threshold': {'name': 'threshold', 'value': 2, 'scope': 'task'}
            }
        }
    }
   

# Generated at 2022-06-22 19:22:34.349754
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert isinstance(config_data, ConfigData)

# Generated at 2022-06-22 19:22:41.716748
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    configdata = ConfigData()
    assert len(configdata.get_settings()) == 0

    setting = ConfigSetting('foo', 'global', 'string')
    setting.value = 'foo'
    configdata.update_setting(setting)

    assert len(configdata.get_settings()) == 1

    setting = ConfigSetting('bar', 'global', 'string')
    setting.value = 'bar'
    configdata.update_setting(setting)

    assert len(configdata.get_settings()) == 2



# Generated at 2022-06-22 19:22:51.570964
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class ConfigSetting(object):

        def __init__(self, name, values, plugin=None):
            self.name = name
            self.values = values
            self.plugin = plugin

    class ConfigPlugin(object):

        def __init__(self, name, type_):
            self.name = name
            self.type = type_

    config_data = ConfigData()

    setting1 = ConfigSetting(name="setting1", values=["val1", "val2"])
    setting2 = ConfigSetting(name="setting2", values=["val1", "val2"], plugin=ConfigPlugin(name="plugin2", type_="type2"))
    setting3 = ConfigSetting(name="setting3", values=["val1", "val2"], plugin=ConfigPlugin(name="plugin3", type_="type3"))

# Generated at 2022-06-22 19:22:52.994779
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    assert configData is not None

# Generated at 2022-06-22 19:22:59.350944
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from config_data import ConfigData
    from config_setting import ConfigSetting
    from config_plugin import ConfigPlugin
    config_data = ConfigData()
    setting1 = ConfigSetting('foo', 'bar')
    config_data.update_setting(setting1)
    setting2 = ConfigSetting('bar', 'foo')
    config_plugin = ConfigPlugin('action', 'module')
    config_data.update_setting(setting2, config_plugin)

test_ConfigData_update_setting()



# Generated at 2022-06-22 19:23:07.387315
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_obj = ConfigData()
    setting1_obj = ConfigData()
    setting1_obj.name = 'setting1'
    setting2_obj = ConfigData()
    setting2_obj.name = 'setting2'
    plugin1_obj = ConfigData()
    plugin1_obj.type = 'type1'
    plugin1_obj.name = 'name1'
    test_obj.update_setting(setting1_obj)
    test_obj.update_setting(setting2_obj)
    test_obj.update_setting(setting1_obj, plugin1_obj)
    test_obj.update_setting(setting2_obj, plugin1_obj)

    assert len(test_obj.get_settings(plugin1_obj)) == 2

# Generated at 2022-06-22 19:23:10.165926
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cfg = ConfigData()

    assert cfg._global_settings == {}
    assert cfg._plugins == {}

# Generated at 2022-06-22 19:23:12.059848
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}


# Generated at 2022-06-22 19:23:20.392741
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings = [
        {'name': 'hosts', 'value': 'localhost'},
        {'name': 'strategy', 'value': 'free'},
        {'name': 'gather_timeout', 'value': '10'},
        {'name': 'gather_facts', 'value': 'no'},
    ]

    config_data = ConfigData()
    for setting in settings:
        config_data.update_setting(Setting(setting['name'], setting['value']))
    assert len(config_data.get_settings()) == 4

    for setting in settings:
        setting = config_data.get_setting(setting['name'])
        assert setting is not None
        assert setting.name == setting['name']
        assert setting.value == setting['value']


# Generated at 2022-06-22 19:23:24.334666
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # This test checks for the proper instantiation of the class
    config_data = ConfigData()

    assert config_data is not None
    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-22 19:23:30.261315
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    class TestPlugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    cd = ConfigData()

    cd.update_setting(Setting('global_setting1', 'global_setting1_value'))
    cd.update_setting(Setting('global_setting2', 'global_setting2_value'))

    tp = TestPlugin('collection', 'collection1')
    cd.update_setting(Setting('collection_plugin_setting1', 'collection_plugin_value1', tp))
    cd.update_setting(Setting('collection_plugin_setting2', 'collection_plugin_value2', tp))

    gs = cd.get_settings()
    assert len(gs) == 2
    assert gs[0].name == 'global_setting1'
    assert g

# Generated at 2022-06-22 19:23:42.159451
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.plugins.loader import PluginLoader
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import mock

    config_data = ConfigData()
    config_data.update_setting(Setting('callback_whitelist', 'default', 'debug'))
    config_data.update_setting(Setting('filter_plugins', 'plugins/filter/'))
    config_data.update_setting(Setting('strategy', 'linear'))
    config_data.update_setting(Setting('vault_password_file', 'plugins/vars/vault/vault_password.txt'))

# Generated at 2022-06-22 19:23:52.129758
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    #create a setting
    from ansible.config import setting_proxy
    from ansible.config.setting_proxy import BasicSetting
    setting = BasicSetting("test_setting", "/path/to/source", "test")

    #
    config_data.update_setting(setting)

    #settings should be retrievable
    assert config_data.get_setting("test_setting") == setting

    #invalid setting
    assert config_data.get_setting("invalid_setting") is None


# Generated at 2022-06-22 19:24:04.445315
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting("host_key_checking", "True"))
    config_data.update_setting(Setting("timeout", "30"))
    config_data.update_setting(Setting("retries", "3"))

    #
    # Testing get_setting None plugin
    #
    assert config_data.get_setting("timeout", None) == "30"
    assert config_data.get_setting("retries", None) == "3"
    assert config_data.get_setting("host_key_checking", None) == "True"
    assert config_data.get_setting("random", None) is None
    assert config_data.get_setting("random", None) is None

    #
    # Testing get_setting with plugin
    #

# Generated at 2022-06-22 19:24:13.883342
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint.config import Setting
    from ansiblelint.plugins.rules import AnsibleLintRule

    class TestPlugin(AnsibleLintRule):
        id = 'TEST1'
        shortdesc = 'My Test Plugin'
        description = shortdesc

    my_data = ConfigData()
    test_setting = Setting(
        name='test_setting',
        plugin=TestPlugin(),
        default=True,
        type=bool,
        description='Test Setting'
    )
    my_data.update_setting(test_setting)

    assert test_setting in my_data.get_settings()
    assert test_setting in my_data.get_settings(test_setting.plugin)
    assert my_data.get_setting('test_setting') == test_setting

# Generated at 2022-06-22 19:24:17.698329
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()

    setting_1 = dict(
        name='setting_1',
        value='value_1',
        origin='origin_1',
        plugin=None
    )

    config.update_setting(setting_1)

    #global plugin
    assert config.get_setting(setting_1.name) == setting_1

    setting_2 = dict(
        name='setting_2',
        value='value_2',
        origin='origin_2',
        plugin='test_plugin',
        type='test_plugin_type'
    )

    config.update_setting(setting_2)

    #plugin
    assert config.get_setting(setting_2.name, setting_2.plugin) == setting_2


# Generated at 2022-06-22 19:24:22.256834
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    _plugin = ('type', 'name')
    _plugins = {'type': {'name': {'name': 'name', 'value': 'value'}}}
    assert data.get_settings(_plugin) == _plugins['type']['name'].values()


# Generated at 2022-06-22 19:24:25.288467
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert cd.get_setting('foo') is None
    cd.update_setting('foo', 'bar')
    assert cd.get_setting('foo') == 'bar'

# Generated at 2022-06-22 19:24:27.755015
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    assert config_data.get_settings(None) == []



# Generated at 2022-06-22 19:24:32.718228
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    plugin = Plugin("foo", "bar")
    configData.update_setting(Setting("foo","bar"), plugin)
    assert plugin.type in configData._plugins
    assert plugin.name in configData._plugins[plugin.type]
    assert "foo" in configData._plugins[plugin.type][plugin.name]
    assert configData._plugins[plugin.type][plugin.name]["foo"].value == "bar"


# Generated at 2022-06-22 19:24:43.030606
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test -1: test_ConfigData_get_setting - Incorrect plugin name
    # Assertion error should be raised
    try:
        config_data = ConfigData()
        config_data.update_setting('localhost')
        config_data.get_setting('localhost', plugin='localhost')
    except AssertionError:
        assert True
    else:
        assert False

    # Test -2: test_ConfigData_get_setting - Correct plugin name
    # No assertion error should be raised
    try:
        config_data = ConfigData()
        config_data.update_setting('localhost')
        config_data.get_setting('localhost', plugin='localhost')
    except AssertionError:
        assert False
    else:
        assert True


# Generated at 2022-06-22 19:24:54.891581
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Create a ConfigData object
    config_data = ConfigData()

    # Create a Setting object for a global setting
    setting_for_global_setting = Setting('setting_for_global_setting', 'string_value', 'var', 'var')
    config_data.update_setting(setting_for_global_setting, None)

    # Create a Setting object for a plugin setting
    setting_for_plugin_setting = Setting('setting_for_plugin_setting', 'string_value', 'now', 'lookup')
    config_data.update_setting(setting_for_plugin_setting, Plugin(name='lookup', type='now'))

    # Verify that the value returned by get_settings(None) is the same that the value in _global_settings

# Generated at 2022-06-22 19:24:58.655907
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)

# Unit tests for function get_setting of class ConfigData

# Generated at 2022-06-22 19:25:00.011533
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()


# Generated at 2022-06-22 19:25:01.988538
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd
    assert not cd._global_settings
    assert not cd._plugins


# Generated at 2022-06-22 19:25:05.300361
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data._global_settings == {}
    assert data._plugins == {}


# Generated at 2022-06-22 19:25:14.247948
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data._global_settings['my_global_setting'] = "my_global_setting_value"
    assert config_data.get_setting('my_global_setting') == "my_global_setting_value"
    config_data._plugins['my_plugin.type'] = {'my_plugin.name': {'my_plugin_setting': "my_plugin_setting_value"}}
    assert config_data.get_setting('my_plugin_setting', plugin={'type': 'my_plugin.type', 'name': 'my_plugin.name'}) == \
           "my_plugin_setting_value"
    assert config_data.get_setting('non_existing_setting') is None

# Generated at 2022-06-22 19:25:21.402241
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    data.update_setting(ConfigValue('ANSIBLE_CALLBACK_WHITELIST', 'kube', 'ansible.builtin'))
    data.update_setting(ConfigValue('ANSIBLE_STDOUT_CALLBACK', 'ok', 'ansible.builtin'))
    assert data.get_settings() == [
        ConfigValue('ANSIBLE_CALLBACK_WHITELIST', 'kube', 'ansible.builtin'),
        ConfigValue('ANSIBLE_STDOUT_CALLBACK', 'ok', 'ansible.builtin')
    ]


# Generated at 2022-06-22 19:25:32.810046
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Create a ConfigData object to test
    config_data = ConfigData()

    # Add a single global setting
    global_setting = ConfigSetting('myname', 'example', 'foo', 'this is an example comment')
    config_data.update_setting(global_setting)

    # Check that we can retrieve it using get_setting()
    assert config_data.get_setting('myname') == global_setting

    # Add a single setting for a plugin
    from ansible.plugins.loader import PluginLoader
    test_plugin = PluginLoader.get('cache', 'test_plugin')
    plugin_setting = ConfigSetting('another_name', 'bar', example='this is another example comment')
    config_data.update_setting(plugin_setting, plugin=test_plugin)

    # Check that we can retrieve it using get_setting()
    assert config

# Generated at 2022-06-22 19:25:44.171959
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """ Test ConfigData.update_setting method """

    plugin_name = 'my_plugin'
    plugin_type = 'module'

    from ansible.plugins.loader import get_plugin_class
    plugin = get_plugin_class(plugin_type, plugin_name)

    data = ConfigData()

    # Test updating a non-existing setting with default value
    setting = Setting('my_setting', 'default')
    data.update_setting(setting)
    assert 'my_setting' in data._global_settings
    assert data._global_settings['my_setting'] == setting

    # Test updating an existing setting with default value
    setting = Setting('my_setting', 'default')
    data.update_setting(setting)
    assert 'my_setting' in data._global_settings
    assert data._global_settings['my_setting'] == setting

# Generated at 2022-06-22 19:25:46.524755
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    data = ConfigData()
    data.update_setting(None)
    data.update_setting(None, None)
    data.update_setting(None, None, None)

# Generated at 2022-06-22 19:25:49.669823
# Unit test for constructor of class ConfigData
def test_ConfigData():
    test_object = ConfigData()
    assert(test_object._global_settings == {})
    assert(test_object._plugins == {})


# Generated at 2022-06-22 19:26:00.487476
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin1 = Plugin('local', 'group_vars', 'ansible/group_vars')
    plugin2 = Plugin('local', 'vars_plugins', 'ansible/vars_plugins')
    plugin3 = Plugin('local', 'action_plugins', 'ansible/action_plugins')
    plugin4 = Plugin('local', 'my_plugins', 'ansible/my_plugins')
    plugin5 = Plugin('local', 'my_plugins2', 'ansible/my_plugins2')
    plugin6 = Plugin('local', 'my_plugins3', 'ansible/my_plugins3')
    setting1 = Setting('some_setting', 'some_value')
    setting2 = Setting('some_setting2', 'some_value2')
    setting3 = Setting('some_setting3', 'some_value3')
    config_data = ConfigData

# Generated at 2022-06-22 19:26:07.412726
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    config_data.update_setting(Setting(name='test_setting_1', description='test description 1', default=1))
    config_data.update_setting(Setting(name='test_setting_2', description='test description 2', default=2))
    config_data.update_setting(Setting(name='test_setting_3', description='test description 3', default=3))

    settings = config_data.get_settings()

    assert len(settings) == 3



# Generated at 2022-06-22 19:26:18.195978
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {'a':1}
    config_data._plugins = {'a': 'a'}

    class testPlugin(object):
        name = 'b'
        type = 'c'

    test_plugin = testPlugin()

    assert config_data.get_settings() == [config_data._global_settings['a']]
    config_data._global_settings['b'] = 2
    assert config_data.get_settings() == [config_data._global_settings['a'], config_data._global_settings['b']]

    assert config_data.get_settings(test_plugin) == []
    config_data._plugins[test_plugin.type][test_plugin.name] = {'c':'c'}
    assert config_data.get_

# Generated at 2022-06-22 19:26:28.198899
# Unit test for constructor of class ConfigData
def test_ConfigData():

    from units.mock.loader import DictDataLoader
    from units.compat.mock import patch

    _loader = DictDataLoader({
        "all": {
            "vars": {
                "cfg_dir": "test/dir"
            }
        },
        "ungrouped": {},
        "test_group": {
            "vars": {
                "cfg_dir": "changed"
            }
        },
        "test_group:children": [
            "test_group"
        ]
    })

    def _get_data(*args, **kwargs):
        return _loader.load_from_file(*args, **kwargs)

    with patch('ansible.cli.setting_loader._get_data', new=_get_data):

        from ansible.cli.setting_loader import Setting

# Generated at 2022-06-22 19:26:29.683148
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cd = ConfigData()
    assert cd is not None


# Generated at 2022-06-22 19:26:31.373430
# Unit test for constructor of class ConfigData
def test_ConfigData():
    conf = ConfigData()
    assert conf._global_settings == {}
    assert conf._plugins == {}

# Generated at 2022-06-22 19:26:32.976612
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    conf = ConfigData()
    assert conf.get_setting('foo') is None


# Generated at 2022-06-22 19:26:38.216260
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansiblelint import Runner, RulesCollection
    from ansiblelint.runner import RulesCollectionBuilder
    from ansiblelint.rules.LineTooLongRule import LineTooLongRule

    test_rules = RulesCollectionBuilder(RulesCollection(), 'test')
    test_rules.register(LineTooLongRule())

    runner = Runner(None, test_rules, None, None, ConfigData(), None, None, None)

    assert runner._config_data.get_setting('max_line_length') == 80

    assert runner._config_data.get_settings() == []

# Generated at 2022-06-22 19:26:47.240919
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting(): 

    import unittest
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.errors import AnsibleParserError
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

    src_data = {'one': [
                        {'two': [
                                {'three': 10}
                                ]
                        }
                    ],
                'four': 40
                }

    def action(var_data, var_name='', set_name=''):

        setting = None

# Generated at 2022-06-22 19:26:56.867507
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class MockPlugin():
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class MockSetting():
        def __init__(self, name):
            self.name = name

    mock_global_setting = MockSetting("global")
    mock_plugin_type1_setting = MockSetting("plugin1")
    mock_plugin_type2_setting = MockSetting("plugin2")
    mock_plugin_type2_plugin1_setting = MockSetting("plugin2_plugin1")

    data = ConfigData()
    data.update_setting(mock_global_setting)
    data.update_setting(mock_plugin_type1_setting, MockPlugin("type1", "plugin1"))

# Generated at 2022-06-22 19:27:02.661076
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = Setting('setting_name', 'setting_value')
    config_data.update_setting(setting)

    settings = config_data.get_settings()
    assert settings[0].name == 'setting_name'
    assert settings[0].value == 'setting_value'



# Generated at 2022-06-22 19:27:10.838649
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict

    g_settings = dict(
        ansible_connection='local',
        ansible_python_interpreter='/usr/bin/python3',
        gather_timeout=10,
        remote_tmp='~/.ansible',
    )
    p_settings = dict(
        fork=10,
        no_log=True,
    )

    config_data = ConfigData()

    # Update global settings.
    for k, v in g_settings.items():
        config_data.update_setting(
            Setting(name=k, value=v)
        )

    # Update module settings.
    for k, v in p_settings.items():
        config_data.update_setting

# Generated at 2022-06-22 19:27:21.308958
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    data = ConfigData()
    # get_setting is a class methods. Hence, we need to mock class object so that we can call it's methods.
    data._global_settings = dict(foo='bar', bar='foo')
    mock_setting = {
        'name': 'foo',
        'plugin': None,
        'value': 'bar'
    }
    mock_setting2 = {
        'name': 'bar',
        'plugin': None,
        'value': 'foo'
    }
    # Call the method under test
    test_result = data.get_setting('foo')
    assert test_result == mock_setting
    test_result2 = data.get_setting('bar')
    assert test_result2 == mock_setting2

    # For plugins

# Generated at 2022-06-22 19:27:32.167675
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    s = Setting('test_global_setting')
    s2 = Setting('test_global_setting2')
    c.update_setting(s)
    c.update_setting(s2)
    plugin = Plugin()
    plugin.type = 'type'
    plugin.name = 'name'
    s = Setting('test_plugin_setting')
    c.update_setting(s, plugin)
    settings = c.get_settings()
    assert len(settings) == 2
    assert settings[0].name == 'test_global_setting'
    assert settings[1].name == 'test_global_setting2'
    settings = c.get_settings(plugin)
    assert len(settings) == 1
    assert settings[0].name == 'test_plugin_setting'


# Generated at 2022-06-22 19:27:36.266329
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert(config_data._global_settings == {})
    assert(config_data._plugins == {})


# Generated at 2022-06-22 19:27:37.754461
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert isinstance(data, ConfigData)

# Generated at 2022-06-22 19:27:48.406399
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    p1 = ConfigPlugin("p1", "type1")
    p2 = ConfigPlugin("p2", "type1")
    p3 = ConfigPlugin("p3", "type2")
    p1s1 = ConfigSetting("s1", "type1", "value1")
    p2s1 = ConfigSetting("s1", "type1", "value2")
    p3s1 = ConfigSetting("s1", "type1", "value3")
    p3s2 = ConfigSetting("s2", "type2", "value4")
    data.update_setting(p1s1, p1)
    data.update_setting(p2s1, p2)
    data.update_setting(p3s1, p3)
    data.update_setting(p3s2, p3)

# Generated at 2022-06-22 19:27:55.574307
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from collections import namedtuple
    from ansiblelint.rules.NoEncryptionInDockerfileRule import NoEncryptionInDockerfileRule
    plugin = namedtuple("Plugin", "name type")
    config_data = ConfigData()
    setting = NoEncryptionInDockerfileRule().get_setting()
    config_data.update_setting(setting, plugin=plugin("testplugin", "testtype"))
    settings = config_data.get_settings(plugin=plugin("testplugin", "testtype"))
    assert(len(settings) == 1)

# Generated at 2022-06-22 19:28:03.058803
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    global_settings = {"foo": "bar"}
    plugins = {"action" : {"copy": {"foo": "baz"}}}
    cfg = ConfigData()
    cfg._global_settings = global_settings
    cfg._plugins = plugins

    assert cfg.get_setting("foo").value == "bar"
    assert cfg.get_setting("foo", "action", "copy").value == "baz"
    assert cfg.get_setting("foo", "action").value == "bar"
    assert cfg.get_setting("foo", "notype", "copy").value == "bar"
    assert cfg.get_setting("foo", "action", "notname").value == "bar"
    assert cfg.get_setting("foo", "notype", "notname").value == "bar"
    assert cfg.get

# Generated at 2022-06-22 19:28:05.607326
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0



# Generated at 2022-06-22 19:28:07.202669
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    assert data.get_setting("ABSLOOT")==None


# Generated at 2022-06-22 19:28:14.314239
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Get an instance of the ConfigData class
    config_data = ConfigData()

    # Get the settings of the global config
    setting_list = config_data.get_settings()
    assert(len(setting_list) == 0)

    # Get the settings of a plugin
    plugin = Plugin(type_='action', name_='test_plugin')
    setting_list = config_data.get_settings(plugin)
    assert(len(setting_list) == 0)

    # Create and add two settings to a plugin
    setting0 = Setting(name_='test_setting0', value='0')
    setting1 = Setting(name_='test_setting1', value='1')
    config_data.update_setting(setting0, plugin)
    config_data.update_setting(setting1, plugin)

# Generated at 2022-06-22 19:28:14.938034
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    assert False

# Generated at 2022-06-22 19:28:25.219324
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from collections import namedtuple
    from ansible.utils import plugin_docs

    Plugin = namedtuple('Plugin', 'type name')

    config_data = ConfigData()

    # Test getting global settings
    config_data.update_setting(plugin_docs.Setting('plugin_list', None))
    config_data.update_setting(plugin_docs.Setting('verbose', True))

    assert all(s.name == 'plugin_list' or s.name == 'verbose' for s in
               config_data.get_settings())

    # Test getting plugin settings
    config_data.update_setting(plugin_docs.Setting('test', None),
                               Plugin(type='Test', name='Test Plugin'))

# Generated at 2022-06-22 19:28:31.683793
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    plugin1 = ConfigSettingPlugin('test', 'module', 'testmodule')
    setting1 = ConfigSetting('A', 'a', 'Aa')
    setting2 = ConfigSetting('B', 'b', 'Bb')

    cd.update_setting(setting1)
    cd.update_setting(setting2, plugin1)

    assert cd.get_setting('A') == setting1
    assert cd.get_setting('B') == None
    assert cd.get_setting('A', plugin1) == None
    assert cd.get_setting('B', plugin1) == setting2


# Generated at 2022-06-22 19:28:36.866333
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    conf = ConfigData()
    a = Setting("a", "b", "c")
    conf.update_setting(a)
    result1 = conf.get_settings()
    assert result1 == [a]
    b = Plugin("d", "e")
    result2 = conf.get_settings(b)
    assert result2 == []



# Generated at 2022-06-22 19:28:50.397061
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(None)
    assert(config_data.get_settings() == [None])
    config_data.update_setting(None)
    assert(config_data.get_settings() == [None, None])
    config_data.update_setting(None, plugin="test")
    assert(config_data.get_settings() == [None, None])
    assert([] == config_data.get_settings(plugin="test"))
    assert([] == config_data.get_settings(plugin="test1"))
    config_data.update_setting(None, plugin="test")
    assert(config_data.get_settings() == [None, None])
    assert(config_data.get_settings(plugin="test") == [None, None])

# Generated at 2022-06-22 19:28:58.978546
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    assert config_data.get_setting("SOME_KEY") is None
    assert config_data.get_setting("SOME_KEY", "SOME_VALUE") is None

    config_data.update_setting("SOME_KEY", "SOME_VALUE")

    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings("SOME_PLUGIN")) == 0

    config_data.update_setting("SOME_KEY", "SOME_VALUE")
    config_data.update_setting("SOME_KEY", "SOME_PLUGIN")

    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings("SOME_PLUGIN")) == 1

# Generated at 2022-06-22 19:29:09.958282
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    assert config_data.get_setting('foo') is None

    from ansible.plugins.loader import Setting
    setting = Setting('foo', 'bar')

    config_data.update_setting(setting)
    assert config_data.get_setting('foo') is not None
    assert config_data.get_setting('foo').value == 'bar'

    from ansible.plugins.loader import Plugin, PluginType
    plugin = Plugin(PluginType.CACHE, 'foo_plugin')

    setting = Setting('baz', 'qux')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('baz') is None
    assert config_data.get_setting('baz', plugin) is not None

# Generated at 2022-06-22 19:29:20.473751
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import PluginLoader

    for plugin_type in ('connection','shell','cache'):

        # Create a dummy connection plugin (will be the dumb one)
        setting = Setting()
        setting.name = 'dummy'
        setting.value = 'dumb'
        setting.scope = 'local'
        setting.origin = 'test'
        setting.plugin = Plugin(plugin_type, 'dummy')
        config_data.update_setting(setting)

        # Create a smart connection plugin with a different name and value than the dumb one
        setting = Setting()
        setting.name = 'smart'
        setting.value = 'smarter'
        setting.scope = 'local'

# Generated at 2022-06-22 19:29:25.302136
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    
    from ansiblelint.rules.UnusedVar import UnusedVarRule
    config_data = ConfigData()
    rule = UnusedVarRule()
    config_data.update_setting(rule.set_option(key='foo', value=1))
    setting = config_data.get_setting(plugin=rule, name='foo')
    assert setting.value == 1
    

# Generated at 2022-06-22 19:29:33.843627
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    setting1 = {'name': 'setting1', 'plugin_type': 'plugin_type1', 'plugin_name': 'plugin_name1', 'value': 'value1'}
    setting2 = {'name': 'setting2', 'plugin_type': 'plugin_type1', 'plugin_name': 'plugin_name1', 'value': 'value2'}
    settings = [setting1, setting2]

    for s in settings:
        config.update_setting(s, plugin=Plugin(s['plugin_type'], s['plugin_name']))

    settings_found = config.get_settings(plugin=Plugin(plugin_type='plugin_type1', plugin_name='plugin_name1'))

# Generated at 2022-06-22 19:29:37.703895
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'global', ''))
    config_data.update_setting(Setting('setting1', 'plugin', 'collection1.module1'))

    # retrieve global setting
    setting = config_data.get_setting('setting1')
    assert setting.type == 'global'

    # retrieve setting for collection1
    setting = config_data.get_setting('setting1', Plugin('collection', 'collection1'))
    assert setting is None
    setting = config_data.get_setting('setting1', Plugin('module', 'module1'))
    assert setting.plugin == 'collection1.module1'


# Generated at 2022-06-22 19:29:39.067379
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-22 19:29:40.780605
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()
    assert(configdata.get_settings() is not None)


# Generated at 2022-06-22 19:29:51.821340
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.plugins import MockPlugin
    from units.plugins.loader import PluginLoader

# Generated at 2022-06-22 19:30:01.970893
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    data.update_setting(setting=Setting("global", "global_setting_value"))
    data.update_setting(setting=Setting("global", "global_setting_value2"))
    data.update_setting(setting=Setting("plugin", "plugin_setting_value"),
                        plugin=Plugin("plugin_type1", "plugin_name1"))
    setting = data.get_setting("global")
    assert setting == Setting("global", "global_setting_value2")
    assert data.get_settings() == [Setting("global", "global_setting_value2")]
    setting = data.get_setting("plugin", Plugin("plugin_type1", "plugin_name1"))
    assert setting == Setting("plugin", "plugin_setting_value")

# Generated at 2022-06-22 19:30:03.942630
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    plugin = None
    data = config_data.get_settings(plugin)
    assert len(data) == 0


# Generated at 2022-06-22 19:30:07.674948
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data.get_settings() == []

    # Unit test for get_setting and update_setting of class ConfigData