

# Generated at 2022-06-22 19:20:12.964351
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    setting = Setting(name="setting", value="value", origin="origin")
    configData.update_setting(setting)
    assert configData.get_setting(setting.name) == setting
    plugin = Plugin(type="type", name="name")
    configData.update_setting(setting, plugin)
    assert configData.get_setting(setting.name, plugin) == setting


# Generated at 2022-06-22 19:20:21.777757
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    global_setting = Setting('setting_g', dict(value='setting_g', section='defaults', config_file='ansible.cfg', plugin=None))
    config.update_setting(global_setting)
    assert config.get_settings() == [global_setting]
    plugin = AnsiblePlugin('cache', 'memory', '')
    plugin_setting = Setting('setting_p', dict(value='setting_p', section='cache_plugins', config_file='ansible.cfg', plugin=plugin))
    config.update_setting(plugin_setting)
    assert config.get_settings(plugin) == [plugin_setting]
    assert config.get_settings() == [global_setting]

# Generated at 2022-06-22 19:20:22.498408
# Unit test for constructor of class ConfigData
def test_ConfigData():
    obj = ConfigData()
    assert obj is not None

# Generated at 2022-06-22 19:20:33.669039
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock, call

    config = ConfigData()

    setting1 = MagicMock()
    setting1.name = 'setting1'

    plugin = MagicMock()
    plugin.type = 'type1'
    plugin.name = 'name1'

    setting2 = MagicMock()
    setting2.name = 'setting2'

    settings = config.get_settings(plugin)
    assert settings == []

    config.update_setting(setting1)
    settings = config.get_settings()
    assert settings == [setting1]

    config.update_setting(setting2, plugin)
    settings = config.get_settings(plugin)
    assert settings == [setting2]


# Generated at 2022-06-22 19:20:39.135240
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # TODO: Improve unit test code and add missing test cases.
    config_data = ConfigData()
    setting = Setting(name="A", value="1", section="plugins", plugin=Plugin("action", "ping"))
    config_data.update_setting(setting)
    #Test check the setting 
    assert config_data._plugins["action"]["ping"]["A"] == setting

# Generated at 2022-06-22 19:20:44.633286
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()

    assert len(configdata.get_settings()) == 0
    assert len(configdata.get_settings("plugin_1")) == 0

    for i in range(10):
        s = Setting("setting_1")
        configdata.update_setting(s)
        s = Setting("setting_1")
        p = Plugin("plugin_1", "type_1")
        configdata.update_setting(s, p)

    assert len(configdata.get_settings()) == 1
    assert len(configdata.get_settings("plugin_1")) == 1

    pass


# Generated at 2022-06-22 19:20:47.478180
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:20:49.760466
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:20:51.093678
# Unit test for constructor of class ConfigData
def test_ConfigData():

    configdata = ConfigData()
    assert configdata is not None

# Generated at 2022-06-22 19:20:56.223066
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0
    config_data.update_setting(Setting('test', 'test', 'test'))
    assert len(config_data.get_settings()) == 1


# Generated at 2022-06-22 19:21:05.564661
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    VALID_SETTING_1 = (
        "plugin_name",
        "plugin_type",
        "plugin_path",
        "config_file_name",
        "config_file_path",
        "display",
        "description",
        "default_value",
        "value"
    )

    VALID_SETTING_2 = (
        "plugin_name",
        "plugin_type",
        "plugin_path",
        "config_file_name",
        "config_file_path",
        "display",
        "description",
        "default_value",
        "value"
    )


# Generated at 2022-06-22 19:21:08.986115
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0

    # Check that an exception is raised when trying to get settings of an
    # undefined plugin
    try:
        config_data.get_settings(Plugin(type="", name=""))
    except Exception as e:
        assert type(e) is TypeError
    else:
        assert False



# Generated at 2022-06-22 19:21:15.398174
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()

    # Test No.1
    settings = config.get_settings()
    assert(len(settings) == 0)

    # Test No.2
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.config import setting
    import ansible_collections.notstdlib.moveitallout.plugins.module_utils.common as common

    config_setting = setting.ConfigSetting('COW', 'A', 'a', common.ConfigAttribute('attr_name', 'attr_val'))
    config.update_setting(config_setting)

    # Test No.3
    settings = config.get_settings(None)
    assert(len(settings) == 1)
    assert(settings[0].name == 'COW')

    # Test No.4

# Generated at 2022-06-22 19:21:18.111122
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

# Generated at 2022-06-22 19:21:18.855518
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    assert True

# Generated at 2022-06-22 19:21:28.187350
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    config_data.update_setting(Setting("CONFIG_FILE", "ansible.cfg", "string"))
    assert config_data.get_setting("CONFIG_FILE") is not None
    assert config_data.get_setting("CONFIG_FILE").name == "CONFIG_FILE"
    assert config_data.get_setting("CONFIG_FILE").default == "ansible.cfg"
    assert config_data.get_setting("CONFIG_FILE").type == "string"

    config_data.update_setting(Setting("BIN_PATH", "/usr/bin:/usr/sbin:/bin:/sbin", "list"), Plugin("shell", "default"))
    assert config_data.get_setting("BIN_PATH", Plugin("shell", "default")) is not None
    assert config_data.get_

# Generated at 2022-06-22 19:21:37.699459
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    s = PluginSetting('test', 'Test')
    s.value = 'test'
    c.update_setting(s)
    assert c.get_settings() == [s]
    assert c.get_settings(Plugin('test', 'Test')) == []
    assert c.get_settings(Plugin('none', 'Test')) == []
    assert c.get_settings(Plugin('test', 'None')) == []
    assert c.get_settings(Plugin('none', 'None')) == []
    s.plugin = Plugin('none', 'None')
    c.update_setting(s)
    assert c.get_settings(Plugin('none', 'None')) == [s]
    assert c.get_settings() == [s]



# Generated at 2022-06-22 19:21:45.811883
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    config.update_setting(Setting('setting1', 'setting1', 'setting1-value'))
    config.update_setting(Setting('setting2', 'setting2', 'setting2-value'))
    config.update_setting(Setting('setting3', 'setting3', 'setting3-value'))
    config.update_setting(Setting('setting4', 'setting4', 'setting4-value'), Plugin('core', 'core'))
    config.update_setting(Setting('setting5', 'setting5', 'setting5-value'), Plugin('core2', 'core2'))
    config.update_setting(Setting('setting6', 'setting6', 'setting6-value'), Plugin('core3', 'core3'))

    settings = config.get_settings()
    assert len(settings) == 3

    settings = config

# Generated at 2022-06-22 19:21:51.360993
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    cd = ConfigData()
    plugin = ConfigPlugin('test', 'test', 'test')
    setting = ConfigSetting('setting', 'setting', 'setting')
    cd.update_setting(setting)
    assert cd._global_settings['setting']
    cd._global_settings = {}
    cd.update_setting(setting, plugin)
    assert cd._plugins['test']['test']['setting']



# Generated at 2022-06-22 19:21:54.377274
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    if config_data._global_settings is None:
        raise AssertionError()
    if config_data._plugins is None:
        raise AssertionError()


# Generated at 2022-06-22 19:22:01.562009
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # method test setup
    from ansible.plugins.loader import PluginLoader
    from ansible.parsing.plugin_docs import readme_find_plugin_config_options
    from ansible.parsing.plugin_docs import get_docstring, get_docstring_summary

    def _get_docstring_summary(path):
        return get_docstring_summary(get_docstring(path, verbose=False))

    plugin_loader = PluginLoader(package='ansible.plugins')
    plugin_collection = plugin_loader.all()
    plugin_names = {}
    for plugin_path in plugin_collection._all_paths:
        plugin_names[plugin_path] = os.path.basename(plugin_path)[:-3]

    config_data = ConfigData()

# Generated at 2022-06-22 19:22:04.789971
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-22 19:22:05.826236
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cd = ConfigData()
    assert cd is not None

# Generated at 2022-06-22 19:22:15.553104
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin = SomePlugin(PLUGIN_TYPE, PLUGIN_NAME)
    config_data = ConfigData()
    ''' tests the method update_setting of class ConfigData '''
    ''' with plugin as None and setting name as some_setting '''
    config_data.update_setting(Setting(SETTING_NAME, "some_value"))
    setting = config_data.get_setting(SETTING_NAME)
    assert setting.name == "some_setting" and setting.value == "some_value"
    ''' with plugin as some_plugin and setting name as some_setting '''
    config_data.update_setting(Setting(SETTING_NAME, "some_value"), plugin)
    setting = config_data.get_setting(SETTING_NAME, plugin)
    assert setting.name == "some_setting" and setting.value

# Generated at 2022-06-22 19:22:25.404808
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()

    from ansible.module_utils.common.collections import ImmutableDict
    setting1 = ImmutableDict(name='test_setting1', type='str', default=None, options={'test_option1': 1, 'test_option2': 2})
    setting2 = ImmutableDict(name='test_setting2', type='int', default=None, options={'test_option3': 3, 'test_option4': 4})

    # Test global settings
    cd.update_setting(setting1)
    assert cd.get_setting('test_setting1') == setting1
    cd.update_setting(setting2)
    assert cd.get_setting('test_setting2') == setting2

    # Test plugin settings
    plugin_type = 'test_plugin_type'

# Generated at 2022-06-22 19:22:35.428881
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin_type=PluginType(name='action')
    plugin_name=PluginName(name='test')
    plugin=Plugin(plugin_type,plugin_name)
    setting=Config(plugin_name,plugin_type,'test','test')

    configdata=ConfigData()
    # test with plugin
    configdata.update_setting(setting, plugin)
    settings=configdata.get_settings(plugin)
    assert len(settings)==1
    assert settings[0].name==setting.name

    # test without plugin
    setting2=Config(plugin_name,plugin_type,'test2','test')
    configdata.update_setting(setting2)
    settings=configdata.get_settings()
    assert len(settings)==1
    assert settings[0].name==setting2.name



# Generated at 2022-06-22 19:22:46.128821
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.config.data import PluginConfig

    config = ConfigData()
    assert config.get_setting('ANSIBLE_ANSIBLE_SSH_RETRIES') is None

    config.update_setting(PluginConfig('ANSIBLE_ANSIBLE_SSH_RETRIES', 4, 1, 'INI', 'all', 'default', 'SSH connection retries'))
    assert config.get_setting('ANSIBLE_ANSIBLE_SSH_RETRIES').name == 'ANSIBLE_ANSIBLE_SSH_RETRIES'

    config.update_setting(PluginConfig('ANSIBLE_STRATEGY', 'linear', 1, 'INI', 'all', 'default', 'execution strategy'))
    assert config.get_setting('ANSIBLE_STRATEGY').name == 'ANSIBLE_STRATEGY'


# Generated at 2022-06-22 19:22:54.734294
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert len(cd.get_settings()) == 0

    s1 = Setting('s1')
    s1.value = True
    cd.update_setting(s1)

    assert len(cd.get_settings()) != 0
    assert len(cd.get_settings()) == 1
    assert cd.get_setting('s1').value == True

    s2 = Setting('s2')
    s2.value = False
    cd.update_setting(s2)

    assert len(cd.get_settings()) == 2
    assert cd.get_setting('s1').value == True
    assert cd.get_setting('s2').value == False



# Generated at 2022-06-22 19:23:04.818370
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    class Plugin(object):
        def __init__(self, name, type):
            self.name = name
            self.type = type

    class Setting(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value

    plugin1 = Plugin("plugin1", "action")
    plugin2 = Plugin("plugin2", "action")
    setting1 = Setting("setting1", "value1")
    setting2 = Setting("setting2", "value2")
    setting3 = Setting("setting3", "value3")
    config_data.update_setting(setting1, plugin1)
    config_data.update_setting(setting2, plugin1)
    config_data.update_setting(setting3, plugin2)
    assert config_data._

# Generated at 2022-06-22 19:23:15.902373
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('interpreter', 'python'))
    assert config_data.get_setting('interpreter') == Setting('interpreter', 'python')
    config_data.update_setting(Setting('interpreter', 'python3'), PluginType('module'), 'example_module')
    assert config_data.get_setting('interpreter', PluginType('module'), 'example_module') == Setting('interpreter', 'python3')

    config_data = ConfigData()
    config_data.update_setting(Setting('interpreter', 'python'))
    assert config_data.get_setting('interpreter') == Setting('interpreter', 'python')

# Generated at 2022-06-22 19:23:16.801810
# Unit test for constructor of class ConfigData
def test_ConfigData():

    obj = ConfigData()
    assert isinstance(obj, ConfigData)


# Generated at 2022-06-22 19:23:19.506180
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data,ConfigData)

# Test for method get_setting

# Generated at 2022-06-22 19:23:32.842989
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    # Test update global setting
    config_data._global_settings = {}
    config_data._plugins = {}
    setting = config_data.get_setting('foo')
    assert setting is None
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    setting = config_data.get_setting('foo')
    assert setting is not None
    assert setting.name == 'foo'
    assert setting.value == 'bar'
    assert config_data._global_settings['foo'].name == setting.name
    assert config_data._global_settings['foo'].value == setting.value
    assert config_data._global_settings == {'foo': setting}
    # Test update setting for plugin_a

# Generated at 2022-06-22 19:23:35.977261
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:23:44.496404
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Test with a wrong plugin
    plugin_wrong = Plugin("test_type", "test_name")
    setting = config_data.get_setting("test_name", plugin_wrong)
    assert setting is None

    # Test with a correct plugin type but wrong name
    plugin_wrong = Plugin("test_type", "test_wrong_name")
    setting = config_data.get_setting("test_name", plugin_wrong)
    assert setting is None

    # Test with a correct plugin type and name
    config_data.update_setting(Setting("test_name", "test_value"), plugin)
    setting = config_data.get_setting("test_name", plugin)
    assert setting.name == "test_name"
    assert setting.value == "test_value"

    # Test with a plugin

# Generated at 2022-06-22 19:23:48.185403
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()

    for setting in config.get_settings():
        assert False

    for setting in config.get_settings('fails'):
        assert False

# Generated at 2022-06-22 19:23:55.331948
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('first_var', '123', 'Global', '', 'Ansible'), None)
    config_data.update_setting(Setting('second_var', 'file.txt', 'Global', '', 'Ansible'), None)
    config_data.update_setting(Setting('third_var', 'var', 'Action', '', 'Linear'), Plugin('Linear', 'Action'))
    config_data.update_setting(Setting('fourth_var', 'path/to/file.txt', 'Action', '', 'Linear'), Plugin('Linear', 'Action'))
    config_data.update_setting(Setting('fifth_var', 'James', 'Connection', '', 'Network'), Plugin('Network', 'Connection'))

# Generated at 2022-06-22 19:24:03.788378
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin_type = "type"
    plugin_name = "name"
    config_data = ConfigData()
    plugin = Plugin(plugin_type, plugin_name, "path")
    def_setting = config_data.get_setting("vars_plugins")
    def_setting.set_value("MY_VARS")
    new_setting = Setting("ANSIBLE_CONFIG", "fake_path")
    config_data.update_setting(new_setting, plugin)
    new_setting = Setting("vars_plugins", "MY_VARS")
    config_data.update_setting(new_setting, plugin)
    settings = config_data.get_settings(plugin)
    assert len(settings) == 2
    settings = config_data.get_settings()
    assert len(settings) == 1


# Generated at 2022-06-22 19:24:14.048845
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    setting = {
        'name': 'c.InteractiveShellApp.log_level',
        'type': 'str',
        'value': 'WARN',
        'help': 'Sets the log level by value or name.'
    }
    data.update_setting(setting)
    result = data.get_setting('c.InteractiveShellApp.log_level')

    assert(type(result) is dict)
    assert(result['name'] == 'c.InteractiveShellApp.log_level')
    assert(data.get_setting('c.InteractiveShellApp') is None)


# Generated at 2022-06-22 19:24:18.663604
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    var = 'var'
    value = 'value'

    config_data = ConfigData()
    config_data.update_setting(Setting(var, value))

    assert config_data.get_settings()[0].value == value


# Generated at 2022-06-22 19:24:28.545881
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import PluginLoader
    from ansible.cli import CLI
    from ansible.errors import AnsibleError
    from ansible.utils.display import Display

    global_settings = {}
    plugins = {}

    display = Display()
    loader = PluginLoader(display)
    cli = CLI(cli_options={})
    cli.verbosity = 0
    cli.parse()

    config_data = ConfigData()


# Generated at 2022-06-22 19:24:30.285513
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    plugin1 = Plugin('Foo', 'Bar')
    settings = [Setting('foo'), Setting('bar')]
    for i in settings:
        cd.update_setting(i)
    assert cd.get_settings(plugin1) == settings

# Generated at 2022-06-22 19:24:35.706706
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.plugins.loader import PluginLoader

    config = ConfigData()
    p = PluginLoader('lookup', 'lookup_plugins', 'LookupModule', 'lookup_')
    for plugin in [plugin for plugin in p.all(class_only=True) if hasattr(plugin, '_setup')]:
        plugin(None, plugin._load_name, config=config)
    setting = config.get_setting('timeout', plugin=p.get('redis_kv'))
    assert(setting.name == 'timeout')
    assert(setting.value == 5)


# Generated at 2022-06-22 19:24:40.423181
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name="TEST_SETTING", value="TEST_VALUE"))
    setting = config_data.get_setting("TEST_SETTING")
    assert setting.name is "TEST_SETTING"
    assert setting.value is "TEST_VALUE"


# Generated at 2022-06-22 19:24:41.285410
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()


# Generated at 2022-06-22 19:24:45.671394
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo'))

    assert len(config_data._global_settings) == 1



# Generated at 2022-06-22 19:24:46.719302
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert isinstance(config, ConfigData)


# Generated at 2022-06-22 19:24:55.803611
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import os
    import ansible.constants as constants
    import ansible.utils as utils
    from ansible.module_utils import six
    from ansible.plugins.loader import config_loader

    class Plugin(object):

        def __init__(self, name, path, module_utils_path, type):
            self.name = name
            self.path = path
            self.module_utils_path = module_utils_path
            self.type = type

    # Create a temporary directory
    TEST_DIR = os.path.join(constants.DEFAULT_LOCAL_TMP, ".ansible-test-config_loader")
    os.makedirs(TEST_DIR)
    os.makedirs(os.path.join(TEST_DIR, "module_utils"))

    # Create test plugin file
    TEST

# Generated at 2022-06-22 19:25:00.957722
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin('test', 'test', 'test')
    setting = Setting('test', 'test', 'test', 'test')
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings(plugin) == [setting]


# Generated at 2022-06-22 19:25:10.430057
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    plugin1 = C.Plugin()
    plugin1.type = 'module'
    plugin1.name = 'setup'
    plugin2 = C.Plugin()
    plugin2.type = 'module'
    plugin2.name = 'group_by'
    plugin3 = C.Plugin()
    plugin3.type = 'shell'
    plugin3.name = 'sh'
    plugin4 = C.Plugin()
    plugin4.type = 'strategy'
    plugin4.name = 'debug'
    plugin5 = C.Plugin()
    plugin5.type = 'module'
    plugin5.name = 'copy'

    setting1 = C.Setting()
    setting1.plugin = plugin1
    setting1.name = 'fact_list'
    setting1.value = ['ansible_facts']
    setting2 = C.Setting()

# Generated at 2022-06-22 19:25:14.660445
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Check to see if the function returns None if the plugin does not exist
    assert config_data.get_setting("PLUGIN_NAME") is None


# Generated at 2022-06-22 19:25:23.203123
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # There is not any setting at the moment
    assert config_data.get_setting("") is None
    assert config_data.get_setting("", "") is None

    # Add some settings
    from ansible.config.setting import Setting
    from ansible.config.manager import ConfigManager

    config = ConfigManager()
    config_data.update_setting(Setting(config, 'foo', 'bar'))
    config_data.update_setting(Setting(config, 'baz', 'qux'))

    # Add global settings
    config_data.update_setting(Setting(config, 'foo1', 'bar1', plugin=''))
    config_data.update_setting(Setting(config, 'baz1', 'qux1', plugin=''))

    # Test there is no error when we

# Generated at 2022-06-22 19:25:26.438379
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    c = ConfigData()
    s = Setting('test')
    c.update_setting(s)
    assert c.get_setting('test') == s


# Generated at 2022-06-22 19:25:34.388986
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    cd = ConfigData()

    cd.update_setting(ConfigSetting('ka', 'va', 'keys', plugin=ConfigPlugin('f', 'g')))
    cd.update_setting(ConfigSetting('kc', 'vc', 'keys', plugin=ConfigPlugin('f', 'g')))
    cd.update_setting(ConfigSetting('kd', 'vd', 'keys', plugin=ConfigPlugin('f', 'g')))
    cd.update_setting(ConfigSetting('kdisk', 'vdisk', 'keys', plugin=ConfigPlugin('f', 'g')))

    settings = {s.name: s for s in cd.get_settings(plugin=ConfigPlugin('f', 'g'))}

    assert len(settings) == 4
    assert settings['ka'].value == 'va'
    assert settings['kc'].value == 'vc'
   

# Generated at 2022-06-22 19:25:45.844034
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from plugin_config import PluginConfig
    from setting import Setting
    from constants import PluginConfigType

    config_data = ConfigData()
    plugin_config = PluginConfig(plugin_type=PluginConfigType.ACTION, plugin_name='lookup', plugin_path='/home/user/ansible/action_plugins/')

    s1 = Setting(name='var1', value='val1', description='var1 description')
    s2 = Setting(name='var2', value='val2', description='var2 description')
    s3 = Setting(name='var3', value='val3', description='var3 description')
    config_data.update_setting(s1, plugin=None)
    config_data.update_setting(s2, plugin=plugin_config)
    config_data.update_setting(s3, plugin=plugin_config)



# Generated at 2022-06-22 19:25:57.606937
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert config.get_setting('test') is None

    from ansible.plugins.loader import PluginLoader, Plugin
    import ansible.constants as C
    plugin = PluginLoader.find_plugin(Plugin(type_name='foo', name='bar'))
    plugin.config_spec = {
        'test1': dict(default=1, type='int'),
        'test2': dict(default=False, type='bool'),
        'test3': dict(default='', type='list')
    }
    setting_name = 'test1'
    setting_type = 'int'
    setting_default = 1
    setting = plugin.get_configuration_spec_option(setting_name, setting_type, setting_default)
    assert setting.name == setting_name
    assert setting.type == setting_type

# Generated at 2022-06-22 19:26:06.339736
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_data = ConfigData()
    print(test_data._global_settings)
    print(test_data._plugins)
    test_data.update_setting(1)
    print(test_data._global_settings)
    print(test_data._plugins)
    test_data.update_setting(2)
    print(test_data._global_settings)
    print(test_data._plugins)
    test_data.update_setting(3, 4)
    print(test_data._global_settings)
    print(test_data._plugins)
    test_data.update_setting(5, 6)
    print(test_data._global_settings)
    print(test_data._plugins)
    test_data.update_setting(7, 6)
    print(test_data._global_settings)
    print

# Generated at 2022-06-22 19:26:07.664763
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cd.update_setting(setting=None)


# Generated at 2022-06-22 19:26:18.349155
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.action.normal.configdata import ConfigData, Setting
    from ansible.plugins.action.normal._utils import expand_tilde_path

    plugin_loader = PluginLoader()

    config_data = ConfigData()
    assert config_data is not None

    # NOTE: Method returns None if plugin is None
    assert config_data.update_setting(None) is None

    # NOTE: Method returns None if plugin is not an object
    assert config_data.update_setting('invalid') is None

    # NOTE: Method returns None if plugin is not a Plugin object
    assert config_data.update_setting(plugin_loader) is None

    # NOTE: Method returns None if plugin does not have name and type attributes
   

# Generated at 2022-06-22 19:26:23.169176
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None
    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-22 19:26:26.163620
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    assert cd.get_setting(name='ANSIBLE_CALLBACK_WHITELIST') is None
    assert cd.get_setting(name='ANSIBLE_STDOUT_CAPTURE', plugin=dict(type='callback', name='minimal')) is None

# Generated at 2022-06-22 19:26:30.866476
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin('TestType', 'TestPlugin', 'TestVersion', 'TestPath')
    setting = Setting('TestSetting', 'TestValue')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['TestType']['TestPlugin']['TestSetting'] == setting


# Generated at 2022-06-22 19:26:32.851508
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:26:37.680149
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_1 = Setting(name='setting_1', value="value1")
    plugin = Plugin()
    config_data.update_setting(setting_1)
    assert config_data.get_setting('setting_1') == setting_1
    config_data.update_setting(setting_1, plugin)
    assert config_data.get_setting('setting_1', plugin) == setting_1

test_ConfigData_update_setting()

# Generated at 2022-06-22 19:26:40.530400
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cdata = ConfigData()
    cdata.update_setting('plugin_name', 'plugin_type')
    assert cdata


# Generated at 2022-06-22 19:26:50.043022
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    configData.update_setting(Setting("defaults", "defaults", "debug"))
    print("unit test for method update_setting of class ConfigData")
    print("method update_setting check data")
    print("get_setting('defaults', None) = ", configData.get_setting("defaults", None), "; Expected: " + "debug")
    print("get_settings(None) = ", configData.get_settings(None), "; Expected: " + "[debug]")
    print("update_setting method check success")


# Generated at 2022-06-22 19:27:01.492403
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    s = Setting('var1', 1)
    cd.update_setting(s)
    s = Setting('var1', 2)
    cd.update_setting(s)
    s = Setting('var2', 3)
    cd.update_setting(s)
    cd.update_setting(Setting('var1', 4), Plugin('module', 'ping'))
    cd.update_setting(Setting('var1', 5), Plugin('module', 'shell'))
    cd.update_setting(Setting('var2', 6), Plugin('module', 'shell'))
    cd.update_setting(Setting('var3', 7), Plugin('module', 'shell'))
    cd.update_setting(Setting('var1', 8), Plugin('module', 'ping'))

# Generated at 2022-06-22 19:27:10.107537
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.utils.plugin import Plugin
    from ansible.utils.vars import combine_vars
    config = ConfigData()
    plugin = Plugin('cache', 'memory', config)
    setting = read_docstring(plugin, 'CACHE_PLUGIN_CONNECTION',
                             base_class='CacheModule',
                             in_core=True)
    config.update_setting(setting)
    assert 'CACHE_PLUGIN_CONNECTION' in config._plugins['cache']['memory']

    # Verify that the setting was updated
    setting_name = 'CACHE_PLUGIN_CONNECTION'

# Generated at 2022-06-22 19:27:20.891393
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    p = Plugin('cache','lookup','plugin_name')
    json = {'type':'cache','name':'lookup','plugin_name':'json'}
    plugin = Plugin().from_json(json)
    assert plugin.name == 'lookup'
    assert plugin.type == 'cache'
    assert plugin.plugin_name == 'json'
    assert str(plugin) == 'cache(lookup)'
    data = ConfigData()
    setting = Setting('env', 'cache', 'lookup', None, 'json', 'plugin_name', {}, None, None)
    data.update_setting(setting, p)
    assert data.get_setting('env', p) == setting
    assert data.get_setting('env', plugin) == setting
    assert data.get_setting('env') == setting

# Generated at 2022-06-22 19:27:23.609057
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert False  # TODO: implement your test here


# Generated at 2022-06-22 19:27:26.244423
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-22 19:27:31.862836
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting("a")
    config.update_setting("b", plugin_type="action", plugin_name="copy")

    assert(len(config.get_settings()) == 1)
    assert("a" in config.get_settings())

    assert(len(config.get_settings("action", "copy")) == 1)
    assert("b" in config.get_settings("action", "copy"))


# Generated at 2022-06-22 19:27:37.064344
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()

    # verifying if the setting will be returned in get_setting
    cd.update_setting(Setting(name='foo', value='bar'))
    assert cd.get_setting('foo')

    # verifying if the setting will be returned in get_settings
    cd.update_setting(Setting(name='baz', value='quux'))
    assert len(cd.get_settings()) == 2

    # verifying if the setting will be returned in get_settings for a specific plugin
    cd.update_setting(Setting(name='foo', value='bar', plugin='my-plugin'))
    assert len(cd.get_settings('my-plugin')) == 1

# Generated at 2022-06-22 19:27:38.768414
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    settings = config.get_settings()
    assert len(settings) == 0


# Generated at 2022-06-22 19:27:49.063258
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin(name="Test", type="HelperPlugin")

    config_data.update_setting(Setting("TestSetting", "TestValue"), plugin)
    config_data.update_setting(Setting("TestSetting2", "TestValue2"), plugin)
    config_data.update_setting(Setting("TestSetting3", "TestValue3", plugin))
    config_data.update_setting(Setting("TestSetting4", "TestValue4", plugin))

    assert len(config_data.get_settings(plugin=plugin)) == 3
    assert len(config_data.get_setting(plugin=plugin, name="TestSetting")) == 1
    assert len(config_data.get_setting(plugin=plugin, name="TestSetting3")) == 1


# Generated at 2022-06-22 19:27:53.425490
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    from ansiblelint import AnsibleLintConfig

    setting = AnsibleLintConfig.setting(['foo', 'bar'])
    setting.value = 'baz'
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting



# Generated at 2022-06-22 19:28:00.210147
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    confdata = ConfigData()

    assert confdata.get_settings()==[], "This should be a empty list"

    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common._collections_compat import Mapping

    class Setting(Mapping):
        def __init__(self, name, value):
            self.name = name
            self.value = value

        def __getitem__(self, key):
            if key == 'name':
                return self.name
            elif key == 'value':
                return self.value
            else:
                raise KeyError('Invalid key: "%s"' % to_native(key))

        def __iter__(self):
            return iter(['name', 'value'])

        def __len__(self):
            return

# Generated at 2022-06-22 19:28:10.400462
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    
    from plugin_docs_fragments.config_data import ConfigData
    from plugin_docs_fragments.setting_data import SettingData
    from plugin_docs_fragments.plugin_data import PluginData
    
    config_data = ConfigData()
    plugin_data_action_module = PluginData(type='ACTION_PLUGINS', name='os_network')
    
    setting_data = SettingData()
    setting_data.name = 'setting'
    config_data.update_setting(setting_data)
    assert config_data.get_setting('setting').name == 'setting'
    
    setting_data = SettingData()

# Generated at 2022-06-22 19:28:13.177804
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # init object
    test_config_data = ConfigData()

    assert test_config_data is not None
    assert len(test_config_data._global_settings) == 0
    assert len(test_config_data._plugins) == 0


# Generated at 2022-06-22 19:28:24.142741
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    plugin_collection = PluginCollection()
    plugin = plugin_collection.get_plugin_by_name('lookup', 'password_lookup')
    plugin_coll2 = PluginCollection()
    plugin2 = plugin_coll2.get_plugin_by_name('shell', 'command')

    config_data.update_setting(Setting('TIMEOUT', '30'), None)
    # noinspection PyTypeChecker
    config_data.update_setting(Setting('SOME_SETTING_1', 'SOME_VALUE_1', plugin))
    config_data.update_setting(Setting('TIMEOUT', '60'), plugin2)

    assert config_data.get_setting('TIMEOUT') == '30'

# Generated at 2022-06-22 19:28:32.832344
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    
    config_data.update_setting(Setting('a'))
    config_data.update_setting(Setting('b'), Plugin(Plugin.CALLBACK, 'c'))
    config_data.update_setting(Setting('c'), Plugin(Plugin.CALLBACK, 'c'))
    config_data.update_setting(Setting('d'), Plugin(Plugin.CALLBACK, 'd'))
    config_data.update_setting(Setting('e'), Plugin(Plugin.CACHE, 'e'))
    config_data.update_setting(Setting('f'), Plugin(Plugin.CACHE, 'f'))
    config_data.update_setting(Setting('g'), Plugin(Plugin.CACHE, 'g'))


# Generated at 2022-06-22 19:28:37.591488
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('test', 'value'))
    assert config_data.get_setting('test')

    config = Plugin('config', 'test')
    config_data.update_setting(Setting('test', 'value'), config)
    assert config_data.get_setting('test', config)

# Generated at 2022-06-22 19:28:43.998946
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('one', '1'))
    config_data.update_setting(ConfigSetting('two', '2'))
    assert len(config_data.get_settings()) == 2


# Generated at 2022-06-22 19:28:47.330916
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting('test')
    assert config_data._global_settings['test'] == 'test'


# Generated at 2022-06-22 19:28:57.942111
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {'name': 'ANSIBLE_CONFIG_CHECKING',
               'value': 'true',
               'priority': 1,
               'origin': 'built-in',
               'plugin': None}
    config_data.update_setting(**setting)
    assert config_data._global_settings.get('ANSIBLE_CONFIG_CHECKING') == setting
    setting['name'] = 'ANSIBLE_FORCE_COLOR'
    config_data.update_setting(**setting)
    assert config_data._global_settings.get('ANSIBLE_FORCE_COLOR') == setting


# Generated at 2022-06-22 19:29:00.982010
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()

    assert len(config._global_settings) == 0
    assert len(config._plugins) == 0


# Generated at 2022-06-22 19:29:02.338971
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    assert False, "Test not implemented"


# Generated at 2022-06-22 19:29:03.542885
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:29:07.305540
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    c = ConfigData()
    c.update_setting(Setting(name='foo', value='bar'))
    assert c.get_setting('foo').value == 'bar'


# Generated at 2022-06-22 19:29:19.146974
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    import tempfile
    # create temporary file and write the sample configuration to it
    conf_file = tempfile.NamedTemporaryFile(mode='w')
    conf_file.write("""[defaults]
callback_whitelist = timers, defaults
roles_path = /Users/ansible/Projects/ansible/roles
""")
    # read the configuration and close the temporary file
    conf_file.flush()
    # a list that is expected to hold the plugin type and name for the plugin we want to display available settings
    expected_plugin_type = 'callback'
    expected_plugin_name = 'defaults'
    config_data = ConfigData()
    settings = config_data.get_settings()
    assert settings[0].name == 'callback_whitelist'

# Generated at 2022-06-22 19:29:23.249551
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # arrange
    config_data = ConfigData()

    # act
    setting1 = config_data.get_setting('default_tasks_seconds')
    setting2 = config_data.get_setting('default_tasks_seconds', 'connection')

    # assert
    assert setting1 is None
    assert setting2 is None


# Generated at 2022-06-22 19:29:24.587962
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()
    assert config

# Test add_setting

# Generated at 2022-06-22 19:29:33.163203
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    conf = ConfigData()
    assert len(conf._global_settings) == 0
    assert len(conf._plugins) == 0

    conf.update_setting(ConfigSetting(name='foo'))
    assert len(conf._global_settings) == 1
    assert len(conf._plugins) == 0
    assert conf._global_settings.get('foo') is not None
    assert conf._global_settings.get('bar') is None

    conf.update_setting(ConfigSetting(name='bar'))
    assert len(conf._global_settings) == 2
    assert len(conf._plugins) == 0
    assert conf._global_settings.get('foo') is not None
    assert conf._global_settings.get('bar') is not None

    p = ConfigPlugin('test', 'test')

# Generated at 2022-06-22 19:29:35.689550
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()

    assert config.get_settings() == [], "Global settings should be empty"
    assert config.get_settings(plugin=None) == [], "Global settings should be empty"



# Generated at 2022-06-22 19:29:42.791411
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = PluginData()
    plugin.type = 'action'
    plugin.name = 'neutron_network_facts'

    # No plugin so it should return none
    assert config_data.get_setting('network_api_timeout', None) is None

    plugin_setting1 = ConfigSetting('network_api_timeout')
    plugin_setting1.set_value(30)
    config_data.update_setting(plugin_setting1, plugin)

    # Verify the plugin setting is updated
    assert 'network_api_timeout' in config_data._plugins[plugin.type][plugin.name] is True

    # Verify the global setting is not updated
    assert 'network_api_timeout' in config_data._global_settings is False


# Generated at 2022-06-22 19:29:53.829013
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.module_utils.common.setting_parser import AnsibleConfig

    config_data = ConfigData()

    # Add a global settings
    setting = AnsibleConfig('global_key', 'global_value', None, None, None, 'global')
    config_data.update_setting(setting)

    # Add a plugin with settings
    plugin = AnsibleConfig('plugin_value', None, 'plugin_type', 'plugin_name', 'plugin_path', 'plugin')
    config_data.update_setting(plugin)

    setting = AnsibleConfig('plugin_key', 'plugin_value', 'plugin_type', 'plugin_name', 'plugin_path', 'plugin')
    config_data.update_setting(setting)

    settings = config_data.get_settings()

    assert len(settings) == 1

# Generated at 2022-06-22 19:30:02.678296
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    from ansible.config.setting import Setting
    from ansible.plugins import AnsiblePlugin
    s = Setting('foo', None, 5, type=int, choices=[1, 2, 3])
    p = AnsiblePlugin('test', 'test')
    cd.update_setting(s)
    assert cd.get_setting('foo').value == 5
    assert cd.get_setting('foo', plugin=p) is None
    s2 = Setting('foo', None, 6, type=int, choices=[1, 2, 3])
    cd.update_setting(s2, plugin=p)
    assert cd.get_setting('foo').value == 5
    assert cd.get_setting('foo', plugin=p).value == 6

# Generated at 2022-06-22 19:30:07.263431
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = Plugin('test_type', 'test_name')

    # Test getting a setting for a specific plugin
    assert config_data.get_setting('some_key', plugin) is None

    # Test getting a setting for global settings
    assert config_data.get_setting('some_key') is None

    # Test getting a setting for a plugin
    setting = Setting('some_key', 'some_value')
    config_data.update_setting(setting, plugin)
    setting_returned = config_data.get_setting('some_key', plugin)
    assert setting_returned is not None
    assert setting_returned.name == 'some_key'
    assert setting_returned.value == 'some_value'

    # Test getting a setting for global settings

# Generated at 2022-06-22 19:30:13.923537
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_settings() == []

    config_data.update_setting(Setting('foo', 'bar', 'the global setting'))
    assert config_data.get_setting('foo') is not None
    assert config_data.get_setting('foo').name == 'foo'
    assert config_data.get_setting('foo').value == 'bar'
    assert config_data.get_setting('foo').description == 'the global setting'

    config_data.update_setting(Setting('foo', 'baz', 'the global setting'),
                               Plugin('core.test', 'core', 'test'))
    assert config_data.get_setting('foo', Plugin('core.test', 'core', 'test')) is not None