

# Generated at 2022-06-22 19:20:16.961689
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class MockPlugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class MockSetting(object):
        def __init__(self, name):
            self.name=name

    # Setting that exists in global context

    config_data = ConfigData()

    setting = MockSetting('first')
    config_data.update_setting(setting)

    assert config_data.get_setting('first') == setting
    assert config_data.get_setting('second') is None

    # Setting that exists in context of a plugin

    config_data = ConfigData()

    plugin = MockPlugin('callback', 'sample')

    setting = MockSetting('first')
    config_data.update_setting(setting, plugin)

    assert config_data.get_setting('first') is None

# Generated at 2022-06-22 19:20:20.933231
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('ansible_python_interpreter', '/usr/bin/python3')
    config_data.update_setting(setting)
    assert config_data._global_settings['ansible_python_interpreter'] == setting

# Generated at 2022-06-22 19:20:26.920079
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()

    setting = Setting('timeout', '300')
    setting.plugin = Plugin('action', 'ping')

    config.update_setting(setting)

    setting2 = Setting('proxy', 'http://41.42.43.44')
    setting2.plugin = Plugin('cloud', 'libcloud')

    config.update_setting(setting2)

    setting3 = Setting('verbosity', '1')

    config.update_setting(setting3)

    assert len(config.get_settings()) == 2
    assert len(config.get_settings(Plugin('action', 'ping'))) == 1
    assert config.get_settings(Plugin('action', 'ping'))[0].name == 'timeout'
    assert config.get_settings(Plugin('action', 'ping'))[0].value == '300'

# Unit test

# Generated at 2022-06-22 19:20:31.788159
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()                                   # Create empty ConfigData instance
    config_data.update_setting(Setting('foo', 'bar', 'baz'))     # Add a global setting
    assert config_data.get_setting('foo') == 'bar'               # Get the global setting and assert its value


# Generated at 2022-06-22 19:20:40.148923
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
   config_data = ConfigData()
   config_data.get_settings()
   assert config_data.get_settings() == []
   assert config_data._global_settings == {}
   assert config_data._plugins == {}
   config_data.get_settings(plugin=None)
   assert config_data.get_settings(plugin=None) == []
   assert config_data._global_settings == {}
   assert config_data._plugins == {}
   config_data.get_settings(plugin=ConfigData())
   assert config_data.get_settings(plugin=ConfigData()) == []
   assert config_data._global_settings == {}
   assert config_data._plugins == {}


# Generated at 2022-06-22 19:20:51.699828
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class Plugin:
        def __init__(self,type,name):
            self.type = type
            self.name = name

    data = ConfigData()

    class Setting:
        def __init__(self,name,value):
            self.name = name
            self.value = value

    setting_1 = Setting('first_name', 'test')
    setting_2 = Setting('last_name', 'test')
    setting_3 = Setting('email', 'test@test.com')

    # Test for global setting
    data.update_setting(setting_1)
    assert(data.get_setting('first_name').name == 'first_name')
    assert(data.get_setting('first_name').value == 'test')

    assert(data.get_setting('last_name') is None)


    # Test for

# Generated at 2022-06-22 19:20:56.697333
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = { 'name': 'setting1', 'value': 'setting1_value' }
    config_data.update_setting(setting)
    assert config_data.get_setting('setting1') == setting


# Generated at 2022-06-22 19:20:59.169738
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert len(cd._global_settings) == 0
    assert len(cd._plugins) == 0


# Generated at 2022-06-22 19:21:01.616830
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data is not None


# Generated at 2022-06-22 19:21:06.132493
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    plugin_defaults = {'foo': 1, 'bar': 'baz'}
    for name, default_value in plugin_defaults.items():
        setting = Setting(name, default_value)
        config.update_setting(setting)

    assert config.get_setting('foo') == 1
    assert config.get_setting('bar') == 'baz'


# Generated at 2022-06-22 19:21:13.890620
# Unit test for constructor of class ConfigData
def test_ConfigData():
    my_config_data_obj = ConfigData()
    my_config_data_obj.update_setting("Setting1")
    my_config_data_obj.update_setting("Setting2")
    my_config_data_obj.update_setting("Setting2", "Plugin1")
    my_config_data_obj.update_setting("Setting3", "Plugin1")
    my_config_data_obj.update_setting("Setting3", "Plugin2")
    print("my_config_data_obj._global_settings : ", my_config_data_obj._global_settings)
    print("my_config_data_obj._global_settings.keys() : ", my_config_data_obj._global_settings.keys())
    print("my_config_data_obj._plugins : ", my_config_data_obj._plugins)
   

# Generated at 2022-06-22 19:21:16.605171
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:21:24.114877
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test = ConfigData()

    # test with no settings
    assert test.get_settings() == []

    # test with settings
    test.update_setting(None)
    assert test.get_settings() != []

    # test with matching plugin
    _plugin = Plugin()
    test.update_setting(None, _plugin)
    assert test.get_settings() != []
    assert test.get_settings(_plugin) != []

    # test with non-matching plugin
    assert test.get_settings(Plugin('invalid', 'invalid')) == []



# Generated at 2022-06-22 19:21:26.051240
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert isinstance(cd, ConfigData)

# Generated at 2022-06-22 19:21:28.510623
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert configdata._global_settings == {}
    assert configdata._plugins == {}

# Generated at 2022-06-22 19:21:30.997586
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-22 19:21:34.826911
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    setting = Setting('test', 'TEST', False, False, 'string', 'test', "Test setting", None, 20)
    data.update_setting(setting)
    assert data.get_setting('test')==setting



# Generated at 2022-06-22 19:21:41.948478
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # create data for tests
    config_data = ConfigData()
    base_plugin = BasePlugin('command')

    # test getting settings for global
    config_data.update_setting(ConfigSetting('commands', 'ansible', '[]', 'string', ['list']))
    assert config_data.get_settings() == [ConfigSetting('commands', 'ansible', '[]', 'string', ['list'])]

    # test getting settings for plugin
    config_data.update_setting(ConfigSetting('name', 'ansible', '[]', 'string', ['list']), base_plugin)
    assert config_data.get_settings(base_plugin) == \
           [ConfigSetting('name', 'ansible', '[]', 'string', ['list'])]


# Generated at 2022-06-22 19:21:47.555897
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    """
    :return:
    """
    config_data = ConfigData()
    config_data.update_setting(Setting(
        name='foo',
        value='bar',
        context=Context.DEFAULT,
        origin='/etc/ansible/ansible.cfg:4'
    ))

    assert config_data.get_setting('foo').value == 'bar'


# Generated at 2022-06-22 19:21:51.416898
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

    setting = {"name": "setting1"}
    config_data.update_setting(setting)
    assert config_data.get_settings() == [{"name": "setting1"}]

# Generated at 2022-06-22 19:21:59.853465
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # set up config
    config = ConfigData()

    # create plugin
    from collections import namedtuple
    Plugin = namedtuple('Plugin', ['type', 'name'])
    plugin = Plugin(type='modules', name='test_plugin')

    # create setting
    from collections import namedtuple
    Setting = namedtuple('Setting', ['name', 'value', 'scope'])
    setting = Setting(name='test_setting', value='test_value', scope='global')
    config.update_setting(setting, plugin)

    # get setting
    setting = config.get_setting('test_setting', plugin)
    assert setting.name == 'test_setting'
    assert setting.value == 'test_value'
    assert setting.scope == 'global'


# Generated at 2022-06-22 19:22:11.182483
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Test method on empty object
    assert len(config_data.get_settings()) == 0
    
    # Add two settings for a plugin
    from ansible_collections.ansible.community.plugins.module_utils.config import Setting
    from ansible_collections.ansible.community.plugins.plugins import Plugin
    
    plugin = Plugin("action", "standard", file_name="second.py")
    setting1 = Setting("setting 1", True)
    setting2 = Setting("setting 2", False)
    
    config_data.update_setting(setting1, plugin)
    config_data.update_setting(setting2, plugin)

    # Test set of settings for a specified plugin
    settings = config_data.get_settings(plugin)
    
    assert len(settings) == 2
   

# Generated at 2022-06-22 19:22:18.607599
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert len(config_data.get_settings()) == 0

    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.connection
    from ansible.plugins.loader import connection_loader

    config_data.update_setting(ConfigSetting(
        name=ansible.module_utils.connection.HAS_PARAMIKO,
        plugin=connection_loader.get('paramiko')
    ))

    assert len(config_data.get_settings()) == 1
    assert config_data.get_setting(ansible.module_utils.connection.HAS_PARAMIKO) is not None
    assert config_data.get_setting(ansible.module_utils.connection.HAS_PARAMIKO).value is True



# Generated at 2022-06-22 19:22:23.628704
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(Setting('foo', 'bar'), None)
    config.update_setting(Setting('foo', 'bar'), Plugin('action', 'test'))
    assert config.get_setting('foo') == Setting('foo', 'bar')
    assert config.get_setting('foo', Plugin('action', 'test')) == Setting('foo', 'bar')


# Generated at 2022-06-22 19:22:25.839845
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()

    assert not config._global_settings
    assert not config._plugins


# Generated at 2022-06-22 19:22:34.684339
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()

    # test the get_setting method with default settings
    assert configData.get_setting('default_callback_whitelist') is None
    assert configData.get_setting('host_key_auto_add') is None

    # test the get_setting method with plugins settings
    assert configData.get_setting('allow_unused_vars', Plugin('callback', 'json')) is None
    assert configData.get_setting('allow_unused_vars', Plugin('callback', 'logs')) is None
    assert configData.get_setting('disable_action_plugins', Plugin('strategy', 'linear')) is None
    assert configData.get_setting('disable_action_plugins', Plugin('strategy', 'free')) is None

    # test the get_setting method with not existing settings
    assert config

# Generated at 2022-06-22 19:22:36.474518
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()
    settings = configData.get_settings()
    assert settings == []


# Generated at 2022-06-22 19:22:47.160694
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # get_settings with no parameter returns the global setting
    # We don't have global setting here, so the expected output is an empty list
    expected_settings = []
    assert ConfigData().get_settings() == expected_settings
    # get_settings with a plugin return the setting related to this plugin
    # We don't have setting related to the plugin, so the expected output is an empty list
    assert ConfigData().get_settings(object()) == expected_settings
    # get_settings with a plugin return the setting related to this plugin
    # We have a setting related to the plugin, so the expected output is a list with the setting
    setting = object()
    plugin = object()
    config_data = ConfigData()
    config_data.update_setting(setting, plugin)
    expected_settings = [setting]

# Generated at 2022-06-22 19:22:57.827679
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.common._collections_compat import Dict

    default_setting_value = Dict(
        name='Hello',
        plugin=None,
        value='world'
    )
    example_setting_value = Dict(
        name='Example',
        plugin=Dict(
            type='action',
            name='example'
        ),
        value='example'
    )

    my_config_data = ConfigData()
    my_config_data.update_setting(default_setting_value)
    my_config_data.update_setting(example_setting_value)

    assert(my_config_data.get_setting('Hello').value == 'world')
    assert(my_config_data.get_setting('Example', example_setting_value.plugin).value == 'example')

# Generated at 2022-06-22 19:22:59.729560
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

# Generated at 2022-06-22 19:23:08.388288
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible import constants as C

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.plugins.loader import find_plugin, load_plugin, PluginLoader
    from ansible.plugins.vars import VarsModule

    # Create a context that contains the following structure:
    # - my_host
    #   - my_group
    #   - my_group2
    #     - my_group3
    #       - my_var = global_value
    # - my_host2


# Generated at 2022-06-22 19:23:12.013030
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting("string", "value"))
    assert config_data.get_setting("string") == "value"


# Generated at 2022-06-22 19:23:13.025705
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = config_data.get_setting('some_setting')
    assert setting is None


# Generated at 2022-06-22 19:23:24.294979
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    config_data.update_setting(Setting(name="name1"))
    config_data.update_setting(Setting(name="name2"))
    config_data.update_setting(PluginSetting(name="name3", plugin=Plugin(type="type1", name="name1")))
    config_data.update_setting(PluginSetting(name="name4", plugin=Plugin(type="type2", name="name2")))

    assert config_data.get_setting(name="name1")
    assert config_data.get_setting(name="name2")
    assert config_data.get_setting(name="name3", plugin=Plugin(type="type1", name="name1"))

# Generated at 2022-06-22 19:23:35.637626
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import os
    from ansible.module_utils._text import to_native
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_all_plugin_loaders

    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock

    def _mock_config_data_constructor():

        config_data = ConfigData()


# Generated at 2022-06-22 19:23:42.064146
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin_type = 'myplugin'
    plugin_name = 'myplugin'
    config_data = ConfigData()
    setting = Setting('foo', 'bar', 'string', 'string')
    config_data.update_setting(setting)
    plugin = Plugin(plugin_type, plugin_name)
    config_data.update_setting(setting, plugin)


# Generated at 2022-06-22 19:23:54.012526
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    configdata = ConfigData()

    class Plugin(object):
        def __init__(self, type_, name):
            self.type = type_
            self.name = name

    class Setting(object):
        def __init__(self, name):
            self.name = name

    # initialize plugins and settings
    plugin_1 = Plugin(type_="type_1", name="name_1")
    setting_1 = Setting(name="setting_1")
    configdata.update_setting(setting=setting_1, plugin=plugin_1)

    plugin_2 = Plugin(type_="type_2", name="name_2")
    setting_2 = Setting(name="setting_2")
    configdata.update_setting(setting=setting_2, plugin=plugin_2)


# Generated at 2022-06-22 19:24:04.885485
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    from units.module_utils.connection import Connection
    from units.module_utils.module import Module

    connection = Connection(
        Connection.TYPE_CLI,
        args=dict(
            host='localhost',
            username='username',
            password='password'
        )
    )

    module_test = Module.load_argument_spec(
        config_data=config_data,
        connection=connection,
        module_name='test',
        task_vars=dict()
    )

    assert module_test.params.get('timeout') == 120
    assert module_test.params.get('max_retries') == 3
    assert module_test.params.get('interval') == 15

    setting_timeout = module_test.settings.get('timeout')
    setting_timeout.value

# Generated at 2022-06-22 19:24:06.446585
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print("Testing update_setting method")



# Generated at 2022-06-22 19:24:11.193432
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    assert cd.get_setting('foo') is None
    cd.update_setting('foo')
    assert cd.get_setting('foo') == 'foo'
    assert cd.get_setting('bar') is None


# Generated at 2022-06-22 19:24:18.227299
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin1 = PluginDefinition('TestModule1')
    plugin2 = PluginDefinition('TestModule2')
    data = ConfigData()
    data.update_setting(Setting('test1', 'test1.variable', 'test1-default', 'test1-description'), plugin1)
    data.update_setting(Setting('test2', 'test2.variable', 'test2-default', 'test2-description'), plugin2)
    # Test global setting
    assert len(data.get_settings()) == 1
    assert data.get_setting('test2') is None
    assert data.get_setting('test1')
    # Test per-plugin settings
    assert data.get_setting('test1', plugin1)
    assert data.get_setting('test2', plugin2)
    # There is only 1 setting for 'TestModule1' so get_settings

# Generated at 2022-06-22 19:24:18.694660
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    pass

# Generated at 2022-06-22 19:24:23.851920
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    config_data.update_setting(ConfigSetting(name='ANSIBLE_CALLBACK_PLUGINS'))
    assert len(config_data._global_settings) == 1
    assert config_data.get_settings()[0].name == 'ANSIBLE_CALLBACK_PLUGINS'


# Generated at 2022-06-22 19:24:29.212764
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    s = Setting("test", "bool")
    c.update_setting(s)
    assert c.get_settings() == [s]
    s2 = Setting("test2", "bool")
    c.update_setting(s2, Plugin("test", "connection"))
    assert c.get_settings() == [s]
    assert c.get_settings(Plugin("test", "connection")) == [s2]


# Generated at 2022-06-22 19:24:36.794030
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin1 = Plugin('connection', 'test1')
    plugin2 = Plugin('shell', 'test2')

    config_data = ConfigData()

    # test1 and test2 are both defined in the config
    config_data.update_setting(Setting('timeout', '10', 'int', plugin1, 10))
    config_data.update_setting(Setting('timeout', '10', 'int', plugin2, 10))

    # test3 is not defined in the config
    plugin3 = Plugin('shell', 'test3')

    # timeout is a global setting
    config_data.update_setting(Setting('timeout', '10', 'int', None, 10))
    # should return None
    assert config_data.get_setting('timeout', plugin3) == None

    # should return Setting('timeout', '10', 'int', None, 10)
   

# Generated at 2022-06-22 19:24:45.527613
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import PluginLoader

    cd = ConfigData()

    plugin = PluginLoader('connection', 'netconf', None, 'path', 'config', 'yaml')
    setting = Setting('frobnicate', 'bool', 'frobnicate connection')
    cd.update_setting(setting, plugin)
    assert cd.get_setting('frobnicate', plugin).name == 'frobnicate'
    assert cd.get_setting('frobnicate', plugin).plugin == plugin

    plugin = PluginLoader('connection', 'local', None, 'path', 'config', 'yaml')
    setting = Setting('frobnicate', 'bool', 'frobnicate connection')
    cd.update_setting(setting, plugin)

# Generated at 2022-06-22 19:24:48.081591
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    assert config_data.get_setting("become") is None



# Generated at 2022-06-22 19:24:53.949352
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData() 
    setting_1 = Setting(name='one',
                        value=1,
                        lineno=1,
                        is_optional=True,
                        is_constant=False,
                        is_boolean=False,
                        is_list=False)
    cd.update_setting(setting_1)
    assert setting_1 == cd._global_settings['one']



# Generated at 2022-06-22 19:24:56.591783
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    assert config_data.get_settings() == []


# Generated at 2022-06-22 19:24:57.808621
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-22 19:25:01.345543
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin_type = "plugins_type"
    plugin_name = "plugin1"
    assert None == config_data.get_setting("setting1", Plugin(plugin_type, plugin_name))


# Generated at 2022-06-22 19:25:10.766409
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.utils import plugin_docs
    from ansible.plugins.loader import lookup_loader, cache_loader

    # Get a category of plugins
    category = plugin_docs.get_category('lookup')

    # Load the configured plugins
    config_data = ConfigData()
    lookups = lookup_loader.all(config_data, category)

    # Add a test setting to one of the plugins
    a_setting = Setting('test_setting_1', 'test value 1')
    config_data.update_setting(a_setting, lookups['password'])

    config_data.update_setting(Setting('test_setting_2', 'test value 2'))

    # Check that the setting was added
    assert config_data.get_setting('test_setting_1', lookups['password']) is not None

    # Check that other

# Generated at 2022-06-22 19:25:21.366434
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    assert(config_data.get_settings() == [])
    assert(config_data.get_settings(Config(Config.GLOBAL, Config.GLOBAL, '')) == [])
    assert(config_data.get_settings(Config(Config.CALLBACK, Config.CALLBACK, '')) == [])
    assert(config_data.get_settings(Config(Config.CONNECTION, Config.CONNECTION, '')) == [])
    assert(config_data.get_settings(Config(Config.CACHE, Config.CACHE, '')) == [])
    assert(config_data.get_settings(Config(Config.SHELL, Config.SHELL, '')) == [])

# Generated at 2022-06-22 19:25:26.195972
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    moduleTest = ConfigData()
    setting_test = PluginSetting(name="foo", value="bar", scope="global")
    moduleTest.update_setting(setting_test)
    assert moduleTest.get_setting(name="foo") == setting_test

# Generated at 2022-06-22 19:25:27.996250
# Unit test for constructor of class ConfigData
def test_ConfigData():
    h = ConfigData()
    assert h

if __name__ == "__main__":
    test_ConfigData()

# Generated at 2022-06-22 19:25:29.707741
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    assert config_data.get_setting('test') is None

# Generated at 2022-06-22 19:25:32.334109
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    configData.update_setting("test_setting")
    assert configData.get_setting("test_setting") == "test_setting"

# Generated at 2022-06-22 19:25:37.016813
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()

    cs1 = CoreSetting(name="settings1", value="settings1")
    cd.update_setting(cs1)
    
    cs2 = CoreSetting(name="settings2", value="settings2")
    cs2.plugin = Plugin(name="cs2_plugin", type="Module")
    cd.update_setting(cs2)

    cs3 = CoreSetting(name="settings3", value="settings3")
    cs3.plugin = Plugin(name="cs3_plugin", type="Module")
    cd.update_setting(cs3)

    cs4 = CoreSetting(name="settings4", value="settings4")
    cs4.plugin = Plugin(name="cs4_plugin", type="Module")
    cd.update_setting(cs4)


# Generated at 2022-06-22 19:25:47.605255
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import unittest
    import copy
    import sys

    class FakePlugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class FakeSetting(object):
        def __init__(self, name, val, types, origin, plugin=None):
            self.name = name
            self.val = val
            self.types = types
            self.origin = origin
            self.plugin = plugin

    from unit.config import ConfigData

    class TestConfigDataMethods(unittest.TestCase):
        def test_update_setting(self):
            config = ConfigData()
            plugin = FakePlugin("type", "name")
            setting = FakeSetting("name", "val", "types", "origin", plugin)
            config.update_setting(setting)

            self

# Generated at 2022-06-22 19:25:50.101139
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-22 19:25:54.735675
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    setting = Setting('verbosity', 'int', False, 'int')
    config_data.update_setting(setting)

    assert config_data.get_setting('verbosity') == setting


# Generated at 2022-06-22 19:25:56.159901
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data is not None


# Generated at 2022-06-22 19:25:58.504798
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:26:08.887930
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test when plugin is None
    from ansible.module_utils.common.config import Setting, StringType
    setting1 = Setting('test_string', 'test_value', StringType, 'test_type', 'test_option')
    setting2 = Setting('test_string2', 'test_value2', StringType, 'test_type', 'test_option')
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    assert config_data.get_setting('test_string') == setting1
    assert config_data.get_setting('test_string2') == setting2
    assert config_data.get_setting('test_string') != setting2

    # Test when plugin is not None
    from ansible.plugins.loader import Plugin

# Generated at 2022-06-22 19:26:10.880889
# Unit test for constructor of class ConfigData
def test_ConfigData():
    test_obj = ConfigData()
    print(test_obj)

# Generated at 2022-06-22 19:26:20.008192
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data=ConfigData()
    config_data.update_setting(Setting("foo", "bar"))
    config_data.update_setting(Setting("foo2", "bar2"))
    config_data.update_setting(Setting("foo3", "bar3"))

    setting=config_data.get_setting("foo")
    assert setting.name == "foo"
    assert setting.default == "bar"
    assert setting.origin == "defaults"

    setting = config_data.get_setting("foo2")
    assert setting.name == "foo2"
    assert setting.default == "bar2"
    assert setting.origin == "defaults"

    setting = config_data.get_setting("foo3")
    assert setting.name == "foo3"
    assert setting.default == "bar3"
    assert setting.origin

# Generated at 2022-06-22 19:26:21.838501
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-22 19:26:26.163560
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting("Name_1", "Value_1")
    config_data.update_setting("Name_2", "Value_2")
    assert config_data.get_setting("Name_1") == "Value_1"
    assert config_data.get_setting("Name_2") == "Value_2"


# Generated at 2022-06-22 19:26:28.830370
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert hasattr(configdata, '_global_settings')
    assert hasattr(configdata, '_plugins')


# Generated at 2022-06-22 19:26:36.664273
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    config_data.update_setting(Setting('setting_1', 'test', 'global'))
    assert config_data.get_setting('setting_1').name == 'setting_1'

    plugin = Plugin('test', 'foo', 'test_plugin')
    config_data.update_setting(Setting('setting_2', 'test', 'global', plugin))
    assert config_data.get_setting('setting_2', plugin).name == 'setting_2'

    assert config_data.get_setting('setting_2').name == 'setting_1'
    assert config_data.get_setting('setting_1', plugin).name == 'setting_2'


# Generated at 2022-06-22 19:26:41.315742
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    assert config_data.get_settings() == []

    config_data.update_setting(Setting(name='foo'))
    assert config_data.get_settings() == [Setting(name='foo')]


# Generated at 2022-06-22 19:26:48.624577
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    plugin = Plugin(name='test_plugin', type='module')
    setting = Setting(name='foo', value='bar', plugin=plugin)

    config_data.update_setting(setting)

    assert len(config_data.get_settings(plugin=plugin)) == 1
    assert config_data.get_settings(plugin=plugin)[0] == setting

# Generated at 2022-06-22 19:27:00.404115
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting = {
        'name': 'key',
        'value': 'value',
        'origin': 'origin',
        'plugin': None,
        'plugin_name': 'plugin_name'
    }
    plugin = {
        'type': 'type',
        'name': 'name'
    }

    config_data = ConfigData()
    config_data.update_setting(setting)

    assert config_data.get_setting('key')['name'] == 'key'
    assert config_data.get_setting('key')['value'] == 'value'
    assert config_data.get_setting('key')['origin'] == 'origin'
    assert config_data.get_setting('key')['plugin'] is None
    assert config_data.get_setting('key')['plugin_name'] == 'plugin_name'
   

# Generated at 2022-06-22 19:27:09.503978
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugins = [Plugin('cache', 'fact_cache'), Plugin('connection', 'local'),
               Plugin('callback', 'json'), Plugin('shell', 'powershell')]
    config_data = ConfigData()
    settings = []
    for plugin in plugins:
        settings.append(Setting(plugin=plugin))
    config_data.update_setting(settings[0])
    config_data.update_setting(settings[1])
    config_data.update_setting(settings[2])
    config_data.update_setting(settings[3])
    settings = config_data.get_settings()
    assert isinstance(settings, list)
    assert len(settings) == 4
    for setting in settings:
        assert isinstance(setting, Setting)
    settings = config_data.get_settings(plugins[0])

# Generated at 2022-06-22 19:27:12.533019
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:27:13.338311
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    assert True

# Generated at 2022-06-22 19:27:14.338973
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data is not None

# Generated at 2022-06-22 19:27:17.424753
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    a = ConfigData()
    s = ConfigData._Setting(name='test', value='test')
    a.update_setting(s)
    assert s.name == a.get_setting('test').name


# Generated at 2022-06-22 19:27:23.228195
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    #get_settings must return a list
    assert isinstance(data.get_settings(), list)
    assert data.get_settings() == []
    data.update_setting(Setting('plugins'))
    data.update_setting(Setting('connection'))
    assert len(data.get_settings()) == 2


# Generated at 2022-06-22 19:27:31.664655
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Create config data object
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)

    # Initialize plugin_settings and test_plugin_settings
    plugin_settings = []
    test_plugin_settings = []

    # Update and get test_plugin setting
    for i in range(3):
        plugin_setting = PluginSetting(str(i), str(i), 'test_plugin')
        plugin_settings.append(plugin_setting)
        config_data.update_setting(plugin_setting)
    test_plugin_settings = config_data.get_settings(plugin_setting.plugin)

    assert test_plugin_settings == plugin_settings


# Generated at 2022-06-22 19:27:43.412046
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    global_settings = {'a': 1, 'b': 2, 'c': 3}
    plugins = {
        'plugin_type1': {
            'plugin_name1': {'a': 4, 'b': 5, 'd': 6},
            'plugin_name2': {'a': 7, 'c': 8, 'd': 9}
        },
        'plugin_type2': {
            'plugin_name1': {'a': 10, 'e': 11, 'f': 12},
            'plugin_name2': {'d': 13, 'e': 14, 'f': 15}
        }
    }
    config_data = ConfigData()
    config_data._global_settings = global_settings
    config_data._plugins = plugins
    assert config_data.get_settings() == global_settings.values()



# Generated at 2022-06-22 19:27:52.599325
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from yaml import load
    from collections import namedtuple

    from ansible.plugins.loader import plugin_loader
    from ansible.plugins.loader import find_plugin

    # Make a fake plugin object which implements the get_setting(setting) method
    class FakePlugin(object):

        plugin_type = 'test'

        def __init__(self, name):
            self.name = name
            self.options = {}

            self.options_file = find_plugin(self.plugin_type, self.name) + '.yml'
            with open(self.options_file) as f:
                self.options = load(f.read())

        def get_option(self, option):
            return self.options.get(option)

    # Instantiate a ConfigData object
    config_data = ConfigData()

    # Instantiate a

# Generated at 2022-06-22 19:27:56.317797
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    setting = ConfigSetting("source", "a/b/c", "global", Plugin("cache", "cache"))
    config_data.update_setting(setting)

    assert config_data.get_setting("source") == setting, "Fail: config_data.get_setting(source) == setting"



# Generated at 2022-06-22 19:28:03.343328
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.plugins.loader import config_loader
    from ansible.plugins.setting import PluginSetting
    from ansible.plugins.action.get_facts import Plugin as GetFactsPlugin
    from ansible.plugins.action.collect_facts import Plugin as CollectFactsPlugin
    from ansible.plugins.action.setup import Plugin as SetupPlugin

    setting_data = {'name': 'force_ansible_config', 'plugin_type': 'action',
                    'plugin_name': 'get_facts', 'description': 'Force the use of the ansible config',
                    'enabled': True}

    config = ConfigData()
    get_facts_plugin = GetFactsPlugin()
    setting = PluginSetting(**setting_data)

    config.update_setting(setting, get_facts_plugin)


# Generated at 2022-06-22 19:28:03.937243
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()

# Generated at 2022-06-22 19:28:05.649997
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()
    assert(len(configdata.get_settings()) == 0)


# Generated at 2022-06-22 19:28:06.911612
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    assert configData is not None


# Generated at 2022-06-22 19:28:12.494637
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_plugin', 'test_plugin', 'test_default', 'test_value'))
    assert config_data.get_setting('test_plugin') == Setting('test_plugin', 'test_plugin', 'test_default', 'test_value')
    assert config_data.get_setting('other_plugin') is None


# Generated at 2022-06-22 19:28:23.335472
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from collections import namedtuple
    from ansiblelint.config import Rule, RulesCollection, Setting, DEFAULTS

    # rule
    inst = Rule('ansible-lint')
    inst.id = 'ANSIBLE0004'
    inst.tags = ['formatting']
    inst.shortdesc = 'This is a shortdesc'
    inst.description = 'This is a description'
    inst.severity = 'MEDIUM'
    inst.add_match(['name=value'])
    inst.add_match(['name=othervalue'])
    inst.add_invalid(['notname=value'])
    inst.add_invalid(['notname=othervalue'])
    inst.version_added = 'v2.0'
    inst.removed_in_version = 'v4.0'

# Generated at 2022-06-22 19:28:32.472674
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()

    # Method update_setting
    # Case 1: No plugin
    setting1 = Setting(name='setting1', default_value='setting1_value',
                       description='setting1 description', aliases=[])
    config.update_setting(setting1)
    assert config.get_setting('setting1') == setting1

    # Case 2: Non-existing plugin
    setting2 = Setting(name='setting2', default_value='setting2_value',
                       description='setting2 description', aliases=[])
    plugin = Plugin(type='Non-existing', name='Non-existing')
    config.update_setting(setting2, plugin)
    assert config.get_setting('setting2', plugin) == setting2

    # Case 3: Existing plugin

# Generated at 2022-06-22 19:28:36.836446
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    import types

    ansible_instance = ConfigData()

    setting_name = 'foo'
    setting_value = 'bar'

    setting_names = ['foo', 'bar']
    setting_values = ['bar', 'foo']

    for setting_name, setting_value in zip(setting_names, setting_values):
        ansible_instance.update_setting(Setting(setting_name, setting_value))

    for setting_name, setting_value in zip(setting_names, setting_values):
        assert ansible_instance.get_setting(setting_name).value == setting_value



# Generated at 2022-06-22 19:28:47.932016
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cfg = ConfigData()
    cfg.update_setting(ConfigSetting('setting1', 'global', 'global'))
    cfg.update_setting(ConfigSetting('setting2', 'type1', 'name1'))
    cfg.update_setting(ConfigSetting('setting3', 'type2', 'name2'))
    assert cfg.get_setting('setting1').name == 'setting1'
    assert cfg.get_setting('setting2').name == 'setting2'
    assert cfg.get_setting('setting3').name == 'setting3'


# Generated at 2022-06-22 19:28:59.264270
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()

    setting_1 = Setting()
    setting_1.name = 'setting_1'
    setting_1.value = 'global'
    setting_1.origin = ''
    setting_1.key = ''

    setting_2 = Setting()
    setting_2.name = 'setting_2'
    setting_2.value = 'plugin'
    setting_2.origin = ''
    setting_2.key = ''

    plugin = Plugin()
    plugin.type = 'testplugin'
    plugin.name = 'test'

    config.update_setting(setting_1)
    config.update_setting(setting_2, plugin)

    assert config.get_setting('setting_1') == setting_1
    assert config.get_setting('setting_2') == setting_1
    assert config.get_setting

# Generated at 2022-06-22 19:29:07.717974
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    setting1 = Setting('a','x','x','x','x','x')
    setting2 = Setting('b','y','y','y','y','y')
    config.update_setting(setting1,None)
    config.update_setting(setting2,None)
    assert config.get_settings()[0].name == 'a'
    assert config.get_settings()[1].name == 'b'
    assert len(config.get_settings()) == 2


# Generated at 2022-06-22 19:29:12.059145
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:29:13.434936
# Unit test for constructor of class ConfigData
def test_ConfigData():
        configdata = ConfigData()

# Generated at 2022-06-22 19:29:14.470080
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    assert configData is not None


# Generated at 2022-06-22 19:29:25.995768
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class TestPlugin(object):

        def __init__(self, type, name):
            self.type = type
            self.name = name

    cd = ConfigData()
    cd.update_setting(Setting('gsetting', 'value'))
    cd.update_setting(Setting('psetting', 'value', TestPlugin('type', 'name')))
    cd.update_setting(Setting('plugin_setting', 'value', TestPlugin('type', 'name')))

    print(cd.get_setting('gsetting'))

    # Make sure no None types are returned
    print(list(filter(lambda x: x is None,cd.get_settings())))

    # Make sure no None types are returned
    print(list(filter(lambda x: x is None,cd.get_settings(TestPlugin('type', 'name')))))

# Generated at 2022-06-22 19:29:27.495100
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-22 19:29:30.998912
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:29:39.001480
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    myConfigData = ConfigData()
    print(myConfigData)
    print(myConfigData._global_settings)
    myConfigData.update_setting('', '')
    myConfigData.update_setting('', '')
    myConfigData.update_setting('', '')
    myConfigData.update_setting('', '')
    myConfigData.update_setting('', '')
    myConfigData.update_setting('', '')
    myConfigData.update_setting('', '')
    myConfigData.update_setting('', '')
    print(myConfigData._global_settings)

test_ConfigData_update_setting()

# Generated at 2022-06-22 19:29:40.437370
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert isinstance(data, ConfigData)

# Generated at 2022-06-22 19:29:51.449470
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()
    configdata.update_setting(setting=Setting('name1', 'value1'))
    configdata.update_setting(setting=Setting('name3', 'value3'))
    configdata.update_setting(setting=Setting('name2', 'value2'))
    configdata.update_setting(setting=Setting('name5', 'value5'), 
                              plugin=Plugin('type1', 'name1'))
    configdata.update_setting(setting=Setting('name4', 'value4'), 
                              plugin=Plugin('type1', 'name1'))
    configdata.update_setting(setting=Setting('name2', 'value2'), 
                              plugin=Plugin('type1', 'name1'))

# Generated at 2022-06-22 19:29:59.190154
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.config.setting import Setting

    # Arrange
    plugin = 'MyPlugin'
    plugin_type = 'PluginType'
    setting_value = 'value'
    setting = Setting(name=plugin, plugin_type=plugin_type, value=setting_value)

    config = ConfigData()

    # Act
    config.update_setting(setting)
    config.update_setting(setting, plugin)

    # Assert
    assert setting_value == config.get_setting(plugin)
    assert setting_value == config.get_setting(plugin, plugin)

# Generated at 2022-06-22 19:30:00.350135
# Unit test for constructor of class ConfigData
def test_ConfigData():
    test = ConfigData()
    assert test != None


# Generated at 2022-06-22 19:30:07.674792
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import pytest

    cd = ConfigData()

    class PluginType(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name
            self.options = {}

    class Setting(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value

    # global setting
    s = Setting(name='foo', value='bar')
    cd.update_setting(s)
    assert cd._global_settings[s.name] == s

    # plugin setting
    p = PluginType('some_type', 'some_name')
    s = Setting(name='foo', value='baz')
    cd.update_setting(s, plugin=p)