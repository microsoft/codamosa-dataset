

# Generated at 2022-06-22 19:20:07.694469
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert(config_data)

# Generated at 2022-06-22 19:20:13.214656
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_data = ConfigData()
    test_setting = {'display_name': 'level', 'name': 'level', 'value': 'high', 'scope': 'global', 'origin': 'global', 'default': None, 'plugin': None}
    plugin = None
    test_data.update_setting(test_setting,plugin)
    setting = test_data.get_setting("level")
    assert (setting == test_setting)


# Generated at 2022-06-22 19:20:21.398257
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    print("test_ConfigData_get_setting")

    cd =ConfigData()

    setting = Setting("test1","value1","test1 desc")
    setting1 = Setting("test2", "value2", "test2 desc")
    setting2 = Setting("test3", "value3", "test3 desc")

    p = Plugin("test_type1","test_name1", "test desc")
    p1 = Plugin("test_type2", "test_name2", "test desc")
    p2 = Plugin("test_type2", "test_name1", "test desc")

    cd.update_setting(setting,None)
    cd.update_setting(setting1,None)
    cd.update_setting(setting2, p)
    cd.update_setting(setting2, p1)

# Generated at 2022-06-22 19:20:22.994994
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    assert config_data.get_settings('foobar') == []

# Generated at 2022-06-22 19:20:34.374840
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Arrange
    data = ConfigData()
    new_setting = Setting("setting_g", "value_g", None)
    data.update_setting(new_setting)
    new_setting = Setting("setting_g1", "value_g1", None)
    data.update_setting(new_setting)
    new_plugin_1 = Plugin("type1", "name1")
    new_setting = Setting("setting_1", "value_1", new_plugin_1)
    data.update_setting(new_setting, new_plugin_1)
    new_plugin_2 = Plugin("type1", "name2")
    new_setting = Setting("setting_2", "value_2", new_plugin_2)
    data.update_setting(new_setting, new_plugin_2)

    # Act

# Generated at 2022-06-22 19:20:36.772536
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None, 'Unable to create an instance of ConfigData'


# Generated at 2022-06-22 19:20:38.730521
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test_object = ConfigData()
    test_value = test_object.get_setting()
    assert test_value == None


# Generated at 2022-06-22 19:20:41.082482
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
   config_data = ConfigData()
   setting = ConfigParser.ConfigParser()
   setting.set('section', 'name', 'value')
   config_data.update_setting(setting)


# Generated at 2022-06-22 19:20:49.101040
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible_collections.sensu.sensu_go.plugins.module_utils.sensu_go.api import corev2 as core
    config_data = ConfigData()
    plugin = core.Plugin(name="test-1", type="check")
    setting = core.PluginSetting(name="test-1", plugin=plugin)
    config_data.update_setting(setting)
    assert config_data._plugins["check"]["test-1"]["test-1"] == setting


# Generated at 2022-06-22 19:20:54.379766
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}
    setting = {'name': 'test'}
    plugin = {'type': 'test', 'name': 'test'}
    config_data.update_setting(setting, plugin)
    assert len(config_data._global_settings) == 0
    assert config_data._plugins["test"]["test"] == {'test': {'name': 'test'}}


# Generated at 2022-06-22 19:20:55.984984
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert 1 == 2



# Generated at 2022-06-22 19:20:58.727931
# Unit test for constructor of class ConfigData
def test_ConfigData():

    configdata = ConfigData()

    # test empty ConfigData
    assert len(configdata._global_settings) == 0
    assert len(configdata._plugins) == 0



# Generated at 2022-06-22 19:20:59.672039
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    assert(True)

# Generated at 2022-06-22 19:21:01.201969
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0



# Generated at 2022-06-22 19:21:03.022305
# Unit test for constructor of class ConfigData
def test_ConfigData():
    
    obj = ConfigData()
    assert obj._global_settings == {}
    assert obj._plugins == {}


# Generated at 2022-06-22 19:21:05.969656
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    setting = Setting('foo', 'bar')
    setting_plugin = Plugin('type','name')
    config.update_setting(setting)
    config.update_setting(setting_plugin)
    import pprint
    pprint.pprint(config)



# Generated at 2022-06-22 19:21:06.921587
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-22 19:21:08.481966
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data is not None
    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-22 19:21:15.200647
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.plugins import connection_loader, module_loader
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.doc_fragments.connection import ConnectionDocumentationFragment
    from ansible.plugins.doc_fragments.module import ModuleDocumentationFragment
    import os

    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'plugins')

    # Create instances of PluginLoader, ConfigData and the documentation fragments
    config_data = ConfigData()

# Generated at 2022-06-22 19:21:18.854532
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()

    assert configdata is not None
    assert configdata._global_settings is not None
    assert configdata._plugins is not None


# Generated at 2022-06-22 19:21:23.313286
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings(): 

    from collections import namedtuple                                                                                                                    

    Setting = namedtuple('Setting', ['name', 'default', 'inheritance'])

    cd = ConfigData()
    cd.update_setting(Setting('test', 'test', 'test'))

    assert cd.get_settings()[0].name == 'test'



# Generated at 2022-06-22 19:21:35.087495
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(setting=setting("setting1", "setting_value1", "string"),
                               plugin=plugin("plugin1", "plugin_type1"))
    config_data.update_setting(setting=setting("setting2", "setting_value2", "string"),
                               plugin=plugin("plugin2", "plugin_type2"))
    config_data.update_setting(setting=setting("setting3", "setting_value3", "string"))

# Generated at 2022-06-22 19:21:40.823373
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    data = ConfigData()
    assert (data.get_setting('foo') is None)

    data.update_setting(Setting('foo', 'bar', 'baz'))
    assert (data.get_setting('foo') == Setting('foo', 'bar', 'baz'))

    plugin = Plugin('os', 'redhat')
    data.update_setting(Setting('foo', 'bar', 'baz', plugin=plugin))
    assert (data.get_setting('foo', plugin=plugin) == Setting('foo', 'bar', 'baz', plugin=plugin))


# Generated at 2022-06-22 19:21:46.300629
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = MockPlugin(type='action', name='test')

    # test to get a non-existing setting
    assert config_data.get_setting('non-existent') is None
    assert config_data.get_setting('non-existent', plugin) is None

    # test to get an existing setting
    setting = MockSetting(name='some-setting')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('some-setting') is None
    assert config_data.get_setting('some-setting', plugin) == setting


# Generated at 2022-06-22 19:21:49.330030
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test1', 'value1'))
    assert config_data.get_setting('test1') == 'value1'


# Generated at 2022-06-22 19:21:58.870782
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(ConfigSetting(name='ANSIBLE_PRIVATE_KEY_FILE', value='value'))
    config.update_setting(ConfigSetting(name='ANSIBLE_SSH_ARGS', value='value'))
    config.update_setting(ConfigSetting(name='ANSIBLE_ROLES_PATH', value='value'))
    config.update_setting(ConfigSetting(name='ANSIBLE_GATHERING', value='value'))
    config.update_setting(ConfigSetting(name='ANSIBLE_GATHER_SUBSET', value='value'))
    config.update_setting(ConfigSetting(name='ANSIBLE_COMMAND_WARNINGS', value='value'))

# Generated at 2022-06-22 19:22:05.735141
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cfg = ConfigData()
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import register_setting, Setting
    s1 = Setting('s1', 'bool', 'default_cfg')
    s2 = Setting('s2', 'bool', 'default_cfg')
    register_setting(cfg, s1)
    register_setting(cfg, s2)
    print(cfg.get_settings())



# Generated at 2022-06-22 19:22:15.467452
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    setting_1 = Setting(name="config1", value="value1")
    setting_2 = Setting(name="config2", value="value2")
    setting_3 = Setting(name="config1", value="value3")
    setting_4 = Setting(name="config4", value="value4", plugin=Plugin(name="plugin1", type="my-type"))

    ## test update_setting for global setting
    configData.update_setting(setting_1)
    configData.update_setting(setting_2)
    configData.update_setting(setting_3)

    assert configData.get_setting("config1") == configData.get_setting("config1")
    assert configData.get_setting("config2") == configData.get_setting("config2")
    assert configData.get_

# Generated at 2022-06-22 19:22:17.937698
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}



# Generated at 2022-06-22 19:22:27.116505
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    c = ConfigData()
    c.update_setting(Setting(name = 'aaa', value = 'bbb'))
    assert c.get_setting('aaa').to_dict() == {'name': 'aaa', 'value': 'bbb'}
    assert c.get_setting('aaa', Plugin(name = 'foo')).to_dict() == {'name': 'aaa', 'value': 'bbb'}
    c.update_setting(Setting(name = 'ccc', value = 'ddd'), Plugin(name='foo'))
    assert c.get_setting('ccc', Plugin(name='foo')).to_dict() == {'name': 'ccc', 'value': 'ddd'}

# Generated at 2022-06-22 19:22:28.558309
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    settings = ConfigData()


# Generated at 2022-06-22 19:22:29.698751
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data._global_settings == {}

# Generated at 2022-06-22 19:22:36.423722
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    plugin = PluginInfo("module_loader", "basic")
    setting = SettingInfo("lookup_plugins", "/path")
    config_data.update_setting(setting)
    assert config_data.get_setting("lookup_plugins") is not None
    assert config_data.get_setting("lookup_plugins", plugin) is None
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting("lookup_plugins") is not None
    assert config_data.get_setting("lookup_plugins", plugin) is not None
    setting.name = "unknown_setting"
    assert config_data.get_setting("unknown_setting", plugin) is None


# Generated at 2022-06-22 19:22:47.161950
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global_1 = Setting("global_1")
    assert global_1.value is None
    config_data = ConfigData()
    assert config_data.get_setting("global_1") is None
    config_data.update_setting(global_1)
    assert config_data.get_setting("global_1") is not None
    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0] == global_1

    plugin_1 = Setting("plugin_1")
    gather_subset = PluginDefinition("gather_subset", "Gather facts", "AnsibleInternal")
    assert len(config_data.get_settings(gather_subset)) == 0
    config_data.update_setting(plugin_1, gather_subset)

# Generated at 2022-06-22 19:22:53.353716
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    config_data.get_setting("foo") == None
    assert config_data.get_setting("foo") == None
    config_data.update_setting([1,2,3])
    config_data.get_setting("foo") == [1,2,3]
    assert config_data.get_setting("foo") == [1,2,3]




# Generated at 2022-06-22 19:22:53.886524
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    pass

# Generated at 2022-06-22 19:23:04.009379
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    print("\n=== Test of ConfigData get_settings method ===")
    from ansible.parsing.plugin_docs import ConfigSetting

    c = ConfigData()

    global_setting = ConfigSetting('test_setting', 'Test setting', 'str', 'default', 'ini', '')
    c.update_setting(global_setting)

    plugin_type = 'test_type'
    plugin_name = 'test_name'
    plugin_setting = ConfigSetting('test_setting', 'Test setting', 'str', 'default', 'ini', '')
    c.update_setting(plugin_setting, plugin_type, plugin_name)

    setting = c.get_setting(plugin_setting.name)
    print("Global setting '{0}' retrieved successfully: {1}".format(plugin_setting.name, setting == plugin_setting))
   

# Generated at 2022-06-22 19:23:05.150420
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

# Generated at 2022-06-22 19:23:08.497688
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:23:10.868437
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    assert isinstance(cd.get_settings(), list)


# Generated at 2022-06-22 19:23:16.809124
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = ConfigSetting("Test_Setting", "test_value", [])
    config_data.update_setting(setting)
    result = config_data.get_setting("Test_Setting")
    assert(result.name == "Test_Setting")
    assert(result.value == "test_value")


# Generated at 2022-06-22 19:23:18.042616
# Unit test for constructor of class ConfigData
def test_ConfigData():

    assert ConfigData() is not None


# Generated at 2022-06-22 19:23:19.675141
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cd = ConfigData()

    assert cd._global_settings == {}
    assert cd._plugins == {}

# Generated at 2022-06-22 19:23:22.581355
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("nonexistent", None) is None
    assert config_data.get_setting("nonexistent", 'plugin') is None


# Generated at 2022-06-22 19:23:30.065631
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    c.update_setting(Setting('ansible_host', '192.168.56.101'), plugin=Plugin('inventory', 'vagrant'))
    print(c.get_setting('ansible_host', plugin=Plugin('inventory', 'vagrant')))
    print(c.get_settings(plugin=Plugin('inventory', 'vagrant')))


# Generated at 2022-06-22 19:23:35.609073
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('key', 'value')
    plugin = Plugin('type', 'name')
    config_data.update_setting(setting)
    assert config_data.get_setting(setting.name) == setting.value
    config_data.update_setting(setting, plugin)
    plugin_setting = config_data.get_setting(setting.name, plugin)
    assert plugin_setting == setting.value
    assert setting == plugin_setting


# Generated at 2022-06-22 19:23:37.538466
# Unit test for constructor of class ConfigData
def test_ConfigData():
    test_config_data = ConfigData()
    assert test_config_data


# Generated at 2022-06-22 19:23:47.775212
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    # This function is monkey patched. Restore functionality after test
    from ansible.module_utils.basic import AnsibleModule
    from ansible.utils.vars import combine_vars

    # Creating an empty ConfigData object
    config_data = ConfigData()
    # Testing the update_setting method
    setting_name = 'test_setting'
    plugin_type = 'test_plugin_type'
    plugin_name = 'test_plugin_name'
    setting_value = 'test_value'
    module_args = {'_ansible_verbosity': 1, setting_name: setting_value}

# Generated at 2022-06-22 19:23:57.227568
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    data = ConfigData()

    # Test different plugin types
    assert len(data.get_settings()) == 0
    assert len(data.get_settings(plugin=Plugin('module', 'ping'))) == 0
    assert len(data.get_settings(plugin=Plugin('connection', 'local'))) == 0
    assert len(data.get_settings(plugin=Plugin('lookup', 'env'))) == 0

    # Create one plugin setting of each type
    data.update_setting(Setting('max_retries', 3, '3 (Default)'), Plugin('connection', 'paramiko'))
    data.update_setting(Setting('gather_timeout', 10, '10 (Default)'), Plugin('plugins', 'facts'))

# Generated at 2022-06-22 19:24:03.654447
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = MockPlugin()
    plugin.name = "test-plugin"
    plugin.type = "connection"
    plugin.path = "/path/to/test-plugin"
    config_data.update_setting("test-setting", plugin=plugin)
    setting = config_data.get_setting("test-setting", plugin=plugin)
    assert setting.name == "test-setting"
    assert setting.value is None


# Generated at 2022-06-22 19:24:09.879489
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = 'plugin'
    setting = 'setting'
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['plugin']['plugin']['setting'] == 'setting'


# Generated at 2022-06-22 19:24:11.004317
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert type(ConfigData()).__name__ == "ConfigData"


# Generated at 2022-06-22 19:24:18.076417
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from units.mock.loader import DictDataLoader
    from ansible.config.manager import ConfigManager

    loader = DictDataLoader({
        '/etc/ansible/ansible.cfg': '',
        '/path/to/ansible.cfg': '',
        '/home/user/ansible.cfg': '',
    })

    config_manager = ConfigManager(loader=loader, conf_file='/etc/ansible/ansible.cfg')
    config_data = config_manager.data

    assert set(config_data.get_settings()) == set([
        'connection_plugins',
        'callback_plugins',
        'shell_plugins',
        'strategy_plugins',
        'lookup_plugins',
        'lookup_terminus',
    ])


# Generated at 2022-06-22 19:24:24.127088
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    setting1 = Setting(name = 'setting 1')
    setting2 = Setting(name = 'setting 2')
    setting3 = Setting(name = 'setting 3')

    plugin = Plugin(name = 'test_plugin', type = 'lookup')

    config_data = ConfigData()
    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin)
    config_data.update_setting(setting3)

    settings = config_data.get_settings()
    assert len(settings) == 3


# Generated at 2022-06-22 19:24:32.196499
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = MockPlugin(type="foo", name="bar")
    setting_1 = MockSetting(name="setting_1")
    setting_2 = MockSetting(name="setting_2")
    setting_3 = MockSetting(name="setting_3")
    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2, plugin)
    config_data.update_setting(setting_3, plugin)
    assert(config_data.get_setting("setting_1") is None)
    assert(config_data.get_setting("setting_2", plugin) is None)
    assert(config_data.get_setting("setting_3", plugin) is None)
    

# Generated at 2022-06-22 19:24:38.535568
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data._global_settings = {"key1": "value1", "key2": "value2"}
    assert config_data.get_setting("key1") == "value1"
    assert config_data.get_setting("key2") == "value2"


# Generated at 2022-06-22 19:24:46.240899
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.plugins.loader import plugin_loader
    # remove previously imported plugins
    plugin_loader._module_cache.clear()
    plugin_loader._plugin_cache.clear()
    plugin_loader.package_cache.clear()
    plugin_loader._subdir_cache.clear()

    data = ConfigData()
    setting = plugin_loader.Setting('test', dict(
        default='test default',
        description='Test description',
        type='str'
    ))

    data.update_setting(setting)
    assert data.get_setting('test') is setting

    setting = plugin_loader.Setting('test', dict(
        default=False,
        description='Test2 description',
        type='bool'
    ))

# Generated at 2022-06-22 19:24:47.061994
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-22 19:24:48.525825
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    output = config_data.get_settings()
    assert output == [], "Test failed"



# Generated at 2022-06-22 19:24:55.234254
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    assert not config_data.get_settings()

    settings = [
        {'name': 'name', 'value': 'value'},
        {'name': 'name', 'value': 'value'},
    ]

    for s in settings:
        config_data.update_setting(Setting(**s))

    settings = config_data.get_settings()
    assert len(settings) == 2
    for s in settings:
        assert isinstance(s, Setting)



# Generated at 2022-06-22 19:24:58.332212
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin_name = PluginName("component", "name")
    config_data = ConfigData()
    config_data.update_setting(Setting("key", "value"), plugin_name)
    assert config_data.get_setting("key", plugin_name) is not None



# Generated at 2022-06-22 19:25:00.060433
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert isinstance(data, ConfigData)



# Generated at 2022-06-22 19:25:02.906898
# Unit test for constructor of class ConfigData
def test_ConfigData():
    global_settings = {}
    plugins = {}
    config_data = ConfigData()
    plugins_data = config_data._plugins
    global_data = config_data._global_settings

#Unit test for method get_setting of class ConfigData

# Generated at 2022-06-22 19:25:08.336814
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('ansible_python_interpreter', '/usr/bin/python'))
    assert config_data.get_setting('ansible_python_interpreter') == '/usr/bin/python'

test_ConfigData_get_setting()


# Generated at 2022-06-22 19:25:14.063455
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # verify get_setting returns None when config setting name is not present in global settings
    assert config_data.get_setting('foo') is None

    config_data._global_settings['foo'] = 'bar'

    # verify get_setting returns config setting from global config settings
    assert config_data.get_setting('foo') == 'bar'

    # verify get_setting returns None when config setting name is not present in global settings
    assert config_data.get_setting('foo') is not None


# Generated at 2022-06-22 19:25:22.882149
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint.plugin_manager import PluginManager
    plugin_manager = PluginManager()

    class TestPlugin(object):
        def __init__(self, name, plugin_type):
            self.name = name
            self.type = plugin_type
            plugin_manager.register(self)

    class TestSetting(object):
        def __init__(self, name, plugin=None):
            self.name = name
            self.plugin = plugin

        def __eq__(self, other):
            return self.name == other.name and self.plugin == other.plugin

    settings_data = ConfigData()

    assert settings_data.get_settings() == []

    settings_data.update_setting(TestSetting('test_setting'))
    assert settings_data.get_settings() == [TestSetting('test_setting')]



# Generated at 2022-06-22 19:25:24.759782
# Unit test for constructor of class ConfigData
def test_ConfigData():
    settings = ConfigData()
    assert settings is not None

# Generated at 2022-06-22 19:25:30.359883
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    setting = Setting('foo_setting', 'bar_value')
    config.update_setting(setting)
    assert 'foo_setting' in config._global_settings
    assert config._global_settings['foo_setting'].value == 'bar_value'
    assert config.get_setting('foo_setting') == setting
    assert config.get_setting('foo_setting').value == 'bar_value'


# Generated at 2022-06-22 19:25:41.250642
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()

    #global_setting_1 is global setting
    global_setting_1 = ConfigSetting('global_setting_1', 'global_setting_1')
    config.update_setting(global_setting_1)

    #global_setting_2 is global setting
    global_setting_2 = ConfigSetting('global_setting_2', 'global_setting_2')
    config.update_setting(global_setting_2)

    #plugin_setting_1 is plugin setting
    plugin_setting_1 = ConfigSetting('plugin_setting_1', 'plugin_setting_1')
    config.update_setting(plugin_setting_1, Plugin('test_plugin_1', 'test_plugin_type_1'))

    #plugin_setting_2 is plugin setting

# Generated at 2022-06-22 19:25:50.126500
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Add a global setting
    setting = ConfigOption('name', 'default')
    config_data.update_setting(setting)

    # Get all settings
    settings = config_data.get_settings()
    assert len(settings) == 1
    assert settings[0] == setting

    # Get a specific setting
    setting = config_data.get_setting('name')
    assert setting.name == 'name'

    # Add a plugin setting
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader('action').find_plugin('file')
    setting = ConfigOption('foo', 'bar')
    config_data.update_setting(setting, plugin)

    # Get all settings for this plugin
    settings = config_data.get_settings(plugin)
    assert len(settings) == 1


# Generated at 2022-06-22 19:26:00.551098
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    # test global setting
    global_setting = ConfigSetting("global setting", [], "global config setting", "global", "global", {})
    config_data.update_setting(global_setting)
    assert("global setting" in config_data._global_settings)
    assert("global setting" in config_data._global_settings)
    assert("global setting" in config_data._plugins["global"]["global"])

    # test global action plugin
    action_plugin = ConfigPlugin("test_action_plugin.py", "action", "action", "", {})
    action_setting = ConfigSetting("action setting", [], "action config setting", "action", "action", {})
    config_data.update_setting(action_setting, action_plugin)

# Generated at 2022-06-22 19:26:08.623936
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0

    config_data = ConfigData()
    config_data._global_settings['setting1'] = 'value1'
    assert len(config_data.get_settings()) == 1

    config_data = ConfigData()
    config_data._plugins = {}
    config_data._plugins['type1'] = {'name1': {'k1': 'v1', 'k2': 'v2'}}
    assert len(config_data.get_settings()) == 0
    assert len(config_data.get_settings(plugin=ConfigPlugin(type='type1', name='name1'))) == 2

# Generated at 2022-06-22 19:26:11.460687
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data._global_settings == {}, "_global_settings should be empty"
    assert config_data._plugins == {}, "_plugins should be empty"


# Generated at 2022-06-22 19:26:13.108848
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    configData.update_setting("test")

# Generated at 2022-06-22 19:26:21.472100
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    test_case = []
    test_case.append([None, {"name": "test_case_1", "value": "test_1_value"}, None, {"name": "test_case_1", "value": "test_1_value"}])
    test_case.append([None, {"name": "test_case_1", "value": "test_1_value"}, {"type": "test_case_1_type"}, None])
    test_case.append([None, {"name": "test_case_1", "value": "test_1_value"},
                    {"type": "test_case_1_type", "name": "test_1_name"}, None])

# Generated at 2022-06-22 19:26:26.708852
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    confdata = ConfigData()
    confdata.update_setting("/foo/bar", plugin=None)
    confdata.update_setting("/foo/bar/bar", plugin=None)
    confdata.update_setting("/foo/bar/foo", plugin=None)
    confdata.update_setting("/foo/bar/foo/foo", plugin=None)
    print(confdata)


if __name__ == '__main__':
    test_ConfigData_update_setting()

# Generated at 2022-06-22 19:26:35.898801
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    # test update on setting where plugin is None
    setting = ConfigSetting(None, 'global', 'global_setting', 'value', None,
                            'something', 'something', 'something', None, None)
    config_data.update_setting(setting)
    assert_that(config_data._global_settings[setting.name], is_(setting))

    # test update on setting where plugin is not None
    setting2 = ConfigSetting(None, 'core', 'core_setting', 'value', None,
                             'something', 'something', 'something', None, None)
    config_data.update_setting(setting2)
    assert_that(config_data._plugins[setting2.type][setting2.name][setting2.name], is_(setting2))



# Generated at 2022-06-22 19:26:37.998929
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-22 19:26:39.032628
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data is not None

# Generated at 2022-06-22 19:26:42.742605
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    myConfigData = ConfigData()
    myConfigData.update_setting(ConfigSetting(name="test"), None)
    assert (myConfigData.get_setting("test") is not None)
    assert (myConfigData.get_setting("test").name == "test")


# Generated at 2022-06-22 19:26:47.526489
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_config = ConfigData()
    test_setting = {'name': 'test_setting'}
    test_config.update_setting(test_setting)
    assert test_config._global_settings['test_setting'] == test_setting

# Generated at 2022-06-22 19:26:49.934250
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-22 19:27:01.421251
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # Instance without parameters
    config_data = ConfigData()

    # Verify member variables are empty
    assert not config_data._global_settings
    assert not config_data._plugins

    # Set a global setting
    global_setting = dict(name='global_setting', default=12345, value=None, vars=['all'])
    config_data.update_setting(global_setting)

    # Set a plugin setting
    plugin = dict(name='plugin', type='prompt')
    plugin_setting = dict(name='plugin_setting', default=None, value=12345, vars=['all'])
    config_data.update_setting(plugin_setting, plugin)

    # Verify global setting is set
    assert 'global_setting' in config_data._global_settings
    assert 'all' in config_data._global_

# Generated at 2022-06-22 19:27:06.584615
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Create a config data object
    config_data = ConfigData()

    # Create a new setting
    setting1 = ConfigSetting('setting1', 'description', 'default')

    # Update the setting to the config data
    config_data.update_setting(setting1)

    # Assert that the get_setting method returns the expected result
    assert config_data.get_setting('setting1') == setting1


# Generated at 2022-06-22 19:27:09.396259
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cd.update_setting(Setting('prefix', 'a string'), Plugin('file', 'prefix'))
    assert cd.get_setting('prefix', Plugin('file', 'prefix')) == Setting('prefix', 'a string')

# Generated at 2022-06-22 19:27:15.201912
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    plugin = Plugin('network.ios.ios_interface', 'intf1')
    setting = Setting('int_type', 'ethernet', 'String')
    configData.update_setting(setting, plugin)
    settings = configData.get_settings(plugin)
    assert(len(settings) == 1)


# Generated at 2022-06-22 19:27:20.961723
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    plugin = Plugin(name='test', type='connection')
    setting = Setting(name='identity_file', plugin=plugin, value='path/to/file', origin='file', scope='host')
    config_data.update_setting(setting)

    assert config_data.get_settings() == [setting]
    assert config_data.get_settings(plugin) == [setting]


# Generated at 2022-06-22 19:27:23.321389
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data


# Generated at 2022-06-22 19:27:30.405738
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    obj = ConfigData()

    # Case 1: Updating global setting
    plugin = None
    setting = ConfigSetting(name='filename')
    obj.update_setting(setting,plugin)
    assert obj._global_settings['filename'] == setting

    # Case 2: Updating plugin setting
    plugin = ConfigPlugin(type='cache', name='jsonfile')
    setting = ConfigSetting(name='filename')
    obj.update_setting(setting,plugin)
    assert obj.get_setting(setting.name, plugin) == setting


# Generated at 2022-06-22 19:27:36.988410
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.basic import AnsiblePlugin 
    from ansible.module_utils.common.collections import ImmutableDict

    class MyPlugin(AnsiblePlugin):

        def __init__(self):
            super(MyPlugin, self).__init__()

    config_data = ConfigData()

    setting_a = Setting("setting_a", "", "", "", "", "default_value_a")
    config_data.update_setting(setting_a)
    setting_b = Setting("namesetting_b", "", "", "", "", "default_value_b")
    config_data.update_setting(setting_b)
    plugin = MyPlugin()
    plugin.name = "some_name"
    plugin.type = "test"

# Generated at 2022-06-22 19:27:39.894306
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert len(data.get_settings()) == 0
    assert len(data.get_settings(None)) == 0


# Generated at 2022-06-22 19:27:50.182397
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
        config_data = ConfigData()
        plugin_1 = Plugin('test_type_1', 'test_name_1')
        plugin_2 = Plugin('test_type_2', 'test_name_2')
        setting_1 = Setting('test_name_1', 'test_value_1', plugin_1)
        setting_2 = Setting('test_name_2', 'test_value_2', None)
        setting_3 = Setting('test_name_2', 'test_value_3', plugin_1)
        setting_4 = Setting('test_name_3', 'test_value_4', plugin_2)
        config_data.update_setting(setting_1)
        config_data.update_setting(setting_2)
        config_data.update_setting(setting_3)
        config_data.update_setting

# Generated at 2022-06-22 19:27:58.121197
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    settings = ConfigData()
    settings.update_setting(Setting("foo", "bar"))
    assert settings.get_setting("foo") == Setting("foo", "bar")
    assert settings.get_setting("foo", Plugin("bar", "baz")) == None
    assert settings.get_setting("baz") == None
    settings.update_setting(Setting("foo", "bar"), Plugin("bar", "baz"))
    assert settings.get_setting("foo", Plugin("bar", "baz")) == Setting("foo", "bar")
    assert settings.get_setting("baz") == None



# Generated at 2022-06-22 19:27:59.920861
# Unit test for constructor of class ConfigData
def test_ConfigData():

    assert ConfigData() is not None


# Generated at 2022-06-22 19:28:03.292284
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    
    configData = ConfigData()
    setting = configData.get_setting('login_user')
    assert setting is None


# Generated at 2022-06-22 19:28:11.730467
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    def create_dummy_setting(setting_name):
        class DummyConfigEntry:
            def __init__(self, name):
                self.name = name
        return DummyConfigEntry(setting_name)
    assert create_dummy_setting('test_setting')
    dummy_config_data = ConfigData()
    dummy_config_data.update_setting(create_dummy_setting('test_setting'))
    assert len(dummy_config_data._global_settings) == 1
    try:
        dummy_config_data.update_setting('test_setting')
    except:
        assert TypeError
    assert (dummy_config_data.get_setting('test_setting')).name == 'test_setting'

# Generated at 2022-06-22 19:28:13.038527
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    print(config_data)
    assert config_data is not None


# Generated at 2022-06-22 19:28:17.453843
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(BoolSetting('bool_setting', False, True, False, 'True or False'))

    setting = config_data.get_setting('bool_setting')
    assert setting.name == 'bool_setting'


# Generated at 2022-06-22 19:28:21.108342
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-22 19:28:24.445849
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:28:27.136158
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:28:28.910293
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
        pass


# Generated at 2022-06-22 19:28:33.166805
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # Arrange
    config = ConfigData()

    # Act
    settings = config._global_settings
    plugins = config._plugins

    # Assert
    assert settings == {}
    assert plugins == {}

# Generated at 2022-06-22 19:28:35.526295
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert isinstance(configdata, ConfigData)


# Generated at 2022-06-22 19:28:37.234100
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings(None) == []


# Generated at 2022-06-22 19:28:48.057225
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert config_data.get_settings(plugin=None) == []

    config_data.update_setting(Setting('group_vars', 'group_vars_path', '[path1, path2]', '[path1, path2]', ['path1', 'path2']), plugin=Plugin('C', 'B', 'path1'))

    assert len(config_data.get_settings(plugin=None)) == 0
    assert len(config_data.get_settings(plugin=Plugin('C', 'B', 'path1'))) == 1



# Generated at 2022-06-22 19:28:59.314712
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    class Plugin():
        def __init__(self, type, name, desc):
            self.type = type
            self.name = name
            self.desc = desc

    class Setting():
        def __init__(self, name, value):
            self.name = name
            self.value = value

    # Plugin 1 with type 'A' and name 'B'
    plugin1 = Plugin('A', 'B', 'C')

    # Update global setting
    setting1 = Setting('A', 'B')
    config_data.update_setting(setting1)
    assert config_data._global_settings['A'] == setting1
    assert config_data.get_setting('A') == setting1

    # Update plugin setting
    setting2 = Setting('D', 'E')
    config_data.update

# Generated at 2022-06-22 19:29:07.717624
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('default_inventory') is None
    assert config_data.get_setting('default_inventory', 'plugin') is None
    config_data.update_setting('default_inventory')
    config_data.update_setting('default_inventory', 'plugin')
    assert config_data.get_setting('default_inventory') == 'default_inventory'
    assert config_data.get_setting('default_inventory', 'plugin') == 'default_inventory'


# Generated at 2022-06-22 19:29:10.755974
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert isinstance(config_data.get_settings(), list)


# Generated at 2022-06-22 19:29:12.232598
# Unit test for constructor of class ConfigData
def test_ConfigData():
    d = ConfigData()
    assert isinstance(d, ConfigData)

# Generated at 2022-06-22 19:29:15.219832
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()
    assert(config.get_setting('foo') is None)

    from ansible.plugins.loader import PluginLoader

    plugin = PluginLoader('callback', 'minimal').get('minimal')
    assert(config.get_setting('foo', plugin) is None)


# Generated at 2022-06-22 19:29:19.473299
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert config.get_setting("foo") == None
    config.update_setting(ConfigSetting("foo", "bar"))
    assert config.get_setting("foo") == "bar"
    assert config.get_setting("foo2") == None


# Generated at 2022-06-22 19:29:28.833227
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    config_data.update_setting(Setting("max_log_size", 1024, 0))
    config_data.update_setting(Setting("max_log_backups", 5, 0))
    config_data.update_setting(Setting("host_key_checking", True, 1))
    config_data.update_setting(Setting("pipelining", True, 1))


# Generated at 2022-06-22 19:29:39.842962
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    def test_get_settings_with_no_plugin_and_no_settings():
        config = ConfigData()
        assert(config.get_setting('bananas') is None)

    def test_get_settings_with_plugin_and_no_settings():
        config = ConfigData()
        from ansible.module_utils.common.dict_transformations import PluginDescriptor
        plugin = PluginDescriptor()
        plugin.type = 'mytype'
        plugin.name = 'myname'
        assert(config.get_setting('bananas', plugin) is None)
        config.update_setting('bananas', plugin)
        assert(config.get_setting('bananas', plugin) is None)

    def test_get_settings_with_no_plugin_and_one_setting():
        config = ConfigData()
        config

# Generated at 2022-06-22 19:29:40.962986
# Unit test for constructor of class ConfigData
def test_ConfigData():
    test = ConfigData()
    assert test


# Generated at 2022-06-22 19:29:41.980424
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData()

# Generated at 2022-06-22 19:29:48.243183
# Unit test for constructor of class ConfigData
def test_ConfigData():
    global_settings = {"foo": "bar"}
    plugins = {"callback": {"default": {"baz": "qux"}}}
    config_data = ConfigData()
    config_data._global_settings.update(global_settings)
    config_data._plugins.update(plugins)

    assert config_data._global_settings == global_settings
    assert config_data._plugins == plugins


# Generated at 2022-06-22 19:29:50.598573
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData
    assert config_data
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:29:56.559317
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = ConfigSetting(
        name='Foo',
        description='This is a config setting',
        value=True,
        type='bool',
        choices=['True', 'False']
    )

    config_data.update_setting(setting, None)

    assert(config_data.get_setting('Foo', None).value is True)



# Generated at 2022-06-22 19:29:59.881512
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData();
    
    setting = Setting("name1", "key1")
    config_data.update_setting(setting)

    print(config_data.get_setting("name1"))
    

# Generated at 2022-06-22 19:30:07.343443
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # create ConfigData object
    config_data = ConfigData()

    # add global setting
    plugin = None
    name = 'ANSIBLE_LIBRARY'
    value = '~/ansible_modules'
    default = '~/ansible_modules'
    setting = Setting(name, value, type='path', default=default, plugin=plugin)
    config_data.update_setting(setting)

    # create setting for module
    plugin = Plugin('module', 'mymodule', 'mymodule.py')
    name = 'SSH_PASSPHRASE'
    value = '1234'
    default = None
    setting = Setting(name, value, type='string', default=default, plugin=plugin)
    config_data.update_setting(setting)

    # get settings for module
    assert config_data.get_settings