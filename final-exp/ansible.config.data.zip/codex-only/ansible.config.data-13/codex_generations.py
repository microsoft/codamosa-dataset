

# Generated at 2022-06-22 19:20:12.742838
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    setting = Setting(None)
    setting.name = 'name'
    setting.value = 'value'
    
    config.update_setting(setting,None)

    setting = Setting('filter','name')
    setting.value = 'value'
    
    config.update_setting(setting,None)
    
    

# Generated at 2022-06-22 19:20:13.980287
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # TODO: Create a unit test :)

    assert False is True

# Generated at 2022-06-22 19:20:20.244313
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting_test = Setting(name='test_setting', value='test value')
    config_data.update_setting(setting=setting_test)
    assert isinstance(config_data.get_setting(name='test_setting'), Setting)
    assert config_data.get_setting(name='test_setting').name == 'test_setting'
    assert config_data.get_setting(name='test_setting').value == 'test value'


# Generated at 2022-06-22 19:20:30.503247
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # test objects
    t_setting = SettingData('hello', 'text', 'setting data object', 'constant', [], '', True)
    t_plugin = PluginData('lookup', 'plugin data object', 'v2', True)

    # test constructor
    t_config_data = ConfigData()

    # test update_setting()
    t_config_data.update_setting(t_setting)
    assert t_config_data._global_settings[t_setting.name] == t_setting
    t_config_data.update_setting(t_setting, t_plugin)
    assert t_config_data._plugins[t_plugin.type][t_plugin.name][t_setting.name] == t_setting

    # test get_setting()
    assert t_config_data.get_setting(t_setting.name)

# Generated at 2022-06-22 19:20:40.454065
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """Unit test for method update_setting of class ConfigData"""
    config_data = ConfigData()
    setting = ConfigSetting('my_global_setting', 'my_global_value', None, None)
    config_data.update_setting(setting)
    assert config_data._global_settings['my_global_setting'].name == 'my_global_setting'
    setting = ConfigSetting('my_global_setting2', 'my_global_value', None, None)
    config_data.update_setting(setting)
    assert config_data._global_settings.get('my_global_setting2').name == 'my_global_setting2'
    setting = ConfigSetting('my_plugin_setting', 'my_plugin_value', None, ConfigPlugin('my_plugin_type', 'my_plugin_name'))
    config_data.update

# Generated at 2022-06-22 19:20:41.388138
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()


# Generated at 2022-06-22 19:20:43.254971
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd.get_setting('ansible_ssh_private_key_file') is None
    assert len(cd.get_settings()) == 0


# Generated at 2022-06-22 19:20:46.632195
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:20:51.700277
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Given
    config_data = ConfigData()
    setting = {'name': 'test', 'value': 'test_value'}
    plugin = 'test'

    # When
    config_data.update_setting(setting, plugin)

    # Then
    assert config_data._plugins['test']['test']['test'].name == 'test'


# Generated at 2022-06-22 19:20:57.817318
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting("foo", "value"))
    assert config_data.get_setting("foo") is not None
    assert config_data.get_setting("foo").name == "foo"
    assert config_data.get_setting("foo").value == "value"



# Generated at 2022-06-22 19:21:06.387126
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()

    plugin_core = Plugin('core', 'core')
    plugin_module = Plugin('module', 'module')
    plugin_callback = Plugin('callback', 'callback')

    setting_a = Setting('a', 1, [], plugin_core)
    setting_b = Setting('b', 2, [], plugin_module)
    setting_c = Setting('c', 3, [], plugin_callback)
    setting_d = Setting('d', 4, [], None)

    configData.update_setting(setting_a)
    configData.update_setting(setting_b)
    configData.update_setting(setting_c)
    configData.update_setting(setting_d)

    settings = configData.get_settings()
    assert(settings[0].name == 'a')

# Generated at 2022-06-22 19:21:09.472118
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    setting = Setting("/usr/local/share/ansible/", "ansible.cfg")

    config.update_setting(setting)
    assert config._global_settings["ANSIBLE_CONFIG"] == setting

# Generated at 2022-06-22 19:21:10.614145
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert isinstance(config, ConfigData)



# Generated at 2022-06-22 19:21:13.067268
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:21:14.357957
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert(config_data)



# Generated at 2022-06-22 19:21:16.764265
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-22 19:21:18.854618
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert isinstance(config, ConfigData)


# Generated at 2022-06-22 19:21:24.988021
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings['verbosity'] = True
    config_data._global_settings['ask_vault_pass'] = False
    config_data._global_settings['vault_password_file'] = '~/.vault_pass'
    config_data._global_settings['forks'] = 10
    config_data._global_settings['timeout'] = 10

    assert len(config_data.get_settings()) == 5
    assert 'verbosity' in config_data.get_settings()[0]['name']


# Generated at 2022-06-22 19:21:35.578090
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from units.mock.loader import DictDataLoader
    from units.plugins.action import ActionBase
    from units.plugins.callback import CallbackBase
    from units.plugins.connection import ConnectionBase
    from units.plugins.lookup import LookupBase
    from units.plugins.shell import ShellModule

    config_data = ConfigData()

    # test getting a global setting in config data
    config_data.update_setting(Setting('verbosity', '1', True, GlobalSettings()))
    config_data.update_setting(Setting('inventory', 'inventory/hosts.yml', False, GlobalSettings()))

    assert config_data.get_setting('verbosity').name == 'verbosity'
    assert config_data.get_setting('verbosity').value == '1'

# Generated at 2022-06-22 19:21:37.181795
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert len(cd._global_settings) == 0
    assert len(cd._plugins) == 0

# Generated at 2022-06-22 19:21:40.482049
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    settings = ConfigData()
    settings.update_setting({"name" : "foo", "value" : "bar"})
    assert settings._global_settings.get("foo").value == "bar"


# Generated at 2022-06-22 19:21:51.636300
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0
    config_data.update_setting(Setting(name='key1', value='value1'))
    assert len(config_data.get_settings()) == 1
    assert config_data.get_setting('key1').value == 'value1'
    config_data.update_setting(Setting(name='key2', value='value2'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_setting('key1').value == 'value1'
    assert config_data.get_setting('key2').value == 'value2'
    config_data.update_setting(Setting(name='key2', value='value2.2'))
    assert len(config_data.get_settings()) == 2

# Generated at 2022-06-22 19:21:53.911602
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:22:01.349161
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    print('\n# Unit test for method `get_settings` of class `ConfigData`')

    config_data = ConfigData()

    global_setting = Setting({'key':'s1', 'section':'global', 'value':'global_value', 'vault_password':None})
    config_data.update_setting(global_setting)

    plugin_setting_1 = Setting({'key': 's1', 'section': 'plugin', 'value': 'plugin_value_1', 'vault_password': None})
    plugin_setting_2 = Setting({'key': 's2', 'section': 'plugin', 'value': 'plugin_value_2', 'vault_password': None})
    config_data.update_setting(plugin_setting_1, Plugin('plugin', 'connection'))

# Generated at 2022-06-22 19:22:12.483174
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config1 = ConfigData()

    # Test setting global setting
    config1.update_setting(AnsiblePluginSetting('ANSIBLE_CACHE_PLUGINS', 'True', 'bool', 'Whether to load plugin cache modules'))
    assert config1.get_setting('ANSIBLE_CACHE_PLUGINS') is not None
    assert config1.get_setting('ANSIBLE_CACHE_PLUGINS').value == 'True'

    # Test updating setting global setting
    config1.update_setting(AnsiblePluginSetting('ANSIBLE_CACHE_PLUGINS', 'False', 'bool', 'Whether to load plugin cache modules'))
    assert config1.get_setting('ANSIBLE_CACHE_PLUGINS') is not None

# Generated at 2022-06-22 19:22:23.354067
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()
    setting = Setting("ANSIBLE_CONFIG_EVENT_PLUGINS_DIR", "/home/muhammad/myplugins/ansible_plugins/eventplugins")
    plugin = Plugin("EAPlugin", "Event")
    configdata.update_setting(setting, plugin)
    assert configdata.get_setting("ANSIBLE_CONFIG_EVENT_PLUGINS_DIR", plugin) == setting
    assert configdata.get_setting("ANSIBLE_CONFIG_EVENT_PLUGINS_DIR") == None

    setting2 = Setting("ANSIBLE_CONFIG_CALLBACK_PLUGINS_DIR", "/home/muhammad/myplugins/ansible_plugins/callbackplugins")
    plugin2 = Plugin("CAPlugin", "Callback")
    configdata.update_setting(setting2, plugin2)

# Generated at 2022-06-22 19:22:33.669478
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    assert config_data.get_settings() == []

    # Add a setting
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.constants import DEFAULT_MODULE_PATH
    from ansible.config.setting import Setting
    from ansible.utils.plugin_docs import make_plugin_docstring, get_docstring_section
    from ansible.plugins.loader import testfixtures

    setting = Setting(
        name='module_path',
        value=[DEFAULT_MODULE_PATH],
        origin=ImmutableDict(),
        plugin=None
    )

    config_data.update_setting(setting)

    settings = config_data.get_settings()

    assert len(settings) == 1

# Generated at 2022-06-22 19:22:35.578074
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}


# Generated at 2022-06-22 19:22:39.263134
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    # Check value of _global_settings
    assert config_data._global_settings == {}

    # Check value of _plugins
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:22:48.225163
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblelint.rules.PluginRule import PluginRule
    from ansiblelint.rules.SettingRule import SettingRule

    config = ConfigData()

    rule_name = 'rule1'
    rule_id = 'rule1'
    rule_desc = 'rule1 description'

    plugin = PluginRule(rule_name,
                        rule_id,
                        rule_desc)

    setting_name = 'setting1'
    setting_id = 'setting1'
    setting_desc = 'setting1 description'
    setting_type = 'bool'

    setting = SettingRule(setting_name,
                          setting_id,
                          setting_desc,
                          plugin=plugin,
                          value_type=setting_type)

    config.update_setting(setting, plugin)


# Generated at 2022-06-22 19:22:58.021381
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()
    settings = config.get_settings()
    assert 0 == len(settings)

    config.update_setting(Setting('setting_1', 'val_1', 'plugin_1', 'type_1'))
    settings = config.get_settings()
    assert 1 == len(settings)

    settings = config.get_settings(Plugin('plugin_1', 'type_1'))
    assert 0 == len(settings)

    config.update_setting(Setting('setting_2', 'val_2', 'plugin_2', 'type_2'))
    settings = config.get_settings()
    assert 2 == len(settings)

    settings = config.get_settings(Plugin('plugin_1', 'type_1'))
    assert 0 == len(settings)


# Generated at 2022-06-22 19:23:07.174985
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Create config data instance
    data = ConfigData()

    # Pick a plugin
    from ansible.plugins.loader import plugin_loader
    from ansible.plugins.connection.ssh import Connection as SSHPlugin

    # Create a setting
    from ansible.utils.module_docs import get_docstring
    from ansible.config.setting import Setting
    doc, metadata, _ = get_docstring(SSHPlugin())
    setting = Setting(name='retries', choices=dict(),
                      value=metadata['options']['retries'][1],
                      origin='ansible.cfg', plugin=SSHPlugin.__name__)
    setting.origin = 'ansible.cfg'
    data.update_setting(setting)

    # Try to get the setting
    returned = data.get_setting(setting.name)
    assert setting == returned



# Generated at 2022-06-22 19:23:17.052314
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Create a config data
    configData = ConfigData()
    # Create a plugin
    import lib.ansible_plugins.module_utils.network.cloudengine.ce.ce_snmp as ce_snmp
    plugin = ce_snmp.CESNMP("/home/ansible/plugins/modules/network/cloudengine/ce_snmp")
    # Update plugin in config data
    configData.update_plugin(plugin)
    # Create and update a setting
    import lib.ansible_plugins.module_utils.network.cloudengine.ce.ce_snmp_ping as ce_snmp_ping
    plugin = ce_snmp_ping.SNMPPing("/home/ansible/plugins/modules/network/cloudengine/ce_snmp_ping")
    setting = ce_snmp_ping.SETTING_PING_

# Generated at 2022-06-22 19:23:21.541437
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    setting = 'class1'
    assert config_data.get_setting(setting) is None

    config_data.update_setting(setting)
    assert config_data.get_setting(setting) == setting


# Generated at 2022-06-22 19:23:34.576210
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    config_data.update_setting(Setting('setting11', 'value11'))
    config_data.update_setting(Setting('setting12', 'value12'))
    plugin = Plugin('type1', 'name1')
    config_data.update_setting(Setting('setting21', 'value21'), plugin)
    config_data.update_setting(Setting('setting22', 'value22'), plugin)

    settings = config_data.get_settings()
    assert len(settings) == 2
    assert settings[0].name == 'setting11'
    assert settings[1].name == 'setting12'

    settings = config_data.get_settings(plugin)
    assert len(settings) == 2
    assert settings[0].name == 'setting21'
    assert settings[1].name == 'setting22'

# Generated at 2022-06-22 19:23:37.683996
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-22 19:23:40.066531
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert len(data._global_settings) == 0
    assert len(data._plugins) == 0

# Generated at 2022-06-22 19:23:48.626050
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}
    dummy_setting = {'name': 'dummy', 'setting_type': 'global'}
    config.update_setting(dummy_setting)
    assert config.get_setting('dummy') == dummy_setting
    assert config.get_settings() == [dummy_setting]

    new_setting = {'name': 'new', 'setting_type': 'plugin'}
    config.update_setting(new_setting, plugin=('new_type', 'new_plugin'))
    assert config.get_setting('new', ('new_type', 'new_plugin')) == new_setting
    assert config.get_settings(('new_type', 'new_plugin')) == [new_setting]

# Generated at 2022-06-22 19:23:51.437929
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    data.update_setting("data")
    assert("data" in data._global_settings)


# Generated at 2022-06-22 19:24:04.231868
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Initializes variables
    config_data = ConfigData()
    config_data._global_settings = {
        'ANSIBLE_CALLBACK_WHITELIST': CallbackWhitelistSetting(),
        'ANSIBLE_CONFIG': ConfigFileSetting(),
        'ANSIBLE_HOST_KEY_CHECKING': HostKeyCheckingSetting()
    }
    config_data._plugins = {
        'callback': {
            'stdout': {
                't1': TextSetting('t1', 'v1')
            }
        }
    }
    plugin = Plugin('callback', 'stdout')
    # Gets settings
    settings = config_data.get_settings(plugin)
    # Asserts number of settings
    assert len(settings) == 1
    # Iterates settings

# Generated at 2022-06-22 19:24:15.354820
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class Plugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class Setting:
        def __init__(self, name, value):
            self.name = name
            self.value = value

    def _test_ConfigData_get_setting(cd, ps, p, s, result):

        if p is None:
            if s is None:
                assert not cd.get_setting(p)
            else:
                assert cd.get_setting(s) == result
        else:
            if s is None:
                assert not cd.get_setting(None, p)
            else:
                assert cd.get_setting(s, p) == result

    cd = ConfigData()
    p_type = "test_type"

# Generated at 2022-06-22 19:24:16.522934
# Unit test for constructor of class ConfigData
def test_ConfigData():
    test_object = ConfigData()
    assert isinstance(test_object, ConfigData)


# Generated at 2022-06-22 19:24:22.963024
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    plugin_type = "test"
    plugin_name = "test_plugin"
    setting_name = "test_setting"
    setting_value = "True"
    plugin = Plugin(plugin_name, plugin_type)

    config_data.update_setting(Setting(name=setting_name, value=setting_value), plugin)

    assert config_data.get_setting(setting_name, plugin) is not None

# Generated at 2022-06-22 19:24:31.833450
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data._global_settings = {'setting_1': 'setting_1'}
    assert config_data.get_setting('setting_1') == 'setting_1'
    assert config_data.get_setting('setting_2') is None
    plugin = Plugin(type='type', name='name')
    assert config_data.get_setting('setting_3', plugin) is None
    config_data._plugins = {'type': {'name': {'setting_2': 'setting_2'}}}
    assert config_data.get_setting('setting_2', plugin) == 'setting_2'
    assert config_data.get_setting('setting_1', plugin) is None
    assert config_data.get_setting('setting_3', plugin) is None


# Generated at 2022-06-22 19:24:42.878318
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Create two different plugins
    plugin1 = PluginDefinition(type='factory', name='my_plugin1')
    plugin2 = PluginDefinition(type='factory', name='my_plugin2')
    # Create a config_data object and add two settings, one global and other plugin-related
    config_data = ConfigData()
    config_data.update_setting(create_setting(name='global', value='global_value'))
    config_data.update_setting(create_setting(name='plugin1', value='plugin1_value'), plugin=plugin1)
    # Get both settings: global and plugin1
    assert config_data.get_setting(name='global').value == 'global_value'
    assert config_data.get_setting('plugin1', plugin1).value == 'plugin1_value'


# Generated at 2022-06-22 19:24:54.836098
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    setting = Setting(Setting.TYPE_STRING, 'this is a setting')
    config_data.update_setting(setting)
    assert config_data._global_settings == {'this is a setting': setting}
    assert config_data._plugins == {}

    setting = Setting(Setting.TYPE_STRING, 'more settings')
    plugin = Plugin(Plugin.TYPE_MODULE, 'this.is.a.module')
    config_data.update_setting(setting, plugin)
    assert config_data._global_settings == {'this is a setting': setting}
    assert config_data._plugins == {Plugin.TYPE_MODULE: {'this.is.a.module': {'more settings': setting}}}



# Generated at 2022-06-22 19:24:58.086968
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # Create an instance of the ConfigData class
    cd = ConfigData()

    # Assert zero plugins stored in ConfigData
    assert len(cd._plugins.keys()) == 0

    # Assert zero settings stored in ConfigData
    assert len(cd._global_settings.keys()) == 0

# Generated at 2022-06-22 19:24:59.831973
# Unit test for constructor of class ConfigData
def test_ConfigData():

    d = ConfigData()

    assert d, 'Test Failed'


# Generated at 2022-06-22 19:25:08.948140
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    setting_1 = Setting('test_setting_1')
    setting_2 = Setting('test_setting_2')
    setting_3 = Setting('test_setting_3')

    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2, plugin=Plugin('test_type', 'test_name'))
    config_data.update_setting(setting_3, plugin=Plugin('test_type', 'test_name'))

    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings(plugin=Plugin('test_type', 'test_name'))) == 2
    assert len(config_data.get_settings(plugin=Plugin('fake_type', 'fake_name'))) == 0

# Generated at 2022-06-22 19:25:17.861585
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    assert len(data.get_settings()) == 0
    assert len(data.get_settings(plugin=None)) == 0
    assert len(data.get_settings(plugin=None)) == 0
    from ansible.plugins.loader import PluginLoader
    plugin_loader = PluginLoader()
    plugin = plugin_loader.get('action', 'win_ping')
    data.update_setting(setting=dict(name='some_setting', plugin=plugin, value='some_value'))
    assert len(data.get_settings()) == 1
    assert len(data.get_settings(plugin=plugin)) == 1
    assert data.get_setting(setting='some_setting', plugin=plugin) == dict(name='some_setting', plugin=plugin, value='some_value')

    # This is testing the updated a file setting

# Generated at 2022-06-22 19:25:19.807340
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('test', 'value'))
    assert len(config_data.get_settings()) == 1


# Generated at 2022-06-22 19:25:21.366273
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert(config_data is not None)


# Generated at 2022-06-22 19:25:25.413049
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    configData.update_setting(Setting('foo', 'bar'))
    assert configData.get_setting('foo') == 'bar'


# Generated at 2022-06-22 19:25:30.873500
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # First testing for plugin
    configData = ConfigData()

    # Update setting for plugin
    configData.update_setting(Setting("test", "test", "test", "test", True))

    # Creating the empty plugin
    plugin = Plugin()
    plugin.type = "test"
    plugin.name = "test"

    # Testing
    setting = configData.get_settings(plugin)
    assert setting == []



# Generated at 2022-06-22 19:25:37.240649
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    cd.update_setting = MockSetting(1, "global_setting_1")
    cd.update_setting = MockSetting(2, "global_setting_2")
    cd.update_setting = MockSetting(1, "foo_setting_1", "foo", "bar")
    cd.update_setting = MockSetting(2, "foo_setting_2", "foo", "bar")
    cd.update_setting = MockSetting(1, "bar_setting_1", "bar", "foo")
    cd.update_setting = MockSetting(2, "bar_setting_2", "bar", "foo")
    assert cd.get_setting("global_setting_1") != None
    assert cd.get_setting("global_setting_2") != None

# Generated at 2022-06-22 19:25:39.579787
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    a = data.get_setting('ANSIBLE_HOST_KEY_CHECKING')
    assert a == None



# Generated at 2022-06-22 19:25:42.270442
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    for k in config_data._global_settings:
        assert config_data._global_settings == config_data.get_settings()

# Generated at 2022-06-22 19:25:45.395073
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(Setting('mode', '644', 'file'))
    assert config.get_setting('mode').name=='mode'

# Generated at 2022-06-22 19:25:49.419012
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()

    import ansible.plugins.loader
    # Setting plugin_type to a non-empty string but not a valid type will cause problems
    # when plugins are loaded.
    plugin = ansible.plugins.loader.Plugin('Unit test', 'plugin_type', 'plugin_name')
    settings = config.get_settings(plugin)
    print(settings)
    assert not settings


# Generated at 2022-06-22 19:25:56.113888
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    from ansible.plugins.loader import PluginLoader
    from ansible import constants as C
    p = PluginLoader('lookup', 'lookup.template')
    s = ConfigDataSetting(setting_name='template', setting_value='test')
    c.update_setting(s, p)

test_ConfigData_update_setting()


# Generated at 2022-06-22 19:26:04.726403
# Unit test for constructor of class ConfigData
def test_ConfigData():
    try:
        from jinja2 import Environment
        from jinja2 import FileSystemLoader
        from jinjamator.plugins import Plugin
    except Exception as e:
        print(e)

    env = Environment(loader=FileSystemLoader('tests/templates/'))
    template = env.get_template('unit_test_config.yml')
    c = ConfigData()
    assert isinstance(c, ConfigData)

    plugin1 = Plugin('jinjamator.plugins.test', 'TestPlugin_1')
    setting1 = dict(name='setting1', value='1', plugin=plugin1, type='const', path='/test')
    setting2 = dict(name='setting2', value='2', plugin=plugin1, type='const', path='/test')

# Generated at 2022-06-22 19:26:06.877784
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert c


# These are integration tests, so cannot be run with the unit tests in the same process


# Generated at 2022-06-22 19:26:08.614574
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()

    assert isinstance(config, ConfigData)
    assert not config._global_settings
    assert not config._plugins


# Generated at 2022-06-22 19:26:18.111063
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    config_data.update_setting(Setting('named_default', type=Setting.CONST_TYPE_BOOL, value='True'))
    config_data.update_setting(Setting('ansible_httpapi_use_ssl', type=Setting.CONST_TYPE_BOOL, value='True'))
    config_data.update_setting(Setting('ansible_httpapi_validate_certs', type=Setting.CONST_TYPE_BOOL, value='False'))

    config_data.update_setting(Setting('ansible_host', type=Setting.CONST_TYPE_STRING, value='10.0.0.25'))

# Generated at 2022-06-22 19:26:25.235960
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    data_source = DataSource()
    data_source.type = 'source'
    data_source.name = 'file'

    variable = Variable()
    variable.name = 'myvar'
    variable.value = 'my val'

    config_data.update_setting(variable, data_source)
    assert config_data.get_setting('myvar', data_source) == variable


# Generated at 2022-06-22 19:26:28.034724
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert len(config._global_settings) == 0
    assert len(config._plugins) == 0


# Generated at 2022-06-22 19:26:36.948162
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import os.path
    import pprint
    import yaml

    # ConfigData object
    config_data = ConfigData()

    # Global settings
    with open(os.path.join('test', 'data', 'ansible.cfg')) as f:
        data = yaml.safe_load(f)
        for name, value in data['DEFAULT'].items():
            config_data.update_setting(Setting(name, value, 'Global Setting'))

    # Plugin settings
    with open(os.path.join('test', 'data', 'connection_plugins.yml')) as f:
        data = yaml.safe_load(f)

# Generated at 2022-06-22 19:26:41.737179
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting = Setting(name='a')
    plugin = Plugin(
        type='a',
        name='b'
    )

    config_data = ConfigData()
    config_data.update_setting(setting, plugin)

    assert setting == config_data.get_setting('a', plugin)


# Generated at 2022-06-22 19:26:53.219300
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()

    name = "test_plugin"

    # Create 2 settings for plugin
    test_plugin_set_1 = dict(name="test_plugin_set_1", value=1, values=["1", "2", "3"], origin="default")
    test_plugin_set_2 = dict(name="test_plugin_set_2", value=2, values=["1", "2", "3"], origin="default")
    cd.update_setting(Setting.from_dict(test_plugin_set_1, type="plugin", name=name))
    cd.update_setting(Setting.from_dict(test_plugin_set_2, type="plugin", name=name))

    # Create 2 settings for global

# Generated at 2022-06-22 19:26:57.992130
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}
    assert config.get_setting('ansible_greeting') is None
    assert config.get_settings() == []


# Generated at 2022-06-22 19:27:08.008145
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_data = ConfigData()
    test_setting = Setting('test_setting', 5)
    test_plugin = Plugin('test_plugin', 'test_type')
    # update setting without plugin
    test_data.update_setting(test_setting)
    assert test_data.get_setting('test_setting') == test_setting
    # update setting with no prior plugin
    test_data.update_setting(test_setting, test_plugin)
    assert test_data.get_setting('test_setting', test_plugin) == test_setting
    # update setting with prior plugin
    test_setting2 = Setting('test_setting', 7)
    test_plugin2 = Plugin('test_plugin2', 'test_type')
    test_data.update_setting(test_setting2, test_plugin)
    assert test_data.get_

# Generated at 2022-06-22 19:27:12.329572
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:27:14.340836
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd.get_setting('') == None


# Generated at 2022-06-22 19:27:17.774257
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting = { "name": "ACCOUNT_API_KEY" }
    config_data = ConfigData()
    config_data.update_setting(setting)
    assert config_data._global_settings["ACCOUNT_API_KEY"] == setting


# Generated at 2022-06-22 19:27:19.887378
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    value = ConfigData.get_settings(ConfigData())
    assert value is None
    assert "Unable to get settings"



# Generated at 2022-06-22 19:27:22.406484
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert c._global_settings == {}
    assert c._plugins == {}



# Generated at 2022-06-22 19:27:28.441409
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    assert config_data.get_setting('TEST') is None

    from ansiblelint.rules.LineTooLong import LineTooLong
    from ansiblelint.setting import Setting

    test_setting = Setting(LineTooLong(), 'TEST', 'True')
    config_data.update_setting(test_setting)
    assert config_data.get_setting('TEST') == test_setting


# Generated at 2022-06-22 19:27:35.893079
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    assert config_data.get_setting('enable_plugins') is None

    # add a global setting
    config_data.update_setting(('enable_plugins', 'True', 'boolean', 'all'))

    assert config_data.get_setting('enable_plugins') is not None
    assert config_data.get_setting('enable_plugins').name == 'enable_plugins'
    assert config_data.get_setting('enable_plugins').value == 'True'
    assert config_data.get_setting('enable_plugins').type == 'boolean'
    assert config_data.get_setting('enable_plugins').plugin is None

    # get a non-existing setting
    assert config_data.get_setting('no_setting') is None



# Generated at 2022-06-22 19:27:46.212210
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class Plugin(object):

        def __init__(self, type, name):
            self.type = type
            self.name = name

    config_data = ConfigData()

    plugin1 = Plugin('gather_facts', 'ansible_os_family')
    plugin1_setting = {'name': 'ansible_os_family'}
    config_data.update_setting(plugin1_setting, plugin1)

    plugin2 = Plugin('connection', 'local')
    plugin2_setting = {'name': 'local'}
    config_data.update_setting(plugin2_setting, plugin2)

    settings = config_data.get_settings()
    assert len(settings) == 2

    plugin1_settings = config_data.get_settings(plugin1)
    assert len(plugin1_settings) == 1

# Generated at 2022-06-22 19:27:48.633645
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()
    config.update_setting(Setting('message', 'this is a message'))
    assert config.get_setting('message') == 'this is a message'


# Generated at 2022-06-22 19:27:58.681528
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.plugin_docs.config import Setting

    config = ConfigData()
    setting = Setting(name="version", value="2.3", scope='ellie')
    config.update_setting(setting)
    assert config.get_setting("version") == setting

    setting = Setting(name="version", value="2.4", scope='ansible.builtin')
    config.update_setting(setting)
    assert config.get_setting("version") == setting

    setting = Setting(name="version", value="2.5", scope='ansible.builtin.alicetaskplugin')
    config.update_setting(setting)
    assert config.get_setting("version") == setting

    setting = Setting(name="version", value="2.6", scope='ansible.builtin.bobbyscriptmodule')
   

# Generated at 2022-06-22 19:28:09.879677
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert(config_data)

    # test get_settings method
    assert(config_data.get_settings())
    assert(config_data.get_settings(plugin=None))
    assert(config_data.get_settings() == config_data.get_settings(plugin=None))

    # test get_setting method
    assert(config_data.get_setting("foo"))
    assert(config_data.get_setting("foo", plugin=None))
    assert(config_data.get_setting("foo") == config_data.get_setting("foo", plugin=None))
    assert(config_data.get_setting("foo", plugin="foo"))

    # test update_setting method
    config_data.update_setting("foo")

# Generated at 2022-06-22 19:28:19.725460
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    configdata = ConfigData()
    assert configdata._global_settings == {}
    assert configdata._plugins == {}

    from ansible.plugins.loader import PluginTypeEnum, PluginParser
    from ansible.plugins.loader import Plugin, create_forced_bool_setting

    plugin = Plugin(PluginTypeEnum.CACHE, 'Test')
    setting = plugin.create_setting(name='my_setting', default_value='my_value')
    assert setting.name == 'my_setting'
    assert setting.value == 'my_value'
    assert configdata.get_setting(setting.name, plugin) == None

    configdata.update_setting(setting, plugin)
    assert configdata.get_setting(setting.name, plugin) == setting
    assert configdata.get_setting(setting.name) == None


# Generated at 2022-06-22 19:28:25.651859
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # set up the context
    config_data = ConfigData()
    test_config = ConfigSetting("value")
    config_data.update_setting(test_config)

    # test the method
    assert config_data.get_setting("value") == test_config



# Generated at 2022-06-22 19:28:26.531575
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigD

# Generated at 2022-06-22 19:28:38.361730
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible import constants as C

    data = ConfigData()

    # construct a global setting
    global_setting_dict = {
        'name': 'foo',
        'value': 'bar',
        'value_type': 'string',
        'origin': 'bar.yml',
        'scope': [C.CONFIG_TYPE_DEFAULT]
    }

    # construct a plugin setting
    plugin_setting_dict = {
        'name': 'foo',
        'value': 'bar',
        'value_type': 'string',
        'origin': 'bar.yml',
        'scope': [C.CONFIG_TYPE_DEFAULT]
    }

    # construct a Plugin object
    from ansible import plugins

# Generated at 2022-06-22 19:28:39.894541
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data

# Generated at 2022-06-22 19:28:51.682299
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()

    setting1 = Setting('test1', 'test1_value')
    setting2 = Setting('test2', 'test2_value')
    setting3 = Setting('test3', 'test3_value')
    setting4 = Setting('test4', 'test4_value')

    config_plugins = [Plugin('test_type', 'test_name'), Plugin('test_type2', 'test_name2')]
    config_settings = [setting1, setting2, setting3, setting4]

    config.update_setting(setting1)
    config.update_setting(setting2, config_plugins[0])
    config.update_setting(setting3, config_plugins[1])
    config.update_setting(setting4)

    settings = config.get_settings()
    assert len(settings) == 2

# Generated at 2022-06-22 19:28:59.921626
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    # test if non-existing setting is returned
    setting = config_data.get_setting("foo")
    assert setting is None
    # test if existing global setting is returned
    config_data._global_settings["foo"] = []
    setting = config_data.get_setting("foo")
    assert setting == []
    # test if non-existing setting of a plugin is returned
    # create a new collection plugin named "collection"
    plugin = Plugin("collection", "collection")
    setting = config_data.get_setting("foo", plugin)
    assert setting is None
    # test if existing setting of a plugin is returned
    # add setting with name "foo" for plugin "collection"
    config_data._plugins["collection"]["collection"]["foo"] = {}
    setting = config_data.get_

# Generated at 2022-06-22 19:29:08.240921
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    data.update_setting('setting1')
    data.update_setting('setting2')
    data.update_setting('setting3')
    data.update_setting('setting4')
    data.update_setting('setting5')
    data.update_setting('setting6')
    data.update_setting('setting7')
    data.update_setting('setting8')
    data.update_setting('setting9')
    data.update_setting('setting10')

    assert len(data.get_settings()) == 10

# Generated at 2022-06-22 19:29:13.904253
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin('a', 'b')
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data._global_settings.get('foo') == setting


# Generated at 2022-06-22 19:29:20.856352
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = None

    setting = Setting(name="setting", value="value", origin="origin", plugin=plugin, config=config_data)
    config_data.update_setting(setting, plugin)
    assert config_data._global_settings.get("setting") == setting

    plugin = Plugin("type", "name")

    setting = Setting(name="setting", value="value", origin="origin", plugin=plugin, config=config_data)
    config_data.update_setting(setting, plugin)
    assert config_data._plugins.get("type").get("name").get("setting") == setting


# Generated at 2022-06-22 19:29:30.096630
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()

    config.update_setting(ConfigSetting('force_handlers', 'false', 'boolean'))
    config.update_setting(ConfigSetting('roles_path', '~/.ansible/roles', 'list'))
    config.update_setting(ConfigSetting('role_name', 'my_role', 'string'))
    config.update_setting(ConfigSetting('retry_files_enabled', 'false', 'boolean'), ConfigPlugin('connection', 'ssh'))
    config.update_setting(ConfigSetting('roles_path', '/path/to/roles', 'list'), ConfigPlugin('role', 'common'))
    config.update_setting(ConfigSetting('lookup_plugins', '/path/to/lookup_plugins', 'list'), ConfigPlugin('lookup', 'mysql_query'))


# Generated at 2022-06-22 19:29:38.339493
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from ansible.plugins.configuration import Setting
    config_data = ConfigData()
    s = Setting(name='foo')
    config_data.update_setting(s)
    assert config_data.get_setting('foo') == s
    s2 = Setting(name='bar')
    config_data.update_setting(s2, 'constants')
    assert config_data.get_setting('bar', 'constants') == s2
    assert config_data.get_setting('bar', 'shell') == None

if __name__ == '__main__':
    test_ConfigData_get_setting()

# Generated at 2022-06-22 19:29:39.736854
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-22 19:29:41.154685
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()
    assert len(config._global_settings) == 0
    assert len(config._plugins) == 0

# Generated at 2022-06-22 19:29:52.241524
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data._global_settings = {'name': 'test_name'}
    config_data._plugins = {'type1': {'name1': {'name': 'test_name1', 'type': 'type1'}, 'name2': {'name': 'test_name2', 'type': 'type1'}},
                             'type2': {'name1': {'name': 'test_name3', 'type': 'type2'}, 'name2': {'name': 'test_name4', 'type': 'type2'}}}

    assert config_data.get_setting('name') == {'name': 'test_name'}
    assert config_data.get_setting('name1') is None
    assert config_data.get_setting('name3') is None
    assert config

# Generated at 2022-06-22 19:29:54.947375
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._plugins == {}
    assert config_data._global_settings == {}


# Generated at 2022-06-22 19:29:57.270633
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert isinstance(cd._global_settings, dict)
    assert isinstance(cd._plugins, dict)


# Generated at 2022-06-22 19:30:03.658709
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    assert config_data.get_setting('g_setting') is None

    config_data.update_setting(Setting(name='g_setting', value=True))
    assert config_data.get_setting('g_setting').value

    config_data.update_setting(
        Setting(name='p_setting', value=False),
        Plugin(name='p_plugin', type='p_type')
    )
    assert not config_data.get_setting('p_setting', Plugin(name='p_plugin', type='p_type')).value



# Generated at 2022-06-22 19:30:05.109605
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert configdata is not None


# Generated at 2022-06-22 19:30:07.686394
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() is not None

# Generated at 2022-06-22 19:30:14.078430
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    import unittest
    import json

    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import fake_loader

    class TestConfigDataGetSetting(unittest.TestCase):
        """ Test case for the method 'get_setting' of class 'ConfigData'
        """

        def setUp(self):

            self.config_data = ConfigData()

            def _get_vault_password(prompt=None, confirm=False):  # pylint: disable=unused-argument
                return "myvaultpassword"

            loader = DataLoader()
            vault_secrets = VaultLib(password_callback=_get_vault_password, loader=loader)