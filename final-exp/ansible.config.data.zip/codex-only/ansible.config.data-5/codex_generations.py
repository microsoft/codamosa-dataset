

# Generated at 2022-06-22 19:20:13.598122
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('one', 'one_value'))
    config_data.update_setting(Setting('two', 'two_value'))
    settings = config_data.get_settings()
    assert len(settings) == 2
    assert settings[0].name == 'one'
    assert settings[1].name == 'two'
    # Verify that original object is not altered
    config_data.update_setting(Setting('three', 'three_value'))
    assert len(settings) == 2

# Generated at 2022-06-22 19:20:15.270450
# Unit test for constructor of class ConfigData
def test_ConfigData():

    c = ConfigData()
    import pytest
    assert isinstance(c, ConfigData) == True


# Generated at 2022-06-22 19:20:20.569644
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    new_config_data = ConfigData()
    setting = {'name':'DEFAULT_ROLES_PATH', 'plugin':'Global'}
    new_config_data.update_setting(setting)
    assert new_config_data.get_setting('DEFAULT_ROLES_PATH', 'test') == setting

test_ConfigData_update_setting()

# Generated at 2022-06-22 19:20:30.502769
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    cdata = ConfigData()
    cdata.update_setting(Setting('foo', 'bar'))
    assert cdata.get_setting('foo') == Setting('foo', 'bar')
    cdata.update_setting(Setting('foo', 'baz'))
    assert cdata.get_setting('foo') == Setting('foo', 'baz')
    plugin = Plugin('test', 'module')
    cdata.update_setting(Setting('bar', 'baz'), plugin)
    assert cdata.get_setting('bar', plugin) == Setting('bar', 'baz')
    cdata.update_setting(Setting('bar', 'baz'), plugin)
    assert cdata.get_setting('bar', plugin) == Setting('bar', 'baz')


# Generated at 2022-06-22 19:20:38.427835
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert cd._global_settings == {}
    assert cd._plugins == {}
    cd.update_setting(Setting('monkey', 'monkey'))
    assert cd._global_settings == {'monkey': Setting('monkey', 'monkey')}
    assert cd._plugins == {}
    cd.update_setting(Setting('monkey', 'monkey'), Plugin('monkey', 'monkey'))
    assert cd._global_settings == {'monkey': Setting('monkey', 'monkey')}
    assert cd._plugins['monkey']['monkey']['monkey'] == Setting('monkey', 'monkey')


# Generated at 2022-06-22 19:20:45.501676
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    cd = ConfigData()
    class Plugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name
            self.implementation = 'None'
            self.api = 1
        def __eq__(self, other):
            return self.type == other.type and self.name == other.name
    class Setting(object):
        def __init__(self, named, plugin, value):
            self.name = named
            self.plugin = plugin
            self.value = value
        def __eq__(self,other):
            return self.name == other.name and self.plugin == other.plugin and self.value == other.value
    c = Setting('connection', Plugin('connection', 'local'), 'local')
    cd.update_setting(c)
    b = Setting

# Generated at 2022-06-22 19:20:53.615804
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    setting_a = ConfigSetting(name='a', value='1')
    data.update_setting(setting=setting_a)
    setting_b = ConfigSetting(name='b', value='2')
    data.update_setting(setting=setting_b)
    setting_c = ConfigSetting(name='c', value='3')
    data.update_setting(setting=setting_c)

    assert data.get_setting(name='a').value == '1'
    assert data.get_setting(name='b').value == '2'
    assert data.get_setting(name='c').value == '3'
    

# Generated at 2022-06-22 19:20:56.076824
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

# Generated at 2022-06-22 19:21:04.875421
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    import sys
    import os
    sys.path.append(os.path.realpath('.'))
    from plugin_setting import PluginSetting
    plugin = PluginSetting('callback','ansible-test-plugin','test_callback_plugin','/tmp','1.0','TEST','INFO','test','test','test','test')
    setting = PluginSetting('string','ansible-test-plugin','test_callback_plugin','/tmp','1.0','TEST','INFO','test','test','test','test')
    config.update_setting(plugin)
    config.update_setting(setting)
    assert config.get_setting('callback') == plugin
    assert config.get_setting('string') == setting


# Generated at 2022-06-22 19:21:06.938612
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:21:14.413837
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    configdata=ConfigData()
    assert not configdata._global_settings
    assert not configdata._plugins

    name='plugin_type1'
    value='plugin_name1'
    plugin_type='global'
    setting=Setting('foo', plugin_type='global', name=name, value=value)
    configdata.update_setting(setting)
    assert configdata._global_settings
    assert len(configdata._global_settings) == 1
    assert configdata._global_settings[setting.name].name == setting.name
    assert configdata._global_settings[setting.name].plugin_type == setting.plugin_type
    assert configdata._global_settings[setting.name].value == setting.value
    assert not configdata._plugins

    name='plugin_type2'
    value='plugin_name2'
    plugin_type

# Generated at 2022-06-22 19:21:17.540430
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()
    config._global_settings['test'] = 'test'
    assert config.get_settings() == config._global_settings.values()

# Generated at 2022-06-22 19:21:20.155904
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert len(config._global_settings) == 0
    assert len(config._plugins) == 0
    

# Generated at 2022-06-22 19:21:31.663148
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('auto_pull', 'enabled', 'True'))
    config_data.update_setting(Setting('auto_pull', 'interval', '1m'))

    config_data.update_setting(Setting('notify', 'debug', 'True', 'local'))
    config_data.update_setting(Setting('notify', 'debug', 'False', 'local', 'debug'))
    config_data.update_setting(Setting('notify', 'debug', 'True', 'remote'))

    assert config_data._global_settings.get('auto_pull').plugin_name is None
    assert config_data._global_settings.get('auto_pull').get_value() == 'True'


# Generated at 2022-06-22 19:21:36.950571
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    # Import the class Setting to be able to create a setting to be updated
    from ansible.config.setting import Setting
    s = Setting('some_key', 'some_value')
    config.update_setting(s)
    assert config._global_settings[s.name] == s


# Generated at 2022-06-22 19:21:38.311050
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert (config_data.get_setting("bad") == None)


# Generated at 2022-06-22 19:21:41.022893
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()

# Generated at 2022-06-22 19:21:42.515145
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-22 19:21:44.808047
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cfg_data = ConfigData()
    assert len(cfg_data._global_settings) == 0
    assert len(cfg_data._plugins) == 0


# Generated at 2022-06-22 19:21:46.672590
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-22 19:21:48.185378
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    assert data.get_setting('') == None

# Generated at 2022-06-22 19:21:57.938121
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.plugin_docs import get_docstring
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.connection.paramiko_ssh import Connection as paramikoConnection
    connection_name = 'paramiko_ssh'
    plugin_loader = PluginLoader(connection_name, 'connection', None, config_data)
    connection_cls = plugin_loader.find_plugin(connection_name)

    # You can get a plugin's docstring using the get_docstring function.
    connection_doc = get_docstring(connection_cls)
    assert connection_doc['short_description'] == "A connection plugin for SSH based connections"

    # A plugin's name is available as an attribute of the class.
    assert connection_cl

# Generated at 2022-06-22 19:22:01.310746
# Unit test for constructor of class ConfigData
def test_ConfigData():

    configdata = ConfigData()
    setting = Setting('test_setting', 'value')
    configdata.update_setting(setting)
    assert(configdata.get_setting('test_setting') == setting)


# Generated at 2022-06-22 19:22:05.375505
# Unit test for constructor of class ConfigData
def test_ConfigData():
    # Instantiate an empty object
    config_data = ConfigData()
    # Check that we have initialized all the fields properly
    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-22 19:22:11.260996
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {'name':'foo','value':'bar'}

    config_data.update_setting(setting,plugin=None)
    assert config_data._global_settings[setting['name']] == setting
    config_data_setting = config_data.get_setting(setting['name'],plugin=None)
    assert config_data_setting == setting



# Generated at 2022-06-22 19:22:18.681693
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    from ansible.plugins.loader import collection_loader, action_loader, lookup_loader
    from ansible.plugins.callback import callback_loader
    from ansible.plugins.connection import connection_loader


# Generated at 2022-06-22 19:22:21.016459
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    assert(len(configData._global_settings) == 0)
    assert(len(configData._plugins) == 0)


# Generated at 2022-06-22 19:22:28.683596
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('ANSIBLE_NOCOWS', 'False'))
    config_data.update_setting(Setting('ANSIBLE_KEEP_REMOTE_FILES', 'False'))
    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings(Plugin('action', 'ping'))) == 0


# Generated at 2022-06-22 19:22:36.185313
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    setting = Setting('name', 'value')

    config_data.update_setting(setting)

    setting = Setting('name', 'value', 'module', 'foo')

    config_data.update_setting(setting)

    setting = Setting('name', 'value', 'module', 'bar')

    config_data.update_setting(setting)

    assert config_data.get_setting('name') is not None
    assert config_data.get_setting('name', plugin=Plugin('module', 'foo')) is not None
    assert config_data.get_setting('name', plugin=Plugin('module', 'bar')) is not None
    assert config_data.get_setting('name', plugin=Plugin('module', 'baz')) is None

# Generated at 2022-06-22 19:22:46.948043
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}
    setting_a = ConfigSettings("ansible", "a", "A", "b", "B", "c")
    config_data.update_setting(setting_a)
    assert config_data._global_settings != {}
    assert config_data._plugins == {}
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}
    setting_a = ConfigSettings("ansible", "a", "A", "b", "B", "c")
    config_data.update_setting(setting_a, plugin="lookup")
    assert config_data._global_settings == {}
    assert config_data._plugins != {}


# Generated at 2022-06-22 19:22:57.744335
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.utils.plugin_docs import (
        get_docstring,
    )
    from ansible.plugins.loader import (
        find_plugin_file,
        get_all_plugin_loaders,
        get_plugin_class,
        get_plugin_type,
        get_loader,
    )
    from ansible.plugins.loader import get_all_plugin_names

    # Setup initial values
    config_data = ConfigData()
    plugin_name = 'ActionModule'
    plugin_type = 'action'
    plugin_path = 'ansible.plugins.action.' + plugin_name
    plugin = get_loader()(plugin_name)

    # Populate global settings

# Generated at 2022-06-22 19:23:04.077536
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    '''
    Test method get_setting of class ConfigData
    '''
    c = ConfigData()
    assert c.get_setting('not_found') == None

    from collections import namedtuple
    Plugin = namedtuple('Plugin', ['name', 'type'])
    p = Plugin('bar', 'foo')
    c.update_setting('baz', p)
    assert c.get_setting('baz',p) == 'baz'

# Generated at 2022-06-22 19:23:09.168592
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.config.setting import Setting

    config_data = ConfigData()

    # Test 1
    setting1 = Setting('setting1', 'value1')
    config_data.update_setting(setting1)
    assert config_data.get_setting('setting1') == setting1
    assert config_data.get_setting('setting2') is None

    # Test 2
    setting2 = Setting('setting2', 'value2')
    config_data.update_setting(setting2)
    assert config_data.get_setting('setting2') == setting2



# Generated at 2022-06-22 19:23:13.125467
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():


    config_data = ConfigData()

    setting = Setting('user', 'bob')
    config_data.update_setting(setting)

    assert config_data.get_setting('user').name == 'user'
    assert config_data.get_setting('user').value == 'bob'

    setting = Setting('user', 'john', 'plugin', 'plugin.yml')
    config_data.update_setting(setting)

    assert config_data.get_setting('user', Plugin('plugin', 'plugin.yml')).name == 'user'
    assert config_data.get_setting('user', Plugin('plugin', 'plugin.yml')).value == 'john'



# Generated at 2022-06-22 19:23:24.334057
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_config_data = ConfigData()
    test_config_data._global_settings = {
        'test1': 'test1',
        'test2': 'test2'
    }
    plugin_types = {
        'test': {
            'test1': {
                'test1': 'test1',
                'test2': 'test2'
            },
            'test2': {
                'test1': 'test1',
                'test2': 'test2'
            }
        }
    }
    test_config_data._plugins = plugin_types
    settings = test_config_data.get_settings()
    settings_from_method = test_config_data.get_settings(None)
    for setting in settings:
        assert setting in settings_from_method

# Generated at 2022-06-22 19:23:25.335326
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass


# Generated at 2022-06-22 19:23:29.550403
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert isinstance(cd, ConfigData)
    assert isinstance(cd._global_settings, dict)
    assert isinstance(cd._plugins, dict)


# Generated at 2022-06-22 19:23:32.371145
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    assert data.get_setting('test') == None


# Generated at 2022-06-22 19:23:43.373195
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    DATA = ConfigData()

    s1 = Setting("s1", "s1", "s1", "s1")
    DATA.update_setting(s2)

    s2 = Setting("s2", "s2", "s2", "s2")
    DATA.update_setting(s2)

    s22 = Setting("s2", "s2", "s2", "s2")
    DATA.update_setting(s22, plugin=Plugin(name="p", type="p"))

    p1 = Plugin(name="p1", type="p1")
    p2 = Plugin(name="p2", type="p2")

    assert len(DATA.get_settings()) == 2
    assert len(DATA.get_settings(p1)) == 0
    assert len(DATA.get_settings(p2)) == 0

# Generated at 2022-06-22 19:23:47.618173
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data
    assert config_data._global_settings is not None
    assert config_data._plugins is not None

# Test for get_setting() of class ConfigData

# Generated at 2022-06-22 19:23:50.058146
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0



# Generated at 2022-06-22 19:23:52.336011
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('hello') == None


# Generated at 2022-06-22 19:23:56.385764
# Unit test for constructor of class ConfigData
def test_ConfigData():
    # test init and get_settings
    config_data = ConfigData()
    assert not config_data.get_settings()


# Generated at 2022-06-22 19:24:00.638804
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    cd.update_setting(Setting('host_key_checking', 'False'))
    cd.update_setting(Setting('color', 'True'))
    cd.update_setting(Setting('timeout', '20'))
    cd.update_setting(Setting('timeout', '30'))
    print(cd.get_settings())


# Generated at 2022-06-22 19:24:10.447897
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    test_setting = Setting('constant_setting', 'constant', 'default_value2')
    config_data.update_setting(test_setting)
    setting = config_data.get_setting('constant_setting')
    assert setting.name == 'constant_setting'

    test_setting = Setting('constant_setting', 'constant', 'default_value2')
    import collections
    test_plugin = collections.namedtuple('Plugin', ['type', 'name'])
    plugin = test_plugin(type='connection', name='localhost')
    config_data.update_setting(test_setting, plugin)
    setting = config_data.get_setting('constant_setting', plugin)
    assert setting.name == 'constant_setting'

# Generated at 2022-06-22 19:24:15.574168
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = Setting('setting_name', 'setting_value', 'setting_section')
    plugin = Plugin(setting, 'plugin_type', 'plugin_name')
    config_data.update_setting(setting)
    assert config_data.get_setting('setting_name', None) == setting
    assert config_data.get_setting('setting_name', plugin) == None
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('setting_name', plugin) == setting



# Generated at 2022-06-22 19:24:24.656789
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    # Check empty ConfigData
    assert not config_data.get_settings()
    # Check global settings
    setting = {'name': 'test1', 'value': 'value1'}
    config_data.update_setting(setting)
    assert config_data.get_settings()
    assert config_data.get_settings()[0]['name'] == 'test1'
    assert config_data.get_settings()[0]['value'] == 'value1'
    assert len(config_data.get_settings()) == 1
    # Check plugin settings
    setting = {'name': 'test2', 'value': 'value2'}
    config_data.update_setting(setting, plugin={'name': 'test_plugin', 'type': 'action'})

# Generated at 2022-06-22 19:24:31.761817
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    from collections import namedtuple
    Plugin = namedtuple('Plugin', ['type', 'name'])
    plugin = Plugin(type='action', name='my_awesome_action')
    from collections import namedtuple
    Setting = namedtuple('Setting', ['name', 'value', 'origin'])
    plugin_setting = Setting(name='FOO', value='1', origin='my_awesome_action')
    config_data.update_setting(plugin_setting, plugin=plugin)
    assert config_data.get_setting('FOO', plugin=plugin) == plugin_setting


# Generated at 2022-06-22 19:24:34.316685
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data



# Generated at 2022-06-22 19:24:43.488189
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('vault_password_file','/tmp/foobar',None))
    config_data.update_setting(Setting('connection', 'ssh', Plugin('connection', 'ssh')))
    config_data.update_setting(Setting('ansible_ssh_user', '', Plugin('connection', 'ssh')))
    config_data.update_setting(Setting('ansible_ssh_port', '', Plugin('connection', 'ssh')))

    assert config_data.get_setting('vault_password_file') == Setting('vault_password_file','/tmp/foobar',None)
    assert config_data.get_setting('connection') is None

# Generated at 2022-06-22 19:24:47.372175
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('ansible_connection', 'local', 'ansible.cfg'))


# Generated at 2022-06-22 19:24:53.514803
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('collection_paths', '/home/foo'))
    config_data.update_setting(Setting('collection_paths', '/home/bar'))
    setting = config_data.get_setting('collection_paths')

    assert setting.name == 'collection_paths'
    assert setting.value == '/home/bar'


# Generated at 2022-06-22 19:25:04.306844
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()
    
    setting = {'name': 'param1', 'value': 'value1'}
    plugin_type = 'library'
    plugin_name = 'my_module'
    plugin = ConfigPlugin(plugin_type, plugin_name)
    
    configdata.update_setting(setting, plugin)
    
    assert configdata._plugins[plugin_type][plugin_name]['param1'] == setting
   
    setting = {'name': 'param2', 'value': 'value2'}
    configdata.update_setting(setting)
    
    assert configdata._global_settings['param2'] == setting
    
    setting = {'name': 'param3', 'value': 'value3'}
    plugin2_type = 'module'
    plugin2_name = 'other_module'
   

# Generated at 2022-06-22 19:25:09.904247
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    data = ConfigData()
    assert len(data.get_settings()) == 0

    s0 = Setting('foo')
    s1 = Setting('bar')
    data.update_setting(s0)
    data.update_setting(s1)
    settings = data.get_settings()

    assert len(settings) == 2
    for s in settings:
        assert s == 'foo' or s == 'bar'


# Generated at 2022-06-22 19:25:13.952737
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    thisConfigData = ConfigData()
    thisConfigData.update_setting('a', 'b')
    assert ConfigData.get_setting(thisConfigData, 'a') == 'b'


# Generated at 2022-06-22 19:25:14.956872
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData() is not None


# Generated at 2022-06-22 19:25:22.533817
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import pytest
    from ansible.galaxy.api.model import Namespace, Plugin

    # Setting with type str
    global_setting = Namespace(name='my_setting_0', type_='str',
                         value='Hello, World!')
    config_data = ConfigData()
    config_data.update_setting(global_setting)
    assert global_setting.name in config_data._global_settings

    # Setting with type bool
    global_setting = Namespace(name='my_setting_1', type_='bool',
                               value=True)
    config_data.update_setting(global_setting)

    # Setting with type int
    global_setting = Namespace(name='my_setting_2', type_='int',
                               value=42)
    config_data.update_setting(global_setting)



# Generated at 2022-06-22 19:25:25.572567
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-22 19:25:31.702575
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("setting1")
    assert len(config_data._global_settings) == 1
    config_data.update_setting("setting2", "plugin")
    assert len(config_data._plugins["plugin"]) == 1
    config_data.update_setting("setting3", "plugin", "pluginname")
    assert len(config_data._plugins["plugin"]["pluginname"]) == 1


# Generated at 2022-06-22 19:25:33.760728
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_setting('display_arg_spec') is None


# Generated at 2022-06-22 19:25:45.181501
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    
    get_setting_result = config_data.get_setting('SETTING1')
    assert get_setting_result is None
    get_all_settings_result = config_data.get_settings()
    assert len(get_all_settings_result) == 0

    setting = Setting('SETTING1', '123', [])
    config_data.update_setting(setting)
    
    get_setting_result = config_data.get_setting('SETTING1')
    assert get_setting_result is not None
    assert get_setting_result.name == 'SETTING1'
    assert get_setting_result == setting

    get_all_settings_result = config_data.get_settings()
    assert len(get_all_settings_result) == 1
    assert get_all_

# Generated at 2022-06-22 19:25:56.113904
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Create a ConfigData object
    config_data = ConfigData()

    # Create a plugin object
    plugin_type = 'C'
    plugin_name = 'CN'
    plugin = Plugin(plugin_type, plugin_name)

    # Create a setting object
    setting_name = 'SN'
    setting_value = 'SV'
    setting = Setting(setting_name, setting_value)

    # Modify the setting by calling the update_setting method on ConfigData object
    config_data.update_setting(setting, plugin)

    # Verify the correctness of update_setting behavior with get_setting
    assert(setting == config_data.get_setting(setting_name, plugin))


# Generated at 2022-06-22 19:26:02.620532
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    config.update_setting(Setting("frodo", "bagins"), plugin="ansible.plugins.action.Frob")
    config.update_setting(Setting("samwise", "gamgee"))

    global_settings = config.get_settings()
    assert len(global_settings) == 1
    assert global_settings[0].name == "samwise"

    frob_settings = config.get_settings(plugin="ansible.plugins.action.Frob")
    assert len(frob_settings) == 1
    assert frob_settings[0].name == "frodo"

# Generated at 2022-06-22 19:26:06.912996
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(get_test_setting('test_name'))

    assert config_data.get_setting('test_name') is not None
    assert config_data.get_setting('test_name').name == 'test_name'


# Generated at 2022-06-22 19:26:12.388502
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting('test1')
    config_data.update_setting('test2')

    result = config_data.get_setting('test1')
    expected = ('test1')
    assert result == expected

    result = config_data.get_setting('test2')
    expected = ('test2')
    assert result == expected



# Generated at 2022-06-22 19:26:15.950845
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("test_plugin_one", "test_plugin_two")

    assert config_data._plugins['test_plugin_one']['test_plugin_two'] ==  "test_plugin_one"


# Generated at 2022-06-22 19:26:23.231259
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from units.mock.plugin import MockSetting
    config_data = ConfigData()
    setting_one = MockSetting(name='one', value=1)
    setting_two = MockSetting(name='two', value=2)
    setting_three = MockSetting(name='three', value=3)
    setting_four = MockSetting(name='four', value=4)
    setting_five = MockSetting(name='five', value=5)
    config_data.update_setting(setting_one)
    config_data.update_setting(setting_two, plugin=MockSetting(plugin_type='type', plugin_name='name'))
    config_data.update_setting(setting_three, plugin=MockSetting(plugin_type='type', plugin_name='other'))

# Generated at 2022-06-22 19:26:29.829465
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Init
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0

    # Update a global setting
    setting = {'name': 'A_GLOBAL_SETTING', 'value': 'A_GLOBAL_VALUE'}
    config_data.update_setting(setting)
    assert len(config_data.get_settings()) == 1
    assert config_data.get_setting('A_GLOBAL_SETTING')['value'] == 'A_GLOBAL_VALUE'

    # Update a plugin setting
    plugin = {'type': 'A_PLUGIN_TYPE', 'name': 'A_PLUGIN_NAME'}
    setting = {'name': 'A_PLUGIN_SETTING', 'value': 'A_PLUGIN_VALUE'}

# Generated at 2022-06-22 19:26:32.935765
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class C(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value


# Generated at 2022-06-22 19:26:40.689713
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Construct an object of class ConfigData
    configData = ConfigData()

    # Test case when there is a global setting and a plugin setting
    setting1 = Setting()
    setting2 = Setting()
    setting1.name = "plugin_dir"
    setting2.name = "plugins"
    setting2.path = "/path/to/plugins"
    configData._global_settings["plugin_dir"] = setting1
    configData._global_settings["plugins"] = setting2
    plugin = Plugin(PluginType.CACHE, "memory")
    setting3 = Setting()
    setting3.name = "ttl"
    setting3.path = "/path/to/ttl"
    if plugin.type not in configData._plugins:
        configData._plugins[plugin.type] = {}

# Generated at 2022-06-22 19:26:50.674907
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    # Plugin is None
    assert config_data.get_settings() == []

    # Plugin name is not in plugins
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader.get("module", "failure")
    assert config_data.get_settings(plugin) == []

    # Plugin setting is not in plugins
    config_data.update_setting("test_setting")
    assert config_data.get_settings(plugin) == []

    # Plugin is in plugins
    config_data.update_setting("test_setting", plugin)
    assert config_data.get_settings(plugin) == ["test_setting"]

# Generated at 2022-06-22 19:26:53.586104
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert not config_data._global_settings
    assert not config_data._plugins


# Generated at 2022-06-22 19:27:04.725767
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansiblelint.config import ConfigData, ConfigLine
    from ansiblelint.rule import RuleMatch, RulesCollection

    config_data = ConfigData()
    config_data.update_setting(ConfigLine('lineinfile', 'dest', 'regex', 'insertafter'))
    config_data.update_setting(ConfigLine('copy', 'src', 'dest', 'folder'))
    config_data.update_setting(ConfigLine('win_copy', 'src', 'dest', 'folder'))

    rule_collection = RulesCollection()

    count = 0
    for setting in config_data.get_settings(None):
        count += 1
        rule_collection.append(RuleMatch(None, setting, {}))

    assert len(rule_collection) == 3
    assert count == 3

    rule_collection = RulesCollection()

    count

# Generated at 2022-06-22 19:27:07.953205
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    x = ConfigData()
    assert x.get_setting('name') == None
    assert x.get_setting('name', 'base') == None
    assert x.get_setting('name', 'base', 'action') == None

# Generated at 2022-06-22 19:27:12.740156
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    assert not configData._plugins
    assert not configData._global_settings

# test for update_setting method of class ConfigData

# Generated at 2022-06-22 19:27:22.347193
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test with none
    config = ConfigData()
    assert config.get_setting('debug') == None
    assert config.get_setting('debug', None) == None

    # Test with global setting
    config_global = ConfigData()
    config_global.update_setting(Setting('debug', 'False', 'bool'))
    assert config_global.get_setting('debug') == None
    assert config_global.get_setting('debug', None) != None
    assert config_global.get_setting('debug', None).value == 'False'

    # Test with plugin setting for plugin with wrong type
    plugin = Plugin('module_utils', 'setup', Plugin.PLUGIN_TYPE_MODULE_UTILS)
    config_module_utils = ConfigData()

# Generated at 2022-06-22 19:27:32.545109
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()
    plugin_plugin = Plugin(type_='plugin', name='plugin')
    plugin_test = Plugin(type_='test', name='test')

    config.update_setting(Setting(name='global1'))
    config.update_setting(Setting(name='global2'))
    config.update_setting(Setting(name='local1'), plugin=plugin_plugin)
    config.update_setting(Setting(name='local2'), plugin=plugin_plugin)
    config.update_setting(Setting(name='local3'), plugin=plugin_test)
    config.update_setting(Setting(name='local4'), plugin=plugin_test)

    g = config.get_settings()
    assert len(g) == 2
    assert {'name': 'global1'} in g

# Generated at 2022-06-22 19:27:37.250689
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    assert not configData.get_settings()
    setting = ConfigSetting("name", "value")
    configData.update_setting(setting)
    assert configData.get_settings()


# Generated at 2022-06-22 19:27:38.959364
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data._global_settings == {}
    assert data._plugins == {}


# Generated at 2022-06-22 19:27:41.267039
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

# Generated at 2022-06-22 19:27:48.123768
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    assert config_data.get_settings(plugin=None) == []

    setting = ConfigSetting('var1', 'value1')
    config_data.update_setting(setting)
    assert config_data.get_settings() == [setting]
    assert config_data.get_settings(plugin=None) == [setting]
    assert config_data.get_setting('var1') == setting
    a

# Generated at 2022-06-22 19:27:49.611320
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-22 19:27:53.538505
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = Plugin('timer', 'stat')
    setting = Setting('start_time', '00:00:00')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('start_time', plugin) == setting



# Generated at 2022-06-22 19:27:54.627075
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-22 19:28:00.708023
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {'a': 1, 'b': 2}
    config_data._plugins = {
        'type1': {
            'plugin1': {'c': 3, 'd': 4, 'e': 5},
            'plugin2': {'f': 6, 'g': 7, 'h': 8}
        },
        'type2': {
            'plugin3': {'i': 9, 'j': 10, 'k': 11},
            'plugin4': {'l': 12, 'm': 13, 'n': 14}
        }
    }
    assert len(config_data.get_settings()) == 2

    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-22 19:28:10.779884
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test global setting
    test_setting = ConfigSetting(name='name', value='value', origin='origin', priority='priority')

    assert config_data.get_setting(test_setting.name) is None
    assert config_data.get_setting(test_setting.name, None) is None

    config_data.update_setting(test_setting, None)

    assert config_data.get_setting(test_setting.name) is not None
    assert config_data.get_setting(test_setting.name) == test_setting
    assert config_data.get_setting(test_setting.name, None) is not None
    assert config_data.get_setting(test_setting.name, None) == test_setting

    # Test setting with plugin

# Generated at 2022-06-22 19:28:18.830854
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.config.manager import PluginConfigManager
    from ansible.config.setting import Setting

    plugin_config_manager = PluginConfigManager()
    config_data = ConfigData()

    setting = Setting('foo', 'bar', 'baz', plugin_config_manager.get_plugin_configuration_definition('cache'), config_data=config_data)

    config_data.update_setting(setting, plugin=setting.plugin)

    assert config_data.get_setting('foo', plugin=setting.plugin) == setting


# Generated at 2022-06-22 19:28:21.243044
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert(ConfigData() is not None)


# Generated at 2022-06-22 19:28:27.885616
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    plugin_name = 'aws'
    plugin_type = 'cloud'
    setting_name = 'region'
    plugin = PluginDescriptor(plugin_name, plugin_type)

    # test non-existing plugins
    assert config_data.get_setting(setting_name, plugin) is None

    # test non-existing settings
    config_data.update_setting(Setting(setting_name), plugin)
    assert config_data.get_setting(setting_name, plugin) is not None
    assert config_data.get_setting('foo', plugin) is None


# Generated at 2022-06-22 19:28:30.619405
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    import pprint
    pprint.pprint(config_data)

# Generated at 2022-06-22 19:28:39.483791
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Create an instance of ConfigData
    config_data = ConfigData()
    # Create plugin instances of each plugin type
    plugin_action = Plugin('action', '../lib/ansible/plugins/action')
    plugin_connection = Plugin('connection', '../lib/ansible/plugins/action')
    plugin_filter = Plugin('filter', '../lib/ansible/plugins/action')

    # Add settings to instance
    config_data.update_setting(Setting('display_skipped_hosts', 'False'))
    config_data.update_setting(Setting('nocows', '1'))
    config_data.update_setting(Setting('host_key_checking', 'False', plugin_connection))
    config_data.update_setting(Setting('pipelining', '1', plugin_connection))

    # Get all settings

# Generated at 2022-06-22 19:28:51.505079
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Create a sample list of AnsiblePlugin objects
    plugin1 = AnsiblePlugin('name1', 'type')
    plugin2 = AnsiblePlugin('name2', 'module')
    plugin_list = [plugin1, plugin2]
    
    # Create an instance of class ConfigData
    conf_data = ConfigData()

    # Update the object with a sample set of data
    conf_data.update_setting(AnsibleSetting('setting1', 'value1', plugin1))
    conf_data.update_setting(AnsibleSetting('setting2', 'value2', plugin2))
    conf_data.update_setting(AnsibleSetting('setting3', 'value3', None))
    conf_data.update_setting(AnsibleSetting('setting4', 'value4', None))
    

# Generated at 2022-06-22 19:28:58.502161
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader

    c = ConfigData()

    assert c.get_settings() == []

    # When no config is set, get_settings should return an empty array
    assert c.get_settings(PluginLoader.get("shell", "echo")) == []

    # When config is set, get_settings should return an array containing only the setting
    s = Setting("name", "value", "line", "filename", "version")
    c.update_setting(s, PluginLoader.get("shell", "echo"))
    assert c.get_settings(PluginLoader.get("shell", "echo"))[0] == s

# Generated at 2022-06-22 19:29:05.236645
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    plugin = None
    assert data.get_setting('foo', plugin) is None
    assert data.get_settings(plugin) == []
    data.update_setting('foo', None)
    assert data.get_setting('foo', plugin) is not None
    assert data.get_settings(plugin) is not None

# Generated at 2022-06-22 19:29:13.988786
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint import RuleMatch

    config_data = ConfigData()

    assert not config_data.get_settings()

    # global setting
    setting = RuleMatch("test_global", "global setting", "global")
    config_data.update_setting(setting)
    assert config_data.get_settings() == [setting]

    # plugin setting
    setting = RuleMatch("test_plugin", "plugin setting", "plugin")
    config_data.update_setting(setting, setting)
    assert config_data.get_settings() == [setting]
    assert config_data.get_setting("test_plugin", setting) == setting

    # same plugin type, different plugin names
    setting = RuleMatch("test_plugin", "plugin setting", "plugin")

# Generated at 2022-06-22 19:29:24.864575
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()

    plugin_1 = Plugin('group', 'test_plugin_1')
    plugin_2 = Plugin('group', 'test_plugin_2')
    plugin_3 = Plugin('group', 'test_plugin_3')
    plugin_4 = Plugin('group', 'test_plugin_4')
    plugin_5 = Plugin('group', 'test_plugin_5')
    plugin_6 = Plugin('group', 'test_plugin_6')

    setting_1 = Setting(plugin_1, 'setting_1', 'value for setting_1 in test_plugin_1')
    setting_2 = Setting(plugin_1, 'setting_2', 'value for setting_2 in test_plugin_1')
    setting_3 = Setting(plugin_2, 'setting_1', 'value for setting_1 in test_plugin_2')


# Generated at 2022-06-22 19:29:32.696740
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint import AnsibleLintRule
    from ansiblelint import RulesCollection
    from ansiblelint import Runner
    import re

    config_data = ConfigData()
    class_name = re.sub(r'(.)([A-Z][a-z]+)', r'\1_\2', 'EqualityFor'
        'DebugInsteadOfAssert')
    class_name = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', class_name).lower()
    class_def = locals()[class_name]

    if 'equal' == 'equal':
        class_def.id = 'ANSIBLE0004'
    if 'equal' == 'equal':
        class_def.shortdesc = 'Debug statements'
        class_def.description

# Generated at 2022-06-22 19:29:34.466332
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert len(data._global_settings) == 0
    assert len(data._plugins) == 0


# Generated at 2022-06-22 19:29:37.330030
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    container = ConfigData()
    type = "connection"
    name = "local"
    setting = Setting(name)
    plugin = Plugin(type, name)
    container.update_setting(setting, plugin)
    assert container.get_setting(name, plugin) == setting


# Generated at 2022-06-22 19:29:40.392318
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    config.update_setting('a', 'b', 'c')
    config.update_setting('d', 'e', 'f')

    assert config.get_settings() == ['a', 'b', 'c', 'd', 'e', 'f']



# Generated at 2022-06-22 19:29:51.448962
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    from ansible.config.data import ConfigData, ConfigSetting
    from ansible.config.manager import ConfigManager
    from ansible.plugins import PluginLoader

    plugin = PluginLoader.get('connection', 'local')

    test_config_data = ConfigData()
    test_config_data.update_setting(ConfigSetting(name='foo', value='bar'))

    with patch('ansible.config.data.ConfigManager') as MockConfigManager:
        MockConfigManager_instance = MockConfigManager.return_value
        MockConfigManager_instance.get_config_data.return_value = test_config_data

        config_manager = ConfigManager()

        # test get_setting without arguments
        assert config_manager.get_setting('foo')

# Generated at 2022-06-22 19:29:53.887142
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert(not config._global_settings)
    assert(not config._plugins)


# Generated at 2022-06-22 19:30:01.547351
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    
    #return empty array
    assert config_data.get_settings() == []

    from ansible.config.setting import Setting

    #return array include one setting
    setting1 = Setting('setting1',None,None)
    config_data.update_setting(setting1)
    assert config_data.get_settings() == [setting1]

    #return array include two setting
    setting2 = Setting('setting1',None,None)
    config_data.update_setting(setting2)
    assert config_data.get_settings() == [setting1,setting2]

# Generated at 2022-06-22 19:30:02.397213
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()


# Generated at 2022-06-22 19:30:05.263268
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-22 19:30:13.544657
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    p1 = Plugin('cache')
    p2 = Plugin('test')
    p3 = Plugin('dummy')
    cd = ConfigData()
    a = Setting('a', 'global', 'global')
    b = Setting('b', 'global', 'global', ('test', 'cache'))
    c = Setting('c', 'global', 'global', ('dummy', ))
    d = Setting('d', 'test', 'test')
    e = Setting('e', 'test', 'test', ('dummy', ))
    g = Setting('g', 'cache', 'cache')
    h = Setting('h', 'cache', 'cache', ('dummy', ))
    cd.update_setting(a)
    cd.update_setting(b)
    cd.update_setting(c)
    cd.update_setting(d)
    cd.update