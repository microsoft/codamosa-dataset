

# Generated at 2022-06-22 19:20:16.315630
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from ansible.plugins.loader import PluginLoader
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.path import unfrackpath

    config_data = ConfigData()

    # Global test
    correct_setting = PluginSetting('foo', 'bar', 'baz')
    config_data.update_setting(correct_setting)
    assert config_data.get_setting('foo') == correct_setting

    # Simple plugin test
    settings = []
    settings.append(PluginSetting('fizz', 'buzz', 'buzz'))
    settings.append(PluginSetting('url', 'http://example.com', False))

# Generated at 2022-06-22 19:20:18.673522
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    result = config_data.get_settings()
    assert result == []



# Generated at 2022-06-22 19:20:26.137081
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint.rule import Rule, RulesCollection
    from ansiblelint.rules.AnsibleLintRule import AnsibleLintRule
    from ansiblelint.rules.AnsibleLintRuleMatch import AnsibleLintRuleMatch
    from ansiblelint.rules.LineRuleMatch import LineRuleMatch
    from ansiblelint.rules.MultiLineRuleMatch import MultiLineRuleMatch
    from ansiblelint.rules.TaskRuleMatch import TaskRuleMatch
    from ansiblelint.rules.FileRuleMatch import FileRuleMatch
    from ansiblelint.rules.RuleMatch import RuleMatch

    import json

    rule_settings = {"max_line_length": {"type": "int", "default": 80}, "max_line_length_exclude_comments": {"type": "boolean", "default": True}}
    rule

# Generated at 2022-06-22 19:20:37.437464
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.config import setting_loader

    config_data = ConfigData()

    config_data.update_setting(setting_loader.Setting(name='LOG_PATH', value='/path/to/logs/log.txt'))
    config_data.update_setting(setting_loader.Setting(name='LOG_PATH', value='/path/to/logs/log.txt',
                                                      plugin_type='callback', plugin_name='json'))

    global_settings = config_data.get_settings()
    assert(global_settings[0].name == 'LOG_PATH')
    assert(global_settings[0].value == '/path/to/logs/log.txt')

    from ansible.plugins.loader import callback_loader, shell_loader
    plugin = callback_loader.CallbackModule('json')

    plugin_settings

# Generated at 2022-06-22 19:20:39.371126
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert not cd._global_settings
    assert not cd._plugins
    assert cd.get_setting('foo') is None

# Generated at 2022-06-22 19:20:45.032961
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting("DOCKER_HOST") is None
    updated_setting = Setting("DOCKER_HOST", "tcp://localhost:2375")
    config_data.update_setting(updated_setting)
    assert config_data.get_setting("DOCKER_HOST") == updated_setting
    assert config_data.get_setting("DOCKER_HOST") != Setting("DOCKER_HOST", "tcp://localhost:2376")
    assert config_data.get_setting("DOCKER_TLS_CERT_DIR") is None



# Generated at 2022-06-22 19:20:46.632078
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-22 19:20:55.143267
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    plugin = Plugin('lookup', 'lookup1')
    config_data.update_setting(Setting('key1', 'value1', plugin.type, plugin.name))
    config_data.update_setting(Setting('key2', 'value2', plugin.type, plugin.name))
    config_data.update_setting(Setting('key3', 'value3', 'filter', 'filter1'))
    config_data.update_setting(Setting('key4', 'value4'))

    assert config_data._global_settings['key4'] == Setting('key4', 'value4')

# Generated at 2022-06-22 19:21:04.804883
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansiblelint.rules.CommandsInsteadOfModulesRule import CommandsInsteadOfModulesRule
    from ansiblelint.runner import Runner
    from ansiblelint.rule_loader import RulesCollection

    import os
    test_runner = Runner(
        playbooks=[os.path.join(os.getcwd(), 'test/test.yml')],
        rules=RulesCollection([CommandsInsteadOfModulesRule()]),
        quiet=True)
    setting = test_runner.config.rule_config.get_settings()[0]
    assert setting.name == 'commands'
    assert setting.value == ['command', 'shell']
    plugin = test_runner.plugins[0][0]
    setting = test_runner.config.rule_config.get_settings(plugin)[0]

# Generated at 2022-06-22 19:21:08.540160
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # Create object.
    config_data = ConfigData()

    # Check if object is not equal to None.
    assert config_data != None
    assert config_data != ''

    # Check if object is a ConfigData class.
    assert isinstance(config_data, ConfigData)


# Generated at 2022-06-22 19:21:10.501853
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert (config_data._global_settings == {})
    assert (config_data._plugins == {})

# Generated at 2022-06-22 19:21:17.950726
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import PluginLoader
    from ansible.parsing.plugin_docs import read_docstring

    config_data = ConfigData()
    plugin = PluginLoader('action', 'shell', 'ActionModule', None, read_docstring(None, 'shell')).get_plugin()
    setting = Setting('shell', 'ActionModule', '/bin/sh')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('shell', plugin) == setting



# Generated at 2022-06-22 19:21:19.103120
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Create Class Instance
    config_data = ConfigDat

# Generated at 2022-06-22 19:21:28.376522
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.config.setting import Setting

    configdata = ConfigData()
    plugin = Plugin('', '')
    setting = Setting('', '', '')

    # Test 1 : Get global settings
    assert configdata.get_settings() == []

    # Test 2 : Get global settings
    configdata.update_setting(setting)
    settings = configdata.get_settings()
    assert settings == [] or settings == [setting]

    # Test 3 : Get settings for plugin
    configdata.update_setting(setting, plugin)
    settings = configdata.get_settings(plugin)
    assert settings == [] or settings == [setting]

# Generated at 2022-06-22 19:21:29.779466
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config == config


# Generated at 2022-06-22 19:21:31.993272
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config is not None, "The instance creation for ConfigData failed"

# The unit test for the constructor of class Setting

# Generated at 2022-06-22 19:21:33.445516
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert isinstance(config, ConfigData)


# Generated at 2022-06-22 19:21:38.311498
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    plugin = PluginInfo('Test', 'test')
    setting = ConfigSetting(name='asdf', value='asdf')
    cd.update_setting(setting, plugin=PluginInfo('Test', 'test'))
    assert cd._plugins['Test']['test']['asdf'] == setting
    assert cd.get_settings(plugin) == [setting]


# Generated at 2022-06-22 19:21:46.312262
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    # update global setting
    setting1 = Setting('setting_1', 'value1', 'global')
    config_data.update_setting(setting1)
    assert config_data._global_settings['setting_1'] == setting1
    assert config_data._plugins == {}

    # update plugin setting
    setting2 = Setting('setting_2', 'value2', 'plugin')
    config_data.update_setting(setting2, plugin=Plugin('module', 'cd'))
    assert config_data._global_settings['setting_1'] == setting1
    assert config_data._plugins['module']['cd']['setting_2'] == setting2

    # update another setting for the same plugin

# Generated at 2022-06-22 19:21:48.964666
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("setting")
    assert config_data.update_setting("setting") == [setting]


# Generated at 2022-06-22 19:21:53.354865
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    settings = ConfigData()

    plugin = None
    settings.update_setting(None, plugin)
    assert settings.get_setting(None, plugin) is None

    plugin = ConfigData()
    settings.update_setting(None, plugin)
    assert settings.get_setting(None, plugin) is None

# Generated at 2022-06-22 19:22:01.108935
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('one', 1))
    config_data.update_setting(Setting('two', 2, 'test'))
    config_data.update_setting(Setting('three', 3, 'test', 'filter'))

    assert config_data.get_setting('one') == Setting('one', 1)
    assert config_data.get_setting('two') == None
    assert config_data.get_setting('three') == None

    assert config_data.get_setting('one', Plugin('test')) == None
    assert config_data.get_setting('two', Plugin('test')) == Setting('two', 2, 'test')
    assert config_data.get_setting('three', Plugin('test')) == None


# Generated at 2022-06-22 19:22:04.016383
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}, 'ConfigData not successfully instantiated'


# Generated at 2022-06-22 19:22:12.216023
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting('DEPRECATION_WARNINGS', None) is None
    config_data.update_setting(Setting('DEPRECATION_WARNINGS', 'yes', 'bool',
                                       None, None))
    assert config_data.get_setting('DEPRECATION_WARNINGS', None) is not None
    with pytest.raises(Exception) as e_info:
        config_data.update_setting(Setting('DEPRECATION_WARNINGS', 'yes', 'bool',
                                       None, None), 'bogus')



# Generated at 2022-06-22 19:22:14.000646
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("CONFIG_FILE") == None


# Generated at 2022-06-22 19:22:16.285455
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    assert config_data.get_setting("name") == None


# Generated at 2022-06-22 19:22:25.813536
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('foo', 'bar', 'baz'))
    config_data.update_setting(ConfigSetting('bar', 'baz', 'foo'))
    config_data.update_setting(ConfigSetting('foo', 'cbz', 'cbaz', 'common'))
    assert config_data._global_settings['bar'].value == 'baz'
    assert config_data._global_settings['foo'].value == 'bar'
    assert config_data._plugins['common']['foo']['foo'].value == 'cbz'
    assert config_data._plugins['common']['foo']['foo'].type == 'common'
    assert config_data._plugins['common']['foo']['foo'].name == 'foo'



# Generated at 2022-06-22 19:22:27.695983
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data, object)


# Generated at 2022-06-22 19:22:30.347715
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    my_data = ConfigData()
    print("Testing get_settings method of ConfigData class")
    assert (my_data.get_settings() == [])


# Generated at 2022-06-22 19:22:30.841649
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData()

# Generated at 2022-06-22 19:22:35.408674
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = Plugin('filter', 'core')
    setting = Setting('FOO', 'BAR')
    config_data.update_setting(setting)
    assert config_data.get_setting('FOO') is not None
    assert config_data.get_setting('FOO', plugin) is None
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('FOO', plugin) is not None


# Generated at 2022-06-22 19:22:46.128968
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo1', 'bar1'))
    settings = config_data.get_settings()
    for setting in settings:
        if setting.name == 'foo':
            assert setting.value == 'bar'
        else:
            assert setting.value == 'bar1'

if __name__ == '__main__':

    config_data = ConfigData()

    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)

    setting = Setting('foo1', 'bar1', Plugin('action', 'baz'))
    config_data.update_setting(setting)

# Generated at 2022-06-22 19:22:51.095702
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    print(config_data._global_settings)
    config_data.update_setting(ConfigSetting(name='name1'))
    print(config_data.get_settings())
    config_data.update_setting(ConfigSetting(name='name2'))
    print(config_data.get_settings())



# Generated at 2022-06-22 19:23:01.307451
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cd.update_setting(Setting('a', 'b'))
    cd.update_setting(Setting('c', 'd'), Plugin('plugins'))
    cd.update_setting(Setting('e', 'f'), Plugin('plugins', 'module'))

    assert(cd.get_setting('a')) == {'name': 'a', 'value': 'b', 'plugin': None}
    assert(cd.get_setting('c', Plugin('plugins'))) == {'name': 'c', 'value': 'd', 'plugin': {'type': 'plugins', 'name': None}}
    assert(cd.get_setting('e', Plugin('plugins', 'module'))) == {'name': 'e', 'value': 'f', 'plugin': {'type': 'plugins', 'name': 'module'}}

# Generated at 2022-06-22 19:23:06.948147
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()

    setting0 = Setting(name='is_in_fact', value='true', plugin=Plugin(name='setup', type='fact'))
    setting1 = Setting(name='is_in_action', value='true', plugin=Plugin(name='debug', type='action'))

    cd.update_setting(setting0)
    cd.update_setting(setting1)

    assert 'is_in_fact' in cd._global_settings
    assert 'is_in_action' in cd._plugins['action']['debug']


# Generated at 2022-06-22 19:23:16.916352
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    conf = ConfigData()
    data = {'name': 'Test', 'type': 'Test', 'constants': {'TestConfig': {'value': 1}}}
    plugin_type = PluginType(data)
    data = {'name': 'Test', 'type': plugin_type, 'paths': ['Tests/test_plugin'], 'conf': {'TestConfig': {'value': 1}}}
    plugin = Plugin(data)
    data = {'name': 'TestConfig', 'value': 1, 'default': 0, 'scope': 'Test'}
    conf.update_setting(Setting(data), plugin)
    assert conf.get_setting('TestConfig', plugin).name == 'TestConfig'
    data = {'name': 'TestConfig', 'value': 1, 'default': 0}
    conf.update_setting(Setting(data))

# Generated at 2022-06-22 19:23:23.863117
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    plugin = Plugin('TestPlugin', Plugin.CORE_PLUGIN)
    test_setting = Setting('test_setting', 'test value', 'test description')
    config_data = ConfigData()
    assert config_data.get_setting('test_setting') is None
    config_data.update_setting(test_setting, plugin)
    assert config_data.get_setting('test_setting') is None
    assert config_data.get_setting('test_setting', plugin) == test_setting


# Generated at 2022-06-22 19:23:35.464100
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.module_utils.common.text.converters import to_text
    from ansible.plugins.loader import configfinder

    config_data = ConfigData()

    for plugin_type in configfinder.ConfigFinder._cache:
        for plugin_name in configfinder.ConfigFinder._cache[plugin_type]:
            for setting_name in configfinder.ConfigFinder._cache[plugin_type][plugin_name]:
                setting = configfinder.ConfigFinder._cache[plugin_type][plugin_name][setting_name]
                config_data.update_setting(setting, plugin=setting)

    # check if settings are cached in ConfigData
    global_settings_in_ConfigData = config_data.get_settings()
    global_settings_in_ConfigFinder = configfinder.ConfigFinder.get_settings()
    assert len

# Generated at 2022-06-22 19:23:46.406247
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting('dummy') is None
    assert config_data.get_setting('dummy_plugin', 'dummy_type') is None
    setting = Setting('dummy', 'dummy')
    config_data.update_setting(setting)
    assert config_data.get_setting('dummy').value == 'dummy'
    assert config_data.get_setting('dummy_plugin', 'dummy_type') is None
    setting = Setting('dummy_plugin', 'dummy')
    plugin = Plugin('dummy_plugin', 'dummy_type')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('dummy_plugin').value is None

# Generated at 2022-06-22 19:23:54.901272
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    setting1 = ConfigSetting(name='setting1', value='foo', origin='consts.py')
    setting2 = ConfigSetting(name='setting2', value='bar', origin='consts.py')

    config_data.update_setting(setting1)
    config_data.update_setting(setting1, plugin=Plugin(name='plugin1', type='action'))
    config_data.update_setting(setting2, plugin=Plugin(name='plugin2', type='action'))

    assert config_data.get_setting('setting1') == setting1
    assert config_data.get_setting('setting1', plugin=Plugin(name='plugin1', type='action')) == setting1

    result = config_data.get_setting('setting2')
    assert result is None

    result = config_data

# Generated at 2022-06-22 19:23:56.676931
# Unit test for constructor of class ConfigData
def test_ConfigData():

    data = ConfigData()
    assert data is not None
    assert data._global_settings == {}
    assert data._plugins == {}

# Generated at 2022-06-22 19:23:59.082983
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0

# Generated at 2022-06-22 19:23:59.805064
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()


# Generated at 2022-06-22 19:24:01.163011
# Unit test for constructor of class ConfigData
def test_ConfigData():

    test_obj = ConfigData()
    assert test_obj is not None


# Generated at 2022-06-22 19:24:11.006597
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    def _test_override_global_setting(config_data, plugin):

        test_global_setting.name = 'test_global_setting_override'
        config_data.update_setting(test_global_setting)

        settings = config_data.get_settings(plugin)
        assert len(settings) == 2
        assert settings[0].name == 'test_plugin_setting'
        assert plugin.type == settings[0].plugin.type
        assert plugin.name == settings[0].plugin.name
        assert settings[1].name == 'test_global_setting_override'
        assert settings[1].plugin is None

    test_global_setting = Setting('test_global_setting', 'global')
    test_global_setting.value = ['test_global_setting_value']

# Generated at 2022-06-22 19:24:13.391137
# Unit test for constructor of class ConfigData
def test_ConfigData():
    test_data = ConfigData()
    assert len(test_data._global_settings) == 0
    assert len(test_data._plugins) == 0


# Generated at 2022-06-22 19:24:24.076462
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    C = ConfigData()
    assert len(C.get_settings()) == 0
    assert len(C.get_settings('foo')) == 0

    class Setting(object):
        def __init__(self):
            self.name = 'setting_name'
    s = Setting()

    C.update_setting(s)
    assert len(C.get_settings()) == 1
    assert len(C.get_settings('foo')) == 0

    class Plugin(object):
        def __init__(self):
            self.name = 'plugin_name'
            self.type = 'plugin_type'
    p = Plugin()

    C.update_setting(s, p)
    assert len(C.get_settings()) == 1
    assert len(C.get_settings(p)) == 1


# Generated at 2022-06-22 19:24:26.147900
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)

test_ConfigData()


# Generated at 2022-06-22 19:24:36.146073
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('ansible_host', 'host2'))
    config_data.update_setting(ConfigSetting('ansible_host', 'host1', FakePlugin('connection', 'local')))
    config_data.update_setting(ConfigSetting('ansible_host', 'host3', FakePlugin('connection', 'netconf')))
    ssh_setting = config_data.get_setting('ansible_host')
    local_setting = config_data.get_setting('ansible_host', FakePlugin('connection', 'local'))
    netconf_setting = config_data.get_setting('ansible_host', FakePlugin('connection', 'netconf'))

    assert ssh_setting == ConfigSetting('ansible_host', 'host2')
    assert local_setting == ConfigSetting

# Generated at 2022-06-22 19:24:44.983531
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    assert_equals(type(config), ConfigData)
    assert_equals(type(config.get_settings()), list)
    assert_equals(len(config.get_settings()), 0)
    assert_equals(type(config.get_settings().__getitem__(0)), str)
    assert_equals(type(config.get_setting('ansible.cfg')), ConfigData)
    assert_equals(type(config.get_setting('ansible.cfg', 'yml')), ConfigData)
    assert_equals(type(config.get_setting('ansible.cfg', 'ini')), ConfigData)
    assert_equals(type(config.get_setting('ansible.cfg', 'json')), ConfigData)

# Generated at 2022-06-22 19:24:45.672600
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()


# Generated at 2022-06-22 19:24:51.077605
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    plugin_type = 'module'
    plugin_name = 'copy'
    setting_name = 'copy'
    setting_value = 'copy'
    setting = Setting(setting_name, setting_value)

    cd = ConfigData()
    cd.update_setting(setting, Plugin(plugin_type, plugin_name))

    assert(len(cd.get_settings()) == 1)
    assert(cd.get_settings(Plugin(plugin_type, plugin_name))[0].value == setting_value)
    assert(cd.get_setting(setting_name, Plugin(plugin_type, plugin_name)) == setting)

# Generated at 2022-06-22 19:24:53.971034
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('plugins') is None


# Generated at 2022-06-22 19:25:02.243100
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('a','','','','','',''))
    config_data.update_setting(Setting('b', '', '', '', '', '', ''))
    config_data.update_setting(Setting('c', '', '', '', '', '', '', '', 'default'))
    config_data.update_setting(Setting('d', '', '', '', '', '', '', '', 'default'))
    config_data.update_setting(Setting('e', 'action', '', '', '', '', '', '', 'default'))
    config_data.update_setting(Setting('f', 'action', '', '', '', '', '', '', 'default'))

# Generated at 2022-06-22 19:25:10.234992
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import ansible.plugins.loader as loader
    import ansible.plugins.filter.core as core

    test_configdata = ConfigData()
    test_plugin = loader.FilterModuleLoader(core, './', 'core')
    test_setting = Setting('test_setting', test_plugin, 'test_value')
    test_configdata.update_setting(test_setting, test_plugin)
    assert test_configdata.get_setting('test_setting') == test_setting
    assert test_setting in test_configdata.get_settings()

# Generated at 2022-06-22 19:25:21.022027
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._plugins ={'cache':{'basic': {'enabled': {'name': 'enabled', 'value': True, 'priority': 1000},
                                              'ttl': {'name': 'ttl', 'value': '1', 'priority': 0}},
                                    'redis': {'host': {'name': 'host', 'value': 'localhost', 'priority': 0},
                                              'port': {'name': 'port', 'value': '6379', 'priority': 1000}}},
                           'module_utils':{'basic': {'use_module_utils_path': {'name': 'use_module_utils_path', 'value': True,
                                                                                  'priority': 0}}}}
    settings = config_data.get_settings()
    assert settings == []

# Generated at 2022-06-22 19:25:23.941283
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # assert config_data.get_settings() == []



# Generated at 2022-06-22 19:25:26.778588
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    config_data.update_setting('setting')

    assert config_data.get_setting('setting') == 'setting'


# Generated at 2022-06-22 19:25:28.156484
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-22 19:25:31.871799
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    class setting_test:
        name = "foo"
        value = "bar"

    config_data.update_setting(setting_test)

    assert config_data._global_settings["foo"] == setting_test


# Generated at 2022-06-22 19:25:34.543100
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    setting = 'foo'
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting



# Generated at 2022-06-22 19:25:36.634233
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert c._global_settings == {}
    assert c._plugins == {}

# Generated at 2022-06-22 19:25:39.001800
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-22 19:25:40.972742
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()
    ret = configdata.get_settings()
    assert ret == []


# Generated at 2022-06-22 19:25:48.357288
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings_data = ConfigData()

    assert len(settings_data._global_settings) == 0
    for setting in settings_data.get_settings():
        assert False
    for setting in settings_data.get_settings(None):
        assert False

    settings_data._global_settings["dummy"] = "dummy_setting"
    settings_data._plugins["dummy"]["plugin"]["dummy"] = "dummy_setting_plugin"

    assert settings_data.get_settings() == ["dummy_setting"]
    assert settings_data.get_settings(None) == ["dummy_setting"]

# Generated at 2022-06-22 19:25:52.484057
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    assert configData.get_setting("ansible_test") is None


# Generated at 2022-06-22 19:26:01.026214
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    
    config_data = ConfigData()
    # Test with a valid global setting
    parameter_setting = ParameterSetting(name='timeout', value='20')
    config_data.update_setting(setting=parameter_setting)
    
    assert 'timeout' in config_data._global_settings

    # Test with a valid setting
    parameter_setting = ParameterSetting(name='ssh_args', value='-F /dev/null', plugin=Plugin('connection', 'ssh'))
    config_data.update_setting(setting=parameter_setting)

    assert 'ssh' in config_data._plugins
    assert 'ssh_args' in config_data._plugins['connection']['ssh']


# Plugin = namedtuple('Plugin', ['type', 'name'])

# Generated at 2022-06-22 19:26:02.349455
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    print(config.get_settings())

# Generated at 2022-06-22 19:26:08.420137
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    c = config_data.get_setting("setting1")
    assert c is None

    from collections import namedtuple
    Setting = namedtuple("Setting", ["name", "value", "priority", "origin"])
    setting = Setting("setting1", "value1", 1, "origin1")
    config_data.update_setting(setting)
    c = config_data.get_setting("setting1")
    assert c.value == "value1"


# Generated at 2022-06-22 19:26:13.869472
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting1 = dict()
    setting1['name'] = 'setting1'
    setting1['value'] = 'value1'
    setting1['section'] = 'global'
    setting1['plugin'] = 'None'

    config_data.update_setting(setting1)
    assert(config_data.get_settings() == [setting1])


# Generated at 2022-06-22 19:26:21.909399
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()

    # Test global setting
    setting1 = Setting(name="setting1", value="value1")
    data.update_setting(setting1)

    assert data == {
        "_global_settings": {
            "setting1": {
                "name": "setting1",
                "value": "value1"
            }
        },
        "_plugins": {}
    }

    # Test plugin setting
    setting2 = Setting(name="setting2", value="value2")
    data.update_setting(setting2, plugin="test")


# Generated at 2022-06-22 19:26:25.725166
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    data = ConfigData()

    with pytest.raises(TypeError):
        data.get_setting()

    with pytest.raises(TypeError):
        data.get_setting(None)

    with pytest.raises(TypeError):
        data.get_setting(None, None)



# Generated at 2022-06-22 19:26:28.736673
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None
    assert config_data._global_settings is not None
    assert config_data._plugins is not None


# Generated at 2022-06-22 19:26:37.422428
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    cd = ConfigData()

    setting1 = Setting("cows", "red", "cows are red")
    cd.update_setting(setting1)
    cd.update_setting(Setting("cows", "black", "cows are black"))
    cd.update_setting(Setting("horses", "white", "horses are white"))
    cd.update_setting(Setting("horses", "black", "horses are black"))
    cd.update_setting(Setting("chicken", "white", "chickens are white"))
    cd.update_setting(Setting("chicken", "black", "chickens are black"))

    assert cd.get_setting("cows") == setting1
    assert cd.get_setting("horses") == Setting("horses", "white", "horses are white")

# Generated at 2022-06-22 19:26:45.586090
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {'name': 'gather_facts', 'section': 'defaults', 'default': 'no', 'type': 'bool'}
    config_data.update_setting(setting, None)
    assert config_data._global_settings['gather_facts'].name == 'gather_facts'
    assert config_data._global_settings['gather_facts'].section == 'defaults'
    assert config_data._global_settings['gather_facts'].default == 'no'
    assert config_data._global_settings['gather_facts'].type == 'bool'


# Generated at 2022-06-22 19:26:47.338358
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cdata = ConfigData()

    assert cdata is not None


# Generated at 2022-06-22 19:26:56.923008
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # TODO: These methods and attributes are part of the Plugin class and will be implemented there
    #       Eventually we will be able to remove this method from this class
    class DummyPlugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class DummySetting:
        def __init__(self, name):
            self.name = name

    plugin1 = DummyPlugin('type1', 'name1')
    plugin2 = DummyPlugin('type2', 'name2')

    config_data = ConfigData()

    # Test 1 - Plugin is None
    # Verify that we get None if not setting exists
    assert config_data.get_setting('foo') is None

    # Test 2 - Plugin is None
    # Verify that we get the expected setting when searching by name

# Generated at 2022-06-22 19:26:58.933024
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:27:08.414469
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

    setting1 = Setting('repository_dir', '/home/user/', None, None, None)
    config_data.update_setting(setting1)

    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0].name == 'repository_dir'
    assert config_data.get_settings()[0].value == '/home/user/'

    setting2 = Setting('galaxy_server_listen_address', '127.0.0.1', 'galaxy', None, None)
    config_data.update_setting(setting2)
    assert len(config_data.get_settings()) == 1

    plugin = Plugin('galaxy', 'galaxy')

# Generated at 2022-06-22 19:27:15.886313
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    # Test getting empty global settings
    assert len(config_data.get_settings()) == 0

    # Test getting empty settings for a plugin
    assert len(config_data.get_settings(plugin=None)) == 0

    # Test getting settings for a plugin that does not exist
    assert len(config_data.get_settings(plugin=None)) == 0



# Generated at 2022-06-22 19:27:27.039445
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    plugin_type = C.DEFAULT_CORE_PLUGIN
    plugin_name = "ansible.builtin.debug"
    plugin = C.Plugin(plugin_type, plugin_name)
    assert config.get_setting("foo") is None
    assert config.get_setting("foo", plugin) is None
    config.update_setting(C.Setting("foo", "bar", "bar"))
    assert config.get_setting("foo") == "bar"
    assert config.get_setting("foo", plugin) is None
    config.update_setting(C.Setting("foo", "bar", "bar", plugin))
    assert config.get_setting("foo", plugin) == "bar"
    assert config.get_setting("foo") == "bar"

# Generated at 2022-06-22 19:27:32.770816
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    # Method get_setting should work correctly when argument plugin is None
    assert config_data.get_setting('None') == None

    # Method get_setting should work correctly when argument plugin exist
    plugin = ''
    config_data.update_setting('setting', plugin=plugin)
    config_data.get_setting('setting', plugin=plugin)

    assert config_data.get_setting('setting', plugin=plugin) == 'setting'



# Generated at 2022-06-22 19:27:36.708965
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # Test the constructor
    c = ConfigData()

    # Check my members are empty
    assert c._global_settings == {}

    # Check my plugins dict is empty
    assert c._plugins == {}



# Generated at 2022-06-22 19:27:42.161162
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # create a config data
    config_data = ConfigData()
    # create a setting
    setting1 = Setting()
    setting1.name = "name1"
    setting1.value = "value1"
    setting1.plugin_type = "plugin_type1"
    setting1.plugin_name = "plugin_name1"
    setting1.source_file = "source_file1"
    # create a plugin
    plugin1 = Plugin()
    plugin1.type = "plugin_type1"
    plugin1.name = "plugin_name1"
    # update the setting in the config_data
    config_data.update_setting(setting1, plugin1)
    # test whether the setting is updated
    assert config_data.get_setting("name1", plugin1) == setting1
    assert config_data.get_

# Generated at 2022-06-22 19:27:51.821430
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import pytest
    from collections import namedtuple

    data = ConfigData()

    setting = namedtuple('Setting', ['name', 'value', 'origin'])
    plugin = namedtuple('Plugin', ['name', 'type'])

    # test when plugin is None
    data.update_setting(setting(name='test_setting', value='test_value', origin='test_origin'), plugin=None)
    assert data._global_settings['test_setting'].name == 'test_setting'
    assert data._global_settings['test_setting'].value == 'test_value'
    assert data._global_settings['test_setting'].origin == 'test_origin'

    #test when plugin is not None

# Generated at 2022-06-22 19:27:52.629695
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert True

# Generated at 2022-06-22 19:27:59.488364
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    setting1 = {'name': 'key1'}
    setting2 = {'name': 'key2'}
    setting3 = {'name': 'key3'}
    data.update_setting(setting1)
    data.update_setting(setting2)
    data.update_setting(setting3)
    data.update_setting(setting1, plugin='foo')
    data.update_setting(setting2, plugin='foo')
    data.update_setting(setting3, plugin='foo')

    assert data.get_settings() == [setting1, setting2, setting3]
    assert data.get_settings(plugin='foo') == [setting1, setting2, setting3]


# Generated at 2022-06-22 19:28:09.199068
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    plugin = Plugin("source")
    plugin.type = "vars"
    plugin.name = "mock_source"

    setting = Setting("mock_setting")
    config_data.update_setting(setting, plugin)

    assert config_data.get_setting("mock_setting", plugin) == setting

    assert config_data.get_setting("mock_setting") is None
    assert config_data.get_setting(plugin.name, plugin.type) is None
    assert config_data.get_setting("not_mock_setting", plugin) is None
    assert config_data.get_setting("mock_setting", Plugin("mock_source2")) is None



# Generated at 2022-06-22 19:28:16.961303
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    data._global_settings["g1"] = Setting("g1", "g1_value")
    data._global_settings["g2"] = Setting("g2", "g2_value")
    data._plugins["P"] = { "p1": {}, "p2": {} }
    data._plugins["P"]["p1"]["s1"] = { "s1" : Setting("s1", "s1_value") }
    data._plugins["P"]["p1"]["s2"] = { "s2" : Setting("s2", "s2_value") }
    data._plugins["P"]["p2"]["s1"] = { "s1" : Setting("s1", "s1_value") }

# Generated at 2022-06-22 19:28:24.809043
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings = [{'name':'1', 'value':'a'}, {'name':'2', 'value':'b'}]
    config_data = ConfigData()
    for setting in settings:
        assert config_data.get_setting(setting['name']) is None, 'Setting {} should be null'.format(setting['name'])


# Generated at 2022-06-22 19:28:26.691973
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data is not None


# Generated at 2022-06-22 19:28:35.652843
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test', 'test', 'test')

    config_data.update_setting(setting=setting)

    assert config_data.get_setting('test') is not None
    assert config_data.get_setting('test').value == 'test'
    assert config_data.get_setting('test').name == 'test'
    assert config_data.get_setting('test').description == 'test'



# Generated at 2022-06-22 19:28:41.617088
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    p = PluginTypeSpec(PluginType.MODULE, "Test")
    s = ConfigSettingSpec(p, "Test", "data", ConfigOptionType.BOOLEAN, "Test data", True)
    cd.update_setting(s)

    settings = cd.get_settings()
    assert len(settings) == 1
    assert settings[0].type == ConfigOptionType.BOOLEAN
    assert settings[0].value == True
    assert settings[0].plugin_type == PluginType.MODULE
    assert settings[0].plugin_name == "Test"

    settings = cd.get_settings(p)
    assert len(settings) == 1
    assert settings[0].type == ConfigOptionType.BOOLEAN
    assert settings[0].value == True

# Generated at 2022-06-22 19:28:52.169132
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_01 = Setting(plugin=Plugin('core','aiocli'), name='core_aiocli_dummy1', value='core_aiocli_dummy1_value')
    setting_02 = Setting(plugin=Plugin('core','aiocli'), name='core_aiocli_dummy2', value='core_aiocli_dummy2_value')

    # when
    config_data.update_setting(setting_01)
    config_data.update_setting(setting_02)

    # then
    assert config_data.get_setting('core_aiocli_dummy1', Plugin('core','aiocli')) == setting_01
    assert config_data.get_setting('core_aiocli_dummy2', Plugin('core','aiocli')) == setting_

# Generated at 2022-06-22 19:28:53.574490
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None



# Generated at 2022-06-22 19:29:01.448669
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    setting = plugin = None
    setting = configData.get_setting('ANSIBLE_FORKS', plugin)
    assert(setting is None)

    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.strategy import StrategyBase

    plugin_name = 'linear'
    plugin_type = 'strategy'
    plugin = PluginLoader.find_plugin(plugin_name, plugin_type)()
    setting = configData.get_setting('ANSIBLE_FORKS', plugin)
    assert(setting is None)

    plugin_name = 'some_non_exist_plugin'
    plugin = PluginLoader.find_plugin(plugin_name, plugin_type)()
    setting = configData.get_setting('ANSIBLE_FORKS', plugin)
    assert(setting is None)

# Unit test

# Generated at 2022-06-22 19:29:03.603235
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config


# Generated at 2022-06-22 19:29:08.247246
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting('max-retries')
    config_data.update_setting('pipelining')

    assert config_data._global_settings.keys() == {'max-retries', 'pipelining'}
    assert config_data._plugins == {}



# Generated at 2022-06-22 19:29:19.737820
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.module_utils._text import to_text
    from ansible.parsing.plugin_docs import read_docstring  # pylint: disable=import-error

    config_data = ConfigData()
    config_data.update_setting(Setting('g_name', 'g_description', 'g_env', 'g_ini', 'g_yaml', type('g', (object,), {'__module__': 'g'})()))
    config_data.update_setting(Setting('g_name', 'g_description', 'g_env', 'g_ini', 'g_yaml', type('g', (object,), {'__module__': 'g'})()))
    assert len(config_data.get_settings()) == 1

# Generated at 2022-06-22 19:29:31.045620
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    class Setting(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value

    class Plugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    assert config_data.get_setting('action_plugins') is None
    assert config_data.get_setting('action_plugins', Plugin('action_plugins', 'lookup')) is None

    action_plugins = Setting('action_plugins', '/ansible/action_plugins')
    config_data.update_setting(action_plugins)
    assert config_data.get_setting('action_plugins') is not None

    assert config_data.get_setting('action_plugins') is not None
    assert config_data.get_setting

# Generated at 2022-06-22 19:29:40.928639
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    data.update_setting(AnsibleSetting('invalid_section', 'invalid_key', 'value'))
    assert data._global_settings == {}
    assert data._plugins == {}
    data.update_setting(AnsibleSetting('defaults', 'invalid_key', 'value'))
    assert data._global_settings == {}
    assert data._plugins == {}
    data.update_setting(AnsibleSetting('defaults', 'inventory', 'value'))
    assert data._global_settings == {'inventory': AnsibleSetting('defaults', 'inventory', 'value')}
    assert data._plugins == {}
    data.update_setting(AnsibleSetting('defaults', 'inventory', 'value2'))

# Generated at 2022-06-22 19:29:46.490695
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {
        "namespace": "string",
        "name": "string",
        "value": "string"
    }
    config_data.update_setting(setting, plugin={
        "type": "string",
        "name": "string"
    })


# Generated at 2022-06-22 19:29:57.275624
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    def mock_ConfigSetting(name, value, origin, plugin=None):
        return (name, value, origin)


# Generated at 2022-06-22 19:29:58.682768
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd is not None


# Generated at 2022-06-22 19:30:04.854238
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Unit test for method get_setting of class ConfigData
    config_data = ConfigData()
    plugin = Plugin.factory(
        {
            "name": "unit-test-plugin",
            "type": "foo"
        }
    )
    setting = Setting.factory(
        {
            "name": "unit_test_setting",
            "value": "unit_test_value"
        }
    )
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting("unit_test_setting", plugin)
    assert config_data.get_setting("unit_test_setting").value == 'unit_test_value'


# Generated at 2022-06-22 19:30:08.096600
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configdata = ConfigData()
    setting = configdata.get_setting("FOO")
    assert setting is None
