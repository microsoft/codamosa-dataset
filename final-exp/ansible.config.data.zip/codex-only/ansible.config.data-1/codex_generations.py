

# Generated at 2022-06-22 19:20:12.375475
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    setting = ConfigSetting(name='name', value='value', plugin=Plugin('plugin'), origin='origin')
    cd.update_setting(setting, plugin=setting.plugin)
    assert cd.get_setting(setting.name) == setting
    assert cd.get_setting(setting.name, plugin=setting.plugin) == setting
    assert cd.get_settings()[0] == setting
    assert cd.get_settings(plugin=setting.plugin)[0] == setting


#
# Class ConfigSetting
#


# Generated at 2022-06-22 19:20:19.286557
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = Setting('path', '/tmp')
    config_data.update_setting(setting)
    assert config_data.get_setting('path') == setting

    setting2 = Setting('path', '/tmp')
    config_data.update_setting(setting2, Plugin(type='action', name='copy'))
    assert config_data.get_setting('path', plugin=Plugin(type='action', name='copy')) == setting2
    assert config_data.get_setting('path') == setting



# Generated at 2022-06-22 19:20:23.318246
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    setting = ConfigSetting.create_setting(name=u'NGINX_VERSION', value={u'version': u'1.10.1'})
    config_data.update_setting(setting, None)

    assert len(config_data._global_settings) > 0



# Generated at 2022-06-22 19:20:27.285953
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("setting1", "plugin1")
    config_data.update_setting("setting2", "plugin2")
    config_data.update_setting("setting3", "plugin3")


# Generated at 2022-06-22 19:20:29.072010
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    pass



# Generated at 2022-06-22 19:20:33.669579
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    data = ConfigData()
    p = MockPlugin(name="foo", type="bar")
    setting = MockSetting(name="foo")
    data.update_setting(setting, p)
    settings = data.get_settings(p)
    for s in settings:
        assert s.name == "foo"
    print(settings)


# Generated at 2022-06-22 19:20:36.309034
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:20:43.892079
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin_name = "faked_plugin"
    plugin_type = "filter"

    # add setting to global list
    setting = Setting()
    setting.name = "global_setting"
    setting.value = "1"
    config_data.update_setting(setting)

    # add setting to plugin
    setting = Setting()
    setting.name = "plugin_setting"
    setting.value = "2"
    plugin_spec = PluginSpec(plugin_name, plugin_type)
    config_data.update_setting(setting, plugin_spec)

    assert config_data.get_setting("global_setting") is not None
    assert config_data.get_setting("plugin_setting", plugin_spec) is not None


# Generated at 2022-06-22 19:20:51.625652
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    setting1 = Setting('int_setting1', 'an_int', 1)
    setting2 = Setting('str_setting2', 'a_str', '2')
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)

    assert len(config_data.get_settings()) == 2
    assert config_data.get_setting('int_setting1').value == 1
    assert config_data.get_setting('str_setting2').value == '2'



# Generated at 2022-06-22 19:21:01.854515
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from units.module_utils.ansible_modules import AnsibleCollectionConfig, PluginConfig
    # Setup test
    configData = ConfigData()
    setting = PluginConfig(None, "foo", "bar", "baz")
    configData.update_setting(setting)
    setting = PluginConfig(AnsibleCollectionConfig("foo"), "bar", "baz", "baz2")
    configData.update_setting(setting)
    assert configData.get_setting("foo") is not None
    assert configData.get_setting("bar") is None
    assert configData.get_setting("foo", AnsibleCollectionConfig("foo")) is None
    assert configData.get_setting("bar", AnsibleCollectionConfig("foo")) is not None


# Generated at 2022-06-22 19:21:04.132700
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert not config_data._global_settings
    assert not config_data._plugins


# Generated at 2022-06-22 19:21:11.452560
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # initialization
    config = ConfigData()

    # run operation
    config._global_settings = {"a":1,"b":2,"c":3}
    config._plugins = {'a':{'b':{'c':4, 'd': 5}}}
    plugin = Plugin("role", "foo")

    # test assertions
    assert config._global_settings["a"] == 1
    assert config._global_settings["b"] == 2
    assert config._global_settings["c"] == 3
    assert config._plugins["a"]["b"]["c"] == 4
    assert config._plugins["a"]["b"]["d"] == 5
    # assert that plugin is what it should be

    # case 1: plugin is None
    setting = Setting("d", "value")
    config.update_setting(setting)
    assert config

# Generated at 2022-06-22 19:21:18.803720
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()
    assert [] == configdata.get_settings()
    import types
    fake_module = types.ModuleType("test")
    fake_module.type = "test_module"
    fake_module.name = "test"
    setting_mock = types.ModuleType("test")
    setting_mock.name = "test_setting"
    configdata.update_setting(setting_mock, fake_module)
    assert [setting_mock] == configdata.get_s

# Generated at 2022-06-22 19:21:21.772730
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data
    assert len(data._global_settings) == 0
    assert len(data._plugins) == 0


# Generated at 2022-06-22 19:21:23.478906
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert len(config_data.get_settings()) == 0



# Generated at 2022-06-22 19:21:28.934146
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting(name='setting1'))
    config_data.update_setting(Setting(name='setting2'))

    for setting in config_data.get_settings():
        assert setting.name in ['setting1', 'setting2']


# Generated at 2022-06-22 19:21:35.465504
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.plugin = None
    config_data.plugin.name = 'Test'
    setting = TestSetting(name='test')
    config_data.update_setting(setting)
    assert config_data.get_settings() == [setting]


# Generated at 2022-06-22 19:21:36.950532
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-22 19:21:42.960120
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data_ = ConfigData();
    plugin = Plugin("collections", "ansible.posix");
    config_data_.update_setting(Setting("list_separator", ":", plugin));
    config_data_.update_setting(Setting("location", "/etc/ansible", 0));
    assert config_data_.get_setting("list_separator").name == "list_separator"
    assert config_data_.get_setting("list_separator").value == ":"
    assert config_data_.get_setting("list_separator").plugin == plugin
    assert config_data_.get_setting("location").name == "location"
    assert config_data_.get_setting("location").value == "/etc/ansible"
    assert config_data_.get_setting("location").plugin == None



# Generated at 2022-06-22 19:21:53.633117
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    import pytest
    from unit.fixtures.plugins import TestPlugin

    # Make test plugin
    plugin = TestPlugin()

    # Make dummy config object
    config = ConfigData()
    with pytest.raises(ValueError) as excinfo:
        config.get_settings()
    assert 'No setting found' in str(excinfo.value)

    # Update with dummy setting
    s = plugin.add_setting('name1')
    config.update_setting(s, plugin=plugin)
    assert config.get_settings()[0].name == 'name1'
    assert config.get_settings(plugin=plugin)[0].name == 'name1'

    # Check bad plugin
    with pytest.raises(ValueError) as excinfo:
        config.get_settings(plugin=TestPlugin('bad_plugin'))

# Generated at 2022-06-22 19:21:54.239419
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cd = ConfigData()

# Generated at 2022-06-22 19:22:01.499604
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    # Test __init__
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    # Add global settings
    config_data.update_setting(Setting('A', '1', 'A', '1'))
    config_data.update_setting(Setting('B', '2', 'B', '2'))
    config_data.update_setting(Setting('C', '3', 'C', '3'))

    # Test global settings
    settings = config_data.get_settings()
    assert len(settings) == 3

# Generated at 2022-06-22 19:22:03.622675
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-22 19:22:12.484909
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data=ConfigData()
    config_data.update_setting(None,None)
    assert config_data._global_settings is {}
    config_data._global_settings={'hello':'world'}
    config_data.update_setting(None,None)
    assert config_data._global_settings is {'hello':'world'}
    config_data._plugins={'plugin_hello':{'hello_world':{'setting':'setting'}}}
    config_data.update_setting(None,None)
    assert config_data._plugins is {'plugin_hello':{'hello_world':{'setting':'setting'}}}



# Generated at 2022-06-22 19:22:23.319115
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    setting_vars = []
    setting_vars.append(ConfigSetting(name='ANSIBLE_COW_SELECTION', value='random'))
    setting_vars.append(ConfigSetting(name='ANSIBLE_COW_WHITELIST', value='bud-frogs'))
    setting_vars.append(ConfigSetting(name='ANSIBLE_NOCOWS', value=True))

    data = ConfigData()

    for setting in setting_vars:
        data.update_setting(setting)

    assert data.get_setting('ANSIBLE_COW_SELECTION') == setting_vars[0]
    assert data.get_setting('ANSIBLE_NOCOWS') == setting_vars[2]
    assert data.get_setting('ANSIBLE_COW_WHITELIST') == setting_vars[1]

# Generated at 2022-06-22 19:22:24.657938
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert(False)


# Generated at 2022-06-22 19:22:33.817393
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    actual_ret = []
    expected_ret = []

    fake_ConfigData = ConfigData()
    for i in range(0,100):
        fake_ConfigData.update_setting("test"+str(i))
        actual_ret.append(fake_ConfigData.get_setting("test"+str(i)))

        expected_ret.append("test"+str(i))
    print("\nactual return of get_setting:\n")
    print(actual_ret)
    print("\nexpected return of get_setting:\n")
    print(expected_ret)
    if actual_ret == expected_ret:
        print("\nis equal")
    else:
        print("\nis not equal")


test_ConfigData_get_setting()

# Generated at 2022-06-22 19:22:44.079702
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    setting = {
        'name': 'any_setting',
        'default': 'any_default',
        'values': ['any_value1', 'any_value2'],
        'type': 'any_type',
        'cli': ['--any-cli'],
        'ini': ['any_ini'],
        'env': ['ANY_ENV'],
        'vars': ['vars']
    }

    setting_obj = AnsibleConfigSetting(**setting)

    config_data_obj = ConfigData()


# Generated at 2022-06-22 19:22:54.283506
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    cfg_data = ConfigData()

    # test setting not existing
    rst_1 = cfg_data.get_setting("foo")
    assert not rst_1

    # test plugin not existing
    rst_2 = cfg_data.get_setting("bar", "foobar")
    assert not rst_2

    # test normal setting
    s = dict(name="foo", value="", origin="", priorities=[],
             vault_id="", vault_priorities=[])
    cfg_data.update_setting(s)
    rst_3 = cfg_data.get_setting("foo")
    assert rst_3 == s

    # test plugin setting
    s = dict(name="bar", value="", origin="", priorities=[],
             vault_id="", vault_priorities=[])
   

# Generated at 2022-06-22 19:23:04.389710
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.config.setting import Setting
    from ansible.config.constants import Plugin, TokenKind, ConstantKind
    a = ConfigData()
    b = Setting(
        key='a',
        section=None,
        kind=TokenKind(ConstantKind.BOOLEAN),
        default=False,
        env_var=None,
        ini=None,
        yaml=None,
        cli=None,
        class_only=True,
        version_added='2.8',
        version_removed=None
    )

# Generated at 2022-06-22 19:23:07.486713
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()

    assert len(config._plugins) == 0
    assert len(config._global_settings) == 0



# Generated at 2022-06-22 19:23:17.206928
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()
    plugins = PluginLoader()

    plugin_type = 'cache'
    for plugin_name in plugins.all(plugin_type):
        plugin = plugins.get(plugin_type, plugin_name)
        settings = config_data.get_settings(plugin)
        assert len(settings) == 0

        setting_name = "my_setting"
        setting_value = "my_value"
        setting = ConfigSetting()
        setting.name = setting_name
        setting.value = setting_value
        config_data.update_setting(setting, plugin)

        settings = config_data.get_settings(plugin)
        assert len(settings) == 1
        setting = settings[0]
        assert setting.name == setting_name

# Generated at 2022-06-22 19:23:26.746110
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    from ansible.module_utils.ansible_release import AnsibleModule
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None
    ansible_module = AnsibleModule(
        argument_spec=dict()
    )
    ansible_module.params = dict(
        foo='bar',
        password='secret'
    )
    for (setting_name, setting_value) in ansible_module.params.items():
        from ansible.module_utils.config_data import ConfigSetting
        from ansible.module_utils.config_data import ConfigPlugin
        from ansible.module_utils import basic
        import os
        basic._ANSIBLE_ARGS = None

# Generated at 2022-06-22 19:23:27.524522
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass

# Generated at 2022-06-22 19:23:36.639633
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    class Plugin(object):
        def __init__(self, plugin_type, plugin_name):
            self.type = plugin_type
            self.name = plugin_name

    class Setting(object):
        def __init__(self, setting_name, setting_value):
            self.name = setting_name
            self.value = setting_value

        def __str__(self):
            return "[%s, %s]" % (self.name, self.value)

    plugin_a = Plugin("v2", "apb")
    plugin_b = Plugin("v2", "docker")

    setting_1 = Setting("HOST", "localhost")
    setting_2 = Setting("PORT", "8383")
    setting_3 = Setting("USER", "admin")

# Generated at 2022-06-22 19:23:43.824898
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # create class to be tested
    config = ConfigData()

    # create global settings
    setting = ConfigSetting('setting1')
    config.update_setting(setting)
    setting = ConfigSetting('setting2')
    config.update_setting(setting)

    assert len(config.get_settings()) == 2

    assert len(config.get_settings(Plugin('test', 'action'))) == 0

    assert len(config.get_settings(Plugin('test', 'connection'))) == 0


# Generated at 2022-06-22 19:23:50.320651
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    assert cd.get_settings() == []

    cd._global_settings['a'] = 'b'
    cd._global_settings['b'] = 'c'
    cd._global_settings['c'] = 'd'

    assert cd.get_settings() == ['b', 'c', 'd']


# Generated at 2022-06-22 19:23:59.065948
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible_collections.ansible.builtin.plugins.module_utils import basic
    from ansible_collections.ansible.builtin.plugins.module_utils.connection.utils.config import ConfigData
    from ansible_collections.ansible.builtin.plugins.module_utils.connection.utils.param import Param
    from ansible_collections.ansible.builtin.plugins.module_utils.connection.utils.connection_loader import ConnectionLoader
    from ansible.plugins.connection import network_cli

    def _make_setting(name, default=None):
        setting = Param(name, default=default)
        return setting

    # create a config data object
    config_data = ConfigData()

    # create a setting
    default_shell_type = 'network_cli'
    default_shell_type_setting = _

# Generated at 2022-06-22 19:24:05.978781
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import io
    from ansible.config.manager import ConfigManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.loader import add_all_plugin_dirs

    # Class InventoryScript
    import ansible.inventory.script
    class InventoryScript(ansible.inventory.script.InventoryScript):
        def __init__(self):
            pass
    ansible.inventory.script.InventoryScript = InventoryScript

    def use_inventory_plugin(self):
        pass

    class Plugin:

        def __init__(self, name, path):
            self._name = name
            self._path = path

        @property
        def name(self):
            return self._name

        @property
        def path(self):
            return self._path

    add_all_plugin

# Generated at 2022-06-22 19:24:13.750424
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()

    plugin_type = 'type'
    plugin_name = 'name'
    plugin = Plugin(plugin_type, plugin_name)
    setting_name = 'setting_name'
    config = 'config'
    value = 'value'
    type = 'type'

    setting = Setting(setting_name, config, value, type, plugin)

    configData.update_setting(setting)

    assert setting == configData.get_settings(plugin)[0]


# Generated at 2022-06-22 19:24:20.733193
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()
    config._global_settings = { 'A': 1, 'B': 2 }
    config._plugins = { 'C': { 'D': { 'E': 3, 'F': 4 } } }

    # Test 1: plugin is None
    assert config.get_setting('A') is 1
    assert config.get_setting('B') is 2
    assert config.get_setting('C') is None
    assert config.get_setting('D') is None
    assert config.get_setting('E') is None
    assert config.get_setting('F') is None
    assert config.get_setting('G') is None

    # Test 2: plugin is not None but doesn't exists
    plugin = Plugin('C', 'S')
    assert config.get_setting('A', plugin) is None
    assert config.get_

# Generated at 2022-06-22 19:24:22.261418
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

# Generated at 2022-06-22 19:24:23.842007
# Unit test for constructor of class ConfigData
def test_ConfigData():
    #Test constructor
    config_data= ConfigData()
    assert config_data

# Generated at 2022-06-22 19:24:30.170995
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    print("Unit test for get_settings method of class ConfigData")
    config_data = ConfigData()
    print("Test case 1: pass None to method")
    print("Return: ", config_data.get_settings())
    print("Expected: ")
    print()
    print("Test case 2: pass a plugin of type None")
    print("Return: ", config_data.get_settings(None))
    print("Expected: ")
    print()
    print("Test case 3: pass a plugin of type 'cache' with name 'redis'")

# Generated at 2022-06-22 19:24:37.074093
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansiblelint.plugins import AnsiblePlugin
    from ansiblelint.settings import Setting

    config_data = ConfigData()

    # Test method get_settings. If no plugins are provided, should return a list of global_settings
    config_data.update_setting(Setting(name='forbid_empty_def', desc='desc1', default=False))
    assert len(config_data.get_settings()) == 1  # should return a list with only one setting

    # Test method get_settings. If a plugin is provided, should return a list of settings
    ansible_plugin = AnsiblePlugin(name='A1', id='T1')
    config_data.update_setting(Setting(name='forbid_empty_play', desc='desc2', default=False), ansible_plugin)

# Generated at 2022-06-22 19:24:41.565484
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting(name="foo", value="bar"))
    assert config_data.get_setting("foo").name == "foo"
    assert config_data.get_setting("foo", plugin="bar").name == "foo"


# Generated at 2022-06-22 19:24:47.729601
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin('cache', 'memory')

    # get_settings with no param
    assert not config_data.get_settings()

    # get_settings with a plugin
    assert not config_data.get_settings(plugin)



# Generated at 2022-06-22 19:24:56.192960
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    global_setting = Setting(0, 'test_key', 'test_value', None)
    config_data.update_setting(global_setting)
    assert config_data._global_settings['test_key'].value == 'test_value'

    plugin_type = Plugin('test_type', None)
    plugin_name = Plugin('test_name', plugin_type)
    plugin_setting = Setting(0, 'test_key', 'test_value', plugin_name)
    config_data.update_setting(plugin_setting)
    assert config_data._plugins['test_type']['test_name']['test_key'].value == 'test_value'


# Generated at 2022-06-22 19:24:58.863260
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    result = config.get_setting('hosts')
    #assert result == None
    assert result is None


# Generated at 2022-06-22 19:25:01.624207
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert( config_data._global_settings == {})
    assert( config_data._plugins == {})


# Generated at 2022-06-22 19:25:10.162738
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from pytest import raises

    import ansible.module_utils.common.plugins as plugins

    config_data = ConfigData()

    # No plugin
    assert len(config_data.get_settings()) == 0

    # No such plugin
    with raises(RuntimeError):
        config_data.get_settings(plugin=plugins.Plugin('module_utils', 'foo', []))

    # No such setting
    with raises(RuntimeError):
        config_data.get_settings(plugin=plugins.Plugin('module_utils', 'os', []))

# Generated at 2022-06-22 19:25:20.983818
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData1 = ConfigData()
    plugin1 = Plugin('Connection', 'docker')
    plugin2 = Plugin('Shell', 'bash')
    setting1 = Setting('host', 'localhost')
    setting2 = Setting('host', '127.0.0.1')
    setting3 = Setting('host', '192.168.56.103')
    setting4 = Setting('host', '192.168.56.104')
    setting5 = Setting('host', '192.168.58.103')
    setting6 = Setting('host', '192.168.58.104')
    configData1.update_setting(setting1, plugin1)
    configData1.update_setting(setting2)
    configData1.update_setting(setting3, plugin2)
    configData1.update_setting(setting4)
    configData1.update

# Generated at 2022-06-22 19:25:24.911372
# Unit test for constructor of class ConfigData
def test_ConfigData():
    new_object = ConfigData()
    assert "global_settings" in dir(new_object)
    assert "plugins" in dir(new_object)


# Generated at 2022-06-22 19:25:31.777769
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    plugin = PluginDefinition()
    name = 'test_setting'
    value = 'test_value'
    plugin_setting = PluginSetting(setting_name=name,
                                   setting_value=value,
                                   plugin_definition=plugin)
    config_data.update_setting(plugin_setting)
    assert config_data.get_settings(plugin_setting.plugin_definition)[0].name == name
    assert config_data.get_settings(plugin_setting.plugin_definition)[0].value == value



# Generated at 2022-06-22 19:25:43.071102
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting(True, "PBR_VERSION", "0.10.0"))
    config_data.update_setting(Setting(True, "SELINUX_SPECFILE", "%(specdir)s/selinux.if"))
    config_data.update_setting(Setting(True, "SELINUX_PC", "%(libdir)s/pkgconfig/selinux.pc"))

    assert config_data.get_setting("PBR_VERSION").value == "0.10.0"
    assert config_data.get_setting("SELINUX_SPECFILE").value == "%(specdir)s/selinux.if"

# Generated at 2022-06-22 19:25:50.885396
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    from collections import namedtuple
    Plugin = namedtuple('Plugin', ['type', 'name'])

    assert(len(config_data.get_settings()) == 0)
    assert(len(config_data.get_settings(Plugin('Foo', 'Bar'))) == 0)

    config_data.update_setting(Setting('baz', 'baz', 'baz'))
    assert(len(config_data.get_settings()) == 1)
    assert(len(config_data.get_settings(Plugin('Foo', 'Bar'))) == 0)

    config_data.update_setting(Setting('baz', 'baz', 'baz'), Plugin('Foo', 'Bar'))
    assert(len(config_data.get_settings()) == 1)

# Generated at 2022-06-22 19:26:00.740410
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # create test data
    config_data = ConfigData()
    config_data._global_settings['key1'] = 'value1'
    config_data._global_settings['key2'] = 'value2'
    config_data._global_settings['key3'] = 'value3'

    # test when plugin is not specified
    settings = config_data.get_settings()
    assert len(settings) == 3
    assert settings[0].name == 'key1' and settings[0].value == 'value1'
    assert settings[1].name == 'key2' and settings[1].value == 'value2'
    assert settings[2].name == 'key3' and settings[2].value == 'value3'

    # test when plugin is specified but not found

# Generated at 2022-06-22 19:26:10.842178
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Create the object to be tested
    config_data = ConfigData()

    #
    # Without plugins
    #

    # No global settings
    assert config_data.get_setting('n/a') is None
    # Global settings available
    setting = Setting('key', 'value', 'string')
    config_data.update_setting(setting)
    assert config_data.get_setting('key').value == 'value'

    #
    # With plugins
    #

    # No plugin settings
    plugin1 = Plugin('plugin_type1', 'plugin1')
    assert config_data.get_setting('n/a', plugin1) is None
    # No matching plugins
    plugin2 = Plugin('plugin_type2', 'plugin2')
    plugin3 = Plugin('plugin_type3', 'plugin3')

# Generated at 2022-06-22 19:26:19.970578
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from collections import namedtuple
    from ansiblelint.rules import RulesCollection

    Plugin = namedtuple('Plugin', ['name', 'type'])
    Collection = namedtuple('Collection', ['rules', 'inline_modules'])
    Rule = namedtuple('Rule', ['name', 'enabled'])
    InlineModule = namedtuple('Module', ['name', 'description'])

    PLUGIN_TYPE_RULE = 'rule'
    PLUGIN_TYPE_INLINE = 'inline-module'

    config_data = ConfigData()
    config_data.update_setting(Setting('plugin_setting', 'plugin_value'))
    config_data.update_setting(Setting('global_setting', 'global_value'), plugin=Plugin('plugin_name', 'plugin_type'))


# Generated at 2022-06-22 19:26:24.300159
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    cd = ConfigData()

    assert cd.get_setting('name_setting_0') is None
    assert cd.get_setting('name_setting_0', plugin=None) is None
    assert cd.get_setting('name_setting_1', plugin='plugin_0') is None

# Generated at 2022-06-22 19:26:27.280682
# Unit test for constructor of class ConfigData
def test_ConfigData():

    c = ConfigData()
    assert c._global_settings == {}
    assert c._plugins == {}


# Generated at 2022-06-22 19:26:31.741593
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()
    plugin = AnsiblePlugin(type='connection', name='dummy')
    setting = AnsibleSetting(name='a')
    setting.set_value('b')
    configdata.update_setting(setting, plugin)
    assert configdata.get_setting('a',plugin) == setting



# Generated at 2022-06-22 19:26:39.145589
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    d = ConfigData()
    assert d.get_setting(None) is None

    d = ConfigData()
    assert d.get_setting(None, None) is None

    d = ConfigData()
    assert d.get_setting("test") is None

    d = ConfigData()
    assert d.get_setting("test", None) is None

    # test load plugins

    d = ConfigData()
    assert d.get_setting("test", None) is None

    d = ConfigData()
    assert d.get_setting("test", "None") is None

    d = ConfigData()
    assert d.get_setting("test", "None", "None") is None

    d = ConfigData()
    assert d.get_setting("", None) is None

    d = ConfigData()

# Generated at 2022-06-22 19:26:41.400563
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    assert type(configData) == ConfigData


# Generated at 2022-06-22 19:26:43.731253
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-22 19:26:45.940408
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:26:49.004679
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting('setting-parameter')
    assert config_data.get_setting('setting-parameter') is not None


# Generated at 2022-06-22 19:26:56.059591
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    # Testing with plugin with type None
    plugin = None
    assert config_data.get_settings(plugin) == []

    # Testing with plugin with name None
    plugin = Plugin()
    assert config_data.get_settings(plugin) == []

    # Testing with plugin with type not None and name not None
    plugin = Plugin("foo")
    assert config_data.get_settings(plugin) == []

    # Updating plugin with type not None and name not None to config_data
    config_data.update_setting(Setting("foo", "foo.bar.com"), plugin)
    assert len(config_data.get_settings(plugin)) == 1

    # Testing that after updating plugin with type and name, get_settings with new plugin
    # with type None is empty
    plugin = Plugin()
    assert config

# Generated at 2022-06-22 19:26:59.366174
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()

    settingInstance = Setting('test', 'someValue', 'someValueType', None)

    cd.update_setting(settingInstance)
    settings = cd.get_settings()
    assert settingInstance in settings


# Generated at 2022-06-22 19:27:07.264711
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint.rules.ConfigParamHasDefaultRule import ConfigParamHasDefaultRule as rule
    config_data = ConfigData()
    config_data.update_setting(rule.Setting('param1', 'value1'))
    config_data.update_setting(rule.Setting('param2', 'value2'))

    settings = config_data.get_settings()

    assert len(settings) == 2
    assert settings[0].name == 'param1'
    assert settings[0].value == 'value1'
    assert settings[1].name == 'param2'
    assert settings[1].value == 'value2'



# Generated at 2022-06-22 19:27:12.432983
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.action.normal import ActionModule as ActionModule_normal
    from ansible.plugins.action.copy import ActionModule as ActionModule_copy
    from ansible.plugins.cache.memory import CacheModule as CacheModule_memory

    config_data = ConfigData()

    # Case 1: plugin is not provided. In this case the configuration setting must be retrieved from the global setting dictionary
    config_data._global_settings["foo"] = PluginSetting(name='foo', value='bar', scope="global")
    assert config_data.get_setting("foo").name == "foo"
    assert config_data.get_setting("foo").value == "bar"
    assert config_data.get_setting("foo").scope == "global"

    # Case 2: plugin is provided, but config_data does

# Generated at 2022-06-22 19:27:14.038954
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert len(config._global_settings.keys()) == 0

# Generated at 2022-06-22 19:27:23.354092
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from lib.config import Setting

    setting_global = Setting(name='setting_global_name', default=1, plugin=False)
    setting_plugin1_type1_name1 = Setting(name='setting_plugin1_type1_name1', default=1, plugin=True)
    setting_plugin1_type2_name2 = Setting(name='setting_plugin1_type2_name2', default=1, plugin=True)
    setting_plugin2_type1_name2 = Setting(name='setting_plugin2_type1_name2', default=1, plugin=True)
    setting_plugin2_type1_name1 = Setting(name='setting_plugin2_type1_name1', default=1, plugin=True)

    config_data = ConfigData()
    config_data.update_setting(setting_global)


# Generated at 2022-06-22 19:27:31.463606
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()

    config_data.update_setting(GlobalSetting(name='foo', value='bar'))

    assert config_data.get_setting('foo') == 'bar'

    plugin_loader = PluginLoader('action', 'TestActionModule')
    plugin_obj = plugin_loader.get('TestActionModule')
    config_data.update_setting(PluginSetting(name='foo', value='bar', plugin=plugin_obj))

    assert config_data.get_setting('foo', plugin=plugin_obj) == 'bar'

# Class to store global setting

# Generated at 2022-06-22 19:27:38.125247
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()
    plugin_type = "test"
    plugin_name = "test"
    configData.update_setting(Setting("test1", "value1", plugin_type, plugin_name))
    setting_list = configData.get_settings(Plugin(plugin_type, plugin_name))
    assert len(setting_list) == 1


# Generated at 2022-06-22 19:27:42.430286
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    assert cd.get_settings() == []

    plugin = ConfigPlugin('test-type', 'test-name')
    assert cd.get_settings(plugin) == []

    setting = ConfigSetting('test-setting', 'test-value', None)
    cd.update_setting(setting)
    assert cd.get_settings() == [setting]
    assert cd.get_settings(plugin) == []

    setting = ConfigSetting('test-setting', 'test-value', plugin)
    cd.update_setting(setting, plugin)
    assert cd.get_settings(plugin) == [setting]



# Generated at 2022-06-22 19:27:44.904277
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:27:53.802900
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin.__new__(Plugin)
    plugin.name = 'test_plugin'
    plugin.namespace = 'test_namespace'
    plugin.path = ['/test/path']
    plugin.type = 'test_type'
    setting1 = Setting.__new__(Setting)
    setting1.name = 'test_setting_1'
    setting1.value = 'test_value_1'
    config_data.update_setting(setting1, plugin)
    setting2 = Setting.__new__(Setting)
    setting2.name = 'test_setting_2'
    setting2.value = 'test_value_2'
    config_data.update_setting(setting2, plugin)
    assert len(config_data.get_settings(plugin)) == 2

#

# Generated at 2022-06-22 19:27:57.423665
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert 'bar' == config_data.get_setting('foo').value


# Generated at 2022-06-22 19:28:08.600674
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    result = len(config_data.get_settings())
    assert result == 0

    from collections import namedtuple
    plugin = namedtuple('Plugin', ['type', 'name'])
    setting = namedtuple('Setting', ['name', 'value'])

    plugin_core = plugin('core', '')
    plugin_collection = plugin('collection', 'my_collection')
    plugin_module = plugin('module', 'my_module')
    plugin_module_utils = plugin('module_utils', 'my_module_utils')
    plugin_playbook = plugin('playbook', 'my_playbook')
    plugin_role = plugin('role', 'my_role')
    plugin_lookup = plugin('lookup', 'my_lookup')
    plugin_shell = plugin('shell', 'my_shell')

# Generated at 2022-06-22 19:28:10.844744
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:28:22.149343
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class Plugin:

        def __init__(self, name):
            self.name = name

    class Setting:

        def __init__(self, name, value):
            self.name = name
            self.value = value

    data = ConfigData()

    # Empty data
    assert data.get_setting("host_key_checking") is None
    assert data.get_setting("host_key_checking", Plugin("docker")) is None
    assert data.get_setting("TEST1", Plugin("apt")) is None

    assert data.get_settings() == []
    assert data.get_settings(Plugin("docker")) == []
    assert data.get_settings(Plugin("apt")) == []

    # Set default value
    data.update_setting(Setting("host_key_checking", "false"))

# Generated at 2022-06-22 19:28:26.098351
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data_obj = ConfigData()
    assert config_data_obj._global_settings == {}
    assert config_data_obj._plugins == {}


# Generated at 2022-06-22 19:28:27.631228
# Unit test for constructor of class ConfigData
def test_ConfigData():
    # Create instance of ConfigData
    config_data = ConfigData()

    # Check that object isn't None
    assert(config_data is not None)



# Generated at 2022-06-22 19:28:29.990910
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert configdata is not None

# Generated at 2022-06-22 19:28:39.532563
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd1 = ConfigData()
    cd2 = ConfigData()

    # Test case 1: Empty state of get_setting, d
    assert cd1.get_setting('ansible_host') is None, 'Empty state test case 1 Failed.'

    # Test case 2: Global setting.
    cd1.update_setting(Setting('ansible_host', '10.0.0.1'))
    assert cd1.get_setting('ansible_host') is not None, 'Global setting test case 2 failed.'

    # Test case 3: Negative test case, plugin type that doesn't exist.
    assert cd1.get_setting('ansible_host', Plugin('not_a_plugin', 'my_plugin')) is None, 'Negative test case 3 failed.'

    # Test case 4: Negative test case, plugin name that doesn't exist.
    assert cd

# Generated at 2022-06-22 19:28:47.848712
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    assert config_data.get_setting('A') is None
    assert config_data.get_setting('B', 'C') is None

    config_data.update_setting('A')
    assert config_data.get_setting('A') is 'A'

    config_data.update_setting('B', 'C')
    assert config_data.get_setting('B', 'C') is 'B'


# Generated at 2022-06-22 19:28:59.263881
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cd = ConfigData()

    cd.update_setting(ConfigSetting(name='foo'))
    cd.update_setting(ConfigSetting(name='bar'))

    cd.update_setting(ConfigSetting(name='foo'), ConfigPlugin(name='test', type='cache'))
    cd.update_setting(ConfigSetting(name='bar'), ConfigPlugin(name='test', type='cache'))

    assert len(cd.get_settings()) == 2
    assert len(cd.get_settings(ConfigPlugin('test', 'cache'))) == 2
    assert cd.get_settings(ConfigPlugin('test2', 'cache')) is None

    assert len(cd.get_settings(plugin=None)) == 2
    assert len(cd.get_settings(ConfigPlugin('test', 'cache'))) == 2

# Generated at 2022-06-22 19:29:07.705499
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin_type = PluginType()
    plugin_type.name = 'foo'
    plugin = Plugin()
    plugin.type = plugin_type
    plugin.name = 'bar'
    setting = Setting()
    setting.name = 'testing'
    config_data.update_setting(setting, plugin=plugin)
    assert config_data.get_setting('testing') is None
    assert config_data.get_setting('testing', plugin=plugin) is setting


# Generated at 2022-06-22 19:29:18.927275
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cdata = ConfigData()
    cdata.update_setting(Setting('v1'))
    cdata.update_setting(Setting('v2', plugin=Plugin('p', 't')))
    assert cdata.get_setting('v1') is not None
    assert cdata.get_setting('v2') is None
    assert cdata.get_setting('v1', Plugin('p', 't')) is None
    assert cdata.get_setting('v2', Plugin('p', 't')) is not None
    assert cdata.get_setting('v1', Plugin('q', 't')) is None
    assert cdata.get_setting('v2', Plugin('q', 't')) is None


# Generated at 2022-06-22 19:29:20.678652
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert isinstance(config_data.get_settings(None), list)

# Generated at 2022-06-22 19:29:29.941331
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import collections

    import pytest

    from ansiblelint import linters

    dummy_setting = collections.namedtuple('setting', ['name', 'value'])

    global_setting = dummy_setting('global', 'true')
    plugin_setting = dummy_setting('plugin', 'true')

    config_data = ConfigData()
    config_data.update_setting(global_setting)

    linters.add_plugin_linter('C0111', 'file', linters.FileLinter)
    linters.add_plugin_linter('C0112', 'block', linters.BlockLinter)

    test_case = collections.namedtuple('test_case', ['linter', 'setting', 'expected'])


# Generated at 2022-06-22 19:29:36.448110
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    s = Setting("test_name", "test_value")
    p = Plugin("test_type", "test_name")
    c.update_setting(s)
    assert c.get_setting("test_name") == s
    c.update_setting(s, p)
    assert c.get_setting("test_name", p) == s



# Generated at 2022-06-22 19:29:39.467191
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    setting = Setting('name')
    plugin = Plugin('type', 'name')

    config_data.update_setting(setting)
    setting_returned = config_data.get_setting(setting.name)

    assert setting.name == setting_returned.name


# Generated at 2022-06-22 19:29:40.853791
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)



# Generated at 2022-06-22 19:29:45.338957
# Unit test for constructor of class ConfigData
def test_ConfigData():
    # print("**** Test_ConfigData ****")

    config_data=ConfigData()
    # print(config_data)
    assert config_data is not None
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:29:50.557391
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Given
    configData = ConfigData()
    configData._global_settings['setting1'] = 'setting1'

    # When
    setting_1 = configData.get_setting('setting1')
    setting_2 = configData.get_setting('setting2')

    # Then
    assert setting_1 == 'setting1'
    assert setting_2 is None


# Generated at 2022-06-22 19:29:54.161712
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    s = Setting()
    s.name = 'test'
    assert c._global_settings == {}
    c.update_setting(s)
    assert c._global_settings['test'] == s


# Generated at 2022-06-22 19:29:56.309741
# Unit test for constructor of class ConfigData
def test_ConfigData():
    """
    We perform unit test for extending the class ConfigData
    """
    configdata = ConfigData()
    assert configdata

# Generated at 2022-06-22 19:29:59.040440
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert {} == config_data._global_settings
    assert {} == config_data._plugins


# Unit tests for get_setting method of class ConfigData

# Generated at 2022-06-22 19:30:00.221821
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd is not None


# Generated at 2022-06-22 19:30:01.642143
# Unit test for constructor of class ConfigData
def test_ConfigData():
    obj = ConfigData()
    assert obj is not None


# Generated at 2022-06-22 19:30:03.070076
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)


# Generated at 2022-06-22 19:30:04.560315
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = Setting("key", "value")
    config_data.update_setting(setting)
    assert config_data.get_setting("key") == setting
