

# Generated at 2022-06-22 19:20:15.214232
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    from collections import namedtuple
    Setting = namedtuple('Setting', ['name', 'value', 'origin', 'type', 'scope'])
    Plugin = namedtuple('Plugin', ['name', 'type'])
    plugin = Plugin('test_plugin', 'test_type')
    setting = Setting('test_setting', 'test_value', 'test_origin', 'test_type', 'test_scope')
    config_data.update_setting(setting)
    assert config_data._global_settings['test_setting'] == setting
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['test_type']['test_plugin']['test_setting'] == setting



# Generated at 2022-06-22 19:20:20.776855
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(Setting("ansible_test_plugin", "mytest_setting", "ansible_test_plugin.mytest_setting", "test", "str", False, "", "", "", "test"))

    assert config.get_setting("ansible_test_plugin.mytest_setting", Plugin("test", "mytest"))



# Generated at 2022-06-22 19:20:23.812939
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    cd._global_settings = {'name1': 'value1'}
    assert cd.get_settings() == [{'name': 'name1', 'value': 'value1'}]


# Generated at 2022-06-22 19:20:25.464871
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
        config_data = ConfigData()
        config_data.update_setting()
        assert(config_data)

# Generated at 2022-06-22 19:20:33.333304
# Unit test for constructor of class ConfigData
def test_ConfigData():
    plugin = None
    data = {'key1': 100, 'key2': 200}
    config = ConfigData()
    assert len(config.get_settings(plugin)) == 0
    for key, value in data.items():
        assert config.get_setting(key, plugin) is None
        setting = Setting('', key, value, 'basic')
        config.update_setting(setting, plugin)
        assert config.get_setting(key, plugin).value == value
    assert len(config.get_settings(plugin)) == len(data)


# Generated at 2022-06-22 19:20:37.065986
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    data.update_setting(Setting('asd', 'value'))
    assert data.get_setting('asd')
    assert data.get_setting('asd') == data.get_setting('asd')


# Generated at 2022-06-22 19:20:40.262867
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Create the object
    obj = ConfigData()
    setting = 'CAPTURE_HOST_VARIABLES'
    plugin = object()
    # Assert to test the method
    assert obj.update_setting(setting, plugin) is None


# Generated at 2022-06-22 19:20:46.655160
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class Plugin:

        def __init__(self, name, type):
            self.name = name
            self.type = type

    class Setting:

        def __init__(self, name):
            self.name = name

    config = ConfigData()

    setting1 = Setting("setting1")
    setting2 = Setting("setting2")
    plugin1 = Plugin("plugin1", "plugin1_type")

    # update plugin setting
    config.update_setting(setting1, plugin1)
    assert config.get_setting("setting1") is None
    assert config.get_setting("setting1", plugin1) is setting1
    assert config.get_setting("setting2") is None
    assert config.get_setting("setting2", plugin1) is None

    # update global setting
    config.update_setting(setting2)
   

# Generated at 2022-06-22 19:20:55.194761
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class Plugin(object):

        def __init__(self, type="", name=""):
            self.type = type
            self.name = name

    config_data = ConfigData()
    setting = dict(name="foo", value=10)
    config_data.update_setting(setting)
    setting = dict(name="bar", value=20)
    config_data.update_setting(setting)
    plugin = Plugin(type="this", name="that")
    setting = dict(name="foo", value=10)
    config_data.update_setting(setting, plugin)
    setting = dict(name="bar", value=20)
    config_data.update_setting(setting, plugin)

# Generated at 2022-06-22 19:20:57.041786
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    s = c.get_settings()
    assert len(s) == 0


# Generated at 2022-06-22 19:20:58.516459
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-22 19:20:59.504708
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()



# Generated at 2022-06-22 19:21:07.533418
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.plugins.loader import config as config_loader
    from collections import namedtuple
    from ansible.module_utils._text import to_text

    plugin = namedtuple('Plugin', ['name', 'type'])
    config_data = ConfigData()

    def _get_availabe_settings(config_data):
        settings = []
        for plugins in config_data._plugins.values():
            for plugin, plugins_settings in plugins.items():
                for setting in plugins_settings:
                    settings.append(setting)

        return settings

    def _get_setting(config_data, name, plugin):
        return config_data.get_setting(name, plugin=plugin)

    setting = config_loader.ConfigSetting('FOO', 'BAR', 'FOO')
    config_data.update_setting(setting)



# Generated at 2022-06-22 19:21:10.464291
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(Setting('foo', 'bar', 'baz'))
    result = config.get_setting('foo')
    assert result == Setting('foo', 'bar', 'baz')



# Generated at 2022-06-22 19:21:18.261188
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # should return empty setting list
    config = ConfigData()
    result = config.get_settings()
    assert result == []

    setting = {
        'name': 'test_setting',
        'value': 'test_value',
        'origin': 'test_origin'
    }
    config.update_setting(setting)
    result = config.get_settings()
    assert result == [setting]

    result = config.get_settings({'type': 'test_type', 'name': 'test_name'})
    assert result == []



# Generated at 2022-06-22 19:21:22.104153
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    configd = ConfigData()
    plugin = 'TestPlugin'
    setting = 'TestSetting'
    configd.update_setting(setting, plugin)
    settings = configd.get_settings(plugin)
    assert settings[0] == setting

# Generated at 2022-06-22 19:21:33.530300
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import unittest
    import mock
    import os

    from ansible.plugins.loader import configuration_loader

    plugin_class = 'ansible.plugins.lookup.foo_plugin'
    test_data_dir = os.path.join(os.path.dirname(__file__), '../unit/data/config_data')

    # Test with no plugin
    config = ConfigData()
    config._global_settings['foo'] = configuration_loader.Setting('foo', 'bar')
    config._global_settings['baz'] = configuration_loader.Setting('baz', 123)

    settings = config.get_settings()
    assert len(settings) == 2
    assert settings[0] == config._global_settings['foo']
    assert settings[1] == config._global_settings['baz']
    assert config.get_settings

# Generated at 2022-06-22 19:21:39.364082
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    cd.update_setting(Setting(name='display_skipped_hosts', value=True))
    cd.update_setting(Setting(name='become_method', value='sudo'), Plugin("command", "become"))
    cd.update_setting(Setting(name='display_ok_hosts', value=True))

    assert len(cd.get_settings()) == 2
    assert len(cd.get_settings(Plugin("command", "become"))) == 1



# Generated at 2022-06-22 19:21:44.035539
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    plugin_name = 'test-plugin'
    setting_name = 'test-setting'
    setting_value = 'test-value'
    test = ConfigData()
    setting = Setting(setting_name, setting_value)
    assert test.get_setting(setting_name) is None
    assert test.update_setting(setting) is None
    assert test.get_setting(setting_name) == setting_value


# Generated at 2022-06-22 19:21:46.483905
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0



# Generated at 2022-06-22 19:21:56.733814
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {'key1': {'name': 'key1', 'value': 'value1', 'assigned_to': None},
                                    'key2': {'name': 'key2', 'value': 'value2', 'assigned_to': None}}
    config_data._plugins = {'action': {'my_action': {'key3': {'name': 'key3', 'value': 'value3',
                                                               'assigned_to': {'type': 'action', 'name': 'my_action'}}}}}


# Generated at 2022-06-22 19:22:07.415404
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Test no plugin
    setting = config_data.get_setting('display_skipped_hosts')
    assert setting is None
    config_data.update_setting(ConfigSetting('display_skipped_hosts', 'yes'))
    setting = config_data.get_setting('display_skipped_hosts')
    assert setting == ConfigSetting('display_skipped_hosts', 'yes')

    # Test with plugin
    setting = config_data.get_setting('display_skipped_hosts', ConfigPlugin('inventory', 'test'))
    assert setting is None
    config_data.update_setting(ConfigSetting('display_skipped_hosts', 'no'), ConfigPlugin('inventory', 'test'))

# Generated at 2022-06-22 19:22:10.866802
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    assert config_data.get_settings(Plugin('Type', 'Name')) == []



# Generated at 2022-06-22 19:22:18.410804
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    myconfigdata = ConfigData()
    set1 = ConfigSetting(name='user', value='testuser', origin='/etc/ansible/ansible.cfg', plugin=Plugin(module_name='module'))
    set2 = ConfigSetting(name='user2', value='testuser2', origin='/etc/ansible/ansible.cfg', plugin=Plugin(module_name='module'))
    set3 = ConfigSetting(name='user', value='testuserglobal', origin='/etc/ansible/ansible.cfg')
    myconfigdata.update_setting(set1)
    myconfigdata.update_setting(set2)
    myconfigdata.update_setting(set3)
    res = myconfigdata.get_settings(Plugin(type='module', name='module'))
    assert len(res) == 2
    res = my

# Generated at 2022-06-22 19:22:19.319716
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd

# Generated at 2022-06-22 19:22:27.545677
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert [] == config_data.get_settings()
    assert None == config_data.get_setting("foo")

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import string_types

    config_data.update_setting(ImmutableDict(name="foo", value="bar"))
    assert ["foo"] == [s.name for s in config_data.get_settings()]
    s = config_data.get_setting("foo")
    assert s.name == "foo"
    assert isinstance(s.value, string_types)
    assert "bar" == s.value


# Generated at 2022-06-22 19:22:35.714649
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
	config_data = ConfigData()
	plugin = Plugin("local")
	plugin.set_type("action")
	plugin.set_name("setup")
	plugin.set_path("/home/anastasija/ansible/ansible/lib/ansible/plugins/action/setup.py")
	setting = Setting("name")
	setting.set_path("/home/anastasija/ansible/ansible/lib/ansible/plugins/action/setup.py")
	setting.set_default("ansible")
	setting.set_type("str")
	setting.set_description("Name of the host to gather facts about\n")
	setting.set_required("yes")
	setting.set_choices("")
	setting.set_version_added("")
	config_data.update_setting(setting, plugin)

# Generated at 2022-06-22 19:22:43.682007
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    global_setting = {"name": "my_setting", "value": "my_value"}
    plugin_setting = {"name": "my_setting", "value": "my_value"}
    plugin = {"type": "my_plugin_type", "name": "my_plugin_name"}

    config = ConfigData()
    config.update_setting(global_setting, None)
    config.update_setting(plugin_setting, plugin)

    result = config.get_setting("my_setting", None)
    assert result == global_setting

    result = config.get_setting("my_setting", plugin)
    assert result == plugin_setting

# Generated at 2022-06-22 19:22:53.868114
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    # test the scenario when setting is none
    assert config_data.get_settings(None) == []
    assert config_data.get_settings(object) == []

    # test the scenario when setting is global
    setting1 = object()
    setting1.name = 'setting1'
    config_data.update_setting(setting1)
    assert config_data.get_setting('setting1') == setting1

    # test the scenario when setting is for first plugin
    plugin1 = object()
    plugin1.type = 'plugin_type'
    plugin1.name = 'plugin1'
    setting2 = object()
    setting2.name = 'setting2'
    config_data.update_setting(setting2, plugin1)
    assert config_data.get_setting('setting2', plugin1)

# Generated at 2022-06-22 19:22:57.141275
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    s1 = {'name': 'test', 'value': '1'}
    cd.update_setting(s1)
    assert cd.get_setting('test') == s1


# Generated at 2022-06-22 19:23:06.557629
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    CONFIG_DATA = ConfigData()
    CONFIG_DATA.update_setting(ConfigSetting('force_color', True))
    CONFIG_DATA.update_setting(ConfigSetting('display_skipped_hosts', True))
    CONFIG_DATA.update_setting(ConfigSetting('nocows', False))
    CONFIG_DATA.update_setting(ConfigSetting('pattern', 'test_playbook'))
    CONFIG_DATA.update_setting(ConfigSetting('host_key_checking', False))
    CONFIG_DATA.update_setting(ConfigSetting('forks', 2))
    CONFIG_DATA.update_setting(ConfigSetting('check', True))
    CONFIG_DATA.update_setting(ConfigSetting('sudo', True))
    CONFIG_DATA.update_setting(ConfigSetting('filename', 'test_playbook'))

# Generated at 2022-06-22 19:23:13.100875
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    plugin = PluginDescriptor('local', 'ping')
    config.update_setting(Setting('host', 'localhost'))
    config.update_setting(Setting('host', 'example.com'), plugin=plugin)

    assert config.get_setting('host').value == 'localhost'
    assert config.get_setting('host', plugin=plugin).value == 'example.com'



# Generated at 2022-06-22 19:23:21.885297
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = PluginType('module', 'git', 'module', 'Git')
    setting = Setting('module_exit_codes', 'dict', 'dict', 'module_exit_codes', '', '', '', ['^[a-zA-Z0-9_\-]+:[0-9]+'], plugin)
    config_data.update_setting(setting, plugin)
    assert config_data._global_settings == {}
    assert config_data._plugins[plugin.type][plugin.name]['module_exit_codes'] == setting


# Generated at 2022-06-22 19:23:25.281229
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cdata = ConfigData()
    assert cdata._global_settings == {}
    assert cdata._plugins == {}


# Generated at 2022-06-22 19:23:32.492846
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    setting = {'name': 'FOO', 'value': 'BAR'}
    setting2 = {'name': 'ANY', 'value': 'BAR'}
    config._global_settings['FOO'] = setting
    config._global_settings['ANY'] = setting2
    assert config.get_settings() == [setting, setting2]


# Generated at 2022-06-22 19:23:43.422490
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    plugin_name = 'test_plugin'
    plugin_type = 'test_type'
    setting_1 = Setting(name='test_setting_1')
    setting_2 = Setting(name='test_setting_2')
    setting_3 = Setting(name='test_setting_3')
    setting_4 = Setting(name='test_setting_4')
    plugin_1 = Plugin(name=plugin_name, type=plugin_type)
    plugin_2 = Plugin(name=plugin_name, type=plugin_type)

    config.update_setting(setting_1)
    config.update_setting(setting_2, plugin_1)
    config.update_setting(setting_3, plugin_2)
    config.update_setting(setting_4, plugin_2)

    settings = config.get

# Generated at 2022-06-22 19:23:49.908454
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    plugin = None
    name = "foo"

    assert config_data.get_setting(name, plugin) == None

    setting = Setting(name)
    config_data.update_setting(setting, plugin)

    assert config_data.get_setting(name, plugin) == setting


# Generated at 2022-06-22 19:23:58.848976
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.cli import CLI

    from ansible.cli.arguments import option_helpers as helpers
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.utils.plugin_docs import get_docstring
    from ansible.utils.plugin_docs import get_versioned_doclink

    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader import AnsibleFileLoader
    from ansible.plugins.loader import collection_loader

    from ansible.plugins.loader import cli_help

    config_data = ConfigData()

    # Call method get_setting of class ConfigData using global setting
    setting_name = 'ANSIBLE_CONFIG'
    setting = config_data.get_setting(setting_name)
    assert setting is None

    #

# Generated at 2022-06-22 19:24:04.166808
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    plugin = Plugin()
    setting = Setting()
    config_data.update_setting(setting)
    setting.name = 'test2'
    config_data.update_setting(setting, plugin)

    assert setting.name in config_data.get_settings(plugin)
    assert 1 == len(config_data.get_settings())
    assert 1 == len(config_data.get_settings(plugin))



# Generated at 2022-06-22 19:24:06.647597
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd is not None


# Generated at 2022-06-22 19:24:14.434356
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Create test ConfigData object
    config_data = ConfigData()

    # First test, in which no setting is stored.
    assert config_data.get_setting('foo') == None

    # Put a setting in the object to be able to test the retrieval of a setting
    class Setting:
        def __init__(self, name):
            self.name = name

    config_data.update_setting(Setting('foo'), plugin=None)

    # Second test, in which a setting is stored and retrieved.
    assert config_data.get_setting('foo') != None


# Generated at 2022-06-22 19:24:19.604677
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    global_settings=[]
    first_global_setting=ConfigData()
    settings={'name':'hello', 'description':'this is global hello setting'}
    first_global_setting(**settings)
    global_settings.append(first_global_setting)
    second_global_setting=ConfigData()
    settings={'name':'world', 'description':'this is global world setting'}
    second_global_setting(**settings)
    global_settings.append(second_global_setting)
    cd=ConfigData()
    for setting in global_settings:
        cd.update_setting(setting)
    assert cd.get_setting(name='hello').description == 'this is global hello setting'
    assert cd.get_setting(name='world').description == 'this is global world setting'



# Generated at 2022-06-22 19:24:20.487346
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData is not None

# Generated at 2022-06-22 19:24:25.607985
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    plugin = PluginDefinition('testPlugin', 'testType')
    setting = SettingDefinition('testSetting', 'testValue', pluginDef=plugin)
    configData.update_setting(setting, plugin)
    assert configData.get_setting('testSetting', plugin).value == 'testValue'
    assert configData.get_setting('testSetting').value == None

# Generated at 2022-06-22 19:24:33.739432
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert list(config_data._global_settings) == []
    assert list(config_data._plugins) == []

    class Plugin(object):

        def __init__(self, name, type):
            self.name = name
            self.type = type

    class Setting(object):

        def __init__(self, name):
            self.name = name

    plugin1 = Plugin("test_plugin1", "test_type1")
    plugin2 = Plugin("test_plugin2", "test_type2")
    setting1 = Setting("test_setting1")
    setting2 = Setting("test_setting2")

    config_data.update_setting(setting1, plugin1)

    assert list(config_data._global_settings) == []

# Generated at 2022-06-22 19:24:42.898161
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.parsing.plugins.lookup import LookupModule

    config = ConfigData()

    assert config.get_setting(None) is None

    config.update_setting(ConfigSetting(name=u'ANSIBLE_LOOKUP_PLUGINS', value=u'/a/b/c'))

    plugin = LookupModule(u'test', u'lookup_plugin', '/a/b/c/test.py')

    assert config.get_setting('ANSIBLE_LOOKUP_PLUGINS') is not None
    assert config.get_setting('ANSIBLE_LOOKUP_PLUGINS') == config.get_setting('ANSIBLE_LOOKUP_PLUGINS', plugin)


# Generated at 2022-06-22 19:24:54.835219
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()

    config.update_setting(Setting('name', 'John Doe'))
    assert config.get_setting('name') is not None
    assert config.get_setting('name').value == 'John Doe'
    config.update_setting(Setting('name', 'Jane Doe'))
    assert config.get_setting('name') is not None
    assert config.get_setting('name').value == 'Jane Doe'

    config.update_setting(Setting('age', '42'))
    assert config.get_setting('age') is not None
    assert config.get_setting('age').value == '42'
    config.update_setting(Setting('age', '43'))
    assert config.get_setting('age') is not None
    assert config.get_setting('age').value == '43'

    config.update

# Generated at 2022-06-22 19:24:56.107030
# Unit test for constructor of class ConfigData
def test_ConfigData():
    obj = ConfigData()
    assert isinstance(obj, ConfigData)


# Generated at 2022-06-22 19:25:05.569557
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()

    # 1. Test updating a global setting
    setting1 = {
        "name": "name_val",
        "value": "value_val",
        "origin": "origin_val",
    }
    configData.update_setting(setting1, None)
    assert(configData.get_setting("name_val", None) == setting1)
    assert(configData.get_settings(None)[0] == setting1)

    # 2. Test updating a plugin setting
    plugin2 = {
        "type": "type_val",
        "name": "name_val",
    }
    setting2 = {
        "name": "name_val",
        "value": "value_val",
        "origin": "origin_val",
    }

# Generated at 2022-06-22 19:25:13.799435
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configdata = ConfigData()

    assert not configdata.get_setting("a")

    configdata._global_settings["a"] = "b"
    assert configdata.get_setting("a", None) == "b"

    configdata._plugins["type"] = {}
    configdata._plugins["type"]["name"] = {}
    configdata._plugins["type"]["name"]["a"] = "c"

    assert configdata.get_setting("a") == "b"
    assert configdata.get_setting("a", type="type", name="name") == "c"
    assert configdata.get_setting("a", type="type") == "c"

    assert not configdata.get_setting("a", type="x")


# Generated at 2022-06-22 19:25:22.231005
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert cd.get_settings() == []
    s = ConfigSetting("foo")
    cd.update_setting(s)
    assert cd.get_settings() == [s]
    s = ConfigSetting("foo1")
    cd.update_setting(s)
    assert set(cd.get_settings()) == {ConfigSetting("foo"), ConfigSetting("foo1")}
    s = ConfigSetting("bar")
    p = ConfigPlugin("bar_plugin", "baz_type")
    cd.update_setting(s, p)
    assert set(cd.get_settings(p)) == {s}
    assert set(cd.get_settings()) == {ConfigSetting("foo"), ConfigSetting("foo1")}


# Generated at 2022-06-22 19:25:27.281783
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    setting = Setting()
    plugin = Plugin()
    data.update_setting(setting, plugin)
    assert data._global_settings == {'name': setting}
    assert data._plugins['type']['name']['name'] == setting

# Generated at 2022-06-22 19:25:30.150015
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    cd._global_settings = {'module.name': 'ip_netns'}
    assert cd.get_settings()[0].name == 'module.name'

# Generated at 2022-06-22 19:25:30.700609
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert True

# Generated at 2022-06-22 19:25:41.627431
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    config_data.update_setting(Setting("setting1", "global", "global", "val1", []))
    config_data.update_setting(Setting("setting2", "global", "global", "val2", []))
    config_data.update_setting(Setting("setting1", "connection", "local", "val1", []))

    settings = config_data.get_settings()

    assert len(settings) == 2
    assert settings[0].name == "setting1"
    assert settings[0].plugin_type == "global"
    assert settings[0].plugin_name == "global"
    assert settings[0].value == "val1"

    assert settings[1].name == "setting2"
    assert settings[1].plugin_type == "global"
    assert settings[1].plugin

# Generated at 2022-06-22 19:25:50.375599
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    setting1 = Setting()
    setting1.name = "option1"
    setting1.value = "value1"

    setting2 = Setting()
    setting2.name = "option2"
    setting2.value = "value2"

    setting3 = Setting()
    setting3.name = "option3"
    setting3.value = "value3"

    plugin = Plugin()
    plugin.type = "callback"
    plugin.name = "test"

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting3, plugin)

    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings(plugin)) == 1

# Generated at 2022-06-22 19:26:00.577766
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.cli import CLI
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()
    plugin_loader = PluginLoader('./lib/ansible/plugins/lookup', './lib/ansible/plugins/lookup')

# Generated at 2022-06-22 19:26:02.014062
# Unit test for constructor of class ConfigData
def test_ConfigData():
    obj = ConfigData()
    assert obj


# Generated at 2022-06-22 19:26:03.727341
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    cd = ConfigData()
    assert cd.get_setting('abc') is None


# Generated at 2022-06-22 19:26:13.292996
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    from collections import namedtuple
    Plugin = namedtuple('Plugin', 'type,name')

    plugin = Plugin(type="module", name="debug")
    from collections import namedtuple
    Setting = namedtuple('Setting', 'name,value,origin')
    setting_name = 'ANSIBLE_DEBUG'
    setting_value = True
    setting_origin = None
    setting_plugin = Plugin(type="module", name="debug")
    setting = Setting(name=setting_name, value=setting_value, origin=setting_origin)
    setting.plugin = setting_plugin
    config_data.update_setting(setting)
    
    plugin = Plugin(type="module", name="debug")
    setting_name = 'ANSIBLE_DEBUG'
    setting_value = False
    setting_origin = None

# Generated at 2022-06-22 19:26:20.233219
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = ConfigClass.PluginDefinition('plugin', 'type')
    config_data.update_setting(ConfigClass.SettingDefinition('setting1', 'int', 'value1', 'desc', 1, plugin), plugin)
    config_data.update_setting(ConfigClass.SettingDefinition('setting2', 'str', 'value2', 'desc', 1, plugin), plugin)

    assert config_data.get_setting('setting1', plugin) == config_data.get_setting('setting1', None)
    assert config_data.get_setting('setting2', plugin) == config_data.get_setting('setting2', None)



# Generated at 2022-06-22 19:26:28.697634
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    test_setting_1 = 'test_setting_1'
    test_setting_2 = 'test_setting_2'
    test_setting_3 = 'test_setting_3'
    test_setting_4 = 'test_setting_4'
    config.update_setting(test_setting_1, None)
    config.update_setting(test_setting_2, None)
    config.update_setting(test_setting_3, None)
    config.update_setting(test_setting_4, None)
    assert config.get_setting(test_setting_1.name) == test_setting_1
    assert config.get_setting(test_setting_2.name) == test_setting_2
    assert config.get_setting(test_setting_3.name) == test_setting_3

# Generated at 2022-06-22 19:26:30.213767
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-22 19:26:32.222286
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    setting = config.get_setting('locatie')
    assert setting is None


# Generated at 2022-06-22 19:26:37.454282
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Data and expected result
    data = {'name': 'foo', 'value': 'bar'}
    expected = {'name': data['name'], 'value': data['value'], 'plugin': None}

    # Prepare env
    config_data = ConfigData()
    
    # Call method and test results
    config_data.update_setting(Setting(data['name'], data['value']))
    assert(config_data.get_setting(data['name']).to_dict() == expected)



# Generated at 2022-06-22 19:26:46.934035
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_dict = {}
    setting_dict['name'] = 'ansible_shell_executable'
    setting_dict['default'] = '/bin/sh'
    setting_dict['type'] = 'string'
    setting_dict['description'] = 'change the shell used for executing commands on targets'
    setting_dict['ini'] = 'ansible_shell_executable'
    config_data.update_setting(Setting('ansible_shell_executable', '/bin/sh'))
    setting = config_data.get_setting('ansible_shell_executable')
    assert setting.name == setting_dict['name']
    assert setting.default == setting_dict['default']
    assert setting.type == setting_dict['type']
    assert setting.description == setting_dict['description']
    assert setting

# Generated at 2022-06-22 19:26:48.623100
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd is not None


# Generated at 2022-06-22 19:27:00.403901
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import ansible.plugins.loader as loader
    from ansible.config.setting import Setting
    from ansible.errors import AnsibleOptionsError
    setting1 = Setting('test1', 'test1', 'test1', 'test1', None, None)
    loader_instance = loader.PluginLoader(class_suffix='Test')
    config_data = ConfigData()
    config_data.update_setting(setting1)
    assert config_data._global_settings['test1'].value == 'test1'
    assert config_data._global_settings['test1'].name == 'test1'
    assert config_data._global_settings['test1'].origin == 'test1'
    assert config_data._global_settings['test1'].plugin == 'test1'
    assert config_data._global_settings['test1'].plugin

# Generated at 2022-06-22 19:27:02.149386
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-22 19:27:05.784806
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(GlobalSetting('default_class', 'default'))
    assert config_data.get_setting('default_class')
    assert config_data.get_setting('no_such_setting') is None


# Generated at 2022-06-22 19:27:12.612084
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert not config_data._global_settings
    assert not config_data._plugins
    assert config_data.get_settings('not_a_valid_input') == []
    assert config_data.get_settings().get_settings() == []
    assert config_data.get_settings(1).get_settings() == []
    assert config_data.get_settings(1.2).get_settings() == []
    assert config_data.get_settings(b'test').get_settings() == []
    assert (True, 'test') not in config_data.get_settings()
    assert config_data.get_settings([True, 'test']).get_settings() == []
    assert True not in config_data.get_settings()
    assert config_data.get_settings(True).get_settings

# Generated at 2022-06-22 19:27:15.499570
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert configdata is not None
    assert configdata._global_settings != None
    assert configdata._plugins != None


# Generated at 2022-06-22 19:27:17.688829
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:27:26.104418
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    c = ConfigData()
    c.update_setting(Setting('foo', 'bar'))
    c.update_setting(Setting('foo', 'baz'), Plugin('connection', 'local'))
    c.update_setting(Setting('bar', 'baz'), Plugin('connection', 'local'))

    assert c.get_setting('foo') == Setting('foo', 'bar')
    assert c.get_setting('foo', Plugin('connection', 'local')) == Setting('foo', 'baz')
    assert c.get_setting('baz') is None


# Generated at 2022-06-22 19:27:28.704547
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    plugin = Plugin()
    setting = Setting(plugin)
    config_data.update_setting(setting, plugin)

    assert config_data._plugins['plugin']['name']['name'] == setting


# Generated at 2022-06-22 19:27:30.321795
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-22 19:27:42.860973
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0

    class Setting(object):

        def __init__(self, name, namespace, value):

            self.name = name
            self.namespace = namespace
            self.value = value

    config_data.update_setting(Setting(name="foo", namespace="bar", value="baz"))

    assert len(config_data._global_settings) == 1
    assert len(config_data._plugins) == 0

    config_data.update_setting(Setting(name="moo", namespace="cow", value="milk"))

    assert len(config_data._global_settings) == 1
    assert len(config_data._plugins) == 0


# Generated at 2022-06-22 19:27:52.260658
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Create an instance of class ConfigData, then call its method update_setting
    config_data = ConfigData()
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0

    setting = {}
    setting['name'] = 'test_setting'
    setting['value'] = 'test_value'
    plugin_name = 'test_plugin'

    config_data.update_setting(setting)

    assert len(config_data._global_settings) == 1
    assert len(config_data._plugins) == 0
    assert config_data._global_settings[setting['name']] == setting

    config_data.update_setting(setting, plugin=plugin_name)
    assert len(config_data._global_settings) == 1
    assert len(config_data._plugins) == 1


# Generated at 2022-06-22 19:27:59.660277
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    '''
    ConfigData: get_settings(self, plugin=None) -> list(ConfigSetting)
    plugin = None, return a list of all global settings
    plugin = None, return a list of all settings for the specified plugin
    '''
    from collections import namedtuple
    from unittest import TestCase

    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    from ansible.galaxy.collection_info import CollectionInfo
    from ansible.galaxy.collection_artifact import CollectionArtifact
    from ansible.galaxy.collection_version import CollectionVersion
    from ansible.galaxy.collection_meta import CollectionMetadata
    from ansible.galaxy.collection_dependency import CollectionDependency

# Generated at 2022-06-22 19:28:06.739361
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    setting = ConfigSetting(name='var_a', default='a', value='b', origin='test')
    data.update_setting(setting)
    result = data.get_settings()
    assert result == [setting]
    assert result[0].name == 'var_a'
    assert result[0].default == 'a'
    assert result[0].value == 'b'
    assert result[0].origin == 'test'



# Generated at 2022-06-22 19:28:14.039566
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Init ConfigData
    config_data = ConfigData()

    # Init setting
    setting = {}
    setting['name'] = 'EXAMPLE_NAME'
    setting['value'] = 'EXAMPLE_VALUE'
    setting['origin'] = 'EXAMPLE_ORIGIN'
    setting['plugin'] = None
    setting['plugin_type'] = 'EXAMPLE_PLUGIN_TYPE'

    # Update setting
    config_data.update_setting(setting)

    # Test get_setting
    assert setting == config_data.get_setting(setting['name'])


# Generated at 2022-06-22 19:28:17.532326
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    data.update_setting(None)
    assert(data._global_settings == {})
    data.update_setting(None, None) 
    assert(data._global_settings == {})


# Generated at 2022-06-22 19:28:19.803301
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert c.get_setting("test") is None

# Generated at 2022-06-22 19:28:21.456627
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()


# Generated at 2022-06-22 19:28:27.175311
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    assert cd.get_setting('user') is None

    cd.update_setting(Setting('user', 'someuser'))
    assert cd.get_setting('user') is not None
    assert cd.get_setting('user').value == 'someuser'


# Generated at 2022-06-22 19:28:30.257750
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # TODO: need to find a way to mock the config objects
    pass


# Generated at 2022-06-22 19:28:39.634050
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test 1: Get global settings
    setting = config_data.get_setting('default_vars_files')
    assert setting is not None
    assert setting.name == 'default_vars_files'

    # Test 2: Get plugin settings
    plugin = Plugin('cloud', 'azure')
    setting = config_data.get_setting(name='base_profile', plugin=plugin)
    assert setting is not None
    assert setting.name == 'base_profile'
    assert setting.plugin == plugin

    # Test 3: Get a non-exist global setting
    setting = config_data.get_setting('random_setting')
    assert setting is None

    # Test 4: Get a non-exist plugin setting
    plugin = Plugin('random', 'random')

# Generated at 2022-06-22 19:28:47.202060
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = Setting('setting1', 'value1')
    config_data.update_setting(setting)
    test_setting = config_data.get_setting('setting1')
    assert test_setting is not None
    assert test_setting.name == 'setting1'
    assert test_setting.value == 'value1'


# Generated at 2022-06-22 19:28:59.126153
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    config_data.update_setting(Setting('version', '2.4'))
    config_data.update_setting(Setting('defaults_path', '/path/to/ansible/defaults'))
    assert len(config_data.get_settings()) == 2
    setting = Setting('version', '2.4')
    plugin = Plugin('defaults', 'lookup', '/path/to/ansible/defaults/lookup')
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings(plugin) == [setting]
    assert config_data.get_settings() == [config_data._global_settings['version'], config_data._global_settings['defaults_path']]

# Unit test

# Generated at 2022-06-22 19:29:01.196131
# Unit test for constructor of class ConfigData
def test_ConfigData():
    a = ConfigData()
    assert type(a) == ConfigData

# Generated at 2022-06-22 19:29:09.394014
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()
    config.update_setting(Setting('some_global_setting', 'some_global_value'))
    config.update_setting(Setting('some_plugin_setting', 'some_plugin_value'), Plugin('some_plugin', 'some_type'))

    assert config.get_setting('some_global_setting') == Setting('some_global_setting', 'some_global_value')
    assert config.get_setting('some_plugin_setting', Plugin('some_plugin', 'some_type')) == Setting('some_plugin_setting',
                                                                                    'some_plugin_value')


# Generated at 2022-06-22 19:29:17.087981
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    test_setting = Setting("env", "export ANSIBLE_REMOTE_TEMP=/tmp", "", "")
    config_data.update_setting(test_setting)
    assert config_data.get_setting("env").value == "/tmp"

if __name__ == "__main__":
    import sys
    import pytest
    sys.exit(pytest.main(["-s", __file__]))

# Generated at 2022-06-22 19:29:26.946076
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.connection.ssh import Connection as SshPlugin
    from ansible.plugins.connection.winrm import Connection as WinrmPlugin
    from ansible.plugins.connection.local import Connection as LocalPlugin
    from ansible.plugins.connection.httpapi import Connection as HttpapiPlugin
    from ansible.plugins.connection.netconf import Connection as NetconfPlugin
    from ansible.plugins.connection.nxos import Connection as NxosPlugin
    from ansible.plugins.connection.eos import Connection as EosPlugin
    from ansible.plugins.connection.junos import Connection as JunosPlugin
    plugin_loader = PluginLoader()
    ssh_plugin = plugin_loader.get(SshPlugin.type, SshPlugin.name)
   

# Generated at 2022-06-22 19:29:29.173511
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert len(data.get_settings()) == 0

# Generated at 2022-06-22 19:29:39.911485
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # initialize objects
    a = Setting(name='test1', value='value1')
    b = Setting(name='test2', value='value2')
    c = Setting(name='test3', value='value3')

    data = ConfigData()

    assert data.get_settings() == []

    data.update_setting(a)
    assert data.get_settings() == [a]

    data.update_setting(b)
    assert data.get_settings() == [a, b]

    # initialize plugin
    plugin = Plugin('test', 'action')

    data.update_setting(a, plugin)
    assert data.get_settings() == [a, b]
    assert data.get_settings(plugin) == [a]

    # update setting
    a = Setting(name='test1', value='value11')
   

# Generated at 2022-06-22 19:29:50.725349
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = MockSetting("plugins_dir", "/somefolder")
    config_data.update_setting(setting)
    setting = MockSetting("plugins_dir", "/someotherfolder")
    config_data.update_setting(setting, MockPlugin("connection", "local"))
    setting = MockSetting("connection_plugins", ["local", "netconf"])
    config_data.update_setting(setting, MockPlugin("connection", "local"))

    settings = config_data.get_settings()
    assert len(settings) == 1
    assert settings[0].name == "plugins_dir"
    assert settings[0].value == "/somefolder"

    settings = config_data.get_settings(MockPlugin("connection", "local"))
    assert len(settings) == 2

# Generated at 2022-06-22 19:29:59.799790
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    
    # call method update_setting
    config_data = ConfigData()
    config_data.update_setting("setting1")

    # assert global settings
    global_settings = config_data.get_settings()
    assert(len(global_settings) == 1)
    assert(global_settings[0] == "setting1")

    # call method update_setting
    config_data.update_setting("setting2", "type", "name")

    # assert plugin settings
    plugin_settings = config_data.get_settings("type", "name")
    assert(len(plugin_settings) == 1)
    assert(plugin_settings[0] == "setting2")


# Generated at 2022-06-22 19:30:04.152419
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert data.get_settings() == []
    data.update_setting(Setting(name='var1', value='val1'))
    data.update_setting(Setting(name='var2', value='val2'))
    assert data.get_settings() == [Setting(name='var1', value='val1'), Setting(name='var2', value='val2')]


# Generated at 2022-06-22 19:30:12.873075
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'default', 'string', 'This is test setting'))
    config_data.update_setting(Setting('test_setting1', 'default', 'string', 'This is test setting'), Plugin('test_plugin', 'test_type'))

    #Test for global setting
    assert config_data.get_setting('test_setting') is not None
    assert config_data.get_setting('test_setting').name == 'test_setting'
    assert config_data.get_setting('test_setting').default == 'default'
    assert config_data.get_setting('test_setting').type == 'string'
    assert config_data.get_setting('test_setting').description == 'This is test setting'

    #Test for plugin setting
    assert config