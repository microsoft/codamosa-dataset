

# Generated at 2022-06-22 19:20:16.227970
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    ansible = ConfigData()
    ansible.update_setting({'name': 'g_setting1', 'value': 'value1'})
    ansible.update_setting({'name': 'g_setting2', 'value': 'value2'})
    ansible.update_setting({'name': 'c_setting1', 'value': 'value3'}, {'type': 'callback', 'name': 'my_callback'})
    ansible.update_setting({'name': 'c_setting2', 'value': 'value4'}, {'type': 'callback', 'name': 'my_callback'})

    assert ansible._global_settings['g_setting1'] ==  {'name': 'g_setting1', 'value': 'value1'}

# Generated at 2022-06-22 19:20:17.494150
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data


# Generated at 2022-06-22 19:20:20.290669
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert(config_data._global_settings == {})
    assert(config_data._plugins == {})


# Generated at 2022-06-22 19:20:21.234745
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()


# Generated at 2022-06-22 19:20:31.737338
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()

    # test with empty config data
    assert config.get_settings() == []

    # test with global setting(s) only
    setting = ConfigSetting(name='setting1')
    config.update_setting(setting)
    assert config.get_settings() == [setting]

    # test with plugin setting(s) only
    plugin = ConfigPlugin('my_module', 'lookup')
    setting = ConfigSetting(name='setting1')
    config.update_setting(setting, plugin)
    assert config.get_settings() == []

    # test with global and plugin setting(s)
    setting = ConfigSetting(name='setting2')
    config.update_setting(setting)
    assert config.get_settings() == [setting]
    assert config.get_settings(plugin) == [setting]


# Unit test

# Generated at 2022-06-22 19:20:33.571738
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('missing') is None


# Generated at 2022-06-22 19:20:35.564461
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data._global_settings == {}
    assert data._plugins == {}


# Generated at 2022-06-22 19:20:37.770750
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-22 19:20:45.114927
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()

    setting_1 = Setting('test1', 'test1 value')
    setting_2 = Setting('test2', 'test2 value')
    plugin = Plugin(PluginType.CACHE, 'test')

    # Test not existing global setting
    assert config.get_setting('not_existing') is None

    # Test not existing plugin
    assert config.get_setting('not_existing', plugin) is None

    # Test existing global setting
    config.update_setting(setting_1)
    assert config.get_setting('test1') is setting_1

    # Test existing plugin setting
    config.update_setting(setting_2, plugin)
    assert config.get_setting('test2', plugin) is setting_2

    # Test not existing plugin setting

# Generated at 2022-06-22 19:20:54.438085
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    assert not config.get_settings()

    config._global_settings['foo'] = 1
    config._global_settings['bar'] = 2
    assert config.get_settings() == [1, 2]

    config._plugins['a'] = {'b': {'foo': 1}}
    assert config.get_settings(plugin='a.b') == [1]

    config._plugins['a']['b']['bar'] = 2
    assert config.get_settings(plugin='a.b') == [1, 2]

    config._plugins['a']['c'] = {'foo': 1}
    assert config.get_settings(plugin='a.c') == [1]

    config._plugins['b'] = {'c': {'foo': 1}}

# Generated at 2022-06-22 19:21:04.663347
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Create a ConfigData object
    cd = ConfigData()

    # Create a Setting object
    class Plugin(object):
        type = 'plugin_type'
        name = 'plugin_name'
    class Setting(object):
        def __init__(self, name):
            self.name = name
            self.value = 'value_%s' % name
            self.origin = 'origin_%s' % name
    s1 = Setting('s1')
    cd.update_setting(s1)

    # Get the setting s1 and check if it returns the right values
    assert cd.get_setting('s1') is not None
    assert cd.get_setting('s1').name == 's1'
    assert cd.get_setting('s1').value == 'value_s1'

# Generated at 2022-06-22 19:21:08.174330
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('setting_foo', 'This is a setting...', 'value of setting foo')
    config_data.update_setting(setting)
    assert config_data._global_settings['setting_foo'] == setting


# Generated at 2022-06-22 19:21:09.841540
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}


# Generated at 2022-06-22 19:21:16.001271
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = ConfigSetting()
    setting.name = "foo"
    setting.value = "bar"
    config_data.update_setting(setting)

    setting = ConfigSetting()
    setting.name = "far"
    setting.value = "boo"
    config_data.update_setting(setting)

    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings()) == 2



# Generated at 2022-06-22 19:21:25.461173
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = { 'setting1': 'value1', 'setting2': 'value2'}
    config_data._plugins = {
        'lookup': {
            'plugin1': {
                'setting1': 'plugin1_setting1',
                'setting2': 'plugin1_setting2'
            },
            'plugin2': {
                'setting1': 'plugin2_setting1',
                'setting2': 'plugin2_setting2'
            }
        }
    }
    settings = config_data.get_settings()
    assert settings is not None
    assert len(settings) == 2
    assert settings[0].name == 'setting1'
    assert settings[0].value == 'value1'
    assert settings[1].name == 'setting2'
   

# Generated at 2022-06-22 19:21:30.288647
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    plugin = Plugin('module', 'default_sudo')
    setting = Setting('sudo_user', 'default_sudo', 'value', 'value_type', 'comment')
    config.update_setting(setting, plugin)

    assert(config.get_setting('sudo_user', plugin) == setting)


# Generated at 2022-06-22 19:21:33.550786
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:21:36.876638
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    cd.update_setting('test_setting', 'test_plugin')
    assert cd.get_setting(), 'test_setting'
    assert cd.get_setting().name == 'test_setting'


# Generated at 2022-06-22 19:21:44.038456
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = {
        "name": "max_fail_percentage",
        "description": "Maximum percentage of hosts to fail for the run to be considered failed",
        "raw": 1,
        "value": 1.1,
        "origin": "runner.yml"
    }
    config_data.update_setting(setting)
    my_setting = config_data.get_setting("max_fail_percentage")
    assert my_setting.name == "max_fail_percentage"
    assert my_setting.origin == "runner.yml"


# Generated at 2022-06-22 19:21:48.183689
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    data = ConfigData()
    global_setting = Setting('global-setting', 'global-value')
    data.update_setting(global_setting)

    assert data.get_settings() == [global_setting]


# Generated at 2022-06-22 19:21:50.462155
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:21:59.444640
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'global', 'global value'))
    config_data.update_setting(Setting('setting2', 'module', 'module value'))
    config_data.update_setting(Setting('setting3', 'module', 'module value'))
    config_data.update_setting(Setting('setting4', 'module', 'module value'))
    config_data.update_setting(Setting('setting5', 'module', 'module value'), plugin=Plugin('module', 'local'))
    config_data.update_setting(Setting('setting6', 'module', 'module value'), plugin=Plugin('module', 'local'))
    config_data.update_setting(Setting('setting7', 'facts', 'facts value'), plugin=Plugin('facts', 'local'))
    config

# Generated at 2022-06-22 19:22:10.824294
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Test 'get_settings' method of class ConfigData

    # Initialize object 'p' of class ConfigData
    p = ConfigData()

    # Test with all parameters of type plugin
    # Test with a known plugin - 'yum'
    assert p.get_settings('yum') == []

    # Test with a known plugin - 'apt'
    assert p.get_settings('apt') == []

    # Test with a known plugin - 'service'
    assert p.get_settings('service') == []

    # Test with a known plugin - 'command'
    assert p.get_settings('command') == []

    # Test with a known plugin - 'shell'
    assert p.get_settings('shell') == []

    # Test with a known plugin - 'script'
    assert p.get_settings('script') == []

    # Test

# Generated at 2022-06-22 19:22:18.385413
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()

    from ansible.config.setting import Setting
    from ansible.config.manager import ConfigManager
    from ansible.plugins import connection_loader

    config_manager = ConfigManager()
    config_manager.get_plugin_option_groups()

    plugin = connection_loader.get('local')()
    config_manager.init_plugin_configuration(plugin)

    for setting in config_manager.get_plugin_settings(plugin):
        config.update_setting(setting, plugin)

    assert plugin.name in config._plugins[plugin.type]
    assert len(config.get_settings(plugin)) == len(list(config._plugins[plugin.type][plugin.name].keys()))

# Generated at 2022-06-22 19:22:20.024227
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert(isinstance(config_data, ConfigData))


# Generated at 2022-06-22 19:22:25.182140
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    config_data._global_settings = {'name1': 'desc1', 'name2': 'desc2'}
    config_data._plugins = {'connection': {'local': {'name3': 'desc3', 'name4': 'desc4'}}}

    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings('local')) == 4

# Generated at 2022-06-22 19:22:26.234710
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()


# Generated at 2022-06-22 19:22:28.474187
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cd = ConfigData()
    assert cd._global_settings == {}
    assert cd._plugins == {}


# Generated at 2022-06-22 19:22:36.044310
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data._global_settings['foo'].value == 'bar'

    config_data.update_setting(Setting('bar', 'baz'),
                               Plugin('baz', 'plugin', 'module'))
    assert config_data._plugins['module']['baz']['bar'].value == 'baz'
    config_data.update_setting(Setting('foo', 'baz'),
                               Plugin('baz', 'plugin', 'module'))
    assert config_data._plugins['module']['baz']['foo'].value == 'baz'

    config_data.update_setting(Setting('foo', 'bar'))

# Generated at 2022-06-22 19:22:40.500536
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name = "test_setting"))
    assert Setting(name = "test_setting") == config_data.get_setting("test_setting")


# Generated at 2022-06-22 19:22:47.523512
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    conf_data = ConfigData()
    data_fake = {"name": "rule_default", "plugin": {"name": "default", "type": "rule"}}
    setting_fake = Setting("rule_default", data_fake)
    conf_data.update_setting(setting_fake, setting_fake.plugin)
    assert conf_data.get_setting("rule_default", Plugin("default", "rule")) == setting_fake

    assert conf_data.get_setting("rule_default") == None

    assert conf_data.get_setting("rule_default", Plugin("other_plugin", "rule")) == None



# Generated at 2022-06-22 19:22:49.979885
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)



# Generated at 2022-06-22 19:22:53.198090
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    plugin_loader = None
    plugin = Plugin(plugin_loader)
    setting = Setting()
    config.update_setting(setting, plugin)
    settings = config.get_settings(plugin)
    assert len(settings) == 1

# Generated at 2022-06-22 19:23:03.305890
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    plugin = PluginDescriptor(None, 'script', 'lookup_plugin')
    setting1 = ConfigSetting(None, 'lookup_plugins', './lookup_plugins')
    setting2 = ConfigSetting(None, 'lookup_plugins', '~/.ansible/lookup_plugins')
    setting3 = ConfigSetting(plugin, 'timeout', '120')
    setting4 = ConfigSetting(plugin, 'timeout', '60')
    config.update_setting(setting1, None)
    config.update_setting(setting2, None)
    config.update_setting(setting3, plugin)
    config.update_setting(setting4, plugin)

    assert config.get_settings() == [setting1, setting2]
    assert config.get_settings(plugin) == [setting3, setting4]


#

# Generated at 2022-06-22 19:23:06.142213
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data is not None, "Expected a ConfigData object"

# Generated at 2022-06-22 19:23:13.264984
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    global_setting = Setting('test_name', '/etc/ansible/test_path', 'test_value')
    cd = ConfigData()
    cd.update_setting(global_setting)
    assert global_setting.name == cd.get_settings()[0].name
    assert global_setting.path == cd.get_settings()[0].path
    assert global_setting.value == cd.get_settings()[0].value


# Generated at 2022-06-22 19:23:18.032386
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    ansible_config_data = ConfigData()
    setting = ConfigSetting("name", "default", None)
    ansible_config_data.update_setting(setting)
    assert ansible_config_data.get_setting("name") is not None


# Generated at 2022-06-22 19:23:19.771936
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)

# Generated at 2022-06-22 19:23:27.816171
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # add a plugin
    plugin = Plugin('module', 'mymodule')
    config_data.update_setting(Setting('FOO', 'bar'), plugin)
    assert ['FOO', 'bar'] == config_data.get_settings(plugin)[0].to_list()

    # add a global setting
    config_data.update_setting(Setting('FOO', 'foobar'))
    assert ['FOO', 'foobar'] == config_data.get_settings()[0].to_list()

    # add a second plugin
    plugin = Plugin('module', 'mymodule1')
    config_data.update_setting(Setting('BAR', 'baz'), plugin)
    assert ['BAR', 'baz'] == config_data.get_settings(plugin)[0].to_list()

    #

# Generated at 2022-06-22 19:23:35.853494
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting("foo") is None
    setting = Setting("foo", "bar", "")
    config_data.update_setting(setting)
    assert config_data.get_setting("foo") == setting
    config_data.update_setting(setting)
    assert config_data.get_setting("foo") == setting
    plugin = Plugin("foo", "bar")
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting("foo") == setting
    assert config_data.get_setting("foo", plugin) == setting


# Generated at 2022-06-22 19:23:46.897212
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import unittest
    from ansiblelint.config import ConfigData, Setting, PluginType

    test_config = ConfigData()

    # Empty config
    assert len(test_config.get_settings()) == 0

    # Add one global setting
    test_setting = Setting('setting1', 'value1', 'Test setting #1')
    test_config.update_setting(test_setting)
    assert len(test_config.get_settings()) == 1

    # Add another global setting
    test_setting = Setting('setting2', 'value2', 'Test setting #2')
    test_config.update_setting(test_setting)
    assert len(test_config.get_settings()) == 2

    # Add a plugin
    plugin = PluginType('filter', 'test_plugin')

# Generated at 2022-06-22 19:23:53.903620
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    setting = Setting('test_key', 'value')
    plugin = Plugin('test_type', 'test_name')
    config_data.update_setting(setting)
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting(setting.name) is setting
    assert config_data.get_setting(setting.name, plugin) is setting
    assert config_data.get_setting('other_key') is None


# Generated at 2022-06-22 19:24:02.580807
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    setting1 = ConfigSetting('foo', 'value')
    setting2 = ConfigSetting('bar', 'value')
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)

    assert (config_data.get_settings() is not None)
    assert (len(config_data.get_settings()) == 2)
    for setting in config_data.get_settings():
        assert(setting.name in ['foo', 'bar'])



# Generated at 2022-06-22 19:24:14.857846
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblelint.rules import RulesCollection
    from ansiblelint.rules.LineTooLong import LineTooLong

    global_setting_name = "line_length"
    global_setting_value = 80
    plugin_setting_value = 120

    config_data = ConfigData()
    config_data.update_setting(LineTooLong.LineTooLongSetting(global_setting_name, global_setting_value, None))
    config_data.update_setting(LineTooLong.LineTooLongSetting(global_setting_name, plugin_setting_value, LineTooLong()))

    # get_setting for global line length
    setting = config_data.get_setting('line_length')
    assert setting is not None
    assert setting.name == 'line_length'
    assert setting.value == global_setting_value

# Generated at 2022-06-22 19:24:21.655726
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test normal state when nothing is set
    config_data = ConfigData()
    assert config_data.get_setting('some_setting') is None

    # Test normal state when global setting is set
    config_data.update_setting(ConfigSetting('some_setting', 'global', 'global', 'unix', 'value'))
    assert config_data.get_setting('some_setting').value == 'value'


# Generated at 2022-06-22 19:24:28.412694
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    setting = ConfigSetting(name='test_setting', plugin=Plugin(type='test_type', name='test_name'))
    data.update_setting(setting, plugin=Plugin(type='test_type', name='test_name'))
    assert data._plugins['test_type']['test_name']['test_setting'] is setting

    setting = ConfigSetting(name='test_setting2')
    data.update_setting(setting)
    assert data._global_settings['test_setting2'] is setting


# Generated at 2022-06-22 19:24:30.017114
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()    
    assert config_data is not None


# Generated at 2022-06-22 19:24:32.016445
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting(setting=None)
    assert config_data.get_setting(setting.name) == None



# Generated at 2022-06-22 19:24:35.144838
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}

# Generated at 2022-06-22 19:24:37.549988
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-22 19:24:44.358124
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Print the unit test case
    print("\n- Test method ConfigData.update_setting:")

    # Create an object to update
    config_data = ConfigData()

    # Check the size of the object
    assert len(config_data._global_settings) == 0
    assert len(config_data.get_settings()) == 0

    # Create an object to update
    config_setting = ConfigSetting("a", "b")

    # Update config_setting using global_setting
    config_data.update_setting(config_setting)

    # Check the size of the object
    assert len(config_data._global_settings) == 1
    assert len(config_data.get_settings()) == 1

    # Check returned value
    assert config_data.get_setting("a") == config_setting


# Generated at 2022-06-22 19:24:55.346604
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    test_config_data = ConfigData()

    if test_config_data.get_setting('test1') is None:

        print('ConfigData.get_setting')
        print('    case 1: [ok] ' + 'global config not set')
        print('')
    else:
        print('ConfigData.get_setting')
        print('    case 1: [fail] ' + 'global config already set')
        print('')

    test_config_data.update_setting(Setting('test1', None, 'value1'))
    if test_config_data.get_setting('test1') is not None:

        print('ConfigData.get_setting')
        print('    case 2: [ok] ' + 'global config set')
        print('')
    else:
        print('ConfigData.get_setting')

# Generated at 2022-06-22 19:24:58.689428
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert len(configdata._global_settings) == 0
    assert len(configdata._plugins) == 0

# Generated at 2022-06-22 19:25:02.733920
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    plugin = Plugin('my', 'fancy', 'plugin')
    setting = Setting('my', 'plugin', 'config')
    config.update_setting(setting, plugin)
    assert config.get_settings('my')['fancy']['plugin']['config'] == setting



# Generated at 2022-06-22 19:25:04.967108
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()

    assert(configData is not None)


# Generated at 2022-06-22 19:25:13.991756
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_config_data = ConfigData()

    # The setting is a non-plugin setting i.e. global setting
    non_plugin_setting = Setting(
        name='ANSIBLE_HOST_KEY_CHECKING',
        value='False',
        priority='50',
        domain='',
        plugin='',
        plugin_type='')

    test_config_data.update_setting(non_plugin_setting)
    assert(non_plugin_setting in test_config_data.get_settings())

    # The setting is a plugin setting
    plugin_setting = Setting(
        name='foo',
        value='bar',
        priority='60',
        domain='',
        plugin='myplugin',
        plugin_type='lookup')

    test_config_data.update_setting(plugin_setting)

# Generated at 2022-06-22 19:25:21.851959
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    # Test update_setting() with a global setting
    setting = Setting('core', 'host_key_checking', True, 'ini')
    config_data.update_setting(setting)

    assert config_data._global_settings == {'host_key_checking': setting}
    assert config_data._plugins == {}

    # Test update_setting() with a plugin setting
    plugin = Plugin('action', 'pause', 'defaults')
    setting = Setting('core', 'host_key_checking', False, 'ini')
    config_data.update_setting(setting, plugin)

    expected_result = {'action': {'pause': {'host_key_checking': setting}}}

# Generated at 2022-06-22 19:25:32.147573
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configdata = ConfigData()
    assert configdata.get_setting('') is None
    assert configdata.get_setting('', 'plugin') is None
    assert configdata.get_setting(None) is None
    assert configdata.get_setting(None, 'plugin') is None
    assert configdata.get_setting(None, None) is None
    assert configdata.get_setting('-', None) is None
    assert configdata.get_setting('-', 'plugin') is None
    configdata._global_settings['setting'] = 'setting'
    assert configdata.get_setting('setting') == 'setting'
    assert configdata.get_setting('setting', 'plugin') is None


# Generated at 2022-06-22 19:25:43.473095
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()

    # Test global setting
    configData.update_setting({'name': 'ANSIBLE_TF_STATE_PATH', 'value': 'files/states', 'scope': ['global'], 'origin': 'default'})
    assert configData.get_setting('ANSIBLE_TF_STATE_PATH')

    # Test group plugin setting
    configData.update_setting({'name': 'enabled', 'value': 'False', 'scope': ['group'],'origin': 'default'})
    assert configData.get_setting('enabled')

    # Test inventory plugin setting
    configData.update_setting({'name': 'enable_plugins', 'value': ['freshness'], 'scope': ['inventory'], 'origin': 'default'})
    assert configData.get_setting('enable_plugins')

    # Test module plugin setting
    config

# Generated at 2022-06-22 19:25:50.191008
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    class Plugin():
        type = 'Type'
        name = 'Name'

    plugin = Plugin()

    class Setting():
        name = None

    setting_1 = Setting()
    setting_1.name = 'global_setting_1'
    config_data.update_setting(setting_1)
    assert config_data.get_setting(setting_1.name)

    setting_2 = Setting()
    setting_2.name = 'plugin_setting_1'
    config_data.update_setting(setting_2, plugin)
    assert config_data.get_setting(setting_2.name, plugin)



# Generated at 2022-06-22 19:25:52.116356
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert  config is not None

# Generated at 2022-06-22 19:26:01.050535
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    data = ConfigData()

    # Validating get_settings with Empty ConfigData
    assert data.get_settings() == []
    assert data.get_settings(plugin=None) == []

    # Validating get_settings with empty ansible.cfg
    data.update_setting(Setting(name="empty", plugin=None))
    assert data.get_settings() == []
    assert data.get_settings(plugin=None) == []

    # Validating get_settings with ansible.cfg with 1 setting
    data.update_setting(Setting(name="single", value="single_value", plugin=None))
    assert data.get_settings() == [Setting(name="single", value="single_value", plugin=None)]

# Generated at 2022-06-22 19:26:03.843352
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = object()
    config_data.update_setting(setting, None)
    assert config_data.get_setting("test_setting") == setting



# Generated at 2022-06-22 19:26:05.776608
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert len(data.get_settings()) == 0


# Generated at 2022-06-22 19:26:13.247259
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_global = Setting('A', 'B')
    config_data.update_setting(setting_global)
    assert(config_data.get_setting('A') == setting_global)
    assert(len(config_data.get_settings()) == 1)

    plugin = Plugin('test', 'connection')
    setting_connection = Setting('C', 'B')
    config_data.update_setting(setting_connection, plugin)
    assert(config_data.get_setting('C', plugin) == setting_connection)
    assert(len(config_data.get_settings(plugin)) == 1)


# Generated at 2022-06-22 19:26:18.619592
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    data._global_settings = {'a': 1, 'b': 2}
    data._plugins = {'action': {'a': {'a': 'a'}}}
    assert data.get_settings() == [1, 2]
    assert data.get_settings(plugin=None) == [1, 2]
    assert data.get_settings(plugin=None) != [1, 2]

test_ConfigData_get_settings()

# Generated at 2022-06-22 19:26:24.009342
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    plugin = Plugin('test')
    config.update_setting(ConfigSetting('test', 'test', 'test', 'test'), plugin)
    assert config._plugins['test']['test']['test'].name == 'test'


# Generated at 2022-06-22 19:26:27.322541
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    config_data.update_setting('1')

    assert config_data.get_setting('1') == '1'

# Generated at 2022-06-22 19:26:36.376726
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.plugins.loader import plugin_loader

    config_data = ConfigData()

    plugin_loader.add_directory('../../action')
    plugin_loader.add_directory('../../lookup')
    plugin_loader.add_directory('../../callback')
    plugin_loader.add_directory('../../filter')
    plugin_loader.add_directory('../../connection')
    plugin_loader.add_directory('../../shell')
    plugin_loader.add_directory('../../module_utils')

    # Config settings

# Generated at 2022-06-22 19:26:43.719263
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    global_setting = ConfigSetting("ansible_python_interpreter", "auto")
    config_data.update_setting(global_setting)
    assert global_setting == config_data.get_setting("ansible_python_interpreter")

    local_setting = ConfigSetting("ANSIBLE_CONFIG", "test")
    plugin = Plugin("test")
    config_data.update_setting(local_setting, plugin)
    assert local_setting == config_data.get_setting("ANSIBLE_CONFIG", plugin)



# Generated at 2022-06-22 19:26:45.934680
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert (config_data)

# Test for get_setting function of class ConfigData

# Generated at 2022-06-22 19:26:54.140511
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()
    plugin_loader = PluginLoader('shell', '', '', '')

    if plugin_loader is not None:
        plugin_names = plugin_loader.all()
        for plugin_name in plugin_names:
            plugin = plugin_loader.get(plugin_name)
            config_data.update_setting(plugin.vars_plugin.get_setting('is_default'),  plugin)
        settings = config_data.get_settings()
        assert len(settings) == len(plugin_names)


# Generated at 2022-06-22 19:26:59.114374
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    assert cd.get_setting(None) is None
    assert cd.get_setting('foo') is None
    assert cd.get_setting('foo', None) is None
    assert cd.get_setting('foo', 'bar', 'baz') is None


# Generated at 2022-06-22 19:27:07.338390
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert len(config_data.get_settings()) == 0

    setting1 = Setting('setting1', 'value1', 'global', None)
    config_data.update_setting(setting1, None)

    assert len(config_data.get_settings()) == 1

    plugin = Plugin('callback', 'test')
    setting2 = Setting('setting2', 'value2', 'local', plugin)
    config_data.update_setting(setting2, plugin)

    assert len(config_data.get_settings(plugin)) == 1

    assert config_data.get_settings(plugin)[0].name == 'setting2'


# Generated at 2022-06-22 19:27:12.469705
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    data = ConfigData()
    data.update_setting(Setting('a', 'b', 'c', 'd', 'e', 'f'))
    data.update_setting(Setting('g', 'h', 'i', 'j', 'k', 'l'))
    data.update_setting(Setting('m', 'n', 'o', 'p', 'q', 'r'), Plugin('t', 'u'))
    data.update_setting(Setting('s', 't', 'u', 'v', 'w', 'x'), Plugin('a', 'b'))
    data.update_setting(Setting('y', 'z', '1', '2', '3', '4'), Plugin('z', '1'))

# Generated at 2022-06-22 19:27:22.216331
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin('test', 'test', 'test')
    setting1 = Setting('test_setting', 'test_value', 'test_description')
    setting2 = Setting('test_setting2', 'test_value2', 'test_description2')
    plugin_string = str(plugin.type) + '.' + str(plugin.name) + '.' + str(plugin.path)

    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin)

    assert config_data.get_settings()[0] == setting1
    assert config_data.get_settings(plugin)[0] == setting2

    with pytest.raises(Exception) as e_info:
        config_data.get_setting('test_setting', plugin)

# Generated at 2022-06-22 19:27:24.364338
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    cd = ConfigData()

    assert len(cd.get_settings()) == 0


# Generated at 2022-06-22 19:27:32.602611
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    assert config_data.get_setting("foo") == None, "The universal configration file does not have such a setting!"
    assert config_data.get_setting("foo",4) == None, " setting 'foo' should not be found, as the plugin is None!"

    assert config_data.get_setting("foo", "bar") == None, " setting 'foo' should not be found, as the plugin is not in the list"
    config_data.update_setting("foo")
    assert config_data.get_setting("foo", "bar") == None, " setting 'foo' should not be found, as the plugin is not in the list"

# Generated at 2022-06-22 19:27:35.926648
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    assert configData._global_settings == {}
    assert configData._plugins == {}


# Generated at 2022-06-22 19:27:46.212077
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    global_setting_name = 'some_global_setting'
    global_setting_value = 'some_global_setting_value'
    global_setting = Setting(global_setting_name, global_setting_value)
    CD = ConfigData()
    CD.update_setting(global_setting)
    assert CD.get_setting(global_setting_name) == global_setting

    plugin = Plugin('plugintype', 'pluginname')
    plugin_setting_name = 'some_plugin_setting'
    plugin_setting_value = 'some_plugin_setting_value'
    plugin_setting = Setting(plugin_setting_name, plugin_setting_value)
    CD.update_setting(plugin_setting, plugin)
    assert CD.get_setting(plugin_setting_name, plugin) == plugin_setting

# Generated at 2022-06-22 19:27:50.384644
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting("a", plugin=None)
    config_data.update_setting("b", plugin="c")

if __name__ == '__main__':
    test_ConfigData_update_setting()

# Generated at 2022-06-22 19:27:58.610893
# Unit test for constructor of class ConfigData
def test_ConfigData():

    from cStringIO import StringIO

    cdata = ConfigData()
    cdata.update_setting(Setting('setting1', 'value1'))
    cdata.update_setting(Setting('setting2', 'value2', plugin_type='inventory'))
    cdata.update_setting(Setting('setting3', 'value3', plugin_name='plugin1', plugin_type='inventory'))
    cdata.update_setting(Setting('setting4', 'value4', plugin_name='plugin2', plugin_type='inventory'))
    cdata.update_setting(Setting('setting5', 'value5', plugin_name='plugin3', plugin_type='lookup'))


# Generated at 2022-06-22 19:28:09.878987
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # example settings
    plugins = [
        (
            Plugin(type='action', name='ping'),
            {
                'setting1': Setting(name='setting1', value='value1', origin='ansible.cfg'),
                'setting2': Setting(name='setting2', value='value2', origin='env'),
            }
        ),
        (
            Plugin(type='action', name='ipaddr'),
            {
                'setting1': Setting(name='setting1', value='value1', origin='ansible.cfg'),
            }
        ),
    ]


# Generated at 2022-06-22 19:28:17.540497
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)

    from ansible.plugins.loader import find_plugin
    pre_check = find_plugin('pre_tasks', 'pre_tasks', False)
    assert pre_check == PluginDefinition(plugin_type='pre_tasks', plugin_name='pre_tasks')

    from ansible.plugins.loader import PluginDefinition
    from ansible.parsing.plugin_docs import read_docstring

    definition = PluginDefinition()
    setting_data = read_docstring(definition, pre_check.plugin_obj)
    assert setting_data.pop('requirements') == []


# Generated at 2022-06-22 19:28:21.243412
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-22 19:28:28.953043
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # make a config data object
    config_data_obj = ConfigData()

    # make a sample config setting
    sample_config_setting_name = "name"
    sample_config_setting_type = "type"
    sample_config_setting_default = "default"
    sample_config_setting_description = "description"
    sample_config_setting_value = None
    sample_config_setting_origin = None

    sample_config_setting_obj = ConfigSetting(sample_config_setting_name,
                                              sample_config_setting_type,
                                              sample_config_setting_default,
                                              sample_config_setting_description,
                                              sample_config_setting_value,
                                              sample_config_setting_origin)

    # make a sample plugin
    sample_plugin_name = "name"

# Generated at 2022-06-22 19:28:39.184241
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()

    assert cd._global_settings == {}
    assert cd._plugins == {}

    cd.update_setting(Setting('foo', 'bar'))
    assert cd._global_settings == {'foo': Setting('foo', 'bar')}

    cd.update_setting(Setting('bar', 'baz'), Plugin('type', 'name'))
    assert cd._plugins == {'type': {'name': {'bar': Setting('bar', 'baz')}}}

    cd.update_setting(Setting('foo', 'baz'), Plugin('type', 'name'))
    assert cd._plugins == {'type': {'name': {'bar': Setting('bar', 'baz'), 'foo': Setting('foo', 'baz')}}}


# Generated at 2022-06-22 19:28:40.171256
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}


# Generated at 2022-06-22 19:28:46.151786
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    global_setting_1 = {"name": "global_setting_1",
                        "value": "value_1",
                        "filename": "filename_1"}
    global_setting_2 = {"name": "global_setting_2",
                        "value": "value_2",
                        "filename": "filename_2"}
    plugin_setting_1 = {"name": "plugin_setting_1",
                        "value": "plugin_value_1",
                        "filename": "plugin_filename_1"}
    plugin_setting_2 = {"name": "plugin_setting_2",
                        "value": "plugin_value_2",
                        "filename": "plugin_filename_2"}

# Generated at 2022-06-22 19:28:48.939694
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)

# get_setting function should return required setting

# Generated at 2022-06-22 19:28:57.148106
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0

    setting1 = Setting('setting1')
    setting2 = Setting('setting2')
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    assert len(config_data.get_settings()) == 2

    plugin = Plugin('name', 'type')
    assert len(config_data.get_settings(plugin)) == 0

# Generated at 2022-06-22 19:29:07.521933
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting_1 = Setting('foo', 'bar')
    setting_2 = Setting('boo', 'baz')
    setting_3 = Setting('baz', 'foo')
    plugin = Plugin('action', 'test')

    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2, plugin)
    config_data.update_setting(setting_3, plugin)
    setting = config_data.get_setting('baz', plugin)
    assert setting.name == 'baz'
    assert setting.value == 'foo'


# Generated at 2022-06-22 19:29:11.257339
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0

test_ConfigData_get_settings()

# Generated at 2022-06-22 19:29:13.296354
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config is not None


# Generated at 2022-06-22 19:29:15.208348
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert not data.get_settings()


# Generated at 2022-06-22 19:29:25.262071
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import sys

    import pytest
    from units.mock.mock_module_loader import MockModuleLoader
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.connection.winrm import Connection
    from ansible.module_utils._text import to_text

    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

    import ansible.constants as C

    class MockPlugin(object):

        def get_option(self, connection, name):
            pass

    def cache_plugin(plugin_name, plugin_class):
        return MockPlugin()

    class MockInventory():

        def __init__(self, host_list):
            self._hosts = host_list


# Generated at 2022-06-22 19:29:29.253973
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting('setting1=value1')
    config.update_setting('setting2=value2')
    assert config.get_setting('setting1') == 'value1'
    assert config.get_setting('setting2') == 'value2'


# Generated at 2022-06-22 19:29:39.699422
# Unit test for constructor of class ConfigData
def test_ConfigData():

    from ansiblelint.rules.test_data.test_setting_type import config_data_global_setting
    from ansiblelint.rules.test_data.test_setting_type import config_data_plugin_setting

    config_data = ConfigData()

    assert config_data is not None

    config_data.update_setting(config_data_global_setting, None)
    config_data.update_setting(config_data_plugin_setting, "Plugin")

    assert config_data.get_setting("plugin_types", None) == 'python'
    assert config_data.get_setting("verbosity", "Plugin") == 3

    assert config_data.get_settings(None) is not None
    assert config_data.get_settings("Plugin") is not None

# Generated at 2022-06-22 19:29:43.334052
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configdata = ConfigData()
    setting1 = Setting('plugin type', 'plugin name', 'setting name', 'setting value', 'setting scope')
    configdata.update_setting(setting1)
    assert setting1 == configdata.get_setting('setting name', 'plugin type', 'plugin name')

# Generated at 2022-06-22 19:29:46.254208
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-22 19:29:50.845062
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()
    configdata.update_setting(Setting("test1", "val1"))
    configdata.update_setting(Setting("test2", "val2"))
    configdata.update_setting(Setting("test3", "val3"))
    assert len(configdata.get_settings()) == 3


# Generated at 2022-06-22 19:30:01.251224
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    assert config_data.get_settings() == []

    config_data = ConfigData()
    config_data.update_setting(Setting('bool', 'True'), Plugin('connection', 'ssh'))
    config_data.update_setting(Setting('bool', 'False'), Plugin('lookup', 'template'))
    config_data.update_setting(Setting('bool', 'True'))
    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings(Plugin('connection', 'ssh'))) == 1
    assert config_data.get_settings(Plugin('connection', 'ssh'))[0].value == 'True'
    assert config_data.get_settings(Plugin('connection', 'ssh'))[0].plugin.name == 'ssh'
    assert config_data

# Generated at 2022-06-22 19:30:04.389466
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    setting = Setting('test', 'global')
    config.update_setting(setting)
    assert len(config._global_settings) == 1
    assert setting.name in config._global_settings
    assert config._global_settings[setting.name] == setting


# Generated at 2022-06-22 19:30:08.548904
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = Setting(name='local', value='localhost')
    config_data.update_setting(setting)
    settings = config_data.get_settings()
    assert settings[0] == setting
