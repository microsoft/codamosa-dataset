

# Generated at 2022-06-22 19:20:08.840301
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-22 19:20:18.718773
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print()
    print('Testing ConfigData:update_setting()')

    print('\tTest 1: Valid plugin and setting')
    data = ConfigData()
    plugin = Plugin()
    plugin.type = 'test_type_1'
    plugin.name = 'test_name_1'
    setting = Setting()
    setting.name = 'test_setting_1'
    setting.value = 'test_value_1'
    data.update_setting(setting, plugin)
    assert data.get_setting('test_setting_1', plugin) == setting

    print('\tTest 2: Valid setting, no plugin')
    setting = Setting()
    setting.name = 'test_setting_2'
    setting.value = 'test_value_2'
    data.update_setting(setting)

# Generated at 2022-06-22 19:20:26.156569
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    setting1 = {'name': 'path', 'value': '/etc/ansible'}
    config.update_setting(setting1)
    actual = config.get_setting('path', None)
    expected = {'name': 'path', 'value': '/etc/ansible'}
    assert(actual == expected)
    actual = config.get_setting('connection', None)
    assert(actual is None)
    actual = config.get_setting('connection', 'localhost')
    assert(actual is None)

    connection_plugin_type = 'connection'
    connection_plugin_name = 'netconf'
    connection_plugin = {connection_plugin_type: {connection_plugin_name: {'host': 'localhost', 'port': 830}}}
    config.update_setting(connection_plugin)

# Generated at 2022-06-22 19:20:28.384425
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-22 19:20:38.731626
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    print (c._global_settings)
    print (c._plugins)
            
    # check for global settings
    c.update_setting(Setting('setting1', 'value1'))
    c.update_setting(Setting('setting2', 'value2'))
    assert len(c.get_settings()) == 2
    assert c.get_setting('setting1') == Setting('setting1', 'value1')
    assert c.get_setting('setting2') == Setting('setting2', 'value2')

    # check for local settings
    p = Plugin('local1', 'plugintype')
    c.update_setting(Setting('setting1', 'value1', 'local1'), p)
    c.update_setting(Setting('setting2', 'value2', 'local1'), p)
    c.update_setting

# Generated at 2022-06-22 19:20:47.969081
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.module_utils.common.config_loader import ConfigData, ConfigSetting

    o = ConfigData()

    o.update_setting(ConfigSetting(name='setting1', value='value1'))
    o.update_setting(ConfigSetting(name='setting1', value='value1', plugin_type='action', plugin_name='debug'))

    assert o.get_settings() == [ConfigSetting(name='setting1', value='value1')]
    assert o.get_settings('action', 'debug') == [ConfigSetting(name='setting1', value='value1', plugin_type='action', plugin_name='debug')]


# Generated at 2022-06-22 19:20:55.854623
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()

    global_settings = configData.get_settings()
    assert(not global_settings)

    setting = Setting("setting1", "value1")
    configData.update_setting(setting)

    global_settings = configData.get_settings()
    assert(len(global_settings) == 1)
    assert(global_settings[0].name == "setting1")

    # Test plugin settings
    plugin_settings = configData.get_settings("plugin")
    assert(not plugin_settings)

    plugin_settings = configData.get_settings("plugin1")
    assert(not plugin_settings)

    plugin_settings = configData.get_settings("plugin2")
    assert(not plugin_settings)

    setting = Setting("setting2", "value2")

# Generated at 2022-06-22 19:20:58.641838
# Unit test for constructor of class ConfigData
def test_ConfigData():
    test_data = ConfigData()
    assert len(test_data._global_settings) == 0
    assert len(test_data._plugins) == 0


# Generated at 2022-06-22 19:20:59.021257
# Unit test for constructor of class ConfigData
def test_ConfigData():

    settings = ConfigData()

# Generated at 2022-06-22 19:21:04.249372
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    setting = {
        'name': 'Greeting',
        'description': 'The message to display on startup.',
        'env': [{
            'name': 'GREETING',
            'value': 'Hello'
        }]
    }

    config_data.update_setting(setting)

    assert setting == config_data.get_setting('Greeting')


# Generated at 2022-06-22 19:21:06.324861
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('version', '2.4', 'global'))
    assert config_data.get_setting('version') is not None


# Generated at 2022-06-22 19:21:07.634290
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert(config is not None)



# Generated at 2022-06-22 19:21:12.592833
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    setting_with_default = ConfigSetting('a', 'string', 'b', 'c', 'd')
    cd.update_setting(setting_with_default)
    setting_with_no_default = ConfigSetting('b', 'string', None, None, None)
    cd.update_setting(setting_with_no_default)
    assert cd.get_setting('a').default == 'c'
    assert cd.get_setting('b') is None

# Generated at 2022-06-22 19:21:23.546161
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    result = True
    config_data = ConfigData()

    class Plugin(object):

        def __init__(self, name, type, path):
            self.name = name
            self.type = type
            self.path = path

    class Setting(object):

        def __init__(self, type, name):
            self.type = type
            self.name = name

    def create_setting(type, name):
        return Setting(type, name)

    # test with empty config_data
    test_settings = config_data.get_settings(None)
    if len(test_settings) != 0:
        result = False

    # test with plugin and empty setting
    test_plugin = Plugin('plugin1', 'type1', '/path1')
    test_settings = config_data.get_settings(test_plugin)


# Generated at 2022-06-22 19:21:30.521203
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = ConfigSetting('foo', 'bar', 'baz')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting 
    plugin = Plugin('module', 'baz', 'baz')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('foo', plugin) == setting


# Generated at 2022-06-22 19:21:39.819762
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.config.setting import Setting

    config_data = ConfigData()

    # create a setting valid for all plugins
    setting_global = Setting('foo', 'bar')
    # create a setting valid for only one plugin of type "shell"
    setting_shell = Setting('foo', 'baz')
    setting_shell.parents.append('shell')
    # create a setting valid for only one plugin of type "inventory"
    setting_inventory = Setting('foo', 'quux')
    setting_inventory.parents.append('inventory')
    # create a setting valid for only two plugins of type "shell"
    setting_shell2 = Setting('foo', 'frob')
    setting_shell2.parents.append('shell')
    setting_shell2.parents.append('shell_foo')

    config_data.update_setting(setting_global)

# Generated at 2022-06-22 19:21:41.048468
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data._global_settings, {})


# Generated at 2022-06-22 19:21:47.631698
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    obj = ConfigData()
    assert obj._global_settings == {}
    assert obj._plugins == {}
    obj.update_setting("setting1")
    assert obj._global_settings == {"setting1" : "setting1"}
    assert obj._plugins == {}
    obj.update_setting("setting2")
    assert obj._global_settings == {"setting1" : "setting1", "setting2" : "setting2"}
    assert obj._plugins == {}
    obj.update_setting("setting3", Plugin("filter", "plugin1"))
    assert obj._global_settings == {"setting1" : "setting1", "setting2" : "setting2"}
    assert obj._plugins == {"filter" : {"plugin1" : {"setting3" : "setting3"}}}
    obj.update_setting("setting1", Plugin("filter", "plugin2"))


# Generated at 2022-06-22 19:21:57.520828
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    configData.update_setting({'name': 'setting', 'value': 'settingvalue'})
    configData.update_setting({'name': 'setting1', 'value': 'settingvalue1', 'plugin': {'name': 'testplugin'}})
    configData.update_setting({'name': 'setting2', 'value': 'settingvalue2', 'plugin': {'name': 'testplugin', 'type': 'action'}})
    assert configData.get_setting('setting')['name'] == 'setting'
    assert configData.get_setting('setting1') is None
    assert configData.get_setting('setting2') is None
    assert configData.get_setting('setting', {'name': 'testplugin'})['name'] == 'setting1'

# Generated at 2022-06-22 19:22:03.861829
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    global_settings = {}
    global_settings["one"] = "value_one"
    global_settings["two"] = "value_two"
    config_data = ConfigData()
    config_data._global_settings = global_settings
    assert len(config_data.get_settings()) == len(global_settings)
    assert config_data.get_setting("one") == "value_one"


# Generated at 2022-06-22 19:22:14.000501
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # instantiate ConfigData
    config_data = ConfigData()

    # create a dummy setting
    from ansible.plugins.loader import setting_loader
    my_setting = setting_loader.get("basic_setting")
    my_setting.value = ("test_setting_value", "my comment")

    # create a dummy plugin
    from ansible.plugins.loader import plugin_loader
    my_plugin = plugin_loader.get("collection")
    my_plugin.name = "test_collection"

    # update the setting
    config_data.update_setting(my_setting, my_plugin)

    # check that the setting can be found in the ConfigData object
    assert(config_data.get_setting("basic_setting", my_plugin))

    # check that the setting's value can also be retrieved

# Generated at 2022-06-22 19:22:16.824021
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    plugin = AnsiblePlugin('lookup', 'bar')
    config_data = ConfigData()
    setting = ConfigSetting('foo', 'bar baz')
    config_data.update_setting(setting, plugin)
    settings = config_data.get_settings(plugin)
    assert setting in settings

# Generated at 2022-06-22 19:22:26.011697
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    def assert_ConfigData_get_setting(name, plugin):
        setting = config_data.get_setting(name, plugin)
        if plugin is None:
            assert setting.name == name and setting.plugin is None
        else:
            assert setting.name == name and setting.plugin == plugin

    from ansible_collections.community.general.plugins.module_utils.config import Setting
    Setting = Setting

    setting1 = Setting('s1')
    setting2 = Setting('s2')
    setting3 = Setting('s3')

    from ansible_collections.community.general.plugins.plugins import Plugin
    Plugin = Plugin

    plugin1 = Plugin('p1', 't1')
    plugin2 = Plugin('p2', 't2')


# Generated at 2022-06-22 19:22:34.824978
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

   
    config = ConfigData()
    # for the following tests, any setting of the plugin type will be used
    plugin = Plugin(
        type='some_type',
        name='some_name',
        path=None,
        python_version=[2, 7],
        priority=1000
    )

    setting = Setting(
        name='some_setting',
        namespace=None,
        version=2,
        value=None,
        origin=None,
        origin_type=None
    )

    assert config.get_setting('missing_global_setting') is None
    assert config.get_setting('missing_per_plugin_setting', plugin) is None

    config.update_setting(setting)
    assert config.get_setting('some_setting') == setting
    assert config.get_setting('some_setting', plugin) is None

# Generated at 2022-06-22 19:22:39.172136
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    foo = ConfigData()

    foo.update_setting(Setting(name="bar", plugin=Plugin(name="baz", type="test")))
    assert foo.get_setting(name="bar", plugin=Plugin(name="baz", type="test")).name == "bar"



# Generated at 2022-06-22 19:22:42.073902
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foobar') is None
    assert config_data.get_setting('foobar', plugin=None) is None


# Generated at 2022-06-22 19:22:47.860927
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {'foo': "bar"}

    assert config_data.get_settings() == [{'foo': "bar"}]

    config_data._plugins['connection'] = {'docker': {'foo': "baz"}}
    config_data._plugins['connection'] = {'local': {'foo': "baz"}}
    assert config_data.get_settings(plugin=Plugin(type='connection', name='local')) == [{'foo': "baz"}]

# Generated at 2022-06-22 19:22:57.511397
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Case 1
    assert config_data.get_setting('foo') is None

    # Case 2
    from ansible.plugins.loader import config_loader
    setting = config_loader.get('foo')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo').value is None

    # Clean up
    config_data._global_settings = {}

    # Case 3
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader('become', 'sudo')
    # Case 2
    setting = config_loader.get('sudo_pass', plugin)
    config_data.update_setting(setting)
    assert config_data.get_setting('sudo_pass', plugin).value is None

# Generated at 2022-06-22 19:23:06.811222
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()

    assert config.get_setting('action_plugins') is None
    assert config.get_setting('AN_INVALID_SETTING') is None

    assert config.get_setting('action_plugins', Plugin('invalid', 'invalid')) is None
    assert config.get_setting('AN_INVALID_SETTING', Plugin('invalid', 'invalid')) is None

    from ansible.plugins.loader import action_loader
    expected = Setting('action_plugins', action_loader)
    config.update_setting(expected)
    print("----> Config:")
    print(config)
    actual = config.get_setting('action_plugins')
    print("----> Actual:")
    print(actual)
    print("----> Expected:")
    print(expected)
    assert actual == expected

# Generated at 2022-06-22 19:23:16.848790
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Add some plugin settings
    config_data.update_setting(setting=Setting(name='setting1', value='setting1_value'))
    config_data.update_setting(setting=Setting(name='setting2', value='setting2_value', priority='highest'))
    config_data.update_setting(setting=Setting(name='setting3', value='setting3_value', priority='lowest'))

    # Add global setting
    config_data.update_setting(setting=Setting(name='global_setting', value='global_setting_value'))

    # Test global settings
    assert config_data.get_setting(name='global_setting') == \
        Setting(name='global_setting', value='global_setting_value')

# Generated at 2022-06-22 19:23:26.093041
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    s = Setting('foo', 'bar', 'baz')
    plugin = Plugin('foo', 'plugin', 'bar')
    c.update_setting(s, plugin)
    assert c.get_settings() == [s]
    assert c.get_settings(plugin) == [s]
    s = Setting('asdf', 'asdf', 'asdf')
    c.update_setting(s)
    assert c.get_settings() == [s]
    assert c.get_settings(plugin) == [s]
    plugin2 = Plugin('foo', 'plugin', 'bar2')
    assert c.get_settings(plugin2) == []

# Unit tests for method get_setting of class ConfigData

# Generated at 2022-06-22 19:23:29.201923
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data != None, 'Failed to create ConfigData instance.'


# Generated at 2022-06-22 19:23:32.166207
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert c._global_settings == {}
    assert c._plugins == {}


# Generated at 2022-06-22 19:23:43.232396
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Initialize test data
    config_data = ConfigData()
    test_plugins = [
        {'name': 'test_plugin_1', 'type': 'test_type_1', 'setting': {'setting_1': 'setting_1', 'setting_2': 'setting_2'}},
        {'name': 'test_plugin_2', 'type': 'test_type_1', 'setting': {'setting_3': 'setting_3', 'setting_4': 'setting_4'}},
        {'name': 'test_plugin_3', 'type': 'test_type_2', 'setting': {'setting_5': 'setting_5', 'setting_6': 'setting_6'}},
    ]


# Generated at 2022-06-22 19:23:45.349303
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    assert configData is not None

# Generated at 2022-06-22 19:23:51.795477
# Unit test for constructor of class ConfigData
def test_ConfigData():
    from ansible.cli.config import ConfigData
    from ansible.plugins.loader import find_plugins
    for plugin, obj in find_plugins('callback', 'plugins/callback'):
        print(dir(obj))
    data = ConfigData()
    assert data._global_settings == {}
    assert data._plugins == {}
#Unit test for get_setting method of class ConfigData

# Generated at 2022-06-22 19:24:04.418846
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
        config_data = ConfigData()
        config_data.update_setting(ConfigSetting("foo", "bar"))
        config_data.update_setting(ConfigSetting("foo2", "bar2"), Plugin("module"))
        config_data.update_setting(ConfigSetting("foo3", "bar3"), Plugin("module", "foo"))

        settings = config_data.get_settings()
        assert len(settings) == 1
        assert settings[0].name == "foo" and settings[0].value == "bar"

        settings = config_data.get_settings(Plugin("module"))
        assert len(settings) == 2
        assert settings[0].name == "foo2" and settings[0].value == "bar2"
        assert settings[1].name == "foo3" and settings[1].value == "bar3"


# Generated at 2022-06-22 19:24:06.209357
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("1")
    assert config_data.get_settings() == ["1"]



# Generated at 2022-06-22 19:24:11.126240
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    conf = ConfigData()
    assert conf.get_settings() == []

    conf.update_setting(ConfigSetting('test', 'value'))
    assert conf.get_settings()[0].name == 'test'


# Generated at 2022-06-22 19:24:12.206593
# Unit test for constructor of class ConfigData
def test_ConfigData():
    obj = ConfigData()
    assert obj is not None

# Generated at 2022-06-22 19:24:19.454797
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = 'aws'
    config_data._global_settings['aws_access_key'] = 'aws_access_key'
    assert 'aws_access_key' in config_data.get_settings()
    assert 'aws_access_key' not in config_data.get_settings(plugin)


# Generated at 2022-06-22 19:24:28.545005
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global_setting = {
        'default': None,
        'env': ['ANSIBLE_CONFIG', 'ANSIBLE_CONFIG_FILE'],
        'ini': ['?', 'config_file', 'CONFIG_FILE'],
        'name': 'config_file',
        'path': 'config',
        'plugin': 'core',
        'provider': None,
        'section': 'defaults',
        'type': 'path'
    }
    # Run method update_setting of class ConfigData
    config_manager = ConfigData()
    config_manager.update_setting(global_setting)
    # Test update_setting
    assert global_setting == config_manager.get_setting('config_file')


# Generated at 2022-06-22 19:24:29.317416
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-22 19:24:36.817699
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()

    from ansible.plugins import plugin_loader, SETUP_CACHE
    SETUP_CACHE['_all_'] = {}
    SETUP_CACHE['_all_']['become_methods'] = []
    SETUP_CACHE['_all_']['cache'] = {}
    SETUP_CACHE['_all_']['connection_plugins'] = {}
    SETUP_CACHE['_all_']['fact_cache_types'] = {}
    SETUP_CACHE['_all_']['inventory_plugins'] = {}
    SETUP_CACHE['_all_']['lookup_plugins'] = {}
    SETUP_CACHE['_all_']['module_utils'] = []

# Generated at 2022-06-22 19:24:45.569115
# Unit test for constructor of class ConfigData
def test_ConfigData():
    # test empty
    global_settings = {}
    plugins = {}
    config_data = ConfigData()
    assert config_data._global_settings == global_settings
    assert config_data._plugins == plugins

    # test base case
    global_settings = {
        'setting1': 'setting 1 global value',
        'setting2': 'setting 2 global value',
        'setting3': 'setting 3 global value'
    }

# Generated at 2022-06-22 19:24:54.127336
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    config_data.update_setting(setting=Setting('setting_global', 'global value'))
    config_data.update_setting(setting=Setting('setting_local_1', 'local value 1'), plugin=Plugin('my_plugin', 'my_type'))
    config_data.update_setting(setting=Setting('setting_local_2', 'local value 2'), plugin=Plugin('my_plugin', 'my_type'))
    config_data.update_setting(setting=Setting('setting_local_3', 'local value 3'), plugin=Plugin('my_plugin', 'my_type'))

    assert config_data.get_settings()[0].name == 'setting_global'
    assert config_data.get_settings()[0].value == 'global value'

    assert config_data.get_settings

# Generated at 2022-06-22 19:25:00.773168
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    setting_1 = Setting(name='Setting 1', value='test', origin='test', prepared=False)
    setting_2 = Setting(name='Setting 2', value='test 2', origin='test 2', prepared=False)

    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2)

    assert config_data.get_setting('Setting 1') == setting_1
    assert config_data.get_setting('setting 2') == setting_2
    assert config_data.get_setting('setting 3') is None



# Generated at 2022-06-22 19:25:03.692581
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    setting = ConfigSetting('setting_1', 'setting 1', True)
    configData.update_setting(setting)
    assert configData.get_setting('setting_1') is setting


# Generated at 2022-06-22 19:25:05.993382
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-22 19:25:07.671870
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') == None


# Generated at 2022-06-22 19:25:12.206108
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data.get_settings() == []
    assert config_data.get_settings('foobar') == []

    assert config_data.get_setting(name='foobar') is None
    assert config_data.get_setting(name='foobar', plugin=None) is None
    assert config_data.get_setting(name='foobar', plugin='foobar') is None

# Generated at 2022-06-22 19:25:14.958531
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_data = ConfigData()
    assert len(test_data.get_settings()) == 0


# Generated at 2022-06-22 19:25:21.685188
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = MyPlugin()
    setting = MySetting()
    config_data.update_setting(setting, plugin)
    assert(len(config_data.get_settings()) == 1)
    assert(len(config_data.get_settings(plugin)) == 1)
    assert(config_data.get_setting('not_existing') is None)
    assert(config_data.get_setting('not_existing', plugin) is None)

if __name__ == "__main__":
    test_ConfigData_get_settings()

# Generated at 2022-06-22 19:25:23.889941
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()


# Generated at 2022-06-22 19:25:30.526554
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    ansible_dir = dict(type='ansible_dir', name='ansible', path='./')
    setting = dict(name='configuration_file', value='ansible.cfg')
    config_data.update_setting(setting, ansible_dir)
    assert config_data.get_setting('configuration_file').name == 'configuration_file'
    assert config_data.get_setting('configuration_file').value == 'ansible.cfg'

# Generated at 2022-06-22 19:25:32.104141
# Unit test for constructor of class ConfigData
def test_ConfigData():
    obj = ConfigData()
    assert isinstance(obj, ConfigData)

# Generated at 2022-06-22 19:25:37.727267
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting(ConfigSetting(name="global_setting", value="global_value"))
    config_data.update_setting(ConfigSetting(name="another_global_setting", value="another_global_value"))
    config_data.update_setting(ConfigSetting(name="setting", value="value"),
                               plugin=ConfigPlugin(type="modules", name="shell", version=None))
    config_data.update_setting(ConfigSetting(name="another_setting", value="another_value"),
                               plugin=ConfigPlugin(type="modules", name="shell", version=None))
    config_data.update_setting(ConfigSetting(name="one_more_setting", value="one_more_value"),
                               plugin=ConfigPlugin(type="connection", name="local", version=None))

   

# Generated at 2022-06-22 19:25:47.930527
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='foo'))
    assert len(config_data.get_settings()) == 1
    config_data.update_setting(Setting(name='bar'))
    assert len(config_data.get_settings()) == 2

    plugin = PluginType('action', 'test')
    config_data.update_setting(Setting(name='test_setting'), plugin)
    assert len(config_data.get_settings()) == 3
    assert len(config_data.get_settings(plugin)) == 1

    # Test for setting already exists
    config_data.update_setting(Setting(name='test_seting', value='test_value'), plugin)
    assert len(config_data.get_settings()) == 3

# Generated at 2022-06-22 19:26:00.030161
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from collections import namedtuple

    # three types of setting: global, with plugin type and with plugin type and plugin name
    PluginSetting = namedtuple('PluginSetting', ['name'])
    PluginTypeSetting = namedtuple('PluginTypeSetting', ['name', 'type'])
    PluginAndTypeSetting = namedtuple('PluginAndTypeSetting', ['name', 'type', 'plugin_name'])

    config_data = ConfigData()
    global_setting = PluginSetting(name='core')
    config_data.update_setting(global_setting)

    plugin_type_setting_1 = PluginTypeSetting(name='core', type='connection')
    config_data.update_setting(plugin_type_setting_1)

    plugin_type_setting_2 = PluginTypeSetting(name='core', type='cache')
    config_data.update_setting

# Generated at 2022-06-22 19:26:02.811140
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-22 19:26:05.652092
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert not data._global_settings, "Test should return empty global settings"
    assert not data._plugins, "Test should return empty plugins"


# Generated at 2022-06-22 19:26:14.992620
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    # Test 2: Plugin name is null
    assert cd.get_settings() == []

    from ansible.cli.arguments import CLIFactory

    plugin_name = "name"
    plugin_type = "type"
    ansible_setting = CLIFactory.setting(plugin_name, plugin_type)
    ansible_setting.name = "name"
    ansible_setting.default = "default"
    ansible_setting.description = "description"
    ansible_setting.cli = ["cli"]
    ansible_setting.ini = ["ini"]
    ansible_setting.env = ["env"]
    assert cd.get_settings() == []

    # Test 3: Plugin name is not null
    cd.update_setting(ansible_setting, ansible_setting)
    assert cd.get_

# Generated at 2022-06-22 19:26:22.646965
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()

    #global setting

    config.update_setting(Setting(name='deprecation_warnings', value=True))

    assert config.get_setting('deprecation_warnings')
    assert not config.get_setting('deprecation_warnings', plugin=AclPlugin(name='acl'))
    assert config.get_setting('deprecation_warnings', plugin=None)

    assert len(config.get_settings()) == 1
    assert len(config.get_settings(None)) == 1
    assert len(config.get_settings(AclPlugin(name='acl'))) == 0

    # plugin setting

    config.update_setting(Setting(name='enabled', value=False), plugin=AclPlugin(name='acl'))

    assert not config.get_setting('enabled')
    assert not config

# Generated at 2022-06-22 19:26:23.645165
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()


# Generated at 2022-06-22 19:26:26.534474
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data._global_settings == {}
    assert data._plugins == {}


# Generated at 2022-06-22 19:26:35.749970
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cfg_data = ConfigData()
    cfg_data.update_setting(ConfigDataSetting('name1', 'global'))
    cfg_data.update_setting(ConfigDataSetting('name2', 'plugin1'))
    cfg_data.update_setting(ConfigDataSetting('name3', 'plugin2'))

    k1 = cfg_data.get_setting('name1')
    assert k1.value == 'global'

    k2 = cfg_data.get_setting('name2', ConfigDataPlugin('type1', 'plugin1'))
    assert k2.value == 'plugin1'

    k3 = cfg_data.get_setting('name3', ConfigDataPlugin('type1', 'plugin2'))
    assert k3.value == 'plugin2'
    pass



# Generated at 2022-06-22 19:26:38.546215
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(ConfigSetting('foo', 'bar', 'global'))
    assert config.get_setting('foo').value == 'bar'

# Generated at 2022-06-22 19:26:47.540951
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Test case 1:
    # Test for global settings
    test_data = ConfigData()
    setting1 = ConfigSetting(name="foo", value="bar")
    setting2 = ConfigSetting(name="baz", value="qux")
    test_data.update_setting(setting1)
    test_data.update_setting(setting2)

    settings = test_data.get_settings()
    assert len(settings) == 2
    assert setting1 in settings
    assert setting2 in settings

    # Test case 2:
    # Test for plugin settings
    plugin = ConfigPlugin(name="test_plugin", path="/test_path", type="test_type")
    setting3 = ConfigSetting(name="test", value="value")
    test_data.update_setting(setting3, plugin)

    settings = test_data.get_settings()

# Generated at 2022-06-22 19:26:49.583778
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() is not None

# Generated at 2022-06-22 19:26:56.428161
# Unit test for constructor of class ConfigData
def test_ConfigData():
    plugin_type = 'test_plugin'
    plugin_name = 'test_plugin'
    setting_name = 'test_setting'
    plugin = '{0}.{1}'.format(plugin_type, plugin_name)
    not_used_setting_name = 'not_used_setting'
    setting = (setting_name, plugin)
    not_used_setting = (not_used_setting_name, plugin)
    config_data = ConfigData()
    assert config_data.get_setting(setting_name) is None
    assert len(config_data.get_settings()) == 0
    config_data.update_setting(setting)
    assert config_data.get_setting(setting_name) is not None
    assert len(config_data.get_settings()) == 1

# Generated at 2022-06-22 19:26:58.408466
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert isinstance(data, ConfigData) == True


# Generated at 2022-06-22 19:27:04.235677
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    c = ConfigData()
    for i in range(10):
        c.update_setting(Setting(name='setting' + str(i), value='value' + str(i)))
    for i in range(10):
        assert c.get_setting('setting' + str(i)).value == 'value' + str(i)
    assert c.get_setting('setting20') == None


# Generated at 2022-06-22 19:27:09.396866
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert(data.get_setting("setting1") is None)
    assert(data.get_setting("setting2") is None)
    assert(data.get_settings() == [])
    data.update_setting("setting1","setting2")
    assert(data.get_setting("setting1") == "setting1")
    assert(data.get_setting("setting2") == "setting2")
    assert(data.get_settings() == ["setting1", "setting2"])

# Generated at 2022-06-22 19:27:15.984898
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cdata = ConfigData()
    cdata.update_setting(ConfigSetting('foo', '', 'bar', False, False, False, True, 'string', '', '', '', ''))
    cdata.update_setting(ConfigSetting('baz', '', 'bar', False, False, False, True, 'string', '', '', '', ''))
    assert(len(cdata.get_settings()) == 2)

# Generated at 2022-06-22 19:27:27.220199
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.plugins.loader import PluginLoader
    import pytest

    config_data = ConfigData()
    for plugin_type in PluginLoader._get_all_plugin_loaders():
        for plugin in plugin_type.all():
            for setting in plugin.config_options:
                config_data.update_setting(setting, plugin)
                settings = config_data.get_settings(plugin)
                assert len(settings) > 0

            global_settings = config_data.get_settings()
            assert len(global_settings) > 0
            assert len(global_settings) == len(config_data._global_settings)

    # Test that get_settings also works when we give a tuple of plugin type and name instead of object
    # to the function

# Generated at 2022-06-22 19:27:35.416721
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from units.compat.mock import patch
    from ansible.plugins.loader import setting_loader

    # Example source file
    source_file = '/absolute/path/to/test.yaml'

    # Example plugin
    example_plugin_name = 'test'

    # Global settings dictionary
    global_settings = {
        "B_BOOL": {
            'type': 'bool',
            'default': False,
            'description': 'A dummy boolean'
        },
        "A_BOOL": {
            'type': 'bool',
            'default': True,
            'description': 'A dummy boolean'
        }
    }

    # Plugin settings dictionary

# Generated at 2022-06-22 19:27:37.710183
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert len(config._global_settings) == 0
    assert len(config._plugins) == 0


# Generated at 2022-06-22 19:27:42.112049
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()
    setting = Setting(name='host_key_checking', value='False',
                      origin='/etc/ansible/ansible.cfg:1')
    configdata.update_setting(setting)
    assert configdata.get_setting('host_key_checking') == setting


# Generated at 2022-06-22 19:27:48.162884
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('C', 'foo'))
    config_data.update_setting(Setting('B', 'bar'))
    config_data.update_setting(Setting('A', 'baz'))
    assert config_data.get_setting('B') is not None
    assert config_data.get_setting('A').value == 'baz'
    assert config_data.get_setting('B').value == 'bar'

# Generated at 2022-06-22 19:27:58.355865
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    config_data.update_setting(Setting('test_setting2', 'test_value2'), Plugin(PluginType.SHELL, 'shell_plugin'))
    assert config_data.get_setting('test_setting').value == 'test_value'
    assert config_data.get_setting('test_setting2').value == 'test_value2'

    config_data.update_setting(Setting('test_setting2', 'test_value3'), Plugin(PluginType.SHELL, 'shell_plugin'))
    assert config_data.get_setting('test_setting2', Plugin(PluginType.SHELL, 'shell_plugin')).value == 'test_value3'


# Generated at 2022-06-22 19:28:03.688388
# Unit test for constructor of class ConfigData
def test_ConfigData():
    my_config_data = ConfigData()
    global_settings = my_config_data.get_settings()
    print(len(global_settings))

if __name__ == "__main__":
    test_ConfigData()

# Generated at 2022-06-22 19:28:06.131431
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data
    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-22 19:28:13.764110
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("name1", "value1"))
    config_data.update_setting(Setting("name2", "value2"))
    config_data.update_setting(Setting("name3", "value3"))
    config_data.update_setting(Setting("name4", "value4"), Plugin("module", "module1"))
    config_data.update_setting(Setting("name5", "value5"), Plugin("module", "module1"))
    config_data.update_setting(Setting("name6", "value6"), Plugin("module", "module1"))

    assert len(config_data._global_settings) == 3
    assert len(config_data._plugins) == 1
    assert len(config_data._plugins["module"]) == 1

# Generated at 2022-06-22 19:28:24.480522
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """
    Method to test the update_setting method of ConfigData class
    """
    config_data = ConfigData()

# Generated at 2022-06-22 19:28:32.962330
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting_1 = {'name': 'test_1', 'value': 'True', 'origin': 'file', 'changed': False}
    setting_2 = {'name': 'test_2', 'value': 'False', 'origin': 'file', 'changed': False}
    setting_3 = {'name': 'test_3', 'value': 'True', 'origin': 'file', 'changed': False}
    plugin_1 = {'type': 'Module', 'name': 'test_plugin_1'}
    plugin_2 = {'type': 'Module', 'name': 'test_plugin_2'}
    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2)

# Generated at 2022-06-22 19:28:38.149023
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()

    setting = {
        'name': 'setting1',
        'section': 'section_name',
        'key': 'key_name',
        'default': 'default_value',
        'value': 'value_set',
        'plugin': None
    }

    config.update_setting(setting)

    assert config.get_settings() == [setting]



# Generated at 2022-06-22 19:28:41.870671
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-22 19:28:47.541730
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {
        "name": "hash_behaviour",
        "value": "merge"
    }
    config_data.update_setting(setting)
    assert config_data._global_settings["hash_behaviour"].value == setting["value"]


# Generated at 2022-06-22 19:28:53.896271
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    settings_to_add = []
    for i in range(2):
        for setting_type in ['string', 'int', 'bool']:
            setting = Setting(str(i), 'global', setting_type)
            settings_to_add.append(setting)
    settings_to_add.append(Setting('1', 'connection', 'string'))
    settings_to_add.append(Setting('2', 'connection', 'string'))
    settings_to_add.append(Setting('1', 'shell', 'string'))
    for setting in settings_to_add:
        config_data.update_setting(setting)

    assert config_data.get_setting('1') == settings_to_add[0]
    assert config_data.get_setting('2') == settings_to_add

# Generated at 2022-06-22 19:28:59.796383
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # define ConfigData object
    config = ConfigData()
    # create the setting
    import inspect
    from library.configdata.setting import Setting
    setting = Setting('scenario', 'required', 'str', 'Scenario used', 'scenario.yml', 
                      'scenario', inspect.getfile(Setting), name='Scenario')
    # update setting
    config.update_setting(setting)
    # get the setting
    config.get_setting(setting.name)
    # test if setting is defined
    assert setting in config.get_settings()

# Generated at 2022-06-22 19:29:09.519923
# Unit test for constructor of class ConfigData
def test_ConfigData():

    c = ConfigData()

    # set global setting [gsetting] to true
    c.update_setting(ConfigSetting('gsetting', True))
    # set setting [setting] to true for local plugin [module_utils]
    c.update_setting(ConfigSetting('setting', True), Plugin(Plugin.type_module_utils, 'module_utils'))

    # verify that
    # - global setting [gsetting] is set to true
    assert c.get_setting('gsetting').value
    # - local setting [setting] for local plugin [module_utils] is set to true
    assert c.get_setting('setting', Plugin(Plugin.type_module_utils, 'module_utils')).value



# Generated at 2022-06-22 19:29:20.361020
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert len(cd._global_settings) == 0
    assert len(cd._plugins) == 0
    cd.update_setting(Setting('constant', 'default'))
    assert len(cd._global_settings) == 1
    assert 'constant' in cd._global_settings
    assert cd._global_settings['constant'].name == 'constant'
    assert cd._global_settings['constant'].value == 'default'
    assert len(cd._plugins) == 0
    cd.update_setting(Setting('pi', '3.14159'), Plugin('facts', 'system'))
    assert len(cd._global_settings) == 1
    assert 'constant' in cd._global_settings
    assert 'pi' not in cd._global_settings
    assert len(cd._plugins) == 1
   

# Generated at 2022-06-22 19:29:21.962778
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}


# Generated at 2022-06-22 19:29:24.421429
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    settings = cd.get_settings()
    assert settings == []

    settings = cd.get_settings('test')
    assert settings == []

# Generated at 2022-06-22 19:29:33.025683
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # create config object
    config_data = ConfigData()

    # create plugin object
    plugin_type = 'module_utils'
    plugin_name = 'test_module_utils'
    plugin = Plugin(plugin_type, plugin_name)

    # create test_setting_1 and update it in config_data as global setting
    test_setting_1 = Setting('setting_1', 'setting_1_value')
    config_data.update_setting(test_setting_1)

    # create test_setting_2 and update it in config_data as plugin setting
    test_setting_2 = Setting('setting_2', 'test_setting_2_value')
    config_data.update_setting(test_setting_2, plugin)

    # create test_setting_3 and update it in config_data as plugin setting
    test_setting_

# Generated at 2022-06-22 19:29:33.729228
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData()

# Generated at 2022-06-22 19:29:42.972168
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    # Test with plugin data
    plugin = Plugin()
    plugin.name = 'test name'
    plugin.type = 'test type'
    setting = PluginSetting(plugin, 'test name', 42)
    config_data.update_setting(setting, plugin)
    settings = config_data.get_settings(plugin)
    assert settings[0].value == setting.value

    # Test without plugin data
    setting = PluginSetting(None, 'test name')
    config_data.update_setting(setting)
    settings = config_data.get_settings()
    assert settings[0].value == setting.value

    # Test with invalid plugin
    plugin = Plugin()
    plugin.name = 'test name'
    plugin.type = 'invalid type'

# Generated at 2022-06-22 19:29:49.281459
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    c = ConfigData()
    a = Setting()
    a.name = "aaa"
    b = Setting()
    b.name = "bbb"
    c.update_setting(a)
    c.update_setting(b)
    d = c.get_setting("aaa")
    assert d.name == 'aaa'
    assert c.get_setting("ccc") is None


# Generated at 2022-06-22 19:29:50.515206
# Unit test for constructor of class ConfigData
def test_ConfigData():

    configData = ConfigData()
    assert configData


# Generated at 2022-06-22 19:29:53.733682
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("setting1", "foo"))
    assert config_data.get_setting("setting1") == Setting("setting1", "foo")


# Generated at 2022-06-22 19:30:02.369632
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()

    setting_1 = Setting(name="setting_1", module_name="module_1", module_path="path_1")
    setting_2 = Setting(name="setting_2", module_name="module_2", module_path="path_2")
    configData.update_setting(setting_1)
    configData.update_setting(setting_2, plugin=Plugin("mytype", "myname"))

    assert(configData.get_setting("setting_1").module_name == "module_1")
    assert(configData.get_setting("setting_2", Plugin("mytype", "myname")).module_path == "path_2")


# Generated at 2022-06-22 19:30:07.666974
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.ansible_release import __version__
    from ansible.plugins.loader import find_plugin
    from ansible.constants import PLUGIN_PATH_CACHE
    from ansible.module_utils.common._collections_compat import Mapping

    config = ConfigData()
    plugin = find_plugin(name='runme', mod_type='shell', dirs=PLUGIN_PATH_CACHE)

    # test global setting
    setting = config.get_setting('ANSIBLE_CONFIG', None)
    assert isinstance(setting, Mapping)
    assert setting['name'] == 'ANSIBLE_CONFIG'
    assert setting['type'] == 'path'
    assert setting['display_in_shell'] is True
    assert setting['default_value'] == ''