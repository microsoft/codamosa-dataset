

# Generated at 2022-06-10 22:40:33.625205
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    ConfigData.__init__(self)
    ConfigData.update_setting(self,setting,plugin=None)
    ConfigData.update_setting(self,setting,plugin=None)


# Generated at 2022-06-10 22:40:37.213691
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    setting = Setting(name="test", value=True)
    config.update_setting(setting)
    assert config.get_setting("test") is not None


# Generated at 2022-06-10 22:40:41.803266
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    assert isinstance(data, ConfigData)

    setting = Setting(name='foo')
    assert isinstance(setting, Setting)

    data.update_setting(setting)
    s = data.get_setting('foo')
    assert s.name == 'foo'


# Generated at 2022-06-10 22:40:48.441280
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    setting = ConfigSetting(name='gbl1', value=True)
    config_data.update_setting(setting)
    assert config_data.get_setting(name='gbl1') == setting

    setting = ConfigSetting(name='xyz1', value=1)
    config_data.update_setting(setting, plugin=ConfigPlugin(type='abc', name='xyz'))
    assert config_data.get_setting(name='xyz1', plugin=ConfigPlugin(type='abc', name='xyz')) == setting


# Generated at 2022-06-10 22:40:58.961425
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()

    # Test adding a global setting
    name = 'foo'
    value = 'bar'
    plugin = None
    setting = Setting(name, value)
    cd.update_setting(setting, plugin=plugin)

    assert cd.get_setting('foo') == setting

    # Test adding a new setting to a plugin
    name = 'bar'
    value = 'baz'
    plugin = Plugin('test', 'test', 'test')
    setting = Setting(name, value)
    cd.update_setting(setting, plugin=plugin)

    assert cd.get_setting('bar', plugin) == setting

    # Test adding another setting to the same plugin
    name = 'foobar'
    value = 'bazfoo'
    setting = Setting(name, value)

# Generated at 2022-06-10 22:41:07.029792
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    pluginA = Plugin("lookup", "File")
    pluginB = Plugin("action", "Pause")
    pluginC = Plugin("action", "Pause")

    settingA1 = Setting("cfg_plugin_dir", "/usr/share/ansible/plugins")
    settingC1 = Setting("cfg_plugin_dir", "/usr/share/ansible/plugins/action")
    settingC2 = Setting("timeout", "30")

    config_data.update_setting(settingA1)
    config_data.update_setting(settingC1, pluginC)
    config_data.update_setting(settingC2, pluginC)

    # test: no plugin
    settings = config_data.get_settings()
    assert(len(settings) == 1)
    assert(settings[0] == settingA1)

# Generated at 2022-06-10 22:41:11.703832
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    setting_value = 'setting_value'
    setting_name = 'setting_name'
    cs = Setting(setting_name, setting_value)

    cd.update_setting(cs,None)

    assert(cd._global_settings['setting_name'] == cs)


# Generated at 2022-06-10 22:41:22.888065
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()

    i = Setting(name='foo', defval=5, desc='some setting', plugin=Plugin('baz', 'foo'))
    cd.update_setting(i)
    assert cd.get_setting('foo', Plugin('baz', 'foo')) == i
    assert cd.get_setting('foo') == None

    i = Setting(name='foo', defval=5, desc='some setting', plugin=Plugin('baz', 'foo'))
    cd.update_setting(i)
    assert cd.get_setting('foo', Plugin('baz', 'foo')) == i
    assert cd.get_setting('foo') == None

    i = Setting(name='bar', defval=5, desc='some setting', plugin=Plugin('baz', 'foo'))
    cd.update_setting(i)

# Generated at 2022-06-10 22:41:27.261731
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    Config_data = ConfigData()
    Config_data.update_setting(Setting('test_setting1', 'test_plugin1', 'test_plugin_type1','test_value'))
    assert Config_data.get_setting('test_setting1') == Setting('test_setting1', None,'None','test_value')

# Generated at 2022-06-10 22:41:34.887680
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    config_data.update_setting(Setting('ANSIBLE_STRICT', 'Strict mode', 'str', 'bool', {'yes', 'no', 'y', 'n'},
                                        'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', None, None,
                                        'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', None, None,
                                        'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', None, None,
                                        'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', None, None, None))

# Generated at 2022-06-10 22:41:38.907124
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []



# Generated at 2022-06-10 22:41:50.064712
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import collections
    from ansible.plugins.loader import PluginLoader

    config = ConfigData()

    # Test update_setting for global configuration
    assert not config.get_setting('something')
    assert len(config.get_settings()) == 0
    assert len(config._global_settings) == 0

    config.update_setting(Setting(name = 'something', value = 'value'))

    assert config.get_setting('something')
    assert len(config.get_settings()) == 1
    assert len(config._global_settings) == 1
    assert 'something' in config._global_settings
    assert config._global_settings['something'].value == 'value'

    # Test update_setting for plugin configuration
    assert not config.get_setting('something', plugin = PluginLoader('lookup').get('dig'))
    assert not config._plugins

# Generated at 2022-06-10 22:41:52.672953
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_instance = ConfigData()
    test_instance.update_setting(setting=None, plugin=None)
    assert test_instance._global_settings == {}
    assert test_instance._plugins == {}


# Generated at 2022-06-10 22:41:58.059630
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}
    config_data.update_setting(Setting(name='display_skipped_hosts', value="False"))
    pass_test = True
    if config_data._global_settings.get('display_skipped_hosts').name != "display_skipped_hosts" or \
        config_data._global_settings.get('display_skipped_hosts').value != "False":
        pass_test = False
    assert pass_test
    config_data.update_setting(Setting(name='display_skipped_hosts', value="True"), Plugin(type='gauge', name='tty'))
    pass_test = True

# Generated at 2022-06-10 22:42:07.437827
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Test 1: Test ConfigData.get_setting when there are no settings
    config_data = ConfigData()
    print("Test 1: Test ConfigData.get_setting when there are no settings")
    if config_data.get_settings() == []:
        print("Test 1: PASSED")
    else:
        print("Test 1: FAILED")
    # Test 2: Test ConfigData.get_setting when get_setting is called without plugin parameter
    # with settings for a plugin
    config_data = ConfigData()
    print("Test 2: Test ConfigData.get_setting when get_setting is called without plugin parameter with settings for a plugin")
    config_data.update_setting(Setting("foo", "bar", "baz", "qux"))

# Generated at 2022-06-10 22:42:17.008651
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    import types
    class Plugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name
        def __repr__(self):
            return 'Plugin(type=%s, name=%s)' % (self.type, self.name)

    class Setting:
        def __init__(self, name, value, plugin=None):
            self.name = name
            self.value = value
            self.plugin = plugin
        def __repr__(self):
            return 'Setting(name=%s, value=%s, plugin=%s)' % (self.name, self.value, self.plugin)

    config_data = ConfigData()


# Generated at 2022-06-10 22:42:28.178118
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    assert len(cd.get_settings()) == 0
    assert len(cd.get_settings(Plugin())) == 0
    assert len(cd.get_settings(Plugin(type="action"))) == 0
    assert len(cd.get_settings(Plugin(type="action", name="pause"))) == 0
    assert len(cd.get_settings(Plugin(type="invalid", name="invalid"))) == 0
    assert len(cd.get_settings()) == 0

    cd._global_settings = {'key': 'val'}
    assert len(cd.get_settings()) == 1
    assert len(cd.get_settings(Plugin())) == 1
    assert len(cd.get_settings(Plugin(type="action"))) == 1

# Generated at 2022-06-10 22:42:40.351488
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Create dummy config data
    conf = ConfigData()
    conf.update_setting(Setting("verbosity", "4"))
    conf.update_setting(Setting("connection", "network_cli"))
    conf.update_setting(Setting("remote_user", "root"))
    conf.update_setting(Setting("timeout", "60"))
    conf.update_setting(Setting("host_key_checking", "False"))
    conf.update_setting(Setting("gathering", "implicit"))
    conf.update_setting(Setting("pipelining", "True"))

    # Testing global scope
    verbosity = conf.get_setting("verbosity")
    assert verbosity.name == "verbosity"
    assert verbosity.value == "4"
    assert verbosity.plugin is None
    assert verbosity.cache is False
    assert verbosity.parent

# Generated at 2022-06-10 22:42:52.521040
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    configData = ConfigData()

    # test case 1: plugin is None and setting is not in the list
    assert configData.get_setting('non-existing-key') == None

    # test case 2: plugin is None and setting is in the list
    from ansible.galaxy.models.setting import Setting
    setting = Setting(name='one')
    configData.update_setting(setting)
    assert configData.get_setting('one') == setting

    # test case 3: plugin is not None and setting is not in the list
    from ansible.galaxy.models.plugin import Plugin
    plugin = Plugin(type='galaxy', name='ansible.galaxy')
    assert configData.get_setting(name='non-existing-key', plugin=plugin) == None

    # test case 4: plugin is not None and setting is in the list

# Generated at 2022-06-10 22:42:53.655981
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    assert True

# Generated at 2022-06-10 22:42:59.563987
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    setting = config.Option(name="greeting", value="hello")

    config_data.update_setting(setting)

    assert(config_data.get_setting("greeting") == setting)


# Generated at 2022-06-10 22:43:09.373354
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert config.get_setting('_ansible_check_mode') is None
    assert config.get_setting('_ansible_check_mode', 'host') is None

    config.update_setting({'name': '_ansible_check_mode', 'value': True})
    assert config.get_setting('_ansible_check_mode') is True
    assert config.get_setting('_ansible_check_mode', 'host') is None

    config.update_setting({'name': '_ansible_check_mode', 'value': True}, 'host')
    assert config.get_setting('_ansible_check_mode') is True
    assert config.get_setting('_ansible_check_mode', 'host') is True


# Generated at 2022-06-10 22:43:15.072345
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    plugin = PluginInfo('lookup', 'file', '/path/to/file')
    setting = ConfigSetting(name='base_dir', value='/path/to/dir', plugin=plugin)
    config_data.update_setting(setting, plugin)

    assert config_data.get_setting('base_dir', plugin) is setting

# Generated at 2022-06-10 22:43:25.448305
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    data = ConfigData()

    # Test 1
    setting = data.get_setting('s1')
    assert setting is None

    # Test 2
    data.update_setting(ConfigSetting('s1', 'global', 'global', 'global', 'global', 'global', 'global'))
    setting = data.get_setting('s1')
    assert setting.name == 's1'
    assert setting.plugin_type == 'global'
    assert setting.plugin_name == 'global'
    assert setting.value == 'global'
    assert setting.default == 'global'
    assert setting.description == 'global'
    assert setting.category == 'global'

    # Test 3
    setting = data.get_setting('s2')
    assert setting is None

    # Test 4

# Generated at 2022-06-10 22:43:30.396349
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting(name="max_children", value="100", plugin=Plugin(type="", name="")))

    assert config_data._global_settings["max_children"].name == "max_children"

# Generated at 2022-06-10 22:43:41.711115
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    global_settings = {}
    for i in range(8):
        name = "Global (%d)" % i
        global_settings[name] = ConfigSetting(name, "This is a global setting #%d" % i)
        config.update_setting(global_settings[name])

    settings = config.get_settings()
    assert len(settings) == len(global_settings)
    for setting in settings:
        assert setting.name in global_settings
        assert setting == global_settings[setting.name]

    try:
        searched_setting = ConfigSetting("Global (-1)", "")
        config.update_setting(searched_setting)
    except:
        pass

    settings = config.get_settings()
    assert len(settings) == len(global_settings)

# Generated at 2022-06-10 22:43:45.406200
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.module_utils.config_data import ConfigData
    from ansible.module_utils.config_data import ConfigSetting

    ConfigData.update_setting(ConfigSetting("setting1","value1"));



# Generated at 2022-06-10 22:43:54.797337
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Setting up required objects
    config_data = ConfigData()
    setting = Setting('test', {'foo': 'bar'})

    # Test plugin is set to None
    assert config_data.get_setting('test') is None

    # Test non existing plugin
    assert config_data.get_setting('test', Plugin('test', 'non_existing')) is None

    # Test non existing plugin type when plugin is not None
    assert config_data.get_setting('test', Plugin('non_existing', 'test')) is None

    # Test non existing setting
    assert config_data.get_setting('test', Plugin('test', 'test')) is None

    # Creating the plugin type
    config_data.update_setting(setting, Plugin('test', 'test'))

# Generated at 2022-06-10 22:44:00.161506
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()

    setting1 = Setting('one')
    configData.update_setting(setting1)
    assert setting1 == configData.get_setting('one')

    setting2 = Setting('one')
    plugin = Plugin('Module', 'test')
    configData.update_setting(setting2, plugin)
    assert setting2 != configData.get_setting('one')
    assert setting2 == configData.get_setting('one', plugin)

# Generated at 2022-06-10 22:44:08.851343
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cs1 = ConfigSetting()
    cs1.name = "ansible_connection"
    cs1.value = "network_cli"
    cd.update_setting(cs1)
    cs2 = ConfigSetting()
    cs2.name = "ansible_network_os"
    cs2.value = "ios"
    cd.update_setting(cs2, Plugin('connection', 'network_cli'))
    cd.update_setting(cs2, Plugin('network_os', 'ios'))


# Generated at 2022-06-10 22:44:15.417599
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    s1 = Setting(name='test')
    s2 = Setting(name='test2')
    cd.update_setting(s1)
    cd.update_setting(s2)
    expected = [s1, s2,]
    actual = cd.get_settings()
    assert actual == expected


# Generated at 2022-06-10 22:44:29.381342
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    default_plugin_type = 'unknown'
    default_plugin_name = 'unknown'
    default_setting_name = 'unknown'
    default_setting_value = 'unknown'
    default_setting_priority = 100
    default_setting = Setting(default_setting_name, default_setting_value, default_setting_priority)
    config_data.update_setting(default_setting)
    assert config_data.get_settings() == [default_setting]
    assert config_data.get_settings(Plugin(default_plugin_type, default_plugin_name)) == []

    plugin_type = 'connection'
    plugin_name = 'local'
    setting_name = 'lots'
    setting_value = 'of'
    setting_priority = 50

# Generated at 2022-06-10 22:44:35.107074
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('key', 'value')
    plugin = Plugin('module', 'path', 'args')
    print(config_data.get_settings())
    config_data.update_setting(setting, plugin)
    print(config_data.get_settings())
    print(config_data.get_settings(plugin))
    setting = Setting('key', 'value1')
    config_data.update_setting(setting, plugin)
    print(config_data.get_settings())
    print(config_data.get_settings(plugin))

if __name__ == '__main__':
    test_ConfigData_update_setting()

# Generated at 2022-06-10 22:44:47.957753
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings_dict = {'a': 1, 'b': 2, 'c': 3}
    settings_list = []
    for k in settings_dict:
        settings_list.append(k)

    settings = ConfigData().get_settings()
    assert settings == []

    settings = ConfigData().get_settings(plugin=None)
    assert settings == []

    settings = ConfigData().get_settings(plugin='a')
    assert settings == []

    config_data = ConfigData()
    settings = config_data.get_settings(plugin=None)
    assert settings == []

    for k in settings_dict:
        config_data.update_setting(k, plugin=None)
    settings = config_data.get_settings(plugin=None)
    assert settings == settings_list

    for k in settings_dict:
        config_

# Generated at 2022-06-10 22:44:48.622630
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    pass

# Generated at 2022-06-10 22:44:58.469803
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin1 = Plugin('type1', 'name1')
    setting1 = Setting(plugin1, 'name1', 'value1')
    config_data.update_setting(setting1, plugin1)
    print(config_data._plugins)
    plugin2 = Plugin('type1', 'name2')
    setting2 = Setting(plugin2, 'name2', 'value2')
    config_data.update_setting(setting2)
    print(config_data._global_settings)
    plugin3 = Plugin('type2', 'name3')
    setting3 = Setting(plugin3, 'name3', 'value3')
    config_data.update_setting(setting3, plugin3)
    print(config_data._plugins)

test_ConfigData_update_setting()

# Generated at 2022-06-10 22:45:08.687325
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_settings = [
        setting('a'),
        setting('b', 'c'),
        setting('d', 'e', 'f'),
    ]
    config_data = ConfigData()
    for test_setting in test_settings:
        config_data.update_setting(test_setting)

    plugin_a = Plugin('a', 'test')
    plugin_b = Plugin('b', 'test', 'test2')

    assert_equal(config_data.get_settings(), test_settings)
    assert_equal(config_data.get_settings(plugin_a), [test_settings[0]])
    assert_equal(config_data.get_settings(plugin_b), [test_settings[1]])


# Generated at 2022-06-10 22:45:10.871510
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()
    assert configdata._global_settings == {}
    assert configdata._plugins == {}


# Generated at 2022-06-10 22:45:13.673024
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    assert cd.get_setting(setting_name="setting1") is None


# Generated at 2022-06-10 22:45:14.287701
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass

# Generated at 2022-06-10 22:45:31.222750
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

# Generated at 2022-06-10 22:45:36.985081
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()

    # Arrange
    setting = Setting()
    setting.plugin = Plugin("Type", "Name")
    setting.name = "a"

    setting1 = Setting()
    setting1.name = "b"


    setting2 = Setting()
    setting2.name = "c"

    # Act
    data.update_setting(setting)
    data.update_setting(setting1)
    data.update_setting(setting2, setting.plugin)

    # Assert
    assert data._global_settings["b"] == setting1
    assert data._plugins["Type"]["Name"]["c"] == setting2


# Generated at 2022-06-10 22:45:48.885781
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.plugins.loader import PluginLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils import plugin_docs
    from ansible.utils.display import Display

    # Create config data instance
    config_data = ConfigData()

    # Create Ansible plugin loader
    plugin_loader = PluginLoader(
        class_name='Connection',
        config_data=config_data,
        class_path='ansible.plugins.connections',
        package_path='ansible.plugins.connection',
        package_name='ansible.plugins.connection',
        display=Display()
    )

    # Create Ansible plugin
    plugin = plugin_loader.get('local')

    # Get Ansible plugin docstring
    plugin_docstring = plugin_docs.get_docstring(plugin, verbose=True)

# Generated at 2022-06-10 22:45:58.708257
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()

    # Test update setting for plugin
    plugin = Plugin(type='action', name='shell')
    setting = Setting(name='random_name', value='random_value')
    config.update_setting(setting, plugin)

    assert config._plugins['action']['shell']['random_name'] == setting

    # Test update setting for global settings
    setting = Setting(name='random_name', value='random_value')
    config.update_setting(setting)

    assert config._global_settings['random_name'] == setting

    # Test update setting for existing plugin
    plugin = Plugin(type='action', name='shell')
    setting = Setting(name='random_name', value='new_random_value')
    config.update_setting(setting, plugin)


# Generated at 2022-06-10 22:46:06.173827
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print("\nTest for method update_setting of class ConfigData")
    config_data = ConfigData()
    config_data.update_setting(Setting("verbosity", "2"))
    verbosity_setting = config_data.get_setting("verbosity")
    assert verbosity_setting.name == "verbosity"
    assert verbosity_setting.value == "2"
    print("Verbosity setting: {}".format(verbosity_setting.name))
    print("Equal to: verbosity")
    print("Value: {}".format(verbosity_setting.value))
    print("Equal to: 2")



# Generated at 2022-06-10 22:46:16.430632
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    config_data.update_setting(Setting('display_skipped_hosts', 'boolean', True, 'Display skipped hosts with ansible-playbook or ansible-pull.'))
    """config_data.update_setting(Setting('display_skipped_hosts', 'boolean', True, 'Display skipped hosts with ansible-playbook or ansible-pull.'), Plugin('connection', 'local'))
    config_data.update_setting(Setting('display_skipped_hosts', 'boolean', False, 'Display skipped hosts with ansible-playbook or ansible-pull.'), Plugin('connection', 'ssh'))"""

    assert config_data.get_settings() == config_data.get_settings(Plugin('connection', 'local'))

# Generated at 2022-06-10 22:46:27.966054
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible_collections.ansible.community.tests.unit.modules.network.cloudengine.ce_command import GlobalSetting, PluginSetting, Plugin

    config_data = ConfigData()

    setting = GlobalSetting('module', 'fav module', 'I am favorite module')
    config_data.update_setting(setting)
    setting = GlobalSetting('module', 'normal module', 'I am normal module')
    config_data.update_setting(setting)
    setting = PluginSetting('module', 'normal module', 'I am plugin module')
    config_data.update_setting(setting, Plugin(type='test'))
    setting = PluginSetting('module', 'another plugin module', 'I am another plugin module')
    config_data.update_setting(setting, Plugin(type='test', name='test'))


# Generated at 2022-06-10 22:46:37.796425
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    plugin = Plugin(type="collections", name="azure", namespace="azure")
    plugin1 = Plugin(type="collections", name="azure.cloud", namespace="azure.cloud")
    plugin2 = Plugin(type="collections", name="azure.mgmt.compute", namespace="azure.mgmt.compute")
    plugin3 = Plugin(type="collections", name="azure.mgmt.network", namespace="azure.mgmt.network")
    plugin4 = Plugin(type="collections", name=None, namespace=None)
    cd.update_setting(Setting(name="azure_cloud_environment", value="AzureCloud"))
    cd.update_setting(Setting(name="azure_preview_modules_enabled", value="True"), plugin1)
    cd.update_

# Generated at 2022-06-10 22:46:43.237359
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Setup
    config_data = ConfigData()
    
    # Test for the case where plugin is None
    setting = plugin = None
    
    # Execute
    config_data.update_setting(setting, plugin)

    # Verify
    assert setting.name in config_data._global_settings
    assert config_data._global_settings[setting.name] == setting


# Generated at 2022-06-10 22:46:54.626037
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    result = cd.get_settings(plugin='None')
    print ('result: '+ str(result))
    result = cd.get_settings(plugin=None)
    print ('result: '+ str(result))
    result = cd.get_setting(name='None')
    print ('result: '+ str(result))
    result = cd.update_setting(setting='None')
    print ('result: '+ str(result))
    result = cd.update_setting(setting=None)
    print ('result: '+ str(result))
    result = cd.get_settings(plugin=None)
    print ('result: '+ str(result))
    result = cd.get_setting(name='None')
    print ('result: '+ str(result))

# Generated at 2022-06-10 22:47:05.489658
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

if __name__ == '__main__':
    test_ConfigData_get_settings()

# Generated at 2022-06-10 22:47:11.027487
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(setting={"testsetting1": "testvalue1"}, plugin=None)
    config_data.update_setting(setting={"testsetting2": "testvalue2"}, plugin=None)
    assert config_data.get_settings() == [{"testsetting1": "testvalue1"}, {"testsetting2": "testvalue2"}]


# Generated at 2022-06-10 22:47:17.898302
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # test that the function return the settings
    data = ConfigData()
    setting1 = {'name': 'test1', 'value': 1, 'plugin': 'testplugin'}
    setting2 = {'name': 'test2', 'value': 2, 'plugin': 'testplugin'}
    data.update_setting(setting1)
    data.update_setting(setting2)
    assert(len(data.get_settings()) == 2)

    # test that the function return the settings for the plugin
    setting3 = {'name': 'test3', 'value': 3, 'plugin': 'testplugin1'}
    setting4 = {'name': 'test4', 'value': 4, 'plugin': 'testplugin1'}
    data.update_setting(setting3)
    data.update_setting(setting4)

# Generated at 2022-06-10 22:47:28.504839
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configdata = ConfigData()
    class Plugin():
        def __init__(self, type, name):
            self.type = type
            self.name = name
    setting = {'name' : 'Name_1', 'value' : 'Value_1', 'plugin' : Plugin('type_1', 'name_1')}
    configdata.update_setting(setting)
    setting = {'name' : 'Name_2', 'value' : 'Value_2'}
    configdata.update_setting(setting)

    test_result = configdata.get_setting('Name_1', Plugin('type_1', 'name_1'))
    assert test_result == setting, 'Setting not retrieved correctly'
    test_result = configdata.get_setting('Name_2')

# Generated at 2022-06-10 22:47:32.642415
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(None)
    config_data.update_setting(None, None)
    config_data.update_setting(None, '')
    config_data.update_setting(None, None)

# Generated at 2022-06-10 22:47:35.028701
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(None)



# Generated at 2022-06-10 22:47:37.376521
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = config_data.get_setting('num_retries')
    assert setting is None

# Generated at 2022-06-10 22:47:46.620531
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin_type = "lookup"
    plugin_name = "dictionary"
    setting_name = "length"
    setting_value = "yes"

    plugin = Plugin(plugin_type, plugin_name)

    setting = Setting(setting_name, setting_value)

    config_data.update_setting(setting, plugin)

    settings = config_data.get_settings(plugin)

    assert settings[0].name == setting_name
    assert settings[0].value == setting_value



# Generated at 2022-06-10 22:47:57.837612
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    setting = config_data.get_setting('g_setting1')
    assert setting is None

    setting = config_data.get_setting('g_setting1', plugin=None)
    assert setting is None

    config_data.update_setting(Setting('g_setting1', 'global setting 1'))

    setting = config_data.get_setting('g_setting1')
    assert setting.name == 'g_setting1'
    assert setting.value == 'global setting 1'

    setting = config_data.get_setting('g_setting1', plugin=None)
    assert setting.name == 'g_setting1'
    assert setting.value == 'global setting 1'

    setting = config_data.get_setting('g_setting2', plugin=None)
    assert setting is None

#

# Generated at 2022-06-10 22:48:04.078099
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = {'name': 'configfile', 'value': '/etc/ansible/ansible.cfg'}
    plugin = {'type': 'core', 'name': 'basic'}
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings()[0]['name'] == 'configfile'

# Generated at 2022-06-10 22:48:19.857545
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_plugin_class_by_name
    from ansible.plugins.loader import get_plugins

    config_data = ConfigData()

    plugin = get_plugin_class("Inventory")("testinventory")
    plugin.name = "testinventory"
    plugin.type = "Inventory"
    plugin.path = "/tmp/test_ConfigData_update_setting/inventory.py"

    import os
    os.makedirs(os.path.dirname(plugin.path))
    with open(plugin.path, "w") as plugin_file:
        plugin_file.write("class InventoryModule(object):\n    pass\n")
    plugin_class = get_plugin_class_by_name(plugin.type, plugin.name)

# Generated at 2022-06-10 22:48:27.759570
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings = [
        ansible_setting.Setting(name='ANSIBLE_INVENTORY_ENABLED', value=['host_list', 'script', 'auto']),
        ansible_setting.Setting(name='ANSIBLE_INVENTORY', value='/etc/ansible/hosts')
    ]
    config_data = ansible_setting.ConfigData()
    for setting in settings:
        config_data.update_setting(setting)
    settings = config_data.get_settings()
    assert len(settings) == 2

# Generated at 2022-06-10 22:48:38.159983
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    from ansible.module_utils.ansible_release import __version__

    from ansible.plugins import get_all_plugin_loaders, PluginLoader

    plugin_loaders = get_all_plugin_loaders()

    for plugin_loader in plugin_loaders.values():

        if not isinstance(plugin_loader, PluginLoader):
            continue

        if plugin_loader.package == 'ansible.plugins.action' or plugin_loader.package == 'ansible.plugins.connection':
            continue

        for plugin in plugin_loader.all():

            version = plugin.__version__

            if version is None:
                version = __version__

            plugin_type = plugin_loader.package.replace('ansible.plugins.', '')

# Generated at 2022-06-10 22:48:42.676047
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    import mock
    setting = mock.Mock()
    setting.name = "foo"
    setting.get_value.return_value = "bar"
    config_data.update_setting(setting)
    assert config_data.get_setting("foo").get_value() == "bar"


# Generated at 2022-06-10 22:48:52.697615
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = ConfigSetting("test_global_name")
    config_data.update_setting(setting)
    setting = ConfigSetting("test_plugin_name", "test_plugin_type")
    config_data.update_setting(setting)
    assert config_data._global_settings.get("test_global_name") is not None
    assert config_data._plugins.get("test_plugin_type") is not None
    assert config_data._plugins.get("test_plugin_type").get("test_plugin_name") is not None
    assert config_data._plugins.get("test_plugin_type").get("test_plugin_name").get("test_plugin_name") is not None


# Generated at 2022-06-10 22:49:03.867653
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    global_setting = ConfigSetting()
    global_setting.type = ConfigSetting.BOOLEAN
    global_setting.name = "test_setting"
    global_setting.default = "false"
    global_setting.choices = []

    local_setting = ConfigSetting()
    local_setting.type = ConfigSetting.BOOLEAN
    local_setting.name = "test_setting"
    local_setting.default = "false"
    local_setting.choices = []

    config_data = ConfigData()
    config_data.update_setting(global_setting)
    config_data.update_setting(local_setting, plugin=ConfigPlugin("test_type", "test_name"))

    assert global_setting == config_data.get_setting("test_setting")
    assert local_setting == config_data.get_setting

# Generated at 2022-06-10 22:49:05.492343
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()

    c.update_setting('string', 'fact-cache')


# Generated at 2022-06-10 22:49:07.122093
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []



# Generated at 2022-06-10 22:49:19.157626
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting_global=setting(name="cfg_global",value=3)
    setting_plugin_plugin_type=setting(name="cfg_plugin_plugin_type",value=5)
    setting_plugin_plugin_type_plugin_name=setting(name="cfg_plugin_plugin_type_plugin_name",value=6)
    cd=ConfigData()
    cd.update_setting(setting_global)
    cd.update_setting(setting_plugin_plugin_type,plugin=Plugin('plugin_type','plugin_name'))
    cd.update_setting(setting_plugin_plugin_type_plugin_name,plugin=Plugin('plugin_type','plugin_name'))
    assert cd.get_setting('cfg_global').value==3
    assert cd.get_setting('cfg_global',None).value==3
    assert cd.get_

# Generated at 2022-06-10 22:49:28.181501
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('bar', 'foo'))

    setting = config_data.get_setting('foo')
    assert setting.name == 'foo'
    assert setting.value == 'bar'

    setting = config_data.get_setting('bar')
    assert setting.name == 'bar'
    assert setting.value == 'foo'

    setting = config_data.get_setting('foobar')
    assert setting is None

    config_data.update_setting(Setting('foo', 'baz'), Plugin('baz', 'baz'))

    setting = config_data.get_setting('foo')
    assert setting.name == 'foo'
    assert setting.value == 'bar'


# Generated at 2022-06-10 22:49:47.730159
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = MockPlugin()

    assert config_data.get_setting(None, plugin=plugin) == None

    plugin.name = "TestPlugin"
    assert config_data.get_setting(None, plugin=plugin) == None

    setting = MockSetting()
    setting.name = "TestSetting"
    config_data.update_setting(setting, plugin=plugin)
    assert config_data.get_setting(setting.name, plugin=plugin) == setting

    setting = MockSetting()
    setting.name = "TestSetting2"
    config_data.update_setting(setting, plugin=plugin)
    assert config_data.get_setting(setting.name, plugin=plugin) == setting

    setting = MockSetting()
    setting.name = "TestSetting2"

# Generated at 2022-06-10 22:49:51.514305
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
	test = ConfigData()
	test.update_setting("hoge")
	print(test)
	test.update_setting("moge", "A")
	print(test)

if __name__ == '__main__':
	test_ConfigData_update_setting()

# Generated at 2022-06-10 22:49:57.512742
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Test for global setting
    setting1 = Setting('foo', 'bar', 'global')
    config_data.update_setting(setting1)

    assert config_data.get_setting('foo', None) == setting1

    # Test for plugin setting
    setting2 = Setting('baz', 'baz', 'core', 'connection', 'local')
    config_data.update_setting(setting2)

    assert config_data.get_setting('baz', Plugin('connection', 'local')) == setting2


# Generated at 2022-06-10 22:50:03.362297
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_config_data = ConfigData()

    assert len(test_config_data.get_settings()) == 0

    setting = TestConfigSetting()
    setting.name = 'name'
    setting.value = 'value'

    test_config_data.update_setting(setting)

    assert len(test_config_data.get_settings()) == 1


# Generated at 2022-06-10 22:50:07.775139
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Unit test for method update_setting of class ConfigData
    from collections import namedtuple
    from ansiblelint.rules.AnsibleLintRule import AnsibleLintRule

    setting_data = namedtuple('setting_data', ['name', 'value', 'path'])
    plugin_data = namedtuple('plugin_data', ['type', 'name'])

    test_setting = setting_data('some_setting_name', 'some_value', 'some_path')
    test_plugin = plugin_data('some_type', 'some_name')
    conf = ConfigData()

    assert conf.get_setting('nonexistant_setting') is None
    assert conf.get_settings() == []

    conf.update_setting(test_setting)

    new_setting = conf.get_setting('some_setting_name')


# Generated at 2022-06-10 22:50:16.815638
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.module_utils.common.collections import ImmutableDict

    config_data = ConfigData()
    result = config_data.get_settings()
    assert result == []

    config_data._global_settings = dict(foo=dict(name='foo', value=1, origin='global'),
                                        bar=dict(name='bar', value=2, origin='global'))

    config_data._plugins = dict(filter=ImmutableDict(foo=dict(name='foo', value=3, origin='filter', filter='foo')),
                                callback=ImmutableDict(foo=dict(name='foo', value=4, origin='callback', callback='foo')))

    result = config_data.get_settings()
    assert len(result) == 2


# Generated at 2022-06-10 22:50:19.687754
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='foo', value='bar'))
    assert config_data.get_settings()[0].value == 'bar'


# Generated at 2022-06-10 22:50:26.485728
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    setting = Setting(name="setting1", values=["value1"], origin="file", plugin=None)
    config_data.update_setting(setting)
    assert config_data.get_setting("setting1").values == ["value1"]

    setting = Setting(name="setting2", values=["value2"], origin="file", plugin=None)
    config_data.update_setting(setting)
    assert config_data.get_setting("setting2").values == ["value2"]



# Generated at 2022-06-10 22:50:36.370932
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    assert config_data.get_setting(name='foo') is None

    from units.compat import mock
    from units.compat.mock import call

    # mock Setting to avoid importing it
    mock_setting = mock.MagicMock()
    mock_setting.name = 'verbosity'

    mock_plugin = mock.MagicMock()
    mock_plugin.type = 'connection'
    mock_plugin.name = 'netconf'

    assert config_data.get_setting(name='verbosity') is None
    config_data.update_setting(setting=mock_setting)
    assert config_data.get_setting(name='verbosity') == mock_setting
    assert mock_setting.to_data_structure.call_count == 0

    mock_setting.reset_mock()