

# Generated at 2022-06-10 22:40:35.792134
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = PluginTypeSettings('test', 'test_plugin')
    setting = PluginSetting('test', 'test_plugin')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('test', plugin).value == 'test_plugin'

# Generated at 2022-06-10 22:40:46.602083
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert (config_data.get_setting('changed_when') is None)

    from ansible.plugins.action import ActionBase
    from ansible.utils.plugin_docs import get_docstring

    docs, examples, returns, params, deprecated = get_docstring(ActionBase, False, False)

# Generated at 2022-06-10 22:40:53.911671
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin("network", "ios")
    setting1 = Setting("username", "abc", plugin.name, plugin.type)
    setting2 = Setting("password", "123", plugin.name, plugin.type)

    config_data.update_setting(setting1, plugin)
    config_data.update_setting(setting2, plugin)
    print("config_data.plugin: ", config_data.plugin)
    print("config_data.global_settings: ", config_data.global_settings)
    print("config_data.get_settings(plugin): ", config_data.get_settings(plugin))


# Generated at 2022-06-10 22:41:01.649089
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = config_data.get_setting("fact_caching") # fact_caching is only in ansible.cfg
    assert isinstance(setting,Setting)
    assert setting.name == "fact_caching"
    assert setting.value == "jsonfile"
    assert setting.section == "defaults"
    assert setting.plugin.type == "delegator"
    assert setting.plugin.name == "setup"
    assert setting.plugin.config_file == "ansible.cfg"


# Generated at 2022-06-10 22:41:08.129499
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert len(config_data.get_setting('setting_with_multiple_values')) == 0
    # add setting with multiple values
    setting = ConfigSetting(
                     name='setting_with_multiple_values',
                     module=['first', 'second'],
                     )
    config_data.update_setting(setting)
    assert config_data.get_setting('setting_with_multiple_values') == setting
    # update a single value of the setting
    setting = ConfigSetting(
                     name='setting_with_multiple_values',
                     module='new',
                     )
    config_data.update_setting(setting)
    assert config_data.get_setting('setting_with_multiple_values').module[-1] == 'new'


# Generated at 2022-06-10 22:41:15.480330
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = Plugin('a','b','c')
    setting = Setting('b', 'c', 'd')
    config_data.update_setting(setting, plugin)
    config_data.update_setting(setting, None)
    assert config_data.get_setting('b',plugin) == setting
    assert config_data.get_setting('b', None) == setting
    assert config_data.get_setting('c', None) is None


# Generated at 2022-06-10 22:41:17.820453
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    c.update_setting('setting1')
    assert c.get_settings()[0] == 'setting1'

# Generated at 2022-06-10 22:41:26.309679
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("test", "global", "global", "global", "global"))
    assert config_data._global_settings["test"].type == "global"

    config_data.update_setting(Setting("test", "auth", "auth", "auth", "auth"))
    assert config_data._plugins["auth"]["auth"]["test"].type == "auth"

    config_data.update_setting(Setting("test", "shell", "shell", "shell", "shell"), Plugin("shell", "shell"))
    assert config_data._plugins["shell"]["shell"]["test"].type == "shell"

# Generated at 2022-06-10 22:41:29.135052
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # create new ConfigData
    config_data = ConfigData()

    # assert that the actual result is the expected one
    assert config_data.get_setting('setting_name') is None


# Generated at 2022-06-10 22:41:38.352626
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import os
    import json
    config = ConfigData()
    setting1 = {"name": "host_key_checking", "plugin_type": "connection", "value": "true"}
    config.update_setting(setting1)
    setting2 = {"name": "host_key_checking", "plugin_type": "connection", "value": "false"}
    config.update_setting(setting2)
    setting3 = {"name": "host_key_checking", "plugin_type": "connection", "value": True}
    config.update_setting(setting3)
    setting4 = {"name": "host_key_checking", "plugin_type": "connection", "value": True}
    config.update_setting(setting4)

# Generated at 2022-06-10 22:41:53.559787
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    setting1 = Setting(name='name1', value='value1', plugin=Plugin(name='plugin1', type='type1'))
    config_data.update_setting(setting1)

    assert config_data.get_setting('name1') == setting1

    setting2 = Setting(name='name2', value='value2', plugin=Plugin(name='plugin2', type='type2'))
    config_data.update_setting(setting2)

    assert config_data.get_setting('name2') == setting2

    setting3 = Setting(name='name3', value='value3', plugin=Plugin(name='plugin3', type='type3'))
    config_data.update_setting(setting3)

    assert config_data.get_setting('name3') == setting3


# Generated at 2022-06-10 22:42:04.313463
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert_equal(cd._plugins, {})
    assert_equal(cd._global_settings, {})
    s = Setting()
    s.name = "foo"
    s.value = "bar"
    cd.update_setting(s)
    assert_equal(len(cd._global_settings), 1)
    assert_equal(len(cd._plugins), 0)
    s.name = "bar"
    s.value = "foo"
    cd.update_setting(s)
    assert_equal(len(cd._global_settings), 2)
    assert_equal(len(cd._plugins), 0)
    assert_equal(cd.get_setting("bar"), "foo")
    assert_equal(cd.get_setting("foo"), "bar")

# Generated at 2022-06-10 22:42:14.468227
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.utils.plugin_docs import get_docstring
    from ansible.utils.plugin_docs import get_docstring_examples
    from ansible.utils.plugin_docs import get_docstring_text
    from ansible.utils.plugin_docs import get_docfragment
    from ansible.utils.plugin_docs import parse_docstring
    from ansible.utils.plugin_docs import get_docopt_usage
    from ansible.utils.plugin_docs import get_docopt_options
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.cache import CacheModule
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.shell import ShellModule
   

# Generated at 2022-06-10 22:42:21.777448
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo2', 'bar2', 'baz2'))
    config_data.update_setting(Setting('foo3', 'bar3', 'baz3'))
    settings = config_data.get_settings()
    assert len(settings) == 3
    for setting in settings:
        assert setting.name in ('foo', 'bar', 'baz')

# Generated at 2022-06-10 22:42:30.933835
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    # test global setting
    setting = {
        'name': 'ANSIBLE_FOO',
        'value': 'bar'
    }
    config_data.update_setting(setting)
    assert config_data.get_setting('ANSIBLE_FOO') == setting

    # test plugin setting
    plugin = {
        'type': 'action',
        'name': 'copy'
    }
    setting = {
        'name': 'ANSIBLE_FOO',
        'value': 'bar',
        'type': 'action',
        'plugin': 'copy',
    }
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('ANSIBLE_FOO', plugin) == setting

    # test validation of update without plugin

# Generated at 2022-06-10 22:42:42.590528
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    from collections import namedtuple
    Plugin = namedtuple('Plugin', 'type, name')
    from collections import namedtuple
    Setting = namedtuple('Setting', 'name')

    # Test global settings
    global_setting = Setting('global_setting')
    config_data.update_setting(global_setting)
    assert(config_data.get_setting('global_setting') == global_setting)
    assert(config_data.get_settings() == [global_setting])

    # Test local settings
    local_setting = Setting('local_setting')
    config_data.update_setting(local_setting, plugin=Plugin('normal', 'local'))
    assert(config_data.get_setting('local_setting', Plugin('normal', 'local')) == local_setting)

# Generated at 2022-06-10 22:42:49.560623
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    global_settings = config.get_settings()
    assert len(global_settings) == 0
    assert isinstance(global_settings, list)

    # setting = Setting()
    # setting.update({'name': 'ansible_posix_implicit_become_method'})
    # config.update_setting(setting)
    #
    # global_settings = config.get_settings()
    # assert len(global_settings) == 1
    # assert isinstance(global_settings, list)
    # assert global_settings[0] == setting
    #
    # plugin = Plugin()
    # plugin.update({'name': 'test', 'type': 'test'})
    #
    # settings = config.get_settings(plugin)
    # assert len(settings) == 0
    # assert is

# Generated at 2022-06-10 22:43:02.093674
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()

    # The following plugin is for testing
    plugin = Plugin('my_type', 'my_name')
    setting = Setting('my_setting', 'my_value', plugin=plugin)
    config.update_setting(setting)

    # The following plugin has no setting
    plugin_2 = Plugin('my_type_2', 'my_name_2')

    # The following plugin has no setting
    plugin_3 = Plugin('my_type_3', 'my_name_3')

    # The following plugin has no setting
    plugin_4 = Plugin('my_type_4', 'my_name_4')

    assert config.get_setting('my_setting') == setting
    assert config.get_setting('my_setting', plugin) == setting
    assert config.get_setting('my_setting_2') == None


# Generated at 2022-06-10 22:43:10.454445
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert len(data.get_settings()) == 0

    data.update_setting(Setting('name', 'global_value'))
    assert data.get_settings()[0].value == 'global_value'
    assert data.get_settings()[0].name == 'name'

    data.update_setting(Setting('name', 'local_value', Plugin('type', 'name')), Plugin('type', 'name'))
    assert data.get_settings(Plugin('type', 'name'))[0].value == 'local_value'
    assert data.get_settings(Plugin('type', 'name'))[0].name == 'name'
    assert len(data.get_settings()) == 1


# Generated at 2022-06-10 22:43:22.746624
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cfg = ConfigData()
    # Ensure that we get an empty list when called on an object with no settings
    assert len(cfg.get_settings()) == 0

    # Ensure that we get an empty list when called on an object with no settings
    assert len(cfg.get_settings(None)) == 0

    # Ensure that we get an empty list when called on an object with no settings for a plugin
    assert len(cfg.get_settings(object(type='aaa', name='bbb'))) == 0

    # Ensure that we get back the setting we added in the above tests.
    cfg.update_setting(object(name='ccc', value='ddd', plugin=None))
    assert len(cfg.get_settings()) == 1
    assert cfg.get_settings()[0].name == 'ccc'
    assert cfg.get_

# Generated at 2022-06-10 22:43:29.895763
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('ANSIBLED_ACCOUNT_ADMIN_NAME', 'admin')
    config_data.update_setting(setting)
    assert config_data.get_setting('ANSIBLED_ACCOUNT_ADMIN_NAME') == setting


# Generated at 2022-06-10 22:43:41.448890
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = Setting('first_setting', 'a', 'first_setting')
    config_data.update_setting(setting)

    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0] == setting

    setting = Setting('second_setting', 'b', 'second_setting')
    config_data.update_setting(setting)

    assert len(config_data.get_settings()) == 2
    assert setting in config_data.get_settings()
    assert config_data.get_settings()[0] != config_data.get_settings()[1]

    plugin = Plugin(Plugin.HOOK, 'my_hook', 'my_dir')
    setting = Setting('first_hook_setting', 'c', 'first_hook_setting')
    config

# Generated at 2022-06-10 22:43:47.051109
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.config.setting import Setting

    config = ConfigData()

    plugin = None
    setting = Setting("test", "value")
    config.update_setting(setting, plugin)
    settings = config.get_settings(plugin)

    assert len(settings) == 1
    assert settings[0].name == "test"
    assert settings[0].value == "value"


# Generated at 2022-06-10 22:43:53.673497
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    assert config_data.get_setting('missing') == None

    config_data._global_settings['setting1'] = {'name': 'setting1', 'plugin': None, 'plugin_type': None, 'value': 'setting1'}

    assert config_data.get_setting('setting1') == {'name': 'setting1', 'plugin': None, 'plugin_type': None, 'value': 'setting1'}
    assert config_data.get_setting('setting1', 'test') == None



# Generated at 2022-06-10 22:43:59.364550
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()

    assert len(config_data.get_settings()) == 0

    collection_plugin = PluginLoader('collections', 'collections', 'CollectionModule', 'modules')
    collection_plugin.add_directory('./test/test_module_utils/test_collections/ansible_module_test_1')
    config_data.update_setting(Setting('test_setting', 'test_default'))
    config_data.update_setting(Setting('test_setting_2', 'test_default_2', module_utils=collection_plugin))

    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0].name == 'test_setting'

# Generated at 2022-06-10 22:44:11.050519
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    assert config_data.get_setting('A_GLOBAL_OPTION') is None

    # Update a global setting and get it
    config_data.update_setting(Setting(name='A_GLOBAL_OPTION', value=True))
    assert config_data.get_setting('A_GLOBAL_OPTION').value == True

    # Update a plugin setting and get it
    plugin = Plugin(type='lookup', name='test_lookup', path='lookup/test_lookup.py')
    config_data.update_setting(Setting(name='A_LOOKUP_OPTION', value=100), plugin)
    assert config_data.get_setting('A_LOOKUP_OPTION', plugin).value == 100


# Generated at 2022-06-10 22:44:17.204904
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Test global setting
    gs = GlobalSetting('global 1', 'global 2')
    config_data.update_setting(gs)
    assert config_data.get_setting('global 1') is not None

    # Test plugin setting
    ps = PluginSetting('plugin 1', 'plugin 2')
    pl = Plugin('collection', 'collection_name')
    config_data.update_setting(ps, pl)
    assert config_data.get_setting('plugin 1', pl) is not None


# Generated at 2022-06-10 22:44:28.191967
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin_type = 'collection'
    plugin_name = 'test_collection'

    collection_setting = ConfigDataSetting('test_setting', 'data', 'some data', plugin_type, plugin_name)
    config_data.update_setting(collection_setting)

    other_setting = ConfigDataSetting('other_setting', 'data', 'some other data', 'some_other_plugin_type', 'some other plugin')
    config_data.update_setting(other_setting)

    settings = config_data.get_settings(plugin=None)
    assert len(settings) == 2

    settings = config_data.get_settings(PluginDescriptor(plugin_type, plugin_name))
    assert len(settings) == 1
    assert settings[0].name == 'test_setting'

# Generated at 2022-06-10 22:44:39.364340
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = Plugin()
    plugin.type = 'foo'
    plugin.name = 'bar'

    assert config_data.get_setting('setting_a') is None
    assert config_data.get_setting('setting_a', plugin) is None

    test_setting = Setting()
    test_setting.name = 'setting_a'
    test_setting.value = 'test_value'

    config_data.update_setting(test_setting)
    assert config_data.get_setting('setting_a') == test_setting
    assert config_data.get_setting('setting_a', plugin) is None

    config_data.update_setting(test_setting, plugin)
    assert config_data.get_setting('setting_a') == test_setting
    assert config_data.get_setting

# Generated at 2022-06-10 22:44:41.774660
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() is not None


# Generated at 2022-06-10 22:44:48.517916
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(ConfigSetting('setting', 'value'))
    setting = config.get_setting('setting')
    assert setting is not None
    assert setting.name == 'setting'
    assert setting.value == 'value'


# Generated at 2022-06-10 22:44:58.398096
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins import PluginBase
    from config_data import ConfigData

    class FakeSetting(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value

    class FakePlugin(PluginBase):
        NAME = "fake_plugin"
        TYPE = "fake_type"

    global_setting_1 = FakeSetting('global_setting_1', 'global_setting_1_value')
    global_setting_2 = FakeSetting('global_setting_2', 'global_setting_2_value')

    plugin_setting_1 = FakeSetting('plugin_setting_1', 'plugin_setting_1_value')
    plugin_setting_2 = FakeSetting('plugin_setting_2', 'plugin_setting_2_value')

    config_data = ConfigData()

# Generated at 2022-06-10 22:45:09.476260
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    """Test for method get_setting of class ConfigData"""
    config_data = ConfigData()
    # Case 1: plugin=None and setting name does not exist
    setting = config_data.get_setting(name='plugin')
    assert setting == None
    # Case 2: plugin=None and setting name exists
    setting = config_data.get_setting(name='verbosity')
    assert isinstance(setting, dict)
    assert 'name' in setting and setting['name'] == 'verbosity'
    assert 'type' in setting and setting['type'] == 'int'
    assert 'default' in setting and setting['default'] == 0
    assert 'description' in setting and setting['description'] == 'Verbosity level'
    assert 'ini' in setting and isinstance(setting['ini'], dict)

# Generated at 2022-06-10 22:45:11.915540
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0
    assert len(config_data.get_settings(object)) == 0


# Generated at 2022-06-10 22:45:20.888269
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    #
    # This unit test statically initializes the class ConfigData and
    # tests the method update_setting().
    #
    import mock
    from unittest import TestCase, main
    from units.unit_data import Data

    class ConfigDataTestCase(TestCase):

        def setUp(self):
            self.config_data = ConfigData()

        def test_update_setting_no_plugins(self):
            setting_mock = mock.MagicMock()
            self.config_data.update_setting(setting_mock)
            self.assertDictEqual({setting_mock.name: setting_mock}, self.config_data._global_settings)

        def test_update_setting_with_plugins(self):
            setting_mock = mock.MagicMock()
            plugin_mock = mock.Magic

# Generated at 2022-06-10 22:45:26.789897
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("setting_1")
    config_data.update_setting("setting_2")
    assert config_data.get_setting("setting_1") == "setting_1"
    assert config_data.get_setting("setting_2") == "setting_2"


# Generated at 2022-06-10 22:45:36.360120
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    config_data.update_setting(Setting(name="FOO1"))
    config_data.update_setting(Setting(name="FOO2"))
    config_data.update_setting(Setting(name="FOO3"), plugin=AnsiblePlugin(type="action", name="copy"))
    config_data.update_setting(Setting(name="FOO4"), plugin=AnsiblePlugin(type="action", name="copy"))
    config_data.update_setting(Setting(name="FOO5"), plugin=AnsiblePlugin(type="action", name="template"))

    global_settings = config_data.get_settings()

    assert len(global_settings) == 3
    assert global_settings[0].name == "FOO1"

# Generated at 2022-06-10 22:45:42.293937
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(Setting("verbosity", "default", "int"))
    assert config.get_setting("verbosity") is not None
    assert "verbosity" == config.get_setting("verbosity").name
    assert Setting("verbosity", "default", "int") == config.get_setting("verbosity")


# Generated at 2022-06-10 22:45:47.149102
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting1 = ConfigSetting(name='setting1', value='value1')
    config_data.update_setting(setting1)
    assert len(config_data._global_settings) == 1
    assert config_data._global_settings['setting1'] == setting1


# Generated at 2022-06-10 22:45:57.552332
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()

    action_loader = PluginLoader('ActionModule', 'ansible.plugins.action')
    cli_loader = PluginLoader('Connection', 'ansible.plugins.connections')
    callback_loader = PluginLoader('CallbackModule', 'ansible.plugins.callback')
    shell_loader = PluginLoader('ShellModule', 'ansible.plugins.shell')
    test_loader = PluginLoader('TestModule', 'ansible.modules.test')

    config_data.update_setting(action_loader.get_plugin('echo'), 'action')
    config_data.update_setting(cli_loader.get_plugin('local'), 'connection')
    config_data.update_setting(callback_loader.get_plugin('tree'), 'callback')
    config_data.update_setting

# Generated at 2022-06-10 22:46:13.220964
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()

    # Plugin setting
    plugin = Plugin(name='test', type='test')
    setting = Setting(name='test', value='test', plugin=plugin)
    config.update_setting(setting)
    assert setting in config.get_settings(plugin)
    assert setting not in config.get_settings()
    assert config.get_setting('test', plugin) == setting

    # Global setting
    setting = Setting(name='test', value='test')
    config.update_setting(setting)
    assert setting in config.get_settings()
    assert config.get_setting('test') == setting

    # Update setting
    setting.value = 'new value'
    config.update_setting(setting)
    assert config.get_setting('test').value == 'new value'


# Generated at 2022-06-10 22:46:13.940935
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    pass

# Generated at 2022-06-10 22:46:26.263458
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    class Plugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    config = ConfigData()
    assert config.get_setting('output_callback') is None
    assert config.get_setting('output_callback', Plugin(None, None)) is None

    class Setting(object):
        def __init__(self, name):
            self.name = name
    setting = Setting('output_callback')
    config.update_setting(setting)
    assert config.get_setting('output_callback') is setting
    assert config.get_setting('output_callback', Plugin(None, None)) is setting

    assert config.get_setting('inventory') is None
    assert config.get_setting('inventory', Plugin('inventory', 'local')) is None

    setting = Setting('inventory')

# Generated at 2022-06-10 22:46:30.894027
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data=ConfigData()
    setting=Setting()
    plugin=Plugin()
    plugin.name = "name"
    plugin.type = "type"
    config_data.update_setting(setting,plugin)
    assert config_data._plugins["type"]["name"]["foo"]=="bar"
    

# Generated at 2022-06-10 22:46:38.446715
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()

    config.update_setting(Setting('foo', 'foo_value'))
    config.update_setting(Setting('foo', 'foo_value', plugin=Plugin('bar', 'random')))
    config.update_setting(Setting('foo', 'foo_value', plugin=Plugin('bar', 'random', PluginType.MODULE)))

    config.update_setting(Setting('bar', 'bar_value'))
    config.update_setting(Setting('bar', 'bar_value', plugin=Plugin('baz', 'random')))
    config.update_setting(Setting('bar', 'bar_value', plugin=Plugin('baz', 'random', PluginType.MODULE)))

    assert(config.get_setting('foo') == 'foo_value')

# Generated at 2022-06-10 22:46:41.776750
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('sudo_user') is None
    assert config_data.get_setting('foo', 'bar') is None


# Generated at 2022-06-10 22:46:46.836838
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    new_setting = config_data.update_setting(Setting(name="name1", value="value1"))
    assert new_setting.name == "name1"
    assert new_setting.value == "value1"
    assert config_data.get_setting("name1") == new_setting


# Generated at 2022-06-10 22:46:57.463033
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # GIVEN: test object
    config_data = ConfigData()

    # WHEN: get_settings method is called for global configuration
    # THEN: settings for global configuration should be returned
    assert type(config_data.get_settings()).__name__ == 'list'
    assert len(config_data.get_settings()) == 0

    # WHEN: get_settings method is called for plugin configuration
    # THEN: settings for plugin configuration should be returned
    assert type(config_data.get_settings('PluginType', 'PluginName')).__name__ == 'list'
    assert len(config_data.get_settings('PluginType', 'PluginName')) == 0

    # WHEN: get_settings method is called for non existing plugin type
    # THEN: settings for plugin configuration should be returned

# Generated at 2022-06-10 22:47:00.539269
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    conf = ConfigData()
    assert conf.get_setting("bla") is None
    s = Setting("bla")
    conf.update_setting(s)
    assert conf.get_setting("bla") is not None


# Generated at 2022-06-10 22:47:10.438848
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    setting_1 = Setting('setting_1', 'value_1')
    config_data.update_setting(setting_1)

    global_setting = config_data.get_setting('setting_1')
    assert global_setting.name == 'setting_1'
    assert global_setting.value == 'value_1'

    setting_2 = Setting('setting_2', 'value_2')
    plugin = Plugin('plugin_1', 'plugin_type')
    config_data.update_setting(setting_2, plugin)

    plugin_setting = config_data.get_setting('setting_2', plugin)
    assert plugin_setting.name == 'setting_2'
    assert plugin_setting.value == 'value_2'



# Generated at 2022-06-10 22:47:30.588787
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    setting = Setting('plugin', 'test', 'name', 'type', 'default value', 'description', 'scope', False)
    config_data.update_setting(setting)
    assert setting.name == config_data.get_setting(setting.name)

    setting = Setting('plugin', 'test', 'name', 'type', 'default value', 'description', 'scope', False)
    config_data.update_setting(setting)
    assert setting.name == config_data.get_setting(setting.name, setting)

    assert None == config_data.get_setting('invalid_setting')
    assert None == config_data.get_setting('invalid_setting', 'invalid_plugin')


# Generated at 2022-06-10 22:47:33.320997
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.get_setting("test")
    config_data.get_setting("test", "type")


# Generated at 2022-06-10 22:47:42.145403
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class plugin(object):
        def __init__(self, p_type, p_name):
            self.type = p_type
            self.name = p_name

    class setting(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value

    st = setting('foo', 'bar')
    cdata = ConfigData()
    cdata.update_setting(st)

    assert cdata._global_settings['foo'].name == 'foo'
    assert cdata._global_settings['foo'].value == 'bar'

    st1 = setting('foo', 'baz')
    cdata.update_setting(st1, plugin('module', 'example'))

    assert cdata._plugins['module']['example']['foo'].name == 'foo'


# Generated at 2022-06-10 22:47:53.484396
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    assert configData._global_settings == {}
    assert configData._plugins == {}

    ansible_global_setting = Setting("ANSIBLE_CONFIG", "Not set", "ansible.cfg")
    configData.update_setting(ansible_global_setting)
    assert len(configData._global_settings) == 1
    assert configData._global_settings["ANSIBLE_CONFIG"] == ansible_global_setting

    ansible_connection_setting = Setting("ANSIBLE_CONNECTION_PLUGINS", "", "/Users/krishna/Development/shippable/environment/ansible/runtimes/2.3.0.0/libexec/lib/python2.7/site-packages/ansible/plugins/connection")
    ansible_connection_plugin = Plugin("connection", "smart")


# Generated at 2022-06-10 22:48:01.728420
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()

    config.update_setting(Setting('name','description','value','short','cli'))

    assert config.get_setting('name') is not None
    assert config.get_setting('name').name == 'name'
    assert config.get_setting('name').description == 'description'
    assert config.get_setting('name').value == 'value'
    assert config.get_setting('name').short_opt == 'short'
    assert config.get_setting('name').cli_arg == 'cli'

    assert config.get_setting('none') is None
    assert config.get_setting('name', Plugin('type','name')) is None

    config.update_setting(Setting('name2', 'description2', 'value2', 'short2', 'cli2', Plugin('type', 'name')))

    assert config

# Generated at 2022-06-10 22:48:11.350762
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    config_data.update_setting(ConfigSetting('collection_paths', 'set', ["/etc/ansible/collections"], None, None, None, None, None))
    config_data.update_setting(ConfigSetting('deprecation_warnings', 'set', True, None, None, None, None, None))

    settings = config_data.get_settings()

    assert len(settings) == 2
    assert settings[0].name == 'collection_paths'
    assert settings[1].name == 'deprecation_warnings'


# Generated at 2022-06-10 22:48:20.886716
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class TestSetting(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value
    
    class TestPlugin(object):
        def __init__(self, type, name):
            self.name = name
            self.type = type

    # Create test object ConfigData
    config_data = ConfigData()

    # Create mock plugin
    plugin = TestPlugin(type='type', name='name')

    # Create mock setting
    setting = TestSetting(name='name', value='value')
    setting1 = TestSetting(name='name1', value='value')

    # Add mock setting to global settings
    config_data.update_setting(setting)

    # Add mock setting to plugin settings
    config_data.update_setting(setting1, plugin=plugin)

    # Check get

# Generated at 2022-06-10 22:48:31.350722
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Import needed dependencies
    from collections import namedtuple
    from ansible.plugins.loader import PluginLoader

    # Set up data
    config = ConfigData()
    global_setting = namedtuple("Setting", "name value plugin")
    plugin_setting = namedtuple("Setting", "name value plugin")
    global_setting.name = 'foo'
    global_setting.value = 'bar'
    plugin_setting.name = 'foo'
    plugin_setting.value = 'baz'
    plugin_setting.plugin = PluginLoader('action').get('ping')
    config.update_setting(global_setting)
    config.update_setting(plugin_setting)

    # Test global setting
    assert config.get_setting("foo") == global_setting
    # Test plugin setting

# Generated at 2022-06-10 22:48:41.941744
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import pprint

    from ansiblelint import AnsibleLintRule
    from ansiblelint.config import Rule, Setting

    # update global settings
    plugin = None
    name = 'ansible-lint_max_line_length'
    default = '79'
    typ = 'int'
    description = 'The maximum acceptable line length in the source code, or 0 to disable line length checking.'
    setting = Setting(name, default, typ, description)
    data = ConfigData()
    data.update_setting(setting, plugin)

    assert data._global_settings[name] == setting

    # update plugin settings
    name = 'ansible-lint_max_line_length'
    default = '79'
    typ = 'int'

# Generated at 2022-06-10 22:48:43.537852
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    conf = ConfigData()
    assert conf.get_settings() == []

# Generated at 2022-06-10 22:48:58.336855
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting('default_callback', None) == None
    setting1 = BaseSetting(name='default_callback', plugin=BasePlugin('callback', 'json'))
    setting1.update(False)
    config_data.update_setting(setting1)
    assert config_data.get_setting('default_callback', None) == setting1


# Generated at 2022-06-10 22:49:07.769824
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.ansible_release import __version__
    from ansible.utils.plugin_docs import doc_fragments_to_rst
    from ansible.config.manager import ConfigManager
    from ansible.config.setting import Setting

    config_manager = ConfigManager()
    config_manager.load_default_config_file()
    config = config_manager.config

    plugin_name = 'setup'
    plugin_type = 'module'

    config_data = ConfigData()

    plugin = config_data.get_setting(plugin_name, plugin_type)
    assert plugin is None

    base_doc = doc_fragments_to_rst(config)
    rst = base_doc + ('\n\nThese are settings for all %s plugins:\n\n' % plugin_type)


# Generated at 2022-06-10 22:49:19.849507
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """
    Name of the test: test_ConfigData_update_setting
    Description:      Method testing for update setting in a configuration file
    """
    config_data = ConfigData()
    # testing for the global configuration file
    default_setting = {'name': 'default', 'value': True, 'priority': 0}
    config_data.update_setting(default_setting)
    assert config_data._global_settings['default'] == default_setting

    # testing for configuration file of plugin_type
    callback_plugin = {'type': 'callback', 'name': 'test'}
    callback_setting = {'name': 'test', 'value': True, 'priority': 1}
    config_data.update_setting(callback_setting, callback_plugin)

    assert config_data._plugins['callback']['test']['test'] == callback

# Generated at 2022-06-10 22:49:28.015133
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    from collections import namedtuple
    plugin = namedtuple("Plugin", ["type", "name"])
    # Global setting
    setting = namedtuple("Setting", ["name", "value"])
    setting1 = setting("display_minimal_output", "true")
    config_data.update_setting(setting1, None)
    assert config_data.get_setting("display_minimal_output", None).value == setting1.value
    # Local setting
    setting2 = setting("verbosity", "1")
    config_data.update_setting(setting2, plugin("connection", "local"))
    assert config_data.get_setting("verbosity", plugin("connection", "local")).value == setting2.value

# Generated at 2022-06-10 22:49:30.822324
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    conf = ConfigData()
    assert conf.get_settings() == []
    assert conf.get_settings(plugin=None) == []

# Generated at 2022-06-10 22:49:41.004379
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='name1',value='value1',scope='global'))
    assert config_data.get_setting('name1').name == 'name1'
    assert config_data.get_setting('name1').value == 'value1'
    assert config_data.get_setting('name1').scope == 'global'
    assert config_data.get_setting('name1') == config_data.get_settings()[0]
    assert config_data.get_settings()[0].name == 'name1'
    assert config_data.get_settings()[0].value == 'value1'
    assert config_data.get_settings()[0].scope == 'global'

# Generated at 2022-06-10 22:49:51.220154
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.config import Config
    from ansible.config.data import ConfigSetting

    config1 = Config()
    config2 = Config()

    group_name = 'my_group'

    config1.initialize_plugin_configuration_definitions(group_name)
    config2.initialize_plugin_configuration_definitions(group_name)

    setting_name = 'setting_one'
    config1.register_setting(setting_name, group_name)
    config2.register_setting(setting_name, group_name)

    setting_name = 'setting_two'
    config1.register_setting(setting_name, group_name)
    config2.register_setting(setting_name, group_name)

    config_data = ConfigData()


# Generated at 2022-06-10 22:49:55.002656
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    if cd is None:
        print("cd is None, so test failed")
        return
    try:
        settings = cd.get_settings()
    except:
        print("get_settings failed")
        return

    print("get_settings test passed")
    

# Generated at 2022-06-10 22:50:00.758145
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    global_settings = {
        'vault_password_file':
        'test/files/ansible.cfg/ansible_2.2/vault_password_file',
        'log_path':
        'test/files/ansible.cfg/ansible_2.2/log_path',
        'force_handlers':
        'test/files/ansible.cfg/ansible_2.2/force_handlers',
        'forks':
        'test/files/ansible.cfg/ansible_2.2/forks'
    }
    plugin_type = "MODULE"
    plugin_name = "wait_for"

# Generated at 2022-06-10 22:50:05.842225
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    plugin = PluginDefinition(vars(PluginTypes)[list(PluginTypes.__dict__.keys())[0]], 'plugin')
    setting = SettingDefinition('setting')
    config.update_setting(setting, plugin)
    assert config.get_settings(plugin) is not None


# Generated at 2022-06-10 22:50:34.694654
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import os

    # Load the config into an object of data type ConfigData
    config_data = ConfigData()
    config_data.update_setting(setting=Setting(name='cfg_loc', value=os.path.dirname(os.path.realpath(__file__))))

    # Create a plugin
    plugin = Plugin(name='standard_library', type='module')

    # Create a setting
    setting = Setting(name='library', value='/usr/share/ansible/plugins/modules')
    config_data.update_setting(setting=setting, plugin=plugin)

    # Ensure that the setting never shows up when calling `get_config` without 'plugin'
    assert config_data.get_settings() == [config_data.get_setting('cfg_loc')]

    # Ensure that the setting shows up as expected
    assert config_