

# Generated at 2022-06-10 22:40:36.224282
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Create PcpObjectId object
    class PcpObjectId(object):
        _id = None
        _type = None

        def __init__(self, id, type):
            self._id = id
            self._type = type

        def getId(self):
            return self._id

        def getType(self):
            return self._type

    # Create ConfigData object
    config_data = ConfigData()

    # Create PcpObjectId objects
    id_setting_object = PcpObjectId("setting_name", "setting")
    id_plugin_object = PcpObjectId("plugin_name", "plugin")
    id_module_object = PcpObjectId("module_name", "module")
    id_module_resource_object = PcpObjectId("module_resource_name", "module_resource")

    #

# Generated at 2022-06-10 22:40:46.756378
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert [] == config_data.get_settings()

    config_data._global_settings['test_setting'] = 'test_setting_value'
    assert [{'name': 'test_setting', 'value': 'test_setting_value'}] == config_data.get_settings()
    assert 'test_setting_value' == config_data.get_settings()[0]['value']

    plugin_1 = Plugin('test_type', 'test_name', 'test_path')
    plugin_2 = Plugin('test_type', 'test_name_2', 'test_path_2')
    plugin_3 = Plugin('test_type_2', 'test_name_3', 'test_path_3')

    #Plugin type not in dict
    config_data._global_settings = {}
   

# Generated at 2022-06-10 22:40:47.734134
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

# Generated at 2022-06-10 22:40:54.794467
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    g1 = ConfigData()
    g1.update_setting(Setting(name='test1', value='test1'))
    g1.update_setting(Setting(name='test2', value='test2'))
    g1.update_setting(Setting(name='test3', value='test3'))
    assert g1.get_settings()[0].value == 'test1'
    assert g1.get_settings()[1].value == 'test2'
    assert g1.get_settings()[2].value == 'test3'


# Generated at 2022-06-10 22:41:04.807302
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    assert data._global_settings == {}
    assert data._plugins == {}

    # add global setting
    setting1 = Setting('setting1', 'value')
    data.update_setting(setting1)
    assert data._global_settings == {'setting1': setting1}
    assert data._plugins == {}

    # add plugin setting
    setting2 = Setting('setting2', 'value')
    plugin1 = Plugin('plugin1', 'module')
    data.update_setting(setting2, plugin1)
    assert data._global_settings == {'setting1': setting1}
    assert data._plugins == {'module': {'plugin1': {'setting2': setting2}}}

    # add another plugin setting
    setting3 = Setting('setting3', 'value')
    plugin2 = Plugin('plugin2', 'module')

# Generated at 2022-06-10 22:41:07.611983
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    configData.update_setting("setting", "plugin")

    assert configData.get_setting("setting", "plugin") == "setting"

# Generated at 2022-06-10 22:41:19.326637
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    class Plugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    plugin1 = Plugin('lookup', 'file')
    plugin2 = Plugin('lookup', 'file1')
    c.update_setting(setting=Setting(name='path', value=['/etc/ansible/hosts']), plugin=plugin1)
    c.update_setting(setting=Setting(name='path', value=['/etc/ansible/hosts1']), plugin=plugin2)
    c.update_setting(setting=Setting(name='timeout', value=10), plugin=None)
    assert len(c.get_settings()) == 1
    assert len(c.get_settings(plugin1)) == 1

# Generated at 2022-06-10 22:41:29.092471
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.plugins.loader import PluginLoaderEntry
    from ansible.plugins.loader import PluginLoader

    pl = PluginLoader(paths=None, package_name='ansible_collections.test.test_utils.plugins')
    plugin_paths = pl.find_plugin_paths()

    # test for a valid plugin
    base_plugin = PluginLoaderEntry('test_utils.plugins.test_plugins', 'TestModule', {}, plugin_paths)
    plugin = PluginLoader('test_utils.plugins.test_plugins', 'TestModule', base_plugin).get('test_plugin_one')

    config_data = ConfigData()

    # Update config data with a valid setting
    setting = ['a', 'b', 'c']
    setting_entry = ['key', 'value', 'description']

# Generated at 2022-06-10 22:41:33.643523
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # config_data.get_setting() returns expected data
    assert config_data.get_setting(None, None) is None

    # config_data.get_setting() returns expected data
    assert config_data.get_setting('foo', None) is None

    # config_data.get_setting() returns expected data
    assert config_data.get_setting('foo', 'bar') is None


# Generated at 2022-06-10 22:41:38.554044
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting1 = PluginSetting('test1', True, "test setting 1")
    setting2 = PluginSetting('test2', True, "test setting 2")

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)

    settings = config_data.get_settings()
    assert settings[0].name == "test1"
    assert settings[1].name == "test2"



# Generated at 2022-06-10 22:41:48.503793
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    setting = Setting(
        'local_tmp', '/tmp', 'path',
        'The directory where temporary files are created when executing modules locally',
        '/tmp')
    configData.update_setting(setting)
    setting = Setting(
        'gathering', 'implicit', 'string',
        'Controls the gathering of facts.',
        'implicit')
    configData.update_setting(setting)



# Generated at 2022-06-10 22:42:00.092593
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    plugin = 'fake_plugin'
    setting = {'name': 'fake_name'}

    # return None if the config is empty
    assert cd.get_setting(None, None) is None

    # return the global setting if plugin is None
    cd._global_settings = {'fake_name': setting}
    assert cd.get_setting('fake_name') == setting

    # return None if the plugin doesn't exist
    assert cd.get_setting('fake_name', 'fake_plugin') is None

    # return the correct setting if the plugin type and name both exist
    cd._plugins = {'fake_type': {'fake_plugin': {'fake_name': setting}}}
    assert cd.get_setting('fake_name', plugin) == setting



# Generated at 2022-06-10 22:42:09.994932
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Create a plugin with type "module" and name "copy"
    plugin = Plugin('copy', 'module')
    # Create a setting with name "forks", category "Internal Options", module "copy"
    setting = Setting(plugin = plugin, name = "forks", category = "Internal Options")
    # Create a ConfigData object and add the setting
    config = ConfigData()
    config.update_setting(setting)
    # Get the setting back out of the config object and check that it matches the original
    setting_result = config.get_setting("forks", plugin)

# Generated at 2022-06-10 22:42:16.816347
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    setting1 = {"name": "foo", "default": "bar"}
    config_data.update_setting(setting1)
    setting2 = {"name": "foo", "default": "bar", "plugin": {"type": "bla", "name": "bazaar"}}
    config_data.update_setting(setting2)

    assert config_data.get_setting("foo", None).to_dict() == setting1
    assert config_data.get_setting("foo", {"type": "bla", "name": "bazaar"}).to_dict() == setting2

# Generated at 2022-06-10 22:42:28.061627
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()

    class Plugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class Setting:
        def __init__(self, name):
            self.name = name

    setting = Setting('foo')
    config.update_setting(setting)
    assert config.get_settings()[0].name == 'foo'
    assert config.get_settings()[0] is setting

    setting = Setting('bar')
    config.update_setting(setting, Plugin('c', 'b'))
    assert config.get_settings()[0].name == 'foo'
    assert config.get_settings(Plugin('c', 'b'))[0].name == 'bar'

    setting = Setting('baz')

# Generated at 2022-06-10 22:42:36.452329
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    assert(None == config_data.get_setting('foo'))
    assert(None == config_data.get_setting('foo', 'bar'))

    setting = {'name': 'foo', 'value': 'bar', 'origin': 'ansible.cfg:1'}
    config_data.update_setting(setting)

    assert(setting == config_data.get_setting('foo'))
    assert(setting == config_data.get_setting('foo', 'bar'))


# Generated at 2022-06-10 22:42:43.957760
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    uut = ConfigData()

    # Test global setting
    setting = ConfigSetting("somevar", "somevalue", "someplugin", "somepluginname")
    uut.update_setting(setting)
    assert(uut.get_setting("somevar") == setting)

    # Test setting for plugin
    setting = ConfigSetting("somevar", "somevalue", "someplugin", "somepluginname")
    uut.update_setting(setting, setting.plugin)
    assert(uut.get_setting("somevar", setting.plugin) == setting)


# Generated at 2022-06-10 22:42:55.530228
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    assert config_data.get_setting('defaults') == None
    assert config_data.get_setting('defaults', plugin=None) == None

    class Plugin(object):
        type = 'action'
        name = 'example'

    plugin = Plugin()
    assert config_data.get_setting('defaults', plugin) == None

    class Setting(object):
        name = 'defaults'
        value = 'whatever'

    setting = Setting()
    config_data.update_setting(setting)
    assert config_data.get_setting('defaults') == setting
    assert config_data.get_setting('defaults', plugin) == None

    class Setting(object):
        name = 'defaults'
        value = 'whatever'

    setting = Setting()
    config_data.update_

# Generated at 2022-06-10 22:42:57.673975
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("name1") == None


# Generated at 2022-06-10 22:43:02.031046
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    
    cfg = ConfigData()
    assert cfg.get_settings() == []
    assert cfg.update_setting(None) is None
    assert cfg.update_setting(None, None) is None
    assert cfg.get_settings() == []


# Generated at 2022-06-10 22:43:13.803798
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(dict(name='foo', value='42', plugin=None))
    assert config.get_setting('foo')['value'] == '42'


# Generated at 2022-06-10 22:43:24.912951
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import os
    import sys
    import shutil
    import tempfile
    import types
    import unittest

    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../lib/'))

    from Config import Config
    from ConfigParser import ConfigParser
    from Plugin import Plugin

    class test_ConfigData(unittest.TestCase):

        def setUp(self):

            self.workdir = tempfile.mkdtemp()
            self.config_file = os.path.join(self.workdir, 'config.cfg')
            self.config_content = """[global]
default_content_type = yaml
"""
            self.plugin_dir = os.path.join(self.workdir, 'plugins')

# Generated at 2022-06-10 22:43:33.155313
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin(type='test_type', name='test_name')
    setting = Setting(name='test_setting', value='test_value', scope='test_scope')
    config_data.update_setting(setting)
    assert config_data._global_settings == {'test_setting': setting}
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['test_type']['test_name'] == {'test_setting': setting}


# Generated at 2022-06-10 22:43:38.332928
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('setting1', 'plugin1:plugin1', 'core')
    plugin = Plugin('core', 'plugin1', '/', 'file', False, None)
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['core']['plugin1']['setting1'] == setting

# Generated at 2022-06-10 22:43:48.808596
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data._global_settings["automation_environment"] = [("unit_test", 0)]
    config_data._global_settings["config_file"] = [("toto", 0)]
    config_data._plugins = {"lookup": {"plugin1": {"option_a": [("titi", 0)]}}}

    # Test get_setting without plugin
    assert config_data.get_setting("automation_environment") == [("unit_test", 0)]
    assert config_data.get_setting("config_file") == [("toto", 0)]
    assert config_data.get_setting("unknown") is None

    # Test get_setting with plugin
    plugin = PluginDefinition("lookup", "plugin1")

# Generated at 2022-06-10 22:43:53.504819
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin = Plugin('__test', 'BASIC')
    config = ConfigData()

    assert len(config.get_settings(plugin=plugin)) == 0

    setting = InputSetting('__test', '__test', '__test', None)
    config.update_setting(setting, plugin)
    assert len(config.get_settings(plugin=plugin)) == 1



# Generated at 2022-06-10 22:44:02.735070
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from collections import namedtuple
    from ansible.plugins.loader import PluginLoader
    import ansible.utils.plugin_docs as plugin_docs

    class ConfigSetting(object):
        def __init__(self, name, value, origin, category, short_desc='', long_desc='', version_added='', aliases=[],
                     ini_file=''):
            self.name = name
            self.value = value
            self.origin = origin
            self.category = category
            self.short_desc = short_desc
            self.long_desc = long_desc
            self.version_added = version_added
            self.aliases = aliases
            self.ini_file = ini_file

    Plugin = namedtuple('Plugin', 'name type')
    config_data = ConfigData()
    plugin_loader = PluginLoader()

# Generated at 2022-06-10 22:44:08.749529
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class Setting():
        def __init__(self, name):
            self.name = name

    config_data = ConfigData()
    setting = Setting('a')
    config_data.update_setting(setting)

    assert config_data._global_settings[setting.name] == setting


# Generated at 2022-06-10 22:44:11.576012
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    setting = ConfigSetting("foo","bar")
    data.update_setting(setting);
    assert data.get_setting("foo") == setting


# Generated at 2022-06-10 22:44:19.503758
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert cd._global_settings == {}
    assert cd._plugins == {}
    s = Setting(name='ansible_python_interpreter', section='defaults')
    cd.update_setting(setting=s)
    assert cd._global_settings == {'ansible_python_interpreter': s}
    assert cd._plugins == {}

    p = Plugin(type='action', name='wait_for_connection')
    s = Setting(name='delay', section='action: wait_for_connection')
    cd.update_setting(setting=s, plugin=p)
    assert cd._global_settings == {'ansible_python_interpreter': s}
    assert cd._plugins == {'action': {'wait_for_connection': {'delay': s}}}




# Generated at 2022-06-10 22:44:35.104718
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()

    config.update_setting(Setting(name="foo", value="bar", origin="rabbithole", plugin="rabbit", plugin_type="store"))
    config.update_setting(Setting(name="bar", value="foo", origin="rabbithole", plugin="rabbit", plugin_type="store"))
    assert len(config.get_settings()) == 0
    assert len(config.get_settings(Plugin(name="rabbit", type="store"))) == 2



# Generated at 2022-06-10 22:44:47.953602
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_1 = Setting('setting_1', 'value_1', [], 'description_1')
    config_data.update_setting(setting_1)
    assert config_data.get_setting('setting_1').name == 'setting_1'
    assert config_data.get_setting('setting_1').value == 'value_1'
    assert config_data.get_setting('setting_1').aliases == []
    assert config_data.get_setting('setting_1').description == 'description_1'
    setting_2 = Setting('setting_2', 'value_2', [], 'description_2')
    config_data.update_setting(setting_2)
    assert config_data.get_setting('setting_2').name == 'setting_2'
    assert config_data.get

# Generated at 2022-06-10 22:44:58.030712
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting1 = ConfigSetting(name="setting_1")
    setting2 = ConfigSetting(name="setting_2")
    setting3 = ConfigSetting(name="setting_3")
    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin=Plugin(name="plugin_1", type="type_1"))
    config_data.update_setting(setting3, plugin=Plugin(name="plugin_2", type="type_1"))
    assert sorted(config_data.get_settings(plugin=Plugin(name="plugin_1", type="type_1"))) == [setting2]
    assert sorted(config_data.get_settings(plugin=Plugin(name="non_existing_plugin", type="type_2"))) == []

# Generated at 2022-06-10 22:45:05.250326
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    plugin = Plugin('shell', 'sh')
    plugin.settings.append(PluginSetting('shell-dir', None))

    # Test if config setting not found
    assert None == config_data.get_setting('no-such-setting')

    # Test if config setting auto generated
    setting = PluginSetting('shell-dir', '/etc')
    config_data.update_setting(setting, plugin)
    assert '/etc' == config_data.get_setting('shell-dir', plugin)



# Generated at 2022-06-10 22:45:16.065267
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.config.setting import Setting
    import os
    os.environ["ANSIBLE_CONFIG"] = "../../ansible.cfg"
    os.environ["ANSIBLE_SHELL_TYPE"] = "sh"
    from ansible.config.manager import ConfigManager
    from ansible.config.ansible_config import AnsibleConfig

    config_manager = ConfigManager()
    config_manager._get_base_config_objects(ansible_config_file=AnsibleConfig, config_file="../../ansible.cfg", env_config_file="../../ansible.cfg")
    config_data = config_manager._config_data
    assert len(config_data.get_settings()) == 4032


# Generated at 2022-06-10 22:45:26.347750
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
   # Create ConfigData object
   config_data = ConfigData()

   # Create global setting and plugin setting and update it
   setting_1 = Setting('setting_1')
   config_data.update_setting(setting_1)
   plugin = Plugin('plugin')
   setting_2 = Setting('setting_2')
   config_data.update_setting(setting_2, plugin)

   # Test method get_setting():
   # Expected result: Return 1st global setting
   assert config_data.get_setting('setting_1') == setting_1
   # Expected result: Return None because plugin_2 does not exist
   assert config_data.get_setting('setting_1', Plugin('plugin_2')) == None
   # Expected result: Return plugin setting
   assert config_data.get_setting('setting_2', plugin) == setting_

# Generated at 2022-06-10 22:45:37.837822
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    expected_setting = None

    # Assert no settings are defined in global scope and no plugin type is defined
    assert config_data.get_setting('setting1', plugin=None) == expected_setting
    assert config_data.get_setting('setting2', plugin=None) == expected_setting
    assert config_data.get_setting('setting3', 'plugin1') == expected_setting
    assert config_data.get_setting('setting4', 'plugin1') == expected_setting
    assert config_data.get_setting('setting5', 'plugin1') == expected_setting
    assert config_data.get_setting('setting6', 'plugin2') == expected_setting
    assert config_data.get_setting('setting7', 'plugin2') == expected_setting

# Generated at 2022-06-10 22:45:49.439567
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # case 1: plugin is None, should return global_setting
    mock_setting = Mock(name='setting', value='setting_value')
    config_data._global_settings['setting_name'] = mock_setting
    setting = config_data.get_setting('setting_name')
    assert setting == mock_setting

    # case 2: plugin is not None and exists in ConfigData, should return its setting
    mock_plugin = Mock(name='plugin', type='plugin_type', name='plugin_name')
    mock_setting = Mock(name='setting', value='setting_value')
    config_data.update_setting(mock_setting, mock_plugin)
    setting = config_data.get_setting('setting_name', mock_plugin)
    assert setting == mock_setting

    # case 3: plugin

# Generated at 2022-06-10 22:45:53.647332
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting(name='vault_password_file') == None
    assert config_data.get_setting(plugin=Plugin(name = 'no-plugin', type = 'no-plugin-type'), name = 'no-plugin-setting') == None


# Generated at 2022-06-10 22:46:00.539488
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import ConfigParser
    from ConfigParser import SafeConfigParser
    from config_data import ConfigData, ConfigSetting
    from config_file_parser import ConfigParserSettings

    settings_file = SafeConfigParser()
    settings_file.add_section("DEFAULT")
    settings_file.set("DEFAULT", "log_path", "%(pwd)s/logs")
    settings_file.set("DEFAULT", "host_key_checking", "False")
    #settings_file.add_section("ssh_connection")
    settings_file.set("ssh_connection", "timeout", "10")
    settings_file.set("ssh_connection", "retries", "3")
    settings_file.set("ssh_connection", "control_path", "%(directory)s/%%h-%%r")

# Generated at 2022-06-10 22:46:12.908015
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert config.get_setting("ssh_args") is None
    config.update_setting("Ansible_python_interpreter", "/bin/python3")
    assert get_setting("Ansible_python_interpreter") is not None

# Generated at 2022-06-10 22:46:21.376515
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Arrange
    import ansible.plugins.loader as p
    config_data = ConfigData()
    config_data.update_setting(p.Setting('setting1', 'value1', 'Setting 1'))
    config_data.update_setting(p.Setting('setting1', 'value1', 'Setting 1'), p.get_plugin_by_name('test', 'test_plugin'))

    # Act
    ret = config_data.get_setting('setting1')
    ret2 = config_data.get_setting('setting1', p.get_plugin_by_name('test', 'test_plugin'))

    # Assert
    assert ret == config_data._global_settings['setting1']
    assert ret2 == config_data._plugins['test']['test_plugin']['setting1']



# Generated at 2022-06-10 22:46:31.620426
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
	# initialise ConfigData class
    cd = ConfigData()
    
    # import dependencies
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.file import ConfigLine
    from ansible.module_utils.common.file import ConfigLineParser
    
    # declare an instance of ConfigLineParser
    clp = ConfigLineParser()

    # declare an instance of ConfigLine, using the class method parse. clp is a ConfigLineParser object
    configline_1 = ConfigLine.parse(clp, 'namespace1.namespace2.config_setting = config_value')
    
    # declare an instance of ConfigLine, using the class method parse. clp is a ConfigLineParser object

# Generated at 2022-06-10 22:46:40.237386
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
# Set up the test
    config = ConfigData()
    global_setting1 = Setting("test_name","test_value")
    plugin_setting1 = Setting("test_name","test_value")
    plugin1 = Plugin("test_type","test_name")

    global_setting2 = Setting("test_name2","test_value2")
    plugin_setting2 = Setting("test_name2","test_value2")
    plugin2 = Plugin("test_type2","test_name2")

    config.update_setting(global_setting1)
    config.update_setting(plugin_setting1, plugin1)
    config.update_setting(global_setting1)
    config.update_setting(plugin_setting2, plugin2)
# Run test
    assert config.get_setting("test_name") == global_setting1

# Generated at 2022-06-10 22:46:51.780900
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting1 = Setting("connection", "ssh", "connection", "default", "host", "localhost", "localhost", "default")
    config_data.update_setting(setting1)
    setting2 = Setting("connection", "ssh", "connection", "default", "host", "127.0.0.1", "localhost", "default")
    config_data.update_setting(setting2)
    assert config_data.get_setting("host").value == "127.0.0.1"
    assert config_data.get_setting("host").top_level_name == "localhost"
    assert config_data.get_setting("host").section == "connection"
    assert config_data.get_setting("host").plugin_name == "default"
    assert config_data.get_setting("host").plugin_

# Generated at 2022-06-10 22:46:56.438877
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('a'))
    config_data.update_setting(PluginSetting('a', 'b', 'b'))

    assert config_data._global_settings['a']
    assert config_data._plugins['b']['b']['a']



# Generated at 2022-06-10 22:47:06.279304
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cd.update_setting(Setting("set1", "value1"))
    assert cd._global_settings["set1"].name == "set1"
    assert cd._global_settings["set1"].value == "value1"
    cd.update_setting(Setting("set2", "value2"))
    assert cd._global_settings["set2"].name == "set2"
    assert cd._global_settings["set2"].value == "value2"
    cd.update_setting(Setting("set3", "value3"))
    assert cd._global_settings["set3"].name == "set3"
    assert cd._global_settings["set3"].value == "value3"
    cd.update_setting(Setting("set4", "value4", Plugin("c", "p")))

# Generated at 2022-06-10 22:47:10.981542
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings_data = ConfigData()
    settings_data.update_setting(Setting('name', 'description', 'name', 'default_value'))
    assert settings_data.get_settings() == [{'description': 'description', 'default_value': 'default_value',
                                             'name': 'name', 'value': 'name'}]

# Generated at 2022-06-10 22:47:15.199943
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    from ansible.config.setting import Setting
    from ansible.config.manager import ConfigManager
    cm = ConfigManager()

    setting = Setting('setting1', cm)
    setting.value = 'value1'

    config_data.update_setting(setting)

    assert setting.value == config_data.get_setting(setting.name).value


# Generated at 2022-06-10 22:47:20.672585
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    c.update_setting('something', 'plugin')
    assert len(c._global_settings) == 0
    assert len(c._plugins) == 1
    c.update_setting('something_else')
    assert len(c._global_settings) == 1
    assert len(c._plugins) == 1
    c.get_settings('plugin')
    c.get_settings()

# Generated at 2022-06-10 22:47:43.004019
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0
    assert len(config_data.get_settings(plugin=None)) == 0


# Generated at 2022-06-10 22:47:54.016588
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    cd.update_setting(Setting('TEST_GLOBAL_SETTING', 'TEST_PLUGIN_DEFAULT_VALUE'))
    cd.update_setting(Setting('TEST_MODULE_SETTING', 'TEST_PLUGIN_DEFAULT_VALUE'), Plugin(PluginType.MODULE, 'TEST_MODULE'))
    cd.update_setting(Setting('TEST_CLI_SETTING', 'TEST_PLUGIN_DEFAULT_VALUE'), Plugin(PluginType.CLI, 'TEST_CLI'))

    assert cd.get_setting('TEST_GLOBAL_SETTING').name == 'TEST_GLOBAL_SETTING'

# Generated at 2022-06-10 22:48:01.562343
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin_setting = ConfigData()
    setting = ConfigData()
    setting.name = 'setting.name'
    setting.value = 'setting.value'
    plugin_setting.name = 'plugin_setting.name'
    plugin_setting.value = 'plugin_setting.value'
    global_setting = ConfigData()
    global_setting.name = 'global_setting.name'
    global_setting.value = 'global_setting.value'
    config_data.update_setting(setting)
    config_data.update_setting(plugin_setting, plugin=ConfigData())
    config_data.update_setting(global_setting)
    assert len(config_data.get_settings()) == 2


# Generated at 2022-06-10 22:48:13.862743
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='foo', value='bar')
    config_data.update_setting(setting, plugin=None)
    assert(config_data.get_setting('foo', plugin=None).value == 'bar')
    assert(config_data.get_setting('random_name', plugin=None) == None)
    from collections import namedtuple
    Plugin = namedtuple('Plugin', 'name,type')
    plugin = Plugin('sample_python', 'python')
    config_data.update_setting(setting, plugin=plugin)
    assert(config_data.get_setting('foo', plugin=plugin).value == 'bar')
    assert(config_data.get_setting('random_name', plugin=plugin) == None)



# Generated at 2022-06-10 22:48:18.955457
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    plugin_type = "connection"
    plugin_name = "local"

    config_data = ConfigData()

    plugin = Plugin(plugin_type, plugin_name)
    config_data.update_setting(Setting("command_timeout", "1"))
    config_data.update_setting(Setting("connection_timeout", "2"), plugin)

    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings(plugin)) == 1


# Generated at 2022-06-10 22:48:22.351910
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    global_setting = Setting('fail_on_missing_handler', 'yes')
    config_data.update_setting(global_setting, None)
    assert config_data.get_setting('fail_on_missing_handler', None).value == 'yes'


# Generated at 2022-06-10 22:48:32.410735
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # PluginConfig.type and PluginConfig.name should be None to get global setting
    assert config_data.get_settings() == [] # No setting

    # Set global config value
    config_data.update_setting(Setting('foo', 'foo'))
    config_data.update_setting(Setting('bar', 'bar'))

    assert config_data.get_settings() == [Setting('foo', 'foo'), Setting('bar', 'bar')]

    # Set config value for a plugin
    plugin = PluginConfig('lookup', 'lookup_file')
    config_data.update_setting(Setting('baz', 'baz'), plugin)
    config_data.update_setting(Setting('qux', 'qux'), plugin)


# Generated at 2022-06-10 22:48:43.102479
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    import unittest
    from units.mock.loader import DictDataLoader
    from units.mock.plugins import ansible_plugin, config_plugin


# Generated at 2022-06-10 22:48:54.246056
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Create ConfigData object
    c1 = ConfigData()

    from ansible_collections.ibm.ibm_zos_core.plugins.module_utils.config.setting import Setting
    # Create setting objects
    s1 = Setting(name='CONNECTION', value='SSH')
    s2 = Setting(name='PLAYBOOK_PATH', value='test/test_data/test_playbook.yml')

    # Update global setting
    c1.update_setting(s1)
    # Update plugin setting
    c1.update_setting(s2, plugin=s2.plugin)

    # Check the updated settting list
    assert len(c1._global_settings) == 1
    assert len(c1._plugins) == 1
    assert len(c1._plugins['PLAYBOOK']) == 1

# Generated at 2022-06-10 22:49:05.215783
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()

    class Setting:
        def __init__(self, name, origin, origin_type, default, value, plugin=None):
            self.name = name
            self.origin = origin
            self.origin_type = origin_type
            self.default = default
            self.value = value
            self.plugin = plugin

    class Plugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    plugin_one = Plugin(type="connection", name="local")
    plugin_two = Plugin(type="connection", name="ssh")
    plugin_three = Plugin(type="connection", name="network_cli")

    config.update_setting(Setting('hostname', "env.HOSTNAME", "env", "localhost", "localhost"), plugin_one)
   

# Generated at 2022-06-10 22:49:28.063884
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    config_data.update_setting(Setting(name='one', value=1))
    config_data.update_setting(Setting(name='two', value=2))

    # validation
    assert config_data._global_settings['one'].name == 'one'
    assert config_data._global_settings['one'].value == 1
    assert config_data._global_settings['two'].name == 'two'
    assert config_data._global_settings['two'].value == 2


# Generated at 2022-06-10 22:49:38.888945
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansiblelint.config import ConfigData, Setting

    data = ConfigData()
    data.update_setting(Setting('s1', 's1'))
    data.update_setting(Setting('s1', 's1', 'p1'))
    data.update_setting(Setting('s2', 's2', 'p1'))
    data.update_setting(Setting('s1', 's1', 'p2'))

    assert len(data.get_settings()) == 1
    assert data.get_settings()[0].name == 's1'
    assert len(data.get_settings('p1')) == 2
    assert data.get_settings('p1')[0].name == 's1'
    assert data.get_settings('p1')[1].name == 's2'

# Generated at 2022-06-10 22:49:49.069311
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    config_data.update_setting(Setting("command_timeout", "20", "integer"))
    config_data.update_setting(Setting("become_user", "sde", "string"))
    config_data.update_setting(Setting("fact_cache_time", "30", "integer"))
    config_data.update_setting(Setting("fact_caching", "redis", "string"))
    config_data.update_setting(Setting("host_key_auto_add", "False", "boolean"))

    assert len(config_data.get_settings()) == 5
    for setting in config_data.get_settings():
        if setting.name == "command_timeout" and setting.value == "20" and setting.setting_type == "integer":
            assert True

# Generated at 2022-06-10 22:49:57.900168
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.connection import ConnectionBase
    from ansible.vars.manager import VariableManager
    import copy

    def make_config_data():
        config_data = ConfigData()
        config_data.update_setting(Setting('host_key_checking', 'True', 'default'))
        config_data.update_setting(Setting('retry_files_enabled', 'True', 'default'))
        config_data.update_setting(Setting('host_key_checking', 'True', 'ssh'))
        config_data.update_setting(Setting('retries', '5', 'ssh'))
        return config_data

    def make_source_host_with_config_data(config_data):
        source_host = ConnectionBase()

# Generated at 2022-06-10 22:50:09.614387
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Arrange
    from ansible.plugins import collection_loader
    from ansible.executor.simple_task_queue import PluginTask
    from ansible.config.setting import Setting
    from ansible.config.constants import DEFAULTS
    from ansible.module_utils.common._collections_compat import MutableMapping
    import os
    import sys

    sys.modules['collection_loader'] = collection_loader
    sys.modules['ansible.plugins.loader'] = collection_loader

    NEED_ROOT_PLUGIN_PATH = DEFAULTS.get_config_file_path('ansible.cfg')

    config_data = ConfigData()

    global_settings = {}
    plugin_settings = {}
    plugin_settings['collection_loader'] = {}

# Generated at 2022-06-10 22:50:13.351903
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    
    test_config = ConfigData()
    test_setting = Setting(name='test', plugin=None, value='value')
    test_config.update_setting(test_setting)
    assert(test_config.get_setting('test').value == 'value')


# Generated at 2022-06-10 22:50:16.259350
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = ConfigSetting("INDENT", "TEST", "TEST", "TEST")
    config_data.update_setting(setting)
    assert(config_data._global_settings["INDENT"] == setting)


# Generated at 2022-06-10 22:50:26.268657
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from importlib import import_module
    from pathlib import Path

    from ansible.plugins.loader import plugin_loader
    from ansible.plugins.connection import ConnectionBase, DATA_CONNECTION_PATH

    plugin_loader.add_directory(Path('tests/unit/plugins'))

    # Add a dummy connection plugin
    plugin_loader.add_directory(DATA_CONNECTION_PATH)
    foo_connection_module = import_module('ansible.plugins.connection.foo')
    foo_connection_class = getattr(foo_connection_module, 'Connection')
    ConnectionBase.register('foo', foo_connection_class)

    # Add a dummy module plugin
    module_plugin_module = import_module('ansible.plugins.test_module_plugin')