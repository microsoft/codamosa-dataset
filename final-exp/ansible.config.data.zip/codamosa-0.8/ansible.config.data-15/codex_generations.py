

# Generated at 2022-06-10 22:40:30.875796
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    DATA = ConfigData()
    DATA.update_setting(Setting())



# Generated at 2022-06-10 22:40:42.384856
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()

    # test with null plugin
    setting = configData.get_setting("some_setting")
    assert setting is None

    from ConfigParser import ConfigParser
    from ConfigParser import NoOptionError

    from ansible.plugins.loader import get_all_plugin_loaders
    for loader_name, loader_type, _ in get_all_plugin_loaders():

        plugin_type = loader_name
        paths = loader_type._get_paths("")
        parser = ConfigParser()
        plugin_configs = []
        for path in paths:
            found = parser.read(path)
            for plugin_config in found:
                plugin_configs.append(plugin_config)
                for section in parser.sections():
                    plugin_name = section.split(":", 1)[1]
                    plugin = Plugin

# Generated at 2022-06-10 22:40:50.124999
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # create config data
    config_data = ConfigData()

    # set the setting
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import text_type
    from ansible.plugins.setting import Setting
    setting = Setting(name="VAR",
                      default="/etc/ansible/hosts")
    setting._data = ImmutableDict(value=text_type,
                                  origin="/etc/ansible/ansible.cfg")
    config_data.update_setting(setting)

    # get the setting
    var = config_data.get_setting("VAR")
    assert var.value == setting.value
    assert var.origin == setting.origin


# Generated at 2022-06-10 22:40:55.874341
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin = None
    config_data = ConfigData()
    config_data.update_setting(Setting_1(), plugin)
    assert config_data.get_setting("setting_1") == Setting_1()

    plugin = Plugin(TYPE_FILTER, "filter_1")
    config_data.update_setting(Setting_2(), plugin)
    assert config_data.get_setting("setting_2", plugin) == Setting_2()


# Generated at 2022-06-10 22:41:04.905956
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(Setting("test_name", "test_value", "test_plugin_type", "test_plugin_name"))
    assert len(config._global_settings) == 0
    assert len(config._plugins) == 1
    assert len(config._plugins["test_plugin_type"]) == 1
    assert len(config._plugins["test_plugin_type"]["test_plugin_name"]) == 1
    assert config._plugins["test_plugin_type"]["test_plugin_name"]["test_name"].name == "test_name"
    assert config._plugins["test_plugin_type"]["test_plugin_name"]["test_name"].value == "test_value"


# Generated at 2022-06-10 22:41:10.405940
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(Setting("consoles", "vsphere_console_password", "test1"))
    assert config.get_setting("consoles", None).name == "consoles"
    assert config.get_setting("shell", None) is None
    assert config.get_setting("shell", Plugin(name="connection", type="connection")) is None

# Generated at 2022-06-10 22:41:21.056684
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    #test 1.
    assert config_data.get_settings(plugin=None) == []

    #test 2.
    assert config_data.get_settings(plugin=[]) == []

    #test 3.
    config_data.update_setting(setting={}, plugin=[])
    assert config_data.get_settings(plugin=None) == []

    #test 4.
    config_data.update_setting(setting={}, plugin=[])
    assert config_data.get_settings(plugin='a') == []

    #test 5.
    config_data.update_setting(setting={}, plugin='a')
    assert config_data.get_settings(plugin='a') == [{}]


# Generated at 2022-06-10 22:41:26.179237
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    class Setting(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value
    s = Setting('fqdn', 'abc.example.com')
    config.update_setting(s)
    assert config.get_setting(s.name) == s
    assert config.get_settings() == [s]


# Generated at 2022-06-10 22:41:29.350576
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name="Debug",
                      value="on")
    config_data.update_setting(setting)
    assert (setting in config_data.get_settings())


# Generated at 2022-06-10 22:41:35.815167
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.action.AddRepository import AddRepository
    from ansible.plugins.action.DeleteRepository import DeleteRepository
    from ansible.plugins.action.DisableRepository import DisableRepository
    from ansible.plugins.action.EnableRepository import EnableRepository

    config_data = ConfigData()
    plugin = AddRepository(None, None)
    config_data.update_setting(fragment_loader.get_fragment('settings', 'addrepository.url'), plugin)
    assert(len(config_data.get_settings(plugin)) == 1)

    plugin = DeleteRepository(None, None)

# Generated at 2022-06-10 22:41:53.499616
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting1 = {'name': 'foo', 'value': 'bar'}
    setting2 = {'name': 'ansible', 'value': 'is', 'plugin': {'type': 'type', 'name': 'name'}}
    setting3 = {'name': 'awesome', 'value': '!!'}

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting3)

    assert config_data._global_settings['foo'] == setting1
    assert config_data._plugins['type']['name']['ansible'] == setting2
    assert config_data._global_settings['awesome'] == setting3


# Generated at 2022-06-10 22:41:58.814509
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    assert isinstance(c, ConfigData)

    d = c.get_settings()
    assert isinstance(d, list)
    assert d == []

    d = c.get_settings(plugin=None)
    assert isinstance(d, list)
    assert d == []


# Generated at 2022-06-10 22:42:07.949804
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test the method when an instance of Setting is passed
    # with no plugins to ConfigData
    global_setting = Setting("test_setting", "test_value")
    config_data = ConfigData()
    config_data.update_setting(global_setting)

    assert config_data._global_settings["test_setting"] is global_setting

    # Test the method when an instance of Setting is passed
    # with plugins to ConfigData
    plugin = Plugin("test_plugin", "test_type")
    plugin.config_dir = None
    plugin.config_file = None

    plugin_setting = Setting("test_setting", "test_value")
    config_data.update_setting(plugin_setting, plugin)

    assert config_data._plugins["test_type"]["test_plugin"]["test_setting"] is plugin_setting

#

# Generated at 2022-06-10 22:42:14.227959
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    cd._global_settings = {'color' : 'red'}
    cd._plugins = {'callback': {'debug' : {'color' : 'blue'}}}

    assert cd.get_setting('color') == 'red'
    assert cd.get_setting('color', 'debug') == 'blue'

    assert cd.get_setting('color', 'test') is None
    assert cd.get_setting('test') is None

# Generated at 2022-06-10 22:42:22.970415
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert config_data.get_settings() == []

    config_data.update_setting(Setting("a", "b"))
    config_data.update_setting(Setting("d", "e"))
    config_data.update_setting(Setting("f", "g"), Plugin("c", "d"))

    assert config_data.get_settings() == [{'a': 'b'}, {'d': 'e'}]
    assert config_data.get_settings(Plugin("c", "d")) == [{'f': 'g'}]



# Generated at 2022-06-10 22:42:26.980246
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    plugin_type = 'connection'
    plugin_name = 'local'
    plugin = Plugin(plugin_type, plugin_name)
    config_data = ConfigData()
    actual = config_data.get_setting('host', plugin)
    assert actual is None


# Generated at 2022-06-10 22:42:39.782730
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from collections import namedtuple
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from lib.config import ConfigManager

    plugin = namedtuple('plugin', ['type', 'name'])
    plugin_type = plugin(type='my_type', name='my_name')
    global_setting = namedtuple('setting', ['name', 'value'])
    setting = global_setting(name='key1', value=1)

    config_manager = ConfigManager()
    config_manager._unfrackpath = mock_unfrackpath_noop

    data_loader = DictDataLoader({
        "my_type": {
            "my_name": {
                "key1": "1"
            }
        }
    })

    config

# Generated at 2022-06-10 22:42:42.953480
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    data = ConfigData()

    setting1 = {'name': 'foo', 'plugin': 'bar'}
    setting2 = {'name': 'foo', 'plugin': 'baz'}

    data.update_setting(setting1)
    data.update_setting(setting2)

    assert data.get_setting('foo') == setting1
    assert data.get_setting('foo', 'bar') == setting1
    assert data.get_setting('foo', 'baz') == setting2

# Generated at 2022-06-10 22:42:47.511436
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    cfg = ConfigData()

    # build a test setting
    s = Setting()
    s.name = "test"
    s.default = 0
    s.type = "int"
    s.scope = "global"
    s.description = "this is a test setting"

    cfg.update_setting(s)

    assert cfg.get_setting("test") == s
    assert cfg.get_setting("test2") == None


# Generated at 2022-06-10 22:42:58.609017
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import plugin_loader

    config_data = ConfigData()

    for p in plugin_loader.all(class_only=True):

        for s in p.get_settings():
            config_data.update_setting(s, p)

    assert config_data.get_setting('allow_duplicates') is not None
    assert config_data.get_setting('allow_duplicates', plugin_loader.get('cache_plugin')) is None
    assert config_data.get_setting('cache_connection', plugin_loader.get('connection_plugin')) is not None
    assert config_data.get_setting('cache_connection', plugin_loader.get('vars_plugin')) is None

    assert len(config_data.get_settings()) == len(plugin_loader.get_all_settings())
   

# Generated at 2022-06-10 22:43:11.397449
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Case 1 - Get global setting
    config_data = ConfigData()
    mock_setting = MockSetting(name="a", value="a")
    config_data.update_setting(mock_setting)
    result = config_data.get_setting("a")
    assert result == mock_setting

    # Case 2 - Get plugin setting
    config_data = ConfigData()
    mock_plugin = MockPlugin(type="connection_plugins", name="a")
    mock_setting = MockSetting(name="a", value="a")
    config_data.update_setting(mock_setting, mock_plugin)
    result = config_data.get_setting("a", mock_plugin)
    assert result == mock_setting


# Generated at 2022-06-10 22:43:15.336004
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('a', 'b'))
    assert config_data.get_setting('a') is not None


# Generated at 2022-06-10 22:43:16.573517
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    pass


# Generated at 2022-06-10 22:43:26.206012
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting1 = Setting(name='setting1')
    setting2 =  Setting(name='setting2', value='value2')
    setting3 =  Setting(name='setting3', value='value3')

    plugin1 = Plugin(type='plugin_type1', name='plugin1')
    plugin2 = Plugin(type='plugin_type2', name='plugin2')

    config_data = ConfigData()
    config_data.update_setting(setting1)
    assert config_data._global_settings[setting1.name] == setting1

    config_data.update_setting(setting2, plugin1)
    config_data.update_setting(setting3, plugin2)
    assert config_data._plugins[plugin1.type][plugin1.name][setting2.name] == setting2

# Generated at 2022-06-10 22:43:38.018250
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()

    config.update_setting(dict(name='setting1', plugin=None, value='value1', origin='ansible.cfg'))
    config.update_setting(dict(name='setting1', plugin=dict(name='ssh', type='connection'), value='value1', origin='ansible.cfg'))
    config.update_setting(dict(name='setting2', plugin=dict(name='gather-facts', type='strategy'), value='value2', origin='ansible.cfg'))

    result = config.get_setting('setting1')
    assert result.name == 'setting1' and result.value == 'value1'
    result = config.get_setting('setting1', dict(type='connection', name='ssh'))
    assert result.name == 'setting1' and result.value == 'value1'

# Generated at 2022-06-10 22:43:45.089416
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansiblite.plugins.action.normal import ActionModule as AnsibleNormalActionModule
    from ansiblite.vars.manager import VariableManager
    from ansiblite.config.manager import ConfigManager
    from ansiblite.config.data import ConfigData
    from ansiblite.utils.plugin_docs import get_docstring
    import ansiblite.plugins.action
    import ansiblite.plugins.lookup

    config_data = ConfigData()

    # add some settings
    # result = None
    # exception = None
    # try:
    #     result = config_data.get_settings()
    # except Exception as ex:
    #     exception = ex
    # assert result is None
    # assert exception is None

    # add some settings

# Generated at 2022-06-10 22:43:53.622388
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    new_setting = Setting('new_setting', 'new_value')
    config_data.update_setting(new_setting)
    assert config_data.get_setting('new_setting', None) == new_setting
    assert config_data.get_setting('new_setting', Plugin('connection', 'local')) is None

    plugin = Plugin('connection', 'local')

    new_setting = Setting('new_setting', 'new_value')
    config_data.update_setting(new_setting, plugin)
    assert config_data.get_setting('new_setting', plugin) == new_setting
    assert config_data.get_setting('new_setting', None) is None


# Generated at 2022-06-10 22:43:59.348307
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Testing update_setting:
    configData = ConfigData()
    assert configData.get_setting('setting1', None) == None
    assert configData.get_setting('setting1', 'plugin1') == None
    assert configData.get_setting('setting1', 'plugin2') == None

    setting1 = Setting()
    setting1.name = 'setting1'
    setting1.plugin = 'plugin1'
    setting1.value = 'value1'
    configData.update_setting(setting1)
    assert configData.get_setting('setting1', None) == None
    assert configData.get_setting('setting1', 'plugin1') != None
    assert configData.get_setting('setting1', 'plugin1').value == 'value1'

# Generated at 2022-06-10 22:44:10.185675
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Test get_setting of class ConfigData with a global setting
    setting = ConfigSetting(name='ansible_redis_host')
    config_data.update_setting(setting)

    assert config_data.get_setting(name='ansible_redis_host') == setting

    # Test get_setting of class ConfigData with a plugin setting
    setting = ConfigSetting(name='ansible_redis_host')
    plugin = ConfigPlugin(type='cache', name='redis')
    config_data.update_setting(setting, plugin)

    assert config_data.get_setting(name='ansible_redis_host', plugin=plugin) == setting



# Generated at 2022-06-10 22:44:12.412768
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    print(cd)


if __name__ == '__main__':
    test_ConfigData_update_setting()

# Generated at 2022-06-10 22:44:24.860858
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

    plugin = Plugin(None, 'test', 'foo')

    config_data = ConfigData()
    assert config_data.get_settings(plugin) == []

    plugin_setting = PluginSetting(None, 'bar')
    config_data.update_setting(plugin_setting, plugin)

    plugin_settings = config_data.get_settings(plugin)
    assert len(plugin_settings) == 1
    assert isinstance(plugin_settings[0], PluginSetting)


# Generated at 2022-06-10 22:44:29.689527
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    if hasattr(config_data, "update_setting"):
        if callable(config_data.update_setting):
            print("Callable method 'update_setting' of class 'ConfigData'")


# Generated at 2022-06-10 22:44:35.991106
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.config.setting import Setting

    cd = ConfigData()

    print("Test 1: update_setting()")
    setting = Setting('ANSIBLE_CONFIG_FILE', '/etc/ansible/ansible.cfg', 'Overrides ANSIBLE_CONFIG_FILE env var using a path to an alternate ansible config file')
    print("  Setting: \"{}\"\n".format(setting))
    cd.update_setting(setting)
    print("    Global settings: \"{}\"\n".format(cd.get_settings()))

    print("Test 2: update_setting()")
    setting = Setting('max_fail_percentage', 50, 'Integer value representing the threshold at which to abort a playbook run.')
    print("  Setting: \"{}\"\n".format(setting))

# Generated at 2022-06-10 22:44:47.450667
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    mocked_setting_1 = Setting('test_setting_1_name', 'test_setting_1_description', 'test_setting_1_value', False)
    mocked_plugin = Plugin('test_plugin_type', 'test_plugin_name', 'test_plugin_version', 'test_plugin_requirements')
    config_data.update_setting(mocked_setting_1, mocked_plugin)
    config_data.update_setting(mocked_setting_1)

    settings = config_data.get_settings()
    plugins = config_data.get_settings(mocked_plugin)

    assert len(settings) == 2
    assert len(plugins) == 1


# Generated at 2022-06-10 22:44:57.657962
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    from ansible.cli import CLI
    from ansible.config.setting import Setting
    from ansible.config.setting_plugin import SettingPlugin
    from ansible.config.setting_collection import SettingCollection

    category = "DEFAULT"
    option = "foo"
    value = "bar"
    default = "baz"

    # test global settings
    setting = Setting(category, option, value, default)
    config.update_setting(setting)
    assert config.get_setting(option) == setting

    # test collection
    collection = SettingCollection("collection1", "collection.ini")
    setting = Setting(category, option, value, default)
    collection.append(setting)
    assert collection.get_setting(option) == setting

    # test plugin

# Generated at 2022-06-10 22:45:08.747388
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    class TestSetting:
        def __init__(self, name):
            self.name = name

    setting_var_name = TestSetting('var_name')
    setting_pref_name = TestSetting('pref_name')

    class TestPlugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    plugin_var = TestPlugin('var', 'filesystem')
    plugin_pref = TestPlugin('prefs', 'secret')

    config_data.update_setting(setting_var_name, plugin=plugin_var)
    config_data.update_setting(setting_pref_name, plugin=plugin_pref)

    assert config_data.get_setting('var_name', plugin=plugin_var) == setting_var

# Generated at 2022-06-10 22:45:10.616819
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cs = ('red', 'green')
    print(cd.get_setting('color'))

# Generated at 2022-06-10 22:45:18.433590
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import plugin_loader

    from ansible.config.setting import Setting

    data = ConfigData()
    assert (len(data.get_settings()) == 0)

    data.update_setting(Setting('setting1', 'setting1', 'setting1', 'setting1', 'setting1'))
    assert (len(data.get_settings()) == 1)

    data.update_setting(Setting('setting2', 'setting2', 'setting2', 'setting2', 'setting2'))
    assert (len(data.get_settings()) == 1)

    group = plugin_loader.get('group')
    user = plugin_loader.get('user')

    assert (len(data.get_settings(group)) == 0)

# Generated at 2022-06-10 22:45:23.590102
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    s = ConfigSetting("fact_caching", "memory")
    cd.update_setting(s)

    settings = cd.get_settings()
    assert settings[0].name == 'fact_caching'
    assert settings[0].value == 'memory'


# Generated at 2022-06-10 22:45:27.969872
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    s = Setting('new_setting', 'test', 'test', 'test')
    c.update_setting(s)
    assert c._global_settings['new_setting'] == s


# Generated at 2022-06-10 22:45:40.137195
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting = Setting('ansible_connection', 'network_cli', '/home/ansible/.ansible/tmp/ansible-tmp-1518653527.85-100045150063473/AnsiballZ_command.py')
    config_data = ConfigData()
    config_data.update_setting(setting)
    print(setting)
    print(config_data.get_setting(setting.name))
    assert config_data.get_setting(setting.name) == setting




# Generated at 2022-06-10 22:45:45.158156
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    conf = ConfigData()
    setting = Setting("test_setting")
    conf.update_setting(setting)
    assert conf.get_setting("test_setting") == setting
    try:
        conf.get_setting("wrong_setting")
        assert False, "Should have raised"
    except KeyError:
        assert True


# Generated at 2022-06-10 22:45:54.141638
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansiblelint import RuleCollection
    cd = ConfigData()
    cd.update_setting({"name": "here_you_go", "value": "foo"}, RuleCollection("mock_name"))
    assert cd.get_setting("here_you_go", RuleCollection("mock_name")) == {"name": "here_you_go", "value": "foo"}
    assert cd.get_setting("here_you_go") is None
    cd.update_setting({"name": "here_you_go", "value": "foo"})
    assert cd.get_setting("here_you_go") == {"name": "here_you_go", "value": "foo"}

# Generated at 2022-06-10 22:45:56.053490
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("setting")
    config_data.update_setting("setting")
    config_data.update_setting("setting", "plugin")
    config_data.update_setting("setting", "plugin")

# Generated at 2022-06-10 22:45:57.908674
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting(name='core_1') == None

# Generated at 2022-06-10 22:46:01.124179
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    #add a setting
    setting = ConfigSetting(name='color', value='blue')
    config_data.update_setting(setting)

    setting = config_data.get_setting('color')
    assert setting.name == 'color'


# Generated at 2022-06-10 22:46:11.656269
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Create object ConfigData
    config_data = ConfigData()

    # Create object Setting with name 'key1' and value 'value1'
    setting1 = Setting(key1, value1)
    # Create object Setting with name 'key2' and value 'value2'
    setting2 = Setting(key2, value2)

    # Update setting1 in ConfigData
    config_data.update_setting(setting1)
    # Update setting2 in ConfigData
    config_data.update_setting(setting2)

    # Assert method get_setting with param setting1.name return setting1
    assert config_data.get_setting(setting1.name) == setting1
    # Assert method get_setting with param setting2.name return setting2
    assert config_data.get_setting(setting2.name) == setting2

# Generated at 2022-06-10 22:46:15.115269
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    g = ConfigData()
    setting1 = {'name': 'setting1', 'value': 1, 'origin': 'defaults', 'plugin': None}
    g.update_setting(setting1)

    assert g.get_setting('setting1') == setting1

# Generated at 2022-06-10 22:46:26.779610
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Unit test for method get_settings with no plugin
    def get_settings_without_plugin(config_data):
        return config_data.get_settings()

    # Unit test for method get_settings with plugin of type 'lookup' and name 'dict'
    def get_settings_with_plugin(config_data):
        from ansible.plugins.loader import lookup_loader
        plugin = lookup_loader.get('dict')
        return config_data.get_settings(plugin=plugin)

    print(get_settings_without_plugin(config_data))
    print(get_settings_with_plugin(config_data))


if __name__ == '__main__':
    test_ConfigData_get_settings()

# Generated at 2022-06-10 22:46:28.632875
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    cfg_data = ConfigData()
    assert len(cfg_data.get_settings()) == 0, 'test_ConfigData_get_settings: get_settings(plugin=None) failed'




# Generated at 2022-06-10 22:46:48.287073
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from units.compat import unittest
    from units.compat.mock import patch, MagicMock
    from ansible.module_utils import basic

    import ansible.module_utils.config as config_utils
    from ansible.errors import AnsibleOptionsError

    MOCK_PLUGIN = MagicMock()

    class TestConfigDataGetSetting(unittest.TestCase):

        def setUp(self):
            self.config_data = config_utils.ConfigData()
            self.config_data._global_settings['bar'] = ''
            self.config_data._plugins['foo'] = MagicMock()
            self.config_data._plugins['foo']['bar'] = MagicMock()
            self.config_data._plugins['foo']['bar']['baz'] = ''


# Generated at 2022-06-10 22:46:52.315328
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test_object = ConfigData()
    test_object.update_setting(Setting(name='abc', value='cde'))
    assert test_object.get_setting('abc') is not None

#Unit test for method get_settings of class ConfigData

# Generated at 2022-06-10 22:47:00.924464
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # create a config data object
    config_data = ConfigData()

    # create some settings
    from collections import OrderedDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping

    s1 = ConfigValue(name='password', value="foo", plugin_type=None, plugin_name=None, category='Connection')
    s2 = ConfigValue(name="connection", value="netconf", plugin_type="connection", plugin_name="netconf", category='Connection')
    s3 = ConfigValue(name="host", value="localhost", plugin_type="inventory", plugin_name="hosts", category='Connection')
    s4 = ConfigValue(name="port", value=8, plugin_type="inventory", plugin_name="hosts", category='Connection')



# Generated at 2022-06-10 22:47:11.224981
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.modules.config_data import ConfigData
    from ansible.modules.config_data import Setting
    from ansible.module_utils._text import to_text

    plugin = None
    json_str = None

    # Test with global settings
    cd = ConfigData()
    plugin = None
    s = Setting(constant=10, name="ansible_test_plugin_default")
    cd.update_setting(s, plugin)
    s = Setting(name="ansible_test_plugin_default", default="ansible_test_plugin_default_value")
    cd.update_setting(s, plugin)
    s = Setting(name="ansible_test_plugin", default="ansible_test_plugin_value")
    cd.update_setting(s, plugin)

# Generated at 2022-06-10 22:47:14.611601
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test exception:
    # Get a setting that does not exists.
    cd = ConfigData()
    p1 = Plugin('collections', 'my_collection')
    assert cd.get_setting('my_setting', plugin=p1) is None
    assert cd.get_setting('my_setting') is None



# Generated at 2022-06-10 22:47:22.907396
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    set1 = Setting('set1', 'hello', ConfigData.STRING_TYPE, None, None, False)
    config_data.update_setting(set1)
    set_type = config_data.get_setting('set1')
    assert set_type.name == 'set1'
    assert set_type.value == 'hello'
    assert set_type.type == ConfigData.STRING_TYPE
    assert set_type.default == None
    assert set_type.scope == None
    assert set_type.secret == False


# Generated at 2022-06-10 22:47:31.356275
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Test get_setting when no setting is present in the config data
    config_data = ConfigData()
    setting = config_data.get_setting("ANSIBLE_CALLBACK_WHITELIST")
    assert setting is None

    # Test get_setting when global setting is present
    config_data.update_setting(ConfigSetting(
        name="ANSIBLE_CALLBACK_WHITELIST", value="json,yaml,minimal"))
    setting = config_data.get_setting("ANSIBLE_CALLBACK_WHITELIST")
    assert setting.name == "ANSIBLE_CALLBACK_WHITELIST"
    assert setting.value == "json,yaml,minimal"
    assert setting.plugin == None

    # Test get_setting when plugin setting is present

# Generated at 2022-06-10 22:47:41.144722
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print("Running Unit Test: ConfigData.update_setting")
    plugin_type = 'action'
    plugin_name = 'debug'
    setting_name = 'connection'
    setting_value = 'local'
    setting_priority = 1
    setting_plugin = Plugin(plugin_type,plugin_name)
    setting = Setting(setting_name,setting_value,setting_priority,setting_plugin)

    config_data = ConfigData()
    config_data.update_setting(setting,setting_plugin)

    assert config_data._plugins[plugin_type][plugin_name][setting_name].name == setting.name
    assert config_data._plugins[plugin_type][plugin_name][setting_name].value == setting.value
    assert config_data._plugins[plugin_type][plugin_name][setting_name].priority == setting.priority


# Generated at 2022-06-10 22:47:52.986530
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting1 = ConfigSetting('credentials_plugins', 'winrm', ['kerberos', 'plaintext'], 'description1')
    plugin1 = ConfigPlugin('cache', 'jsonfile')
    config_data.update_setting(setting1, plugin1)
    assert config_data.get_setting('credentials_plugins', plugin1) == ['kerberos', 'plaintext']
    setting2 = ConfigSetting('connection_plugins', 'winrm', ['kerberos', 'plaintext'], 'description2')
    plugin2 = ConfigPlugin('cache', 'jsonfile2')
    config_data.update_setting(setting2, plugin2)
    assert config_data.get_setting('connection_plugins', plugin2) == ['kerberos', 'plaintext']
    assert config_data.get_setting

# Generated at 2022-06-10 22:47:58.403069
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()

    tmp = ConfigSetting('name', 'value')
    data.update_setting(tmp)
    assert data.get_setting('name').name == 'name', \
        "Expected to find setting 'name' in global settings"

    tmp = ConfigSetting('name', 'value')
    plugin = ConfigPlugin('type', 'name')
    data.update_setting(tmp, plugin)
    assert data.get_setting('name', plugin).name == 'name', \
        "Expected to find setting 'name' in plugin 'type.name'"



# Generated at 2022-06-10 22:48:19.963558
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config = Config()
    config.name = 'test'
    setting = Setting()
    setting.name = 'testname'
    setting.value = 'testvalue'
    config_data.update_setting(setting, config)
    assert(config_data.get_settings(config)[0].value == 'testvalue')


# Generated at 2022-06-10 22:48:26.238213
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin_type = 'lookup'
    plugin_name = 'env'
    setting_name = 'key'
    setting_value = 'default'

    plugin = Plugin(plugin_type, plugin_name)

    setting = Setting(setting_name, setting_value)

    config_data.update_setting(setting, plugin)

    assert config_data._plu

# Generated at 2022-06-10 22:48:36.756008
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    from ansible.plugins.loader import PluginLoader

    test_plugin_type = 'test_plugin_type'
    test_plugin_name = 'test_plugin_name'
    test_plugin_class = 'TestPluginClass'

    test_plugin = PluginLoader.load_plugin(test_plugin_type, test_plugin_name, test_plugin_class)

    test_plugin_setting_names = ['test_plugin_setting_name_1', 'test_plugin_setting_name_2', 'test_plugin_setting_name_3']

    for test_plugin_setting_name in test_plugin_setting_names:
        from ansible.config.setting import Setting

        test_setting = Setting(name=test_plugin_setting_name)

# Generated at 2022-06-10 22:48:38.111246
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    assert config_data.get_settings() == []

# Generated at 2022-06-10 22:48:46.694985
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()

    class Plugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class Setting:
        def __init__(self, name, runtime=False):
            self.name = name
            self.runtime = runtime

    foo_setting = Setting('foo')

    config.update_setting(foo_setting)

    # Test case where no plugin is defined
    assert foo_setting == config.get_setting('foo')
    assert None == config.get_setting('bar')

    # Test case where a plugin is defined
    foo_plugin = Plugin('foo', 'bar')

    foo_plugin_setting = Setting('foo')
    bar_plugin_setting = Setting('bar')

    config.update_setting(foo_plugin_setting, foo_plugin)
   

# Generated at 2022-06-10 22:48:58.732382
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin_type = "role"
    plugin_name = "ansible.ssh_users"
    setting_name = "foo"
    setting_default = "bar"

    setting = Setting(setting_name, setting_default)

    config_data.update_setting(setting)

    setting = Setting(setting_name, setting_default)

    config_data.update_setting(setting, plugin_type, plugin_name)

    setting = config_data.get_setting(setting_name)
    assert setting is not None
    assert setting.name == setting_name
    assert setting.default == setting_default

    setting = config_data.get_setting(setting_name, plugin_type, plugin_name)
    assert setting is not None
    assert setting.name == setting_name
    assert setting.default

# Generated at 2022-06-10 22:49:03.959796
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting("test", "global test setting", "test_value"))
    result = config_data.get_setting('test')
    assert result.name == "test"
    assert result.value == "test_value"
    assert result.description == "global test setting"
    assert result.plugin is None



# Generated at 2022-06-10 22:49:05.951084
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    
    print('config_data.get_setting(name) = ' + repr(config_data.get_setting('name')))


# Generated at 2022-06-10 22:49:17.781388
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblelint.helper import Plugin
    from ansiblelint.rules import RulesCollection
    from ansiblelint.rules import RulesCollectionMatch
    from ansiblelint.rules.Indentation import Indentation

    configData = ConfigData()
    plugin = Plugin(5, 'Indent', type='rules')
    setting = RulesCollectionMatch(Indentation(None, None, None, None), RulesCollection('', [], []), [], [])
    configData.update_setting(setting, plugin)
    setting = RulesCollectionMatch(Indentation(None, None, {'nested': 4}, None), RulesCollection('', [], []), [], [])
    configData.update_setting(setting, plugin)
    plugin = Plugin(5, 'Indent', type='playbook')


# Generated at 2022-06-10 22:49:24.929914
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # setup expected result from mocked methods and init class
    expected_result = ConfigSetting('boolean_test_setting', 'BOOL', True)
    config_data.update_setting(expected_result)

    # get actual result from method get_setting of class ConfigData
    actual_result = config_data.get_setting('boolean_test_setting')

    # assert if result is expected
    assert expected_result is actual_result

# Generated at 2022-06-10 22:50:15.749348
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

# Generated at 2022-06-10 22:50:19.917439
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin = PluginType('module', 'test-module')
    setting = Setting('test-test', 'Testing', 'test', 'string', plugin)
    config = ConfigData()
    config.update_setting(setting)
    assert config.get_setting('test-test', plugin) == setting

# Generated at 2022-06-10 22:50:21.454920
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

# Generated at 2022-06-10 22:50:25.398841
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='website', value='http://www.ansible.com'))
    assert config_data.get_setting('website') == Setting(name='website', value='http://www.ansible.com')
