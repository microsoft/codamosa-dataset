

# Generated at 2022-06-10 22:40:39.424493
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import os
    import ara.clients.ansible.config
    import ara.clients.ansible.plugins
    import ara.models.ansible.config

    config = ConfigData()

    # read config file
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '.ansible.cfg')
    config_parser = ara.clients.ansible.config.read(path)

    # get all plugins from config file
    all_plugins = ara.clients.ansible.plugins.find_plugins(config_parser)

    # add all plugins to config
    for plugin in all_plugins:
        setting = ara.models.ansible.config.Setting(
            name=plugin['setting'],
            value=plugin['value']
        )
        config

# Generated at 2022-06-10 22:40:48.746770
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    setting = Setting('valid_setting', 'true')
    setting.origin = 'default'

    # Test case 1: plugin only
    plugin = Plugin('psrp')
    config.update_setting(setting, plugin)
    plugin_setting = config.get_setting('valid_setting', plugin)
    assert plugin_setting.name == setting.name
    assert plugin_setting.value == setting.value
    assert plugin_setting.origin == setting.origin

    # Test case 2: setting only
    setting.name = 'valid_setting2'
    setting.value = 'false'
    setting.origin = 'default'
    config.update_setting(setting)
    setting2 = config.get_setting('valid_setting2')
    assert setting2.name == setting.name

# Generated at 2022-06-10 22:40:50.781361
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    settings = config_data.get_settings()

    assert settings == []



# Generated at 2022-06-10 22:41:01.737963
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import become_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import test_loader

    config_data = ConfigData()
    config_data.update_setting(Setting(name='a', description='a'))
    config_data.update_setting(Setting(name='b', description='b'))
    config_data.update_setting(Setting(name='c', description='c'))
    config_data.update_setting(Setting(name='d', description='d'))
    config

# Generated at 2022-06-10 22:41:05.419143
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    setting = {'name': 'test_conf'}
    configData.update_setting(setting)
    if configData.get_setting('test_conf')['name'] == 'test_conf':
        print ('ok')
    else:
        print ('error')

if __name__ == '__main__':
    test_ConfigData_update_setting()

# Generated at 2022-06-10 22:41:13.861344
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='setting_name', value='setting_value'))
    assert config_data._global_settings['setting_name'] == Setting(name='setting_name', value='setting_value')
    config_data.update_setting(Setting(name='setting_name', value='setting_value'), plugin=Plugin(type='type', name='name'))
    assert config_data._plugins['type']['name']['setting_name'] == Setting(name='setting_name', value='setting_value')


# Generated at 2022-06-10 22:41:24.548145
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Create a new config data object
    cdata = ConfigData()
    # Create a new global setting object
    gsetting = ConfigDataSetting('ENV_ASK_VALUE', 'ask')
    # Add global setting to config data
    cdata.update_setting(gsetting)
    # Check that the global setting is in the list of global settings
    assert(gsetting in cdata.get_settings())
    # Check that the global setting is in the list of settings of a plugin
    assert(gsetting in cdata.get_settings(plugin=None))
    # Create a new plugin
    plugin = ConfigDataPlugin(type='collection', name='zabbix')
    # Create a new plugin setting object
    psetting = ConfigDataSetting('bob', 'tim')
    # Add plugin setting to config data

# Generated at 2022-06-10 22:41:33.332159
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblelint.rules.LineTooLongRule import LineTooLongRule

    configs = [
        {
            'id': 'AN007',
            'type': 'line_too_long',
            'line_length': 80
        },
        {
            'id': 'AN007',
            'type': 'line_too_long',
            'line_length': 100
        },
    ]

    cd = ConfigData()

    for config in configs:
        setting = LineTooLongRule(config.get('id'), config.get('type'), config.get('line_length'))
        cd.update_setting(setting)

    tested = cd.get_setting('line_length')
    assert tested.value == 80

    tested = cd.get_setting('line_length', plugin='foo')
    assert tested is None



# Generated at 2022-06-10 22:41:35.963316
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # check global config
    # config_data.get_setting("foo")

    # check plugin config
    # config_data.get_setting("foo", "bar")

# Generated at 2022-06-10 22:41:44.979574
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblelint.rules.IdempotentModuleCheck import IdempotentModuleCheck
    from ansiblelint.rules.IdempotentModuleCheck import ConfigData

    configdata = ConfigData()
    rule = IdempotentModuleCheck(configdata)

    assert rule.get_setting("foo") is None

    configdata.update_setting("foo")

    assert rule.get_setting("foo") == "foo"

    configdata.update_setting("bar", "baz", "baz")

    assert rule.get_setting("bar", "baz", "baz") == "bar"


# Generated at 2022-06-10 22:41:59.590304
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    assert config_data.get_setting('test') is None
    assert config_data.get_setting('test1') is None
    assert config_data.get_setting('test2') is None

    class Plugin:

        def __init__(self, type, name):
            self.type = type
            self.name = name

    class Setting:

        def __init__(self, name, value):
            self.name = name
            self.value = value

    plugin_test = Plugin('test', 'test')
    plugin_test1 = Plugin('test1', 'test1')
    setting_test = Setting('test', 'test')
    setting_test1 = Setting('test1', 'test1')
    setting_test2 = Setting('test2', 'test2')

# Generated at 2022-06-10 22:42:09.196157
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    p0 = PluginDefinition("i_am_plugin_type", "i_am_plugin_name")
    p1 = PluginDefinition("i_am_plugin_type", "i_am_plugin_name_2")
    s0 = SettingDefinition("i_am_setting_name", "i_am_setting_value")
    s1 = SettingDefinition("i_am_setting_name_2", "i_am_setting_value_2")

    cd = ConfigData()

    cd.update_setting(s0)
    assert cd.get_setting("i_am_setting_name") == s0
    assert cd.get_setting("i_am_setting_name", p0) == s0
    assert cd.get_setting("i_am_setting_name", p1) == s0


# Generated at 2022-06-10 22:42:17.785961
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Arrange
    from ansible.utils.plugin_docs import ConfigIniSetting

    from collections import namedtuple
    Plugin = namedtuple('Plugin', ['type', 'name'])

    config_data = ConfigData()
    plugin = Plugin('connection', 'network_cli')
    setting = ConfigIniSetting(name='paramiko_conn_args', default=dict(allow_agent=False), section='connection defaults', doc=dict(format='<DOC>', repr='<DOC>', type='dict',
                                                                                                                              sample='<DOC>', description='<DOC>'))

    # Act
    config_data.update_setting(setting)

    # Assert
    assert setting == config_data.get_setting(setting.name)

    # Act
    config_data.update_setting(setting, plugin)



# Generated at 2022-06-10 22:42:23.840390
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    result = config_data.get_setting(None, None)
    assert result == None

    config_data = ConfigData()
    result = config_data.get_setting("test setting", None)
    assert result == None

    config_data = ConfigData()
    result = config_data.get_setting("test setting", "test plugin")
    assert result == None


# Generated at 2022-06-10 22:42:31.931255
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.config.data import ConfigData, ConfigSetting
    from ansible.config.manager import ConfigManager

    config_manager = ConfigManager(cwd=None)
    config_data = ConfigData()

    # Add a global setting
    config_data.update_setting(ConfigSetting('base_path', config_manager))

    # Add a plugin setting
    config_data.update_setting(ConfigSetting('precedence', config_manager),
                               plugin=config_manager.plugins.get_plugin('inclusions', 'include_role'))

    assert config_data.get_setting('base_path') is not None
    assert config_data.get_setting('precedence') is None


# Generated at 2022-06-10 22:42:43.164224
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings = []
    global_setting = GlobalSetting('foo', 'string')
    global_setting.set_value('bar')
    settings.append(global_setting)
    global_setting = GlobalSetting('bar', 'string')
    global_setting.set_value('rab')
    settings.append(global_setting)
    plugin_setting = PluginSetting('foo', 'string')
    plugin_setting.set_value('bar')
    settings.append(plugin_setting)

    configdata = ConfigData()
    for setting in settings:
        configdata.update_setting(setting)

    assert (configdata.get_settings(None) != None)
    assert (len(configdata.get_settings(None)) == 2)

# Generated at 2022-06-10 22:42:47.385967
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    setting1 = Setting('Foo', 'Bar')
    setting2 = Setting('Baz', 'Qux')
    setting3 = Setting('Quux', 'Quuz')
    config.update_setting(setting1)
    config.update_setting(setting2)
    config.update_setting(setting3)
    assert [setting1, setting2, setting3] == config.get_settings()


# Generated at 2022-06-10 22:42:51.282084
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()
    config.update_setting(Setting('setting1', 'ansible.cfg', 1))
    assert config.get_setting('setting1').value

    # TODO: test for update_setting for plugin


# Generated at 2022-06-10 22:42:59.932919
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()
    test_var = 'test_var'
    test_val = 'test_value'
    test_plugin_name = 'test_plugin_name'

    test_plugin = PluginLoader.find_plugin(None, test_plugin_name)

    if test_plugin is None:
        # Need to create a plugin as there isn't one that already exists
        test_plugin_path = ConfigData.__module__.replace('core.config_data', 'test/unit/test_utils/test_plugins/test')
        test_plugin = PluginLoader._add_directory(None, test_plugin_path)

    test_setting = Setting(test_var, test_val)

    config_data.update_setting(test_setting, plugin=test_plugin)



# Generated at 2022-06-10 22:43:09.921844
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    data.update_setting(Setting(name='setting1', value=1), plugin=None)
    data.update_setting(Setting(name='setting2', value=2), plugin=None)
    data.update_setting(Setting(name='setting3', value=3), plugin=Plugin('test1'))
    data.update_setting(Setting(name='setting4', value=4), plugin=Plugin('test1'))
    data.update_setting(Setting(name='setting5', value=5), plugin=Plugin('test1', 'action'))
    data.update_setting(Setting(name='setting6', value=6), plugin=Plugin('test1', 'cache'))

# Generated at 2022-06-10 22:43:23.833147
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    conf = ConfigData()
    plugin1 = Plugin(type='action', name='myaction')

    # Any kind of plugin with unknown name
    mysetting = conf.get_setting('myvar')
    assert mysetting == None

    # Any kind of plugin with known name
    mysetting = Setting('myvar', 'myvalue')
    conf.update_setting(mysetting)
    mysetting = conf.get_setting('myvar')
    assert mysetting.name == 'myvar'
    assert mysetting.value == 'myvalue'

    # Action plugin without name
    mysetting = conf.get_setting('myvar', plugin1)
    assert mysetting == None

    # Action plugin with known name
    mysetting = Setting('myvar', 'myvalue')
    conf.update_setting(mysetting, plugin1)
    mysetting = conf

# Generated at 2022-06-10 22:43:36.060456
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    # test for setting global setting
    setting1 = Setting('enable_plugins','connection.*','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','')
    setting2 = Setting('interpreter_python','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','')
    config_data.update_setting(setting1)
    config_data.update_

# Generated at 2022-06-10 22:43:41.709550
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    cd = ConfigData()
    #Test if empty
    assert cd.get_settings() == []

    #Test if not empty
    from ansible.plugins.loader import PluginLoader

    pl = PluginLoader(configuration=None)
    plugin = pl.all(class_only=True)
    cd.update_setting(plugin[0])
    assert cd.get_settings() == [plugin[0]]

# Generated at 2022-06-10 22:43:51.898093
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    configdata = ConfigData()

    global_setting = {
        'name': 'foo',
        'value': 'bar',
        'type': 'env',
        'scope': 'all',
        'origin': 'default'
    }
    plugin_setting = {
        'name': 'foo',
        'value': 'baz',
        'type': 'env',
        'scope': 'inventory',
        'origin': 'default'
    }

    configdata.update_setting(global_setting)
    configdata.update_setting(plugin_setting)

    # test that existant setting is retrieved
    assert(configdata.get_setting('foo') is not None)
    assert(configdata.get_setting('foo', plugin=Plugin(type='inventory', name='hosts')) is not None)

    # test that non exist

# Generated at 2022-06-10 22:43:55.332229
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Given
    config = ConfigData()
    config._global_settings = {'foo': 'bar'}
    config._plugins = {'foobar': 'foos'}

    # When
    settings = config.get_settings()

    # Then
    assert settings == ['bar']


# Generated at 2022-06-10 22:44:03.072066
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    plugin = PluginType('callback', 'disk_usage')
    setting = PluginSetting('callback_whitelist', 'disk_usage', '/opt')
    config.update_setting(setting, plugin)

    assert config.get_setting('callback_whitelist',plugin) == setting
    assert config.get_settings(plugin) == [setting]

    setting = PluginSetting('callback_whitelist', 'debug', '/home/root')
    config.update_setting(setting)
    assert config.get_setting('callback_whitelist') == setting
    assert config.get_settings() == [setting]



# Generated at 2022-06-10 22:44:03.649238
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert False

# Generated at 2022-06-10 22:44:15.576690
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.module_utils.common.collections import ImmutableDict

    config_data = ConfigData()

    global_setting = Setting("inventory", "/etc/ansible/hosts")
    plugin_setting = Setting("vars", "/etc/ansible/group_vars/all/vars")
    plugin_setting.plugin = Plugin("inventory", "some_plugin")

    config_data.update_setting(global_setting)
    config_data.update_setting(plugin_setting)

    global_settings = config_data.get_settings()
    assert len(global_settings) == 1 and global_settings[0] == global_setting

    plugin_settings = config_data.get_settings(plugin_setting.plugin)
    assert len(plugin_settings) == 1 and plugin_settings[0] == plugin_setting


# Generated at 2022-06-10 22:44:21.497473
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Create a plugin
    from lib.data_structures import Plugin
    test_plugin1 = Plugin(type="action", name="test")

    # Test with the plugin
    settings = config_data.get_settings(test_plugin1)
    assert not settings

    # Create a setting
    from lib.data_structures import Setting
    test_setting1 = Setting("test", "value")

    # Update the setting in the ConfigData object
    config_data.update_setting(test_setting1)

    # Retest with the plugin
    settings = config_data.get_settings(test_plugin1)
    assert not settings

    # Update the setting in the ConfigData object with the plugin
    config_data.update_setting(test_setting1, test_plugin1)

    # Retest with the

# Generated at 2022-06-10 22:44:33.425869
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    from collections import namedtuple

    Setting = namedtuple('Setting', ['name', 'value', 'origin'])
    Plugin = namedtuple('Plugin', ['type', 'name'])
    plugin = Plugin('module', 'copy')
    setting1 = Setting('ANSIBLE_COPY_MODULE_PATH', '/my/ansible/path', 'env')
    setting2 = Setting('ANSIBLE_COPY_MODULE_PATH', '/my/config/path', 'config')

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting1, plugin)
    config_data.update_setting(setting2, plugin)


# Generated at 2022-06-10 22:44:48.291507
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global_setting = Setting(name='auto_add_hosts', value='True', origin='global.ini')
    test1_setting = Setting(name='auto_add_hosts', value='True', origin='test1.ini')
    test2_setting = Setting(name='auto_add_hosts', value='False', origin='test2.ini')
    test3_setting = Setting(name='auto_add_hosts', value='False', origin='test3.ini')

    config_data = ConfigData()

    module = Module('test', 'test')
    config_data.update_setting(global_setting)
    config_data.update_setting(test1_setting, plugin=module)
    config_data.update_setting(test2_setting, plugin=module)

# Generated at 2022-06-10 22:44:49.729312
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    assert data.get_setting('') is None

# Generated at 2022-06-10 22:44:57.503076
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    class Plugin():
        def __init__(self, name, type):
            self.name = name
            self.type = type
    class Setting():
        def __init__(self, name):
            self.name = name
    plugin = Plugin("name", "type")
    setting1 = Setting("name1")
    setting2 = Setting("name2")
    config.update_setting(setting1, plugin)
    config.update_setting(setting2, plugin)
    assert config.get_settings() == []
    assert config.get_settings(plugin) == [setting1, setting2]

# Generated at 2022-06-10 22:45:08.442060
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    import ansible.module_utils.connection
    plugin = ansible.module_utils.connection.Connection('local', '/tmp/ansible_pipelining_inventory')

    from ansible.module_utils.parsing.convert_bool import boolean
    import ansible.module_utils.common.json_utils
    assert not config_data.get_setting('accelerate', plugin=plugin)


# Generated at 2022-06-10 22:45:18.678441
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cm = ConfigData()
    cm._global_settings = {
        'string_setting': {'value': 'bar', 'type': 'str'},
        'int_setting': {'value': 5, 'type': 'int'},
        'bool_setting': {'value': True, 'type': 'bool'},
        'list_setting': {'value': ['a', 'b', 'c'], 'type': 'list'},
    }


# Generated at 2022-06-10 22:45:31.406729
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class TestPlugin(object):
        def __init__(self, name, type):
            self._name = name
            self._type = type
        def get_name(self):
            return self._name
        def get_type(self):
            return self._type

    from ansible.plugins.loader import PluginLoader
    from ansible.config.setting import Setting

    config = ConfigData()

    plugin_type = 'test'
    plugin_name = 'test'
    plugin = PluginLoader.get(plugin_name, plugin_type)

    setting_name = 'test'
    setting = Setting(plugin, setting_name)

    config.update_setting(setting)

    assert config.get_setting(setting_name, plugin=plugin) is not None
    assert config.get_setting(setting_name) is None
    assert config

# Generated at 2022-06-10 22:45:35.879918
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Initializing of a new object
    config_data = ConfigData()
    # Testing of a method implementation
    PLUGIN = ("name", "module", "type")
    SETTING = ("name", "value")
    config_data.update_setting(SETTING, PLUGIN)
    assert config_data._plugins[PLUGIN.type][PLUGIN.name][SETTING.name] == SETTING


# Generated at 2022-06-10 22:45:41.974813
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data=ConfigData()
    assert config_data.update_setting("hello=world") == {"hello":"world"}
    assert config_data.update_setting("foo=bar") == {"hello":"world","foo":"bar"}
    assert config_data.update_setting("hello=world") == {"foo":"bar"}
    assert config_data.update_setting("foo=bar") == {}

# Generated at 2022-06-10 22:45:53.049778
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Create 2 settings
    from ansible.module_utils.common.netcommon import Setting
    s1 = Setting(name='setting1', value='setting 1', aliases=['s1'], default='s1 default', choices=['s1 choice'])
    s2 = Setting(name='setting2', value='setting 2', aliases=['s2'], default='s1 default', choices=['s1 choice'])

    # Create ConfigData object
    config_data = ConfigData()

    # Add setting
    assert config_data.get_setting('setting1') is None
    config_data.update_setting(s1)
    assert config_data.get_setting('setting1') == s1

    # Remove setting
    config_data.update_setting(Setting(name='setting1'))

# Generated at 2022-06-10 22:46:01.513127
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting1 = {'name': 'setting1', 'value': 'value1'}
    plugin1 = {'type': 'plugin1', 'name': 'plugin1'}
    plugin2 = {'type': 'plugin2', 'name': 'plugin2'}

    config_data.update_setting(setting1, plugin1)
    assert plugin1['type'] in config_data._plugins
    assert plugin1['name'] in config_data._plugins[plugin1['type']]
    assert setting1['name'] in config_data._plugins[plugin1['type']][plugin1['name']]
    assert setting1['value'] == config_data._plugins[plugin1['type']][plugin1['name']][setting1['name']]['value']


# Generated at 2022-06-10 22:46:14.977006
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()

    # Test01: setting not in ConfigData
    assert not data.get_setting('test_setting')

    # Test02: setting in ConfigData, but not for given plugin
    data.update_setting('test_setting')
    assert data.get_setting('test_setting')

    # Test03: setting in ConfigData for given plugin
    from ansible.plugins.vars import VarsModule
    vars_module_plugin = VarsModule({}, {}, {}, {}, None)
    data.update_setting('test_setting', vars_module_plugin)
    assert data.get_setting('test_setting', vars_module_plugin)



# Generated at 2022-06-10 22:46:27.043114
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin_1 = Plugin('type 1', 'name 1', [])
    plugin_2 = Plugin('type 2', 'name 2', [])
    plugin_3 = Plugin('type 2', 'name 3', [])

    settings = []
    for i in range(3):
        settings.append(Setting('setting {}'.format(i + 1), 'value {}'.format(i + 1), i + 1))

    for s in settings:
        config_data.update_setting(s)

    for s in config_data.get_settings():
        assert s in settings

    for s in settings:
        config_data.update_setting(s, plugin_1)

    for s in config_data.get_settings():
        assert s in settings

# Generated at 2022-06-10 22:46:32.279755
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    # Create a plugin
    from ansible.plugins.loader import get_plugin_class

    F, C, lookup_class, D, T = get_plugin_class("action")
    plugin = T()
    plugin.name = "foo"
    plugin.type = "module"
    # Create a setting
    from ansible.utils.plugin_docs import Setting

    setting = Setting(name="bar", description="bar description", version_added="2.0", required=False)
    # Test the empty state
    assert config_data.get_setting("bar", plugin) is None
    assert config_data.get_setting("bar") is None
    assert config_data.get_settings(plugin) == []
    # Test after adding the setting
    config_data.update_setting(setting, plugin)
   

# Generated at 2022-06-10 22:46:40.578135
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    data = ConfigData()
    data._global_settings = {'setting1': "setting1", 'setting2': "setting2"}
    data._plugins = {'type1': {'name1': {'setting1': "setting11", 'setting2': "setting21"}}}

    # Test global_setting
    setting1 = data.get_setting('setting1')
    assert setting1.name == 'setting1'
    assert setting1.value == 'setting1'
    assert setting1.plugin is None

    # Test plugin_setting
    plugin = Plugin('type1', 'name1')
    setting2 = data.get_setting('setting2', plugin)
    assert setting2.name == 'setting2'
    assert setting2.value == 'setting21'
    assert setting2.plugin == plugin


# Generated at 2022-06-10 22:46:42.638105
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert(config_data == config_data)


# Generated at 2022-06-10 22:46:43.290619
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    pass

# Generated at 2022-06-10 22:46:54.673187
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global_setting_1 = ConfigSetting("setting_1", "value_1")
    global_setting_2 = ConfigSetting("setting_2", "value_2")
    config_data = ConfigData()
    config_data.update_setting(global_setting_1)
    config_data.update_setting(global_setting_2)
    global_settings = config_data.get_settings()
    assert len(global_settings) == 2
    assert global_settings[0] == global_setting_1
    assert global_settings[1] == global_setting_2

    plugin_setting_1 = ConfigSetting("setting_1", "value_1")
    plugin_setting_2 = ConfigSetting("setting_2", "value_2")
    plugin_1 = Plugin("crawler", "plugin_1")

# Generated at 2022-06-10 22:46:58.938042
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings["key1"] = 1
    config_data._global_settings["key2"] = 1
    config_data._global_settings["key3"] = 1

    ans = [1, 1, 1]
    assert config_data.get_settings() == ans

# Generated at 2022-06-10 22:47:09.118978
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    assert cd.get_settings() == []

    from ansible.plugins.loader import plugin_loader
    from ansible.plugins.inventory import InventoryModule
    from ansible.plugins.lookup import LookupBase
    from ansible.plugins.action import ActionBase
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.strategy import StrategyBase

    assert len(plugin_loader.all()) == 0

    plugin_loader.add(InventoryModule, 'tests.plugins.test_plugin.inventory')
    plugin_loader.add(LookupBase, 'tests.plugins.test_plugin.lookup')
    plugin_loader.add(ActionBase, 'tests.plugins.test_plugin.action')
    plugin_loader.add(ConnectionBase, 'tests.plugins.test_plugin.connection')
   

# Generated at 2022-06-10 22:47:14.320335
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting('plugin_name')
    assert config_data._global_settings['plugin_name'] == 'plugin_name'
    assert config_data._plugins == {}
    config_data.update_setting('test_name', plugin='test_plugin')
    assert config_data._plugins == {'test_plugin': {'test_name': {'test_name': 'test_name'}}}

# Generated at 2022-06-10 22:47:29.788432
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    # Global, single use case
    setting1 = PluginSetting(name='test_setting1', value='test_value1', scope='global', plugin_name=None, plugin_type=None)
    config_data.update_setting(setting1)
    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0].name == setting1.name
    assert config_data.get_settings()[0].value == setting1.value
    assert config_data.get_settings()[0].scope == setting1.scope
    assert config_data.get_settings()[0].plugin_name == setting1.plugin_name
    assert config_data.get_settings()[0].plugin_type == setting1.plugin_type

    # Global, multi use case


# Generated at 2022-06-10 22:47:40.124259
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from units.mock.loader import DictDataLoader
    from units.mock.loader import PluginLoader
    from units.plugins.module_utils._text import to_bytes

    config = ConfigData()

    gs = PluginLoader('', '', config, '', '', None).get_all_plugin_names()
    assert len(gs) == 0

    config.update_setting({'name': 'FOO', 'description': '', 'default': '', 'env': [],
                           'ini': [], 'yaml': [], 'vars': [], 'const': None,
                           'takes_value': False, 'type': 'bool', 'choices': [], 'cliopts': []})

    gs = config.get_settings()
    assert len(gs) == 1

# Generated at 2022-06-10 22:47:51.230504
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    assert len(config_data._global_settings) == 0

    new_setting = Setting("setting_1", "this is my first setting")
    config_data.update_setting(new_setting)
    assert len(config_data._global_settings) == 1

    new_plugin = Plugin("plugin_1", "my_plugin_type")
    config_data.update_setting(new_setting, new_plugin)
    assert len(config_data._plugins) == 1
    assert len(config_data._plugins["my_plugin_type"]) == 1
    assert len(config_data._plugins["my_plugin_type"]["plugin_1"]) == 1


# Generated at 2022-06-10 22:48:00.724413
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting(None) == None, "Initailised config_data should not contain any setting"
    config_data.update_setting(Setting('test', 'value'))
    assert config_data.get_setting('test') != None and config_data.get_setting('test').name == 'test', "test_setting should be located in config_data"
    config_data.update_setting(Setting('test_2', 'value'))
    assert config_data.get_setting('test') != None and config_data.get_setting('test').name == 'test'
    assert config_data.get_setting('test_2') != None and config_data.get_setting('test_2').name == 'test_2'


# Generated at 2022-06-10 22:48:13.427988
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins import module_loader

    config_data = ConfigData()

    # Test with no defined global or plugin settings
    settings = config_data.get_settings()
    assert(len(settings) == 0)

    # Test with global settings, but no plugin defined
    config_data.update_setting(Setting('path', './plugins', ''))
    settings = config_data.get_settings()
    assert(len(settings) == 1)
    assert(settings[0].name == 'path')
    assert(settings[0].value == './plugins')

    # Test with global and plugin settings
    config_data.update_setting(Setting('test_setting', 'test', ''), module_loader.find_plugin('basic_module'))

# Generated at 2022-06-10 22:48:22.313299
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    example_plugin1 = Plugin(type='connection', name='connection1')
    example_plugin2 = Plugin(type='action', name='action1')

    example_config_data = ConfigData()
    example_config_data.update_setting(Setting(name='minimum_value', value='0', plugin=example_plugin1))
    example_config_data.update_setting(Setting(name='default_value', value='10', plugin=example_plugin1))
    example_config_data.update_setting(Setting(name='maximum_value', value='100', plugin=example_plugin1))
    example_config_data.update_setting(Setting(name='minimum_value', value='0', plugin=example_plugin2))

# Generated at 2022-06-10 22:48:26.721894
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    print('Current settings: ', config._global_settings)
    config.update_setting(Setting('foo', 'bar'))
    config.update_setting(Setting('foo', 'biz'), Plugin('type', 'name'))
    print('Current settings: ', config._global_settings)


# Generated at 2022-06-10 22:48:33.990426
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    # Test global settings
    config_data._global_settings = {
        'str_setting': 'some string value',
        'int_setting': 99999
    }

    assert config_data.get_setting('str_setting') == 'some string value'
    assert config_data.get_setting('int_setting') == 99999

    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'str_setting'
    assert config_data.get_settings()[1].name == 'int_setting'


# Generated at 2022-06-10 22:48:41.413531
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    plugin = {'type': 'module', 'name': 'docker_container'}

    setting = {'config_name': 'max_retries', 'value': 2}
    config_data.update_setting(setting, plugin)

    settings = config_data.get_settings(plugin)
    assert len(settings) == 1
    assert settings[0]['value'] == 2

    settings = config_data.get_settings()
    assert len(settings) == 0


# Generated at 2022-06-10 22:48:48.168039
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    test_config_data = ConfigData()
    test_setting = mock.Mock()
    test_setting.name = "setting_name_1"
    test_setting.setting_type = "setting_type_1"
    test_setting.setting_value = "setting_value_1"
    test_setting.plugin = None
    test_config_data.update_setting(test_setting)

    actual_result = test_config_data.get_setting("setting_name_1")
    expected_result = test_setting
    assert actual_result == expected_result

    actual_result = test_config_data.get_settings(test_setting.plugin)
    expected_result = [test_setting]
    assert actual_result == expected_result

# Generated at 2022-06-10 22:49:03.665501
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = PluginDefinition('role', 'myrole')
    setting = PluginSetting('a_setting', 'string', 'default_value', 'description')
    config_data.update_setting(setting)
    assert config_data.get_setting('a_setting').name == 'a_setting'
    assert config_data.get_setting('a_setting').type == 'string'
    assert config_data.get_setting('a_setting').default == 'default_value'
    assert config_data.get_setting('a_setting').description == 'description'

    config_data.update_setting(setting, plugin=plugin)
    assert config_data.get_setting('a_setting', plugin=plugin).name == 'a_setting'

# Generated at 2022-06-10 22:49:07.078695
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin=Plugin('gzip', '', '')
    setting=Setting('verbose', '2', '')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('verbose', plugin) == setting


# Generated at 2022-06-10 22:49:17.533780
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class Plugin(object):
        def __init__(self, name, type):
            self.name = name
            self.type = type

    cd = ConfigData()
    assert (cd.get_setting("a") is None)
    assert (cd.get_setting("a", Plugin("b", "c")) is None)

    cd.update_setting("a")
    assert (cd.get_setting("a") == "a")
    assert (cd.get_setting("a", Plugin("b", "c")) is None)

    cd.update_setting("b", Plugin("b", "c"))
    assert (cd.get_setting("b", Plugin("b", "c")) == "b")

# Generated at 2022-06-10 22:49:27.525631
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    conf = ConfigData()
    plugin1 = PluginDescriptor()
    plugin1.name = 'ansible.builtin.perf_events'
    plugin1.type = 'callback'
    plugin1.path = '/path/plugin1'

    plugin2 = PluginDescriptor()
    plugin2.name = 'ansible.plugins.test.test_callback'
    plugin2.type = 'callback'
    plugin2.path = '/path/plugin2'

    settingA = ConfigSettingDescriptor()
    settingA.name = 'ANSI_COLOR'
    settingA.value = '1'
    settingA.category = 'DISPLAY'
    settingA.plugin = plugin1

    settingB = ConfigSettingDescriptor()
    settingB.name = 'DISPLAY_OK_HOSTS'

# Generated at 2022-06-10 22:49:33.619048
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = Plugin("inventory", "test")
    setting = Setting("key", "value", plugin)
    config_data.update_setting(setting)
    actual_value = config_data.get_setting("key", plugin)
    assert actual_value.name == "key"
    assert actual_value.value == "value"


# Generated at 2022-06-10 22:49:38.498304
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    assert data._global_settings == {}
    assert data._plugins == {}

    assert data.get_setting('setting') == None
    assert data.get_setting('setting', 'Plugin') == None
    assert data.get_setting('setting', 'Plugin') == None
    assert data.get_setting('setting').name == 'setting'



# Generated at 2022-06-10 22:49:48.592443
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    configData = ConfigData()
    class Plugin(object):
        def __init__(self):
            self.type = None
            self.name = None

    class Setting(object):
        def __init__(self):
            self.plugin = None
            self.name = None

    #Create local "mock" plugin
    plugin = Plugin()
    plugin.type = 'type1'
    plugin.name = 'name1'

    #Create local "mock" setting
    setting = Setting()
    setting.plugin = plugin
    setting.name = 'name1'
    configData.update_setting(setting)

    assert configData.get_settings() == [setting]

    setting = Setting()
    setting.plugin = None
    setting.name = 'name2'
    configData.update_setting(setting)

    #Check

# Generated at 2022-06-10 22:49:57.568147
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.config.data import ConfigData
    from ansible.config.manager import ConfigManager
    config_data = ConfigData()
    ConfigManager(data=config_data)  # register the default data class
    config_manager = ConfigManager(data=config_data)
    loader = DictDataLoader({ "foobar-test-setting.yaml": """
---
plugin_name: test_plugin
plugin_type: test_type
setting_name: test_setting
setting_default: test_setting_default
setting_type: string
setting_value: test_setting_value
setting_scope: test_scope
    """})
    config_manager._plugin_config_loader = loader
   

# Generated at 2022-06-10 22:50:09.435152
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    from ansible import context
    context.CLIARGS = {'connection': 'local'}

    from ansible.utils.plugin_docs import get_docstring
    docstring = get_docstring(
        config_data, 'acme_network_os', 'acme_network_os_setting', doc_fragment_loader
    )

    from ansible.plugins.setting import Setting
    setting = Setting(
        name='timeout',
        plugin_name='acme_network_os_setting',
        plugin_type='network_os',
        doc=docstring,
        value=30,
        defaults={'connection': 'local'}
    )
    config_data.update_setting(setting)
    assert setting == config_data.get_setting('timeout')

    setting = Setting

# Generated at 2022-06-10 22:50:13.927917
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting("test_setting", "/tmp")
    config_data.update_setting(setting)
    setting_db = config_data.get_setting("test_setting")
    assert setting_db == setting

if __name__ == "__main__":
    test_ConfigData_update_setting()