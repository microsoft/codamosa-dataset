

# Generated at 2022-06-10 22:40:35.772323
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # assert for global setting
    config_data = ConfigData()
    global_setting = Setting('/etc/ansible/ansible.cfg', 'host_key_checking', 'False')
    config_data.update_setting(global_setting)
    assert len(config_data.get_settings()) == 1
    assert global_setting == config_data.get_setting('host_key_checking')

    # assert for global setting in another path
    global_setting = Setting('/etc/ansible/ansible.cfg', 'pipelining', 'True')
    config_data.update_setting(global_setting)
    assert len(config_data.get_settings()) == 2
    assert global_setting == config_data.get_setting('pipelining')

    # assert for global setting with same name in another path
    global_setting = Setting

# Generated at 2022-06-10 22:40:42.862341
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.plugin_api import PluginApi

    config_data = ConfigData()

    plugin = PluginApi('role', 'mysql')
    setting_1 = PluginSetting('mysql', 'role')
    config_data.update_setting(setting_1, plugin)

    assert config_data.get_setting('mysql', plugin).name == 'mysql'
    assert config_data.get_setting('mysql', plugin)



# Generated at 2022-06-10 22:40:48.196145
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print('=> Test ConfigData.update_setting')
    config_data = ConfigData()
    config_data.update_setting({'name': 'name1', 'value': 'value1', 'origin': 'origin1', 'scope': []})
    config_data.update_setting({'name': 'name2', 'value': 'value2', 'origin': 'origin2', 'scope': []})
    assert len(config_data.get_settings()) == 2


# Generated at 2022-06-10 22:40:58.715263
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import pytest

    from ansible.module_utils.common.validation import check_type_bool, check_type_list, check_type_path, check_type_string

    from ansible_collections.ansible.community.plugins.module_utils.ansible_lint import RunnerConfig, ShellCommand, RunnerConfigOption, PluginOptionBoolean, PluginOptionList, PluginOptionPath, PluginOptionString, PluginOptionUnknown

    from ansible_collections.ansible.community.plugins.module_utils.ansible_lint.runner import ConfigData, Types

    plugin_name = 'test_plugin'
    plugin_option = 'foo'
    config_data = ConfigData()

    # Test adding a setting that is not a RunnerConfigOption and checking that it throws an exception

# Generated at 2022-06-10 22:41:06.837831
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
	
	cd = ConfigData()
	s1 = Setting("string_setting", "string", "mystring")
	s2 = Setting("int_setting", "int", 20)
	s3 = Setting("int_setting", "int", 200)
	s4 = Setting("string_setting", "string", "mystring")
	s5 = Setting("string_setting", "string", "yourstring")
	s6 = Setting("string_setting", "string", "yourstring")
	
	# update global settings
	cd.update_setting(s1)
	cd.update_setting(s2)
	cd.update_setting(s3)

	# update plugin settings
	p = Plugin("myplugin", "mytype")
	cd.update_setting(s4, plugin = p)

# Generated at 2022-06-10 22:41:18.499074
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.validation import check_type_str

# Generated at 2022-06-10 22:41:20.763676
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from types import SimpleNamespace

    plugin = SimpleNamespace(type='action', name='my_action')

    cd = ConfigDat

# Generated at 2022-06-10 22:41:30.280290
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import collection_loader, module_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible import context

    config_data = ConfigData()

    # in order to test the plugin settings, we need to remove the global settings because
    # plugin settings are defined by their diff compared to the global settings
    for setting in config_data.get_settings():
        config_data.update_setting(setting)

    settings = config_data.get_settings()
    assert len(settings) == 0

    variables = {
        'hostvars': {},
        'groups': {},
        'omit': '',
        'vars': {},
        'host': '',
    }

# Generated at 2022-06-10 22:41:34.391904
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()
    config.update_setting(Setting('a', '1'))
    config.update_setting(Setting('a', '2'))
    assert config.get_setting('a', Plugin('p')) == None
    assert config.get_setting('b') == None
    assert config.get_setting('b', Plugin('p')) == None
    assert config.get_setting('a').value == '1'


# Generated at 2022-06-10 22:41:46.389201
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting(None) == None

    config_data.update_setting(ConfigSetting('foo', 0, 'global'))
    assert config_data.get_setting('foo') == ConfigSetting('foo', 0, 'global')
    assert config_data.get_setting('bar') == None
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) == None

    config_data.update_setting(ConfigSetting('foo', 1, 'bar', 'baz'))
    assert config_data.get_setting('foo') == ConfigSetting('foo', 0, 'global')
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) == ConfigSetting('foo', 1, 'bar', 'baz')
    assert config_data.get

# Generated at 2022-06-10 22:41:59.671036
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Can get global settings
    config = ConfigData()
    config._global_settings['foo'] = 'bar'
    assert config.get_settings()[0].value == 'bar'

    # Can get plugin setting
    plugin = Plugin('foo', 'action')
    config.update_setting(Setting('bar', 'baz'))
    assert config.get_settings(plugin)[0].value == 'baz'

    # Can get module settings from a collection
    plugin = Plugin('foo', 'connection')
    plugin.include_role = Plugin('bar', 'action')
    config.update_setting(Setting('baz', 'qux'))
    assert config.get_settings(plugin)[0].value == 'qux'



# Generated at 2022-06-10 22:42:06.596377
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    plugin = 'plugin'
    plugin_type = 'plugin_type'
    setting1 = 'test_setting'
    setting2 = 'test_setting2'

    config.update_setting(setting1, plugin)
    result = config.get_setting(setting1, plugin)
    assert result == setting1

    result = config.get_setting(setting2, plugin)
    assert result == None
    result = config.get_setting(setting2)
    assert result == None

    result = config.get_setting(setting1)
    assert result == None


# Generated at 2022-06-10 22:42:14.014747
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert(config_data._global_settings == {})
    assert(config_data._plugins == {})

    setting1 = Setting('global_setting1', 'global_value1')
    config_data.update_setting(setting1)
    assert(config_data._global_settings['global_setting1'].name == 'global_setting1')
    assert(config_data._global_settings['global_setting1'].value == 'global_value1')
    assert(config_data._plugins == {})


# Generated at 2022-06-10 22:42:15.938551
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    assert configData.get_setting('foo') == None


# Generated at 2022-06-10 22:42:22.018823
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from plugins.module_utils.common.config_loader import ConfigLoader
    config_data = ConfigData()
    config_loader = ConfigLoader()
    config_loader.load_config(config_data)
    setting = config_data.get_setting("DEFAULT_NETWORK")
    assert(setting.value == "net0")
    assert(setting.name == "DEFAULT_NETWORK")


# Generated at 2022-06-10 22:42:31.122076
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.module_utils.common.config import Setting
    from ansible.module_utils.common.validation import check_type_bool, check_type_list, check_type_str, check_type_int
    from ansible.module_utils.common.config import PluginType


    f_name = 'force_color'
    v = True
    d = 'disable colorized output'
    c = check_type_bool

    t = Setting(name=f_name, value=v, description=d, check_type=c)

    f_name = 'ignore_config'
    v = ['*.ini']
    d = 'list of configuration files to ignore'
    c = check_type_list(check_type_str())


# Generated at 2022-06-10 22:42:42.592372
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Should update
    config_data = ConfigData()
    plugin = Plugin("type_1", "name_1")
    setting1 = Setting("name_1", "value_1")
    setting2 = Setting("name_2", "value_2")
    setting3 = Setting("name_3", "value_3")
    setting4 = Setting("name_4", "value_4")
    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin)
    config_data.update_setting(setting3)
    config_data.update_setting(setting4, plugin)
    assert config_data.get_setting("name_1") == setting1
    assert config_data.get_setting("name_2", plugin) == setting2

# Generated at 2022-06-10 22:42:54.317223
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from yaml import safe_load
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.plugins.loader import module_loader, fragment_loader
    from ansible.module_utils.common.collections import ImmutableDict

    cdata = ConfigData()

    def get_module_docstrings(module_name):
        (doc, plainexamples, returndocs, metadata) = read_docstring(module_loader._find_plugin(module_name))
        if doc.get('doc', False):
            docs = [line.strip() for line in doc['doc'].split('\n') if ':setting:' in line]
            return docs
        else:
            return None


# Generated at 2022-06-10 22:43:05.620097
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from ansible.plugins.loader import get_all_plugin_loaders, get_redirect_data
    from ansible.cli.config import CLI
    from ansible.config.manager import ConfigManager
    from ansible.config.data import ConfigData
    
    #def get_redirect_data(plugin_type, plugin_name, display_name):

config_data = ConfigData()
#Get Ansible Plugin Types and Names
types = get_all_plugin_loaders()
types = list(types.keys())
for plugin_type in types:
    plugin_names = get_all_plugin_loaders()[plugin_type]
    for plugin_name in plugin_names:
        plugin_class = get_all_plugin_loaders()[plugin_type][plugin_name]
        plugin = plugin_class.plugin_object
       

# Generated at 2022-06-10 22:43:12.189689
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(Setting('var1', 'value'))
    assert config._global_settings['var1'].name == 'var1'
    assert config._global_settings['var1'].value == 'value'
    config.update_setting(Setting('var2', 'value', Plugin('type', 'name')))
    assert config._plugins['type']['name']['var2'].name == 'var2'
    assert config._plugins['type']['name']['var2'].value == 'value'


# Generated at 2022-06-10 22:43:16.840785
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    for key, val in configData.__dict__.items():
        print(key, val)

# Generated at 2022-06-10 22:43:24.573368
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin('action', 'myaction')
    setting = Setting('myvar', 'myvalue', plugin)
    config_data.update_setting(setting)
    res1 = config_data.get_setting('myvar')
    res2 = config_data.get_settings(plugin)
    assert res1 is not None
    assert res2 is not None
    assert res1.name == 'myvar'
    assert res1.name == setting.name
    assert res2 == [setting]
    assert res2[0] is setting


# Generated at 2022-06-10 22:43:34.277395
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import PluginLoader
    import Setting

    config = ConfigData()

    setting = Setting.Setting('foo', 'bar')

    plugin = PluginLoader.Plugin('foo', 'bar')
    config.update_setting(setting, plugin)

    assert config.get_setting('foo', plugin) == setting
    setting.value = 'baz'
    assert config.get_setting('foo', plugin) == setting

    setting = Setting.Setting('foo', 'bar')
    config.update_setting(setting)

    assert config.get_setting('foo') == setting
    setting.value = 'baz'
    assert config.get_setting('foo') == setting

# Generated at 2022-06-10 22:43:37.778442
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0
    assert config_data.get_settings(BasePlugin(type='connection')) is None


# Generated at 2022-06-10 22:43:46.334513
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    a = AnsiblePluginConfig(type="callback", name="default", setting_name=None, value="hello")
    c.update_setting(a)
    assert c._global_settings["default"] == a
    assert c._global_settings["default"].type == "callback"
    assert c._global_settings["default"].setting_name == "default"
    assert c._global_settings["default"].value == "hello"
    assert "default" in c._global_settings
    assert len(c._global_settings) == 1
    assert len(c._plugins["callback"]) == 0


# Generated at 2022-06-10 22:43:55.513149
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Test 1: plugin is None, no setting is found
    config_data = ConfigData()
    settings = config_data.get_settings()
    assert not settings

    # Test 2: plugin is empty, no setting is found
    config_data = ConfigData()
    plugin = Plugin()
    settings = config_data.get_settings(plugin)
    assert not settings

    # Test 3: plugin is an object, one setting is found
    config_data = ConfigData()
    plugin = Plugin(name='test')
    config_data.update_setting(Setting(name='test_setting'), plugin)
    settings = config_data.get_settings(plugin)
    assert len(settings) == 1
    assert settings[0] == Setting(name='test_setting')

    # Test 4: plugin is None, one setting is found
    config_data

# Generated at 2022-06-10 22:44:06.802506
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    print("\n")

    # Testcase 1: no plugin is passed
    # Expected result: all settings from global config will be returned

    # Create ConfigData object
    test_config_data = ConfigData()

    # Create 6 settings for global config (3 for each setting type)
    test_settings = []
    test_settings.append(Setting("string", "string_setting1", "value1"))
    test_settings.append(Setting("string", "string_setting2", "value2"))
    test_settings.append(Setting("string", "string_setting3", "value3"))
    test_settings.append(Setting("list", "list_setting1", ["a", "b", "c"]))
    test_settings.append(Setting("list", "list_setting2", ["d", "e"]))
    test_settings.append

# Generated at 2022-06-10 22:44:09.792956
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    assert cd._global_settings == {}
    assert cd._plugins == {}
    assert cd.get_settings() == []


# Generated at 2022-06-10 22:44:18.515612
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    settings = {'a': "1", 'b': "2"}
    # set global settings
    for key in settings:
        setting = Setting(key, settings[key], None)
        config.update_setting(setting)
    # get settings
    for key in settings:
        setting = config.get_setting(key)
        assert(setting.name == key)
        assert(setting.value == settings[key])
        assert(setting.plugin is None)
    # test not exist setting
    setting = config.get_setting('not_exist')
    assert(setting is None)

    # set plugin settings
    plugin = Plugin('type', 'name')
    settings = {'a': "1", 'b': "2"}

# Generated at 2022-06-10 22:44:25.351450
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Setup
    config_data = ConfigData()
    setting = ConfigData.ConfigSetting('test', 'test')
    plugin = ConfigData.ConfigPlugin('test', 'test', 'test')

    # Execute
    config_data.update_setting(setting)
    config_data.update_setting(setting, plugin)

    # Assert
    assert config_data._global_settings['test'] == 'test'
    assert config_data._plugins['test']['test']['test'] == 'test'

# Generated at 2022-06-10 22:44:31.971684
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Given
    config_data = ConfigData()

    # When
    config_data.update_setting('setting')

    # Then
    assert config_data._global_settings == {'setting': 'setting'}
    assert config_data._plugins == {}


# Generated at 2022-06-10 22:44:40.014462
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='ansible_port', value='54321', origin='/etc/ansible/ansible.cfg')
    plugin = Plugin('connection', 'ssh')
    config_data.update_setting(setting, plugin)

    assert config_data._global_settings == {}
    assert config_data._plugins['connection']['ssh']['ansible_port'].value == '54321'


# Generated at 2022-06-10 22:44:49.858158
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    plugin1 = Plugin('test', 'lookup', 'Test')
    plugin2 = Plugin('test2', 'lookup', 'Test2')
    plugin_no = Plugin('not', 'lookup', 'Not')

    setting1 = Setting('item', 'value', plugin1)
    setting2 = Setting('second_item', 'second_value', plugin1)
    setting3 = Setting('third_item', 'third_value', plugin2)
    setting4 = Setting('global_item', 'global_value', None)

    cd.update_setting(setting1)
    cd.update_setting(setting2)
    cd.update_setting(setting3)
    cd.update_setting(setting4)

    settings1 = cd.get_settings(plugin1)

# Generated at 2022-06-10 22:44:59.268985
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Create a new ConfigData instance
    config_data = ConfigData()

    # Update the global default setting
    setting = Setting('default')
    config_data.update_setting(setting)

    # Retrieve the global default setting
    settings = config_data.get_settings()
    assert settings[0].name == 'default'

    # Update a setting of the plugin named "foo" and of type "action"
    setting = Setting('bar', plugin='action.foo')
    config_data.update_setting(setting)

    # Retrieve the settings of the plugin named "foo" and of type "action"
    settings = config_data.get_settings(plugin='action.foo')
    assert settings[0].name == 'default'
    assert settings[1].name == 'bar'

    # Retrieve the global default setting
    settings = config

# Generated at 2022-06-10 22:45:10.426395
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Tests get_setting for global setting for config data
    config_data = ConfigData()
    config_data.update_setting(Setting(name="Env", value="Dev"))
    assert config_data.get_setting("Env") == Setting(name="Env", value="Dev")

    # Tests get_setting for Plugin type and Plugin name setting for config data
    config_data.update_setting(Setting(name="Env", value="Dev"), plugin=Plugin(name="aws", type="cloud"))
    assert config_data.get_setting("Env", plugin=Plugin(name="aws", type="cloud")) == Setting(name="Env", value="Dev")

    # Tests get_setting for non existing plugin setting for config data
    assert config_data.get_setting("Env", plugin=Plugin(name="aws", type="cloud")) != Setting

# Generated at 2022-06-10 22:45:11.601440
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-10 22:45:18.433641
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting1 = setting.Setting('setting1', True)
    setting2 = setting.Setting('setting2', False)
    plugin_name = plugin.PluginName('connection', 'local')
    config_data.update_setting(setting1, plugin.Plugin(plugin_name))
    config_data.update_setting(setting2, plugin.Plugin(plugin_name))
    assert len(config_data.get_settings(plugin.Plugin(plugin_name))) == 2


# Generated at 2022-06-10 22:45:31.223229
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    '''Check that the method get_settings returns the expected list of setting objects.

    :return: true if the test is passed, false otherwise
    '''
    settings = []
    # settings in global section
    settings.append(Setting('plugins', 'lookup', 'lookup_plugins',
                            'path', '/home/ansible/ansible/plugins/lookup',
                            'string', 'path(s) of lookup plugin to load',
                            'no'))
    settings.append(Setting('plugins', 'module_utils', 'module_utils',
                            'paths', '/home/ansible/ansible/lib/ansible/module_utils',
                            'list', 'paths to additional module_utils files to import',
                            'yes'))


# Generated at 2022-06-10 22:45:34.850679
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    value = None
    new_configdata = ConfigData()
    assert not new_configdata.get_settings()
    assert new_configdata._global_settings == {}
    assert new_configdata._plugins == {}


# Generated at 2022-06-10 22:45:46.425566
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    setting_1 = Setting('setting_1', 'value_1', 'description_1', 'global')
    setting_2 = Setting('setting_2', 'value_2', 'description_2', 'global')
    setting_3 = Setting('setting_3', 'value_3', 'description_3', 'global')
    setting_4 = Setting('setting_4', 'value_4', 'description_4', 'global')
    setting_5_local = Setting('setting_5', 'local_value_5', 'local_description_5', 'local')
    setting_5_cache = Setting('setting_5', 'cache_value_5', 'cache_description_5', 'cache')

    config.update_setting(setting_1)
    config.update_setting(setting_2)
    config.update_setting

# Generated at 2022-06-10 22:45:51.165050
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting('test_setting')
    assert(config_data.get_setting('test_setting') == 'test_setting')


# Generated at 2022-06-10 22:45:56.106416
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    data.update_setting(AnsibleSetting('foo', 'bar', 'baz', 'desc', 'str', ['str']))
    assert data.get_settings() == [AnsibleSetting('foo', 'bar', 'baz', 'desc', 'str', ['str'])]


# Generated at 2022-06-10 22:46:01.946434
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from PluginSetting import PluginSetting
    from PluginSpec import PluginSpec

    config_data = ConfigData()
    config_data.update_setting(PluginSetting('key1', 'value1'))
    config_data.update_setting(PluginSetting('key2', 'value2'), PluginSpec('type1', 'name1'))

    assert config_data.get_setting('key1') == PluginSetting('key1', 'value1')
    assert config_data.get_setting('key2', PluginSpec('type1', 'name1')) == PluginSetting('key2', 'value2')
    assert not config_data.get_setting('key2')

# Generated at 2022-06-10 22:46:12.703444
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    # negative test case: the default setting of no plugin is None
    assert config_data.get_setting('no_plugin', 'default') is None
    # positive test case: the global setting is foo
    config_data.update_setting(Setting('foo', 'global', 'global'))
    assert config_data.get_setting('foo', 'global') == 'global'
    assert config_data.get_setting('foo') == 'global'
    # negative test case: the setting of no plugin is None
    assert config_data.get_setting('no_plugin') is None
    # positive test case: the netconf setting is bar
    config_data.update_setting(Setting('bar', 'netconf', 'netconf'))

# Generated at 2022-06-10 22:46:16.389459
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    from ansible.plugins import module_loader
    plugin = module_loader._find_plugin('shell', 'default', 'become')
    assert isinstance(config_data.get_setting('shell_executable', plugin), ConfigurationSettingValue)


# Generated at 2022-06-10 22:46:27.965860
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_g = TestSetting('g')
    config_data.update_setting(setting_g)
    assert config_data.get_setting('g').value == 'g'

    setting_p = TestSetting('p')
    plugin = TestPlugin('test', 'test', 'test', 'test')
    config_data.update_setting(setting_p, plugin)
    assert config_data.get_setting('p', plugin).value == 'p'

    setting_p1 = TestSetting('p1')
    plugin1 = TestPlugin('test', 'test1', 'test', 'test')
    config_data.update_setting(setting_p1, plugin1)
    assert config_data.get_setting('p1', plugin1).value == 'p1'

    assert config_data.get_

# Generated at 2022-06-10 22:46:36.768943
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(setting1)
    assert config_data._global_settings["deprecation_warnings"] == setting1
    config_data.update_setting(setting2, plugin1)
    assert config_data._plugins["connection"]["ssh"]["pty"] == setting2
    config_data.update_setting(setting3, plugin2)
    assert config_data._plugins["shell"]["sh"]["executable"] == setting3
    config_data.update_setting(setting1, plugin1)
    assert config_data._plugins["connection"]["ssh"]["deprecation_warnings"] == setting1


# Generated at 2022-06-10 22:46:46.354106
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from test.unit.config_data_updater.setting import MockSetting

    config_data = ConfigData()

    s_0 = MockSetting(name="name1")
    s_1 = MockSetting(name="name2")

    try:
        assert len(config_data.get_settings()) == 0
        assert config_data.get_settings() == []

        config_data.update_setting(s_0)
        config_data.update_setting(s_1)
        assert len(config_data.get_settings()) == 2
        assert config_data.get_settings() == [s_0, s_1]

    except Exception as e:
        raise e
    finally:
        pass



# Generated at 2022-06-10 22:46:57.098032
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    setting_1 = Setting("foo", "bar")

    config_data.update_setting(setting_1)

    assert config_data.get_setting("foo") == setting_1
    assert config_data.get_settings() == [setting_1]
    assert config_data.get_setting("foo", Plugin("bla", "bla")) is None
    assert config_data.get_settings(Plugin("bla", "bla")) == []

    setting_2 = Setting("foo2", "bar2")

    config_data.update_setting(setting_2, Plugin("foo", "bar"))

    assert config_data.get_setting("foo2", Plugin("foo", "bar")) == setting_2

# Generated at 2022-06-10 22:47:06.936637
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class Plugin(object):
        def __init__(self, plugin_type, plugin_name):
            self.type = plugin_type
            self.name = plugin_name

    class Setting(object):
        def __init__(self, name, value, plugin=None):
            if plugin is None:
                self.plugin_type = ''
                self.plugin_name = ''
            else:
                self.plugin_type = plugin.type
                self.plugin_name = plugin.name
            self.name = name
            self.value = value

        def to_dict(self):
            d = {}
            d['plugin_type'] = self.plugin_type
            d['plugin_name'] = self.plugin_name
            d['name'] = self.name
            d['value'] = self.value
            return d

    config

# Generated at 2022-06-10 22:47:18.675926
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # First test: plugin is not provided, so the setting is added to global settings
    config_data = ConfigData()
    setting = ConfigSetting('test_setting', 'test_value')

    config_data.update_setting(setting)

    assert config_data.get_setting('test_setting') == setting
    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0] == setting

    # Second test: plugin is provided (plugin is used to store the setting)
    plugin = ConfigPlugin('test_plugin', 'test_type')
    setting = ConfigSetting('test_setting', 'new_value')

    config_data.update_setting(setting, plugin)

    assert config_data.get_setting('test_setting', plugin) == setting

# Generated at 2022-06-10 22:47:25.431782
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting("route53_zone_id") is None

    class MockSetting(object):
        def __init__(self):
            self.name = "route53_zone_id"

    config_data.update_setting(MockSetting())
    assert config_data.get_setting("route53_zone_id") is not None


# Generated at 2022-06-10 22:47:37.145058
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.ansible_galaxy import GalaxyConfigSetting, GalaxyConfigPlugin

    c = ConfigData()

    s = GalaxyConfigSetting('plugins', 'galaxy_server')
    s.add_value('http://galaxy.example.com/api/')
    c.update_setting(s)

    s = GalaxyConfigSetting('ignore_certs', 'galaxy_server')
    s.add_value('True')
    c.update_setting(s)

    s = GalaxyConfigSetting('plugins', 'command_line')
    s.add_value('~/.ansible/roles')
    c.update_setting(s)

    assert c.get_setting('plugins') == s
    assert c.get_setting('plugins', GalaxyConfigPlugin('galaxy_server')) == s
    assert c.get_setting

# Generated at 2022-06-10 22:47:50.198751
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import unittest
    import mock
    import os
    import sys
    from units.mock.loader import MockLoader
    from units.mock.paths import mock_paths_loader

    mock_paths_loader()
    loader = MockLoader()
    loader.load_plugin(os.path.join('units', 'modules', 'scaffolding.py'))

    sys.modules['ansible.plugins.loader'] = loader

    from ansible.modules.scaffolding import BasicModule

    config_data = ConfigData()

    plugin = BasicModule(None, 'other_plugin')
    settings = config_data.get_settings(plugin=plugin)
    assert settings == []

    setting = plugin.get_option('foo')
    config_data.update_setting(setting=setting, plugin=plugin)

    setting2 = plugin

# Generated at 2022-06-10 22:48:00.206578
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class CustomPluginDefinition:

        def __init__(self, name, type):
            self.name = name
            self.type = type

    class CustomSetting:

        def __init__(self, name, value, plugin=None):
            self.name = name
            self.value = value
            self.plugin = plugin

    test_setting_1 = CustomSetting('ANSIBLE_TEST_SETTING_1', 'foo')
    test_setting_2 = CustomSetting('ANSIBLE_TEST_SETTING_2', 'bar')

    test_config_data = ConfigData()
    test_config_data.update_setting(test_setting_1)
    test_config_data.update_setting(test_setting_2)

    assert len(test_config_data._global_settings) == 2


# Generated at 2022-06-10 22:48:12.813673
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('ansible_ssh_common_args', 'value'))
    config_data.update_setting(ConfigSetting('timeout', '10', plugin=ConfigPlugin('Connection', 'ssh')))
    config_data.update_setting(ConfigSetting('forks', '5', plugin=ConfigPlugin('Strategy', 'linear')))
    config_data.update_setting(ConfigSetting('retries', '3', plugin=ConfigPlugin('Action', 'copy')))
    config_data.update_setting(ConfigSetting('host_key_checking', 'False', plugin=ConfigPlugin('Connection', 'local')))
    config_data.update_setting(ConfigSetting('host_key_checking', 'False', plugin=ConfigPlugin('Connection', 'ssh')))
    config_data.update_setting

# Generated at 2022-06-10 22:48:17.864224
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from lib.config.setting import Setting

    config = ConfigData()

    setting_name = 'deprecated'
    setting_value = 'value of the setting deprecated'
    setting = Setting(setting_name, setting_value)
    config.update_setting(setting)

    assert config.get_setting(setting_name) == setting



# Generated at 2022-06-10 22:48:28.321888
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from tempfile import mkdtemp
    from os import path
    from shutil import rmtree

    from ansible.module_utils.ansible_release import __version__
    from ansible.plugins.test.test_module.test_module import Plugin

    from ansiblelint.config import RulesCollection
    from ansiblelint.config.yaml_loader import YamlConfigLoader

    # Configure temporary directory, data and config path
    tmpdir = mkdtemp()
    config_path = path.join(tmpdir, 'rules.yml')
    data = {'rules': [{
        'name': 'test-rule',
        'id': 'TEST'
    }]}

    # Create config file
    with open(config_path, 'w') as config_file:
        config_file.write(data)

   

# Generated at 2022-06-10 22:48:29.719897
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    print(config_data.get_settings())

# Generated at 2022-06-10 22:48:36.606364
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = Plugin('lookup','file','','','','','','','','','','','','','')
    setting = Setting('name','','','','','','','')
    config_data.update_setting(setting)
    assert (config_data._global_settings.get('name') == config_data.get_setting('name'))
    assert (config_data._global_settings.get('name') != config_data.get_setting('name', plugin))


# Generated at 2022-06-10 22:48:46.124813
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1'))
    config_data.update_setting(Setting('setting2'))
    config_data.update_setting(Setting('setting3'))

    settings = config_data.get_settings()

    assert len(settings) == 3
    assert 'setting1' in settings[0].name
    assert 'setting2' in settings[1].name
    assert 'setting3' in settings[2].name


# Generated at 2022-06-10 22:48:54.002639
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin_type, plugin_name = 'test_plugin_type', 'test_plugin_name'
    cd = ConfigData()
    cd._global_settings['foo'] = 'bar'
    cd._plugins[plugin_type] = {plugin_name:{'bar':'foo'}}
    assert cd.get_settings()[0]._name == 'foo'
    assert cd.get_settings(Plugin(name=plugin_name, type=plugin_type))[0]._name == 'bar'


# Generated at 2022-06-10 22:49:05.066014
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import unittest
    class TestConfigData(unittest.TestCase):
        def test_update_setting(self):
            config_data = ConfigData()

            plugin = None
            setting = ConfigDataSetting('setting_1', 'value_1')
            config_data.update_setting(setting, plugin)

            plugin = PluginDescriptor('plugin_type_1', 'plugin_name_1')
            setting = ConfigDataSetting('setting_1', 'value_1')
            config_data.update_setting(setting, plugin)

            setting = ConfigDataSetting('setting_2', 'value_2')
            config_data.update_setting(setting, plugin)

            plugin = PluginDescriptor('plugin_type_2', 'plugin_name_2')
            setting = ConfigDataSetting('setting_1', 'value_1')


# Generated at 2022-06-10 22:49:06.282401
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    assert c.get_settings() == []


# Generated at 2022-06-10 22:49:18.196372
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    # create a setting for global plugin 
    setting = {
        'name': 'ANSIBLE_CONFIG_WAS_SET',
        'plugin': '',
        'value': 'True',
        'scope': '',
        'origin': '/dev/null',
        'priority': '100',
        'version': '1.0',
        'is_new': True
    }
    config_data.update_setting(setting)
    assert config_data._global_settings == setting
    # create a setting for callback plugin

# Generated at 2022-06-10 22:49:24.225476
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    myConfigData = ConfigData()
    myConfigData.update_setting({'name': 'ansible_connection', 'type': 'string', 'value': 'fake'})
    assert myConfigData.get_setting('ansible_connection') == {'name': 'ansible_connection', 'type': 'string', 'value': 'fake'}


# Generated at 2022-06-10 22:49:29.686208
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.plugins.loader import get_all_plugin_loaders

    config_data = ConfigData()

    config_data.update_setting(GlobalSetting('verbosity', 'ANSIBLE_VERBOSITY', '1'))
    config_data.update_setting(GlobalSetting('log_path', 'ANSIBLE_LOG_PATH', '/tmp/test.log'))

    # Test get settings without plugin argument
    settings = config_data.get_settings()

    assert len(settings) == 2
    assert settings[0].name == 'verbosity'
    assert settings[0].constant == 'ANSIBLE_VERBOSITY'
    assert settings[0].default_value == '1'

# Generated at 2022-06-10 22:49:38.155060
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting({"name": "a_var", "version": (1, 0), "value": 100})

    setting = config_data.get_setting("a_var")
    assert setting.value == 100, "ConfigData.get_setting should return the value of the setting"

    config_data.update_setting({"name": "a_var", "version": (1, 0), "value": 200})
    setting = config_data.get_setting("a_var")
    assert setting.value == 200, "ConfigData.get_setting should return the value of the updated setting"

# Generated at 2022-06-10 22:49:44.918900
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()

    assert data.get_setting('foo') == None

    from units.mock.loader import DictDataLoader
    from ansible.parsing.dataloader import DataLoader

    dl = DictDataLoader({
        'ansible.cfg': """
[defaults]
foo = default
"""})

    from ansible.config.manager import ConfigManager

    cm = ConfigManager(dl)
    data = ConfigManager(dl).data

    assert data.get_setting('foo') == 'default'


# Generated at 2022-06-10 22:49:46.827331
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    setting = Setting('foo', 'bar', 'baz')
    config.upda

# Generated at 2022-06-10 22:50:05.547366
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    s = Setting('key', 'value')
    plugin = Plugin('type', 'name')
    cd.update_setting(s, plugin)
    assert cd.get_setting('key', plugin) == s
    assert cd.get_setting('key', None) is None
    s = Setting('key', 'value')
    cd.update_setting(s, None) 
    assert cd.get_setting('key', None) == s
    assert cd.get_setting('key', plugin) == s



# Generated at 2022-06-10 22:50:15.520059
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    import unittest
    from collections import namedtuple

    from ansible.parsing import vault

    from ansible_collections.ansible.community.plugins.inventory.ec2_group import TYPE_NAME
    from ansible_collections.ansible.community.plugins.inventory.ec2_group import PLUGIN_NAME_PREFIX

    vault.VaultLib.is_encrypted = lambda x: True

    global_setting = namedtuple('key', 'name value')
    plugin_setting = namedtuple('key', 'name value')

    global_setting_1 = global_setting('test1', 'test1')
    global_setting_2 = global_setting('test2', 'test2')

    plugin_setting_1 = plugin_setting('test1', 'test1')

# Generated at 2022-06-10 22:50:18.909112
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {'a': 'b'}

    test_settings = config_data.get_settings()
    assert test_settings == [{'a': 'b'}]



# Generated at 2022-06-10 22:50:21.296882
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert(data.get_settings() == [])
    assert(data.get_settings(object) == [])

# Generated at 2022-06-10 22:50:27.185318
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    settings = ConfigData()
    setting = Setting('fixture', 'global')
    settings.update_setting(setting)
    assert settings.get_setting('fixture', None).value == 'global'

    setting = Setting('fixture', 'local')
    settings.update_setting(setting, Plugin('core', 'unit_test_plugin'))
    assert settings.get_setting('fixture', Plugin('core', 'unit_test_plugin')).value == 'local'
