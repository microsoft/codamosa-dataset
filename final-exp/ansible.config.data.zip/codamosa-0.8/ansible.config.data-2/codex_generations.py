

# Generated at 2022-06-10 22:40:39.713473
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    setting = Setting('lookup_plugin', name='foo', value='yaml')
    config_data.update_setting(setting, None)
    assert config_data.get_setting('foo', None) == setting

    # test for get_setting for different types of plugins
    for plugin_type in Plugin.get_plugin_types():
        plugin = Plugin(plugin_type, name='foo')
        setting = Setting('lookup_plugin', name='foo', value='yaml')
        config_data.update_setting(setting, plugin)
        assert config_data.get_setting('foo', plugin) == setting


# Generated at 2022-06-10 22:40:48.647377
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    """Test method get_settings of class ConfigData"""
    from ansiblelint.rules import FileMatch
    from ansiblelint.rules.BareVariablesRule import BareVariablesRule

    cfgdata = ConfigData()
    barevarsrule = BareVariablesRule()
    fm = FileMatch('.*', barevarsrule)
    cfgdata.update_setting(fm, barevarsrule)
    assert cfgdata.get_setting('match').name == 'match'
    assert cfgdata.get_setting('match').value == '.*'
    assert cfgdata.get_setting('id').name == 'id'
    assert cfgdata.get_setting('id', barevarsrule).value == 'ANSIBLE0004'



# Generated at 2022-06-10 22:40:59.241382
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Test data
    global_setting = Flag('enable', 'ansible-cli')
    core_plugin_setting = Flag('enable', 'ansible-core')
    module_plugin_setting = Flag('enable', 'ansible-module')
    shell_plugin_setting = Flag('enable', 'ansible-shell')

    # Test creation of ConfigData object
    config_data = ConfigData()
    assert config_data

    # Test setting of global data
    config_data.update_setting(global_setting)
    assert config_data.get_setting('enable') == global_setting

    # Test setting of plugin data
    config_data.update_setting(core_plugin_setting, core_plugin_setting.plugin)
    assert config_data.get_setting('enable', core_plugin_setting.plugin) == core_plugin_setting
    config

# Generated at 2022-06-10 22:41:07.220288
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.config.setting import Setting

    plugin1 = ConfigData()
    plugin2 = ConfigData()

    setting1 = Setting('foo1', 'default1')
    setting2 = Setting('foo2', 'default2')
    setting3 = Setting('foo3', 'default3')
    setting4 = Setting('foo4', 'default4')
    setting5 = Setting('foo5', 'default5')
    setting6 = Setting('foo6', 'default6')

    plugin1.update_setting(setting1)
    plugin2.update_setting(setting2)
    plugin1.update_setting(setting3, plugin2)
    plugin2.update_setting(setting4, plugin1)
    plugin1.update_setting(setting5)
    plugin1.update_setting(setting6, plugin2)

    # test_get_settings

# Generated at 2022-06-10 22:41:13.485894
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    value = '127.0.0.1'
    setting = Setting('ansible_python_interpreter', value)
    config.update_setting(setting)
    assert config.get_setting('ansible_python_interpreter') == value
    assert config.get_setting('ansible_python_interpreter', plugin=Plugin('connection', 'local')) is None


# Generated at 2022-06-10 22:41:19.840879
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    
    # Testing for empty object
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0
    assert config_data.get_settings() == []

    # Testing for List of objects
    config_data_list = ConfigData()
    #TODO: Add lines to populate settings

    # Asserting
    assert len(config_data_list.get_settings()) > 0


# Generated at 2022-06-10 22:41:23.974855
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    conf = ConfigData()
    setting = Setting(name='foo', value='bar')
    conf.update_setting(setting)
    assert conf.get_setting(name='foo') == setting
    assert conf.get_setting(name='foo', plugin=Plugin(type='connection', name='local')) is None


# Generated at 2022-06-10 22:41:32.965262
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils._text import to_bytes
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.plugins.loader import plugin_loader, get_all_plugin_loaders
    from ansible.plugins import module_loader

    import ansible.plugins
    import ansible.utils
    import os
    import sys

    path = os.path.join(os.path.dirname(__file__), '../')
    sys.path.append(path)

    config_data = ConfigData()

    plugin_paths = [os.path.expanduser("~/.ansible/plugins"),
                    "/usr/share/ansible/plugins",
                    "/usr/local/share/ansible/plugins"]

    # test_setting_global
    all_loaders = get_all_plugin

# Generated at 2022-06-10 22:41:40.493762
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    assert cd.get_setting("foo") is None
    import ansible.plugins
    try:
        class TestPluginType1(ansible.plugins.ActionBase):
            TYPE = "test_plugin_type1"
        class TestPlugin1(TestPluginType1):
            NAME = "test_plugin1"
        class TestPlugin2(TestPluginType1):
            NAME = "test_plugin2"
        assert cd.get_setting("foo", TestPlugin1()) is None
        assert cd.get_setting("foo", TestPlugin2()) is None
    finally:
        del ansible.plugins.TestPluginType1
        del ansible.plugins.TestPlugin1
        del ansible.plugins.TestPlugin2
    assert cd.get_setting("foo") is None


# Generated at 2022-06-10 22:41:47.075036
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Arrange
    # Initialize ConfigData object
    cd = ConfigData()

    # Test
    # test if we get all global settings
    global_settings = cd.get_settings()
    # test if there are not plugins
    plugins = cd.get_settings()

    # Assert
    assert len(global_settings) == 0
    assert len(plugins) == 0

# Generated at 2022-06-10 22:41:54.017339
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansiblelint.rules.Tests.unit_import.method_update_setting import config_data
    print(config_data.get_setting("verbosity"))
    print(config_data.get_setting("force_color"))
    print(config_data.get_setting("forks"))
    print(config_data.get_setting("display_skipped_hosts"))

# Generated at 2022-06-10 22:42:04.691750
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    """
    Unit test for method get_settings of class ConfigData
    :return:
    """
    config_data = ConfigData()
    plugin = PluginData(type='test_type',
                        name='test_name',
                        description='test description')
    setting1 = SettingData(name='test_name1',
                           default='default value test_name1',
                           description='description test_name1',
                           value='test_value1')
    setting2 = SettingData(name='test_name2',
                           default='default value test_name2',
                           description='description test_name2',
                           value='test_value2')
    config_data.update_setting(setting1, plugin)
    config_data.update_setting(setting2, plugin)

# Generated at 2022-06-10 22:42:05.883024
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

# Generated at 2022-06-10 22:42:10.941935
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    import os
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.tests.test_action.print_args as print_args
    import ansible.plugins.tests.test_filter.hello as hello
    from ansible.module_utils._text import to_bytes
    from ansible.utils.plugin_docs import get_docstring
    from ansible.utils.display import Display
    import ansible.utils.module_docs as module_docs

    config_data = ConfigData()

    # Test with no plugins.
    assert config_data.get_setting("action_plugins") is None
    assert config_data.get_setting("callback_plugins") is None
    assert config_data.get_setting("doc_fragments_path") is None

# Generated at 2022-06-10 22:42:19.238352
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    test_config_data = ConfigData()

    test_plugin = Plugin('test_plugin')
    test_plugin.type = 'type'
    test_plugin.name = 'name'
    test_plugin.path = 'path'
    test_plugin.class_name = 'class_name'

    test_setting = Setting()
    test_setting.name = 'name'
    test_setting.value = 'value'
    test_setting.default = 'default'
    test_setting.desc = 'desc'

    assert test_config_data.get_settings(test_plugin) == []

    test_config_data.update_setting(test_setting, test_plugin)
    assert len(test_config_data.get_settings(test_plugin)) == 1

# Generated at 2022-06-10 22:42:23.068578
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = ConfigSetting("option", "value", "collection", "plugin")
    config_data.update_setting(setting)
    assert setting == config_data.get_setting("option", "collection", "plugin")

# Generated at 2022-06-10 22:42:31.601255
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    plugin = ConfigPlugin()
    plugin.name = "example"
    plugin.type = "module"

    setting1 = ConfigSetting()
    setting1.name = "setting1"
    setting1.value = "value1"
    data.update_setting(setting1, plugin)

    setting2 = ConfigSetting()
    setting2.name = "setting2"
    setting2.value = "value2"
    data.update_setting(setting2)

    result = data.get_setting("setting1", plugin)
    assert result.name == "setting1"
    assert result.value == "value1"

    result = data.get_setting("setting2")
    assert result.name == "setting2"
    assert result.value == "value2"
# End of unit test for method update_setting of

# Generated at 2022-06-10 22:42:36.606508
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    s = get_setting("test1")
    cd.update_setting(s)
    s = get_setting("test2")
    cd.update_setting(s)
    assert get_settings() == [s1, s2]


# Generated at 2022-06-10 22:42:45.964113
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting1 = Setting('setting_name', 'setting_value', [])
    setting2 = Setting('setting_name2', 'setting_value2', [])
    plugin1 = Plugin('plugin_name', 'plugin_type')
    config_data.update_setting(setting1, plugin=plugin1)
    assert config_data._plugins['plugin_type']['plugin_name']['setting_name'] == setting1
    config_data.update_setting(setting2, plugin=plugin1)
    assert config_data._plugins['plugin_type']['plugin_name']['setting_name2'] == setting2
    assert config_data._plugins['plugin_type']['plugin_name'].get('setting_name') == setting1

# Generated at 2022-06-10 22:42:57.471232
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class TestPluginType(object):
        def __init__(self):
            self.type = 'test_type'
        def __eq__(self, other):
            if isinstance(other, TestPluginType):
                return self.type == other.type
            return NotImplemented
        def __ne__(self, other):
            result = self.__eq__(other)
            if result is NotImplemented:
                return result
            return not result
        def __hash__(self):
            return hash(self.type)

    class TestPluginName(object):
        def __init__(self):
            self.type = TestPluginType()
            self.name = 'test_name'

# Generated at 2022-06-10 22:43:08.887149
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.config.setting import Setting

    data = ConfigData()
    setting1 = Setting(name='setting1',
                       value=True,
                       option_type=bool,
                       )
    data.update_setting(setting1)

    assert 'setting1', data.get_setting('setting1')

    from ansible.config.plugin import Plugin
    plugin1 = Plugin(type='action',
                     name='copy',
                     )
    setting2 = Setting(name='setting2',
                       value=True,
                       option_type=bool,
                       )
    data.update_setting(setting2, plugin=plugin1)

    assert 'setting2' == data.get_setting('setting2', plugin=plugin1).name

# Generated at 2022-06-10 22:43:20.802665
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    a = ConfigData()
    assert a.get_setting('foo') == None

    a.update_setting(Setting(name='foo'), plugin=None)

    assert a.get_setting('foo') != None
    assert a.get_setting('foo') == a.get_settings()[0]

    a.update_setting(Setting(name='bar'), plugin=Plugin('collector', 'one'))

    assert a.get_setting('bar', plugin=Plugin('collector', 'one')) != None
    assert a.get_setting('bar', plugin=Plugin('collector', 'one')) == a.get_settings(Plugin('collector', 'one'))[0]

if __name__ == '__main__':
    test_ConfigData_update_setting()



# Generated at 2022-06-10 22:43:25.906143
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansiblelint.rule import Plugin, Rule
    from ansiblelint.rule_loader import RuleLoader

    config_data = ConfigData()

    plugin = Plugin('Test', None)

    rule_loader = RuleLoader()
    rule = rule_loader.load_rule('ANSIBLE0004')
    config_data.update_setting(rule, plugin)

    assert config_data.get_settings() == rule_loader.get_rules()
    assert config_data.get_settings(plugin) == [rule]

# Generated at 2022-06-10 22:43:37.781634
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0

    setting1 = ConfigSetting('enable_plugins', 'value1', 'bool',
                             'A test setting')

    setting2 = ConfigSetting('enable_plugins', 'value2', 'bool',
                             'A test setting')

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    assert len(config_data.get_settings()) == 1

    assert config_data.get_setting('enable_plugins') == setting2

    setting3 = ConfigSetting('host_key_auto_add', 'value3', 'bool',
                             'A test setting')

    config_data.update_setting(setting3)
    assert len(config_data.get_settings()) == 2

    assert config

# Generated at 2022-06-10 22:43:40.834652
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo')
    setting.set_value('1')
    config_data.update_setting(setting)
    assert setting == config_data._global_settings['foo']

# Generated at 2022-06-10 22:43:51.206868
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("x", "global", "global", "global", "global", "global"))
    config_data.update_setting(Setting("z", "global", "global", "global", "global", "global"))
    config_data.update_setting(Setting("y", "global", "global", "global", "global", "global"))
    config_data.update_setting(Setting("x", "inventory", "ec2", "ec2", "ec2", "ec2"))
    config_data.update_setting(Setting("z", "inventory", "ec2", "ec2", "ec2", "ec2"))
    config_data.update_setting(Setting("z", "inventory", "gcp", "gcp", "gcp", "gcp"))
    config_data

# Generated at 2022-06-10 22:43:55.837430
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert data.get_settings() == []

    setting = ConfigSetting(name='TestSetting', value='TestValue')
    data.update_setting(setting)
    assert data.get_settings() == [setting]

    plugin = ConfigPlugin(name='TestPlugin', type='TestType')
    setting = ConfigSetting(name='TestSetting', value='TestValue')
    data.update_setting(setting, plugin)
    assert data.get_settings(plugin) == [setting]

# Generated at 2022-06-10 22:44:03.349274
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert [] == data.get_settings()

    data = ConfigData()
    data.update_setting(Setting(name='username', value='admin'))
    data.update_setting(Setting(name='password', value='admin123'))
    data.update_setting(Setting(name='mac', value='00:50:56:C0:00:01'))
    assert [
        Setting(name='username', value='admin'),
        Setting(name='password', value='admin123'),
        Setting(name='mac', value='00:50:56:C0:00:01')
    ] == data.get_settings()

# Generated at 2022-06-10 22:44:15.416472
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configdata = ConfigData()
    configdata.update_setting(Setting('version', '2'))
    configdata.update_setting(Setting('library', './library'))
    configdata.update_setting(Setting('module_name', 'ansible.module_utils.package'), Plugin('module_utils', 'package'))
    configdata.update_setting(Setting('module_args', 'state=latest name=ansible'), Plugin('module_utils', 'package'))

    version_setting = configdata.get_setting('version')
    assert version_setting.name == 'version'
    assert version_setting.value == '2'

    library_setting = configdata.get_setting('library')
    assert library_setting.name == 'library'
    assert library_setting.value == './library'


# Generated at 2022-06-10 22:44:29.310409
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()

    # Test with invalid setting name
    assert config.get_setting("invalid_name") is None

    # Test with invalid plugin
    plugin = Plugin("invalid_type", "invalid_name")
    assert config.get_setting("invalid_name", plugin) is None

    # Test with valid setting name
    setting = Setting("valid_name", "valid_value")
    config.update_setting(setting)
    assert config.get_setting("valid_name") == setting

    # Test with valid setting name and plugin
    plugin = Plugin("valid_type", "valid_name")
    setting = Setting("valid_name", "valid_value")
    config.update_setting(setting, plugin)
    assert config.get_setting("valid_name", plugin) == setting


# Generated at 2022-06-10 22:44:46.533777
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import pytest
    from types import ModuleType

    from ansiblelint import RulesCollection
    from ansiblelint import RulesCollectionBuilder
    from ansiblelint import AnsibleLintConfig
    from ansiblelint.rules import AnsibleLintRule

    class DummyRule(AnsibleLintRule):
        id = 'DUMMY-RULE'
        shortdesc = 'Dummy rule'
        description = 'Dummy rule'
        tags = ['dummy']

    def test_generator():
        for i in range(3):
            yield i, 'plugin_{0}'.format(i)

    config_data = ConfigData()

    config = AnsibleLintConfig()
    rc_builder = RulesCollectionBuilder()
    rc_builder.register_rules(DummyRule)

# Generated at 2022-06-10 22:44:56.953067
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.common.validation import PluginType
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.plugin_docs import find_plugin_docs_files
    from ansible.utils.plugin_docs import read_docstring

    from ansible.config.manager import ConfigManager
    from ansible.config.manager import ConfigData
    from ansible.config.manager import Setting

    # Setup plugin loader in case there are docstrings
    plugin_loader = PluginLoader(package='ansible_collections.ansible.community.plugins',
                                 directories=[],
                                 defer_load=False,
                                 class_only=True)

    config_data = ConfigData()

    #global_setting = Setting(name=u'ANSIBLE_CON

# Generated at 2022-06-10 22:45:03.016640
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Empty config_data
    assert len(config_data.get_settings()) == 0

    # First plugin
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.action.copy import ActionModule as Plugin1
    plugin1 = PluginLoader.find_plugin(Plugin1.__name__, 'action')
    plugin1_settings = config_data.get_settings(plugin1)
    assert len(plugin1_settings) == 0

    # Second plugin
    from ansible.plugins.action.template import ActionModule as Plugin2
    plugin2 = PluginLoader.find_plugin(Plugin2.__name__, 'action')
    plugin2_settings = config_data.get_settings(plugin2)
    assert len(plugin2_settings) == 0

    # Add first setting

# Generated at 2022-06-10 22:45:15.257616
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin1 = Plugin('local', 'shell')
    plugin2 = Plugin('cliconf', 'ios')
    plugin3 = Plugin('inventory', 'static')

    setting1 = Setting('host', 'localhost')
    setting2 = Setting('username', 'root')
    setting3 = Setting('password', 'test')
    setting4 = Setting('timeout', '5')
    setting5 = Setting('port', '22')
    setting6 = Setting('network_os', 'ios')

    config_data.update_setting(setting1, plugin1)
    config_data.update_setting(setting2, plugin1)
    config_data.update_setting(setting3, plugin1)
    config_data.update_setting(setting4, plugin1)


# Generated at 2022-06-10 22:45:25.787987
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.parsing.plugin_docs import read_docstring
    mock_plugin = MagicMock()

    config_data = ConfigData()

    Setting = namedtuple('Setting', ['plugin_type', 'name', 'default', 'description', 'env'])
    setting_0 = Setting(None, 'ANSIBLE_CALLBACK_WHITELIST', '', '', '')
    setting_1 = Setting(None, 'ANSIBLE_STDOUT_CALLBACK', 'default', '', '')
    setting_2 = Setting(None, 'ANSIBLE_CALLBACK_PLUGINS', '', '', '')
    mock_plugin.type = 'callback'
    mock_plugin.name = 'default'
    setting_3 = Setting(mock_plugin.type, 'callback_whitelist', '', '', '')


# Generated at 2022-06-10 22:45:31.953947
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    global_settings = {}
    global_settings["test"] = "true"
    global_settings["test2"] = "false"
    settings = ConfigData()
    plugin = None
    settings.update_setting(global_settings["test"], plugin)
    settings.update_setting(global_settings["test2"], plugin)
    assert settings.get_settings() == global_settings

# Generated at 2022-06-10 22:45:41.119025
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin1 = PluginDefinition('vagrant', 'box')
    plugin2 = PluginDefinition('vagrant', 'plugin')
    cd = ConfigData()
    cd.update_setting(Setting('vagrant', 'box', 'name', 'value'))
    cd.update_setting(Setting('vagrant', 'box', 'version', 'value'))
    cd.update_setting(Setting('vagrant', 'plugin', 'name', 'value2'))
    assert cd.get_setting(plugin1.name, plugin1) == "value"
    assert cd.get_setting(plugin2.name, plugin2) == "value2"


# Generated at 2022-06-10 22:45:50.102238
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class Setting (object):
        def __init__(self, name, value):
            self.name = name
            self.value = value
            self.origin = None
            self.priority = 0
            self.version = None

    c1 = ConfigData()
    c1.update_setting(Setting('g1', 'test'))
    assert(c1.get_setting('g1') is not None)

    c2 = ConfigData()
    c2.update_setting(Setting('g1', 'test'), 'core')
    assert(c2.get_setting('g1', 'core') is None)


# Generated at 2022-06-10 22:45:52.017802
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_setting("unit_test") is None


# Generated at 2022-06-10 22:46:00.837331
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test non-existing setting
    setting = config_data.get_setting('name')
    assert setting is None

    # Test non-existing setting in plugins
    setting = config_data.get_setting('name', Plugin('nonexisting', 'nonexisting'))
    assert setting is None

    # Test existing setting
    config_data.update_setting(Setting('name', 'value'))
    setting = config_data.get_setting('name')
    assert setting
    assert setting == Setting('name', 'value')

    # Test existing setting in plugins
    config_data.update_setting(Setting('name', 'value'), Plugin('nonexisting', 'nonexisting'))
    setting = config_data.get_setting('name', Plugin('nonexisting', 'nonexisting'))
    assert setting

# Generated at 2022-06-10 22:46:18.510821
# Unit test for method get_settings of class ConfigData

# Generated at 2022-06-10 22:46:26.356024
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # The test uses the plugin with the following path:
    #     tests/sanity/code-smell/docs-module-not-found.py
    plugin_type = 'code_smell'
    plugin_name = 'docs_module_not_found'

    configData = ConfigData()
    setting_default = Setting(plugin_type, plugin_name, 'default')
    setting_default.value = '1.0'
    setting_default.description = 'Default value if the setting is not set.'
    configData.update_setting(setting_default)
    setting_example = Setting(plugin_type, plugin_name, 'example')
    setting_example.value = 'False'
    setting_example.description = 'Example value for the setting.'
    configData.update_setting(setting_example)

    # Test that the default settings

# Generated at 2022-06-10 22:46:30.725955
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(DefSetting("/usr/local/bin/ansible", "executable", "core", None))
    assert config.get_setting("/usr/local/bin/ansible", None).name == "/usr/local/bin/ansible"
    assert config.get_setting("/usr/local/bin/ansible", None).plugin_name is None
    assert config.get_setting("/usr/local/bin/ansible", None).plugin_type is None
    assert config.get_setting("/usr/local/bin/ansible", None).value == "/usr/local/bin/ansible"

# Generated at 2022-06-10 22:46:33.253726
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting(name='key_no_value') is None


# Generated at 2022-06-10 22:46:37.659169
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    plugin = Plugin('MyPlugin', 'mytype')
    s = Setting('myhostname', 'somehostname')
    cd.update_setting(s, plugin)
    assert cd.get_setting('myhostname') is None
    assert cd.get_setting('myhostname', plugin) is not None


# Generated at 2022-06-10 22:46:48.735868
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # This test is for a setting that does not exist in the configuration data
    # yet.
    setting = ConfigSetting('some_key', 'some_value')
    data = ConfigData()
    data.update_setting(setting)
    assert data.get_setting('some_key') == setting
    # This test is for a setting that already exists in the configuration data.
    # The value of the setting objects should be different.
    setting = ConfigSetting('some_key', 'some_value_2')
    data.update_setting(setting)
    assert data.get_setting('some_key') == setting
    # This test is for updating a setting in a plugin.
    setting = ConfigSetting('some_key', 'some_plugin_value')
    plugin = Plugin('type', 'name')
    data.update_setting(setting, plugin)
   

# Generated at 2022-06-10 22:46:54.040514
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    print(cd.get_setting('test'))
    print(cd.get_setting('test', plugin=1))
    print(cd.get_setting('ansible_python_interpreter'))
    print(cd.get_setting('ANSIBLE_CONFIG'))

test_ConfigData_get_setting()

# Generated at 2022-06-10 22:46:58.093452
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    dummy_setting = Setting()
    config_data = ConfigData()
    config_data.update_setting(dummy_setting)
    assert(config_data._global_settings["/usr/share/ansible/ansible.cfg"] == dummy_setting)


# Generated at 2022-06-10 22:47:08.054120
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    cd = ConfigData()

    setting1 = {'name': 'default_transport', 'plugin': None, 'value': 'ssh'}
    setting2 = {'name': 'remote_user', 'plugin': None, 'value': 'root'}
    setting3 = {'name': 'host_key_checking', 'plugin': None, 'value': False}
    setting4 = {'name': 'port', 'plugin': None, 'value': 22}
    setting5 = {'name': 'log_path', 'plugin': None, 'value': '/var/log/ansible.log'}
    setting6 = {'name': 'interpreter_python', 'plugin': None, 'value': '/usr/bin/python3'}

# Generated at 2022-06-10 22:47:10.066916
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    assert config_data.get_setting(None) is None



# Generated at 2022-06-10 22:47:40.124964
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print("\nStart unit testing...\n")
    config = ConfigData()
    assert len(config._global_settings.keys()) == 0
    assert len(config._plugins.keys()) == 0
    assert config.get_setting("default_log_path",plugin=None) == None

    # Testing global config
    setting = ConfigSetting("default_log_path", "/var/log/ansible")
    assert setting.name == "default_log_path"
    assert setting.value == "/var/log/ansible"
    assert setting.plugin == None

    config.update_setting(setting)
    assert config.get_setting("default_log_path",plugin=None) == setting
    assert len(config._global_settings.keys()) == 1
    assert len(config._plugins.keys()) == 0

    # Testing plugin config
   

# Generated at 2022-06-10 22:47:52.314323
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()

    from ansiblelint.rules.NoDebugOrWarnRule import NoDebugOrWarnRule
    from ansiblelint.rule import RuleMatch

    class DummySetting:

        def __init__(self, name, plugin):
            self.name = name
            self.plugin = plugin
            self.id = ''

    class DummyPlugin:

        def __init__(self, name, type):
            self.name = name
            self.type = type

    plugin_no_debug_or_warn = DummyPlugin('no-debug-or-warn', 'rules')
    setting_no_debug_or_warn = DummySetting('no-debug-or-warn', plugin_no_debug_or_warn)


# Generated at 2022-06-10 22:48:00.006441
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting = Setting("my_setting", ["my_value"])
    plugin = Plugin("my_plugin", "network_os")
    config_data = ConfigData()
    config_data.update_setting(setting=setting, plugin=plugin)
    assert "my_setting" in config_data._plugins["network_os"]["my_plugin"]
    assert config_data._plugins["network_os"]["my_plugin"]["my_setting"].name == "my_setting"
    assert config_data._plugins["network_os"]["my_plugin"]["my_setting"].value == ["my_value"]


# Generated at 2022-06-10 22:48:06.579080
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()

    # check that get_setting return set value
    setting = Setting('abc', Plugin('abc'))
    config._plugins['abc']['abc']['abc'] = setting
    assert config.get_setting('abc', 'abc') == setting

    # check that get_setting return None when value is not set
    assert config.get_setting('ghi', 'jkl') is None



# Generated at 2022-06-10 22:48:10.579172
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    setting = Setting('one', 'global', 'globalvalue')
    data.update_setting(setting)
    assert data.get_setting('one') == setting


# Generated at 2022-06-10 22:48:20.318653
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting()
    setting.name = 'config_data_update_setting_test'
    config_data.update_setting(setting)
    retval = config_data.get_setting('config_data_update_setting_test')
    assert retval is not None and retval.name == 'config_data_update_setting_test'
    config_data.update_setting(setting)
    retval = config_data.get_settings()
    assert len(retval) == 1 and retval[0].name == 'config_data_update_setting_test'
    config_data.update_setting(setting, plugin=Plugin('plugin_type', 'plugin_name'))

# Generated at 2022-06-10 22:48:31.225510
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    plugin = None
    settings = config_data.get_settings(plugin)
    assert settings == []

    plugin = Plugin('hosts', None)
    settings = config_data.get_settings(plugin)
    assert settings == []

    plugin = Plugin('hosts', 'test_host')
    settings = config_data.get_settings(plugin)
    assert settings == []

    config_data.update_setting(Setting('test', 'value'))
    config_data.update_setting(Setting('test1', 'value1'))
    config_data.update_setting(Setting('test2', 'value2'))

    plugin = None
    settings = config_data.get_settings(plugin)
    assert len(settings) == 3

    return


# Generated at 2022-06-10 22:48:39.410418
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    script_dir = os.path.dirname(__file__)
    data = ConfigData.ConfigData()
    setting = ConfigSetting.ConfigSetting('test', "test for ConfigData", ConfigData._ConfigData__get_setting, ConfigData._ConfigData__update_setting)
    with open(os.path.join(script_dir, 'test_data/test_update_setting.yml')) as f:
      data.update_setting(setting, os.path.join(script_dir, 'test_data/test_update_setting.yml'))
      assert setting.value == 1


# Generated at 2022-06-10 22:48:47.502697
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("ansible_connection", "local"))
    config_data.update_setting(Setting("ansible_python_interpreter", "/usr/bin/python"))
    config_data.update_setting(Setting("vault_password", "password", "vault", "/home/user/.vault_pass.txt"))
    setting = config_data.get_setting("ansible_connection")
    assert setting.value == "local"
    setting = config_data.get_setting("vault_password", Plugin("vault", "password", "/home/user/.vault_pass.txt"))
    assert setting.value == "/home/user/.vault_pass.txt"
    assert setting.plugin.name == "password"

# Generated at 2022-06-10 22:48:50.101482
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin = {}
    plugin = ConfigData()
    assert plugin == {'type': {'name': {'name': 'setting'}}}


# Generated at 2022-06-10 22:49:26.766805
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('name', 'value'))
    assert config_data._global_settings['name'].value == 'value'
    assert config_data.get_setting('name') == config_data._global_settings['name']


# Generated at 2022-06-10 22:49:34.397116
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    configData.update_setting(Setting('perl_binary', 'perl_binary', '', '', '/usr/bin/perl'))

    assert configData.get_setting('perl_binary').value == '/usr/bin/perl'
    assert configData.get_setting('perl_binary', Plugin('filter', 'ipaddr')) == None
    assert configData.get_setting('bogus_setting') == None



# Generated at 2022-06-10 22:49:44.238041
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()
    plugin = PluginInfo('test', 'collections')

    setting = SettingInfo('TEST_VAR', 'test')
    assert config.get_setting('TEST_VAR') is None
    config.update_setting(setting)
    setting = SettingInfo('TEST_VAR', 'test')
    assert config.get_setting('TEST_VAR', plugin) is None

    setting = SettingInfo('TEST_VAR', 'value')
    config.update_setting(setting, plugin)
    assert config.get_setting('TEST_VAR', plugin)

    expected_settings = [('TEST_VAR', 'value')]
    settings = config.get_settings(plugin)
    assert len(settings) == 1
    assert (settings[0].name, settings[0].value) in expected

# Generated at 2022-06-10 22:49:52.565862
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting1 = ConfigData()
    setting2 = ConfigData()
    setting3 = ConfigData()
    # Setting 1 & 2 have the same name
    setting1.name = 'domain'
    setting2.name = 'domain'
    # Setting 3 has another name
    setting3.name = 'username'

    # test is the setting 1 & 2 are in the same plugin
    assert setting1.plugin == setting2.plugin


    #Iterate the settings
    for setting in setting1:
        setting.update_global_setting(setting)

    for setting in setting1:
        setting.update_global_setting(setting)

    assert setting1.get_setting('domain')

# Generated at 2022-06-10 22:49:59.819803
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import unittest2 as unittest
    from ansiblelint import Runner, RulesCollection
    from ansiblelint.rules import RulesCollection
    import ansiblelint.utils

    from ansiblelint.runner import Runner
    from ansiblelint.rules import RulesCollection
    from ansiblelint import AnsibleLintRule
    class MyTestRule(AnsibleLintRule):
        id = 'TEST-1'
        shortdesc = 'Test Rule'
        severity = 'VERY HIGH'
        description = ''
        tags = ['tests']

        def match(self, file, line):
            return True

    class TestConfigData(unittest.TestCase):

        def setUp(self):
            self.runner = Runner(
                RulesCollection(), '', [], [], [], [])

# Generated at 2022-06-10 22:50:11.314553
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    assert c._global_settings == {}
    assert c._plugins == {}
    s = Setting('foo', 'bar', 'baz')
    c.update_setting(s)
    assert c._global_settings == {'foo': s}
    assert c._plugins == {}
    s = Setting('foo', 'bar', 'baz')
    c.update_setting(s, 'foo')
    assert c._global_settings == {'foo': s}
    assert c._plugins == {}
    s = Setting('foo', 'baz', 'baz')
    c.update_setting(s, Plugin('bar', 'baz'))
    assert c._global_settings == {'foo': s}
    assert c._plugins == {'bar': {'baz': {'foo': s}}}



# Generated at 2022-06-10 22:50:13.197526
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    data  = ConfigData()
    data.update_setting(setting)

    assert data._global_settings

# Generated at 2022-06-10 22:50:14.765904
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    conf = ConfigData()
    assert conf.get_setting("name") is None


# Generated at 2022-06-10 22:50:23.264319
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data._global_settings["foo"] = "bar"
    config_data._global_settings["bar"] = "baz"
    config_data._plugins["foo"] = {"bar": {"baz": "qux"}}

    assert config_data.get_setting("foo") == "bar"
    assert config_data.get_setting("bar") == "baz"
    assert config_data.get_setting("baz", Plugin("foo", "bar")) == "qux"
    assert config_data.get_setting("not there") is None
    assert config_data.get_setting("not there", Plugin("foo", "bar")) is None


# Generated at 2022-06-10 22:50:33.659348
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    conf = ConfigData()
    conf.update_setting(Setting(name='timeout', value='30', origin='/a/b/ansible.cfg'))
    conf.update_setting(Setting(name='timeout', value='10', origin='/a/b/ansible.cfg', plugin=Plugin(type='c', name='d')))
    conf.update_setting(Setting(name='timeout', value='15', origin='/a/b/ansible.cfg', plugin=Plugin(type='e', name='f')))
    conf.update_setting(Setting(name='timeout', value='20', origin='/a/b/ansible.cfg', plugin=Plugin(type='e', name='g')))
