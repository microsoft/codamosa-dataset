

# Generated at 2022-06-10 22:40:42.134578
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(ConfigSetting(name='foo', value='bar'))
    config_data.update_setting(ConfigSetting(name='baz', value='qux'))
    assert config_data.get_setting('foo').value == 'bar'
    assert config_data.get_setting('baz').value == 'qux'
    assert config_data.get_setting('unknown') is None

    config_data.update_setting(ConfigSetting(name='foo', value='quux'), plugin=Plugin('lookup', 'password'))
    config_data.update_setting(ConfigSetting(name='baz', value='quuz'), plugin=Plugin('lookup', 'password'))
    assert config_data.get_setting('foo').value == 'bar'

# Generated at 2022-06-10 22:40:50.448530
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # GIVEN
    setting = Setting(name='test1')
    plugin = Plugin(name='test2', type='test3')
    data = ConfigData()

    # WHEN
    data.update_setting(setting, plugin)

    # THEN
    assert None is data.get_setting('test1')
    assert None is data.get_setting('test2')
    assert None is data.get_setting('test3')
    assert None is data.get_setting('test4', plugin)

    assert None is data.get_setting(None, plugin)
    assert None is data.get_setting('test1', plugin)
    assert 'test3' == data.get_setting('test2', plugin).name
    assert None is data.get_setting('test3', plugin)

# Generated at 2022-06-10 22:40:59.553198
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Exercise
    config_data = ConfigData()
    config_data.update_setting(Setting('version', '2.9'))

    # Verify
    assert config_data._global_settings.get('version').name == 'version', 'Expected the global settings to have a setting called version'
    assert config_data._global_settings.get('version').value == '2.9', 'Expected the global settings to have a value of 2.9 for the version setting'
    assert len(config_data._global_settings) == 1, 'Expected there to be one entry in the global settings'
    assert len(config_data._plugins) == 0, 'Expected there to be no plugin data'


# Generated at 2022-06-10 22:41:07.405949
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import copy_loader
    from ansible.plugins.action import ActionBase
    # Create the basic plugins and settings
    plugins = [
        (
            ActionBase,
            [
                'TestPlugin',
            ]
        ),
        (
            copy_loader,
            [
                'TestLoader',
            ]
        ),
    ]

# Generated at 2022-06-10 22:41:19.059619
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    def get_setting(config_data, plugin_names):
        global_settings = config_data.get_settings()
        for plugin_name in plugin_names:
            assert len(global_settings) == 2
            assert config_data.get_setting('plugin_type',plugin_name) == 'test'
            assert config_data.get_setting('plugin_name',plugin_name) == plugin_name.name

    config_data = ConfigData()
    plugin1 = Plugin('test','plugin1')
    plugin2 = Plugin('test','plugin2')

    setting1 = Setting('plugin_type', 'test')
    setting2 = Setting('plugin_name', 'plugin1')
    config_data.update_setting(setting1)
    config_data.update_setting(setting2,plugin1)


# Generated at 2022-06-10 22:41:28.798020
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('boolean_global_set', 'true'))
    config_data.update_setting(Setting('integer_global_set', '3'), None)
    config_data.update_setting(Setting('string_global_set', 'string'), None)
    config_data.update_setting(Setting('boolean_set', 'false', Plugin(Plugin.TYPE_MODULE, 'boolean')), Plugin(Plugin.TYPE_MODULE, 'boolean'))
    config_data.update_setting(Setting('integer_set', '5', Plugin(Plugin.TYPE_MODULE, 'integer')), Plugin(Plugin.TYPE_MODULE, 'integer'))

# Generated at 2022-06-10 22:41:37.932043
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    data.update_setting(Setting('pkcs11_module_path' , '/usr/lib/opensc-pkcs11.so'))
    assert data.get_setting('pkcs11_module_path')

    data.update_setting(Setting('plugin_filters', 'repo:.*'))
    assert data.get_setting('plugin_filters')

    data.update_setting(Setting('_name', 'git'), Plugin('repo_git', 'vars'))
    assert data.get_setting('_name', Plugin('repo_git', 'vars'))

    data.update_setting(Setting('url', 'https://github.com/ansible/ansible'))
    assert data.get_setting('url')


# Generated at 2022-06-10 22:41:49.023077
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()
    setting_1 = PluginSetting('a_new_setting', 'a new setting')
    config_data.update_setting(setting_1)
    setting_2 = PluginSetting('a_new_setting', 'another new setting', Plugin(PluginLoader.lookup_plugin_loader('filter')))
    config_data.update_setting(setting_2)

    if config_data.get_setting('a_new_setting').value != 'a new setting':
        raise AssertionError("Expected 'a new setting', got '%s'" % config_data.get_setting('a_new_setting').value)

# Generated at 2022-06-10 22:42:00.878560
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    assert config_data.get_setting("test1", None) is None
    assert config_data.get_setting("test2") is None
    assert config_data.get_setting("test3", None) is None
    assert config_data.get_setting("test4") is None

    assert config_data.get_settings(None) == []
    assert config_data.get_settings() == []

    import ansible.plugins.loader as loader
    plugin1 = loader.PluginLoader("strategy", "plugin1")
    plugin2 = loader.PluginLoader("strategy", "plugin2")

    from ansible.playbook.play_context import PlayContext
    config_data.update_setting(PlayContext.DEFAULT_SUDO_EXE, plugin1)
    config_data.update_setting

# Generated at 2022-06-10 22:42:07.205259
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from container.lxc.settings import ConfigSetting

    d = ConfigData()
    d.update_setting(ConfigSetting('lxc.hook.pre-start', '/path/to/script', ConfigAttribute.NONE, 'lxc.hook.pre-start', None))

    assert d.get_setting('lxc.hook.pre-start')[0].name == 'lxc.hook.pre-start'
    assert d.get_setting('lxc.hook.pre-start')[0].value == '/path/to/script'


# Generated at 2022-06-10 22:42:15.810827
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    '''TestConfigData'''
    cdata = ConfigData()
    cdata.update_setting(ConfigSetting("host", "localhost", "hostname of this computer"))
    cdata.update_setting(ConfigSetting("host", "localhost", "hostname of this computer"))
    cdata.update_setting(ConfigSetting("host", "localhost", "hostname of this computer"))
    print(cdata.get_settings())
    print(cdata.get_settings())
    print(cdata.get_settings())

# Generated at 2022-06-10 22:42:17.994939
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    assert data.get_setting('provider') is None



# Generated at 2022-06-10 22:42:22.676607
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    configData = ConfigData()
    assert configData.get_setting('name') is None

    # define a global setting
    setting = {'name': 'foo', 'value': 'bar'}
    configData.update_setting(setting)
    assert configData.get_setting('foo') == setting


# Generated at 2022-06-10 22:42:28.099335
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = ConfigSetting(name="test_setting")
    plugin = Plugin(type="test_type", name="test_name")
    config_data.update_setting(setting, plugin)

    assert config_data._plugins == {
        "test_type": {
            "test_name": {
                "test_setting": setting
            }
        }
    }


# Generated at 2022-06-10 22:42:39.024536
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    setting = {"name": "CONFIG_FILE", "value": "~/ansible.cfg", "priority": 0, "version": 0}
    config_data.update_setting(setting)

    assert config_data._global_settings.get("CONFIG_FILE")

    setting = {"name": "INVENTORY", "value": "hosts", "priority": 0, "version": 0}
    plugin = {"type": "inventory", "name": "hosts"}
    config_data.update_setting(setting, plugin)
    plugin = {"type": "inventory", "name": "hosts"}
    assert config_data.get_setting("INVENTORY", plugin)



# Generated at 2022-06-10 22:42:45.677673
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Set up defaults
    new_plugin = Plugin('python', 'connection')
    new_setting = PluginSetting('paramiko_connection', 'string')

    # Create new instance of class ConfigData
    cd = ConfigData()

    # Update setting of the new instance with the new plugin and new setting
    cd.update_setting(new_setting, new_plugin)

    # Confirm setting was updated
    assert(cd._global_settings[new_setting.name] == new_setting)
    assert(cd._plugins[new_plugin.type][new_plugin.name][new_setting.name] == new_setting)


# Generated at 2022-06-10 22:42:50.464431
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    data.update_setting('a', plugin='bin')
    data.update_setting('b', plugin='bin')
    data.update_setting('c', plugin='bin')
    data.update_setting('d', plugin='bin')
    print(data)


# Generated at 2022-06-10 22:42:59.932852
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    assert configData.get_settings() == []

    plugin_name = 'my plugin'
    plugin_type = 'my type'
    setting_name = 'my setting'
    setting_value = 'my value'

    plugin = Plugin(plugin_name, plugin_type)
    setting = Setting(setting_name, setting_value)
    configData.update_setting(setting, plugin)

    assert setting == configData.get_setting(setting_name, plugin)
    assert [setting] == configData.get_settings(plugin)
    assert configData.get_settings() == []



# Generated at 2022-06-10 22:43:09.944770
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from collections import namedtuple

    cd = ConfigData()
    # Setting defined for a specific plugin
    s = namedtuple('Setting', ['name', 'value', 'origin'])
    p = namedtuple('Plugin', ['type', 'name'])
    plugin = p("lookup", "some_lookup")
    setting = s("skip_duplicates", True, "some_lookup.yml")
    cd.update_setting(setting, plugin)
    assert cd.get_setting("skip_duplicates", plugin) == setting

    # Setting defined for a specific plugin
    # But retrieved for another plugin
    plugin2 = p("lookup", "another_lookup")
    assert cd.get_setting("skip_duplicates", plugin2) == None

    # Setting defined for globals

# Generated at 2022-06-10 22:43:22.380104
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    config._global_settings = {
        "domainname": {
            "name": "domainname",
            "value": "test.example.com",
            "path": "/etc/resolv.conf",
            "key": "domain",
            "merge_type": "replace",
            "merge_priority": 10,
            "template": None,
            "backup": False
        },
        "search": {
            "name": "search",
            "value": ["test.example.com"],
            "path": "/etc/resolv.conf",
            "key": "search",
            "merge_type": "append",
            "merge_priority": 10,
            "template": None,
            "backup": False
        }
    }

# Generated at 2022-06-10 22:43:37.065407
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting( GlobalSetting( 'g_name_1', 'g_value_1', 'g_origin_1' ) )
    config_data.update_setting( PluginSetting( 'g_name_2', 'g_value_2', 'g_origin_2' ) )
    config_data.update_setting( PluginSetting( 'c_name_1', 'c_value_1', 'c_origin_1' ), collector_plugin )
    config_data.update_setting( PluginSetting( 'c_name_2', 'c_value_2', 'c_origin_2' ), collector_plugin )
    config_data.update_setting( PluginSetting( 'e_name_1', 'e_value_1', 'e_origin_1' ), callback_plugin )
   

# Generated at 2022-06-10 22:43:42.264182
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # set up object
    config = ConfigData()
    config.update_setting(Setting(name='first', value='one'))
    config.update_setting(Setting(name='second', value='two'))

    # test expected results
    assert config.get_settings() == [Setting(name='first', value='one'), Setting(name='second', value='two')]

# Generated at 2022-06-10 22:43:52.404317
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    '''
    Unit test for method get_settings of class ConfigData
    '''
    from configparser import ConfigParser, NoSectionError
    from collections import namedtuple
    from ansible.utils.config_loader import ConfigLoader, get_config_file
    import os.path

    # namedtuple to store setting
    Setting = namedtuple('Setting', ['name', 'value', 'source'])

    # Config data to hold all settings
    config_data = ConfigData()

    # load global config settings
    loader = None
    try:
        loader = ConfigLoader()
    except NoSectionError as e:
        pass

    # create a global setting
    global_setting = Setting('root_path', '/', 'global')

    # update global setting
    config_data.update_setting(global_setting)

    # create and update a

# Generated at 2022-06-10 22:43:56.110302
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    config.update_setting(Setting('test1', 'test1'))
    config.update_setting(Setting('test2', 'test2'))
    settings = [setting.name for setting in config.get_settings()]
    assert len(settings) == 2
    assert 'test1' in settings
    assert 'test2' in settings


# Generated at 2022-06-10 22:44:07.432307
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.module_utils.common.collections import ImmutableDict

    config_data = ConfigData()
    plugin = ImmutableDict(dict(type='fraction', name='default'))

# Generated at 2022-06-10 22:44:15.653340
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Test 1: Update a global config setting
    scope = ConfigData()
    scope.update_setting(ConfigSetting("my_setting", "my_value", None))

    # Test 2: Update a plugin config setting
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader('connection', 'local', None).get()
    scope.update_setting(ConfigSetting("my_setting", "my_value", plugin))

    # Test 3: Check for correct config setting retrieval
    assert ConfigData.get_setting("my_setting") == "my_value"
    assert ConfigData.get_setting("my_setting", plugin) == "my_value"

# Generated at 2022-06-10 22:44:21.531892
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Setup objects necessary for testing get_setting
    config_data = ConfigData()
    plugin = Plugin('connection', 'local')
    setting = Setting('hostfile', 'foo')

    # Assert that an empty object returns None
    assert config_data.get_setting('hostfile') is None

    # Assert that an object without the requested setting returns None
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('hash_behaviour') is None

    # Assert that a global setting returns a setting
    assert config_data.get_setting('hostfile') is setting

    # Assert that a plugin setting returns a setting
    assert config_data.get_setting('hostfile', plugin) is setting

    # Assert that a non-existent plugin returns None

# Generated at 2022-06-10 22:44:32.498524
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.parsing.plugin_docs import read_docstring

    config_data = ConfigData()

    module = ModuleFixture(type='module', name='foo_module')
    config = ConfigFixture(name='BAR', module=module)
    docstring = read_docstring(config_data)
    config_data.update_setting(config)
    settings = config_data.get_settings(module)

    assert len(settings) == 1

    assert settings[0].name == config.name
    assert settings[0].plugin.name == module.name
    assert settings[0].plugin.type == module.type

    # Check all available settings
    settings = config_data.get_settings()
    assert len(settings) == 1
    assert settings[0] == config



# Generated at 2022-06-10 22:44:45.480249
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    plugin_type = "test_type"
    plugin_name = "test_name"
    setting_name = "test_config"
    setting_value = "test_value"

    config_data = ConfigData()
    assert config_data.get_setting(setting_name) is None

    from ansible.utils.config_data import ConfigSetting

    plugin_setting = ConfigSetting(setting_name, setting_value)
    config_data.update_setting(plugin_setting)

    assert config_data.get_setting(setting_name) is not None
    assert config_data.get_setting(setting_name).name == setting_name
    assert config_data.get_setting(setting_name).value == setting_value
    assert config_data.get_setting(setting_name).plugin is None


# Generated at 2022-06-10 22:44:56.167430
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Empty object tests
    config = ConfigData()
    assert len(config._global_settings) == 0
    assert len(config._plugins) == 0

    # Non-empty object tests
    plugin_object = Plugin('network', 'ios')
    config_object = Config(plugin_object, 'enable_network_logging', True, 'should the network logging be enabled?')
    config.update_setting(config_object)

    assert len(config._global_settings) == 0
    assert len(config._plugins) == 1
    assert 'network' in config._plugins
    assert 'ios' in config._plugins['network']
    assert 'enable_network_logging' in config._plugins['network']['ios']
    assert isinstance(config._plugins['network']['ios']['enable_network_logging'], Config)
   

# Generated at 2022-06-10 22:45:01.767007
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)

    config_data.update_setting(Setting('test', 'Test', 'Test'))
    assert config_data.get_setting('test') != None

# Generated at 2022-06-10 22:45:13.342792
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    obj = ConfigData()
    plugin1 = Plugin('cache', 'memory')
    plugin2 = Plugin('action', 'acme')
    plugin_setting1 = Setting('plugin_setting_1')
    plugin_setting2 = Setting('plugin_setting_2')
    global_setting = Setting('global_setting')
    obj.update_setting(plugin_setting1, plugin1)
    obj.update_setting(plugin_setting2, plugin2)
    obj.update_setting(global_setting)
    assert obj.get_settings() == [global_setting]
    assert obj.get_settings(plugin1) == [plugin_setting1]
    assert obj.get_settings(plugin2) == [plugin_setting2]


# Generated at 2022-06-10 22:45:18.027955
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from .setting import Setting as s
    setting = s(name='test1', value='value1')
    from .plugin import Plugin as p
    plugin = p('Collections', 'aws')

    data = ConfigData()
    data.update_setting(setting=setting)

    data.update_setting(setting=setting, plugin=plugin)

    assert data.get_settings(plugin=plugin)[0].name == 'test1'

# Generated at 2022-06-10 22:45:28.637676
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting())
    config_data.update_setting(ConfigSetting(), ConfigPlugin())
    config_data.update_setting(ConfigSetting())
    config_data.update_setting(ConfigSetting(), ConfigPlugin())

    assert config_data._global_settings.get('setting1') is not None
    assert config_data._global_settings.get('setting2') is None
    assert config_data._plugins.get('default') is not None
    assert config_data._plugins.get('default').get('config') is not None
    assert config_data._plugins.get('default').get('config').get('setting1') is not None
    assert config_data._plugins.get('default').get('config').get('setting2') is None


# Generated at 2022-06-10 22:45:33.215802
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint.rules import ConfigData
    from ansiblelint.rules.Setting import Setting

    config_data = ConfigData()
    setting = Setting('test', 'test')

    config_data.update_setting(setting)
    assert config_data.get_setting('test') == setting



# Generated at 2022-06-10 22:45:44.877554
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0

    config_data.update_setting('global name')
    assert len(config_data._global_settings) == 1
    assert len(config_data._plugins) == 0
    assert 'global name' in config_data._global_settings

    config_data.update_setting('plugin name', 'plugin type', 'plugin name')
    assert len(config_data._global_settings) == 1
    assert len(config_data._plugins) == 1
    assert 'plugin type' in config_data._plugins
    assert len(config_data._plugins['plugin type']) == 1
    assert 'plugin name' in config_data._plugins['plugin type']

# Generated at 2022-06-10 22:45:51.704858
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint.rules.MultilineStringRule import MultilineStringRule
    from ansiblelint.utils import AnsibleLintConfig

    config = AnsibleLintConfig()
    config.update_setting(MultilineStringRule, config.get_plugins().get('MULTIPLE_LINES_IN_BLOCK'))
    assert config.get_setting('no_multiline_block').plugin == config.get_plugins().get('MULTIPLE_LINES_IN_BLOCK')

# Generated at 2022-06-10 22:45:59.032584
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()
    config.update_setting(Setting('blabla1', 'pouet', 'pouet'))
    config.update_setting(Setting('blabla2', 'pouet', 'pouet'), Plugin('connection', 'local'))

    assert len(config.get_settings()) == 1
    assert len(config.get_settings(Plugin('connection', 'local'))) == 1
    assert config.get_settings()[0].name == 'blabla1'
    assert config.get_settings(Plugin('connection', 'local'))[0].name == 'blabla2'



# Generated at 2022-06-10 22:46:08.896053
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    setting1 = {'name': 'plugin_type', 'plugin_type': 'type1', 'plugin_name': 'name1', 'value': 'value1'}
    setting2 = {'name': 'plugin_type', 'plugin_type': 'type1', 'plugin_name': 'name1', 'value': 'value2'}
    setting3 = {'name': 'plugin_name', 'plugin_type': 'type1', 'plugin_name': 'name1', 'value': 'value3'}

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting3)

    settings = config_data.get_settings(plugin=None)

    print("\ntest_ConfigData_get_settings.")


# Generated at 2022-06-10 22:46:18.459514
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from units.mock.conf import PluginSetting

    config_data = ConfigData()

    test_name = 'test_name'

    mock_plugin = None
    assert config_data.get_settings(plugin=mock_plugin) == []

    mock_plugin = 'mock_plugin'
    assert config_data.get_settings(plugin=mock_plugin) == []

    mock_plugin.type = 'mock_type'
    assert config_data.get_settings(plugin=mock_plugin) == []

    mock_plugin.name = 'mock_name'
    assert config_data.get_settings(plugin=mock_plugin) == []

    config_data._global_settings = {test_name: 'test_value'}
    assert config_data.get_settings(plugin=mock_plugin) == []

# Generated at 2022-06-10 22:46:29.512492
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    
    # Test on global settings
    setting_foo = Setting('foo', 'bar')
    config_data.update_setting(setting_foo)
    assert config_data.get_setting('foo') is setting_foo
    
    # Test on plugin settings with a new plugin
    plugin = Plugin('disk', 'netapp')
    setting_baz = Setting('baz', 'qux')
    config_data.update_setting(setting_baz, plugin)
    assert config_data.get_setting('baz', plugin) is setting_baz

    # Test on plugin settings with an existing plugin
    setting_quux = Setting('quux', 'quuz')
    config_data.update_setting(setting_quux, plugin)

# Generated at 2022-06-10 22:46:30.893675
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    assert config.get_settings() == []


# Generated at 2022-06-10 22:46:33.243948
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    setting = Setting('test', '')
    plugin = Plugin('test', '')
    config.update_setting(setting)
    assert config.get_setting('test') == setting
    config.update_setting(setting, plugin)
    assert config.get_setting('test', plugin) == setting


# Generated at 2022-06-10 22:46:40.990437
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Create a config instance
    config = ConfigData()

    # Create a plugin instance
    plugin = Plugin()

    # Create a global setting instance
    global_setting = Setting()

    # Create a plugin specific setting instance
    plugin_setting = Setting()

    # Assign appropriate values to the global setting
    global_setting.name = 'global_setting_name'
    global_setting.value = 'global_setting_value'

    # Assign appropriate values to the plugin setting
    plugin_setting.name = 'plugin_setting_name'
    plugin_setting.value = 'plugin_setting_value'

    # Update the config instance with the global setting
    config.update_setting(global_setting)

    # Update the config instance with the plugin setting
    config.update_setting(plugin_setting, plugin)

    # Make sure that the global setting was

# Generated at 2022-06-10 22:46:50.059183
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data._global_settings["socket_timeout"] = "10"
    config_data._plugins["action"]["action_plugin"]["socket_timeout"] = "20"
    config_data._plugins["action"]["action_plugin_2"]["socket_timeout"] = "30"

    assert config_data.get_setting("socket_timeout") == "10"
    assert config_data.get_setting("socket_timeout", "action_plugin") == "20"
    assert config_data.get_setting("socket_timeout", "action_plugin_2") == "30"


# Generated at 2022-06-10 22:46:59.599999
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import ansible_test._internal.plugins.loader
    from ansible_test._internal.cli.config import ConfigData

    config_data = ConfigData()
    plugin_class = ansible_test._internal.plugins.loader.ActionModule()

    config_data.update_setting(plugin_class.get_setting('action_plugins'), None)
    config_data.update_setting(plugin_class.get_setting('module_utils'), None)

    config_data.update_setting(plugin_class.get_setting('action_plugins'), plugin_class)
    config_data.update_setting(plugin_class.get_setting('module_utils'), plugin_class)

    assert config_data.get_setting('action_plugins') != None
    assert config_data.get_setting('module_utils') != None

    assert config_data.get

# Generated at 2022-06-10 22:47:08.596617
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from ansible.inventory.config import Plugin, Setting
    from ansible.inventory.config import ConfigData
    config = ConfigData()
    global_setting = Setting('foo', 'bar', description='Global setting')
    plugin = Plugin('foo', 'bar')
    setting = Setting('foo', 'bar', description='Plugin setting')
    config.update_setting(global_setting)
    config.update_setting(setting, plugin=plugin)
    assert config.get_setting('foo') == global_setting
    assert config.get_setting('foo', plugin=plugin) == setting
    assert config.get_setting('nonexistant') is None
    assert config.get_setting('nonexistant', plugin=plugin) is None


# Generated at 2022-06-10 22:47:14.771818
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    global_setting = Setting('test_setting', value='test_value')
    config_data = ConfigData()
    config_data.update_setting(global_setting)
    s = config_data.get_setting('test_setting')
    assert s.name == 'test_setting'
    assert s.value == 'test_value'
    assert config_data.get_setting('test_setting2') is None
    assert config_data.get_setting('test_setting2', Plugin(name='test_plugin')) is None



# Generated at 2022-06-10 22:47:26.334124
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    configdata = ConfigData()
    configdata.update_setting(Setting(name='c.d', value='c', origin='d', priority=0))
    configdata.update_setting(Setting(name='a.b', value='a', origin='b', priority=0, plugin='sample-plugin'))

    # Normal case, plugin not passed
    assert (configdata._global_settings['c.d'].value == 'c') and (configdata._global_settings['c.d'].origin == 'd')

    # Normal case, plugin passed
    assert (configdata._plugins['sample_plugin']['sample-plugin']['a.b'].value == 'a') and (configdata._plugins['sample_plugin']['sample-plugin']['a.b'].origin == 'b')


# Generated at 2022-06-10 22:47:30.809654
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_configdata = ConfigData()
    test_setting = {'name': 'test1'}
    test_configdata.update_setting(test_setting)
    assert test_configdata.get_settings()[0].get('name') == 'test1'


# Generated at 2022-06-10 22:47:52.558636
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import config_loader
    from ansible.plugins.loader import plugin_loader

    data = ConfigData()

    setting = config_loader.get("setting", name="ANSIBLE_CALLBACK_WHITELIST", plugin=None)
    data.update_setting(setting)

    plugin = plugin_loader.get("callback", "stdout")
    setting = config_loader.get("setting", name="display_skipped_hosts", plugin=plugin)
    data.update_setting(setting, plugin=plugin)

    assert setting == data.get_setting("display_skipped_hosts", plugin=plugin)
    assert setting == data.get_settings(plugin=plugin)[0]
    assert setting != data.get_setting("ANSIBLE_CALLBACK_WHITELIST", plugin=None)
    assert setting

# Generated at 2022-06-10 22:48:01.365369
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import Plugin
    from ansible.config.setting import Setting

    # instantiate ConfigData
    config_data = ConfigData()

    # Setup
    setting = Setting('foo', 'bar')
    plugin = Plugin(type='whatevz', name='irrelevant')

    # Test
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', plugin) is None

    config_data.update_setting(setting)

    assert config_data.get_setting('foo') is not None
    assert config_data.get_setting('foo', plugin) is None
    assert config_data.get_setting('foo').name == 'foo'
    assert config_data.get_setting('foo').value == 'bar'


# Generated at 2022-06-10 22:48:14.104896
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(Setting(name='ANSIBLE_LIBRARY', value='/usr/share/ansible/plugins/inventory'))
    config.update_setting(Setting(name='ANSIBLE_LIBRARY', value='/home/dhuang/.ansible/plugins/modules',
                                  plugin=Plugin('module', 'keycloak')))
    assert config.get_setting('ANSIBLE_LIBRARY') == Setting(name='ANSIBLE_LIBRARY', value='/usr/share/ansible/plugins/inventory')

# Generated at 2022-06-10 22:48:15.793819
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    x = ConfigData()
    x.update_setting(['a', 'b', 'c'])


# Generated at 2022-06-10 22:48:18.899321
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_get_settings = ConfigData()
    test_get_settings.update_setting('hello')
    test_get_settings.update_setting('world')
    assert len(test_get_settings.get_settings()) == 2


# Generated at 2022-06-10 22:48:26.330431
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins import PluginLoader
    plugin_loader = PluginLoader('')
    settings_loader = ConfigData()

    config_data = {
        'name': 'test_setting',
        'value': 'test_value'
    }
    setting = plugin_loader.get('config_setting', 'test').get('test_setting')(config_data)

    # Update only one setting
    settings_loader.update_setting(setting)
    settings = settings_loader.get_settings()
    assert len(settings) == 1
    assert settings[0].name == 'test_setting'
    assert settings[0].value == 'test_value'

    # Update a new plugin with a new setting
    settings_loader.update_setting(setting, plugin='test_type.test_name')
    settings = settings_loader.get_settings

# Generated at 2022-06-10 22:48:30.147447
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()
    assert configData.get_settings() == []
    configData._global_settings = {'foo': 'bar', 'bar': 42, 'baz': True}
    assert len(configData.get_settings()) == 3


# Generated at 2022-06-10 22:48:40.347755
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}
    assert config.get_setting('name') is None
    assert config.get_settings() == []
    config.update_setting(Setting('name', 'foo'))
    assert config._global_settings == {'name': Setting('name', 'foo')}
    assert config._plugins == {}
    assert config.get_setting('name') == Setting('name', 'foo')
    assert config.get_settings() == [Setting('name', 'foo')]
    assert config.get_setting('name', Plugin('baz', 'bar')) is None
    assert config.get_settings(Plugin('baz', 'bar')) == []
    config.update_setting(Setting('name', 'foo'), Plugin('baz', 'bar'))
   

# Generated at 2022-06-10 22:48:48.012749
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    settings = config.get_settings()
    assert len(settings) == 0

    # Test get_settings with global settings
    config = ConfigData()
    setting = {}
    setting['name'] = 'timeout'
    setting['value'] = '30'
    config.update_setting(setting)
    setting = {}
    setting['name'] = 'connection'
    setting['value'] = 'ssh'
    config.update_setting(setting)
    settings = config.get_settings()
    assert len(settings) == 2

    # Test get_settings with multiple plugins
    config = ConfigData()
    setting = {}
    setting['name'] = 'timeout'
    setting['value'] = '30'
    config.update_setting(setting, Plugin('cache', 'yaml'))
    setting = {}
   

# Generated at 2022-06-10 22:48:50.475436
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    data = config_data.get_settings()
    assert data == []


# Generated at 2022-06-10 22:49:02.482655
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    settings_list = config_data.get_settings()
    assert len(settings_list) == 0


# Generated at 2022-06-10 22:49:09.855956
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    plugin_1 = Plugin("Core", "connection")
    plugin_2 = Plugin("Core", "filesystem")
    plugin_3 = Plugin("Core", "file_finder")
    plugin_4 = Plugin("Core", "vault")
    plugin_5 = Plugin("Core", "lookup")
    plugin_6 = Plugin("Core", "cache")

    setting_1 = Setting("ANSIBLE_PIPELINING", plugin_1, False)
    setting_2 = Setting("ANSIBLE_CALLBACK_WHITELIST", plugin_1, "default")
    setting_3 = Setting("ANSIBLE_KEEP_REMOTE_FILES", plugin_2, False)
    setting_4 = Setting("ANSIBLE_REMOTE_TEMP", plugin_2, "/tmp")

# Generated at 2022-06-10 22:49:10.738776
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    assert True

# Generated at 2022-06-10 22:49:16.361255
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    configData = ConfigData()
    plugin_type = 'test_type'
    plugin_name = 'test_name'

    assert len(configData.get_settings()) == 0
    assert len(configData.get_settings(plugin_type)) == 0
    assert len(configData.get_settings(plugin_type, plugin_name)) == 0

# Generated at 2022-06-10 22:49:26.970482
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()

    config_data.update_setting(Setting('default_action', 'push'))
    config_data.update_setting(Setting('default_action', 'push', PluginDefinition('action', 'copy')))

    setting = config_data.get_setting('default_action')
    assert setting.name == 'default_action'
    assert setting.value == 'push'
    assert setting.plugin is None

    setting = config_data.get_setting('default_action', PluginDefinition('action', 'copy'))
    assert setting.name == 'default_action'
    assert setting.value == 'push'
    assert setting.plugin is not None
    assert setting.plugin.type == 'action'
    assert setting.plugin.name == 'copy'


# Unit test

# Generated at 2022-06-10 22:49:38.378182
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    config = ConfigParser()
    config.add_setting(name="setting_1", plugin=None, value=5)
    config.add_setting(name="setting_2", plugin=Plugin("type_1", "plugin_1"), value=6)
    config.add_setting(name="setting_3", plugin=Plugin("type_2", "plugin_2"), value=7)
    data.update_setting(config.get_setting(name="setting_1"))
    data.update_setting(config.get_setting(name="setting_2"))
    data.update_setting(config.get_setting(name="setting_3"))
    settings = data.get_settings()
    assert len(settings) == 1
    assert settings[0].name == "setting_1"

# Generated at 2022-06-10 22:49:48.448422
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert(len(cd.get_settings()) == 0)
    
    # Add a global setting
    s1 = Setting(name='ANSIBLE_LIBRARY')
    cd.update_setting(s1)
    assert(len(cd.get_settings()) == 1)
    
    # Add another global setting
    s2 = Setting(name='ANSIBLE_ROLES_PATH')
    cd.update_setting(s2)
    assert(len(cd.get_settings()) == 2)
    assert(cd.get_setting('ANSIBLE_LIBRARY') is not None)
    
    # Add a new library plugin
    p = Plugin(type='library', name='json_query')
    s = Setting(name='MODULE_UTILS_JSON_QUERY_DIR')
    cd.update_

# Generated at 2022-06-10 22:49:57.184636
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_object = ConfigData()
    assert isinstance(test_object, ConfigData), "test_object should be an instance of ConfigData"
    assert len(test_object._global_settings) == 0, "test_object._global_settings should be empty"

    test_object.update_setting(Setting("foo", "bar", "bar"))
    assert len(test_object._global_settings) == 1, "test_object._global_settings should have one item"
    assert test_object._global_settings["foo"] == "bar", "test_object._global_settings['foo'] should be equal to bar"
    assert test_object.get_setting("foo") == "bar", "test_object.get_setting('foo') should be equal to bar"


# Generated at 2022-06-10 22:50:09.283632
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    config_data.update_setting(Setting('setting_one', 'value_one'), None)
    config_data.update_setting(Setting('setting_two', 'value_two'), Plugin('type_one', 'name_one'))

    settings = config_data.get_settings()
    assert len(settings) == 1
    assert settings[0].name == 'setting_one'
    assert settings[0].value == 'value_one'

    settings = config_data.get_settings(Plugin('type_one', 'name_one'))
    assert len(settings) == 1
    assert settings[0].name == 'setting_two'
    assert settings[0].value == 'value_two'

    settings = config_data.get_settings(Plugin('type_two', 'name_two'))


# Generated at 2022-06-10 22:50:17.600022
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    config_data.update_setting(Setting('key1', 'value1'))
    config_data.update_setting(Setting('key2', 'value2'))
    config_data.update_setting(Setting('key3', 'value3'), Plugin(plugin_type='lookup', plugin_name='makeyaml'))
    config_data.update_setting(Setting('key4', 'value4'), Plugin(plugin_type='lookup', plugin_name='makeyaml'))
    config_data.update_setting(Setting('key5', 'value5'), Plugin(plugin_type='lookup', plugin_name='flattennestedlist'))