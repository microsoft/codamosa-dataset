

# Generated at 2022-06-10 22:40:37.242890
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()
    configdata.update_setting(Setting('fact_caching', 'ansible.builtin.file_system', 'test', 'test', 'test'))
    configdata.update_setting(Setting('fact_caching_timeout', 'ansible.builtin.file_system', 'test', 'test', 'test'))
    configdata.update_setting(Setting('fact_caching_connection', 'ansible.builtin.file_system', 'test', 'test', 'test'))
    setting = configdata.get_settings()
    assert len(setting) == 3
    assert setting[0].name == 'fact_caching' and setting[1].name == 'fact_caching_timeout' and setting[2].name == 'fact_caching_connection'



# Generated at 2022-06-10 22:40:47.432838
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting("setting1")
    config.update_setting("setting2")
    config.update_setting("setting3", plugin="cloud")
    config.update_setting("setting4", plugin="cloud")
    config.update_setting("setting5", plugin="shell")
    config.update_setting("setting6", plugin="cloud")
    assert config.get_setting("setting1") == "setting1"
    assert config.get_setting("setting2") == "setting2"
    assert config.get_setting("setting3", plugin="cloud") == "setting3"
    assert config.get_setting("setting4", plugin="cloud") == "setting4"
    assert len(config.get_settings()) == 2
    assert len(config.get_settings(plugin="cloud")) == 3

# Generated at 2022-06-10 22:40:57.184683
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Init config data obj and default setting
    config_data = ConfigData()
    default_setting = ComponentSetting('foo', 'bar')
    config_data.update_setting(default_setting)

    # Test invalid type
    assert config_data.get_settings(Component('invalid', 'bar')) == []

    # Test invalid name
    assert config_data.get_settings(Component('default', 'invalid')) == []

    # Test for global setting
    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'

    # Init new setting and add to config data obj
    new_setting = ComponentSetting('foo', 'foo')

# Generated at 2022-06-10 22:41:05.013558
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    from PluginSetting import PluginSetting
    from PluginSpec import PluginSpec

    # Test for global setting
    setting = PluginSetting('core.display_skipped_hosts', 'on')
    config.update_setting(setting)

    assert config.get_setting('core.display_skipped_hosts') == setting

    # Test for plugin setting
    plugin = PluginSpec("action", "debug")
    setting = PluginSetting("autocapture_no_stdout", "no")
    config.update_setting(setting, plugin)

    assert config.get_setting("autocapture_no_stdout", plugin) == setting

# Generated at 2022-06-10 22:41:16.602446
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    assert not configData._global_settings
    assert not configData._plugins
    import core.plugin
    plugin = core.plugin.Plugin(type='faketype', name='fakename')
    setting = core.plugin.Setting('fakesetting', 'fakedef', 'fakepath', 'fakevalue')
    configData.update_setting(setting)
    assert configData._global_settings['fakesetting'].name == 'fakesetting'
    assert configData._global_settings['fakesetting'].default == 'fakedef'
    assert configData._global_settings['fakesetting'].path == 'fakepath'
    assert configData._global_settings['fakesetting'].value == 'fakevalue'
    configData.update_setting(setting, plugin)

# Generated at 2022-06-10 22:41:21.712917
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from collections import namedtuple, OrderedDict

    from ansible.config.setting import Setting

    Setting = namedtuple("Setting", "name value origin plugin type plugin_name")

    config_data = ConfigData()


# Generated at 2022-06-10 22:41:28.318119
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('ansible_host','127.0.0.1','defaults','all','Ansible inventory host'))
    config_data.update_setting(Setting('ansible_port', 22, 'defaults', 'all', 'Ansible inventory host port'))
    config_data.update_setting(Setting('ansible_connection', 'smart', 'defaults', 'all', 'Ansible inventory host connection'))
    assert config_data._global_settings.get('ansible_host').value == '127.0.0.1' and config_data._global_settings.get('ansible_port').value == 22 and config_data._global_settings.get('ansible_connection').value == 'smart'


# Generated at 2022-06-10 22:41:35.397620
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    global_setting1 = Setting('setting1', 'value')
    global_setting2 = Setting('setting2', 'value2')
    global_setting3 = Setting('setting3', 'value3')
    global_setting4 = Setting('setting4', 'value4')

    plugin_setting1 = Setting('plugin_setting1', 'plugin_value')
    plugin_setting2 = Setting('plugin_setting2', 'plugin_value2')
    plugin_setting3 = Setting('plugin_setting3', 'plugin_value3')
    plugin_setting4 = Setting('plugin_setting4', 'plugin_value4')

    config = ConfigData()
    config.update_setting(global_setting1)
    config.update_setting(global_setting2)
    config.update_setting(global_setting3)

# Generated at 2022-06-10 22:41:45.976612
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    data = ConfigData()
    data.update_setting(Setting('foo', 'string', 'bar'))
    data.update_setting(Setting('bar', 'string', 'baz'), Plugin.DEFAULT)

    assert data.get_setting('foo') is None
    assert data.get_setting('bar') is not None

    class FakePlugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    plugin = FakePlugin('default', 'FAKE')
    data.update_setting(Setting('foo', 'string', 'bar'), plugin)
    assert data.get_setting('foo', plugin) is not None
    assert data.get_setting('bar', plugin) is None


# Generated at 2022-06-10 22:41:51.017654
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    yaml_setting = {'name': 'foo', 'value': 'bar'}
    setting = Setting(yaml_setting)
    
    config_data.update_setting(setting)
    assert(config_data.get_setting('foo') == setting)


# Generated at 2022-06-10 22:42:02.446145
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {
        'name': 'ANSIBLE_CALLBACK_WHITELIST',
        'value': 'profile_tasks,timer',
        'plugin': {
            'name': None,
            'type': 'global',
            'path': None
        }
    }
    config_data.update_setting(setting, plugin=None)
    expected = setting

    assert(config_data.get_setting(setting['name']) == expected)


# Generated at 2022-06-10 22:42:12.614760
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    setting1 = Setting('my_setting1', 'my_section1', 'my_value1')
    setting2 = Setting('my_setting2', 'my_section2', 'my_value2')
    setting3 = Setting('my_setting3', 'my_section3', 'my_value3')
    setting4 = Setting('my_setting4', 'my_section4', 'my_value4')

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting3)
    config_data.update_setting(setting4)

    settings = config_data.get_settings()

    assert len(settings) == 4

    settings = config_data.get_settings(plugin='test')

# Generated at 2022-06-10 22:42:16.882393
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    from ansible.parsing import plugin_docs
    setting = plugin_docs.AnsiblePluginSetting('setting1', 'bar', 'global', 'default')
    config_data.update_setting(setting, None)
    assert config_data.get_setting('setting1') == setting
    assert config_data.get_settings() == [setting]



# Generated at 2022-06-10 22:42:26.703068
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    # test with a non-plugin setting
    config_data.update_setting(Setting('foo', 'bar'))
    assert ('foo', 'bar') == (config_data._global_settings['foo'].name, config_data._global_settings['foo'].value)
    # test with a plugin setting
    config_data.update_setting(Setting('foo', 'bar'), Plugin('action', 'copy'))
    assert ('foo', 'bar') == (config_data._plugins['action']['copy']['foo'].name, config_data._plugins['action']['copy']['foo'].value)


# Generated at 2022-06-10 22:42:29.483096
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    setting = Setting('foo', '/etc/foo.conf', 'bar')
    config.update_setting(setting, None)
    expected = [setting]
    assert expected == config.get_settings()


# Generated at 2022-06-10 22:42:42.452784
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import ansible
    from ansible.plugins.loader import PluginLoader
    plugin_loader = PluginLoader(None, 'action')
    all_plugins = plugin_loader.all()

    config_data = ConfigData()

    for k, v in all_plugins.items():
        for action_plugin in v:
            if hasattr(action_plugin, 'CLI_OPTIONS'):
                for option, option_data in action_plugin.CLI_OPTIONS.items():
                    setting = ansible.cli.CLI.cli_option_to_setting(action_plugin.NAME, option, option_data)
                    if setting is not None:
                        config_data.update_setting(setting, action_plugin)

    if len(config_data.get_settings()) > 0:
        return True
    return False

# Generated at 2022-06-10 22:42:49.488164
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    setting = Setting('key', 'value', 'plugin_desc')
    config_data.update_setting(setting)
    assert 'key' in config_data._global_settings

    plugin_name = 'foo_plugin'
    plugin_type = 'bar_type'
    plugin = Plugin(plugin_name, plugin_type)
    setting = Setting('key', 'value', plugin_desc)
    config_data.update_setting(setting, plugin)
    assert 'key' in config_data._plugins[plugin_type][plugin_name]

    setting = Setting('key', 'value', plugin_desc)
    config_data.update_setting(setting)
    assert 'key' in config_data._global_settings
    setting = Setting('key_2', 'value', plugin_desc)
    config_data

# Generated at 2022-06-10 22:42:55.201358
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting_type = "str"
    setting_name = "test_setting"
    setting_value = "test_value"
    setting = Setting(setting_type, setting_name, setting_value)
    config_data.update_setting(setting)

    assert config_data.get_setting(setting_name).value == setting_value



# Generated at 2022-06-10 22:43:02.829666
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    print("ConfigData.update_setting() doesn't handle plugin names specified")
    cd = ConfigData()
    cd.update_setting("testSetting1")
    print("testSetting1")
    print(cd.get_settings())
    print("testSetting2")
    print(cd.get_settings())

    class Plugin:
        def __init__(self, name, type):
            self.type = type
            self.name = name
    myplugin = Plugin("test", "testType")


# Generated at 2022-06-10 22:43:11.483474
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    plugin = config.Plugin('connection', 'docker')
    settings = [config.Setting('ansible_connection', 'docker'),
                config.Setting('ansible_host', 'docker_server'),
                config.Setting('ansible_user', 'root'),
                config.Setting('ansible_password', '123')]

    for setting in settings:
        config.update_setting(setting, plugin)

    assert config.get_setting('ansible_connection') is None
    assert config.get_setting('ansible_connection', plugin) == settings[0]
    assert config.get_setting('ansible_host', plugin) == settings[1]
    assert config.get_setting('ansible_user', plugin) == settings[2]

# Generated at 2022-06-10 22:43:26.047204
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting('foo')
    
    assert config_data._global_settings['foo'] == 'foo'
    assert config_data._plugins == {}
    
    config_data.update_setting('bar', plugin=Plugin(type='foo', name='bar'))
    
    assert config_data._global_settings == {}
    assert config_data._plugins['foo']['bar'] == {'bar': 'bar'}
    
    
    
    

# Generated at 2022-06-10 22:43:37.924660
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # initialize data
    data = ConfigData()

    # setup data
    import json
    plugin_type = 'command'
    plugin_name = 'command_test'
    setting_name = 'command_test_setting'
    setting_value = 'command_test_setting_value'
    plugin = AnsiblePlugin(plugin_type,plugin_name)
    setting = AnsibleSetting(setting_name)
    setting.value = setting_value

    # test get_settings
    data.update_setting(setting, plugin)
    settings = data.get_settings(plugin)
    assert len(settings) == 1

    # test get_setting
    setting = data.get_setting(setting_name, plugin)
    assert setting is not None
    assert setting.name == setting_name
    assert setting.value == setting_value

    # test

# Generated at 2022-06-10 22:43:48.487280
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    import os
    d = dict(name="ANSIBLE_CONFIG", origin="environment", origin_name=os.environ, priority=100)
    import json

# Generated at 2022-06-10 22:43:56.825217
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    fake_setting = { "name" : "a" }
    config_data.update_setting(fake_setting)
    assert config_data._global_settings["a"] == fake_setting

    config_data.update_setting(fake_setting, "dummy_plugin")
    assert config_data._plugins["dummy_plugin"]["a"] == fake_setting

    config_data.update_setting(fake_setting, "dummy_plugin")
    assert config_data._plugins["dummy_plugin"]["a"] == fake_setting

    fake_setting_2 = { "name" : "b" }
    config_data.update_setting(fake_setting_2, "dummy_plugin")
    assert config_data._global_settings["a"] == fake_setting
    assert config_

# Generated at 2022-06-10 22:44:08.494726
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert (config_data.get_setting('test') is None)

    class plugin():
        type = 'test'
        name = 'test'

    # populate global setting
    setting = plugin()
    setting.name = 'test1'
    config_data.update_setting(setting)
    assert (config_data.get_setting(setting.name) == setting)
    assert (config_data.get_setting(setting.name, plugin()) == setting)

    # populate setting for specific plugin
    setting = plugin()
    setting.name = 'test2'
    config_data.update_setting(setting, plugin())
    assert (config_data.get_setting(setting.name) == setting)
    assert (config_data.get_setting(setting.name, plugin()) == setting)


# Generated at 2022-06-10 22:44:16.035113
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # create ConfigData class object
    config_data = ConfigData()
    # create PluginOption object
    plugin_option = PluginOption()
    plugin_option.name = "test_option"
    # create Plugin object
    plugin = Plugin()
    plugin.type = "action"
    plugin.name = "test_action"
    # create Setting object
    setting = Setting()
    # fill the setting with option and plugin
    setting.option = plugin_option
    setting.plugin = plugin
    # update setting
    config_data.update_setting(setting=setting, plugin=plugin)


# Generated at 2022-06-10 22:44:17.358847
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-10 22:44:25.350713
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("setting1")
    config_data.update_setting("setting2", "plugin")
    result = config_data.get_settings()
    assert result == ["setting1", "setting2"], "get_settings should return a list of PluginSettings."
    result = config_data.get_setting("setting2", "plugin")
    assert result == "setting2", "get_setting should return the setting specified."
    result = config_data.get_settings("plugin")
    assert result == ["setting2"], "get_settings should return a list of PluginSettings for the specified plugin."

# Generated at 2022-06-10 22:44:30.557674
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(setting={"name": "foo0", "type": "string", "default": "bar0"}, plugin=None)
    assert config.get_setting(name="foo0", plugin=None) == {"name": "foo0", "type": "string", "default": "bar0"}


# Generated at 2022-06-10 22:44:33.996699
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    setting = Setting("setting1", "value1")
    config_data.update_setting(setting)
    assert config_data._global_settings["setting1"].value == "value1"


# Generated at 2022-06-10 22:45:00.344610
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Create a new instance of class ConfigData
    config = ConfigData()

    # Set the global configuration settings
    config._global_settings = {
        'setting1': {'value': 'value1'},
        'setting2': {'value': 'value2'}
    }

    # Set the plugins configuration settings
    config._plugins = {
        'collections': {
            'my_collection': {
                'setting3': {'value': 'value3'},
                'setting4': {'value': 'value4'}
            }
        }
    }

    # Try to get a global configuration setting
    setting1 = config.get_setting('setting1')
    assert setting1 == {'value': 'value1'}

    # Try to get a configuration setting for a plugin

# Generated at 2022-06-10 22:45:09.682117
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()

    action_loader = PluginLoader('ActionModule', 'ansible.plugins.action', config_data)
    setting = action_loader.get('copy.remove_target_dir', 'copy')

    config_data.update_setting(setting, action_loader.get_plugin_from_name('copy'))
    config_data.get_setting('remove_target_dir', action_loader.get_plugin_from_name('copy'))
    config_data.get_settings()

if __name__ == '__main__':
    test_ConfigData_get_settings()

# Generated at 2022-06-10 22:45:16.192461
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Setup
    config_data = ConfigData()
    config_data.update_setting(Setting(name='loglevel', value='10'))
    config_data.update_setting(Setting(name='log_path', value='/home/myuser/ansible/logs'))

    # Execute
    settings = config_data.get_settings()

    # Verify
    assert settings is not None and len(settings) == 2



# Generated at 2022-06-10 22:45:17.793779
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    data = ConfigData()

    assert data.get_settings() == []


# Generated at 2022-06-10 22:45:20.355309
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    cd.update_setting(ConfigSetting('auth_type', 'basic'))
    assert cd.get_setting('auth_type') == 'basic'

# Generated at 2022-06-10 22:45:23.105279
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = config_data.get_setting('ansible_become_user')
    print(setting)

# Generated at 2022-06-10 22:45:28.983520
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('name', 'description', 'value'))
    global_setting = config_data.get_setting('name')
    assert global_setting.name == 'name'
    assert global_setting.description == 'description'
    assert global_setting.value == 'value'


# Generated at 2022-06-10 22:45:31.071145
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-10 22:45:42.248566
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()
    from ansible.utils.plugin_docs import create_setting_instance_from_dict

    setting_dict = {
        'config': {
            'env': {
                'FOO': 'bar'
            },
            'defaults': {
                'timeout': 5,
                'remote_user': 'default_remote_user'
            },
            'inventory': '/usr/share/ansible/inventory'
        },
        'doc': {
            'strings': [
                'something'
            ]
        }
    }
    setting = create_setting_instance_from_dict(setting_dict, 'defaults')

    # when the settings.name is 'defaults'
    configdata.update_setting(setting)
    global_settings = configdata.get_settings()
    assert global_settings

# Generated at 2022-06-10 22:45:44.603055
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("bla") is None


# Generated at 2022-06-10 22:46:20.338776
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

# Generated at 2022-06-10 22:46:23.151675
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cd.update_setting('foo', 'bar')
    assert cd._global_settings['foo'] == 'bar'


# Generated at 2022-06-10 22:46:23.781492
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass

# Generated at 2022-06-10 22:46:30.081230
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()

    setting = ConfigSetting(name='test1', value=True, plugin=ConfigPlugin(type='test-type', name='test-name'))
    data.update_setting(setting)

    assert data.get_setting(name='test1').value is True
    assert data.get_setting(name='test1-1') is None
    assert data.get_setting(name='test1', plugin=ConfigPlugin(type='test-type1', name='test-name')).value is True


# Generated at 2022-06-10 22:46:30.735449
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert 1 == 0

# Generated at 2022-06-10 22:46:34.302054
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert len(data.get_settings()) == 0
    data.update_setting(ConfigDataSetting("foo", "bar", "baz"))
    assert len(data.get_settings()) == 1



# Generated at 2022-06-10 22:46:44.249110
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting = Setting(name='test_name', value='test_value',origin='test_origin')
    plugin = Plugin(name='test_plugin',type='test_plugin_type')
    config_data = ConfigData()

    #check that the method update setting works for a global setting
    config_data.update_setting(setting)

    assert config_data.get_setting(setting.name) == setting
    assert config_data.get_setting(setting.name, plugin) is None

    #check that the method update setting works for a local setting
    config_data.update_setting(setting, plugin)

    assert config_data.get_setting(setting.name, plugin) == setting



# Generated at 2022-06-10 22:46:55.498872
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

   # pre-condition:
   # create a plugin
   plugin = Plugin()
   # create two settings
   setting_1 = Setting()
   setting_2 = Setting()
   setting_1.name = 'author_name'
   setting_2.name = 'author_email'
   # add settings to the plugin
   plugin.add_setting(setting_1)
   plugin.add_setting(setting_2)

   #create configdata
   configdata = ConfigData()
   # add the plugin to configdata
   configdata.update_plugin(plugin)
   # post-condition:
   # get settings from the configdata
   settings = configdata.get_settings(plugin)

   #assert the length of the settings list is 2
   assert len(settings) == 2, "assertion failed - get_settings"



# Generated at 2022-06-10 22:47:05.425893
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    import sys
    import os
    from collections import namedtuple
    sys.path.append(os.path.join(os.path.dirname(__file__),'..'))

    from lib.settings import IntegerSetting, StringSetting, BooleanSetting, FloatSetting
    from lib.plugin import Plugin

    setting1 = IntegerSetting(name='setting1', path=['path1', 'path2', 'path3'], default=1, aliases=['setting_1'])
    setting2 = IntegerSetting(name='setting2', path=['path1', 'path2', 'path3'])
    plugin = Plugin(name='plugin_name', type='plugin_type', namespace='plugin_namespace')

    config_data.update_setting(setting1)

# Generated at 2022-06-10 22:47:14.176694
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}
    setting = {'name': 'x', 'value': '123', 'origin': 'ANSI'}
    config_data.update_setting(setting)
    assert config_data._global_settings == {'x': setting}
    assert config_data._plugins == {}
    plugin = {'type': 'CORE', 'name': 'Y', 'origin': 'ANSI'}
    config_data.update_setting(setting, plugin)
    assert config_data._global_settings == {'x': setting}
    assert config_data._plugins == {'CORE': {'Y': {'x': setting}}}


# Generated at 2022-06-10 22:47:59.085714
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblelint.rules.LineTooLong import LineTooLong
    from ansiblelint.rules.TrailingWhitespace import TrailingWhitespace

    config_data = ConfigData()

    # Setting exists in global settings
    setting = config_data.get_setting('line_length')
    assert setting.name == 'line_length'
    assert type(setting.rule) == LineTooLong
    assert setting.default_value == 120

    # Setting exists in plugins settings
    setting = config_data.get_setting('trailing_whitespace', plugin='ANSIBLE0008')
    assert setting.name == 'trailing_whitespace'
    assert type(setting.rule) == TrailingWhitespace
    assert setting.default_value == True

    # Setting does not exist in global settings
    setting = config_data.get_

# Generated at 2022-06-10 22:48:11.788362
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()

    import os
    import os.path
    import shutil
    import tempfile
    import traceback
    import yaml

    CONTAINER = None
    tmpdir = None

# Generated at 2022-06-10 22:48:14.102884
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

# Unit tests for method get_setting of class ConfigData

# Generated at 2022-06-10 22:48:20.725261
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting1 = Setting(name = 'foo', value = '1', origin = 'bar')
    plugin = Plugin(name = 'test1', type = 'test2')
    config_data.update_setting(setting1, plugin)
    settings = config_data.get_settings(plugin)
    assert len(settings) == 1
    assert settings[0].get_name() == 'foo'
    assert settings[0].get_value() == '1'
    assert settings[0].get_origin() == 'bar'



# Generated at 2022-06-10 22:48:31.302093
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.module_utils.config_data import Setting

    global_setting_names = ['display_skipped_hosts', 'stdout_callback']
    plugin_setting_names = {'callback': ['minimal'], 'lookup': ['file']}
    config = ConfigData()
    for name in global_setting_names:
        setting = Setting(name, name)
        config.update_setting(setting)

    assert len(config.get_settings()) == len(global_setting_names)
    assert config.get_setting('stdout_callback').value == 'stdout_callback'
    assert config.get_setting('stdout_callback') in config.get_settings()
    assert len(config.get_settings()) == len(global_setting_names)


# Generated at 2022-06-10 22:48:41.894629
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    setting_1 = {'name': 'name1', 'type': 'type1', 'default': 'default1', 'current_value': 'current_value1'}
    config_data.update_setting(setting_1)

    setting_2 = {'name': 'name2', 'type': 'type2', 'default': 'default2', 'current_value': 'current_value2'}
    config_data.update_setting(setting_2)

    setting_3 = {'name': 'name3', 'type': 'type3', 'default': 'default3', 'current_value': 'current_value3'}
    config_data.update_setting(setting_3, plugin={'type': 'type3', 'name': 'name3'})


# Generated at 2022-06-10 22:48:51.480245
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    test_value = "test_value"
    config_data.update_setting(test_value)
    assert config_data.get_setting(test_value.name) == test_value

    test_value1 = "test_value1"
    plugin_type = "test_plugin_type"
    plugin_name = "test_plugin_name"
    test_plugin = TestPlugin(plugin_type, plugin_name)
    config_data.update_setting(test_value1, test_plugin)
    assert config_data.get_setting(test_value1.name, test_plugin) == test_value1


# Generated at 2022-06-10 22:48:56.788428
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    from ansiblelint.rules import AnsibleLintRule
    setting = AnsibleLintRule()
    setting.name = 'foo'
    setting.value = 'bar'
    config.update_setting(setting)
    got = config.get_setting('foo')
    assert got == 'bar'


# Generated at 2022-06-10 22:49:06.699373
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    assert config_data.get_setting('setting1') is None
    assert config_data.get_setting('setting1', 'plugin1/Type1') is None

    plugin1_setting1 = Setting(plugin_type='Type1', plugin_name='plugin1', name='setting1', value='value1', origin='origin1')
    config_data.update_setting(plugin1_setting1)

    plugin2_setting1 = Setting(plugin_type='Type2', plugin_name='plugin2', name='setting1', value='value1', origin='origin1')
    config_data.update_setting(plugin2_setting1)

    assert config_data.get_setting('setting1') is None
    assert config_data.get_setting('setting1', plugin1_setting1) == plugin1_setting1

# Generated at 2022-06-10 22:49:18.760758
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    m = ConfigData()

    assert m._global_settings == {}
    assert m._plugins == {}

    # Test with empty config
    assert m.get_settings() == []
    assert m.get_settings(BaseSetting()) == []
    assert m.get_settings(BaseSetting(name='a')) == []
    assert m.get_settings(BaseSetting(name='a', value='b')) == []

    # Add some settings and test again
    m.update_setting(BaseSetting(name='a', value='b'))
    m.update_setting(BaseSetting(name='c', value='d'))
    assert m.get_settings() == [BaseSetting(name='a', value='b'), BaseSetting(name='c', value='d')]
    assert m.get_settings(BaseSetting()) == []
    assert m