

# Generated at 2022-06-10 22:40:39.078958
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # New ConfigData object
    data = ConfigData()

    # Dummy setting to add in global settings
    setting = dict()
    setting['name'] = 'plugin'
    setting['value'] = 'test'
    setting['plugin_type'] = None
    setting['plugin_name'] = None

    data.update_setting(setting)

    # Plugin type supported by the settings object
    plugin = dict()
    plugin['type'] = 'test'

    # Plugin name
    plugin['name'] = 'test'

    # Setting name
    setting['name'] = 'test_test'

    # Setting value
    setting['value'] = 'test_test'

    data.update_setting(setting, plugin)

# Generated at 2022-06-10 22:40:46.175379
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    expected_output = {
            'plugin_type': 'vars',
            'plugin_name': 'foo',
            'name': 'bar',
            'value': 'foobar',
    }

    config_data = ConfigData()
    config_data.update_setting(PluginSetting(
        'bar',
        'foobar',
        plugin_type='vars',
        plugin_name='foo'
    ))

    assert config_data._plugins['vars']['foo']['bar'].as_dict() == expected_output



# Generated at 2022-06-10 22:40:55.109798
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class TestSetting(object):
        def __init__(self, name):
            self.name = name

    a = ConfigData()
    plugin = None
    setting = TestSetting('test')
    a.update_setting(setting, plugin)
    assert a._global_settings is not None
    assert a._global_settings['test'] is not None
    assert a._global_settings['test'].name == 'test'
    assert a._plugins is None

    setting = TestSetting('test2')
    a.update_setting(setting, 'plugin')
    assert a._global_settings is not None
    assert a._global_settings['test'] is not None
    assert a._global_settings['test'].name == 'test'
    assert a._plugins['plugin'] is not None

# Generated at 2022-06-10 22:41:05.041998
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import os
    import pytest

    from ansible.cli import CLI
    from ansible.config.manager import ConfigManager, Setting

    # create a random file name
    config_file_name = os.path.join(os.path.dirname(__file__), 'test_config_file_' + str(os.getpid()))

    # create a test config file
    fd = open(config_file_name, "w")
    fd.write("""
[defaults]
retry_files_enabled = True
retry_files_save_path = ~/.ansible-retry
retry_files_save_path~ = .
""")
    fd.flush()
    fd.close()

    # instantiate a config object
    config = ConfigManager(config_file=config_file_name)

   

# Generated at 2022-06-10 22:41:16.646513
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible import context
    from ansible.config.manager import ConfigManager

    context.CLIARGS = {'config_file': ''}
    context._init_global_context()

    config_manager = ConfigManager(
        sources=[],
        loader=DictDataLoader({
            'unfrackpath_backup': mock_unfrackpath_noop,
            'CONFIG_FILE': '',
            'DEFAULTS': {},
        })
    )

    config_manager.data = ConfigData()

    # test get_setting()
    assert config_manager.get_setting('module_name') is None

    # test get_setting() with global setting
    config_manager

# Generated at 2022-06-10 22:41:21.759013
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Defining setting with "core" plugin and name "inventory_sources"
    setting0 = Setting()
    setting0.plugin = 'core'
    setting0.name = 'inventory_sources'

    # Defining setting with "core" plugin, name "inventory_sources" and value "192.168.56.10"
    setting1 = Setting()
    setting1.plugin = 'core'
    setting1.name = 'inventory_sources'
    setting1.value = '192.168.56.10'

    # Defining setting with "core" plugin and name "vvvv"
    setting2 = Setting()
    setting2.plugin = 'core'
    setting2.name = 'vvvv'

    # Defining setting with "shell" plugin and name "vvvv"
    setting3 = Setting()
    setting3.plugin

# Generated at 2022-06-10 22:41:28.600550
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='test1', value='value1', plugin=None))
    config_data.update_setting(Setting(name='test2', value='value2', plugin=Plugin(type='test', name='test1')))
    config_data.update_setting(Setting(name='test3', value='value3', plugin=Plugin(type='test', name='test1')))
    config_data.update_setting(Setting(name='test4', value='value4', plugin=Plugin(type='test', name='test2')))

    assert len(config_data.get_settings(None)) == 1
    assert len(config_data.get_settings(Plugin(type='test', name='test1'))) == 2

# Generated at 2022-06-10 22:41:35.200451
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None

    config_data.update_setting(DefaultSetting('foo', '', 'global setting', 'ini', 'foo/bar.ini', '', ''))
    assert config_data.get_setting('foo') is not None

    assert config_data.get_setting('foo', Plugin('module', 'async_wrapper')) is None

    config_data.update_setting(DefaultSetting('foo', '', 'plugin setting', 'ini', 'foo/bar.ini', '', ''), Plugin('module', 'async_wrapper'))
    assert config_data.get_setting('foo', Plugin('module', 'async_wrapper')) is not None



# Generated at 2022-06-10 22:41:39.650232
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    class MockSetting():
        def __init__(self):
            self.name = "MockSetting"
        def get_config_value(self):
            return True
    config_data.update_setting(MockSetting())

# Generated at 2022-06-10 22:41:44.979330
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    # check that plugin arguments are not required when retrieving global settings
    config_data.update_setting(Setting(name="env", env=['PATH=/usr/bin']))
    assert config_data.get_setting('env') == Setting(name="env", env=['PATH=/usr/bin'])


# Generated at 2022-06-10 22:41:56.112235
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
  # Setup
  global_setting_1 = {'name': 'foo', 'value': 1}
  global_setting_2 = {'name': 'bar', 'value': 2}
  config_data = ConfigData()
  config_data._global_settings = {'foo': global_setting_1, 'bar': global_setting_2}

  # Get the setting
  foo = config_data.get_setting('foo')

  # Assert that the retrieved setting is the expected one
  assert foo == global_setting_1


# Generated at 2022-06-10 22:42:01.603468
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    d = ConfigData()
    plugin = ConfigPlugin("test", "test", "test")
    setting = ConfigSetting("test", "test", "test")

    assert len(d.get_settings(plugin)) == 0
    d.update_setting(setting, plugin)
    assert len(d.get_settings(plugin)) == 1
    assert len(d.get_settings()) == 0


# Generated at 2022-06-10 22:42:03.015011
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting = ConfigData(self)
    setting.update_setting(None)

# Generated at 2022-06-10 22:42:09.995971
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting1 = Setting('test_setting1', 'this is a test', 'config', 'this is the description')
    setting2 = Setting('test_setting2', 'this is a test', 'config', 'this is the description')
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    assert len(config_data.get_settings()) == 2, 'unexpected number of settings'

    # Unit test for method get_setting of class ConfigData

# Generated at 2022-06-10 22:42:15.152527
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from collections import namedtuple
    from ansible.module_utils.common.config import Setting

    ConfigDataClass = ConfigData()
    Plugin = namedtuple("Plugin", "type name")
    plugin = Plugin("test", "test")
    setting = Setting("test","test","test")
    ConfigDataClass.update_setting(setting,plugin)
    assert ConfigDataClass.get_setting("test", plugin) is setting

# Generated at 2022-06-10 22:42:25.052625
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Arrange
    config_data = ConfigData()
    setting1 = config_data.Setting(plugin=None, name='key1', value='value1', origin='origin1')
    setting2 = config_data.Setting(plugin=None, name='key2', value='value2', origin='origin2')

    # Act
    config_data.update_setting(setting1, plugin=None)
    config_data.update_setting(setting2, plugin=None)

    # Assert
    assert config_data.get_setting('key1') == setting1
    assert config_data.get_setting('key2') == setting2
    assert config_data.get_setting('key3') is None



# Generated at 2022-06-10 22:42:30.787693
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    setting = Setting("foo", "bar", "baz")
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting("foo", plugin) == setting
    assert config_data.get_setting("foo") is None
    setting = Setting("foo", "bar", "baz")
    config_data.update_setting(setting)
    assert config_data.get_setting("foo") == setting
    assert config_data.get_setting("foo", plugin) is None


# Generated at 2022-06-10 22:42:42.524857
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Initialization of ConfigData instance with no global settings
    config_data = ConfigData()
    assert config_data.get_settings() == []
    config_data = ConfigData()
    assert config_data.get_settings(None) == []

    # Initialization of ConfigData instance with global setting
    config_data = ConfigData()
    setting = {
        "name": "foo",
        "type": "boolean",
        "default": False,
        "desc": "Foo setting"
    }
    config_data.update_setting(setting)
    assert config_data.get_settings()[0]['name'] == "foo"
    assert config_data.get_settings()[0]['type'] == "boolean"
    assert config_data.get_settings()[0]['default'] == False
    assert config

# Generated at 2022-06-10 22:42:47.541127
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    plugin = PluginDefinition('test', 'test')
    setting = SettingDefinition('test', 'test', 'test')
    config_data.update_setting(setting)
    config_data.update_setting(setting, plugin)

    print(config_data.get_settings())
    print(config_data.get_settings(plugin))
    print(config_data.get_setting('test'))
    print(config_data.get_setting('test', plugin))



# Generated at 2022-06-10 22:42:58.258852
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    global_setting_names = ['log_path', 'callback_whitelist', 'action_plugins']
    global_settings = list(map(lambda x: ConfigSetting(x, 'path', 'path to log file'), global_setting_names))
    
    # Configure global settings
    config_data = ConfigData()
    for gs in global_settings:
        config_data.update_setting(gs)
    # First test, call get_setting without plugin
    settings = config_data.get_settings()
    assert len(settings) == len(global_settings)
    for s in settings:
        assert s in global_settings


# Generated at 2022-06-10 22:43:08.848634
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()

    global_setting = Setting('global.setting', None, None, None, None)
    configdata.update_setting(global_setting)
    assert configdata.get_setting('global.setting') is global_setting

    plugin = Plugin('module', 'ping')
    plugin_setting = Setting('module.ping.setting', None, None, None, None)
    configdata.update_setting(plugin_setting, plugin)

    assert configdata.get_setting('global.setting') is global_setting
    assert configdata.get_setting('module.ping.setting', plugin) is plugin_setting


# Generated at 2022-06-10 22:43:14.289662
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting("setting1")
    config_data.update_setting("setting2")
    assert config_data.get_setting("setting1") == "setting1"
    assert config_data.get_setting("setting2") == "setting2"
    assert config_data.get_setting("setting3") is None


# Generated at 2022-06-10 22:43:16.269165
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    assert cd.get_settings() == []


# Generated at 2022-06-10 22:43:26.021804
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class Plugin():
        def __init__(self, type, name):
            self._type = type
            self._name = name
        @property
        def type(self):
            return self._type
        @property
        def name(self):
            return self._name

    class Setting():
        def __init__(self, name, default):
            self._name = name
            self._default = default
        @property
        def name(self):
            return self._name
        @property
        def default(self):
            return self._default

    config = ConfigData()

    # no plugin set
    plugin = None
    # no settings in config
    assert config.get_settings(plugin) == []

    # no plugin set
    # one setting in config
    setting = Setting('setting1', '10')
    config.update

# Generated at 2022-06-10 22:43:34.175837
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    print("test_ConfigData_update_setting:")
    print("data.update_setting(name='test', value='test', plugin='test')")
    data.update_setting(name='test', value='test', plugin='test')
    print("data.get_setting(name='test')")
    print(data.get_setting(name='test'))
    print("data.get_setting(name='test', plugin='test')")
    print(data.get_setting(name='test', plugin='test'))

# Generated at 2022-06-10 22:43:35.527392
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    pass


# Generated at 2022-06-10 22:43:41.081589
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    s1 = Setting(name='s1', value='v1', origin='o1')
    s2 = Setting(name='s2', value='v2', origin='o2')
    cd = ConfigData()
    cd.update_setting(s1)
    cd.update_setting(s2)
    ss = cd.get_settings()
    assert len(ss) == 2


# Generated at 2022-06-10 22:43:45.152232
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigInternalSetting(name='version', value='2.8'))
    assert config_data.get_setting('version') == ConfigInternalSetting(name='version', value='2.8')



# Generated at 2022-06-10 22:43:47.257636
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    plugin = 'cloud'
    settings = config.get_settings(plugin)
    assert settings == []

# Generated at 2022-06-10 22:43:53.137246
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_obj = ConfigData()
    setting_obj = Setting()
    assert setting_obj
    setting_obj.update("test_setting", "test_value", "test_config_file")
    config_data_obj.update_setting(setting_obj)

    assert config_data_obj.get_setting("test_setting") == setting_obj
    assert config_data_obj.get_setting("test_setting_unknown") == None


# Generated at 2022-06-10 22:43:58.623401
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('ansible_foo', 'bar'))
    assert config_data.get_setting('ansible_foo') == Setting('ansible_foo', 'bar')


# Generated at 2022-06-10 22:44:10.676448
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    # add mock setting for plugin A
    plugin_a = PluginType('A')
    setting_a = Setting('A', '1')
    config_data.update_setting(setting_a, plugin_a)
    # add mock setting for plugin B
    plugin_b = PluginType('B')
    setting_b = Setting('B', '2')
    config_data.update_setting(setting_b, plugin_b)
    # check if setting is added only for plugin A
    assert config_data.get_settings() == []
    assert config_data.get_settings(plugin_a) == [setting_a]
    assert config_data.get_settings(plugin_b) == [setting_b]
    assert config_data.get_setting('A', plugin_a) == setting_a


# Generated at 2022-06-10 22:44:15.374448
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class Setting(object):
        name = 'setting_name'
        value = 'setting_value'

    config_data = ConfigData()
    config_data.update_setting(Setting())
    assert config_data._global_settings['setting_name'].name == 'setting_name'
    assert config_data._global_settings['setting_name'].value == 'setting_value'

# Generated at 2022-06-10 22:44:16.770949
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    configdata = ConfigData()
    setting = ConfigSetting('value_a')



# Generated at 2022-06-10 22:44:19.621954
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(path='one',name='two',value='three'))
    assert config_data.get_setting('two') == Setting(path='one',name='two',value='three')

# Generated at 2022-06-10 22:44:27.208023
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = ConfigSetting(name='ansible_host', value='localhost')
    config_data.update_setting(setting)

    plugin = Plugin('shell', 'core')
    setting2 = ConfigSetting(name='extensions', value=['.sh', '.bash', '.ksh'])
    config_data.update_setting(setting2, plugin)

    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings(plugin)) == 2


# Generated at 2022-06-10 22:44:31.696289
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # given
    config_data = ConfigData()
    setting = Setting('FooBar', 'BarFoo')
    config_data.update_setting(setting)

    # when
    actual = config_data.get_setting('FooBar')

    # then
    assert actual.name == 'FooBar'


# Generated at 2022-06-10 22:44:33.417522
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-10 22:44:46.418664
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('some_global_setting', '/etc/some_global_setting'))
    config_data.update_setting(ConfigSetting('some_module_setting', '/etc/ansible/some_module_setting'))

    settings = config_data.get_settings()
    assert len(settings) == 1
    assert settings[0].name == 'some_global_setting'
    assert settings[0].value == '/etc/some_global_setting'

    sample_module_plugin = Plugin('module', 'sample_module')
    settings = config_data.get_settings(sample_module_plugin)
    assert len(settings) == 1
    assert settings[0].name == 'some_module_setting'

# Generated at 2022-06-10 22:44:51.244555
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    d = ConfigData()
    d.update_setting(Setting('foo', 'global', 'bar', 'global', 'global'))
    assert d.get_settings()[0].value == 'bar'
    assert d.get_setting('foo').value == 'bar'


# Generated at 2022-06-10 22:44:57.932458
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0
    assert len(config_data.get_settings(plugin="the_plugin")) == 0


# Generated at 2022-06-10 22:45:04.024074
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()

    #Global setting
    cd.update_setting(Setting("foo", "static", "bar"))
    assert cd._global_settings == {"foo": Setting("foo", "static", "bar")}

    #Plugin setting
    cd.update_setting(Setting("foo", "static", "bar"), Plugin("cloud", "aws"))
    assert cd._plugins == {'cloud': {'aws': {"foo": Setting("foo", "static", "bar")}}}

# Generated at 2022-06-10 22:45:15.980554
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    from units.mock.loader import DictDataLoader
    config_data_loader = DictDataLoader({
        'plugin_name': 'plugin_name',
        'plugin_path': '',
        'plugin_type': 'action',
        'aliases': [],
    })
    from units.compat.mock import MagicMock
    plugin = MagicMock()
    plugin.type = 'action'
    plugin.name = 'plugin_name'
    config_data_loader.set_base_plugin(plugin)
    config_data_loader.set_global_vars({
        'setting_name': 'setting_value'
    })
    config_data.update(config_data_loader, None)
    assert config_data.get_setting('setting_name') is not None

# Generated at 2022-06-10 22:45:26.306150
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting(name='a', value='a'))
    config_data.update_setting(ConfigSetting(name='b', value='b'))
    assert(config_data.get_setting('a').name == 'a')
    assert(config_data.get_setting('a').value == 'a')
    assert(config_data.get_setting('b').name == 'b')
    assert(config_data.get_setting('b').value == 'b')
    config_data.update_setting(ConfigSetting(name='a', value='aa', plugin=Plugin('c','d')))
    assert(config_data.get_setting('a').name == 'a')
    assert(config_data.get_setting('a').value == 'aa')

# Generated at 2022-06-10 22:45:36.181599
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    import ansible.plugins
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.executor.module_common import MODULE_ARGS
    import ansible.models.config
    from ansible.models.config import AnsibleConfig

    ansible_setting = ansible.models.config.setting_loader.get("defaults", "retry_files_save_path") # type: AnsibleConfig
    ansible_setting[MODULE_ARGS]["default"] = AnsibleVaultEncryptedUnicode("/tmp/ansible-retry") # type: AnsibleVaultEncryptedUnicode

    config_data.update_setting(ansible_setting)

    #

# Generated at 2022-06-10 22:45:44.355127
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    plugin = None
    setting = Setting(name='foo', value='bar')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('foo') == setting


# Generated at 2022-06-10 22:45:49.345298
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.plugins.loader import PluginLoader
    c = ConfigData()
    # Variable 'ansible_ssh_port' is a global variable
    c.update_setting(PluginLoader().get("vars", "ansible_ssh_port"))
    assert c._global_settings.get("ansible_ssh_port") is not None


# Generated at 2022-06-10 22:45:59.069337
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    import os
    import glob

    config_data = ConfigData()

    data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "unit/compat/json/config_data")
    for f in glob.glob(os.path.join(data_dir, "*.json")):
        with open(f) as fh:
            plugin_data = json.load(fh)

            for plugin_type in plugin_data:
                for plugin_name in plugin_data[plugin_type]:
                    for k, v in plugin_data[plugin_type][plugin_name].items():
                        config_data.update_setting(ConfigSetting(k, v))


    # Test if get_setting returns correct value

# Generated at 2022-06-10 22:46:08.941985
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting1 = Setting(name='max_retries', plugin=Plugin('shell'), value=3, origin='stdout')
    setting2 = Setting(name='timeout', plugin=Plugin('shell'), value=1.0, origin='stdout')
    setting3 = Setting(name='max_retries', plugin=Plugin('shell'), value=10, origin='stdout')
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting3)

    # Test with a module that is not known
    settings = config_data.get_settings(plugin=Plugin('banana'))
    assert settings == []

    # Test with no module. Then we get the global settings which are the max_retries setting with the highest value
    settings

# Generated at 2022-06-10 22:46:18.480358
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Create object
    config_data = ConfigData()

    # Test get_setting
    # Assert None settings
    assert config_data.get_setting(name='foo') == None
    assert config_data.get_setting(name='foo', plugin=Plugin(type='', name='')) == None
    assert config_data.get_setting(name='foo', plugin=Plugin(type='action', name='bar')) == None

    # Add setting
    config_data.update_setting(setting=Setting(name='foo', plugin=Plugin(type='action', name='bar')))

    # Assert setting
    assert config_data.get_setting(name='foo', plugin=Plugin(type='action', name='bar')) != None

# Generated at 2022-06-10 22:46:33.388653
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    plugin = PluginInfo('LookupModule', 'lookup_plugin')
    setting = Setting('timeout', 'int', '10')

    # ConfigData.update_setting(setting)
    config_data.update_setting(setting)

    # ConfigData.update_setting(setting, plugin)
    config_data.update_setting(setting, plugin)

    # ConfigData.update_setting(Setting('timeout', 'int', '6'), plugin)
    config_data.update_setting(Setting('timeout', 'int', '6'), plugin)

    # ConfigData.update_setting(Setting('timeout', 'str', '6'), plugin)
    config_data.update_setting(Setting('timeout', 'str', '6'), plugin)

    assert len(config_data.get_settings()) == 3

    assert config_

# Generated at 2022-06-10 22:46:34.378196
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []



# Generated at 2022-06-10 22:46:39.820862
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    setting_1 = ConfigSetting(name='foo', plugin='bar', value='baz')
    data.update_setting(setting_1)

    assert data._global_settings['foo'] == setting_1

    setting_2 = ConfigSetting(name='foo', plugin=Plugin('magic', 'the gathering'), value='barbaz')
    data.update_setting(setting_2)

    assert data._plugins['magic']['the gathering']['foo'] == setting_2


# Generated at 2022-06-10 22:46:43.341743
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting( Setting('', 'ansible_connection', 'paramiko'))
    assert config.get_setting('ansible_connection')


# Generated at 2022-06-10 22:46:54.720237
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    
    plugin_type = 'service'
    plugin_name = 'service_webserver'
    setting_name = 'port'
    setting_value = '80'
    setting_type = 'integer'
    setting_desc = 'The default port for the webserver'

    # Class initialization
    config_data = ConfigData()

    setting = Setting()
    setting.name = setting_name
    setting.value = setting_value
    setting.type = setting_type
    setting.desc = setting_desc

    plugin = Plugin()
    plugin.type = plugin_type
    plugin.name = plugin_name

    config_data.update_setting(setting, plugin)

    # Test
    setting_test = config_data.get_setting(setting_name, plugin)


# Generated at 2022-06-10 22:46:58.627176
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0
    assert len(config_data.get_settings('foo')) == 0
    assert len(config_data.get_settings(None)) == 0


# Generated at 2022-06-10 22:47:08.714517
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    '''
    test case for method update_setting of class ConfigData
    '''

    config_data = ConfigData()

    from ansible.plugins.loader import action_loader
    from ansible.plugins.action.copy import ActionModule
    plugin = action_loader.get('copy', class_only=True)
    plugin.name = 'copy'
    plugin.path = '/root/.ansible/plugins/modules/copy.py'
    plugin.type = 'action'
    plugin.aliases = ['async', 'synchronize']
    plugin.short_desc = 'copy files to remote locations'
    plugin.version = None
    plugin.deprecated = False
    plugin.docuri = None
    plugin.docfrag = None
    plugin.internal_data = None


# Generated at 2022-06-10 22:47:12.096812
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    p = Plugin()
    s = Setting()
    config_data.update_setting(s, p)
    assert config_data.get_setting(p.name, p.type) == s


# Generated at 2022-06-10 22:47:18.466955
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from mock import Mock
    from ansible.module_utils.common._collections import ImmutableDict

    config_data = ConfigData()
    plugin = Mock()
    plugin.type = 'test_type'
    plugin.name = 'test_name'

    setting = Mock()
    setting.name = 'test_setting'
    setting.value = 'test_value'

    assert config_data.get_setting('test_setting') is None
    assert config_data.get_setting(plugin=plugin) is None
    assert config_data.get_setting('test_setting', plugin=plugin) is None

    config_data.update_setting(setting)

    assert config_data.get_setting('test_setting') == setting
    assert config_data.get_setting('test_setting', plugin=plugin) is None

    config_data

# Generated at 2022-06-10 22:47:26.253034
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting_1 = Setting("a")
    setting_2 = Setting("b")
    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2)
    plugin = Plugin("c", "d")
    config_data.update_setting(setting_1, plugin)
    assert config_data.get_setting("a") == setting_1
    assert config_data.get_setting("a", plugin) == setting_1


# Generated at 2022-06-10 22:47:40.741742
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data._global_settings = dict(a=1, b=2, c=3)
    config_data._plugins = dict(foo=dict(bar=dict(d=4, e=5)))
    # get_setting(name, plugin)
    # Testing global_settings
    assert config_data.get_setting('a').name == 'a'
    assert config_data.get_setting('a').value == 1
    assert config_data.get_setting('b').name == 'b'
    assert config_data.get_setting('b').value == 2
    assert config_data.get_setting('c').name == 'c'
    assert config_data.get_setting('c').value == 3
    # Testing plugins

# Generated at 2022-06-10 22:47:41.468127
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    pass

# Generated at 2022-06-10 22:47:48.759250
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting('setting_global')
    assert config_data.get_setting('setting_global')  == 'setting_global'
    config_data.update_setting('setting_plugin')
    assert config_data.get_setting('setting_plugin')  == 'setting_plugin'
    assert config_data.get_setting('setting_global')  == 'setting_global'


# Generated at 2022-06-10 22:47:51.718760
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    a = ConfigData()
    b = ConfigData()
    if a == b:
        print("test case 1: OK")

test_ConfigData_get_settings()

# Generated at 2022-06-10 22:47:56.432951
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    setting1 = {'name' : 'test_setting', 'value' : 'value1'}
    config_data.update_setting(setting1)

    setting2 = config_data.get_setting('test_setting')

    assert setting1 == setting2


# Generated at 2022-06-10 22:48:03.227207
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from units.module_utils.basic import AnsibleModule

    config_data = ConfigData()
    plugin_name = 'test-unit-001'
    setting_name = 'test-unit-001-setting'
    module = AnsibleModule(argument_spec={
        'name': {'type': 'str', 'required': True},
        'plugin_name': {'type': 'str', 'required': True},
        'value': {'type': 'str', 'required': False},
    })
    setting = None
    plugin = None

    module.params['name'] = setting_name
    module.params['plugin_name'] = plugin_name
    setting = module.params['name']
    plugin = module.params['plugin_name']

    config_data.update_setting(setting, plugin)


test_ConfigData_update_

# Generated at 2022-06-10 22:48:07.627173
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Create ConfigData
    config_data = ConfigData()

    # Unit test for method update_setting of class ConfigData
    setting = Setting('default', 'test_encoding_name')
    config_data.update_setting(setting)



# Generated at 2022-06-10 22:48:16.653800
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    global_setting = Setting('setting1', 'value1')
    config_data.update_setting(global_setting)
    plugin = Plugin('plugin', 'plugin_type')
    plugin_setting = Setting('plugin_setting', 'plugin_value')
    config_data.update_setting(plugin_setting, plugin)

    assert config_data._global_settings == {'setting1': global_setting}
    assert plugin.type in config_data._plugins
    assert plugin.name in config_data._plugins[plugin.type]
    assert plugin_setting.name in config_data._plugins[plugin.type][plugin.name]



# Generated at 2022-06-10 22:48:24.736148
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test with setting which is not exist
    setting = config_data.get_setting('setting_not_exist')
    assert(setting is None)

    # Test with setting which is exist
    from ansible.module_utils.common.validation import Setting
    import ansible.module_utils.common.validation as validation
    setting = Setting('setting_name', 'setting_value', validation.ValueType.STRING)
    config_data.update_setting(setting)
    setting = config_data.get_setting('setting_name')
    assert('setting_name' == setting.name)
    assert('setting_value' == setting.value)

    # Test with setting which is exist in a plugin
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-10 22:48:34.491839
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint.rules import RulesCollection
    from ansiblelint import Runner
    import os
    path_to_config = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test/testdata/yamllint.yml')
    path_to_rules = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test/testdata/rules_dir/')
    rules_dirs = [path_to_rules]
    config_data = ConfigData()
    rules_collection = RulesCollection()
    runner = Runner(rules_dirs=rules_dirs, config_file=path_to_config, config_data=config_data, rules=rules_collection)
    assert runner.config_data._global

# Generated at 2022-06-10 22:48:54.564651
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_obj = ConfigData()
    assert isinstance(test_obj._global_settings.get('config_name'), type(None))
    assert isinstance(test_obj._plugins.get('action'), type(None))
    setting = mock.Mock()
    test_obj.update_setting(setting, None)
    assert isinstance(test_obj._global_settings.get('config_name'), mock.Mock)
    assert isinstance(test_obj._plugins.get('action'), type(None))
    plugin = mock.Mock()
    test_obj.update_setting(setting, plugin)
    assert isinstance(test_obj._global_settings.get('config_name'), mock.Mock)
    assert isinstance(test_obj._plugins.get('action'), mock.Mock)


# Generated at 2022-06-10 22:48:59.478516
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    cd = ConfigData()

    plugin = None
    name = "foo"
    assert cd.get_setting(name, plugin) is None

    setting = Setting("foo", "foo_type")
    cd.update_setting(setting)

    assert cd.get_setting(name, plugin) == setting


# Generated at 2022-06-10 22:49:08.494970
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting1 = Setting(name = "setting1", 
                value = "key1_value",
                plugin = Plugin(plugin_type = 'plugin_type1', 
                                plugin_name = 'plugin_name1'))

    setting2 = Setting(name = "setting2", 
                value = "key2_value",
                plugin = Plugin(plugin_type = 'plugin_type2', 
                                plugin_name = 'plugin_name2'))

    config_data = ConfigData()
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)

    # Test if the updated global setting is inside config_data
    assert 'setting1' in config_data._global_settings
    assert 'setting2' in config_data._global_settings                               

    # Test if the updated plugin setting

# Generated at 2022-06-10 22:49:20.318817
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()
    plugin1 = Plugin('network_os', 'cisco')
    plugin2 = Plugin('network_os', 'juniper')
    plugin3 = Plugin('network_os', 'arista')
    plugin4 = Plugin('connection', 'netconf')
    plugin5 = Plugin('connection', 'cliconf')
    plugin6 = Plugin('inventory', 'aws')
    plugin7 = Plugin('inventory', 'gcp')
    plugin8 = Plugin('inventory', 'vmware')
    setting1 = ConfigSetting('timeout', '60')
    setting2 = ConfigSetting('persistent_connection', 'network_cli')
    setting3 = ConfigSetting('gather_subset', '!config')
    setting4 = ConfigSetting('gather_timeout', '30')

    configData.update_setting(setting1, plugin1)
   

# Generated at 2022-06-10 22:49:25.661531
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    config.update_setting(Setting('key1', 'value1'), Plugin('local', 'action'))
    assert(config.get_settings(Plugin('local', 'action'))[0].name == 'key1')
    assert(config.get_settings(Plugin('local', 'action'))[0].value == 'value1')


# Generated at 2022-06-10 22:49:37.218469
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Test data
    cd = ConfigData()

    # Initialize setting objects
    s1 = { 'name':'foo', 'value':'bar', 'plugin':None }
    s2 = { 'name':'baz', 'value':'baz', 'plugin':None }
    s3 = { 'name':'foo', 'value':'baz', 'plugin':'A' }
    s4 = { 'name':'foo', 'value':'bar', 'plugin':'B' }

    # Update data storage
    cd.update_setting(s1)
    cd.update_setting(s2)
    cd.update_setting(s3)
    cd.update_setting(s4)

    # Test 1
    assert len(cd.get_settings()) == 2
    assert len(cd.get_settings(s3))

# Generated at 2022-06-10 22:49:41.792123
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cfg=ConfigData()
    cfg.update_setting("test1")
    cfg.update_setting("test2")

    assert cfg._global_settings["test1"] == "test1"
    assert cfg._global_settings["test2"] == "test2"

if __name__ == '__main__':
    test_ConfigData_update_setting()

# Generated at 2022-06-10 22:49:51.922273
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    from ansible.plugins.loader import shared_loader

# Generated at 2022-06-10 22:49:53.188319
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()
    assert configdata.get_settings() == []

# Generated at 2022-06-10 22:49:57.447490
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configdata = ConfigData()
    assert configdata.get_setting("foo", None) == None
    import ansible.plugins.loader
    plugin = ansible.plugins.loader.Plugin("type", "name", "path")
    assert configdata.get_setting("foo", plugin) == None
    assert configdata.get_settings(plugin) == []


# Generated at 2022-06-10 22:50:28.375523
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    global_setting_1 = Setting('global_setting_1', 'global_value_1')
    global_setting_2 = Setting('global_setting_2', 'global_value_2')
    global_setting_3 = Setting('global_setting_3', 'global_value_3')
    config_data.update_setting(global_setting_1)
    config_data.update_setting(global_setting_2)
    config_data.update_setting(global_setting_3)

    plugin = Plugin('type_1', 'name_1')
    plugin_setting_1 = Setting('setting_1', 'value_1')
    plugin_setting_2 = Setting('setting_2', 'value_2')
    config_data.update_setting(plugin_setting_1, plugin)
    config