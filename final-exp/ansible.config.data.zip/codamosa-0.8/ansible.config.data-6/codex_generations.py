

# Generated at 2022-06-10 22:40:36.038413
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    plugin = PluginOptions()
    plugin.type = 'some_type'
    plugin.name = 'some_name'
    setting = SettingOptions()
    setting.name = 'some_setting_name'
    setting.value = 'some_setting_value'
    setting.scope = SettingOptions.SCOPE_GLOBAL
    setting.origin = SettingOptions.ORIGIN_DEFAULT

    config_data.update_setting(setting, plugin)

    updated_setting = config_data.get_setting('some_setting_name', plugin)
    assert updated_setting.name == 'some_setting_name'
    assert updated_setting.value == 'some_setting_value'
    assert updated_setting.scope == SettingOptions.SCOPE_GLOBAL
    assert updated_setting.origin == SettingOptions.OR

# Generated at 2022-06-10 22:40:46.640755
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # test case 1: undefined key, plugin = None
    assert config_data.get_setting("INVALID KEY", None) == None

    # test case 2: defined key, plugin = None
    config_data._global_settings["FOO"] = "BAR"
    assert config_data.get_setting("FOO", None) == "BAR"

    # test case 3: undefined key, plugin = Plugin
    class Plugin(object):
        type = "COLLECTION"
        name = "FOO"
    assert config_data.get_setting("INVALID KEY", Plugin()) == None

    # test case 4: undefined key, plugin = Plugin
    config_data._plugins["COLLECTION"] = {}
    config_data._plugins["COLLECTION"]["FOO"] = {}
    config

# Generated at 2022-06-10 22:40:47.899522
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert config.get_setting('data_dir') == None


# Generated at 2022-06-10 22:40:58.134350
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from collections import namedtuple
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.compat import IS_PYTHON3
    from ansible.module_utils.local import LocalAnsibleModule

    if IS_PYTHON3:
        unicode = str

    def set_module_args(args):
        args = json.dumps({'ANSIBLE_MODULE_ARGS': args})
        basic._ANSIBLE_ARGS = to_bytes(args)

    def exit_json(*args, **kwargs):
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        raise AnsibleFailJson(kwargs)


# Generated at 2022-06-10 22:41:06.641219
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    test_data = ConfigData()
    test_data.update_setting(Setting('plugins', '1'))  # global setting
    test_data.update_setting(Setting('name', '1', Plugin('a', 'b')))  # plugin setting

    # When getting an existing global setting by name
    assert test_data.get_setting('plugins') == Setting('plugins', '1')
    # When getting a non-existing global setting by name
    assert test_data.get_setting('test') is None
    # When getting an existing plugin setting by name and plugin
    assert test_data.get_setting('name', Plugin('a', 'b')) == Setting('name', '1', Plugin('a', 'b'))
    # When getting a non-existing plugin setting by name

# Generated at 2022-06-10 22:41:18.141101
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert (config_data._global_settings == {})
    assert (config_data._plugins == {})

    config_data.update_setting(Setting('FOO', 'FOO_VALUE'))
    assert (config_data._global_settings == {'FOO': Setting('FOO', 'FOO_VALUE')})
    assert (config_data._plugins == {})

    config_data.update_setting(Setting('BAR', 'BAR_VALUE'), Plugin('VAR', 'PATH'))
    assert (config_data._global_settings == {'FOO': Setting('FOO', 'FOO_VALUE')})
    assert (config_data._plugins == {'VAR': {'PATH': {'BAR': Setting('BAR', 'BAR_VALUE')}}})



# Generated at 2022-06-10 22:41:24.256259
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.config.setting import Setting

    config_data = ConfigData()
    assert config_data.get_settings() == []

    s1 = Setting('foo')
    s2 = Setting('bar')
    config_data.update_setting(s1)
    config_data.update_setting(s2)
    assert config_data.get_settings() == [s1, s2]

    assert config_data.get_settings(None) == [s1, s2]

# Generated at 2022-06-10 22:41:33.138265
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Wrong setting name will return None
    config_data = ConfigData()
    setting = config_data.get_setting("wrong-setting-name")
    assert setting is None

    # Retrieve a setting without plugin
    config_data.update_setting(Setting(name='test-setting', value='test-value'))
    setting = config_data.get_setting("test-setting")
    assert setting is not None
    assert setting.name == 'test-setting'
    assert setting.value == 'test-value'

    # Retrieve a setting from a plugin
    plugin = Plugin(type='test-plugin-type', name='test-plugin-name')
    config_data.update_setting(Setting(name='test-setting', value='test-value'), plugin)
    setting = config_data.get_setting("test-setting", plugin)


# Generated at 2022-06-10 22:41:40.655112
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Initialize instance of class ConfigData
    config_data = ConfigData()
    setting_1_key = 'test_setting_1'
    setting_1_val = 'test_setting_1_value'
    setting_2_key = 'test_setting_2'
    setting_2_val = 'test_setting_2_value'
    setting_3_key = 'test_setting_3'
    setting_3_val = 'test_setting_3_value'
    plugin_type = 'test_type'
    plugin_name = 'test_name'
    # Test variable assert
    assert config_data.get_setting(setting_1_key) is None
    # Test method update_setting
    config_data.update_setting(ConfigSetting(setting_1_key, setting_1_val))
    # Test variable

# Generated at 2022-06-10 22:41:53.500554
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    plugin_type = 'test_plugin_type'
    plugin_name = 'test_plugin_name'

    setting1 = Setting.create(
        'test_name1',
        'test_value1',
        'test_section1',
        'test_subsection1')
    config_data.update_setting(setting1)

    setting2 = Setting.create(
        'test_name2',
        'test_value2',
        'test_section2',
        'test_subsection2')
    config_data.update_setting(setting2, Plugin.create(plugin_type, plugin_name))

    settings = config_data.get_settings()
    assert len(settings) == 1


# Generated at 2022-06-10 22:41:57.278573
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    config_data.update_setting("test")
    assert config_data.get_settings() == ["test"]

# Generated at 2022-06-10 22:42:04.986407
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    test_plugins = [
        {'type': 'module', 'name': 'conjur'},
        {'type': 'module', 'name': 'conjur_aws'},
        {'type': 'module', 'name': 'conjur_template'},
        {'type': 'lookup', 'name': 'conjur_secret'}
    ]
    assert config.get_settings() == []
    for plugin in test_plugins:
        assert config.get_settings(plugin=plugin) == []
        assert config.get_settings(plugin=plugin) == []

# Generated at 2022-06-10 22:42:08.017480
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(dest='1', type='bool', default='yes', ini_section='1', ini_key='1'))
    assert '1' in config_data._global_settings

# Generated at 2022-06-10 22:42:17.314982
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import Plugin, PluginLoader
    from ansible.plugins.loader import path_dwim_relative, find_plugin

    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionFinder
    loader = AnsibleCollectionLoader()
    loader.add_collection_path('./collections')
    collection_finder = AnsibleCollectionFinder(loader, '')
    loader._add_collection_resolver(collection_finder)

    # Find the collection plugin
    plugin_path = path_dwim_relative('./', 'collection', 'my_collection')

# Generated at 2022-06-10 22:42:20.443408
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert None == config_data.get_settings()
    assert None == config_data.get_settings(plugin = None)


# Generated at 2022-06-10 22:42:30.289071
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    class Plugin(object):

        def __init__(self, type, name):
            self.type = type
            self.name = name


# Generated at 2022-06-10 22:42:35.542902
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    setting = ConfigEntry('setting_name')
    plugin = ConfigPlugin('plugin_name', 'plugin_type')
    data.update_setting(setting)
    data.update_setting(setting, plugin)


# Generated at 2022-06-10 22:42:40.313570
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    from ansible import constants as C
    C.DEFAULT_MODULE_PATH = os.path.dirname(__file__)
    result = cd.get_setting('default_inventory_base', plugin='InventoryModule')
    assert result == '/etc/ansible'


# Generated at 2022-06-10 22:42:42.276771
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """
    Test that the method update_setting
    """
    config = ConfigData()
    setting = Setting('word','word','word','word','word','word','word','word','word','word','word','word' )
    test = config.get_setting('word')
    assert test == None


# Generated at 2022-06-10 22:42:49.435095
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.config import PluginConfig
    from ansible.module_utils.config import SettingConfig

    config_data = ConfigData()

    setting_plugin = SettingConfig(
        name='plugin1_setting1', value='plugin1.setting1:true', priority=10)
    config_data.update_setting(setting_plugin, plugin=PluginConfig('connection', 'local'))

    setting_global = SettingConfig(name='global1_setting1', value='global1.setting1:true', priority=10)
    config_data.update_setting(setting_global)

    setting_global = SettingConfig(name='global2_setting1', value='global2.setting1:true', priority=10)
    config_data.update_setting(setting_global)


# Generated at 2022-06-10 22:42:59.252022
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    c.update_setting(Setting(name='test', value='value', origin='test'))
    assert c._global_settings['test'].name == 'test'
    assert c._global_settings['test'].value == 'value'
    assert c._global_settings['test'].origin == 'test'



# Generated at 2022-06-10 22:43:03.253113
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    test_setting = PluginSetting(name='test_setting', value='test_value')
    config_data.update_setting(test_setting)
    assert config_data.get_setting('test_setting') == test_setting

# Generated at 2022-06-10 22:43:04.642406
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd=ConfigData()
    assert not cd._global_settings


# Generated at 2022-06-10 22:43:09.187178
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from collections import namedtuple
    config_data = ConfigData()
    Plugin = namedtuple('Plugin',['name', 'type'])
    plugin = Plugin('neutron', 'networking')
    assert config_data.get_settings() == []
    assert config_data.get_settings(Plugin('neutron', 'networking')) == []


# Generated at 2022-06-10 22:43:13.125145
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = Setting("a")
    config_data.update_setting(setting)
    settings = config_data.get_settings()
    #assert len(settings) == 1
    assert settings[0].name == "a"


# Generated at 2022-06-10 22:43:23.981571
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    global_setting = ConfigSetting('setting1', '/home/ansibles/setting1')
    plugin = ConfigPlugin('module', 'paramiko')
    plugin_setting = ConfigSetting('setting1', '/home/ansibles/module/paramiko/setting1')

    config_data.update_setting(global_setting)
    config_data.update_setting(plugin_setting, plugin)

    assert config_data.get_setting('setting1') == global_setting
    assert config_data.get_setting('setting1', plugin) == plugin_setting

    assert config_data.get_settings() == [global_setting]
    assert config_data.get_settings(plugin) == [plugin_setting]



# Generated at 2022-06-10 22:43:36.299683
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # mocks
    class MockPlugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class MockSetting:
        def __init__(self, name):
            self.name = name

    global_setting = MockSetting('global_setting')
    plugin_setting = MockSetting('plugin_setting')

    # create instance
    config_data = ConfigData()

    # add global setting
    config_data.update_setting(global_setting)

    # add plugin setting
    plugin = MockPlugin('lookup', 'aws')
    config_data.update_setting(plugin_setting, plugin)

    # get global setting
    setting = config_data.get_setting('global_setting')
    assert setting.name == 'global_setting'

    # get plugin setting
    setting

# Generated at 2022-06-10 22:43:43.549010
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Valid plugin type
    plugin = Plugin(type='action', name='foo', path='/path/to')
    config_data = ConfigData()

    assert config_data.get_settings() == []
    assert config_data.get_settings(plugin) == []

    # Invalid plugin type
    plugin = Plugin(type='invalid', name='foo', path='/path/to')
    config_data = ConfigData()

    assert config_data.get_settings() == []
    assert config_data.get_settings(plugin) == []


# Generated at 2022-06-10 22:43:53.463813
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()

    # Test for global settings
    config.update_setting(Setting('string', 'foo'))
    config.update_setting(Setting('bool', True))
    config.update_setting(Setting('integer', 1))

    settings = config.get_settings()
    assert len(settings) == 3
    assert all([s.name == 'string' or s.name == 'bool' or s.name == 'integer'
                for s in settings])

    # Test for plugin settings
    config.update_setting(Setting('string', 'bar', Plugin('action', 'example')))
    config.update_setting(Setting('bool', False, Plugin('action', 'example')))
    config.update_setting(Setting('integer', 2, Plugin('action', 'example')))


# Generated at 2022-06-10 22:44:02.694881
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    # test on nothing set
    assert config_data.get_settings() == []

    # test on a global configuration set
    setting = ConfigSetting('test', 'elem1')
    config_data.update_setting(setting)
    assert config_data.get_settings() == [setting]

    # test on a local configuration set
    plugin = PluginConfig('test', 'cisco_ios')
    setting2 = ConfigSetting('test2', 'elem2')
    config_data.update_setting(setting2, plugin)
    assert config_data.get_settings(plugin) == [setting2]

    # test when global and local configuration set
    assert config_data.get_settings() == [setting, setting2]

    # test on a local configuration set

# Generated at 2022-06-10 22:44:19.343854
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    config_data._global_settings = {
        "vault_password_file": "/root/some_path/.vault_pass",
    }

    assert len(config_data._global_settings) == 1

    config_data._plugins = {
        "connection": {
            "ssh": {
                "timeout": 30,
                "ssh_args": "-C",
            }
        }
    }

    assert len(config_data._plugins) == 1
    assert len(config_data._plugins["connection"]) == 1

    # Test getting the global settings
    settings = config_data.get_settings()
    assert settings[0].name == "vault_password_file"
    assert settings[0].value == "/root/some_path/.vault_pass"

    # Test getting plugin

# Generated at 2022-06-10 22:44:24.501054
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    global_setting = Setting('foo', 'bar', 'doc_string', None, None, None)
    config_data.update_setting(global_setting)

    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0].plugin is None
    asser

# Generated at 2022-06-10 22:44:32.347595
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    plugin = PluginData('test_type', 'test_name')
    setting = SettingData('test_name')

    config_data.update_setting(setting, plugin)

    assert config_data.get_setting('test_name', plugin).name == 'test_name'
    assert config_data.get_setting('test_name', plugin).default == None
    assert config_data.get_setting('test_name', plugin).plugin_type == 'test_type'
    assert config_data.get_setting('test_name', plugin).plugin_name == 'test_name'

# Generated at 2022-06-10 22:44:45.367857
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from collections import namedtuple
    from ansible.parsing.plugin_docs import read_docstring
    Plugin = namedtuple('Plugin', ['name', 'type'])

    config_data = ConfigData()
    plugin = Plugin('action', 'action')

    config_data.update_setting(read_docstring(plugin, './lib/ansible/modules/network/nxos/nxos_bgp.py'), plugin)
    config_data.update_setting(read_docstring(plugin, './lib/ansible/modules/network/nxos/nxos_facts.py'), plugin)

    for k in config_data._global_settings:
        assert(k == 'explicit_setup' or k == 'proxy' or k == 'persistent_connection')


# Generated at 2022-06-10 22:44:56.084059
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert config.get_setting('name') is None

    config.update_setting(Setting('name', 'value'))
    assert config.get_setting('name') is not None
    assert config.get_setting('name').value == 'value'

    assert config.get_setting('name', Plugin('t', 'n')) is None
    assert config.get_setting('name', Plugin('t', 'n')).value == 'value'

    config.update_setting(Setting('name', 'value2'), Plugin('t', 'n'))
    assert config.get_setting('name') is not None
    assert config.get_setting('name').value == 'value'
    assert config.get_setting('name', Plugin('t', 'n')) is not None

# Generated at 2022-06-10 22:45:05.570732
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    instance = ConfigData()

    import ansible.plugins.loader as plugins_loader

    instance.update_setting(plugins_loader.create_setting(name='plugin_name', value="plugin_value", plugin=None))

    # Find a plugin to update
    plugin = plugins_loader.find_plugin(type='action', name='assert')

    assert len(instance.get_settings(plugin)) == 0

    instance.update_setting(plugins_loader.create_setting(name='plugin_name1', value="plugin_value1", plugin=plugin))
    instance.update_setting(plugins_loader.create_setting(name='plugin_name2', value="plugin_value2", plugin=plugin))

    assert len(instance.get_settings(plugin)) == 2
    assert len(instance.get_settings(None)) == 1

# Generated at 2022-06-10 22:45:09.347837
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    setting = Setting('foo')
    config_data.update_setting(setting)

    assert config_data.get_setting('foo') == setting



# Generated at 2022-06-10 22:45:19.221502
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader
    from ansible.utils.plugin_docs import get_docstring
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    local_path = os.path.dirname(__file__)
    data_loader = DataLoader()

    plugin_loader = PluginLoader("vars", "vars_plugins", C.DEFAULT_VARS_PLUGIN_PATH, '_', 'vars_plugins')
    var_plugins = plugin_loader.all()
    for var_plugin in var_plugins:
        var_plugin._load_plugin()
        doc_text = get_docstring(var_plugin._plugin_class._get_methods()[0])

# Generated at 2022-06-10 22:45:29.834147
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    #create local instances
    data = ConfigData()
    setting1 = ConfigSetting('setting1')
    setting2 = ConfigSetting('setting2')
    plugin = ConfigPlugin('test', 'become')

    # test with no settings loaded
    assert data.get_settings() == []

    # test with no settings loaded for plugin
    assert data.get_settings(plugin) == []

    # test with global setting loaded only
    data.update_setting(setting1)
    assert data.get_settings() == [setting1]

    # test with one setting loaded for plugin
    data.update_setting(setting1, plugin)
    assert data.get_settings(plugin) == [setting1]

    # test with two settings loaded for plugin
    data.update_setting(setting2, plugin)

# Generated at 2022-06-10 22:45:31.827539
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('xyz') is None


# Generated at 2022-06-10 22:45:45.381714
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    ConfigData_object = ConfigData()
    ConfigData_object.update_setting(None)
    with pytest.raises(Exception):
        ConfigData_object.update_setting(123)
    with pytest.raises(Exception):
        ConfigData_object.update_setting('abc')

# Generated at 2022-06-10 22:45:56.192223
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # initialize config data object
    config_data = ConfigData()
    # initialize settings
    setting1 = Setting(name='plugin_import_path', value=['lib/ansible/plugins/lookup','lib/ansible/plugins/filter'], scope='global')
    setting2 = Setting(name='stdout_callback', value='json', scope='global')
    # update settings
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    # assert settings
    assert config_data._global_settings == {'plugin_import_path': setting1, 'stdout_callback': setting2}

    # initialize config data object
    config_data = ConfigData()
    # initialize settings
    setting1 = Setting(name='ignore_errors', value=True, scope='action')
    setting2 = Setting

# Generated at 2022-06-10 22:46:02.913934
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    # Test empty config data
    assert config_data.get_settings() == []
    # Test global config
    global_setting = ConfigSetting('Setting1', 'Value1')
    config_data.update_setting(global_setting)
    assert config_data.get_settings() == [global_setting]

    # Test content of plugin config (not defined plugin)
    assert config_data.get_settings(PluginIdentifier('Not', 'Defined')) == []
    # Test content of plugin config (existing plugin)
    plugin = PluginIdentifier('Existing', 'Plugin')
    plugin_setting = ConfigSetting('Setting2', 'Value1')
    config_data.update_setting(plugin_setting, plugin)
    assert config_data.get_settings(plugin) == [plugin_setting]
    # Test

# Generated at 2022-06-10 22:46:14.072882
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    setting1 = Setting('setting1', 'value1')
    config_data.update_setting(setting1, None)
    setting2 = Setting('setting2', 'value2')
    config_data.update_setting(setting2, None)

    setting3 = Setting('setting3', 'value3')
    plugin_type = PluginType('Module','module')
    plugin = Plugin('AzureModules','azure_rm_vm',plugin_type)
    config_data.update_setting(setting3, plugin)

    setting4 = Setting('setting4', 'value4')
    plugin2 = Plugin('AzureModules','azure_rm_vm_facts',plugin_type)
    config_data.update_setting(setting4, plugin2)

    expected_result = [setting1,setting2]


# Generated at 2022-06-10 22:46:24.982287
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    global_settings = {}
    settings = {}

    config_data = ConfigData()

    assert config_data.get_settings() == settings
    assert config_data.get_settings() == global_settings

    settings['setting1'] = 1
    global_settings['setting1'] = 1

    assert config_data.get_settings() == settings
    assert config_data.get_settings() == global_settings

    # import pdb; pdb.set_trace()
    settings['setting2'] = 2
    global_settings['setting2'] = 2

    assert config_data.get_settings() == settings
    assert config_data.get_settings() == global_settings


# Generated at 2022-06-10 22:46:30.866361
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting("setting_name") is None
    assert config_data.get_setting("setting_name", None) is None
    assert config_data.get_settings() == []
    assert config_data.get_settings(None) == []

    from collections import namedtuple
    PluginInfo = namedtuple("PluginInfo", ["type", "name"])
    plugin = PluginInfo("collection", "test_collection")
    config_data.update_setting("test_setting", plugin)
    assert config_data.get_setting("setting_name") is None
    assert config_data.get_setting("setting_name", None) is None
    assert config_data.get_settings() == []
    assert config_data.get_settings(None) == []


# Generated at 2022-06-10 22:46:35.421486
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Setup
    config_data = ConfigData()
    config_data.update_setting(None)
    config_data.update_setting(None, None)

    # Verify
    assert config_data.get_setting(None) is None
    assert config_data.get_setting(None, None) is None


# Generated at 2022-06-10 22:46:42.048880
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # A config data.
    config = ConfigData()
    # Two settings
    s1 = Setting("a", "int", 1)
    s2 = Setting("b", "bool", False)
    # Configure a and b settings for collection plugin 'a'
    collection_plugin_a = Plugin("collection", "a")
    config.update_setting(s1, collection_plugin_a)
    config.update_setting(s2, collection_plugin_a)
    # Configure a and b settings for collection plugin 'b'
    collection_plugin_b = Plugin("collection", "b")
    config.update_setting(s1, collection_plugin_b)
    config.update_setting(s2, collection_plugin_b)
    # Two settings again, a and b
    s3 = Setting("c", "int", 1)


# Generated at 2022-06-10 22:46:53.568851
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    from collections import namedtuple
    Plugin = namedtuple('Plugin', ['type', 'name'])

    setting1 = Setting('setting1', 'global', 'None', 'None')
    config_data.update_setting(setting1)
    setting2 = Setting('setting2', 'global', 'None', 'None')
    config_data.update_setting(setting2)
    setting3 = Setting('setting3', 'global', 'None', 'None')
    config_data.update_setting(setting3)

    plugin1 = Plugin('plugin1', 'plugin1')
    setting4 = Setting('setting4', 'global', 'None', 'None')
    config_data.update_setting(setting4)
    setting5 = Setting('setting5', 'global', 'None', 'None')
    config_data

# Generated at 2022-06-10 22:47:03.705747
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting('global_setting')
    assert config_data._global_settings == {'global_setting': 'global_setting'}

    # config_data._plugins is an ordereddict.
    config_data.update_setting('type1_setting1', 'type1', 'type1_plugin1')
    config_data.update_setting('type1_setting2', 'type1', 'type1_plugin2')
    config_data.update_setting('type2_setting1', 'type2', 'type2_plugin1')
    config_data.update_setting('type2_setting2', 'type2', 'type2_plugin2')
    config_data.update_setting('type2_setting3', 'type2', 'type2_plugin3')

    assert config_data

# Generated at 2022-06-10 22:47:38.060143
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Initialize ConfigData
    cd = ConfigData()
    s1 = Setting("s1", "s1_type", "s1_name")
    s2 = Setting("s2", "s2_type", "s2_name")
    p1 = Plugin("p1_type", "p1_name")
    p2 = Plugin("p2_type", "p2_name")

    # Update global setting
    cd.update_setting(s1)
    assert cd.get_setting("s1") == s1

    # Update plugin setting (p1)
    cd.update_setting(s2, p1)
    assert cd.get_setting("s2", p1) == s2

    # Update plugin setting (p2)
    cd.update_setting(s1, p2)
    assert cd.get_setting

# Generated at 2022-06-10 22:47:44.744515
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    assert cd.get_setting('default_callback_whitelist') == None
    cd.update_setting(Setting('default_callback_whitelist', 'json'))
    assert cd.get_setting('default_callback_whitelist') == 'json'

if __name__ == '__main__':
    test_ConfigData_get_setting()

# Generated at 2022-06-10 22:47:48.817620
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    expected_result = 1,
    data = ConfigData()
    data.update_setting(Setting(name='plugin_dirs',
                                value=expected_result))
    assert data.get_settings()[0].value == expected_result


# Generated at 2022-06-10 22:47:58.674770
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = PluginDefinition()
    plugin.name = "Plugin1"
    plugin.type = "Action"
    setting = SettingDefinition()
    setting.name = "test1"
    setting.default = "test_default_value"
    config_data.update_setting(setting, plugin)
    setting.name = "test2"
    setting.default = "test_default_value"
    config_data.update_setting(setting, plugin)
    setting.name = "test3"
    setting.default = "test_default_value"
    config_data.update_setting(setting, plugin)

    settings = config_data.get_settings(plugin)
    assert(len(settings) == 3)



# Generated at 2022-06-10 22:48:11.350667
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins import AnsiblePlugin
    from ansible.plugins.configuration import ConfigurationSetting

    # Create a collection of sample settings
    setting1 = ConfigurationSetting('foo', 'http')
    setting2 = ConfigurationSetting('bar', 'localhost')
    setting3 = ConfigurationSetting('baz', '8080')

    # Create a ConfigData object and add sample settings
    object = ConfigData()
    object.update_setting(setting1)
    object.update_setting(setting2)
    object.update_setting(setting3)

    # Test getting settings without a plugin
    settings = object.get_settings()
    assert len(settings) == 3
    assert setting1 in settings
    assert setting2 in settings
    assert setting3 in settings

    # Test getting settings with a plugin
    plugin = AnsiblePlugin('module', 'thing')
    setting

# Generated at 2022-06-10 22:48:12.068978
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    conf = ConfigData()
    assert conf.get_settings() == []


# Generated at 2022-06-10 22:48:14.608094
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    conf_data = ConfigData()
    print ('This is a test for expected value for method update_setting of class ConfigData')
    print ('Expected value for this method is None')
    print ('Actual value for this method is: %s' % conf_data.update_setting())


# Generated at 2022-06-10 22:48:20.109125
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    print(config_data.get_setting('PYTHONPATH').value)
    assert config_data.get_setting('PYTHONPATH').value == './'
    config_data.update_setting(Setting('PYTHONPATH', '/usr/bin'))
    print(config_data.get_setting('PYTHONPATH').value)
    assert config_data.get_setting('PYTHONPATH').value == '/usr/bin'



# Generated at 2022-06-10 22:48:28.500436
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_object=ConfigData()
    plugin_type='AnsibleModule'
    plugin_name='AnsibleModule'
    setting_name='ANSIBLE_MODULE_ARGS'
    setting_value='{"argument_spec": {"state": {"required": true, "choices": ["present", "absent"], "type": "str"}}, "supports_check_mode": true}'
    setting=Setting(setting_name,setting_value)
    config_data_object.update_setting(setting, Plugin(plugin_type, plugin_name))



# Generated at 2022-06-10 22:48:33.418930
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data=ConfigData()
    test_dict={"name": "SOME_SETTING", "value": 1, "scope": ["playbook", "task"], "origin": "file", "plugin": None}
    config_data.update_setting(ConfigSetting(test_dict))
    assert config_data._global_settings["SOME_SETTING"].name == "SOME_SETTING"


# Generated at 2022-06-10 22:49:20.464543
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    data = ConfigData()
    # Assert get_settings returns correct value
    assert len(data.get_settings()) == 0
    assert len(data.get_settings(None)) == 0

    # Assert get_settings returns correct value
    plugin = Plugin('plugins', 'test')
    data.update_setting(Setting(plugin, 'host_list', 'test'))
    assert len(data.get_settings()) > 0
    assert len(data.get_settings(None)) == 0

    # Assert get_settings returns correct value
    data.update_setting(Setting('test', None))
    assert len(data.get_settings()) > 0
    assert len(data.get_settings(None)) > 0


# Generated at 2022-06-10 22:49:24.635252
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', plugin=PluginTypeName('module', 'foo')) is None


# Generated at 2022-06-10 22:49:35.610732
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.config.manager import ConfigManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.dataloader import DataLoader
    from collections import namedtuple

    config_manager = ConfigManager()

    setting_spec = namedtuple('setting_spec', ['plugin', 'setting', 'value', 'include'])


# Generated at 2022-06-10 22:49:41.884720
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert(config_data.get_setting("ANSIBLE_FORCE_COLOR", None)==None)
    config_data.update_setting(Setting("ANSIBLE_FORCE_COLOR", "", "boolean", None, None, None, True))
    assert(isinstance(config_data.get_setting("ANSIBLE_FORCE_COLOR", None), Setting))
    assert(config_data.get_setting("ANSIBLE_FORCE_COLOR", None).value==True)


# Generated at 2022-06-10 22:49:46.132790
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    my_class = ConfigData()
    my_class.update_setting("setting1", "plugin1")
    assert my_class._global_settings == "setting1"

    my_class.update_setting("setting2", "plugin2")
    assert my_class._plugins["plugin2"] == "setting2"


# Generated at 2022-06-10 22:49:55.708514
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    import ansible.constants as C
    import ansible.module_utils.six as six
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.modules.packaging.os import get_distribution
    from ansible.plugins.loader import config_loader
    from ansible.plugins.connection.ssh import Connection as ConnectionImpl
    from ansible.utils.boolean import boolean
    connection_impl = ConnectionImpl.get_connection_class()
    connection_impl.get_option = lambda *args: False
    connection_impl.get_plugin_option = get_option
    connection_impl.get_plugin_option_bool = lambda *args: False
    config_loader.get_plugin_class = get_plugin_class

# Generated at 2022-06-10 22:49:59.283269
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(Setting('allow_world_readable_tmpfiles', 'True'))
    assert config.get_setting('allow_world_readable_tmpfiles') == 'True'
    config.update_setting(Setting('allow_world_readable_tmpfiles', 'False'))
    assert config.get_setting('allow_world_readable_tmpfiles') == 'False'



# Generated at 2022-06-10 22:50:05.646272
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting({'name': 'test','value': 'a','description': '','short_description': '','constant': '','default': '','type': ''})
    assert config._global_settings.get('test') == {'name': 'test','value': 'a','description': '','short_description': '','constant': '','default': '','type': ''}


# Generated at 2022-06-10 22:50:14.716942
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.config.settings import ConfigSetting

    data = ConfigData()

    # testing global setting
    name = 'abc'
    value = 'def'
    setting = ConfigSetting('test1', name, value, ['test1'], 'core', 'test1', [])
    data.update_setting(setting)
    assert data.get_setting(name) == setting

    # testing plugin setting
    name = 'ghi'
    value = 'jkl'
    setting = ConfigSetting('test2', name, value, ['test2'], 'core', 'test2', [])
    data.update_setting(setting, plugin=setting.plugin)
    assert data.get_setting(name, plugin=setting.plugin) == setting

# Generated at 2022-06-10 22:50:16.746564
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    result_test = config_data.get_setting('test')
    assert result_test == None