

# Generated at 2022-06-10 22:40:34.428131
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    settings = ConfigData()
    test_setting = Setting('name','value','description')
    settings.update_setting(test_setting)
    assert settings._global_settings['name'] == test_setting


# Generated at 2022-06-10 22:40:45.620341
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    if __name__ == "__main__":

        from ansible.module_utils.common.collections import ImmutableDict

        from units.compat.mock import patch
        from units.modules.utils import set_module_args

        from ansible.module_utils.basic import AnsibleModule
        from ansible.plugins.action.debug import ActionModule as DebugActionModule

        class MyDebugActionModule(DebugActionModule):

            def run(self, tmp=None, task_vars=None):
                return super(MyDebugActionModule, self).run(tmp, task_vars)

        class TestModule(object):
            def __init__(self, **kwargs):
                self.params = {
                    'name': 'aname',
                    'type': 'atype',
                }

# Generated at 2022-06-10 22:40:54.090547
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    plugin_1 = Plugin('test_plugin_1', 'test_type_1')
    plugin_2 = Plugin('test_plugin_2', 'test_type_1')

    setting_1 = Setting('test_setting_1', 'plugin')
    setting_2 = Setting('test_setting_2', 'core')

    config_data.update_setting(setting_1, plugin=plugin_1)
    config_data.update_setting(setting_2)

    assert config_data.get_setting('test_setting_1', plugin_1) is not None
    assert config_data.get_setting('test_setting_2') is not None
    assert config_data.get_setting('test_setting_1', plugin_2) is None


# Generated at 2022-06-10 22:41:04.282531
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansiblelint.rules import AnsibleLintRule

    class Rule1(AnsibleLintRule):
        id = 'TEST-1234'
        shortdesc = 'Test setting 1'
        description = 'Test setting 1'
        tags = ['formatting']

    class Rule2(AnsibleLintRule):
        id = 'TEST-5678'
        shortdesc = 'Test setting 2'
        description = 'Test setting 2'
        tags = ['formatting']

    class Rule3(AnsibleLintRule):
        id = 'TEST-1234'
        shortdesc = 'Test setting 3'
        description = 'Test setting 3'
        tags = ['formatting']


# Generated at 2022-06-10 22:41:15.731998
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import load_plugins
    from ansible.plugins.loader import find_plugin

    config_data = ConfigData()

    plugin_name = 'action'
    plugin_type = 'test_plugin'
    config_data.update_setting(ConfigSetting(plugin_name, plugin_type, 'test', 'test'))

    assert config_data._global_settings['test']
    assert not config_data._plugins

    # Example of a loaded plugin
    plugin = find_plugin(plugin_name, plugin_type)
    plugin_loaded = load_plugins(plugin_name, plugin_type, plugin)

    config_data.update_setting(ConfigSetting(plugin.name, plugin.type, 'test', 'test'), plugin_loaded)

    assert config_data._global_settings['test']

# Generated at 2022-06-10 22:41:21.947429
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Initialize ConfigData
    config_data = ConfigData()

    # Create a test setting
    from ansible.module_utils.common.config import Setting
    setting = Setting("test_name", "test_value", "test_value", 0)

    # Call method update_setting on config_data
    config_data.update_setting(setting)

    # Check result
    assert config_data._global_settings["test_name"] == setting


# Generated at 2022-06-10 22:41:28.784551
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting("byobu", "enabled", "true", "bool", "globally enables or disables byobu")
    config_data.update_setting(setting)
    setting = Setting("ansible_lint", "enabled", "true", "bool", "globally enables or disables ansible lint")
    config_data.update_setting(setting)
    setting = Setting("ansible_lint", "path", "~/.vim/lint/lint_ansible.sh", "string", "specifies where ansible lint is located")
    config_data.update_setting(setting)
    setting = Setting("flake8", "enabled", "true", "bool", "globally enables or disables flake8")
    config_data.update_setting(setting)
    setting

# Generated at 2022-06-10 22:41:29.402531
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    pass


# Generated at 2022-06-10 22:41:38.687823
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}
    global_setting = GlobalConfigSetting("author", "sri")
    config_data.update_setting(global_setting)
    assert config_data._global_settings == {"author": global_setting}
    assert config_data._plugins == {}
    plugin_setting = PluginConfigSetting("author", "sri", "action", "debug")
    config_data.update_setting(plugin_setting)
    assert config_data._global_settings == {"author": global_setting}
    assert config_data._plugins == {"action": {"debug": {"author": plugin_setting}}}

    plugin_setting2 = PluginConfigSetting("version", "1.0", "action", "debug")

# Generated at 2022-06-10 22:41:44.258381
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name="LIBRARY_PATH",
                      plugin=Plugin(name="foo", type="library", value="/a/b/c"))
    config_data.update_setting(setting)
    assert config_data._plugins["library"]["foo"]["LIBRARY_PATH"] == setting

# Generated at 2022-06-10 22:41:48.695907
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    assert len(cd.get_settings()) == 0


# Generated at 2022-06-10 22:42:00.641767
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class TestSettings:
        def __init__(self, name):
            self.name = name

    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.lookup import LookupBase

    class lookup_plugin(LookupBase):
        def __init__(self, basedir=None, runner=None, **kwargs):
            super(lookup_plugin, self).__init__(basedir=basedir, runner=runner, **kwargs)

    # There is no setting defined in the config file

    cfg_data = ConfigData()

    local_plugin = lookup_plugin()
    local_plugin.type = "lookup"
    local_plugin.name = "local"

    settings = cfg_data.get_settings(plugin=local_plugin)

    assert (settings == [])

    # There is a

# Generated at 2022-06-10 22:42:03.329013
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(ConfigSetting(name='test_name',value='test_value'))
    assert config._global_settings['test_name'] == 'test_value'



# Generated at 2022-06-10 22:42:06.836630
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    s = ConfigSetting(name='test', value='fake')
    c.update_setting(s)
    assert c.get_setting('test').name == 'test'
    assert c.get_setting('test').value == 'fake'


# Generated at 2022-06-10 22:42:15.191364
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = ConfigSetting('setting1', 'value1', 'text1')
    config_data.update_setting(setting)
    setting = ConfigSetting('setting2', 'value2', 'text2')
    config_class = ConfigClass(config_data, 'action', 'copy')
    config_data.update_setting(setting, config_class)

    assert config_data.get_setting('setting1') == ConfigSetting('setting1', 'value1', 'text1')
    assert config_data.get_setting('setting2', config_class) == ConfigSetting('setting2', 'value2', 'text2')


# Generated at 2022-06-10 22:42:23.889412
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c_data = ConfigData()
    setting1 = {'name':'global_setting', 'value':'global_value'}
    c_data.update_setting(setting1, None)
    setting2 = {'name':'plugin_setting', 'value':'plugin_value'}
    plugin1 = {'name':'plugin_name', 'type':'plugin_type'}
    c_data.update_setting(setting2, plugin1)
    assert c_data.get_setting('global_setting', None) == setting1
    assert c_data.get_setting('plugin_setting', plugin1) == setting2

# Generated at 2022-06-10 22:42:29.519895
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import find_plugin
    from ansible.plugins.vars.base_vars import BaseVarsPlugin

    data = ConfigData()
    plugin = find_plugin(BaseVarsPlugin, "test_var")
    setting = plugin.build_setting('test_setting', True)
    data.update_setting(setting, plugin)

    assert len(data.get_settings(plugin)) > 0
    assert len(data.get_settings()) == 0

# Generated at 2022-06-10 22:42:34.010978
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configdata = ConfigData()
    assert(configdata.get_setting('UNIT_TEST_CONFIG_KEY').name == 'UNIT_TEST_CONFIG_KEY')


# Generated at 2022-06-10 22:42:37.032178
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    obj_t = ConfigData()

    # Call the method under testing
    ans = obj_t.get_settings()

    # Assertion
    assert ans is not None


# Generated at 2022-06-10 22:42:40.400210
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(ConfigSetting(name="foo", value="bar"))
    assert config.get_setting(name="foo") == 'bar'


# Generated at 2022-06-10 22:42:47.631584
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class Plugin:
        type = None
        name = None

    setting1 = ConfigData.ConfigSetting()
    setting1.name = 'foo'

    setting2 = ConfigData.ConfigSetting()
    setting2.name = 'bar'

    data = ConfigData()
    data.update_setting(setting1)
    data.update_setting(setting2)

    settings = data.get_settings()

    for s in settings:
        print(s.name)

    assert len(settings) == 2

# Generated at 2022-06-10 22:42:55.639111
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    _plugins = {'myplugin': {'myname': {'myname.myvalue': 'myvalue', 'myname.myvalue2': 'myvalue2'}}}

    config_data = ConfigData()
    config_data._plugins = _plugins

    # Test getting the value of a defined setting
    assert config_data.get_settings('myplugin', 'myname') == _plugins['myplugin']['myname']

    # Test getting the value of a missing setting
    assert config_data.get_settings('myplugin', 'mymissingname') == {}

# Generated at 2022-06-10 22:43:06.583589
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """Unit test for method ConfigData.update_setting()"""
    #Create an instance of ConfigData
    config_data = ConfigData()
    #Create a setting
    from ansible.config.setting import Setting
    setting = Setting('timeout', 0, 'INTEGER')
    
    #Update setting in config_data with no plugin
    config_data.update_setting(setting)
    assert config_data.get_setting('timeout') == setting

    #Update setting in config_data with plugin
    from ansible.config.plugin import Plugin
    plugin = Plugin('action', 'shell', 'action')
    setting = Setting('timeout', 0, 'INTEGER')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('timeout', plugin) == setting



# Generated at 2022-06-10 22:43:16.532380
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.config.manager import ConfigManager
    from ansible.config.setting import Setting

    data = ConfigData()

    # populate with global setting
    setting = Setting("g_test", "global test setting", "text")
    setting.set_value("global setting value")
    data.update_setting(setting)

    assert len(data.get_settings()) == 1
    assert data.get_settings()[0].name == "g_test"
    assert data.get_settings()[0].value == "global setting value"

    # populate with plugin setting
    plugin = ConfigManager()
    plugin.type = "action"
    plugin.name = "copy"
    setting = Setting("p_test", "plugin test setting", "text")
    setting.set_value("plugin setting value")

# Generated at 2022-06-10 22:43:24.090609
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    plugin = Plugin('action', 'testPlugin')
    setting = PluginSetting('testSetting', 'testValue', 'testScope')
    configData.update_setting(setting, plugin)
    assert configData._plugins[plugin.type][plugin.name][setting.name].name == setting.name
    assert configData._plugins[plugin.type][plugin.name][setting.name].value == setting.value
    assert configData._plugins[plugin.type][plugin.name][setting.name].scope == setting.scope


# Generated at 2022-06-10 22:43:34.327949
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    PASSED = True
    config_data = ConfigData()

    try:
        config_data.update_setting('CONFIG_NAME', 'DEV')
        value = config_data.get_setting('CONFIG_NAME')
        if value != 'DEV':
            print('FAILED: test_ConfigData_get_setting expected: DEV actual: ', value)
            PASSED = False
        else:
            print('PASSED: test_ConfigData_get_setting expected: DEV actual: ', value)
    except Exception as e:
        print('FAILED: test_ConfigData_get_setting exception: ', e)
        PASSED = False

    return PASSED

# Generated at 2022-06-10 22:43:41.542537
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_name = 'foo'
    setting_value = 'bar'
    setting_type = 'string'
    setting = Setting(setting_name, setting_value, setting_type, None)
    config_data.update_settings(setting)
    assert config_data.get_settings().get(setting_name).get_value() == setting_value
    assert config_data.get_settings().get(setting_name).get_type() == setting_type


# Generated at 2022-06-10 22:43:44.362911
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    #setting = Setting()
    assert config.get_settings(None) == []
    assert config.get_setting('s') == None

# Generated at 2022-06-10 22:43:54.008543
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cdata = ConfigData()
    assert cdata != None
    assert cdata.get_setting('_ansible_parsed') == None
    assert cdata.get_settings() == []
    assert cdata.get_settings(PluginName('connection', 'foo')) == []
    assert cdata.get_setting('_ansible_parsed', PluginName('connection', 'foo')) == None
    setting = Setting('_ansible_parsed', True)
    setting.plugin = PluginName('connection', 'foo')
    cdata.update_setting(setting)
    assert cdata.get_setting('_ansible_parsed') == None
    assert cdata.get_settings() == []
    assert cdata.get_settings(PluginName('connection', 'foo')) != []
    assert cdata.get_setting

# Generated at 2022-06-10 22:43:59.224198
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    config = {}
    config['CONSTANT'] = 'global_constant'
    config['GLOBAL_BASE_PATH'] = 'global_base_path'
    cd.update_setting(config)

    assert cd.get_setting('CONSTANT') == 'global_constant'
    assert cd.get_setting('GLOBAL_BASE_PATH') == 'global_base_path'


# Generated at 2022-06-10 22:44:15.652871
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting('setting_global')
    config_data.update_setting('setting_plugin_A', plugin={'type': 'plugin_type', 'name': 'plugin_A'})
    config_data.update_setting('setting_plugin_B', plugin={'type': 'plugin_type', 'name': 'plugin_B'})

    assert config_data.get_setting('setting_global') == 'setting_global'
    assert config_data.get_setting('setting_global', plugin={'type': 'plugin_type', 'name': 'plugin_A'}) == 'global'
    assert config_data.get_setting('setting_plugin_A', plugin={'type': 'plugin_type', 'name': 'plugin_A'}) == 'plugin_A'
    assert config_data

# Generated at 2022-06-10 22:44:25.040679
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('callback','always','always','always','always'))
    config_data.update_setting(
        Setting('callback','stdout','custom',
                '{"stdout": {"callback": "stdout", "version": "v2"}}',
                '{"stdout": {"callback": "stdout", "version": "v1"}}'))
    config_data.update_setting(
        Setting('callback','default','custom',
                '{"default": {"callback": "default", "version": "v2"}}',
                '{"default": {"callback": "default", "version": "v1"}}'))
    # Verify that the global callback setting contains the value 'always'

# Generated at 2022-06-10 22:44:31.581174
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin_type = 'connection'
    plugin_name = 'local'
    config_data.update_setting(Setting('foo', 'bar', 'bar'), Plugin(plugin_type, plugin_name))
    settings = config_data.get_settings(Plugin(plugin_type, plugin_name))
    assert len(settings) == 1
    assert settings[0].name == 'foo'
    assert settings[0].value == 'bar'


# Generated at 2022-06-10 22:44:39.418049
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='foo', value='bar'))
    config_data.update_setting(Setting(name='bar', value='foo'))
    assert config_data.get_setting(name='foo') == Setting(name='foo', value='bar')
    assert config_data.get_setting(name='bar') == Setting(name='bar', value='foo')



# Generated at 2022-06-10 22:44:48.268420
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {'name': 'core.config_file',
               'value': '~/.vim',
               'type': 'string'}
    config_data.update_setting(setting)
    assert config_data._global_settings['core.config_file'] == setting
    setting2 = {'name': 'core.config_file',
                'value': '~/.vimrc',
                'type': 'string'}
    config_data.update_setting(setting2)
    assert config_data._global_settings['core.config_file'] == setting2

# Generated at 2022-06-10 22:44:58.215431
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()

    class Plugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class Setting(object):
        def __init__(self, name):
            self.name = name

    s1 = Setting('setting1')
    s2 = Setting('setting2')
    s3 = Setting('setting3')
    s4 = Setting('setting4')
    s5 = Setting('setting5')

    p1 = Plugin('type1', 'plugin1')
    p2 = Plugin('type1', 'plugin2')
    p3 = Plugin('type2', 'plugin1')
    p4 = Plugin('type2', 'plugin2')

    data.update_setting(s1)
    data.update_setting(s2, p1)
    data

# Generated at 2022-06-10 22:45:09.240024
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansiblelint.rules.NoUnicodeLiteralsRule import NoUnicodeLiteralsRule
    from ansiblelint.rules.NoUnicodeLiteralsRule import Setting
    
    config_data = ConfigData()

    # No setting values
    settings = config_data.get_settings(NoUnicodeLiteralsRule)
    assert(len(settings) == 0)

    # Add a global setting
    global_setting = Setting('global_setting', 'global_value')
    config_data.update_setting(global_setting)

    # Add a setting for a plugin
    plugin_setting = Setting('plugin_setting', 'global_value')
    plugin = NoUnicodeLiteralsRule('test/test-collections/ansible_collections/ansiblelint/plugins/test_action.py')

# Generated at 2022-06-10 22:45:19.123101
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import collections

    from ansiblelint.rules import RulesCollection

    # Import rules to load them and their metadata
    import ansiblelint.rules.AnsibleUndefinedVariable
    import ansiblelint.rules.TaskHasNoAction
    import ansiblelint.rules.PackageInstalledWithVersion
    import ansiblelint.rules.CommandContainsShellSpecialChar
    import ansiblelint.rules.UseShellInsteadOfCommand
    import ansiblelint.rules.CommandHasNoArgs
    import ansiblelint.rules.CommandShellUnquoted
    import ansiblelint.rules.TaskHasNameVar
    import ansiblelint.rules.UseCommandNotShell
    import ansiblelint.rules.ShellHasNoArgs
    import ansiblelint.rules.CommandUsedInsteadOfArgument

# Generated at 2022-06-10 22:45:23.349136
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print("Testing update_setting method of ConfigData")
    cd = ConfigData()
    cd.update_setting(Setting(name="a"))
    assert cd.get_setting("a") is not None

#===== Config Data ======


# Generated at 2022-06-10 22:45:34.148037
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()

    # Test a global setting
    s = Setting("global_setting", "value1")
    config.update_setting(s)
    assert config.get_setting("global_setting") == s
    assert config.get_setting("non_existent_setting") is None

    # Test a plugin setting
    p = Plugin("module", "aws")
    s = Setting("plugin_setting", "value2")
    config.update_setting(s, plugin=p)
    assert config.get_setting("plugin_setting", plugin=p) == s
    assert config.get_setting("non_existent_setting", plugin=p) is None


# Generated at 2022-06-10 22:45:55.253531
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import configparser

    class FakePlugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name
            self.dir = ""

    global_config_data = ConfigData()
    global_config_data.update_setting(ConfigSetting(
        'display_skipped_hosts', 'always', 'boolean', 'display_skipped_hosts option documentation'
    ))

    # Test with no plugin - Should return list of one ConfigSetting
    assert len(global_config_data.get_settings()) == 1

    # Test with no plugin - Should return list of zero ConfigSetting
    assert len(global_config_data.get_settings(FakePlugin('connection', 'local'))) == 0

    # Test with plugin - Should return list of one ConfigSetting

# Generated at 2022-06-10 22:46:02.488629
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from unittest import TestCase
    from mock import patch
    from ansiblelint.config import RulesCollection
    from ansiblelint.config import RulesCollectionRegistry
    from ansiblelint.config import ConfigData
    from ansiblelint.config import PluginSetting
    from ansiblelint.config import AnsiblePlugin
    from ansiblelint.rules import AnsibleLintRule
    from ansiblelint.plugins.rules import AnsibleLintRulePlugin

    class TestRule(AnsibleLintRule):
        id = 'TEST-RULE'
        shortdesc = 'A test rule'
        info = 'Test rule'
        severity = 'VERY-LOW'

    class TestConfigData(ConfigData):
        def __init__(self):
            super(TestConfigData, self).__init__()
            self

# Generated at 2022-06-10 22:46:05.012115
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

# Generated at 2022-06-10 22:46:15.622345
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()
    plugin = Plugin("test_plugin")
    setting = Setting("test_setting", "test_value")

    # Test exception if plugin not defined
    try:
        config.get_settings(plugin)
    except Exception as e:
        assert str(e) == "Plugin not defined"
    else:
        assert False, "Exception expected"

    # Test empty plugin
    config.update_setting(setting, plugin)
    settings = config.get_settings(plugin)
    assert len(settings) == 0

    # Test one setting
    config.update_setting(setting, plugin)
    settings = config.get_settings(plugin)
    assert len(settings) == 1

    # Test plugin with multiple settings
    setting = Setting("test_setting2", "test_value2")

# Generated at 2022-06-10 22:46:27.534735
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    ds = dict(
        default=dict(
            forks=10,
            become=dict(
                method='sudo',
                user='root',
            ),
        ),
        webservers=dict(
            hosts=['host01', 'host02'],
            vars=dict(
                http_port=80,
            ),
        ),
        db=dict(
            hosts=['db01', 'db02'],
            vars=dict(
                mongo_port=27017,
            ),
        ),
    )

# Generated at 2022-06-10 22:46:37.402635
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    config_data.update_setting(Setting(name='val1', value='val1'))
    assert config_data._global_settings['val1'].name == 'val1'
    assert config_data._global_settings['val1'].value == 'val1'
    assert len(config_data._global_settings) == 1

    config_data.update_setting(Setting(name='val1', value='val2'))
    assert config_data._global_settings['val1'].name == 'val1'
    assert config_data._global_settings['val1'].value == 'val2'
    assert len(config_data._global_settings) == 1

    config_data.update_setting(Setting(name='val2', value='val2'))
    assert config_data._global

# Generated at 2022-06-10 22:46:42.251547
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert (cd.get_setting('DEBUG') is None)
    cd.update_setting('DEBUG', 'false')
    assert (cd.get_setting('DEBUG') == 'false')
    cd.update_setting('DEBUG', 'true')
    assert (cd.get_setting('DEBUG') == 'true')


# Generated at 2022-06-10 22:46:44.248455
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    conf = ConfigData()
    assert conf.get_setting("python_interpreter") is None


# Generated at 2022-06-10 22:46:55.497996
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.config.setting import Setting
    from ansible.plugins.loader import PluginLoader

    plugin_loader = PluginLoader()

    config_data = ConfigData()

    default_setting = Setting('CONFIG_DATA_DEFAULT_SETTING', description='Default setting for unit test',
                              default='value', type=str, ini=dict(key='config_data_default_setting'), env_var=None)
    global_setting = Setting('CONFIG_DATA_GLOBAL_SETTING', description='Global setting for unit test',
                             default='value', type=str, ini=dict(key='config_data_global_setting'), env_var=None)

    config_data.update_setting(default_setting)
    config_data.update_setting(global_setting)

    # Test get_setting with default setting and no

# Generated at 2022-06-10 22:47:05.425373
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugins = ['awx.plugins.inventory.VMwareInventory', 'awx.plugins.inventory.AzureInventory']
    for plugin in plugins:
        plugin_info = plugin.split('.')
        plugin_name = plugin_info[-1]

        config = Config(plugin_name, plugin, plugin_info[2].split('_')[0], 'inventory')
        config.set_setting('user', 'admin')
        config.set_setting('password', 'admin')
        config.set_setting('vcenter', '192.168.1.101')
        config.set_setting('subscription_id', '46afafaf-dffd-63e8-8bb9-6d94ac6ff7b6')
        config_data.update_setting(config)

   

# Generated at 2022-06-10 22:47:37.929160
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """Unit test for method ``update_setting()`` of class ``ConfigData``."""

    # instantiate ConfigData object
    config_data = ConfigData()

    # create a plugin
    plugin = Plugin('testplugin', 'testplugin type')

    # create a setting
    setting = Setting('testsetting', 'testsetting value')

    # add the setting with the plugin
    config_data.update_setting(setting, plugin)

    # retrieve the setting from the plugin
    ret_setting = config_data.get_setting('testsetting', plugin)

    # test that the retrieved setting is the input setting
    assert (ret_setting == setting)


# Generated at 2022-06-10 22:47:47.246096
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting("a", "b", "c", "d"))
    config_data.update_setting(Setting("a", "b", "c", "d", "module"))
    config_data.update_setting(Setting("a", "b", "c", "d"), Plugin("", "", ""))
    assert 2 == len(config_data.get_settings())
    assert 1 == len(config_data.get_settings(Plugin("module", "", "")))


# Generated at 2022-06-10 22:47:58.220820
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.config.setting import Setting
    from ansible.config.plugin import Plugin

    config = ConfigData()

    assert len(config.get_settings()) == 0
    assert len(config.get_settings(Plugin())) == 0

    setting = Setting('foo')
    config.update_setting(setting)
    assert len(config.get_settings()) == 1
    assert config.get_settings()[0].name == 'foo'

    setting = Setting('bar')
    plugin = Plugin(type='cache', name='wavsep')
    config.update_setting(setting, plugin)
    assert len(config.get_settings(plugin)) == 1
    assert config.get_settings(plugin)[0].name == 'bar'
    assert len(config.get_settings()) == 1


# Generated at 2022-06-10 22:48:10.910619
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # create config_data
    config_data = ConfigData()
    # create plugins
    plugin1 = Plugin('plugins/callback/my_callback', 'my_callback', 'callback')
    plugin2 = Plugin('plugins/filter/my_filter', 'my_filter', 'filter')
    # create global settings
    setting1 = Setting('ANSIBLE_CONFIG_FILE', 'ansible.cfg')
    # create plugin settings
    setting2 = Setting('hello', 'world')
    setting3 = Setting('foo', 'bar')
    # add settings to config_data
    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin1)
    config_data.update_setting(setting3, plugin2)

    assert config_data.get_setting('ANSIBLE_CONFIG_FILE') == setting1

# Generated at 2022-06-10 22:48:17.502273
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test case 1: update global setting
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar', plugin=None))
    assert config_data.get_setting('foo', plugin=None) is not None
    assert config_data.get_setting('foo', plugin=None).value == 'bar'

    # Test case 2: update a setting of a specific plugin
    config_data.update_setting(Setting('foo', 'bar1', plugin=Plugin('test', 'test')))
    assert config_data.get_setting('foo', plugin=Plugin('test', 'test')) is not None
    assert config_data.get_setting('foo', plugin=Plugin('test', 'test')).value == 'bar1'

# Generated at 2022-06-10 22:48:18.652071
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    print(config.get_settings())

# Generated at 2022-06-10 22:48:29.377683
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins import PluginFactory
    from ansible.plugins.loader import plugin_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.collection.test.data import TestDataClass

    collection_loader = AnsibleCollectionLoader(None)
    collection_loader.set_collection_paths([TestDataClass.collection_dir])

    plugins = PluginFactory(None, 't', None, None)

    plugin_loader.set_collection_loader(collection_loader)
    plugin_loader.add_directory(TestDataClass.plugin_dir)
    plugin_loader.set_plugin_package(TestDataClass.plugin_package)

    config_data = ConfigData()


# Generated at 2022-06-10 22:48:39.845728
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class Plugin:

        def __init__(self, type='', name=''):
            self.type = type
            self.name = name

    class Setting:

        def __init__(self, name='', value='', origin='', plugin_type='', plugin_name=''):
            self.name = name
            self.value = value
            self.origin = origin
            self.plugin_type = plugin_type
            self.plugin_name = plugin_name

    config_data = ConfigData()

    setting1 = Setting('name1', 'value1', 'origin1', 'type1', 'name1')

    assert(len(config_data.get_settings()) == 0)

    config_data.update_setting(setting1)
    assert(len(config_data.get_settings()) == 1)

    setting2 = Setting

# Generated at 2022-06-10 22:48:47.756892
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()

    # Case 1:
    # test for global settings
    configdata.update_setting(setting={'name': 'git_repo_uri',
                                       'value': 'https://github.com/ansible/ansible-tower-samp',
                                       'conf_file': None,
                                       'section': None,
                                       'priority': 10,
                                       'plugin': None})
    assert configdata._global_settings.get('git_repo_uri').name == 'git_repo_uri', 'Plugin name is different'
    assert configdata._global_settings.get('git_repo_uri').value == 'https://github.com/ansible/ansible-tower-samp', 'Plugin type is different'

# Generated at 2022-06-10 22:48:54.150286
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    import core.setting
    setting_one = core.setting.Setting("user", "description", default="")
    setting_two = core.setting.Setting("password", "description", default="")
    config.update_setting(setting_one)
    config.update_setting(setting_two)
    assert len(config._global_settings) == 2
    assert len(config._plugins) == 0


# Generated at 2022-06-10 22:49:44.873692
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    plugin = None

    assert configData.get_settings(plugin) == []
    setting1 = Setting("test1", "test1", None, None)
    configData.update_setting(setting1, plugin)
    assert str(configData.get_settings(plugin)[0]) == str(setting1)

    plugin = Plugin("TestPlugin", "TestPluginType")
    assert configData.get_settings(plugin) == []
    setting2 = Setting("test2", "test2", None, None)
    configData.update_setting(setting2, plugin)
    assert str(configData.get_settings(plugin)[0]) == str(setting2)


# Generated at 2022-06-10 22:49:54.745241
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    import sys
    sys.path.insert(0, '..')
    from config_data import ConfigData, ConfigSetting
    from plugins import Plugin

    cd = ConfigData()

    sgs = ConfigSetting()
    sgs.name = 'global_setting'
    sgs.value = 'global_setting_value'
    cd.update_setting(sgs)

    p1 = Plugin()
    p1.type = 'type'
    p1.name = 'name'

    s1 = ConfigSetting()
    s1.name = 'setting'
    s1.value = 'setting_value'
    cd.update_setting(s1, p1)

    assert cd.get_setting('global_setting') == sgs
    assert cd.get_setting('setting', p1) == s1

# Generated at 2022-06-10 22:49:58.229954
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    assert config.get_setting('foo') is None
    assert config.get_setting('bar', FakePlugin('test', 'foo', 'test_plugin')) is None
    

    config.update_setting(FakeSetting('foo'))
    assert config.get_setting('foo') == FakeSetting('foo')
    

# Generated at 2022-06-10 22:49:59.798217
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

# Generated at 2022-06-10 22:50:11.314523
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()
    assert isinstance(configdata, ConfigData)
    print("test_ConfigData_get_settings - ConfigData instance created")

    setting = None
    settings = configdata.get_settings()
    assert settings == []
    print("test_ConfigData_get_settings - get_settings without defined settings")

    setting = Setting(name='test')
    configdata.update_setting(setting)
    settings = configdata.get_settings()
    assert settings == [setting]
    print("test_ConfigData_get_settings - get_settings with one defined setting")

    setting2 = Setting(name='test2')
    configdata.update_setting(setting2)
    settings = configdata.get_settings()
    assert settings == [setting, setting2]

# Generated at 2022-06-10 22:50:14.527376
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    assert config.get_settings() == []
    config.update_setting(Setting('foo', None, 'bar'))
    assert config.get_settings() == [Setting('foo', None, 'bar')]


# Generated at 2022-06-10 22:50:24.050034
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', None) is None
    assert config_data.get_setting('foo', 'connection') is None
    setting = Setting('bar', 'boo', 'console', 'connection')
    config_data.update_setting(setting, 'connection')
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', None) is None
    assert config_data.get_setting('foo', 'connection') is None
    assert config_data.get_setting('bar') is None
    assert config_data.get_setting('bar', None) is None
    assert config_data.get_setting('bar', 'connection') == setting


# Generated at 2022-06-10 22:50:34.225984
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    assert(c.get_settings() == [])
    assert(c.get_settings(Plugin({'name': '', 'type': ''})) == [])

    s = Setting({'name': 'a', 'value': 'b'})
    c.update_setting(s)
    assert(c.get_settings() == [s])
    assert(c.get_settings(Plugin({'name': '', 'type': ''})) == [])

    s2 = Setting({'name': 'a', 'value': 'b'})
    c.update_setting(s2, Plugin({'name': 'a', 'type': 'b'}))
    assert(c.get_settings() == [s])