

# Generated at 2022-06-24 18:15:04.780558
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("setting", None)
    assert config_data.get_settings(None) == "setting"

if __name__ == '__main__':
    test_ConfigData_update_setting()

# Generated at 2022-06-24 18:15:09.256801
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(name=None) == None
    assert config_data_0.get_setting(name="test_character", plugin=None) == None


# Generated at 2022-06-24 18:15:13.187426
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting("setting_0", "global_setting_0"))
    config_data_1.update_setting(Setting("setting_1", "global_setting_1"))
    assert(config_data_1.get_setting("setting_0") == Setting("setting_0", "global_setting_0"))
    assert(config_data_1.get_setting("setting_1") == Setting("setting_1", "global_setting_1"))
    assert(config_data_1.get_setting("setting_0", Plugin("plugin_0")) == None)


# Generated at 2022-06-24 18:15:15.953594
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    global config_data_0
    config_data_0 = ConfigData()
    print(config_data_0.get_settings())


# Generated at 2022-06-24 18:15:18.942589
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting('foo', 'bar'))
    assert config_data_0.get_settings() == [Setting('foo', 'bar')]


# Generated at 2022-06-24 18:15:21.305744
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings = config_data_0.get_settings()
    assert(len(settings) == 0)


# Generated at 2022-06-24 18:15:24.494578
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting_1 = Setting('abc', False)
    config_data_1.update_setting(setting_1, None)

    assert config_data_1.get_setting('abc', None).value == False


# Generated at 2022-06-24 18:15:27.517219
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Initialization of test data
    config_data_0 = ConfigData()
    setting_0 = config_data_0.update_setting(name, plugin)
# ----------------------------------------------------------------------
# Code template for test case test_ConfigData_get_setting of class ConfigData

# Generated at 2022-06-24 18:15:33.865770
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    """Unit test for the ConfigData method get_settings"""
    config_data = ConfigData()
    plugin = Plugin("type0", "name0")
    setting = Setting("setting0", "type0", "value0")
    config_data.update_setting(setting)
    assert config_data.get_settings(plugin)==[]

# Generated at 2022-06-24 18:15:39.015933
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    line_0 = "display_skipped_hosts = True"
    setting = parse_line(line_0, config_data_0)
    assert not config_data_0.get_setting('display_skipped_hosts')
    config_data_0.update_setting(setting)
    assert config_data_0.get_setting('display_skipped_hosts')

# Generated at 2022-06-24 18:15:45.032036
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting()
    config_data_0.get_settings()

test_ConfigData_get_setting()

# Generated at 2022-06-24 18:15:50.971709
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # create an instance of ConfigData
    config_data_0 = ConfigData()
    # setter call
    config_data_0.update_setting(config_setting_0)
    assert config_data_0.get_setting('foo')


# Generated at 2022-06-24 18:15:56.617608
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = Plugin()
    plugin_0.type = "action"
    plugin_0.name = "command"
    setting_0 = Setting()
    setting_0.name = "action_command_some_var"
    setting_0.value = "some_value"
    setting_0.plugin = plugin_0
    config_data_0.update_setting(setting_0)
    assert(len(config_data_0.get_settings(plugin_0)) == 1)


# Generated at 2022-06-24 18:15:59.661719
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='key',section='section',value='value')
    config_data.update_setting(setting)
    setting2 = config_data.get_setting(name='key')
    assert(setting == setting2)

# Generated at 2022-06-24 18:16:06.886416
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting())
    config_data.update_setting(Setting())
    config_data.update_setting(Setting())
    config_data.update_setting(Setting())
    config_data.update_setting(Setting())
    config_data.update_setting(Plugin(), Plugin())
    config_data.update_setting(Plugin(), Plugin())
    config_data.update_setting(Plugin(), Plugin())
    config_data.update_setting(Plugin(), Plugin())
    config_data.update_setting(Plugin(), Plugin())
    return config_data

# Generated at 2022-06-24 18:16:07.897397
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()


# Generated at 2022-06-24 18:16:10.747335
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test_case_0()
    config_data_0 = ConfigData()
    assert config_data_0.get_setting("debug") is None


# Generated at 2022-06-24 18:16:18.988487
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting_0 = Setting('k', 3)
    setting_1 = Setting('k', 4)

    config_data_0.update_setting(setting_0, None)
    config_data_0.update_setting(setting_1, Plugin('j', 'c'))

    retrieved_settings_0 = config_data_0.get_settings()
    assert len(retrieved_settings_0) == 1

    retrieved_settings_1 = config_data_0.get_settings(Plugin('j', 'c'))
    assert len(retrieved_settings_1) == 1


# Generated at 2022-06-24 18:16:24.473663
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    assert isinstance(config_data_0, ConfigData)
    assert not config_data_0.get_setting('env', plugin=None)
    assert not config_data_0._plugins

    config_data_0.update_setting(Setting('env', 'dev', 'global'))

    assert config_data_0.get_setting('env', plugin=None).value == 'dev'


# Generated at 2022-06-24 18:16:28.094473
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting_0 = ConfigParser.RawConfigParser()
    config_data = ConfigData()
    config_data.update_setting(setting_0)


# Generated at 2022-06-24 18:16:33.621955
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 18:16:35.550142
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    assert config_data_0.get_settings().__len__() == 0


# Generated at 2022-06-24 18:16:37.512363
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    assert config_data_1.get_setting(None) is None, 'ConfigData get_setting did not return None as expected'


# Generated at 2022-06-24 18:16:48.366720
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_1 = Setting('foo', True, 'global')
    with pytest.raises(Exception) as exception:
        config_data_1.update_setting(setting_1, None)
    assert 'the setting should not be  None !' in str(exception)

    setting_2 = Setting('foo', True, 'global')
    config_data_1.update_setting(setting_2, None)
    assert config_data_1.get_setting('foo') is setting_2

    plugin_1 = Plugin('A', 'B')
    setting_3 = Setting('foo', True, 'global')
    config_data_1.update_setting(setting_3, plugin_1)
    assert config_data_1.get_setting('foo', plugin_1) is setting_3

# Generated at 2022-06-24 18:16:52.770002
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings_0 = config_data_0.get_settings()
    assert len(settings_0) == 0


# Generated at 2022-06-24 18:16:59.289401
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = test_case_0()
    global_setting_0 = GlobalSetting('DEFAULT_MODULE_NAME', 'str', 'DEFAULT_MODULE_NAME', 'The module to use when no module is explicitly specified.', None, None, 'ini')
    config_data_0.update_setting(global_setting_0)
    settings_0 = config_data_0.get_settings()
    assert settings_0 == [global_setting_0]


# Generated at 2022-06-24 18:17:08.280823
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    plugins_1 = []
    plugin_0 = Plugin('lookup','find')
    plugins_1.append(plugin_0)
    plugin_1 = Plugin('callback','default')
    plugins_1.append(plugin_1)
    for plugin_x in plugins_1:
        setting_0 = Setting('name', 'find')
        config_data_1.update_setting(setting_0, plugin_x)
    setting_1 = Setting('name', 'default')
    config_data_1.update_setting(setting_1)
    assert config_data_1.get_settings() == [setting_1]
    assert config_data_1.get_settings(plugin_0) == [setting_0]


# Generated at 2022-06-24 18:17:10.600762
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() is not None


# Generated at 2022-06-24 18:17:19.802132
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()
    config_data_3 = ConfigData()
    setting_1 = Setting()
    setting_1.name = 'inventory'
    setting_1.value = 'test_inventory'
    setting_1.type = 'file'
    setting_1.path = 'test_inventory_path'
    config_data_2.update_setting(setting_1)

    plugin = Plugin()
    plugin.type = 'connection'
    plugin.name = 'local'
    setting_2 = Setting()
    setting_2.name = 'inventory'
    setting_2.value = 'test_inventory'
    setting_2.type = 'file'
    setting_2.path = 'test_inventory_path'
    config_data_3.update_setting

# Generated at 2022-06-24 18:17:23.293930
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting()
    config_data_0.update_setting(setting_0)
#

# Generated at 2022-06-24 18:17:30.116073
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()

    # Test with no settings
    assert config_data_0.get_setting('C.DEFAULT_HOST_LIST') is None


# Generated at 2022-06-24 18:17:35.898684
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting_0 = Setting('setting_0')
    config_data_1.update_setting(setting_0)
    assert config_data_1.get_setting('setting_0') == setting_0


# Generated at 2022-06-24 18:17:38.774765
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-24 18:17:41.249050
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    # Verify that the method exists and has the correct signature
    assert hasattr(config_data_0, 'update_setting') and callable(getattr(config_data_0, 'update_setting'))



# Generated at 2022-06-24 18:17:48.022822
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    # Test case where only plugin settings exist
    plugin_settings = {}
    plugin_settings["test"] = {
        "module_defaults": {
            "retries": 42,
        }
    }
    config_data.update_plugin_settings(plugin_settings)
    retries = config_data.get_setting("retries", PluginType.MODULE, "test")
    assert retries == 42

    # Test case where setting exists both in global settings and plugin settings
    # Plugin-specific setting should take precedence
    plugin_settings = {}
    plugin_settings["test"] = {
        "module_defaults": {
            "retries": 42,
        }
    }
    config_data.update_plugin_settings(plugin_settings)

# Generated at 2022-06-24 18:17:58.216444
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_0 = Setting(name='test_setting')
    config_data_1.update_setting(setting_0)
    assert(config_data_1.get_setting('test_setting') is not None)
    setting_1 = Setting(name='test_setting2')
    config_data_1.update_setting(setting_1, Plugin(type='connection', name='network_cli'))
    assert(config_data_1.get_setting('test_setting2', plugin=Plugin(type='connection', name='network_cli')) is not None)

# Generated at 2022-06-24 18:17:59.665356
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:18:01.773082
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert list(config_data_1.get_settings()) == []


# Generated at 2022-06-24 18:18:05.207231
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting)


# Generated at 2022-06-24 18:18:09.775678
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    plugin_0 = config_data_0.get_setting("name")
    try:
        config_data_0.update_setting(plugin_0)
    except Exception:
        pass


# Generated at 2022-06-24 18:18:21.387187
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting={"name": "test_name",
                                         "value": "test_value"},
                                 plugin=None)

    result = config_data_0.get_setting(name="test_name", plugin=None)
    assert result['name'] == "test_name"


# Generated at 2022-06-24 18:18:30.503567
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """
    Test update setting method
    """
    config_data = ConfigData()

    setting_0 = Setting('ansible_connection', 'ssh', 'connection', 'all')
    setting_1 = Setting('ansible_host', 'localhost', 'host', 'all')

    config_data.update_setting(setting_0)
    config_data.update_setting(setting_1)

    assert config_data._global_settings == {'ansible_connection': 'ssh', 'ansible_host': 'localhost'}



# Generated at 2022-06-24 18:18:33.655972
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    # Testing setting count of global settings
    assert len(config_data_0.get_settings()) == 0
    # Testing setting count of global settings
    assert len(config_data_0.get_settings(None)) == 0


# Generated at 2022-06-24 18:18:42.026620
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    setting_0 = Setting("foo", "bar", "string")
    setting_1 = Setting("foo", "baz", "string")
    config_data_0.update_setting(setting_0)
    config_data_0.update_setting(setting_1, Plugin("Vars", "foo"))

    assert "foo" == config_data_0.get_setting("foo").name
    assert "bar" == config_data_0.get_setting("foo").value
    assert "Vars" == config_data_0.get_setting("foo", Plugin("Vars", "foo")).plugin.type
    assert "foo" == config_data_0.get_setting("foo", Plugin("Vars", "foo")).plugin.name
    assert "baz" == config_data_0

# Generated at 2022-06-24 18:18:44.290438
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = config_data_0.update_setting()

# Generated at 2022-06-24 18:18:46.402468
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert not config_data_0.get_setting()


# Generated at 2022-06-24 18:18:52.893466
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting_0 = Setting("ANSIBLE_CALLBACK_PLUGINS")
    setting_0.value = "./callback_plugins"
    config_data_0.update_setting(setting_0)
    setting_1 = Setting("ANSIBLE_ACTION_PLUGINS")
    setting_1.value = "./action_plugins"
    config_data_0.update_setting(setting_1)
    assert config_data_0.get_settings().__len__() == 2


# Generated at 2022-06-24 18:18:57.775446
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_0 = Setting('PluginDir', '/etc/ansible/plugins/modules')
    config_data_1.update_setting(setting_0)
    assert setting_0 == config_data_1._global_settings['PluginDir']


# Generated at 2022-06-24 18:18:59.940327
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    class Plugin:
        def __init__(self):
            self.type = 'shell'
            self.name = 'pwsh'


# Generated at 2022-06-24 18:19:09.353390
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    setting = Setting('setting_name', 'setting_value', 'setting_section')
    config_data.update_setting(setting)
    result_setting = config_data.get_setting('setting_name')
    assert result_setting is not None
    assert result_setting.name == 'setting_name'
    assert result_setting.value == 'setting_value'
    assert result_setting.section == 'setting_section'

    setting = Setting('setting_name', 'setting_value_update', 'setting_section_update')
    config_data.update_setting(setting)
    result_setting = config_data.get_setting('setting_name')
    assert result_setting is not None
    assert result_setting.name == 'setting_name'

# Generated at 2022-06-24 18:19:35.747435
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='foo', value='bar', origin='ansible.config.settings')
    config_data_0.update_setting(setting_0)
    setting_1 = Setting(name='bar', value='baz', origin='ansible.config.settings')
    config_data_0.update_setting(setting_1)
    plugin_1 = Plugin('connection', 'local')
    plugin_1.update_setting(setting_0)
    config_data_0.update_setting(setting_0, plugin_1)
    plugin_1.update_setting(setting_1)
    config_data_0.update_setting(setting_1, plugin_1)
    setting_2 = Setting(name='foo', value='bar', origin='ansible.config.settings')

# Generated at 2022-06-24 18:19:38.296380
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()


# Generated at 2022-06-24 18:19:50.685354
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()

    setting_0 = Setting()
    setting_0.name = "name_0"
    setting_0.value = "value_0"
    setting_0.plugin = None
    setting_0.section = "section_0"
    config_data_0.update_setting(setting_0)
    
    assert config_data_0._global_settings == {"name_0": setting_0}
    
    setting_1 = Setting()
    setting_1.name = "name_1"
    setting_1.value = "value_1"
    setting_1.plugin = None
    setting_1.section = "section_1"
    config_data_0.update_setting(setting_1)


# Generated at 2022-06-24 18:20:00.198791
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    plugin_1 = PluginDefinition(type="foo")
    plugin_1.name = "bar"
    setting_1 = SettingDefinition(name="baz")
    plugin_1.settings.append(setting_1)
    config_data_1.update_setting(setting_1, plugin=plugin_1)
    result = config_data_1.get_settings(plugin=plugin_1)
    assert len(result) == 1
    assert result[0].name == "baz"
    assert result[0].plugin == plugin_1



# Generated at 2022-06-24 18:20:01.644415
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:20:03.497917
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert len(config_data_0.get_settings()) == 0



# Generated at 2022-06-24 18:20:08.510811
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0._global_settings is not None
    assert config_data_0._plugins is not None
    assert config_data_0.get_settings() is not None
    assert config_data_0.get_settings() == []

# Generated at 2022-06-24 18:20:13.269228
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    name_0 = "default_cache_plugin"
    plugin_0 = None
    setting_0 = config_data_0.get_setting(name_0, plugin_0)
    assert setting_0 is None


# Generated at 2022-06-24 18:20:20.183239
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    plugin_0 = PluginConfiguration('test', None)
    plugin_1 = PluginConfiguration('test', 'test')
    plugin_2 = PluginConfiguration('test', 'test')
    plugin_3 = PluginConfiguration('test', 'test')

    setting_0 = SettingConfiguration('setting')
    setting_1 = SettingConfiguration('setting')
    setting_2 = SettingConfiguration('setting')

    config_data_0 = ConfigData()

    config_data_0.update_setting(setting_0, plugin_0)

    config_data_0.update_setting(setting_1, plugin_1)
    config_data_0.update_setting(setting_2, plugin_2)

    expected_0 = [setting_0]
    expected_1 = [setting_1, setting_2]


# Generated at 2022-06-24 18:20:22.277743
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    
    data_0 = ConfigData()
    data_0.update_setting("value", "value")
    print()


# Generated at 2022-06-24 18:21:01.885047
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting('5')
    print('Value returned from method update_setting is',config_data_1.update_setting())


# Generated at 2022-06-24 18:21:08.968394
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    # Test call with name=None and plugin=None
    assert config_data_0.get_setting() == None

    # Test call with name=None and plugin=plugin_0
    from ansible.plugins.loader import PluginLoader
    plugin_0 = PluginLoader()
    plugin_0.type = None
    plugin_0.name = None
    assert config_data_0.get_setting(plugin=plugin_0) == None


# Generated at 2022-06-24 18:21:13.882550
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    new_setting = Setting("test", "value", "type", plugin)
    config_data_0.update_setting(new_setting)
    assert config_data_0.get_setting("test") == new_setting


# Generated at 2022-06-24 18:21:20.429704
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    test_setting = {"name": "test_setting_name", "env_var": "test_setting_env_var",
                    "default": "test_setting_default", "config_file_section": "test_section_value",
                    "config_file_key": "test_key_value", "vault_key": "test_vault_key_value",
                    "vault_section": "test_vault_section_value",
                    "description": "test_description_value"}
    test_plugin = {"type": "test_type", "name": "test_name", "version": "test_version"}

    # Test passing string as a parameter setting

# Generated at 2022-06-24 18:21:28.812111
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    data_0 = ConfigData()
    type_0 = "ANSIBLE_LIBRARY"
    setting_0 = ConfigurationSetting(name="ANSIBLE_LIBRARY", type=type_0,
                                     value="/home/ubuntu/.ansible/plugins/modules:/usr/share/ansible/plugins/modules",
                                     plugin_name="", plugin_type=type_0, plugin_version="", version=1,
                                     origin="DEFAULT")
    config_data_0.update_setting(setting_0=setting_0)
    assert config_data_0._global_settings == data_0._global_settings


# Generated at 2022-06-24 18:21:33.081113
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test1', 'test', 1)
    config_data.update_setting(setting)
    assert(config_data.get_setting('test1') == setting)


# Generated at 2022-06-24 18:21:37.182153
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    # Invoke the method:
    result = config_data_1.get_setting(name='name_0', plugin='plugin_0')
    assert result is None



# Generated at 2022-06-24 18:21:44.665221
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Check return value exists
    config_data_0 = ConfigData()
    plugins_0 = ['foo']
    settings_0 = config_data_0.get_settings(plugins_0)
    assert settings_0
    # Check return value type
    assert isinstance(settings_0, list)
    # Check return value is correct
    assert settings_0 == []


# Generated at 2022-06-24 18:21:47.035810
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
	#  assert config_data.get_settings() == []


# Generated at 2022-06-24 18:21:49.972944
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Create a new instance of ConfigData
    config_data = ConfigData()
    # Attempt to retrieve a setting
    setting = config_data.get_setting(name='test_setting_0')
    assert setting is None


# Generated at 2022-06-24 18:23:14.615310
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()

    setting_0 = Setting("foo")
    data.update_setting(setting_0)
    setting_1 = Setting("bar")
    data.update_setting(setting_1)
    actual = data.get_setting("foo")
    expected = setting_0
    assert actual == expected

# Generated at 2022-06-24 18:23:15.542480
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    ConfigData.get_settings(config_data_1)


# Generated at 2022-06-24 18:23:23.399568
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    setting_0 = Setting('lookup_plugins', '/home/ansible/ansible/lookup_plugins')
    config_data_0.update_setting(setting_0)

    assert config_data_0._global_settings['lookup_plugins'] == setting_0

    setting_0 = Setting('lookup_plugins')
    config_data_0.update_setting(setting_0)

    assert config_data_0._global_settings['lookup_plugins'] == setting_0



# Generated at 2022-06-24 18:23:27.571247
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    import os
    import tempfile

    # Create a settings object from an int setting provided from defaults
    from ansible.plugins.action.copy import ActionModule as ActionCopy
    from ansible.plugins.connection.local import Connection as ConnectionLocal
    from ansible.plugins.inventory.hostname import InventoryModule as InventoryHostname
    from ansible.plugins.lookup.first_found import LookupModule as LookupFirstFound
    from ansible.plugins.shell.bash import ShellModule as ShellBash

    setting_0 = config_data_0.get_setting('copy_verbosity')
    new_value_0 = 2
    setting_0.value = new_value_0

    # Update the global setting
    config_data_0.update_setting(setting_0)
    assert config_data_

# Generated at 2022-06-24 18:23:31.709205
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(None)
    config_data_1.update_setting(None, None)


# Generated at 2022-06-24 18:23:38.349812
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Initialize
    config_data_0 = ConfigData()

    # Method update_setting of class ConfigData
    inp_setting_1 = config_data_0.update_setting(inp_setting=None, plugin=None)
    print(inp_setting_1)
    inp_setting_2 = config_data_0.update_setting(inp_setting=None, plugin=None)
    print(inp_setting_2)


# Generated at 2022-06-24 18:23:44.461738
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()

    setting_0 = config_data_1.get_setting("setting_0")
    assert setting_0 is None
    plugin_type_0 = "type_0"
    plugin_name_0 = "name_0"
    plugin_0 = Plugin(plugin_type_0, plugin_name_0)
    setting_1 = config_data_1.get_setting("setting_0", plugin_0)
    assert setting_1 is None
    setting_2 = Setting("setting_0")
    config_data_1.update_setting(setting_2)
    setting_3 = config_data_1.get_setting("setting_0")
    assert setting_3 == setting_2
    setting_4 = config_data_1.get_setting("setting_0", plugin_0)


# Generated at 2022-06-24 18:23:47.013202
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:23:54.155820
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = C._configuration.Setting(None)
    setting_0.name = ''
    setting_0.value = ''
    config_data_0.update_setting(setting_0)
    config_data_0.get_settings()



# Generated at 2022-06-24 18:24:00.104953
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting = Setting(name='blah')
    config_data_0.update_setting(setting)
    settings = config_data_0.get_settings()
    assert len(settings) == 1
