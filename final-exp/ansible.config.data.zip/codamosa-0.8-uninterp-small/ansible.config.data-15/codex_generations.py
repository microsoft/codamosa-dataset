

# Generated at 2022-06-24 18:15:11.102705
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_01 = ConfigData()
    config_data_02 = ConfigData()
    config_data_03 = ConfigData()
    config_data_04 = ConfigData()
    setting_01 = PluginSetting(name='setting_01')
    plugin_01 = Plugin('plugin_01', 'plugin_type_01')
    setting_02 = PluginSetting(name='setting_02')
    plugin_02 = Plugin('plugin_02', 'plugin_type_02')
    setting_03 = PluginSetting(name='setting_03')
    plugin_03 = Plugin('plugin_03', 'plugin_type_03')
    setting_04 = PluginSetting(name='setting_04')
    plugin_04 = Plugin('plugin_04', 'plugin_type_04')

# Generated at 2022-06-24 18:15:16.578194
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    result_1 = config_data_1.get_settings()
    assert result_1 == []

    config_data_2 = ConfigData()
    result_2 = config_data_2.get_settings(plugin=None)
    assert result_2 == []


# Generated at 2022-06-24 18:15:19.453333
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_1.update_setting("setting1", "plugin1")
    assert config_data_1.get_settings("plugin1") == "setting1"


# Generated at 2022-06-24 18:15:21.622839
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting('aT8;)T]{?Yk')


# Generated at 2022-06-24 18:15:24.192015
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    assert config_data_0.update_setting(None) is None


# Generated at 2022-06-24 18:15:26.188972
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting="", plugin=None)



# Generated at 2022-06-24 18:15:35.586877
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    import sys
    import os
    import tempfile
    import shutil
    import ansible.plugins.loader
    test_dir = tempfile.mkdtemp()
    config_data_1.update_setting(ansible.plugins.loader.PluginConfiguration('hello', '{0}/hello.ini'.format(test_dir), 'ini', ['DEFAULT']))
    assert config_data_1.get_settings()[0].name == 'hello'
    shutil.rmtree(test_dir)


# Generated at 2022-06-24 18:15:41.993446
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    plugin = ConfigPlugin(ConfigPlugin.CORE,'core')
    config_data_0.update_setting(ConfigSetting('ANSIBLE_STDOUT_CALLBACK', True, plugin=plugin))

    assert config_data_0.get_setting('ANSIBLE_STDOUT_CALLBACK',plugin=plugin) is not None


# Generated at 2022-06-24 18:15:43.669163
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings_0 = config_data_0.get_settings()


# Generated at 2022-06-24 18:15:48.926349
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    # create some settings
    setting = Setting(name='name_0', value='value_0')
    config_data.update_setting(setting)

    # find no plugins with this name
    plugin = Plugin('no_type', 'name_0')
    assert config_data.get_setting(setting.name, plugin) is None

    setting = Setting(name='name_0', value='value_0')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting(setting.name, plugin) is not None
    assert config_data.get_setting(setting.name, plugin) == setting



# Generated at 2022-06-24 18:15:53.054272
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_1 = ConfigData()
    assert None == config_data_1.get_settings(None)


# Generated at 2022-06-24 18:15:54.968151
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    assert config_data_0.update_setting(setting=True, plugin=None) == None


# Generated at 2022-06-24 18:15:59.761812
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(namespace='ansible.builtin', name='HOST_KEY_CHECKING', value='False', origin='', category='')
    config_data_0.update_setting(setting=setting_0, plugin=None)


# Generated at 2022-06-24 18:16:04.937036
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('name_0', 'value_0')
    config_data_0.update_setting(setting_0)
    assert(config_data_0._global_settings['name_0'] == setting_0)


# Generated at 2022-06-24 18:16:07.315382
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert config_data_1.get_settings(plugin=None) == []
    pass


# Generated at 2022-06-24 18:16:10.497165
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    name = 'test_name'
    plugin = None
    result = config_data_0.get_setting(name, plugin)
    assert result is None


# Generated at 2022-06-24 18:16:13.458158
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    setting_0 = Setting()
    setting_0.name = 'abc'

    config_data_0.update_setting(setting_0)


# Generated at 2022-06-24 18:16:23.642375
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print('Testing update_setting')
    config_data_0 = ConfigData()

    setting_0 = ConfigSetting('setting_0', 'description_0')
    config_data_0.update_setting(setting_0)
    return_value_0 = config_data_0.get_setting('setting_0')
    assert return_value_0.name == 'setting_0'
    assert return_value_0.description == 'description_0'

    setting_1 = ConfigSetting('setting_1', 'description_1')
    plugin_0 = Plugin('name_0', 'type_0')
    config_data_0.update_setting(setting_1, plugin_0)
    return_value_1 = config_data_0.get_setting('setting_1', plugin_0)

# Generated at 2022-06-24 18:16:35.639254
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    global_setting_1 = Setting('foo', 'bar')
    config_data.update_setting(global_setting_1)

    assert True == config_data.get_setting(global_setting_1.name)

    global_setting_2 = Setting('foo', 'baz')
    config_data.update_setting(global_setting_2)

    assert global_setting_2 == config_data.get_setting(global_setting_2.name)

    plugin = Plugin('foo', 'baz')
    plugin_setting_1 = Setting('foo', 'bar')
    config_data.update_setting(plugin_setting_1, plugin)

    assert plugin_setting_1 == config_data.get_setting(plugin_setting_1.name, plugin)


# Generated at 2022-06-24 18:16:37.335008
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    assert config_data_1.get_setting("foo") is None



# Generated at 2022-06-24 18:16:49.253426
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    from collections import namedtuple
    class Setting(object):
        def __init__(self, name):
            self.name = name
    setting = Setting('setting')
    config_data.update_setting(setting, None)
    class Plugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name
    plugin = Plugin('type', 'name')
    config_data.update_setting(setting, plugin)
    assert config_data._global_settings['setting'] == setting
    assert config_data._plugins['type']['name']['setting'] == setting


# Generated at 2022-06-24 18:16:59.432638
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting('foo', value='bar'))
    config_data_0.update_setting(Setting('foo', value='bar', plugin=Plugin('foo', 'bar')))

    assert config_data_0.get_setting('foo') is not None
    assert config_data_0.get_setting('foo').value == 'bar'
    assert config_data_0.get_setting('foo', Plugin('foo', 'bar')).value == 'bar'
    assert config_data_0.get_setting('baz') is None
    assert config_data_0.get_setting('baz', 'bar') is None



# Generated at 2022-06-24 18:17:04.605711
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='name_0')
    setting_0.update_value()
    plugin_0 = ModulePlugin()
    setting_0.update_value(plugin_0)
    settings_0 = config_data_0.get_settings()
    settings_1 = config_data_0.get_settings(plugin_0)


# Generated at 2022-06-24 18:17:14.601168
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting('node=1.2.3.4')
    config_data_0.update_setting('passwd=mypass')
    config_data_0.update_setting(setting=None)
    config_data_0.update_setting('port=1.2.3.4')
    config_data_0.update_setting('node=1.2.3.4', plugin=None)
    config_data_0.update_setting('port=1.2.3.4', plugin=None)
    config_data_0.update_setting('passwd=mypass', plugin=None)
    config_data_0.update_setting('node=1.2.3.4')

# Generated at 2022-06-24 18:17:20.890435
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    print("Testing get_setting of class ConfigData")

    config_data_0 = ConfigData()
    config_data_0.update_setting(ConfigSetting(u'conf_name', u'string', u'conf_value'))
    config_data_0.update_setting(ConfigSetting(u'conf_name', u'string', u'conf_value2'))
    conf_setting = config_data_0.get_setting(u'conf_name')
    print("conf_setting", conf_setting)
    conf_setting = config_data_0.get_setting(u'conf_name2')
    print("conf_setting", conf_setting)


# Generated at 2022-06-24 18:17:23.469410
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()


# Generated at 2022-06-24 18:17:30.116375
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    print('\nUnit test for method get_settings of class ConfigData')

    config_data_0 = ConfigData()

    for name in ['foo']:
        setting_0 = Setting('foo', 'foo_value')

        config_data_0.update_setting(setting_0)

        settings = config_data_0.get_settings()

        assert len(settings) == 1

        assert settings[0].name == 'foo'

    print('\nUnit test for method get_settings of class ConfigData: success')


# Generated at 2022-06-24 18:17:35.400659
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    """

    """
    print('Test method get_settings of class ConfigData')
    config_data_0 = ConfigData()
    settings = config_data_0.get_settings()
    assert len(settings) == 0


# Generated at 2022-06-24 18:17:38.265536
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert len(config_data_1.get_settings()) == 0


# Generated at 2022-06-24 18:17:47.809260
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.parsing.dataloader import DataLoader
    config_data_0 = ConfigData()
    DataLoader
    plugin = DataLoader
    test_ConfigData_get_setting_name = None
    test_ConfigData_get_setting_plugin = None

    # Invoke method
    try:
        return_value = config_data_0.get_setting(test_ConfigData_get_setting_name, test_ConfigData_get_setting_plugin)
    except Exception as exception:
        error = exception
        print(error)



# Generated at 2022-06-24 18:17:59.305142
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(setting=None)
    return 0


# Generated at 2022-06-24 18:18:01.179037
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting()


# Generated at 2022-06-24 18:18:06.086525
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    global_settings = config_data.get_settings()
    assert global_settings.__class__ == list and len(global_settings) == 0


# Generated at 2022-06-24 18:18:09.923665
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test_case_0()

    temp_1 = ConfigData()
    print(temp_1.get_setting("name"))
    print(temp_1.get_setting("name", plugin=None))


# Generated at 2022-06-24 18:18:13.368129
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Test with plugin is None
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []

    config_data_0.update_setting(Setting('debug', True, 'Default', 'bool'))
    assert config_data_0.get_settings() != []

# Generated at 2022-06-24 18:18:14.169077
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()

# Generated at 2022-06-24 18:18:20.630919
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_1 = ConfigData()

    setting_1 = MockConfigSetting('tty_logging', bool, False)
    config_data_1.update_setting(setting_1)

    setting_2 = MockConfigSetting('tty_logging', bool, False)
    plugin_1 = MockConfigPlugin('connection', 'ssh')
    config_data_1.update_setting(setting_2, plugin_1)

    assert setting_1 == config_data_1.get_setting('tty_logging')
    assert setting_2 == config_data_1.get_setting('tty_logging', plugin_1)



# Generated at 2022-06-24 18:18:32.762413
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    new_setting = {'deadline': '3', 'force': True, 'force_handlers': False,
                   'inventory': [], 'module_path': '', 'one_line': False,
                   'output_callback': 'default', 'poll_interval': 15,
                   'scp_extra_args': '', 'sftp_extra_args': '', 'ssh_common_args': '',
                   'ssh_extra_args': '', 'syntax': False, 'tree': None,
                   'verbosity': 0}

    for setting in new_setting:
        config_data.update_setting(name=setting, plugin=None)
        if config_data.get_setting(name=setting, plugin=None) is None:
            return False
    return True



# Generated at 2022-06-24 18:18:34.222576
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:18:38.174078
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    try:
        ConfigData.get_setting(config_data_0)
    except NotImplementedError as e:
        print(e)
    except SystemExit as e:
        print(e)


# Generated at 2022-06-24 18:18:46.631387
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert True

# Generated at 2022-06-24 18:18:54.643932
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting = ConfigSetting('setting_0', 'True')
    setting_1 = ConfigSetting('setting_1', 'False')
    setting_2 = ConfigSetting('setting_2', 'str,int')
    setting_3 = ConfigSetting('setting_3', '10')
    setting_4 = ConfigSetting('setting_4', 'str')
    setting_5 = ConfigSetting('setting_5', 'str,int')
    setting_6 = ConfigSetting('setting_6', '10.5')
    setting_7 = ConfigSetting('setting_7', 'int')
    setting_8 = ConfigSetting('setting_8', '10')
    setting_9 = ConfigSetting('setting_9', 'int')
    setting_10 = ConfigSetting('setting_10', '10.5')
    setting_11 = Config

# Generated at 2022-06-24 18:19:03.615917
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Set up
    config_data_1 = ConfigData()
    setting_1 = Setting({'name': 'some_setting_1', 'plugin': 'some_plugin_1'})
    setting_2 = Setting({'name': 'some_setting_1', 'plugin': 'some_plugin_2'})
    config_data_1.update_setting(setting_1)
    config_data_1.update_setting(setting_2)

    # Execute
    result_1 = config_data_1.get_settings()
    result_2 = config_data_1.get_settings(setting_1.plugin)

    # Verify
    assert len(result_1) == 1
    assert len(result_2) == 1


# Generated at 2022-06-24 18:19:06.996955
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Test with plugin = None
    config_data_0 = ConfigData()
    result_0 = config_data_0.get_settings(plugin=None)
    assert result_0 == []


# Generated at 2022-06-24 18:19:13.152459
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = Plugin(name='test', type='test', count=0)
    setting_0 = Setting('test2', 'test2', 'test2', 'test2', 0, 'test2', 'test2', 'test2', 'test2', 'test2', 'test2')
    config_data_0.update_setting(setting_0, plugin_0)
    config_data_0.get_settings(plugin_0)



# Generated at 2022-06-24 18:19:21.129022
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    # Test with a string

    config_data_0.update_setting("test_setting_0")

    assert(config_data_0.get_setting("test_setting_0") == "test_setting_0")
    # Test with an integer

    config_data_0.update_setting(1701)

    assert(config_data_0.get_setting(1701) == 1701)
    # Test with a dictionary

    config_data_0.update_setting({"test_setting_1": "test_setting_1"})

    assert(config_data_0.get_setting({1701: "test_setting_0"}) == {"test_setting_1": "test_setting_1"})


# Generated at 2022-06-24 18:19:22.743005
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    data_0 = config_data.get_setting('foo')
    assert data_0 is None


# Generated at 2022-06-24 18:19:27.178885
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting()
    config_data_1.update_setting({})
    config_data_1.update_setting('')
    config_data_1.update_setting(())
    config_data_1.update_setting(('Setting Name',))
    config_data_1.update_setting(('Setting Name','Setting Value'))



# Generated at 2022-06-24 18:19:32.798630
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0_0 = Setting('foo', 'bar')
    config_data_0.update_setting(setting_0_0)
    setting_0 = config_data_0.get_setting('foo')
    assert setting_0.name == 'foo' and setting_0.value == 'bar'



# Generated at 2022-06-24 18:19:39.652828
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    assert type(config_data_0) == ConfigData
    assert type(config_data_0._global_settings) == dict
    assert type(config_data_0._plugins) == dict
    assert not config_data_0._global_settings
    assert not config_data_0._plugins


# Generated at 2022-06-24 18:19:49.727511
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting)


# Generated at 2022-06-24 18:19:51.629508
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()


# Generated at 2022-06-24 18:20:01.987924
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Test for a setting name that does not exist.
    config_data_1 = ConfigData()
    setting_1 = config_data_1.get_setting(name='undefined')
    assert setting_1 == None

    # Test for a defined global setting.
    setting_2 = Setting(name='foo', value='bar')
    config_data_2 = ConfigData()
    config_data_2.update_setting(setting_2)
    setting_3 = config_data_2.get_setting(name='foo')
    assert setting_3.name == 'foo'
    assert setting_3.value == 'bar'

    # Test for a defined plugin setting.
    setting_4 = Setting(name='foo', value='bar')
    plugin_1 = Plugin('action', 'test_action')
    config_data_3 = Config

# Generated at 2022-06-24 18:20:04.101554
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:20:08.924017
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_1 = Config(None, None, None)
    config_data_0.update_setting(config_1)
    assert config_data_0.get_setting(config_1.name) != None


# Generated at 2022-06-24 18:20:10.781929
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert ConfigData().get_settings() is None


# Generated at 2022-06-24 18:20:18.386791
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data_setting = ConfigDataSetting("timeout", "90", "Timeout in seconds for the connection")
    config_data_plugin = ConfigDataPlugin("connection", "local")
    config_data_0 = ConfigData()
    config_data_0.update_setting(config_data_setting, config_data_plugin)
    assert config_data_0.get_setting("timeout", config_data_plugin) == config_data_setting



# Generated at 2022-06-24 18:20:20.160400
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(None, None)



# Generated at 2022-06-24 18:20:22.237911
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting_0, plugin_0)


# Generated at 2022-06-24 18:20:24.503606
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {}
    config_data._plugins = {}
    assert config_data.get_settings() == []


# Generated at 2022-06-24 18:20:38.816901
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    config_data.update_setting(Setting('foo', 42, 'bar'))
    config_data.update_setting(Setting('foo', 42, 'bar', 'baz'))
    assert config_data.get_setting('foo') == Setting('foo', 42, 'bar')
    assert config_data.get_setting('foo', Plugin('baz', 'bar')) == Setting('foo', 42, 'bar', 'baz')



# Generated at 2022-06-24 18:20:40.858545
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting)


# Generated at 2022-06-24 18:20:47.740921
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_1 = ConfigData()
    plugin1 = Plugin('abc', 'executor')
    plugin2 = Plugin('abc', 'callback')
    plugin3 = Plugin('xyz', 'callback')

    setting1 = Setting('foo', 'bar')
    setting2 = Setting('foo', 'bar')
    setting3 = Setting('foo', 'bar')

    config_data_1.update_setting(setting1, plugin=plugin1)
    config_data_1.update_setting(setting2, plugin=plugin1)
    config_data_1.update_setting(setting3, plugin=None)

    assert config_data_1.get_settings(plugin=plugin1) == [setting1, setting2]
    assert config_data_1.get_settings(plugin=plugin2) == []
    assert config_data_1.get

# Generated at 2022-06-24 18:20:59.278886
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(display='default_queue', description='', name='default_queue', type='str', value='ansible', category='', source_file='/home/ansible/workspace/ansible-project/ansible/plugins/callback/default.yml', source_line=1)
    config_data_0.update_setting(setting_0)
    setting_1 = Setting(display='default_queue', description='', name='default_queue', type='str', value='ansible', category='', source_file='/home/ansible/workspace/ansible-project/ansible/plugins/callback/default.yml', source_line=1)
    config_data_0.update_setting(setting_1)

# Generated at 2022-06-24 18:21:05.846390
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_obj = ConfigData()
    setting = Setting(name='foo', value='foovalue')
    plugin = Plugin('shell', 'sh')
    config_data_obj.update_setting(setting, plugin)
    assert config_data_obj._global_settings == {}
    assert plugin.type in config_data_obj._plugins
    assert plugin.name in config_data_obj._plugins[plugin.type]
    assert 'foo' in config_data_obj._plugins[plugin.type][plugin.name]
    assert config_data_obj._plugins[plugin.type][plugin.name]['foo'] == setting


# Generated at 2022-06-24 18:21:08.194638
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == None
    assert config_data_0.get_settings(plugin=None) == None


# Generated at 2022-06-24 18:21:10.115134
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:21:18.666369
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('foo', 'str', 'string', description='bar', values=['foo', 'bar']))
    config_data_1.update_setting(Setting('bar', 'bool', 'bool', description='foo'))

    s = config_data_1.get_setting('foo')
    assert s.name == 'foo'
    assert s.type == 'str'
    assert s.default == 'string'
    assert s.description == 'bar'
    assert s.values == ['foo', 'bar']

    s = config_data_1.get_setting('bar')
    assert s.name == 'bar'
    assert s.type == 'bool'
    assert s.default == 'bool'
    assert s.description == 'foo'
   

# Generated at 2022-06-24 18:21:22.194729
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    s = Setting()
    s.name = 'foo'
    s.value = 'bar'
    c.update_setting(s)
    assert s in c.get_settings()


# Generated at 2022-06-24 18:21:23.974009
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:21:38.824553
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    # Create a setting object and add it to the config data object
    setting_0 = Setting('path', '/etc/ansible/ansible.cfg')
    config_data_0.update_setting(setting_0)

    # Get the setting for the given setting name
    setting = config_data_0.get_setting('path')
    assert setting.name == 'path' and setting.value == '/etc/ansible/ansible.cfg'


# Generated at 2022-06-24 18:21:45.709693
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    # Testing to see if config_data_0 contains no settings
    assert len(config_data_0.get_settings()) == 0

    # Testing to see if config_data_0 contains no settings for a plugin
    assert len(config_data_0.get_settings(plugin=Plugin('connection', 'local'))) == 0



# Generated at 2022-06-24 18:21:49.067267
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='setting_test'), plugin=None)
    setting = config_data.get_setting('setting_test')
    assert setting is not None


# Generated at 2022-06-24 18:22:00.986964
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    setting = Setting(name='string_setting', value='a string', description='a config setting that is a string')

    config_data_1 = ConfigData()
    config_data_1.update_setting(setting)

    setting = config_data_1.get_setting('string_setting')
    assert setting.name == 'string_setting'
    assert setting.value == 'a string'
    assert setting.description == 'a config setting that is a string'
    assert setting.plugin is None

    setting = config_data_1.get_settings()[0]
    assert setting.name == 'string_setting'
    assert setting.value == 'a string'
    assert setting.description == 'a config setting that is a string'
    assert setting.plugin is None

    plugin = Plugin(type='cache', name='mycache')


# Generated at 2022-06-24 18:22:02.901012
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()


# Generated at 2022-06-24 18:22:04.929764
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting_0, plugin_0)


# Generated at 2022-06-24 18:22:06.528047
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:22:11.426940
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()
    config_data_3 = ConfigData()
    config_data_4 = ConfigData()
    config_data_5 = ConfigData()
    config_data_6 = ConfigData()
    config_data_7 = ConfigData()

    from ansible.plugins.loader import get_plugin_loader
    collection_loader = get_plugin_loader("collections")

    plugin = collection_loader.get("ansible.netcommon", "module_utils", "net_version")

# Generated at 2022-06-24 18:22:17.796407
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    setting_0 = Setting(name="ansible_verbosity", value="my_value")
    config_data.update_setting(setting_0)

    setting_1 = Setting(name="ansible_host_key_checking", value="False")
    config_data.update_setting(setting_1)

    setting_2 = Setting(name="ansible_host_key_checking", value="True")
    config_data.update_setting(setting_2)

    s = config_data.get_setting("ansible_host_key_checking")
    assert(s.value == "True")


# Generated at 2022-06-24 18:22:20.329654
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting)

# Generated at 2022-06-24 18:22:46.089258
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting_0 = config_data_0.get_settings()


# Generated at 2022-06-24 18:22:52.139350
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test case 0
    test_case_0()

    config_data_0 = ConfigData()
    setting_0 = config_data_0.get_setting('name', 'plugin')
    assert setting_0 is None

    setting_1 = config_data_0.get_setting(None, 'plugin')
    assert setting_1 is None

    setting_2 = config_data_0.get_setting(None, None)
    assert setting_2 is None


# Generated at 2022-06-24 18:22:55.634918
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(config_data_1.get_setting())
    config_data_1.update_setting(config_data_1.get_setting())
    config_data_1.update_setting(config_data_1.get_setting())
    config_data_1.update_setting(config_data_1.get_setting())



# Generated at 2022-06-24 18:22:59.846061
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_12 = ConfigData()
    setting_12 = Setting(name='name_12', description='description_12', value='value_12')
    try:
        config_data_12.update_setting(setting_12)
    except Exception as e:
        print(str(e))


# Generated at 2022-06-24 18:23:02.560409
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings = config_data_0.get_settings()

    assert settings is not None
    assert len(settings) == 0



# Generated at 2022-06-24 18:23:05.416959
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)

    assert config_data._global_settings['foo'].name == 'foo'
    assert config_data._global_settings['foo'].value == 'bar'



# Generated at 2022-06-24 18:23:10.481464
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()

    setting_1 = Setting(name='ANSIBLE_CONFIG', scope='boolean', value='True', plugin=None)
    config_data_1.update_setting(setting=setting_1)

    setting_2 = Setting(name='ANSIBLE_FORKS', scope='integer', value='10', plugin=None)
    config_data_1.update_setting(setting=setting_2)



# Generated at 2022-06-24 18:23:20.954577
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Case 1:
    # Create an empty ConfigData object
    # Verify that the list of settings returned by get_settings is empty

    print('=== Case 1: Calling get_settings on an empty ConfigData object. Expecting empty list.')
    config_data = ConfigData()
    assert config_data.get_settings() == []

    # Case 2:
    # Add a global setting to ConfigData object
    # Verify that the list of settings returned by get_settings includes the added setting

    print('=== Case 2: Add a global setting to an empty ConfigData object. Expecting list of settings with one entry.')
    global_setting = ('short_description', 'short_description_value')
    config_data.update_setting(PluginSetting(global_setting[0], global_setting[1]))

# Generated at 2022-06-24 18:23:24.094024
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    assert config_data_0.update_setting(None) == None


# Generated at 2022-06-24 18:23:26.234560
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:23:45.113177
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting('background_color') == None


# Generated at 2022-06-24 18:23:52.896425
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()

    setting_0 = Setting(name='name_0')
    config_data_0.update_setting(setting_0, plugin=None)

    plugin_0 = Plugin(name='name_0', type='type_0')
    setting_1 = Setting(name='name_1')
    config_data_0.update_setting(setting_1, plugin=plugin_0)

    settings_0 = config_data_0.get_settings(plugin=None)
    settings_1 = config_data_0.get_settings(plugin=plugin_0)

    assert len(settings_0) == 1
    assert settings_0[0] == setting_0

    assert len(settings_1) == 1
    assert settings_1[0] == setting_1



# Generated at 2022-06-24 18:23:56.600834
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting('f_bar')


# Generated at 2022-06-24 18:24:01.145701
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    if len(config_data_0.get_settings()) != 0:
        raise RuntimeError("Failed to return expected values for get_settings()")



# Generated at 2022-06-24 18:24:04.316217
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting('', None) is None


# Generated at 2022-06-24 18:24:11.541228
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Initialize objects
    config_data_1 = ConfigData()
    import ansible.constants as C
    # Assert that get_setting works without parameters when there are no
    # global settings
    config_data_1.get_setting()

    # Assert that get_setting works without parameters when there are global
    # settings
    config_data_1.update_setting(C.ConfigOption(name='log_path', default='/var/log/ansible/ansible.log', value='/var/log/ansible/ansible.log', aliases=[]))
    config_data_1.get_setting()

    # Assert that get_setting works with parameters when there are no global
    # settings
    from ansible.plugins.loader import PluginLoader
    import ansible.plugins

# Generated at 2022-06-24 18:24:16.696989
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('0', '0')
    ##
    ## expected setting_0
    ##
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_setting(setting_0.name) == setting_0


# Generated at 2022-06-24 18:24:27.569254
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible_collections.ansible.community.plugins.module_utils.config import ConfigData
    from ansible_collections.ansible.community.plugins.module_utils.config import Setting

    class Plugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class C0(object):
        def __init__(self, name, filename='c0.yml'):
            self.name = name
            self.filename = filename

        def __call__(self, value):
            pass

    class C1(object):
        def __init__(self, name, filename='c1.yml'):
            self.name = name
            self.filename = filename

        def __call__(self, value):
            pass

    # test update_setting

# Generated at 2022-06-24 18:24:39.014537
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    global_setting_0 = GlobalSetting()
    global_setting_1 = GlobalSetting()
    global_setting_0.name = "a"
    global_setting_1.name = "b"
    config_data_0.update_setting(global_setting_0)
    config_data_0.update_setting(global_setting_1)
    plugin_0 = Plugin()
    plugin_0.type = "a"
    plugin_0.name = "b"
    plugin_setting_0 = PluginSetting()
    plugin_setting_0.name = "c"
    plugin_setting_1 = PluginSetting()
    plugin_setting_1.name = "d"
    config_data_0.update_setting(plugin_setting_0, plugin_0)
    config_data

# Generated at 2022-06-24 18:24:42.085591
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Check that get_settings works with an empty config data
    config_data = ConfigData()

    assert config_data.get_settings() == []
