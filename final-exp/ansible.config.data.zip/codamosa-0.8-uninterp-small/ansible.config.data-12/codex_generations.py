

# Generated at 2022-06-24 18:15:12.582821
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    result_1 = config_data_1.get_settings()
    assert result_1 == []

    setting_2 = ConfigSetting(name='name_2', type='type_2', path='path_2', section='section_2', description='description_2', default='default_2', aliases='aliases_2', env_vars='env_vars_2')
    config_data_1.update_setting(setting=setting_2)
    result_3 = config_data_1.get_settings()
    assert isinstance(result_3, list)
    assert len(result_3) == 1
    assert result_3[0] == setting_2

    plugin_4 = BasePlugin(name='name_4', type='type_4')
    result_5 = config_data_

# Generated at 2022-06-24 18:15:22.771987
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    # Test passing 0 arguments to update_setting
    try:
        config_data_0.update_setting()
        assert False, "Expected exception"
    except TypeError:
        pass
    except Exception as e:
        assert False, "Exception: " + str(e)
    else:
        assert True, "Expected exception"

    # Test passing 1 argument to update_setting
    try:
        config_data_0.update_setting(None)
        assert False, "Expected exception"
    except TypeError:
        pass
    except Exception as e:
        assert False, "Exception: " + str(e)
    else:
        assert True, "Expected exception"

    # Test passing 2 arguments to update_setting

# Generated at 2022-06-24 18:15:24.011143
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    assert False


# Generated at 2022-06-24 18:15:26.679310
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_setting_0 = config_data_0.get_setting("INVENTORY", plugin=None)
    assert config_setting_0 is None


# Generated at 2022-06-24 18:15:38.590660
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=setting_0, plugin=plugin_0)
    assert config_data_0.get_setting(name='foo') == setting_0
    assert config_data_0.get_setting(name='bar') is None
    config_data_0.update_setting(setting=setting_1, plugin=plugin_0)
    assert config_data_0.get_setting(name='foo') == setting_1
    assert config_data_0.get_setting(name='bar') is None
    config_data_0.update_setting(setting=setting_2, plugin=plugin_1)
    assert config_data_0.get_setting(name='foo') == setting_1

# Generated at 2022-06-24 18:15:48.996187
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    class_name_0 = 'Config'
    module_name_0 = 'ansible-test-harness.testing_utils'
    module_path_0 = 'ansible-test-harness-venv/lib/python2.7/site-packages/ansible_test_harness/testing_utils/config.py'
    object_path_0 = 'ansible-test-harness-venv/lib/python2.7/site-packages/ansible_test_harness/testing_utils/config.pyc'
    settings_data_0 = {'VALIDATE_SYNTAX': True, 'VERBOSITY': 0}
    value_0 = 'value'

# Generated at 2022-06-24 18:15:54.718789
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = Plugin()
    plugin_0.name = 'test_plugin'
    plugin_0.type = 'action'
    # Test of get_settings for the scenario where all values are empty
    assert len(config_data_0.get_settings()) == 0
    # Test of get_settings for the scenario where all values are not empty
    assert len(config_data_0.get_settings(plugin_0)) == 0


# Generated at 2022-06-24 18:15:58.542037
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_1 = ConfigData()
    assert config_data_1.get_settings() == []


# Generated at 2022-06-24 18:16:01.773944
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()
    config_data_1.update_setting(ConfigSetting())
    config_data_1.update_setting(ConfigSetting())
    config_data_1.update_setting(ConfigSetting())

    assert len(config_data_1._global_settings) == 3


# Generated at 2022-06-24 18:16:05.172203
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_1 = ConfigData()

    plugin = (None, None)
    _settings = config_data_1.get_settings(plugin)
    print (_settings)

if __name__ == '__main__':
    test_case_0()
    test_ConfigData_get_settings()

# Generated at 2022-06-24 18:16:17.937389
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = ConfigData.Plugin()
    plugin_1 = ConfigData.Plugin()
    plugin_2 = ConfigData.Plugin()
    plugin_2.type = 'callback'
    plugin_2.name = 'yaml'
    plugin_3 = ConfigData.Plugin()
    plugin_3.type = 'callback'
    plugin_3.name = 'yaml'
    plugin_4 = ConfigData.Plugin()
    plugin_4.type = 'callback'
    plugin_4.name = 'yaml'
    config_setting_0 = ConfigData.Setting('log_path')
    config_setting_0.value = '../logs'
    config_setting_0.type = 'str'
    config_setting_0.section = 'defaults'
    config_setting_

# Generated at 2022-06-24 18:16:26.428866
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Input data
    config_data_1 = ConfigData()
    plugin_0 = 'mock'
    setting_name_0 = 'mock'

    # Expected result
    result_0 = None

    # Expected result
    result_1 = None

    # Expected result
    result_2 = None

    # Perform unit test
    assert result_0 == config_data_1.get_setting(setting_name_0, plugin_0)
    assert result_1 == 'mock'
    assert result_2 == 'mock'



# Generated at 2022-06-24 18:16:36.638213
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()
    config_data_1.update_setting(
        Setting(name='retry_files_enabled', value=[True], origin=None, priorities=[], path=None)
    )

    config_data_1.update_setting(
        Setting(name='lorem', value=[True], origin=None, priorities=[], path=None),
        plugin=Plugin(type='module', name='shell')
    )

    print(config_data_1.get_settings())
    print(config_data_1.get_settings(
        plugin=Plugin(type='module', name='shell')
    ))

    assert config_data_1.get_settings()[0].name == 'retry_files_enabled'

# Generated at 2022-06-24 18:16:46.068199
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
	config_data_0 = ConfigData()
	# Test with required values only
	config_setting = ConfigSetting(name='foo')
	config_data_0.update_setting(config_setting, None)
	# Test with non-required values
	config_plugin = ConfigPlugin(type='cache', name='redis')
	config_data_0.update_setting(config_setting, config_plugin)
	assert(get_setting('foo', None) == config_setting)
	assert(get_setting('foo', config_plugin) == config_setting)


# Generated at 2022-06-24 18:16:52.324748
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting = Setting()
    config_data_0.update_setting(setting)


# Generated at 2022-06-24 18:16:53.962681
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('setting_name') == None


# Generated at 2022-06-24 18:16:56.599670
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_1 = ConfigData()
    settings = ['foo', 'bar']
    config_data_1.settings = settings
    config_data_0.settings = settings
    config_data_1.settings = settings


# Generated at 2022-06-24 18:17:06.159845
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin({'name': 'my_test_plugin_0', 'type': 'test'})
    setting = Setting({'name': 'my_test_setting_0', 'default': 'test_default_0', 'desc': 'desc_0', 'env': 'env_0', 'ini': 'ini_0', 'key': 'key_0', 'secret': False, 'short': 'short_0', 'type': 'string'})
    config_data.update_setting(setting, plugin)
    setting = config_data.get_setting('my_test_setting_0', plugin)
    assert setting.name == 'my_test_setting_0'



# Generated at 2022-06-24 18:17:07.681275
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:17:09.151399
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:17:16.848621
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    try:
        config_data_0.update_setting(plugin=plugin_0, setting=setting_0)
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-24 18:17:20.161388
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(str(), bool()) is None


# Generated at 2022-06-24 18:17:31.693793
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting("name0")
    config_data_1.update_setting("name1", "value1")
    config_data_1.update_setting("name2", "value2", "type0")
    config_data_1.update_setting("name3", "value3", "type1", "name0")
    config_data_1.update_setting("name4", "value4", "type1", "name1")
    config_data_1.update_setting("name5", "value5", "type1", "name1", "version0")
    config_data_1.update_setting("name6", "value6", "type1", "name1", "version1")

# Generated at 2022-06-24 18:17:34.876134
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting)
    # Insert test here


# Generated at 2022-06-24 18:17:39.801021
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting() == None
    assert config_data_0.get_setting(plugin='plugin') == None
    assert config_data_0.get_setting(name='name', plugin='plugin') == None

# Generated at 2022-06-24 18:17:44.665228
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    plugin = None
    setting_0 = Setting('name', 'value')
    config_data_0.update_setting(setting_0, plugin)


# Generated at 2022-06-24 18:17:48.356109
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    test_case_0()
    if config_data_0.get_settings(None):
        print("Test case passed.")
    print("Test case not passed.")

# Generated at 2022-06-24 18:17:57.837886
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    test_setting = Setting('TYPE', 'PLUGIN', 'NAME', 'DESCRIPTION', 'DEFAULT')
    test_plugin = Plugin('TYPE', 'PLUGIN')
    config_data_0.update_setting(test_setting)
    assert test_setting is config_data_0.get_setting('NAME')
    config_data_0.update_setting(test_setting, test_plugin)
    assert test_setting is config_data_0.get_setting('NAME', test_plugin)


# Generated at 2022-06-24 18:18:08.226561
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Create objects of type ConfigData
    config_data_0 = ConfigData()
    # Create object of type ConfigSetting
    config_setting_0_0 = ConfigSetting(name='name_0', value='value_0', section='section_0')
    # Update setting for a non-plugin related setting
    config_data_0.update_setting(config_setting_0_0)
    # Check if the setting is updated correctly
    if config_data_0.get_setting('name_0') != config_setting_0_0:
        raise AssertionError
    # Create object of type Plugin
    plugin_0_0 = Plugin(type='type_0', name='name_0')
    # Create object of type ConfigSetting

# Generated at 2022-06-24 18:18:09.422698
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_case_0()


# Generated at 2022-06-24 18:18:28.545473
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_setting_0 = Setting(setting_type=SettingType.Text, name='setting_name', default_value='setting_value',
                               values=None, internal=False, options=None, sensitive=False)
    config_data_0.update_setting(config_setting_0)
    settings = config_data_0.get_settings()
    assert settings[0].get_type() == config_setting_0.type
    assert settings[0].get_name() == config_setting_0.name
    assert settings[0].get_default_value() == config_setting_0.default_value
    assert settings[0].get_values() == config_setting_0.values
    assert settings[0].get_internal() == config_setting_0.internal

# Generated at 2022-06-24 18:18:35.507880
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    global_setting = Setting('global_setting', 'global_value', None, None)
    config_data.update_setting(global_setting)
    assert config_data.get_setting('global_setting') == global_setting

    plugin = Plugin('type', 'name')
    plugin_setting = Setting('plugin_setting', 'plugin_value', plugin.type, plugin.name)
    config_data.update_setting(plugin_setting, plugin)
    assert config_data.get_setting('plugin_setting', plugin) == plugin_setting

    assert config_data.get_setting('plugin_setting') is None


# Generated at 2022-06-24 18:18:40.840032
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Type definition for method update_setting
    class Setting():
    # Fields
        name = "name"
        def_name = "default"
        desc = "desc"
        required = False
        value = "value"

# Type definition for class ConfigData
    class Plugin():
    # Type definition for class ConfigData
        class Type():
            NETCONF = "netconf"
            MODULE = "module"

    # Fields
        name = "name"
        type = Type.NETCONF
    config_data_0 = ConfigData()
    setting_0 = Setting()
    config_data_0.update_setting(setting_0)


# Generated at 2022-06-24 18:18:45.697421
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('enabled', 'yes')
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_setting('enabled') != None

# Generated at 2022-06-24 18:18:50.799331
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()

    setting_0 = Setting(name="test", value="test", priority=0, version=None, origin="test")
    config_data_0.update_setting(setting=setting_0)

    result = config_data_0.get_settings()
    assert len(result) == 1

# Generated at 2022-06-24 18:18:54.445202
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(None, None, None)
    config_data_0.update_setting(setting_0, None)


# Generated at 2022-06-24 18:18:57.598762
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(name='string')
    print(config_data_0._global_settings)


# Generated at 2022-06-24 18:18:59.700377
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

# Testing method get_settings of class ConfigData

# Generated at 2022-06-24 18:19:03.458641
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(name='test_0', value='test_1', aliases=[], version_added='test_3',
                                 now_default='test_4')


# Generated at 2022-06-24 18:19:07.978138
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = ArgSpec(name='ansible_ssh_common_args', default=None)
    config_data_0.update_setting(setting=setting_0)
    assert config_data_0._global_settings['ansible_ssh_common_args'] == setting_0


# Generated at 2022-06-24 18:19:28.176733
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('abc', 'def', plugin=Plugin('abc', 'def')))
    assert config_data_1.get_settings(Plugin('abc', 'def'))[0].value == 'def'


# Generated at 2022-06-24 18:19:30.725959
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:19:33.659850
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='foo', value_type=ValueType.STRING, value='foo')
    config_data_0.update_setting(setting_0)


# Generated at 2022-06-24 18:19:46.979776
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='plugin_setting_0')
    setting_1 = Setting(name='plugin_setting_1')
    setting_2 = Setting(name='plugin_setting_2')
    plugin_0 = Plugin(name='plugin_0')
    plugin_1 = Plugin(name='plugin_1')
    plugin_2 = Plugin(name='plugin_2')
    config_data_0.update_setting(setting_0, plugin=plugin_0)
    config_data_0.update_setting(setting_1, plugin=plugin_1)
    config_data_0.update_setting(setting_2, plugin=plugin_2)
    settings_0 = config_data_0.get_settings()
    assert len(settings_0) == 3

# Generated at 2022-06-24 18:19:48.907861
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    # Test with empty values
    config_data_0.update_setting(None, None)



# Generated at 2022-06-24 18:19:50.516467
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()



# Generated at 2022-06-24 18:19:55.049810
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()
    expected_result_0 = 0
    actual_result_0 = len(config_data_0.get_settings())
    assert expected_result_0 == actual_result_0



# Generated at 2022-06-24 18:19:58.726787
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    print(config_data.get_settings())


# Generated at 2022-06-24 18:20:02.166352
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(None)
    config_data_0.get_setting(None)
    config_data_0.get_setting(None)


# Generated at 2022-06-24 18:20:12.394357
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global config_data_0
    config_data_0 = ConfigData()
    setting_0 = Setting("PASSWORD_LENGTH", "12", None, None, None, None)
    config_data_0.update_setting(setting_0, None)
    setting_1 = Setting("PASSWORD_LENGTH", "12", None, None, None, None)
    config_data_0.update_setting(setting_1, None)
    print("Setting PASSWORD_LENGTH = %s" % config_data_0.get_setting("PASSWORD_LENGTH").value)


# Generated at 2022-06-24 18:20:29.246810
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_case_0 = ConfigData()
    assert test_case_0.get_settings() == []


# Generated at 2022-06-24 18:20:32.404975
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    print("Executing test_ConfigData_get_settings")
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:20:40.840101
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    import SystemConfiguration
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Global setting: plugin not set
    setting_0 = SystemConfiguration.SCDynamicStoreCopyConsoleUser(None, None, None)[1]
    # Global setting: plugin set to None
    setting_1 = SystemConfiguration.SCDynamicStoreCopyLocalHostName(None)[0]
    # Plugin setting: plugin_type = 'builtin', plugin_name = 'builtin'
    setting_2 = SystemConfiguration.SCNetworkInterfaceGetHardwareAddress(None, 'en0')

    print("Workspace: {}".format(setting_0))
    print("Workspace: {}".format(setting_1))

# Generated at 2022-06-24 18:20:47.741926
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # test with plugin
    plugin = get_test_plugin('test-plugin')
    config_data_0 = ConfigData()
    setting_0 = get_test_setting(plugin)
    config_data_0.update_setting(setting_0, plugin)
    setting_0_1 = config_data_0.get_setting(setting_0.name, plugin)
    assert setting_0_1 == setting_0

    # test without plugin
    plugin_0 = get_test_plugin('test-plugin-0')
    config_data_1 = ConfigData()
    setting_1 = get_test_setting(plugin_0)
    config_data_1.update_setting(setting_1)
    setting_1_1 = config_data_1.get_setting(setting_1.name)
    assert setting_1_1

# Generated at 2022-06-24 18:20:49.924766
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting_1 = config_data_1.get_setting("setting-0")


# Generated at 2022-06-24 18:20:53.825724
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    # config_data_0.get_settings(plugin=None)
    assert config_data_0.get_settings(plugin=None) == []
    # config_data_0.get_settings(plugin=None)
    


# Generated at 2022-06-24 18:20:59.672193
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert(len(config_data_0.get_settings()) == 0)
    assert(len(config_data_0.get_settings(None)) == 0)
    assert(len(config_data_0.get_settings(PluginInstanceIdentifier('test_plugin_type', 'test_plugin_name'))) == 0)


# Generated at 2022-06-24 18:21:06.955034
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('setting_name_0', 'setting_description_0')
    config_data_0.update_setting(setting_0)
    assert config_data_0._global_settings['setting_name_0'] == setting_0
    setting_1 = Setting('setting_name_1', 'setting_description_1')
    config_data_0.update_setting(setting_1)
    assert config_data_0._global_settings['setting_name_1'] == setting_1

    # Test with a plugin
    plugin = Plugin('plugin_name', 'plugin_type')
    setting_2 = Setting('setting_name_2', 'setting_description_2')
    config_data_0.update_setting(setting_2, plugin)
    assert config_data_0

# Generated at 2022-06-24 18:21:11.224599
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = test_case_0()
    test_setting_0 = Setting(name='name', plugin=None)
    config_data_0.update_setting(test_setting_0)


# Generated at 2022-06-24 18:21:14.429038
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()


# Generated at 2022-06-24 18:21:53.970351
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Create a ConfigData object
    config_data_3 = ConfigData()

    # Create a Plugin object with type - 'shell' and name - '/bin/sh'
    plugin_0 = Plugin(type='shell', name='/bin/sh')

    # Create a Setting object with name - 'ansible_shell_type' and value - 'csh', plugin - plugin_0
    setting_0 = Setting(name='ansible_shell_type', value='csh', plugin=plugin_0)

    # Update the created setting using update_setting method
    config_data_3.update_setting(setting_0)

    # Get the setting using get_setting method
    setting_1 = config_data_3.get_setting(name='ansible_shell_type', plugin=plugin_0)

    # Verify the setting is updated properly
    assert setting

# Generated at 2022-06-24 18:22:03.514452
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()
    setting_0 = Setting(name='TEST_SETTING_0', value='TEST_VALUE_0')
    config_data_1.update_setting(setting_0)
    assert config_data_1._global_settings['TEST_SETTING_0'].name == 'TEST_SETTING_0'
    assert config_data_1._global_settings['TEST_SETTING_0'].value == 'TEST_VALUE_0'
    setting_1 = Setting(name='TEST_SETTING_1', value='TEST_VALUE_1')
    config_data_1.update_setting(setting_1)
    assert config_data_1._global_settings['TEST_SETTING_1'].name == 'TEST_SETTING_1'
    assert config_

# Generated at 2022-06-24 18:22:09.464678
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    config_setting = ConfigSetting()
    config_data.update_setting(config_setting)
    assert config_setting == config_data.get_setting(config_setting.name)

    
    config_plugin = ConfigPlugin(config_plugin.type, config_plugin.name)
    config_data.update_setting(config_setting, config_plugin)
    assert config_setting == config_data.get_setting(config_setting.name, config_plugin)

    config_data.update_setting(config_setting)
    assert config_setting == config_data.get_setting(config_setting.name)



# Generated at 2022-06-24 18:22:15.830334
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()

    # Test for input: (setting, plugin=None)
    setting_0 = Setting()
    config_data_0.update_setting(setting_0)

    # Test for input: (setting, plugin=None)
    setting_1 = Setting()
    plugin_1 = Plugin()
    config_data_0.update_setting(setting_1, plugin_1)



# Generated at 2022-06-24 18:22:25.569838
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Setup
    config_setting_0 = ConfigSetting(
        name = 'RANDOM_CHOICE',
        value = 'INCLUDES',
        type = 'STRING',
        description = '"The type of plugin to create random choices from"',
        origin = '',
        plugin = None
    )

    # Test
    config_data_1 = ConfigData()
    config_data_1.update_setting(config_setting_0)
    config_setting_1 = config_data_1.get_setting('RANDOM_CHOICE')

    assert config_setting_0.name == config_setting_1.name
    assert config_setting_0.value == config_setting_1.value



# Generated at 2022-06-24 18:22:29.255599
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting('a', 'a') == None

# Generated at 2022-06-24 18:22:31.344751
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []

# Generated at 2022-06-24 18:22:32.984358
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert  config_data_0.get_setting == None


# Generated at 2022-06-24 18:22:41.369667
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    from collections import namedtuple
    from ansible.utils.collection_plugins import is_collection_ref

    class PluginType(object):
        def __init__(self, name, type):
            self.name = name
            self.type = type


    class Setting(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value

    plugin_type_1 = PluginType(name='test_plugin_type_1', type='./type_1')
    plugin_type_2 = PluginType(name='test_plugin_type_2', type='./type_2')

    setting_1 = Setting('test_setting_1', 'test_value_1')

# Generated at 2022-06-24 18:22:48.572179
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    used_plugin = []
    expected_result = []
    actual_result = config_data_0.get_settings(used_plugin)
    assert(actual_result == expected_result)
    expected_result = []
    actual_result = config_data_0.get_settings(used_plugin)
    assert(actual_result == expected_result)


# Generated at 2022-06-24 18:24:09.208705
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()

    # Test with a global setting
    global_setting_1 = Setting(None, None, name='ansible_python_interpreter', value='/tmp/python', type='path')
    config_data_1.update_setting(global_setting_1)
    assert config_data_1.get_setting('ansible_python_interpreter').value == '/tmp/python'

    # Test with a core plugin setting
    core_plugin_setting_1 = Setting(None, None, name='settings', value='asdf', type='core', plugin_type='action',
                                    plugin_name='pause')
    config_data_2.update_setting(core_plugin_setting_1)

# Generated at 2022-06-24 18:24:20.398325
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    assert config_data_0.get_setting('0') is None

    # test for global setting
    global_setting_0 = {'name': '0', 'description': ''}
    config_data_0.update_setting(global_setting_0)

    assert config_data_0.get_setting('0') == global_setting_0
    assert config_data_0.get_setting('1') is None

    # test for setting of specific plugin
    plugin_0 = {'type': 'test', 'name': 'test'}

    plugin_setting_0 = {'name': 'test_0', 'description': ''}
    config_data_0.update_setting(plugin_setting_0, plugin_0)


# Generated at 2022-06-24 18:24:21.078684
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    pass

# Generated at 2022-06-24 18:24:29.271288
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_setting_0 = ConfigSetting()
    config_setting_0.name = 'ansible'
    config_setting_0.value = 'awesome'
    config_setting_0.plugin = ConfigPlugin()
    config_setting_0.plugin.name = 'defaults'
    config_setting_0.plugin.type = 'default'

    assert config_setting_0.plugin.type == 'default'
    assert config_setting_0.plugin.name == 'defaults'
    config_data_1.update_setting(config_setting_0)

    assert config_data_1.get_settings(config_setting_0.plugin)[0].name == 'ansible'

# Generated at 2022-06-24 18:24:31.907243
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    print("get_settings: {}".format(config_data.get_settings()))


# Generated at 2022-06-24 18:24:41.087623
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(ConfigSetting('key1', 'value1', Plugin('hosts', 'hosts_file')))
    config_data_1.update_setting(ConfigSetting('key2', 'value2', Plugin('hosts', 'hosts_file')))
    config_data_1.update_setting(ConfigSetting('key1', 'value1', Plugin('hosts', 'hosts_file')))
    config_data_1.update_setting(None, None)
    config_data_1.update_setting(None, Plugin('plugins', 'plugins_directory'))
    config_data_1.update_setting(ConfigSetting('settings_file', '/home/users/user1/.ansible.cfg'), None)

# Generated at 2022-06-24 18:24:42.548306
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()



# Generated at 2022-06-24 18:24:47.245710
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('Name', 'value2'))

    assert config_data_1.get_settings()[0].name == 'Name'
    assert config_data_1.get_settings()[0].value == 'value2'


# Generated at 2022-06-24 18:24:51.586453
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-24 18:24:54.880974
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    from ansiblelint.rules import AnsibleLintRule
    plugin = AnsibleLintRule()
    assert plugin is not None
    config_data.update_setting(plugin)
