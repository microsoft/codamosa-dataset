

# Generated at 2022-06-24 18:15:03.982182
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting = config_data_1.get_setting('foo')
    assert setting is None

# Generated at 2022-06-24 18:15:09.471373
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_settings_0 = ConfigData('test_config_data_settings_0')
    assert config_data_settings_0.get_settings() == ['test_config_data_settings_0'], 'Expected value: ["test_config_data_settings_0"]'


# Generated at 2022-06-24 18:15:11.320764
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    assert config_data_1.get_setting("name") == None


# Generated at 2022-06-24 18:15:14.628974
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    env = test_case_0()
    update_setting(self, config_data_0)
    assert env.get_setting(name) == ''


# Generated at 2022-06-24 18:15:17.328333
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(None)
    config_data.update_setting(None)

# difflib.SequenceMatcher(None, 'a', None)

# Generated at 2022-06-24 18:15:19.948213
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    assert config_data_0.update_setting(0) is None, "config_data_0.update_setting(0) does not return None."


# Generated at 2022-06-24 18:15:21.465608
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.get_settings()


# Generated at 2022-06-24 18:15:23.156465
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:15:26.790226
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('setting_name', 'setting_value')
    config_data.update_setting(setting)
    setting_updated = config_data.get_setting(setting.name)
    assert setting.value == setting_updated.value


# Generated at 2022-06-24 18:15:30.075143
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    print('''
    unit test for get_settings method of ConfigData

    ''', sep='')
    test_case_0()

# Generated at 2022-06-24 18:15:35.748185
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting_0, plugin_1)
    config_data_0.update_setting(setting_1, plugin_1)


# Generated at 2022-06-24 18:15:37.654058
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()



# Generated at 2022-06-24 18:15:41.303751
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert config_data_1.get_settings() == []


# Generated at 2022-06-24 18:15:43.669277
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = None
    plugin_0 = None
    config_data_0.update_setting(setting_0, plugin_0)


# Generated at 2022-06-24 18:15:44.793997
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    pass


# Generated at 2022-06-24 18:15:49.028957
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting('travis_job_number') == None


# Generated at 2022-06-24 18:15:54.429821
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert_equal(config_data_0.get_setting("Ansible", Plugin("CLI", "")), None)
    assert_equal(config_data_0.get_setting("PLUGIN", Plugin("CLI", "")), None)
    assert_equal(config_data_0.get_setting("PLUGIN", Plugin("CLI", "Ansible")), None)


# Generated at 2022-06-24 18:16:03.699354
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import find_plugin
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.config.manager import ConfigManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader

    # Create a config data object
    # PlaybookExecutor creates an object of this class
    config_

# Generated at 2022-06-24 18:16:05.340717
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:16:07.268075
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:16:11.261750
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()


# Generated at 2022-06-24 18:16:21.567512
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_1 = Setting()
    plugin_2 = Plugin()
    setting_3 = Setting()
    plugin_4 = Plugin()
    setting_5 = Setting()
    plugin_6 = Plugin()
    setting_7 = Setting()
    plugin_8 = Plugin()
    setting_9 = Setting()
    plugin_10 = Plugin()
    setting_11 = Setting()
    plugin_12 = Plugin()
    setting_13 = Setting()
    plugin_14 = Plugin()
    setting_15 = Setting()
    plugin_16 = Plugin()
    setting_17 = Setting()
    plugin_18 = Plugin()
    setting_19 = Setting()
    plugin_20 = Plugin()
    setting_21 = Setting()
    plugin_22 = Plugin()
    setting_23 = Setting()
    plugin_24

# Generated at 2022-06-24 18:16:22.893801
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:16:29.984314
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("setting1", "plugin")
    if config_data._global_settings != []:
        raise Exception("ConfigData update_setting failed")


# Generated at 2022-06-24 18:16:38.031742
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()


# Generated at 2022-06-24 18:16:46.281845
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = Plugin(0, "plugin_0", "plugin_type_0")
    setting_0 = Setting(0, "setting_0")
    config_data_0.update_setting(setting_0, None)
    config_data_0.update_setting(setting_0, plugin_0)
    settings_0 = config_data_0.get_settings(plugin_0)
    assert len(settings_0) == 1


# Generated at 2022-06-24 18:16:55.370547
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    class Setting():
        def __init__(self):
            self.name = 'tag'
            self.section = 'abc'
            self.plugin = 'def'
            self.plugin_type = 'ghi'
            self.value = 'xyz'
            self.type = 'tuv'

    setting_0 = Setting()
    config_data_0.update_setting(setting_0)

    assert(config_data_0._global_settings.get('tag') is not None)



# Generated at 2022-06-24 18:17:05.833455
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class Plugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    plugin1 = Plugin('type1', 'name1')
    plugin2 = Plugin('type2', 'name2')
    config_data = ConfigData()

    setting1 = {'name': 'name1'}
    setting2 = {'name': 'name2'}

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting2, plugin1)

    settings = config_data.get_settings()
    assert len(settings) == 2
    assert settings[0]['name'] == 'name1'
    assert settings[1]['name'] == 'name2'

    settings = config_data.get_

# Generated at 2022-06-24 18:17:10.047068
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    global_setting_1 = Setting(name='VERBOSITY', default=0, choices=[0, 1, 2, 3], type='int', origin='default', scope='global', plugin_specific=False)
    config_data_0.update_setting(global_setting_1)
    r0 = config_data_0.get_settings()
    assert True

# Generated at 2022-06-24 18:17:13.521300
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    assert config_data_0.get_settings() == []
    assert config_data_0.get_settings().__len__() == 0


# Generated at 2022-06-24 18:17:29.004717
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('display_skipped_hosts', False, 'boolean')
    setting_1 = Setting('display_ok_hosts', False, 'boolean')
    setting_2 = Setting('stdout_callback', 'default', 'string')

    config_data_0.update_setting(setting_0)
    config_data_0.update_setting(setting_1)
    config_data_0.update_setting(setting_2)

    assert config_data_0._global_settings.get('stdout_callback') == setting_2
    assert config_data_0._global_settings.get('display_ok_hosts') == setting_1
    assert config_data_0._global_settings.get('display_skipped_hosts') == setting_0



# Generated at 2022-06-24 18:17:35.944512
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('core', 'ansible_config')
    setting_1 = Setting('core', 'ansible_managed')
    setting_2 = Setting('core', 'ansible_version')
    setting_3 = Setting('core', 'host_key_checking')
    setting_4 = Setting('core', 'pipelining')
    setting_5 = Setting('core', 'retry_files_enabled')
    setting_6 = Setting('core', 'roles_path')
    setting_7 = Setting('core', 'default_module_name')
    setting_8 = Setting('core', 'DEFAULT_KEEP_REMOTE_FILES')
    setting_9 = Setting('core', 'DEFAULT_REMOTE_TMP')

# Generated at 2022-06-24 18:17:43.407350
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    plugin_1 = Plugins()
    plugin_1.name = "name_1"
    plugin_1.type = "type_1"
    try:
        ret_1 = config_data_1.get_settings(plugin_1)
        assert isinstance(ret_1, list)
    except Exception as e:
        print("Exception in test case", str(e))



# Generated at 2022-06-24 18:17:44.437966
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:17:47.422294
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    # This method is just a stub, and should be removed before final release
    assert config_data_0._global_settings is None, \
        "The method get_settings in ConfigData is not implemented"


# Generated at 2022-06-24 18:17:50.741358
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = test_case_0()
    settings = config_data_0.get_settings()


# Generated at 2022-06-24 18:17:57.886406
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.get_settings()
    config_data_0.get_settings()
    config_data_0.get_settings()
    config_data_0.get_settings()
    config_data_0.get_settings()
    config_data_0.get_settings()
    config_data_0.get_settings()


# Generated at 2022-06-24 18:18:02.286228
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Initialize data
    config_data = ConfigData()
    setting_0 = Setting(name='setting_0', value=None) 

    # Execute edge cases
    config_data.update_setting(setting_0)

    # Execute nominal cases
    config_data.update_setting(setting_0)


# Generated at 2022-06-24 18:18:05.612326
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    assert config_data_1.get_setting(name='test') is None


# Generated at 2022-06-24 18:18:07.098549
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_1 = ConfigData()
    assert len(config_data_1.get_settings()) == 0


# Generated at 2022-06-24 18:18:26.090540
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    setting_1 = ConfigSetting('test_setting_1', '', '', '', '', '', None, True)
    config_data.update_setting(setting_1)

    setting_2 = ConfigSetting('test_setting_2', '', '', '', '', '', None, True)
    config_data.update_setting(setting_2)

    assert len(config_data._global_settings) == 2

    plugin = ConfigPlugin('callback', 'junit', None)
    setting_3 = ConfigSetting('test_setting_3', '', '', '', '', '', None, True)
    config_data.update_setting(setting_3, plugin)
    setting_4 = ConfigSetting('test_setting_4', '', '', '', '', '', None, True)


# Generated at 2022-06-24 18:18:27.766384
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:18:31.151595
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting() == None
    assert config_data_0.get_setting() == None
    assert config_data_0.get_setting() == None


# Generated at 2022-06-24 18:18:35.372546
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    setting_0 = ConfigSetting(name="test_setting", description="This is a test setting.", type="bool", default=True)
    config_data_0.update_setting(setting=setting_0)

    setting_1 = config_data_0.get_setting(name="test_setting")
    assert setting_1 == setting_0


# Generated at 2022-06-24 18:18:36.470232
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()


# Generated at 2022-06-24 18:18:40.416978
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test case 0:
    config_data_0 = ConfigData()
    setting_0 = AnsiblePluginSetting(name='crazy_name', value='foo')
    plugin_0 = AnsiblePlugin(type='blah', name='blahblah')
    config_data_0.update_setting(setting_0, plugin=plugin_0)
    output_0 = config_data_0.get_setting('crazy_name', plugin=plugin_0)
    assert output_0 == setting_0

# Generated at 2022-06-24 18:18:45.333018
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    print(config_data_1.get_settings(None))
    assert config_data_1.get_settings(None) == []


# Generated at 2022-06-24 18:18:49.456844
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('test_name', 'test_value'))
    assert config_data.get_setting('test_name') == 'test_value'


# Generated at 2022-06-24 18:18:53.352428
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(None)


# Generated at 2022-06-24 18:19:03.382369
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_setting_0 = ConfigSetting('setting-0')
    config_data_0.update_setting(config_setting_0)
    config_setting_1 = ConfigSetting('setting-1')
    config_data_0.update_setting(config_setting_1)
    config_setting_2 = ConfigSetting('setting-2')
    config_data_0.update_setting(config_setting_2)
    config_setting_3 = ConfigSetting('setting-3')
    config_data_0.update_setting(config_setting_3)
    config_setting_4 = ConfigSetting('setting-4')
    config_data_0.update_setting(config_setting_4)
    config_setting_5 = ConfigSetting('setting-5')
    config_data_0.update

# Generated at 2022-06-24 18:19:25.141899
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert type(config_data_0.get_settings()) is list


# Generated at 2022-06-24 18:19:31.376566
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_name_0', 'test_value_0', 'test_plugin_type_0', 'test_plugin_name_0', 'test_host_prefix_0')
    config_data.update_setting(setting)
    assert config_data._global_settings['test_name_0'].value == 'test_value_0'
    assert config_data._global_settings['test_name_0'].host_prefix == 'test_host_prefix_0'
    assert config_data._global_settings['test_name_0'].plugin_name == 'test_plugin_name_0'
    assert config_data._global_settings['test_name_0'].plugin_type == 'test_plugin_type_0'

# Generated at 2022-06-24 18:19:36.073798
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='default_comment_token', value='#', origin='defaults')
    config_data.update_setting(setting)
    assert config_data.get_setting('default_comment_token')



# Generated at 2022-06-24 18:19:38.612306
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()

    print(config_data_0.get_settings())


# Generated at 2022-06-24 18:19:41.982752
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(None, None)
    # Input params
    plugin = None
    setting_1 = None
    try:
        config_data_0.update_setting(setting_0, plugin, setting_1)
    except Exception as e:
        print(e.message)
    # Output params
    return setting_1

# Generated at 2022-06-24 18:19:43.178174
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test_case_0()



# Generated at 2022-06-24 18:19:51.891473
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()

    # Test get setting without global setting and plugin setting
    assert config_data_0.get_setting("nonsense") == None

    config_data_0.update_setting(ConfigSetting("global_setting", "global", "global_value"))
    assert config_data_0.get_setting("global_setting").value == "global_value"
    assert config_data_0.get_setting("nonsense") == None

    config_data_0.update_setting(ConfigSetting("plugin_setting", "plugin", "plugin_value"), Plugin(name="plugin_name", type="plugin_type"))
    assert config_data_0.get_setting("plugin_setting", Plugin(name="plugin_name", type="plugin_type")).value == "plugin_value"

    assert config_data_0.get

# Generated at 2022-06-24 18:19:54.863158
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(name=None) is None


# Generated at 2022-06-24 18:20:04.122799
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    for plugin in ['core', 'extras', 'collections']:
        for name in ['libcloud', 'ansible-modules-core']:
            plugin_setting = config_data.get_setting(name, plugin)
            assert plugin_setting == None
            plugin_settings = config_data.get_settings(plugin)
            assert plugin_settings == []

    for global_setting in ['self_contained_plugins', 'callback_plugins', 'action_plugins']:
        setting = config_data.get_setting(global_setting)
        assert setting == None
        settings = config_data.get_settings()
        assert settings == []



# Generated at 2022-06-24 18:20:05.761454
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    assert config_data_0.ge

# Generated at 2022-06-24 18:20:46.993340
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert ConfigData().get_settings() == [], "Test failed: ConfigData().get_settings() == []"


# Generated at 2022-06-24 18:20:50.970199
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = PluginDefinition()
    plugin_0.name = "Plugin_name"
    plugin_0.path = "Path"
    plugin_0.type = "Type"
    config_data_0.get_settings(plugin = plugin_0)


# Generated at 2022-06-24 18:20:52.214534
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:20:55.502686
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='test', defined_in='test')
    config_data_0.update_setting(setting_0, None)


# Generated at 2022-06-24 18:21:00.611934
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    # Try to get a setting that doesn't exist
    assert config_data_0.get_setting('bar') is None


# Generated at 2022-06-24 18:21:11.197915
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    from ansible.config.setting import Setting

    setting_1 = Setting('SOME_SETTING_NAME', 'SOME_SETTING_VALUE')
    config_data_0.update_setting(setting_1)
    assert config_data_0._global_settings['SOME_SETTING_NAME'] == setting_1

    from ansible.config.plugin import Plugin

    setting_2 = Setting('SOME_OTHER_SETTING_NAME', 'SOME_OTHER_SETTING_VALUE')
    plugin_3 = Plugin('SOME_PLUGIN_TYPE', 'SOME_PLUGIN_NAME')
    config_data_0.update_setting(setting_2, plugin_3)

# Generated at 2022-06-24 18:21:19.365658
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    result = None
    expected_results = None

    # First set of tests - add a global setting

    config_data_0 = ConfigData()
    assert config_data_0.get_setting('foo') is None

    config_data_0.update_setting(ConfigSetting('foo', 'global', 'bar'))
    assert config_data_0.get_setting('foo') is not None

    assert config_data_0.get_setting('foo').name == 'foo'
    assert config_data_0.get_setting('foo').plugin_type == 'global'
    assert config_data_0.get_setting('foo').plugin == None
    assert config_data_0.get_setting('foo').value == 'bar'

    # Second set of tests - add a setting to a plugin type

    config_data_0 = ConfigData()

# Generated at 2022-06-24 18:21:29.435691
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(test_Setting_0)
    assert config_data_0.get_setting(test_Setting_0.name) == test_Setting_0
    config_data_0.update_setting(test_Setting_1, plugin=test_Plugin_0)
    assert config_data_0.get_setting(test_Setting_1.name, plugin=test_Plugin_0) == test_Setting_1
    config_data_0.update_setting(test_Setting_2)
    assert config_data_0.get_setting(test_Setting_2.name) == test_Setting_2
    config_data_0.update_setting(test_Setting_3, plugin=test_Plugin_0)
    assert config_data_0.get_setting

# Generated at 2022-06-24 18:21:32.765893
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0._global_settings == {}
    assert config_data_0._plugins == {}


# Generated at 2022-06-24 18:21:35.176455
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:23:13.840568
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting())
    result = config_data_1.get_setting(None)
    assert( result is not None )


# Generated at 2022-06-24 18:23:16.696554
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global config_data_0, setting_0, plugin_0
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting_0, plugin_0)
    assert config_data_0._global_settings == {}
    assert config_data_0._plugins == {plugin_0.type: {plugin_0.name: {setting_0.name: setting_0}}}


# Generated at 2022-06-24 18:23:20.350179
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []
    assert config_data_0.get_settings(None) == []


# Generated at 2022-06-24 18:23:23.432737
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Create instance of ConfigData
    config_data_0 = ConfigData()
    # Call method get_settings of class ConfigData
    config_data_0.get_settings()



# Generated at 2022-06-24 18:23:26.339999
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting='setting_0')
    # get_setting(name, plugin)
    # assert config_data_0.get_setting() ==


# Generated at 2022-06-24 18:23:31.644898
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('test setting with plugin type', value='test value', plugin_type='action')
    config_data_0.update_setting(setting_0, plugin_0)


# Generated at 2022-06-24 18:23:40.500648
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # init
    config_data_0 = ConfigData()

    # global config
    setting = config_data_0.get_setting("test")
    assert setting is None

    setting = config_data_0.get_setting("test", "test_config")
    assert setting is None

    config_data_0.update_setting("test_setting", "test_config")
    setting = config_data_0.get_setting("test", "test_config")
    assert setting is not None

    assert setting.name == "test"
    assert setting.plugin_type == "test_config"
    assert setting.plugin_name == "test"
    assert setting.plugin_type == "plugin"
    assert setting.plugin_name == None
    assert setting.plugin_type == None
    assert setting.plugin_name == None

# Unit

# Generated at 2022-06-24 18:23:43.294316
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    # test_ConfigData_get_setting_0
    # Initialize ArgumentParser
    # Setup argument 0
    setting_0 = Setting()
    test_ConfigData_get_setting_0 = config_data_0.get_setting(setting_0)
    assert test_ConfigData_get_setting_0 is None

# Generated at 2022-06-24 18:23:44.760046
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert None == config_data_0.get_setting('')


# Generated at 2022-06-24 18:23:47.435443
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting('config_file', plugin='shell')
    config_data_1.update_setting('config_file', plugin='cli')

