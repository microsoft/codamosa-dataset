

# Generated at 2022-06-24 18:14:59.194448
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting()
    config_data.update_setting(plugin=None)


# Generated at 2022-06-24 18:15:05.053108
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_0 = Setting(name='setting_0', value='setting_0_value')
    plugin_0 = Plugin(type='action', name='action_0')
    config_data_1.update_setting(setting_0=setting_0, plugin=plugin_0)


# Generated at 2022-06-24 18:15:10.194976
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(None)
    config_data.update_setting(None, plugin=None)
    config_data.update_setting(None, plugin=None)
    config_data.update_setting(None, plugin=None)


# Generated at 2022-06-24 18:15:13.006169
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting(name='a', value='a'))
    assert config_data_1.get_setting('a') == Setting(name='a', value='a')



# Generated at 2022-06-24 18:15:15.778295
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(setting=None, plugin=None)


# Generated at 2022-06-24 18:15:21.088879
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    plugin_0 = Plugin(None, "Unnamed Plugin")
    setting_0 = Setting(None, 6)
    config_data_0.update_setting(setting_0, plugin_0)


# Generated at 2022-06-24 18:15:23.460978
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting="setting", plugin=None)


# Generated at 2022-06-24 18:15:25.752955
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert config_data_0.get_settings() == []
    assert config_data_0.get_settings(plugin=plugin_1) == []

# Generated at 2022-06-24 18:15:30.279690
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting, plugin=None)
    assert config_data_0._global_settings == {'setting': setting}


# Generated at 2022-06-24 18:15:39.866828
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global config_data
    config_data = test_case_0()
    # Test updating a global setting
    setting = {'name': 'test', 'default': True, 'desc': 'test', 'type': 'boolean'}
    config_data.update_setting(setting)
    assert config_data.get_setting('test') == setting
    # Test updating a plugin setting
    setting = {'name': 'test', 'default': True, 'desc': 'test', 'type': 'boolean'}
    config_data.update_setting(setting, {'type': 'network', 'name': 'napalm'})
    assert config_data.get_setting('test', {'type': 'network', 'name': 'napalm'}) == setting

# Generated at 2022-06-24 18:15:44.699572
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = config_data_0.get_setting(None, None)


# Generated at 2022-06-24 18:15:54.962500
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Create a ConfigData object and check that the it contains a global section,
    # and no plugins.
    config_data_0 = ConfigData()
    assert(config_data_0._global_settings)
    assert(not config_data_0._plugins)

    # Check that there are no settings in the global config section when the
    # ConfigData object is first created.
    assert(not config_data_0._global_settings)

    # Create a new setting and check that it is saved in the global section
    # of the ConfigData object.
    config_data_0.update_setting("foo")
    assert("foo" in config_data_0._global_settings)


# Generated at 2022-06-24 18:15:58.256776
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    print(config_data_0.get_settings())


# Generated at 2022-06-24 18:16:04.314940
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    assert callable(ConfigData.get_setting)
    config_data_0 = ConfigData()
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()
    config_data_3 = ConfigData()
    # Make sure input is working correctly
    try:
        config_data_0.get_setting()
        raise AssertionError
    except TypeError: pass
    # Test no plugin found
    assert not config_data_1.get_setting('foo')
    # Test global plugin
    assert not config_data_2._global_settings.get('foo')
    setting_0 = PluginSetting('foo', 'bar', 'global', 'global')
    config_data_2.update_setting(setting_0)
    assert config_data_2.get_setting('foo') == config_data_2

# Generated at 2022-06-24 18:16:06.040758
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() is not None



# Generated at 2022-06-24 18:16:08.374853
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    result = config_data_0.get_setting(name=None, plugin=None)


# Generated at 2022-06-24 18:16:10.023315
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:16:11.825382
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting('')


# Generated at 2022-06-24 18:16:13.971136
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings = config_data_0.get_settings()

    assert settings == []


# Generated at 2022-06-24 18:16:21.951964
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting_0 = Setting('test1', 'test-type')
    setting_1 = Setting('test2', 'test-type')
    setting_2 = Setting('test3', 'test-type')

    config_data_1.update_setting(setting_0)
    config_data_1.update_setting(setting_1)
    config_data_1.update_setting(setting_2, Plugin('test-plugin', 'test-type'))

    assert config_data_1.get_setting('test1') == setting_0


# Generated at 2022-06-24 18:16:27.905433
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    # Test when getting global settings
    assert config_data_1.get_setting('FORKS') == None


# Generated at 2022-06-24 18:16:37.172839
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()
    config_data_1.update_setting(
        'default_stdout_callback')
    config_data_1.update_setting(
        'connection_debug')
    config_data_1.update_setting(
        'tasks_for_debug')
    config_data_1.update_setting(
        'stdout_lines_for_debug')

    config_data_2 = ConfigData()
    config_data_2.update_setting(
        'default_stdout_callback',
        'callbacks')
    config_data_2.update_setting(
        'enable_vebosity',
        'callbacks')
    config_data_2.update_setting(
        'connection_debug')

# Generated at 2022-06-24 18:16:48.282878
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    config_data.update_setting(Setting(name='TestSetting1', value='TestValue1', namespace='TestNamespace1'))
    config_data.update_setting(Setting(name='TestSetting2', value='TestValue2', namespace='TestNamespace1'))
    config_data.update_setting(Setting(name='TestSetting3', value='TestValue3', namespace='TestNamespace1'))

    assert config_data.get_setting('TestSetting1') == Setting(name='TestSetting1', value='TestValue1', namespace='TestNamespace1')
    assert config_data.get_setting('TestSetting2') == Setting(name='TestSetting2', value='TestValue2', namespace='TestNamespace1')

# Generated at 2022-06-24 18:16:55.057067
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()

    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.nso.setting import Setting
    setting_0 = Setting(name='setting_name_0', value='setting_value_0')
    config_data_1.update_setting(setting_0)

    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils import to_list
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.nso.plugin import Plugin
    plugin_0 = Plugin(type='plugin_type_0', name='plugin_name_0', version='plugin_version_0')

# Generated at 2022-06-24 18:17:05.699757
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    from ansiblelint.rules.DjangoSettingsEnv import DjangoSettingsEnv
    plugin_1 = DjangoSettingsEnv(config_data_1)

    from ansiblelint.rules.DjangoSettingsSecret import DjangoSettingsSecret
    plugin_2 = DjangoSettingsSecret(config_data_1)

    # _global_settings
    config_data_1.update_setting(DjangoSettingsEnv.Setting("debug", "true"))
    assert config_data_1._global_settings["debug"].name == "debug"
    assert config_data_1._global_settings["debug"].value == "true"

    # _plugins
    assert plugin_1.name in config_data_1._plugins[plugin_1.type]

# Generated at 2022-06-24 18:17:09.286747
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    with pytest.raises(Exception) as exception_info:
        config_data_0.update_setting(None)
    assert exception_info.type == TypeError
    assert str(exception_info.value) == "expected setting to be of type 'Setting', got None"


# Generated at 2022-06-24 18:17:12.929647
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    expected_value = []
    actual_value = config_data_0.get_settings()
    assert actual_value == expected_value


# Generated at 2022-06-24 18:17:15.763004
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    case_0 = test_case_0()
    case_0.update_setting(case_0)
    # Assert settings is updated
    assert case_0.update_setting(case_0)


# Generated at 2022-06-24 18:17:17.641289
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    x = config_data_0.get_settings()
    assert not x


# Generated at 2022-06-24 18:17:26.738602
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = Plugin(type='C', name='A')
    setting_0 = Setting(name='A', description='A', value='A')
    config_data_0.update_setting(setting_0, plugin_0)
    setting_1 = Setting(name='B', description='B', value='B')
    config_data_0.update_setting(setting_1, plugin_0)
    config_data_0.get_settings(plugin_0)



# Generated at 2022-06-24 18:17:43.801332
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Test config_data_1 with this method
    config_data_1 = ConfigData()
    setting_1 = {'name': 'food', 'default': 'vegan'}
    config_data_1.update_setting(setting_1)

    setting_2 = {'name': 'drink', 'default': 'vodka'}
    config_data_1.update_setting(setting_2)

    setting_3 = {'name': 'transport', 'default': 'train'}
    config_data_1.update_setting(setting_3)

    config_data_1.get_settings()

    # Test config_data_2 with this method
    config_data_2 = ConfigData()
    setting_1 = {'name': 'food', 'default': 'vegan'}

# Generated at 2022-06-24 18:17:48.880349
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    """
    Assert that get_setting returns the correct setting

    """
    config_data_0 = ConfigData()
    global_setting_0 = GlobalSetting(name='display_skipped_hosts', value=True, origin='ansible.cfg')
    config_data_0.update_setting(global_setting_0)

    assert isinstance(config_data_0.get_setting(name='display_skipped_hosts'), GlobalSetting)
    assert config_data_0.get_setting(name='display_skipped_hosts').value is True


# Generated at 2022-06-24 18:17:56.979985
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    plugin_1 = Plugin("module", "copy")
    setting_1 = Setting("ANSIBLE_COPY_REMOTE_TMP", "remote_tmp")
    config_data_1.update_setting(setting_1, plugin_1)
    print(config_data_1.get_setting("ANSIBLE_COPY_REMOTE_TMP", plugin_1))



# Generated at 2022-06-24 18:18:02.451602
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Setup
    config_data_0 = ConfigData()
    config_data_0._global_settings = {}
    config_data_0._plugins = {}
    setting = Setting(name='Name', type=None, value=None)
    plugin = Plugin(type='Type', name='Name')

    # Test execution
    config_data_0.update_setting(setting=setting, plugin=plugin)



# Generated at 2022-06-24 18:18:04.450226
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata_0 = ConfigData()
    setting = ConfigData.Setting('setting_1')
    configdata_0.update_setting(setting)


# Generated at 2022-06-24 18:18:06.154546
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert type(config_data._global_settings) is dict


# Generated at 2022-06-24 18:18:11.885133
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()

    config_data_0.update_setting( Setting(name='linter_disable_warnings', value='*'), Plugin(type='linter', name='docstyle') )

    assert config_data_0.get_setting('linter_disable_warnings', Plugin('linter', 'docstyle')) == Setting('linter_disable_warnings', ['*'])


# Generated at 2022-06-24 18:18:13.819589
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(None)


# Generated at 2022-06-24 18:18:15.013988
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:18:16.870940
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert isinstance(config_data_0.get_setting('name'), None)


# Generated at 2022-06-24 18:18:23.951509
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()


# Generated at 2022-06-24 18:18:26.652568
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Test cases
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:18:28.670453
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    data._update_setting()
    assert data._update_setting() == None


# Generated at 2022-06-24 18:18:33.267335
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data_update_setting_1 = ConfigData()
    config_data_update_setting_2 = ConfigData()
    config_data.update_setting(config_data_update_setting_1)
    config_data.update_setting(config_data_update_setting_2)

# Generated at 2022-06-24 18:18:37.677390
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting("pitying", plugin="promotion")
    config_data_0.update_setting("pitying", plugin="promotion")
    config_data_0.get_setting("pitying")

# Generated at 2022-06-24 18:18:38.938255
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting()


# Generated at 2022-06-24 18:18:41.714438
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Create an instance of Context for testing.
    config_data_0 = ConfigData()



# Generated at 2022-06-24 18:18:44.737179
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    assert(config_data_0.get_setting('test') is None)


# Generated at 2022-06-24 18:18:48.872809
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    config_data_0.update_setting({"key": "foo"})

    assert config_data_0._global_settings["foo"] == {"key": "foo"}


# Generated at 2022-06-24 18:18:54.679932
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting(name='test_setting', value='test_value'))
    assert(len(config_data_1.get_settings()) == 1)


# Generated at 2022-06-24 18:19:00.101041
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()
    retVal = configData.get_settings()
    assert retVal is None


# Generated at 2022-06-24 18:19:01.567230
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting="setting")

# Generated at 2022-06-24 18:19:05.995809
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert hasattr(config_data_0, "get_settings")
    assert callable(config_data_0.get_settings)


# Generated at 2022-06-24 18:19:09.018253
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting = Setting('some_setting', '/path/to/file')
    config_data_1.update_setting(setting, plugin=Plugin('file_finder', 'action'))


# Generated at 2022-06-24 18:19:10.431772
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()


# Generated at 2022-06-24 18:19:13.010145
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    assert config_data.get_settings(plugin=None) == []


# Generated at 2022-06-24 18:19:21.272372
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    # Check that object returned is of type list
    assert isinstance(config_data_0.get_settings(), list)
    # Check that a list is returned if plugin is not provided
    assert len(config_data_0.get_settings()) == 0
    # Check that a list is returned if plugin is not provided
    config_data_0.update_setting(Setting("foo", "foo", "value", "", "int", "doc"))
    assert len(config_data_0.get_settings()) == 1
    # Check that a list is returned if plugin is provided
    plugin_0 = Plugin("foo", "action", "value", "", "doc")

# Generated at 2022-06-24 18:19:22.569024
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting('test')
    assert True == True


# Generated at 2022-06-24 18:19:25.668075
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None, plugin=None)
    env_vars_0 = config_data_0.get_settings(plugin=None)
    assert set(env_vars_0) == set([None])

# Generated at 2022-06-24 18:19:31.148794
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data._global_settings = {}
    config_data._plugins = {}
    """Test for updating global setting"""
    config_data.update_setting(Setting(name='test', value='test_value'))
    assert config_data._global_settings['test'].value == 'test_value'

    """Test for updating plugin setting"""
    config_data._plugins['vars'] = {}
    config_data.update_setting(Setting(name='test', value='test_value'), Plugin(type='vars', name='main'))
    assert config_data._plugins['vars']['main']['test'].value == 'test_value'


# Generated at 2022-06-24 18:19:39.552795
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='strict', value=False, category='defaults')
    config_data_0.update_setting(setting_0)


# Generated at 2022-06-24 18:19:49.380629
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from yaml import safe_load
    from ansible.plugins.loader import collection_loader

    test_case_0()
    test_case_1()

    settings = [
        'ansible.cfg',
        '~/.ansible.cfg',
        './ansible.cfg'
    ]

    config_data = ConfigData()

    for setting in settings:
        config_data.update_setting(setting)

    if config_data.get_setting('ansible.cfg') is None:
        return

    plugin_loader = collection_loader.get('vars.yaml')

    if plugin_loader is None:
        return 

    plugin_loader.add_directory(path='/dev/null')
    plugin = plugin_loader.get_plugin('')


# Generated at 2022-06-24 18:19:58.156860
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    from ansible.module_utils.config_loader import ConfigManager, Setting

    plugin_0 = ConfigManager.Plugin('test', 'config_manager', 'test_0_type', 'test_0_name')
    setting_0 = Setting('test_setting_0')
    config_data.update_setting(setting_0, plugin_0)

    setting_0_retrieved = config_data.get_setting('test_setting_0', plugin_0)
    assert setting_0_retrieved is setting_0



# Generated at 2022-06-24 18:20:04.428211
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(name = None, plugin = None) is None
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(name = "abc", plugin = None) is None
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(name = "abc", plugin = None) is None
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(name = "abc", plugin = None) is None


# Generated at 2022-06-24 18:20:15.256659
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = BasePlugin('test_type', 'test_name')
    # Test with a negative value for parameter plugin
    assert config_data_0.get_settings(plugin=-1) == []
    # Test with a positive value for parameter plugin
    assert config_data_0.get_settings(plugin=plugin_0) == []
    setting_0 = Setting('test_setting', 'test_value')
    config_data_0.update_setting(setting_0, plugin_0)
    # Test with a negative value for param plugin and a positive value for parameter name
    assert config_data_0.get_settings(plugin=plugin_0) == [setting_0]
    # Test with a positive value for parameter plugin and a negative value for parameter name
    assert config_data_0.get_

# Generated at 2022-06-24 18:20:18.940069
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting('incoming')
    assert config_data_0._global_settings == {'incoming': 'incoming'}


# Generated at 2022-06-24 18:20:21.778472
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('display-skipped-hosts', 'onfail')
    config_data_0.update_setting(setting_0, 'yum')


# Generated at 2022-06-24 18:20:24.051583
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('ansible_python_interpreter', '', '', '', None, None))


# Generated at 2022-06-24 18:20:28.302576
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting_0 = ConfigSetting.ConfigSetting()
    setting_0.name = 'name_0'
    setting_0.default = 'default_0'
    setting_0.path = 'path_0'
    setting_0.section = 'section_0'
    # Call method e.g. config_data_0.update_setting(setting_0)


# Generated at 2022-06-24 18:20:30.217707
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:20:40.492899
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Instance of the plugin
    plugin = Plugin(type="__init__")

    # Instance of the Configuration setting
    config_setting = Configuration(name="__init__.py")

    config_data_1 = ConfigData()
    config_data_1.update_setting(config_setting, plugin=plugin)
    setting = config_data_1.get_setting("__init__.py", plugin=plugin)
    assert(setting is not None)
    assert(setting.name == "__init__.py")
    assert(setting.plugin.type == "__init__")



# Generated at 2022-06-24 18:20:45.494181
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test with a global setting
    config_data_1 = ConfigData()
    assert len(config_data_1.get_settings()) == 0
    config_data_1.update_setting(Setting(name="max_processes", value=2))
    assert len(config_data_1.get_settings()) == 1

    # Test with a plugin setting
    config_data_2 = ConfigData()
    assert len(config_data_2.get_settings()) == 0
    config_data_2.update_setting(Setting(name="max_processes", value=2), Plugin(name="x", type="a"))
    assert len(config_data_2.get_settings()) == 0

# Generated at 2022-06-24 18:20:48.493971
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting = 'kind'
    plugin = 'Config'
    config_data_1.update_setting(setting, plugin)


# Generated at 2022-06-24 18:20:50.257329
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(object())


# Generated at 2022-06-24 18:20:54.505961
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting = Setting('foo', 'bar')
    config_data_1.update_setting(setting)
    assert config_data_1._global_settings['foo'] == setting
    print("Testcase: ConfigData_update_setting passed")


# Generated at 2022-06-24 18:20:58.811328
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    config_data_1.update_setting('setting_0', plugin=None)
    assert 'setting_0' in config_data_1._global_settings



# Generated at 2022-06-24 18:21:01.659728
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = test_case_0()
    passed_settings = config_data_0.get_settings(plugin=None)
    assert True

# Generated at 2022-06-24 18:21:11.231130
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    
    # Global settings
    global_setting_0 = ConfigSetting('test_name', 
                                     'test_type', 
                                     'test_default', 
                                     'test_description',
                                     'test_applies',
                                     'test_env')
    global_setting_1 = ConfigSetting('test_name_1', 
                                     'test_type_1', 
                                     'test_default_1', 
                                     'test_description_1',
                                     'test_applies_1',
                                     'test_env_1')
    
    config_data_0.update_setting(global_setting_0)
    config_data_0.update_setting(global_setting_1)
    
    assert len(config_data_0.get_settings()) == 2
    
# Unit test

# Generated at 2022-06-24 18:21:16.233223
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == [], "Returned: " + str(config_data_0.get_settings())


# Generated at 2022-06-24 18:21:19.202093
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name=None, value=None, origin=None, plugin=None)
    config_data_0.update_setting(setting_0)


# Generated at 2022-06-24 18:21:25.320920
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    global config_data_0
    config_data_1 = ConfigData()

    assert len(config_data_1.get_settings()) == 0


# Generated at 2022-06-24 18:21:26.835244
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:21:35.035479
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(GlobalSetting(name='ansible_managed', value='Test Ansible Management'))
    config_data_1.update_setting(GlobalSetting(name='become_method', value='sudo'))
    assert 'Test Ansible Management' == config_data_1.get_setting('ansible_managed').value
    assert 'sudo' == config_data_1.get_setting('become_method').value


# Generated at 2022-06-24 18:21:38.419367
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    plugin = Plugin(type, name)
    name = str()
    result = config_data_0.get_setting(name, plugin)
    assert result is None


# Generated at 2022-06-24 18:21:50.725326
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    # Should return an empty list
    settings = config_data_0.get_settings(None)
    assert len(settings) == 0

    config_data_0.update_setting(Setting("name", "value"))
    config_data_0.update_setting(Setting("name1", "value0"))
    config_data_0.update_setting(Setting("name2", "value1"))
    settings = config_data_0.get_settings(None)
    assert len(settings) == 3
    assert settings[0].name == "name" and settings[0].value == "value"
    assert settings[1].name == "name1" and settings[1].value == "value0"
    assert settings[2].name == "name2" and settings[2].value == "value1"

# Generated at 2022-06-24 18:21:55.620631
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    with pytest.raises(TypeError):
        config_data_0.get_settings(plugin=3)



# Generated at 2022-06-24 18:22:04.215743
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Expectations for global setting
    setting_0 = config_data.get_setting('name_0')
    assert setting_0 is None
    setting_1 = config_data.get_setting('name_1')
    assert setting_1 is None

    # Expectations for plugin setting
    setting_0 = config_data.get_setting('name_0', None)
    assert setting_0 is None
    setting_1 = config_data.get_setting('name_1', None)
    assert setting_1 is None

    # Expectations for plugin setting
    setting_0 = config_data.get_setting('name_0',0)
    assert setting_0 is None
    setting_1 = config_data.get_setting('name_1',0)
    assert setting_1 is None


# Generated at 2022-06-24 18:22:09.541389
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Test for global setting
    config_data.update_setting(Setting(name="ansible_host_key_checking", value="False"))

    assert config_data.get_settings()[0].value == "False"

    # Test for plugin
    plugin = Plugin(name="setup", type="module")
    config_data.update_setting(Setting(name="gather_timeout", value="10"), plugin=plugin)

    assert config_data.get_settings(plugin=plugin)[0].value == "10"


# Generated at 2022-06-24 18:22:12.119095
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    test_ConfigData_update_setting_0(config_data_0)



# Generated at 2022-06-24 18:22:15.035817
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:22:35.884881
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin = Plugin()
    global_setting = Setting(name='name_0', value='somedata_0', plugin=plugin)
    settings = PluginSettings()
    plugin_setting = Setting(name='name_1', value='somedata_1', plugin=plugin)
    settings.add(plugin_setting)
    config_data_0.update_setting(global_setting)
    config_data_0.update_settings(settings)
    actual = config_data_0.get_settings()
    expected = [global_setting, plugin_setting]
    assert actual == expected


# Generated at 2022-06-24 18:22:39.621336
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Create an instance of ConfigData
    config_data_0 = ConfigData()
    # Create an instance of ConfigSetting
    config_setting_0 = ConfigSetting()
    # Update the ConfigSetting in the ConfigData instance
    config_data_0.update_setting(config_setting_0)


# Generated at 2022-06-24 18:22:44.229805
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting_0 = Setting(None, None, None, None, None)
    setting_0.value = True
    setting_0.name = 'verbosity'
    setting_0.scope = 'global'
    setting_0.origin = 'user'
    config_data_0.update_setting(setting_0)
    config_data_0.get_settings()

# Generated at 2022-06-24 18:22:49.730503
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
   
    config_data_0 = ConfigData()

    assert config_data_0.get_setting(name=None) == None
    assert config_data_0.get_setting(plugin=None) == None
    assert config_data_0.get_setting(plugin=None, name=None) == None


# Generated at 2022-06-24 18:22:54.285265
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    setting_0 = Setting(name='foo', value='wibble', scope='filter')
    config_data_0.update_setting(setting_0)
    assert setting_0 == config_data_0.get_setting('foo')

    setting_1 = Setting(name='bar', value='spam', scope='plugin', plugin_name='local_action', plugin_type='action')
    config_data_0.update_setting(setting_1)
    assert setting_1 == config_data_0.get_setting('bar', Plugin('local_action', 'action'))


# Generated at 2022-06-24 18:22:58.082808
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Setup test fixture
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None,plugin=None)
    assert config_data_0._global_settings == {None}


# Generated at 2022-06-24 18:23:00.947631
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert (config_data_0.get_setting(name=None, plugin=None) is None)


# Generated at 2022-06-24 18:23:07.183925
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint.rules.lineinfile.EnsureTrailingNewlineRule import ConfigData
    from ansiblelint.rules.lineinfile.EnsureTrailingNewlineRule import Setting
    from ansiblelint.rules.lineinfile.EnsureTrailingNewlineRule import Plugin

    config_data_1 = ConfigData()
    setting = Setting('KEY1', 'VALUE1')
    plugin = Plugin(type='COLLECTION', name='ansible_collections.ansible.builtin')

    config_data_1.update_setting(setting)
    config_data_1.update_setting(setting, plugin)

    assert config_data_1._global_settings['KEY1'].value == 'VALUE1'

# Generated at 2022-06-24 18:23:08.386409
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Perform test
    config_data_0 = ConfigData()

# Generated at 2022-06-24 18:23:09.682460
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    """Get setting for a particular plugin"""
    pass


# Generated at 2022-06-24 18:23:22.612700
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    
    # Testing global settings
    for setting in config_data_1._global_settings:
        assert setting in config_data_1.get_settings()


# Generated at 2022-06-24 18:23:28.953032
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    s = Setting('a', 'b', 'c', 'd')
    cd.update_setting(s)
    s = Setting('a', 'b', 'c', 'e')
    cd.update_setting(s, Plugin('a', 'b'))
    s = Setting('a', 'b', 'c', 'e')
    cd.update_setting(s, Plugin('a', 'b'))
    s = Setting('a', 'b', 'c', 'd')
    cd.update_setting(s)


# Generated at 2022-06-24 18:23:39.787877
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1._global_settings['ANSIBLE_ROLES_PATH'] = '1'
    config_data_1._plugins['inventory'] = {'test': {'option_a': '1'}}
    config_data_1._plugins['cache'] = {'test': {'option_b': '2'}}
    config_data_1._plugins['strategy'] = {'test': {'option_c': '3'}}
    config_data_1._plugins['callback'] = {'test': {'option_d': '4'}}
    config_data_1._plugins['vars_loader'] = {'test': {'option_e': '5'}}

# Generated at 2022-06-24 18:23:48.029515
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='a', default='a', choices=['', 'a', 'b'], description='a', type='a', aliases=['a'])
    config_data_0.update_setting(setting=setting_0)
    # Test for failure for branch coverage
    assert config_data_0._global_settings['a'] == setting_0
    assert config_data_0.get_setting(name='a') == setting_0
    assert config_data_0._global_settings['a'] == setting_0

    plugin_0 = Plugin(type='a', name='a')
    config_data_0.update_setting(setting=setting_0, plugin=plugin_0)
    # Test for failure for branch coverage

# Generated at 2022-06-24 18:23:55.741905
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test with no plugin
    conf_data_0 = ConfigData()
    conf_data_0.update_setting( Setting("setting_0", "some value"))
    assert conf_data_0.get_setting("setting_0") == 'some value', \
        "Expected `some value`"
    conf_data_0.update_setting( Setting("setting_1", "value: {{ value_0 }}"))
    assert conf_data_0.get_setting("setting_1") == 'value: {{ value_0 }}', \
        "Expected `value: {{ value_0 }}`"

    # Test with plugin
    conf_data_0.update_setting( Setting("setting_0", "some other value"), plugin=Plugin("plugin_type_0", "plugin_0"))

# Generated at 2022-06-24 18:24:07.550315
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='unittest_0', value='value_0', priority=0)
    plugin_0 = Plugin(type='type_0', name='name_0')
    setting_1 = Setting(name='unittest_1', value='value_1', priority=1)
    plugin_1 = Plugin(type='type_1', name='name_1')
    config_data_0.update_setting(setting_0)
    config_data_0.update_setting(setting_1, None)
    config_data_0.update_setting(setting_0, plugin_0)
    config_data_0.update_setting(setting_1, plugin_1)

# Generated at 2022-06-24 18:24:10.233978
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings = config_data_0.get_settings()
    assert len(settings) is 0


# Generated at 2022-06-24 18:24:20.939826
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    plugin_type_1 = "connection"
    plugin_name_1 = "winrm"
    name_1 = "vault_password_file"
    short_name_1 = "vault_password_file"
    default_1 = "~/.vault_pass.txt"
    env_1 = ["ANSIBLE_VAULT_PASSWORD_FILE"]
    ini_1 = ["vault_password_file"]
    version_added_1 = "1.6"
    ini_1 = {'env': 'ANSIBLE_VAULT_PASSWORD_FILE', 'ini': 'vault_password_file', 'name': 'vault_password_file', 'type': 'path', 'version_added': '1.6', 'required': False}

# Generated at 2022-06-24 18:24:23.096209
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-24 18:24:30.316850
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    plugin_0 = MockPlugin()
    plugin_0.name = "ping"
    plugin_0.type = "connection"

    plugin_1 = MockPlugin()
    plugin_1.name = "shell"
    plugin_1.type = "shell"

    plugin_2 = MockPlugin()
    plugin_2.name = "ping"
    plugin_2.type = "shell"

    plugin_3 = MockPlugin()
    plugin_3.name = "shell"
    plugin_3.type = "connection"

    setting_0 = MockSetting()
    setting_0.name = "foo"
    setting_0.value = "bar"

    config_data_0.update_setting(setting_0)