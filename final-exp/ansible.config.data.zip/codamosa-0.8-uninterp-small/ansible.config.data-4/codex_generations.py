

# Generated at 2022-06-24 18:15:07.744726
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    global_setting_1 = GlobalSetting('display.width', '80')
    config_data_1.update_setting(global_setting_1)
    assert config_data_1.get_setting('display.width').value == '80'


# Generated at 2022-06-24 18:15:10.825833
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting("insert")
    setting0 = config_data_0.get_setting("insert")
    assert False


# Generated at 2022-06-24 18:15:19.084920
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible import constants as C
    from ansible.constants import load_config_file
    config_data = ConfigData()
    load_config_file(config_data)
    for plugin_name, plugin_info in C.PLUGIN_PATH_SETTINGS.items():
        if plugin_name in ['callback', 'lookup', 'vars_plugins']:
            continue
        settings = config_data.get_settings()
        assert len(settings) != 0


# Generated at 2022-06-24 18:15:22.339488
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    test_1 = config_data_1.get_settings()
    assert test_1 == []
    test_2 = config_data_1.get_settings(None)
    assert test_2 == []
    test_3 = config_data_1.get_settings(None)
    assert test_3 == []

# Generated at 2022-06-24 18:15:23.731631
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings = ConfigData().get_settings()
    assert isinstance(settings, list)


# Generated at 2022-06-24 18:15:28.922900
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='foo', value=['value1', 'value2'], origin='foo', plugin=Plugin(type='bar', name='baz'))
    config_data_0.update_setting(setting_0, plugin=Plugin(type='bar', name='baz'))
    setting_1 = Setting(name='foo', value='value1', origin='foo', plugin=Plugin(type='bar', name='baz'))
    config_data_0.update_setting(setting_1)


# Generated at 2022-06-24 18:15:33.769348
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # CASE 0
    plugin = None
    setting_name = 'foo'
    result = config_data.get_setting(setting_name)
    assert result is None

    # CASE 1
    plugin = MockPlugin('module', 'ping')
    setting_name = 'foo'
    result = config_data.get_setting(setting_name, plugin)
    assert result is None

    # CASE 2
    plugin = MockPlugin('module', 'ping')
    setting_name = 'foo'
    config_data.update_setting(MockSetting(setting_name, plugin))
    result = config_data.get_setting(setting_name, plugin)
    assert result.name == setting_name

    # CASE 3
    plugin = None
    setting_name = 'foo'
    config_data.update

# Generated at 2022-06-24 18:15:35.307190
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_case_0()


# Generated at 2022-06-24 18:15:41.224391
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting)
    assert config_data_0.get_setting(setting.name).name == setting.name
    assert config_data_0.get_setting(setting.name).value == setting.value


# Generated at 2022-06-24 18:15:46.785455
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    # Create an instance of a configuration setting
    setting_0 = plugin_settings.Setting("test_name_0", "test_desc_0", "test_default_value_0", "test_choice_values_0")
    # Create an instance of a plugin
    plugin_0 = plugins.Plugin("test_type_0", "test_name_0")
    # Update the configuration setting using the config data API
    config_data_1.update_setting(setting_0, plugin_0)
    assert config_data_1.get_setting("test_name_0", plugin_0) == setting_0

# Generated at 2022-06-24 18:15:52.825203
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_1 = ConfigData()
    setting_1 = Setting('0', 'name', 'description', 'str', 'default', 'config')
    config_data_1.update_setting(setting_1)
    assert config_data_1.get_setting('name') == setting_1


# Generated at 2022-06-24 18:15:54.719706
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = None
    settings = config_data.get_settings(plugin)


# Generated at 2022-06-24 18:15:58.981974
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    setting1 = Setting(name='url', default='https://localhost/api')
    setting2 = Setting(name='username', default='admin')
    setting3 = Setting(name='password', default='admin')

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting3)



# Generated at 2022-06-24 18:16:01.794918
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    # Global settings add.
    config_data_0.update_setting(Setting("no_log", "default", "yes", True))
    assert config_data_0.get_setting("no_log") is not None


# Generated at 2022-06-24 18:16:05.235927
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # initialize a ConfigData instance
    config_data = ConfigData()

    # discuss the cases when plugin is None
    assert config_data.get_settings() == []

    # discuss the cases when plugin is not None
    assert config_data.get_settings(plugin="test_plugin") == []


# Generated at 2022-06-24 18:16:15.848061
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()

# Generated at 2022-06-24 18:16:23.486463
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Test case 0
    config_data_0 = ConfigData()
    config_setting_0 = ConfigSetting()
    config_setting_0.name = "name"
    config_setting_0.value = "value"
    config_setting_0.description = "description"
    config_setting_0.win_reboot_required = True
    config_setting_0.mac_reboot_required = True
    config_setting_0.linux_reboot_required = True
    setting = config_data_0.get_setting(config_setting_0.name)
    assert setting is None


# Generated at 2022-06-24 18:16:27.729056
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting('setting')
    assert config_data._global_settings == {'setting': 'setting'}


# Generated at 2022-06-24 18:16:32.517018
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    actual_result_0 = config_data_0.get_setting('name', 'plugin')

    assert actual_result_0 is None, 'Expected result is None but actual result is %s.' % actual_result_0


# Generated at 2022-06-24 18:16:35.511417
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = Setting()
    setting.name = "foo"
    config_data.update_setting(setting)
    config_data.get_settings()


# Generated at 2022-06-24 18:16:40.164097
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    config_data_0.get_setting(name='var_name_0')



# Generated at 2022-06-24 18:16:42.946689
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    str_0 = config_data_0.get_settings()


# Generated at 2022-06-24 18:16:47.055935
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()


# Generated at 2022-06-24 18:17:00.169794
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting0_0 = Setting(name='setting0_0', plugin=None, value=None)
    config_data_1.update_setting(setting=setting0_0, plugin=None)
    setting0_1 = Setting(name='setting0_1', plugin=None, value=None)
    config_data_1.update_setting(setting=setting0_1, plugin=None)
    setting0_2 = Setting(name='setting0_2', plugin=None, value=None)
    config_data_1.update_setting(setting=setting0_2, plugin=None)
    setting0_3 = Setting(name='setting0_3', plugin=None, value=None)
    config_data_1.update_setting(setting=setting0_3, plugin=None)


# Generated at 2022-06-24 18:17:05.398423
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    test_0 = config_data_0.get_setting('test_0')
    assert test_0 is None, "test_0 is None"

    config_data_1 = ConfigData()
    test_0 = config_data_1.get_setting('test_0')
    assert test_0 is None, "test_0 is None"


# Generated at 2022-06-24 18:17:12.309425
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_9 = ConfigData()
    plugin_0 = PluginDefinition()
    plugin_0.type = 'module'
    plugin_0.name = 'ec2'
    ansible_config_setting_0 = AnsibleConfigSetting()
    ansible_config_setting_0.name = 'ec2_url'
    ansible_config_setting_0.value = 'foo'
    ansible_config_setting_0.short_desc = 'foo'
    ansible_config_setting_0.ini_name = 'foo'
    ansible_config_setting_0.ini_section = 'foo'
    ansible_config_setting_0.ini_key = 'foo'
    ansible_config_setting_0.env_var = 'foo'

# Generated at 2022-06-24 18:17:17.841506
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    
    config_data_0 = ConfigData()
    plugin_1 = PluginSpec(type='inventory',name='plugin1',path='/path/')
    setting_2 = Setting(name='setting_name')
    setting_3 = Setting(name='setting_name')
    setting_4 = Setting(name='setting_name')
    setting_5 = Setting(name='setting_name')
    setting_6 = Setting(name='setting_name')
    setting_7 = Setting(name='setting_name')
    setting_8 = Setting(name='setting_name')
    setting_9 = Setting(name='setting_name')
    setting_10 = Setting(name='setting_name')
    setting_11 = Setting(name='setting_name')
    setting_12 = Setting(name='setting_name')

# Generated at 2022-06-24 18:17:20.699701
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:17:23.909645
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data_0 = ConfigData()
    data_0.setup()



# Generated at 2022-06-24 18:17:26.296556
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()

    # TODO: Add more complete tests for get_setting
    assert config_data_1.get_setting(None) == None



# Generated at 2022-06-24 18:17:34.237026
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    global_setting = Setting("default_accept_response_timeout", "10000", None, None)
    config_data_0.update_setting(global_setting)
    plugin = Plugin("Core", "localhost")
    plugin_setting = Setting("accept_response_timeout", "5000", plugin, None)
    config_data_0.update_setting(plugin_setting)
    assert config_data_0.get_setting("default_accept_response_timeout") == global_setting
    assert config_data_0.get_setting("accept_response_timeout", plugin) == plugin_setting



# Generated at 2022-06-24 18:17:38.713889
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    test_setting_0 = Setting('debug', 'boolean', 'false', 'Debug')
    config_data_0.update_setting(test_setting_0)


# Generated at 2022-06-24 18:17:39.899330
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_obj = ConfigData()
    assert config_data_obj.get_settings() == []


# Generated at 2022-06-24 18:17:41.682157
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('FOO')
    config_data_0.update_setting(setting_0)


# Generated at 2022-06-24 18:17:45.868574
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    import pytest
    from ansiblelint.rules import ConfigData
    config_data_0 = ConfigData()

    setting = config_data_0.get_setting("max_fail_percentage", plugin=None)
    assert setting == None



# Generated at 2022-06-24 18:17:57.299618
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    
    config_data_1 = ConfigData()

    from ansible.plugins.loader import PluginLoader

    plugin_loader_0 = PluginLoader(class_name='TestPlugin', package='ansible_collections.test.plugins.test_plugin',
                                   config=config_data_1, subdir='test_plugin')

    plugin_loader_0.get()

    settings_0 = config_data_1.get_settings(plugin=None)
    assert len(settings_0) == 1

    settings_1 = config_data_1.get_settings(plugin='test_plugin')
    assert len(settings_1) == 1



# Generated at 2022-06-24 18:17:59.583684
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(setting, plugin)


# Generated at 2022-06-24 18:18:01.738189
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(setting=None, plugin=None)


# Generated at 2022-06-24 18:18:06.624125
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data_obj = ConfigData()
    data_obj._global_settings = {"notify": "action"}

    setting = data_obj.get_setting("notify")
    assert setting["name"] == "notify"
    assert setting["value"] == "action"


# Generated at 2022-06-24 18:18:11.079811
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    setting = config_data_0.get_setting("foo", plugin=None)
    assert(setting is None)

    setting = config_data_0.get_setting("foo", "plugin")
    assert(setting is None)


# Generated at 2022-06-24 18:18:14.957908
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(name="string", plugin=None) is None


# Generated at 2022-06-24 18:18:18.701766
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()
    config_data_0 = ConfigData()
    setting_0 = Setting(name='s', description='s', default='s', ini=None, env=None, cli=None, plugin=None, secret=False)
    config_data_0.update_setting(setting=setting_0)

# Generated at 2022-06-24 18:18:21.961630
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-24 18:18:25.017721
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()

    assert config_data_1.get_setting('no_exist') is None

# Generated at 2022-06-24 18:18:31.231697
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()
    config_data_3 = ConfigData()
    config_data_4 = ConfigData()
    config_data_5 = ConfigData()
    config_data_6 = ConfigData()
    config_data_7 = ConfigData()
    config_data_8 = ConfigData()
    config_data_9 = ConfigData()
    config_data_10 = ConfigData()

# Generated at 2022-06-24 18:18:33.695342
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_2 = Setting()
    config_data_1.update_setting(setting_2)
    print('ConfigData update_setting()')


# Generated at 2022-06-24 18:18:35.979681
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()

    assert config_data_1.get_setting("foo") is None


# Generated at 2022-06-24 18:18:36.633928
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    pass

# Generated at 2022-06-24 18:18:43.219349
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test for non-existent setting for global setting
    assert config_data.get_setting("foo") is None

    # Test for valid global setting
    foo_setting = Setting("foo", "bar")
    config_data.update_setting(foo_setting)
    assert config_data.get_setting("foo") == foo_setting

    # Test for non-existent setting for plugin
    fake_plugin = Plugin("fake_plugin", "fake_type")
    assert config_data.get_setting("foo", fake_plugin) is None

    # Test for valid plugin setting
    bar_setting = Setting("bar", "baz", fake_plugin)
    config_data.update_setting(bar_setting)
    assert config_data.get_setting("bar", fake_plugin) == bar_setting

# Unit

# Generated at 2022-06-24 18:18:53.137256
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('setting_0'))
    assert config_data_1.get_setting('setting_0') == Setting('setting_0')
    config_data_1.update_setting(Setting('setting_0_1'))
    assert config_data_1.get_setting('setting_0_1') == Setting('setting_0_1')
    config_data_1.update_setting(Setting('setting_1'), Plugin('plugin_0', 'type_0'))
    assert config_data_1.get_setting('setting_1', Plugin('plugin_0', 'type_0')) == Setting('setting_1')
    config_data_1.update_setting(Setting('setting_1'), Plugin('plugin_1', 'type_0'))


# Generated at 2022-06-24 18:19:04.224495
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name="setting_abc",
                                       value="foo",
                                       plugin=Plugin(name="plugin_abc",
                                                     type="type_abc")))
    assert config_data.get_setting(name="setting_abc") is None
    assert config_data.get_setting(name="setting_abc", plugin=Plugin(name="plugin_abc", type="type_abc")) is not None
    assert config_data.get_setting(name="setting_abc", plugin=Plugin(name="plugin_abc", type="type_abc")).name == "setting_abc"
    assert config_data.get_setting(name="setting_abc", plugin=Plugin(name="plugin_abc", type="type_abc")).value == "foo"


# Generated at 2022-06-24 18:19:09.634471
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)


# Generated at 2022-06-24 18:19:16.091406
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    global_var_test_plugin_0 = ansible.plugins.loader.TestPlugin('test', 'test', 'test')
    ansible.plugins.loader.setting_loader.Setting('setting_name', 2, 'setting_description', 'setting_default')
    config_data_1.update_setting(ansible.plugins.loader.setting_loader.Setting('setting_name', 2, 'setting_description', 'setting_default'), global_var_test_plugin_0)


# Generated at 2022-06-24 18:19:24.185247
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('test_setting_0'))
    assert config_data_1.get_setting('test_setting_0') == Setting('test_setting_0')
    assert config_data_1.get_setting('test_setting_1') == None
    assert config_data_1.get_setting('test_setting_0', Plugin('test_type_0', 'test_name_0')) == None
    config_data_2 = ConfigData()
    config_data_2.update_setting(Setting('test_setting_2'), Plugin('test_type_0', 'test_name_0'))
    assert config_data_2.get_setting('test_setting_2') == None

# Generated at 2022-06-24 18:19:29.130388
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('ANSIBLE_DATADOG_API_KEY', 'mydatadogapikey', Plugin('lookup', 'datadog_lookup'))
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_setting('ANSIBLE_DATADOG_API_KEY', Plugin('lookup', 'datadog_lookup')) == setting_0
    assert config_data_0.get_setting('ANSIBLE_DATADOG_APP_KEY', Plugin('lookup', 'datadog_lookup')) is None
    assert config_data_0.get_setting('ANSIBLE_DATADOG_API_KEY') is None



# Generated at 2022-06-24 18:19:35.373003
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test case 0
    # Constructor test
    config_data_0 = ConfigData()
    # Test plugin is not None
    # assert config_data_0.get_setting(None, None) == None
    assert config_data_0.get_setting(None, None) is None
    # Test if plugin doesn't exist
    assert config_data_0.get_setting(None, Plugin(None, None, None)) == None
    # Test if plugin is None
    assert config_data_0.get_setting('name', None) is None


# Generated at 2022-06-24 18:19:39.173870
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    updated_config_data_0 = config_data_0.update_setting()
    assert updated_config_data_0 is not None


# Generated at 2022-06-24 18:19:50.718848
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # TestCase 0
    #
    # Global settings only
    config_data_0 = ConfigData()
    assert(config_data_0.get_setting("ansible.test_setting") is None)

    # TestCase 1
    #
    # Global settings plus plugin settings
    config_data_1 = ConfigData()
    config_data_1.update_setting("ansible.test_setting")
    assert(config_data_1.get_setting("ansible.test_setting") == "ansible.test_setting")
    assert(config_data_1.get_setting("ansible.nonexistent_setting") is None)

    # TestCase 2
    #
    # Global settings plus plugin settings
    config_data_2 = ConfigData()
    config_data_2.update_setting("ansible.test_setting")

# Generated at 2022-06-24 18:19:58.101437
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # TODO: implement tests
    config_data_0 = ConfigData()
    plugin_0 = PluginInstance(name='foo', type='baz', attr='fubar')
    setting_0 = Setting(name='bar', description='baz')
    config_data_0.update_setting(setting_0, plugin_0)
    config_data_0.get_setting('bar', plugin_0)


# Generated at 2022-06-24 18:20:00.412566
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None)

# Generated at 2022-06-24 18:20:14.389701
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    plugin_0 = {'type': 'connection', 'name': 'local', 'enabled': False}
    config_data_0.update_setting({'name': 'ANSIBLE_CONNECTION_PLUGINS', 'value': '/usr/bin/ansible,/etc/ansible/connection_plugins'}, plugin_0)
    assert config_data_0.get_setting('ANSIBLE_CONNECTION_PLUGINS', plugin_0) == {'name': 'ANSIBLE_CONNECTION_PLUGINS', 'value': '/usr/bin/ansible,/etc/ansible/connection_plugins'}
    assert config_data_0.get_settings(plugin_0) == [config_data_0.get_setting('ANSIBLE_CONNECTION_PLUGINS', plugin_0)]


# Generated at 2022-06-24 18:20:17.347025
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting_0 = Setting(1, "jyw @rqrns.com", "password")
    config_data_0.update_setting(setting_0)


# Generated at 2022-06-24 18:20:19.316176
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    assert ConfigData.get_setting(config_data_0, self, name) == None


# Generated at 2022-06-24 18:20:25.117373
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    plugin_0 = Plugin('C.lint', 'yaml')
    plugin_1 = Plugin('yaml', 'yaml')
    setting_0 = Setting('linters.yaml.yamllint.args', '', 'flag list', plugin_0, 'yamllint')
    setting_1 = Setting('linters.yaml.yamllint.config', '', 'path', plugin_0, 'yamllint')
    setting_2 = Setting('encoding', '', 'string', plugin_1, 'yamllint')
    setting_3 = Setting('indent', '', 'integer', plugin_1, 'yamllint')
    config_data_0.update_setting(setting_0)
    config_data_0.update_setting(setting_1)

# Generated at 2022-06-24 18:20:27.039937
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None)


# Generated at 2022-06-24 18:20:28.717580
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test_case_0()
    config_data_0 = ConfigData()
    assert config_data_0.get_setting("global") is None


# Generated at 2022-06-24 18:20:34.012107
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Create new ConfigData object
    test_config_data = ConfigData()

    # Create new setting object
    from ansiblelint import PluginsDirectory
    from ansiblelint.rules import AnsibleLintRule
    from ansiblelint.setting import Setting
    plugin_dir = PluginsDirectory()
    plugin = plugin_dir.get_plugin_by_name('ansible-lint', 'plugin type')
    rule = AnsibleLintRule('fake rule', '/fake/path')
    test_setting = Setting('fake setting', True, 'fake_section', 'fake_subsection')

    # Test when plugin argument is None
    test_config_data.update_setting(test_setting)

    assert test_config_data.get_setting('fake setting') is test_setting

    # Test when plugin argument is not None
    test_

# Generated at 2022-06-24 18:20:41.202547
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Case 0
    config_data_0 = ConfigData()
    setting_0 = Setting(name='name_0', value='value_0')
    config_data_0.update_setting(setting=setting_0)
    assert config_data_0.get_setting(name='name_0').value == 'value_0'
    assert config_data_0.get_setting(name='name_0').name == 'name_0'

# Generated at 2022-06-24 18:20:42.622690
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    print('Testing get_setting method')
    test_case_0()


# Generated at 2022-06-24 18:20:44.979922
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = config_data_0.get_setting('name')
    setting_1 = config_data_0.get_setting('name', 'plugin')


# Generated at 2022-06-24 18:20:55.352991
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    # Create settings for each of the 2 plug-ins
    setting_vault = PluginSetting(name='vault')
    setting_math = PluginSetting(name='math')

    # Create 2 plug-ins
    plugin_0 = Plugin(name='vault', type='lookup')
    plugin_1 = Plugin(name='math', type='filter')

    # Update ConfigData
    config_data_0.update_setting(setting_vault, plugin_0)
    config_data_0.update_setting(setting_math, plugin_1)


# Generated at 2022-06-24 18:21:06.096888
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()
    assert len(config_data_1._global_settings) == 0
    assert len(config_data_1._plugins) == 0

    class Setting0(object):

        def __init__(self, name, value):
            self.name = name
            self.value = value

    setting0 = Setting0('foo', 'bar')

    config_data_1.update_setting(setting0)

    assert len(config_data_1._global_settings) == 1
    assert len(config_data_1._plugins) == 0

    assert config_data_1._global_settings['foo'].name == 'foo'
    assert config_data_1._global_settings['foo'].value == 'bar'


# Generated at 2022-06-24 18:21:07.191667
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:21:15.513267
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """
    This test verifies that the update_setting method of the ConfigData class
    functions correctly.
    """
    # Create an instance of ConfigData
    config_data_1 = ConfigData()

    # Create a Setting instance
    setting_0 = Setting('setting_name_0', 'value_0')
    plugin_0 = Plugin('plugin_type_0', 'plugin_name_0')

    # Invoke the method under test
    config_data_1.update_setting(setting_0)

    # Verify that the Setting instance was added to the global settings
    setting_1 = config_data_1.get_setting('setting_name_0')
    assert setting_1 == setting_0

    # Invoke the method under test with a plugin
    config_data_1.update_setting(setting_0, plugin_0)

   

# Generated at 2022-06-24 18:21:24.346645
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_1 = ansible.module_utils.config.setting.Setting(name='test_setting_1')
    setting_2 = ansible.module_utils.config.setting.Setting(name='test_setting_2')
    plugin_1 = ansible.module_utils.config.plugin.Plugin(name='test_plugin_1', type='test_type_1')
    plugin_2 = ansible.module_utils.config.plugin.Plugin(name='test_plugin_2', type='test_type_2')
    config_data_1.update_setting(setting_1)
    config_data_1.update_setting(setting_2, plugin_1)


# Generated at 2022-06-24 18:21:34.320993
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    cs = ConfigData()

    cs.update_setting(Setting('setting0', 'value0'))
    cs.update_setting(Setting('setting1', 'value1'))
    cs.update_setting(Setting('setting0', 'value2'))
    cs.update_setting(Setting('setting1', 'value3'))
    cs.update_setting(Setting('setting2', 'value4'))

    cs.update_setting(Setting('setting1', 'value5'), Plugin('plugin', 'type'))
    cs.update_setting(Setting('setting2', 'value6'), Plugin('plugin', 'type'))
    cs.update_setting(Setting('setting1', 'value7'), Plugin('plugin', 'type2'))
    cs.update_setting(Setting('setting2', 'value8'), Plugin('plugin', 'type2'))



# Generated at 2022-06-24 18:21:36.913919
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    if config_data_1.get_setting() is None:
        pass


# Generated at 2022-06-24 18:21:50.290206
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    global_setting_0 = GlobalSetting('', '', '')
    global_setting_1 = GlobalSetting('', '', '')
    global_setting_2 = GlobalSetting('', '', '')
    global_setting_3 = GlobalSetting('', '', '')
    global_setting_4 = GlobalSetting('', '', '')
    global_setting_5 = GlobalSetting('', '', '')
    global_setting_6 = GlobalSetting('', '', '')
    global_setting_7 = GlobalSetting('', '', '')
    global_setting_8 = GlobalSetting('', '', '')
    global_setting_9 = GlobalSetting('', '', '')
    global_setting_0.name = 'settings0'
    global_setting_1.name = 'settings1'


# Generated at 2022-06-24 18:21:53.694168
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting("action_plugins")
    setting_0.value = "./action_plugins"
    config_data_0.update_setting(setting_0)
    assert config_data_0._global_settings["action_plugins"] == setting_0


# Generated at 2022-06-24 18:21:55.703406
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()


# Generated at 2022-06-24 18:22:05.542150
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print("Testing method ConfigData_update_setting")
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting)
    config_data_0.get_settings(plugin)
    config_data_0.update_setting(setting)

# Generated at 2022-06-24 18:22:11.035050
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global config_data_0
    config_data_0.update_setting(None, None)

test_case_0()
test_ConfigData_update_setting()

# Generated at 2022-06-24 18:22:11.729596
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    pass


# Generated at 2022-06-24 18:22:18.664920
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()
    setting_1 = None
    plugin_1 = None
    try:
        config_data_1.update_setting(setting_1, plugin_1)
    except AssertionError:
        pass
    else:
        assert False, 'ExpectedAssertionError not raised'

    setting_2 = Setting(name='foo', value='bar', path='/tmp/foo.yml', section='DEFAULT', plugin_type='inventory')
    plugin_2 = Plugin(name='bar', type='inventory')
    config_data_2 = ConfigData()
    config_data_2.update_setting(setting_2, plugin_2)

# Generated at 2022-06-24 18:22:22.495765
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_case_0()
    config_data_0 = ConfigData()
    settings = config_data_0.get_settings()
    assert(settings == [])


# Generated at 2022-06-24 18:22:24.442016
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting(name='us-east-1', plugin=None)

# Generated at 2022-06-24 18:22:26.126665
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    try:
        assert c.update_setting(None) == None
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-24 18:22:29.700686
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    result = config_data_0.get_setting('var_name', None)

# Generated at 2022-06-24 18:22:31.238830
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data0 = ConfigData()
    config_data0.update_setting()

# Generated at 2022-06-24 18:22:32.749610
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    result = config_data_0.get_settings()


# Generated at 2022-06-24 18:22:42.555889
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    test_case_0()


# Generated at 2022-06-24 18:22:45.607419
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert isinstance(config_data_1.get_settings(), list)




# Generated at 2022-06-24 18:22:49.922288
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    # the following attribute should contain an empty dictionary
    config_data_0._global_settings
    # the following attribute should contain an empty dictionary
    config_data_0._plugins


# Generated at 2022-06-24 18:22:51.543976
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting("setting_0") is None


# Generated at 2022-06-24 18:22:55.270305
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting()



# Generated at 2022-06-24 18:23:04.735752
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.utils.plugin_docs import AnsiblePlugin, AnsiblePluginSetting

    config = ConfigData()

    # First add a global setting
    setting = AnsiblePluginSetting(name='test_setting_0',
                                   description='This is a test setting',
                                   required=True,
                                   default='test_default_0')
    config.update_setting(setting)

    plugin = AnsiblePlugin(type='test_type_0',
                           name='test_name_0',
                           description='This is a test plugin')
    setting = AnsiblePluginSetting(name='test_setting_1',
                                   description='This is a test setting',
                                   required=True,
                                   default='test_default_1')
    config.update_setting(setting, plugin)


# Generated at 2022-06-24 18:23:09.967277
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()


if __name__ == '__main__':
    import sys
    import logging
    import os

    logging.basicConfig(format='TEST %(message)s')

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)

    test_ConfigData_update_setting()

# Generated at 2022-06-24 18:23:11.948669
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert len(config_data_1.get_settings()) == 0


# Generated at 2022-06-24 18:23:22.716288
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.plugin_docs import get_docstring
    from collections import namedtuple

    config_data_0 = ConfigData()
    assert isinstance(config_data_0, ConfigData) == True
    actual = config_data_0.get_setting('core')
    assert type(actual) == type(None)
    plugin = namedtuple('plugin', ['name', 'type'])
    plugin.name = 'strategy_plugins'
    plugin.type = 'strategy'
    actual = config_data_0.get_setting('linear', plugin)
    expected = config_data_0.get_setting('linear')
    assert actual == expected
    plugin = namedtuple('plugin', ['name', 'type'])
    plugin.name = 'action_plugins'


# Generated at 2022-06-24 18:23:25.512945
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # TestCase 0
    config_data_0 = ConfigData()
    assert config_data_0.get_setting("", "") == None, "TestCase 0 Failed"



# Generated at 2022-06-24 18:23:36.640716
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    #config_data_0.get_settings(plugin=None)


# Generated at 2022-06-24 18:23:40.976423
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:23:43.475367
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    plugin = None
    name = 'env'
    setting = config_data_0.get_setting(name, plugin)
    assert setting is None


# Generated at 2022-06-24 18:23:49.395001
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin = Plugin('Collection', 'module_utils')
    config_setting = ConfigSetting('first_setting', 'first_value', plugin)
    config_data = ConfigData()
    config_data.update_setting(config_setting)
    setting = config_data.get_settings(plugin)
    assert config_setting == setting[0]
    setting = config_data.get_settings()
    assert not setting


# Generated at 2022-06-24 18:23:53.267536
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting()
    config_data_0.update_setting(setting_0)


# Generated at 2022-06-24 18:24:06.204412
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(name='test_setting')
    assert (config_data_1.get_setting('test_setting') is not None)
    assert (config_data_1.get_setting('test_setting').name == 'test_setting')
    config_data_1.update_setting(name='test_setting_2')
    assert (config_data_1.get_setting('test_setting_2') is not None)
    assert (config_data_1.get_setting('test_setting_2').name == 'test_setting_2')
    assert (config_data_1.get_setting('test_setting').name == 'test_setting')




# Generated at 2022-06-24 18:24:08.552285
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    for i in range(0, 10):
        assert (config_data_0.get_setting('test') is None)


# Generated at 2022-06-24 18:24:20.084329
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()
    config_data_2 = ConfigData()
    config_data_3 = ConfigData()

    config_data_1.update_setting(test_case_0())
    config_data_2.update_setting(test_case_1())
    config_data_3.update_setting(test_case_2())

    assert config_data_1.get_setting('no_log')[0] == 'yes'
    assert config_data_2.get_setting('no_log')[0] == 'no'
    assert config_data_3.get_setting('no_log')[0] == 'yes'
    assert config_data_1.get_setting('action_plugins') == []
    assert config_data_2.get_setting('action_plugins') == []

# Generated at 2022-06-24 18:24:21.733395
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()



# Generated at 2022-06-24 18:24:23.403241
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:24:50.009040
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

# unit test for method get_setting of class ConfigData

# Generated at 2022-06-24 18:25:00.002759
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_2 = ConfigData()
    plugin_2 = Plugin(type_name='inventory', name='my_plugin')
    plugin_3 = Plugin(type_name='cache', name='my_plugin')
    config_data_2.update_setting(plugin=plugin_2, setting=ConfigEntry(name='option1', section='section1', value='value2'))
    plugin_4 = Plugin(type_name='inventory', name='my_plugin')
    config_data_2.update_setting(plugin=plugin_4, setting=ConfigEntry(name='option1', section='section1', value='value2'))
    plugin_5 = Plugin(type_name='inventory', name='my_other_plugin')