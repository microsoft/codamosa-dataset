

# Generated at 2022-06-24 18:15:07.141262
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('setting_0')
    plugin_0 = Plugin(None, None)
    config_data_0.update_setting(setting_0, plugin_0)
    assert setting_0 == config_data_0.get_setting('setting_0', plugin_0)


# Generated at 2022-06-24 18:15:12.180736
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    from ansible.plugins.loader import become_loader, cache_loader, connection_loader, callback_loader, shell_loader

    # Test with global settings.
    from ansible.config.data import ConfigData
    from ansible.config.settings import Setting

    setting_1 = Setting('bar', 'foo', 'bar value')
    setting_2 = Setting('foo', 'foo', 'foo value')

    config_data_0.update_setting(setting_1)
    config_data_0.update_setting(setting_2)

    settings_0 = config_data_0.get_settings()
    assert settings_0[0] == config_data_0.get_setting('bar')
    assert settings_0[1] == config_data_0.get_setting('foo')

# Generated at 2022-06-24 18:15:13.320422
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_case_0()


# Generated at 2022-06-24 18:15:18.132825
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    setting_0 = Setting(name='foo', value=1)
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_setting('foo') == setting_0


# Generated at 2022-06-24 18:15:19.699468
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting == None


# Generated at 2022-06-24 18:15:21.543499
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting = config_data_0.get_setting("", plugin=None)


# Generated at 2022-06-24 18:15:29.313077
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_0 = Setting(name='foo', value='bar')
    setting_1 = Setting(name='spam', value='eggs')
    setting_2 = Setting(name='foo', value='hello', plugin=Plugin(type='callback', name='dummy'))
    setting_3 = Setting(name='foo', value='world', plugin=Plugin(type='cache', name='memory'))
    setting_4 = Setting(name='eggs', value='bar', plugin=Plugin(type='cache', name='memory'))

    config_data_1.update_setting(setting_0)
    config_data_1.update_setting(setting_1)
    config_data_1.update_setting(setting_2)
    config_data_1.update_setting(setting_3)
   

# Generated at 2022-06-24 18:15:36.521409
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting({'default': False, 'name': 'ZLIB_DEVEL', 'section': 'Packages', 'type': 'bool', 'value': [True, False]})
    assert config_data_0._global_settings['ZLIB_DEVEL'] == {'default': False, 'name': 'ZLIB_DEVEL', 'section': 'Packages', 'type': 'bool', 'value': [True, False]}


# Generated at 2022-06-24 18:15:45.975417
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    test_plugin_0 = Plugin(u'action', u'command')
    test_plugin_1 = Plugin(u'module', u'command')
    test_plugin_2 = Plugin(u'action', u'ping')
    test_plugin_3 = Plugin(u'module', u'ping')
    test_setting_0 = Setting(u'something', u'value')
    config_data_0.update_setting(test_setting_0, plugin=test_plugin_0)
    config_data_0.update_setting(test_setting_0, plugin=test_plugin_1)
    config_data_0.update_setting(test_setting_0, plugin=test_plugin_2)

# Generated at 2022-06-24 18:15:49.560151
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting("None").value == "None"


# Generated at 2022-06-24 18:15:58.258746
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
	config_data_0 = ConfigData()
	settings = config_data_0.get_settings()


# Generated at 2022-06-24 18:16:00.059451
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting() == None


# Generated at 2022-06-24 18:16:08.377402
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.config.plugin_settings import PluginSettings
    config_data_0 = ConfigData()
    ansible_plugin_0 = PluginSettings('', '', '')
    ansible_plugin_1 = PluginSettings('', '', '')
    ansible_plugin_2 = PluginSettings('', '', '')
    ansible_plugin_3 = PluginSettings('', '', '')
    ansible_plugin_4 = PluginSettings('', '', '')
    ansible_plugin_5 = PluginSettings('', '', '')
    ansible_plugin_6 = PluginSettings('', '', '')
    ansible_plugin_7 = PluginSettings('', '', '')
    ansible_plugin_8 = PluginSettings('', '', '')
    ansible_plugin_9 = PluginSettings('', '', '')
    ansible_

# Generated at 2022-06-24 18:16:18.902498
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin('name', 'type')
    print('test_ConfigData_get_settings:', config_data.get_settings())

    setting = Setting('name', 'value', 'section', 'subsection')
    config_data.update_setting(setting)
    print('test_ConfigData_get_settings:', config_data.get_settings())
    print('test_ConfigData_get_settings:', config_data.get_settings(plugin))
    print('test_ConfigData_get_settings:', config_data.get_settings(None))

    plugin2 = Plugin('name2', 'type')
    config_data.update_setting(setting, plugin2)
    print('test_ConfigData_get_settings:', config_data.get_settings(plugin2))

# Generated at 2022-06-24 18:16:19.485023
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()

# Generated at 2022-06-24 18:16:25.999085
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    # Test update_setting(self, setting, plugin=None)
    config_data.update_setting(Setting('plugin_sync', 'on'))
    assert config_data._global_settings['plugin_sync'] == Setting('plugin_sync', 'on')
    config_data.update_setting(Setting('alias', 'new_alias'), Plugin('shell', 'shell'))
    assert config_data._plugins['shell']['shell']['alias'] == Setting('alias', 'new_alias')



# Generated at 2022-06-24 18:16:28.031352
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:16:32.332887
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    plugin_0 = Plugin('cache', 'memory')
    setting_0 = Setting('size', '10kb')
    config_data_0.update_setting(setting_0, plugin_0)


# Generated at 2022-06-24 18:16:38.117600
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    plugin = Plugin('connection', 'local')
    setting = Setting('host_pattern', '*')

    config_data.update_setting(setting, plugin)

    s = config_data.get_settings(plugin)
    assert len(s) == 1
    assert s[0].name == setting.name
    assert s[0].value == setting.value

    s = config_data.get_settings()
    assert len(s) == 0



# Generated at 2022-06-24 18:16:41.285934
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    assert config_data_1.get_setting(name="name 1", plugin=None) is None


# Generated at 2022-06-24 18:16:53.696457
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    config_data_0.update_setting("option_a")


# Generated at 2022-06-24 18:16:54.974658
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(None, None)


# Generated at 2022-06-24 18:17:00.031617
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    plugin_type_0 = 'module'
    plugin_name_0 = 'ansible.module_utils.check_mode'
    plugin_0 = Plugin(type=plugin_type_0, name=plugin_name_0)
    setting_name_0 = 'CHECK_MODE'
    setting_0 = Setting(name=setting_name_0, desc='Whether the plugin supports check mode.', default='True', type='boolean')
    config_data_0.update_setting(setting=setting_0, plugin=plugin_0)
    setting_0 = config_data_0.get_setting(name=setting_name_0, plugin=plugin_0)
    assert setting_0.name == setting_name_0


# Generated at 2022-06-24 18:17:03.809322
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Setup
    global config_data_0
    config_data_0 = ConfigData()
    assert config_data_0


# Generated at 2022-06-24 18:17:06.058671
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Case 0: Test with default args
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == [], 'Incorrect return value for method ConfigData.get_settings().'


# Generated at 2022-06-24 18:17:08.855211
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    print("TESTING get_setting")
    config_data_1 = ConfigData()
    for s in config_data_1.get_settings():
        print(s)

# Generated at 2022-06-24 18:17:18.719290
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    # test global settings
    settings0 = config_data_0.get_settings()
    assert settings0 == []

    setting0 = Setting('setting0', 'setting0 value', 'setting0 description')
    config_data_0.update_setting(setting0)

    settings1 = config_data_0.get_settings()
    assert len(settings1) == 1
    assert settings1[0].name == 'setting0'
    assert settings1[0].value == 'setting0 value'
    assert settings1[0].description == 'setting0 description'

    setting1 = Setting('setting1', 'setting1 value', 'setting1 description')
    config_data_0.update_setting(setting1)

    settings2 = config_data_0.get_settings()

# Generated at 2022-06-24 18:17:20.102047
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()

# Generated at 2022-06-24 18:17:22.430534
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:17:27.533948
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin = Plugin()
    # FIXME: this test is not enough to cover task data, we
    # should add more test cases
    config_data_0.update_setting(setting=setting, plugin=plugin)
    config_data_0.get_settings()

# Generated at 2022-06-24 18:17:40.804544
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting = config_data_0.get_setting(name="name")
    assert setting == None
    assert setting is None



# Generated at 2022-06-24 18:17:43.486783
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings_0 = config_data_0.get_settings()


# Generated at 2022-06-24 18:17:47.334347
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # variables used for testing
    plugin = None
    settings = {}

    # test case 1: plugin is None
    plugin = None
    settings = config_data.get_settings(plugin)
    # expected result: settings is an empty list
    assert settings == []


# Generated at 2022-06-24 18:17:52.111693
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    settings = config_data_0.get_settings()

    assert len(settings) == 0, "Expected a return value of 0 from method 'get_settings' from class ConfigData"



# Generated at 2022-06-24 18:17:52.965898
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(setting)


# Generated at 2022-06-24 18:18:01.807364
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    plugin_info_0 = PluginInfo('cliconf', 'ios')
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting(name='_ansible_version', value='2.2.1.0'))

    assert config_data_0.get_setting('_ansible_version') == Setting(name='_ansible_version', value='2.2.1.0')


# Generated at 2022-06-24 18:18:09.391499
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    from ansiblelint.rules.TasksHaveTypeRule import TasksHaveTypeRule
    from ansiblelint import RulesCollection

    rules_collection = RulesCollection()

    rules_collection.register(TasksHaveTypeRule())

    from ansiblelint.runner import Runner

    config = {
        'metadata': {
            'name': 'foo'
        },
        'rules_dir': [],
        'rules_file': [],
        'excluded_paths': []
    }

    runner = Runner(config_data, rules_collection, config)

    config_data.update_setting(runner.get_setting('TASKS_HAVE_TYPE'))


# Generated at 2022-06-24 18:18:11.223292
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    assert config_data_0.get_setting(name=None, plugin=None) == None


# Generated at 2022-06-24 18:18:15.135844
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()
    plugin_0 = Plugin("Network", "nso")
    setting_0 = Setting("nso:datamodel")
    setting_0.value = "network"
    config_data_0.update_setting(setting_0, plugin_0)
    settings = config_data_0.get_settings()
    assert settings[0].value == "network"


# Generated at 2022-06-24 18:18:20.597112
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting()
    setting_0.name = 'foo'
    setting_0.value = 'bar'
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_setting('foo') == setting_0
    config_data_0.update_setting(setting_0, Plugin('foo', 'bar'))
    assert config_data_0.get_setting('foo', Plugin('foo', 'bar')) == setting_0


# Generated at 2022-06-24 18:18:31.963691
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-24 18:18:39.418061
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_1 = config_data_1.Setting(name="log_level", value="INFO")
    config_data_1.update_setting(setting_1)
    setting_2 = config_data_1.Setting(name="log_path", value="/path/to/log/file")
    config_data_1.update_setting(setting_2)
    plugin_1 = config_data_1.Plugin(type="test", name="test-1")
    setting_3 = config_data_1.Setting(name="test_setting_1", value="test value 1")
    config_data_1.update_setting(setting_3, plugin_1)
    setting_4 = config_data_1.Setting(name="test_setting_2", value="test value 2")
    config

# Generated at 2022-06-24 18:18:44.229542
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Case 0: setting is not defined
    config_data = ConfigData()
    assert config_data.get_setting("test") == None
    assert config_data.get_setting("test", None) == None


# Generated at 2022-06-24 18:18:52.275079
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting(name='ansible_connection', value='winrm', priority=1))
    plugins = [Plugin(name='on_any', type='callback', path='/usr/lib/python2.7/dist-packages/ansible/plugins/callback/on_any.py')]
    for plugin in plugins:
        config_data_0.update_setting(Setting(name='ansible_connection', value='winrm', priority=1), plugin=plugin)
    print(config_data_0.get_settings())
    print(config_data_0.get_settings(plugin=plugin))



# Generated at 2022-06-24 18:18:58.353582
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Test setting a global setting
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('action_plugins', '/usr/libexec/nise-ansible/action_plugins'))
    assert config_data_1.get_setting('action_plugins') == '/usr/libexec/nise-ansible/action_plugins'

    # Test updating a global setting
    config_data_1.update_setting(Setting('action_plugins', '/plugins'))
    assert config_data_1.get_setting('action_plugins') == '/plugins'

    # Test updating a plugin setting
    plugin = Plugin('callback', 'default')
    config_data_1.update_setting(Setting('log_path', '/log/ansible-callback-default'), plugin)
    assert config_data_1.get_setting

# Generated at 2022-06-24 18:19:00.921152
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('rcfile', None)
    config_data_0.update_setting(None, None)


# Generated at 2022-06-24 18:19:05.207992
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.update_setting('user_method')
    assert config_data_0.get_settings() is not None


# Generated at 2022-06-24 18:19:10.543516
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting_0 = Setting('test_setting_0')
    setting_1 = Setting('test_setting_1')
    config_data.update_setting(setting_0)
    config_data.update_setting(setting_1)
    settings = config_data.get_settings()
    assert len(settings) == 2
    assert settings[0].name == 'test_setting_0'
    assert settings[1].name == 'test_setting_1'
    settings = config_data.get_settings(plugin=Plugin('test_plugin', 'test_type'))
    assert len(settings) == 0


# Generated at 2022-06-24 18:19:13.152649
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('name', 'value')
    config_data_0.update_setting(setting_0)


# Generated at 2022-06-24 18:19:19.118451
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('automation_tools_version', '1.0'))
    config_data_1.update_setting(Setting('automation_tools_version', '1.0', Plugin('collection', 'acme.tools')))
    print(config_data_1.get_setting('automation_tools_version'))
    print(config_data_1.get_setting('automation_tools_version', Plugin('collection', 'acme.tools')))


# Generated at 2022-06-24 18:19:48.032606
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    # Get global setting with name ENV
    setting = config_data_0.get_setting('ENV')
    assert setting is None

    # Get setting with name ENV from plugin with type connection and name local
    from ansible.plugins.loader import PluginLoader

    plugin = PluginLoader('Driver').get('local')
    assert plugin
    setting = config_data_0.get_setting('ENV', plugin)
    assert setting is None


# Generated at 2022-06-24 18:19:50.845272
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    # Code starts here
    assert config_data_0.get_settings() == []
    # Code ends here


# Generated at 2022-06-24 18:20:01.496124
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    # No setting for plugin_type plugin_name
    assert config_data.get_setting(None, None) is None
    assert config_data.get_setting('plugin_name', 'plugin_type') is None
    # Test for plugin
    plugin = object()
    assert config_data.get_setting(plugin, None) is None
    assert config_data.get_setting(plugin, 'plugin_type') is None
    # Test for None
    assert config_data.get_setting(None, None) is None
    assert config_data.get_setting(None, 'plugin_type') is None
    # Test for a global setting
    global_setting = object()
    config_data._global_settings['plugin_name'] = global_setting

# Generated at 2022-06-24 18:20:10.780110
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = config_data.get_setting('SOMETHING')

    assert setting is None, 'Setting SOMETHING not expected to be in data'

    config_data.update_setting(Setting('SOMETHING', 'VALUE'))

    setting = config_data.get_setting('SOMETHING')

    assert setting is not None, 'Setting SOMETHING expected to be in data'
    assert setting.name == 'SOMETHING', 'Setting name is unexpected'
    assert setting.value == 'VALUE', 'Setting value is unexpected'



# Generated at 2022-06-24 18:20:20.143824
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Setup test case
    config_data_0 = ConfigData()

    # Test 1: No settings
    settings = config_data_0.get_setting('Some_setting', plugin=None)
    assert settings == None

    # Test 2: Setting on global level
    config_data_0.update_setting(Setting(name='Some_setting_1', value='some_value', origin='/some/path/on/filesystem'), plugin=None)
    settings = config_data_0.get_settings(plugin=None)
    assert settings[0].name == 'Some_setting_1'

    # Test 3: Setting on global level and plugin level
    plugin = Plugin('some_type', 'some_name')

# Generated at 2022-06-24 18:20:23.266348
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    # Test case with None
    config_data_0.update_setting(None)

    # Test case with empty dict
    config_data_0.update_setting({})

# Generated at 2022-06-24 18:20:24.183340
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

# Generated at 2022-06-24 18:20:29.567577
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Initialize config_data with ConfigData
    config_data = ConfigData()

    # Define setting
    setting = {}

    # Initialize plugin
    plugin = {}

    # Call to method update_setting of class ConfigData
    # config_data.update_setting(setting, plugin)

    # Verify that the following calls are made
    # config_data._global_settings.update(setting)
    # config_data._plugins[plugin.type][plugin.name].update(setting)
    assert True


# Generated at 2022-06-24 18:20:39.309039
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting_0 = MockSetting()
    setting_0.name = 'name'
    plugin_0 = MockPlugin()
    plugin_0.type = 'type'
    plugin_0.name = 'name'
    setting = config_data.get_setting(setting_0.name, plugin_0)
    assert setting is None
    config_data.update_setting(setting_0, plugin_0)
    assert config_data.get_setting(setting_0.name, plugin_0) == setting_0
    settings = config_data.get_settings(plugin_0)
    assert settings == [setting_0]
    settings = config_data.get_settings()
    assert settings == []

# Mock classes

# Generated at 2022-06-24 18:20:40.858694
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:21:25.559717
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData0 = ConfigData()
    assert configData0
    assert configData0._global_settings == {}
    assert configData0._plugins == {}
    setting1 = Setting('foo')
    setting1.value = 'bar'
    setting1.plugin = ('global', 'global')
    configData0.update_setting(setting1)


# Generated at 2022-06-24 18:21:26.736516
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

# Generated at 2022-06-24 18:21:38.324586
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():


    # Constructor test:
    config_data_0 = ConfigData()
    assert(isinstance(config_data_0, ConfigData))

    # Generate a global setting
    global_setting_0 = GlobalSetting('foo', 'int')
    config_data_0.update_setting(global_setting_0)

    # Generate a plugin setting
    plugin_setting_0 = PluginSetting('bar', 'str', 'foo')
    config_data_0.update_setting(plugin_setting_0)

    assert(len(config_data_0.get_settings()) == 1)
    assert(len(config_data_0.get_settings(plugin_setting_0.plugin)) == 1)
    assert(len(config_data_0.get_settings(GlobalPlugin(global_setting_0.name))) == 0)




# Generated at 2022-06-24 18:21:41.134878
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting()


# Generated at 2022-06-24 18:21:51.622399
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(setting=Setting(name='setting_1', value=1))
    config_data.update_setting(setting=Setting(name='setting_2', value='2'))
    config_data.update_setting(setting=Setting(name='setting_3', value=[3, 4, 5]))
    config_data.update_setting(setting=Setting(name='setting_4', value={'k_4': 3, 'key_4': 4}),
                               plugin=Plugin(name='plugin_1', type='plugin_type_1'))
    config_data.update_setting(setting=Setting(name='setting_5', value=5),
                               plugin=Plugin(name='plugin_2', type='plugin_type_1'))
    config_data.update_

# Generated at 2022-06-24 18:21:55.267825
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    assert config_data_1.get_setting('ansible_host') is None


# Generated at 2022-06-24 18:22:00.088329
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting("setting1", plugin=None)
    config_data.update_setting("setting2", plugin=None)
    config_data.update_setting("setting3", plugin=None)
    output = config_data.get_settings(plugin=None)
    expected = ['setting1', 'setting2', 'setting3']
    assert (output == expected), 'Expected output : {}. Actual output : {}'.format(expected, output)



# Generated at 2022-06-24 18:22:08.939218
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []
    setting_0 = ConfigSetting()
    setting_0.name = 'debug'
    setting_0.value = False
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_setting('debug') != None
    plugin_0 = PluginInfo()
    plugin_0.name = 'ec2'
    plugin_0.type = 'inventory'
    setting_0 = ConfigSetting()
    setting_0.name = 'regions'
    setting_0.value = ['us-west-1']
    config_data_0.update_setting(setting_0, plugin_0)
    assert config_data_0.get_setting('regions', plugin_0) != None
   

# Generated at 2022-06-24 18:22:10.697792
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    settings = config_data_0.get_settings()


# Generated at 2022-06-24 18:22:16.574083
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting = {
      "default": None,
      "desc": "",
      "name": "",
      "type": None,
      "value": "",
      "version_added": None
    }
    config_data_0.update_setting(setting)
    plugin = {
      "name": "",
      "type": None
    }
    config_data_0.update_setting(setting, plugin)


# Generated at 2022-06-24 18:23:52.520018
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Initialization for testing
    config_data = ConfigData()
    config_data.update_setting(Setting('ansible_connection', 'local'))
    config_data.update_setting(Setting('ansible_connection', 'local', 'connection', 'SSH'))
    config_data.update_setting(Setting('ansible_connection', 'local', 'inventory', 'ec2.py'))
    config_data.update_setting(Setting('ansible_user', 'root', 'inventory', 'ec2.py'))
    config_data.update_setting(Setting('ansible_ssh_private_key_file', '~/.ssh/id_rsa', 'inventory', 'ec2.py'))

    # Testing helper function get_setting()

# Generated at 2022-06-24 18:23:56.744525
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    result_0 = config_data_0.get_setting(name='version')
    assert result_0 is None


# Generated at 2022-06-24 18:24:00.663047
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_update_setting_0 = ConfigData()

# Generated at 2022-06-24 18:24:09.312507
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Setup
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting(name='setting_1', value='value1'))
    config_data_1.update_setting(Setting(name='setting_2', value='value2'))
    config_data_1.update_setting(Setting(name='setting_3', value='value3'))

    # Exercise
    retval_1 = config_data_1.get_settings()

    # Verify
    assert len(retval_1) == 3

    # Cleanup

    # Exercise
    config_data_1.update_setting(Setting(name='setting_1', value='value1', plugin=Plugin(type='module', name='module_a')))

# Generated at 2022-06-24 18:24:14.713401
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(ansible_custom_config.ConfigSetting('verbosity', '4'))
    assert config_data_0.get_setting('verbosity') == '4'



# Generated at 2022-06-24 18:24:24.039854
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # initialize the ConfigData object
    config_data_1 = ConfigData()
    setting_0 = Setting()
    setting_0.name = u'fact_caching_connection'
    setting_0.value = u'localhost'
    config_data_1.update_setting(setting_0)
    setting_1 = Setting()
    setting_1.name = u'fact_caching_connection'
    setting_1.value = u'localhost'
    config_data_1.update_setting(setting_1)
    # get the list of setting objects
    result = config_data_1.get_settings()
    # check if the method returned an array with two objects
    assert type(result) is list
    assert len(result) == 2
    # get the list of setting objects
    result = config_data_1.get_

# Generated at 2022-06-24 18:24:26.530396
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting_0 = None
    plugin_0 = None
    actual = config_data_0.get_settings(plugin_0)


# Generated at 2022-06-24 18:24:29.334006
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_case_1_config_data = ConfigData()
    test_case_1_config_data.get_settings()


# Generated at 2022-06-24 18:24:32.537265
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    result = config_data_0.get_settings()
    assert isinstance(result, list)


# Generated at 2022-06-24 18:24:34.502405
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
