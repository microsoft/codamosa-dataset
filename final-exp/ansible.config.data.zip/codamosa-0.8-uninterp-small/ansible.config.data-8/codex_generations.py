

# Generated at 2022-06-24 18:15:05.895421
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting("name", "description", "value")
    plugin_0 = Plugin("type", "name", "/path/to/plugin")
    config_data_0.update_setting(setting_0, plugin_0)
    result_0 = config_data_0.get_setting("name", plugin_0)
    assert result_0.name == "name"


# Generated at 2022-06-24 18:15:08.882398
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert config_data_1.get_settings() is not None


# Generated at 2022-06-24 18:15:17.287838
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Test scenario where there are no plugins
    config_data_0 = ConfigData()
    setting_0 = config_data_0.get_setting("MONGO_URI").value
    assert setting_0 == "localhost:27017"

    # Test scenario where there is only a global setting
    config_data_0 = ConfigData()
    settings_0 = config_data_0.get_settings()
    assert len(settings_0) == 1

    # Test scenario where there are only settings for a particular plugin
    config_data_0 = ConfigData()
    settings_0 = config_data_0.get_settings(plugin=Plugin("action", "debug"))
    assert len(settings_0) == 0
    settings_0 = config_data_0.get_settings(plugin=Plugin("become", "sudo"))

# Generated at 2022-06-24 18:15:19.182279
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting_0 = config_data_1.get_setting(name = 'locale')



# Generated at 2022-06-24 18:15:21.417178
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    c0 = ConfigData()
    # call to method get_setting
    assert c0.get_setting('host_key_checking') is None


# Generated at 2022-06-24 18:15:25.848684
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting())
    plugin_1 = Plugin(PluginType.CONNECTION, "local")
    config_data_1.update_setting(Setting(), plugin_1)
    setting_1 = config_data_1.get_setting("test", None)
    setting_2 = config_data_1.get_setting("test", plugin_1)


# Generated at 2022-06-24 18:15:37.678886
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()

    setting_0 = Setting('a', 'b', 'c')
    config_data_0.update_setting(setting_0)
    setting_1 = Setting('d', 'e', 'f')
    config_data_0.update_setting(setting_1)

    ret = config_data_0.get_settings()
    assert ret == [setting_0, setting_1]

    plugin = Plugin('h', 'i')
    setting_2 = Setting('j', 'k', 'l')
    config_data_0.update_setting(setting_2, plugin)
    setting_3 = Setting('m', 'n', 'o')
    config_data_0.update_setting(setting_3, plugin)

    ret = config_data_0.get_settings(plugin)
   

# Generated at 2022-06-24 18:15:43.347391
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Test initalization
    config_data_0 = ConfigData()
    # Test get_settings, test get settings when the plugin is not set
    assert config_data_0.get_settings() == []

    # Test get_settings, test get settings when the plugin is set
    assert config_data_0.get_settings() == []



# Generated at 2022-06-24 18:15:46.202222
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    config_data_0.get_setting('action', True)
    config_data_0.get_setting('project_dir', True)


# Generated at 2022-06-24 18:15:49.209730
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting()


# Generated at 2022-06-24 18:15:56.486934
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    plugin_0 = None
    setting_0 = None
    setting_1 = None
    setting_2 = None
    setting_3 = None
    setting_4 = None
    config_data_0.update_setting(setting=setting_0, plugin=plugin_0)
    config_data_0.update_setting(setting=setting_2)
    config_data_0.update_setting(setting=setting_4, plugin=plugin_0)


# Generated at 2022-06-24 18:15:57.807478
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

# Generated at 2022-06-24 18:16:01.632887
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('', '', '')
    plugin_0 = Plugin('', '')
    config_data_0.update_setting(setting_0, plugin_0)
    assert config_data_0.get_setting('', plugin_0) == setting_0


# Generated at 2022-06-24 18:16:03.345513
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 18:16:05.293669
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(None, None)


# Generated at 2022-06-24 18:16:06.653274
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings = ConfigData().get_settings()
    assert settings is None


# Generated at 2022-06-24 18:16:11.543777
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from new_project.settings import Setting
    config_data_0 = ConfigData()

    setting = Setting(name='setting', value='value')
    config_data_0.update_setting(setting)

    # check if setting has been updated
    assert len(config_data_0.get_settings()) == 1



# Generated at 2022-06-24 18:16:21.904450
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()
    config_data_3 = ConfigData()

    setting_0 = Setting(configuration_key='key_0',
                        name='plugin.name',
                        defaults=dict(
                            type='plugin_type',
                            name='plugin_name',
                            foo='bar'
                        ))

    # Call method get_setting of config_data_1
    retval_1 = config_data_1.get_setting(setting_0.name)

    # Verify that attribute _global_settings of config_data_1 is equal to {}
    assert retval_1 == {}, 'Attribute _global_settings of config_data_1 does not equal to {}'

    # Call method update_setting of config_data_1

# Generated at 2022-06-24 18:16:23.793490
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # no exception raised, update_setting passed
    try:
        test_case_0()
    except Exception:
        assert(0)


# Generated at 2022-06-24 18:16:30.956835
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    plugin = Plugin(type='type_value', name='name_value')
    setting = Setting(name='name_value')
    config_data_0.update_setting(setting, plugin)
    # TODO: create a setting object and pass it to setting
    assert not config_data_0.get_setting('name_value')



# Generated at 2022-06-24 18:16:38.380118
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(
        [
            {
                'name': 'foo',
                'version': '1.0',
                'path': '/home/me/playbooks/roles/foo/tasks/main.yml',
                'type': 'role',
                'src': '',
                'line': 1,
                'source': 'foo',
                'options': {}
            }
        ]
    )


# Generated at 2022-06-24 18:16:40.598389
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    # Test with settings and plugins



# Generated at 2022-06-24 18:16:49.278909
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting_0, plugin_0)
    config_data_0.update_setting(setting_1, plugin_0)
    config_data_0.update_setting(setting_2, plugin_1)
    config_data_0.update_setting(setting_3, plugin_1)
    config_data_0.update_setting(setting_4)
    assert config_data_0.get_setting(name_0, plugin_0) == setting_0
    assert config_data_0.get_setting(name_1) == setting_4
    assert config_data_0.get_setting(name_2, plugin_2) == None


# Generated at 2022-06-24 18:16:51.928593
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    print(config_data_0.get_settings())


# Generated at 2022-06-24 18:17:03.412352
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()
    plugin_type_0 = 'foo'
    plugin_0 = {'type': plugin_type_0, 'name': 'bar'}
    plugin_type_1 = 'foo'
    plugin_1 = {'type': plugin_type_1, 'name': 'baz'}
    setting_name_0 = 'fly'
    setting_value_0 = 'Make it so.'
    setting_0 = {'name': setting_name_0, 'value': setting_value_0}

    config_data_0.update_setting(setting_0, plugin_0)
    config_data_0.update_setting(setting_0, plugin_1)
    result_0 = config_data

# Generated at 2022-06-24 18:17:08.765104
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    Setting_1 = {
        'name': 'SETTING_1',
        'value': 'your_value'
    }
    Plugin_1 = {
        'type': 'module',
        'name': 'module_1'
    }
    config_data_1.update_setting(Setting_1)
    config_data_1.update_setting(Setting_1, Plugin_1)

test_ConfigData_update_setting()

# Generated at 2022-06-24 18:17:10.334415
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()



# Generated at 2022-06-24 18:17:19.677752
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()

    setting_0 = Setting(name='sett_0', value='sett_0_value')
    config_data_1.update_setting(setting=setting_0)

    settings = config_data_1.get_settings()
    assert 1 == len(settings)
    assert setting_0 == settings[0]

    plugin_0 = Plugin(name='plugin_0', type='module')
    setting_1 = Setting(name='sett_1', value='sett_1_value')
    config_data_1.update_setting(setting=setting_1, plugin=plugin_0)

    settings = config_data_1.get_settings(plugin=plugin_0)
    assert 1 == len(settings)
    assert setting_1 == settings[0]


# Generated at 2022-06-24 18:17:28.071546
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting(name="timeout"))
    config_data_1.update_setting(Setting(name="verbosity"))
    plugin = Plugin(type="inventory", name="my_inventory")
    config_data_1.update_setting(Setting(name="hostfile"), plugin)
    config_data_1.update_setting(Setting(name="vars"), plugin)
    settings = config_data_1.get_settings()
    settings = config_data_1.get_settings(plugin)


# Generated at 2022-06-24 18:17:28.601132
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass

# Generated at 2022-06-24 18:17:33.894251
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert(config_data_0.get_setting('persistent_connection') is None)

# Generated at 2022-06-24 18:17:35.334379
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    assert config_data_0.update_setting() == None


# Generated at 2022-06-24 18:17:41.894792
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    test_case_0()

    config_data_1 = ConfigData()
    config_data_1.update_setting(TestSetting('a', 1.2))
    config_data_1.update_setting(TestSetting('b', 1.2), TestPlugin('c', 'b', 'c'))
    config_data_1.update_setting(TestSetting('d', 2.3))
    config_data_1.update_setting(TestSetting('d', 3.4), TestPlugin('d', 'd', 'd'))

    # Non-existent global setting
    assert config_data_1.get_setting('z', TestPlugin('a', 'b', 'c')) is None

    # Non-existent plugin setting

# Generated at 2022-06-24 18:17:46.323714
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    # Test exception raised for global setting when setting does not exist
    try:
        config_data_0.update_setting(None)
    except AttributeError as e:
        assert e.args[0] == "'NoneType' object has no attribute 'name'"


# Generated at 2022-06-24 18:17:58.886111
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    plugin_0 = ansible.plugins.connection.__init__.ConnectionPlugin(name='local', type='connection')
    setting_0 = ansible.plugins.connection.__init__.ConnectionSetting(name='unix', aliases=['unix'], description='Use the Unix socket for connecting', plugin=plugin_0)
    config_data_1.update_setting(setting_0, plugin=plugin_0)
    setting_1 = ansible.plugins.connection.__init__.ConnectionSetting(name='localhost', aliases=['localhost'], description='Use the Unix socket for connecting', plugin=plugin_0)
    config_data_1.update_setting(setting_1, plugin=plugin_0)

# Generated at 2022-06-24 18:18:03.065523
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('setting_0', 'setting_value_0')
    config_data_0.update_setting(setting_0)
    setting = config_data_0.get_setting('setting_0')
    assert setting.name == 'setting_0'
    assert setting.value == 'setting_value_0'



# Generated at 2022-06-24 18:18:05.688336
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Unit test for method update_setting of class ConfigData
    config_data = ConfigData()
    config_data.update_setting(None)


# Generated at 2022-06-24 18:18:07.979778
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:18:13.860495
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    fake_plugin = 'fake_plugin'
    fake_setting = 'fake_setting'

    assert 0 == len(config_data.get_settings())
    assert 0 == len(config_data.get_settings(fake_plugin))

    config_data.update_setting(fake_setting)
    assert 1 == len(config_data.get_settings())
    assert 0 == len(config_data.get_settings(fake_plugin))


# Generated at 2022-06-24 18:18:15.380250
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting('test_setting')


# Generated at 2022-06-24 18:18:21.386238
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    global_settings = config_data_1.get_settings()
    assert global_settings is []
    plugin = Plugin(0, 'test')
    setting = Setting('test', 'test')
    config_data_1.update_setting(setting, plugin)
    settings = config_data_1.get_settings(plugin)
    assert settings is not []


# Generated at 2022-06-24 18:18:26.598112
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_3 = ConfigData()

    setting_0 = Setting()
    setting_0.name = 'Setting'
    setting_0.value = 'value'

    config_data_3.update_setting(setting_0)



# Generated at 2022-06-24 18:18:28.946872
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting('name_0') is None


# Generated at 2022-06-24 18:18:37.385188
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
   

# Generated at 2022-06-24 18:18:50.289062
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_1 = {'name': 'AUTO_COLLAPSE_OUTPUT', 'default': False}
    config_data_1.update_setting(setting_1)
    assert config_data_1._global_settings['AUTO_COLLAPSE_OUTPUT'] is not None
    setting_2 = {'name': 'COMMAND_WARNINGS', 'default': True}
    config_data_1.update_setting(setting_2)
    assert config_data_1._global_settings['COMMAND_WARNINGS'] is not None

    ###########################################
    # testing update_setting with plugins

    setting_3 = {'name': 'timeout', 'default': 10}

# Generated at 2022-06-24 18:18:51.463454
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    result_0 = config_data_0.get_setting("armstrong")
    print(result_0)


# Generated at 2022-06-24 18:18:53.197264
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:18:54.702718
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()




# Generated at 2022-06-24 18:18:59.737118
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()

    setting_1 = Setting(name="test", value="test", scope="inventory_host", origin="test")

    config_data_1.update_setting(setting_1, None)

    assert config_data_1.get_setting("test") == setting_1


# Generated at 2022-06-24 18:19:01.003372
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert config_data_0.get_settings(None) != None




# Generated at 2022-06-24 18:19:10.682439
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    import copy
    from ansiblelint.rules.LineTooLong import LineTooLong
    from ansiblelint.rules.AnsibleLintRules import AnsibleLintRules
    from ansiblelint.rules.TrailingWhitespace import TrailingWhitespace
    from ansiblelint.rules.UsingCommandInsteadOfModule import UsingCommandInsteadOfModule
    line_too_long = LineTooLong()
    trailing_whitespace = TrailingWhitespace()
    using_command_instead_of_module = UsingCommandInsteadOfModule()
    ansible_lint_rules = AnsibleLintRules()
    ansible_lint_rules_copy = copy.deepcopy(ansible_lint_rules)

# Generated at 2022-06-24 18:19:13.327289
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    ret = config_data_0.get_setting()
    assert ret is None, "Failed to get expected result"


# Generated at 2022-06-24 18:19:15.889242
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:19:21.470219
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    plugin_0 = Plugin(None)
    setting_0 = Setting('None', 'None', 'bool', None, None, None, None)
    config_data_0.update_setting(setting_0, plugin=plugin_0)


# Generated at 2022-06-24 18:19:23.057633
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting() is None


# Generated at 2022-06-24 18:19:29.928479
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    configuration_setting = ConfigurationSetting(configuration_key="test_key_0", value="test_value_0")
    plugin_0 = Plugin(type=Plugin.CORE, name="core_plugin_0")
    config_data.update_setting(configuration_setting, plugin_0)
    configuration_setting = ConfigurationSetting(configuration_key="test_key_1", value="test_value_1")
    plugin_1 = Plugin(type=Plugin.CORE, name="core_plugin_1")
    config_data.update_setting(configuration_setting, plugin_1)
    configuration_setting = ConfigurationSetting(configuration_key="test_key_2", value="test_value_2")
    config_data.update_setting(configuration_setting)
    configuration_setting = ConfigurationSetting

# Generated at 2022-06-24 18:19:32.109455
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:19:35.619842
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting('setting_0')
    assert config_data_1.get_setting('setting_0') == 'setting_0'


# Generated at 2022-06-24 18:19:41.763783
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    setting = Setting('default', 'plugin_name', 'plugin_type', 2)

    config_data_0 = ConfigData()
    config_data_0.update_setting(setting)
    assert config_data_0.get_setting('default') == setting
    assert config_data_0.get_setting('non_existing') == None


# Generated at 2022-06-24 18:19:49.481831
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting( (ConfigSetting("debug", "Unittest", "B")) )
    if config_data_0._global_settings["debug"].key != "debug" and config_data_0._global_settings["debug"].value != "Unittest" and config_data_0._global_settings["debug"].value_type != "B":
        raise AssertionError("config_data_0._global_settings['debug'].key, config_data_0._global_settings['debug'].value, config_data_0._global_settings['debug'].value_type were not as expected")


# Generated at 2022-06-24 18:19:55.359914
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()


# Generated at 2022-06-24 18:20:04.999595
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_1._global_settings = {
        'p1': 'v1',
        'p2': 'v2',
        'p3': 'v3'
    }
    plugin1 = Plugin()
    plugin1.type = 'foo'
    plugin1.name = 'bar'
    plugin1.version = '1.0'
    config_data_1._plugins = {
        'foo': {
            'bar': {
                'p1': 'v1',
                'p2': 'v2',
                'p3': 'v3'
            }
        }
    }
    # Test case #0 - check for global settings

# Generated at 2022-06-24 18:20:08.395551
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    # Negative test case: no settings
    result = config_data_0.get_settings()
    assert result == []



# Generated at 2022-06-24 18:20:17.207033
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_1 = ConfigData()
    config_data_1.update_setting(AnsibleSetting(name='foo', value='bar'))
    assert len(config_data_1.get_settings()) == 1
    assert config_data_1.get_settings()[0].name == 'foo'
    assert config_data_1.get_settings()[0].value == 'bar'

    config_data_2 = ConfigData()
    config_data_2.update_setting(AnsibleSetting(name='foo', value='bar'), AnsiblePlugin(plugin_type='shell', plugin_name='sh'))
    assert len(config_data_2.get_settings(AnsiblePlugin(plugin_type='shell', plugin_name='sh'))) == 1

# Generated at 2022-06-24 18:20:18.726356
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    

# Generated at 2022-06-24 18:20:21.948028
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_case_0()

    config_data_0 = ConfigData()
    assert config_data_0.get_settings(None) == list(), "config_data_0.get_settings(None) != list()"


# Generated at 2022-06-24 18:20:23.536272
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting() is None


# Generated at 2022-06-24 18:20:25.937326
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    # Test with a non-plugin setting
    # Test with a setting for a plugin
    # Test with a setting for a plugin type


# Generated at 2022-06-24 18:20:26.965442
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()


# Generated at 2022-06-24 18:20:31.696441
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    test_setting_0 = Setting()
    test_setting_0.name = 'test_setting_0'
    config_data.update_setting(test_setting_0)

    settings = config_data.get_settings()

    if len(settings) != 1:
        raise AssertionError('Expected 1, got: ' + str(len(settings)))
    if settings[0].name != 'test_setting_0':
        raise AssertionError('Expected 1, got: ' + settings[0].name)

    print('test_ConfigData_get_settings: PASS')



# Generated at 2022-06-24 18:20:41.682871
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting()


# Generated at 2022-06-24 18:20:48.013297
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()

    setting_0 = Setting(name='force_color', value='false', origin='default')
    config_data_1.update_settings(setting_0, plugin=None)

    setting_1 = Setting(name='force_color', value='true')
    config_data_1.update_settings(setting_1, plugin=Plugin(type='default', name='colors'))

    setting_2 = Setting(name='force_color', value='true')
    config_data_1.update_settings(setting_2, plugin=Plugin(type='core', name='display'))

    setting_3 = Setting(name='force_color', value='false')
    config_data_1.update_settings(setting_3, plugin=Plugin(type='core', name='colors'))

    setting_

# Generated at 2022-06-24 18:20:50.455902
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    
    assert config_data_0._global_settings == {}
    assert config_data_0._plugins == {}


# Generated at 2022-06-24 18:20:52.544702
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert config_data_1.get_settings().__len__() == 0


# Generated at 2022-06-24 18:21:04.225884
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    # ConfigData with 1 global setting instance
    setting_0 = ConfigSetting('setting', 'global', 'global', 'global', 'global')
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_settings()[0] == setting_0

    # ConfigData with 1 internal plugin setting instance
    plugin_0 = ConfigPlugin('ansible.builtin', 'myplugin', 'myplugin', 'myplugin', 'myplugin')
    setting_1 = ConfigSetting('setting', 'global', 'global', 'global', 'global')
    config_data_0.update_setting(setting_1, plugin_0)
    assert config_data_0.get_settings(plugin_0)[0] == setting_1

    # ConfigData with 2 global setting instances
   

# Generated at 2022-06-24 18:21:06.531813
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Declare local variables
    config_data_1 = ConfigData()
    setting_0 = Setting("setting_0")

    config_data_1.update_setting(setting_0)

    # We should have one setting in the global set
    assert len(config_data_1._global_settings) == 1
    assert setting_0.name in config_data_1._global_settings


# Generated at 2022-06-24 18:21:08.247667
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    value = config_data_0.get_setting('legacy', plugin=None)
    assert value is None


# Generated at 2022-06-24 18:21:16.638611
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert cd.get_setting('test') is None
    assert cd.get_settings() == []

    g_setting = ConfigSetting({'name': 'test', 'value': 'test_value'})
    cd.update_setting(g_setting)
    assert cd.get_setting('test') is not None
    assert cd.get_setting('test').value == 'test_value'
    assert cd.get_settings() is not None
    assert len(cd.get_settings()) == 1

    p_setting = ConfigSetting({'name': 'test', 'value': 'p_test_value'})
    p = Plugin({'type': 'test_type', 'name': 'test_name'})
    cd.update_setting(p_setting, p)
    assert cd.get_setting('test', p)

# Generated at 2022-06-24 18:21:18.936815
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()
    setting_0 = Setting()
    setting_1 = Setting()
    setting_2 = Setting()


# Generated at 2022-06-24 18:21:20.936571
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    result = config_data_0.get_settings()


# Generated at 2022-06-24 18:21:38.377267
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings_0 = config_data_0.get_settings()
    assert not settings_0


# Generated at 2022-06-24 18:21:40.191924
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting)


# Generated at 2022-06-24 18:21:43.104757
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting({})


# Generated at 2022-06-24 18:21:47.528936
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    plugin_0 = Plugin(namespace='ansible_collections.ns.coll')
    setting_0 = Setting(name='data.variable')
    config_data_1.update_setting(setting_0, plugin_0)



# Generated at 2022-06-24 18:21:52.073031
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Arrange
    config_data_0 = ConfigData()
    setting_0 = Setting('foo', 'bar')

    # Act
    config_data_0.update_setting(setting_0)
    setting_1 = config_data_0.get_setting('foo')

    # Assert
    assert setting_1.name == 'foo'
    assert setting_1.value == 'bar'


# Generated at 2022-06-24 18:22:01.954344
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    # Test for method update_setting in class ConfigData with 
    # existing global setting
    config_data_1.update_setting(ConfigSetting('default_callback', 'default', 'stdout'))
    assert config_data_1.get_setting('default_callback') == 'stdout'
    config_data_1.update_setting(ConfigSetting('default_callback', 'default', 'json'))
    assert config_data_1.get_setting('default_callback') == 'json'

    # Test for method update_setting in class ConfigData with a new global
    # setting
    config_data_1.update_setting(ConfigSetting('callback_whitelist', 'default', 'my_callback'))

# Generated at 2022-06-24 18:22:07.240001
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    global_setting_0 = Setting('constant_inventory_enabled', 'false')
    config_data_0.update_setting(global_setting_0)
    setting_0 = config_data_0.get_setting('constant_inventory_enabled')
    print(setting_0.name)
    print(setting_0.value)
    print("test_case_0 : Passed!")



# Generated at 2022-06-24 18:22:08.261549
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    # TODO: Implement
    assert True



# Generated at 2022-06-24 18:22:14.270165
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings(None) == []
    config_data_0.update_setting(Setting('foo', 'bar'), None)
    assert config_data_0.get_settings(None) == [Setting('foo', 'bar')]



# Generated at 2022-06-24 18:22:18.910819
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    testing_object = ConfigData()

    assert testing_object.get_setting() == None
    assert testing_object.get_setting() == None
    assert testing_object.get_setting() == None

# Generated at 2022-06-24 18:23:04.588680
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_1 = Plugin("", "", "")
    assert config_data_0.get_settings(plugin_1) == []


# Generated at 2022-06-24 18:23:05.417655
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:23:06.428224
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()


# Generated at 2022-06-24 18:23:07.761736
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_=ConfigData()
    assert config_data_.get_setting(None)==None


# Generated at 2022-06-24 18:23:17.114206
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting(name='ansible_verbosity', value='1'))
    config_data_1.update_setting(Setting(name='ansible_connection', value='network_cli', plugin_type='connection', plugin_name='netconf'))

    settings = config_data_1.get_settings();
    assert len(settings) == 1
    assert settings[0].name == 'ansible_verbosity'
    assert settings[0].value == '1'

    settings = config_data_1.get_settings(Plugin(type='connection', name='netconf'))
    assert len(settings) == 1
    assert settings[0].name == 'ansible_connection'
    assert settings[0].value == 'network_cli'



# Generated at 2022-06-24 18:23:26.512504
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == [config_data_0._global_settings]
    assert config_data_0.get_settings() == config_data_0._global_settings
    assert config_data_0.get_settings("test") == config_data_0._plugins["test"]
    assert type(config_data_0.get_settings("test")) == dict
    assert type(config_data_0.get_settings()) == dict


# Generated at 2022-06-24 18:23:35.171882
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert ((config_data_0.get_setting('foo', None) is None) == True)
    # Add setting to settings list
    settings_0 = Setting('foo', 'bar', 'Baz')
    config_data_0.update_setting(settings_0, None)
    assert (config_data_0.get_setting('foo', None) is settings_0)


# Generated at 2022-06-24 18:23:36.936229
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-24 18:23:42.890213
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting()
    config_data_0.update_setting(setting_0)
    assert setting_0 == config_data_0.get_setting(None)


# Generated at 2022-06-24 18:23:52.105970
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

  # Test with a plugin and a name that already exists in the data
  config_data = ConfigData()
  plugin = Plugin('my_plugin', 'my_type')
  config_setting = ConfigSetting('is_valid', True)
  config_data.update_setting(config_setting, plugin)

  assert config_data.get_setting('is_valid', plugin) is not None
  assert config_data.get_setting('is_valid', plugin).name == 'is_valid'
  assert config_data.get_setting('is_valid', plugin).value == True
  assert config_data.get_setting('is_valid', plugin).plugin.name == 'my_plugin'
  assert config_data.get_setting('is_valid', plugin).plugin.type == 'my_type'
