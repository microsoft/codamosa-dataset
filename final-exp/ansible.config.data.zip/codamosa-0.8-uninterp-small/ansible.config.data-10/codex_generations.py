

# Generated at 2022-06-24 18:15:04.586847
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    # This is a simple case
    config_data_update_setting = config_data.update_setting(setting)


# Generated at 2022-06-24 18:15:09.553893
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    plugin_0 = MockPlugin()
    setting_0 = MockSetting()
    config_data_0.update_setting(setting_0, plugin_0)
    assert config_data_0._global_settings == {}



# Generated at 2022-06-24 18:15:12.518551
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings_0 = config_data_0.get_settings()
    settings_0 = config_data_0.get_settings()
    settings_0 = config_data_0.get_settings()
    print(settings_0)

# Generated at 2022-06-24 18:15:14.752391
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    global config_data_0
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:15:22.294254
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('test_setting_name', 'test_setting_value')
    setting_1 = Setting('test_setting_name', 'test_setting_value')
    config_data_0.update_setting(setting_0)
    setting_0 = config_data_0.get_setting('test_setting_name')
    assert setting_0 == setting_1



# Generated at 2022-06-24 18:15:28.488344
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_0 = ansible.module_utils.config_loader.setting.Setting()
    setting_0.name = "SRV_ID"
    setting_0.description = "The ID of the server"
    setting_0.value = "my_server"
    config_data_1.update_setting(setting_0)
    setting_1 = ansible.module_utils.config_loader.setting.Setting()
    setting_1.name = "SRV_PASSWORD"
    setting_1.description = "The password of the server"
    setting_1.value = "s3kr1t"
    config_data_1.update_setting(setting_1)
    setting_2 = ansible.module_utils.config_loader.setting.Setting()

# Generated at 2022-06-24 18:15:31.688100
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    for name in set([None, '', 'null', 'instrumentation-type', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9']):
        try:
            config_data_0.get_setting(name, plugin=None)
        except (TypeError, ValueError) as e:
            assert True
        else:
            assert False


# Generated at 2022-06-24 18:15:33.493517
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting()


# Generated at 2022-06-24 18:15:35.910169
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:15:45.732992
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_plugin
    from ansible.plugins.loader import get_plugins_of_category
    from ansible.plugins.loader import get_plugin_paths
    from ansible.plugins.loader import list_plugin_classes
    from ansible.plugins.loader import list_plugin_names
    from ansible.plugins.loader import list_plugins
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    #

# Generated at 2022-06-24 18:15:52.019659
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    
    # Test with non-existing setting
    assert config_data_0.get_setting('name') is None
    assert config_data_0.get_setting('name', None) is None


# Generated at 2022-06-24 18:15:53.189491
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # TODO: build test case
    raise NotImplementedError


# Generated at 2022-06-24 18:15:58.322719
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    cli_config_setting_0 = config_data_0.get_setting("default_remote_tmp")
    assert cli_config_setting_0.name == "default_remote_tmp"
    assert cli_config_setting_0.plugin.type == "core"
    assert cli_config_setting_0.plugin.name == "core"
    assert cli_config_setting_0.value == "$HOME/.ansible/tmp"
    assert cli_config_setting_0.raw == "unset"


# Generated at 2022-06-24 18:16:02.076212
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='foo', value='bar')
    config_data_0.update_setting(setting_0)
    setting_1 = config_data_0.get_setting('foo')
    assert(setting_1.name == 'foo')
    assert(setting_1.value == 'bar')


# Generated at 2022-06-24 18:16:05.234910
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting()
    config_data_0.get_setting()
    config_data_0.get_setting()
    config_data_0.get_setting()


# Generated at 2022-06-24 18:16:10.168471
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    setting = Setting(name="ansible_connection", value="network_cli")
    assert (not config_data_1.get_settings())
    config_data_1._global_settings["ansible_connection"] = setting
    assert (config_data_1.get_settings())


# Generated at 2022-06-24 18:16:15.661294
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Arrange
    config_data = ConfigData()
    config_data.update_setting(Setting('some.key', '/etc/foo.conf'))

    # Act
    config_data.update_setting(Setting('some.key', '/etc/new_foo.conf'))

    # Assert
    assert config_data.get_setting('some.key').value == '/etc/new_foo.conf'



# Generated at 2022-06-24 18:16:21.953141
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    plugin_0 = DummyPlugin(name='foo', type='bar')
    setting_0 = DummySetting(name='foo', plugin=plugin_0)
    config_data_0.update_setting(setting_0, plugin_0)

    assert config_data_0.get_setting('foo', plugin_0) == setting_0
    assert config_data_0.get_setting('foo', plugin=None) is None


# Generated at 2022-06-24 18:16:27.320957
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_case_0()
    config_data_1 = ConfigData()
    s = Setting("A", "B")
    config_data_1.update_setting(s)
    assert config_data_1.get_settings() == [s], "Method get_settings of class ConfigData is not working as expexted"



# Generated at 2022-06-24 18:16:29.518799
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting("abc")


# Generated at 2022-06-24 18:16:38.668818
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    # update setting without a plugin
    config_data_0.update_setting(setting)

    assert (config_data_0.get_setting("path")) == 'path_value'
    assert (config_data_0.get_setting("other_path")) == 'other_path_value'
    assert (config_data_0.get_settings()) == [{'name': 'path', 'value': 'path_value'}, {'name': 'other_path', 'value': 'other_path_value'}]

    # update setting for a specific plugin
    config_data_0.update_setting(setting, plugin=Plugin(type="netconf", name="nxos"))

    assert (config_data_0.get_setting("path")) == 'path_value'

# Generated at 2022-06-24 18:16:39.676064
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert False  # TODO: implement your test here


# Generated at 2022-06-24 18:16:42.464776
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    result = config_data_0.get_settings()
    assert result == []



# Generated at 2022-06-24 18:16:47.552228
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:16:50.154792
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    ansible_config_1 = config_data_0.get_settings()


# Generated at 2022-06-24 18:16:58.797310
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    from ansible.module_utils.ansible_release import __version__
    from ansible.plugins.loader import configuration
    setting = configuration.Setting(name='SOME_SETTING', description='This is a description', default='some default',
                                    env_var='SOME_SETTING', value_type='str', ini=True, cli=True,
                                    version_added=__version__)

    config_data_0.update_setting(setting)

    assert config_data_0.get_setting('SOME_SETTING') is not None



# Generated at 2022-06-24 18:17:02.199494
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting('FzHs')


# Generated at 2022-06-24 18:17:03.639361
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:17:05.961305
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    setting = 'default_debug=true'
    config_data.update_setting(setting)
    assert config_data._global_settings['default_debug'] == 'true'



# Generated at 2022-06-24 18:17:09.007957
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting_0 = Setting(None, None, None)
    plugin_0 = Plugin(None, None)
    assert config_data_1.get_setting(setting_0, plugin_0) is None


# Generated at 2022-06-24 18:17:19.105883
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_1._global_settings = {'a': 1, 'b': 2}
    config_data_1._plugins = {'a': {'1': {'c': 3, 'd': 4}}}
    assert config_data_1.get_settings() == [config_data_1._global_settings['a'], config_data_1._global_settings['b']]
    assert config_data_1.get_settings('a', '1') == [config_data_1._plugins['a']['1']['c'], config_data_1._plugins['a']['1']['d']]

# Generated at 2022-06-24 18:17:21.463937
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-24 18:17:27.131654
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None, plugin=None)
    assert len(config_data_0.get_settings()) == 0
    assert config_data_0._global_settings is not None


# Generated at 2022-06-24 18:17:29.237449
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting('foo') == None


# Generated at 2022-06-24 18:17:30.497413
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None)


# Generated at 2022-06-24 18:17:34.815263
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None)
    assert isinstance(config_data_0.get_settings(plugin=None), list)


# Generated at 2022-06-24 18:17:43.045150
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    setting = TestSetting(name='test_setting')
    config_data_0.update_setting(setting, TestPlugin('test_plugin'))

    setting.value = 'test_value'
    config_data_0.update_setting(setting, TestPlugin('test_plugin'))

    assert config_data_0.get_setting('test_setting', TestPlugin('test_plugin')).value == 'test_value'


# Generated at 2022-06-24 18:17:45.458711
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting())
    setting = config_data_0.get_setting('string')
    assert setting is not None
    assert setting.values == ['ansible.test.test_config.test_case_0()']


# Generated at 2022-06-24 18:17:48.852804
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings(plugin=None) == [], 'assert#1 failed'


# Generated at 2022-06-24 18:17:58.561464
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting_0 = Setting('setting_0', 'value_0')
    config_data_0.update_setting(setting_0)
    setting_1 = Setting('setting_1', 'value_1')
    config_data_0.update_setting(setting_1)
    setting_2 = Setting('setting_2', 'value_2')
    config_data_0.update_setting(setting_2)
    settings = config_data_0.get_settings()
    assert settings == [setting_0, setting_1, setting_2]



# Generated at 2022-06-24 18:18:09.375035
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_setting_0 = ConfigSetting('setting_name', 'setting_value')
    config_setting_1 = ConfigSetting('setting_name', 'setting_value')
    config_setting_2 = ConfigSetting('setting_name', 'setting_value')
    config_setting_3 = ConfigSetting('setting_name', 'setting_value')
    config_setting_4 = ConfigSetting('setting_name', 'setting_value')
    config_plugin_0 = ConfigPlugin('plugin_name', 'plugin_type')
    config_plugin_1 = ConfigPlugin('plugin_name', 'plugin_type')
    config_plugin_2 = ConfigPlugin('plugin_name', 'plugin_type')
    config_plugin_3 = ConfigPlugin('plugin_name', 'plugin_type')
    config_plugin_4 = Config

# Generated at 2022-06-24 18:18:16.536865
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    # test case 0
    config_data_0 = ConfigData()
    plugin = Plugin(type_='something', name='something_else', module='a module')
    assert config_data_0.get_setting('no_setting', plugin) is None
    # test case 1
    config_data_1 = ConfigData()
    assert config_data_1.get_setting('no_setting') is None
    # test case 2
    config_data_2 = ConfigData()
    plugin_2 = Plugin(type_='something', name='something_else', module='a module')
    config_data_2.update_setting(Setting(name='test'))
    config_data_2.update_setting(Setting(name='test2'))

# Generated at 2022-06-24 18:18:20.066298
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = MockSetting('name_0', 'value_0')
    setting_0.type = 'type_0'
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_setting(setting_0.name) == setting_0


# Generated at 2022-06-24 18:18:25.947164
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_0 = Setting('my_setting', 'my_value')
    plugin_0 = Plugin('type', 'name')
    config_data_1.update_setting(setting_0, plugin_0)

# Generated at 2022-06-24 18:18:35.270815
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test with undefined plugin
    # Expected result: success
    plugin_0 = ansible.plugins.loader.PluginLoader._load_module_source({"_original_path": "loader.py", "_module_name": "loader", "_load_name": "loader", "name": "loader", "type": "module_utils"})
    config_data_0 = ConfigData()
    config_data_0.update_setting(config_data_0, plugin_0)
    # Test with correct argument
    # Expected result: success
    config_data_1 = ConfigData()
    config_data_1.update_setting(config_data_1, plugin_0)
    # Test with undefined setting
    # Expected result: success
    config_data_2 = ConfigData()

# Generated at 2022-06-24 18:18:39.679987
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    plugin_0 = Plugin('', '', '', '')
    setting_0 = PluginSetting('', '', '', '', '', '')
    config_data_0.update_setting(setting_0, plugin_0)
    assert config_data_0.get_setting(setting_0.name, plugin_0) == setting_0


# Generated at 2022-06-24 18:18:42.590661
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() is not None


# Generated at 2022-06-24 18:18:44.108865
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 18:18:45.927445
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()


# Generated at 2022-06-24 18:18:48.663398
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    # Test with no plugin, where the config setting should be looked up from the global_settings
    setting = config_data_0.get_setting('type_name')
    assert setting == None, "Global setting should be empty"
    setting = config_data_0.get_setting('context')
    assert setting == None, "Global setting should be empty"
    setting = config_data_0.get_setting('name')
    assert setting == None, "Global setting should be empty"
    setting = config_data_0.get_setting('foo')
    assert setting == None, "Global setting should be empty"


# Generated at 2022-06-24 18:18:58.737605
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=Setting(name='setting_2', value='setting_2_value'))
    config_data_0.update_setting(setting=Setting(name='setting_4', value='setting_4_value', plugin=Plugin(type='type_1', name='name_1')))
    assert config_data_0.get_setting(name='setting_2') == 'setting_2_value'
    assert config_data_0.get_setting(name='setting_4', plugin=Plugin(type='type_1', name='name_1')) == 'setting_4_value'
    assert config_data_0.get_setting(name='setting_2', plugin=Plugin(type='type_1', name='name_1')) is None



# Generated at 2022-06-24 18:19:07.068678
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_1 = ConfigData()

    setting_2 = Setting(name='setting.name')
    plugin_3 = Plugin(name='plugin.name', type='plugin.type')

    config_data_1.update_setting(setting_2, plugin_3)

    setting_4 = config_data_1.get_setting('setting.name', plugin_3)
    assert type(setting_4) == Setting
    assert setting_4.name == 'setting.name'

    setting_5 = config_data_1.get_setting('other.name', plugin_3)
    assert setting_5 is None


# Generated at 2022-06-24 18:19:13.511448
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    test_setting_0 = Setting()
    config_data_0.update_setting(test_setting_0)
    test_plugin_0 = Plugin()
    config_data_0.update_setting(test_setting_0, test_plugin_0)
    test_plugin_0_0 = PluginType()
    test_plugin_0 = Plugin(test_plugin_0_0)
    config_data_0.update_setting(test_setting_0, test_plugin_0)


# Generated at 2022-06-24 18:19:16.573775
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=[0])


# Generated at 2022-06-24 18:19:20.007802
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    setting_0 = MockSetting(name='bar')
    cd.update_setting(setting_0, plugin=None)


# Generated at 2022-06-24 18:19:25.908675
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    class Plugin:
        def __init__(self, type, name):
            self.type=type
            self.name=name
    class Setting:
        def __init__(self, name):
            self.name=name
    # ConfigData.update_setting(setting, plugin=None)
    setting = Setting('ansible_cfg')
    plugin = Plugin('action', 'AnsibleModule')
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting)
    config_data_0.update_setting(setting, plugin)
    pass


# Generated at 2022-06-24 18:19:29.484544
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert isinstance(config_data_0.get_settings(), list) and config_data_0.get_settings() == []


# Generated at 2022-06-24 18:19:31.981029
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:19:36.258875
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('string', 'default', 'description', 'section', 'name'))
    settings = config_data_1.get_settings()
    assert len(settings) == 1
    assert settings[0].default == 'default'
    assert settings[0].description == 'description'
    assert settings[0].section == 'section'
    assert settings[0].name == 'name'
    assert settings[0].value == 'default'


# Generated at 2022-06-24 18:19:39.301674
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    assert True == config_data_0.update_setting(None)


# Generated at 2022-06-24 18:19:51.941383
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('pem_file', '~/.ssh/id_rsa'))
    config_data.update_setting(Setting('use_tty', 'False'), Plugin('connection', 'presto'))
    config_data.update_setting(Setting('pem_file', '~/.ssh/id_rsa.pub', 'path'))
    config_data.update_setting(Setting('pem_file', '~/.ssh/id_rsa.pub', 'path', 'connect'))
    config_data.update_setting(Setting('yum_baseurl', 'http://mirror.centos.org/centos/7/os/x86_64/'))
    assert config_data.get_settings() and len(config_data.get_settings())

# Generated at 2022-06-24 18:19:58.640577
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_1 = Plugin(1, 2, 3)
    setting_2 = Setting(4, 5, 6)
    config_data_0.update_setting(setting_2, plugin_1)
    settings_3 = config_data_0.get_settings(plugin_1)
    assert settings_3 == [setting_2]


# Generated at 2022-06-24 18:20:01.362363
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings_0 = config_data_0.get_settings()
    assert settings_0 == []


# Generated at 2022-06-24 18:20:09.843034
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin = MockPlugin('type_x', 'name_x')

    setting = MockSetting('setting_x1')
    config_data = ConfigData()
    config_data.update_setting(setting)

    assert config_data.get_settings(plugin) == []
    assert config_data.get_settings() == [setting]

    setting = MockSetting('setting_x2')
    config_data.update_setting(setting, plugin)

    assert config_data.get_settings(plugin) == [setting]



# Generated at 2022-06-24 18:20:18.104947
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Test Get Global setting
    config_data_0 = ConfigData()
    setting_data_0 = SettingData()
    setting_data_0.name = "test_setting_0"
    setting_data_0.value = "test_value_0"
    config_data_0.update_setting(setting_data_0)
    assert config_data_0.get_setting("test_setting_0").value == "test_value_0"

    # Test Get Plugin setting
    plugin_data_0 = PluginData()
    plugin_data_0.type = "test_type_0"
    plugin_data_0.name = "test_name_0"
    setting_data_1 = SettingData()
    setting_data_1.name = "test_setting_1"

# Generated at 2022-06-24 18:20:21.309425
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    # Test update when there is not plugin
    config_data_0.update_setting('Setting1')
    assert config_data_0.get_setting('Setting1') == 'Setting1'


# Generated at 2022-06-24 18:20:22.864216
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:20:25.135081
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings_0 = config_data_0.get_settings()
    assert settings_0 == []


# Generated at 2022-06-24 18:20:26.424210
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()



# Generated at 2022-06-24 18:20:34.539503
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.config.setting import Setting

    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting('defaults', 'sudo_flags', 'list', default='-H', origin='defaults'))
    config_data_0.update_setting(Setting('playbook', 'remote_user', 'string', default='root', origin='defaults'))
    config_data_0.update_setting(Setting('action_plugin', 'deprecation_warnings', 'bool', default=True, origin='defaults'))
    config_data_0.update_setting(Setting('inventory', 'timeout', 'float', default=10.0, origin='defaults'))
    assert config_data_0._global_settings['defaults'].name == 'defaults'
    assert config_data_0._global_

# Generated at 2022-06-24 18:20:44.626699
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:20:54.160790
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    # Empty string name
    try:
        config_data_0.get_setting("")
        assert False
    except:
        pass

    # Invalid plugin type
    try:
        config_data_0.get_setting("Invalid", "Invalid")
        assert False
    except:
        pass

    # Invalid plugin name
    try:
        config_data_0.get_setting("Invalid", Plugin("Invalid", "Invalid"))
        assert False
    except:
        pass

    # Invalid setting name
    try:
        config_data_0.get_setting("Invalid", Plugin("Invalid", "Invalid"))
        assert False
    except:
        pass


# Generated at 2022-06-24 18:21:04.972943
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

# Generated at 2022-06-24 18:21:06.891419
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Create an instance of ConfigData
    config_data_1 = ConfigData()
    config_data_1.update_setting(self.test_case_0(), None)


# Generated at 2022-06-24 18:21:08.309299
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(None)


# Generated at 2022-06-24 18:21:18.143329
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # ceate config data instance
    config_data_0 = ConfigData()

    # update setting plugin_name_0
    config_data_0.update_setting(
        Setting('plugin_name_0'))

    # update settings plugin_name_1
    config_data_0.update_setting(
        Setting('plugin_name_1'))

    # update settings plugin_name_2
    config_data_0.update_setting(
        Setting('plugin_name_2'))

    # update settings plugin_name_2 with plugin type and name
    config_data_0.update_setting(
        Setting('plugin_name_3'), Plugin(type='action', name='copy'))
    config_data_0.update_setting(
        Setting('plugin_name_4'), Plugin(type='action', name='copy'))


# Generated at 2022-06-24 18:21:28.296677
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    # Global settings
    config_data_0.update_setting(Setting('setting_0', 'global', 'global', 'global', None))
    config_data_0.update_setting(Setting('setting_1', 'global', 'global', 'global', None))
    config_data_0.update_setting(Setting('setting_2', 'global', 'global', 'global', None))

    # Module settings
    module_plugin_0 = Plugin('module', 'module_plugin_0')
    module_plugin_1 = Plugin('module', 'module_plugin_1')
    module_plugin_2 = Plugin('module', 'module_plugin_2')

# Generated at 2022-06-24 18:21:40.047510
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_0 = Setting('key_file', 'private.key', 'global', 'ansible.cfg')

    assert config_data_1 is not None

    config_data_1.update_setting(setting_0)
    setting_1 = config_data_1.get_setting('key_file')

    assert setting_1.name == 'key_file'
    assert setting_1.value == 'private.key'

    setting_0.value = 'public.key'
    config_data_1.update_setting(setting_0)

    setting_1 = config_data_1.get_setting('key_file')

    assert setting_1.name == 'key_file'
    assert setting_1.value == 'public.key'


# Generated at 2022-06-24 18:21:43.480793
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting_0, plugin=plugin_0)


# Generated at 2022-06-24 18:21:45.198006
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:21:59.684749
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting_1 = Setting()
    plugin_1 = Plugin()
    plugin_1.name = "plugin_name_1"
    plugin_1.type = "plugin_type_1"
    config_data_1.update_setting(setting_1, plugin_1)
    assert config_data_1.get_setting("setting_name_1") == None
    assert config_data_1.get_setting("setting_name_1", plugin_1) == setting_1


# Generated at 2022-06-24 18:22:02.014105
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting("/etc/profile.d/ansible.sh") is None


# Generated at 2022-06-24 18:22:09.828075
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting = Setting(None, "setting_name_1", "setting_value_1")
    config_data_1.update_setting(setting)
    setting = Setting(Plugin(None, "plugin_name_1"), "setting_name_1", "setting_value_1")
    config_data_1.update_setting(setting)
    setting = Setting(Plugin("plugin_type_1", "plugin_name_1"), "setting_name_1", "setting_value_1")
    config_data_1.update_setting(setting)
    setting = config_data_1.get_setting("setting_name_1")
    assert setting.name == "setting_name_1"
    assert setting.value == "setting_value_1"
    assert setting.plugin is None
    setting

# Generated at 2022-06-24 18:22:11.433327
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:22:14.212086
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(None)


# Generated at 2022-06-24 18:22:17.777639
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:22:28.565908
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # First test with a non-None plugin
    config_data_1 = ConfigData()
    assert config_data_1._global_settings == {}
    assert config_data_1._plugins == {}

    setting = {'name': 'foo_setting', 'value': 'foo_value'}
    config_data_1.update_setting(setting)
    assert config_data_1._global_settings == {'foo_setting': setting}
    assert config_data_1._plugins == {}

    # Second test with a None plugin
    plugin = {'type': 'foo_type', 'name': 'foo_name'}
    config_data_1.update_setting(setting, plugin)
    assert config_data_1._global_settings == {'foo_setting': setting}

# Generated at 2022-06-24 18:22:37.784726
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    # Test update_setting with plugin_type 'callback'
    assert set(config_data_0.get_settings(plugin_type='callback')) == set()

    config_data_0.update_setting(setting={'plugin_type': 'callback', 'name': 'foo', 'value': 'bar'},
                                 plugin={'type': 'callback', 'name': 'bar'})

    assert config_data_0.get_settings(plugin_type='callback')[0]['name'] == 'foo'

    # Test update_setting with setting.name 'DEFAULT_CALLBACK'
    assert config_data_0.get_settings(plugin_type='callback')[0]['name'] == 'foo'

# Generated at 2022-06-24 18:22:39.621905
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting("test")


# Generated at 2022-06-24 18:22:41.749675
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting('plugin.yml')
    try:
        assert config_data_0
    except AssertionError:
        pass

# Generated at 2022-06-24 18:22:58.860281
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    test_setting = Setting('setting.name', 'setting.value', 'setting.description', 'setting.short_desc', 'setting.env',
                           'int')
    config_data.update_setting(test_setting)
    assert config_data._global_settings['setting.name'] == test_setting



# Generated at 2022-06-24 18:23:06.447101
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_0 = ConfigSetting(name='setting_0', value=None)
    plugin_0 = Plugin('Test', 'test', 'collection')
    plugin_1 = Plugin('Test', 'test', 'inventory')

    # update_setting with plugin_0
    config_data.update_setting(setting_0, plugin_0)
    assert config_data._plugins['collection']['Test.test']['setting_0'] == setting_0
    assert config_data._global_settings == {}
    assert 'collection' in config_data._plugins
    assert 'Test.test' in config_data._plugins['collection']
    assert 'setting_0' in config_data._plugins['collection']['Test.test']

    # update_setting with plugin_1

# Generated at 2022-06-24 18:23:08.546068
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting())
    print(config_data_0.get_setting(Setting()))


# Generated at 2022-06-24 18:23:15.495619
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # test set_setting
    setting = ConfigurationSetting(name='test_setting_0')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting_0') == setting
    # test set_plugin_setting
    setting = ConfigurationSetting(name='test_setting_1')
    config_data.update_setting(setting, plugin=Plugin('test_plugin', 'test_type'))
    assert config_data.get_setting('test_setting_1', plugin=Plugin('test_plugin', 'test_type')) == setting



# Generated at 2022-06-24 18:23:18.054361
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting('foo') is None


# Generated at 2022-06-24 18:23:24.044773
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(constants.COMMAND_LINE)
    config_data_0.update_setting(setting_0, None)
    settings_0 = config_data_0.get_settings()
    for s_0 in settings_0:
        if s_0.name == setting_0.name:
            assert(True)
            return
    assert(False)


# Generated at 2022-06-24 18:23:28.551566
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    #
    #  Note: initial run of this test will fail and raise TypeError, because
    #  method get_settings of class ConfigData has incorrect signature,
    #  i.e. it should take a parameter with default value.
    #
    config_data_0 = ConfigData()
    #
    #  This line will raise TypeError
    #
    setting_0 = config_data_0.get_settings()


# Generated at 2022-06-24 18:23:39.621127
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    setting_1 = ConfigSetting()
    setting_1.name = 'ansible_managed'
    setting_1.type = 'string'
    setting_1.default = '/etc/ansible/roles/ansible-role-dummy/templates/dummy.j2'
    setting_1.description = 'A string that can be used to describe the template name, host, modification time of the template file and the owner uid, when the template file is modified.'
    setting_1.inclusions = 'all'
    setting_1.value = 'This file has been managed by Ansible, all changes will be lost!'

    plugin_2 = ConfigPlugin()
    plugin_2.type = 'template'
    plugin_2.name = 'j2'

    config_data_0.update_setting

# Generated at 2022-06-24 18:23:41.813042
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:23:51.706345
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting({'name': 'verbose', 'default': 'y', 'config': {'key': 'verbose', 'section': 'none', 'file': 'ansible.cfg', 'type': 'boolean', 'choices': [], 'scope': {'subkey': '', 'path': '/etc/ansible'}, 'env': ['ANSIBLE_VERBOSE'], 'version_added': '0.1', 'description': 'Show detailed information about the running playbook.'}})

# Generated at 2022-06-24 18:24:21.497192
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    input_plugin_0 = Plugin(
        'connection',
        'local',
        'action',
        '0.0.0.0',
        '8100',
        'username',
        'password',
    )
    input_plugin_1 = Plugin(
        'connection',
        'local',
        'action',
        '0.0.0.0',
        '8100',
        'username',
        'password',
    )
    expected = []
    actual = config_data_0.get_settings(input_plugin_0)
    assert actual == expected
    expected = []
    actual = config_data_0.get_settings(input_plugin_1)
    assert actual == expected


# Generated at 2022-06-24 18:24:29.238082
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_1 = ConfigData()
    plugin_1 = PluginDescriptor('connection', 'dummy')
    setting_1 = ConfigSetting(plugin_1, 'executable_path', 'relative', '', '', '', '', '', '')
    config_data_1.update_setting(setting_1, plugin_1)

    assert config_data_1.get_setting('executable_path', plugin_1) == setting_1, \
        "Failed to get a setting"

    assert config_data_1.get_settings(plugin_1) != [], \
        "Failed to get settings"

    assert config_data_1.get_settings(plugin_1)[0] == setting_1, \
        "Failed to get a setting"


# Generated at 2022-06-24 18:24:31.842154
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting='setting_0')


# Generated at 2022-06-24 18:24:36.837911
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Initialize
    config_data_0 = ConfigData()
    plugin_0 = plugin.Plugin('foo_0', 'type_0')
    # Check
    if config_data_0.get_settings(plugin=plugin_0):
        assert False


# Generated at 2022-06-24 18:24:42.740094
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    config_data_0.update_setting(Setting("show_content_length", "on"))
    config_data_0.update_setting(Setting("request_timeout", "60"))
    config_data_0.update_setting(Setting("display_skipped_hosts", "on"))

    config_data_0.update_setting(Setting("gathering", "implicit"))
    config_data_0.update_setting(Setting("fact_caching", "memory"))
    config_data_0.update_setting(Setting("fact_caching_timeout", "86400"))
    config_data_0.update_setting(Setting("fact_caching", "jsonfile"))
    config_data_0.update_setting(Setting("fact_caching_connection", "/tmp/facts"))
    config

# Generated at 2022-06-24 18:24:45.277842
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    assert config_data_1.get_setting("data_ssss") == None


# Generated at 2022-06-24 18:24:49.965353
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    # Update as global setting
    config_data_0.update_setting(ConfigSetting(name='my_setting', value='my_value'))

    # Update as plugin setting
    plugin = Plugin(type='v2_playbook', name='my_playbook')
    config_data_0.update_setting(ConfigSetting(name='my_setting', value='my_value'), plugin=plugin)


# Generated at 2022-06-24 18:24:59.947395
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    # Test case 0
    # Test that a value is returned when asking an existing setting by name
    setting_0 = Setting(name='ansible_become_user')
    config_data_0.update_setting(setting_0)
    setting_result = config_data_0.get_setting(setting_0.name)
    assert setting_result == setting_0

    # Test case 1
    # Test that a value is returned when asking an existing setting by object
    setting_1 = Setting(name='ansible_become_user')
    config_data_0.update_setting(setting_1)
    setting_result = config_data_0.get_setting(setting_0)
    assert setting_result == setting_1

    # Test case 2
    # Test that a value is returned