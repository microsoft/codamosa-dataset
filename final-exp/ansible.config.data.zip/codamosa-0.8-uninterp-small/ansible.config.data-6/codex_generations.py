

# Generated at 2022-06-24 18:15:06.314728
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()

    setting_0 = Setting("foo", "bar", DATA_TYPE_STRING, "Description")
    config_data_0.update_setting(setting_0)
    setting_1 = config_data_0.get_setting("foo")
    assert setting_1 == setting_0


# Generated at 2022-06-24 18:15:11.285504
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_1 = ConfigData()
    settings_1 = config_data_1.get_settings()
    assert len(settings_1) == 0

    config_data_2 = ConfigData()
    settings_2 = config_data_2.get_settings()
    assert len(settings_2) == 0


# Generated at 2022-06-24 18:15:21.713618
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Get a setting by name
    config_data_1 = ConfigData()
    setting_0 = Setting('abc')
    config_data_1.update_setting(setting_0)
    assert config_data_1.get_setting('abc')
    # Get a setting by name and plugin
    config_data_2 = ConfigData()
    plugin_0 = Plugin('ab', 'cd')
    setting_1 = Setting('abc', plugin_0)
    config_data_2.update_setting(setting_1)
    assert config_data_2.get_setting('abc', plugin_0)
    # Get a setting by name and plugin, should return None
    setting_2 = Setting('abc')
    assert not config_data_2.get_setting('abc', setting_2)
    # Get a setting by name, should return None


# Generated at 2022-06-24 18:15:22.824409
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()


# Generated at 2022-06-24 18:15:24.845188
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert config_data_1.get_settings() == []


# Generated at 2022-06-24 18:15:27.517005
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    test_case_0()

if __name__ == "__main__":
    # These tests are not mandatory for the system to function properly but we include them for completeness
    test_ConfigData_get_settings()

# Generated at 2022-06-24 18:15:31.881671
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = SettingItem()
    config_data_0.update_setting(setting_0)


# Generated at 2022-06-24 18:15:34.896367
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    name_0 = 'name'
    plugin_0 = None
    assert not config_data_0.get_setting(name_0, plugin_0)


# Generated at 2022-06-24 18:15:36.472458
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

# Generated at 2022-06-24 18:15:41.441113
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_setting_0 = ConfigSetting(u'x', u'z')
    config_data_0.update_setting(config_setting_0, ConfigPlugin(u'y', u'z'))


# Generated at 2022-06-24 18:15:49.504857
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert isinstance(config_data_1.get_settings(None), list)


# Generated at 2022-06-24 18:15:55.751322
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    config_data._global_settings = {
        'foobar': [1, 2, 3],
    }

    config_data._plugins = {
        'foo': {
            'bar': {
                'foobar': [1, 2, 3],
            },
        },
    }

    assert config_data.get_settings() == [1, 2, 3]
    assert config_data.get_settings(FooPlugin('bar')) == [1, 2, 3]


# Generated at 2022-06-24 18:15:57.485923
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:16:04.095688
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """ Unit test for method update_setting of class ConfigData """

    config_data_1 = ConfigData()
    assert config_data_1.get_settings() == []
    assert config_data_1.get_setting(None) == None

    class Setting(object):

        def __init__(self, name):
            self.name = name

    setting_0 = Setting('test')
    config_data_1.update_setting(setting_0)
    assert config_data_1.get_settings() == [setting_0]
    assert config_data_1.get_setting('test') == setting_0

    class Plugin(object):

        def __init__(self, type, name):
            self.type = type
            self.name = name

    plugin_0 = Plugin('test_type', 'test_name')
   

# Generated at 2022-06-24 18:16:08.664284
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting("") == None
    assert config_data_0.get_setting("", None) == None
    assert config_data_0._global_settings == {}
    assert isinstance(config_data_0._global_settings, dict)


# Generated at 2022-06-24 18:16:10.314244
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:16:12.147495
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = config_data_0.get_setting('foo')

# Generated at 2022-06-24 18:16:14.564499
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    assert config_data_0 is not None, "Could not create ConfigData"


# Generated at 2022-06-24 18:16:17.081785
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    setting_0 = None
    config_data_0.update_setting(setting_0)

    return config_data_0

# Generated at 2022-06-24 18:16:19.301669
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert (config_data_0.get_setting("foo_bar") is None)



# Generated at 2022-06-24 18:16:31.967814
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = config_data_0.get_setting("/etc/ansible/ansible.cfg")
    setting_1 = config_data_0.get_setting("/etc/ansible/ansible.cfg")
    plugin_0 = Plugin("uri", "url")
    setting_2 = config_data_0.get_setting("/etc/ansible/ansible.cfg", plugin_0)


# Generated at 2022-06-24 18:16:33.583789
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:16:40.953948
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global config_data
    global setting_0
    global value_0
    global plugin_0
    global setting_1
    global value_1
    global plugin_1
    global setting_2
    global value_2
    global plugin_2
    global type_0

    # global config_data
    # global setting_0
    # global value_0
    # global plugin_0
    # global setting_1
    # global value_1
    # global plugin_1
    # global setting_2
    # global value_2
    # global plugin_2
    # global type_0
    #
    config_data = ConfigData()
    setting_0 = 'plugins'
    value_0 = 'yaml'
    plugin_0 = None
    setting_1 = 'timeout'
    value_1 = 12
    plugin

# Generated at 2022-06-24 18:16:44.095416
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin(None, '', '', '', '')
    assert config_data.get_settings(plugin) == []


# Generated at 2022-06-24 18:16:57.475334
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('name', 'value'))

    assert config_data_1.get_setting('name').name == 'name'
    assert config_data_1.get_setting('name').value.value == 'value'
    assert config_data_1.get_setting('name').plugin is None

    config_data_2 = ConfigData()
    config_data_2.update_setting(Setting('name1', 'value', Plugin('action', 'test'), 'source'))
    config_data_2.update_setting(Setting('name2', 'value', Plugin('action', 'test'), 'source'))

# Generated at 2022-06-24 18:17:00.543063
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting()


# Generated at 2022-06-24 18:17:02.845322
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting('data_0') is None


# Generated at 2022-06-24 18:17:05.686808
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('C', 'test', 'B')
    config_data_0.update_setting(setting_0)



# Generated at 2022-06-24 18:17:06.546011
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

# Generated at 2022-06-24 18:17:08.488146
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.get_settings()


# Generated at 2022-06-24 18:17:28.429395
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    from ansible import context
    from ansible.parsing.plugin_docs import read_docstring

    from ansible.plugins import AnsiblePlugin, connection_loader, module_loader
    from ansible.plugins.loader import find_plugin_files
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.display import Display

    from ansible_collections.ansible.community.plugins.module_utils import facts
    from ansible_collections.ansible.community.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.community.plugins.module_utils.urls import fetch_url

    import os


# Generated at 2022-06-24 18:17:35.406624
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_1 = Setting(name='ANSIBLE_HOST_KEY_CHECKING', value='False')
    config_data_1.update_setting(setting=setting_1)
    plugin_1 = Plugin(type='callback', name='minimal')
    setting_3 = Setting(name='VERBOSITY', value='1')
    config_data_1.update_setting(setting=setting_3, plugin=plugin_1)
    expected_output = {'ANSIBLE_HOST_KEY_CHECKING': setting_1}
    assert config_data_1._global_settings == expected_output
    assert config_data_1._plugins[plugin_1.type][plugin_1.name][setting_3.name] == setting_3
    


# Generated at 2022-06-24 18:17:42.060639
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    setting_1 = Setting(name='run_once', value='1')
    config_data_1.update_setting(setting_1)
    settings_1 = config_data_1.get_settings()
    assert len(settings_1) == 1
    assert settings_1[0] == setting_1


# Generated at 2022-06-24 18:17:43.116998
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    assert True


# Generated at 2022-06-24 18:17:44.178967
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    print(config_data_0.get_settings())

# Generated at 2022-06-24 18:17:46.474841
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()
    config_data_0.update_setting('a', 'b')
    config_data_0.get_settings()
    config_data_0.get_settings('a')
    config_data_0.get_settings('b')


# Generated at 2022-06-24 18:17:58.935011
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(None, 'root', 'http://localhost/api', 'https', None, None, None, 'admin', 'admin', None, None, None)
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_setting('http_port') == 80
    setting_0 = Setting(None, 'root', 'http://localhost/api', 'http', None, None, None, 'admin', 'admin', None, None, None)
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_setting('http_port') == 443

if __name__ == '__main__':
    test_case_0()
    test_ConfigData_update_setting()

# Generated at 2022-06-24 18:18:09.423573
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    config_data_0.update_setting(None)
    config_data_0.update_setting(None)
    config_data_0.update_setting(None)
    config_data_0.update_setting(None)

    # Update global setting
    setting_1 = Setting('setting_0', 'default_val')
    config_data_0.update_setting(setting_1)
    assert config_data_0.get_setting('setting_0') == setting_1

    # Update global setting to a different value
    setting_2 = Setting('setting_0', 'new_val')
    config_data_0.update_setting(setting_2)
    assert config_data_0.get_setting('setting_0') == setting_2

    # Attempt to update plugin setting without

# Generated at 2022-06-24 18:18:13.719809
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Create an object of ConfigData class
    config_data_1 = ConfigData()
    # Add a setting to global settings
    config_data_1.update_setting(Setting("ansible_managed", "This file is managed by Ansible", None))
    # Check the setting has been added to global settings
    assert config_data_1._global_settings["ansible_managed"] is not None


# Generated at 2022-06-24 18:18:21.573184
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()

    import ansible.plugins.loader as loader
    loader.load_plugins()

    for plugin_type in loader.all():
        for plugin in plugin_type.all():
            # Action plugins
            if plugin._load_name == 'async':
                assert plugin._load_name == 'async'
                assert plugin.name == 'async'
            # Connection plugins
            if plugin._load_name == 'ansible.netcommon.network_cli':
                assert plugin._load_name == 'ansible.netcommon.network_cli'
                assert plugin.name == 'network_cli'
                assert plugin.type == 'connection'
            # Shell plugins
            if plugin._load_name == 'pipelining':
                assert plugin._load_name == 'pipelining'

# Generated at 2022-06-24 18:18:34.666348
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Case 0:
    config_data_0 = ConfigData()
    setting_0 = ConfigData()
    plugin_0 = ConfigData()
    config_data_0.update_setting(setting_0, plugin_0)

if __name__ == '__main__':
    print('Running unit tests')
    print(test_case_0.__doc__)
    test_case_0()
    print(test_ConfigData_update_setting.__doc__)
    test_ConfigData_update_setting()

# Generated at 2022-06-24 18:18:37.025325
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    global_settings = config_data_0.get_settings()
    assert not global_settings


# Generated at 2022-06-24 18:18:39.018806
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("setting")
    assert config_data.get_setting("setting") == "setting"


# Generated at 2022-06-24 18:18:41.837757
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-24 18:18:49.750359
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting = Setting(name='action_plugins',value='/usr/share/ansible/plugins/action',scope='',plugin='',key='')
    config_data_0.update_setting(setting, plugin=None)
    setting = Setting(name='shell',value='/bin/bash',scope='',plugin='',key='')
    config_data_0.update_setting(setting, plugin=None)



# Generated at 2022-06-24 18:18:53.243943
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print('in test_ConfigData_update_setting')

    # Setup
    config_data_1 = ConfigData()

    # Exercise
    config_data_1.global_settings['fact_caching_timeout'] = 0

    # Verify
    assert config_data_1.global_settings['fact_caching_timeout'] == 0

# Generated at 2022-06-24 18:18:56.283279
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.plugins.loader import PluginLoader


# Generated at 2022-06-24 18:19:04.624291
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import ConfigSetting
    class ConfigPlugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    config_data.update_setting(ConfigSetting.ConfigSetting(name="foo", value=1, default=1))
    assert config_data._global_settings == {"foo": ConfigSetting.ConfigSetting(name="foo", value=1, default=1)}
    assert config_data._plugins == {}

    config_plugin = ConfigPlugin(type="inventory", name="foo_inventory")
    config_data.update_setting(ConfigSetting.ConfigSetting(name="bar", value=2, default=2), config_plugin)
    assert config_data._global

# Generated at 2022-06-24 18:19:10.036356
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None,
                                 plugin=None)

# Generated at 2022-06-24 18:19:11.350984
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:19:32.189078
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData();
    if (config_data_0.get_settings() != []):
        raise RuntimeError("Expected [], but got {}".format(config_data_0.get_settings()));


# Generated at 2022-06-24 18:19:45.610418
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    from ansiblelint.rules.OpeningQuoteInvertedRule import OpeningQuoteInvertedRule
    from ansiblelint.rules.TaskHasNameRule import TaskHasNameRule

    setting_0 = Setting('max-line-length', OpeningQuoteInvertedRule.id, 'no')
    setting_1 = Setting('max-line-length', TaskHasNameRule.id, 'yes')

    config_data.update_setting(setting_0)
    config_data.update_setting(setting_1)

    settings = config_data.get_settings()

    assert len(settings) == 2
    assert settings[0].name == 'max-line-length'
    assert settings[0].value == 'no'
    assert settings[0].plugin_name == OpeningQuoteInvertedRule.id

# Generated at 2022-06-24 18:19:52.901807
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()

    config_data_1.update_setting(Setting(name='one', value='1', origin='1', plugin=None))
    assert config_data_1.get_setting('one').value == '1'
    assert config_data_1.get_setting('one').origin == '1'

    config_data_2 = ConfigData()

    config_data_2.update_setting(Setting(name='one', value='1', origin='1', plugin=Plugin('one', 'one')))
    config_data_2.update_setting(Setting(name='two', value='2', origin='2', plugin=Plugin('one', 'one')))

# Generated at 2022-06-24 18:20:01.032231
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test variables
    config_data = ConfigData()
    setting_0 = AnsibleConfigSetting(name="foo", version="2.0", values={"values":["bar"]})
    plugin_0 = AnsiblePlugin(name="p_0", type="t_0")

    config_data.update_setting(setting_0, plugin_0)

    assert config_data._plugins["t_0"]["p_0"]["foo"].to_dict() == setting_0.to_dict()

if __name__ == '__main__':
    test_case_0()
    test_ConfigData_update_setting()

# Generated at 2022-06-24 18:20:04.586952
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_0 = Setting({'value': 'test content'}, 'test name', 'test default value')
    plugin_0 = Plugin('test type', 'test name')
    config_data_1.update_setting(setting_0, plugin_0)
    assert config_data_1._plugins['test type']['test name']['test name'].name == 'test name'


# Generated at 2022-06-24 18:20:15.382786
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    plugin_0 = PluginInfo('action', 'name_0')
    plugin_1 = PluginInfo('cache', 'name_1')
    setting_0 = Setting('name_0', 'new_value', 'default_value')
    setting_1 = Setting('name_1', 'new_value', 'default_value')
    setting_2 = Setting('name_2', 'new_value', 'default_value')
    # Test without setting plugin
    settings_0 = config_data_1.get_settings()
    settings_1 = config_data_1.get_settings(plugin_0)
    settings_2 = config_data_1.get_settings(plugin_1)
    settings_3 = settings_0

# Generated at 2022-06-24 18:20:17.312672
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()



# Generated at 2022-06-24 18:20:24.368987
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    from ansiblelint.rules import RuleMatch, AnsibleLintRule, match

    class ExampleRule(AnsibleLintRule):
        id = 'E0001'
        shortdesc = 'example rule'
        description = 'example rule'
        severity = 'LOW'
        tags = ['formatting']
        version_added = 'v1.0.0'

        def get_settings(self, run_context):
            return config_data.get_settings()

        def match(self, file, text):
            return match(self, file, text, run_context)

    rule = ExampleRule()
    file = ''
    text = ''
    run_context = None

    from ansiblelint.settings import RULE_LEVEL_CHOICES


# Generated at 2022-06-24 18:20:33.046940
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_1 = ConfigData()

    # Missing data
    current_plugin = None
    assert config_data_1.get_settings() == []
    current_plugin = PluginSpec('plugins', 'fake_plugin', 'python')
    assert config_data_1.get_settings(current_plugin) == []
    current_plugin = PluginSpec('cache', 'fake_plugin', 'python')
    assert config_data_1.get_settings(current_plugin) == []
    assert config_data_1.get_setting('setting_0') is None
    assert config_data_1.get_setting('setting_0', current_plugin) is None

    # Global settings
    setting_0 = SettingSpec('setting_0', 'string')
    setting_1 = SettingSpec('setting_1', 'integer')
    setting_2 = Setting

# Generated at 2022-06-24 18:20:41.603370
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Create a new config_data instance
    config_data = ConfigData()

    # Attempt to retrieve a non-existent setting
    setting = config_data.get_setting('test')
    assert setting is None

    # Make sure we can retrieve global settings
    global_setting = ConfigSetting('name', 'test')
    config_data.update_setting(global_setting)
    setting = config_data.get_setting('name')
    assert setting is not None
    assert setting.name == "name"

    # Make sure we can retrieve plugin settings
    plugin_setting = ConfigSetting('name', 'test')
    config_data.update_setting(plugin_setting, ConfigPlugin('type', 'name', 'path'))
    setting = config_data.get_setting('name', ConfigPlugin('type', 'name', 'path'))

# Generated at 2022-06-24 18:21:16.051683
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:21:18.984289
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    name_0 = 'foo'
    plugin_0 = None
    setting = config_data_0.get_setting(name_0, plugin_0)
    assert setting is None


# Generated at 2022-06-24 18:21:20.983827
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:21:23.128819
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting1 = config_data_1.update_setting("this is a setting")


# Generated at 2022-06-24 18:21:24.928706
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    print(config_data_0.get_settings())


# Generated at 2022-06-24 18:21:26.835108
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test for no setting
    test_get_setting()
    test_get_setting_0()



# Generated at 2022-06-24 18:21:38.585080
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Test 0: Test for get_setting with name as an invalid string syntax
    try:
        from ansiblelint.rules.UseCommandInsteadOfShellRule import UseCommandInsteadOfShellRule
        config_data.get_setting('invalid string syntax', UseCommandInsteadOfShellRule())
        assert(False)
    except TypeError:
        assert(True)

    # Test 1: Test for get_setting with plugin as an invalid value
    try:
        config_data.get_setting('UseCommandInsteadOfShell', 'invalid plugin')
        assert(False)
    except TypeError:
        assert(True)

    # Test 2: Test for get_setting with name as a valid string syntax
    #         and plugin as a valid value
    from ansiblelint.rules.UseCommandInsteadOfShellRule import Use

# Generated at 2022-06-24 18:21:50.783055
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting_0 = Setting('name', 'value0')
    setting_1 = Setting('name', 'value1')
    setting_2 = Setting('name', 'value2')
    plugin_0 = Plugin('type0', 'name0')
    plugin_1 = Plugin('type0', 'name1')
    plugin_2 = Plugin('type1', 'name2')
    config_data.update_setting(setting_0)
    config_data.update_setting(setting_1, plugin_0)
    config_data.update_setting(setting_2, plugin_1)
    expected = [setting_0]
    observed = config_data.get_settings()
    assert(expected == observed)
    expected = [setting_1]
    observed = config_data.get_settings(plugin_0)

# Generated at 2022-06-24 18:21:55.328164
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.module_utils.common._collections_compat import Mapping
    config_data_1 = ConfigData()
    assert_is_instance(config_data_1.get_settings(), list, 'The type of the return value of method ConfigData.get_settings is not a list.')
    assert_not_is_instance(config_data_1.get_settings(), Mapping, 'The type of the return value of method ConfigData.get_settings is not a subclass of Mapping.')


# Generated at 2022-06-24 18:21:56.985448
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    setting_1 = config_data_1.get_settings()

# Generated at 2022-06-24 18:23:29.291827
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_1.update_setting("test_name_0", "test_value_0", "test_path_0", "test_plugin_name_0", "test_plugin_type_0")
    if config_data_1.get_settings("test_plugin_name_0", "test_plugin_type_0")[0].name != "test_name_0":
        assert False
    if config_data_1.get_settings("test_plugin_name_0", "test_plugin_type_0")[0].value != "test_value_0":
        assert False
    if config_data_1.get_settings("test_plugin_name_0", "test_plugin_type_0")[0].path != "test_path_0":
        assert False


# Generated at 2022-06-24 18:23:35.548041
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    try:
        config_data_0.get_setting(name=None, plugin=None)
    except Exception as e:
        print(str(e))
        print("An exception occurred in method get_setting() of class ConfigData")


# Generated at 2022-06-24 18:23:39.948329
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    assert config_data_1.get_settings() == []
    setting_2 = ConfigData.Setting(name='vault_password_file', value='~/.vault_pass.txt')
    config_data_1.update_setting(setting_2)
    assert config_data_1.get_settings() == [ConfigData.Setting(name='vault_password_file', value='~/.vault_pass.txt')]


# Generated at 2022-06-24 18:23:45.208244
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting = Setting("setting")
    plugin = Plugin("plugin")
    setting.plugin = plugin
    config_data_0.update_setting(setting)
    settings = config_data_0.get_settings(plugin)
    assert(len(settings) == 1)


# Generated at 2022-06-24 18:23:51.046595
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin1 = Plugin("cli", "localhost")
    plugin2 = Plugin("persistent", "localhost")
    setting1 = Setting("cluster_size", "3", plugin1)
    setting2 = Setting("cluster_size", "5", plugin2)
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    assert config_data.get_setting(setting1.name, plugin1) == setting1


# Generated at 2022-06-24 18:23:53.300394
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:23:55.745398
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:24:04.915447
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting({'name': 'ansible.cfg', 'default': None, 'env': None, 'ini': 'ansible_config', 'vars': None, 'ini_details': None, 'config': None, 'section': 'defaults', 'key': None}, None)
    assert "ansible_config" == config_data_0._global_settings["ansible.cfg"]["ini"]


# Generated at 2022-06-24 18:24:08.580518
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting(name='foo', value=1, origin='me', priority=1, version=1))
    config_data_0.update_setting(Setting(name='foo', value=2, origin='you', priority=1, version=1))
    result = config_data_0.get_settings()
    assert len(result) == 1


# Generated at 2022-06-24 18:24:14.594623
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    # Create a Setting object
    setting_1 = Setting(name="test")
    # Update setting
    config_data_1.update_setting(setting_1)
    # Check setting
    assert config_data_1.get_setting("test") == setting_1