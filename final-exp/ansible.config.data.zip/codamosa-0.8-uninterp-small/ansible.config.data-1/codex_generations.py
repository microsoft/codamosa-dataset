

# Generated at 2022-06-24 18:15:09.255209
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting()
    setting_1 = Setting(name = 'foo')
    plugin_0 = Plugin(name = "ansible", type='action')
    config_data_0.update_setting(setting_0,plugin_0)
    config_data_0.update_setting(setting_1)
    setting_2 = config_data_0.get_setting("foo")
    assert setting_2.name == "foo"
    assert setting_0 == setting_2
    assert setting_1 == None


# Generated at 2022-06-24 18:15:12.275975
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = object()
    plugin = object()
    config_data.update_setting(setting, plugin)
    assert setting == [config_data.update_setting(setting, plugin) for _ in range(1)].pop()



# Generated at 2022-06-24 18:15:15.953835
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    #TODO: Need to create a setting object and pass it here
    #config_data_1.update_setting(setting)



# Generated at 2022-06-24 18:15:24.600975
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    # Test callback plugin "TestCallbackPlugin" settings
    setting_0_0 = Setting(name='setting_0_0', value='setting_value_0_0')
    config_data_0.update_setting(setting_0_0, plugin=Plugin(type='callback', name='TestCallbackPlugin'))
    setting_0_1 = Setting(name='setting_0_1', value='setting_value_0_1')
    config_data_0.update_setting(setting_0_1, plugin=Plugin(type='callback', name='TestCallbackPlugin'))
    setting_0_2 = Setting(name='setting_0_2', value='setting_value_0_2')

# Generated at 2022-06-24 18:15:25.481161
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    pass



# Generated at 2022-06-24 18:15:29.352216
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_setting = ConfigSetting('setting_name', 'value', 'description')
    plugin = Plugin('test_plugin', PluginType.SHELL, '/path/to/test_plugin')
    config_data.update_setting(config_setting)
    assert config_data.get_setting('setting_name') == config_setting
    config_data.update_setting(config_setting, plugin)
    assert config_data.get_setting('setting_name', plugin) == config_setting

# Generated at 2022-06-24 18:15:37.849750
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Load the plugin cache if needed.
    config_data_1 = ConfigData()

    # Update a setting.
    plugin_1 = '''
[foo:vars]
test_setting_1=a value
'''
    config_data_2 = ConfigData()
    config_data_2.update_setting(plugin_1)

    # Update a setting and check the result.
    plugin_2 = '''
[foo:vars]
test_setting_2=a value
'''
    config_data_3 = ConfigData()
    config_data_3.update_setting(plugin_2)


# Generated at 2022-06-24 18:15:40.465001
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.get_settings()


# Generated at 2022-06-24 18:15:45.635524
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()

    setting = Setting(name='foo', value='bar')
    config_data_0.update_setting(setting)
    assert config_data_0.get_setting('foo') == setting


# Generated at 2022-06-24 18:15:49.504466
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin = None
    assert config_data_0.get_settings(plugin) == []


# Generated at 2022-06-24 18:15:52.904751
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()



# Generated at 2022-06-24 18:15:59.508611
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Constructor test
    config_data_0 = ConfigData()
    # Verifying if attributes were instantiated correctly
    assert config_data_0._global_settings == {}
    assert config_data_0._plugins == {}
    # Calling method update_setting with wrong parameters
    try:
        config_data_0.update_setting('a')
    except Exception:
        assert True
    else:
        assert False
    # Calling method update_setting with correct parameters
    import plugins
    import models
    plugin = plugins.Plugin({'name': 'PluginA', 'type': 'TypeA', 'provider': 'package'})
    setting = models.Setting('setting', 'value', 'PluginA', 'TypeA')
    config_data_0.update_setting(setting, plugin)
    # Verifying new values for attributes
    assert config_

# Generated at 2022-06-24 18:16:01.449704
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:16:04.126720
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print('Testing ConfigData.update_setting()')
    config_data = ConfigData()
    setting = [None]
    plugin = [None]
    config_data.update_setting(setting[0], plugin[0])


# Generated at 2022-06-24 18:16:10.167855
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # test case 0
    config_data_0 = ConfigData()
    setting_data_0 = SettingData('CONFIG_FILE', default='/etc/ansible/ansible.cfg', option_type=ConfigOptionType.PATH)
    config_data_0.update_setting(setting_data_0)
    assert config_data_0.get_setting('CONFIG_FILE').option_type == ConfigOptionType.PATH



# Generated at 2022-06-24 18:16:13.077633
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    # Test without setting any plugin.
    plugin = None
    settings = config_data_1.get_settings(plugin)
    assert (settings == [])


# Generated at 2022-06-24 18:16:18.247040
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    assert config_data_0.get_setting('fact_caching_timeout') == None

    config_data_0.update_setting(Setting(name='fact_caching_timeout', value=600))
    assert config_data_0.get_setting('fact_caching_timeout') == Setting(name='fact_caching_timeout', value=600)


# Generated at 2022-06-24 18:16:20.477078
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings = config_data_0.get_settings()
    assert settings == []


# Generated at 2022-06-24 18:16:22.325404
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:16:28.288825
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting('is_logging_enabled', True))
    assert config_data_0.get_setting('is_logging_enabled') is not None


# Generated at 2022-06-24 18:16:31.206804
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    pass

# Generated at 2022-06-24 18:16:38.498307
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test with setting is None
    try:
        config_data_0 = ConfigData()
        config_data_0.update_setting(None)
        assert False
    except:
        assert True

    # Test with setting is not None and plugin is None
    try:
        config_data_0 = ConfigData()
        setting_0 = Setting('setting_0')
        config_data_0.update_setting(setting_0)
        assert config_data_0._global_settings.get('setting_0') == setting_0
    except:
        assert False

    # Test with setting is not None and plugin is not None

# Generated at 2022-06-24 18:16:48.812587
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    # setting should be none-type
    config_data_1.update_setting(None)

    # setting should be Setting type
    config_data_1.update_setting('test')

    # setting should have a name
    config_data_1.update_setting({})

    # setting should have a value
    config_data_1.update_setting(dict(name='test'))

    # setting should have a value
    config_data_1.update_setting(dict(name='test', value=""))

    # setting should have a value
    config_data_1.update_setting(dict(name='test', value="  "))

    # setting should have a value
    config_data_1.update_setting(dict(name='test', value="setting_value"))

    # setting

# Generated at 2022-06-24 18:17:00.011675
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()

    # Test global settings
    settings_0 = config_data_0.get_settings()
    assert len(settings_0) == 0

    from ansible.vars.hostvars import HostVars

    # Test global settings
    hostvars_0 = HostVars(host='localhost', host_vars={'ansible_user': 'root'})
    settings_1 = config_data_0.get_settings(hostvars_0)
    assert len(settings_1) == 0

    # Test default inventory plugin
    from ansible.plugins.loader import inventory_loader

    plugin_0 = inventory_loader.get_plugin()
    settings_2 = config_data_0.get_settings(plugin_0)
    assert len(settings_2) == 0

    # Test default

# Generated at 2022-06-24 18:17:03.412257
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting({})


# Generated at 2022-06-24 18:17:05.548056
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    result = config_data_0.update_setting(setting=None)


# Generated at 2022-06-24 18:17:07.728300
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    class_reflection_0 = object
    assert config_data_0.get_setting == class_reflection_0.get_setting

# Generated at 2022-06-24 18:17:10.902844
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting("setting", None)
    assert config_data_1._global_settings["setting"] == "setting"


# Generated at 2022-06-24 18:17:12.735041
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    assert None == ConfigData().get_setting("TestSetting")


# Generated at 2022-06-24 18:17:16.970182
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'true'))
    assert config_data.get_setting('foo') != None
    assert config_data.get_setting('foo').name == 'foo'
    assert config_data.get_setting('foo').value == 'true'


# Generated at 2022-06-24 18:17:23.551328
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    global config_data_0
    if config_data_0 is None:
        config_data_0 = ConfigData()
    result = config_data_0.get_settings()
    assert isinstance(result, list) == True


# Generated at 2022-06-24 18:17:25.540538
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting = config_data_0.get_setting('text')
    assert setting is None



# Generated at 2022-06-24 18:17:26.656598
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()

# Generated at 2022-06-24 18:17:27.891151
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:17:33.559897
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Case 0:
    # Create an instance of ConfigData and call get_settings()
    test_case_0()

    # Case 1:
    # Create an instance of ConfigData, add some settings and then call get_settings()
    config_data_1 = ConfigData()
    config_data_1.update_setting(setting='setting 0')
    config_data_1.update_setting(setting='setting 1')
    config_data_1.update_setting(setting='setting 2')
    config_data_1.get_settings()

# Generated at 2022-06-24 18:17:35.400244
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()



# Generated at 2022-06-24 18:17:42.987006
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Create a new config data
    config_data = ConfigData()

    # Create a new setting
    setting = None

    # Verify the method returns the expected result

    # Create a new setting
    setting = Setting(None, 'option1', 'value1')

    # Update setting
    config_data.update_setting(setting)

    # Verify the method returns the expected result
    config_data.get_setting('option1') == setting


# Generated at 2022-06-24 18:17:45.618226
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data._global_settings = {'g': 'g'}
    config_data._plugins = {'T': {'N': {'n': 'n'}}}
    config_data.get_setting('g')
    config_data.get_setting('n', 'T', 'N')


# Generated at 2022-06-24 18:17:55.238132
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('foo', value='42'))
    config_data_1.update_setting(Setting('bar', value='false'))
    config_data_1.update_setting(Setting('baz', value='blue', plugin=Plugin('color', 'primary')))
    config_data_1.update_setting(Setting('baz', value='red', plugin=Plugin('color', 'secondary')))


# Generated at 2022-06-24 18:17:57.336318
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = Plugin(type='', name='')
    assert config_data_0.get_settings(plugin=plugin_0) == []


# Generated at 2022-06-24 18:18:06.849407
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    import ansible.plugins.configuration_loader
    config_data.update_setting(ansible.plugins.configuration_loader.Setting("verbose", "VERBOSE", "string"))
    # TODO: assert something here ...
    return True


# Generated at 2022-06-24 18:18:08.654915
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    pass


# Generated at 2022-06-24 18:18:11.329043
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugins_0 = []
    settings_0 = config_data_0.get_settings(plugins_0)
    assert settings_0 == []


# Generated at 2022-06-24 18:18:14.248257
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    try:
        config_data = ConfigData()
        config_data.get_settings()
    except Exception as e:
        print('Exception raised:')
        print(str(e))
        raise
    else:
        print('No exception raised.')
        assert True


# Generated at 2022-06-24 18:18:22.068430
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    plugin_0 = Plugin(type='test', name='test')
    setting_0 = Setting('test', 'test', 0)
    plugin_0.add_setting(setting_0)
    config_data_1.update_setting(setting_0, plugin_0)
    assert config_data_1.get_settings(plugin_0)[0] == setting_0
    assert config_data_1.get_settings(plugin_0)[0].name == 'test'
    setting_1 = Setting('test2', 'test2', 1)
    config_data_1.update_setting(setting_1)
    assert config_data_1.get_settings()[0] == setting_1
    assert config_data_1.get_settings()[0].name == 'test2'



# Generated at 2022-06-24 18:18:33.063697
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    plugin_0 = Plugin('plugin_a')
    setting_0 = Setting('setting_a', 'STRING', 'GLOBAL', 'a', 'description', plugin_0)

    config_data_0.update_setting(setting_0, plugin=plugin_0)
    assert config_data_0._global_settings == {}
    assert config_data_0._plugins == {'plugin_a': {'plugin_a': {'setting_a': setting_0}}}

    setting_1 = Setting('setting_b', 'STRING', 'user', 'b', 'description')
    setting_1.plugin = plugin_0
    config_data_0.update_setting(setting_1)
    assert config_data_0._global_settings == {'setting_b': setting_1}
   

# Generated at 2022-06-24 18:18:38.595683
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0a = ConfigData()
    setting_0a = Setting('', 'global', 'global', 'option', 'type')
    setting_0a.path = 'path_data_0'
    setting_0a.version = 'version_0'
    config_data_0a.update_setting(setting_0a)
    assert config_data_0a._global_settings['setting_0a'] == setting_0a


# Generated at 2022-06-24 18:18:41.714391
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings = config_data_0.get_settings()
    assert len(settings) == 0


# Generated at 2022-06-24 18:18:52.094263
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = PluginInfo()
    plugin_0.name = 'global'
    plugin_0.type = 'module'
    plugin_0.path = '/home/admin/.ansible/plugins/modules'
    plugin_0.module_name = 'string_utils'
    setting_0 = Setting()
    setting_0.name = 'FORCE_COLOR'
    setting_0.value = 'True'
    setting_0.section = ''
    setting_0.key = ''
    setting_0.plugin = plugin_0
    config_data_0.update_setting(setting_0, plugin_0)
    setting_0 = Setting()
    setting_0.name = 'ANSIBLE_CONFIG'
    setting_0.value = '/home/admin/ansible.cfg'

# Generated at 2022-06-24 18:18:54.324673
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(name=None) is None


# Generated at 2022-06-24 18:19:05.758766
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings(None) == []


# Generated at 2022-06-24 18:19:11.294739
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cfg_data = ConfigData()
    test_setting1 = Setting('setting1', 'setting1desc')
    cfg_data.update_setting(test_setting1)
    assert cfg_data.get_setting('setting1') == test_setting1

#Unit test for method get_setting of class ConfigData

# Generated at 2022-06-24 18:19:13.862850
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()

    assert config_data_1.get_setting('auto_resume', plugin=None) is None


# Generated at 2022-06-24 18:19:24.154092
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='SETTING_0', value='value_0')
    config_data_0.update_setting(setting=setting_0)
    setting_1 = Setting(name='SETTING_1', value='value_1')
    config_data_0.update_setting(setting=setting_1)
    setting_2 = Setting(name='SETTING_2', value='value_2')
    config_data_0.update_setting(setting=setting_2)
    setting_3 = Setting(name='SETTING_3', value='value_3')
    config_data_0.update_setting(setting=setting_3)



# Generated at 2022-06-24 18:19:30.477466
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.action import ActionModule
    action_loader = PluginLoader(class_name="ActionModule",
                                 package="ansible.plugins.action",
                                 config=config_data)
    action_plugin = next(a for a in action_loader.all())
    config_data.update_setting(setting=action_plugin.get_setting("ANSIBLE_ACTION_WARNINGS"))
    config_data.update_setting(setting=action_plugin.get_setting("ANSIBLE_ACTION_WARNINGS"))
    setting_0 = config_data.get_setting(name="ANSIBLE_ACTION_WARNINGS")
    assert setting_0.name == "ANSIBLE_ACTION_WARNINGS"


# Generated at 2022-06-24 18:19:37.067682
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_1 = ConfigData()
    settings_0 = config_data_1.get_setting('total_seconds')
    settings_1 = config_data_1.get_setting('automation_enabled')
    settings_2 = config_data_1.get_setting('automation_engine')
    settings_3 = config_data_1.get_setting('automation_enabled')
    settings_4 = config_data_1.get_setting('automation_enabled', 'cloud', 'gcp')
    settings_5 = config_data_1.get_setting('automation_enabled', 'cloud', 'gcp')
    settings_6 = config_data_1.get_setting('automation_enabled', 'cloud', 'aws')

# Generated at 2022-06-24 18:19:40.603898
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting = 'foo'
    assert isinstance(config_data_0.update_setting(setting), ConfigData) is True


# Generated at 2022-06-24 18:19:43.189205
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    print(config_data_0.update_setting())


# Generated at 2022-06-24 18:19:50.951309
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = config_data_0.get_setting("", plugin=None)
    assert setting_0 is None

    config_data_1 = ConfigData()
    setting_1 = config_data_1.get_setting("", plugin=None)
    assert setting_1 is None

    config_data_2 = ConfigData()
    setting_2 = config_data_2.get_setting("", plugin=None)
    assert setting_2 is None

    config_data_3 = ConfigData()
    setting_3 = config_data_3.get_setting("", plugin=None)
    assert setting_3 is None



# Generated at 2022-06-24 18:19:55.541501
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()

    # Run the get_settings method of config_data_1
    result = config_data_1.get_settings()

    # Verify the result
    assert(result == [])


# Generated at 2022-06-24 18:20:15.358702
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()



# Generated at 2022-06-24 18:20:19.045547
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    c = ConfigData()
    s = c.get_setting("test_setting_0")
    s = c.get_setting("test_setting_1", "test_plugin_0")


# Generated at 2022-06-24 18:20:27.669705
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin_0 = Plugin('type_1', 'name_0')
    setting_0 = Setting('name_0', 'value_0')
    setting_1 = Setting('name_1', 'value_1')

    assert config_data.get_setting('name_0') is None
    assert config_data.get_setting('name_1') is None
    assert config_data.get_setting('name_0', plugin_0) is None
    assert config_data.get_setting('name_1', plugin_0) is None

    config_data.update_setting(setting_0, plugin_0)
    config_data.update_setting(setting_1, plugin_0)

    assert config_data.get_setting('name_0') is None

# Generated at 2022-06-24 18:20:29.104781
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()


# Generated at 2022-06-24 18:20:34.245663
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = SettingData('test_0', value='test_0')
    config_data_0.update_setting(setting_0)
    assert setting_0 in config_data_0.get_settings()


# Generated at 2022-06-24 18:20:37.380295
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = config_data_0.get_setting('name', plugin=None)


# Generated at 2022-06-24 18:20:40.596149
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    assert(config_data_0.get_settings() == [])
    assert(config_data_0.get_settings(None) == [])

    config_data_0 = ConfigData()

# Generated at 2022-06-24 18:20:43.101987
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    settings = config.get_settings()
    assert len(settings) == 0

test_ConfigData_get_settings()


# Generated at 2022-06-24 18:20:44.920864
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting('wbn-c')


# Generated at 2022-06-24 18:20:55.540919
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    print("Testing method ConfigData.get_setings...")

    config_data_0 = ConfigData()

    plugin_0 = Plugin('shell', 'sh')
    plugin_0.update_setting('SHELL', 'sh')
    plugin_0.update_setting('ENV', '/etc/profile')
    config_data_0.update_setting(plugin_0.get_setting('SHELL'))
    config_data_0.update_setting(plugin_0.get_setting('ENV'), plugin_0)
    assert config_data_0.get_settings() == [{'option': 'sh', 'name': 'SHELL'}]

# Generated at 2022-06-24 18:21:16.031498
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(name='test_setting', value='test_value', plugin=None)

# Generated at 2022-06-24 18:21:17.865654
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test case 0
    config_data_0 = ConfigData()
    config_data_0.update_setting()


# Generated at 2022-06-24 18:21:20.159472
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test case 0: verify that get_setting returns None given an empty ConfigData object
    test_case_0()



# Generated at 2022-06-24 18:21:22.284361
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(config_data_0.update_setting)


# Generated at 2022-06-24 18:21:32.181352
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    setting_1 = Setting('name_1')
    setting_2 = Setting('name_2')
    plugin_2 = Plugin(None, None, 'type_2', 'name_2')
    config_data_1.update_setting(setting_1)
    config_data_1.update_setting(setting_2, plugin_2)

    result_1 = config_data_1.get_settings()
    expected_1 = [setting_1]
    assert result_1 == expected_1

    result_2 = config_data_1.get_settings(plugin_2)
    expected_2 = [setting_2]
    assert result_2 == expected_2



# Generated at 2022-06-24 18:21:34.583823
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    test_case_0()


# Generated at 2022-06-24 18:21:43.838526
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()

    class plugin_setting_1(object):
        name = 'plugin_setting_1'
        value = 'plugin_setting_1_value'

    class plugin_setting_2(object):
        name = 'plugin_setting_2'
        value = 'plugin_setting_2_value'

    class plugin_setting_3(object):
        name = 'plugin_setting_3'
        value = 'plugin_setting_3_value'
    class plugin_1(object):
        type = 'plugin_type_1'
        name = 'plugin_name_1'
        setting = plugin_setting_1()

    class plugin_2(object):
        type = 'plugin_type_2'
        name = 'plugin_name_2'


# Generated at 2022-06-24 18:21:47.477694
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Instantiation of object
    config_data_1 = ConfigData()
    # Call of method get_setting
    config_data_1.get_setting(setting, plugin=None)


# Generated at 2022-06-24 18:21:49.479011
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()
    settings = config_data_0.get_settings()

    assert len(settings) == 0


# Generated at 2022-06-24 18:22:00.994804
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Create fake settings
    class FakeGlobalSetting(object):
        # Fake setting
        pass

    class FakePluginSetting(object):
        # Fake setting
        pass

    # Create fake plugins
    class FakePlugin(object):
        # Fake plugin
        pass

    plugin_type = 'type_0'
    plugin_name = 'name_0'
    setting_name = 'setting_name_0'

    config_data = ConfigData()

    # Test case where setting does not exist
    settings = config_data.get_settings()
    assert len(settings) == 0

    # Test case where only global setting exists
    global_setting = FakeGlobalSetting()
    global_setting.name = setting_name
    config_data.update_setting(global_setting)
    settings = config_data.get_settings()

# Generated at 2022-06-24 18:22:53.773145
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='action_delete_line_regexp', type='action', value='DeleteHost')
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_setting('action_delete_line_regexp').name == 'action_delete_line_regexp'
    assert config_data_0.get_setting('action_delete_line_regexp').value == 'DeleteHost'
    assert config_data_0.get_setting('action_delete_line_regexp').type == 'action'


# Generated at 2022-06-24 18:22:57.105855
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    setting = { 'name': 'test' }
    config_data.update_setting(setting)

    assert setting == config_data.get_setting('test')


# Generated at 2022-06-24 18:23:01.580278
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = ConfigSetting('timeout', '1', 'global')
    setting_0.value = '1'
    assert config_data_0.get_setting(setting_0) is None
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_setting(setting_0).value == '1'


# Generated at 2022-06-24 18:23:10.904464
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_1 = Setting(name='setting_1', value='value_1')
    plugin_1 = Plugin(type='type_1', name='name_1')
    plugin_2 = Plugin(type='type_2', name='name_2')
    plugin_3 = Plugin(type='type_3', name='name_3')
    plugin_4 = Plugin(type='type_4', name='name_4')
    plugin_5 = Plugin(type='type_5', name='name_5')
    config_data_1.update_setting(setting_1, plugin=None)
    config_data_1.update_setting(setting_1, plugin=plugin_1)
    config_data_1.update_setting(setting_1, plugin=plugin_2)
    config_data

# Generated at 2022-06-24 18:23:13.922635
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    settings = config_data_0.get_settings()
    assert settings == []
    settings = config_data_0.get_settings(plugin=None)
    assert settings == []


# Generated at 2022-06-24 18:23:15.569491
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('Setting Name', 'Setting value')
    config_data_0.update_setting(setting_0)


# Generated at 2022-06-24 18:23:19.660101
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None)
    config_data_0.update_setting(setting=None, plugin=None)


# Generated at 2022-06-24 18:23:24.622119
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    int_0 = config_data_0.update_setting(setting)
    assert int_0 is None
    int_0 = config_data_0.update_setting(setting)
    assert int_0 is None


# Generated at 2022-06-24 18:23:26.056087
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting()


# Generated at 2022-06-24 18:23:37.252618
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    # with plugin
    setting_1 = Setting("a.b.c.d:e:f:g:h", "value1", "int", "", "", "", "")
    plugin_1 = Plugin("lookup", "lookup_plugin")
    config_data_1.update_setting(setting_1, plugin_1)
    settings = config_data_1.get_settings(plugin_1)
    assert(len(settings) == 1)
    # without plugin
    settings = config_data_1.get_settings()
    assert(len(settings) == 0)


# Generated at 2022-06-24 18:24:26.774174
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='verbose', plugin=ActionModule('action', 'copy'), value='False', origin='ansible.cfg',
                        section='defaults', version_added=2)
    config_data_0.update_setting(setting_0, plugin=ActionModule('action', 'copy'))

    assert config_data_0.get_setting(name='verbose', plugin=ActionModule('action', 'copy')).value == 'False'
    assert config_data_0.get_setting(name='verbose').value == 'False'


# Generated at 2022-06-24 18:24:32.403280
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = [Setting(name='test_setting_name', value=['test_setting_value'])]
    plugin = Plugin('plugin_name', 'plugin_type')
    config_data.update_setting(setting, plugin)
    assert setting in config_data.get_settings(plugin)


# Generated at 2022-06-24 18:24:39.305325
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data is not None
    from .config_setting import ConfigSetting
    from .config_plugin import ConfigPlugin
    plugin = ConfigPlugin(name='Shell', type='connection')
    setting = ConfigSetting(name='forks', value=42, plugin=plugin, path=None)
    config_data.update_setting(setting, plugin)
    result = config_data.get_setting('forks', plugin)
    assert result.value == 42


# Generated at 2022-06-24 18:24:41.469422
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting()


# Generated at 2022-06-24 18:24:49.755881
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting(name="name_1", value="value_1", origin="origin_1", plugin=None, plugin_class=None))
    assert config_data_1.get_setting("name_1").value == "value_1"
    assert config_data_1.get_setting("name_1").name == "name_1"
    assert config_data_1.get_setting("name_1").plugin_class == None
    assert config_data_1.get_setting("name_1").plugin == None
    assert config_data_1.get_setting("name_1").origin == "origin_1"
    assert config_data_1.get_settings().pop().value == "value_1"
  

# Generated at 2022-06-24 18:24:52.189772
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Declare and initialize the object
    config_data_0 = ConfigData()

    # Call the method
    output = config_data_0.get_settings()



# Generated at 2022-06-24 18:24:53.563587
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:24:55.658501
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()

    config_data_0.update_setting(None)

    assert config_data_0.get_setting("name") == None
