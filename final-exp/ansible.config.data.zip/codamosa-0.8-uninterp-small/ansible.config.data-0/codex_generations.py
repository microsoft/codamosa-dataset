

# Generated at 2022-06-24 18:15:00.075221
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test_case_0()


# Generated at 2022-06-24 18:15:05.116787
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = create_ConfigData_instance_1()
    config_data_1.update_setting(SettingData('foo', 'bar', None), PluginData('cache', 'memory'))
    assert config_data_1.get_setting('foo') == None


# Generated at 2022-06-24 18:15:08.122813
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert config_data_1._global_settings == {}
    assert config_data_1._plugins == {}

# Generated at 2022-06-24 18:15:16.774105
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    assert config_data_1.get_setting('DEPRECATION_WARNINGS') == None
    assert config_data_1.get_setting('DEFAULT_CALLABLE_WHITELIST') == None
    config_data_2 = ConfigData()
    assert config_data_2.get_setting('DEPRECATION_WARNINGS') == None
    assert config_data_2.get_setting('DEFAULT_CALLABLE_WHITELIST') == None
    config_data_3 = ConfigData()
    assert config_data_3.get_setting('DEPRECATION_WARNINGS') == None
    assert config_data_3.get_setting('DEFAULT_CALLABLE_WHITELIST') == None
    config_data_4 = ConfigData()

# Generated at 2022-06-24 18:15:19.739633
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Init test data
    config_data_0 = ConfigData()

    # Call get_setting on config_data_0
    result = config_data_0.get_setting('name', plugin='plugin_0')
    assert result == None


# Generated at 2022-06-24 18:15:22.785920
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    try:
        config_data_0.get_settings(None)
    except AttributeError as e:
        assert 0, "Must raise attribute error: " + str(e)


# Generated at 2022-06-24 18:15:25.137783
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    print("config_data_0.get_setting(): ", config_data_0.get_setting())

# Generated at 2022-06-24 18:15:27.001137
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

# Generated at 2022-06-24 18:15:38.803083
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()
    config_data_3 = ConfigData()
    config_data_4 = ConfigData()
    config_data_5 = ConfigData()
    setting_1 = Setting('ansible_port', u'ansible', u'config file', u'22', u'22', u'', u'', u'', u'', u'string', u'integer', u'ansible_port', u'', u'', True, False, False, False, False, False, u'', u'', u'', u'', None, None, True, None, None, None, False, False, False, False, None, None, u'', u'')
    Setting.update(config_data_1, setting_1)

# Generated at 2022-06-24 18:15:48.995147
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    from ansible_galaxy.models import Setting, PluginSpec
    setting_0 = Setting(name='foo', value=10)
    setting_1 = Setting(name='bar', value=True)
    setting_2 = Setting(name='foobar', value='hello world')
    config_data.update_setting(setting_0)
    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2)
    assert config_data.get_setting(setting_0.name) == setting_0
    assert config_data.get_setting(setting_1.name) == setting_1
    assert config_data.get_setting(setting_2.name) == setting_2
    assert config_data.get_setting('foo') == setting_0
    assert config

# Generated at 2022-06-24 18:15:56.251978
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    setting_0 = Setting('display_skipped_hosts', 'boolean', 'on')
    config_data_0.update_setting(setting_0)

    setting_1 = config_data_0.get_setting('display_skipped_hosts')
    assert(setting_0.name == setting_1.name and
           setting_0.value == setting_1.value and
           setting_0.value_type == setting_1.value_type)



# Generated at 2022-06-24 18:16:01.075787
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_settings_0 = ConfigData()
    config_data_settings_0.data = {
      'type': 'ansible.module_utils.basic.ConfigData',
      'settings': {
        'foo': {
          'name': 'foo',
          'value': 'bar',
          'scope': ['playbook', 'task'],
          'origin': 'task',
          'plugin_type': '',
          'plugin_name': '',
          'default': False
        }
      }
    }
    config_data_settings_0.get_settings()

# Generated at 2022-06-24 18:16:09.373597
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    test_setting_0 = Setting()
    test_setting_0.name = 'test_setting_0'
    test_setting_0.type = 'str'
    test_setting_0.default = 'some string'
    test_setting_0.help = 'a test setting'
    test_setting_0.choices = ['test']
    test_setting_0.scope = ['playbook', 'connection']
    test_setting_0.section = 'test'

    config_data_1.update_setting(test_setting_0)
    assert test_setting_0.name in config_data_1._global_settings

    test_setting_1 = Setting()
    test_setting_1.name = 'test_setting_1'

# Generated at 2022-06-24 18:16:12.650746
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    name = ''
    plugin = ''
    assert (config_data_0.get_setting(name, plugin) == None)


# Generated at 2022-06-24 18:16:21.098391
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()

    setting_0 = Setting('test', 'test value')
    setting_1 = Setting('test_1', 'test value 1')

    plugin_0 = Plugin('test', 'test', [setting_0, setting_1])

    config_data_0.update_setting(setting_0)
    config_data_0.update_setting(setting_1, plugin_0)

    settings = config_data_0.get_settings(plugin_0)

    assert len(settings) == 2

    settings = config_data_0.get_settings()

    assert len(settings) == 1



# Generated at 2022-06-24 18:16:27.141718
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # create object of the class to be tested
    config_data_0 = ConfigData()
    # set values of instance attributes
    config_data_0._global_settings = {'null_option': None, 'string_option': 'default', 'int_option': 5}
    config_data_0._plugins = {}
    # create test input variables
    name = 'null_option'
    plugin = None
    # perform the test
    result = config_data_0.get_setting(name, plugin)
    # check for expected results
    assert result is None


# Generated at 2022-06-24 18:16:35.940890
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting_0 = Setting('setting_0')
    config_data.update_setting(setting_0)
    setting_1 = Setting('setting_1')
    plugin_0 = Plugin('plugin_0', 'type_0')
    config_data.update_setting(setting_1, plugin_0)
    setting_2 = Setting('setting_2')
    plugin_1 = Plugin('plugin_1', 'type_1')
    config_data.update_setting(setting_2, plugin_1)
    print(config_data.get_setting('setting_1', plugin_0))

test_ConfigData_get_setting()


# Generated at 2022-06-24 18:16:42.657911
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Global setting
    global_setting_0 = Setting(name='chunk_size')
    global_setting_0.set_value(1024)
    global_setting_0.set_type('int')
    ConfigData.update_setting(global_setting_0)

    assert ConfigData.get_setting('chunk_size').name == 'chunk_size'
    assert ConfigData.get_setting('chunk_size').value == 1024
    assert ConfigData.get_setting('chunk_size').type == 'int'

    # Plugin setting
    plugin_setting_0 = Setting(name='chunk_size')
    plugin_setting_0.set_value(1024)
    plugin_setting_0.set_type('int')
    plugin_0 = Plugin('Network', 'test_plugin')

# Generated at 2022-06-24 18:16:50.408402
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = ConfigSetting(name="foo", value="bar", plugin=None)
    config_data_0.update_setting(setting_0)
    setting_1 = ConfigSetting(name="baz", value="qux", plugin=None)
    config_data_0.update_setting(setting_1)
    setting_2 = ConfigSetting(name="fribb", value="ble", plugin=ConfigPlugin(name="core", type="action"))
    config_data_0.update_setting(setting_2)
    setting_3 = ConfigSetting(name="frob", value="baz", plugin=ConfigPlugin(name="core", type="action"))
    config_data_0.update_setting(setting_3)
    found_setting_0 = config_data_0.get_setting

# Generated at 2022-06-24 18:17:00.614787
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting(name="terminal.ansicolors"))

    assert config_data_1.get_setting(plugin=None) is not None
    assert len(config_data_1.get_settings()) == 1

    config_data_2 = ConfigData()
    config_data_2.update_setting(Setting(name="editor.tabSize", plugin=Plugin(name="javascript", type="language")))

    assert config_data_2.get_setting(plugin=Plugin(name="javascript", type="language")) is not None
    assert config_data_2.get_setting(name="editor.tabSize") is None
    assert config_data_2.get_settings(plugin=Plugin(name="javascript", type="language")) is not None

# Generated at 2022-06-24 18:17:07.681333
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_setting_1 = ConfigSetting('setting_1', 'mysetting', 'myvalue')
    config_data_1.update_setting(config_setting_1)
    result = config_data_1.get_setting('setting_1')
    assert result.name == 'setting_1'


# Generated at 2022-06-24 18:17:10.445333
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    assert config_data_0.update_setting('/etc/ansible/ansible.cfg') == None


# Generated at 2022-06-24 18:17:13.128975
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert callable(config_data_0.get_setting)


# Generated at 2022-06-24 18:17:15.585378
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting = 'foo'
    plugin = None
    assert config_data_1.get_setting(setting, plugin) == None


# Generated at 2022-06-24 18:17:17.171507
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting()


# Generated at 2022-06-24 18:17:20.576134
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_0 = Setting()
    config_data_1.update_setting(setting_0)

# Generated at 2022-06-24 18:17:26.132509
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    # Test case for method get_settings of class ConfigData
    # Called with valid parameter
    # Expected result: Success
    try:
        config_data_0.get_settings()
    except Exception as e:
        print("Exception occured: ", e)
        assert False


# Generated at 2022-06-24 18:17:34.313789
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting()
    config_data.update_setting(description='This setting controls...')
    config_data.update_setting('my_plugin')
    config_data.update_setting(None, plugin='my_plugin')
    config_data.update_setting('my_plugin.yaml')
    config_data.update_setting('my_plugin.yaml', name='setting_a')
    config_data.update_setting('my_plugin.yaml', name='setting_a', default='/usr/share/ansible/plugins')
    config_data.update_setting('my_plugin.yaml', name='setting_a', default='/usr/share/ansible/plugins', env_var='ANSIBLE_MY_PLUGIN_SETTING_A')
    config_

# Generated at 2022-06-24 18:17:35.171118
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test_case_0()


# Generated at 2022-06-24 18:17:36.511535
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-24 18:17:46.071005
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
# Test for param: setting
# Update a global setting
    from ansible.config.setting import Setting
    setting_0 = Setting()
    setting_0.name = 'ANSIBLE_CALLBACK_WHITELIST'
    setting_0.value = 'profile_tasks'
    config_data_0.update_setting(setting_0)

# Update a plugin setting
    setting_1 = Setting()
    setting_1.name = 'stdout'
    setting_1.value = 'true'
    from ansible.plugins.loader import PluginLoader
    plugin_loader_0 = PluginLoader('callback', 'stdout')
    config_data_0.update_setting(setting_1, plugin_loader_0)


# Generated at 2022-06-24 18:17:49.392533
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting('setting', None)


# Generated at 2022-06-24 18:17:51.219336
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:17:57.885894
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print('TEST #1: update_setting(setting, None)')
    config_data_1 = ConfigData()
    setting = Setting()
    setting.name = 'test_setting'
    config_data_1.update_setting(setting, None)
    assert config_data_1._global_settings[setting.name].name == setting.name
    print('Result: PASS')


# Generated at 2022-06-24 18:18:08.314850
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    foobar_0 = ConfigSetting()
    foobar_1 = ConfigSetting()
    foobar_2 = ConfigSetting()
    foobar_3 = ConfigSetting()
    foobar_4 = ConfigSetting()
    config_data_0.update_setting(foobar_0)
    config_data_0.update_setting(foobar_1)
    config_data_0.update_setting(foobar_2)
    config_data_0.update_setting(foobar_3)
    config_data_0.update_setting(foobar_4)
    foobar_5 = config_data_0.get_settings()
    foobar_1.value = foobar_5[1].value
    print(foobar_5)


# Generated at 2022-06-24 18:18:17.282558
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting(name='roles_path', value='/foo'))
    config_data_0.update_setting(Setting(name='library', value='/bar', plugin=Plugin(type='module_utils', name='lib1')))
    config_data_0.update_setting(Setting(name='filter', value='/baz', plugin=Plugin(type='filters', name='filter1')))

    print(sorted([s.value for s in config_data_0.get_settings()]))
    assert sorted(['/foo']) == sorted([s.value for s in config_data_0.get_settings()])
    assert ['roles_path'] == [s.name for s in config_data_0.get_settings()]



# Generated at 2022-06-24 18:18:27.969505
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Test case 0
    test_case_0()

    # Test case 1
    config_data_1 = ConfigData()

    assert config_data_1.get_setting("ansible_host") == None

    # Test case 2
    config_data_2 = ConfigData()
    config_data_2.update_setting(Setting("ansible_host", "localhost", "localhost", "inventory_hostname", "string", "localhost"))

    assert config_data_2.get_setting("ansible_host").name == "ansible_host"

    # Test case 3
    config_data_3 = ConfigData()
    config_data_3.update_setting(Setting("ansible_host", "localhost", "localhost", "inventory_hostname", "string", "localhost"))


# Generated at 2022-06-24 18:18:30.149549
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting('any') == None


# Generated at 2022-06-24 18:18:31.840356
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert  config_data.get_setting('test') == None


# Generated at 2022-06-24 18:18:39.328373
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    plugin_0 = Plugin(None, None, None)
    setting_0 = Setting(None, None, '0', None, None)
    config_data_0.update_setting(setting_0, plugin=plugin_0)
    check_0 = config_data_0._plugins
    assert check_0 == {}, 'Expected: {}, but got: {}'.format({}, check_0)
    check_0 = config_data_0._global_settings

# Generated at 2022-06-24 18:18:48.626073
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()

# Generated at 2022-06-24 18:18:55.819759
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    config_data_1.update_setting(ConfigSetting('timezone', 'Etc/UTC'))
    assert config_data_1.get_setting('timezone') == ConfigSetting('timezone', 'Etc/UTC')
    assert config_data_1.get_settings() == [ConfigSetting('timezone', 'Etc/UTC')]



# Generated at 2022-06-24 18:19:04.475566
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    test_setting_0 = Setting()
    test_setting_0.name = 'test_setting_0'
    config_data.update_setting(test_setting_0)
    assert config_data._global_settings['test_setting_0'] == test_setting_0
    test_setting_1 = Setting()
    test_setting_1.name = 'test_setting_1'
    test_setting_1.plugin.name = 'ansible.module_utils.data'
    test_setting_1.plugin.type = PluginType.MODULE
    config_data.update_setting(test_setting_1)
    assert config_data._plugins[PluginType.MODULE]['ansible.module_utils.data']['test_setting_1'] == test_setting_1

# Unit

# Generated at 2022-06-24 18:19:13.133039
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    from ansible.cli import CLI
    from ansible.config.setting import Setting
    from ansible.plugins.loader import PluginLoader

    setting = Setting('test_setting', ['no_source'])
    setting.value = 'test'

    # make sure the setting actually exists
    config_data.update_setting(setting)

    assert config_data.get_setting('test_setting') == setting
    assert config_data.get_settings() == [setting]

    plugin_loader = PluginLoader('action', 'test_action_plugin', 'TestActionModule', 'TestActionPlugin')
    plugin = plugin_loader.get_plugin()


# Generated at 2022-06-24 18:19:15.370956
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # case 0
    config_data_0 = ConfigData()
    settings = config_data_0.get_settings()
    assert len(settings) == 0


# Generated at 2022-06-24 18:19:16.542547
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:19:20.396428
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    config_data_0.update_setting()

    assert isinstance(config_data_0, ConfigData), "Failed to instantiate ConfigData object"


# Generated at 2022-06-24 18:19:26.647462
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c0 = ConfigData()
    c0.update_setting(Setting(name="A0"))
    c0.update_setting(Setting(name="A1"))
    c0.update_setting(Setting(name="A2"))
    c0.update_setting(Setting(name="A3"))
    c0.update_setting(Setting(name="A4"))

    assert len(c0.get_settings()) == 5
    assert c0.get_setting("A0") is not None
    assert c0.get_setting("A1") is not None
    assert c0.get_setting("A2") is not None
    assert c0.get_setting("A3") is not None
    assert c0.get_setting("A4") is not None

    # Update a setting
    s0 = Setting(name="A0")

# Generated at 2022-06-24 18:19:29.053029
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    assert (config_data.get_setting('foo') is None)


# Generated at 2022-06-24 18:19:31.625408
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = config_data.get_setting(None, None)



# Generated at 2022-06-24 18:19:42.594569
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # TODO: Add test here
    return True


# Generated at 2022-06-24 18:19:45.138746
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting('setting_value')


# Generated at 2022-06-24 18:19:49.359188
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name="python_version", value="2.7.0")
    config_data.update_setting(setting)
    if (config_data._global_settings["python_version"] == setting):
        print('Pass')
    else:
        print('Failed')



# Generated at 2022-06-24 18:19:54.864245
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Construct a config_data_0 data object to pass as parm_0 to the update_setting method
    config_data_0 = ConfigData()

    # Call method update_setting of class ConfigData with a config_data_0 object
    config_data_0.update_setting(parm_0)


# Generated at 2022-06-24 18:19:58.676562
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()

if __name__ == '__main__':
    test_ConfigData_update_setting()

# Generated at 2022-06-24 18:20:05.769640
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('plugin_dir', '/etc/ansible/plugins'))
    config_data_1.update_setting(Setting('module_dir', '/etc/ansible/modules'))

    assert config_data_1.get_setting('plugin_dir') == Setting('plugin_dir', '/etc/ansible/plugins')
    assert config_data_1.get_setting('module_dir') == Setting('module_dir', '/etc/ansible/modules')

    plugin = Plugin('action', 'ping')
    config_data_1.update_setting(Setting('plugin_dir', '/etc/ansible/plugins/action/ping'), plugin)

# Generated at 2022-06-24 18:20:08.685397
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert(config_data_0.get_setting('foo') is None)


# Generated at 2022-06-24 18:20:11.572050
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting()


# Generated at 2022-06-24 18:20:19.420318
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='', value=None, value_type=None, origin=None, plugin=None, filename=None)
    config_data_0.update_setting(setting_0)


# Generated at 2022-06-24 18:20:21.734341
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    global_setting = config_data_0.get_setting('')

    assert global_setting is None


# Generated at 2022-06-24 18:20:30.349889
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    assert isinstance(config_data_1, ConfigData)
    config_data_1.get_setting(None, None)


# Generated at 2022-06-24 18:20:40.128856
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    setting_0 = Setting(name="default_test")
    setting_1 = Setting(name="test_test", plugin=Plugin(type="module", name="test_test_module"))
    setting_2 = Setting(name="test_test_test", plugin=Plugin(type="module", name="test_test_module"))
    setting_3 = Setting(name="test_test_test_test", plugin=Plugin(type="module", name="test_test_module_test"))
    config_data_1.update_setting(setting_0)
    config_data_1.update_setting(setting_1)
    config_data_1.update_setting(setting_2)
    config_data_1.update_setting(setting_3)
    assert config_data_1.get_settings()

# Generated at 2022-06-24 18:20:42.262684
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    # assert config_data_0.update_setting(__setting='__setting_0', __plugin='__plugin_0') is None


# Generated at 2022-06-24 18:20:44.702432
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    print(type(config_data_0.get_setting(None)))
    print(type(config_data_0.get_setting(None, None)))


# Generated at 2022-06-24 18:20:55.390824
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = {'type': 'string', 'name': 'string'}
    plugin_1 = {'type': 'string', 'name': 'string'}
    setting_0 = {'name': 'string', 'path': 'string', 'plugin_type': 'string', 'plugin_name': 'string', 'value': 'string'}
    setting_1 = {'name': 'string', 'path': 'string', 'plugin_type': 'string', 'plugin_name': 'string', 'value': 'string'}

    # Test case 1: Global settings
    config_data_0.update_setting(setting=setting_0, plugin=None)

# Generated at 2022-06-24 18:21:06.120034
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    assert config_data_1.get_setting('string') is None
    assert config_data_1.get_setting('list') is None
    assert config_data_1.get_setting('boolean') is None
    assert config_data_1.get_setting('dict') is None
    assert config_data_1.get_setting('integer') is None
    assert config_data_1.get_setting('float') is None
    assert config_data_1.get_setting('complex') is None
    assert config_data_1.get_setting('set') is None
    assert config_data_1.get_setting('array') is None
    assert config_data_1.get_setting('bytes') is None

    assert len(config_data_1.get_settings()) == 0


# Generated at 2022-06-24 18:21:08.157234
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = config_data_0.get_setting('name')
    assert setting_0 == None


# Generated at 2022-06-24 18:21:13.053477
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """
    update_setting(self, setting, plugin=None)
    """
    # Test config_data_0 with Global Settings
    config_data_0 = ConfigData()
    test_setting_0 = ConfigSetting("test_setting_0", "test_0")
    config_data_0.update_setting(test_setting_0)

    assert config_data_0.get_setting("test_setting_0") == test_setting_0


# Generated at 2022-06-24 18:21:16.085999
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """ test case for config_data:ConfigData.update_setting
    """
    global config_data_0
    assert config_data_0 is not None
    test_case_ConfigData_update_setting(config_data_0)



# Generated at 2022-06-24 18:21:24.647059
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    config_data.update_setting(Setting(name='test_get_settings', config_key='test_get_settings', default={}, type={}, required={}, secret={}, choices={}))
    config_data.update_setting(Setting(name='test_get_settings', config_key='test_get_settings', default={}, type={}, required={}, secret={}, choices={}))
    config_data.update_setting(Setting(name='test_get_settings', config_key='test_get_settings', default={}, type={}, required={}, secret={}, choices={}))
    print([setting.name for setting in config_data.get_settings()])


# Generated at 2022-06-24 18:21:40.094975
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    from collections import namedtuple
    plugin_0 = namedtuple('plugin', 'type name')
    plugin_0.type = 'connection'
    plugin_0.name = 'local'
    setting_0 = namedtuple('setting', 'name value origin')
    setting_0.name = 'timeout'
    setting_0.value = '30'
    setting_0.origin = 'cmdline'
    config_data_0.update_setting(setting=setting_0, plugin=plugin_0)


# Generated at 2022-06-24 18:21:41.764770
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass


# Generated at 2022-06-24 18:21:44.145538
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting('test_setting_1')


# Generated at 2022-06-24 18:21:46.738457
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    assert config_data_0.get_setting("ansible_play") == None


# Generated at 2022-06-24 18:21:51.996789
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_setting_0 = ConfigSetting(key='key_0', value='value_0')
    config_setting_0.name = 'name_0'
    config_setting_0.default = 'default_0'
    config_setting_0.fallback = 'fallback_0'
    config_setting_0.plugin = None
    config_data_0.update_setting(config_setting_0, None)


# Generated at 2022-06-24 18:21:58.666191
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    # testing with no plugins
    settings = config_data_0.get_settings()
    assert len(settings) == 0
    assert settings == []

    # testing with a plugin that doesn't exist
    class Plugin:
        type = 'foo'
        name = 'bar'

    settings = config_data_0.get_settings(plugin=Plugin)
    assert len(settings) == 0
    assert settings == []



# Generated at 2022-06-24 18:22:01.405319
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    config_data_1.update_setting("Test")

    config_data_2 = ConfigData()

    config_data_2.update_setting("Test")


# Generated at 2022-06-24 18:22:04.461329
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(name='Unit test for method get_setting for class ConfigData', 
                                     plugin=None) is None


# Generated at 2022-06-24 18:22:06.128792
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting('setting') == None


# Generated at 2022-06-24 18:22:08.030286
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(param_1)
    assert config_data_0.update_setting(param_1) == expected_result


# Generated at 2022-06-24 18:22:28.689428
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Create a ConfigData object and call method get_settings with argument plugin set to None
    config_data = ConfigData()
    # Create a Plugin object and set access attribute "name" to "syslog".
    plugin = Plugin()
    plugin.name = "syslog"
    # Call method get_settings with argument plugin set to "test_plugin"
    settings = config_data.get_settings(plugin)
    
    #print('settings: ', settings)
    #assert len(settings) == 1
    for setting in settings:
        #print('setting: ', setting)
        assert setting in settings
        assert isinstance(setting, Setting)
        # The setting with name "syslog_id" must be the first in the settings list.
        if setting.name == "syslog_id":
            assert setting.value == "bird"
            assert setting

# Generated at 2022-06-24 18:22:29.442050
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass

# Generated at 2022-06-24 18:22:38.002678
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # First test case: plugin is None
    config_data_0 = ConfigData()

    test_setting_0 = _Setting(
        name='CONFIG_FILE',
        value='/path/to/config/file',
        default='/path/to/config/file',
        type='string',
        ini_section=None,
        ini_key=None,
        env_var=None,
        required=True,
        choices=None,
        aliases=None,
        deprecated_names=None,
        description=None,
        read_only=False,
        inserted_by=None,
        inserted_at=None,
        category=None,
        deprecated_choices=None)

    settings = config_data_0.get_settings()

    assert 1 == len(settings)


# Generated at 2022-06-24 18:22:46.034574
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()
    config_data_3 = ConfigData()
    config_data_4 = ConfigData()
    config_data_5 = ConfigData()
    config_data_6 = ConfigData()
    config_data_7 = ConfigData()
    config_data_8 = ConfigData()
    config_data_9 = ConfigData()
    config_data_10 = ConfigData()
    config_data_11 = ConfigData()
    config_data_12 = ConfigData()
    config_data_13 = ConfigData()
    config_data_14 = ConfigData()
    config_data_15 = ConfigData()
    config_data_16 = ConfigData()
    config_data_17 = ConfigData()
    config_data_18 = ConfigData()
   

# Generated at 2022-06-24 18:22:51.891826
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    """
    check the correct return value of get_setting method of ConfigData class
    """

    config_data_0 = ConfigData()

    # test global setting, returns empty list
    settings = config_data_0.get_settings()
    assert len(settings) == 0

    # test plugin setting, returns empty list
    settings = config_data_0.get_settings('a plugin')
    assert len(settings) == 0



# Generated at 2022-06-24 18:22:54.479218
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    setting = {'name': 'foo', 'value': 'bar', 'origin': 'baz'}
    data.update_setting(setting)
    assert data.get_setting('foo') == setting


# Generated at 2022-06-24 18:23:04.362400
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting("AllowWarningInterruptionPlugin"))
    config_data_0.update_setting(Setting("AllowWarningInterruptionPlugin", "False"))
    config_data_0.update_setting(Setting("AlwaysAllowPullRequestMerge"))
    config_data_0.update_setting(Setting("AlwaysAllowPullRequestMerge", "False"))
    config_data_0.update_setting(Setting("ApprovalsBeforeMerge"))
    config_data_0.update_setting(Setting("ApprovalsBeforeMerge", "2"))
    config_data_0.update_setting(Setting("BranchRegex"))

# Generated at 2022-06-24 18:23:08.385569
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    import ansible.utils.plugin_docs
    setting_0 = ansible.utils.plugin_docs.ConfigEntry()
    import ansible.plugins.loader
    plugin_0 = ansible.plugins.loader.Plugin()
    config_data_0.update_setting(setting_0, plugin_0)

# Generated at 2022-06-24 18:23:18.059984
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    tmp_config_data_0 = ConfigData()
    tmp_config_setting_00 = ConfigSetting("setting_name_00")
    tmp_config_setting_01 = ConfigSetting("setting_name_01")
    tmp_config_setting_02 = ConfigSetting("setting_name_02")
    tmp_plugin_00 = Plugin("plugin_type_00", "plugin_name_00")
    tmp_plugin_01 = Plugin("plugin_type_01", "plugin_name_01")
    tmp_config_data_0.update_setting(tmp_config_setting_00)
    tmp_config_data_0.update_setting(tmp_config_setting_01, tmp_plugin_00)
    tmp_config_data_0.update_setting(tmp_config_setting_02, tmp_plugin_01)
    # test asserts


# Generated at 2022-06-24 18:23:19.641177
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    result = config_data_0.get_settings()
    assert isinstance(result, list)
    assert result == []



# Generated at 2022-06-24 18:23:38.479442
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    setting_0 = Setting()
    config_data_1.update_setting(setting_0, None)

    setting_1 = Setting()
    plugin_0 = Plugin()
    config_data_1.update_setting(setting_1, plugin_0)



# Generated at 2022-06-24 18:23:39.897085
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:23:46.603369
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()

    plugin_1 = PluginData('netconf', 'nxos-telemetry', 'cisco', None)

    setting_1 = SettingData('aaa', 'bbb', 'ccc', 
                            'ddd', 'eee', None, None, 
                            'fff', 'ggg', None, None)

    config_data_1.update_setting(setting_1, plugin_1)

    assert config_data_1.get_setting('aaa') is None
    assert config_data_1.get_setting('aaa', plugin_1) == setting_1


# Generated at 2022-06-24 18:23:51.720327
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting_plugin_0 = SettingPlugin(name = '1', type = '0')
    setting_0 = Setting(name = '0', value = '1')
    config_data.update_setting(setting_0, setting_plugin_0)
    assert len(config_data.get_settings(setting_plugin_0)) == 1
    assert config_data.get_settings(setting_plugin_0)[0].name == '0'

# Generated at 2022-06-24 18:23:56.944971
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting(name='foo', plugin=None))
    result = config_data_0.get_setting('foo', None)
    assert result.name == 'foo'
    assert result.default == None
    assert result.env_var == None
    assert result.description == None
    assert result.vault_id == None
    assert result.ini_section == None
    assert result.ini_key == None
    assert result.ini_type == None
    assert result.secret == False
    assert result.yaml_key == None
    assert result.env_var_prefix == None
    assert result.plugin == None
    assert result.plugin_name == None
    assert result.plugin_type == None
    assert result.confidential == False
    assert result

# Generated at 2022-06-24 18:24:00.310800
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    #assert config.test_case_0()==True  #TODO fix this test to work


# Generated at 2022-06-24 18:24:06.390943
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    
    # Test case 1: Test with invalid parameters.
    result_1 = config_data_0.get_setting()
    assert result_1 is None
    
    # Test case 2: Test with a valid plugin and setting name.
    result_2 = config_data_0.get_setting('foo', plugin=None)
    assert result_2 is None


# Generated at 2022-06-24 18:24:11.979894
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    config_data_1.update_setting(Setting(None, "name_1", "value_1"))
    config_data_1.update_setting(Setting(None, "name_2", "value_2"))

    config_data_2 = ConfigData()

    config_data_2.update_setting(Setting(None, "name_2", "value_2_updated"))
    config_data_2.update_setting(Setting(None, "name_3", "value_3"))

    config_data_1.update_setting(Setting(None, "name_3", "value_3"))

    test_passed = False

# Generated at 2022-06-24 18:24:13.400051
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings_0 = config_data_0.get_settings()
    assert(settings_0 == [])


# Generated at 2022-06-24 18:24:20.237797
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # prepare data for test case
    config_data_1 = ConfigData()
    setting_0 = Setting('test_name', 'test_value')
    plugin_0 = Plugin('test_type', 'test_name')

    # run test
    config_data_1.update_setting(setting_0, plugin_0)

    # verify results
    assert config_data_1._global_settings == {}
    assert config_data_1._plugins == {'test_type': {'test_name': {'test_name': setting_0}}}
