

# Generated at 2022-06-24 18:15:12.772387
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()

    # Testing global setting
    setting_0 = Setting('TestSetting_0')
    setting_0.value = "Value_0"
    config_data_0.update_setting(setting_0)

    assert config_data_0.get_setting('TestSetting_0') == setting_0

    # Testing invalid setting in global scope
    assert config_data_0.get_setting('TestSetting_1') is None

    # Testing plugin specific setting
    setting_1 = Setting('TestSetting_1')
    setting_1.value = "Value_1"
    plugin_1 = Plugin('plugin', 'test_plugin')
    config_data_0.update_setting(setting_1, plugin_1)

    assert config_data_0.get_setting('TestSetting_1', plugin_1)

# Generated at 2022-06-24 18:15:20.210264
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    setting_0 = Setting(
        name='1',
        value='2',
        plugin='a'
    )

    config_data.update_setting(setting_0)

    expected_settings = [
        {
            "name": "1",
            "value": "2",
            "plugin": "a"
        }
    ]

    settings = config_data.get_settings()

    assert list(settings) == expected_settings


# Generated at 2022-06-24 18:15:26.396135
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin = object()
    setting = object()
    config_data_0.update_setting(setting, plugin)

    settings = config_data_0.get_settings(plugin)
    assert len(settings) == 1
    assert settings[0] == setting
    setting = object()
    config_data_0.update_setting(setting, plugin)
    settings = config_data_0.get_settings(plugin)
    assert len(settings) == 2
    assert settings[0] == setting or settings[1] == setting
    assert settings[0] == setting or settings[1] == setting


# Generated at 2022-06-24 18:15:32.192802
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting())
    assert config_data_0.get_setting('name') is not None
    assert config_data_0.get_setting('name', Plugin()) is None



# Generated at 2022-06-24 18:15:34.403580
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    result = config_data_0.get_settings()
    assert result == []


# Generated at 2022-06-24 18:15:45.130124
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Setup Test
    config_data = ConfigData()

    # Test get_setting global
    setting_1 = Setting(name='module_setup', value=True)
    setting_2 = Setting(name='default_module_name', value='command')
    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2)

    global_setting_1 = config_data.get_setting('module_setup')
    global_setting_2 = config_data.get_setting('default_module_name')

    # Verify that global setting was returned successfully
    assert global_setting_1.name == 'module_setup' and \
        global_setting_1.value == 'True'
    assert global_setting_2.name == 'default_module_name' and \
        global_setting_2.value

# Generated at 2022-06-24 18:15:49.615977
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_1 = Setting()
    config_data_1.update_setting(setting_1)


# Generated at 2022-06-24 18:15:53.749483
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    print('Global settings:')
    for setting in config_data_0.get_settings():
        print(setting.name)
    print('Global setting for ansible_shell_type: '.format(config_data_0.get_setting('ansible_shell_type')))


# Generated at 2022-06-24 18:15:57.153606
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None, plugin=None)


# Generated at 2022-06-24 18:15:58.828322
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_1.get_settings()


# Generated at 2022-06-24 18:16:02.999552
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:16:13.076200
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test case 1: random name
    config_data_1 = ConfigData()
    setting_1 = config_data_1.get_setting('HGJHGJUYUGYUYGUYUYGUYUYG')
    assert setting_1 == None, "Test case 1 for ConfigData.get_setting() failed"

    # Test case 2: global setting
    setting_2 = Setting(name='setting_2', value='setting_2_value')
    config_data_2 = ConfigData()
    config_data_2.update_setting(setting_2)
    setting_2_result = config_data_2.get_setting('setting_2')
    assert setting_2_result == setting_2, "Test case 2 for ConfigData.get_setting() failed"


# Generated at 2022-06-24 18:16:15.848559
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings = config_data_0.get_settings()
    settings = config_data_0.get_settings(plugin=None)

# Generated at 2022-06-24 18:16:17.602333
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.get_settings()


# Generated at 2022-06-24 18:16:23.022399
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()
    config_data_3 = ConfigData()
    settings_1 = config_data_1.get_setting(None, None)
    settings_2 = config_data_2.get_setting(False, False)
    settings_3 = config_data_3.get_setting(True, True)


# Generated at 2022-06-24 18:16:30.956749
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting is not None
        # ValueError
        # with self.assertRaises(ValueError):
        #     config_data_0.get_setting()

        # TypeError
        # with self.assertRaises(TypeError):
        #     config_data_0.get_setting(1)



# Generated at 2022-06-24 18:16:34.458353
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    config_data_0.update_setting("'", plugin=None)
    assert config_data_0.get_setting("'", plugin=None) is not None


# Generated at 2022-06-24 18:16:36.099454
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(setting=None, plugin=None)


# Generated at 2022-06-24 18:16:47.614181
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    from ansible import context
    from ansible.plugins.loader import fragment_loader
    from ansible.errors import AnsibleError

    # Set up the context for testing
    context.CLIARGS = {'vault_password_files': [], 'ask_vault_pass': False}
    context.CACHE = None
    context.search_paths = None
    context.PLUGINS_PATH = None

    # Load the fragments needed for the test
    fragment_loader.add_directory('./_data/fragments')
    fragment_loader.update_fragments()
    fragment_loader.resolve_fragments()

    # Test update_setting using a global-level configuration setting
    setting = fragment_loader.get('defaults', 'pipelining')
    config_

# Generated at 2022-06-24 18:16:49.341200
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()

    config_data_0.update_setting(None)



# Generated at 2022-06-24 18:16:53.376931
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print('test ConfigData.update_setting')

    test_case_0()


# Generated at 2022-06-24 18:17:04.675986
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_1 = Setting('foo')
    config_data_0.update_setting(setting_1)
    config_data_0.update_setting(setting_1)
    config_data_0.update_setting(setting_1)
    config_data_0.update_setting(setting_1)
    config_data_0.update_setting(setting_1)
    config_data_0.update_setting(setting_1)
    config_data_0.update_setting(setting_1)
    config_data_0.update_setting(setting_1)
    config_data_0.update_setting(setting_1)
    config_data_0.update_setting(setting_1)
    config_data_0.update_setting(setting_1)
    config

# Generated at 2022-06-24 18:17:06.179560
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:17:08.539112
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Set up test data
    config_data_0 = ConfigData()
    config_data_0.get_settings(plugin=None)


# Generated at 2022-06-24 18:17:11.322512
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings(plugin=None) == [], 'The settings should be an empty list'


# Generated at 2022-06-24 18:17:20.174395
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    plugin_0 = Plugin()
    plugin_0.type = "also"
    plugin_0.name = "interpolated"
    setting_0 = ConfigSetting()
    setting_0.name = "SETTING"
    config_data_0.update_setting(setting_0, plugin_0)
    assert config_data_0.get_setting("SETTING", plugin_0) is setting_0
    setting_0.vault_password = 'default'
    assert ((config_data_0.get_setting("SETTING", plugin_0) is setting_0) and (setting_0.vault_password == 'default'))
    setting_0.vault_password = "default"

# Generated at 2022-06-24 18:17:31.698503
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    assert len(config_data_1.get_settings()) == 0
    assert len(config_data_1.get_settings(plugin=None)) == 0

    from ansible_collections.sensu.sensu_go.plugins.module_utils import (
        settings as setting_utils
    )

    config_data_1.update_setting(
        setting_utils.Setting(
            name='foo',
            type='bool',
            validate=None,
            aliases=[],
            version_added=None,
            load_from_file=None,
            default=None,
            env_var=None
        )
    )

# Generated at 2022-06-24 18:17:39.147254
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting = Setting('foo', 'bar', 'baz')
    config_data_0.update_setting(setting, plugin)
    assert config_data_0.get_setting('foo') == setting
    assert config_data_0.get_setting('foo', plugin) == setting
    assert config_data_0.get_setting('foo', plugin1) is None


# Generated at 2022-06-24 18:17:43.416896
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()



if __name__ == '__main__':
    test_ConfigData_update_setting()

# Generated at 2022-06-24 18:17:46.497947
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_1.update_setting()
    config_data_1.update_setting()
    config_data_1.update_setting()
    assert config_data_1.get_settings()
    assert config_data_1.get_settings()
    assert config_data_1.get_settings()


# Generated at 2022-06-24 18:17:53.969563
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    result = config_data_0.get_settings()
    assert result == []


# Generated at 2022-06-24 18:17:57.907208
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData ()
    assert config_data_1.get_settings () == []


# Generated at 2022-06-24 18:18:00.145279
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting(name=None, plugin=None)


# Generated at 2022-06-24 18:18:09.850795
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name="one", value="1")
    config_data.update_setting(setting)
    assert config_data._global_settings['one'].name == "one"
    assert config_data._global_settings['one'].value == "1"
    setting2 = Setting(name="two", value="2")
    plugin = Plugin(type="filter", name="test_plugin")
    config_data.update_setting(setting2, plugin)
    assert config_data._plugins['filter']['test_plugin']['two'].name == "two"
    assert config_data._plugins['filter']['test_plugin']['two'].value == "2"


# Generated at 2022-06-24 18:18:13.937686
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting = Setting(name='some_setting', value='some_value')
    config_data_0.update_setting(setting)
    setting_0 = config_data_0.get_setting('some_setting')
    assert setting_0.name == 'some_setting' and setting_0.value == 'some_value'


# Generated at 2022-06-24 18:18:18.352717
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()

    test_setting_1 = _TestSetting("TestSettingOne", 1234, "TestPluginOne", "TestPluginTypeOne")

    config_data_1.update_setting(test_setting_1)
    assert config_data_1.get_setting("TestSettingOne") == test_setting_1


# Generated at 2022-06-24 18:18:29.098868
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.cli.config import CLIConfigParser
    from ansible.config.manager import ConfigManager
    from ansible.config.setting import Setting

    config_data = ConfigData()
    config_parser_0 = CLIConfigParser()
    config_parser_0.read(['config_data_setting_0.cfg'])

    config_manager_0 = ConfigManager(config_data, config_parser_0)
    config_manager_0.parse()

    # Get global settings
    settings = config_data.get_settings()
    assert len(settings) == 10
    assert settings[0].name == 'constants'
    assert settings[0].default == 'test_default'
    assert settings[0].value == 'test_value'
    assert settings[0].scope == ['constants']

# Generated at 2022-06-24 18:18:30.788367
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:18:38.521667
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    assert_raises(TypeError, config_data_0.get_settings)

    assert_raises(KeyError, config_data_0.get_setting, 'not_set')

    assert_raises(KeyError, config_data_0.get_setting, 'not_set', _get_setting_plugin())

    assert_equals(config_data_0.get_setting('not_set', None), None)
    assert_equals(config_data_0.get_setting('not_set', _get_setting_plugin(None, None)), None)

    assert_equals(config_data_0.get_settings(None), [])
    assert_equals(config_data_0.get_settings(_get_setting_plugin(None, None)), [])


# Generated at 2022-06-24 18:18:43.705973
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('module_defaults', 'policies', 'loop', None, 'BAR', [], 'STRING')
    config_data_0.update_setting(setting_0)



# Generated at 2022-06-24 18:18:49.717133
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(None) is None


# Generated at 2022-06-24 18:18:55.435159
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting("setting1", "value1"))
    config_data.update_setting(Setting("setting2", "value2"))

    assert(config_data.get_settings() == [Setting("setting1", "value1"), Setting("setting2", "value2")])


# Generated at 2022-06-24 18:19:00.634295
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting('ANSIBLE_DEFAULT_LOG_PATH','/home/david/ansible.log'))
    assert config_data_0.get_setting('ANSIBLE_DEFAULT_LOG_PATH') == '/home/david/ansible.log'


# Generated at 2022-06-24 18:19:01.730455
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:19:08.274420
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    try:
        test_global_settings = config_data.get_settings()
        test_plugins_settings = config_data.get_settings(Plugin("test", "test_plugin"))
    except Exception as e:
        raise Exception("Test FAILED: get_settings: ", e)

    if test_global_settings is not None or test_plugins_settings is not None:
        raise Exception("Test FAILED: get_settings")


# Generated at 2022-06-24 18:19:17.167893
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Test with valid plugin and settings.
    config_data_1 = ConfigData()
    config_data_1.update_setting(setting=Setting(name='setting_1', value='value_1'))
    settings_1 = config_data_1.get_settings()
    assert len(settings_1) == 1 and settings_1[0].name == 'setting_1'
    plugin_1 = Plugin(type='type_1', name='name_1')
    settings_2 = config_data_1.get_settings(plugin=plugin_1)
    assert len(settings_2) == 0
    config_data_1.update_setting(setting=Setting(name='setting_2', value='value_2'), plugin=plugin_1)
    settings_3 = config_data_1.get_settings(plugin=plugin_1)

# Generated at 2022-06-24 18:19:19.312203
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:19:20.420763
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()


# Generated at 2022-06-24 18:19:27.918277
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    # A plugin-specific setting
    setting_1 = {'name': 'foo', 'value': 'bar', 'source': 'default'}
    config_data_1.update_setting(setting_1)
    global_settings_1 = config_data_1.get_settings()
    global_settings_1[0].get('source') == 'default'
    # A system-wide setting
    setting_2 = {'name': 'baz', 'value': 'qux', 'source': 'default'}
    config_data_1.update_setting(setting_2, plugin=None)
    global_settings_2 = config_data_1.get_settings()
    global_settings_2[0].get('source') == 'default'

# Generated at 2022-06-24 18:19:29.686120
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:19:41.102222
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting(name)
    config_data_0.get_setting(name, plugin)


# Generated at 2022-06-24 18:19:42.373698
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()


# Generated at 2022-06-24 18:19:44.817430
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    print(str(config_data_0.get_settings()))


# Generated at 2022-06-24 18:19:52.543628
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    setting_0 = ConfigSetting(name='default_completion_timeout',
                              description='Default timeout for command completion.',
                              default='10',
                              ini_section='defaults',
                              ini_key='completion_timeout')
    setting_1 = ConfigSetting(name='log_path',
                              description='If this setting is defined, all log output will be written to this path. '
                                          'If the path points to a directory, log filenames will be generated '
                                          'automatically.',
                              ini_section='defaults',
                              ini_key='log_path')

# Generated at 2022-06-24 18:19:58.746310
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.update_setting(mock_get_setting1)
    config_data_0.update_setting(mock_get_setting1)
    settings = config_data_0.get_settings()
    assert_equal(settings, [mock_get_setting1, mock_get_setting2])
    

# Generated at 2022-06-24 18:20:03.782456
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    test_setting_1 = Setting("plugin_name_0", "namespace_0", "name_0", "value_0")
    test_setting_1.origin = "from_file"
    config_data_1.update_setting(test_setting_1)
    # This should return "from_file"
    assert config_data_1.get_setting("name_0").origin == "from_file"


# Generated at 2022-06-24 18:20:05.459346
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:20:08.403948
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 18:20:15.700951
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    global_setting = ConfigSetting('my_var', 'my_value')
    plugin_setting = ConfigSetting('my_var', 'my_value')
    plugin = Plugin('my_plugin', 'my_type')
    config_data_1 = ConfigData()
    config_data_1.update_setting(global_setting)
    config_data_1.update_setting(plugin_setting, plugin)
    assert config_data_1.get_setting('my_var') == global_setting
    assert config_data_1.get_setting('my_var', plugin) == plugin_setting


# Generated at 2022-06-24 18:20:23.854580
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    default_setting_0 = None
    plugin_setting_0 = PluginSetting(default_setting_0, 'option_1')
    plugin_0 = None
    plugin_1 = Plugin(plugin_0, 'community.general', 'general', 'Network')
    plugin_1.type = 'action'
    plugin_1.name = 'plugin_1'
    config_data_0.update_setting(plugin_setting_0, plugin_1)
    plugin_setting_1 = PluginSetting(default_setting_0, 'option_2')
    plugin_2 = Plugin(plugin_1, 'community.general', 'general', 'Network')
    plugin_2.type = 'action'
    plugin_2.name = 'plugin_1'

# Generated at 2022-06-24 18:20:42.363006
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting='setting_2')
    assert config_data_0.get_settings() == ['setting_2']


# Generated at 2022-06-24 18:20:46.827025
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting = Setting('a', 'b', 'c', 'd')
    config_data_0.update_setting(setting)
    assert config_data_0._global_settings['a'].name == 'a'
    assert config_data_0._global_settings['a'].value == 'b'
    assert config_data_0._global_settings['a'].description == 'c'
    assert config_data_0._global_settings['a'].default == 'd'


# Generated at 2022-06-24 18:20:48.360421
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:20:50.773085
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting("config")
    assert len(config_data_0._global_settings) == 1


# Generated at 2022-06-24 18:20:54.037714
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(ConfigSetting('foo', 'bar'))
    print(config_data_0.get_setting('foo').value)


# Generated at 2022-06-24 18:21:04.900997
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_obj = ConfigData()
    config_data_obj_1 = ConfigData()
    config_data_obj_2 = ConfigData()
    config_data_obj_3 = ConfigData()

    # Case 0: Set global setting
    assert len(config_data_obj.get_settings()) == 0

    config_data_obj.update_setting(Setting(True, 'foo', 'int'))
    assert len(config_data_obj.get_settings()) == 1

    assert config_data_obj.get_setting('foo') == Setting(True, 'foo', 'int')
    assert config_data_obj.get_setting('bar') is None

    # Case 1: Set module setting
    assert len(config_data_obj_1.get_settings()) == 0

    m_1 = Module('core', 'shell')

# Generated at 2022-06-24 18:21:09.838782
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='foo_name', value='foo_value', plugin=None)
    config_data_0.update_setting(setting_0, plugin=None)

    settings = config_data_0.get_settings()
    assert len(settings) == 1
    assert settings[0].name == 'foo_name'
    assert settings[0].value == 'foo_value'
    assert settings[0].plugin is None


# Generated at 2022-06-24 18:21:11.383226
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:21:20.395086
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("name", "value"))
    assert config_data.get_setting("name").name == "name"
    assert config_data.get_setting("name").value == "value"
    assert config_data.get_setting("name", plugin=Plugin("none", "none")).name == "name"
    assert config_data.get_setting("name", plugin=Plugin("none", "none")).value == "value"
    config_data.update_setting(Setting("name", "value", plugin=Plugin("none", "none")))
    assert config_data.get_setting("name").name == "name"
    assert config_data.get_setting("name").value == "value"

# Generated at 2022-06-24 18:21:30.106488
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting()
    config_data_0.update_setting()
    config_data_0.update_setting()
    config_data_0.update_setting()
    config_data_0.update_setting()
    config_data_0.update_setting()
    config_data_0.update_setting()
    config_data_0.get_setting()
    config_data_0.update_setting()
    config_data_0.update_setting()
    config_data_0.update_setting()
    config_data_0.update_setting()
    config_data_0.update_setting()
    config_data_0.update_setting()
    config_data_0.update_setting()
    config_data_0.get

# Generated at 2022-06-24 18:21:54.151610
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    settings_0 = settings.Settings()
    settings.Setting._constructor=True
    settings.Setting._constructor=None
    settings.Settings._constructor=True
    settings.Setting._constructor=None
    settings.Settings._constructor=None
    settings.Settings._constructor=None
    settings.Settings._constructor=True
    settings.Settings._constructor=None
    settings.Settings._constructor=True
    settings.Settings._constructor=None
    settings.Settings._constructor=None
    settings.Settings._constructor=True
    settings.Settings._constructor=None
    settings.Settings._constructor=True
    settings.Settings._constructor=True
    settings.Settings._constructor=None
    settings.Settings._constructor=True

# Generated at 2022-06-24 18:21:56.909922
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
  config_data_1 = ConfigData()
  assert config_data_1.get_settings() == [], 'Expected empty list'



# Generated at 2022-06-24 18:21:58.771290
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert config_data_1.get_settings() == []


# Generated at 2022-06-24 18:22:00.901733
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_update_setting = ConfigData()
    config_data_update_setting.update_setting('Setting1', 'Plugin1')


# Generated at 2022-06-24 18:22:09.490420
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print("Testing update_setting")
    config_data_1 = ConfigData()
    setting_1 = ConfigDataSetting("ansible_hosts", "hosts", "127.0.0.1", "string", "set to a list of hostname or ip address of hosts to be managed by ansible if the default of detecting the local machine's hostname via socket.gethostname() is not desired")
    config_data_1.update_setting(setting_1)

    if len(config_data_1._global_settings) != 1:
        raise RuntimeError("Expected 1 global setting, but got %d" % len(config_data_1._global_settings))

# Generated at 2022-06-24 18:22:12.702405
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = test_case_0()
    setting_0 = config_data_0.get_setting(name='foo')

    assert setting_0 is None


# Generated at 2022-06-24 18:22:16.171880
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansiblelint.rules.UseShellInsteadOfCommandRule import CommandSetting
    config_data_0 = ConfigData()
    setting_0 = CommandSetting('command')
    result = config_data_0.update_setting(setting_0)
    assert result is None


# Generated at 2022-06-24 18:22:21.756592
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass
    # config_data_0 = ConfigData()
    # # ConfigData.update_setting(config_data_0, setting_0, plugin_0)
    # # ConfigData.update_setting(config_def_data, ConfigSetting(setting_0), plugin_0)


# Generated at 2022-06-24 18:22:29.916050
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    config_data_0 = ConfigData()
    config_data_0.update_setting(name="foo", default=None, type="str", value="foo", module=module)
    config_data_0.update_setting(name="bar", default=None, type="str", value="bar", module=module)
    config_data_0.update_setting(name="baz", default=None, type="str", value="baz", module=module)
    return_value = config_data_0.get_setting(name="baz")
    assert return_value is not None
    return_value = config_data_0.get_setting(name="qux")
    assert return_value is None

#

# Generated at 2022-06-24 18:22:32.784609
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_1 = Setting('body_size', '128')
    config_data_1.update_setting(setting_1)


# Generated at 2022-06-24 18:22:57.893373
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    with pytest.raises(ValueError):
        config_data_0.update_setting(Setting('test_code', value='test_value', state='test_state'))


# Generated at 2022-06-24 18:22:59.312836
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    pass # TODO



# Generated at 2022-06-24 18:23:01.930522
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Arrange
    config_data_0 = ConfigData()

    # Assert
    assert test_expected(config_data_0.get_settings(),[]) is True


# Generated at 2022-06-24 18:23:09.719210
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    setting_a = Setting('setting_a', 'value_a1')
    setting_b = Setting('setting_b', 'value_b1')

    plugin_a = PluginDefinition(PluginType.ACTION, 'plugin_a')

    config_data.update_setting(setting_a)
    assert config_data.get_setting('setting_a') == setting_a

    config_data.update_setting(setting_b, plugin_a)
    assert config_data.get_setting('setting_b', plugin_a) == setting_b
    assert config_data.get_setting('setting_a') == setting_a



# Generated at 2022-06-24 18:23:19.951146
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()
    setting_0 = Setting(name='AUTH_PASSWORD', type='str', value='pass')
    config_data_0.update_setting(setting=setting_0, plugin=Plugin(type='basic', name='httpapi'))
    setting_1 = Setting(name='HTTP_AUTH_PASS', type='str', value='pass')
    config_data_0.update_setting(setting=setting_1, plugin=Plugin(type='basic', name='httpapi'))

    settings = config_data_0.get_settings(plugin=Plugin(type='basic', name='httpapi'))

    assert len(settings) == 2
    assert settings[0].name == 'AUTH_PASSWORD'
    assert settings[0].type == 'str'

# Generated at 2022-06-24 18:23:29.551401
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    test_setting_0 = Setting(name="test0_name", description="test0_description")
    config_data_0.update_setting(test_setting_0)
    assert config_data_0._global_settings == {"test0_name": test_setting_0}

    test_plugin1_0 = Plugin("test_plugin1_0", "type1")
    test_setting_1 = Setting(name="test1_name", description="test1_description")
    config_data_0.update_setting(test_setting_1, test_plugin1_0)
    assert config_data_0._plugins["type1"]["test_plugin1_0"] == {"test1_name": test_setting_1}


# Generated at 2022-06-24 18:23:32.277756
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert config_data_1.get_settings() == []


# Generated at 2022-06-24 18:23:39.999355
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    # Test for the default values for the method get_setting:
    # NameError: name 'plugin' is not defined
    config_data_0.get_setting(name='name', plugin=None)
    # KeyError: 'name'
    config_data_0.get_setting(name='name', plugin='plugin')
    # TypeError: get_setting() got an unexpected keyword argument 'name'
    config_data_0.get_setting(plugin='plugin')
    # TypeError: get_setting() got an unexpected keyword argument 'name'
    config_data_0.get_setting(name='name')



# Generated at 2022-06-24 18:23:41.997458
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin = None
    config_data_0.get_settings(plugin)


# Generated at 2022-06-24 18:23:47.099117
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting='setting_0')
    assert config_data_0.get_setting(name='setting_0') == 'setting_0', 'The setting is not set correctly'


# Generated at 2022-06-24 18:24:16.975020
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    test_config_data_plugin_0 = test_config_data_plugin_0()
    test_config_data_setting_0 = test_config_data_setting_0()
    config_data.update_setting(test_config_data_setting_0, test_config_data_plugin_0)
    test_config_data_setting_1 = test_config_data_setting_1()
    config_data.update_setting(test_config_data_setting_1)
    assert config_data.get_setting('test_setting_name') == test_config_data_setting_1
    assert config_data.get_setting('test_setting_name') != test_config_data_setting_0


# Generated at 2022-06-24 18:24:19.967066
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:24:25.337605
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print("Start: test_ConfigData_update_setting")
    ConfigData_inst = ConfigData()
    # Update a global setting
    ConfigData_inst.update_setting(1,None)
    assert(ConfigData_inst.get_setting(1) == None)
    print("End: test_ConfigData_update_setting")
    

# Generated at 2022-06-24 18:24:29.050564
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_setting_0 = ConfigSetting()
    config_data_0.update_setting(config_setting_0)


# Generated at 2022-06-24 18:24:31.107586
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    print(config_data_0.get_settings())


# Generated at 2022-06-24 18:24:40.810476
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    print("test_ConfigData_update_setting - IN")

#    config_data.update_setting(Setting(name='Test', value=True))
#    print(config_data.get_setting('Test'))

    ansible_os_family = ansible.module_utils.basic.AnsibleOSFamily()
    plugin_loader = PluginLoader(ansible_os_family)

    # Add 3 settings for 2 plugins
    setting_0 = Setting(name='Test0', value=True, plugin=Plugin('module', 'copy'))
    config_data.update_setting(setting=setting_0)
    setting_1 = Setting(name='Test1', value='string', plugin=Plugin('module', 'copy'))
    config_data.update_setting(setting=setting_1)
    setting

# Generated at 2022-06-24 18:24:45.755921
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    test_setting_1 = Setting(name='foo', value=1)
    config_data_1.update_setting(test_setting_1)
    assert config_data_1.get_setting('foo') == test_setting_1


# Generated at 2022-06-24 18:24:52.194439
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_setting_0 = ConfigSetting(config_data_0, '', False, False, None, None)
    config_data_0.update_setting(config_setting_0, None)
    config_setting_1 = ConfigSetting(config_data_0, '', False, True, None, None)
    config_data_0.update_setting(config_setting_1, None)
    config_data_0.update_setting(config_setting_1, None)


# Generated at 2022-06-24 18:24:53.924475
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting() is None


# Generated at 2022-06-24 18:25:04.113937
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    setting_0 =  Setting()
    setting_0.name = 'foo'
    setting_0.value = 'bar'

    plugin_0 = Plugin()
    plugin_0.name = 'foo'
    plugin_0.path = 'test/test'
    plugin_0.type = 'module'

    config_data_0.update_setting(setting_0, plugin=None)

    result = config_data_0.get_settings(plugin=plugin_0)
    assert result == []

    result = config_data_0.get_settings(plugin=None)
    assert result == [{'name': 'foo', 'value': 'bar'}]

    config_data_0.update_setting(setting_0, plugin=plugin_0)