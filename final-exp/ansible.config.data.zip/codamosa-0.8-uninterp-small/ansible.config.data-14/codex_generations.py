

# Generated at 2022-06-24 18:14:58.819378
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    config_data_0.update_setting(setting)


# Generated at 2022-06-24 18:15:01.130415
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(str()) is None



# Generated at 2022-06-24 18:15:06.877266
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = GlobalSetting(name = 'ansible_host', value = '1.1.1.1')
    config_data.update_setting(setting = setting)
    assert config_data.get_setting(name = 'ansible_host') == setting


# Generated at 2022-06-24 18:15:13.799305
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name="foo", default=None, description=None, value=None, origin=None, plugin=None)
    setting_1 = Setting(name="baz", default=None, description=None, value=None, origin=None, plugin=None)
    config_data_0.update_setting(setting_0)
    config_data_0.update_setting(setting_1)
    #assert config_data_0.get_setting('baz', plugin=None) == setting_1 # TODO
    pass


# Generated at 2022-06-24 18:15:22.824495
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()

    from ansible.config.setting import Setting
    from ansible.plugins import Plugin
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    # Plugin for which to add settings, then retrieve
    plugin_loader = PluginLoader(class_name='ModuleUtils')
    plugin_types = plugin_loader._get_all_subclasses(
        base_class_type='ModuleUtils'
    )

    test_collection_loader = AnsibleCollectionLoader()
    plugin_utils_type = plugin_types[0]


# Generated at 2022-06-24 18:15:25.521048
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("hello")
    assert config_data._global_settings == "hello"


# Generated at 2022-06-24 18:15:27.641980
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    from ansible.config.manager import Setting

# Generated at 2022-06-24 18:15:32.391397
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('foobar'))
    assert config_data_1.get_setting('foobar') is not None



# Generated at 2022-06-24 18:15:41.164119
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    ansible_2_4_0_0 = config_data_0.get_setting('ANSIBLE_COLLECTIONS_PATH')
    test_0 = ansible_2_4_0_0
    assert test_0 == None
    ansible_2_6_0_0 = config_data_0.get_setting('ANSIBLE_CALLBACK_WHITELIST')
    test_1 = ansible_2_6_0_0
    assert test_1 == None
    ansible_2_6_0_1 = config_data_0.get_setting('ANSIBLE_GATHERING')
    test_2 = ansible_2_6_0_1
    assert test_2 == None
    ansible_2_6_0_2 = config_data_0.get

# Generated at 2022-06-24 18:15:42.934516
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting(None, None)


# Generated at 2022-06-24 18:15:48.334251
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(None)


# Generated at 2022-06-24 18:15:50.688055
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() is None


# Generated at 2022-06-24 18:15:51.612102
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    c0 = ConfigData()


# Generated at 2022-06-24 18:15:56.554447
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting('setting')
    config_data_0.update_setting('setting')
    config_data_0.update_setting('setting')
    config_data_0.update_setting('setting')
    config_data_0.update_setting('setting')
    config_data_0.update_setting('setting')
    config_data_0.update_setting('setting')


# Generated at 2022-06-24 18:15:58.722014
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting("--allow-unknown-internal-module-names")

# Generated at 2022-06-24 18:16:01.659602
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(config_data_0, name="test")
    config_data_0.update_setting(setting_0, None)
    assert len(config_data_0._global_settings) == 1


# Generated at 2022-06-24 18:16:09.125817
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    # Test update_setting with no arguments.
    # Should raise TypeError
    try:
        config_data_0.update_setting()
    except TypeError:
        assert(True)
    else:
        assert(False)

    # Test update_setting with a non-Setting argument.
    # Should raise TypeError
    try:
        config_data_0.update_setting(3)
    except TypeError:
        assert(True)
    else:
        assert(False)


if __name__ == '__main__':
    test_case_0()
    test_ConfigData_update_setting()

# Generated at 2022-06-24 18:16:13.921380
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    # Tests for cases when plugin is None
    assert config_data_0.get_settings(plugin=None) is None
    assert config_data_0.get_settings(plugin=None) is None
    assert config_data_0.get_settings(plugin=None) is None


# Generated at 2022-06-24 18:16:15.848735
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    config_data_0.update_setting()


# Generated at 2022-06-24 18:16:18.439813
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(None)
    config_data_0.update_setting(None, None)


# Generated at 2022-06-24 18:16:25.798648
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    plugin_0 = Plugin()
    setting_1 = dict()
    setting_1["name"] = "DUMMY"
    setting_1["value"] = "DUMMY"
    setting_1["origin"] = "DUMMY"
    setting_1["priority"] = 0
    config_data_1.update_setting(setting_1, plugin_0)


# Generated at 2022-06-24 18:16:32.883461
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    setting_0 = dict(name='test_setting_0', value=0)
    setting_1 = dict(name='test_setting_0', value=1)
    config_data.update_setting(setting_0)
    config_data.update_setting(setting_1)
    config_data.get_settings()
    assert setting_0 == config_data.get_settings()

# Generated at 2022-06-24 18:16:40.678678
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0_settings_0 = {}
    config_data_0_settings_0['config_data_0_setting_0'] = 'config_data_0_setting_0'
    config_data_0_settings_0['config_data_0_setting_1'] = 'config_data_0_setting_1'

    config_data_0 = ConfigData()
    config_data_0.update_setting('config_data_0_setting_0')

# Generated at 2022-06-24 18:16:43.645229
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = config_data_0.get_setting(plugin='plugin_0', name='name_0')
    setting_1 = config_data_0.get_setting(name='name_0')
    setting_2 = config_data_0.get_setting(name='name_0', plugin=None)


# Generated at 2022-06-24 18:16:50.385823
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Initializations
    config_data_0 = ConfigData()
    plugin_0 = Plugin('', '')

    # Test
    test = config_data_0.get_settings(plugin=plugin_0)

    # Assert
    assert test == []


# Generated at 2022-06-24 18:16:53.047638
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None)



# Generated at 2022-06-24 18:17:04.271924
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Get non-existent setting
    assert config_data.get_setting(None, None) is None

    # Get global setting
    global_setting = Setting('name', 'default_value', 'description')
    config_data.update_setting(global_setting)
    assert config_data.get_setting('name') == global_setting

    # Get callback setting
    callback_setting = Setting('name', 'default_value', 'description')
    callback_plugin = Plugin('callback', 'debug', 'description')
    config_data.update_setting(callback_setting, callback_plugin)
    assert config_data.get_setting('name', callback_plugin) == callback_setting

    # Get not-assigned callback setting

# Generated at 2022-06-24 18:17:05.504501
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global config_data_0
    config_data_0.update_setting(Setting_0)


# Generated at 2022-06-24 18:17:08.913702
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    
    config_data_0 = ConfigData()
    config_setting_0 = Setting('name', 'value', 'plugin', 'plugin_type')
    config_data_0.update_setting(config_setting_0)
    print(config_data_0.get_setting('name'))


# Generated at 2022-06-24 18:17:10.474859
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()


# Generated at 2022-06-24 18:17:20.276567
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()

    test_case_0(config_data_0)
    config_data_0.update_setting(setting=Setting('path', '/tmp/'))
    test_case_1(config_data_0)
    config_data_0.update_setting(setting=Setting('module_name', 'copy'))
    test_case_2(config_data_0)
    config_data_0.update_setting(setting=Setting('name', 'ansible'))
    test_case_3(config_data_0)
    config_data_0.update_setting(setting=Setting('path', ''))
    test_case_4(config_data_0)



# Generated at 2022-06-24 18:17:22.010412
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:17:31.401482
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting =  {'name': 'required', 'default': False, 'env': [], 'ini': [], 'yaml': [], 'python': {'type': 'bool'}, 'argparse': {'help': 'setting to require', 'action': 'store_true'}, 'configparser': {}, 'constant': {}, 'type': 'bool'})

# Generated at 2022-06-24 18:17:44.271140
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('name1', 'value1'))
    config_data_1.update_setting(Setting('name2', 'value2'))
    config_data_1.update_setting(Setting('name3', 'value3'), Plugin(PluginType.CORE, 'core'))
    assert config_data_1.get_setting('name1') == Setting('name1', 'value1')
    assert config_data_1.get_setting('name2') == Setting('name2', 'value2')
    assert config_data_1.get_setting('name3', Plugin(PluginType.CORE, 'core')) == Setting('name3', 'value3')
    assert config_data_1.get_setting('name4') is None

# Generated at 2022-06-24 18:17:49.853482
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    setting_0 = config_data.get_setting('val_0')
    assert setting_0 is None

    setting_1 = config_data.get_setting('val_1', 'plugin_0')
    assert setting_1 is None

    setting_2 = config_data.get_setting('val_1', 'plugin_1')
    assert setting_2 is None

    config_data.update_setting(Setting('val_0', '', '', None, '', ''))

    setting_3 = config_data.get_setting('val_0')
    assert setting_3.name == 'val_0'

    config_data.update_setting(Setting('val_1', '', '', None, '', ''), 'plugin_0')


# Generated at 2022-06-24 18:17:53.469324
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert((config_data_0.get_setting('setting')) == None)


# Generated at 2022-06-24 18:17:55.823708
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    for plugin in config_data_0.get_settings():
        plugin.name


# Generated at 2022-06-24 18:17:57.035197
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()


# Generated at 2022-06-24 18:17:59.353173
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()


if __name__ == '__main__':
    test_ConfigData_update_setting()

# Generated at 2022-06-24 18:18:02.901666
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_0 = Setting(name='foo', value='bar')
    plugin_0 = Plugin(type='foo', name='bar')
    config_data.update_setting(setting=setting_0, plugin=plugin_0)


# Generated at 2022-06-24 18:18:15.727162
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    """Test for method get_setting of class ConfigData."""
    config_data_0 = ConfigData()

    # No value exists for setting
    try:
        config_data_0.get_setting('x')
    except:
        pass
    else:
        raise AssertionError('Unable to raise exception for accessing a non-existent setting')

    from ansible.module_utils.common.collections import ImmutableDict
    setting_0 = ImmutableDict({'type': 'dict', 'key': 'x', 'value': {'a': 'b'}})
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_setting('x') == setting_0

# Generated at 2022-06-24 18:18:17.243414
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(None)


# Generated at 2022-06-24 18:18:20.456699
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting('connection', 'local', 'connection', True))
    # Call method get_settings
    assert (config_data_0.get_settings(Plugin('connection', 'local')) != [])


# Generated at 2022-06-24 18:18:29.597157
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Instantiate an object of class ConfigData
    config_data_0 = ConfigData()
    # Create new Setting object
    setting_01 = Setting(name='options', value='value1', plugin=None)
    # Update the information for the Setting object
    config_data_0.update_setting(setting_01)
    # Get the information for the Setting object
    value = config_data_0.get_settings()[0]
    # Check if the returned value is the same as the one stored
    assert value == setting_01

# Generated at 2022-06-24 18:18:37.738662
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()
    setting_0 = Setting('setting_0', 'value_0')
    setting_1 = Setting('setting_1', 'value_1')

    plugin_0 = Plugin('test_case_0', 'cache')
    plugin_1 = Plugin('test_case_0', 'shell')

    config_data_0.update_setting(setting_0, plugin=None)
    config_data_0.update_setting(setting_1, plugin=plugin_0)

    settings = config_data_0.get_settings()
    assert len(settings) == 1
    assert settings[0] == setting_0

    settings = config_data_0.get_settings(plugin=plugin_0)
    assert len(settings) == 1
    assert settings[0] == setting_1

    settings = config

# Generated at 2022-06-24 18:18:48.709096
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """
    test_ConfigData_update_setting
    """
    config_data_0 = ConfigData()
    setting = {}
    setting['name'] = "JAVA_HOME"
    setting['value'] = "/usr/java/jdk1.7.0_21"
    setting['status'] = "active"
    config_data_0.update_setting(setting)

    setting = {}
    setting['name'] = "JAVA_HOME"
    setting['value'] = "/usr/java/jdk1.7.0_22"
    setting['status'] = "inactive"
    config_data_0.update_setting(setting)



# Generated at 2022-06-24 18:18:52.410611
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()

# Generated at 2022-06-24 18:18:55.943670
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = None
    plugin_0 = None
    config_data_0.update_setting(setting_0, plugin_0)
    setting_1 = None
    plugin_1 = None
    config_data_0.update_setting(setting_1, plugin_1)


# Generated at 2022-06-24 18:18:57.119147
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert False


# Generated at 2022-06-24 18:19:04.027472
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    plugin_0 = Plugin('my_type', 'my_name')
    settings_0 = config_data_0.get_settings(plugin=plugin_0)
    settings_1 = config_data_0.get_settings(plugin=plugin_0)
    settings_2 = config_data_0.get_settings(plugin='my_name')
    settings_3 = config_data_0.get_settings(plugin='my_name')
    settings_4 = config_data_0.get_settings()
    settings_5 = config_data_0.get_settings()


# Generated at 2022-06-24 18:19:11.721376
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    global config_data_0
    setting_0 = Setting(name='name_1')
    plugin_0 = Plugin(name='name_0', type='type_0')
    setting_1 = config_data_0.get_setting(setting_0.name, plugin_0)


# Generated at 2022-06-24 18:19:20.389027
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = Plugin('junit', '1.4')
    setting_0 = Setting('name', 'junit')
    setting_1 = Setting('type', '1.4')
    setting_2 = Setting('location', 'C:\\Users\\sanjiv\\junit.jar')
    config_data_0.update_setting(setting_0, plugin_0)
    config_data_0.update_setting(setting_1, plugin_0)
    config_data_0.update_setting(setting_2)
    setting_3 = config_data_0.get_setting('junit', config_data_0.get_setting('junit'))
    assert setting_3.get_setting('value') == 'junit'

# Generated at 2022-06-24 18:19:23.671131
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-24 18:19:25.308091
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting('/etc/ansible/ansible.cfg')

# Generated at 2022-06-24 18:19:29.487799
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = Plugin('action_plugin', 'copy')
    assert config_data_0.get_settings(plugin_0) is not None


# Generated at 2022-06-24 18:19:34.639532
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test when plugin is None and name is a string
    config_data_0 = ConfigData()
    config_data_0.update_setting(
        {'name': 'my_global_setting'})

    # Test when plugin is "None" but name is not a string
    config_data_1 = ConfigData()
    update_setting_0 = config_data_1.update_setting(
        {'name': {}})


# Generated at 2022-06-24 18:19:37.105617
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting()

# Generated at 2022-06-24 18:19:39.653363
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(None)


# Generated at 2022-06-24 18:19:41.403193
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:19:50.985444
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    print (os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.dirname(os.path.abspath(__file__)) + '/../data/test_ansible_config_data_update_setting0.json') as f:
        test_data = json.load(f)
    #print(test_data)
    for config_item in test_data:
        config_data_0.update_setting(Setting(name=config_item['name'], value=config_item['value'], origin=config_item['origin'] ,plugin=Plugin(type_=config_item['plugin']['type'], name=config_item['plugin']['name'])))
    #print(config_data_0._global_settings

# Generated at 2022-06-24 18:19:59.946482
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.get_settings()
    config_data_0.get_settings()
    config_data_0.get_settings()


# Generated at 2022-06-24 18:20:02.408274
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting = None
    plugin = None
    config_data_0.update_setting(setting, plugin)


# Generated at 2022-06-24 18:20:04.570716
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:20:10.166032
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    setting_0 = ConfigSetting(config_data_0, 'foo', 'bar', 'baz')
    setting_0.update()
    result_0 = config_data_0.get_setting('foo')
    assert result_0.name == 'foo'


# Generated at 2022-06-24 18:20:13.319823
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings = config_data_0.get_settings()
    if settings:
        assert True
    else:
        assert False


# Generated at 2022-06-24 18:20:17.239928
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    plugin_0 = Plugin('module')
    str_0 = config_data_0.get_setting('inventory')
    str_1 = config_data_0.get_setting('splunk_password', plugin_0)


# Generated at 2022-06-24 18:20:20.076794
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []

# Unittest for method get_setting of class ConfigData

# Generated at 2022-06-24 18:20:28.565401
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert len(config_data._global_settings) == 0

    setting = ConfigSetting()
    setting.name = "abc"
    setting.value = "def"
    setting.plugins = ["foo", "bar"]
    setting.plugin_type = "XYZ"

    config_data.update_setting(setting)
    assert len(config_data._global_settings) == 1
    assert config_data._global_settings["abc"] == setting

    setting.name = "foo"
    config_data.update_setting(setting, plugin="foo")
    assert len(config_data._plugins["XYZ"]["foo"]) == 1
    assert config_data._plugins["XYZ"]["foo"]["foo"] == setting



# Generated at 2022-06-24 18:20:39.345167
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Test no plugin
    config_data_0 = ConfigData()
    config_setting_0 = Setting('setting_name_0')
    config_setting_1 = Setting('setting_name_1')
    config_setting_2 = Setting('setting_name_2')
    config_data_0.update_setting(config_setting_0)
    config_data_0.update_setting(config_setting_1)
    config_data_0.update_setting(config_setting_2)
    assert config_data_0.get_settings() == [config_setting_0, config_setting_1, config_setting_2]

    # Test with plugin
    config_data_1 = ConfigData()
    config_plugin_0 = Plugin('plugin_type_0', 'plugin_name_0')

# Generated at 2022-06-24 18:20:41.876586
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    settings_0 = settings_0()
    for k in settings_0:
        config_data_0.update_setting(k)


# Generated at 2022-06-24 18:20:48.901226
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    data = config_data.get_setting("foo")
    assert data is None


# Generated at 2022-06-24 18:20:54.326916
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    from ansible.config.plugin import PluginConfig, PluginConfigValue
    from ansible.config.settings import SETTINGS
    setting_1 = PluginConfig('test', SETTINGS['DEFAULT']())
    expected = config_data_1
    actual = config_data_1.update_setting(setting_1)
    assert(actual == expected)



# Generated at 2022-06-24 18:20:55.646255
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting = Setting()


# Generated at 2022-06-24 18:21:01.773994
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting("this_is_a_test_key_input", "this_is_a_test_plugin_input") == None


# Generated at 2022-06-24 18:21:08.020150
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {}
    setting['name'] = 'name'
    setting['value'] = 'value'
    setting['priority'] = 10
    config_data.update_setting(setting)
    assert(config_data.get_setting('name'))



# Generated at 2022-06-24 18:21:18.085841
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import config

    def update_setting(setting_name, data, plugin=None):
        setting = config.Setting(setting_name, data)
        config_data.update_setting(setting, plugin)

    config_data = ConfigData()
    update_setting('log_path', '/var/log/ansible.log')
    update_setting('fact_path', '/var/ansible/cache')
    update_setting('roles_path', '/var/ansible/roles')
    update_setting('library', '/usr/share/ansible')
    update_setting('action_plugins', '/usr/share/ansible/plugins/action')
    update_setting('filter_plugins', '/usr/share/ansible/plugins/filter')
    update_setting('lookup_plugins', '/usr/share/ansible/plugins/lookup')

# Generated at 2022-06-24 18:21:21.727885
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    name = random.choice(string.ascii_letters)
    plugin = Plugin()
    result = config_data_0.get_setting(name, plugin)
    assert result is not None


# Generated at 2022-06-24 18:21:24.256027
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting_1 = config_data_1.get_setting('foo')
    print(setting_1)


# Generated at 2022-06-24 18:21:26.127122
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:21:27.221132
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_case_0()


# Generated at 2022-06-24 18:21:39.510512
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_obj_0 = ConfigData()
    setting_obj_0 = AnsibleConfigSetting()
    setting_obj_0.name = 'META_SETUP_HELPER_CONFIGS_0'
    assert config_data_obj_0.update_setting(setting_obj_0) == None


# Generated at 2022-06-24 18:21:44.900765
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    import ansible.constants
    setting = ansible.constants.CLI_OPTIONS.DEFAULT_CALLBACK_WHITELIST
    config_data.update_setting(setting, None)


# Generated at 2022-06-24 18:21:48.658275
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
# Test scenario 1:
# Unmatched plugin
    result = config_data_0.get_setting("Playbook", plugin="Toplevel")
    assert (result is None)


# Generated at 2022-06-24 18:21:53.118564
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:22:02.272652
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Test 'update_setting' with a global setting
    config_data = ConfigData()
    config_data.update_setting(Setting('debug', 'False'))
    config_data.update_setting(Setting('display_skipped_hosts', 'False'))

    # Test 'update_setting' with a normal plugin
    config_data.update_setting(Setting('display_skipped_hosts', 'True', Plugin('callback', 'default')))

    # Test 'update_setting' with a callback plugin
    config_data.update_setting(Setting('display_skipped_hosts', 'False', Plugin('callback', 'minimal')))
    config_data.update_setting(Setting('display_skipped_hosts', 'True', Plugin('callback', 'skippy')))



# Generated at 2022-06-24 18:22:06.284506
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_setting_2 = ConfigSetting(name='when_path')
    config_data_1.update_setting(config_setting_2)
    assert config_data_1.get_setting(name='when_path') == config_setting_2


# Generated at 2022-06-24 18:22:08.958404
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    # get_setting with plugin
    setting = config_data_0.get_setting("foo")
    assert setting is None

    # get_setting with plugin
    setting = config_data_0.get_setting("foo", Plugin("action", "stop"))
    assert setting is None


# Generated at 2022-06-24 18:22:14.842494
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('name', 'value'), None)
    assert config_data._global_settings['name'].name == 'name'
    assert config_data._global_settings['name'].value == 'value'
    assert config_data.get_setting('name') is not None


# Generated at 2022-06-24 18:22:26.100102
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()
    config_data_3 = ConfigData()
    config_data_4 = ConfigData()
    config_data_5 = ConfigData()
    config_data_6 = ConfigData()
    config_data_7 = ConfigData()
    config_data_8 = ConfigData()
    config_data_9 = ConfigData()
    config_data_10 = ConfigData()
    config_data_11 = ConfigData()
    config_data_12 = ConfigData()
    config_data_13 = ConfigData()
    config_data_14 = ConfigData()
    config_data_15 = ConfigData()
    config_data_16 = ConfigData()
    config_data_17 = ConfigData()
    config_data_18 = ConfigData()
   

# Generated at 2022-06-24 18:22:31.080427
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    plugin = Plugin('action', 'copy')
    config_data.update_setting(setting, plugin)


# Generated at 2022-06-24 18:22:55.341338
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.update_setting(ConfigSetting()) == None


# Generated at 2022-06-24 18:23:00.726652
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting = Setting('debug', 'bool', False, 'True', None)
    plugin_0 = Plugin('Core', 'Command Line Tool')
    plugins_0 = [plugin_0]
    config_data_0.update_setting(setting, None)
    settings_0 = config_data_0.get_settings(None)
    assert settings_0 == [setting]


# Generated at 2022-06-24 18:23:04.702352
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_0 = ConfigData()
    setting_0 = Setting(name='name', description='description')
    config_data_0.update_setting(setting=setting_0)
    setting = config_data_0.get_setting(name='name')

    assert setting == setting_0


# Generated at 2022-06-24 18:23:09.882606
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Return all the settings if plugin is None
    config_data_0 = ConfigData()
    setting_0 = Setting(None, 'foobar', '/path/to/file')
    config_data_0.update_setting(setting_0)
    result = config_data_0.get_settings()
    assert len(result) == 1
    assert isinstance(result[0], Setting)
    assert result[0].name == 'foobar'


# Generated at 2022-06-24 18:23:11.604896
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting()
    pass

# Generated at 2022-06-24 18:23:16.098664
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting()
    setting_0.name = 'test setting_0'
    config_data_0.update_setting(setting_0)
    setting_1 = config_data_0.get_setting('test setting_0')
    assert setting_1.name == 'test setting_0'


# Generated at 2022-06-24 18:23:21.231889
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    limit = '10'
    setting = ConfigDataSetting('limit', limit)

    config_data.update_setting(setting)

    assert config_data.get_setting('limit') is setting
    assert config_data.get_settings() == [setting]


# Generated at 2022-06-24 18:23:25.389237
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting = config_data_0.get_setting(str)
    if setting is None:
        print('Test passed')
    else:
        print('Test failed')


# Generated at 2022-06-24 18:23:31.252508
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Create object TestConfigData to test get_settings method
    obj_ConfigData = ConfigData()
    obj_ConfigData.update_setting("setting", "plugin")
    obj_ConfigData.get_settings("plugin")


# Generated at 2022-06-24 18:23:35.847045
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Test case 0
    config_data_0 = ConfigData()
    plugin_0 = None
    settings_0 = config_data_0.get_settings(plugin_0)
    assert settings_0 == []


# Generated at 2022-06-24 18:24:15.001741
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test with no args
    test_case_0()


# Generated at 2022-06-24 18:24:23.612673
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_1 = ConfigData()
    config_data_1.update_setting("plugin1")
    config_data_1.update_setting("plugin2")
    config_data_1.update_setting("plugin global")

    assert config_data_1.get_setting("plugin global", None) is not None, "ConfigData get_settings method test 1 failed"
    assert config_data_1.get_setting("plugin2") is not None, "ConfigData get_settings method test 2 failed"
    assert config_data_1.get_setting("plugin1") is not None, "ConfigData get_settings method test 3 failed"
    assert config_data_1.get_setting("plugin4") == None, "ConfigData get_settings method test 4 failed"

# Generated at 2022-06-24 18:24:25.836207
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting, plugin)


# Generated at 2022-06-24 18:24:38.077815
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_1 = ConfigData()
    plugin_1 = Plugin(Plugin.TYPE_CACHE, "test")
    setting_1 = Setting("test", "1")
    config_data_1.update_setting(setting_1)
    config_data_1.update_setting(setting_1, plugin=plugin_1)

    s = config_data_1.get_settings()
    assert len(s) == 1
    assert s[0].name == "test"
    assert s[0].value == "1"

    s = config_data_1.get_settings(plugin=plugin_1)
    assert len(s) == 1
    assert s[0].name == "test"
    assert s[0].value == "1"


# Generated at 2022-06-24 18:24:45.752031
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting("foo", "bar", "baz"))
    config_data_1.get_setting("foo")

    config_data_2 = ConfigData()
    config_data_2.update_setting(Setting("foo", "bar", "baz"), Plugin("foo", "bar"))
    config_data_2.get_setting("foo", Plugin("foo", "bar"))


# Generated at 2022-06-24 18:24:51.266797
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_data_2 = ConfigData()
    config_data_3 = ConfigData()
#Test 1 : Check for Global settings

# Generated at 2022-06-24 18:24:57.000109
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data_1 = ConfigData()
    config_data_1._global_settings = {'setting_g_0': None, 'setting_g_1': None}

    assert config_data_1.get_setting('setting_g_0') is not None
    assert config_data_1.get_setting('setting_g_1') is not None
    assert config_data_1.get_setting('setting_g_2') is None
