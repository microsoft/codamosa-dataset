

# Generated at 2022-06-24 18:15:06.454684
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() is None
    config_data_0._global_settings['plugin_details'] = None
    assert config_data_0.get_settings() is not None
    assert config_data_0.get_settings() == [None] 


# Generated at 2022-06-24 18:15:08.574901
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # test_case_0 setup begin
    # Declare vars
    config_data_0 = ConfigData()
    # test_case_0 setup end
    config_data_0.update_setting(setting=None,plugin=None)
    # test_case_0 execute begin
    
    # test_case_0 execute end


# Generated at 2022-06-24 18:15:10.697584
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(None, None) == None


# Generated at 2022-06-24 18:15:17.526286
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin = Plugin(type="connection", name="winrm")
    setting = Setting(name="transport", value="credssp")
    config_data_0.update_setting(setting, plugin=plugin)
    assert config_data_0.get_settings(plugin=plugin)[0].value == "credssp"



# Generated at 2022-06-24 18:15:21.153826
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # initialize object
    config_data_0 = ConfigData()

    # call method get_settings of class ConfigData with argument config_data_0
    r = ConfigData.get_settings(config_data_0, None)

    # assert if r is empty
    assert not bool(r)



# Generated at 2022-06-24 18:15:26.862170
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('Test', 'This is a test setting', 'boolean', '', True)

    config_data.update_setting(setting)

    assert config_data._global_settings['Test'].type == 'boolean'
    assert config_data._global_settings['Test'].default == True
    assert config_data._global_settings['Test'].description == 'This is a test setting'


# Generated at 2022-06-24 18:15:33.392854
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    settings = [{'name': 'setting_name', 'value': 'setting_value'}]
    config_data_1 = ConfigData()
    config_data_1.update_setting(settings[0])
    assert config_data_1._global_settings['setting_name'].name == 'setting_name'


# Generated at 2022-06-24 18:15:38.477384
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Test with a global setting
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('binary_ansible_callbacks', '/usr/bin/ansible-callbacks'))


# Generated at 2022-06-24 18:15:44.543495
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    assert config_data_1.get_setting("no_setting") is None


# Generated at 2022-06-24 18:15:45.765354
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    assert config_data_1.get_settings() == []


# Generated at 2022-06-24 18:15:50.574389
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Case 0
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:15:58.193645
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.module_utils import basic
    from ansible.module_utils.common.logging import LoggingConfigurator
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.config import Setting, PluginConfig
    from ansible.module_utils.common.config import PluginConfigLoader, Config
    from ansible.module_utils.common.config import PluginLoader, DefaultConfig


# Generated at 2022-06-24 18:15:59.635482
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings(None) == []


# Generated at 2022-06-24 18:16:02.659675
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_get_settings = ConfigData()
    assert config_data_get_settings.get_settings() == []


# Generated at 2022-06-24 18:16:03.459740
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()


# Generated at 2022-06-24 18:16:13.743411
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansiblelint.rules.AnsibleLintRule import AnsibleLintRule
    from ansiblelint.rules.CommandContainsModuleNameRule import CommandContainsModuleNameRule
    from ansiblelint.rules.UseShellInsteadOfCommandRule import UseShellInsteadOfCommandRule
    plugin_type = 'ansible-lint rule'
    plugin_name = 'ANSIBLE0003'
    plugin_0 = AnsibleLintRule(plugin_type, plugin_name, {})
    plugin_1 = CommandContainsModuleNameRule(plugin_type, plugin_name, {})
    plugin_2 = UseShellInsteadOfCommandRule(plugin_type, plugin_name, {})
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []
    assert config_data_0.get_settings

# Generated at 2022-06-24 18:16:22.148440
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin_0 = Plugin('module', 'copy')
    setting_0 = ConfigSetting('ansible_copy_remote_user', 'Ansible remote_user for copy plugin', config_file.CONFIG_FILE_TYPE_INI, 'DEFAULT', 'remote_user')

    config_data_0 = ConfigData()

    config_data_0.update_setting(setting_0)
    setting_1 = config_data_0.get_setting('ansible_copy_remote_user')
    print(setting_0.name)
    print(setting_1.name)



############## Test Cases ###############################################

# Generated at 2022-06-24 18:16:26.678310
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_1 = ConfigData()
    config_data_1.update_setting('setting_1')
    assert config_data_1.get_setting('setting_1') == 'setting_1'

test_ConfigData_update_setting()

# Generated at 2022-06-24 18:16:34.446815
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting(name=None, plugin=None)
    config_data_0.get_setting(name=None, plugin=None)
    config_data_0.get_setting(name=None, plugin=None)
    config_data_0.get_setting(name=None, plugin=None)
    config_data_0.get_setting(name=None, plugin=None)
    config_data_0.get_setting(name=None, plugin=None)
    config_data_0.get_setting(name=None, plugin=None)
    config_data_0.get_setting(name=None, plugin=None)
    config_data_0.get_setting(name=None, plugin=None)
    config_data_0.get

# Generated at 2022-06-24 18:16:37.241823
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert isinstance(config_data_0.get_setting(None), type(None))
    assert config_data_0.get_setting(None) == None
    assert isinstance(config_data_0.get_setting(None, None), type(None))
    assert config_data_0.get_setting(None, None) == None


# Generated at 2022-06-24 18:16:42.401818
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(None)
    assert config_data.get_setting(None) == None



# Generated at 2022-06-24 18:16:44.963770
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting(name='string')


# Generated at 2022-06-24 18:16:53.628325
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Test case #0.
    config_data_0 = ConfigData()

    # Test case #1.
    config_data_1 = ConfigData()
    setting_1 = 'Foo'
    config_data_1.update_setting(setting_1)

    # Test case #2.
    config_data_2 = ConfigData()
    setting_2 = 'Bar'
    plugin_2 = 'Baz'
    config_data_2.update_setting(setting_2, plugin_2)



# Generated at 2022-06-24 18:16:59.389315
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    assert len(config_data_1.get_settings()) == 0

    plugin_0 = Plugin('core', 'core')
    setting_0 = Setting('a', None, None, plugin_0)
    config_data_1.update_setting(setting_0)

    assert len(config_data_1.get_settings()) == 1
    assert config_data_1.get_setting('a', None).name == 'a'

    setting_1 = Setting('b', None, None, plugin_0)
    config_data_1.update_setting(setting_1)

    assert len(config_data_1.get_settings()) == 2
    assert config_data_1.get_setting('a', None).name == 'a'

# Generated at 2022-06-24 18:17:05.552081
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    config_setting_1 = ConfigSetting("setting_0", "setting_value_0")
    config_setting_2 = ConfigSetting("setting_1", "setting_value_1")
    config_data_1.update_setting(config_setting_1)
    config_data_1.update_setting(config_setting_2)

    assert config_data_1.get_settings() == [config_setting_1, config_setting_2]


# Generated at 2022-06-24 18:17:07.326514
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(config_setting_0, plugin_1)



# Generated at 2022-06-24 18:17:09.257033
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global data_0
    data_0 = ConfigData()
    assert data_0.update_setting(None, None) is None


# Generated at 2022-06-24 18:17:19.074010
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansiblelint.rules.PluginRule import PluginRule
    from ansiblelint.rules.SettingRule import SettingRule
    from ansiblelint.rules.PluginRuleType import PluginRuleType
    from ansiblelint.rules.Rule import Rule

    config_data_1 = ConfigData()
    config_data_1.update_setting(SettingRule(Rule.ID('1'), 'setting_1', 'setting_1_value'))
    config_data_1.update_setting(SettingRule(Rule.ID('2'), 'setting_2', 'setting_2_value'))
    config_data_1.update_setting(SettingRule(Rule.ID('3'), 'setting_3', 'setting_3_value'))

# Generated at 2022-06-24 18:17:21.463185
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    assert config_data_1.update_setting is not None


# Generated at 2022-06-24 18:17:28.850105
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_setting = ConfigSetting()
    config_setting.name = "foo"
    config_setting.value = "bar"
    config_setting.origin = "default"
    config_setting.priority = 0
    config_data_0.update_setting(config_setting)
    assert not config_data_0.get_setting("foo").has_parent()


# Generated at 2022-06-24 18:17:37.769812
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting_1 = Setting(name='a', value='b')
    config_data_1.update_setting(setting_1)

    assert config_data_1.get_setting('a') is setting_1



# Generated at 2022-06-24 18:17:40.038185
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting('foo')


# Generated at 2022-06-24 18:17:46.024175
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # initialize ConfigData object
    config_data = ConfigData()

    # create MockSetting object and assign it to global_setting
    mock_setting = MockSetting('setting_1')
    config_data.update_setting(mock_setting)
    # create MockPlugin object and assign the global_setting (should return None)
    mock_plugin = MockPlugin('type_1', 'name_1')
    assert config_data.get_setting('setting_1', mock_plugin) is None
    # test: return global_setting
    assert config_data.get_setting('setting_1') is mock_setting
    # test: return None (setting does not exist)
    assert config_data.get_setting('setting_x') is None

    # create MockSetting object and assign it to a plugin
    mock_setting = MockSetting('setting_2')


# Generated at 2022-06-24 18:17:47.419189
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()

# Generated at 2022-06-24 18:17:49.610632
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:17:57.885526
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansiblelint.rules import Plugin, Setting
    plugin = Plugin('filter', 'lookup')
    setting = Setting('VERBOSE', 'EXIT_ON_ERROR', 'boolean', False, False)
    config_data_1 = ConfigData()
    config_data_1.update_setting(setting, plugin)
    assert len(config_data_1.get_settings()) == 0
    assert len(config_data_1.get_settings(plugin)) == 1


# Generated at 2022-06-24 18:17:59.808335
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print("\nUnit test for method update_setting of class ConfigData\n")



# Generated at 2022-06-24 18:18:02.452481
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting('aoeu')
    config_data_0.get_setting(str_arg='aoeu')


# Generated at 2022-06-24 18:18:04.260764
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_obj = ConfigData()
    config_data_obj.update_setting(setting, plugin)


# Generated at 2022-06-24 18:18:06.795353
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting('name', 'plugin')
    assert config_data_0.get_setting('name', 'plugin') == None


# Generated at 2022-06-24 18:18:12.614956
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting, plugin=None)


# Generated at 2022-06-24 18:18:13.863748
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:18:15.379685
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    """
      Test case for the function get_setting.
    """
    config_data = ConfigData()
#    assert False

# Generated at 2022-06-24 18:18:17.796918
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting()
    plugin_0 = Plugin()
    config_data_0.update_setting(setting_0, plugin_0)


# Generated at 2022-06-24 18:18:25.448037
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('config_file', '/etc/ansible/ansible.cfg')
    plugin_0 = Plugin('None', 'None')
    # Calling update_setting method of ConfigData with arguments setting_0, plugin_0
    config_data_0.update_setting(setting_0, plugin_0)
    # Checking if the settings for plugin_0 are accessed properly
    # add code here to retrieve settings for plugin_0 using config_data_0
    # assert to verify that settings for plugin_0 are retrieved properly
    

# Generated at 2022-06-24 18:18:33.140975
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    plugin_0 = Plugin('my-module', 'mymodule', 'mymodule', Plugin.TYPE_MODULE)
    plugin_1 = Plugin('my-module', 'mymodule', 'mymodule', Plugin.TYPE_MODULE)

    config_data_0.update_setting(Setting('name: mymodule', plugin_0))
    config_data_0.update_setting(Setting('name: mymodule', plugin_1))

    assert config_data_0.get_setting('name: mymodule') == Setting('name: mymodule', plugin_0)


# Generated at 2022-06-24 18:18:37.521705
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    setting_0 = Setting(name='foo', value=1)
    config_data_1.update_setting(setting_0)
    setting_1 = config_data_1.get_setting(name='foo')

    return setting_0 == setting_1


# Generated at 2022-06-24 18:18:50.288476
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = Plugin('ssh', 'connection')
    setting_0 = Setting('ansible_user', 'root', 'ssh', {'key': 'value', 'other_key': 'other_value'})
    config_data_0.update_setting(setting_0, plugin_0)
    setting_1 = Setting('ansible_host', 'localhost', 'ssh', {'key': 'value', 'other_key': 'other_value'})
    config_data_0.update_setting(setting_1, plugin_0)
    setting_2 = Setting('ansible_port', '22', 'ssh', {'key': 'value', 'other_key': 'other_value'})
    config_data_0.update_setting(setting_2, plugin_0)
    actual_param

# Generated at 2022-06-24 18:18:56.242298
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.global_settings = {'key_0': 'value_0', 'key_1': 'value_1'}
    config_data_0.plugins = {'key_0': {'key_0': {'key_0': 'value_0'}, 'key_1': {'key_0': 'value_0'}}, 'key_1': {'key_0': {'key_0': 'value_0'}, 'key_1': {'key_0': 'value_0'}}}
    plugin = {'name': 'name_0', 'type': 'type_0'}
    config_data_0.get_settings(plugin)
    plugin = {'name': 'name_0', 'type': 'type_0'}
    config_data

# Generated at 2022-06-24 18:19:03.642649
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='VERBOSITY', value='1', description=None)
    config_data_0.update_setting(setting=setting_0)
    setting_1 = Setting(name='CONFIGURATION_FILE', value=None, description=None)
    config_data_0.update_setting(setting=setting_1)
    assert(config_data_0.get_setting(name='VERBOSITY') == setting_0)
    assert(config_data_0.get_setting(name='CONFIGURATION_FILE') == setting_1)


# Generated at 2022-06-24 18:19:14.759282
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Arrange
    config_data_0 = ConfigData()
    plugin_0 = Plugin('', '', '', '')

    # Act
    setting = config_data_0.get_setting('', plugin_0)

    # Assert
    assert setting is None


# Generated at 2022-06-24 18:19:17.329021
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting()


# Generated at 2022-06-24 18:19:19.150715
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    config_data_0.get_setting('name', plugin)


# Generated at 2022-06-24 18:19:21.058990
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:19:22.031568
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    a = ConfigData()
    assert a.get_setting() == None


# Generated at 2022-06-24 18:19:29.312950
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """
    # Unit test for method update_setting of class ConfigData
    """
    config_data_0 = ConfigData()
    setting_0_0 = Setting('foo', 'bar', None, None, [])
    plugin_0_0 = Plugin('bar', 'baz', None, 'collections', None, 0, None)
    config_data_0.update_setting(setting_0_0, None)
    config_data_0.update_setting(setting_0_0, plugin_0_0)
    setting_0_1 = Setting('foo', 'baz', None, None, [])
    plugin_0_1 = Plugin()
    config_data_0.update_setting(setting_0_1, plugin_0_1)
    config_data_0.update_setting(setting_0_1)



# Generated at 2022-06-24 18:19:36.784899
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='name_0', value='value_0')
    expected = {'name': 'name_0', 'value': 'value_0'}
    actual = config_data_0.update_setting(setting_0)
    assert actual == expected

    config_data_1 = ConfigData()
    expected = []
    actual = config_data_0.get_settings()
    assert actual == expected

    config_data_2 = ConfigData()
    expected = {}
    actual = config_data_1._global_settings
    assert actual == expected

    config_data_3 = ConfigData()
    setting_1 = Setting(name='name_1', value='value_1')

# Generated at 2022-06-24 18:19:48.350093
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    global_setting = Setting("name0", "/etc/ansible/ansible.cfg", "global", "global", "string", "The hostname or IP address to use as a proxy", "localhost")
    plugin_setting = Setting("name1", "/etc/ansible/ansible.cfg", "default", "command", "string", "A free form string that is used by the /usr/bin/module executor as the executable", "/usr/bin/python")

    config_data_0 = ConfigData()
    config_data_0.update_setting(global_setting)

    assert config_data_0.get_setting("name0") is not None
    assert config_data_0.get_setting("name1") is None
    config_data_0.update_setting(plugin_setting, plugin_setting.plugin)
    assert config_data_

# Generated at 2022-06-24 18:19:52.336214
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Initilise the test data
    config_data_0 = ConfigData()

    # Test method get_setting
    assert config_data_0.get_setting(setting=setting_0, plugin=plugin_0) == None



# Generated at 2022-06-24 18:20:00.764675
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting(name='test_name', value='test_value'), plugin=Plugin(name='test_plugin', type='test_type'))
    config_settings_0 = config_data_0.get_settings(plugin=Plugin(name='test_plugin', type='test_type'))
    # Assertion
    assert config_settings_0[0].name == 'test_name'
    assert config_settings_0[0].value == 'test_value'
    assert config_settings_0[0].plugin is not None


# Generated at 2022-06-24 18:20:11.932977
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting = config_data_0.get_setting(name=None)
    assert setting is None


# Generated at 2022-06-24 18:20:21.948189
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()

    setting_0 = Setting(name='debug')
    config_data_0.update_setting(setting_0)

    assert_equals(config_data_0.get_setting('debug'), setting_0)
    assert_equals(config_data_0.get_settings(), [setting_0])

    plugin_0 = PluginConfig('action', 'local')

    setting_1 = Setting(name='action_plugins', value='local')
    config_data_0.update_setting(setting_1, plugin_0)

    assert_equals(config_data_0.get_setting('action_plugins', plugin_0), setting_1)
    assert_equals(config_data_0.get_settings(plugin_0), [setting_1])


# Generated at 2022-06-24 18:20:24.540874
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:20:26.267347
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    config_data_0.update_setting('Unnamed values')

# Generated at 2022-06-24 18:20:28.237878
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None)
    config_data_0.update_setting(setting=None, plugin=None)


# Generated at 2022-06-24 18:20:39.155600
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None, plugin=Plugin(name='vagrant', type='connection'))
    assert config_data_0.get_settings(plugin=Plugin(name='vagrant', type='connection')) == []
    config_data_0.update_setting(setting=None, plugin=Plugin(name='vagrant', type='connection'))
    assert config_data_0.get_settings(plugin=Plugin(name='vagrant', type='connection')) == []
    config_data_0.update_setting(setting=None, plugin=Plugin(name='vagrant', type='connection'))
    assert config_data_0.get_settings(plugin=Plugin(name='vagrant', type='connection')) == []

# Generated at 2022-06-24 18:20:41.558890
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting = config_data_0.get_setting("name")
    if (setting) is not None:
        assert False


# Generated at 2022-06-24 18:20:42.909783
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:20:44.519050
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:20:47.263417
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()

    assert(config_data_0.get_setting('foo') is None)


# Generated at 2022-06-24 18:21:07.608774
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_setting_0 = ConfigSetting(False, '', 'env', None, '')
    config_data_0.update_setting(config_setting_0)


# Generated at 2022-06-24 18:21:12.166152
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting(ConfigDict0())
    print(config_data_1.get_setting('ansible_connection'))



# Generated at 2022-06-24 18:21:20.210329
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_1 = ConfigData()
    setting_0 = Setting()
    config_data_0.update_setting(setting_0)
    config_data_1.update_setting(setting_0)
    config_data_1.update_setting(setting_0)
    config_data_1.update_setting(setting_0)
    config_data_1.update_setting(setting_0)
    config_data_1._plugins['ssh']['ssh_connection'] = config_data_0._plugins['ssh']['ssh_connection']
    config_data_1._global_settings = config_data_0._global_settings


# Generated at 2022-06-24 18:21:24.298828
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Test case 0
    config_data_0 = ConfigData()
    assert config_data_0.get_setting("foo") is None

    # Test case 1
    config_data_1 = ConfigData()
    assert config_data_1.get_setting("foo") is None


# Generated at 2022-06-24 18:21:27.029651
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cdata = ConfigData()
    cdata.update_setting('test')
    result = cdata.get_setting('test')
    assert result == 'test'


# Generated at 2022-06-24 18:21:37.400544
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = PluginInfo()
    plugin_0.name = "baz"
    plugin_0.type = "foo"
    setting_0 = Setting()
    setting_0.name = "baz"
    setting_0.value = "baz"
    setting_0.plugin = plugin_0
    config_data_0.update_setting(setting_0)
    settings = config_data_0.get_settings(plugin_0)
    assert len(settings) == 1
    assert settings[0].name == setting_0.name
    assert settings[0].value == setting_0.value



# Generated at 2022-06-24 18:21:38.944400
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    assert isinstance(config_data.get_settings(), list)

# Generated at 2022-06-24 18:21:40.620687
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting()


# Generated at 2022-06-24 18:21:45.256890
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()

    config_data_1.update_setting('setting_0', None)
    assert config_data_1._global_settings['setting_0'] == 'setting_0'


# Generated at 2022-06-24 18:21:46.687338
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_case_0()

# Generated at 2022-06-24 18:22:28.496637
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    assert config_data_0._global_settings == {}
    assert config_data_0._plugins == {}
    config_data_0.update_setting(None)
    assert config_data_0._global_settings == {None: None}
    config_data_0.update_setting(None, None)
    assert config_data_0._plugins == {None: {None: {None: None}}}


# Generated at 2022-06-24 18:22:30.261724
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()


# Generated at 2022-06-24 18:22:39.143996
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    # Test with invalid args
    invalid_args = (
        (None,),
        (Setting('a', 'b', 'c'),),
        (Setting('a', 'b', 'c'), Plugin('d', 'e')),
    )
    for args in invalid_args:
        try:
            config_data_0.update_setting(*args)
        except Exception as e:
            print("Failed: update_setting() with args %s, error %s" % (args, e))
    # Test with valid args

# Generated at 2022-06-24 18:22:46.333324
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    from ansible.plugins.action import ActionBase
    plugin = ActionBase('name')
    from ansible.config.setting import Setting
    setting = Setting('name', '')
    config_data.update_setting(setting, plugin)


# Generated at 2022-06-24 18:22:49.770684
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = test_case_0()
    test_setting = config_data_0.get_setting('NotExist')
    assert test_setting is None


# Generated at 2022-06-24 18:22:50.990761
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:22:57.264829
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Create a ConfigData object
    data_0 = ConfigData()
    setting = Setting('ENHANCED_HTTP_API', True, 'boolean')
    data_0.update_setting(setting)
    assert data_0._global_settings['HTTP_API']


# Generated at 2022-06-24 18:23:00.698315
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting)
    assert config_data_0.get_setting(setting.name) == setting
    assert config_data_0.get_setting(setting.name, plugin) == None


# Generated at 2022-06-24 18:23:04.285122
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()

    # This will cause a NameError, as it should.
    try:
        config_data_1.get_setting('test_setting', 'test_plugin')
    except NameError:
        print('PASS')



# Generated at 2022-06-24 18:23:09.666281
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    plugin_0 = PluginDescriptor('foo', 'bar')
    setting_0 = SettingDescriptor('foo_setting', 'foo_value', 'foo_default_value')
    config_data_0.update_setting(setting_0, plugin_0)

    # Load settings from config data
    settings_0 = config_data_0.get_settings(plugin_0)
    assert settings_0
    assert len(settings_0) == 1


# Generated at 2022-06-24 18:24:21.063810
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()


# Generated at 2022-06-24 18:24:22.758037
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:24:24.457146
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    assert config_data_0.get_setting(name=name) == CurrentValue

# Generated at 2022-06-24 18:24:29.496409
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    # Test for function with correct parameters
    assert config_data_0.get_setting(None) is None
    # Test for function with correct parameters
    assert config_data_0.get_setting(None, None) is None


# Generated at 2022-06-24 18:24:32.148256
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting(str()) is None



# Generated at 2022-06-24 18:24:39.198628
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    # Testing with parameters where `plugin` is None
    setting = {"name": "ANSIBLE_JINJA2_NATIVE"}
    config.update_setting(setting, None)
    assert config.get_setting("ANSIBLE_JINJA2_NATIVE", None) == setting
    # Testing with a plugin which is not loaded in the config
    plugin = {"type": "foo", "name": "bar"}
    config.update_setting(setting, plugin)
    assert config.get_settin

# Generated at 2022-06-24 18:24:48.909173
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()

    # Unit test for all Global settings
    for setting in dict(CONFIGURABLE=True, DYNAMIC=True, NAME='Test setting',
                        SOURCE='https://docs.ansible.com/ansible/latest/plugins/configuration_loader.html'):

        if setting == 'CONFIGURABLE':
            config_data_0.update_setting(plugin=None, setting=('CONFIGURABLE', True))
        elif setting == 'DYNAMIC':
            config_data_0.update_setting(plugin=None, setting=('DYNAMIC', True))
        elif setting == 'NAME':
            config_data_0.update_setting(plugin=None, setting=('NAME', 'Test setting'))
        elif setting == 'SOURCE':
            config_data_

# Generated at 2022-06-24 18:24:51.549499
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()
    config_data_0.update_setting(name = "value", name = "value", name = "value")


# Generated at 2022-06-24 18:24:53.522717
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-24 18:24:56.279021
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin = 'aveng'
    plugin = Plugin(plugin)
    config_data_0 = test_case_0()
    config_data_0.get_settings(plugin=plugin)
