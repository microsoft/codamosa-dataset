

# Generated at 2022-06-24 18:15:07.008318
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    #  Testing internal module with google style
    config_data_1 = ConfigData()
    plugin = PluginInfo('plugins', 'shell', 'ShellModule')
    setting = ConfigSetting('namespace', 'default', '')
    config_data_1.update_setting(setting, plugin)
    result = config_data_1.get_settings(plugin)
    assert(result[0].name == 'namespace')
    return True


# Generated at 2022-06-24 18:15:07.529335
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass


# Generated at 2022-06-24 18:15:09.510025
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin(type='',name='',path='',subdir='')
    setting = Setting(name='', value='')
    actual = config_data.update_setting(setting,plugin)
    assert actual == None


# Generated at 2022-06-24 18:15:11.063203
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting()
    assert True

# Generated at 2022-06-24 18:15:14.129339
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting('strvar1') is None


# Generated at 2022-06-24 18:15:21.499930
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting('setting1')
    config_data.update_setting('setting2')
    settings = [i.name for i in config_data.get_settings()]
    assert settings == ['setting1', 'setting2']


# Generated at 2022-06-24 18:15:25.914811
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []
    assert config_data_0.get_settings() == []
    assert config_data_0.get_settings() == []
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:15:34.801268
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    plugin_0 = PluginType()
    name = 'example_setting'
    plugin_0.name = name
    plugin_0.type = 'example_plugin_type'
    setting_0 = Setting()
    setting_0.name = name
    config_data_0.update_setting(setting_0, plugin_0)
    settings = config_data_0.get_setting(setting_0, plugin_0)
    assert settings.name == name


# Generated at 2022-06-24 18:15:42.486105
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin()
    plugin.type = 'action'
    plugin.name = 'fail'
    setting = Setting()
    setting.name = 'msg'
    setting.value = 'Test message'
    config_data.update_setting(setting, plugin)
    result = config_data.get_settings(plugin)
    if result[0] is not setting:
        assert False
    else:
        assert True


# Generated at 2022-06-24 18:15:43.256626
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:15:48.334285
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:15:53.563887
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    config_setting_0 = ConfigSetting(name='conn_host', value='localhost', plugin=None)

    config_data_0.update_setting(setting=config_setting_0)

    assert config_data_0.get_setting(name='conn_host') is not None
    assert config_data_0.get_setting(name='conn_host').get_value() == 'localhost'



# Generated at 2022-06-24 18:15:59.339514
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    settings_0 = config_data_0.get_settings(None)
    settings_1 = config_data_0.get_settings()
    settings_2 = config_data_0.get_settings()
    settings_3 = config_data_0.get_settings()
    assert(settings_3 == settings_2)
    assert(settings_2 == settings_1)
    assert(settings_1 == settings_0)


# Generated at 2022-06-24 18:16:07.032617
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_1_0 = Setting('system_name', 'Test System', SettingType.STRING, 'system name')
    config_data_1.update_setting(setting_1_0)
    setting_1_1 = Setting('system_name', 'Test System', SettingType.STRING, 'system name')
    config_data_1.update_setting(setting_1_1)
    setting_1_2 = Setting('system_name', 'Test System', SettingType.STRING, 'system name')
    config_data_1.update_setting(setting_1_2)


# Generated at 2022-06-24 18:16:09.222815
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    print("get_settings = " + str(config_data_1.get_settings()))


# Generated at 2022-06-24 18:16:19.255184
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Verify that nothing is returned for a non-existent setting.
    assert config_data.get_setting("key") is None
    assert config_data.get_setting("key", plugin="aws") is None

    # Create a global setting and verify that it is returned.
    config_data.update_setting(Setting("key", "value"))
    assert config_data.get_setting("key").name == "key"

    # Create a plugin-specific setting and verify that it is returned.
    config_data.update_setting(Setting("key", "value"), plugin="aws")
    assert config_data.get_setting("key", plugin="aws").name == "key"
    assert config_data.get_setting("key", plugin="gcp") is None



# Generated at 2022-06-24 18:16:22.050000
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    with pytest.raises(Exception):
        config_data_0.get_setting('name')


# Generated at 2022-06-24 18:16:26.258208
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    result_pattern = re.compile('<(.*?)>')
    test_case_0_obj = test_case_0()
    test_case_0_obj.get_setting()
    print('Expected Output:\t<None>')
    print('Actual Output:\t<' + repr(test_case_0_obj.get_setting()) + '>')

# Generated at 2022-06-24 18:16:29.272530
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert config_data_0.get_setting('setting_1') == None


# Generated at 2022-06-24 18:16:37.772861
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Create a new instance of the plugin configuration data
    config_data = ConfigData()

    # Create a new instance of the plugin configuration setting
    setting = ConfigSetting()

    # Set the name of the setting
    setting.name = 'test_string'

    # Set the value of the setting
    setting.value = 'test'

    # Test for method get_setting() without a plugin argument
    mod_setting = config_data.get_setting(setting.name)
    assert not(mod_setting is None)
    assert mod_setting.value == setting.value

    # Test for method get_setting() with a plugin argument
    mod_setting = config_data.get_setting(setting.name, plugin)
    assert not(mod_setting is None)
    assert mod_setting.value == setting.value


# Generated at 2022-06-24 18:16:50.836212
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    print(str(ConfigData.get_setting.__doc__))

    config_data = ConfigData()
    # test the case where there is no setting for the specified plugin
    setting = config_data.get_setting('SOME_SETTING', plugin='SOME_PLUGIN')
    assert setting == None


# Generated at 2022-06-24 18:16:55.583252
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    plugin_0 = Plugin(type='foobar', name='baz')
    setting_0 = Setting(name='some_setting', value='some value', plugin=plugin_0)
    config_data_1.update_setting(setting_0)
    result = config_data_1.get_setting('some_setting', plugin_0)
    if result.name != 'some_setting':
        raise RuntimeError('expected result to be defined, but it was not.')

# Generated at 2022-06-24 18:16:56.883536
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_0 = ConfigData()

    result = config_data_0.get_settings()
    assert result == []



# Generated at 2022-06-24 18:17:04.507701
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()

    fields = {
        'default': None,
        'env': [],
        'ini': [],
        'name': 'ANSIBLE_GATHERING',
        'paths': []
    }

    setting = Setting(fields)

    config_data_0.update_setting(setting)


# Generated at 2022-06-24 18:17:07.958570
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting('setting_1')
    config_data.update_setting('setting_2')

    assert len(config_data.get_settings()) == 2


# Generated at 2022-06-24 18:17:14.040688
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    
    # Test case 0

    config_data_0 = ConfigData()
    config_data_0.update_setting(Setting("test_global_0", "global", "string", "global test value 0"))
    config_data_0.update_setting(Setting("test_global_1", "global", "int", 1))
    config_data_0.update_setting(Setting("test_plugin_0", "core", "string", "core test value 0"))
    config_data_0.update_setting(Setting("test_plugin_1", "core", "int", 2))

    settings_0 = config_data_0.get_settings()
    assert settings_0[0].value == "global test value 0"
    assert settings_0[1].value == 1

# Generated at 2022-06-24 18:17:16.762409
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

    # Test 1:
    # Verify that with no settings global settings are returned
    settings = config_data_0.get_settings()
    assert not settings


# Generated at 2022-06-24 18:17:21.217236
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Test with valid arguments
    global config_data_0
    result_get_settings = config_data_0.get_settings()
    assert len(result_get_settings) == 0


# Generated at 2022-06-24 18:17:23.955781
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting = Settings()
    config_data_0.update_setting(setting)


# Generated at 2022-06-24 18:17:26.340721
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting)
    config_data_0.get_setting(name, plugin)


# Generated at 2022-06-24 18:17:38.526399
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    global_setting_0 = Setting(name='None', value='None')
    plugin_0 = Plugin(type='None', name='None')
    config_data_0.update_setting(setting=global_setting_0)
    config_data_0.update_setting(setting=global_setting_0, plugin=plugin_0)


# Generated at 2022-06-24 18:17:48.978704
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Parameters
    plugins = []
    plugins.append(Plugin('TestPlugin', 'action'))
    plugins.append(Plugin('TestPlugin', 'action'))

    configurations = []
    configurations.append(Config('test_setting_0', 1))
    configurations.append(Config('test_setting_1', 2))

    configurations.append(Config('test_setting_2', 3, plugins[0]))
    configurations.append(Config('test_setting_3', 4, plugins[0]))

    configurations.append(Config('test_setting_4', 5, plugins[1]))
    configurations.append(Config('test_setting_5', 6, plugins[1]))

    config_data = ConfigData()
    for plugin in plugins:
        config_data.update_setting(plugin)

    for configuration in configurations:
        config_data

# Generated at 2022-06-24 18:17:58.588185
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("setting_x")
    assert len(config_data._global_settings) == 1
    assert "setting_x" in config_data._global_settings
    assert config_data._global_settings["setting_x"] == "setting_x"

    config_data.update_setting("setting_x2")
    assert len(config_data._global_settings) == 2
    assert "setting_x2" in config_data._global_settings
    assert config_data._global_settings["setting_x2"] == "setting_x2"


# Generated at 2022-06-24 18:17:59.260268
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass

# Generated at 2022-06-24 18:18:01.537221
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    assert len(config_data_1._global_settings) == 0


# Generated at 2022-06-24 18:18:07.633750
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test case 0
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting=None)
    config_data_0.get_setting(name=None, plugin=None)
    # Test case 1
    config_data_1 = ConfigData()
    config_data_1.update_setting(setting=None)
    config_data_1.get_setting(name=None, plugin=None)



# Generated at 2022-06-24 18:18:10.151352
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting = ConfigSetting()
    config_data_1.update_setting(setting)


# Generated at 2022-06-24 18:18:13.246447
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting = Setting(key="foo", value=None)
    config_data_0.update_setting(setting)
    assert config_data_0.get_setting("foo") == setting


# Generated at 2022-06-24 18:18:14.050835
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass


# Generated at 2022-06-24 18:18:16.600214
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    # ConfigData.update_setting(setting=Setting(name='HELLO', value='world', origin='~/ansible.cfg:5'))
    return

# Generated at 2022-06-24 18:18:29.845835
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()
    from ansible.module_utils.common._collections_compat import Mapping
    assert isinstance(config_data_1.get_settings(), Mapping)



# Generated at 2022-06-24 18:18:30.908591
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass


# Generated at 2022-06-24 18:18:33.059372
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(setting)
    assert config_data.__dict__ == {'_global_settings': {}, '_plugins': {}}

# Generated at 2022-06-24 18:18:35.550293
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    base_setting_0 = BaseSetting()
    config_data_0.update_setting(base_setting_0)
    

# Generated at 2022-06-24 18:18:41.848404
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    setting_0 = FileSetting(filename=FileFinder.get_filename('settings/action_plugins/group_by.py'))
    setting_0.name = 'group_by'
    setting_0.aliases = []
    setting_0.description = 'This plugin allows looping over the result set of a task, using a key to\nuniquely identify items in the result (by default, the `name` key). As results\nare received from the task result callback, they are grouped according to the\nvalue of the key, and then saved in the value of the `item` variable for each\niteration. This is useful for operating on multiple instances of a resource\nwith a single task, for example, stopping multiple EC2 instances.'
    setting_0.choices = None

# Generated at 2022-06-24 18:18:47.531391
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # 0. initialize objects
    config_data_0 = ConfigData()

    # 1. check empty config data
    conf_list = config_data_0.get_settings()
    assert (len(conf_list) == 0), "test_data_0 didn't have any settings"



# Generated at 2022-06-24 18:18:50.588085
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(name="abc")
    assert config_data.get_setting(name="abc") is not None, "Test failed"



# Generated at 2022-06-24 18:18:56.409312
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    print("\n")
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting(name='setting_1', values=[1]))
    config_data_1.update_setting(Setting(name='setting_2', values=[2]))
    config_data_1.update_setting(Setting(name='setting_3', values=[3]))
    config_data_1.update_setting(Setting(name='setting_4', values=[4]))
    config_data_1.update_setting(Setting(name='setting_5', values=[5]))
    config_data_1.update_setting(Setting(name='setting_6', values=[6]))
    setting_1 = config_data_1.get_setting('setting_1')

# Generated at 2022-06-24 18:18:58.085168
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:19:00.759709
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='test_setting_0')
    config_data.update_setting(setting)
    assert config_data._global_settings['test_setting_0'] == setting



# Generated at 2022-06-24 18:19:13.343018
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()


# Generated at 2022-06-24 18:19:21.713353
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Get instance of config_data
    config_data_0 = ConfigData()
    # Get test setting
    setting_0 = Setting(None, 'test', 'test.ini', 'test.ini', 'setting', 'setting', 'setting', 0, True)
    # Update setting
    config_data_0.update_setting(setting_0, None)
    # Check if setting is updated
    assert config_data_0.get_setting('test', None) == setting_0


# Generated at 2022-06-24 18:19:23.203629
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []


# Generated at 2022-06-24 18:19:30.011193
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    # Setting setting0 for plugin (module, name_module)
    setting_0 = Setting(name=name_module, value=None, origin=origin_file)
    config_data_0.update_setting(setting_0, plugin)
    # Setting setting1 for plugin (module, name_module)
    setting_1 = Setting(name=directory_name, value=[value_list_0, value_list_1], origin=origin_file)
    config_data_0.update_setting(setting_1, plugin)
    # Setting setting2 for plugin (module, name_module)
    setting_2 = Setting(name=filename_name, value=value_str_0, origin=origin_file)
    config_data_0.update_setting(setting_2, plugin)
    # Setting

# Generated at 2022-06-24 18:19:32.147047
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.get_settings()



# Generated at 2022-06-24 18:19:35.866286
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Setup
    config_data_0 = ConfigData()

    # Exercise
    # Exercise
    # Verify
    assert config_data_0.get_setting(name=None) == None, "Expected None"


# Generated at 2022-06-24 18:19:47.969380
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    plugin_0 = plugin_type('pdb', 'pdb', 'pdb')
    setting_0 = config_setting(name='my_setting',
                               default='blah',
                               aliases=['bob'],
                               desc='some setting')
    setting_1 = config_setting(name='bob',
                               default='blah',
                               aliases=['my_setting'],
                               desc='some setting')
    config_data_0.update_setting(setting_0, plugin_0)
    config_data_0.update_setting(setting_1, plugin_0)
    actual = config_data_0.get_settings(plugin_0)
    assert actual == [setting_0, setting_1]

# Generated at 2022-06-24 18:19:53.410854
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(setting, plugin=None)
    assert config_data_0.get_setting(setting, plugin=None) == config_data_0.get_setting(setting, plugin=None), 'test_ConfigData_get_setting() failed'


# Generated at 2022-06-24 18:20:01.449906
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
	# Create config_data_1
    config_data_1 = ConfigData()
	# Create setting_2 and setting_3
    setting_2 = Setting(None, "core", True, "ansible.cfg setting in the [defaults] section")
    setting_3 = Setting(None, "inventory", "/usr/local/etc/ansible/hosts", "ansible.cfg setting in the [defaults] section")
	# Add setting_2 and setting_3 to config_data_1
    config_data_1.update_setting(setting_2)
    config_data_1.update_setting(setting_3)


# Generated at 2022-06-24 18:20:10.728608
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_1 = Setting()
    setting_1.name = "TEST_SETTING"
    setting_1.value = "test setting"
    setting_1.plugin = Plugin(name="TEST_PLUGIN", type="MODULE")
    config_data_1.update_setting(setting_1)
    assert setting_1 == config_data_1.get_setting("TEST_SETTING", Plugin(name="TEST_PLUGIN", type="MODULE")), "test_case_1_failed"



# Generated at 2022-06-24 18:20:29.049690
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting(name='name_0', value='value_0')
    config_data_0.update_setting(setting=setting_0)
    setting_1 = Setting(name='name_1', value='value_1')
    plugin_0 = Plugin(type='type_0', name='name_0')
    config_data_0.update_setting(setting=setting_1, plugin=plugin_0)
    assert config_data_0._global_settings['name_0'] == setting_0
    assert config_data_0._plugins['type_0']['name_0']['name_1'] == setting_1


# Generated at 2022-06-24 18:20:34.342665
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    global_setting = GlobalSetting('setting_name')
    config_data.update_setting(global_setting)

if __name__ == '__main__':
    test_case_0()
    test_ConfigData_update_setting()

# Generated at 2022-06-24 18:20:36.241919
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()



# Generated at 2022-06-24 18:20:44.296107
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c_d = ConfigData()
    from ansible.module_utils.common.collections import ImmutableDict
    c_d.update_setting(ImmutableDict({'name': 'default_ipv4_network', 'value': '192.168.1.0/24'}))
    c_d.update_setting(ImmutableDict({'name': 'default_ipv4_address', 'value': '192.168.1.2'}), plugin=ImmutableDict({'name': 'network', 'type': 'module'}))
    c_d.update_setting(ImmutableDict({'name': 'force_ipv4', 'value': 'True'}), plugin=ImmutableDict({'name': 'network', 'type': 'module'}))

# Generated at 2022-06-24 18:20:55.117330
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting('a', '1a'))
    config_data_1.update_setting(Setting('b', '1b'))
    config_data_1.update_setting(Setting('c', '1c'))
    config_data_1.update_setting(Setting('d', '2a'))
    config_data_1.update_setting(Setting('e', '2b'), Plugin('custom', 'c1'))

    assert len(config_data_1.get_settings()) == 3
    assert len(config_data_1.get_settings(Plugin('custom', 'c1'))) == 1
    assert len(config_data_1.get_settings(Plugin('custom', 'not-found'))) == 0


# Generated at 2022-06-24 18:20:58.939447
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("test")


# Generated at 2022-06-24 18:21:05.851308
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # get_setting: no plugins defined
    setting = config_data.get_setting('hostfile')
    assert setting is None

    # get_setting: no plugin defined
    setting = config_data.get_setting('hostfile', plugin=None)
    assert setting is None

    # get_setting: no plugin defined
    setting = config_data.get_setting('hostfile', plugin='foo.bar')
    assert setting is None

    # get_setting: no plugin defined
    setting = config_data.get_setting('hostfile', plugin=object)
    assert setting is None


# Generated at 2022-06-24 18:21:07.568538
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    config_data_0.get_setting(u'name', None)


# Generated at 2022-06-24 18:21:13.509000
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    setting_1 = Setting(name='test_setting')
    config_data_1.update_setting(setting=setting_1, plugin=None)

    assert config_data_1._global_settings['test_setting'] == setting_1


# Generated at 2022-06-24 18:21:15.604444
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    assert config_data_1.get_setting("foo") == None


# Generated at 2022-06-24 18:21:28.599561
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting()
    config_data_0.update_setting(setting_0)
    config_data_0.get_setting(setting_0.name)


# Generated at 2022-06-24 18:21:40.187488
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert cd._global_settings == {}
    assert cd._plugins == {}

    cd.update_setting(Setting(name='a', value='b'))

    assert cd._global_settings == {'a': Setting(name='a', value='b')}
    assert cd._plugins == {}

    cd.update_setting(Setting(name='c', value='d'), Plugin('abc', 'def'))
    assert cd._global_settings == {'a': Setting(name='a', value='b')}
    assert cd._plugins == {'abc': {'def': {'c': Setting(name='c', value='d')}}}

    cd.update_setting(Setting(name='e', value='f'), Plugin('abc', 'ghi'))

# Generated at 2022-06-24 18:21:51.446469
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    global_setting_0 = None
    global_setting_1 = None
    global_setting_2 = None

    plugin_setting_0 = None
    plugin_setting_1 = None
    plugin_setting_2 = None
    plugin_setting_3 = None
    plugin_setting_4 = None
    plugin_setting_5 = None

    assert global_setting_0 is None

    global_setting_0 = config_data.get_setting(name='foo')
    assert global_setting_0 is None

    global_setting_0 = {'name': 'foo', 'value': 'bar'}
    config_data.update_setting(setting=global_setting_0)
    global_setting_1 = config_data.get_setting(name='foo')


# Generated at 2022-06-24 18:21:54.182504
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Init a ConfigData object
    config_data_1 = ConfigData()
    # Get a value with a nonexistent key, check if None is returned
    expected = None
    actual = config_data_1.get_settings()
    assert actual == expected


# Generated at 2022-06-24 18:22:03.513135
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {
        'name': 'gather_subset',
        'plugin_type': None,
        'plugin_name': None,
        'default': "!all",
        'priority': 10,
        'env': [],
        'ini': ["GATHER_SUBSET"],
        'yaml': [],
        'const': [],
        'type': "string",
        'choices': {
            'all': "all",
            'network': "network",
            'hardware': "hardware",
            'facter': "facter",
            'ohai': "ohai",
            'custom': "custom"
        }
    }
    config_data.update_setting(setting)
    assert config_data.get_setting(setting['name']) == setting

# Generated at 2022-06-24 18:22:05.522427
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    assert config_data_0 != None
    config_data_0.update_setting(None)


# Generated at 2022-06-24 18:22:09.273272
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting_0 = Setting(name='name')
    plugin_0 = Plugin(name='name', type='type')
    config_data.update_setting(setting_0, None)
    expected = [setting_0]
    actual = config_data.get_settings()
    assert [expected[i].name for i in range(len(expected))] == [actual[i].name for i in range(len(actual))]


# Generated at 2022-06-24 18:22:11.431197
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()
    config_data_0.get_settings()


# Generated at 2022-06-24 18:22:18.577557
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test case 0
    config_data_0 = ConfigData()
    config_data_0.update_setting(BooleanSetting(False, 'f', 'warg', 'warg'))
    assert config_data_0.get_setting('f') == BooleanSetting(False, 'f', 'warg', 'warg')
    assert config_data_0.get_setting('g') == None

    # Test case 1
    config_data_1 = ConfigData()
    config_data_1.update_setting(IntegerSetting(1, 'g', 'warg', 'warg'))
    config_data_1.update_setting(IntegerSetting(2, 'f', 'warg', 'warg'))

# Generated at 2022-06-24 18:22:29.073199
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    try:
        config_data_0.get_setting("", "")
        assert False
    except ValueError:
        pass

    try:
        config_data_0.get_setting("", None)
        assert False
    except ValueError:
        pass

    try:
        config_data_0.get_setting(None, None)
        assert False
    except ValueError:
        pass

    try:
        config_data_0.get_setting(None, "")
        assert False
    except ValueError:
        pass

    result = config_data_0.get_setting("parsers", None)
    assert result is None

    result = config_data_0.get_setting("", None)
    assert result is None


# Generated at 2022-06-24 18:22:52.111520
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_1 = ConfigData()
    import ansible.plugins.action.normal as action_plugin
    import ansible.plugins.connection.network_cli as connection_plugin
    import ansible.plugins.shell.sh as shell_plugin
    setting1 = None
    plugin1 = action_plugin.ActionModule()
    plugin2 = connection_plugin.Connection()
    plugin3 = shell_plugin.ShellModule()
    assert config_data_1.get_setting(setting1.name, plugin1) == None
    assert config_data_1.get_setting(setting1.name, plugin2) == None
    assert config_data_1.get_setting(setting1.name, plugin3) == None


# Generated at 2022-06-24 18:23:02.814487
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()

# Generated at 2022-06-24 18:23:07.107822
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # case 0
    config_data_0 = ConfigData()
    assert config_data_0.get_settings() == []

    # case 1
    config_data_1 = ConfigData()
    config_data_1.update_setting(Setting())
    assert config_data_1.get_settings() == [Setting()]


# Generated at 2022-06-24 18:23:08.587553
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting()


# Generated at 2022-06-24 18:23:09.850524
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_ConfigData_get_settings_instances()

# Generated at 2022-06-24 18:23:20.126062
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    global_setting_0 = Setting('setting_0', 'value_0', None, None)
    plugin_0 = Plugin('plugin_type_0', 'plugin_0')
    plugin_setting_0 = Setting('setting_0', 'plugin_0_value_0', None, plugin_0)
    plugin_setting_1 = Setting('setting_1', 'plugin_0_value_1', None, plugin_0)
    plugin_1 = Plugin('plugin_type_0', 'plugin_1')
    plugin_setting_2 = Setting('setting_0', 'plugin_1_value_0', None, plugin_1)
    plugin_setting_3 = Setting('setting_1', 'plugin_1_value_1', None, plugin_1)

# Generated at 2022-06-24 18:23:26.557688
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_0 = ConfigData()

# Generated at 2022-06-24 18:23:28.475013
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()


# Generated at 2022-06-24 18:23:32.618285
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data._global_settings == {} and config_data._plugins == {}, "config_data is not empty"


# Generated at 2022-06-24 18:23:40.098461
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    assert config_data_1.get_setting("foo") is None
    setting_1 = Setting("foo", "bar", "baz")
    assert config_data_1.update_setting(setting_1) is None
    assert isinstance(config_data_1.get_setting("foo"), Setting)
    setting_2 = Setting("foo", "bar", "baz", "plugin1", "plugins")
    assert config_data_1.update_setting(setting_2) is None
    assert isinstance(config_data_1.get_setting("foo", Plugin("plugin1", "plugins")), Setting)

# Generated at 2022-06-24 18:23:53.775500
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    assert (config_data_0.get_setting(None) == None)
    assert (config_data_0.get_setting(None, None) == None)



# Generated at 2022-06-24 18:23:56.039456
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_1 = ConfigData()


# Generated at 2022-06-24 18:23:57.676753
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_case_0()

# Generated at 2022-06-24 18:24:03.315829
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_object = None #TODO: Initialize config_data_object
    plugin = None #TODO: Initialize plugin
    setting = None #TODO: Initialize setting
    config_data_object.update_setting(setting, plugin)



# Generated at 2022-06-24 18:24:07.820741
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    instance_0 = Setting('a', 'b')
    config_data_0.update_setting(instance_0)

# Generated at 2022-06-24 18:24:12.707815
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data_0 = ConfigData()
    setting_0 = Setting('foo')
    config_data_0.update_setting(setting_0)
    assert config_data_0.get_setting('foo') == setting_0


# Generated at 2022-06-24 18:24:13.770304
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_0 = ConfigData()
    config_data_0.update_setting(config_data_0)


# Generated at 2022-06-24 18:24:21.748566
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_1 = ConfigSetting(name='setting_1', value='value_1')
    plugin_1 = ConfigPlugin(name='plugin_1', type='type_1')
    config_data.update_setting(setting_1)
    config_data.update_setting(setting_1, plugin_1)
    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings(plugin_1)) == 1
    setting_2 = ConfigSetting(name='setting_2', value='value_2')
    config_data.update_setting(setting_2, plugin_1)
    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings(plugin_1)) == 2

# Generated at 2022-06-24 18:24:29.614394
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_1 = ConfigData()

    from lib.settings import PluginSetting, BooleanSetting, ListSetting
    setting_1 = PluginSetting('foo1', 'bar', 'some_value')
    setting_2 = BooleanSetting('foo2', 'bar', False)
    setting_3 = ListSetting('foo3', 'bar', ['value_1'])
    setting_4 = BooleanSetting('foo4', 'bar', True)
    setting_5 = PluginSetting('foo5', 'bar', 'another_value')

    config_data_1.update_setting(setting_1)
    config_data_1.update_setting(setting_2)
    config_data_1.update_setting(setting_3)
    config_data_1.update_setting(setting_4)

# Generated at 2022-06-24 18:24:33.627900
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting('test', plugin=None)
    assert config_data.get_setting('test', plugin=None) == 'test'


# Generated at 2022-06-24 18:24:53.108778
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_1 = ConfigData()
    config_data_1.update_setting("test", "None")
    config_data_1.update_setting("test")
    config_data_1.update_setting("test", "None")
    config_data_1.update_setting("test")

test_ConfigData_update_setting()

# Generated at 2022-06-24 18:25:03.567868
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Testing invalid value passed for argument setting
    config_data_0 = ConfigData()
    assert type(config_data_0) == ConfigData, "config_data_0 is not an instance of class ConfigData"

    config_data_0.update_setting(None)
    assert config_data_0._global_settings == {None}, "config_data_0._global_settings is not equal to {None}"

    # Testing invalid value passed for argument plugin
    config_data_0.update_setting("Non-None")
    assert config_data_0._global_settings == {"Non-None"}, "config_data_0._global_settings is not equal to {'Non-None'}"

    # Testing valid values passed for argument setting and plugin
    config_data_0.update_setting("setting", "plugin")
    assert config_data_0