

# Generated at 2022-06-20 13:33:15.018144
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    data.update_setting(ConfigSetting('context_path','/zabbix'))


# Generated at 2022-06-20 13:33:20.258016
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting(None) is None
    assert config_data.get_setting('') is None
    assert config_data.get_setting('invalid_setting') is None
    assert config_data.get_setting('default_key_value', plugin=None) is None


# Generated at 2022-06-20 13:33:28.492116
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    plugin_type = 'test'
    plugin_name = 'unit_test'

    # test with non existent plugin type
    setting = config_data.get_setting('test')
    assert setting is None

    # test with non existent plugin name
    setting = config_data.get_setting('test', Plugin(plugin_type, plugin_name))
    assert setting is None

    # test with non existent setting name
    config_data.update_setting(Setting('test'))
    setting = config_data.get_setting('non_exist_setting')
    assert setting is None

    # test with valid plugin type and name
    setting = Setting('test')
    config_data.update_setting(setting, Plugin(plugin_type, plugin_name))

# Generated at 2022-06-20 13:33:33.349037
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    assert True

# Generated at 2022-06-20 13:33:37.895939
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin(PluginType.CORE, 'core')
    config_data.update_setting(
        Setting(SettingName.INVENTORY, 'inventory', True, False, plugin.type, plugin.name))
    config_data.update_setting(Setting(SettingName.RETRY_FILES_ENABLED,
                                       'retry_files_enabled', True, True))
    settings = config_data.get_settings()
    assert len(settings) == 2
    settings = config_data.get_settings(plugin)
    assert len(settings) == 1

# Generated at 2022-06-20 13:33:40.614090
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert (config is not None)


# Generated at 2022-06-20 13:33:48.372829
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from plugins.module_utils.connection._winrm_common import ConfigSetting

    config = ConfigData()
    config.update_setting(ConfigSetting('transport', 'env:path'))
    config.update_setting(ConfigSetting('trusted_hosts', 'env:path'))
    config.update_setting(ConfigSetting('host', 'env:path'))
    config.update_setting(ConfigSetting('port', 'env:path'))
    config.update_setting(ConfigSetting('username', 'env:path'))
    config.update_setting(ConfigSetting('password', 'env:path'))

    settings = config.get_settings()
    assert len(settings) == 6
    assert 'transport' in [setting.name for setting in settings]
    assert 'trusted_hosts' in [setting.name for setting in settings]

# Generated at 2022-06-20 13:33:50.453001
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting('module_name')

# Generated at 2022-06-20 13:34:01.130753
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import sys
    import inspect

    plugin = None

    configdata = ConfigData()

    setting1 = Setting(name="value1")
    setting2 = Setting(name="value2")
    configdata.update_setting(setting1)
    configdata.update_setting(setting2)
    assert configdata.get_settings() == [setting1, setting2], "get_settings() is not working correctly"

    setting3 = Setting(name="value3")
    setting4 = Setting(name="value4")
    configdata.update_setting(setting3, plugin=plugin)
    configdata.update_setting(setting4, plugin=plugin)
    assert configdata.get_settings(plugin=plugin) == [setting3, setting4], "get_settings() is not working correctly"


# Generated at 2022-06-20 13:34:03.928868
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert cd.update_setting == 'function'

# Generated at 2022-06-20 13:34:08.434205
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-20 13:34:11.105411
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()


# Generated at 2022-06-20 13:34:19.740678
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    p = ConfigData()
    s1 = ConfigSetting("A", "B", "C")
    p.update_setting(s1)
    s2 = ConfigSetting("D", "B", "C")
    s3 = ConfigSetting("A", "E", "C")
    p.update_setting(s2)
    p.update_setting(s3)
    s4 = ConfigSetting("A", "B", "F")
    p.update_setting(s4)
    if (p.get_setting("A") is None):
        print("Setting 'A' is not found")
    elif (p.get_setting("D") is not None):
        print("Setting 'D'is found")

# Generated at 2022-06-20 13:34:30.877162
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Test case: global setting
    config_data = ConfigData()
    config_data.update_setting(Setting('setting_A', 'hello'))

    setting = config_data.get_setting('setting_A')
    assert setting is not None
    assert setting.name == 'setting_A'
    assert setting.value == 'hello'

    # Test case: global setting not found
    setting = config_data.get_setting('not_exist')
    assert setting is None

    # Test case: plugin setting
    from ansible.plugins.loader import plugin_loader

    plugin = plugin_loader.get('vars', 'my_plugin')
    config_data.update_setting(Setting('setting_B', 'world', plugin))

    setting = config_data.get_setting('setting_B', plugin)
    assert setting is not None


# Generated at 2022-06-20 13:34:31.975969
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()
    assert configData.get_settings() == []

if __name__ == '__main__':
    test_ConfigData_get_settings()

# Generated at 2022-06-20 13:34:42.407957
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Create a valid configuration data
    config_data = ConfigData()
    config_data.update_setting(GlobalSettings(name="config_file", value="/etc/ansible/ansible.cfg"))
    config_data.update_setting(GlobalSettings(name="inventory", value="/etc/ansible/hosts"))

    # Check the valid configuration
    assert config_data.get_setting(name="config_file").value == "/etc/ansible/ansible.cfg"
    assert len(config_data.get_settings()) == 2

    # Create a plugin
    plugin = Plugin(type="lookup", name="first")

    # Check the invalid configuration
    assert config_data.get_setting(name="config_file", plugin=plugin) is None
    assert len(config_data.get_settings(plugin=plugin)) == 0

    #

# Generated at 2022-06-20 13:34:53.214117
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.plugins import module_loader
    from ansible.module_utils.six import iteritems
    from ansible.config.module_docs import read_docstring

    config_data = ConfigData()

    # First, try to get non-existing setting from non-existent plugin
    unknown_plugin = module_loader._create_plugin_from_name('unknown_plugin', 'action')
    unknown_setting = config_data.get_setting('invalid_setting', unknown_plugin)
    assert unknown_setting is None

    # Get settings for normal plugins
    for plugin in module_loader.all():

        if not plugin.documentation:
            docstring = read_docstring(plugin._original_path, verbose=False, ignore_errors=True)
            plugin.documentation = docstring

        # plugin._module is the actual module that was imported

# Generated at 2022-06-20 13:35:03.600547
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    foo_setting = Setting('foo', 'bar')
    config_data.update_setting(foo_setting)

    plugin_1 = Plugin('p1', 'plugin1', 'p_module')
    plugin_2 = Plugin('p2', 'plugin2', 'p_module')

    p1_setting = Setting('p1_setting', 'bar')
    config_data.update_setting(p1_setting, plugin=plugin_1)
    p2_setting = Setting('p2_setting', 'bar')
    config_data.update_setting(p2_setting, plugin=plugin_2)

    assert config_data.get_settings() == [foo_setting]
    assert config_data.get_settings(plugin_1) == [p1_setting]

# Generated at 2022-06-20 13:35:05.980616
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:35:07.195516
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd is not None


# Generated at 2022-06-20 13:35:14.041928
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:35:22.935003
# Unit test for constructor of class ConfigData
def test_ConfigData():
    gs = GlobalSetting(name='INVENTORY',value='/opt/ansible/inventory')
    md = ModuleData(name='my-hosts',plugin='inventory_plugin',settings=[gs])
    cd = ConfigData()
    cd.update_setting(gs,plugin=None)
    assert len(cd.get_settings(plugin=None)) == 1
    cd.update_setting(gs,md)
    assert len(cd.get_settings(md)) == 2
    assert len(cd.get_settings()) == 3


# Generated at 2022-06-20 13:35:29.780556
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_path = "./"
    config_file = "ansible.cfg"
    config_parser = ConfigParser(config_data, config_path, config_file)
    config_data = config_parser.parse_config_file()
    for setting in config_data.get_settings():
        if setting.name == "callback_whitelist":
            assert setting.value == "profile_tasks"


# Generated at 2022-06-20 13:35:32.481975
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('foo'))
    assert config_data.get_setting('foo') is not None


# Generated at 2022-06-20 13:35:37.960857
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    conf_data = ConfigData()
    setting = Setting('foo', 'bar')
    conf_data.update_setting(setting)
    assert conf_data.get_setting('foo') == setting



# Generated at 2022-06-20 13:35:48.729578
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('ansible_connection', 'smart','short_description','description','ini','ini','ini','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''))
    assert config_data.get_setting(name='ansible_connection').name == 'ansible_connection'
    assert config_data.get_setting(name='ansible_connection').value == 'smart'
    assert config_data.get_setting(name='ansible_connection').ini == 'ini'



# Generated at 2022-06-20 13:35:56.142702
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import plugin_loader

    cfg_data = ConfigData()
    cfg_data.update_setting(Setting('group_name', {'default': 'all'}))
    cfg_data.update_setting(Setting('inventory', {'default': '/etc/ansible/hosts'}))
    cfg_data.update_setting(Setting('test_setting1', {'default': 'test', 'env': 'test_env_var'}, plugin_loader.get('inventory', 'host_list')))
    cfg_data.update_setting(Setting('test_setting2', {'default': 'test', 'env': 'test_env_var'}, plugin_loader.get('inventory', 'host_list')))

    global_settings = cfg_data.get_settings()

# Generated at 2022-06-20 13:36:08.065255
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(setting=Setting(name='test_setting_1', value=1, scope='global'))
    config_data.update_setting(plugin=Plugin(name='test_plugin_1', type='test_type_1'), setting=Setting(name='test_setting_2', value=2))
    assert config_data.get_setting(name='test_setting_1') == Setting(name='test_setting_1', value=1, scope='global')

# Generated at 2022-06-20 13:36:09.370815
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()
    assert configData.get_settings() == []


# Generated at 2022-06-20 13:36:13.236100
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config



# Generated at 2022-06-20 13:36:30.323532
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    data1 = {"name": "test1", "value": "value1", "origin": "test", "type": "test1"}
    data2 = {"name": "test2", "value": "value2", "origin": "test", "type": "test2"}
    data3 = {"name": "test3", "value": "value3", "origin": "test", "type": "test3"}
    data4 = {"name": "test4", "value": "value4", "origin": "test", "type": "test4"}
    data5 = {"name": "test5", "value": "value5", "origin": "test", "type": "test5"}
    data6 = {"name": "test6", "value": "value6", "origin": "test", "type": "test6"}


# Generated at 2022-06-20 13:36:31.702017
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = Plugin('role', 'test')
    setting = Setting('test', 'test')
    config_data.update_setting(setting, plugin=plugin)
    assert config_data.get_setting('test', plugin) == setting


# Generated at 2022-06-20 13:36:34.462638
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-20 13:36:37.682390
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None
    assert isinstance(config_data, ConfigData)

test_ConfigData()


# Generated at 2022-06-20 13:36:45.443462
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test 1
    setting = config_data.get_setting('display_skipped_hosts')
    assert setting.name == 'display_skipped_hosts'
    assert setting.value is True

    # Test 2
    setting = config_data.get_setting('display_skipped_hosts', 'blah')
    assert setting is None

    # Test 3
    setting = config_data.get_setting('display_skipped_hosts', 'core')
    assert setting is None

    # Test 4
    setting = config_data.get_setting('display_skipped_hosts', 'callback')
    assert setting is None

    # Test 5
    setting = config_data.get_setting('display_skipped_hosts', 'strategy')
    assert setting is None

    # Test

# Generated at 2022-06-20 13:36:52.377841
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    cfgdata = ConfigData()

    # Test a global setting
    global_setting = Setting('global_setting')
    cfgdata.update_setting(global_setting)
    assert len(cfgdata.get_settings()) == 1
    assert cfgdata.get_settings()[0].name == 'global_setting'

    # Test a plugin setting
    plugin_setting = Setting('plugin_setting')
    cfgdata.update_setting(plugin_setting, Plugin('plugin_type', 'plugin_name'))
    assert len(cfgdata.get_settings()) == 1
    assert len(cfgdata.get_settings(Plugin('plugin_type', 'plugin_name'))) == 1
    assert cfgdata.get_settings(Plugin('plugin_type', 'plugin_name'))[0].name == 'plugin_setting'

    # Test multiple

# Generated at 2022-06-20 13:36:54.208350
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data.get_settings() == []

# Generated at 2022-06-20 13:36:56.243436
# Unit test for constructor of class ConfigData
def test_ConfigData():
    conf = ConfigData()

    return conf


# Generated at 2022-06-20 13:36:58.758897
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:37:01.990526
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(Setting('foo', 'foo_value'))
    assert config.get_setting('foo') == Setting('foo', 'foo_value')


# Generated at 2022-06-20 13:37:20.727868
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()
    # empty configdata
    assert len(configdata.get_settings()) == 0

    # Set a global setting and test
    plugin = "global"
    name = "deprecation_warnings"
    value = "false"
    setting = Setting(plugin, name, value)
    configdata.update_setting(setting)
    assert len(configdata.get_settings()) == 1
    assert len(configdata.get_settings()) == 1
    assert configdata.get_setting(name, plugin) == setting

    # Add a connection setting and test
    plugin = "connection"
    name = "host"
    value = "127.0.0.1"
    setting = Setting(plugin, name, value)
    configdata.update_setting(setting)

# Generated at 2022-06-20 13:37:27.034373
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from yaml import YAMLObject, YAMLObjectMetaclass
    from types import MethodType
    from ansible.utils.vars import combine_vars

    class Core(YAMLObject):

        yaml_tag = u'!Core'

        def __init__(self, host):
            self.name = 'core'
            self.host = host

# Generated at 2022-06-20 13:37:34.181946
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('one'), plugin=Plugin('one', 'type'))
    assert config_data.get_setting('one') is None    
    assert config_data.get_setting('one', plugin=Plugin('one', 'type')) is not None    
    

# Generated at 2022-06-20 13:37:46.385691
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('string_setting') is None
    assert config_data.get_setting('string_setting', plugin = Plugin(type='connection', name='connection_name')) is None
    assert config_data.get_setting('string_setting', plugin = Plugin(type='shell', name='shell_name')) is None
    config_data.update_setting(Setting(type='string', name='string_setting'))
    assert config_data.get_setting('string_setting') is not None
    assert config_data.get_setting('string_setting', plugin = Plugin(type='connection', name='connection_name')) is None
    assert config_data.get_setting('string_setting', plugin = Plugin(type='shell', name='shell_name')) is None
    config_data

# Generated at 2022-06-20 13:37:55.301701
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    # test1: set setting for global plugin
    setting1 = ConfigSetting("foo")
    setting2 = ConfigSetting("bar", value="baz")
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    assert config_data.get_setting("foo") == setting1
    assert config_data.get_setting("bar") == setting2

    # test2: set setting for named plugin
    plugin1 = ConfigPlugin("foo", PluginType.CACHE)
    setting3 = ConfigSetting("foo")
    setting4 = ConfigSetting("bar", value="baz")
    config_data.update_setting(setting3, plugin=plugin1)
    config_data.update_setting(setting4, plugin=plugin1)
    assert config_data.get

# Generated at 2022-06-20 13:38:06.250236
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class Plugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class Setting(dict):
        def __init__(self, name, value):
            self.name = name
            self["value"] = value

    config_data = ConfigData()

    plugin1 = Plugin("connection", "default")

    plugin_setting = Setting("host", "example.com")
    config_data.update_setting(plugin_setting, plugin=plugin1)
    assert config_data.get_setting("host", plugin=plugin1) is plugin_setting

    plugin_setting = Setting("port", "22")
    config_data.update_setting(plugin_setting, plugin=plugin1)
    assert config_data.get_setting("port", plugin=plugin1) is plugin_setting

   

# Generated at 2022-06-20 13:38:18.728287
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    type_string = "type"
    name_string = "name"
    setting_name = "setting"
    value_string = "value"
    setting = Setting(setting_name, value_string)
    # add a global setting
    config_data.update_setting(setting)
    assert config_data.get_setting(setting_name) is not None, "ConfigData is broken"
    # add a plugin setting
    plugin = Plugin(type_string, name_string)
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting(setting_name, plugin) is not None, "ConfigData is broken"


# Generated at 2022-06-20 13:38:26.840562
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()

    # test data
    plugin_type = 'mytype'
    plugin_name = 'myname'
    setting_name = 'mysetting'
    setting_value = 1

    # test add/get of global setting
    global_setting = Setting(setting_name, setting_value)
    config.update_setting(global_setting)

    setting = config.get_setting(setting_name)
    assert setting is not None
    assert setting == global_setting

    # test add/get of plugin setting
    plugin_setting = Setting(setting_name, setting_value, plugin_type, plugin_name)
    config.update_setting(plugin_setting)

    setting = config.get_setting(setting_name, plugin_setting)
    assert setting is not None
    assert setting == plugin_setting

    # test getting

# Generated at 2022-06-20 13:38:39.068673
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class Plugin:

        def __init__(self, type, name):
            self.type = type
            self.name = name

    class Setting:

        def __init__(self, name):
            self.name = name

    config_data = ConfigData()

    config_data.update_setting(Setting('setting1'))
    config_data.update_setting(Setting('setting2'))

    config_data.update_setting(Setting('setting3'), Plugin('type1', 'name1'))
    config_data.update_setting(Setting('setting4'), Plugin('type1', 'name1'))

    assert(len(config_data.get_settings()) == 2)
    assert(len(config_data.get_settings(Plugin('type1', 'name1'))) == 2)

# Generated at 2022-06-20 13:38:40.254336
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert hasattr(ConfigData, '__init__')


# Generated at 2022-06-20 13:39:05.346975
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    config_data.update_setting('setting1')
    assert len(config_data._global_setting) == 1

    config_data.update_setting('setting2')
    assert len(config_data._global_setting) == 2


# Generated at 2022-06-20 13:39:15.829863
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('foo_global', 'baz_global', 'bar_global'))
    config_data.update_setting(Setting('foo', 'baz', 'bar'), Plugin('foo', 'bar'))

    assert config_data.get_setting('foo_global').value == 'baz_global'
    assert config_data.get_setting('foo_global').description == 'bar_global'
    assert config_data.get_setting('foo_global', Plugin('foo', 'bar')).value == 'baz_global'
    assert config_data.get_setting('foo_global', Plugin('foo', 'bar')).description == 'bar_global'

    assert config_data.get_setting('foo').value == 'baz'
    assert config_data.get_

# Generated at 2022-06-20 13:39:23.472421
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    from ansible_collections.community.general.plugins.modules.cloud import azure_rm_storageaccount
    config_data.update_setting(azure_rm_storageaccount.AzureRMStorageAccount.account_kind)
    from ansible_collections.community.general.plugins.modules.cloud import azure_rm_deployment
    config_data.update_setting(azure_rm_deployment.AzureRMDeployment.resource_group_name)

    # test get_setting
    assert config_data.get_setting('account_kind') is not None
    assert config_data.get_setting('resource_group_name') is not None

    # test get_settings
    assert len(config_data.get_settings()) == 2

# Generated at 2022-06-20 13:39:26.195273
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader

    # Arrange
    config_data = ConfigData()

    # Act
    plugins = PluginLoader.all()

    # Assert
    for plugin in plugins:
        assert config_data.get_settings(plugin) == []

# Generated at 2022-06-20 13:39:34.421017
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    setting = Setting('api_url', 'https://www.example.com', 'global')
    config_data.update_setting(setting)

    plugin = Plugin()
    plugin.type = 'action'
    plugin.name = 'foo'
    setting = Setting('api_url', 'https://www.example.com/action', 'plugin')
    config_data.update_setting(setting, plugin)

    settings = config_data.get_settings()
    assert len(settings) == 1
    assert settings[0].name == 'api_url'
    assert settings[0].value == 'https://www.example.com'
    assert settings[0].scope == 'global'

    settings = config_data.get_settings(plugin)
    assert len(settings) == 1

# Generated at 2022-06-20 13:39:41.774027
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    setting = Setting("setting1")
    data.update_setting(setting, Plugin(None, "plugin1"))
    plugin = Plugin(None, "plugin1")
    assert len(data.get_settings(plugin)) > 0, "Get settings of plugin success"
    assert data.get_settings(plugin)[0].name == "setting1", "Get settings of plugin success"


# Generated at 2022-06-20 13:39:43.852064
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test = ConfigData()
    assert test.get_setting("test") == None


# Generated at 2022-06-20 13:39:49.166952
# Unit test for constructor of class ConfigData
def test_ConfigData():
    # Create a config object
    config = ConfigData()

    assert isinstance(config, ConfigData)

    # Verify the instance is of class ConfigData
    assert isinstance(config, ConfigData)

    # Verify the object is empty
    assert config.get_settings() == []

    # Add a setting, verify it exists
    setting = Setting('name', 'value')
    config.update_setting(setting)
    assert config.get_settings() != []


# Generated at 2022-06-20 13:39:54.918400
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    configdata = ConfigData()
    settings = configdata.get_settings()
    assert len(settings) == 0


# Generated at 2022-06-20 13:39:56.844486
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    assert data.get_setting('foo') == None


# Generated at 2022-06-20 13:40:43.607808
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    
    from ansible.parsing import vault
    from ansible.config.setting_parser import SettingParser
    
    data = ConfigData()

    module_options = {}
    module_options['one'] = SettingParser(name='one', default=1)
    module_options['two'] = SettingParser(name='two', default=2)

    plugin_options = {}
    plugin_options['three'] = SettingParser(name='three', default=3)
    plugin_options['four'] = SettingParser(name='four', default=4)

    one = module_options['one']
    two = module_options['two']
    three = plugin_options['three']
    four = plugin_options['four']

    # Test case - global level settings
    data.update_setting(one)
    data.update_setting(two)



# Generated at 2022-06-20 13:40:45.364136
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_setting()) == 0


# Generated at 2022-06-20 13:40:58.146740
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    cd = ConfigData()

    assert not cd.get_settings(plugin=None)

    assert not cd.get_settings(plugin=object())

    class TestPlugin1:

        def __init__(self):
            self.TYPE = 'test'
            self.NAME = 'plugin1'

    plugin1 = TestPlugin1()

    assert not cd.get_settings(plugin=plugin1)

    from ansible.plugins.setting import Setting
    from ansible.plugins.loader import find_plugin_file

    class TestSetting1(Setting):
        def __init__(self):
            super(TestSetting1, self).__init__('SETTING1', (str, int,), 'SETTING1 default', find_plugin_file(plugin1.TYPE, plugin1.NAME))

    setting1 = TestSetting1()

    cd.update_setting

# Generated at 2022-06-20 13:41:08.367868
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins import AnsiblePlugin

    class TestPlugin(AnsiblePlugin):

        def __init__(self):
            self.name = 'test_plugin'
            self.type = 'test'

    config_data = ConfigData()
    plugin = TestPlugin()
    config_data.update_setting('a', plugin)
    config_data.update_setting('b', plugin)

    assert config_data.get_settings(plugin) == ['a', 'b']
    assert config_data.get_settings() == []

# Generated at 2022-06-20 13:41:09.784401
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data



# Generated at 2022-06-20 13:41:12.681009
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-20 13:41:14.992807
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("name", "value"))
    assert config_data.get_setting("name") == Setting("name", "value")


# Generated at 2022-06-20 13:41:20.495504
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test invalid case
    configData = ConfigData()
    setting = configData.get_setting("setting")
    assert setting is None

    # Test global setting
    configData = ConfigData()
    configData.update_setting(Setting("setting", "a_value"))
    setting = configData.get_setting("setting")
    assert setting is not None
    assert setting.name == "setting"
    assert setting.value == "a_value"

    # Test plugin setting
    configData = ConfigData()
    configData.update_setting(Setting("setting", "a_value"), Plugin("my_type", "my_name"))
    setting = configData.get_setting("setting", Plugin("my_type", "my_name"))
    assert setting is not None
    assert setting.name == "setting"

# Generated at 2022-06-20 13:41:24.958687
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    setting1 = Setting('setting1', 'global')
    config_data.update_setting(setting1)

    setting2 = Setting('setting2', 'global')
    config_data.update_setting(setting2)

    assert config_data.get_setting('setting1') == setting1
    assert config_data.get_setting('setting2') == setting2
    assert config_data.get_setting('setting3') == None


# Generated at 2022-06-20 13:41:35.744490
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible_collections.testns.testcoll.plugins.module_utils.test_utils import (
        PluginUtilsTestCase,
    )
    from ansible_collections.testns.testcoll.plugins.module_utils.test_utils import (
        TestSetting,
        TestPlugin,
    )

    plugin_utils_test_case = PluginUtilsTestCase()
    config_data = ConfigData()

    def _get_setting(name):
        return TestSetting(name=name, value=name)

    def _get_settings():
        return [_get_setting(n) for n in ['test1', 'test2', 'test3']]

    #  get_settings -- empty config_data
    plugin_utils_test_case.assert_equal(config_data.get_settings(), [])

    # 

# Generated at 2022-06-20 13:42:15.092232
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config



# Generated at 2022-06-20 13:42:18.468450
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    assert config_data.get_setting("test-setting") is None
    assert config_data.get_setting("test-setting", "test-plugin") is None


# Generated at 2022-06-20 13:42:23.732549
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = Setting('ansible_python_interpreter', '/usr/bin/python')
    config_data.update_setting(setting)
    setting = Setting('ansible_connection', 'local')
    config_data.update_setting(setting, 'connection', 'local')
    assert config_data.get_setting('ansible_python_interpreter') == setting
    assert config_data.get_setting('ansible_connection', 'connection', 'local') == setting



# Generated at 2022-06-20 13:42:35.293393
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings_data = ConfigData()
    plugin_name = "name"
    plugin_type = "module"
    setting_1 = Setting("name_1", "value_1", "module", "initial value")
    setting_2 = Setting("name_2", "value_2", "module", "initial value")
    settings_data.update_setting(setting_1, PluginFactory.create(plugin_name, plugin_type))
    settings_data.update_setting(setting_2, PluginFactory.create(plugin_name, plugin_type))

    settings = settings_data.get_settings(PluginFactory.create(plugin_name, plugin_type))

    assert settings[0] == setting_1
    assert settings[1] == setting_2


# Generated at 2022-06-20 13:42:36.736190
# Unit test for constructor of class ConfigData
def test_ConfigData():

    assert ConfigData

# Generated at 2022-06-20 13:42:38.577329
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    assert data.get_setting('ansible_connection') == None


# Generated at 2022-06-20 13:42:46.449468
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    s = Setting()
    c.update_setting(s)
    assert c._global_settings[s.name] == s
    assert c._global_settings.get(s.name) == s
    assert c.get_setting(s.name) == s
    assert c.get_settings() == [s]
    assert c.get_settings(s) == [s]


# Generated at 2022-06-20 13:42:57.749582
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()

    ## Valid plugin with valid name and valid setting
    setting = {
        'name': 'auth_type',
        'value': 'basic',
        'plugin': {
            'type': 'inventory',
            'name': 'azure'
        }
    }
    config.update_setting(setting)
    assert config._plugins['inventory']['azure']['auth_type'] == setting

    ## Invalid plugin with valid name and valid setting
    setting = {
        'name': 'auth_type',
        'value': 'basic',
        'plugin': {
            'type': 'inventory1',
            'name': 'azure'
        }
    }
    config.update_setting(setting)
    assert 'inventory1' not in config._plugins

    ## Valid plugin with invalid name and valid setting


# Generated at 2022-06-20 13:43:08.729411
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from units.mock.loader import DictDataLoader

    data = ConfigData()

    data_loader = DictDataLoader({'ANSIBLE_STDOUT_CALLBACK': 'json'})
    data.update_setting(data_loader.get_setting('ANSIBLE_STDOUT_CALLBACK'))

    data_loader = DictDataLoader({'plugin_test_test': 'test'})
    data.update_setting(data_loader.get_setting('plugin_test_test', dict(type='test', name='test')))

    assert data.get_setting('ANSIBLE_STDOUT_CALLBACK')
    assert data.get_setting('plugin_test_test', dict(type='test', name='test'))
