

# Generated at 2022-06-20 13:33:16.760314
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    setting = {}
    setting['name'] = 'key_1'
    setting['value'] = 'value_1'
    plugin = {}
    plugin['type'] = 'cache'
    plugin['name'] = 'redis'
    configData.update_setting(configData,plugin)
    assert configData


# Generated at 2022-06-20 13:33:23.153243
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    configData = ConfigData()
    setting = Setting("foo", "bar")
    configData.update_setting(setting)

    assert configData.get_setting("foo") == setting
    assert configData.get_setting("blah") == None


# Generated at 2022-06-20 13:33:29.530019
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Create a config data instance
    config_data = ConfigData()

    # Create some settings and check if they are not found
    assert config_data.get_setting('setting1') is None
    assert config_data.get_setting('setting1', plugin=__import__('ansible.plugins.callback').CallbackModule.Plugin()) is None

    # Create a setting and update the config data with that setting
    plugin = __import__('ansible.plugins.callback').CallbackModule.Plugin()
    setting = __import__('ansible.config.setting').Setting('setting1')
    config_data.update_setting(setting, plugin=plugin)

    # Check if the setting is found in the config data
    assert setting == config_data.get_setting('setting1', plugin=plugin)



# Generated at 2022-06-20 13:33:33.762429
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = config_data._global_settings.get("lookup_plugins")
    print("setting: %s" % setting)


# Generated at 2022-06-20 13:33:38.081317
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()

    config.update_setting(ConfigSetting('async_dir', '~/.ansible/job'))
    config.update_setting(ConfigSetting('log_path', '/path/log/file'))

    assert config.get_setting('log_path') == '/path/log/file'
    assert config.get_setting('async_dir') == '~/.ansible/job'

    assert config.get_setting('log_path', Plugin('connection', 'ssh')) is None
    assert config.get_setting('async_dir', Plugin('connection', 'ssh')) is None


# Generated at 2022-06-20 13:33:40.709167
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert isinstance(data, ConfigData)


# Generated at 2022-06-20 13:33:46.878773
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.config.setting import Setting

    config_data = ConfigData()
    config_data.update_setting(Setting("config_file", "~/.ansible/ansible.cfg", False, "ANSIBLE_CONFIG"))
    assert config_data.get_setting("config_file") == Setting("config_file", "~/.ansible/ansible.cfg", False, "ANSIBLE_CONFIG")
    assert config_data.get_setting("log_path") is None


# Generated at 2022-06-20 13:33:55.366445
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {
        'default_module_name': 'copy',
        'max_fail_percentage': 5,
    }
    config_data._plugins = {
        'connection': {
            'ssh': {
                'host_key_checking': 'False',
                'scp_if_ssh': 'True',
            },
        },
    }
    print(config_data.get_settings())
    print(config_data.get_settings('connection', 'ssh'))


# Generated at 2022-06-20 13:34:05.413626
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # init config
    config = ConfigData()
    config.update_setting(Setting(name='log_path', value='/var/log/ansible.log'))
    config.update_setting(Setting(name='log_path', value='/tmp/ansible.log',
                                  plugin=Plugin(type='callback', name='default')))

    # get global setting log_path
    setting = config.get_setting(name='log_path')
    assert setting.value == '/var/log/ansible.log'

    # get setting log_path of plugin callback/default
    setting = config.get_setting(name='log_path', plugin=Plugin(type='callback', name='default'))
    assert setting.value == '/tmp/ansible.log'

    # get unknown setting of plugin callback/default
    setting = config.get

# Generated at 2022-06-20 13:34:09.285686
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    result = config_data.get_settings()
    assert (len(result) == 0)



# Generated at 2022-06-20 13:34:13.912907
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:34:25.811379
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Create an instance of ConfigData
    config = ConfigData()

    # Create an instance of ConfigSetting
    global_setting = ConfigSetting('global_setting', 'value1')

    # Add a global setting to config
    config.update_setting(global_setting)

    assert config.get_settings() == [global_setting]

    # Create an instance of ConfigPlugin
    plugin = ConfigPlugin('plugin1', 'type1')

    # Create an instance of ConfigSetting
    plugin_setting = ConfigSetting('plugin_setting', 'value1')

    # Add a plugin setting to config
    config.update_setting(plugin_setting, plugin)

    assert config.get_settings(plugin) == [plugin_setting]


# Generated at 2022-06-20 13:34:34.385613
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    config_data = ConfigData()

    # Test that it raises KeyError if plugin and setting are None
    try:
        config_data.update_setting(None)
        assert False
    except KeyError:
        assert True

    # Test that it raises KeyError if setting is None
    test_plugin = AnsibleBaseYAMLObject("test", "test")
    try:
        config_data.update_setting(None, test_plugin)
        assert False
    except KeyError:
        assert True

    # Test that it raises KeyError if plugin is None
    test_setting = AnsibleBaseYAMLObject("test", "test")

# Generated at 2022-06-20 13:34:43.746442
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    setting = Setting()
    setting.name = 'a'
    setting.value = [2, 3]
    setting.origin = "/etc/ansible/ansible.cfg"
    cd.update_setting(setting)
    setting = Setting()
    setting.name = 'b'
    setting.value = 'server'
    setting.origin = "/etc/ansible/ansible.cfg"
    cd.update_setting(setting)
    settings = cd.get_settings()
    assert settings[0].name == 'a'
    assert settings[1].name == 'b'
    assert settings[0].value == [2, 3]
    assert settings[1].value == 'server'


# Generated at 2022-06-20 13:34:49.694048
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    config.update_setting(Setting("foo", "bar"))
    config.update_setting(Setting("bar", "foo"))

    assert config.get_settings() == [Setting("foo", "bar"), Setting("bar", "foo")]


# Generated at 2022-06-20 13:35:01.522470
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    it = ConfigData()

    setting = ConfigSetting('setting_1', 'value_1', 'description_1')
    it.update_setting(setting)

    assert setting.name in it._global_settings
    assert it._global_settings[setting.name] == setting

    plugin = Plugin('type_1', 'name_1')
    setting_2 = ConfigSetting('setting_2', 'value_2', 'description_2')
    it.update_setting(setting_2, plugin)

    assert plugin.type in it._plugins
    assert plugin.name in it._plugins[plugin.type]
    assert setting_2.name in it._plugins[plugin.type][plugin.name]
    assert it._plugins[plugin.type][plugin.name][setting_2.name] == setting_2



# Generated at 2022-06-20 13:35:03.503086
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert len(data.get_settings()) == 0
    assert len(data.get_settings(plugin=None)) == 0


# Generated at 2022-06-20 13:35:13.760802
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()
    assert "testEnv" not in configdata._global_settings
    assert "testVar" not in configdata._global_settings
    configdata.update_setting("testEnv=testEnv")
    configdata.update_setting("testVar=testVar")
    assert "testEnv" in configdata._global_settings
    assert "testVar" in configdata._global_settings
    assert configdata._global_settings["testEnv"] == "testEnv"
    assert configdata._global_settings["testVar"] == "testVar"


# Generated at 2022-06-20 13:35:18.364124
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    global_setting = Setting('test', 'test', 'test', 'test', 'test')
    plugin = Plugin('test', 'test')
    config_data.update_setting(global_setting)
    config_data.update_setting(global_setting, plugin)
    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings(plugin)) == 1


# Generated at 2022-06-20 13:35:19.549087
# Unit test for constructor of class ConfigData
def test_ConfigData():

    foo = ConfigData()

    assert foo is not None

# Generated at 2022-06-20 13:35:28.592281
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    plugin = Plugin('action', 'local')
    setting = Setting('module_name', 'shell')

    config_data.update_setting(setting, plugin)

    assert config_data.get_setting('module_name', plugin).value == 'shell'


# Generated at 2022-06-20 13:35:31.320926
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    c = config_data.get_setting(None, None)
    assert c is None

test_ConfigData_get_setting()


# Generated at 2022-06-20 13:35:37.154865
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Set some plugin data
    plugin_type = 'connection'
    plugin_name = 'netconf'

    setting = Setting(name='host',
                      plugin_type=plugin_type,
                      plugin_name=plugin_name,
                      value=['172.17.0.2'])

    config_data.update_setting(setting)

    # Return global settings
    assert config_data.get_settings(None) == []

    # Return data of plugin
    assert config_data.get_settings(Plugin(plugin_type, plugin_name)) == [setting]



# Generated at 2022-06-20 13:35:44.223743
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configdata = ConfigData()

    setting_1 = Setting(name="test_1", value="test_value")
    configdata.update_setting(setting_1)

    assert configdata.get_setting("test_1") == setting_1
    assert configdata.get_setting("test_2") is None


# Generated at 2022-06-20 13:35:46.805213
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:35:55.238540
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.config_data import ConfigData
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.config_loader import ConfigFileLoader
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic

    # Create config data
    config_data = ConfigData()
    # Create config loader
    config_loader = ConfigFileLoader(config_data)

    # Load ansible.cfg
    config_loader.load_config_file(basic._ANSIBLE_CONFIG_PATH)
    # Load ansible.cfg with config as argument
    config_loader.load_configuration(basic._ANSIBLE_CONFIG_PATH)

    # Retrieve value of config option name
    value = config_

# Generated at 2022-06-20 13:36:02.888147
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting_name = 'some_setting'
    setting_value = 'some_value'
    cd = ConfigData()
    setting = Setting(setting_name, setting_value)
    cd.update_setting(setting)
    assert cd.get_setting(setting_name) is not None
    assert cd.get_setting(setting_name).name == setting_name
    assert cd.get_setting(setting_name).value == setting_value



# Generated at 2022-06-20 13:36:14.604756
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}
    # test update global setting
    setting1 = {
        'name': 'A',
        'value': '222',
        'type': 'str',
        'category': 'a',
    }
    config_data.update_setting(setting1)
    assert config_data._global_settings == {'A': setting1}
    assert config_data._plugins == {}
    # test update plugin setting
    setting2 = {
        'name': 'B',
        'value': '333',
        'type': 'str',
        'category': 'b',
    }
    plugin1 = {
        'name': 'B',
        'type': 'cache',
    }
    config_data.update

# Generated at 2022-06-20 13:36:17.908390
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert(cd is not None)
    assert(cd._global_settings == {})
    assert(cd._plugins == {})



# Generated at 2022-06-20 13:36:21.098002
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', plugin='bar') is None

# Generated at 2022-06-20 13:36:39.036276
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    s1 = Setting(name="s1", value=1)
    p1 = Plugin(type="test", name="test1")
    p2 = Plugin(type="test2", name="test2")

    c = ConfigData()

    c.update_setting(s1)
    assert(c.get_setting(s1.name) == s1)

    c.update_setting(s1, p1)
    assert(c.get_setting(s1.name, p1) == s1)

    s2 = Setting(name="s2", value=2)
    c.update_setting(s2, p2)
    assert(c.get_setting(s2.name, p2) == s2)


# Generated at 2022-06-20 13:36:45.929038
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    import types
    from nxos_plugins import types as plugin_types
    from nxos_plugins import plugin

    sample_plugin = plugin.Plugin(
        name='sample_plugin',
        type=plugin_types.CORE,
        path='nxos_plugins.plugin.Plugin'
    )

    sample_setting = {
        'name': 'setting1',
        'description': 'Sample Setting',
        'value': None,
        'default': 1,
        'env_var': 'SAMPLE_SETTING',
        'required': True
    }

    config_data = ConfigData()
    config_data.update_setting(setting=sample_setting, plugin=sample_plugin)

    settings = config_data.get_settings(sample_plugin)
    assert isinstance(settings, list)
    assert len(settings)

# Generated at 2022-06-20 13:36:52.604220
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.errors import AnsibleError
    from ansible.module_utils import plugins
    from ansible.parsing.yaml.objects import AnsibleMapping

    cd = ConfigData()
    assert cd.get_settings() == []
    assert cd.get_settings(plugins.lookup_loader.get('template')) == []

    cd._global_settings['defaults_files'] = AnsibleMapping([('name', 'defaults_files'), ('value', 'null')])
    assert cd.get_settings() != []
    assert cd.get_settings(plugins.lookup_loader.get('template')) == []

    cd._plugins['lookup'] = {}
    try:
        cd.get_settings(plugins.lookup_loader.get('template'))
    except AnsibleError:
        pass

# Generated at 2022-06-20 13:36:53.345777
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    pass

# Generated at 2022-06-20 13:37:05.117810
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    config_data = ConfigData()

    # Case 1: Plugin is none and global setting exists
    config_data.update_setting(GlobalConfigSetting('foo', 'bar', 'baz'))
    assert config_data.get_setting('foo') == GlobalConfigSetting('foo', 'bar', 'baz')

    # Case 2: Plugin is not none, but given plugin exists
    config_data.update_setting(PluginConfigSetting('foo', 'bar', 'baz'), Plugin('module_utils', 'foo'))
    assert config_data.get_setting('foo', Plugin('module_utils', 'foo')) == PluginConfigSetting('foo', 'bar', 'baz')
    config_data.update_setting

# Generated at 2022-06-20 13:37:09.464720
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_object = ConfigData()
    print(test_object._global_settings)
    print(test_object._plugins)
    test_object.update_setting(None)
    print(test_object._global_settings)
    print(test_object._plugins)

test_ConfigData_update_setting()

# Generated at 2022-06-20 13:37:12.214634
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    import configobj
    setting = configobj.ConfigObj()
    setting['name'] = 'foo'
    data.update_setting(setting)
    setting2 = data.get_setting('foo')
    assert(setting == setting2)

# Generated at 2022-06-20 13:37:17.667211
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    """Test method update_setting of class ConfigData."""

    config_data = ConfigData()
    setting = {'name': 'test_key', 'value': 'test_value'}
    config_data.update_setting(setting)
    new_setting = config_data.get_setting('test_key')
    assert new_setting == setting


# Generated at 2022-06-20 13:37:22.005114
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    obj = ConfigData()
    setting = Setting('test_setting', 'section', 'preset_value', 'test_description')
    obj.update_setting(setting)
    assert obj.get_setting('test_setting') == Setting('test_setting', 'section', 'preset_value', 'test_description')
    assert obj.get_setting('test_setting').name == 'test_setting'
    assert obj.get_setting('test_setting').section == 'section'
    assert obj.get_setting('test_setting').default == 'preset_value'
    assert obj.get_setting('test_setting').description == 'test_description'


# Generated at 2022-06-20 13:37:27.778670
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint.rules.UseCommandInsteadOfShell import CommandShellRuleMatch

    config_data = ConfigData()
    setting = CommandShellRuleMatch()
    config_data.update_setting(setting=setting, plugin="UseCommandInsteadOfShell")
    value = config_data.get_settings(plugin="UseCommandInsteadOfShell")
    assert setting == value[0]

# Generated at 2022-06-20 13:37:46.349101
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin1 = Plugin('module', 'shell')
    plugin2 = Plugin('module', 'yum')
    plugin3 = Plugin('module', 'command')
    plugin4 = Plugin('module', 'bash')
    plugin5 = Plugin('connection', 'local')
    plugin6 = Plugin('connection', 'paramiko')
    plugin7 = Plugin('shell', 'bash')
    plugin8 = Plugin('shell', 'sh')
    plugin9 = Plugin('cache', 'memory')
    plugin10 = Plugin('cache', 'redis')
    setting1 = Setting('ANSIBLE_FORCE_COLOR', 'yes')
    setting2 = Setting('ANSIBLE_HOST_KEY_CHECKING', 'False')
    setting3 = Setting('ANSIBLE_DEPRECATION_WARNINGS', 'False')

# Generated at 2022-06-20 13:37:47.154942
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass



# Generated at 2022-06-20 13:37:52.281173
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from tests.unit.config.helpers import PluginA

    plugin_a_defaults = {
        'plugin_a1': 'plugin_a_default1',
        'plugin_a2': 'plugin_a_default2',
        'plugin_a3': 'plugin_a_default3'
    }

    config_data = ConfigData()

    assert config_data.get_setting('plugin_a1') is None
    assert config_data.get_setting('plugin_a1', PluginA()) is None
    assert config_data.get_setting('plugin_a1', PluginA('plugin_a1')) is None
    assert config_data.get_setting('plugin_a1', PluginA('plugin_a1', 'plugin_a_value1')) is None


# Generated at 2022-06-20 13:37:53.036594
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cd = ConfigData()

# Generated at 2022-06-20 13:38:04.447020
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    class Setting:
        def __init__(self, name):
            self.name = name


    plugin1 = Setting('plugin1')

    s1 = Setting('s1')
    s2 = Setting('s2')
    s3 = Setting('s3')

    config_data.update_setting(s1)
    config_data.update_setting(s2)
    config_data.update_setting(s3, plugin=plugin1)

    assert config_data.get_setting('s1').name == 's1'
    assert config_data.get_setting('s2').name == 's2'
    assert config_data.get_setting('s3', plugin=plugin1).name == 's3'


# Generated at 2022-06-20 13:38:14.121058
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    setting1 = {'name': 'setting1'}
    setting2 = {'name': 'setting2'}
    plugin = {'type': 'callback', 'name': 'plugin1'}

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting1, plugin=plugin)
    config_data.update_setting(setting2, plugin=plugin)

    #test scenario where no plugin is passed in
    assert [setting1, setting2] == config_data.get_settings()

    #test scenario where plugin is passed
    assert [setting1, setting2] == config_data.get_settings(plugin=plugin)



# Generated at 2022-06-20 13:38:17.474620
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert isinstance(ConfigData(),  ConfigData)


# Generated at 2022-06-20 13:38:18.757836
# Unit test for constructor of class ConfigData
def test_ConfigData():
    testData = ConfigData()
    assert testData


# Generated at 2022-06-20 13:38:22.184619
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    test_config_data = ConfigData()
    test_config_data.update_setting()

    assert test_config_data.get_settings() == test_config_data.get_settings()

#Unit test for method update_setting of class ConfigData

# Generated at 2022-06-20 13:38:23.168268
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()


# Generated at 2022-06-20 13:38:39.229907
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    configdata = ConfigData()
    assert isinstance(configdata, ConfigData)
    assert len(configdata.get_settings()) == 0

    from ansible.plugins.configuration import Setting
    setting = Setting()
    configdata.update_setting(setting)
    assert len(configdata.get_settings()) == 1

    from ansible.plugins.loader import get_all_plugin_loaders, PluginLoader
    plugin = PluginLoader('connection', 'local', 'local', 'connection')
    setting.plugin = plugin
    configdata.update_setting(setting)
    assert len(configdata.get_settings()) == 1
    assert len(configdata.get_settings(plugin)) == 1

    from ansible.plugins.connection.network_cli import ConnectionModule
    connection = ConnectionModule()
    setting.plugin = connection
    configdata.update

# Generated at 2022-06-20 13:38:47.390468
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigDataSetting(name="config_file", value="/etc/ansible/ansible.cfg"))
    assert config_data.get_setting(name="config_file") == ConfigDataSetting(name="config_file", value="/etc/ansible/ansible.cfg")
    assert config_data.get_setting(name="bar") == None
    assert config_data.get_settings() == [ConfigDataSetting(name="config_file", value="/etc/ansible/ansible.cfg")]
    assert config_data.get_settings(plugin=Plugin("action", "ping")) == []
    assert config_data.get_settings(plugin=Plugin("connection", "local")) == []


# Generated at 2022-06-20 13:38:53.869433
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    config_data.update_setting(Setting('foo', 'baz'))
    assert config_data.get_setting('foo') == Setting('foo', 'baz')


# Generated at 2022-06-20 13:38:56.840487
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    plugin = "plugin"
    configData.update_setting(plugin)
    assert plugin == configData.get_setting(name=None)


# Generated at 2022-06-20 13:39:00.464860
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # Test 1: Create an instance of ConfigData and verify
    config_data = ConfigData()
    assert config_data is not None
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-20 13:39:08.093019
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    test_instance = ConfigData()

    setting_1 = Setting()
    setting_1.name = "test1"
    test_instance.update_setting(setting_1)

    setting_2 = Setting()
    setting_2.name = "test2"
    test_instance.update_setting(setting_2)

    setting_3 = Setting()
    setting_3.name = "test3"
    test_instance.update_setting(setting_3, Plugin(type="action", name="command"))

    settings = test_instance.get_settings()
    assert settings[0].name == "test1"
    assert settings[1].name == "test2"
    assert settings[2] is None

    settings = test_instance.get_settings(Plugin(type="action", name="command"))

# Generated at 2022-06-20 13:39:11.030370
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    expected_global_settings = {}
    expected_plugins = {}

    assert config._global_settings == expected_global_settings
    assert config._plugins == expected_plugins

# Generated at 2022-06-20 13:39:13.831199
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings=={}
    assert config._plugins=={}

# Generated at 2022-06-20 13:39:19.115493
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin=None
    # test name
    assert isinstance(config_data.get_settings(plugin), list)

# Generated at 2022-06-20 13:39:30.662069
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    setting = Setting('foo', 'bar')

    config_data.update_setting(setting)

    assert config_data._global_settings['foo'].name == 'foo'
    assert config_data._global_settings['foo'].value == 'bar'
    assert config_data._plugins == {}
    assert config_data.get_setting('foo').name == 'foo'
    assert config_data.get_setting('foo').value == 'bar'


# Generated at 2022-06-20 13:39:37.555236
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()

    assert configData._global_settings == {}
    assert configData._plugins == {}

# Generated at 2022-06-20 13:39:48.684201
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test the return value of method get_setting() with a non existing 
    # setting (name, plugin) in the config data.
    value1 = config_data.get_setting('non_existing', 'plugin')
    assert value1 == None

    # Test the return value of method get_setting() with an existing 
    # global setting (name, None) in the config data.
    config_data.update_setting('global_setting')
    value2 = config_data.get_setting('global_setting')
    assert value2 == 'global_setting'

    # Test the return value of method get_setting() with an existing 
    # plugin setting (name, plugin) in the config data.
    config_data.update_setting('plugin_setting','plugin')
    value3 = config_data.get

# Generated at 2022-06-20 13:39:54.514783
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("my_setting") is None

# Generated at 2022-06-20 13:39:55.640761
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    print(cd)

# Generated at 2022-06-20 13:39:59.388623
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('host_key_checking') is None
    assert config_data.get_setting('host_key_checking', 'plugin name') is None


# Generated at 2022-06-20 13:40:01.599010
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:40:06.377218
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    data.update_setting(Setting('a', 'b'))
    assert data._global_settings['a'] == Setting('a', 'b')
    data.update_setting(Setting('c', 'd'), Plugin('p', 'f'))
    assert data._plugins['p']['f']['c'] == Setting('c', 'd')


# Generated at 2022-06-20 13:40:16.140207
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import sys
    sys.path.append('./lib')

    from units.mock.loader import DictDataLoader
    from units.plugins.action.my_action import ActionModule as MyAction
    from units.plugins.lookup.my_lookup import LookupModule as MyLookup
    from units.plugins.filter.my_filter import FilterModule as MyFilter

    config_data = ConfigData()

    config_data.update_setting(MyAction.get_setting_definition("test_setting"))
    config_data.update_setting(MyLookup.get_setting_definition("test_setting"))

    assert config_data.get_setting("test_setting") == MyAction.get_setting_definition("test_setting")
    assert config_data.get_setting("test_setting", plugin=MyLookup) == MyLookup.get

# Generated at 2022-06-20 13:40:17.167177
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data is not None


# Generated at 2022-06-20 13:40:27.757550
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.plugins.loader import PluginLoader, get_all_plugin_loaders
    from ansible.plugins.catalog.catalog import PluginCatalog
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude


# Generated at 2022-06-20 13:40:33.723075
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    my_configdata = ConfigData()
    assert my_configdata.get_setting('setting') == None


# Generated at 2022-06-20 13:40:43.659143
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    print('test_ConfigData')
    config_data = ConfigData()
    setting_1 = {'name': 'setting_1', 'type': 'int', 'value': 1, 'default': 1, 'scope': 'GLOBAL'}
    setting_2 = {'name': 'setting_2', 'type': 'int', 'value': 2, 'default': 2, 'scope': 'NEIGHBOR'}
    setting_3 = {'name': 'setting_3', 'type': 'int', 'value': 3, 'default': 3, 'scope': 'PLUGIN'}
    setting_4 = {'name': 'setting_4', 'type': 'int', 'value': 4, 'default': 4, 'scope': 'PLUGIN'}
    config_data.update_setting(setting_1)
    config_data.update

# Generated at 2022-06-20 13:40:45.391484
# Unit test for constructor of class ConfigData
def test_ConfigData():
    C = ConfigData()
    assert not C._global_settings
    assert not C._plugins


# Generated at 2022-06-20 13:40:50.018776
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-20 13:40:51.581898
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-20 13:41:01.412368
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('m1', None) is None
    assert config_data.get_setting('m1', 'c.h') is None

    config_data.update_setting(Setting('m1', 'b', 'c', 'd'))
    assert config_data.get_setting('m1', None).name == 'm1'
    assert config_data.get_setting('m1', None).default == 'b'
    assert config_data.get_setting('m1', None).value == 'b'
    assert config_data.get_setting('m1', None).yaml == 'c'
    assert config_data.get_setting('m1', None).ini == 'd'
    assert config_data.get_setting('m1', None).scope == SCOPE

# Generated at 2022-06-20 13:41:14.635636
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()

    test_settings = []

    # global settings
    test_settings.append(('action_plugins', None))
    test_settings.append(('cache_plugins', None))
    test_settings.append(('callback_plugins', None))
    test_settings.append(('connection_plugins', None))
    test_settings.append(('lookup_plugins', None))
    test_settings.append(('strategy_plugins', None))
    test_settings.append(('vars_plugins', None))
    test_settings.append(('filter_plugins', None))
    test_settings.append(('test_plugins', None))
    test_settings.append(('terminal_plugins', None))

# Generated at 2022-06-20 13:41:17.721560
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    config_data.update_setting(Setting())
    config_data.update_setting(Setting('var1'))
    config_data.update_setting(Setting('var2'))

    assert len(config_data.get_settings()) == 3


# Generated at 2022-06-20 13:41:31.369735
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from tempfile import mkdtemp
    from ansible.config.setting import Setting
    from ansible.config.manager import ConfigManager
    from ansible.config.data import ConfigData
    path = mkdtemp()
    config_manager = ConfigManager(paths=path)
    config_manager.set_section_attribute('core', 'basedir', path)
    config_data = ConfigData()

    raw_data = {'basedir': path}

    setting = Setting('basedir', 'core', raw_data, config_manager)

    config_data.update_setting(setting)

    assert config_data._global_settings['basedir'] == setting

    setting = Setting('log_path', 'core', raw_data, config_manager)

    config_data.update_setting(setting)


# Generated at 2022-06-20 13:41:39.801362
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # This test tests the get_plugin method of ConfigData class
    # Create ConfigData object
    config_data = ConfigData()
    # Create plugin and setting objects
    setting = Setting('test_setting', 'value', '1.0.0')
    plugin = Plugin('test_plugin', 'action', '1.0.0')
    # Add plugin and setting
    config_data.update_setting(setting)
    config_data.update_setting(setting, plugin)
    # Test getting setting objects from ConfigData object
    assert(config_data.get_settings()[0].name == setting.name)
    assert(config_data.get_settings(plugin)[0].name == setting.name)
    assert(config_data.get_setting('test_setting').name == setting.name)

# Generated at 2022-06-20 13:41:50.780543
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    assert c.get_settings() == []
    # add a global setting
    c.update_setting(Setting('key', 'value'))
    assert c.get_settings() == [Setting('key', 'value')]
    # add a setting for ansible_yaml
    c.update_setting(Setting('key', 'value', Plugin('ansible_yaml', 'lookup')))
    assert c.get_settings() == [Setting('key', 'value')]
    assert c.get_settings(Plugin('ansible_yaml', 'lookup')) == [Setting('key', 'value', Plugin('ansible_yaml', 'lookup'))]
    # add a setting for stash
    c.update_setting(Setting('key', 'value', Plugin('stash', 'filter')))
    assert c

# Generated at 2022-06-20 13:42:00.116659
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin('module', 'gcp_sql_database_instance')
    config_data.update_setting(Setting('module_defaults', 'gcp_compute'), plugin)
    assert config_data.get_setting('module_defaults', plugin).name == 'module_defaults'
    assert config_data.get_setting('module_defaults').name == 'module_defaults'


# Generated at 2022-06-20 13:42:04.256068
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = ConfigSetting("CONFIG_FILE")
    assert config_data.get_settings() == []
    config_data.update_setting(setting)
    assert config_data.get_settings() == [setting]


# Generated at 2022-06-20 13:42:07.895344
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-20 13:42:14.732841
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = PluginDescriptor('filter', 'f1')
    setting = ConfigSetting(name='s1', plugin=plugin, value='foo')

    config_data.update_setting(setting)

    setting = config_data.get_setting('s1', plugin)
    assert setting.name == 's1'
    assert setting.value == 'foo'


# Generated at 2022-06-20 13:42:21.956802
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    # Test update setting on empty data
    setting = {'name': 'setting 1', 'value': 'value 1', 'plugin': 'plugin 1'}
    config_data.update_setting(setting)
    assert config_data._global_settings['setting 1'] == setting

    # Test update setting on non-empty data
    setting = {'name': 'setting 2', 'value': 'value 2', 'plugin': 'plugin 2'}
    config_data.update_setting(setting)
    assert config_data._global_settings['setting 2'] == setting


# Generated at 2022-06-20 13:42:27.411849
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:42:29.844731
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-20 13:42:36.854269
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    import ansible.config.setting
    s = ansible.config.setting.Setting('password', '/etc/ansible/ansible.cfg', ['all', 'ssh'])
    cd.update_setting(s)
    assert cd.get_setting('password') is s
    ps = ansible.config.setting.PluginSetting('sudo_user', '/etc/ansible/ansible.cfg', ['all', 'ssh'], 'connection', 'ssh')
    cd.update_setting(ps)
    assert cd.get_setting('sudo_user', ps.plugin) is ps



# Generated at 2022-06-20 13:42:46.121212
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data._global_settings = {
        "a": dict(name="a", value=1, origin="dummy_playbook"),
        "b": dict(name="b", value=2, origin="dummy_playbook"),
        "c": dict(name="c", value=3, origin="dummy_playbook")
    }
    assert config_data.get_setting("a") == dict(name="a", value=1, origin="dummy_playbook")
    assert config_data.get_setting("b") == dict(name="b", value=2, origin="dummy_playbook")
    assert config_data.get_setting("c") == dict(name="c", value=3, origin="dummy_playbook")


# Generated at 2022-06-20 13:42:54.256876
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}


# Generated at 2022-06-20 13:42:57.752204
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData()


# Generated at 2022-06-20 13:43:04.204675
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {'a': 1, 'b': 2}
    settings = config_data.get_settings()
    settings = [setting.name for setting in settings]
    if not all(settings == config_data._global_settings.keys()):
        raise Exception('Error, test_ConfigData_get_settings failed!')


# Generated at 2022-06-20 13:43:09.492283
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin_name = 'Test'
    setting_name = 'Test'
    default_value = 'Test'
    current_value = 'Test'
    setting = Setting(setting_name, default_value, current_value)
    config_data.update_setting(setting)
    assert config_data._global_settings[setting_name] == setting