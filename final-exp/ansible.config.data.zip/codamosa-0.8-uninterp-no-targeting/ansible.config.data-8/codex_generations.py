

# Generated at 2022-06-20 13:33:12.054886
# Unit test for constructor of class ConfigData
def test_ConfigData():
    ConfigData()


# Generated at 2022-06-20 13:33:17.341923
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cd.update_setting(Setting('test_setting1', 'test_value', plugin=Plugin('test_type', 'test_name')))
    assert cd._global_settings == {}
    assert cd._plugins['test_type']['test_name']['test_setting1'].value == 'test_value'



# Generated at 2022-06-20 13:33:27.812875
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import os
    import tempfile
    from ansible.plugins.loader import setting_loader
    from ansible.plugins.loader import plugin_loader

    setting_t = setting_loader.get('host_list')
    setting = setting_t()

    plugin_t = plugin_loader.get('callback')
    plugin = plugin_t(None, 'minimal')

    plugin_t = plugin_loader.get('connection')
    plugin2 = plugin_t(None, 'local')
    plugin3 = plugin_t(None, 'netconf')

    config_data = ConfigData()
    config_data.update_setting(setting, plugin)

    # test for "minimal" callback
    setting = config_data.get_setting('host_list', plugin)
    assert setting is not None
    assert setting.name == 'host_list'

# Generated at 2022-06-20 13:33:37.791078
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting("setting1")
    config_data.update_setting("setting2")
    config_data.update_setting("setting3")
    config_data.update_setting("setting4", plugin="plugin1")
    config_data.update_setting("setting5", plugin="plugin2")
    config_data.update_setting("setting6", plugin="plugin3")
    assert config_data.get_settings() == ["setting1", "setting2", "setting3"]
    assert config_data.get_settings("plugin1") == ["setting4"]
    assert config_data.get_settings("plugin2") == ["setting5"]
    assert config_data.get_settings("plugin3") == ["setting6"]



# Generated at 2022-06-20 13:33:44.232852
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data._global_settings = {'config': 'config', 'environment': 'environment'}
    assert config_data.get_setting('config') == config_data._global_settings['config']
    assert config_data.get_setting('environment') == config_data._global_settings['environment']
    assert config_data.get_setting('not_exist') is None


# Generated at 2022-06-20 13:33:46.184668
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    pass


# Generated at 2022-06-20 13:33:49.947867
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(config_data)
    assert (config_data._global_settings.get('plugin.file.path') == config_data)


# Generated at 2022-06-20 13:33:51.410137
# Unit test for constructor of class ConfigData
def test_ConfigData():
    with pytest.raises(TypeError):
        ConfigData()

# Generated at 2022-06-20 13:33:52.804359
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    c = ConfigData()

    assert c.get_settings() == []

# Generated at 2022-06-20 13:34:03.906159
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader
    from ansible.utils.config_data import ConfigData
    from ansible.utils.config_data import PluginSetting

    # Create the test object
    config_data = ConfigData()

    # Add a global setting
    plugin_name = 'test_name'
    plugin_type = 'lookup'
    plugin = PluginLoader.find_plugin(plugin_type, plugin_name)
    setting_name = 'test_setting_name'
    setting_value = 'test_setting_value'
    setting = PluginSetting(setting_name, setting_value, plugin, is_global=True)
    config_data.update_setting(setting)

    # Add a global setting that is overridden
    plugin_name = 'test_name'
    plugin_type = 'lookup'

# Generated at 2022-06-20 13:34:10.180259
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.plugins.loader import get_all_plugin_loaders

    config_data = ConfigData()

    for plugin_loader in get_all_plugin_loaders():
        for plugin in plugin_loader.all():
            assert config_data.get_setting(plugin.name) is None


# Generated at 2022-06-20 13:34:19.240517
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from ansiblelint.rules import AnsibleLintRule
    from ansiblelint.rules.TagImportance import TagImportance
    from ansiblelint.rules.TaskHasTag import TaskHasTag
    from ansiblelint.rules.MetaMainHasVersion import MetaMainHasVersion

    data = ConfigData()
    data.update_setting(AnsibleLintRule.setting_factory('tag-importance-10', 10, 'test', 'tag-importance', type='int'))
    assert data.get_setting('tag-importance-10').value == 10

    data.update_setting(TaskHasTag.tag_importance_setting, TaskHasTag)
    assert data.get_setting('tag-importance', TaskHasTag).value == 10


# Generated at 2022-06-20 13:34:30.633492
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class TestConfig():
        def __init__(self):
            self.type = 'type'
            self.name = 'name'

    test_global = ConfigData()
    test_plugin = ConfigData()

    setting = {}
    setting['name'] = 'name'
    setting['value'] = 'value'
    setting['origin'] = 'origin'
    setting['section'] = 'section'
    setting['level'] = 'level'

    # Testing for global setting
    test_global.update_setting(setting)
    assert test_global._global_settings['name'].name == setting['name']
    assert test_global._global_settings['name'].value == setting['value']
    assert test_global._global_settings['name'].origin == setting['origin']
    assert test_global._global_settings['name'].section

# Generated at 2022-06-20 13:34:36.794092
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    class Plugin(object):
        def __init__(self):
            self.name = 'plugin name'
            self.type = 'plugin type'

    class Setting(object):
        def __init__(self):
            self.name = 'setting_name'
            self.value = 'setting value'
            self.origin = {'one': 'string', 'two': 'another string'}

    plugin = Plugin()
    setting = Setting()
    config_data.update_setting(setting, plugin)
    settings = config_data.get_settings(plugin)
    assert(len(settings) == 1)
    assert(settings[0].name == 'setting_name')

# Generated at 2022-06-20 13:34:39.826542
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Both methods should be equal
    assert config_data.get_setting("setting1", plugin=None) == config_data.get_settings(plugin=None)[0]



# Generated at 2022-06-20 13:34:46.987832
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # create config data
    config_data = ConfigData()
    # create setting
    config_setting = PluginConfig()
    config_setting.name = "SomeSetting"
    config_setting.value = "SomeValue"
    config_setting.plugin_type = "SomePluginType"
    config_setting.plugin_name = "SomePluginName"
    config_setting.default_value = "SomeDefaultValue"
    config_setting.plugin = Plugin()
    config_setting.plugin.name = "SomePluginName"
    config_setting.plugin.type = "SomePluginType"
    config_data.update_setting(config_setting, plugin = config_setting.plugin)
    # get a setting
    actual = config_data.get_setting("SomeSetting", plugin = config_setting.plugin)
    # compare with expected
    expected = config

# Generated at 2022-06-20 13:34:49.174327
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-20 13:35:01.276958
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class Plugin():
        def __init__(self, name, type):
            self.name = name
            self.type = type

    def _global_settings_get(name):
        return None

    def _plugins_get(type):
        return None

    # test _global_settings exists and is not empty
    a = ConfigData()
    a._global_settings = {'foo': 'bar'}
    assert a.get_setting('foo') == 'bar'

    # test _plugins exists and is not empty
    b = ConfigData()
    b._plugins = {'foo': {'bar': {'baz': 'buz'}}}
    c = Plugin(name='bar', type='foo')
    assert b.get_setting('baz', c) == 'buz'

    # test the setting exists in both _global_

# Generated at 2022-06-20 13:35:12.309000
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.parsing.config.setting import Setting
    from ansible.parsing.config.plugin import Plugin

    data = ConfigData()

    for plugin in [Plugin('cache', 'foo'), Plugin('shell', 'bar'), Plugin('module', 'fact')]:
        setting = Setting('become', plugin.type, False, 'BECOME_ASK', 'boolean', [], 'default')
        data.update_setting(setting, plugin)

    assert len(data.get_settings()) == 0
    assert len(data.get_settings(Plugin('cache', 'bar'))) == 0

    assert len(data.get_settings(Plugin('cache', 'foo'))) == 1
    assert data.get_settings(Plugin('cache', 'foo'))[0].name == 'become'


# Generated at 2022-06-20 13:35:24.416977
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()
    assert configData._global_settings == {}
    assert configData._plugins == {}

    # test invalid plugin
    invalidPlugin = "invalid plugin"
    settings = configData.get_settings(invalidPlugin)
    assert settings == []

    # test global setting for invalid plugin
    settings = configData.get_setting("invalid")
    assert settings == None

    # test global setting
    globalSetting = "global setting"
    configData._global_settings["global"] = "global setting"
    settings = configData.get_setting("global")
    assert settings == globalSetting

    # test empty _plugins
    settings = configData.get_settings()
    assert settings == [globalSetting]

    # test invalid plugin
    settings = configData.get_settings(invalidPlugin)
    assert settings == []



# Generated at 2022-06-20 13:35:37.034367
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    cfg_data = ConfigData()
    cfg_data.update_setting(ConfigSetting('log_path', 'logs/ansible.log'))

    assert 2 == len(cfg_data.get_settings())

test_ConfigData_get_settings()



# Generated at 2022-06-20 13:35:47.397835
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import plugin_loaders

    config = ConfigData()

    # Each plugin will have at least one setting
    for plugin_loader in plugin_loaders.all():
        for plugin in plugin_loader.all():

            for setting in config.get_settings(plugin):
                config.update_setting(setting, plugin)

            # The next code should fail since this is an existing setting
            if plugin.settings:
                setting = plugin.settings[0]
                with pytest.raises(ValueError) as excinfo:
                    config.update_setting(setting, plugin)
                assert 'is already present' in str(excinfo.value)

    # global settings
    setting = Setting('FOO', 'FOO', '/foo/bar', '/foo/bar/')
    config.update_setting(setting)
    assert config

# Generated at 2022-06-20 13:35:51.851959
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert len(cd._global_settings) == 0
    assert len(cd._plugins) == 0

    cd.update_setting(Setting('ANSIBLE_HOST_KEY_CHECKING', 'False'))
    assert cd.get_setting('ANSIBLE_HOST_KEY_CHECKING')
    assert len(cd._global_settings) == 1
    assert len(cd._plugins) == 0

    cd = ConfigData()
    plugin = Plugin('', '', 'filter')
    cd.update_setting(Setting('', '', '', 'filter', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', plugin), plugin)
    assert cd.get_setting('', plugin)
    assert len(cd._global_settings) == 0

# Generated at 2022-06-20 13:35:58.028264
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()

    assert cd.get_setting('ANSIBLE_INVENTORY') is None
    assert cd.get_setting('ANSIBLE_INVENTORY', 'i') is None
    assert cd.get_setting('ANSIBLE_INVENTORY', 'i:d') is None
    assert cd.get_setting('ANSIBLE_INVENTORY', 'i:d:my_plugin') is None
    assert len(cd.get_settings()) == 0
    assert len(cd.get_settings('i')) == 0
    assert len(cd.get_settings('i:d')) == 0
    assert len(cd.get_settings('i:d:my_plugin')) == 0


# Generated at 2022-06-20 13:36:09.001657
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    class Plugin:
        def __init__(self, name, type):
            self.name = name
            self.type = type

    class Setting:
        def __init__(self, config_data, name, plugin, value):
            self.config_data = config_data
            self.name = name
            self.plugin = plugin
            self.value = value

    # Global setting
    setting = Setting(config_data, 'foo', None, 'bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting

    # Plugin setting
    foo_plugin = Plugin('foo', 'test')
    setting = Setting(config_data, 'foo', foo_plugin, 'bar')
    config_data.update_setting(setting)

# Generated at 2022-06-20 13:36:13.752037
# Unit test for constructor of class ConfigData
def test_ConfigData():
    obj = ConfigData()
    assert not obj._global_settings
    assert not obj._plugins


# Generated at 2022-06-20 13:36:17.640718
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-20 13:36:20.147407
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:36:25.996964
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    a = ConfigData()
    a.update_setting("setting1")
    a.update_setting("setting2")
    a.update_setting("setting3")
    a.update_setting("setting4")
    assert a.get_setting("setting1").name == 'setting1'


# Generated at 2022-06-20 13:36:39.719050
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.compat import ipaddress

    from ansible.module_utils import basic

    setting1 = basic.AnsibleModule([])
    setting1.params = dict(key='value')
    setting1.type='test'
    setting1.name='test_setting_1'

    setting2 = basic.AnsibleModule([])
    setting2.params = dict(key='value')
    setting2.type = 'test'
    setting2.name = 'test_setting_2'

    setting3 = basic.AnsibleModule([])
    setting3.params = dict(key='value')
    setting3.type = 'test'
    setting3.name = 'test_setting_3'

   

# Generated at 2022-06-20 13:36:48.156848
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()


# Generated at 2022-06-20 13:37:00.262620
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.parsing.plugin_docs import read_docstring

    config = ConfigData()

    # create docstring for collection foo
    docstring = """\
---
module: test
short_description: test
version_added: "1.0"
author: "Ansible"
description:
    - This is a test module
options:
    name:
        description:
            - name
        required: true
        default: bar
        choices:
            - bar
            - baz
        aliases:
            - one
            - two
    age:
        description:
            - age
        required: true
        default: 42
        aliases:
            - three
            - four
"""

    docstring_meta = read_docstring(docstring, 'test_module')

    # create dummy module for collection foo
    module

# Generated at 2022-06-20 13:37:01.461875
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    assert config.get_settings() == []

# Generated at 2022-06-20 13:37:09.301452
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # this unit test is performed here since the unit test is written in python, but the tested method is in ansible.
    # as a result, the module containing the tested method can't import the unit test module. 
    # Test 1: update global setting
    # Test 2: update plugin setting

    # Test 1
    config_data = ConfigData()
    setting = ConfigSetting('param', 'value')
    config_data.update_setting(setting)

    assert setting.name == config_data.get_setting(setting.name).name
    assert setting.value == config_data.get_setting(setting.name).value

    # Test 2
    config_data = ConfigData()
    setting = ConfigSetting('param', 'value')
    plugin = ConfigPlugin(config_data, 'test', 'test')

# Generated at 2022-06-20 13:37:11.553014
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()
    config.update_setting(Setting(name="force_handlers", value=True))
    assert config.get_setting("force_handlers").value is True



# Generated at 2022-06-20 13:37:20.746530
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()

    setting1 = {'name': 'foo', 'value': 'bar'}
    config.update_setting(setting1)
    assert config.get_setting('foo') == setting1

    plugin2 = Plugin(Plugin.TYPE_CACHE, 'redis')
    setting2 = {'name': 'foo', 'value': 'bar2'}
    config.update_setting(setting2, plugin=plugin2)
    assert config.get_setting('foo') == setting1
    assert config.get_setting('foo', plugin=plugin2) == setting2

    plugin3 = Plugin(Plugin.TYPE_CACHE, 'memcache')
    setting3 = {'name': 'foo', 'value': 'bar3'}
    config.update_setting(setting3, plugin=plugin3)
    assert config.get

# Generated at 2022-06-20 13:37:27.060711
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    config._global_settings = {
        'setting1': {'name': 'setting1', 'value': 'value1'},
        'setting2': {'name': 'setting2', 'value': 'value2'},
        'setting3': {'name': 'setting3', 'value': 'value3'},
    }
    config._plugins = {
        'type1': {
            'name1': {
                'setting1': {'name': 'setting1', 'value': 'value4'},
                'setting2': {'name': 'setting2', 'value': 'value5'},
            }
        }
    }

    # Call method get_settings

# Generated at 2022-06-20 13:37:35.272998
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(GlobalSetting(name='namespace', value='test'))
    assert config_data.get_setting('global/namespace') == 'test'

    config_data.update_setting(PluginSetting(name='plugin_name', value='test'), Plugin(name='test', type='test'))
    assert config_data.get_setting('test/test/plugin_name') == 'test'


# Generated at 2022-06-20 13:37:46.817461
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    settings = {
        'foo': 'bar',
        'baz': 'qux'
    }

    settings_for_a_plugin = {
        'foo': 'bar',
    }

    config_data = ConfigData()
    for k, v in settings.items():
        config_data.update_setting(SettingData(name=k, value=v))
    for k, v in settings_for_a_plugin.items():
        config_data.update_setting(SettingData(name=k, value=v), PluginData(type='v1', name='foobar'))

    assert config_data.get_setting('baz') == 'qux'
    assert config_data.get_setting(name='foo') == 'bar'

# Generated at 2022-06-20 13:37:55.648875
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('setting1', 'value1'))
    config_data.update_setting(ConfigSetting('setting2', 'value2'))
    config_data.update_setting(ConfigSetting('setting3', 'value3'), plugin=ConfigPlugin('module_utils', 'module_utils_name'))
    config_data.update_setting(ConfigSetting('setting4', 'value4'), plugin=ConfigPlugin('module_utils', 'module_utils_name'))
    config_data.update_setting(ConfigSetting('setting5', 'value5'), plugin=ConfigPlugin('module', 'module_name'))

    settings = config_data.get_settings()
    assert len(settings) == 2
    assert settings[0].name == 'setting1'
    assert settings[0].value

# Generated at 2022-06-20 13:38:23.874758
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class TestSetting:
        def __init__(self, name, value):
            self.name = name
            self.value = value

    class TestPlugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    data = ConfigData()

    # Add a global setting
    data.update_setting(TestSetting('ANALYTICS_ENABLED', 'yes'))

    # Add a plugin setting
    data.update_setting(TestSetting('LOG_FILE', 'test.log'), TestPlugin('action', 'test'))

    # Test get_setting:
    # Test global setting
    assert data.get_setting('ANALYTICS_ENABLED').value == 'yes'
    # Test plugin setting

# Generated at 2022-06-20 13:38:37.485968
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(Setting('foo', 'bar'))
    config.update_setting(Setting('foo', 'bar'))

    assert config.get_setting('foo') is not None
    assert config.get_setting('foo').name == 'foo'
    assert config.get_setting('foo').value == 'bar'
    assert config.get_setting('foo').plugin is None
    assert config.get_setting('foo').priority == 0

    assert config.get_setting('foo2') is None
    assert config.get_setting('foo', Plugin('Foo', 'foo1')) is None
    assert config.get_setting('foo', Plugin('Bar', 'bar1')) is None


# Generated at 2022-06-20 13:38:47.808441
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.config.setting import Setting

    config_data = ConfigData()

    module_setting = Setting('module_setting',
                             'module_setting_value',
                             'path/to/module/module_setting.yaml')

    config_data.update_setting(module_setting, plugin=None)
    assert config_data.get_setting('module_setting') == module_setting
    assert config_data.get_settings() == [module_setting]

    plugin_setting = Setting('plugin_setting',
                             'plugin_setting_value',
                             'path/to/plugin/plugin_setting.yaml')

    plugin = Plugin('plugintype', 'pluginname')
    config_data.update_setting(plugin_setting, plugin)

# Generated at 2022-06-20 13:38:55.341255
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings["ANSIBLE_CALLBACK_WHITELIST"] = "test_config"
    config_data._plugins["callback"] = {}
    config_data._plugins["callback"]["test_callback"] = {}
    config_data._plugins["callback"]["test_callback"]["CALLBACK_1"] = "test_callback_1"

    assert len(config_data.get_settings()) == 1



# Generated at 2022-06-20 13:39:01.375476
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    # Create dummy setting and plugin
    plugin = Plugin(type='dummy', name='dummy')
    setting = Setting(name='dummy', values={})

    # Global setting
    config_data.update_setting(setting)
    assert config_data.get_setting('dummy') == setting

    # Plugin setting
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('dummy', plugin) == setting



# Generated at 2022-06-20 13:39:05.396448
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    data = ConfigData()
    data.update_setting(Setting('abc', 'value1'))
    assert data.get_settings()[0].name == 'abc'
    assert len(data.get_settings()) == 1


# Generated at 2022-06-20 13:39:15.855057
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblelint.plugins.configuration.lineinfile import LineInFileMatch
    from ansiblelint.rule import RuleMatch
    from ansiblelint.rule import get_filename

    filename = get_filename('test/unit/plugins/configuration/lineinfile/bad/tests/ansible.cfg')
    match = RuleMatch(filename=filename, start_line=0, start_column=0, end_line=0, end_column=0)
    line_in_file_match = LineInFileMatch(match, '- name: "Make sure Ansible always uses Python 3"', None)

    config_data = ConfigData()
    setting = config_data.get_setting(line_in_file_match.setting_name, plugin=line_in_file_match.plugin)

    assert setting == None

    config_

# Generated at 2022-06-20 13:39:17.957344
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:39:23.373933
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    CD = ConfigData()
    assert len(CD.get_settings()) == 0
    assert len(CD.get_settings('some_plugin')) == 0
    CD.update_setting('setting_1', 'some_plugin')
    assert len(CD.get_settings()) == 0
    assert len(CD.get_settings('some_plugin')) == 1
    CD.update_setting('setting_2')
    assert len(CD.get_settings()) == 1
    assert len(CD.get_settings('some_plugin')) == 1
test_ConfigData_update_setting()

# Generated at 2022-06-20 13:39:26.749903
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = Setting('ansible_host', 'host.example.com')
    config_data.update_setting(setting)
    assert config_data.get_setting('ansible_host') == setting


# Generated at 2022-06-20 13:40:09.533328
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin1 = Plugin(name='plugin1', type='action')
    plugin2 = Plugin(name='plugin2', type='action')
    plugin3 = Plugin(name='plugin3', type='filter')
    setting1 = Setting(name='setting1', value='value1')
    setting2 = Setting(name='setting2', value='value2')
    setting3 = Setting(name='setting3', value='value3')
    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin=plugin1)
    config_data.update_setting(setting3, plugin=plugin3)
    assert config_data.get_setting('setting1') == setting1
    assert config_data.get_setting('setting2', plugin=plugin1) == setting2
    assert config

# Generated at 2022-06-20 13:40:22.899167
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()
    config_data.update_setting(Setting("ansible_ssh_user"))
    config_data.update_setting(Setting("ansible_ssh_private_key_file", plugin=PluginLoader.all().get("connection").get("params")))
    config_data.update_setting(Setting("ansible_ssh_host"))

    data = config_data.get_settings()

    # Global Settings
    assert len(data) == 2

    # Connection Settings
    data = config_data.get_settings(PluginLoader.all().get("connection").get("params"))
    assert len(data) == 1


# Generated at 2022-06-20 13:40:24.493359
# Unit test for constructor of class ConfigData
def test_ConfigData():
    confdata=ConfigData()
    assert confdata is not None


# Generated at 2022-06-20 13:40:25.428484
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    pass


# Generated at 2022-06-20 13:40:28.065214
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert isinstance(config._global_settings, dict)
    assert config._global_settings == {}
    assert isinstance(config._plugins, dict)
    assert config._plugins == {}

# Generated at 2022-06-20 13:40:35.961222
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()

    assert config.get_setting('default_period') is None

    config.update_setting(Setting('default_period', '1 hour'))
    assert config.get_setting('default_period').name == 'default_period'
    assert config.get_setting('default_period').value == '1 hour'

    config.update_setting(Setting('default_period', '1 day'))
    assert config.get_setting('default_period') == '1 day'

    config.update_setting(Setting('default_period', '1 month'))
    assert config.get_setting('default_period') == '1 month'

    config.update_setting(Setting('default_period', '1 year'))
    assert config.get_setting('default_period') == '1 year'


# Generated at 2022-06-20 13:40:41.063140
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import fragment_loader

    configData = ConfigData()
    setting = fragment_loader.setting_loader.get("FOO_BAR")
    configData.update_setting(setting)
    assert len(configData.get_settings()) == 1
    assert configData.get_setting(setting.name) is not None
    assert configData.get_setting(setting.name).name == setting.name

# Generated at 2022-06-20 13:40:44.521958
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()
    assert [] == configdata.get_settings()


# Generated at 2022-06-20 13:40:58.137156
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    
    config_data = ConfigData()
    config_data._global_settings = {'name1': "value1", 'name2': "value2"}

    config_data._plugins = {}

    plugin = ConfigPlugin('type1', "name1")
    config_data._plugins[plugin.type] = {}
    config_data._plugins[plugin.type][plugin.name] = {'name3': "value3", 'name4': "value4"}

    plugin = ConfigPlugin('type1', "name2")
    config_data._plugins[plugin.type] = {}
    config_data._plugins[plugin.type][plugin.name] = {'name5': "value5", 'name6': "value6"}

    plugin = ConfigPlugin('type2', "name3")
    config_data._plugins[plugin.type] = {}


# Generated at 2022-06-20 13:41:10.290361
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting({'name': 'LAST_TASK_ID'})
    config_data.update_setting({'name': 'LAST_TASK_ID'}, {'type': 'CALLBACK', 'name': 'default'})

    setting = config_data.get_setting('LAST_TASK_ID')
    assert setting['name'] == 'LAST_TASK_ID'
    setting = config_data.get_setting('LAST_TASK_ID', {'type': 'CALLBACK', 'name': 'default'})
    assert setting['name'] == 'LAST_TASK_ID'


# Generated at 2022-06-20 13:42:35.804604
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test cases
    # 1. Create a config setting for global settings and validate
    global_config_data = ConfigData()
    global_config_data.update_setting(ConfigSetting('DEFAULT_ANSIBLE_CONFIG', '/etc/ansible/ansible.cfg'))
    assert global_config_data.get_setting('DEFAULT_ANSIBLE_CONFIG') is not None
    assert global_config_data.get_setting('DEFAULT_ANSIBLE_CONFIG').name == 'DEFAULT_ANSIBLE_CONFIG'
    assert global_config_data.get_setting('DEFAULT_ANSIBLE_CONFIG').value == '/etc/ansible/ansible.cfg'

    # 2. Create a config setting for global settings and validate

# Generated at 2022-06-20 13:42:45.676114
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='inventory_plugins', value='/user/share/ansible/plugins/inventory,/user/share/ansible/plugins/inventory/aws'))
    config_data.update_setting(Setting(name='inventory_plugins', value='/usr/share/ansible/plugins/inventory,/usr/share/ansible/plugins/inventory/aws', plugin=Plugin(type='INVENTORY', name='myinventory')))
    assert config_data.get_setting('inventory_plugins') == Setting(name='inventory_plugins', value='/user/share/ansible/plugins/inventory,/user/share/ansible/plugins/inventory/aws')

# Generated at 2022-06-20 13:42:51.427564
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    setting = Setting("name", "default", "path", "description")
    configData.update_setting(setting)
    assert configData._global_settings["name"] == setting


# Generated at 2022-06-20 13:42:58.724726
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = old_ConfigData()

    def test_get_settings_no_param():
        setting = old_Setting()
        setting.name = "a setting"
        setting.value = "a value"
        config.update_setting(setting)

        setting2 = old_Setting()
        setting2.name = "another setting"
        setting2.value = "another value"
        config.update_setting(setting2)

        assert config.get_settings() is True, "Doesn't return None " \
                                              "when no param is passed"

    def test_get_setting_param():
        setting = old_Setting()
        setting.name = "a setting"
        setting.value = "a value"
        config.update_setting(setting)


# Generated at 2022-06-20 13:43:09.849729
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    conf = ConfigData()
    from ansiblelint.rules.no_commands import NoCommandsRule
    r = NoCommandsRule()
    assert conf.get_setting('no_commands', r) is None
    c = r.set_config({'no_commands': {'cmds': ['grep'], 'msg': 'Please use command module when possible'}})
    assert c == {'no_commands': {'cmds': ['grep'], 'msg': 'Please use command module when possible'}}
    conf.update_setting(c, r)
    assert conf.get_setting('no_commands', r) == {'cmds': ['grep'], 'msg': 'Please use command module when possible'}
    assert conf.get_setting('no_commands') is None