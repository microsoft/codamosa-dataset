

# Generated at 2022-06-20 13:33:22.765054
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Setup
    config = ConfigData()
    plugin1 = Plugin('connection', 'local')
    plugin2 = Plugin('lookup', 'template')
    plugin3 = Plugin('action', 'pause')
    plugins = [plugin1, plugin2, plugin3]

    setting1 = Setting('timeout', '10')
    setting2 = Setting('max_retries', '5')
    global_settings = [setting1, setting2]

    for setting in global_settings:
        config.update_setting(setting)

    for plugin in plugins:
        for setting in global_settings:
            config.update_setting(setting, plugin)

    # Verify
    for plugin in plugins:
        for setting in global_settings:
            assert config.get_setting(setting.name) == setting

# Generated at 2022-06-20 13:33:23.897175
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-20 13:33:28.440702
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert True

# Generated at 2022-06-20 13:33:31.438256
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    assert c._global_settings == {}

    s = Setting(name='test')
    c.update_setting(s)
    assert c._global_settings['test'] == s


# Generated at 2022-06-20 13:33:41.231703
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin("test_type", "test_name")
    setting = Setting("test_key", "test_value")
    config_data.update_setting(setting, plugin)

    assert config_data._global_settings == {}
    assert config_data._plugins == {"test_type": {"test_name": {"test_key": setting}}}

    setting2 = Setting("test_key2", "test_value2")
    config_data.update_setting(setting2)

    assert config_data._global_settings == {"test_key2": setting2}
    assert config_data._plugins == {"test_type": {"test_name": {"test_key": setting}}}


# Generated at 2022-06-20 13:33:43.024657
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    assert cd.get_setting('core') is None


# Generated at 2022-06-20 13:33:48.717497
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("test_setting_1", "test_value_1"))
    assert config_data.get_setting("test_setting_1") == Setting("test_setting_1", "test_value_1")


# Generated at 2022-06-20 13:33:53.122701
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    assert len(config._global_settings) == 0

    # Test if global setting is correctly update
    config.update_setting(Setting('a', 1))
    assert 'a' in config._global_settings
    config.update_setting(Setting('b', 2))
    assert 'b' in config._global_settings

    assert len(config._global_settings) == 2

    # Test if plugin setting is correctly update
    plugin = Plugin('type', 'name')
    plugin2 = Plugin('type2', 'name2')
    config.update_setting(Setting('a', 1), plugin)
    config.update_setting(Setting('b', 2), plugin)
    config.update_setting(Setting('c', 3), plugin)
    config.update_setting(Setting('a', 4), plugin2)
    config.update

# Generated at 2022-06-20 13:34:01.324448
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()

    global_param = None
    plugin_param = None

    global_params = config.get_settings()
    for param in global_params:
        if param.name == 'global1':
            global_param = param
    for param in global_params:
        if param.name == 'global1':
            global_param = param

    assert global_param.name == 'global1'
    assert global_param.value == 'test'
    assert global_param.type == 'bool'
    assert global_param.description == 'description for global1'


# Generated at 2022-06-20 13:34:03.917584
# Unit test for constructor of class ConfigData
def test_ConfigData():
    conf = ConfigData()
    assert conf is not None


# Generated at 2022-06-20 13:34:07.292047
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass

# Generated at 2022-06-20 13:34:14.063909
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    plugin = MockPlugin()
    config_data = ConfigData()
    setting = MockSetting(name="TEST_NAME")

    config_data.update_setting(setting, plugin=plugin)

    assert id(config_data.get_setting(plugin=plugin, name=setting.name)) == id(setting)


# Generated at 2022-06-20 13:34:19.159636
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    setting = Setting("test_setting", "test_value", 'foo.bar', 'test_desc', "str")
    config_data.update_setting(setting)

    assert config_data.get_setting("test_setting") == setting


# Generated at 2022-06-20 13:34:21.089536
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data is not None


# Generated at 2022-06-20 13:34:26.125383
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    config_data.update_setting(Setting('g1', 'global', 'g1_value'))
    config_data.update_setting(Setting('p1', 'plugin', 'p1_value', 'p1_type', 'p1_name'))

    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings(Plugin('p1_type', 'p1_name'))) == 1


# Generated at 2022-06-20 13:34:29.431876
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert data.get_settings() == []
    data.update_setting(Setting(name='foo', value='bar'))
    assert data.get_settings() == [Setting(name='foo', value='bar')]

# Generated at 2022-06-20 13:34:33.206436
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-20 13:34:44.677429
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('test_setting', value='test_value', origin='test_origin'))
    config_data.update_setting(ConfigSetting('test_setting1', value='test_value', origin='test_origin'), plugin=Plugin('test_type', 'test_name'))

    setting = config_data.get_setting('test_setting')
    setting1 = config_data.get_setting('test_setting1')
    setting2 = config_data.get_setting('test_setting2')
    assert setting.name == 'test_setting'
    assert setting.value == 'test_value'
    assert setting.origin == 'test_origin'
    assert setting1.name == 'test_setting1'
    assert setting1.value == 'test_value'
   

# Generated at 2022-06-20 13:34:53.253293
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()

    from ansible.config.setting import Setting
    from ansible.config.constants import ConfigAttribute

    # General usage
    setting = Setting('DEPRECATION_WARNINGS',
                      'yes',
                      ConfigAttribute.BOOLEAN,
                      "Enable or disable warnings for deprecated features.")
    data.update_setting(setting)
    assert data.get_setting('DEPRECATION_WARNINGS')

    # Plugin usage
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader.get('cache', 'memory')
    setting = Setting('timeout',
                      '120',
                      ConfigAttribute.INTEGER,
                      "Duration in seconds to keep the cache data in memory before expiring")
    data.update_setting(setting, plugin)
    assert data.get_setting('timeout', plugin)

# Generated at 2022-06-20 13:35:03.843907
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import datetime
    from ansible.config.setting import Setting

    a = Setting('a', '', 'foo', 'string', ['a', 'b', 'c', 'd'])
    b = Setting('a', '', 'foo', 'string', ['a', 'b', 'c', 'd'])
    c = Setting('c', '', 'foo', 'string', ['a', 'b', 'c', 'd'])
    d = Setting('d', '', 'foo', 'string', ['a', 'b', 'c', 'd'])

    # no plugin
    config_data = ConfigData()

    config_data.update_setting(a)
    config_data.update_setting(b)
    config_data.update_setting(c)


# Generated at 2022-06-20 13:35:12.829235
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    NonePlugin = object
    NonePlugin.name = None
    NonePlugin.type = None
    config_data.update_setting(Setting('setting_1', 'value_1'))
    config_data.update_setting(Setting('setting_2', 'value_2', 'description_2'))

    assert len(config_data.get_settings(NonePlugin)) == 2



# Generated at 2022-06-20 13:35:20.749174
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Test invalid values
    print("------ Test: Invalid values ------")
    print("Test plugin with value None")
    print(config_data.get_settings(None))
    print("Test plugin with value string")
    print(config_data.get_settings("string"))
    print("Test plugin with value int")
    print(config_data.get_settings(1))
    print("Test plugin with value array")
    print(config_data.get_settings(["string1", "string2"]))

    # Test valid values
    print("------ Test: Valid values ------")
    # Test empty config data
    print("Test empty config data")
    print(config_data.get_settings())
    print(config_data.get_settings())

    # Test global setting
    print("Test global setting")

# Generated at 2022-06-20 13:35:23.101657
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}

# Generated at 2022-06-20 13:35:25.628899
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    setting = ConfigSetting("ansible_port", "22")

    data.update_setting(setting)

    assert data.get_setting("ansible_port") == setting

# Generated at 2022-06-20 13:35:35.663236
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Arrange
    c = ConfigData()
    c._global_settings = {"setting1":{"name":"setting1", "default":True, "description":"description1"},
                          "setting2":{"name":"setting2", "default":True, "description":"description2"},
                          "setting3":{"name":"setting3", "default":True, "description":"description3"}}
    c._plugins = {'connection': {'ssh': {'paramiko_lib': {'name': 'paramiko_lib',
                                                         'default': None,
                                                         'description': 'The paramiko library to use.'}}}}

# Generated at 2022-06-20 13:35:49.486430
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from plugin_setting import PluginSetting
    from plugin_loader import PluginLoader

    config_data = ConfigData()
    plugin_loader = PluginLoader()

    # update a setting with value "Hello"
    setting = PluginSetting(name='greeting', value='Hello')
    config_data.update_setting(setting)

    # retrieve the setting back
    value = config_data.get_setting(setting.name).value
    print(value)
    if value != setting.value:
        print('Error: Test fail to retrieve a global setting')

    plugin = plugin_loader.get_plugin('module')
    assert plugin is not None

    # update a setting with value "World"
    setting = PluginSetting(name='greeting', value='World')
    config_data.update_setting(setting, plugin)

    # retrieve the setting back


# Generated at 2022-06-20 13:35:56.504527
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    from ansible.plugins.loader import PluginLoader

    from ansible.plugins.connection import NetworkConnection
    from ansible.plugins.connection.network_cli import Connection as NetworkCliConnection
    from ansible.plugins.connection.network_httpapi import Connection as NetworkHttpApiConnection

    settings = config_data.get_settings()
    assert len(settings) == 0

    plugin = PluginLoader.load_plugin(NetworkConnection, 'network_cli')
    settings = config_data.get_settings(plugin)
    assert len(settings) == 0

    plugin = PluginLoader.load_plugin(NetworkCliConnection, 'network_cli')
    settings = config_data.get_settings(plugin)
    assert len(settings) == 0


# Generated at 2022-06-20 13:36:03.626154
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    setting1 = Setting(name="test", value="test_value")
    plugin = Plugin(type="test_type", name="test_name")
    config.update_setting(setting1)
    config.update_setting(setting1, plugin)
    assert config.get_setting("test") == setting1
    assert config.get_setting("test", plugin) == setting1


# Generated at 2022-06-20 13:36:07.681473
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config is not None


# Generated at 2022-06-20 13:36:15.669553
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    setting1 = Setting(name='setting1', value='value1', plugin_type=PluginType.CONNECTION, plugin_name='local')
    setting2 = Setting(name='setting2', value='value2', plugin_type=PluginType.CONNECTION, plugin_name='local')
    setting3 = Setting(name='setting3', value='value3', plugin_type=PluginType.MODULE, plugin_name='setup')
    setting4 = Setting(name='setting4', value='value4', plugin_type=PluginType.MODULE, plugin_name='setup')

    plugin_type = PluginType.CONNECTION
    plugin_name = 'local'
    settings = config_data.get_settings(plugin=Plugin(plugin_type, plugin_name))
    assert settings == []


# Generated at 2022-06-20 13:36:24.330404
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:36:28.921038
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    assert len(config_data._global_settings) == 2
    assert config_data.get_settings(). __sizeof__() == 2
    assert config_data.get_setting('setting1').name == 'setting1'


# Generated at 2022-06-20 13:36:37.305260
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    setting_1 = Setting("behavior","lookup_plugins", "shorten", 1, "/test/test_file")
    setting_2 = Setting("behavior","lookup_plugins", "find", 1, "/test/test_file")

    config = ConfigData()
    config.update_setting(setting_1)
    config.update_setting(setting_2)

    result = config.get_settings()
    assert result[0].name == "shorten"
    assert result[1].name == "find"

# Generated at 2022-06-20 13:36:41.195860
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data, object)


# Generated at 2022-06-20 13:36:43.006697
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert not config_data.get_settings()
    assert not config_data.get_settings(None)

# Generated at 2022-06-20 13:36:47.641062
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-20 13:36:59.763829
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data_obj = ConfigData()

    class Plugin(object):
        def __init__(self, type, name):
            self._type = type
            self._name = name

        def get_name(self):
            return self._name

        def get_type(self):
            return self._type

    class PluginSetting(object):
        def __init__(self, name, value):
            self._name = name
            self._value = value

        def get_name(self):
            return self._name

        def get_value(self):
            return self._value

    global_setting = PluginSetting('global_setting', 'value')
    plugin_setting = PluginSetting('plugin_setting', 'value')
    plugin = Plugin('type', 'name')

    config_data_obj.update_setting(global_setting)


# Generated at 2022-06-20 13:37:08.440907
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    plugin = ConfigPlugin(name='test_plugin', type='test_type')
    setting = ConfigSetting(name='test_setting', plugin=plugin)
    cd.update_setting(setting)
    settings = cd.get_settings(plugin)
    assert len(settings) == 1, 'test_ConfigData_update_setting failed: 1'
    setting_test = settings[0]
    assert setting_test.name == 'test_setting', 'test_ConfigData_update_setting failed: 2'
    plugin_test = setting_test.plugin
    assert plugin_test.name == 'test_plugin', 'test_ConfigData_update_setting failed: 3'
    assert plugin_test.type == 'test_type', 'test_ConfigData_update_setting failed: 4'

# Generated at 2022-06-20 13:37:10.388043
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert len(config._global_settings) == 0
    assert len(config._plugins) == 0


# Generated at 2022-06-20 13:37:17.159861
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin()
    setting = Setting('setting', 'value')
    config_data.update_setting(setting, plugin)
    setting2 = Setting('setting2', 'value2')
    config_data.update_setting(setting2, plugin)
    setting3 = Setting('setting3', 'value3')
    config_data.update_setting(setting3)

    settings = config_data.get_settings()
    assert len(settings) == 3
    assert settings[0].name == 'setting3'
    assert settings[1].name == 'setting'
    assert settings[2].name == 'setting2'

    settings = config_data.get_settings(plugin)
    assert len(settings) == 2
    assert settings[0].name == 'setting'

# Generated at 2022-06-20 13:37:31.482265
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    plugin = Plugin('cloud', 'azure', 'connection')
    plugin1 = Plugin('cloud', 'azure', 'connection2')
    plugin2 = Plugin('cloud', '', 'connection2')

    setting1 = AnsibleSetting('test_setting', 'test_value')
    setting2 = AnsibleSetting('test_setting1', 'test_value1')

    config_data.update_setting(setting1, plugin)
    config_data.update_setting(setting2)

    assert config_data.get_setting('test_setting') == setting2
    assert config_data.get_setting('test_setting') != setting1
    assert config_data.get_setting('test_setting1') == setting2
    assert config_data.get_setting('test_setting1') != setting1

    assert config

# Generated at 2022-06-20 13:37:46.308758
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from unit.mock import Mock, patch
    from ansible.module_utils.config_data import ConfigData
    test_config_data = ConfigData()

    # Testing when plugin is None
    test_setting = Mock(name = 'test_setting')
    test_config_data.update_setting(test_setting)
    assert test_config_data.get_settings() == [test_setting], "get_settings() should return a list of 'Settings' when plugin is None"

    # Testing when plugin exists in 'ConfigData'
    test_plugin = Mock(name = 'test_plugin', type = 'test_type')
    test_config_data.update_setting(test_setting, test_plugin)

# Generated at 2022-06-20 13:37:51.820561
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin_setting = ConfigSetting('test_setting_1', 'BAR', 'text', 'test description')
    config_data.update_setting(plugin_setting)
    assert config_data._global_settings['test_setting_1'] == plugin_setting
    plugin_setting = ConfigSetting('test_setting_2', ['foo', 'bar'], 'list', 'test description')
    config_data.update_setting(plugin_setting)
    assert config_data._global_settings['test_setting_2'] == plugin_setting
    plugin_setting = ConfigSetting('test_setting_3', {'foo': 'bar'}, 'dict', 'test description')
    config_data.update_setting(plugin_setting)
    assert config_data._global_settings['test_setting_3'] == plugin_setting


# Generated at 2022-06-20 13:38:03.875834
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    data = ConfigData()
    assert(len(data.get_settings()) == 0)

    from units.mock.loader import DictDataLoader
    from units.plugins.loader import PluginLoader
    from ansible.plugins.loader import find_plugin_file
    from ansible.plugins import get_all_plugin_loaders
    from ansible.plugins.loader import get_all_plugin_names


# Generated at 2022-06-20 13:38:05.244118
# Unit test for constructor of class ConfigData
def test_ConfigData():
  assert ConfigData()._global_settings == {} and ConfigData()._plugins == {}

# Generated at 2022-06-20 13:38:14.962472
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    print("test_ConfigData_get_setting")

    from ansible.plugins.loader import PluginLoader

    test_data = ConfigData()
    test_data.update_setting(Setting(name='default_roles_path', value='/usr/share/ansible/roles:/etc/ansible/roles', plugin=None))

    lookup_plugin = PluginLoader('lookup', 'lookup').get_plugin('files')

    # Try to get a setting that doesn't exist
    assert test_data.get_setting('foo', plugin=lookup_plugin) is None

    # Try to get a setting that does exist

# Generated at 2022-06-20 13:38:16.522510
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    assert not config.get_settings()


# Generated at 2022-06-20 13:38:25.170760
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    
    # Initialize an object of class ConfigData
    config = ConfigData()

    # Create a new plugin
    plugin = Plugin(type='action_plugin', name='my_plugin', path='/some/path/my_plugin')

    # Create a new configuration setting
    setting = Setting(name='some', description='some description')
    config.update_setting(setting=setting, plugin=plugin)

    # Get the setting with the specified attributes
    assert config.get_setting(name='some', plugin=plugin) == setting
    assert config.get_setting(name='some', plugin=None) is None
    assert config.get_setting(name='other', plugin=plugin) is None
    assert config.get_setting(name='other', plugin=None) is None



# Generated at 2022-06-20 13:38:32.834243
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import types
    import unittest
    import yaml

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.compat.ipaddress import ip_address
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    from ansible.cli.arguments import options as cli_options
    from ansible.config.manager import ConfigManager, Setting, load_config_file

    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 1

    sample_config_data = """
[defaults]
timeout = 1
    """

    cli_args = ['ansible', '-m', 'setup']

   

# Generated at 2022-06-20 13:38:35.373077
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    assert configData.get_setting("vault_password_file") is None


# Generated at 2022-06-20 13:38:52.894265
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    assert len(config_data._plugins) == 0

    setting = Setting(name='test', value='a value', origin='a origin')
    config_data.update_setting(setting)
    assert config_data._global_settings['test'].value == 'a value'

    setting = Setting(name='test', value='a new value', origin='a origin')
    config_data.update_setting(setting)
    assert config_data._global_settings['test'].value == 'a new value'


# Generated at 2022-06-20 13:39:02.165114
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    class Plugin:
        def __init__(self, type=None, name=None):
            self.type = type
            self.name = name
        @staticmethod
        def get(name = "foo"):
            return Plugin(type = 'action', name = name)

    class Setting:
        def __init__(self, name=None, value=None, origin=None, priority=None, version=None, lineage=None,
                     hash_value=None, plugin=None, plugin_file=None, cache=None, cache_plugin_path=None):
            self.name = name
            self.value = value
            self.origin = origin
            self.priority = priority
            self.version = version
            self.lineage = lineage
            self.hash_value = hash_value
            self.plugin = plugin
            self.plugin

# Generated at 2022-06-20 13:39:11.500639
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.config_loader import PluginConfigSetting

    config = ConfigData()

    config.update_setting(PluginConfigSetting('one', 'value'))
    config.update_setting(PluginConfigSetting('two', 'two value'))

    assert config.get_setting('one')
    assert config.get_setting('one', plugin=ImmutableDict(dict(name='invalid', type='invalid')))
    assert config.get_setting('one', plugin=ImmutableDict(dict(name='new-name', type='new-type')))
    assert config.get_setting('two')


# Generated at 2022-06-20 13:39:14.033555
# Unit test for constructor of class ConfigData
def test_ConfigData():
    conf = ConfigData()

    assert conf._global_settings == {}
    assert conf._plugins == {}


# Generated at 2022-06-20 13:39:18.667701
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.get_settings()


# Generated at 2022-06-20 13:39:25.758101
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    global_settings = {'ansible_user': 'user1', 'ansible_ssh_pass': 'pass1'}
    plugin_settings = {}
    config_data = ConfigData()
    config_data._global_settings = global_settings
    config_data._plugins = plugin_settings
    settings = config_data.get_settings()
    assert settings == [global_settings['ansible_user'], global_settings['ansible_ssh_pass']]


# Generated at 2022-06-20 13:39:34.123989
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # The function should have no effect, because the config settings (Docker) are not use in the dynamic inventory script
    config_data = ConfigData()
    config_data.update_setting({"name": "var1"})
    assert config_data.get_settings() == [{"name": "var1"}]

    # The function should have no effect, because the config settings (plugin) is not use
    config_data = ConfigData()
    config_data.update_setting({"name": "var1"}, {"type": "plugin", "name": "nagios"})
    assert config_data.get_settings() == []

    # The function should add the config settings (global), because the settings is about plugin we use
    config_data = ConfigData()

# Generated at 2022-06-20 13:39:46.303875
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test Object
    config_data = ConfigData()
    # Test Variable
    test_data = {
        'name': 'test_name',
        'value': 'test_value',
        'plugin_type': 'test_type',
        'plugin_name': 'test_name',
        'section_name': 'test_section_name'
    }
    # Test update of global setting
    config_data.update_setting(ConfigSetting(test_data))
    assert config_data.get_setting('test_name') == ConfigSetting(test_data)
    # Test update of plugin specific setting
    config_data.update_setting(ConfigSetting(test_data), ConfigPlugin(test_data))
    assert config_data.get_setting('test_name', ConfigPlugin(test_data)) == ConfigSetting(test_data)




# Generated at 2022-06-20 13:39:47.700122
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0

# Generated at 2022-06-20 13:39:49.895613
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:40:04.437926
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_setting = ConfigSetting()
    config_setting.name = 'setting_1'
    config_setting.value = 'value_1'
    config_data.update_setting(config_setting)
    assert len(config_data.get_settings()) == 1


# Generated at 2022-06-20 13:40:12.274858
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = {
        "has_wildcards": False,
        "value": "",
        "is_secret": False,
        "is_unsafe": False,
        "is_bypass_checks": False,
        "plugin_type": "",
        "plugin_name": "",
        "name": "",
    }
    config_data.update_setting(setting)
    assert setting == config_data.get_setting("")
    assert setting == config_data.get_setting("", None)

# Generated at 2022-06-20 13:40:24.445221
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    # Set plugins to an empty dictionary before testing the method update_setting of class ConfigData
    config_data._plugins = {}
    # Create a test object of class Setting with a name of "foo"
    from ansible.plugins.loader import Setting
    setting = Setting("foo")
    config_data.update_setting(setting, None)
    # Check the setting has been updated successfully
    assert config_data._global_settings["foo"] == setting
    # Create a test object of class Plugin with a type of "foo" and a name of "bar"
    from ansible.plugins.loader import Plugin
    plugin = Plugin("foo", "bar")
    config_data.update_setting(setting, plugin)
    # Check the setting has been updated successfully

# Generated at 2022-06-20 13:40:31.180261
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    setting = dict(name='ANSIBLE_CALLBACK_PLUGINS', value='/usr/share/ansible/plugins/callback')
    cd.update_setting(setting)
    assert cd._global_settings['ANSIBLE_CALLBACK_PLUGINS']['name'] == 'ANSIBLE_CALLBACK_PLUGINS'
    assert cd._global_settings['ANSIBLE_CALLBACK_PLUGINS']['value'] == '/usr/share/ansible/plugins/callback'
    assert cd._global_settings['ANSIBLE_CALLBACK_PLUGINS']['plugin'] is None


# Generated at 2022-06-20 13:40:42.218078
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert config_data.get_settings() == []

    config_data.update_setting(Setting("defaults_foo_bar", "bar", 'path', 'scalar'))
    config_data.update_setting(Setting("defaults_spam_eggs", "eggs", 'path', 'scalar'))
    config_data.update_setting(Setting("callback_foo_bar", "bar", 'path', 'scalar'), Plugin("callback", "foo"))
    config_data.update_setting(Setting("callback_spam_eggs", "eggs", 'path', 'scalar'), Plugin("callback", "spam"))


# Generated at 2022-06-20 13:40:50.326097
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    class Plugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class Setting:
        def __init__(self, name):
            self.name = name

    plugin_1 = Plugin("type_1", "name_1")
    plugin_2 = Plugin("type_2", "name_2")
    plugin_3 = Plugin("type_3", "name_3")
    plugin_4 = Plugin("type_1", "name_4")

    setting_1 = Setting("setting_1")
    setting_2 = Setting("setting_2")
    setting_3 = Setting("setting_3")
    setting_4 = Setting("setting_4")
    setting_5 = Setting("setting_5")

# Generated at 2022-06-20 13:40:56.035897
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # init config data
    config_data = ConfigData()

    # test global setting
    setting = config_data.get_setting("default_module_name")
    assert setting is None

    #test settting for a specific module
    module_name = "yum"
    module_type = "module_utils"
    plugin_type = "module_utils"
    plugin_name = module_type + "/" + module_name
    setting = config_data.get_setting("module_name", plugin_name, plugin_type)
    assert setting is None



# Generated at 2022-06-20 13:41:00.280919
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cfgdata = ConfigData()
    plugin = BaseConfigDataPlugin()
    plugin.name = 'Plugin1'
    plugin.type = 'type1'
    setting = BaseConfigDataSetting()
    setting.name = 'Setting1'
    setting.value = 'Test1'
    cfgdata.update_setting(setting, plugin)


# Generated at 2022-06-20 13:41:14.594647
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings = [
        {
            'name': 'name_1',
            'value': 'value_1',
            'plugin': {'name': 'plugin_name_1', 'type': 'plugin_type_1'}
        },
        {
            'name': 'name_2',
            'value': 'value_2',
            'plugin': {'name': 'plugin_name_2', 'type': 'plugin_type_2'}
        },
        {
            'name': 'name_3',
            'value': 'value_3',
            'plugin': None
        }
    ]

    settings = [Setting(**x) for x in settings]

    data = ConfigData()

    for s in settings:
        data.update_setting(s, s.plugin)


# Generated at 2022-06-20 13:41:25.419612
# Unit test for constructor of class ConfigData
def test_ConfigData():
    new_global_settings = {
        "name1": "value1",
        "name2": "value2",
    }
    new_plugins = {
        "type1": {
            "name1": {
                "name3": "value3",
                "name4": "value4",
            },
            "name2": {
                "name5": "value5",
            }
        },
        "type2": {
            "name3": {
                "name6": "value6",
            }
        }
    }
    config_data = ConfigData()
    assert not config_data._global_settings
    assert not config_data._plugins
    config_data._global_settings = new_global_settings
    config_data._plugins = new_plugins
    assert config_data._global_settings == new_

# Generated at 2022-06-20 13:41:50.210845
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    settings = ConfigData()
    module_type = "module"
    module_name = "ping"
    module_setting_name = "ping_timeout"
    module_setting_value = "100"
    setting_key = "ANSIBLE_" + module_setting_name.upper()
    config_value = module_setting_name + " = " + module_setting_value
    settings.update_setting(Setting(plugin_name=module_name, plugin_type=module_type, name=module_setting_name, key=setting_key, value=config_value))

    assert settings.get_setting(module_setting_name, Plugin(name=module_name, type=module_type)).value == config_value


# Generated at 2022-06-20 13:41:58.490046
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    
    configData = ConfigData()
    configSetting = ConfigSetting('Assignee', '', 'Project-level assignment', 'Ansible', False, False)
    
    configData.update_setting(configSetting)
    #assert(configData.get_setting('Assignee').name == 'Assignee')
    
    

# Generated at 2022-06-20 13:42:05.185399
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()
    plugin_loader = PluginLoader(None, config_data=config_data)

    action_plugin = plugin_loader.get('action', 'service')
    assert config_data.get_setting('foo', action_plugin) is None

    config_data.update_setting('foo', action_plugin)
    assert config_data.get_setting('foo', action_plugin) == 'foo'


# Generated at 2022-06-20 13:42:14.108786
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import pytest
    from unit.mock import Mock
    config_data = ConfigData()
    plugin = Mock(type='test_type', name='test_name')
    setting = Mock(name='test_setting')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('test_setting', plugin) == setting

# Generated at 2022-06-20 13:42:17.108782
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_setting("setting") is None
    assert not config_data.get_settings()


# Generated at 2022-06-20 13:42:24.570040
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    configdata = ConfigData()
    assert len(configdata._global_settings) == 0 and len(configdata._plugins) == 0
    setting = {'name': 'max_fail_percentage', 'value': '2'}
    configdata.update_setting(setting)
    assert len(configdata._global_settings) == 1 and len(configdata._plugins) == 0
    assert configdata._global_settings['max_fail_percentage'].name == 'max_fail_percentage'
    plugin = {'type': 'lookup', 'name': 'redis_kv'}
    setting = {'name': 'host', 'value': '192.168.1.1'}
    configdata.update_setting(setting, plugin)
    assert len(configdata._global_settings) == 1 and len(configdata._plugins)

# Generated at 2022-06-20 13:42:32.983617
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('g_setting'))
    config_data.update_setting(Setting('p_setting'), Plugin('p_type', 'p_name'))

    assert config_data.get_setting('g_setting').name == 'g_setting'
    assert config_data.get_setting('p_setting', Plugin('p_type', 'p_name')).name == 'p_setting'


# Generated at 2022-06-20 13:42:44.681922
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    global_setting = _ConfigSetting('user')
    config_data.update_setting(global_setting)
    assert config_data.get_setting('user') == global_setting

    local_setting = _ConfigSetting('user', 'connection', 'ssh')
    config_data.update_setting(local_setting)
    assert config_data.get_setting('user', local_setting.plugin) == local_setting

    config_data = ConfigData()
    local_setting = _ConfigSetting('user', 'connection', 'ssh')
    config_data.update_setting(local_setting)

    assert config_data.get_setting('user', local_setting.plugin) == local_setting
    assert config_data.get_setting('user') is None



# Generated at 2022-06-20 13:42:46.926739
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()

    assert(config._global_settings == {})
    assert(config._plugins == {})



# Generated at 2022-06-20 13:42:57.761189
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    # Valid input
    plugin = Plugin(type="connection",name="plugin_name")
    setting = Setting(name="name_1", value="value_1", section="section_name")
    config_data.update_setting(setting, plugin)

    # Valid input with None plugin
    setting = Setting(name="name_2", value="value_2", section="section_name")
    config_data.update_setting(setting)

    # Invalid Input
    plugin = Plugin(type="wrong_type",name="plugin_name")
    setting = Setting(name="name_3", value="value_3", section="section_name")
    config_data.update_setting(setting, plugin)

    assert(config_data._global_settings == {'name_2': setting})