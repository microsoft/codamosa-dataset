

# Generated at 2022-06-20 13:33:16.182852
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert (config.get_setting("nonexistent") is None)
    assert (config.get_settings() == [])


# Generated at 2022-06-20 13:33:27.762018
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(
        PluginSetting('name1', 'global1', 'default1', 'env1', 'path1', 'type1'))
    config.update_setting(
        PluginSetting('name2', 'global2', 'default2', 'env2', 'path2', 'type2'), Plugin(Plugin.DEFAULT, 'pluginA'))
    config.update_setting(
        PluginSetting('name3', 'global3', 'default3', 'env3', 'path3', 'type3'), Plugin(Plugin.DEFAULT, 'pluginB'))
    assert config.get_setting('name1') == PluginSetting('name1', 'global1', 'default1', 'env1', 'path1', 'type1')

# Generated at 2022-06-20 13:33:37.991450
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    cd.update_setting(Setting('fact_caching_timeout', 3600))
    cd.update_setting(Setting('max_fail_percentage', 15))
    cd.update_setting(Setting('forks', 1))
    cd.update_setting(Setting('action_plugin_path', 'plugins/actions'))
    assert cd.get_setting('action_plugin_path') == Setting('action_plugin_path', 'plugins/actions')
    assert cd.get_setting('fact_caching_timeout') == Setting('fact_caching_timeout', 3600)
    assert cd.get_setting('max_fail_percentage') == Setting('max_fail_percentage', 15)

# Generated at 2022-06-20 13:33:41.088170
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("setting1")

# Generated at 2022-06-20 13:33:46.880205
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()

    # Test with a global setting.
    setting = Setting('ansible_version', '2.4.0')
    data.update_setting(setting)
    assert data.get_setting('ansible_version') == setting

    # Test with a plugin setting.
    setting = Setting('ansible_version', '2.4.0', Plugin('connection', 'local'))
    data.update_setting(setting)
    assert data.get_setting('ansible_version', setting.plugin) == setting



# Generated at 2022-06-20 13:33:48.621871
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config._global_settings = {'name1': 'value'}
    assert config.get_setting('name1') == 'value'


# Generated at 2022-06-20 13:33:51.051940
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    setting = Setting('my_var', 'value')
    plugin = Plugin('my_plugin', 'my_type')
    cd.update_setting(setting)
    cd.update_setting(setting, plugin)
    print(cd.get_setting('my_var', plugin))
    print(cd.get_setting('my_var'))


# Generated at 2022-06-20 13:33:58.305255
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_data = ConfigData()

    class Setting(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value
            self.path = None

    global_setting = Setting('ansible_python_interpreter', '/usr/bin/python')
    test_data.update_setting(global_setting)

    assert global_setting in test_data.get_settings()
    assert global_setting == test_data.get_setting('ansible_python_interpreter')


# Generated at 2022-06-20 13:34:06.896090
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    def create_plugin(name, type_):
        class plugin(object):
            def __init__(self, name, type_):
                self.name = name
                self.type = type_
        return plugin(name, type_)

    foo_plugin = create_plugin("foo", "test")
    bar_plugin = create_plugin("bar", "test")

    class setting(object):
        def __init__(self, name):
            self.name = name

    foo_setting = setting("foo")
    init_setting = setting("__init__")

    def test(plugin, setting, expected_name, expected_type, expected_val):
        config_data.update_setting(setting, plugin)
        returned_setting = config_data.get_setting(expected_name, plugin)


# Generated at 2022-06-20 13:34:18.481737
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}
    config_data.update_setting(Setting('foo', 'bar', 1))
    assert config_data._global_settings == {'foo': Setting('foo', 'bar', 1)}
    assert config_data._plugins == {}
    config_data.update_setting(Setting('foo', 'bar', 1), Plugin('lookup', 'test_lookup'))
    assert config_data._global_settings == {'foo': Setting('foo', 'bar', 1)}
    assert config_data._plugins == {'lookup': {'test_lookup': {'foo': Setting('foo', 'bar', 1)}}}


# Generated at 2022-06-20 13:34:22.083457
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data


# Generated at 2022-06-20 13:34:23.709780
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data

# Generated at 2022-06-20 13:34:24.894308
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass


# Generated at 2022-06-20 13:34:30.519977
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    plugin_type = "connection"
    plugin_name = "my_plugin"
    from ansible.plugins.loader import get_plugin_class
    plugin = get_plugin_class(plugin_type, plugin_name)
    setting = plugin.get_option("host")
    config_data.update_setting(setting)
    config_data.update_setting(setting, plugin)


# Generated at 2022-06-20 13:34:37.121097
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    configData.update_setting(Setting('ANSIBLE_MODULE_ARGS', '{ "msg": "Hello World!" }'))
    configData.update_setting(Setting('ANSIBLE_MODULE_ARGS', '{ "msg": "Hello World!" }', 'command'))
    assert configData.get_setting('ANSIBLE_MODULE_ARGS').name == 'ANSIBLE_MODULE_ARGS'
    assert configData.get_setting('ANSIBLE_MODULE_ARGS', PluginData()).name == 'ANSIBLE_MODULE_ARGS'
    assert configData.get_setting(
        'ANSIBLE_MODULE_ARGS',
        PluginData('command')
    ).name == 'ANSIBLE_MODULE_ARGS'


# Generated at 2022-06-20 13:34:45.669004
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # create settings for testing
    global_setting = ConfigData.Setting("SOME_GLOBAL_SETTING", "Value1")

    # create test plugin object
    plugin = ConfigData.Plugin("SomePlugin", "Type1")

    # create test config data object
    config_data = ConfigData()

    # test global setting
    config_data.update_setting(global_setting)
    assert config_data.get_setting("SOME_GLOBAL_SETTING") == global_setting

    # test plugin setting
    plugin_setting = ConfigData.Setting("SOME_PLUGIN_SETTING", "Value2")
    config_data.update_setting(plugin_setting, plugin)
    assert config_data.get_setting("SOME_PLUGIN_SETTING", plugin) == plugin_setting

    # assert that adding the same setting

# Generated at 2022-06-20 13:34:58.526265
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # test for global settings
    config = ConfigData()
    config._global_settings = {'ansible_connection': "winrm"}
    setting = config.get_setting('ansible_connection')
    assert setting is not None
    assert setting.value == "winrm"
    # test for plugin settings
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader('connection').get('ssh')
    config._plugins['connection'] = {'ssh': {'ansible_ssh_private_key_file': "~/.ssh/id_rsa"}}
    setting = config.get_setting('ansible_ssh_private_key_file', plugin)
    assert setting is not None
    assert setting.value == "~/.ssh/id_rsa"


# Generated at 2022-06-20 13:35:03.115499
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting("test")

# Generated at 2022-06-20 13:35:16.188621
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblelint.config import Rule, Plugin
    from ansiblelint.config.rules import AnsibleLintRule

    rule_name_1 = 'ansible-lint-rule-1'
    rule_id_1 = 'rule-1'
    rule_1 = AnsibleLintRule(rule_name_1,
                             id=rule_id_1,
                             shortdesc='description',
                             description='description',
                             severity='CRITICAL',
                             tags=['formatting'])

    rule_name_2 = 'ansible-lint-rule-2'
    rule_id_2 = 'rule-2'

# Generated at 2022-06-20 13:35:17.441881
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert not config_data



# Generated at 2022-06-20 13:35:28.204414
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Initialise a ConfigData object
    config_data = ConfigData()

    # Create a setting for a plugin and add it to the configuration
    plugin = Plugin('a_type', 'a_name')
    setting1 = Setting('a_setting1', 'a_value1', plugin)
    config_data.update_setting(setting1, plugin)

    # Create another setting for the same plugin and add it to the configuration
    setting2 = Setting('a_setting2', 'a_value2', plugin)
    config_data.update_setting(setting2, plugin)

    # Check that both settings are returned as a list of settings
    assert config_data.get_settings(plugin) == [setting1, setting2],\
        "Settings should be list of two settings"


# Generated at 2022-06-20 13:35:30.523066
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:35:32.770272
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:35:37.958010
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    setting1 = Setting('hash_behavior', 'merge')
    config_data.update_setting(setting1)

    assert config_data.get_setting('hash_behavior') == setting1

# Generated at 2022-06-20 13:35:41.315945
# Unit test for constructor of class ConfigData
def test_ConfigData():

    configData = ConfigData()
    assert configData._global_settings == {}
    assert configData._plugins == {}


# Generated at 2022-06-20 13:35:46.669974
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData() is not None
    assert len(ConfigData()._global_settings) == 0
    assert len(ConfigData()._plugins) == 0


# unit test for get_setting method of class ConfigData

# Generated at 2022-06-20 13:35:48.538094
# Unit test for constructor of class ConfigData
def test_ConfigData():
    settings = ConfigData()
    assert settings._global_settings == {}
    assert settings._plugins == {}


# Generated at 2022-06-20 13:35:51.632853
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    # First test -- Testing constructor
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-20 13:35:58.595194
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='test_setting1', value='test_value1', plugin=None))
    config_data.update_setting(Setting(name='test_setting2', value='test_value2', plugin=Plugin('test_plugin_type', 'test_plugin_name')))
    assert len(config_data.get_settings(plugin=None)) == 1
    assert config_data.get_setting('test_setting1', plugin=None).value == 'test_value1'
    assert len(config_data.get_settings(plugin=Plugin('test_plugin_type', 'test_plugin_name'))) == 1

# Generated at 2022-06-20 13:36:00.756736
# Unit test for constructor of class ConfigData
def test_ConfigData():
    d = ConfigData()
    assert d is not None


# Generated at 2022-06-20 13:36:10.724402
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    obj_in = ConfigData()
    assert isinstance(obj_in,ConfigData)
    # How set up a local variable inside the method get_setting?
    # I never seen this.
    obj_out = obj_in.get_setting()
    assert isinstance(obj_out,None)


# Generated at 2022-06-20 13:36:23.287230
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible_collections.testns.testcoll.plugins.module_utils.testconfig import ConfigModule

    data = ConfigData()

    setting = ConfigModule.TestConfig(name='testvar_name', value='testvar_value', 
                                      origin='testvar_origin', plugin=None)
    data.update_setting(setting)

    setting = ConfigModule.TestConfig(name='testvar_name', value='testvar_value', 
                                      origin='testvar_origin', plugin=None)
    data.update_setting(setting)

    setting = ConfigModule.TestConfig(name='testvar_name', value='testvar_value',
                                      origin='testvar_origin', plugin=ConfigModule.TestConfigPlugin(name='test_plugin', path='/', type='module_utils'))

# Generated at 2022-06-20 13:36:26.359474
# Unit test for constructor of class ConfigData
def test_ConfigData():
  configData = ConfigData()
  assert configData is not None

import os
import re
import subprocess
import yaml
import json

PLUGIN_PATH = "./lib/ansible/plugins"
PLUGIN = "plugins"


# Generated at 2022-06-20 13:36:30.172737
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert config_data.get_settings() == []

    config_data._global_settings['setting_1'] = 'value_1'
    config_data._global_settings['setting_2'] = 'value_2'

    assert config_data.get_settings() == ['value_1', 'value_2']

# Generated at 2022-06-20 13:36:41.531094
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    class Setting(object):
        def __init__(self, name):
            self.name = name

    assert config_data.get_settings() == []
    assert config_data.get_settings('plugin') == []

    global_setting = Setting('global_setting')
    plugin_setting = Setting('plugin_setting')

    config_data.update_setting(global_setting)

    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0].name == 'global_setting'

    assert len(config_data.get_settings('plugin')) == 0

    config_data.update_setting(plugin_setting, 'plugin')

    assert len(config_data.get_settings('plugin')) == 1

# Generated at 2022-06-20 13:36:44.047273
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin_test = ConfigData()
    d= dict(name="host", value="localhost", origin="ini")
    
    # Empty plugin
    plugin_test.update_setting(d)

    assert plugin_test.get_setting("host") == d


# Generated at 2022-06-20 13:36:50.560202
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    setting = Settings()
    config_data.update_setting(setting)
    setting = Settings()
    config_data.update_setting(setting)
    setting = Settings()
    config_data.update_setting(setting)

    assert len(config_data.get_settings()) == 3
    assert len(config_data.get_settings(plugin=None)) == 3

    pytest.raises(AttributeError, config_data.get_settings)
    pytest.raises(AttributeError, config_data.get_setting, '', '', '')


# Generated at 2022-06-20 13:36:54.208102
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert 'bar' == config_data.get_setting('foo')
    

# Generated at 2022-06-20 13:37:00.366168
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # create new object instance
    configdata_obj = ConfigData()
    # add settings to the global settings and a given plugin
    configdata_obj.update_setting(ConfigSetting("type", "PluginLoader"), None)
    configdata_obj.update_setting(ConfigSetting("working_dir", "/some/path"), Plugin("action", "script"))

    # get setting(s)
    settings = configdata_obj.get_settings()
    assert len(settings) == 1 and settings[0].name == "type"

    settings = configdata_obj.get_settings(plugin=Plugin("action", "script"))
    assert len(settings) == 1 and settings[0].name == "working_dir"


# Generated at 2022-06-20 13:37:08.758169
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Initialize test data
    from ansible.plugins import PluginLoader
    from ansible.models.ansible_base_config_data import AnsibleBaseConfigData

    config_data = ConfigData()
    plugins = PluginLoader().all()

    config_data.update_setting(AnsibleBaseConfigData(name='setting1', value='setting1', plugin=plugins['callback']['human_log'], type='callback'))

    # Set variable values
    setting_name = 'setting1'
    plugin_type = 'callback'
    plugin_name1 = 'human_log'
    plugin_name2 = 'debug'

    # Test case 1: testing when valid plugin is supplied
    actual_setting1 = config_data.get_setting(setting_name, plugins[plugin_type][plugin_name1])
    expected_setting1 = Ans

# Generated at 2022-06-20 13:37:20.531607
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = PluginDefinition(plugin_type='test', plugin_name='test')
    setting = SettingDefinition(name='test', value=1, default=1, values=None)
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting(setting.name, plugin) == setting


# Generated at 2022-06-20 13:37:30.935091
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    global_settings = {'foo': 'bar', 'bar': 'baz'}
    config = ConfigData()
    config._global_settings = global_settings

    # Test global settings
    assert global_settings['foo'] == config.get_setting('foo')
    assert global_settings['bar'] == config.get_setting('bar')
    # Test global settings with passed plugin
    assert global_settings['foo'] == config.get_setting('foo', 'Plugin')
    assert global_settings['bar'] == config.get_setting('bar', 'Plugin')

    # Test call with unknown name
    assert config.get_setting('xxx') is None
    # Test call with unknown name and plugin
    assert config.get_setting('xxx', 'Plugin') is None
    # Test call with unknown plugin

# Generated at 2022-06-20 13:37:36.377640
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from units.mock.loader import DictDataLoader
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import plugin_loader

    config_data = ConfigData()

    config_data.update_setting(ConfigSetting("param1", "value1", "description 1"))
    config_data.update_setting(ConfigSetting("param1", "value1_alias1", "description 1", "alias1"))

    config_data.update_setting(ConfigSetting("param2", "value2", "description 2"))
    config_data.update_setting(ConfigSetting("param2", "value2_alias1", "description 2", "alias1"))

# Generated at 2022-06-20 13:37:40.426257
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Setup:
    # ConfigData without plugins
    data = ConfigData()

    # Act:
    config = data.get_settings()

    # Assert:
    assert config is None


# Generated at 2022-06-20 13:37:52.019224
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    # test for return None for empty ConfigData
    assert cd.get_setting('foo') is None
    assert cd.get_setting('foo', Plugin('module')) is None

    # test for global setting
    cd.update_setting(Setting('foo', 'bar', plugin=None))
    assert cd.get_setting('foo') == Setting('foo', 'bar', plugin=None)
    assert cd.get_setting('foo', Plugin('module')) == Setting('foo', 'bar', plugin=None)

    # test for plugin setting
    cd.update_setting(Setting('foo', 'baz', plugin=Plugin('module')))
    assert cd.get_setting('foo') == Setting('foo', 'bar', plugin=None)

# Generated at 2022-06-20 13:38:03.924708
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()

    plugin = None
    settings = data.get_settings(plugin)
    assert len(settings) == 0

    setting = Setting('foo', 'bar')
    data.update_setting(setting)
    settings = data.get_settings()
    assert len(settings) == 1
    assert settings[0].name == 'foo'
    assert settings[0].value == 'bar'
    assert settings[0].plugin_type is None
    assert settings[0].plugin_name is None

    data = ConfigData()
    plugin = Plugin('foo', 'bar')
    settings = data.get_settings(plugin)
    assert len(settings) == 0

    setting = Setting('foo', 'bar')
    data.update_setting(setting, plugin)
    settings = data.get_settings(plugin)

# Generated at 2022-06-20 13:38:07.723976
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = { 'name' : 'plugin_1_setting_1', 'value' : 'String' }

    config_data.update_setting(setting)
    settings = config_data.get_settings()

    assert settings[0] == setting

    settings = config_data.get_settings(plugin)


# Generated at 2022-06-20 13:38:08.880404
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd is not None


# Generated at 2022-06-20 13:38:11.136784
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    print(config_data)


# Generated at 2022-06-20 13:38:13.894059
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)
    assert not config_data._global_settings
    assert not config_data._plugins

# Generated at 2022-06-20 13:38:42.623216
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Create config data and add a setting to it
    config_data = ConfigData()
    config_data.update_setting(Setting('debug', 'Unset', 'The debug level'))

    # Test if we can get the setting by using method get_settings
    assert config_data.get_settings().__len__() == 1

    # Test if we can only get the setting if we do not provide a plugin
    assert config_data.get_settings(plugin=None).__len__() == 1

    # Test if we get no setting by using method get_settings when we do provide a plugin
    plugin = Plugin('library', 'test_library')
    assert config_data.get_settings(plugin=plugin).__len__() == 0

    # Test if we get no setting when we provide a invalid plugin

# Generated at 2022-06-20 13:38:54.885658
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from units.mock.loader import DictDataLoader

    from units.compat import unittest
    from ansible.config.setting import Setting

    class TestConfigDataGetSettings(unittest.TestCase):

        def setUp(self):

            self.config_data = ConfigData()
            self.config_data.update_setting(Setting('test_test', 'value', 'test', 'test', DictDataLoader({})))
            self.config_data.update_setting(Setting('test_test2', 'value2', 'test', 'test2', DictDataLoader({})))
            self.config_data.update_setting(Setting('test_test3', 'value3', 'test', 'test3', DictDataLoader({})))

# Generated at 2022-06-20 13:39:01.051914
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('string', 'name', 'value'))
    config_data.update_setting(Setting('string', 'name1', 'value1'))
    assert config_data.get_settings()[0].to_str() == "[string] name: value"
    assert config_data.get_settings()[1].to_str() == "[string] name1: value1"


# Generated at 2022-06-20 13:39:04.539825
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    obj = ConfigData()
    assert None == obj.get_setting("Some setting")
    assert None == obj.get_setting("Some setting", "Plugin")


# Generated at 2022-06-20 13:39:15.811753
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test_data = ConfigData()

    test_data.update_setting(Setting("hostfile", "/etc/hosts"))
    test_data.update_setting(Setting("forks", "10"))
    test_data.update_setting(Setting("timeout", "10"))
    test_data.update_setting(Setting("forks", "100", "ansible", "command_line"))
    test_data.update_setting(Setting("forks", "200", "ansible", "connection"))
    test_data.update_setting(Setting("forks", "300", "ansible", "inventory"))

    assert test_data.get_setting("hostfile").value == "/etc/hosts"
    assert test_data.get_setting("forks").value == "100"

# Generated at 2022-06-20 13:39:25.666121
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('A', 'global-value'))
    assert config_data.get_setting('A').value == 'global-value'

    plugin = Plugin('common', 'test')
    config_data.update_setting(Setting('A', 'local-value'), plugin)
    assert config_data.get_setting('A').value == 'local-value'
    assert config_data.get_setting('A', plugin).value == 'local-value'
    assert config_data.get_setting('A').value == 'global-value'


# Generated at 2022-06-20 13:39:34.057618
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansiblelint.rules.LineTooLongRule import LineTooLongRule
    from ansiblelint.rules.TaskHasLoopRule import TaskHasLoopRule
    from ansiblelint.rules.TaskHasTagRule import TaskHasTagRule
    from ansiblelint.rules.TaskHasWhenRule import TaskHasWhenRule
    from ansiblelint.rules.TrailingWhitespaceRule import TrailingWhitespaceRule
    from ansiblelint.rules.UsingCommandInsteadOfModuleRule import UsingCommandInsteadOfModuleRule
    from ansiblelint.rules.UsingExpandedWithItemsRule import UsingExpandedWithItemsRule

    config_data = ConfigData()

    config_data.update_setting(LineTooLongRule(80, 'off').get_config_setting())

# Generated at 2022-06-20 13:39:39.043484
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    configData = ConfigData()
    import pprint
    pprint.pprint(configData._plugins)
    print(configData._global_settings)
    #print(configData.get_settings())
test_ConfigData_get_settings()

# Generated at 2022-06-20 13:39:47.089671
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    g = ConfigData()
    g.update_setting(Setting(name='name1',value='value1'))
    g.update_setting(Setting(name='name2',value='value2'),plugin=Plugin(type='type1',name='name1'))
    assert g.get_settings()[0].name == 'name1'
    assert g.get_settings(plugin=Plugin(type='type1',name='name1'))[0].name == 'name2'
    assert g.get_settings(plugin=Plugin(type='type2',name='name1')) == []


# Generated at 2022-06-20 13:39:49.577641
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = Setting('group', 'marker', 'group', 'marker')
    config_data.update_setting(setting)
    assert config_data.get_settings()[0].name == 'group'


# Generated at 2022-06-20 13:40:15.948153
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting("test_setting") is None
    assert config_data.get_setting("test_setting", plugin=None) is None
    mock_setting = Mock()
    mock_setting.name = "test_setting"
    config_data.update_setting(mock_setting)
    assert config_data._global_settings["test_setting"] == mock_setting
    config_data.update_setting(mock_setting, None)
    assert config_data._global_settings["test_setting"] == mock_setting
    assert config_data.get_setting("test_setting") == mock_setting
    assert config_data.get_setting("test_setting", plugin=None) == mock_setting


# Generated at 2022-06-20 13:40:26.935344
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    setting1 = ConfigSetting('shallow_clone', 'NewValue')
    setting2 = ConfigSetting('merge', 'NewValue')
    plugin1 = Plugin('module')
    plugin2 = Plugin('callback')
    config.update_setting(setting1)
    config.update_setting(setting2, plugin1)
    config.update_setting(setting2, plugin2)
    assert config.get_settings() is config.get_settings(plugin1) is config.get_settings(plugin2)
    assert config.get_setting('shallow_clone') == config.get_setting('shallow_clone', plugin1) == config.get_setting('shallow_clone', plugin2)
    assert config.get_setting('merge', plugin1) == config.get_setting('merge', plugin2)

# Generated at 2022-06-20 13:40:30.341058
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass



# Generated at 2022-06-20 13:40:34.476081
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    config_data.update_setting(Setting('verbosity', 2))

    assert(len(config_data.get_settings()) == 1)


# Generated at 2022-06-20 13:40:43.916373
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.config.setting import Setting
    from ansible.plugins.loader import PluginLoader, find_plugin

    # First create a fake plugin
    class FakePlugin:
        pass

    fake_plugin = FakePlugin()
    fake_plugin.type = 'test'
    fake_plugin.name = 'fake'

    # Now create a fake setting for it
    fake_setting = Setting('foo', 'bar', 'description')
    fake_setting.origin = 'test'

    # Create an empty ConfigData object
    data = ConfigData()

    # And ensure it can't be found
    assert data.get_setting(fake_setting.name, fake_plugin) is None

    # Add the setting for the plugin to the ConfigData object
    data.update_setting(fake_setting, fake_plugin)

    # And ensure it's there
    setting

# Generated at 2022-06-20 13:40:45.838963
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert len(cd._global_settings) == 0
    assert len(cd._plugins) == 0


# Generated at 2022-06-20 13:40:54.698475
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = ConfigData.Setting('s1', 's1_value', 's1_description')
    config_data.update_setting(setting)
    pair = {'name': 's1', 'value': 's1_value', 'description': 's1_description', 'plugin': None}
    assert config_data.get_setting(setting.name) == pair



# Generated at 2022-06-20 13:41:03.706197
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting("var1") is None
    config_data.update_setting(Setting("var1", "value1"))
    assert config_data.get_setting("var1").value == "value1"
    assert config_data.get_setting("var2") is None
    config_data.update_setting(Setting("var2", "value2"), Plugin("foo", "bar"))
    assert config_data.get_setting("var2") is None
    assert config_data.get_setting("var2", Plugin("foo", "bar")).value == "value2"
    assert config_data.get_setting("var3") is None
    config_data.update_setting(Setting("var3", "value3", Plugin("foo", "bar")))

# Generated at 2022-06-20 13:41:15.095724
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    global_setting = Setting('test1', True, 'test desc')
    plugin1 = Plugin('test_type', 'test_name')
    setting1 = Setting('test2', True, 'test desc')
    setting2 = Setting('test3', True, 'test desc')

    config_data.update_setting(global_setting)
    config_data.update_setting(setting1, plugin1)
    config_data.update_setting(setting2, plugin1)

    assert config_data.get_setting('test1') == global_setting
    assert config_data.get_setting('test2', plugin1) == setting1
    assert config_data.get_setting('test3', plugin1) == setting2

    assert config_data.get_settings() == [global_setting]
    assert config_

# Generated at 2022-06-20 13:41:21.211801
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    configData = ConfigData()
    setting = Setting()
    setting.name = 'x'
    configData.update_setting(setting, plugin=None)
    setting.name = 'y'
    configData.update_setting(setting, plugin=None)
    assert(configData.get_setting('x') is not None)
    assert(configData.get_setting('y') is not None)

    plugin = Plugin()
    plugin.type = 'callback'
    plugin.name = 'mycallback'
    setting.name = 'x'
    configData.update_setting(setting, plugin=plugin)
    setting.name = 'y'
    configData.update_setting(setting, plugin=plugin)
    assert(configData.get_setting('x', plugin=plugin) is not None)

# Generated at 2022-06-20 13:41:48.538998
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin_paths = 'paths'
    plugin_types = ['module', 'doc_fragments', 'lookup', 'filter', 'callback', 'netconf', 'terminal', 'vars']
    plugin_names = ['action', 'async_wrapper', 'callback_module_name', 'connection', 'executor', 'persistent']
    plugin_classes = ['ActionModule', 'AsyncWrapper', 'CallbackModuleName', 'Connection', 'Executor', 'Persistent']

    config_data = ConfigData()
    assert config_data.get_settings() == []

    for plugin_type in plugin_types:
        plugin_info = PluginInfo(plugin_paths=plugin_paths, plugin_type=plugin_type, plugin_name=None, plugin_class=None)

# Generated at 2022-06-20 13:41:55.664594
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Creates an instance of class ConfigData
    cd = ConfigData()
    # Creates an instance of class Setting and set its name to "testname"
    s = Setting()
    s.name = "testname"
    # Creates an instance of class Plugin and sets its type and name to "TestPlugin"
    p = Plugin()
    p.type = "TestPlugin"
    p.name = "TestPlugin"
    # Sets the private attribute _plugins of the instance of ConfigData
    cd._plugins = {p.type: {p.name: {}}}
    # Invokes the method update_setting and checks if it runs succesfully
    cd.update_setting(s,p)
    # Checks the method by comparing the result of method get_setting to the Setting "s"

# Generated at 2022-06-20 13:41:57.701708
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    settings = config_data.get_settings()


# Generated at 2022-06-20 13:42:07.303968
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('string', 'ansible', 'ansible_static_fact', 'this is a string'))
    config_data.update_setting(Setting('integer', 'ansible', 'ansible_static_fact', 42))
    config_data.update_setting(Setting('bool', 'ansible', 'ansible_static_fact', True))

    settings = config_data.get_settings()
    assert len(settings) == 3

    config_data.update_setting(Setting('integer', 'ansible_global', 'ansible_global', 'some integer'))
    config_data.update_setting(Setting('bool', 'ansible_global', 'ansible_global', 'some boolean'))

    settings = config_data.get_settings()
    assert len(settings)

# Generated at 2022-06-20 13:42:19.327784
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    assert config_data.get_setting('NoSetting') is None
    assert config_data.get_setting('NoSetting', 'NoPlugin') is None

    config_data.update_setting('Setting1')
    config_data.update_setting('Setting2', 'Plugin1')
    config_data.update_setting('Setting3', 'Plugin2')
    config_data.update_setting('Setting4', 'Plugin3')

    assert config_data.get_setting('Setting1') is None
    assert config_data.get_setting('Setting1', 'Plugin1') is None
    assert config_data.get_setting('Setting2') is None
    assert config_data.get_setting('Setting2', 'Plugin1') is None
    assert config_data.get_setting('Setting3') is None

# Generated at 2022-06-20 13:42:21.180925
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:42:26.812655
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

# Generated at 2022-06-20 13:42:33.415529
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    from collections import namedtuple
    from ansiblelint import RulesCollection
    Setting = namedtuple('Setting', ['name', 'value', 'plugin_type'])
    setting = Setting('linelength', '80', 'rules')
    config_data.update_setting(setting)
    assert config_data.get_setting('linelength') == setting


# Generated at 2022-06-20 13:42:34.958287
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    plugin = None
    assert [] == config.get_settings(plugin)



# Generated at 2022-06-20 13:42:38.667578
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Initialization
    config_data = ConfigData()

    # get_settings with empty ConfigData
    settings = config_data.get_settings()
    assert settings == []
