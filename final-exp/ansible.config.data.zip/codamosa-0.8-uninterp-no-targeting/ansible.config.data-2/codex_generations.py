

# Generated at 2022-06-20 13:33:11.142384
# Unit test for constructor of class ConfigData
def test_ConfigData():
	assert ConfigData()


# Generated at 2022-06-20 13:33:22.911077
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Prepare fixture
    obj = ConfigData()

    # Test global settings
    obj.update_setting(Setting('foo', 'bar', obj, None))
    obj.update_setting(Setting('baz', 'qux', obj, None))
    obj.update_setting(Setting('quux', 'quuz', obj, None))

    # Test plugin settings
    obj.update_setting(Setting('foo', 'bar', obj, 'itp'), Plugin('itp', 'test_plugin'))
    obj.update_setting(Setting('baz', 'qux', obj, 'itp'), Plugin('itp', 'test_plugin'))
    obj.update_setting(Setting('quux', 'quuz', obj, 'itp'), Plugin('itp', 'test_plugin'))

    settings_global = obj.get_settings()
    settings

# Generated at 2022-06-20 13:33:29.573897
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    setting = {'name': 'setting1', 'value': 'value1', 'origin': 'source1'}
    plugin = {'type': 'collection', 'name': 'collection1'}
    test_get_settings(config_data, setting, value=True, plugin=plugin)

    setting = {'name': 'setting1', 'value': 'value1', 'origin': 'source1'}
    plugin = {'type': 'collection', 'name': 'collection1'}
    test_get_settings(config_data, setting, value=True, plugin=plugin)

    setting = {'name': 'setting2', 'value': 'value2', 'origin': 'source2'}
    plugin = {'type': 'collection', 'name': 'collection2'}

# Generated at 2022-06-20 13:33:35.630091
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('library', 'defaults/name', '/test/test.py'))
    assert config_data.get_setting(None, 'defaults/name') == '/test/test.py'
    assert config_data.get_setting(Plugin('name', 'type'), 'defaults/name') == '/test/test.py'



# Generated at 2022-06-20 13:33:40.085896
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    print("test_ConfigData_get_setting")
    data = ConfigData()
    assert data.get_setting("setting1") is None

if __name__ == "__main__":
    test_ConfigData_get_setting()

# Generated at 2022-06-20 13:33:42.314944
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:33:55.914414
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    plugin = PluginInfo()
    plugin.type = "N"
    plugin.name = "M"
    cd.update_setting(Setting("P", "V"), plugin)
    cd.update_setting(Setting("Q", "W"))
    cd.update_setting(Setting("R", "S"))
    cd.update_setting(Setting("S", "T"))
    assert cd.get_settings(plugin) is not None
    assert cd.get_settings(plugin)[0].name == "P"
    assert cd.get_settings()[0].name == "R"
    assert cd.get_settings()[1].name == "Q"
    assert len(cd.get_settings()) == 2


# Generated at 2022-06-20 13:33:56.880426
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data

# Generated at 2022-06-20 13:34:06.247963
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    plugin_setting = ConfigSetting("setting_name", "setting_value")
    config.update_setting(plugin_setting)
    plugin_setting2 = ConfigSetting("setting_name2", "setting_value2")
    config.update_setting(plugin_setting2)
    print("plugin_setting.name = {}".format(plugin_setting.name))
    print("plugin_setting.value = {}".format(plugin_setting.value))
    print("plugin_setting2.name = {}".format(plugin_setting2.name))
    print("plugin_setting2.value = {}".format(plugin_setting2.value))
    my_settings = config.get_settings()
    for my_setting in my_settings:
        print("my_setting.name = {}".format(my_setting.name))
       

# Generated at 2022-06-20 13:34:14.651371
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='token', value='sometoken'))
    config_data.update_setting(Setting(name='url', value='http://someurl/'))
    assert config_data.get_setting('token').value == 'sometoken'
    assert config_data.get_setting('url').value == 'http://someurl/'
    assert config_data.get_setting('dummy') is None

    plugin = Plugin(type='mytype', name='myname')
    config_data.update_setting(Setting(name='plugin_token', value='plugin_token_value'), plugin=plugin)
    assert config_data.get_setting('plugin_token', plugin=plugin).value == 'plugin_token_value'



# Generated at 2022-06-20 13:34:19.869438
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert isinstance(cd, ConfigData)

# Generated at 2022-06-20 13:34:24.167236
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='time', value='10s'))
    assert config_data.get_setting(name='time') == Setting(name='time', value='10s')


# Generated at 2022-06-20 13:34:30.352610
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    setting1 = Setting('foo', 'bar', None)
    config_data.update_setting(setting1)

    setting2 = Setting('baz', 'qux', None)
    config_data.update_setting(setting2)

    assert config_data.get_setting('foo') == setting1
    assert config_data.get_setting('baz') == setting2
    assert config_data.get_setting('foobar') is None


# Generated at 2022-06-20 13:34:36.442134
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    try:
        from ansible.config.manager import ConfigManager
    except ImportError:
        print("Couldn't find a module ansible.config.manager. Skipping test_ConfigData_update_settings")
        return
        
    config = ConfigData()
    config_manager = ConfigManager()
    config_manager.set_setting("setting1", 'UnitTest1', 1)
    config.update_setting(config_manager.setting_definitions['setting1'])

    assert(config.get_setting('setting1').value == 1)
    assert(config.get_setting('setting1').value == config_manager.setting_definitions['setting1'].value)


# Generated at 2022-06-20 13:34:45.324058
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    config_data.update_setting(Setting("setting1", "value1"))
    config_data.update_setting(Setting("setting2", "value2"))
    config_data.update_setting(Setting("setting1", "value1", Plugin("module", "module1")))
    config_data.update_setting(Setting("setting2", "value2", Plugin("module", "module1")))
    config_data.update_setting(Setting("setting1", "value1", Plugin("module", "module2")))
    config_data.update_setting(Setting("setting1", "value1", Plugin("module", "module3")))

    assert config_data.get_setting("setting1") == Setting("setting1", "value1")

# Generated at 2022-06-20 13:34:56.451813
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_obj = ConfigData()
    setting_obj = Setting()

    config_data_obj.update_setting(setting_obj, Plugin('action'))
    assert config_data_obj._plugins['action']['action']['action'] == setting_obj
    assert config_data_obj._plugins['action']['action'] == {'action': setting_obj}
    assert config_data_obj._plugins['action'] == {'action': {'action': setting_obj}}
    assert config_data_obj._plugins == {'action': {'action': {'action': setting_obj}}}



# Generated at 2022-06-20 13:34:59.046171
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    assert isinstance(configData._global_settings, dict)
    assert isinstance(configData._plugins, dict)


# Generated at 2022-06-20 13:35:12.251060
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ..data import Setting

    config_data = ConfigData()

    # get_setting should return None if the setting does not exist
    assert config_data.get_setting('somesetting', None) is None

    # get_setting should return a setting if it exists (without plugin filter)
    setting = Setting('somesetting', 'value', 'str')
    config_data.update_setting(setting)
    assert config_data.get_setting('somesetting', None) is setting

    # get_setting should return a setting if it exists (with plugin filter)
    from ..data import Plugin

    plugin = Plugin('testplugin', 'test')
    setting = Setting('somesetting', 'value', 'str')
    config_data.update_setting(setting, plugin)

# Generated at 2022-06-20 13:35:14.448871
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    assert config_data.get_settings() == []
    assert config_data.get_settings('test') == []

# Generated at 2022-06-20 13:35:16.613005
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    assert cd.get_setting("foo") == None
    assert cd.get_setting("nonexisting") == None


# Generated at 2022-06-20 13:35:19.820132
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data


# Generated at 2022-06-20 13:35:28.505060
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint import AnsibleLintConfig
    from ansiblelint import Setting

    config_data = ConfigData()

    config_data.update_setting(AnsibleLintConfig.Rules["ANSIBLE0001"], None)
    config_data.update_setting(AnsibleLintConfig.Rules["ANSIBLE0002"], None)
    config_data.update_setting(AnsibleLintConfig.Rules["ANSIBLE0003"], None)
    config_data.update_setting(AnsibleLintConfig.Rules["ANSIBLE0004"], None)
    config_data.update_setting(AnsibleLintConfig.Rules["ANSIBLE0005"], None)
    config_data.update_setting(AnsibleLintConfig.Rules["ANSIBLE0006"], None)

# Generated at 2022-06-20 13:35:34.126537
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    client = MockPlugin(type='cache', name='foo')
    setting = MockSetting('test', 'bar')

    cd.update_setting(setting)
    assert cd._global_settings['test'].value == 'bar'
    assert cd._global_settings['test'].plugin == None

    cd.update_setting(setting, client)
    assert cd._plugins['cache']['foo']['test'].value == 'bar'
    assert cd._plugins['cache']['foo']['test'].plugin == client


# Generated at 2022-06-20 13:35:43.537129
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()

    plugin1 = PluginData('name1', 'type1')
    plugin2 = PluginData('name2', 'type2')

    assert data.get_setting('xyz', plugin1) is None
    assert data.get_setting('xyz', plugin2) is None

    setting1 = SettingData('xyz', 'value1')
    setting2 = SettingData('xyz', 'value2')

    data.update_setting(setting1, plugin1)

    assert data.get_setting('xyz', plugin1).value == 'value1'
    assert data.get_setting('xyz', plugin2) is None

    data.update_setting(setting2, plugin2)

    assert data.get_setting('xyz', plugin1).value == 'value1'

# Generated at 2022-06-20 13:35:47.452065
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data_test_1 = ConfigData()
    config_data_test_2 = ConfigData()

    assert config_data_test_1._global_settings == {}
    assert config_data_test_2._plugins == {}
    assert config_data_test_1._plugins != config_data_test_2._plugins

# Generated at 2022-06-20 13:35:55.558002
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    import json
    import os
    import tempfile

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import PY3
    from ansible.compat.tests import unittest
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.context_objects import AnsibleContext
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    class TestPlugin(object):
        def __init__(self):
            self.context = AnsibleContext()

# Generated at 2022-06-20 13:35:57.908804
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert c.get_setting('ANSIBLE_INVENTORY') is None

# Generated at 2022-06-20 13:36:07.426301
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from collections import namedtuple

    test_object = ConfigData()

    plugin = namedtuple('plugin', ['type', 'name'])

    assert test_object.get_setting('ANSIBLE_TRANSPORT', None) is None
    assert test_object.get_setting('ANSIBLE_TRANSPORT', plugin(type=None, name=None)) is None
    assert test_object.get_setting('ANSIBLE_TRANSPORT', plugin(type='connection', name=None)) is None
    assert test_object.get_setting('ANSIBLE_TRANSPORT', plugin(type='connection', name='local')) is None


# Generated at 2022-06-20 13:36:15.533378
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    print('test_ConfigData_update_setting')
    conf = ConfigData()
    assert conf is not None
    assert len(conf._global_settings) == 0
    assert conf._global_settings == {}

    conf.update_setting(Setting(name='some setting'))
    assert len(conf._global_settings) == 1
    assert conf._global_settings == {'some setting': {'name': 'some setting'}}

    plugin = Plugin(name='test plugin', type='module')
    #test adding a setting to a plugin
    conf.update_setting(Setting(name='module setting'), plugin)
    assert 'module' in conf._plugins
    assert 'test plugin' in conf._plugins['module']
    assert len(conf._plugins['module']['test plugin']) == 1

# Generated at 2022-06-20 13:36:24.879511
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()
    assert config.get_setting('all_tests_must_pass') is None
    assert config.get_setting('all_tests_must_pass', plugin=None) is None
    assert config._global_settings == {}
    assert config._plugins == {}

    setting = Setting('all_tests_must_pass', 'true')
    config.update_setting(setting)
    assert config.get_setting('all_tests_must_pass') == setting
    assert config.get_setting('all_tests_must_pass', plugin=None) == setting
    assert config._global_settings == {'all_tests_must_pass': setting}
    assert config._plugins == {}


# Generated at 2022-06-20 13:36:29.801830
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data= ConfigData()
    config_data.update_setting(setting={},plugin={})
    config_data.update_setting(setting={'name':'value'},plugin={'type':'value2','name':'value3'})



# Generated at 2022-06-20 13:36:32.424026
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    # Initialize the setting array
    assert config_data._global_settings == {}

# Generated at 2022-06-20 13:36:33.792369
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config


# Generated at 2022-06-20 13:36:38.926094
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin('foo', 'bar')
    setting = Setting('baz', 'qux')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['foo']['bar']['baz'] == setting
    return True

# Generated at 2022-06-20 13:36:45.847969
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()

    class ConfigSetting(object):
        def __init__(self, name, plugin):
            self.name = name
            self.plugin = plugin

    class ConfigPlugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    s0 = ConfigSetting("abc", None)
    p1 = ConfigPlugin("connection", "local_test")
    s1 = ConfigSetting("xyz", p1)

    cd.update_setting(s0)
    cd.update_setting(s1)

    assert "abc" in cd._global_settings
    assert "connection" in cd._plugins
    assert "local_test" in cd._plugins["connection"]
    assert "xyz" in cd._plugins["connection"]["local_test"]


#

# Generated at 2022-06-20 13:36:47.912674
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-20 13:36:53.086292
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    rs = setting.Setting('value','description','default','short','type','choices','scope','version','deprecated','removed')
    config_data.update_setting(rs)
    setting_entry = config_data.get_setting('value')
    assert setting_entry.name == 'value'

# Generated at 2022-06-20 13:36:57.681300
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    assert cd.get_settings() == []
    setting = ConfigSetting("string", "key", "value", "string value")
    cd.update_setting(setting)
    assert cd.get_settings()[0] == setting



# Generated at 2022-06-20 13:37:11.320706
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    plugin_type = 'foo'
    plugin_name = 'bar'

    setting_name = 'spam'
    value = 'eggs'
    setting_encoding = None

    # Update a setting

    setting = Setting(setting_name, value, setting_encoding)

    config_data.update_setting(setting)

    # Get the setting, should be there

    setting = config_data.get_setting(setting_name, plugin=Plugin(plugin_type, plugin_name))

    assert(setting)

    # Get the setting, should not be there

    setting = config_data.get_setting('unknown')

    assert(setting is None)

    # Get all settings, should be there

    settings = config_data.get_settings()

    assert(len(settings) == 1)

   

# Generated at 2022-06-20 13:37:20.346796
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    
    config_data.update_setting(ConfigSetting('g_setting_1', 1))
    config_data.update_setting(ConfigSetting('g_setting_2', 2))
    config_data.update_setting(ConfigSetting('g_setting_3', 3))

    assert config_data.get_setting('g_setting_1') == ConfigSetting('g_setting_1', 1)
    assert config_data.get_setting('g_setting_2') == ConfigSetting('g_setting_2', 2)
    assert config_data.get_setting('g_setting_3') == ConfigSetting('g_setting_3', 3)
    assert config_data.get_setting('none') is None


# Generated at 2022-06-20 13:37:27.376545
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()

# Generated at 2022-06-20 13:37:35.803357
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    
    config_data = ConfigData()
    setting_plugin = Setting('plugin_name', 'plugin_type')
    setting_global = Setting('global_name')
    
    config_data.update_setting(setting_plugin, plugin=None)
    config_data.update_setting(setting_global, plugin=None)

    assert config_data.get_setting('plugin_name', plugin=setting_plugin) == setting_plugin
    assert config_data.get_setting('global_name', plugin=setting_plugin) == setting_global


# Generated at 2022-06-20 13:37:40.787004
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    setting = Setting()
    setting.name = "testname"
    setting.value = "testvalue"
    config.update_setting(setting, None)
    assert config.get_setting("testname", None).value == "testvalue"


# Generated at 2022-06-20 13:37:45.032698
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    assert len(config.get_settings()) == 0


# Generated at 2022-06-20 13:37:46.230479
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-20 13:37:55.254244
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # test 1
    setting = config_data.get_setting('test')
    # should be the global setting 'test'
    if setting is None or setting.scope != 'global':
        raise Exception('test 1 failed')

    # test 2
    setting = config_data.get_setting('test', plugin=Plugin('strategy', 'strategy_plugin_test'))
    # should be the global setting 'test'
    if setting is None or setting.scope != 'global':
        raise Exception('test 2 failed')

    # test 3
    setting = config_data.get_setting('test', plugin=Plugin('action', 'action_plugin_test'))
    # should be the global setting 'test'
    if setting is None or setting.scope != 'global':
        raise Exception('test 3 failed')

   

# Generated at 2022-06-20 13:38:06.245174
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class TestData():

        def __init__(self):
            self.name = "test"
            self.value = "passed"

    config_data = ConfigData()

    plugin = Plugin(None, None)
    setting = TestData()
    config_data.update_setting(setting)

    plugin.type = "something"
    plugin.name = "dummy"
    setting = TestData()
    config_data.update_setting(setting, plugin)

    settings = config_data.get_settings()
    assert len(settings) == 1
    assert settings[0].name == "test"
    assert settings[0].value == "passed"

    settings = config_data.get_settings(plugin)
    assert len(settings) == 1
    assert settings[0].name == "test"

# Generated at 2022-06-20 13:38:17.646650
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    print("\n\n")
    import ConfigData as configData
    import PluginBase as pluginBase

    config = configData.ConfigData()
    config.update_setting(pluginBase.Setting(name="common", desc="This is a common setting"))
    config.update_setting(pluginBase.Setting(name="shell", desc="This is a shell setting"), pluginBase.PluginBase("shell", "cmd"))
    assert config.get_setting("common")
    assert config.get_setting("shell", pluginBase.PluginBase("shell", "cmd"))
    assert config.get_setting("notexist") is None


# Generated at 2022-06-20 13:38:19.142441
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    setting_nop = ConfigData()
    assert setting_nop.get_settings() == []

# Generated at 2022-06-20 13:38:23.223284
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    assert config.get_settings() == []
    setting = Setting('setting_name', 'setting_value')
    config.update_setting(setting, plugin=Plugin('plugin_name', 'plugin_type'))
    assert config.get_settings() == [setting]


# Generated at 2022-06-20 13:38:37.486405
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    setting = Setting('setting 1')
    config_data.update_setting(setting)
    assert config_data.get_setting('setting 1') == setting

    plugin = Plugin('plugin 1', 'module')
    setting = Setting('setting 2')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('setting 2', plugin) == setting



# Generated at 2022-06-20 13:38:46.678988
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('setting', 'setting_value')
    # test update_setting with a plugin set to None
    config_data.update_setting(setting)
    assert config_data._global_settings['setting'] == setting

    # test update_setting with a plugin set to ValueError
    plugin = Plugin('ValueError', 'NameError')
    config_data.update_setting(setting, plugin)
    assert config_data._global_settings['setting'] == setting
    assert config_data._plugins['ValueError']['NameError']['setting'] == setting

    # test update_setting with a plugin set to type other than ValueError
    plugin.type = 'Exception'
    config_data.update_setting(setting, plugin)
    assert config_data._global_settings['setting'] == setting
    assert config

# Generated at 2022-06-20 13:38:58.159160
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    data = ConfigData()

    assert( not data.get_settings())

    data.update_setting(Setting(name="ANSIBLE_FORKS", value=20, origin="CLI", scope="global"))
    data.update_setting(Setting(name="ANSIBLE_FOO", value=20, origin="CLI", scope="global"))
    data.update_setting(Setting(name="ANSIBLE_BAR", value=20, origin="CLI", scope="global"))

    settings = data.get_settings()
    assert(len(settings) == 3)
    assert(settings[0].name == "ANSIBLE_FORKS")
    assert(settings[1].name == "ANSIBLE_FOO")
    assert(settings[2].name == "ANSIBLE_BAR")
    assert(settings[0].value == 20)

# Generated at 2022-06-20 13:39:11.502170
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible_collections.misc.plugins.setting import Setting

    data = ConfigData()

    setting = Setting(name='foo', plugin_type='bar', plugin_name='baz', value='foobar')
    data.update_setting(setting=setting, plugin=setting.plugin)
    setting = Setting(name='foo', plugin_type='bar', plugin_name='baz', value='foobaz')
    data.update_setting(setting=setting, plugin=setting.plugin)
    setting = Setting(name='foo', plugin_type='bar', plugin_name='baz', value='foobar')
    data.update_setting(setting=setting, plugin=setting.plugin)

    settings = data.get_settings(plugin=setting.plugin)
    assert len(settings) == 2
    assert settings[0].value == 'foobar'

# Generated at 2022-06-20 13:39:15.191167
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data
    assert isinstance(config_data._global_settings, dict)
    assert isinstance(config_data._plugins, dict)


# Generated at 2022-06-20 13:39:16.776862
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert c._global_settings == {}
    assert c._plugins == {}


# Generated at 2022-06-20 13:39:20.430491
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    # Test initial values
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-20 13:39:22.611129
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("setting1") == None


# Generated at 2022-06-20 13:39:33.186831
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data_object = ConfigData()
    config_data_object.update_setting(setting=None, plugin=None)
    config_data_object.update_setting(setting=None, plugin={'type': 'test_type', 'name': 'test_name'})
    config_data_object.update_setting(setting={'name': 'test_name', 'value': 'test_value'}, plugin={'type': 'test_type', 'name': 'test_name'})
    config_data_object.update_setting(setting={'name': 'test_name', 'value': 'test_value'})
    assert config_data_object is not None
    config_data_object2 = ConfigData()

# Generated at 2022-06-20 13:39:37.895529
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    print(cd._global_settings)

    plugins = {}
    plugins['action'] = {}
    plugins['connection'] = {}

    # action plugin
    plugins['action']['apt'] = {}
    plugins['action']['apt']['credential'] = {'name':'apt-credential'}
    plugins['action']['copy'] = {}
    plugins['action']['copy']['credential'] = {'name': 'copy-credential'}

    # connection plugin
    plugins['connection']['local'] = {}
    plugins['connection']['local']['credential'] = {'name':'local-credential'}
    plugins['connection']['smart'] = {}

# Generated at 2022-06-20 13:39:46.935570
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}



# Generated at 2022-06-20 13:39:49.695156
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    data.update_setting(Setting(name="test_setting", value=0, is_constant=True, default_value=0))
    assert data.get_settings()[0].value == 0
    assert data.get_settings()[0].get_value() == 0



# Generated at 2022-06-20 13:39:54.917954
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    a = ConfigData()

    a.update_setting('omg')
    assert a._global_settings == {'omg'}



# Generated at 2022-06-20 13:40:02.654317
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    from ansibledocgen.doc_plugins.doc_data_setting import ConfigSetting
    config_setting = ConfigSetting()
    config_setting.name = 'key1'
    config_setting.short_description = 'one'
    config_data.update_setting(config_setting)

    assert len(config_data._global_settings) == 1
    assert config_data._global_settings['key1'].name == 'key1'
    assert config_data._global_settings['key1'].short_description == 'one'


# Generated at 2022-06-20 13:40:12.217807
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.config.setting import Setting
    from ansible.config.data import PluginConfig

    config_data = ConfigData()
    config_data.update_setting(Setting('name', 'foo'))
    assert config_data.get_setting('name') == Setting('name', 'foo')

    plugin = PluginConfig('type', 'name')
    config_data.update_setting(Setting('name', 'bar'), plugin=plugin)
    assert config_data.get_setting('name', plugin=plugin) == Setting('name', 'bar')


# Generated at 2022-06-20 13:40:14.910795
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data_obj = ConfigData()
    assert config_data_obj is not None


# Generated at 2022-06-20 13:40:16.980705
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()
    settings = configData.get_settings()
    assert settings == []

# Generated at 2022-06-20 13:40:22.658944
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {'name': 'test_setting', 'value': 'test_value'}
    config_data.update_setting(setting)
    assert 'test_setting' in config_data._global_settings
    assert 'test_value' == config_data._global_settings['test_setting']['value']


# Generated at 2022-06-20 13:40:23.617339
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()


# Generated at 2022-06-20 13:40:32.070951
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    print("Testing get_setting() from ConfigData Class")
    global_setting = ConfigSetting("cal_autoinstall_enabled", "1")
    plugin = Plugin("credential", "netapp")
    plugin_setting = ConfigSetting("ntap_pass", "sample_password")
    config_data = ConfigData()
    config_data.update_setting(global_setting)
    config_data.update_setting(plugin_setting, plugin)
    assert config_data.get_setting("cal_autoinstall_enabled") == global_setting
    assert config_data.get_setting("ntap_pass", plugin) == plugin_setting
    assert config_data.get_setting("ntap_pass") is None
    assert config_data.get_setting("cal_autoinstall_enabled", plugin) is None


# Generated at 2022-06-20 13:40:50.559088
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:40:51.651516
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()


# Generated at 2022-06-20 13:40:54.618357
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cd.update_setting('test1')
    assert cd.get_setting('test1') == 'test1'



# Generated at 2022-06-20 13:40:56.054261
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert configdata is not None

# Generated at 2022-06-20 13:41:03.473456
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    setting1 = Setting('attr1', module='a', defaults={'attr2': 'b'})
    setting2 = Setting('attr2', module='a', defaults={'attr2': 'b'})
    setting3 = Setting('attr1', module='b', defaults={'attr2': 'b'})
    config.update_setting(setting1)
    config.update_setting(setting2)
    config.update_setting(setting3)
    assert len(config.get_settings()) == 2
    assert len(config.get_settings(module='a')) == 2
    assert len(config.get_settings(module='b')) == 1

# Generated at 2022-06-20 13:41:08.255705
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='test_setting_1')
    config_data.update_setting(setting)
    assert config_data._global_settings['test_setting_1'] == setting


# Generated at 2022-06-20 13:41:10.758921
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-20 13:41:18.405162
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from collections import namedtuple
    from ansiblelint.rules.LineTooLong import AnsibleLintRule
    from ansiblelint.rules.NoEmptyPlaybook import AnsibleLintRule
    from ansiblelint.rules.TaskHasChangedCheck import AnsibleLintRule
    from ansiblelint import RulesCollection
    from ansiblelint import Runner
    from ansiblelint.rules import RulesCollection
    from ansiblelint import Runner, RulesCollection
    from ansiblelint.rules import RulesCollection
    Plugin = namedtuple('Plugin', ['type', 'name'])
    setting1 = namedtuple('Setting', ['name', 'value', 'description'])
    setting2 = namedtuple('Setting', ['name', 'value', 'description'])

# Generated at 2022-06-20 13:41:22.169251
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-20 13:41:29.323917
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    config_data.update_setting(Setting('CONSISTENT_HASHING_BASE_FILE', '', '', '', '', ''))

    plugin = Plugin('CACHE', 'redis', 'Redis Cache Plugin')
    setting = Setting('CONFIG_FILE', '', '', '', '', '')
    config_data.update_setting(setting, plugin)

    assert setting == config_data.get_setting('CONFIG_FILE', plugin)


# Generated at 2022-06-20 13:42:01.597671
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()


# Generated at 2022-06-20 13:42:11.513158
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Initial global setting for method update_setting
    global_setting_1 = {'name': 'autosave_on_exit', 'value': 'off', 'plugin_type': 'global' }
    global_setting_2 = {'name': 'convert_file_newline', 'value': 'on', 'plugin_type': 'global' }

    # Initial plugin's setting for method update_setting
    plugin_setting_1 = {'name': 'autosave_on_exit', 'value': 'off', 'plugin_type': 'credential', 'plugin_name': 'azure'}
    plugin_setting_2 = {'name': 'convert_file_newline', 'value': 'on', 'plugin_type': 'credential', 'plugin_name': 'azure'}

    # Initial configData for method update_setting

# Generated at 2022-06-20 13:42:16.554330
# Unit test for constructor of class ConfigData
def test_ConfigData():
    def do_assert(obj):
        assert isinstance(obj.get_settings(), list)
        assert len(obj.get_settings()) == 0
        assert isinstance(obj.get_settings(plugin=object), list)
        assert len(obj.get_settings(plugin=object)) == 0

    # Constructor of class ConfigData()
    obj = ConfigData()
    do_assert(obj)

# Generated at 2022-06-20 13:42:23.785795
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Test empty ConfigData
    config_data = ConfigData()
    assert(config_data.get_setting(name="foo") is None)

    # Test global setting
    config_data.update_setting(Setting('foo', 'value_foo'))
    setting = config_data.get_setting(name="foo")
    assert(setting.name == 'foo')
    assert(setting.value == 'value_foo')

    # Test plugin setting
    config_data.update_setting(Setting('bar', 'value_bar'), plugin=Plugin('path', 'file'))
    setting = config_data.get_setting(name="bar", plugin=Plugin('path', 'file'))
    assert(setting.name == 'bar')
    assert(setting.value == 'value_bar')


# Generated at 2022-06-20 13:42:26.454687
# Unit test for constructor of class ConfigData
def test_ConfigData():

    c = ConfigData()

    assert c is not None


# Generated at 2022-06-20 13:42:33.878456
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import pytest
    from units.mock.loader import DictDataLoader
    from units.plugins.loader import PluginLoader
    from units.compat import text_type

    config_data = ConfigData()

    # Create a plugin

# Generated at 2022-06-20 13:42:39.335333
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData
    # test None setting load from global
    test_setting = config_data.get_setting("None")
    assert test_setting == None
    # test None setting load from plugin

# Generated at 2022-06-20 13:42:43.824388
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import get_all_plugin_loaders

    config_data = ConfigData()
    for plugin_loader_cls in get_all_plugin_loaders():
        for plugin in plugin_loader_cls.all():
            config_data.update_setting(setting=plugin, plugin=plugin)

# Generated at 2022-06-20 13:42:53.016017
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    data._global_settings = {"a": "hello", "b": "world", "c": "test"}
    data._plugins = {
        "boo": {
            "bar": {"baz": "foo", "spam": "ham"},
            "eggs": {"spam": "bacon", "baz": "fruit"},
            "foo": {"baz": "bar", "spam": "effect"}
        }
    }
    assert data.get_setting("a") == "hello"
    assert data.get_setting("b") == "world"
    assert data.get_setting("c") == "test"
    assert data.get_setting("b", plugin=PluginInfo("boo", "bar")) == "ham"

# Generated at 2022-06-20 13:42:59.936811
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from collections import namedtuple
    from ansiblelint.rules.BasicRule import BasicRule
    Plugin = namedtuple('Plugin', 'type name')

    # set up test data
    config_data = ConfigData()
    test_setting = BasicRule().get_id()
    config_data.update_setting(test_setting)

    # test plugin is None
    assert len(list(config_data.get_settings())) == 1
    assert config_data.get_settings()[0].name == test_setting

    # test plugin exists
    test_plugin = Plugin(type='rules', name='test_plugin')
    test_setting2 = BasicRule(name='test_setting2').get_id()
    config_data.update_setting(test_setting2, plugin=test_plugin)