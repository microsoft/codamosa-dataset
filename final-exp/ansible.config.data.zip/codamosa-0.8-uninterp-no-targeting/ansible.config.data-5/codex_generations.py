

# Generated at 2022-06-20 13:33:23.164857
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Test default values by calling get_setting without any setting defined
    assert config_data.get_setting('gather_facts') == None
    assert config_data.get_setting('gather_subset') == None
    assert config_data.get_setting('forks') == None
    assert config_data.get_setting('fact_caching') == None

    # Test with global settings defined
    config_data.update_setting(Setting('gather_facts', 'false', 'string'))
    config_data.update_setting(Setting('gather_subset', 'all', 'string'))
    config_data.update_setting(Setting('forks', '1', 'integer'))
    config_data.update_setting(Setting('fact_caching', 'memory', 'string'))
   

# Generated at 2022-06-20 13:33:29.686801
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    import unittest
    import sys

    class Plugin(object):
        def __init__(self):
            self.type = 'module'
            self.name = 'foo'

    class Setting(object):
        def __init__(self, name):
            self.name = name

    class ConfigDataTestCase(unittest.TestCase):
        def test_get_setting(self):
            # Test for plugin = None
            config_data = ConfigData()
            setting = Setting('foo')
            config_data.update_setting(setting)
            self.assertEqual(config_data.get_setting('foo'), setting)
            self.assertEqual(config_data.get_setting('foo', plugin=Plugin()), setting)
            self.assertEqual(config_data.get_setting('missing'), None)
            self

# Generated at 2022-06-20 13:33:37.491657
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting1 = Setting(name='test_setting', value='test_value', origin='test_origin', plugin=None)
    setting2 = Setting(name='test_setting', value='test_value', origin='test_origin', plugin=Plugin('fixture', 'test_type', 'test_name'))
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    assert config_data._global_settings['test_setting'] == setting1
    assert config_data._plugins['test_type']['test_name']['test_setting'] == setting2


# Generated at 2022-06-20 13:33:43.944464
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    assert not config_data._plugins
    assert not config_data._global_settings

    setting = ConfigSetting("test_setting", "Test setting", "str")
    assert not config_data._plugins
    assert not config_data._global_settings

    config_data.update_setting(setting)
    assert not config_data._plugins
    assert config_data._global_settings



# Generated at 2022-06-20 13:33:46.801338
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    assert 0, "Not implemented"


# Generated at 2022-06-20 13:33:48.327150
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # pylint: disable=unused-variable
    config_data = ConfigData()

# Generated at 2022-06-20 13:33:59.839229
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_object = ConfigData()

    setting1 = {"name":"test_setting1",
                "value":"test_value1",
                "origin":"test_origin1",
                "plugin_type":"test_plugin_type1",
                "plugin_name":"test_plugin_name1"}

    config_data_object.update_setting(setting1)

    setting2 = {"name":"test_setting2",
                "value":"test_value2",
                "origin":"test_origin2",
                "plugin_type":"test_plugin_type2",
                "plugin_name":"test_plugin_name2"}

    config_data_object.update_setting(setting2)


# Generated at 2022-06-20 13:34:10.885446
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    setting0 = Setting(name='setting0', default=None, type=None)
    plugin0_1 = Plugin(type='type0', name='name0_1')
    setting0_1 = Setting(name='setting0_1', default=None, type=None)
    plugin0_2 = Plugin(type='type0', name='name0_2')
    setting0_2 = Setting(name='setting0_2', default=None, type=None)
    plugin1_1 = Plugin(type='type1', name='name1_1')
    setting1_1 = Setting(name='setting1_1', default=None, type=None)
    plugin1_2 = Plugin(type='type1', name='name1_2')

# Generated at 2022-06-20 13:34:14.057975
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import sys
    import os

    sys.path.append(os.path.abspath('../../test_utils'))

    import test_utils

    test_utils.run_ansible_module(['config_data.py'])

# Generated at 2022-06-20 13:34:21.563787
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('some_setting', 'some_value'))
    assert config_data.get_setting('some_setting') == 'some_value'


# Generated at 2022-06-20 13:34:29.430542
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin_type = 'CLI'
    plugin_name = 'ansible-doc'
    setting_name = 'manpage_dir'
    setting = Setting(setting_name, plugin_type, plugin_name)
    config_data.update_setting(setting, plugin_type, plugin_name)
    assert config_data._global_settings[setting.name] == setting


# Generated at 2022-06-20 13:34:31.199363
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test_data = ConfigData()
    assert test_data.get_setting("name") == None


# Generated at 2022-06-20 13:34:34.115547
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data.get_settings(plugin=None) == []
    assert config_data.get_setting(name='name', plugin=None) is None

# Generated at 2022-06-20 13:34:44.129422
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from units.mock.loader import DictDataLoader

    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import find_plugin

    config_data = ConfigData()

# Generated at 2022-06-20 13:34:50.943206
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    config_data.update_setting(setting=None, plugin=None)

    config_data.update_setting(setting=1, plugin=None)

    config_data.update_setting(setting=2, plugin=2)

    config_data.update_setting(setting=3, plugin={})

    config_data.update_setting(setting=[], plugin={'name': 'foo', 'type': 'bar'})

# Generated at 2022-06-20 13:35:01.486645
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    global_setting = Setting("setting1", "value1")
    plugin_setting = Setting("setting2", "value2")
    config_data = ConfigData()
    config_data.update_setting(global_setting)
    plugin = Plugin("network", "cisco_ios")
    config_data.update_setting(plugin_setting, plugin)

    assert config_data.get_setting("setting1").value == "value1"
    assert config_data.get_setting("setting1", plugin).value == "value1"
    assert config_data.get_setting("setting2").value is None
    assert config_data.get_setting("setting2", plugin).value == "value2"



# Generated at 2022-06-20 13:35:03.724385
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data._global_settings['name1'] = 'value1'
    assert config_data.get_setting('name1') == 'value1'


# Generated at 2022-06-20 13:35:13.376335
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    from ansible_collections.all.notmintest.tests.unit.compat import mock

    mock_plugin = mock.create_autospec(object)
    mock_plugin.type = 'mock'
    mock_plugin.name = 'mock'

    assert config_data.get_setting('mock_setting') is None
    assert config_data.get_setting('mock_setting', mock_plugin) is None

    mock_setting = mock.create_autospec(object)
    mock_setting.name = 'mock_setting'

    config_data.update_setting(mock_setting)

    assert config_data.get_setting('mock_setting') == mock_setting
    assert config_data.get_setting('mock_setting', mock_plugin) is None



# Generated at 2022-06-20 13:35:13.794629
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData()

# Generated at 2022-06-20 13:35:15.077649
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd._plugins == {}
    assert cd._global_settings == {}


# Generated at 2022-06-20 13:35:18.734661
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data is not None


# Generated at 2022-06-20 13:35:19.962267
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert isinstance(data, ConfigData)


# Generated at 2022-06-20 13:35:21.317497
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data


# Generated at 2022-06-20 13:35:23.641673
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert len(ConfigData()._global_settings) == 0
    assert len(ConfigData()._plugins) == 0


# Generated at 2022-06-20 13:35:33.358751
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    setting = Setting("api_host", "value")
    setting_type = PluginType("TestType")
    setting_plugin = Plugin(setting_type, ('api_host', 'TestPlugin'))
    config_data.update_setting(setting, plugin=setting_plugin)

    assert config_data.get_setting('api_host', plugin=setting_plugin) == setting

    setting = Setting("username", "value")
    setting_plugin = Plugin(setting_type, ('username', 'TestPlugin'))
    config_data.update_setting(setting, plugin=setting_plugin)

    assert config_data.get_setting('username', plugin=setting_plugin) == setting


# Generated at 2022-06-20 13:35:34.746230
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-20 13:35:40.364174
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData=ConfigData()
    assert configData.get_settings() == []


# Generated at 2022-06-20 13:35:42.799027
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}
    
    

# Generated at 2022-06-20 13:35:52.664595
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class PluginType(object):
        def __init__(self):
            self.type = "type"
            self.name = "name"

    class PluginModule(object):
        def __init__(self):
            self.type = "module"
            self.name = "name"


    class Setting:
        def __init__(self, name, value, origin=None):
            self.name = name
            self.value = value
            self.origin = origin

    config_data = ConfigData()
    config_data.update_setting(Setting("setting1", "value1", "ini_file"))
    config_data.update_setting(Setting("setting2", "value2", "ini_file"))
    config_data.update_setting(Setting("setting1", "value3", "ini_file"), PluginType())
   

# Generated at 2022-06-20 13:35:58.243623
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    setting = Setting('A', 'B', 'C', 'D')
    configData.update_setting(setting)
    assert configData.get_setting('A') == setting


# Generated at 2022-06-20 13:36:09.281783
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin = PluginDefinition(type='module', name='ping')
    setting = PluginSetting(name='max_retries',
                            description='Maximum number of retries to execute module.',
                            default=None,
                            choices=None,
                            aliases=['max_module_retries'])
    config = ConfigData()
    config.update_setting(setting)
    config.update_setting(setting, plugin)
    assert config.get_setting('max_retries') == setting
    assert config.get_setting('max_retries', plugin) == setting
    assert config.get_settings() == [setting]
    assert config.get_settings(plugin) == [setting]


# Generated at 2022-06-20 13:36:17.425583
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    setting = Setting(name="test_setting", value="test_value", origin="test_origin", string_form="test_string_form")

    config_data.update_setting(setting, plugin=None)

    assert config_data._global_settings["test_setting"] == setting


# Generated at 2022-06-20 13:36:22.862543
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()
    setting = {'name': 'test1', 'default': 'test2'}
    configdata.update_setting(setting)
    assert configdata._global_settings == {'test1': {'name': 'test1', 'default': 'test2'}}



# Generated at 2022-06-20 13:36:28.737099
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    plugin_type = 'my_plugin'
    plugin_name = 'my_plugin'
    setting_name = 'setting'
    setting_value = 'setting_value'
    plugin = ConfigPlugin(plugin_type, plugin_name)

    setting = ConfigSetting(setting_name, setting_value)
    config.update_setting(setting, plugin)
    assert config.get_setting(setting_name) == None
    assert config.get_setting(setting_name, plugin) == setting



# Generated at 2022-06-20 13:36:39.596808
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting1 = Setting('bool', 'setting1', True)
    assert setting1 == config_data.update_setting(setting1)
    setting2 = Setting('bool', 'setting1', True, plugin=Plugin('test', 'local'))
    assert setting2 == config_data.update_setting(setting2, plugin=Plugin('test', 'local'))

    assert setting1 == config_data.get_setting('setting1')
    assert setting2 == config_data.get_setting('setting1', plugin=Plugin('test', 'local'))
    assert config_data.get_setting('setting2') is None
    assert config_data.get_setting('setting2', plugin=Plugin('test', 'local')) is None


# Generated at 2022-06-20 13:36:49.571314
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    """
    @Test: test_ConfigData_get_setting
    """
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.config.data import Setting
    from ansible.plugins.loader import config_loader
    from ansible.plugins.loader import module_loader

    cfg = ConfigData()
    cfg.update_setting(Setting('foo', 'bar'))
    cfg.update_setting(Setting('foo2', 'bar2', module_loader.ModuleUtil.subclass))
    cfg.update_setting(Setting('foo3', 'bar3', config_loader.ConfigUtil.subclass))

# Generated at 2022-06-20 13:36:59.406527
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    my_config_data = ConfigData()

    my_config_data.update_setting(Setting("setting_one", "setting_one_value"))
    my_config_data.update_setting(Setting("setting_two", "setting_two_value"))
    my_config_data.update_setting(Setting("setting_three", "setting_three_value"))

    assert my_config_data.get_settings() == [
        Setting("setting_one", "setting_one_value"),
        Setting("setting_two", "setting_two_value"),
        Setting("setting_three", "setting_three_value")
    ]



# Generated at 2022-06-20 13:37:01.420670
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:37:08.388795
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configData = ConfigData()
    assert len(configData.get_settings()) == 0
    configData.update_setting(Setting('test1', 'value1'))
    assert len(configData.get_settings()) == 1
    configData.update_setting(Setting('test2', 'value2'))
    assert len(configData.get_settings()) == 2
    configData.update_setting(Setting('test3', 'value3'))
    assert len(configData.get_settings()) == 3
    configData.update_setting(Setting('test4', 'value4'))
    assert len(configData.get_settings()) == 4



# Generated at 2022-06-20 13:37:15.704712
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    print(config_data._global_settings)
    print(config_data._plugins)

    class Setting:

        def __init__(self, type, name, value):
            self.type = type
            self.name = name
            self.value = value

    class Plugin:

        def __init__(self, type, name):
            self.type = type
            self.name = name

    global_setting1 = Setting("global", "foo", 1)
    plugin_setting1 = Setting("connection", "foo", "bar")
    plugin_setting2 = Setting("connection", "bar", "baz")

    plugin1 = Plugin("connection", "local")
    plugin2 = Plugin("connection", "ssh")

    config_data.update_setting(global_setting1, None)
    config_

# Generated at 2022-06-20 13:37:30.908628
# Unit test for constructor of class ConfigData
def test_ConfigData():
    from plugin_setting import PluginSetting

    config_data = ConfigData()

    setting1 = PluginSetting(False, 'g1')
    setting2 = PluginSetting(False, 'g2')
    setting3 = PluginSetting(True, 'a1')
    setting4 = PluginSetting(True, 'b1')
    setting5 = PluginSetting(True, 'b2')
    setting6 = PluginSetting(True, 'b3')

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting3, setting3.plugin)
    config_data.update_setting(setting4, setting4.plugin)
    config_data.update_setting(setting5, setting5.plugin)

    settings = config_data.get_settings()

# Generated at 2022-06-20 13:37:33.183775
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting('a')
    result = config_data.get_setting('a')
    assert result == 'a', 'Not able to update setting'

# Generated at 2022-06-20 13:37:37.297830
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cfgdata = ConfigData()
    assert {} == cfgdata._global_settings
    assert {} == cfgdata._plugins

# Generated at 2022-06-20 13:37:47.735047
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.config_module import Setting

# Generated at 2022-06-20 13:37:52.555801
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Fixture setup
    valid_setting = Setting("host_key_checking", "yes")
    global_settings = [Setting("host_key_checking", "yes"), Setting("color", "yes")]
    plugins = [{"type": "callback", "name": "verbose",
                "settings": [Setting("one", "1"), Setting("two", "2")]},
               {"type": "callback", "name": "default",
                "settings": [Setting("platform", "linux"), Setting("version", "1.0")]}]

    my_config = ConfigData()
    my_config._global_settings = {}
    my_config._plugins = {}

    #Test setup
    for s in global_settings:
        my_config.update_setting(s)


# Generated at 2022-06-20 13:37:54.147240
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config is not None


# Generated at 2022-06-20 13:38:01.921117
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    from ansible import constants as C
    from ansible.cli.playbook.play.vars import VarsPlugin
    plugin = VarsPlugin(play=None,
                        inventory=None,
                        loader=None,
                        display=None,
                        options=None)
    plugin.name = C.DEFAULT_VARS_PLUGIN
    plugin.type = 'vars'
    config_data.update_setting(setting=config_data, plugin=plugin)


# Generated at 2022-06-20 13:38:06.882280
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    global_setting = Setting('foo', 'bar')
    plugin = Plugin('foo', 'baz', 'bar')
    plugin_setting = Setting('foo', 'baz')

    config_data.update_setting(global_setting)
    test_setting = config_data.get_setting(global_setting.name)
    assert test_setting == global_setting

    config_data.update_setting(plugin_setting, plugin)
    test_setting = config_data.get_setting(plugin_setting.name, plugin)
    assert test_setting == plugin_setting



# Generated at 2022-06-20 13:38:12.382021
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()

    result = cd.get_settings()

    assert isinstance(result, list)
    assert len(result) == 0

    assert result == []

# Generated at 2022-06-20 13:38:13.840392
# Unit test for constructor of class ConfigData
def test_ConfigData():
    a = ConfigData()
    assert a is not None


# Generated at 2022-06-20 13:38:37.886832
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    # Test case for updating a global setting
    setting_global = {
        "name": "test_setting_global",
        "value": "test_value_global",
        "default": "test_default_global"
    }
    config_data.update_setting(setting_global)
    assert config_data.get_setting(setting_global["name"]) == setting_global

    # Test case for updating a setting for a callback plugin
    plugin_type = 'callback'
    plugin_name = 'my_callback_plugin'
    setting = {
        "name": "test_setting_callback",
        "value": "test_value_callback",
        "default": "test_default_callback"
    }

# Generated at 2022-06-20 13:38:46.983807
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from config import ConfigData
    from config import ConfigSetting

    # Test case with two global setting and two plugin setting
    setting1 = ConfigSetting()
    setting1.name = "setting1"
    setting2 = ConfigSetting()
    setting2.name = "setting2"
    setting3 = ConfigSetting()
    setting3.name = "setting3"
    setting4 = ConfigSetting()
    setting4.name = "setting4"

    config = ConfigData()
    config.update_setting(setting1)
    config.update_setting(setting2)
    config.update_setting(setting3, plugin='plugin1')
    config.update_setting(setting4, plugin='plugin2')

    # Test with global in second place
    setting = config.get_setting('setting2')
    assert setting.name == 'setting2'

    #

# Generated at 2022-06-20 13:38:51.335832
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config is not None
    assert len(config._global_settings) == 0
    assert len(config._plugins) == 0

# Generated at 2022-06-20 13:39:01.346738
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting('default_inventory') is None
    assert config_data.get_settings() == []
    setting = Setting('default_inventory', 'ansible.cfg', 'fake-data')
    config_data.update_setting(setting)
    assert config_data.get_setting('default_inventory') == setting
    assert config_data.get_settings() == [setting]

    assert config_data.get_setting('default_callback_whitelist', Plugin('callback', 'first')) is None
    assert config_data.get_setting('default_callback_whitelist', Plugin('callback', 'second')) is None
    assert config_data.get_settings(Plugin('callback', 'first')) == []

# Generated at 2022-06-20 13:39:11.503168
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()

    assert configData.get_setting('ANSIBLE_NOCOWS') == None

    configData.update_setting(ConfigDataSetting('ANSIBLE_NOCOWS', 'true', 'bool', 'env', 'string'))

    assert configData.get_setting('ANSIBLE_NOCOWS')._name == 'ANSIBLE_NOCOWS'
    assert configData.get_setting('ANSIBLE_NOCOWS')._value == 'true'
    assert configData.get_setting('ANSIBLE_NOCOWS')._type == 'bool'
    assert configData.get_setting('ANSIBLE_NOCOWS')._scope == 'env'
    assert configData.get_setting('ANSIBLE_NOCOWS')._origin == 'string'


# Generated at 2022-06-20 13:39:16.961037
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin_client = PluginClient("myplugin")
    config_data = ConfigData()
    plugin_setting = PluginSetting("setting_name", "setting_value")
    config_data.update_setting(plugin_setting, plugin=plugin_client)
    assert(config_data._plugins["client"]["myplugin"]["setting_name"] == plugin_setting)


# Generated at 2022-06-20 13:39:17.648652
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()

# Generated at 2022-06-20 13:39:23.455922
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test no plugins
    assert(config_data.get_setting('foo') is None)

    # Test with plugin
    plugin = AnsiblePlugin()
    config_data.update_setting(setting='foo', plugin=plugin)
    assert(config_data.get_setting('foo', plugin=plugin) == 'foo')


# Generated at 2022-06-20 13:39:24.285969
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    assert False

# Generated at 2022-06-20 13:39:26.586720
# Unit test for constructor of class ConfigData
def test_ConfigData():

    data = ConfigData()

    assert(data is not None)
    assert(data._global_settings is not None)
    assert(data._plugins is not None)


# Generated at 2022-06-20 13:39:40.581836
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cd.update_setting("global_setting_1")
    assert cd.get_setting("global_setting_1") == "global_setting_1"
    cd.update_setting("global_setting_2")
    assert cd.get_setting("global_setting_2") == "global_setting_2"
    cd.update_setting("global_setting_3", "plugin-1")
    assert cd.get_setting("global_setting_3", "plugin-1") == "global_setting_3"
    cd.update_setting("global_setting_3", "plugin-1")
    assert cd.get_setting("global_setting_3", "plugin-1") == "global_setting_3"
    cd.update_setting("global_setting_4", "plugin-2")
    assert cd.get

# Generated at 2022-06-20 13:39:50.074780
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    cd = ConfigData()
    assert(len(cd.get_settings()) == 0)

    from jinja2 import Undefined
    from ansible.plugins.loader import PluginLoader
    from ansible.config.plugin_settings import PluginSetting
    import pytest
    pytest.importorskip('ansible.plugins.action')

    shell_plugin = PluginLoader.find_plugin('action', 'shell')
    setting = PluginSetting('foo', 'bar', Undefined, 'baz')
    cd.update_setting(setting)
    assert(len(cd.get_settings()) == 1)
    assert(cd.get_settings()[0].name == setting.name)
    assert(cd.get_settings()[0].value == setting.value)
    assert(cd.get_settings(plugin=shell_plugin) == None)



# Generated at 2022-06-20 13:39:53.300368
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()

# Generated at 2022-06-20 13:39:55.594021
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config is not None
    assert config._global_settings == {}
    assert config._plugins == {}


# Generated at 2022-06-20 13:39:57.574301
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-20 13:40:00.328907
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()

    #Should be empty
    assert(configData._global_settings == {})
    assert(configData._plugins == {})


# Generated at 2022-06-20 13:40:07.592907
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(Setting(name='os', value='darwin'))
    config.update_setting(Setting(name='python_path', value='/usr/bin/python', plugin=Plugin(name='my_plugin', type='action')))

    assert config.get_setting('os') is not None
    assert config.get_setting('python_path') is None
    assert config.get_setting('python_path', Plugin(name='my_plugin', type='action')) is not None
    assert config.get_setting('python_path', Plugin(name='another_plugin', type='action')) is None


# Generated at 2022-06-20 13:40:10.234513
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert (config_data is not None)


# Generated at 2022-06-20 13:40:16.606842
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = AnsiblePlugin('foo', 'bar')
    setting = AnsibleSetting('foo', 'bar')
    config_data.update_setting(setting, plugin)
    assert config_data


# Generated at 2022-06-20 13:40:19.312949
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cd = ConfigData()

    assert len(cd._global_settings) == 0
    assert len(cd._plugins) == 0



# Generated at 2022-06-20 13:40:50.209972
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Unit test for method get_settings of class ConfigData
    # when there's a global setting
    global_setting = Setting('global_setting', 'global_value')
    config_data.update_setting(global_setting)
    settings = config_data.get_settings()
    assert len(settings) == 1
    assert settings[0] == global_setting

    # Unit test for method get_settings of class ConfigData
    # when there are settings for a plugin
    plugin_setting1 = Setting('plugin_setting1', 'plugin_value1')
    plugin_setting2 = Setting('plugin_setting2', 'plugin_value2')
    plugin1 = Plugin('action', 'echo')
    config_data.update_setting(plugin_setting1, plugin1)

# Generated at 2022-06-20 13:40:57.358837
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert (config.get_setting("foo") is None)

    setting = Setting('foo')
    config.update_setting(setting)
    assert (config.get_setting("foo") is setting)

    plugin = Plugin('bar', 'baz', 'baz')
    config.update_setting(setting, plugin)
    assert (config.get_setting("foo") is None)
    assert (config.get_setting("foo", plugin) is setting)



# Generated at 2022-06-20 13:40:58.354468
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData() is not None

# Generated at 2022-06-20 13:41:03.472487
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    global_setting = {'foo': 'bar'}
    config_data._global_settings = global_setting
    assert config_data.get_setting('foo') == global_setting['foo']

    plugin_setting = {'foo': 'bar'}
    config_data._plugins = {'foo': {'bar': plugin_setting}}
    assert config_data.get_setting('foo', plugin='bar') == plugin_setting['foo']


# Generated at 2022-06-20 13:41:14.945887
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    from ansible.utils.plugin_docs import get_docstring

    plugin = Plugin(name=None, type=None)
    settings = config_data.get_settings(plugin)
    assert(len(settings) == 0)

    plugin1 = Plugin(name="plugin1", type='plugin_type')
    Configuration(name="setting1", plugin=plugin1)
    Configuration(name="setting2", plugin=plugin1)
    config_data.update_setting(Configuration(name="setting1", plugin=plugin1))
    config_data.update_setting(Configuration(name="setting2", plugin=plugin1))

    settings = config_data.get_settings(plugin1)
    assert(len(settings) == 2)

# Generated at 2022-06-20 13:41:18.430710
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar', 'description')
    config_data.update_setting(setting)
    assert setting == config_data.get_setting('foo')
    plugin = Plugin('cache', 'Test Plugin', 'cache')
    config_data.update_setting(setting, plugin)
    assert setting == config_data.get_setting('foo', plugin)



# Generated at 2022-06-20 13:41:25.996407
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = Plugin('TestPlugin')
    setting1 = Setting('test1', 'value1')
    setting2 = Setting('test2', 'value2')
    setting3 = Setting('test3', 'value3')
    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin)
    config_data.update_setting(setting3, plugin)

    assert config_data.get_setting('test2') is None
    assert config_data.get_setting('test1') == setting1
    assert config_data.get_setting('test2', plugin) == setting2
    assert config_data.get_setting('test3', plugin) == setting3


# Generated at 2022-06-20 13:41:27.547612
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data


# Generated at 2022-06-20 13:41:28.929023
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data is not None


# Generated at 2022-06-20 13:41:31.370304
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='foo'))
    assert config_data.get_setting('foo') is not None


# Generated at 2022-06-20 13:42:22.610388
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    setting1 = {'name': 'setting1', 'value': 'value1', 'origin': 'test_host.yml'}
    config._global_settings[setting1['name']] = setting1
    setting2 = {'name': 'setting2', 'value': 'value2', 'origin': 'test_host.yml'}
    config._global_settings[setting2['name']] = setting2
    assert config.get_setting(setting1['name']).value == setting1['value']
    assert config.get_settings()[0].value == setting1['value']
    assert config.get_settings()[1].value == setting2['value']

# Generated at 2022-06-20 13:42:25.905869
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='test_setting_1', value='test_value_1'))
    assert config_data._global_settings['test_setting_1'] == Setting(name='test_setting_1', value='test_value_1')


# Generated at 2022-06-20 13:42:36.482836
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    # global setting
    test_get_setting(config_data)
    # action setting
    from ConfigParser import ConfigParser
    from ansible.plugins.action import ActionBase
    test_plugin = ActionBase()
    test_plugin.NAME = 'test'
    test_plugin.type = 'action'
    test_get_setting(config_data, test_plugin)
    # callback setting
    from ansible.plugins.callback import CallbackBase
    test_plugin = CallbackBase()
    test_plugin.NAME = 'test'
    test_plugin.type = 'callback'
    test_get_setting(config_data, test_plugin)
    # connection setting
    from ansible.plugins.connection import ConnectionBase
    test_plugin = ConnectionBase(None)

# Generated at 2022-06-20 13:42:39.950731
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    setting = Setting('host_key_checking', 'True')
    cd.update_setting(setting)
    assert cd.get_setting('host_key_checking').value == 'True' 


# Generated at 2022-06-20 13:42:48.403488
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    import unittest
    import ansible.utils.plugin_docs as plugin_docs

    docs = plugin_docs.ConfigData()

    #
    # Test ConfigData.get_setting with a setting that does not exist
    #
    ansible_setting = docs.get_setting("does not exist")
    assert ansible_setting is None

    #
    # Test ConfigData.get_setting with a setting that does not exist but has a default
    #
    ansible_setting = docs.get_setting("does not exist", plugin_docs.PluginOption("filter", "normalize"))
    assert ansible_setting is None

    #
    # Test ConfigData.get_setting with a setting that exists and has a default
    #

# Generated at 2022-06-20 13:42:56.232253
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert None == config_data.get_setting('disabled_group_priorities')
    assert None == config_data.get_setting('disabled_group_priorities', 'callback')
    setting = Setting('disabled_group_priorities', 'False', '', '')
    config_data.update_setting(setting, 'callback')
    assert 'False' == config_data.get_setting('disabled_group_priorities', 'callback').value
    assert 'False' == config_data.get_setting('disabled_group_priorities').value



# Generated at 2022-06-20 13:43:00.609618
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting("abc")
    config_data.update_setting("xyz")
    assert config_data.get_settings() == ["abc", "xyz"]

# Generated at 2022-06-20 13:43:06.237401
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data is not None
    assert config_data._global_settings is not None
    assert config_data._plugins is not None

    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0

# Unit tests for get_setting method of class ConfigData

# Generated at 2022-06-20 13:43:11.029319
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin_type = "c"
    plugin_name = "n"
    setting_name = "s"
    value = "v"
    plugin = Plugin(plugin_type, plugin_name)
    setting = Setting(setting_name, value)
    config_data.update_setting(setting, plugin)
    settings = config_data.get_settings(plugin)
    assert settings[0].name == setting_name
    assert settings[0].value == value