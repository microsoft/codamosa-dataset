

# Generated at 2022-06-20 13:33:15.789462
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert c is not None
    assert c._global_settings == {}
    assert c._plugins == {}


# Generated at 2022-06-20 13:33:19.326404
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
	assert True

# Generated at 2022-06-20 13:33:28.106977
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from plugin_setting import PluginSetting
    from plugin_spec import PluginSpec
    a = ConfigData()
    b = PluginSetting('var1', 'value1', 'description1', None, [], {}, {})
    c = PluginSetting('var2', 'value2', 'description2', None, [], {}, {})
    a.update_setting(b)
    a.update_setting(c)
    d = PluginSetting('var3', 'value3', 'description3', None, [], {}, {})
    e = PluginSetting('var4', 'value4', 'description4', None, [], {}, {})
    b = PluginSpec('plugin_type', 'plugin_name')
    a.update_setting(d, b)
    a.update_setting(e, b)

# Generated at 2022-06-20 13:33:37.974836
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from units.compat import mock
    from units.compat.mock import MagicMock
    from units.compat.mock import patch
    from units.compat.mock import call

    mocked_plugin = mock.create_autospec(MagicMock, name='plugin')

    mocked_plugin.type = 'foo'
    mocked_plugin.name = 'bar'

    mocked_setting = mock.create_autospec(MagicMock, name='setting')

    mocked_setting.name = 'baz'
    mocked_setting.value = 'qux'

    ConfigData().update_setting(setting=mocked_setting, plugin=mocked_plugin)
    assert ConfigData().get_setting(name='baz').value == 'qux'

# Generated at 2022-06-20 13:33:41.596971
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    assert configData._global_settings == {}
    assert configData._plugins == {}


# Generated at 2022-06-20 13:33:56.641387
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_setting_1 = {'plugin': {'type': 'module', 'name': 'dummy_module'}, 'name': 'dummy1', 'value': None}
    test_setting_2 = {'plugin': {'type': 'module', 'name': 'dummy_module'}, 'name': 'dummy2', 'value': None}
    test_setting_3 = {'plugin': {'type': 'module', 'name': 'dummy_module2'}, 'name': 'dummy3', 'value': None}

    config = ConfigData()
    config.update_setting(test_setting_1)
    config.update_setting(test_setting_2)
    config.update_setting(test_setting_3)

# Generated at 2022-06-20 13:33:57.600375
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData()


# Generated at 2022-06-20 13:34:06.614684
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    conf = ConfigData()
    s1 = Setting('a', 'b')
    s2 = Setting('a', 'b', 'c')
    s3 = Setting('a', 'b', 'c')
    s4 = Setting('b', 'b', 'c')
    conf.update_setting(s1)
    assert conf.get_settings() == [s1]
    conf.update_setting(s2)
    assert conf.get_settings() == [s1]
    assert conf.get_settings(s2) == [s2]
    assert conf.get_setting(s2.name, s2) == s2
    conf.update_setting(s3)
    assert conf.get_settings(s2) == [s2, s3]

# Generated at 2022-06-20 13:34:13.078721
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    
    class Setting:
        def __init__(self):
            self.name = None
            self.value = None

    # Test get_setting with a plugin
    plugin = Setting()
    plugin.name = "plugin_name"
    plugin.type = "plugin_type"
    plugin_setting = Setting()
    plugin_setting.name = "plugin_setting"
    plugin_setting.value = "plugin_value"
    data.update_setting(plugin_setting, plugin)
    assert data.get_setting("plugin_setting", plugin) == plugin_setting
    assert data.get_setting("plugin_setting") is None

    # Test get_setting without a plugin
    global_setting = Setting()
    global_setting.name = "global_setting"

# Generated at 2022-06-20 13:34:19.633198
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()
    setting_global = Setting("global_setting", "global")
    setting_plugin = Setting("plugin_setting", "plugin")
    configdata.update_setting(setting_global)
    plugin = Plugin("local_plugin", "lookup")
    configdata.update_setting(setting_plugin, plugin)
    assert configdata.get_setting("global_setting") == setting_global
    assert configdata.get_setting("plugin_setting", plugin) == setting_plugin



# Generated at 2022-06-20 13:34:23.325270
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    data = ConfigData()

    # Empty configuration data
    assert data.get_settings() == []


# Generated at 2022-06-20 13:34:32.685563
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test 1
    config_data = ConfigData()
    setting_1 = Setting("test1", "test1")
    config_data.update_setting(setting_1)
    setting_2 = Setting("test2", "test2")
    config_data.update_setting(setting_2)
    assert config_data.get_setting("test1") == setting_1
    assert config_data.get_setting("test2") == setting_2
    assert config_data.get_setting("test3", "test") is None

    # Test 2
    plugin = Plugin("test", "test")
    setting = Setting("test", "test")
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting("test", plugin) == setting



# Generated at 2022-06-20 13:34:35.018472
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert not config_data._global_settings
    assert not config_data._plugins


# Generated at 2022-06-20 13:34:44.590073
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    from ansible.plugins.loader import PluginLoader
    from ansible.config.manager import ConfigManager
    from ansible.config.data import PluginConfig
    from ansible.config.data import Setting

    plugin = PluginLoader.load_plugin('./test/test_plugins/test_module_path', 'TestModulePath', 'test_module_path')
    config_data.update_setting(Setting('test_setting', 'test_value'))
    config_data.update_setting(Setting('test_setting2', 'test_value2'))

    config_data.update_setting(Setting('test_setting', 'test_plugin_value'), plugin)
    config_data.update_setting(Setting('test_setting2', 'test_plugin_value2'), plugin)

    test_setting = config_data

# Generated at 2022-06-20 13:34:49.192856
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # try to create a new ConfigData object
    data = ConfigData()
    assert(data)

    # the ConfigData object is successfully created
    print("Successfully created a new ConfigData object")


# Generated at 2022-06-20 13:34:53.094597
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    global_setting = Setting('global', 'global', 'global value')
    config_data.update_setting(global_setting)

    assert config_data.get_setting('global') == global_setting


# Generated at 2022-06-20 13:35:02.668179
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Test an update of a global setting
    settings = ConfigData()
    global_setting = ConfigSetting(name='global', value='global')
    settings.update_setting(global_setting)
    assert settings.get_setting('global') is global_setting

    # Test an update of a plugin setting
    # If we're here, global settings have been setup
    # so we won't test them again
    plugin = Plugin(type='mod', name='action')
    plugin_setting = ConfigSetting(name='test', value='test')
    settings.update_setting(plugin_setting, plugin)
    assert settings.get_setting('test', plugin) is plugin_setting



# Generated at 2022-06-20 13:35:16.149244
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from units.mock.loader import DictDataLoader
    from units.mock.plugin import MockPlugin

    config_data = ConfigData()

    setting = DictDataLoader({'name': 'foo', 'value': 'bar'})
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting

    plugin = MockPlugin('bar', 'baz')
    setting = DictDataLoader({'name': 'foo', 'value': 'bar'})
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('foo', plugin) == setting

    plugin = MockPlugin('bar', 'baz')
    setting = DictDataLoader({'name': 'foo', 'value': 'bar'})
    config_data.update_setting(setting)

# Generated at 2022-06-20 13:35:25.800944
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # test global settings
    setting_1 = Setting('setting_1', 'global setting 1')
    config_data.update_setting(setting_1)
    assert config_data.get_settings()[0].name == 'setting_1'
    assert config_data.get_settings()[0].value == 'global setting 1'

    # test plugin specific settings
    plugin = Plugin(name='test', type='test_type')
    setting_2 = Setting('setting_2', 'plugin setting 1')
    config_data.update_setting(setting_2, plugin)
    assert config_data.get_settings(plugin)[0].name == 'setting_2'
    assert config_data.get_settings(plugin)[0].value == 'plugin setting 1'



# Generated at 2022-06-20 13:35:35.789795
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from units.mock.config_data import ConfigData
    from units.mock.plugins import MockPlugin

    config_data = ConfigData()
    plugin1 = MockPlugin('my_plugin_type')
    plugin2 = MockPlugin('my_plugin_type')
    plugin1.name = 'plugin1'
    plugin2.name = 'plugin2'

    setting1 = plugin1.get_settings()[0]
    setting2 = plugin2.get_settings()[0]
    setting1.name = 'my_setting'
    setting2.name = 'my_setting'

    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin2)

    assert setting1 not in config_data.get_settings(plugin1)

# Generated at 2022-06-20 13:35:51.166714
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    s1 = Setting('setting1', 'value1')
    s2 = Setting('setting2', 'value2')
    s3 = Setting('setting3', 'value3')
    s4 = Setting('setting4', 'value4')

    config_data.update_setting(s1)
    config_data.update_setting(s2)
    config_data.update_setting(s3)

    p = Plugin('test', 'lookup', 'plugins/lookup/test.py', '', '', '', '', '', '', '')

    config_data.update_setting(s4, p)

    assert config_data.get_settings() == [s1, s2, s3]
    assert config_data.get_settings(p) == [s4]
    assert config_

# Generated at 2022-06-20 13:35:54.555860
# Unit test for constructor of class ConfigData
def test_ConfigData():
    test_config_data = ConfigData()
    assert test_config_data._global_settings == {}
    assert test_config_data._plugins == {}


# Generated at 2022-06-20 13:35:55.699769
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data is not None

# Generated at 2022-06-20 13:36:07.710022
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    setting = config_data.get_setting('default_config_file')
    assert setting.name == 'default_config_file'
    assert setting.value == 'config.yaml'

    setting = config_data.get_setting('default_inventory_file')
    assert setting.name == 'default_inventory_file'
    assert setting.value == 'myansible/hosts'

    setting = config_data.get_setting('default_persistent_connection')
    assert setting.name == 'default_persistent_connection'
    assert setting.value == 'ssh'

    setting = config_data.get_setting('default_playbook_file')
    assert setting.name == 'default_playbook_file'
    assert setting.value == 'myansible/playbook.yaml'

    setting

# Generated at 2022-06-20 13:36:14.549143
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    assert config_data.get_setting(name = 'default_config_data') != None
    assert config_data.get_setting(name = 'default_config_data') == config_data
    assert config_data.get_setting(name = 'default_plugin_data') == None

    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader.get('action', 'pause')
    assert config_data.get_setting(name = 'default_config_data', plugin = plugin) == config_data
    assert config_data.get_setting(name = 'default_plugin_data', plugin = plugin) == None


# Generated at 2022-06-20 13:36:17.426403
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata=ConfigData()
    #assert configdata._global_settings == {}
    #assert configdata._plugins == {}


# Generated at 2022-06-20 13:36:19.545268
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    assert isinstance(configData, ConfigData)


# Generated at 2022-06-20 13:36:25.961868
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    setting = Setting('var', 'config_dir')
    setting.value = '/root/test'
    config.update_setting(setting)
    data = config.get_setting('config_dir')

    assert data.value == '/root/test'


# Generated at 2022-06-20 13:36:39.725414
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblelint.rules.AnsibleLintRule import AnsibleLintRule

    r1 = AnsibleLintRule("no-pip", "Use the 'yum' module rather than running 'pip'")
    r2 = AnsibleLintRule("no-apt", "Use the 'yum' module rather than running 'apt'")
    r3 = AnsibleLintRule("no-zypper", "Use the 'yum' module rather than running 'zypper'")

    setting1 = ConfigSetting("no-pip", "Use the 'yum' module rather than running 'pip'", "ERROR", r1, True)
    setting2 = ConfigSetting("no-apt", "Use the 'yum' module rather than running 'apt'", "ERROR", r2, True)

# Generated at 2022-06-20 13:36:42.189977
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # setup
    config_data = ConfigData()
    # execution
    result = config_data.get_settings()
    # assertion
    assert result == []



# Generated at 2022-06-20 13:36:58.532130
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    from ansible.utils.plugin_docs import ConfigSetting
    cs1 = ConfigSetting('name1')
    cs2 = ConfigSetting('name2')
    cs3 = ConfigSetting('name3')
    cs4 = ConfigSetting('name4')
    assert cd.get_setting('name1') is None
    cd.update_setting(cs1)
    assert cd.get_setting('name1') == cs1
    assert cd.get_setting('name2') is None
    from ansible.plugins.loader import PluginLoader
    cl = PluginLoader('cache')
    cd.update_setting(cs2, cl)
    assert cd.get_setting('name2') is None
    assert cd.get_setting('name3') is None
    cd.update_setting(cs3, cl)
    assert cd.get

# Generated at 2022-06-20 13:37:04.594352
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = {'name': 'attr1', 'value': 111}
    config_data.update_setting(setting)
    setting = {'name': 'attr2', 'value': 222}
    config_data.update_setting(setting)
    assert config_data.get_setting('attr2') == {'name': 'attr2', 'value': 222}


# Generated at 2022-06-20 13:37:12.685956
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblite.plugins.loader import PluginLoader

    config_data = ConfigData()

    test_plugin_name = 'TestPlugin'
    test_plugin_type = 'action'

    test_setting_name = 'test'
    test_setting_value = 'value'

    plugin = PluginLoader.find_plugin(test_plugin_name, test_plugin_type)
    setting = Setting('test_setting_name', 'test_setting_value')

    assert config_data.get_setting(test_setting_name, plugin) is None

    config_data.update_setting(setting, plugin)

    assert config_data.get_setting(test_setting_name, plugin) == test_setting_value



# Generated at 2022-06-20 13:37:18.792739
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Create an instance of the class
    data = ConfigData()

    # Create a Mock
    data._global_settings = {
        'reset': 'default_value',
        'setting': 'value'
    }

    # Call the method with a non-existing setting
    assert data.get_setting('not_existing') is None

    # Call the method with a global setting
    assert data.get_setting('setting') == 'value'

    # Create a Mock
    data._plugins = {
        'module': {
            'setup': {
                'reset': 'default_value',
                'setting': 'value'
            }
        }
    }

    # Call the method with a plugin setting
    assert data.get_setting('setting', Plugin('module', 'setup')) == 'value'



# Generated at 2022-06-20 13:37:25.594817
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data
    setting = {'name': 'setting1', 'value': 'val1', 'src': 'src1'}
    setting2 = {'name': 'setting2', 'value': 'val2', 'src': 'src2'}
    setting3 = {'name': 'setting3', 'value': 'val3', 'src': 'src3'}


# Generated at 2022-06-20 13:37:37.621439
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from collections import namedtuple

    Plugin = namedtuple('Plugin', ['type', 'name'])
    Setting = namedtuple('Setting', ['name', 'default_value', 'constant', 'required', 'choices', 'deprecated'])

    cd = ConfigData()
    assert cd.get_setting('force_handlers') is None

    cd.update_setting(Setting('force_handlers', False, True, False, [], []))
    assert cd.get_setting('force_handlers').default_value == False

    cd.update_setting(Setting('force_handlers', True, True, False, [], []))
    assert cd.get_setting('force_handlers').default_value == True


# Generated at 2022-06-20 13:37:40.825469
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:37:45.032312
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert len(data._global_settings) == 0
    assert len(data._plugins) == 0

# Generated at 2022-06-20 13:37:49.620947
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='string_setting'))
    assert config_data.get_setting(name='string_setting') is not None
    config_data.update_setting(Setting(name='array_setting'))
    assert config_data.get_setting(name='array_setting') is not None


# Generated at 2022-06-20 13:38:03.538438
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()
    setting_global = Setting('red_hat_subscription', 'subscription_url', 'subscription.rhsm.redhat.com')
    configdata.update_setting(setting_global)
    assert setting_global == configdata.get_setting('subscription_url')
    assert None == configdata.get_setting('subscription_url', 'subscription.rhsm.redhat.com')

    plugin = Plugin('subscription_manager', 'subscription_manager')
    setting_subscription_manager = Setting('subscription_manager', 'subscription_url', 'subscription.rhsm.redhat.com')
    configdata.update_setting(setting_subscription_manager, plugin)
    assert setting_subscription_manager == configdata.get_setting('subscription_url', plugin)

# Unit test

# Generated at 2022-06-20 13:38:22.184227
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    from ansible.config.setting import Setting

    setting_a = Setting('setting_a')
    config_data.update_setting(setting_a)

    setting_b = Setting('setting_b')
    config_data.update_setting(setting_b)

    assert config_data.get_setting('setting_a') == setting_a
    assert config_data.get_setting('setting_b') == setting_b

    from ansible.config.config import collect_all_plugins

    plugin_b = collect_all_plugins('shell')[0]
    setting_b_shell = Setting('setting_b')
    config_data.update_setting(setting_b_shell, plugin_b)

    plugin_a = collect_all_plugins('shell')[1]
    setting_a_shell

# Generated at 2022-06-20 13:38:23.066342
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert isinstance(ConfigData(), ConfigData)

# Generated at 2022-06-20 13:38:27.028302
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    '''
    Ensure proper working of update_setting method
    '''
    assert True

# Generated at 2022-06-20 13:38:29.241285
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config


# Generated at 2022-06-20 13:38:32.519500
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    a = ConfigData()
    a.update_setting(None)
    a.get_setting(None)
    a.get_setting(None, None)


# Generated at 2022-06-20 13:38:33.832839
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()



# Generated at 2022-06-20 13:38:34.449425
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config is not None


# Generated at 2022-06-20 13:38:37.085505
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    s = Setting('key', 'value')
    cd.update_setting(s)
    assert cd.get_setting('key') == s


# Generated at 2022-06-20 13:38:46.639945
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('name1'))
    config_data.update_setting(Setting('name2'), 'shell')
    config_data.update_setting(Setting('name3'), 'network', 'napalm')
    # Test with empty config_data
    assert config_data.get_setting('name1') == Setting('name1')
    assert config_data.get_setting('name2', 'shell') == Setting('name2')
    assert config_data.get_setting('name3', 'network', 'napalm') == Setting('name3')
    assert config_data.get_settings() == [Setting('name1')]
    assert config_data.get_settings('shell') == [Setting('name2')]

# Generated at 2022-06-20 13:38:58.159836
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    # Test get_settings() when there is no setting
    assert config_data.get_settings() == []
    # Test get_settings(plugin) when there is no setting
    from ansible.plugins.loader import TestConnectionPlugin
    plugin = TestConnectionPlugin('test')
    assert config_data.get_settings(plugin) == []

    from ansible.module_utils.six.moves import configparser
    from ansible.utils.vars import combine_vars
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.plugins.loader import shared_loader_obj
    # Create a fake setting
    setting = to_native(to_bytes('foo'), errors='strict')
    config = configparser.ConfigParser()

# Generated at 2022-06-20 13:39:20.231104
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(Setting('verbosity', '10', 'global', 'descreption'))

    assert config.get_setting('verbosity') is not None


# Generated at 2022-06-20 13:39:27.725283
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='test_name', value='test_value'))
    assert config_data.get_setting(name='test_name').value == 'test_value'
    config_data.update_setting(Setting(name='test_name', value='modified_value'), plugin=Plugin(name='test_plugin', type='test_type'))
    assert config_data.get_setting(name='test_name', plugin=Plugin(name='test_plugin', type='test_type')).value == 'modified_value'


# Generated at 2022-06-20 13:39:35.903304
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from collections import namedtuple
    from ansiblelint.rules import runner
    from ansiblelint.rules.MetaDoubleQuotedString import MetaDoubleQuotedString

    plugin = namedtuple("plugin", ["name", "type"])
    data = ConfigData()
    data.update_setting(MetaDoubleQuotedString("DOCUMENTATION_SHOULD_START_WITH_DOUBLE_QUOTE", "include", "command"), plugin("runner", "rules"))
    data.update_setting(MetaDoubleQuotedString("DOCUMENTATION_SHOULD_START_WITH_DOUBLE_QUOTE", "include", "command"), plugin("runner", "rules"))
    settings = data.get_settings(plugin("runner", "rules"))
    assert 2 == len(settings)
    assert type(settings[0]) is MetaDoubleQuoted

# Generated at 2022-06-20 13:39:38.289364
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='test1'))
    assert len(config_data._global_settings) == 1
    assert len(config_data._plugins) == 0
    assert config_data._global_settings['test1'].name == 'test1'


# Generated at 2022-06-20 13:39:47.593074
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    cd = ConfigData()

    # no setting is set
    assert None is cd.get_setting("foo")

    # setting exists
    assert None is cd.get_setting("foo")

    # setting is added
    setting = Setting("foo", 1, {})
    cd.update_setting(setting)
    assert setting is cd.get_setting("foo")

    # setting does not exist for plugin
    assert None is cd.get_setting("bar", Plugin("shell", "sh"))

    # setting is added for plugin
    setting = Setting("bar", 1, {})
    cd.update_setting(setting, Plugin("shell", "sh"))
    assert setting is cd.get_setting("bar", Plugin("shell", "sh"))

# Generated at 2022-06-20 13:39:49.041108
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    assert configData._global_settings == {}
    assert configData._plugins == {}


# Generated at 2022-06-20 13:40:00.478982
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # this method it tests is depend on the get_setting method.
    # so we make an object of type ConfigData and call the get_setting method to
    # populate it's internal dictionary.
    obj = ConfigData()
    obj.update_setting(setting=ConfigSetting(
        name='test', plugin=ConfigPlugin(type='test', name='test')))
    settings = obj.get_settings(ConfigPlugin(type='test', name='test'))

    assert settings[0].plugin.type == 'test'
    assert settings[0].name == 'test'



# Generated at 2022-06-20 13:40:08.327272
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

    setting1 = ConfigSetting(name='setting1', priority=1)
    setting2 = ConfigSetting(name='setting2', priority=2)
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'setting1'
    assert config_data.get_settings()[1].name == 'setting2'
    assert config_data.get_settings()[0].priority == 1
    assert config_data.get_settings()[1].priority == 2


# Generated at 2022-06-20 13:40:19.969521
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.plugins.loader import PluginLoader

    config = ConfigData()

    assert config.get_setting('fact_caching_timeout') is None
    assert config.get_setting('fact_caching_timeout', PluginLoader.find_plugin(None, 'caching')) is None

    config.update_setting(Setting(name='fact_caching_timeout', value=42))
    assert config.get_setting('fact_caching_timeout') is not None
    assert config.get_setting('fact_caching_timeout').name == 'fact_caching_timeout'
    assert config.get_setting('fact_caching_timeout').value == 42

    config.update_setting(Setting(name='fact_caching_timeout', value=42), PluginLoader.find_plugin(None, 'caching'))
    assert config.get_

# Generated at 2022-06-20 13:40:20.784359
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data


# Generated at 2022-06-20 13:41:02.363331
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin("connection","local")
    plugin2 = Plugin("connection","paramiko")
    plugin3 = Plugin("shell","bash")
    plugin4 = Plugin("shell","powershell")

    setting1 = Setting("timeout",10,plugin)
    setting2 = Setting("timeout",20,plugin)
    setting3 = Setting("timeout",30,plugin2)
    setting4 = Setting("env",["A=1","B=2","C=3"],plugin)
    setting5 = Setting("env",["D=4","E=5","F=6"],plugin)
    setting6 = Setting("cwd","/home/test/test_dir",plugin)
    setting7 = Setting("cwd","/home/test/",plugin)
    setting8 = Setting("prompt","test>",plugin3)
    setting

# Generated at 2022-06-20 13:41:09.834489
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    import pytest
    from units.compat.mock import MagicMock, Mock
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.action import ActionBase
    from ansible.utils.path import unfrackpath
    import os

    config_data = ConfigData()

    # Expected behaviour:
        # get_setting('foo', None) -> returns None
        # get_setting('foo', Plugin('action', 'foo')) -> returns None
    for plugin in [None, Plugin('action', 'foo')]:
        assert config_data.get_setting('foo', plugin) is None

    # Expected behaviour:
        # get_setting('foo', None) -> returns Setting('foo', 'bar')
        # get_setting('foo', Plugin('action', 'foo')) -> returns Setting('foo', 'bar')
   

# Generated at 2022-06-20 13:41:13.286163
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting1 = Setting('var1', 'value1')
    config_data.update_setting(setting1)
    print (config_data.get_setting('var1').value)


# Generated at 2022-06-20 13:41:25.359775
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Test 1: Add setting to global config
    config1 = ConfigData()
    plugin1 = Plugin('None', 'None', None)
    setting1 = Setting('test_setting', 'test_value', 'test_description', plugin1, 'test_directory')
    config1.update_setting(setting1)
    config1.update_setting(setting1)  # add setting again to verify that it is not added twice
    assert setting1.value == config1.get_setting('test_setting').value

    # Test 2: Add setting to plugin config
    config2 = ConfigData()
    plugin2 = Plugin('TestType', 'TestName', None)
    setting2 = Setting('test_setting', 'test_value', 'test_description', plugin2, 'test_directory')
    config2.update_setting(setting2)
    assert setting2

# Generated at 2022-06-20 13:41:34.097624
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # "test1" is the name of setting
    test_setting = Setting(name="test1", value=True, origin='default')

    # Create a ConfigData object
    configData = ConfigData()

    # Create a plugin object
    plugin = Plugin(type="module", name="ping", path="/foo/bar")

    # Add the setting to ConfigData
    configData.update_setting(test_setting, None)

    # Execute get_settings function
    assert configData.get_settings() == [test_setting]

    # Execute get_settings function with plugin
    assert configData.get_settings( plugin ) == []

# Generated at 2022-06-20 13:41:35.826873
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()

    actual = config.get_settings()
    expected = []
    assert actual == expected



# Generated at 2022-06-20 13:41:48.469649
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    config_data.update_setting(Setting("ANSIBLE_CONFIG", "/dev/null"))
    config_data.update_setting(Setting("ANSIBLE_CALLBACK_WHITELIST", "profile_tasks, timer"))
    config_data.update_setting(Setting("ANSIBLE_STDOUT_CALLBACK", "yaml"))

    settings = config_data.get_settings()
    assert len(settings) == 3
    assert settings[0].name == "ANSIBLE_CONFIG"
    assert settings[0].value == "/dev/null"
    assert settings[1].name == "ANSIBLE_CALLBACK_WHITELIST"
    assert settings[1].value == "profile_tasks, timer"
    assert settings[2].name == "ANSIBLE_STDOUT_CALLBACK"
   

# Generated at 2022-06-20 13:41:55.637991
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()

    s = Setting('some_setting_1', 'value1')
    cd.update_setting(s)
    cd.update_setting(Setting('some_setting_2', 'value2'))

    p = Plugin('mytype_1', 'myname_1')
    cd.update_setting(Setting('some_setting_3', 'value3', p))
    cd.update_setting(Setting('some_setting_4', 'value4', p))

    assert cd.get_setting('some_setting_1') is not None
    assert cd.get_setting('some_setting_2') is not None
    assert cd.get_setting('some_setting_1') == s
    assert cd.get_setting('some_setting_2').name == 'some_setting_2'
    assert cd.get_setting

# Generated at 2022-06-20 13:42:06.218584
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    setting = Setting(name="FOO", plugin=None)
    configData.update_setting(setting)
    assert(configData._global_settings['FOO'] is setting)
    assert(len(configData._global_settings) == 1)
    assert(configData.get_setting('FOO') is setting)
    assert(configData.get_settings()[0] is setting)

    setting2 = Setting(name="FOO", plugin=Plugin())
    configData.update_setting(setting2)
    assert(configData._global_settings['FOO'] is setting)
    assert(len(configData._global_settings) == 1)
    assert(configData.get_setting('FOO') is setting)
    assert(configData.get_settings()[0] is setting)

# Generated at 2022-06-20 13:42:18.221009
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # If a valid setting is passed, then it should return the setting
    setting = Setting('version','0.0.1','Ansible version')
    config_data.update_setting(setting)
    assert setting == config_data.get_setting('version')

    # If an invalid setting is passed, then it should return None
    assert None == config_data.get_setting('version2')

    # If a plugin is passed, then settings for that plugin should be returned
    plugin = Plugin('core','ansible')
    setting = Setting('version','0.1.1','Ansible version')
    config_data.update_setting(setting,plugin)
    assert setting == config_data.get_setting('version',plugin)

