

# Generated at 2022-06-20 13:33:16.667172
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    data.update_setting(Setting('foo','bar','','','','',False))

    settings = data.get_settings()
    assert len(settings) == 1
    assert settings[0].name == 'foo'
    assert settings[0].value == 'bar'


# Generated at 2022-06-20 13:33:27.812793
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from raw.module_utils.common.collection_list import CollectionList
    from raw.module_utils.common.setting import Setting
    from raw.module_utils.common.plugin import Plugin
    from raw.module_utils.common.factory import set_config_data
    from raw.module_utils.common.factory import get_config_data

    import sys

    setting_1 = Setting('setting_1', 'value_1', 'dev', '201703')
    setting_2 = Setting('setting_2', 'value_2', 'dev', '201704')
    setting_3 = Setting('setting_3', 'value_3', 'dev', '201705')
    setting_4 = Setting('setting_4', 'value_4', 'dev', '201706')

# Generated at 2022-06-20 13:33:36.949351
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import get_all_plugin_loaders

    config_data = ConfigData()

    for loader_type, loader_obj in get_all_plugin_loaders():

        for plugin_type in loader_obj:

            for plugin_name, plugin_obj in loader_obj[plugin_type].all(class_only=True):

                plugin_data = ConfigData()
                plugin_data.update_setting(plugin_obj.get_configuration_spec(), plugin_obj)

                config_data.update_setting(plugin_obj.get_configuration_spec(), plugin_obj)

    assert config_data

# Generated at 2022-06-20 13:33:39.940237
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data._global_settings == {}
    assert data._plugins == {}

# Generated at 2022-06-20 13:33:40.921217
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}


# Generated at 2022-06-20 13:33:44.434624
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    c.update_setting(ConfigSetting("key", "value"))
    c.update_setting(ConfigSetting("key2", "value2"))
    assert [s.value for s in c.get_settings()] == ["value", "value2"]



# Generated at 2022-06-20 13:33:53.312401
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    cd = ConfigData()

    assert cd.get_setting(None) is None
    assert cd.get_setting("") is None
    assert cd.get_setting("INVALID_KEY") is None

    assert cd.get_setting("INVALID_KEY", None) is None
    assert cd.get_setting("INVALID_KEY", "") is None
    assert cd.get_setting("INVALID_KEY", "INVALID_KEY") is None


# Generated at 2022-06-20 13:34:04.297919
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from units.mock.loader import DictDataLoader
    from units.plugins.action.ping import Ping

    config_data = ConfigData()

    setting_name = 'foo'
    setting_value = 'bar'

    setting = Setting(setting_name, setting_value)
    config_data.update_setting(setting)

    settings = config_data.get_settings()

    assert settings[0].name == 'foo'
    assert settings[0].value == 'bar'

    plugin = Ping(DictDataLoader())
    setting = Setting(setting_name, setting_value)
    config_data.update_setting(setting, plugin)
    settings = config_data.get_settings(plugin)

    assert settings[0].name == 'foo'
    assert settings[0].value == 'bar'


# Generated at 2022-06-20 13:34:13.351756
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting(name='something') is None

    setting = Setting(name='something',
                      value='this is a test',
                      plugin=Plugin('some_plugin', 'some_type'))
    config_data.update_setting(setting, setting.plugin)
    assert config_data.get_setting(name='something', plugin=setting.plugin) is not None
    assert config_data.get_setting(name='something', plugin=setting.plugin).value == 'this is a test'

    config_data = ConfigData()
    setting = Setting(name='something',
                      value='this is a test',
                      plugin=Plugin('some_plugin', 'some_type'))
    config_data.update_setting(setting)

# Generated at 2022-06-20 13:34:16.769516
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = dict(name='foo', value='bar')
    config_data.update_setting(setting, plugin='foo')
    assert config_data._plugins['foo']['foo']['foo'] == setting


# Generated at 2022-06-20 13:34:30.645051
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cfg_data = ConfigData()
    setting0 = Setting('key0', 'value0', 'key0')
    setting1 = Setting('key1', 'value1', 'key1')
    cfg_data.update_setting(setting0)
    cfg_data.update_setting(setting1)
    #test for global
    settings = cfg_data.get_settings()
    assert len(settings) == 2
    assert settings[0].name == setting0.name
    assert settings[0].origin == setting0.origin
    assert settings[1].name == setting1.name
    assert settings[1].origin == setting1.origin
    #test for collection plugin
    collection_plugin = Plugin('/some/path/to/collection1', 'collection', 'collection_name')

# Generated at 2022-06-20 13:34:37.380167
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    cd = ConfigData()

    # test updating a setting without a plugin type or name
    setting = {'set_name': 'abc', 'set_value': 'def', 'set_scope': 'global', 'plugin_type': '', 'plugin_name': ''}
    cd.update_setting(setting)

    assert cd._global_settings['abc'] == 'def'
    assert cd._plugins == {}

    # test updating a setting with a plugin type and name
    setting2 = {'set_name': 'ghi', 'set_value': 'jkl', 'set_scope': 'global', 'plugin_type': 'abc', 'plugin_name': 'def'}
    cd.update_setting(setting2)

    assert cd._global_settings['abc'] == 'def'

# Generated at 2022-06-20 13:34:45.809044
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import mock

    class MockPlugin(object):
        name = 'mock'
        type = 'mock'

    class MockSetting(object):
        name = 'mock_setting'

    mock_instance = ConfigData()
    mock.patch('ansible.utils.plugin_docs.ConfigData.get_setting', mock_instance.get_setting).start()
    mock.patch('ansible.utils.plugin_docs.ConfigData.get_settings', mock_instance.get_settings).start()

    # test global setting
    s = MockSetting()
    mock_instance.update_setting(s)

    assert(s == mock_instance._global_settings['mock_setting'])
    assert(s == mock_instance.get_setting('mock_setting'))

# Generated at 2022-06-20 13:34:58.908127
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test1', 'test_value_1'))
    assert len(config_data._global_settings) == 1
    assert config_data._global_settings.get('test1').value == 'test_value_1'
    assert len(config_data._plugins) == 0

    config_data.update_setting(Setting('test2', 'test_value_2'), Plugin('test_type_1', 'test_plugin_1'))
    assert len(config_data._plugins) == 1
    assert len(config_data._plugins['test_type_1']) == 1
    assert len(config_data._plugins['test_type_1']['test_plugin_1']) == 1

# Generated at 2022-06-20 13:35:00.530290
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd is not None


# Generated at 2022-06-20 13:35:06.125615
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    test_obj = ConfigData()
    test_obj.update_setting(Setting('foo', 'bar'))
    test_obj.update_setting(Setting('bar', 'foo'))
    assert test_obj.get_setting('foo') == test_obj.get_setting('bar')


# Generated at 2022-06-20 13:35:12.905170
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    print("Testing method get_settings of class ConfigData")
    config = ConfigData()
    setting1 = Setting("setting1", "/path/setting1")
    setting2 = Setting("setting2", "/path/setting2")
    setting3 = Setting("setting3", "/path/setting3")
    config.update_setting(setting1)
    config.update_setting(setting2, Plugin("test", "test"))
    setting3 = config.get_settings()
    assert setting3 == [setting1, setting2]




# Generated at 2022-06-20 13:35:18.092468
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    configData = ConfigData()
    setting0 = ConfigSetting(name='someSetting', value='someValue', origin='ini', scope='global')
    setting1 = ConfigSetting(name='someOtherSetting', value='someOtherValue', origin='ini', scope='global')
    configData.update_setting(setting0)
    configData.update_setting(setting1)
    assert configData.get_setting('someSetting').value == 'someValue'
    assert configData.get_setting('someOtherSetting').value == 'someOtherValue'


# Generated at 2022-06-20 13:35:31.936783
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    assert not config_data._global_settings
    assert not config_data._plugins

    assert config_data.get_setting("test1", None) is None

    class Plugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    plugin = Plugin("test-type", "test-name")
    assert config_data.get_setting("test2", plugin) is None

    class Setting(object):
        def __init__(self, name):
            self.name = name

    setting = Setting("test")

    config_data.update_setting(setting)
    assert config_data.get_setting("test", None) == setting

    config_data.update_setting(setting, plugin)
    assert config_data.get_setting

# Generated at 2022-06-20 13:35:42.253770
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('v1', Plugin(PluginType.CONNECTION, 'p1')))
    config_data.update_setting(Setting('v2'))

    assert config_data.get_setting('v1').name == 'v1'
    assert config_data.get_setting('v1').plugin.name == 'p1'
    assert config_data.get_setting('v2').name == 'v2'
    assert config_data.get_setting('v2').plugin == None



# Generated at 2022-06-20 13:35:50.774489
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    config_data.update_setting(Setting(name="setting1"))
    assert len(config_data.get_settings()) == 1


# Generated at 2022-06-20 13:35:58.577284
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Set up objects
    config_data = ConfigData()
    config_data.update_setting(SettingGlobal('ansible_connection', 'ssh'))
    config_data.update_setting(SettingGlobal('ansible_python_interpreter', '/usr/bin/python2.7'))

    # Test all settings
    settings = config_data.get_settings()
    assert all(setting.plugin.type == 'setting' for setting in settings)
    assert all(setting.plugin.name == 'global' for setting in settings)
    assert all(setting.name in ('ansible_connection', 'ansible_python_interpreter') for setting in settings)
    assert len(settings) == 2
    assert settings[0].value == 'ssh'
    assert settings[0].origin == '<unknown>'

# Generated at 2022-06-20 13:36:09.338248
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(Setting("setting1_gvalue1", "setting1_gname1", "setting1_gtype1", "setting1_gpath1", "setting1_gscope1", None))
    config.update_setting(Setting("setting1_gvalue2", "setting1_gname2", "setting1_gtype2", "setting1_gpath2", "setting1_gscope2", None))
    config.update_setting(Setting("setting1_pvalue1", "setting1_pname1", "setting1_ptype1", "setting1_ppath1", "setting1_pscope1", Plugin("plugin1", "plugin_type1")))

# Generated at 2022-06-20 13:36:22.953528
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    # test for updating global setting
    setting = Setting('default_attributes', '{}', 'dict', None, None)
    config_data.update_setting(setting)
    assert config_data.get_setting(setting.name) == setting

    # test for updating plugin setting
    config_data.update_setting(setting, Plugin('my_plugin', 'my_plugin_type'))
    config_data.update_setting(setting, Plugin('my_plugin2', 'my_plugin_type'))

    assert config_data._plugins['my_plugin_type']['my_plugin'][setting.name] == setting
    assert config_data._plugins['my_plugin_type']['my_plugin2'][setting.name] == setting


# Generated at 2022-06-20 13:36:25.954919
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    plugin = Plugin('cache', 'memory')
    setting = Setting('connection_timeout', '300')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('connection_timeout', plugin) == setting

# Generated at 2022-06-20 13:36:30.978150
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:36:41.803184
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
	plugin_a = Plugin('a', 'lookup')
	plugin_b = Plugin('b', 'lookup')
	cfg = ConfigData()
	assert cfg.get_setting('a') == None
	assert cfg.get_setting('b') == None
	assert cfg.get_setting('a', plugin_a) == None
	assert cfg.get_setting('a', plugin_b) == None
	cfg.update_setting(Setting('a', 'foo'))
	assert cfg.get_setting('a') == 'foo'
	assert cfg.get_setting('b') == None
	assert cfg.get_setting('a', plugin_a) == None
	assert cfg.get_setting('a', plugin_b) == None
	cfg.update_setting(Setting('b', 'bar'), plugin_a)

# Generated at 2022-06-20 13:36:51.767611
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    import plugin
    import setting
    config_data = ConfigData()
    s1 = setting.Setting('test', 1, plugin.Plugin('test_plugin_type', 'test_plugin_name'))
    s2 = setting.Setting('test', 2, plugin.Plugin('test_plugin_type', 'test_plugin_name2'))
    s3 = setting.Setting('test2', 3)
    config_data.update_setting(s3)
    config_data.update_setting(s1)
    config_data.update_setting(s2)
    assert config_data.get_setting('test2').value == 3
    assert config_data.get_setting('test', s1.plugin).value == 1
    assert config_data.get_setting('test', s2.plugin).value == 2


# Generated at 2022-06-20 13:36:54.759313
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-20 13:36:56.806067
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data is not None

# Generated at 2022-06-20 13:37:09.907012
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='foo', value='bar')
    config_data.update_setting(setting, plugin=None)
    assert(config_data.get_setting('foo', plugin=None) == setting)


# Generated at 2022-06-20 13:37:11.269860
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    dbs = config.get_settings()
    assert dbs == []

# Generated at 2022-06-20 13:37:15.898223
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert config_data.get_settings() == []


# Generated at 2022-06-20 13:37:24.670457
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    # get_settings called on an empty ConfigData
    assert config_data.get_settings() == []

    # get_settings called on a ConfigData with 1 global setting
    config_data._global_settings["global_setting1"] = 1
    assert config_data.get_settings() == [1]



# Generated at 2022-06-20 13:37:32.824477
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    configData.update_setting(Setting("setting1", "value1"))
    configData.update_setting(Setting("setting2", "value2"))
    configData.update_setting(Setting("setting3", "value3", plugin=Plugin("type1", "name1")))
    configData.update_setting(Setting("setting4", "value4", plugin=Plugin("type1", "name1")))

    assert configData.get_setting("setting1") is not None
    assert configData.get_setting("setting1").value == "value1"

    assert configData.get_setting("setting2") is not None
    assert configData.get_setting("setting2").value == "value2"


# Generated at 2022-06-20 13:37:45.670686
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Verify the update_setting method can set a global config setting
    data = ConfigData()
    data.update_setting(Setting('FOO', 'BAR'))
    assert data._global_settings['FOO'].name == 'FOO'
    assert data._global_settings['FOO'].value == 'BAR'

    # Verify the update_setting method can set a plugin config setting
    data.update_setting(Setting('FOO', 'BAR'), Plugin('CLI', 'foo-plugin'))
    assert data._plugins['CLI']['foo-plugin']['FOO'].name == 'FOO'
    assert data._plugins['CLI']['foo-plugin']['FOO'].value == 'BAR'



# Generated at 2022-06-20 13:37:47.759673
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting(None, None) is None



# Generated at 2022-06-20 13:37:49.583116
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:37:58.671891
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    my_data = ConfigData()

    #Test get_setting with plugin parameter set to None
    #There should not be any exception raised
    my_data.get_setting("testSetting1")

    #Test get_setting with plugin parameter set to a plugin
    #There should not be any exception raised
    my_data.get_setting("testSetting1", Plugin(None, "testPlugin1"))


# Generated at 2022-06-20 13:38:04.720920
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name="url"))
    config_data.update_setting(Setting(name="port", value=1234))
    config_data.update_setting(Setting(name="url_prefix", value="ABC"))
    config_data.update_setting(Setting(name="port_suffix", value="XYZ"))
    config_data.update_setting(Setting(name="url_suffix", value="XYZ"), Plugin("foo", "bar"))


# Generated at 2022-06-20 13:38:17.473800
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()
    assert config is not None


# Generated at 2022-06-20 13:38:23.759059
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings = [
        Setting('git_path', '/usr/bin/git', 'core'),
        Setting('GIT_ASKPASS', '', 'core'),
        Setting('git_path', '/usr/bin/git', 'core'),
        Setting('pipelining', '', 'ssh_connection')
    ]

    assert len(settings) == 4

    config_data = ConfigData()

    for s in settings:
        config_data.update_setting(s)

    assert config_data._global_settings is not None
    assert len(config_data._global_settings) == 4
    assert len(config_data.get_settings()) == 4



# Generated at 2022-06-20 13:38:35.422983
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    """
    Test class ConfigData: get_setting
    """
    cd = ConfigData()

    setting_global = BaseSetting('global_setting', 'global_value')
    cd.update_setting(setting_global)
    setting = cd.get_setting('global_setting')
    assert setting == setting_global

    setting_plugin = BaseSetting('plugin_setting', 'plugin_value')
    cd.update_setting(setting_plugin, BasePlugin('shell'))
    setting = cd.get_setting('plugin_setting', BasePlugin('shell'))
    assert setting == setting_plugin


# Generated at 2022-06-20 13:38:41.360276
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    assert None == config.get_setting('setting_name')

    config.update_setting(Setting('setting_name', 'setting_value'))
    assert 'setting_value' == config.get_setting('setting_name').value

    plugin = Plugin('plugin_name', 'plugin_type')
    config.update_setting(Setting('setting_name', 'setting_value'), plugin)
    assert 'setting_value' == config.get_setting('setting_name', plugin).value



# Generated at 2022-06-20 13:38:44.564484
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data

# Generated at 2022-06-20 13:38:56.145071
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("foo") == None
    plugin = Plugin("bar", "baz")
    assert config_data.get_setting("foo", plugin) == None

    setting = Setting("foo")
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting("foo") == None
    assert config_data.get_setting("foo", plugin) == setting
    assert config_data.get_setting("bar") == None
    assert config_data.get_setting("bar", plugin) == None

    setting = Setting("bar")
    config_data.update_setting(setting)
    assert config_data.get_setting("bar") == setting
    assert config_data.get_setting("bar", plugin) == setting



# Generated at 2022-06-20 13:39:02.230157
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global_setting = ConfigSetting('global_setting', True)
    conf = ConfigData()
    conf.update_setting(global_setting)
    assert conf._global_settings == {'global_setting': global_setting}
    #
    plugin_setting = ConfigSetting('plugin_setting', True)
    plugin = ConfigPlugin('fancy_plugin', 'my_plugins')
    conf.update_setting(plugin_setting, plugin)
    #
    assert conf._plugins == {plugin.type: {plugin.name: {plugin_setting.name: plugin_setting}}}


# Generated at 2022-06-20 13:39:05.738805
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # No parameters passed to constructor
    config_data = ConfigData()

    # Empty dictionaries are expected
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:39:15.854084
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)

    class Setting(object):
        def __init__(self, name):
            self.name = name

    class Plugin(object):
        def __init__(self, name, type):
            self.name = name
            self.type = type

    global_settings = {}
    settings = {}

    plugin_foo_action = Plugin('foo/action', 'action')
    settings[plugin_foo_action.name] = {}

    plugin_foo_connection = Plugin('foo/connection', 'connection')
    settings[plugin_foo_connection.name] = {}

    plugin_bar_connection = Plugin('bar/connection', 'connection')
    settings[plugin_bar_connection.name] = {}


# Generated at 2022-06-20 13:39:16.820159
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    pass

# Generated at 2022-06-20 13:39:41.013377
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting('test_setting')
    assert config.get_settings(None) == ['test_setting']

# Generated at 2022-06-20 13:39:50.386401
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    config_data.update_setting(Setting('var', 'var', 'default', 'var description'))
    config_data.update_setting(Setting('var_type', 'var_type', 'string', 'var type description'))
    config_data.update_setting(Setting('var_name', 'var_name', 'default', 'var name description'))
    config_data.update_setting(Setting('var_path', 'var_path', '/path/to/default', 'var path description'))
    config_data.update_setting(Setting('var_multiline', 'var_multiline', 'default', 'var multiline description'))

    assert len(config_data.get_settings()) == 5


# Generated at 2022-06-20 13:39:52.651281
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert configdata

# Generated at 2022-06-20 13:39:57.726009
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()

    setting = {'name': 'foo', 'value': 'bar', 'config_file_path': '/path/foo.ini'}
    plugin = {'type': 'module', 'name': 'collect_facts', 'config_file_path': '/path/facts.ini'}

    config.update_setting(setting, plugin)
    print(config.get_settings())

test_ConfigData_update_setting()

# Generated at 2022-06-20 13:40:07.315409
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.plugins.loader import Plugin
    from ansible.config.setting import Setting

    config_data = ConfigData()
    plugin = Plugin('test', 'test_type')
    setting = Setting('test', 'test', 'test')

    assert config_data.get_setting(setting.name, plugin) is None
    config_data.update_setting(setting)
    assert config_data.get_setting(setting.name, None) == setting
    assert config_data.get_setting(setting.name, plugin) == setting

    setting = Setting('test', 'test', 'test', plugin=plugin)
    config_data.update_setting(setting)
    assert config_data.get_setting(setting.name, None) == setting
    assert config_data.get_setting(setting.name, plugin) == setting

# Unit test

# Generated at 2022-06-20 13:40:10.854548
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd._global_settings == {}
    assert cd._plugins == {}


# Generated at 2022-06-20 13:40:13.827309
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test = ConfigData()


# Generated at 2022-06-20 13:40:16.326216
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:40:27.135369
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from io import StringIO
    from ansible.config.data import ConfigData
    from ansible.config.data import ConfigLine
    from ansible.config.data import ConfigLineParser


# Generated at 2022-06-20 13:40:41.211466
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    import ansible.plugins.loader as loader
    from ansible.plugins.lookup import LookupBase

    config_data.update_setting('test_setting', loader.find_plugin(LookupBase, 'file'))
    assert(len(config_data.get_settings(loader.find_plugin(LookupBase, 'file'))) == 1)

    config_data.update_setting('test_setting', loader.find_plugin(LookupBase, 'file'))
    assert(len(config_data.get_settings(loader.find_plugin(LookupBase, 'file'))) == 1)

    config_data.update_setting('test_setting_2', loader.find_plugin(LookupBase, 'file'))

# Generated at 2022-06-20 13:40:59.144419
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert(config_data._global_settings == {})
    assert(config_data._plugins == {})

# Generated at 2022-06-20 13:41:05.024107
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    plugin = ansible.plugins.PluginLoader(module_utils=module_utils,
                                          dir_list=plugins,
                                          class_name='Default',
                                          config_data=config_data)

    setting = ansible.plugins.task.Task.get_setting(name='foo', plugin=None)
    assert setting.name == 'foo'

    setting = ansible.plugins.task.Task.get_setting(name='bar', plugin=plugin)
    assert setting.name == 'bar'
    assert setting.value == 'baz'



# Generated at 2022-06-20 13:41:08.751338
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data=ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', 'bar') is None

# Generated at 2022-06-20 13:41:10.268249
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert config.get_setting('foo') is None


# Generated at 2022-06-20 13:41:11.503491
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-20 13:41:18.923338
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    settings = ConfigData()
    setattr(ConfigData, '_ConfigData__global_settings', {'foo': 'bar'})
    setattr(ConfigData, '_ConfigData__plugins', {'connection': {'local': {'foo': 'baz'}}})
    setting = 'foo'
    
    settings.update_setting(setting)
    assert settings._global_settings == {'foo': 'bar'}

    settings.update_setting(setting, plugin='local')
    assert settings._plugins == {'connection': {'local': {'foo': 'baz'}}}
    
    settings._global_settings[setting] = 'baz'
    settings.update_setting(setting)
    assert settings._global_settings == {'foo': 'baz'}


# Generated at 2022-06-20 13:41:26.507086
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin1 = PluginInfo('test_plugin1','TestPlugin1','Common', 'TestModule')
    plugin2 = PluginInfo('test_plugin2','TestPlugin2','IsModule', 'TestModule')
    setting1 = SettingInfo('test_setting1','TestSetting1','TestPlugin', 'String', 'TestModule')
    setting2 = SettingInfo('test_setting2','TestSetting2','TestPlugin2', 'String', 'TestModule')
    setting3 = SettingInfo('test_setting3','TestSetting3','TestPlugin2', 'String', 'TestModule')

    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin2)
    config_data.update_setting(setting3, plugin2)

    assert config_data.get_setting('test_setting1')

# Generated at 2022-06-20 13:41:36.667040
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    # test global settings
    assert config_data.get_settings() == []
    # test plugins with no settings
    assert config_data.get_settings(TestPlugin) == []
    assert config_data.get_settings(TestPlugin2) == []
    # test plugins with one setting
    config_data.update_setting(PluginSetting("Test", "Test value", TestPlugin))
    assert config_data.get_settings(TestPlugin) == [PluginSetting("Test", "Test value", TestPlugin)]
    config_data.update_setting(PluginSetting("Test2", "Test2 value", TestPlugin2))
    assert config_data.get_settings(TestPlugin2) == [PluginSetting("Test2", "Test2 value", TestPlugin2)]
    # test plugins with several settings
    config_data.update_

# Generated at 2022-06-20 13:41:48.469670
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert None == config.get_setting('test_setting')

    config.update_setting(Setting('test_setting', 'value1'))
    assert 'value1' == config.get_setting('test_setting')

    config.update_setting(Setting('other_setting', 'value2'))
    assert 'value2' == config.get_setting('other_setting')

    config.update_setting(Setting('test_setting', 'value3'))
    assert 'value3' == config.get_setting('test_setting')
    assert 'value2' == config.get_setting('other_setting')

    config.update_setting(Setting('test_setting', 'value1'), Plugin('module', 'test_plugin'))

# Generated at 2022-06-20 13:41:50.721387
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo'))
    assert config_data.get_setting('foo') is not None


# Generated at 2022-06-20 13:42:29.663909
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = PluginInstance(PluginType.ACTION, "my_action")
    config_data.update_setting(Setting("some_path", "some_value"), None)
    config_data.update_setting(Setting("some_other_path", "some_other_value"), plugin)

    settings = config_data.get_settings()
    assert len(settings) == 1
    assert settings[0].name == "some_path"
    assert settings[0].value == "some_value"

    settings = config_data.get_settings(plugin)
    assert len(settings) == 1
    assert settings[0].name == "some_other_path"
    assert settings[0].value == "some_other_value"


# Generated at 2022-06-20 13:42:32.696242
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data
    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-20 13:42:35.008101
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert isinstance(config, ConfigData)
    assert len(config._global_settings) == 0
    assert len(config._plugins) == 0


# Generated at 2022-06-20 13:42:45.069014
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert cd is not None
    assert cd._global_settings == {}
    assert cd._plugins == {}

    cd.update_setting(ConfigSetting('foo', 'bar', 'global', 'plugin', 0))
    assert cd._global_settings == {'foo': ConfigSetting('foo', 'bar', 'global', 'plugin', 0)}
    assert cd._plugins == {}

    cd.update_setting(ConfigSetting('foo', 'bar', 'plugin', 'plugin', 0))
    assert cd._global_settings == {'foo': ConfigSetting('foo', 'bar', 'global', 'plugin', 0)}
    assert cd._plugins == {'plugin': {'plugin': {'foo': ConfigSetting('foo', 'bar', 'plugin', 'plugin', 0)}}}


# Generated at 2022-06-20 13:42:49.298278
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd=ConfigData()
    assert cd._global_settings=={}
    assert cd._plugins=={}
    assert cd.get_setting('name', 'plugin')==None
    assert cd.get_settings(plugin=None)==[]
    setting=''
    assert cd.update_setting(setting)==None

# Generated at 2022-06-20 13:42:58.343205
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.plugin_docs import get_docstring

    from ansible.plugins.action import ActionModule
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.filter import FilterModule
    from ansible.plugins.inventory import InventoryBase
    from ansible.plugins.lookup import LookupBase
    from ansible.plugins.strategy import StrategyBase

    import yaml

    # Data
    config_data = ConfigData()

    plugins_to_test = [ActionModule, ConnectionBase, FilterModule, InventoryBase, LookupBase, StrategyBase]

# Generated at 2022-06-20 13:43:01.179582
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()

    import pytest
    with pytest.raises(TypeError):
        cd2 = ConfigData(5)



# Generated at 2022-06-20 13:43:09.453839
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    d = ConfigData()

    from .setting_definition import SettingDefinition
    k = SettingDefinition(name="key", default_value="default")
    d.update_setting(setting=k)
    e = SettingDefinition(name="key", default_value="default")
    d.update_setting(setting=e)

    assert d._global_settings["key"].__dict__ == e.__dict__
    import copy
    assert d._global_settings["key"] is not e
    assert copy.copy(d._global_settings["key"]).__dict__ == e.__dict__
