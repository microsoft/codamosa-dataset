

# Generated at 2022-06-20 13:33:14.661629
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd._global_settings == {}
    assert cd._plugins == {}


# Generated at 2022-06-20 13:33:18.761951
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()

    assert data.get_settings() == []

    data.update_setting({'name': 'foo'})

    assert data.get_settings() == [{'name': 'foo'}]



# Generated at 2022-06-20 13:33:23.232011
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin = Plugin("module", "test_module")
    setting = Setting("test_setting")
    config = ConfigData()
    config.update_setting(setting, plugin)
    assert(config._plugins["module"]["test_module"]["test_setting"] == setting)


# Generated at 2022-06-20 13:33:29.720065
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from yaml import load
    from io import StringIO

    from ansible.plugins.loader import load_plugin_class_names

    config_data = ConfigData()

    file_name = "./lib/ansible/plugins/callback/simple.py"
    with open(file_name, 'r') as stream:
        source = stream.read().replace('@', '%')
        data = load(source, Loader=yaml.FullLoader)
        plugin_type= data['plugin type']
        plugin_names = load_plugin_class_names(file_name, plugin_type)

        for plugin_name in plugin_names:
            plugin_class_obj = load_plugin_class(file_name, plugin_name, plugin_type)
            plugin_obj = plugin_class_obj(config_data)

# Generated at 2022-06-20 13:33:40.711566
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    data = ConfigData()

    setting = Setting('module_name_whitelist', 'hello', 'module')
    data.update_setting(setting)
    assert data.get_setting('module_name_whitelist', Plugin('action', 'copy')) == 'hello'
    assert data.get_setting('module_name_whitelist') == 'hello'
    assert data.get_setting('module_name_whitelist', Plugin('lookup', 'file')) == 'hello'
    assert data.get_setting('module_name_whitelist', Plugin('become', 'sudo')) == 'hello'

    setting = Setting('module_name_whitelist', 'world', 'module', Plugin('action', 'copy'))
    data.update_setting(setting)

# Generated at 2022-06-20 13:33:46.654600
# Unit test for constructor of class ConfigData
def test_ConfigData():
    import unittest

    class TestCase(unittest.TestCase):

        def test_init(self):

            obj = ConfigData()
            assert isinstance(obj, ConfigData)

            assert obj._global_settings == {}
            assert obj._plugins == {}

    import sys
    suite = unittest.TestLoader().loadTestsFromTestCase(TestCase)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        sys.exit(1)


# Generated at 2022-06-20 13:33:56.410153
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()

    # Get a global setting
    configData.update_setting(Setting("SETTING_GLOBAL", "STRING", "value"))
    assert configData.get_setting("SETTING_GLOBAL") == Setting("SETTING_GLOBAL", "STRING", "value")

    # Get a plugin setting
    plugin = Plugin("plugin_type", "plugin_name")
    configData.update_setting(Setting("SETTING_PLUGIN", "STRING", "value"), plugin)
    assert configData.get_setting("SETTING_PLUGIN", plugin) == Setting("SETTING_PLUGIN", "STRING", "value")



# Generated at 2022-06-20 13:34:06.016265
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()

    from ansible import constants as C

    global_setting = ConfigSetting(C.DEFAULT_HOST_LIST, C.DEFAULT_HOST_LIST)
    config.update_setting(global_setting)

    plugin_type = PluginType("Module_util")
    module_util_file = ConfigSetting("module_utils", "modules/module_utils")
    module_util_plugin = Plugin("FileModuleUtil", 'modules/module_utils', plugin_type)
    config.update_setting(module_util_file, module_util_plugin)

    from ansible.utils.plugin_docs import read_docstub
    from ansible.plugins.module_utils import basic

    basic_module_util_plugin = Plugin("basic", basic, plugin_type)

# Generated at 2022-06-20 13:34:09.284530
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:34:19.145864
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    global_settings = {'g_setting1': 'value1', 'g_setting2': 'value2'}
    plugin_settings_one = {'p_setting1': 'value1', 'p_setting2': 'value2'}
    plugin_settings_two = {'p_setting3': 'value3', 'p_setting4': 'value4'}

    config_data = ConfigData()
    config_data._global_settings = global_settings
    config_data._plugins = {
        'plugin_type': {
            'plugin_name1': plugin_settings_one,
            'plugin_name2': plugin_settings_two
        }
    }

    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings(None)) == 2

# Generated at 2022-06-20 13:34:33.349998
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(Setting('foo_global', 'foo global'))
    assert config.get_setting('foo_global') is not None
    assert config.get_setting('foo_global', Plugin('connection', 'local')) is None
    assert config.get_setting('foo_local') is None
    assert config.get_setting('foo_local', Plugin('connection', 'local')) is None

# Generated at 2022-06-20 13:34:36.876411
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()

# Generated at 2022-06-20 13:34:39.640911
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    print(config_data.get_setting(''))
    print(config_data.get_setting('', ''))



# Generated at 2022-06-20 13:34:41.985877
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    configData = ConfigData()
    setting = configData.get_setting("param1")
    assert len(configData.get_settings()) == 0



# Generated at 2022-06-20 13:34:47.994035
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import PluginLoader
    from ansible.module_utils.six import PY2, PY3
    from ansible.utils.plugin_docs import cut_blank_lines
    from ansible.utils.plugin_docs import get_docstring

    if PY3:
        unicode = str

    class MyPlugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class MySettings(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value

    config = ConfigData()

    plugin1 = MyPlugin('test_type', 'test_name')

# Generated at 2022-06-20 13:35:00.015077
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

     # Test data
     setting = ConfigSetting('host_key_checking', True, 'global', 'BOOLEAN')
     plugin = Plugin('connection', 'ssh')
     config_data = ConfigData()
     config_data.update_setting(setting)

     # Get the settings for a plugin that does exist
     assert len(config_data.get_settings(plugin=plugin)) == 0

     # Get the settings for a plugin that doesn't exist
     assert len(config_data.get_settings(plugin=None)) == 1
     assert config_data.get_settings(plugin=None)[0].name == 'host_key_checking'
     assert config_data.get_settings(plugin=None)[0].value == True
     assert config_data.get_settings(plugin=None)[0].scope == 'global'
     assert config_data.get

# Generated at 2022-06-20 13:35:12.251004
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Test for global setting
    setting = Setting('test', 'test')
    config_data.update_setting(setting)
    assert config_data.get_setting('test') == setting

    # Test for plugin setting
    plugin = Plugin('test', 'test')
    setting = Setting('test', 'test')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('test', plugin) == setting

    # Test for not existing setting
    setting = Setting('test', 'test')
    assert config_data.get_setting('not_existing') == None

    # Test for not existing plugin setting
    plugin = Plugin('test', 'test')
    setting = Setting('test', 'test')
    assert config_data.get_setting('not_existing', plugin) == None

# Generated at 2022-06-20 13:35:19.490846
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Add a global setting
    global_setting = {'name': 'ANSIBLE_PRIVATE_KEY_FILE', 'value': '/Users/username/.ssh/id_rsa'}
    config_data.update_setting(Setting(global_setting))

    # Add some plugin settings
    plugin_settings = [
        {'name': 'NAME', 'value': 'myname'},
        {'name': 'AGE', 'value': '25'},
        {'name': 'JOB', 'value': 'engineer'}
    ]

    for plugin_setting in plugin_settings:
        config_data.update_setting(Setting(plugin_setting), Plugin('lookup', 'test'))

    assert config_data.get_setting('ANSIBLE_PRIVATE_KEY_FILE') == global_setting

# Generated at 2022-06-20 13:35:24.434996
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    #global_settings = {}
    config_data = ConfigData()
    test_setting = {'name':'somename', 'value':'somevalue', 'section':'section1', 'plugin':None}
    config_data.update_setting(test_setting)
    assert config_data.get_settings() == [test_setting]

# Generated at 2022-06-20 13:35:28.855173
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(None, None)
    config_data.update_setting(None, "test_plugin")
    plugin = ("test_type", "test_name")
    config_data.update_setting(None, plugin)

# Generated at 2022-06-20 13:35:39.522547
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    settings = [
        Setting('one', 'one', 'plugin-one', 'string', 'global'),
        Setting('two', 'two', 'plugin-two', 'string', 'global')
    ]
    for setting in settings:
        config.update_setting(setting)

    setting = config.get_setting('one')
    assert setting.name == settings[0].name
    assert setting.value == settings[0].value
    assert setting.plugin == settings[0].plugin
    assert setting.type == settings[0].type
    assert setting.scope == settings[0].scope

    setting = config.get_setting('two')
    assert setting.name == settings[1].name
    assert setting.value == settings[1].value
    assert setting.plugin == settings[1].plugin
    assert setting.type == settings

# Generated at 2022-06-20 13:35:47.033266
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(TestSetting('TestSetting', 'TestValue'))
    config_data.update_setting(TestSetting('TestSetting', 'TestValue'))
    config_data.update_setting(TestSetting('IgnoreSetting', 'IgnoreValue'))
    config_data.update_setting(TestSetting('TestSetting2', 'TestValue2'))
    assert len(config_data.get_settings()) == 3
    assert config_data.get_settings()[0].name == 'TestSetting'
    assert config_data.get_settings()[1].name == 'IgnoreSetting'
    assert config_data.get_settings()[2].name == 'TestSetting2'


# Generated at 2022-06-20 13:35:54.222675
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.configuration import ConfigurationPlugin
    from ansible.plugins.loader import configuration_loader

    config_data = ConfigData()

    config_data.update_setting('foo')
    assert config_data.get_setting('foo') == 'foo'
    assert config_data.get_settings() == ['foo']

    config_data.update_setting('bar', plugin=ConfigurationPlugin('this', configuration_loader))
    plugin = config_data.get_setting('bar', plugin=ConfigurationPlugin('this', configuration_loader))
    assert plugin == 'bar'
    assert config_data.get_settings(ConfigurationPlugin('this', configuration_loader)) == ['bar']

# Generated at 2022-06-20 13:35:58.704363
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert isinstance(config_data, ConfigData)
    assert isinstance(config_data._global_settings, dict)
    assert isinstance(config_data._plugins, dict)


# Generated at 2022-06-20 13:36:09.405970
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._plugins = {
        'become':{
            'become_method':{
                'name': 'become_method',
                'value': 'sudo'
            }
        },
        'strategy':{
            'strategy_name':{
                'value': 'linear'
            }
        },
        'organization':{
            'organization_name':{
                'value': 'org1'
            }
        }
    }
    plugin_type = 'become'
    # plugin name to get
    plugin_name = 'become_method'
    settings = config_data.get_settings(plugin_type, plugin_name)
    assert len(settings) == 1
    assert settings[0]['name'] == 'become_method'
   

# Generated at 2022-06-20 13:36:14.284843
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings is not None
    assert config_data._plugins is not None


# Generated at 2022-06-20 13:36:16.522070
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-20 13:36:19.737749
# Unit test for constructor of class ConfigData
def test_ConfigData():
    my_config = ConfigData()
    assert isinstance(my_config, ConfigData)
    assert my_config.get_setting("not exist") is None


# Generated at 2022-06-20 13:36:23.779703
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting()



# Generated at 2022-06-20 13:36:30.353092
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    p1 = Plugin('module', 'p1')
    p2 = Plugin('module', 'p2')
    p3 = Plugin('module', 'p3')
    s1 = Setting('a', 'int', '10', ['a'])
    s2 = Setting('b', 'str', '10', ['b'])
    s3 = Setting('c', 'int', '20', ['c'])
    s4 = Setting('d', 'int', '10', ['d'])
    s5 = Setting('e', 'int', '10', ['e'])
    data = ConfigData()
    data.update_setting(s1, p1)
    data.update_setting(s2, p1)
    data.update_setting(s3, p2)
    data.update_setting(s4)
    assert data.get

# Generated at 2022-06-20 13:36:38.925725
# Unit test for constructor of class ConfigData
def test_ConfigData():

    data = ConfigData()
    assert data._global_settings == {}
    assert data._plugins == {}
    assert data.get_setting(name='ANSIBLE_INTERNAL_DATA') is None
    assert not data.get_settings()


# Generated at 2022-06-20 13:36:42.600946
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting(name='test1'))
    config_data.update_setting(ConfigSetting(name='test2'))

    setting = config_data.get_setting('test1')
    assert setting.name == 'test1'


# Generated at 2022-06-20 13:36:48.068165
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('Something', None) is None


# Generated at 2022-06-20 13:36:54.659352
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    configdata = ConfigData()
    configdata._global_settings = {'a': 'b'}
    configdata._plugins = {'a': {'a': {'a': 'a'}}}

    assert configdata.get_settings() == [{'a': 'b'}]

    assert configdata.get_settings(plugin=Plugin('a', 'a')) == [{'a': 'a'}]



# Generated at 2022-06-20 13:36:56.196607
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()


# Generated at 2022-06-20 13:36:57.682126
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert configdata


# Generated at 2022-06-20 13:37:11.319881
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    import os
    import sys
    import subprocess

    script_dir = os.path.dirname(__file__)
    python_script = os.path.join(script_dir, "ansible-config-test-settings.py")

    user_config = os.path.join(script_dir, "data/ansible.cfg")
    config_data = ConfigData()
    config_data.update_setting(Setting("config_file", user_config))

    p = subprocess.Popen([python_script, "--config-data", config_data], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    return_code = p.returncode
    if return_code != 0:
        sys.stdout.write(out + "\n")

# Generated at 2022-06-20 13:37:20.725600
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    
    config_data = ConfigData()
    
    setting_1 = Setting(name="SETTING_1", value="VALUE_1", origin="ORIGIN_1")
    setting_2 = Setting(name="SETTING_2", value="VALUE_2", origin="ORIGIN_2")
    plugin_1 = Plugin(type="TYPE_1", name="NAME_1")
    plugin_2 = Plugin(type="TYPE_2", name="NAME_2")

    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2, plugin_1)
    config_data.update_setting(setting_2, plugin_2)
    
    assert len(config_data._global_settings) == 1

# Generated at 2022-06-20 13:37:31.011970
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from units.mock.loader import PluginLoader, DictDataLoader
    from units.mock.path import MockPath

    class TestPlugin(object):

        def __init__(self, name, plugin_type='cache'):
            self.name = name
            self.type = plugin_type

    cd = ConfigData()
    cd.update_setting(setting=DictDataLoader({'key1':'value1'}), plugin=TestPlugin('default'))
    cd.update_setting(setting=DictDataLoader({'key1':'value1'}), plugin=TestPlugin('default'))
    cd.update_setting(setting=DictDataLoader({'key1':'value1'}), plugin=TestPlugin('default'))
    assert len(cd._plugins['cache'])==1

# Generated at 2022-06-20 13:37:35.545372
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Arrange
    config_data = ConfigData()
    config_data._global_settings['mi_name'] = 48
    config_data._plugins['plugin_type'] = {}
    config_data._plugins['plugin_type']['plugin_name'] = {}
    config_data._plugins['plugin_type']['plugin_name']['pl_name'] = 'value'

    # Act and Assert
    assert config_data.get_setting('mi_name') == 48
    assert config_data.get_setting('pl_name', 'plugin_type', 'plugin_name') == 'value'



# Generated at 2022-06-20 13:37:49.385600
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    assert config.get_settings() == []
    setting = ConfigSetting(name='foo', plugin=None)
    config.update_setting(setting)
    assert config.get_settings() == [setting]
    assert config.get_settings(plugin='bar') == []
    setting2 = ConfigSetting(name='foo', plugin='bar')
    config.update_setting(setting2)
    assert config.get_settings() == [setting]
    assert config.get_settings('bar') == [setting2]

# Generated at 2022-06-20 13:38:03.540516
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import unittest

    class Plugin(object):

        def __init__(self, type, name):
            self.type = type
            self.name = name

    class Setting(object):

        def __init__(self, name, default_value, plugin=None):
            self.plugin = plugin
            self.name = name
            self.default_value = default_value

    class TestConfigData(unittest.TestCase):

        def setUp(self):
            self.config_data = ConfigData()
            self.plugin = Plugin('lookup', 'github_status')
            self.global_setting = Setting('ansible_connection', 'ssh', None)
            self.plugin_setting = Setting('api_user', 'test', self.plugin)

# Generated at 2022-06-20 13:38:05.339269
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()
    assert configdata.get_settings() == []


# Generated at 2022-06-20 13:38:12.456523
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('1', '1', '1'))
    config_data.update_setting(Setting('2', '2', '2'), Plugin('1', '1'))
    assert config_data._global_settings['1'] == setting('1', '1', '1')
    assert config_data._plugins['1']['1']['2'] == setting('2', '2', '2')



# Generated at 2022-06-20 13:38:14.348752
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-20 13:38:18.956932
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    data = ConfigData()
    assert data.get_setting('ansible_python_interpreter') is None
    assert data.get_setting('ansible_foo_bar', plugin='myplugin') is None
    assert data.get_setting('ansible_python_interpreter', plugin='myplugin') is None



# Generated at 2022-06-20 13:38:26.983553
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class Plugin:

        def __init__(self, name, type):
            self.name = name
            self.type = type

    global_setting = {'name': 'color', 'value': True}
    plugin_setting = {'name': 'color', 'value': False}
    config = ConfigData()
    config.update_setting(Setting.from_dict(plugin_setting), Plugin('colorize', 'terminal'))
    config.update_setting(Setting.from_dict(global_setting))

    assert config.get_setting('color') == Setting.from_dict(global_setting)
    assert config.get_setting('color', plugin=Plugin('colorize', 'terminal')) == Setting.from_dict(plugin_setting)

# Generated at 2022-06-20 13:38:39.151393
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblelint.rules.FilenameHasDashRule import FilenameHasDashRule
    from ansiblelint.rules.FilenameHasDoubleUnderscoreRule import FilenameHasDoubleUnderscoreRule
    from ansiblelint.rules.FilenameHasSingleUnderscoreRule import FilenameHasSingleUnderscoreRule

    config_data = ConfigData()

    # Check if plugin isn't set in config file and in config data
    rule = FilenameHasDoubleUnderscoreRule()
    assert config_data.get_setting('filename_has_double_underscore', rule) is None

    # Check if plugin is set in config file but not in config data
    rule = FilenameHasSingleUnderscoreRule()
    assert config_data.get_setting('filename_has_single_underscore', rule) is None

    # Check if plugin and setting exist in config file and

# Generated at 2022-06-20 13:38:47.809069
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Define ConfigData object with one global setting and one setting for a plugin
    config_data = ConfigData()
    global_setting = ConfigSetting('some_global_setting', 'this is a global setting')
    plugin_setting = ConfigSetting('some_plugin_setting', 'this is a plugin setting')
    plugin = Plugin('my_plugin', 'my_plugin_type')
    config_data.update_setting(global_setting)
    config_data.update_setting(plugin_setting, plugin)

    # Define local variables to hold returning values
    setting = None

    # Call method get_setting of class ConfigData object
    setting = config_data.get_setting('some_global_setting')

    # Assert that returned value is equal to global setting
    assert setting == global_setting, 'ERROR: returned setting is not the same as global setting'

# Generated at 2022-06-20 13:38:54.371522
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test', 'value', 'default value', 'description')
    plugin = Plugin(Plugin.TYPE_CORE, 'test')
    config_data.update_setting(setting, plugin)
    assert config_data._global_settings == {}
    assert config_data._plugins[Plugin.TYPE_CORE]['test']['test'] == setting



# Generated at 2022-06-20 13:39:11.511215
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import os
    import unittest

    from ansiblelint import Runner
    from ansiblelint.utils.yaml_config import ConfigData

    from ansiblelint.utils.file import File
    from ansiblelint.rules.RulesCollection import RulesCollection
    from ansiblelint.rules.lineinfile import LineInFile
    from ansiblelint.rules.filepermissions import FilePermissions

    class TestConfigData_update_setting(unittest.TestCase):

        def test_update_setting(self):
            config = ConfigData()
            config.update_setting(FilePermissions('/etc/passwd', '0644', '', ''))
            config.update_setting(FilePermissions('/etc/passwd', '0644', '', '', True))

# Generated at 2022-06-20 13:39:15.191415
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test_object = ConfigData()
    test_object.update_setting(GlobalSetting('foo', 'bar', 'string'))
    assert 'foo' == test_object.get_setting('foo').name


# Generated at 2022-06-20 13:39:19.729450
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data=ConfigData()
    setting = Setting('a', 'b', 'c', 'd', 'e')
    plugin=Plugin('a', 'b')
    config_data.update_setting(setting, plugin)
    assert(config_data.get_setting('a',plugin) is not None)
    assert(config_data.get_setting('d', plugin) is None)



# Generated at 2022-06-20 13:39:23.606496
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    data = ConfigData()
    data.update_setting(Setting('var1','value1',None))
    data.update_setting(Setting('var2','value2',Plugin('type','name')))
    print(data.get_setting('var1'))
    print(data.get_setting('var2', Plugin('type','name')))
    print(data.get_setting('var3'))


# Generated at 2022-06-20 13:39:27.841601
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    cd.update_setting(Setting('bool_setting', config_type='bool', value=True))
    cd.update_setting(Setting('string_setting', config_type='string', value='Hello'))
    settings = cd.get_settings()
    assert len(settings) == 2


# Generated at 2022-06-20 13:39:31.004536
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    data.update_setting(Object())
    assert data.get_settings() == (Object(),)


# Generated at 2022-06-20 13:39:46.228205
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(ConfigSetting(name='setting'))
    config_data.update_setting(ConfigSetting(name='setting_b'))
    config_data.update_setting(ConfigSetting(name='setting_c', plugin=ConfigPlugin(type='filter', name='set')))
    config_data.update_setting(ConfigSetting(name='setting_d', plugin=ConfigPlugin(type='lookup', name='url')))
    config_data.update_setting(ConfigSetting(name='setting_e', plugin=ConfigPlugin(type='callbacks', name='default')))

    # Test 1.
    assert config_data.get_setting(name='setting').name == 'setting'

    # Test 2.

# Generated at 2022-06-20 13:39:48.770810
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    test_setting = {'setting_1':'1'}
    plugin = 'example'
    config_data.update_setting(test_setting)
    assert(config_data.get_setting('setting_1',plugin) is None)

# Generated at 2022-06-20 13:40:03.225533
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()

    assert [] == cd.get_settings()

    cd.update_setting(PluginSetting('g1', 'g1_name', 'g1_value'))
    cd.update_setting(PluginSetting('g2', 'g2_name', 'g2_value'))
    assert cd.get_settings() == [
        PluginSetting('g1', 'g1_name', 'g1_value'),
        PluginSetting('g2', 'g2_name', 'g2_value')
    ]

    plugin = Plugin('plugin_type', 'plugin_name')
    cd.update_setting(PluginSetting('p1', 'p1_name', 'p1_value'), plugin)
    cd.update_setting(PluginSetting('p2', 'p2_name', 'p2_value'), plugin)

# Generated at 2022-06-20 13:40:05.555778
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:40:24.035512
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    import datetime
    import ansible.utils.plugin_docs

    expected = """author:
    description: Author of the module.
    type: str
    default: Ansible Core Team
    ini:
        - key: author
          section: defaults
    env:
        - name: ANSIBLE_AUTHOR
    yaml:
        key: author
        version_added: '1.0'
"""


    settings = ansible.utils.plugin_docs.ConfigData()

    settings.update_setting(ansible.utils.plugin_docs.Setting('author', 'Author of the module.', 'str', 'Ansible Core Team', '1.0', '1.0'))

# Generated at 2022-06-20 13:40:28.216173
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()

    s = ConfigSetting(name='timeout',
                      value='10',
                      value_type='int',
                      description='timeout in seconds',
                      ini_section='default',
                      ini_key='timeout')

    config.update_setting(s)

    assert config.get_setting('timeout').value == 10


# Generated at 2022-06-20 13:40:29.923416
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:40:35.533278
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None
    assert config_data._global_settings is not None
    assert config_data._plugins is not None
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-20 13:40:44.335998
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class TestConfigData(ConfigData):
        def __init__(self):
            super(TestConfigData, self).__init__()

    test_config_data = TestConfigData()
    assert test_config_data.get_setting("var1") is None
    assert test_config_data.get_setting("var2") is None
    assert test_config_data.get_settings() == []

    class TestSetting():
        def __init__(self, name, value):
            self.name = name
            self.value = value

    test_setting = TestSetting("var1", "val1")
    test_config_data.update_setting(test_setting)
    assert test_config_data.get_setting("var1") == test_setting
    assert test_config_data.get_setting("var2") is None


# Generated at 2022-06-20 13:40:58.136869
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.callback import CallbackBase

    class TestPlugin(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'notification'
        CALLBACK_NAME = 'test_plugin'

    class TestPluginTwo(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'notification'
        CALLBACK_NAME = 'test_plugin_two'

    plugin = TestPlugin(load_options=True)
    plugin_two = TestPluginTwo(load_options=True)

    assert config.get_setting('test', plugin) is None
    assert config.get_setting('test', plugin_two) is None


# Generated at 2022-06-20 13:40:59.645102
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert len(data._global_settings) == 0
    assert len(data._plugins) == 0

# Generated at 2022-06-20 13:41:13.614943
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    from ansible_collections.ansible.community.plugins.module_utils.common.plugins import PluginLoader, Plugin
    from ansible_collections.ansible.community.plugins.module_utils.common.config import PluginSetting

    # Set up the config data with a global setting, a shell plugin setting and a terminal plugin setting
    global_setting = PluginSetting('simple', ['yes'])
    config_data.update_setting(global_setting)

    shell_plugin_setting = PluginSetting('shell', ['bash'])
    shell_plugin = Plugin('shell', PluginLoader.SHELL_PLUGIN)
    config_data.update_setting(shell_plugin_setting, shell_plugin)

    terminal_plugin_setting = PluginSetting('terminal', ['yes'])

# Generated at 2022-06-20 13:41:25.390544
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert cd._global_settings == {}
    assert cd._plugins == {}

    s1 = Setting(name='setting_1', value='setting1')
    cd.update_setting(s1)
    assert cd._global_settings == {'setting_1': s1}
    assert cd._plugins == {}

    s2 = Setting(name='setting_2', value='setting2')
    p1 = Plugin(type='inventory', name='hosts')
    cd.update_setting(s2, plugin=p1)
    assert cd._plugins == {'inventory': {'hosts': {'setting_2': s2}}}
    assert cd._global_settings == {'setting_1': s1}

    s3 = Setting(name='setting_1', value='new_setting1')

# Generated at 2022-06-20 13:41:26.406780
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:41:32.157065
# Unit test for constructor of class ConfigData
def test_ConfigData():
    obj = ConfigData()
    assert obj is not None


# Generated at 2022-06-20 13:41:35.342999
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    assert config_data.get_settings(PluginName('test')) == []


# Generated at 2022-06-20 13:41:43.516256
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_object = ConfigData()
    test_object.update_setting("appl", "vj")
    test_object.update_setting("appl1")
    print(test_object._global_settings)
    print(test_object._plugins)


test_ConfigData_update_setting()


# Generated at 2022-06-20 13:41:49.950739
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    import os

    config_data = ConfigData()
    # config_data._global_settings = {'foo1':'bar1', 'foo2':'bar2'}
    config_data._global_settings = {'foo1': 'bar1'}
    assert len(config_data.get_settings()) == 1

    config_data._plugins['database'] = {'Microsoft SQL Server': {'foo1': 'bar1'}}
    plugin = Plugin({'type': 'database', 'name': 'Microsoft SQL Server'})
    assert len(config_data.get_settings(plugin)) == 1
    assert len(config_data.get_settings()) == 1



# Generated at 2022-06-20 13:42:04.690636
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # make config object
    config = ConfigData()

    # global setting
    setting = ConfigSetting('FROM_ENV', 'FROM_ENV_VALUE')
    config.update_setting(setting)

    # check setting global
    assert config.get_setting('FROM_ENV').value == 'FROM_ENV_VALUE'

    # check setting local
    assert config.get_setting('ANSIBLE_INVENTORY', plugin=ConfigPlugin('Inventory', 'i1')).value is None

    # local setting
    setting = ConfigSetting('ANSIBLE_INVENTORY', 'ANSIBLE_INVENTORY_VALUE')
    config.update_setting(setting, plugin=ConfigPlugin('Inventory', 'i1'))

    # check setting global

# Generated at 2022-06-20 13:42:18.528728
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('a') is None
    assert config_data.get_setting('a', None) is None

    # update_setting
    import collections
    config_data.update_setting(collections.namedtuple('Setting', 'name,value')('test_name', 'test_value'))
    config_data.update_setting(collections.namedtuple('Setting', 'name,value')('test_name', 'test_value'), None)
    config_data.update_setting(collections.namedtuple('Setting', 'name,value')('test_name', 'test_value'), collections.namedtuple('Plugin', 'name,type')('test_name', 'test_type'))

# Generated at 2022-06-20 13:42:21.617490
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert isinstance(cd, ConfigData)
    assert not hasattr(cd, '_global_settings')
    assert not hasattr(cd, '_plugins')


# Generated at 2022-06-20 13:42:33.619761
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    s1 = Setting("a")
    s2 = Setting("b")
    s3 = Setting("c")
    cd.update_setting(s1)
    cd.update_setting(s2, Plugin("f", "filter"))
    assert cd.get_setting("a") == s1
    assert cd.get_setting("b", Plugin("f", "filter")) == s2
    assert cd.get_setting("c") is None
    assert cd.get_setting("a", Plugin("f", "filter")) is None


# Generated at 2022-06-20 13:42:34.494952
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()


# Generated at 2022-06-20 13:42:37.484497
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()

    assert config._global_settings == {}
    assert config._plugins == {}

# Generated at 2022-06-20 13:42:51.084846
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

    config_data._plugins['my_type'] = {
        'my_name': {
            'my_setting1': 'my_setting1'
        }
    }
    config_data._global_settings['my_global_setting1'] = 'my_global_setting1'
    assert config_data.get_settings() == [config_data._global_settings['my_global_setting1']]
    assert config_data.get_settings(plugin=Plugin('my_type', 'my_name')) == [config_data._plugins['my_type']['my_name']['my_setting1']]


# Generated at 2022-06-20 13:42:56.971114
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    setting1 = Setting("allow_duplicates", "boolean", "True")
    setting2 = Setting("allow_duplicates", "boolean", "False")
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    assert len(config_data.get_settings()) == 2
    config_data.update_setting(setting1)
    assert len(config_data.get_settings()) == 2


# Generated at 2022-06-20 13:42:59.446489
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
	config_data = ConfigData()
	print(config_data.get_setting('test'))

# Generated at 2022-06-20 13:43:06.250426
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    s = {'name': 'version', 'default': '2.3', 'type': 'str'}
    from ansible.cli.plugin.config_data import ConfigSetting
    configdata_setting = ConfigSetting(s)
    config_data.update_setting(configdata_setting)
    assert config_data.get_settings() == [configdata_setting]



# Generated at 2022-06-20 13:43:07.251376
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()



# Generated at 2022-06-20 13:43:11.625479
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None
