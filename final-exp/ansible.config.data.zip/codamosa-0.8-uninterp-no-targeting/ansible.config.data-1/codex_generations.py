

# Generated at 2022-06-20 13:33:19.743857
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {
        'name': 'test_setting_1',
        'changed': True,
        'value': 'updated_value_1',
        'plugin': {
            'type': 'inventory',
            'name': 'local'
        }
    }
    config_data.update_setting(setting)
    assert setting['name'] == 'test_setting_1'
    assert setting['value'] == 'updated_value_1'
    assert config_data.get_setting(setting['name']).value == 'updated_value_1'


# Generated at 2022-06-20 13:33:27.869037
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from awxkit.api.resources import setting
    Setting = setting.Setting
    plugin = setting.Plugin()
    plugin.type = 'bar'
    plugin.name = 'foo'
    cfg = ConfigData()
    setting1 = Setting()
    setting1.key = 'key'
    setting1.value = 'value'
    setting2 = Setting()
    setting2.key = 'key2'
    setting2.value = 'value2'
    cfg.update_setting(setting1, plugin)
    cfg.update_setting(setting2, plugin)
    assert cfg.get_setting('key', plugin).value == 'value'
    assert cfg.get_setting('key2', plugin).value == 'value2'



# Generated at 2022-06-20 13:33:33.360421
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()

    assert(config._global_settings == {})
    assert(config._plugins == {})


# Generated at 2022-06-20 13:33:35.387326
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert len(data._global_settings) == 0, "Checking empty construction of global settings"
    assert len(data._plugins) == 0, "Checking empty construction of plugins"


# Generated at 2022-06-20 13:33:45.860754
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global_settings = {
        'host_key_checking': {
            'name': 'host_key_checking',
            'value': 'True',
            'default': 'True'
        }
    }
    plugins = {
        'cache': {
            'fact_cache': {
                'timeout': {
                    'name': 'timeout',
                    'value': '3600',
                    'default': '3600'
                }
            }
        },
        'callback': {
            'json': {
                'stdout': {
                    'name': 'stdout',
                    'value': 'None',
                    'default': 'None'
                }
            }
        }
    }

# Generated at 2022-06-20 13:33:57.409962
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin_type = 'connection'
    user_connection_plugin_name = 'ansible.netcommon.network_cli'
    ansible_connection_plugin_name = 'ansible.netcommon.network_cli'
    ansible_connection_plugin = Plugin(plugin_type, ansible_connection_plugin_name)

    config_data.update_setting(Setting('timeout', '120', ansible_connection_plugin))
    config_data.update_setting(Setting('retries', '10', ansible_connection_plugin))

    user_connection_plugin = Plugin(plugin_type, user_connection_plugin_name)
    config_data.update_setting(Setting('timeout', '300', user_connection_plugin))

    assert config_data.get_setting('timeout').value == '300'

# Generated at 2022-06-20 13:34:06.504947
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # set up test objects
    config_data = ConfigData()
    
    # test update_setting(setting, plugin = None) with no plugin param
    config_data.update_setting(Setting('setting_one', 'value_one'))
    assert config_data.get_setting('setting_one') == 'value_one'

    # test update_setting(setting, plugin = None) with a plugin param
    config_data.update_setting(Setting('setting_one', 'value_one_new'), Plugin('type_one', 'name_one'))
    assert config_data.get_setting('setting_one') == 'value_one'
    assert config_data.get_setting('setting_one', Plugin('type_one', 'name_one')) == 'value_one_new'


# Generated at 2022-06-20 13:34:11.599528
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_plg_one = Setting('Path', '/path/to/file', 'path', 'f')
    plugin_one = Plugin('Path', 'one', 'p')
    config_data.update_setting(setting_plg_one, plugin_one)
    assert config_data._plugins[plugin_one.type][plugin_one.name] == {'Path': setting_plg_one}


# Generated at 2022-06-20 13:34:17.732248
# Unit test for constructor of class ConfigData
def test_ConfigData():
    from ConfigData import ConfigData
    from Setting import Setting

    data = ConfigData()
    assert len(data._global_settings) == 0
    assert len(data._plugins) == 0

    setting = Setting(name='test_setting', value='test_value')
    data.update_setting(setting)
    assert len(data._global_settings) == 1
    assert len(data._plugins) == 0

    found = data.get_setting(setting.name)
    assert found == setting



# Generated at 2022-06-20 13:34:26.983346
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting1 = Setting('text1', 'success', 'my desc', "my_path", "my_plugin", "my_plugin_type")
    setting2 = Setting('text2', 'success', 'my desc', "my_path", "my_plugin", "my_plugin_type")
    setting3 = Setting('text3', 'success', 'my desc', "my_path", "my_plugin", "my_plugin_type")
    plugin = Plugin('my_plugin', "my_plugin_type")
    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin)
    config_data.update_setting(setting3, plugin)
    assert len(config_data.get_settings()) == 1

# Generated at 2022-06-20 13:34:39.746018
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.module_utils.ansible_release import __version__ as current_ansible_version
    config_data = ConfigData()
    config_data.update_setting('[defaults]\nroles_path = /foo/bar/myroles', None)
    ansible_version = config_data.get_setting('roles_path', None)
    assert ansible_version._value == current_ansible_version
    assert ansible_version._plugin is None
    assert ansible_version._origin == 'config file'
    assert ansible_version._filename is None


# Generated at 2022-06-20 13:34:46.000086
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('ANSIBLE_CALLBACK_PLUGINS', '$HOME/.ansible/plugins/callback:$HOME/.ansible/plugins/callback/custom'))
    config_data.update_setting(Setting('ANSIBLE_PLUGIN_ENVIRONMENT', 'development'))
    settings = config_data.get_settings()
    assert len(settings) == 2
    assert settings[0].name == 'ANSIBLE_CALLBACK_PLUGINS'
    assert settings[1].name == 'ANSIBLE_PLUGIN_ENVIRONMENT'


# Generated at 2022-06-20 13:34:48.143452
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data is not None

# Generated at 2022-06-20 13:35:00.146755
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from units.mock.loader import DictDataLoader

    from ansible.plugins.loader import fragment_loader
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    # TODO: this will be replaced by a real configobj
    base_data = {'retry_files_enabled': '0', 'gathering': 'explicit'}

    # TODO: split this test into configure_setting_global and configure_setting_plugin

    # test configuration with no plugin
    config_data = ConfigData()
    dl = DataLoader()

# Generated at 2022-06-20 13:35:02.352251
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    settings = config_data.get_settings()
    assert len(settings) == 0



# Generated at 2022-06-20 13:35:16.150192
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    class Plugin(object):

        def __init__(self, type, name):
            self._type = type
            self._name = name

        @property
        def type(self):
            return self._type

        @property
        def name(self):
            return self._name

    class Setting(object):

        def __init__(self, name):
            self._name = name

        @property
        def name(self):
            return self._name

    configdata = ConfigData()

    # Test with a global setting
    setting = Setting('ansible_connection')
    assert setting.name in configdata._global_settings is False
    configdata.update_setting(setting)
    assert setting.name in configdata._global_settings is True

    # Test with a plugin setting
    plugin = Plugin('connection', 'paramiko')
   

# Generated at 2022-06-20 13:35:18.241577
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("test") == None

test_ConfigData_get_setting()

# Generated at 2022-06-20 13:35:26.854947
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    config_data._global_settings["plugin_setting1"] = "plugin_setting1_value"
    config_data._global_settings["plugin_setting2"] = "plugin_setting2_value"
    assert set(config_data.get_settings()) == set(["plugin_setting1_value", "plugin_setting2_value"])

# Generated at 2022-06-20 13:35:28.380840
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-20 13:35:36.976935
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    setting_1 = Setting('foo','bar','baz','blah','1','2','3','4','5')
    config_data.update_setting(setting_1)
    setting_2 = Setting('bar','bar','baz','blah','1','2','3','4','5')
    config_data.update_setting(setting_2)
    setting_3 = Setting('baz','bar','baz','blah','1','2','3','4','5')
    config_data.update_setting(setting_3)
    setting_4 = Setting('blah','bar','baz','blah','1','2','3','4','5')
    config_data.update_setting(setting_4)

    settings = config_data.get_settings()
    assert len(settings) == 4

# Generated at 2022-06-20 13:35:46.181357
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_settings = config_data.get_settings()
    assert config_settings == []


# Generated at 2022-06-20 13:35:50.073464
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    """
    Arrange: instantiate an instance of ConfigData
    Act: call the get_settings method of class ConfigData
    Arrange: the return value should be an empty list
    """
    cd = ConfigData()
    assert [] == cd.get_settings()


# Generated at 2022-06-20 13:35:51.972688
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}

# Generated at 2022-06-20 13:36:06.483584
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    configData._global_settings = {
        'debug' : {
            'name' : 'debug',
            'section' : 'DEFAULT',
            'plugin' : None,
            'value' : True
        },
        'log_path' : {
            'name' : 'log_path',
            'section' : 'DEFAULT',
            'plugin' : None,
            'value' : '/var/log/ansible.log'
        }
    }

# Generated at 2022-06-20 13:36:10.300219
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
	configdata=ConfigData()
	assert len(configdata)==0
	configdata.update_setting(Setting('1','1'))
	assert len(configdata)==1
	configdata.update_setting(Setting('2','2','3','4'))
	assert len(configdata)==2
	assert configdata.get_setting('2','2')=='4'


# Generated at 2022-06-20 13:36:17.425515
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='foo', default=None, choices=[])
    config_data.update_setting(setting)
    assert config_data.get_setting('foo').name == 'foo'
    assert config_data.get_settings()[0].name == 'foo'


# Generated at 2022-06-20 13:36:19.925482
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Initialization
    configData = ConfigData()

    # Method under test
    configData.get_settings()




# Generated at 2022-06-20 13:36:25.419015
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    setting = {"name": "ansible_connection", "value": "local"}
    config.update_setting(setting)
    assert setting == config.get_setting("ansible_connection")


# Generated at 2022-06-20 13:36:38.062202
# Unit test for constructor of class ConfigData
def test_ConfigData():
    global_setting = {'ANSIBLE_LOG_PATH': 'log/ansible.log'}
    plugin_setting = {'ANSIBLE_LOG_PATH': 'log/ansible.log'}

    config_data = ConfigData()
    config_data.update_setting(global_setting)
    config_data.update_setting(plugin_setting)
    assert config_data.get_settings() == [global_setting]
    assert config_data.get_settings(plugin_setting) == [plugin_setting]
    print('Test Config Data Class Successfully')


if __name__ == '__main__':
    test_ConfigData()

# Generated at 2022-06-20 13:36:41.254268
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    assert(len(config_data.get_settings()) == 0)



# Generated at 2022-06-20 13:36:51.377137
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configdata = ConfigData()
    plugin = None
    testing = configdata.get_setting('retries', plugin)
    assert testing is None



# Generated at 2022-06-20 13:36:53.736765
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:37:03.422865
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_instance = ConfigData()
    config_data_instance.update_setting(Setting("log_file", "logs/ansible.log", "LogFile"))
    config_data_instance.update_setting(Setting("log_path", "logs/", "LogPath"))
    config_data_instance.update_setting(Setting("log_level", "INFO", "LogLevel"))
    plugin = Plugin("become", "become.myprivilege", "BecomePlugin")
    config_data_instance.update_setting(Setting("become_password", "test", "BecomePlugin"), plugin)
    assert len(config_data_instance.get_settings()) == 3


# Generated at 2022-06-20 13:37:07.385113
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data

    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-20 13:37:14.512951
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_global = Setting('global', 'global_element')
    setting_test_1 = Setting('test', 'test_element')
    setting_test_2 = Setting('test', 'test_element_2')
    plugin_test = Plugin('test', 'test_plugin')
    config_data.update_setting(setting_global)
    config_data.update_setting(setting_test_1, plugin_test)
    config_data.update_setting(setting_test_2, plugin_test)


# Generated at 2022-06-20 13:37:20.087897
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    
    # Create Global setting
    import json
    global_setting_data = '{"name": "option1", "default": "globalvalue1", "env": "globalenv1", "ini": [["globalini1", "ini"]], "cmdline": true}'
    global_setting_json = json.loads(global_setting_data)

    class GlobalSetting():
        pass

    global_setting = GlobalSetting()
    global_setting.name = global_setting_json["name"]
    global_setting.default = global_setting_json["default"]
    global_setting.env = global_setting_json["env"]
    global_setting.ini = global_setting_json["ini"]
    global_setting.cmdline = global_setting_json["cmdline"]

    config_data = ConfigData()
    config_data.update_setting

# Generated at 2022-06-20 13:37:26.590173
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(setting=Setting(name='setting_name', plugin='plugin_name', value='value'))
    settings = config_data.get_settings()
    assert 'value' == settings[0].value
    assert 'value' == config_data.get_setting(name='setting_name').value


# Generated at 2022-06-20 13:37:35.809810
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    p1 = Plugin('vault_credential', 'aws')
    p2 = Plugin('vault_credential', 'foo')
    s1 = Setting('vault_id', 'aws')
    s2 = Setting('vault_id', 'foo')
    cfg = ConfigData()
    cfg.update_setting(s1, p1)
    cfg.update_setting(s2, p2)
    assert cfg.get_setting('vault_id', p1) == s1


# Generated at 2022-06-20 13:37:38.168846
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-20 13:37:39.722258
# Unit test for constructor of class ConfigData
def test_ConfigData():
	config_data = ConfigData()
	assert config_data.__class__ == ConfigData

# Generated at 2022-06-20 13:37:56.275033
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Create object of class ConfigData
    config_data = ConfigData()

    # Test case of method update_setting with one plugin and one setting
    plugin = Plugin(type='lookup', name='ip')
    setting = Setting(name='http_proxy', value='proxy.company.com', section='env')
    config_data.update_setting(setting, plugin)
    settings = config_data.get_settings(plugin)
    assert len(settings) == 1
    assert settings[0].name == 'http_proxy'
    assert settings[0].section == 'env'
    assert settings[0].value == 'proxy.company.com'

    # Test case of method update_setting with no plugin
    global_setting = Setting(name='timeout', value='10', section='defaults')
    config_data.update_setting(global_setting)

# Generated at 2022-06-20 13:37:58.181716
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert isinstance(cd, ConfigData)


# Generated at 2022-06-20 13:38:06.278326
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test1 = ConfigData()

    assert len(test1.get_settings()) == 0

    #global setting
    test1.update_setting(Setting(name='test_setting1', value='test_val1'))
    test1.update_setting(Setting(name='test_setting2', value='test_val2'))

    #plugins
    test1.update_setting(Setting(name='test_setting3', value='test_val3'), Plugin('test_plugin1', 'test_type1'))
    test1.update_setting(Setting(name='test_setting4', value='test_val4'), Plugin('test_plugin1', 'test_type1'))
    test1.update_setting(Setting(name='test_setting3', value='test_val3'), Plugin('test_plugin2', 'test_type1'))

# Generated at 2022-06-20 13:38:09.707639
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
        pass

# Generated at 2022-06-20 13:38:20.425229
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from units.module_utils._text import to_bytes

    # test valid setting
    config = ConfigData()
    config.update_setting(ConfigSetting('foo', 'bar'))
    assert config.get_setting('foo') == ConfigSetting('foo', 'bar')

    # test when plugin is None
    config = ConfigData()
    config.update_setting(ConfigSetting('foo', 'bar'))
    assert config.get_setting('foo') == ConfigSetting('foo', 'bar')

    # test when plugin is not None
    config = ConfigData()
    config.update_setting(ConfigSetting('foo', 'bar'), plugin=ConfigPlugin(type='connection', name='local'))
    assert config.get_setting('foo', plugin=ConfigPlugin(type='connection', name='local')) == ConfigSetting('foo', 'bar')

# Unit

# Generated at 2022-06-20 13:38:22.986852
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    assert ConfigData().update_setting("settingName")._global_settings.keys() == "settingName"

test_ConfigData_update_setting()


# Generated at 2022-06-20 13:38:30.051704
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert config.get_setting('testCar') == None

    config.update_setting(Setting('testCar', 'Opel'))
    assert config.get_setting('testCar') == 'Opel'


# Generated at 2022-06-20 13:38:37.638154
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    expected_config_data = ConfigData()
    config_data.update_setting(Setting(name='count_per_page', value='50', description='Number of results per page'))
    expected_config_data._global_settings = {'count_per_page': Setting(name='count_per_page', value='50', description='Number of results per page')}
    assert config_data._global_settings == expected_config_data._global_settings


# Generated at 2022-06-20 13:38:47.964837
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # create some dummy settings with different keys
    setting1 = ConfigSetting("setting1", "value1")
    setting2 = ConfigSetting("setting2", "value2")
    setting3 = ConfigSetting("setting3", "value3")

    # create some dummy plugins with different keys
    plugin1 = ConfigPlugin("plugin1", "plugin_type1")
    plugin2 = ConfigPlugin("plugin2", "plugin_type2")

    # create instance of ConfigData
    data = ConfigData()

    # add settings to global config
    data.update_setting(setting1)
    data.update_setting(setting2)

    # add settings to plugins
    data.update_setting(setting3, plugin1)
    data.update_setting(setting3, plugin2)

    # Test - global config

# Generated at 2022-06-20 13:38:58.937957
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins import PluginManager
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict

    pm = PluginManager('module')
    pm._plugins['module'] = [{'name': 'foo', 'module': 'bar'},
                             {'name': 'baz', 'module': 'qux'}]

    configData = ConfigData()
    foo_plugin = pm.get('module', 'foo')

    # Test with a setting provided per plugin
    configData.update_setting(ImmutableDict(name="bar", value="foo_a", origin="source"), plugin=foo_plugin)

# Generated at 2022-06-20 13:39:14.444750
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin1 = Plugin('lookup', 'lookup')
    setting1 = Setting('lookups', 'lookup_plugin', 'lookup')
    setting2 = Setting('lookups', 'lookup_plugin2', 'lookup2')
    plugin2 = Plugin('connection', 'ansible-connection')
    setting3 = Setting('connections', 'connection_plugin', 'ansible-connection')
    setting4 = Setting('connections', 'connection_plugin2', 'ansible-connection2')

    config_data = ConfigData()
    config_data.update_setting(setting1, plugin1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting3, plugin2)
    config_data.update_setting(setting4)
    returned_value = config_data.get_settings()

    assert len

# Generated at 2022-06-20 13:39:27.577148
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # PluginInfo
    ansible_plugin = PluginInfo(type=PluginInfo.CORE)
    ansible_plugin.name = "ansible"

    # Setting
    setting = Setting(name='force_handlers')
    setting.value = 'True'

    # ConfigData
    configData = ConfigData()
    configData.update_setting(setting)

    # tests
    force_handlers1 = configData.get_setting('force_handlers')
    assert force_handlers1.value == "True"

    setting.value = 'False'
    configData.update_setting(setting)
    force_handlers2 = configData.get_setting('force_handlers')
    assert force_handlers2.value == "False"

    setting.value = 'true'
    setting.plugin = ansible_plugin
    config

# Generated at 2022-06-20 13:39:34.839070
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from pkgutil import iter_modules
    from ansible.core.plugins.loader import find_plugin_files, add_all_plugin_dirs

    config = ConfigData()

    # test if all non-hidden settings are present in the global list
    setting_names = set()
    for name, ispkg in iter_modules(add_all_plugin_dirs(None)):
        for path in find_plugin_files(name):
            for setting in config.get_settings():
                if setting.name.startswith('_'):
                    continue
                setting_names.add(setting.name)
    assert set(config.get_settings()) == setting_names

# Generated at 2022-06-20 13:39:42.799572
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting1 = {"name": "first", "value": "1"}
    setting2 = {"name": "second", "value": "2"}
    setting3 = {"name": "third", "value": "3"}
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting3, plugin="plugin")
    assert len(config_data.get_settings()) == 2

# Generated at 2022-06-20 13:39:45.011529
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cfg_data = ConfigData()
    assert cfg_data._global_settings == {}
    assert cfg_data._plugins == {}



# Generated at 2022-06-20 13:39:47.613419
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    from Config.PluginConfiguration import Setting

    setting = Setting('foo', False)
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting
    assert config_data.get_setting('bar') is None


# Generated at 2022-06-20 13:39:54.701920
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test', 'value1'))
    config_data.update_setting(Setting('test', 'value2', Plugin('', '', 'type1')))
    assert config_data.get_setting('test') == 'value1'
    assert config_data.get_setting('test', Plugin('', '', 'type1')) == 'value2'


# Generated at 2022-06-20 13:40:05.347798
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Test empty ConfigData object
    cd = ConfigData()
    all_settings = cd.get_settings()
    assert len(all_settings) == 0

    # Test ConfigData object with one global setting
    from ansible_collections.ansible.community.plugins.module_utils.facts.system.distribution import Setting
    s = Setting('name', 'value', 'string', 'description')
    cd = ConfigData()
    cd.update_setting(s)
    all_settings = cd.get_settings()
    assert len(all_settings) == 1
    assert isinstance(all_settings[0], Setting)
    assert all_settings[0].name == 'name'
    assert all_settings[0].value == 'value'
    assert all_settings[0].type == 'string'
    assert all_settings[0].description

# Generated at 2022-06-20 13:40:07.416738
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    c = ConfigData()
    assert c.get_setting(None) is None


# Generated at 2022-06-20 13:40:14.444648
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import os
    import sys
    import textwrap
    import unittest
    from io import StringIO
    from unittest.mock import patch

    from ansible.config.manager import get_default_locations, ConfigManager
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import string_types

    from ansible.plugins.loader import cliconf_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import terminal_

# Generated at 2022-06-20 13:40:41.968622
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings_dict = {'setting1': {'default': 'default1', 'value': 'value1', 'type': 'type1', 'scope': ['scope1', 'scope2']},
                     'setting2': {'default': 'default2', 'value': 'value2', 'type': 'type2', 'scope': ['scope3']}}
    plugin = Plugin('myplugin', 'mytype')
    config_data = ConfigData()
    for setting in settings_dict:
        setting_object = Setting()
        for key, value in settings_dict[setting].items():
            setattr(setting_object, key, value)
        setting_object.name = setting
        config_data.update_setting(setting_object, plugin)


# Generated at 2022-06-20 13:40:44.558390
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    assert configData.get_setting("INVALID_SETTING") is None

# Generated at 2022-06-20 13:40:50.018272
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(PluginSetting(name="valid", value="valid value"))
    assert config.get_setting(name="valid") is not None



# Generated at 2022-06-20 13:41:00.359261
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()

    # Expected: Global setting is added to self._global_settings
    setting = Setting(name="foo", value=1)
    configData.update_setting(setting)
    assert len(configData._global_settings) == 1
    assert configData._global_settings["foo"] == setting

    # Expected: Plugin setting is added to self._plugins
    plugin = Plugin(type="callback", name="bar")
    setting = Setting(name="bar", value=2)
    configData.update_setting(setting, plugin)
    assert len(configData._plugins) == 1
    assert len(configData._plugins["callback"]) == 1
    assert len(configData._plugins["callback"]["bar"]) == 1
    assert configData._plugins["callback"]["bar"]["bar"] == setting




# Generated at 2022-06-20 13:41:12.686507
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    configData._global_settings = {'test' : 'test'}
    configData._plugins = {'testType' : {'testName' : {'test' : 'test'}}}
    setting = 'test2'
    configData.update_setting(setting)
    assert configData._global_settings['test2'] == 'test2'
    setting = 'test2'
    plugin = 'test'
    configData.update_setting(setting, plugin)
    assert configData._plugins['testType']['testName']['test2'] == 'test2'


# Generated at 2022-06-20 13:41:13.788966
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    '''
    :return:
    '''
    pass


# Generated at 2022-06-20 13:41:25.390856
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Test with a plugin that is not set
    config_data = ConfigData()
    assert config_data.get_setting('string_setting') == None
    assert config_data.get_setting('bool_setting') == None
    assert config_data.get_setting('int_setting') == None
    assert config_data.get_setting('float_setting') == None
    assert config_data.get_setting('list_setting') == None
    assert config_data.get_setting('dict_setting') == None
    assert config_data.get_setting('array_setting') == None

    # Test with a global setting that is not set
    config_data = ConfigData()
    assert config_data.get_setting('string_setting') == None
    assert config_data.get_setting('bool_setting') == None
    assert config_data

# Generated at 2022-06-20 13:41:35.922093
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting_1 = Setting('name_1', 'default_value_1', 'value_1')
    setting_2 = Setting('name_2', 'default_value_2', 'value_2')
    setting_3 = Setting('name_3', 'default_value_3', 'value_3')
    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2)
    config_data.update_setting(setting_3, Plugin(PLUGIN_TYPE_SHARED, 'plugin_1'))

    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings(Plugin(PLUGIN_TYPE_SHARED, 'plugin_1'))) == 1

# Generated at 2022-06-20 13:41:40.871237
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()

    assert configData._global_settings == {}
    assert configData._plugins == {}


# Generated at 2022-06-20 13:41:52.966499
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    from collections import namedtuple
    Plugin = namedtuple('Plugin', 'type name')
    plugin_1 = Plugin(type='action', name='action_1')
    plugin_2 = Plugin(type='action', name='action_2')
    plugin_3 = Plugin(type='filter', name='filter_1')

    assert config_data.get_settings(plugin_1) == []
    assert config_data.get_settings(plugin_2) == []
    assert config_data.get_settings(plugin_3) == []

    # Add a global setting
    from ansiblelint.rules.Precedence import Precedence
    from ansiblelint.config.yaml import RulesYaml
    rule_file = "tests/rules/precedence.yaml"
    rules_yaml

# Generated at 2022-06-20 13:42:30.356457
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    
    configData = ConfigData()
    
    configData.update_setting(None)
    configData.update_setting(None, None)
    configData.update_setting(None, 'plugin')


# Generated at 2022-06-20 13:42:35.910144
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Initialise config data
    configData = ConfigData()
    # Create a global setting
    setting = Setting('foo', 'bar')
    # Update config data and add the setting
    configData.update_setting(setting)
    # Get the settings
    settings = configData.get_settings()

    # Check that the settings contains one setting
    assert len(settings) == 1
    assert settings[0].name == 'foo'


# Generated at 2022-06-20 13:42:42.110994
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting('global setting')
    config_data.update_setting('global setting 2')
    config_data.update_setting('setting for plugin 1')
    setting = config_data.get_setting('setting for plugin 1')
    print(setting.name)
    setting = config_data.get_setting('global setting')
    print(setting.name)


# Generated at 2022-06-20 13:42:46.927005
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    # Test case of get_settings without plugin
    print(config_data.get_settings())
    # Test case of get_settings with plugin
    plugin = {'name': 'vpc', 'type': 'module'}
    print(config_data.get_settings(plugin))


# Generated at 2022-06-20 13:42:57.749627
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting_1 = Setting(name='a', value=1, origin='file', plugin=None, plugin_type='global')
    setting_2 = Setting(name='b', value=2, origin='file', plugin=Plugin(name='test_plugin', type='cli'), plugin_type='cli')
    setting_3 = Setting(name='c', value=3, origin='file', plugin=Plugin(name='test_plugin', type='other'), plugin_type='other')

    # test with invalid plugin
    assert config_data.get_setting('a') is None

    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2)
    config_data.update_setting(setting_3)

    # test with global plugin
    assert config_data.get_setting

# Generated at 2022-06-20 13:43:05.799281
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from ansible.module_utils.config.data import ConfigData, Setting
    from ansible.module_utils.config.types import Plugin
    config = ConfigData()
    plugin = Plugin('lookup', 'lookup')
    config.update_setting(Setting('_prefix', 'ansible_lookup_'))
    setting = config.get_setting('_prefix')
    assert setting.name == '_prefix'
    assert setting.get() == 'ansible_lookup_'

# Generated at 2022-06-20 13:43:07.154749
# Unit test for constructor of class ConfigData
def test_ConfigData():

    data = ConfigData()

    assert data
