

# Generated at 2022-06-20 13:33:22.369117
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    assert config_data.get_settings_()

    config_data = ConfigData()
    config_data._global_settings['setting1'] = 'setting1'
    assert config_data.get_settings_()

    config_data = ConfigData()
    config_data._global_settings['setting1'] = 'setting1', 2
    assert config_data.get_settings_()

    config_data = ConfigData()
    config_data._global_settings['setting1'] = 'setting1', 2, ['a', 'b', 'c']
    assert config_data.get_settings_()

    config_data = ConfigData()
    config_data._global_settings['setting1'] = 'version', 2, ['a', 'b', 'c']
    assert config_data.get_settings_()



# Generated at 2022-06-20 13:33:25.093254
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    assert data.get_setting('foo') is None
    data.update_setting(Setting('foo', 'bar'))
    assert data.get_setting('foo').value == 'bar'



# Generated at 2022-06-20 13:33:29.629545
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    assert config_data.get_setting("key1") is None


# Generated at 2022-06-20 13:33:37.034703
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    data = ConfigData()

    global_setting = {'name': 'force_color', 'value': True, 'origin': 'ansible.cfg', 'level': 'info'}
    data.update_setting(global_setting)
    assert data.get_setting('force_color') == global_setting

    connection_setting = {'name': 'persistent_connect_timeout', 'value': 10, 'origin': 'ansible.cfg', 'level': 'info'}
    data.update_setting(connection_setting, plugin={'type': 'connection', 'name': 'network_cli'})
    assert data.get_setting('persistent_connect_timeout', plugin={'type': 'connection', 'name': 'network_cli'}) == connection_setting



# Generated at 2022-06-20 13:33:41.185065
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    config_data.update_setting(SettingTest('num', 'Number of Tests', 1))
    assert config_data.get_setting('num').value == 1


# Generated at 2022-06-20 13:33:48.662661
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_1 = ConfigData()
    assert config_1.get_setting("test_setting") == None, "ConfigData.get_setting should return None"

    config_2 = ConfigData()
    config_2.update_setting(Setting("test_setting", "test_value", ["test_type"], "test_description"))
    assert config_2.get_setting("test_setting") is not None, "ConfigData.get_setting should return a Setting"
    assert config_2.get_setting("test_setting").value == "test_value", "ConfigData.get_setting should find the Setting"

    config_3 = ConfigData()
    config_3.update_setting(Setting("test_setting", "test_value", ["test_type"], "test_description"))

# Generated at 2022-06-20 13:33:50.644838
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    config_data.update_setting(Setting("foo", "bar"))
    assert config_data.get_setting("foo").name == "foo"
    assert config_data.get_setting("foo").value == "bar"



# Generated at 2022-06-20 13:33:59.926990
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from units.compat.mock import patch
    from units.modules.utils import set_module_args

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True),
            plugin_type=dict(type='str'),
        ),
        supports_check_mode=True
    )

    with patch.object(ConfigData, 'get_settings') as mock_get_settings:
        set_module_args(dict(
            name='foo',
            plugin_type='bar',
        ))

        result = ConfigData.get_settings(module)
        assert result == mock_get_settings.return_value



# Generated at 2022-06-20 13:34:10.885483
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    class Setting(object):
        def __init__(self, name, value, origin, scope, plugin=None):
            self.name = name
            self.value = value
            self.origin = origin
            self.scope = scope
            self.plugin = plugin

    class Plugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    global_setting = Setting('global_key', 'global_value', 'core.yml', 'global')
    config_data.update_setting(global_setting)
    assert config_data._global_settings['global_key'].value == 'global_value'

    plugin1 = Plugin('parent', 'a_plugin')

# Generated at 2022-06-20 13:34:19.339427
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd_test = ConfigData()
    cs_test = ConfigSetting()
    cs_test.name = "name"
    cs_test.value = "value"
    cs_test.origin = "origin"
    cs_test.plugin.type = "type"
    cs_test.plugin.name = "name"

    cd_test.update_setting(cs_test, cs_test.plugin)
    cd_return = cd_test.get_setting("name", cs_test.plugin)

    assert cd_return.name == "name"
    assert cd_return.value == "value"
    assert cd_return.origin == "origin"
    assert cd_return.plugin.type == "type"
    assert cd_return.plugin.name == "name"


# Generated at 2022-06-20 13:34:27.739979
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    data = ConfigData()

    plugin = Plugin(type='action', name='pause')
    setting = PluginSetting(name='pause', value='0')

    data.update_setting(setting)
    data.update_setting(setting, plugin=plugin)

    settings_1 = data.get_settings()
    settings_2 = data.get_settings(plugin)

    assert(len(settings_1) == 1)
    assert(settings_1[0].name == 'pause')

    assert(len(settings_2) == 1)
    assert(settings_2[0].name == 'pause')
    assert(settings_2[0].value == '0')


# Generated at 2022-06-20 13:34:33.515232
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()

    # Test 1: If a plugin is passsed, the settings for that plugin should be returned
    configdata._plugins['connection_plugin'] = {'local': {'core': 'core'}}
    assert len(configdata.get_settings(plugin='connection_plugin')) == 1

    # Test 2: If a plugin is passsed, the settings for that plugin should be returned
    configdata._global_settings = {'core': 'core'}
    assert len(configdata.get_settings(plugin=None)) == 1



# Generated at 2022-06-20 13:34:44.707805
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class Plugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    config = ConfigData()

    setting1 = {'name': 'setting1', 'value': 1}
    setting2 = {'name': 'setting2', 'value': 2}
    setting3 = {'name': 'setting3', 'value': 3}
    setting4 = {'name': 'setting4', 'value': 4}

    config.update_setting(setting1)
    assert config.get_setting('setting1') == setting1
    assert config.get_setting('setting1') != setting2
    assert config.get_setting('setting3') == None
    assert config.get_setting('setting4') == None
    plugin1 = Plugin('module', 'testmodule')
    config.update

# Generated at 2022-06-20 13:34:47.882560
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()

    assert config is not None

# Generated at 2022-06-20 13:34:55.928917
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    setting1 = Setting('basic_setting','basic_setting','basic')
    setting2 = Setting('specific_setting','specific_setting','specific')
    configData.update_setting(setting1)
    configData.update_setting(setting2, plugin=Plugin('type1', 'name1'))
    assert (configData._global_settings == {'basic_setting': setting1})
    assert (configData._plugins == {'type1': {'name1': {'specific_setting': setting2}}})

# Generated at 2022-06-20 13:35:04.917388
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    settings = [
        Setting('default_ipv4_addr_pool', [], ['vpn-profile'], 'Inventories', 'Community',
                'The default IP address pool to use for IP address assignment when configuring the IPsec VPN.', '', '',
                '', ''),
        Setting('default_ipv6_addr_pool', [], ['vpn-profile'], 'Inventories', 'Community',
                'The default IP address pool to use for IP address assignment when configuring the IPsec VPN.', '', '',
                '', ''),
        Setting('default_ipv4_addr_pool', [], ['vpn-profile'], 'Inventories', 'Community',
                'The default IP address pool to use for IP address assignment when configuring the IPsec VPN.', '', '',
                '', '')
    ]

# Generated at 2022-06-20 13:35:13.936491
# Unit test for constructor of class ConfigData
def test_ConfigData():
    from ansible.module_utils.common.validation import Plugin, Setting
    config_data = ConfigData()

    test_plugin = Plugin("test", "test", "test")
    test_plugin2 = Plugin("test2", "test2", "test2")

    test_setting = Setting("test", "test", "test", "test", "test")
    test_setting2 = Setting("test2", "test2", "test2", "test2", "test2")

    # Test case to create a new setting and access it via get_setting
    config_data.update_setting(test_setting, test_plugin)
    assert config_data.get_setting("test", test_plugin) == test_setting

    # Test case to update an existing setting and access it via get_setting

# Generated at 2022-06-20 13:35:26.302019
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    plugin_type1 = 'lookup'
    plugin_name1 = 'plugin1'
    plugin_type2 = 'vars'
    settings = [
        Setting(plugin_type1, name='var1', path='value1'),
        Setting(plugin_type1, name='var2', path='value2'),
        Setting(plugin_type2, name='var3', path='value3')
    ]

    config_data = ConfigData()
    for setting in settings:
        config_data.update_setting(setting)

    assert config_data.get_setting('var1') == settings[0]
    assert config_data.get_setting('var2') == settings[1]
    assert config_data.get_setting('var3') == settings[2]
    assert config_data.get_setting('var4') is None


# Generated at 2022-06-20 13:35:34.898274
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.connections.local import Connection

    config = ConfigData()

    # Test for global setting
    setting = Setting('test_setting', 123)
    config.update_setting(setting)

    assert config.get_settings()[0].__dict__ == setting.__dict__

    # Test for adding setting to connection plugin
    setting = Setting('test_setting', 123)
    connection = PluginLoader.get('connection', 'local')
    config.update_setting(setting, connection)
    assert setting.__dict__ in [s.__dict__ for s in config.get_settings(connection)]



# Generated at 2022-06-20 13:35:42.168821
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    plugin = PluginDefinition("1", "2")
    setting = SettingDefinition("name", 1, plugin)
    config_data.update_setting(setting)

    assert setting == config_data.get_setting("name", plugin)

# Generated at 2022-06-20 13:35:47.226602
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    cd.update_setting(ConfigSetting('fact_cache', '/var/cache/ansible/facts'))
    assert  cd.get_setting('fact_cache').value == '/var/cache/ansible/facts'


# Generated at 2022-06-20 13:35:54.556452
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    from collections import namedtuple
    from ansiblelint.rules.LineTooLongRule import LineTooLongRule
    Setting = namedtuple('Setting', 'name value type')
    setting = Setting('line_length', '80', 'int')
    plugin = LineTooLongRule()
    config_data.update_setting(setting, plugin)
    settings = config_data.get_settings(plugin)
    assert settings[0].value == '80'
    assert settings[0].name == 'line_length'
    assert settings[0].type == 'int'


# Generated at 2022-06-20 13:36:03.869530
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin('shell', 'shell')
    setting = Setting('hosts', 'localhost')
    config_data.update_setting(setting)
    assert config_data.get_settings(plugin) is None
    setting = Setting('hosts', '127.0.0.1')
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings(plugin)[0].name == 'hosts'
    assert config_data.get_settings(plugin)[0].value == '127.0.0.1'


# Generated at 2022-06-20 13:36:07.823325
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(Setting('default_cache_plugin', 'yaml'))
    assert config._global_settings['default_cache_plugin'] == Setting('default_cache_plugin', 'yaml')


# Generated at 2022-06-20 13:36:15.745685
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ConfigParser import ConfigParser
    import os

    test_file_path = os.path.join('test', 'unit', 'test_data')

    config_parser = ConfigParser()
    config_parser.read(os.path.join(test_file_path, 'test_ansible.cfg'))

    settings = config_parser.items('defaults')

    config_data = ConfigData()

    for path, value in settings:
        if path == 'inventory' or path == 'library' or path == 'roles_path':
            continue

        config_data.update_setting(Setting(path, value))

    assert config_data.get_setting('ansible_managed') == settings[0]
    assert config_data.get_setting('host_key_checking') == settings[1]


# Generated at 2022-06-20 13:36:25.918958
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class FakePlugin():
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class FakeSetting():
        def __init__(self, name, value):
            self.name = name
            self.value = value

    # Positive case
    config_data = ConfigData()
    config_data.update_setting(FakeSetting('host_key_checking', 'yes'))
    assert 'host_key_checking' == config_data.get_setting('host_key_checking').name

    # Negative case
    assert None == config_data.get_setting('test')

    # Positive case
    config_data.update_setting(FakeSetting('test', 'yes'), FakePlugin('test', 'test'))

# Generated at 2022-06-20 13:36:37.300222
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    setting1 = Setting('test_setting1')
    data.update_setting(setting1)
    setting2 = Setting('test_setting2')
    data.update_setting(setting2, Plugin('test_plugin', 'test_type'))

    setting3 = data.get_setting('test_setting1')
    setting4 = data.get_setting('test_setting2', Plugin('test_plugin', 'test_type'))

    assert setting3.name == 'test_setting1'
    assert setting4.name == 'test_setting2'



# Generated at 2022-06-20 13:36:41.428970
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # GIVEN

    # WHEN
    configdata = ConfigData()

    # THEN
    assert configdata._global_settings == {}


# Generated at 2022-06-20 13:36:45.487672
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-20 13:36:46.768452
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)

# Generated at 2022-06-20 13:37:00.632215
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    data = ConfigData()
    data.update_setting(Setting('ANSIBLE_CALLBACK_WHITELIST', 'profile_tasks'))
    data.update_setting(Setting('ANSIBLE_CALLBACK_WHITELIST', ['profile_tasks', 'timer'], 'anisble.plugins.callback.timer'))
    data.update_setting(Setting('ANSIBLE_CALLBACK_WHITELIST', 'profile_tasks', PluginType.CALLBACK, 'profile_tasks'))
    setting = data.get_setting('ANSIBLE_CALLBACK_WHITELIST')
    assert setting.name == 'ANSIBLE_CALLBACK_WHITELIST'
    assert setting.value == ['profile_tasks', 'timer']
    assert setting.plugin is None

# Generated at 2022-06-20 13:37:06.094485
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    config_data.update_setting(global_setting, None)

    assert config_data.get_settings()[0].name == "global_key"
    assert config_data.get_settings(core_plugin)[0].name == "core_key"
    assert config_data.get_settings(callback_plugin)[0].name == "callback_key"



# Generated at 2022-06-20 13:37:09.034359
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert len(config_data._global_settings) == 0
    assert len(config_data._plugins) == 0


# Generated at 2022-06-20 13:37:10.766995
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert not config_data._global_settings
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:37:16.764108
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cdata = ConfigData()
    cdata.update_setting(Setting('a', 'b'))
    cdata.update_setting(Setting('b', 'c'))

    assert len(cdata.get_settings()) == 2


# Generated at 2022-06-20 13:37:21.707609
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('is_sourced') == None


# Generated at 2022-06-20 13:37:29.010657
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    import pytest
    # create an example of ConfigData
    config_data = ConfigData()
    # create an example of Setting
    setting = Setting('test', 'test')
    # update setting to check if it is returned in get_settings method
    config_data.update_setting(setting)
    settings = config_data.get_settings()
    setting_names = [setting_item.name for setting_item in settings]
    # check if the setting is returned
    assert 'test' in setting_names


# Generated at 2022-06-20 13:37:31.717263
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Arrange
    config = ConfigData()
    plugin = 'abc'
    config._global_settings = {'key': 'value'}

    config._plugins = {
        plugin.type: {
            plugin.name: {
                'key': 'value'
            }
        }
    }

    # Act
    settings = config.get_settings(plugin)

    # Assert
    assert len(settings) == 2

# Generated at 2022-06-20 13:37:46.016185
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    settingA = ConfigSetting("A","global", "global", "global")
    settingB = ConfigSetting("B","global", "global", "global")

    config_data.update_setting(settingA)
    config_data.update_setting(settingB)

    assert config_data.get_setting("A") == settingA
    assert config_data.get_setting("B") == settingB

    from ansible import constants as C

    plugin = Plugin("module", "shell")
    settingC = ConfigSetting("C", C.CONFIG_SHELL_PLUGIN, "shell", "shell")

    config_data.update_setting(settingC, plugin)
    assert config_data.get_setting("C", plugin) == settingC



# Generated at 2022-06-20 13:37:50.556598
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.config.setting import Setting
    setting_1 = Setting('foo', [42])
    data.update_setting(setting_1)
    setting_2 = data.get_setting('foo')
    assert setting_2.value[0] == 42


# Generated at 2022-06-20 13:38:05.826521
# Unit test for constructor of class ConfigData
def test_ConfigData():
    import pytest
    from ansible.plugins.loader import find_plugin_file

    plugin_name = 'TestPlugin'
    plugin_type = 'cliconf'
    plugin_config_file = find_plugin_file(plugin_type, plugin_name)
    test_config_data = ConfigData()

    print('test case: test_ConfigData')

    # test_get_setting_with_empty_name
    assert test_config_data.get_setting('') == None

    # test_get_setting_with_not_exist_setting
    assert test_config_data.get_setting('abc') == None

    # test_get_setting_with_not_exist_type_and_name

# Generated at 2022-06-20 13:38:08.951990
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(ConfigSetting("verbosity", "1", "Verbosity level"))

    setting = config.get_setting("verbosity")
    assert setting
    assert setting.name == "verbosity"
    assert setting.value == "1"


# Generated at 2022-06-20 13:38:11.149643
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert(cd is not None)


# Generated at 2022-06-20 13:38:13.478765
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert {} == config_data._global_settings
    assert {} == config_data._plugins


# Generated at 2022-06-20 13:38:21.615952
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Setup
    configData = ConfigData()
    setting = ConfigSetting(name='test_setting')

    # Assert default
    assert configData.get_setting('test_setting') is None

    # Assert global setting
    configData.update_setting(setting)
    assert configData.get_setting('test_setting') == setting

    # Assert plugin type
    plugin = Plugin('test_type', 'test_name')
    configData.update_setting(setting, plugin)
    assert configData.get_setting('test_setting', plugin) == setting


# Generated at 2022-06-20 13:38:27.178036
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import ansible.plugins.loader as loader
    loader.PluginLoader = None
    cd = ConfigData()
    cd.update_setting(Setting("plugin_dir", "/home/test", loader.PluginLoader("cache", "test1")))
    cd.update_setting(Setting("plugin_dir", "/home/test2", loader.PluginLoader("cache", "test2")))
    assert cd.get_settings(loader.PluginLoader("cache", "test1"))[0].name == "plugin_dir"
    assert cd.get_settings(loader.PluginLoader("cache", "test1"))[0].value == "/home/test"
    assert cd.get_settings(loader.PluginLoader("cache", "test2"))[0].value == "/home/test2"



# Generated at 2022-06-20 13:38:39.151996
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name="foo", value="bar"))
    config_data.update_setting(Setting(name="foo", value="baz", plugin=Plugin(name="qux", type="core")))
    assert config_data.get_setting("foo") == Setting(name="foo", value="bar")
    assert config_data.get_setting("foo", plugin=Plugin(name="qux", type="core")) == Setting(name="foo", value="baz", plugin=Plugin(name="qux", type="core"))
    assert config_data.get_setting("foo", plugin=Plugin(name="qux", type="cache")) is None
    assert config_data.get_setting("quux") is None

#Unit test for method get_settings of class ConfigData

# Generated at 2022-06-20 13:38:47.808522
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # initialize the data for a plugin and setting
    setting_data = ('PLUGIN_VARIABLE', 'Module', '', 'PLUGIN_VARIABLE_VALUE', 'PLUGIN_VARIABLE_DESCRIPTION')

    config_data = ConfigData()
    config_data.update_setting(*setting_data)

    assert config_data.get_setting('PLUGIN_VARIABLE', plugin=None) is None
    assert config_data.get_setting('PLUGIN_VARIABLE', plugin=ConfigData()) is None
    assert config_data.get_setting('PLUGIN_VARIABLE', plugin=ConfigData()) is None
    assert config_data.get_setting('PLUGIN_VARIABLE', plugin=ConfigData()).name == 'PLUGIN_VARIABLE'
   

# Generated at 2022-06-20 13:38:57.647629
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.config.setting import Setting, Field

    config = ConfigData()
    config.update_setting(Setting(name="test_setting1", default=1))
    config.update_setting(Setting(name="test_setting2", default=2))

    assert isinstance(config._global_settings, Mapping)
    assert config._global_settings == ImmutableDict({"test_setting1": Setting(name="test_setting1", default=1),
                                                     "test_setting2": Setting(name="test_setting2", default=2)})


# Generated at 2022-06-20 13:38:59.376754
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert config.get_setting('nonexist') is None


# Generated at 2022-06-20 13:39:04.395833
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data is not None

# Generated at 2022-06-20 13:39:15.109070
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting_plugin1_1 = Setting('features_string', 'feature1', 'string')
    config_data.update_setting(setting_plugin1_1)
    setting_plugin1_2 = Setting('features_string', 'feature1', 'string')
    config_data.update_setting(setting_plugin1_2)
    setting_plugin2_1 = Setting('features_string', 'feature2', 'string')
    config_data.update_setting(setting_plugin2_1)
    settings = config_data.get_settings()
    assert settings == [setting_plugin1_1, setting_plugin1_2, setting_plugin2_1]


# Generated at 2022-06-20 13:39:17.834407
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = None
    config_data.update_setting("GlobalSetting")
    assert config_data.get_setting("GlobalSetting") == "GlobalSetting"


# Generated at 2022-06-20 13:39:20.130486
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData()._global_settings == {}
    assert ConfigData()._plugins == {}


# Generated at 2022-06-20 13:39:24.561457
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert not config_data.get_settings()
    config_data.update_setting(Setting(name='test'))
    assert config_data.get_settings()[0].name == 'test'
    assert not config_data.get_settings('test')

# Generated at 2022-06-20 13:39:28.107430
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    print("Testing ConfigData.get_setting")

    config_data = ConfigData()

    setting1 = config_data.get_settings()  # Test case with no plugin
    assert setting1 == []

    setting2 = config_data.get_settings()  # Test case with invalid plugin
    assert setting2 == []

# Generated at 2022-06-20 13:39:36.136221
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    plugin = AnsiblePlugin('', '', '')
    setting1 = ConfigSetting('', '', '')
    setting2 = ConfigSetting('', '', '')

    config_data = ConfigData()
    settings = config_data.get_settings()
    assert len(settings) == 0

    # test with plugin
    config_data.update_setting(setting1, plugin)
    settings = config_data.get_settings(plugin)
    settings_dict = {setting.name: setting for setting in settings}

    assert settings_dict.get(setting1.name) == setting1
    assert settings_dict.get(setting2.name) is None

    # test global
    config_data.update_setting(setting2)
    settings = config_data.get_settings()

# Generated at 2022-06-20 13:39:47.186922
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class TestPlugin():

        def __init__(self, name, type):
            self.name = name
            self.type = type

    def _test_ConfigData_get_settings(config_data, plugin, expected_output):
        actual_output = config_data.get_settings(plugin)
        assert actual_output == expected_output

    config_data = ConfigData()

    plugin = TestPlugin("plugin1", "plugin1_type")
    _test_ConfigData_get_settings(config_data, plugin, [])

    plugin = TestPlugin("plugin1", "plugin1_type")
    config_data.update_setting("setting_value_1", plugin=None)
    _test_ConfigData_get_settings(config_data, None, ["setting_value_1"])


# Generated at 2022-06-20 13:39:53.051007
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    cd = ConfigData()

    class Plugin(object):

        def __init__(self, type, name):
            self.type = type
            self.name = name

    import copy

    class Setting(object):

        def __init__(self, name, value):
            self.name = name
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

    setting = Setting('foo', 'bar')
    setting2 = Setting('foo2', 'bar2')
    plugin = Plugin('my_type', 'my_name')
    pluginb = Plugin('my_type_other', 'my_name_other')

    cd.update_setting(setting)
    cd.update_setting(setting2, pluginb)
    cd.update_setting(copy.copy(setting), plugin)

# Generated at 2022-06-20 13:39:55.794238
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}

# Unit Test for get_setting for class ConfigData

# Generated at 2022-06-20 13:40:08.922559
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    from ansible.plugins.loader import PluginLoader
    action_plugin_loader = PluginLoader('ActionModule', 'ansible.plugins.action', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugins')
    action_plugin_loader.add_directory(C.DEFAULT_ACTION_PLUGIN_PATH)
    action_plugin_loader.add_directory(C.DEFAULT_ACTION_INCLUDE_PATH)
    action_plugin_loader.add_directory(C.DEFAULT_ACTION_INCLUDE_PATH2)
    all_action_plugins = action_plugin_loader.all()
    for plugin in all_action_plugins:
        if plugin.name == 'debug':
            assert plugin.name == 'debug'
            assert plugin.docs == 'Print statements during execution'

# Generated at 2022-06-20 13:40:13.086321
# Unit test for constructor of class ConfigData
def test_ConfigData():
    pass

# Generated at 2022-06-20 13:40:17.247879
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('a', 'b'))
    assert len(config_data._global_settings) == 1
    assert config_data.get_setting('a') is not None


# Generated at 2022-06-20 13:40:23.283928
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('ansible_host_key_checking', 'no', 'yaml')
    plugin = Plugin('type', 'name')
    config_data.update_setting(setting, plugin)

    # Verfiy that the expected setting is returned
    assert config_data.get_setting("ansible_host_key_checking", plugin) == setting


# Generated at 2022-06-20 13:40:28.256405
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    settings_data = ConfigData()

    plugin_type = PluginType('parser')
    plugin_name = 'ansible-config'
    plugin = Plugin(plugin_type, plugin_name)

    setting1 = Setting('foo', 'bar')
    settings_data.update_setting(setting1, plugin)
    assert settings_data._plugins['parser'][plugin_name]['foo'] == setting1



# Generated at 2022-06-20 13:40:29.699291
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert config_data.get_settings() == []



# Generated at 2022-06-20 13:40:41.733455
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Create a ConfigData instance
    config = ConfigData()

    # Create a global setting
    global_setting = ConfigSetting(name='foo', value='bar')
    # Add it to the instance
    config.update_setting(setting=global_setting)
    # Check that 'foo' was added successfully
    assert config.get_setting(name='foo', plugin=None) == global_setting

    # Create a plugin setting
    import ansible.plugins.loader
    plugin_setting = ConfigSetting(name='baz', value='qux')
    # Add it to the instance
    config.update_setting(setting=plugin_setting, plugin=ansible.plugins.loader.all.Connection('ssh'))
    # Check that 'baz' was added successfully

# Generated at 2022-06-20 13:40:49.580687
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting1 = None
    plugin1 = None
    setting2 = None
    plugin2 = None
    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin1)
    assert config_data.get_setting(setting1.name) == setting1
    assert config_data.get_setting(setting2.name, plugin1) == setting2
    assert config_data.get_setting(setting2.name, plugin2) == None
    assert config_data.get_settings() == [setting1]
    assert config_data.get_settings(plugin1) == [setting2]
    assert config_data.get_settings(plugin2) == []

# Generated at 2022-06-20 13:41:00.124403
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting1 = {'name': 'setting1', 'value': 'value1'}
    setting2 = {'name': 'setting2', 'value': 'value2'}
    setting3 = {'name': 'setting3', 'value': 'value3'}
    plugin = {'type': 'type1', 'name': 'name1'}

    # Overwrite existing setting
    config_data.update_setting(setting1, plugin)
    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin)
    config_data.update_setting(setting1, None)

    assert config_data.get_setting('setting1', plugin) == setting1
    assert config_data.get_setting('setting2', plugin) == setting2
    assert config_

# Generated at 2022-06-20 13:41:08.159290
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}
    
    assert config_data.get_settings(None) == []
    assert config_data.get_settings(Plugin(None, None)) == []

# Generated at 2022-06-20 13:41:13.357399
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert (config_data is not None)

# Generated at 2022-06-20 13:41:19.825247
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    conf_data = ConfigData()

    print("Test: Get global setting")
    dir(conf_data)
    conf_data._global_settings['ansible_diff_mode'] = 'yes'
    conf_data.update_setting(conf_data._global_settings['ansible_diff_mode'])
    result = conf_data.get_settings()
    assert 'yes' == result[0].value

    print("Test: Get module setting")
    from ansible.plugins.loader import module_loader
    plugin = module_loader.get('shell')
    plugin.settings['shell_executable'] = '/bin/ksh'
    conf_data.update_setting(plugin.settings['shell_executable'], plugin)
    result = conf_data.get_settings(plugin)
    assert '/bin/ksh' == result[0].value

# Generated at 2022-06-20 13:41:29.656057
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    plugin1 = PluginDefinition('Test Plugin')
    setting1 = SettingDefinition('test setting', 'test value')
    plugin1.update_setting(setting1)
    plugin2 = PluginDefinition('Test Plugin 2')
    setting2 = SettingDefinition('test setting 2', 'test value 2')
    plugin2.update_setting(setting2)
    config.update_setting(setting1, plugin1)
    config.update_setting(setting2, plugin2)
    assert config.get_setting('test setting', plugin1) == setting1
    assert config.get_setting('test setting 2', plugin2) == setting2



# Generated at 2022-06-20 13:41:38.909757
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # I initialize the context
    config_data = ConfigData()

    # I create some settings
    from units.mock.loader import DictDataLoader
    from ansible.plugins.loader import plugin_loader
    plugin_loader._loaders['test_loader'] = DictDataLoader()
    from units.mock.plugins.test_connection import TestConnectionPlugin
    p = TestConnectionPlugin('test_name')

    from ansible.plugins.setting import Setting
    s1 = Setting(name='s1', plugin_type='test_loader', plugin_name='test_name', description='s1 description')
    s2 = Setting(name='s2', plugin_type='test_loader', plugin_name='test_name', description='s2 description')

    # I add the settings
    config_data.update_setting(s1)
    config

# Generated at 2022-06-20 13:41:49.202152
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()

    class TestPlugin():
        def __init__(self, name, type):
            self.name = name
            self.type = type

    settings = config.get_settings(None)
    assert not settings

    from ansible.plugins.action import ActionBase
    test_plugin_1 = TestPlugin('test_plugin_1', 'action')
    test_plugin_2 = TestPlugin('test_plugin_2', 'action')
    settings = config.get_settings(test_plugin_1)
    assert not settings
    settings = config.get_settings(test_plugin_2)
    assert not settings

    from ansible.plugins.loader import PluginLoader
    loader = PluginLoader(test_plugin_1.type)
    action_plugin = loader.get(test_plugin_1.name)

# Generated at 2022-06-20 13:41:55.976052
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    setting1 = Setting('foo', 'bar', 'baz')
    setting2 = Setting('foo', 'bar', 'baz')
    setting3 = Setting('foo', 'bar', 'baz')
    setting4 = Setting('foo', 'bar', 'baz')
    setting5 = Setting('foo', 'bar', 'baz')
    setting6 = Setting('foo', 'bar', 'baz')

    plugin1 = Plugin('foo', 'bar')
    plugin2 = Plugin('baz', 'foo')
    plugin3 = Plugin('baz', 'bar')

    config.update_setting(setting1)
    config.update_setting(setting2, plugin1)
    config.update_setting(setting3, plugin2)
    config.update_setting(setting4, plugin3)


# Generated at 2022-06-20 13:42:06.435584
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Create a new configuration data object
    config = ConfigData()
    
    # Creating a new setting and updating the configuration data
    setting_one = Setting(name='one', value=1)
    config.update_setting(setting_one)
    
    # Asserting the values for setting one
    assert config.get_setting(name='one') == setting_one

    # Creating a new setting and updating the configuration data
    setting_two = Setting(name='two', value=2)
    config.update_setting(setting_two)
    
    # Asserting the values for setting two
    assert config.get_setting(name='two') == setting_two

    # Asserting the values for all settings in the configuration data
    assert setting_one in config.get_settings() and setting_two in config.get_settings()

# Generated at 2022-06-20 13:42:18.767952
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    the_config = ConfigData()

    class MyPlugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    plugin = MyPlugin('color', 'red')
    assert the_config.get_setting('color', plugin) == None
    setting = {'name': 'color', 'value': 'red'}
    the_config.update_setting(setting, plugin)
    assert the_config.get_setting('color', plugin) == setting
    assert the_config.get_setting('color', None) == None
    assert the_config.get_setting('color', MyPlugin('color', 'blue')) == None
    assert the_config.get_setting('color', MyPlugin('color', 'red')) == setting

# Generated at 2022-06-20 13:42:21.999440
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('debug') is None
    assert config_data.get_setting('defaut_preferences_file') is None


# Generated at 2022-06-20 13:42:35.516314
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    plugin_type = 'type'
    plugin_name = 'name'
    plugin_path = ''
    plugin = Plugin(plugin_type, plugin_name, plugin_path)
    setting_name = 'name'
    setting_value = 'value'
    setting_comment = '#comment'
    setting_type = 'type'
    setting = Setting(setting_name, setting_value, setting_comment, setting_type)
    config.update_setting(setting, plugin)
    assert config.get_setting(setting_name, plugin) == setting
    assert config.get_settings(plugin) == [setting]
    assert config.get_setting('test', plugin) is None
    assert config.get_settings() == []


# Generated at 2022-06-20 13:42:52.345419
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    def test_get_settings(config):
        assert config.get_settings() == []
        return True

    # Test default behavior
    config = ConfigData()
    assert test_get_settings(config)

    # Test behavior when global setting exists
    from ansible_lib.plugins.inventory.yml.setting import Setting
    config.update_setting(Setting(name='host_list', value='hosts', vtype='string'))
    assert test_get_settings(config)

    # Test behavior when global setting exists and first level plugin exists
    from ansible_lib.plugins.inventory.yml.plugin import Plugin
    plugin = Plugin(type='test_type', name='test_name')
    config.update_setting(Setting(name='plugin_setting', value='plugin_setting_value', vtype='string'), plugin)
    assert test

# Generated at 2022-06-20 13:42:56.611950
# Unit test for constructor of class ConfigData
def test_ConfigData():
    try:
        config_data = ConfigData()
        assert config_data is not None
        assert config_data._global_settings == {}
        assert config_data._plugins == {}
    except Exception as err:
        print("Error: {}".format(err))
        assert False

from ansible.plugins.loader import plugin_loader



# Generated at 2022-06-20 13:43:08.007168
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting("setting1", plugin=None)
    config_data.update_setting("setting2", plugin=None)
    config_data.update_setting("setting3", plugin="plugin1")
    config_data.update_setting("setting4", plugin="plugin1")

    assert config_data._global_settings['setting1'] == "setting1"
    assert config_data._global_settings['setting2'] == "setting2"
    assert config_data._plugins['plugin1']['plugin1']['setting3'] == "setting3"
    assert config_data._plugins['plugin1']['plugin1']['setting4'] == "setting4"
