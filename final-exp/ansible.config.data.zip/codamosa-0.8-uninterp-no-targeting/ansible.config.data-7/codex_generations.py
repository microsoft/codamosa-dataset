

# Generated at 2022-06-20 13:33:18.763117
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configdata = ConfigData()
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.connection import ConnectionBase
    plugin = PluginLoader._find_plugin('connection', "local")
    plugin_obj = plugin()
    setting_name = "name1"
    setting_value = "val1"
    
    configdata.update_setting(ConfigSetting(setting_name, setting_value), plugin_obj)
    assert(configdata.get_setting(setting_name, plugin_obj)==ConfigSetting(setting_name, setting_value))



# Generated at 2022-06-20 13:33:20.255704
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    print(config)


# Generated at 2022-06-20 13:33:23.230972
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting("name", "value")
    assert "value" == config_data.get_setting("name")


# Generated at 2022-06-20 13:33:29.720224
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import PluginLoader
    import ansible.constants as C
    import os

    plugin_loader = PluginLoader(
        'ActionModule',
        'ansible.plugins.action',
        C.DEFAULT_INVENTORY_ACTION_PLUGIN_PATH,
        'action_plugins'
    )
    action_plugins = list(plugin_loader.all())
    plugin_loader = PluginLoader(
        'Connection',
        'ansible.plugins.connection',
        os.path.join(os.path.dirname(__file__), '..', '..', '..', 'connection_plugins'),
        'connection_plugins'
    )
    connection_plugins = list(plugin_loader.all())

# Generated at 2022-06-20 13:33:32.223556
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:33:42.939355
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansiblelint import Runner, RulesCollection
    from ansiblelint.rules import AnsibleLintRule
    from ansiblelint.runners import RunnerConfig
    from ansiblelint.runner_config import RunnerContext
    from ansiblelint.runner_config import Setting

    class TestRule(AnsibleLintRule):
        id = 'ANSIBLE0004'
        shortdesc = 'Test rule'
        description = 'Test rule'
        tags = {'test'}

        def match(self, file, text):
            return []

    class TestRule2(AnsibleLintRule):
        id = 'ANSIBLE0005'
        shortdesc = 'Test rule'
        description = 'Test rule'
        tags = {'test'}

        def match(self, file, text):
            return []


# Generated at 2022-06-20 13:33:52.755349
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()
    data.update_setting(Setting(name='setting1'))
    data.update_setting(Setting(name='setting2'))

    assert data.get_setting('setting1') == Setting(name='setting1')
    assert data.get_setting('setting2') == Setting(name='setting2')
    assert data.get_setting(None) == None
    assert data.get_setting('') == None
    assert data.get_setting('NonExistantSetting') == None


# Generated at 2022-06-20 13:34:03.869910
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblelint.rules import AnsibleLintRule
    from ansiblelint.rules.UseShellInsteadOfCommandRule import UseShellInsteadOfCommandRule

    rule = UseShellInsteadOfCommandRule()
    global_setting = AnsibleLintRule(id='TEST_RULE', shortdesc='Global test rule')
    global_setting.tags = ['GLOBAL']
    plugin_setting = AnsibleLintRule(id='TEST_RULE', shortdesc='Plugin test rule')
    plugin_setting.tags = ['PLUGIN']

    config = ConfigData()

    assert config.get_setting('TEST_RULE', rule) is None

    config.update_setting(global_setting)

    assert config.get_setting('TEST_RULE', rule) == global_setting


# Generated at 2022-06-20 13:34:06.385744
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # With empty config_data
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-20 13:34:07.678749
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    pass


# Generated at 2022-06-20 13:34:11.213081
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()


# Generated at 2022-06-20 13:34:16.912333
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    config_data.update_setting(Setting("foo", "bar", "default"))
    config_data.update_setting(Setting("ansible", "tests", "plugin"))

    assert len(config_data.get_settings()) == 1

    assert len(config_data.get_settings(Plugin("collection", "ansible.tests"))) == 1

    assert len(config_data.get_settings(Plugin("module", "test"))) == 0



# Generated at 2022-06-20 13:34:26.951540
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # get_setting: no plugin
    config_data.update_setting(ConfigSetting('global_setting', 'global_setting_value'))

    assert config_data.get_setting('global_setting').name == 'global_setting'
    assert config_data.get_setting('global_setting').value == 'global_setting_value'

    # get_setting: plugin
    config_data.update_setting(ConfigSetting('custom_setting', 'custom_setting_value'), ConfigPlugin('module', 'mymodule'))

    assert config_data.get_setting('custom_setting', ConfigPlugin('module', 'mymodule')).name == 'custom_setting'
    assert config_data.get_setting('custom_setting', ConfigPlugin('module', 'mymodule')).value == 'custom_setting_value'

#

# Generated at 2022-06-20 13:34:31.210613
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = 'setting'
    setting = config_data.get_setting(setting)
    assert setting is None


# Generated at 2022-06-20 13:34:36.110918
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(setting=Setting(name='setting1', value='value1'), plugin=None)
    assert config_data.get_setting(name='setting1', plugin=None) == Setting(name='setting1', value='value1')


# Generated at 2022-06-20 13:34:42.446696
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()

    # Get a setting which doesn't exist
    s = cd.get_setting('my_setting', None)
    assert s is None

    # Get a setting which exists
    s = Setting('my_setting', 'my_value')
    cd.update_setting(s)
    s = cd.get_setting('my_setting')
    assert isinstance(s, Setting)
    assert s.name == 'my_setting'
    assert s.value == 'my_value'


# Generated at 2022-06-20 13:34:49.410771
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    MOCK_SETTING = Mock()
    MOCK_PLUGIN = Mock()
    cd = ConfigData()
    assert cd.get_setting(MOCK_SETTING, MOCK_PLUGIN) is None



# Generated at 2022-06-20 13:35:01.400135
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.plugin_docs import read_docstring

    config_data = ConfigData()

    # global setting
    global_setting = read_docstring('''
    ---
    options:
      foo:
        description: a foo option
        required: True
        type: str
        version_added: 2.3
    ''')
    config_data.update_setting(global_setting)

    foo_setting = config_data.get_setting('foo')
    assert foo_setting.name == 'foo'
    assert foo_setting.required is True
    assert foo_setting.type == 'str'
    assert foo_setting.aliases == []
    assert foo_setting.choices == []
    assert foo_setting.default

# Generated at 2022-06-20 13:35:07.082408
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansiblelint.utils import Plugin, PluginType

    config_data = ConfigData()

    # Create a global setting
    global_setting = {
        "name": "excluded_paths",
        "section": "ANSIBLE0003",
        "options": {
            "data": {
                "keyvalue": [
                    {
                        "key": "paths",
                        "value": ["/tmp"]
                    }
                ]
            },
            "scope": "GLOBAL",
            "plugin": "ANSIBLE0003"
        }
    }
    # Create a setting

# Generated at 2022-06-20 13:35:13.109779
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    data.update_setting(Setting('test', 'global'))
    data.update_setting(Setting('test', 'plugin', 'plugin1'))
    assert data.get_settings() == [Setting('test', 'global')]
    assert data.get_settings(Plugin('mytype', 'myname')) == []
    assert data.get_settings(Plugin('plugin', 'plugin1')) == [Setting('test', 'plugin', 'plugin1')]



# Generated at 2022-06-20 13:35:21.964689
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert cd.get_setting('ansible_managed') is None
    s = Setting('ansible_managed', 'This file and its contents were created by ansible-config')
    cd.update_setting(s)
    assert cd.get_setting('ansible_managed') is None
    p = Plugin('action', 'test')
    cd.update_setting(s, p)
    assert cd.get_setting('ansible_managed') is None
    assert cd.get_setting('ansible_managed', p) is s


# Generated at 2022-06-20 13:35:23.874577
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()
    assert configData


# Generated at 2022-06-20 13:35:25.887083
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-20 13:35:27.121014
# Unit test for constructor of class ConfigData
def test_ConfigData():
    ConfigData()


# Generated at 2022-06-20 13:35:28.647400
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert(config_data)


# Generated at 2022-06-20 13:35:29.276726
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData()

# Generated at 2022-06-20 13:35:37.322440
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin1 = MockPlugin("module")
    plugin2 = MockPlugin("module")
    plugin3 = MockPlugin("module", "foo")
    plugin4 = MockPlugin("inventory")
    plugin5 = MockPlugin("lookup")
    plugin6 = MockPlugin("connection")
    setting1 = MockSetting("test1", "test1")
    setting2 = MockSetting("test2", "test2")
    setting3 = MockSetting("test1", "test3")

    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin1)
    config_data.update_setting(setting3, plugin2)
    config_data.update_setting(MockSetting("test1", "test4"), plugin3)

# Generated at 2022-06-20 13:35:47.398885
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    import os
    from ansible.module_utils.config_loader import ConfigLoader
    from ansible.plugins.loader import PluginLoader

    ansible_cfg = os.environ.get('ANSIBLE_CONFIG', '/Users/mohith/ansible/ansible.cfg')
    config_loader = ConfigLoader(filename=ansible_cfg)
    config_data.update_setting(config_loader.get_setting("core", "string_conversion_action"))
    config_data.update_setting(config_loader.get_setting("core", "vault_password_file"))

    plugins=PluginLoader()
    plugin_names = plugins.get_plugin_names("lookup")


# Generated at 2022-06-20 13:35:53.112562
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_instance = ConfigData()
    test_instance._plugins = {'connection': {'winrm': {'ansible_winrm_server_cert_validation': 'ignore'}}}
    test_instance.update_setting(ansible.plugins.connection.winrm.AnsibleWinRMHookConnection().get_option('ansible_winrm_server_cert_validation'), ansible.plugins.connection.winrm.Connection('winrm'))



# Generated at 2022-06-20 13:35:57.183273
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()
    assert len(config._global_settings) == 0
    assert len(config._plugins) == 0


# Generated at 2022-06-20 13:36:08.589609
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()
    assert data.get_setting('ANSIBLE_LOG_PATH') is None
    from types import SimpleNamespace
    from ansible.module_utils._text import to_bytes
    plugin = SimpleNamespace(type='defaults', name='ansible')
    data.update_setting(SimpleNamespace(name='ANSIBLE_LOG_PATH',
                                        value=to_bytes(u'/tmp'),
                                        origin=None), plugin)
    assert data.get_setting('ANSIBLE_LOG_PATH', plugin) is not None

# Generated at 2022-06-20 13:36:10.505048
# Unit test for constructor of class ConfigData
def test_ConfigData():


    config = ConfigData()
    assert config

    # Ensure that ConfigData can be initialized


# Generated at 2022-06-20 13:36:15.241297
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()

    setting = 'setting'
    plugin = 'plugin'

    cd.update_setting(setting, plugin)

    assert setting in cd._plugins[plugin.type][plugin.name]

# Generated at 2022-06-20 13:36:25.666099
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    import ansible.config.setting_loader

    Setting_0 = ansible.config.setting_loader.Setting
    setting_0 = Setting_0('setting_name_0', 'setting_description_0', [])
    config_data.update_setting(setting_0)

    Setting_1 = ansible.config.setting_loader.Setting
    setting_1 = Setting_1('setting_name_1', 'setting_description_1', [])
    config_data.update_setting(setting_1)

    Setting_2 = ansible.config.setting_loader.Setting
    setting_2 = Setting_2('setting_name_2', 'setting_description_2', [])
    config_data.update_setting(setting_2)


# Generated at 2022-06-20 13:36:29.500942
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

# Generated at 2022-06-20 13:36:33.455012
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    # verify that the global settings dictionary is empty
    assert {} == config_data._global_settings

    # verify that the plugins dictionary is empty
    assert {} == config_data._plugins

# Generated at 2022-06-20 13:36:43.071283
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

  class Plugin(object):

    def __init__(self, name, type):
      self.name = name
      self.type = type

  class Setting(object):

    def __init__(self, name, value):
      self.name = name
      self.value = value

  conf_data = ConfigData()
  assert conf_data.get_setting('ansible_ssh_common_args') is None

  ansible_ssh_common_args = Setting('ansible_ssh_common_args', '-F /path/to/ssh_config')
  conf_data.update_setting(ansible_ssh_common_args)
  assert conf_data.get_setting('ansible_ssh_common_args') == ansible_ssh_common_args


# Generated at 2022-06-20 13:36:47.641201
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-20 13:36:59.752097
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from collections import namedtuple

    Plugin = namedtuple('Plugin', ['type', 'name'])
    plugin_1 = Plugin('action', 'test_action')
    plugin_2 = Plugin('cache', 'test_cache')

    from ansible.config.setting import Setting

    config_data = ConfigData()
    config_data.update_setting(Setting('plugin_1', 'test_plugin_1'))
    config_data.update_setting(Setting('plugin_1', 'test_plugin_1_1', plugin_1))
    config_data.update_setting(Setting('plugin_2', 'test_plugin_2', plugin_1))
    config_data.update_setting(Setting('plugin_2', 'test_plugin_2_1', plugin_2))


# Generated at 2022-06-20 13:37:03.038310
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    cd.update_setting(Setting('config_version', '2.0.0'))
    assert cd.get_setting('config_version').value() == '2.0.0'


# Generated at 2022-06-20 13:37:20.725401
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    t = {}

    configdata = ConfigData()
    i1 = Setting(name='option1', value='value1', origin='O1', plugin='type1.name1')
    configdata.update_setting(i1)
    t[i1.name] = i1
    i2 = Setting(name='option2', value='value2', origin='O2', plugin='type1.name1')
    configdata.update_setting(i2)
    t[i2.name] = i2
    i3 = Setting(name='option3', value='value3', origin='O3', plugin='type1.name1')
    configdata.update_setting(i3)
    t[i3.name] = i3

# Generated at 2022-06-20 13:37:31.013540
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    file_setting = FileSetting('/etc/hosts')
    file_setting.update_provider(ProviderSetting('lineinfile', 'plugin', 'foo'))
    config.update_setting(file_setting)
    assert config.get_setting('/etc/hosts') == file_setting
    assert config.get_setting('/etc/passwd') is None
    assert config.get_setting('/etc/hosts', Plugin('lineinfile', 'plugin', 'foo')) == file_setting
    assert config.get_setting('/etc/hosts', Plugin('replace', 'plugin', 'bar')) is None
    assert config.get_setting('/etc/passwd', Plugin('lineinfile', 'plugin', 'foo')) is None

# Generated at 2022-06-20 13:37:32.789259
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-20 13:37:44.509863
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Initialize ConfigData object
    config_data = ConfigData()
    # Initialize Plugin object
    plugin = Plugin()
    plugin.type = "lookup"
    plugin.name = "foo"
    # Initialize Setting object
    setting = Setting()
    setting.name = "bar1"
    # Update setting object to config_data
    config_data.update_setting(setting, plugin)
    # Run get_setting method with setting name and plugin object
    test_setting = config_data.get_setting("bar1", plugin)
    assert test_setting == setting
    assert isinstance(test_setting, Setting)


# Generated at 2022-06-20 13:37:45.923287
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("foo") is None

# Generated at 2022-06-20 13:37:55.175485
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings['a'] = 'a'
    config_data._global_settings['b'] = 'b'
    config_data._plugins['type1'] = {'name1': {'c': 'c', 'd': 'd'}}
    config_data._plugins['type2'] = {'name2': {'e': 'e', 'f': 'f'}}
    config_data._plugins['type3'] = {'name3': {'g': 'g', 'h': 'h'}}

    assert config_data.get_settings() == [config_data._global_settings['a'], config_data._global_settings['b']]

# Generated at 2022-06-20 13:37:57.236280
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-20 13:38:01.766811
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    data = ConfigData()

    # Test settings in global config
    setting = Setting()
    setting.name = 'setup_hostname'
    setting.value = True
    setting.plugin = None
    data.update_setting(setting)

    assert data.get_setting('setup_hostname') == setting



# Generated at 2022-06-20 13:38:03.976338
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:38:05.604603
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()

    def test_instance_of_ConfigData():
        assert isinstance(config_data, ConfigData)

# Generated at 2022-06-20 13:38:18.726920
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    '''
    Test for method get_setting
    '''
    test_ConfigData = ConfigData()
    
    assert test_ConfigData.get_setting() is None
    assert test_ConfigData.get_setting(plugin=None) is None


# Generated at 2022-06-20 13:38:19.677289
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData is not None


# Generated at 2022-06-20 13:38:21.615466
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    c.update_setting("setting")
    assert c._global_settings["setting"] is not None

# Generated at 2022-06-20 13:38:28.264094
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vars import combine_vars

    from ansible.plugins.loader import find_plugin
    from ansible.utils.plugin_docs import get_docstring
    from ansible.utils.display import Display

    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.config_data import ConfigData

    import ansible_collections.notstdlib.moveitallout.plugins.module_utils.config_data_test_lib as config_data_test_lib

    config_data = ConfigData()
    display

# Generated at 2022-06-20 13:38:33.115334
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    plugin = PluginDefinition('test-plugin', 'test-plugin-type')

    config.update_setting(ConfigSetting('test-setting-1', 'test-setting-value-1', plugin))
    config.update_setting(ConfigSetting('test-setting-2', 'test-setting-value-2', plugin))

    settings = config.get_settings(plugin)

    assert isinstance(settings, list)
    assert len(settings) == 2
    assert settings[0].name == 'test-setting-1'
    assert settings[0].plugin == plugin
    assert settings[0].value == 'test-setting-value-1'

    assert settings[1].name == 'test-setting-2'
    assert settings[1].plugin == plugin
    assert settings[1].value == 'test-setting-value-2'

# Generated at 2022-06-20 13:38:39.205088
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test for function to get setting for global setting
    config_data = ConfigData()
    plugin = Plugin('test_type', 'test_name')
    setting = ConfigSetting('test_setting1', 'test_setting1_value', 'test_setting1_description', plugin)
    config_data.update_setting(setting, plugin)
    assert setting == config_data.get_setting('test_setting1', plugin)


# Generated at 2022-06-20 13:38:40.017428
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    pass

if __name__ == "__main__":
    test_ConfigData_get_settings()

# Generated at 2022-06-20 13:38:48.580380
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configdata = ConfigData()
    setting = Setting('ANSIBLE_ROLES_PATH', '/home/ansible/roles', "path to look for roles in")
    configdata.update_setting(setting)
    assert configdata.get_setting(name='ANSIBLE_ROLES_PATH') == setting


# Generated at 2022-06-20 13:38:58.216129
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()

    config.update_setting(ConfigSetting("foo", "bar"))     # Should store as global setting
    config.update_setting(ConfigSetting("spam", "ham"))
    assert len(config.get_settings()) == 2

    config.update_setting(ConfigSetting("foo", "baz"), ConfigPlugin("foo", "foo", {}))  # Should overwrite global setting
    config.update_setting(ConfigSetting("spam", "eggs"), ConfigPlugin("foo", "foo", {}))
    assert len(config.get_settings(ConfigPlugin("foo", "foo", {}))) == 2

    assert config.get_setting("foo", ConfigPlugin("foo", "foo", {})).value == "baz"
    assert config.get_setting("spam", ConfigPlugin("foo", "foo", {})).value == "eggs"


# Generated at 2022-06-20 13:39:11.501171
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()

    # Test get_setting with no settings
    setting = config.get_setting('foo')
    assert setting is None

    # Test get_setting with global setting
    setting = ConfigSetting('foo', 'global', 'global')
    config.update_setting(setting)
    setting = config.get_setting('foo')
    assert setting is not None and setting.name == 'foo'

    # Test get_setting with plugin setting
    plugin = Plugin('type', 'name')
    setting = ConfigSetting('foo', 'type', 'name')
    config.update_setting(setting, plugin)
    setting = config.get_setting('foo', plugin)
    assert setting is not None and setting.name == 'foo'

    # Test get_setting with different plugin setting
    plugin = Plugin('type2', 'name2')
   

# Generated at 2022-06-20 13:39:31.936031
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Create a config data instance
    config_data = ConfigData()

    # Assert that get_settings returns a empty list
    assert config_data.get_settings() == []

    # Add settings
    config_data.update_setting(Setting(name='core', value='/etc/ansible/ansible.cfg'))
    config_data.update_setting(Setting(name='config', plugin=Plugin(type='core'), value='/etc/ansible/ansible.cfg'))
    config_data.update_setting(Setting(name='config', plugin=Plugin(type='module', name='script'), value='/etc/ansible/ansible.cfg'))

# Generated at 2022-06-20 13:39:43.466318
# Unit test for constructor of class ConfigData
def test_ConfigData():

    from ansiblelint import RulesCollection
    from ansiblelint import Runner

    test_collection = RulesCollection.create_from_directory('test/rules')
    test_runner = Runner(test_collection)
    config_data = test_runner.config_data

    assert len(config_data._global_settings) == 4
    assert len(config_data._plugins) == 1
    assert len(config_data._plugins['role']) == 1
    assert len(config_data._plugins['role']['role_1']) == 2


# Generated at 2022-06-20 13:39:54.267852
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class Setting(object):

        def __init__(self, name, value):
            self.name = name
            self.value = value

    class Plugin(object):

        def __init__(self, type, name):
            self.type = type
            self.name = name

    data = ConfigData()
    data.update_setting(Setting('global1', 1))
    data.update_setting(Setting('global2', 2))
    data.update_setting(Setting('plugin1', 11), Plugin('type1', 'plugin1'))
    data.update_setting(Setting('plugin2', 12), Plugin('type2', 'plugin2'))
    data.update_setting(Setting('plugin3', 13), Plugin('type3', 'plugin3'))

# Generated at 2022-06-20 13:40:05.014367
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    assert_equals(config_data.get_settings(), [],
                  "config_data.get_settings() returns empty list if no settings are set")

    plugin = Plugin("core", "test")
    setting = Setting("test_setting", "test_value")
    config_data.update_setting(setting, plugin)

    assert_equals(config_data.get_settings(), [setting],
                  "config_data.get_settings() returns a list containing one setting if only one setting is set")
    assert_equals(config_data.get_settings(plugin), [setting],
                  "config_data.get_settings() returns a list containing one setting when plugin was passed")

# Generated at 2022-06-20 13:40:15.664265
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin_1 = Plugin(type='connection', name='local')
    plugin_2 = Plugin(type='connection', name='paramiko')
    plugin_3 = Plugin(type='module', name='template')
    plugin_4 = Plugin(type='module', name='debug')
    setting_local_remote_port = Setting(name='remote_port')
    setting_paramiko_remote_port = Setting(name='remote_port')
    setting_template_path = Setting(name='path')
    setting_debug_msg = Setting(name='msg')

    config_data.update_setting(setting_local_remote_port, plugin_1)
    config_data.update_setting(setting_paramiko_remote_port, plugin_2)

# Generated at 2022-06-20 13:40:26.736101
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import os
    import stat

    def write_test_file(fname, contents):
        f = open(fname, 'w')
        f.write(contents)
        f.close()

    def test_setup():
        # Create test dirs and files
        os.makedirs("./test_data/cfg_data_test/")
        os.makedirs("./test_data/cfg_data_test/group_vars/")
        os.makedirs("./test_data/cfg_data_test/host_vars/")
        os.makedirs("./test_data/cfg_data_test/playbooks/")
        os.makedirs("./test_data/cfg_data_test/roles/rolea/")

# Generated at 2022-06-20 13:40:37.235232
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting1 = Setting('a', 'cluster')
    setting2 = Setting('b', 'cluster')
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    settings = config_data.get_settings()
    assert len(settings) == 2
    assert settings[0] == setting1
    assert settings[1] == setting2


# Generated at 2022-06-20 13:40:44.769428
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cfg = ConfigData()
    import copy
    setting_g = copy.deepcopy(GlobalSetting('become', 'False'))
    cfg.update_setting(setting_g)
    assert cfg.get_setting('become') is not None
    assert cfg.get_setting('become') == setting_g

    setting_p = copy.deepcopy(PluginSetting('use', 'basictemplate', 'False'))
    cfg.update_setting(setting_p)
    assert cfg.get_setting('use', setting_p.plugin) is not None
    assert cfg.get_setting('use', setting_p.plugin) == setting_p

    setting_g2 = copy.deepcopy(GlobalSetting('become_user', 'root'))
    cfg.update_setting(setting_g2)


# Generated at 2022-06-20 13:40:58.137581
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Create new ConfigData object
    config_data = ConfigData()
    # Instantiate objects for testing purposes
    from ansible.module_utils.six import MovedModule
    from ansible.module_utils.common._collections_compat import Mapping
    test_plugin1 = MovedModule('test_type', 'test_name', 'test_path')
    test_plugin2 = MovedModule('test_type2', 'test_name2', 'test_path2')
    # Add settings for one plugin
    setting1 = ConfigSetting('test_setting1', 'test_value1', Mapping())
    config_data.update_setting(setting1, plugin=test_plugin1)
    # Add the same setting for another plugin
    setting2 = ConfigSetting('test_setting1', 'test_value3', Mapping())
    config_

# Generated at 2022-06-20 13:40:59.644507
# Unit test for constructor of class ConfigData
def test_ConfigData():

    c = ConfigData()
    assert c._global_settings == {}
    assert c._plugins == {}



# Generated at 2022-06-20 13:41:31.371287
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd1 = ConfigData()

    setting_global = ConfigSetting(name='g', value='bla', origin='/etc/ansible/ansible.cfg')
    cd1.update_setting(setting_global)

    plugin_type = 'connection'
    plugin_name = 'local'
    plugin = ConfigPlugin(name=plugin_name, type=plugin_type)

    setting_plugin = ConfigSetting(name='p', value='bla', origin='/etc/ansible/ansible.cfg')
    cd1.update_setting(setting_plugin, plugin)

    assert cd1.get_setting('g') == setting_global
    assert cd1.get_setting('p', plugin) == setting_plugin
    assert cd1.get_setting('not_existing') is None

# Generated at 2022-06-20 13:41:39.800443
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible_collections.ansible.community.plugins.module_utils.network.common.config import NetworkConfig, NetworkConfigItem, dumps
    from ansible_collections.ansible.community.plugins.module_utils.network.common.utils import dict_diff

    g1 = NetworkConfigItem('global', 'global',
                     values={'log_path': '/var/log/logging'})
    g2 = NetworkConfigItem('global', 'global',
                     values={'log_path': '/var/log/logging2'})
    p1 = NetworkConfigItem('plugin', 'plugin',
                     values={'log_path': '/var/log/plugin'})

    cd = ConfigData()
    cd.update_setting(g1, None)
    cd.update_setting(g2, None)

# Generated at 2022-06-20 13:41:45.445830
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cd = ConfigData()

    assert cd is not None
    assert len(cd._global_settings) == 0
    assert len(cd._plugins) == 0



# Generated at 2022-06-20 13:41:47.057791
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert c is not None


# Generated at 2022-06-20 13:41:50.309580
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert len(configdata._global_settings) == 0
    assert "core" not in configdata._plugins
    assert "callback" not in configdata._plugins


# Generated at 2022-06-20 13:41:55.463156
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}


# Generated at 2022-06-20 13:42:06.089837
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    global_data = {
        'ANSIBLE_FORKS': 80,
        'ANSIBLE_HOST_KEY_CHECKING': False,
        'ANSIBLE_RETRY_FILES_ENABLED': False
    }

    plugin_data = {
        'callback': {
            'stdout': {
                'color': True,
                'display': 'stderr'
            },
            'minimal': {
                'display': 'stderr'
            }
        },
        'connection': {
            'network_cli': {
                'connection_timeout': 30,
                'persistent_connection': True,
                'persistent_log_messages': False,
                'user': 'test_user'
            }
        }
    }


# Generated at 2022-06-20 13:42:18.613134
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.config.setting import Setting
    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()

    # test for when plugin name provided
    plugin_name = 'action'
    plugin_type = 'plugin'
    plugin_loader = PluginLoader(plugin_type)
    plugin = plugin_loader[plugin_name]

    setting1 = Setting(name='setting1', versioned=True, scope='global', secret=False,
                       type='str', fallback=['default'],
                       choices=['default', 'value'])
    config_data.update_setting(setting1)
    setting2 = Setting(name='setting2', versioned=True, scope='global', secret=False,
                       type='str', fallback=['default'],
                       choices=['default', 'value'])
    config_data

# Generated at 2022-06-20 13:42:19.050781
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass

# Generated at 2022-06-20 13:42:22.041371
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configData = ConfigData()

    assert (len(configData._global_settings) == 0)
    assert ('plugins' not in configData._global_settings)


# Generated at 2022-06-20 13:42:42.192983
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings is not None


# Generated at 2022-06-20 13:42:45.857242
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    c = ConfigData()
    #s1 = Setting('TestSetting1', 'TestValue1', 'TestVersion1')
    c.update_setting(s1)
    assert c.get_setting('TestSetting1') == s1


# Generated at 2022-06-20 13:42:47.295047
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.get_settings() == []
    assert config_data.get_settings() == []

# Generated at 2022-06-20 13:42:52.769963
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = Setting('test', 'bool', False, None)
    config_data.update_setting(setting)
    settings = config_data.get_settings()
    assert len(settings) == 1
    assert settings[0].name == 'test'


# Generated at 2022-06-20 13:42:58.994629
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting1', 'test value 1'))
    config_data.update_setting(Setting('test_setting2', 'test value 2'))

    assert config_data._global_settings['test_setting1'].value == 'test value 1'
    assert config_data._global_settings['test_setting2'].value == 'test value 2'
    assert config_data.get_setting('test_setting1').value == 'test value 1'
    assert config_data.get_setting('test_setting2').value == 'test value 2'


# Generated at 2022-06-20 13:43:00.562526
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert (cd._global_settings == {})
    assert (cd._plugins == {})


# Generated at 2022-06-20 13:43:10.613945
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    # test get_settings with no setting and no plugin
    settings = config_data.get_settings()
    assert settings == [], "Error in test_ConfigData_get_settings"
    # test get_settings with one setting and no plugin
    from ansible.cli.config import Setting
    setting_1 = Setting()
    setting_1.name = "setting_1"
    setting_1.value = "value_1"
    config_data.update_setting(setting_1)
    settings = config_data.get_settings()
    assert settings == [setting_1], "Error in test_ConfigData_get_settings"
    # test get_settings with one setting and a plugin
    from ansible.cli.config import Plugin
    plugin = Plugin()
    plugin.type = "collection"
   