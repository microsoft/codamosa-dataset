

# Generated at 2022-06-20 13:33:22.829067
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    assert config_data.get_setting('ansible_connection') is None
    assert config_data.get_setting('host_key_checking', plugin='paramiko') is None
    assert config_data.get_setting('host_key_checking', plugin='ssh') is None

    from ansible.plugins.loader import config_loader
    ssh_config_manager = config_loader.get('ssh', 'paramiko')
    ssh_config_manager.update_setting('host_key_checking')
    config_data.update_setting(ssh_config_manager.get_setting('host_key_checking'), plugin='paramiko')
    assert config_data.get_setting('host_key_checking', plugin='paramiko') == ssh_config_manager.get_setting('host_key_checking')

    ssh_config

# Generated at 2022-06-20 13:33:29.530490
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.module_utils.config_data import ConfigData, Setting

    config_data = ConfigData()

    plugin_name_1 = 'ansible'
    plugin_type_1= 'collection'

    config_data.update_setting(Setting(name='ns_prefix', value='foo', origin='config_file'))
    config_data.update_setting(Setting(name='version', value='2.8', origin='config_file'))
    config_data.update_setting(Setting(name='galaxy_command', value='.', origin='config_file'))

    config_data.update_setting(Setting(name='ns_prefix', value='ansible', origin='config_file'), plugin=ConfigData.Plugin(name=plugin_name_1, type=plugin_type_1))

# Generated at 2022-06-20 13:33:35.437408
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting('setting1')
    config_data.update_setting('setting2')
    assert config_data.get_setting('setting1') is not None
    assert config_data.get_setting('setting2') is not None
    assert config_data.get_setting('setting2') == 'setting2'

# Generated at 2022-06-20 13:33:45.860965
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting(name='foo', plugin=ConfigPlugin(type='foo', name='bar')))
    config_data.update_setting(ConfigSetting(name='foo', plugin=ConfigPlugin(type='foo', name='baz')))
    config_data.update_setting(ConfigSetting(name='foo', plugin=ConfigPlugin(type='qux', name='bar')))
    config_data.update_setting(ConfigSetting(name='foo', plugin=ConfigPlugin(type='qux', name='baz')))

    settings = config_data.get_settings()
    assert len(settings) == 2 
    assert settings[0].type == 'qux' and settings[0].name == 'bar' 

# Generated at 2022-06-20 13:33:49.747236
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # Create ConfigData object
    config_data = ConfigData()

    # Verify object properties initialized to empty dicts
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:33:51.831369
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {"test1": "test"}
    plugin = Plugin(type="test_type", name="test_name")
    config_data._plugins = {"test_type": {"test_name": {"test2": "test"}}}
    assert config_data.get_settings(plugin) == [{"test2": "test"}]

# Generated at 2022-06-20 13:34:00.639792
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # Create ConfigData object
    config_data = ConfigData()

    # Create new setting
    from ansible_collections.ansible.community.plugins.module_utils.config_loader import Setting
    setting = Setting()
    setting.name = "test_setting"
    setting.default = None
    setting.type = "str"
    setting.scope = "connection"

    # Add setting to config_data
    config_data.update_setting(setting)

    # assert that get_settings returns the correct setting
    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0] == setting



# Generated at 2022-06-20 13:34:10.899282
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Test global settings
    setting1 = Setting('setting1', value='global', plugin_type=None, plugin_name=None)
    config_data.update_setting(setting1)
    assert config_data.get_setting('setting1') == setting1
    assert config_data.get_setting('setting1', plugin=Plugin(name='plugin', type='type')) == setting1
    assert config_data.get_setting('setting2') is None
    assert config_data.get_setting('setting2', plugin=Plugin(name='plugin', type='type')) is None

    # Test plugin settings
    setting2 = Setting('setting2', value='plugin', plugin_type='type', plugin_name='plugin')
    config_data.update_setting(setting2)
    assert config_data.get_

# Generated at 2022-06-20 13:34:12.740645
# Unit test for constructor of class ConfigData
def test_ConfigData():
    obj = ConfigData()

    assert len(obj._global_settings) == 0
    assert len(obj._plugins) == 0


# Generated at 2022-06-20 13:34:14.939501
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()
    plugin = None
    settings = config_data.get_settings(plugin)

    assert not settings

# Generated at 2022-06-20 13:34:22.496277
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    settings_value = []
    config_data = ConfigData()
    assert config_data.get_setting('discard_unknown_keys') is None
    assert config_data.get_setting('ansible_shell_type') is None
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-20 13:34:26.208256
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # given
    test_obj = ConfigData()

    # when
    actual = test_obj.get_setting('test_setting')

    # then
    assert actual is None



# Generated at 2022-06-20 13:34:29.513621
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    c.update_setting(Setting(name='test'))
    assert len(c.get_settings()) == 1
    assert c.get_settings()[0].name == 'test'


# Generated at 2022-06-20 13:34:33.749671
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    import ansible.module_utils.ansible_release
    from ansible.plugins.loader import PluginLoader

    cd = ConfigData()
    ansible_release = ansible.module_utils.ansible_release
    pl = PluginLoader(cd, '', '', '', '', '', '', [], [], None, None, None)
    assert pl.get_settings() == cd.get_settings()



# Generated at 2022-06-20 13:34:44.708327
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    from ansible.plugins.loader import get_all_plugin_loaders

    settings_plugins = {}

    for loader in get_all_plugin_loaders():
        plugins = loader.all()
        for plugin in plugins:
            if hasattr(plugins[plugin], 'get_settings'):
                plugin_settings = plugins[plugin].get_settings()
                settings_plugins[plugin] = plugin_settings
            else:
                settings_plugins[plugin] = []

    for p in settings_plugins:
        for s in settings_plugins[p]:
            config_data.update_setting(s, p)

    # Test if it returns all global settings
    all_global_settings = config_data.get_settings()
    assert len(all_global_settings) != 0

    # Test if it returns the

# Generated at 2022-06-20 13:34:48.269906
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("test") is None


# Generated at 2022-06-20 13:34:55.023869
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    p = Plugin('type', 'name')
    s = Setting('s1')
    p.settings.append(s)
    cd = ConfigData()
    cd.update_setting(s, p)
    assert len(cd.get_settings(p)) == 1
    assert cd.get_settings(p)[0].name == 's1'
    assert len(cd.get_settings()) == 0

# Generated at 2022-06-20 13:35:04.456411
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    plugin_a    = ConfigPlugin("Module", "lookup_a")
    plugin_b    = ConfigPlugin("Module", "lookup_b")
    setting_a   = ConfigSetting("fact_base_path", "/home/")
    setting_b   = ConfigSetting("fact_base_path", "/var/")
    plugin_c    = ConfigPlugin("Module", "lookup_c")
    setting_c   = ConfigSetting("fact_base_path", "/root/")
    plugin_d    = ConfigPlugin("Module", "lookup_d")
    setting_d   = ConfigSetting("fact_base_path", "/usr/share/")

    config_data.update_setting(setting_a, plugin=plugin_a)

# Generated at 2022-06-20 13:35:13.167817
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()

    assert c.get_setting('foo') is None
    assert c.get_setting('bar', 'plugin') is None

    c.update_setting(Setting('foo', 'bar'))
    c.update_setting(Setting('bar', 'foo'), 'plugin')
    assert c.get_setting('foo') == 'foo'
    assert c.get_setting('bar', 'plugin') == 'bar'

    c.update_setting(Setting('foo', 'baz'))
    c.update_setting(Setting('bar', 'baz'), 'plugin')
    assert c.get_setting('foo') == 'baz'
    assert c.get_setting('bar', 'plugin') == 'baz'

# Generated at 2022-06-20 13:35:20.568448
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert config_data.get_settings() == []

    plugin = Plugin(type='action', name='assert')
    setting1 = Setting(name='foo', value='bar')
    setting2 = Setting(name='baz', value='qux')

    config_data.update_setting(setting1, plugin=plugin)
    config_data.update_setting(setting2, plugin=plugin)

    settings = config_data.get_settings(plugin=plugin)
    assert len(settings) == 2

    for setting in settings:

        if setting.name == 'foo':
            assert setting.value == 'bar'
        elif setting.name == 'baz':
            assert setting.value == 'qux'


# Generated at 2022-06-20 13:35:26.467244
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    c.update_setting(ConfigSetting('option1', 'value for option1', 'TEST'))
    c.update_setting(ConfigSetting('option2', 'value for option2', 'TEST'))
    assert len(c.get_settings()) == 2


# Generated at 2022-06-20 13:35:36.027029
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()

    assert config_data.get_settings() == []
    assert config_data.get_settings(Plugin({'type': 'foo', 'name': 'bar'})) == []
    assert config_data.get_setting("setting") is None
    assert config_data.get_setting("setting", Plugin({'type': 'foo', 'name': 'bar'})) is None

    config_data.update_setting(Setting("setting", "value"))

    assert config_data.get_settings() == [Setting("setting", "value")]
    assert len(config_data.get_settings(Plugin({'type': 'foo', 'name': 'bar'}))) == 0
    assert config_data.get_setting("setting").value == 'value'

# Generated at 2022-06-20 13:35:47.143830
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting("command", "command", "hostname"))
    config_data.update_setting(Setting("command", "command", "hostname"))
    config_data.update_setting(Setting("command1", "command1", "hostname1"))
    config_data.update_setting(Setting("command2", "command2", "hostname2"))
    config_data.update_setting(Setting("command3", "command3", "hostname3"))
    settings = config_data.get_settings()
    assert len(settings) == 2



# Generated at 2022-06-20 13:35:49.346414
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert not isinstance(data, ConfigData)

    data = ConfigData()
    assert isinstance(data, ConfigData)

# Generated at 2022-06-20 13:35:51.379865
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.update_setting(Setting('test', None)) == None


# Generated at 2022-06-20 13:35:55.821632
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.plugins.loader import action_loader, connection_loader, filter_loader, module_utils_loader, module_loader, test_loader, lookup_loader, callback_loader

    config_data = ConfigData()
    config_data.update_setting(action_loader.get('test'), plugin=action_loader.get('test'))
 
    return config_data

# Generated at 2022-06-20 13:35:59.118415
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    get_settings = config_data.get_settings()
    assert isinstance(get_settings, list)


# Generated at 2022-06-20 13:36:01.656320
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert (data._global_settings == {})
    assert (data._plugins == {})

# Generated at 2022-06-20 13:36:10.613144
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global_setting_1 = Setting(name='local_tmp', value='$HOME/.ansible/tmp')
    global_setting_2 = Setting(name='availablity_zone', value='us-east-1b')
    aws_setting_1 = Setting(name='access_key', value='ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    aws_setting_2 = Setting(name='secret_key', value='0123456789')
    aws_plugin = Plugin('aws', 'ec2')

    config_data = ConfigData()
    config_data.update_setting(global_setting_1)
    config_data.update_setting(global_setting_2)
    config_data.update_setting(aws_setting_1, aws_plugin)
    config_data.update_setting

# Generated at 2022-06-20 13:36:22.282304
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from .setting import Setting

    config_data = ConfigData()

    setting_1 = Setting('setting_1', 'value_setting_1')
    config_data.update_setting(setting_1)

    setting_2 = Setting('setting_2', 'value_setting_2')
    plugin = Plugin('plugin_1', 'sample')
    config_data.update_setting(setting_2, plugin)

    setting_3 = Setting('setting_3', 'value_setting_3')
    plugin = Plugin('plugin_2', 'sample')
    config_data.update_setting(setting_3, plugin)

    assert config_data._global_settings['setting_1'].name == 'setting_1'



# Generated at 2022-06-20 13:36:26.514841
# Unit test for constructor of class ConfigData
def test_ConfigData():

    cfg = ConfigData()

    assert cfg._global_settings == {}
    assert cfg._plugins == {}


# Generated at 2022-06-20 13:36:27.642415
# Unit test for constructor of class ConfigData
def test_ConfigData():
    pass

# Generated at 2022-06-20 13:36:33.687052
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_date = ConfigData()
    config_date.update_setting(Setting('connection', 'local'))
    config_date.update_setting(Setting('retries', '3'))
    config_date.update_setting(Setting('forks', '5'))
    config_date.update_setting(Setting('host_key_checking', 'yes'))

    assert len(config_date._global_settings) == 4

    assert config_date.get_setting('connection') == Setting('connection', 'local')
    assert config_date.get_setting('retries') == Setting('retries', '3')
    assert config_date.get_setting('forks') == Setting('forks', '5')
    assert config_date.get_setting('host_key_checking') == Setting('host_key_checking', 'yes')

   

# Generated at 2022-06-20 13:36:37.494791
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:36:45.442561
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test_data = ConfigData()
    setting1 = Setting("my_setting_1", "my_value_1", "my_type_1", "my_path_1", "my_owner_1", "my_group_1", "my_modified_1", "my_plugin_name_1", "my_plugin_type_1")
    test_data.update_setting(setting1, setting1.plugin)
    setting2 = test_data.get_setting("my_setting_1", setting1.plugin)
    assert setting1.name == setting2.name
    assert setting1.value == setting2.value
    assert setting1.type == setting2.type
    assert setting1.owner == setting2.owner
    assert setting1.group == setting2.group
    assert setting1.created_at == setting2.created_at

# Generated at 2022-06-20 13:36:48.357743
# Unit test for constructor of class ConfigData
def test_ConfigData():
    
    plugin_group = "ConfigData"
    plugin_name = "ConfigData"
    assert ConfigData.__init__(ConfigData()) is not None
    ConfigData.__init__(ConfigData())
    

# Generated at 2022-06-20 13:37:00.400424
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting_1 = Setting('TestSetting1', 'test_value')
    setting_2 = Setting('TestSetting2', 'test_value')
    setting_3 = Setting('TestSetting3', 'test_value')
    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2, Plugin('test', 'test', PluginType.CACHE))
    config_data.update_setting(setting_3, Plugin('test', 'test', PluginType.CACHE))

    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings(Plugin('test', 'test', PluginType.CACHE))) == 2
    assert setting_1 in config_data.get_settings()

# Generated at 2022-06-20 13:37:05.002058
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config.__class__ == ConfigData


# Generated at 2022-06-20 13:37:13.405642
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    assert config_data.get_setting(None) == None

    # Setup a global setting
    setting_scope = config_data.get_setting('ANSIBLE_CONFIG_MODULE_SETTINGS')
    assert setting_scope == None
    setting_scope = Setting('ANSIBLE_CONFIG_MODULE_SETTINGS', 'constant', '', '', '', '', '', 'cli')
    config_data.update_setting(setting_scope)

    # Get all settings of config_data
    settings = config_data.get_settings()
    assert len(settings) == 1

    # Get all settings of config_data
    settings = config_data.get_settings()
    assert len(settings) == 1

    # Get the setting ANSIBLE_CONFIG_MODULE_SETTINGS from

# Generated at 2022-06-20 13:37:19.351362
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    name = "foo"
    value = "bar"   
    # Creating a setting to test the method update_setting
    setting = Setting(name, value, Constant(value), ["all"], "test")
    config.update_setting(setting)

    assert config._global_settings[name] == setting
    assert config._global_settings[name].values == [Constant(value)]
    assert config._global_settings[name].original_value == "bar"
    assert config._global_settings[name].name == name
    assert config._global_settings[name].source == "test"
    assert config._global_settings[name].type == "string"
    assert config._global_settings[name].category == "all"
    assert config._global_settings[name].subcategory == None



# Generated at 2022-06-20 13:37:23.458149
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data


# Generated at 2022-06-20 13:37:31.922502
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    def __get_setting(name, value):
        s = Setting()
        s.name = name
        s.value = value
        return s

    plugin_type = 'test'
    plugin_name = 'test_plugin'
    plugin_namespace = 'test_namespace'
    config_data = ConfigData()

    setting1 = __get_setting('setting1', 'value1')
    config_data.update_setting(setting1)

    setting2 = __get_setting('setting2', 'value2')
    config_data.update_setting(setting2)

    plugin1 = Plugin()
    plugin1.type = plugin_type
    plugin1.name = 'plugin1'
    plugin1.namespace = plugin_namespace
    setting3 = __get_setting('setting3', 'value3')
    config_data

# Generated at 2022-06-20 13:37:40.544482
# Unit test for constructor of class ConfigData
def test_ConfigData():
    # test object constructer
    assert hasattr(ConfigData, '__init__')
    o = ConfigData()
    assert isinstance(o, ConfigData)
    assert o._global_settings == {}
    assert o._plugins == {}
    assert o.get_setting('test') is None
    assert o.get_settings() == []

# Generated at 2022-06-20 13:37:46.517443
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(Setting('a', 'b'))
    assert config.get_setting('a') is not None
    assert config.get_setting('a', Plugin('123', 'c')) is None


# Generated at 2022-06-20 13:37:55.325256
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config = ConfigData()

    class Plugin:

        def __init__(self, type, name):
            self.type = type
            self.name = name

    global_setting = {
        'name': 'callback_whitelist',
        'value': ['profile_tasks', 'timer'],
        'section': '',
        'plugin': None
    }
    config.update_setting(global_setting)

    plugin_type = 'CLI'
    plugin_name = 'console'
    plugin = Plugin(plugin_type, plugin_name)
    plugin_setting = {
        'name': 'stdout_callback',
        'value': 'default',
        'section': '',
        'plugin': plugin
    }
    config.update_setting(plugin_setting)


# Generated at 2022-06-20 13:38:04.798440
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    print("Testing ConfigData.update_setting()")

    config_data = ConfigData()

    setting1 = ConfigSetting("test", "Test value 1")
    config_data.update_setting(setting1)
    setting2 = ConfigSetting("test", "Test value 2", plugin=ConfigPlugin("test", "test"))
    config_data.update_setting(setting2)

    assert config_data.get_setting("test").value == "Test value 1"
    assert config_data.get_setting("test", plugin=ConfigPlugin("test", "test")).value == "Test value 2"

    print("ConfigData.update_setting() is working without errors")


# Generated at 2022-06-20 13:38:12.046965
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    zz = ConfigData()
    zz.update_setting(Setting('enable', 'test'))
    assert zz.get_setting('enable') == 'test'

    zz.update_setting(Setting('enable', 'test').identify('zzz', 'zzz'))
    assert zz.get_setting('enable') == 'test'
    assert zz.get_setting('enable', Plugin('zzz', 'zzz')).value == 'test'


# Generated at 2022-06-20 13:38:13.112864
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert cd

# Generated at 2022-06-20 13:38:20.330089
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
  cfg=ConfigData()
  assert cfg._global_settings == {}
  assert cfg._plugins == {}

  cfg.update_setting("setting", "plugin")
  assert cfg._global_settings == {}
  assert cfg._plugins == {}

  cfg.update_setting("setting", None)
  assert cfg._global_settings == {"setting": "setting"}
  assert cfg._plugins == {}

# Generated at 2022-06-20 13:38:21.526607
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert 1

# Generated at 2022-06-20 13:38:39.151948
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()
    assert config_data.get_settings() == []
    assert config_data.get_settings() == []

    text_setting = {'name': 'text', 'type': 'str', 'value': ''}
    config_data.update_setting(text_setting)
    assert config_data.get_settings() == [text_setting]
    assert config_data.get_settings() == [text_setting]

    text_setting_update = {'name': 'text', 'type': 'str', 'value': 'Hello'}
    config_data.update_setting(text_setting_update)
    assert config_data.get_settings() == [text_setting_update]
    assert config_data.get_settings() == [text_setting_update]


# Generated at 2022-06-20 13:38:47.809019
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(ConfigSetting('a', 'b', 'c', 'd', 'e', 'f'))
    config.update_setting(ConfigSetting('a', 'b', 'c', 'd', 'e', 'f', 'g'))
    config.update_setting(ConfigSetting('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'))
    config.update_setting(ConfigSetting('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'))

    # Test with just 1 parameter
    assert config.get_setting('a') == config._global_settings['a']

    # Test with all parameters
    assert config.get_setting('a', ConfigPlugin('b', 'c')) == config._plugins

# Generated at 2022-06-20 13:38:58.186963
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import os
    import yaml
    from collections import namedtuple

    from ansible_test.units.test_data.config_data.test_config_data_update_setting_test_data import (
        config_data_update_setting_global_setting_test_data,
    )

    class ConfigDataTest(ConfigData):
        pass

    Plugin = namedtuple('Plugin', 'type name')

    config_data_test = ConfigDataTest()

    for test_data in config_data_update_setting_global_setting_test_data:
        setting = test_data['setting']
        setting['plugin'] = Plugin(type=setting['plugin']['type'], name=setting['plugin']['name'])

        config_data_test.update_setting(setting=setting['setting'], plugin=setting['plugin'])

# Generated at 2022-06-20 13:39:11.500245
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    global_setting = Setting('name1', 'description1', 'value1')

    plugin1 = Plugin('type1', 'name1', 'description1')
    setting = Setting('name1', 'description1', 'value1')
    plugin_setting = PluginSetting(setting, plugin1)

    plugin = Plugin('type1', 'name1', 'description1')

    config_data = ConfigData()

    config_data.update_setting(global_setting)
    config_data.update_setting(plugin_setting, plugin1)

    result = config_data.get_settings(plugin)

    assert len(result) == 1
    assert result[0].name == 'name1'
    assert result[0].description == 'description1'
    assert result[0].value == 'value1'


# Generated at 2022-06-20 13:39:19.020110
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data=ConfigData()

    setting_1=['host_key_checking=False']
    setting_2=['localhost ansible_connection=local']
    setting_3=['deprecation_warnings=False']

    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2)
    config_data.update_setting(setting_3)

    assert config_data.update_setting(setting_1)
    assert config_data.update_setting(setting_2)
    assert config_data.update_setting(setting_3)

# Generated at 2022-06-20 13:39:26.988037
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()

    # when no single setting, then return None
    setting = configData.get_setting('test_setting')
    assert setting is None

    # when single setting exists, then return correct setting
    configData._global_settings['test_setting'] = 'test_value'
    setting = configData.get_setting('test_setting')
    assert setting == 'test_value'

    # when single setting exists, but wrong name is given, then return None
    setting = configData.get_setting('wrong_name')
    assert setting is None


# Generated at 2022-06-20 13:39:30.427193
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data is not None
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:39:36.543622
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(ConfigSetting('g_foo', 'g_bar'))
    config_data.update_setting(ConfigSetting('p_foo', 'p_bar', 'c', 'co'))

    assert config_data.get_setting('g_foo') is not None
    assert config_data.get_setting('g_foo').name == 'g_foo'
    assert config_data.get_setting('g_foo').value == 'g_bar'

    assert config_data.get_setting('p_foo') is not None
    assert config_data.get_setting('p_foo').name == 'p_foo'
    assert config_data.get_setting('p_foo').value == 'p_bar'

# Generated at 2022-06-20 13:39:38.938801
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    setting = config_data.get_setting('foo')
    assert setting == None

    config_data.update_setting('bar')
    setting = config_data.get_setting('foo')
    assert setting == None

# Generated at 2022-06-20 13:39:41.763811
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:39:57.690678
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    setting1 = Setting("key1", "value1", "key1_help")
    setting2 = Setting("key2", "value2", "key2_help")
    configData.update_setting(setting1)
    configData.update_setting(setting2)
    assert configData.get_setting('key1') == setting1
    assert configData.get_setting('key2') == setting2
    

# Generated at 2022-06-20 13:40:07.274389
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting1 = Setting('setting1', 'value')
    setting2 = Setting('setting2', 'value')
    setting3 = Setting('setting3', 'value')
    
    plugin1 = Plugin('type', 'name')
    plugin2 = Plugin('type', 'name')
    plugin3 = Plugin('type', 'name')
    plugin4 = Plugin('type', 'name')
    
    config_data = ConfigData()
    config_data.update_setting(setting1, None)
    config_data.update_setting(setting2, None)
    config_data.update_setting(setting3, plugin1)
    
    assert config_data.get_settings() == [setting1, setting2]
    assert config_data.get_settings(plugin1) == [setting3]
    assert config_data.get_settings(plugin2)

# Generated at 2022-06-20 13:40:14.278565
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    class Plugin(object):

        def __init__(self, name, type):
            self.name = name
            self.type = type

    class Setting(object):

        def __init__(self, name):
            self.name = name

    c = ConfigData()

    s = Setting('global_setting')
    c.update_setting(s)

    s = Setting('foo')
    c.update_setting(s)
    s = Setting('bar')
    c.update_setting(s, Plugin('foo', 'test'))

    assert c.get_setting('global_setting') == s
    assert c.get_setting('foo') != s
    assert c.get_setting('bar', Plugin('foo', 'test')) == s


# Generated at 2022-06-20 13:40:21.549215
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_plugin = ConfigPlugin("test_plugin", "test_type")
    setting = Setting("test_setting", "test_value")
    config_data.update_setting(setting=setting, plugin=config_plugin)
    assert config_data._global_settings == {}, "Global settings not empty"
    assert config_data._plugins["test_type"]["test_plugin"]["test_setting"].name == "test_setting"


# Generated at 2022-06-20 13:40:23.712471
# Unit test for constructor of class ConfigData
def test_ConfigData():

    configData = ConfigData()
    assert len(configData._global_settings) == 0
    assert len(configData._plugins) == 0


# Generated at 2022-06-20 13:40:25.593701
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    assert config_data.get_setting('test_name') == None


# Generated at 2022-06-20 13:40:33.336227
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from config import ConfigSetting
    from config import ConfigPlugin
    import unittest

    class ConfigDataTest(unittest.TestCase):

        def test_get_setting_without_plugin(self):
            config_data = ConfigData()
            config_setting = ConfigSetting('foo')
            config_data.update_setting(config_setting)
            self.assertEqual(config_data.get_setting('foo'), config_setting)

        def test_get_setting_with_plugin(self):
            config_data = ConfigData()
            plugin = ConfigPlugin('test', 'action')
            config_setting = ConfigSetting('foo')
            config_data.update_setting(config_setting, plugin)
            self.assertEqual(config_data.get_setting('foo', plugin), config_setting)

    unittest.main()

# Generated at 2022-06-20 13:40:43.213897
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    config_data.update_setting(Setting("verbosity", "2"))
    config_data.update_setting(Setting("bin_ansible_callbacks", True))

    plugin = Plugin("action", "ping")
    config_data.update_setting(Setting("retries", "5"), plugin)

    # Test global settings
    assert config_data.get_setting("verbosit") is None
    assert config_data.get_setting("verbosity") == 2
    assert config_data.get_setting("bin_ansible_callbacks") is True

    # Test local settings
    assert config_data.get_setting("retries") is None
    assert config_data.get_setting("retries", plugin) == 5


# Generated at 2022-06-20 13:40:45.694258
# Unit test for constructor of class ConfigData
def test_ConfigData():

    # Empty constructor
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-20 13:40:57.358356
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    global_setting = ConfigSetting('foo', 'bar', '')
    assert config_data.get_setting('foo') is None
    config_data.update_setting(global_setting)
    assert config_data.get_setting('foo') == global_setting
    plugin_setting = ConfigSetting('foo', 'bar', '')
    class Plugin:
        def __init__(self):
            self.type = "c"
            self.name = "d"
    plugin = Plugin()
    assert config_data.get_setting('foo', plugin) is None
    config_data.update_setting(plugin_setting, plugin)
    assert config_data.get_setting('foo', plugin) == plugin_setting


# Generated at 2022-06-20 13:41:16.888665
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo', 'bar') is None


# Generated at 2022-06-20 13:41:24.611476
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from collections import namedtuple
    config_data = ConfigData()
    plugin = namedtuple('fake_object', ['type', 'name'])("Module", "fake_module")
    settings = config_data.get_settings(plugin)
    assert [] == settings

# Generated at 2022-06-20 13:41:27.066874
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    global_settings = c.get_settings()
    assert len(global_settings)==0


# Generated at 2022-06-20 13:41:28.944332
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cd = ConfigData()
    assert 0 == len(cd._global_settings)
    assert 0 == len(cd._plugins)


# Generated at 2022-06-20 13:41:30.666068
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-20 13:41:32.059242
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert data


# Generated at 2022-06-20 13:41:38.854971
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    tmp_setting1 = {"name": "key1", "value": "value1", "origin": "origin1"}
    tmp_setting2 = {"name": "key2", "value": "value2", "origin": "origin2"}
    config_data.update_setting(tmp_setting1)
    assert tmp_setting1 == config_data._global_settings["key1"]
    config_data.update_setting(tmp_setting2, "plugin")
    assert tmp_setting2 == config_data._plugins["plugin"]["plugin"]["key2"]


# Generated at 2022-06-20 13:41:49.189821
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    setting1 = Setting(name='foo', value=1)
    setting2 = Setting(name='bar', value=2)
    setting3 = Setting(name='foo', value=3)

    config_data = ConfigData()

    # No settings
    assert len(config_data.get_settings()) == 0
    # One global setting
    config_data.update_setting(setting1)
    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0] == setting1
    # Add the same setting and verify it's the same object
    config_data.update_setting(setting1)
    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0] == setting1
    # Add another global setting
    config_data.update_setting

# Generated at 2022-06-20 13:41:50.114516
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass



# Generated at 2022-06-20 13:42:04.376170
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    
    from ansible.config.setting import Setting
    
    config_data = ConfigData()

    config_data.update_setting(Setting("ANSIBLE_CONFIG", "/etc/ansible/ansible.cfg", "the path to the ansible configuration file"))

    assert "ANSIBLE_CONFIG" in config_data._global_settings

    config_data.update_setting(Setting("ANSIBLE_INVENTORY", "inventories/hosts", "location of the inventory, which can be a list or a directory"), plugin=PluginDefinition('inventory'))

    assert 'inventory' in config_data._plugins
    assert 'auto' in config_data._plugins['inventory']
    assert 'ANSIBLE_INVENTORY' in config_data._plugins['inventory']['auto']


# Generated at 2022-06-20 13:42:41.189406
# Unit test for constructor of class ConfigData
def test_ConfigData():

    new_configData = ConfigData()
    assert new_configData is not None

# Generated at 2022-06-20 13:42:45.955239
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    from ansible.config.setting import Setting
    setting = Setting('TEST')
    setting.value = 'TESTVALUE'
    config_data.update_setting(setting)
    assert config_data._global_settings['TEST'] == setting


# Generated at 2022-06-20 13:42:50.680565
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    setting = Setting('name', 'value', 'desc')
    config_data.update_setting(setting)
    setting = Setting('name2', 'value2', 'desc2')
    config_data.update_setting(setting)

    settings = config_data.get_settings()

    assert len(settings) == 2


# Generated at 2022-06-20 13:42:58.724935
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0

    from ansible.plugins.loader import get_all_plugin_loaders
    plugin_loaders = get_all_plugin_loaders()

    # Add some data and test again
    config_data.update_setting(Setting('verbosity', '1', None, plugin_loaders['core']))
    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings(plugin_loaders['core'])) == 1
    assert config_data.get_settings()[0].name == config_data.get_settings(plugin_loaders['core'])[0].name

# Generated at 2022-06-20 13:43:00.715531
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    assert isinstance(cd, ConfigData)
    assert cd.get_setting('foo') is None
    assert cd.get_setting('foo', 'foo') is None



# Generated at 2022-06-20 13:43:03.548313
# Unit test for constructor of class ConfigData
def test_ConfigData():
    # test for the default value of all property of class ConfigData
    cd=ConfigData()
    assert cd._global_settings == {}
    assert cd._plugins == {}

# Generated at 2022-06-20 13:43:09.882914
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    conf_data = ConfigData()
    setting_1 = dict(name='setting_1', value={'key': 1})
    setting = dict(plugin_type='module', plugin_name='test_module', **setting_1)
    plugin = Plugin(**setting)
    setting = Setting(**setting_1)
    conf_data.update_setting(setting, plugin)

    assert conf_data._plugins['module']['test_module']['setting_1'] == setting

