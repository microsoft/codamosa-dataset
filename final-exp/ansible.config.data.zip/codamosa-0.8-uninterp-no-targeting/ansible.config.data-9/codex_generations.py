

# Generated at 2022-06-20 13:33:21.481606
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings['ansible_managed'] = 'Ansible managed'
    plugins = {}
    plugins['v2_0_action'] = {}
    plugins['v2_0_action']['copy'] = {}
    plugins['v2_0_action']['copy']['dest_parent'] = 'localhost'
    config_data._plugins = plugins

    settings = config_data.get_settings()
    assert len(settings) == 1
    assert settings[0].name == 'ansible_managed'
    assert settings[0].value == 'Ansible managed'

    settings = config_data.get_settings(Plugin(type='v2_0_action', name='copy'))
    assert len(settings) == 1

# Generated at 2022-06-20 13:33:28.889528
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import ansible
    from ansible.config.setting import Setting

    setting1 = Setting('test1', 'test1')
    setting2 = Setting('test2', 'test2')
    setting3 = Setting('test3', 'test3')

    config = ConfigData()
    assert len(config.get_settings()) == 0
    assert len(config.get_settings(ansible.plugins.connection.local.Connection('local'))) == 0

    config.update_setting(setting1)
    config.update_setting(setting2, ansible.plugins.connection.local.Connection('local'))

    assert len(config.get_settings()) == 1
    assert len(config.get_settings(ansible.plugins.connection.local.Connection('local'))) == 1


# Generated at 2022-06-20 13:33:37.311239
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    # Set global settings of ansible.cfg
    config.update_setting(Setting('DEFAULT_ROLES_PATH', 'roles', 'path'))
    config.update_setting(Setting('HOST_KEY_CHECKING', 'false', 'bool'))
    # Set settings of [defaults] section
    config.update_setting(Setting('action_plugins', 'action_plugins', 'path'), Plugin('defaults', 'action_plugins'))
    config.update_setting(Setting('callback_whitelist', 'callback_whitelist', 'string'), Plugin('defaults', 'callback_whitelist'))
    print(config._plugins)
    print(config._global_settings)

    config.update_setting(Setting('DEFAULT_ROLES_PATH', 'roles', 'path'))
   

# Generated at 2022-06-20 13:33:43.736253
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    setting = Setting(name='key', values=['value1', 'value2'])
    configData.update_setting(setting)
    setting = Setting(name='key', values=['value3', 'value4'])
    configData.update_setting(setting)

    assert configData._global_settings['key'].values == ['value1', 'value2']


# Generated at 2022-06-20 13:33:46.964353
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data is not None

# Generated at 2022-06-20 13:33:49.698141
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:33:52.061671
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(Setting('display', 'debug', 'yes'), None)


# Generated at 2022-06-20 13:33:53.066470
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()


# Generated at 2022-06-20 13:33:54.480721
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert configdata is not None


# Generated at 2022-06-20 13:33:56.206541
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert isinstance(config, ConfigData)


# Generated at 2022-06-20 13:34:06.951668
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import PluginLoader
    from ansible.utils.plugin_docs import DOCUMENTABLE_PLUGINS
    config_data = ConfigData()
    for plugin_type in DOCUMENTABLE_PLUGINS:
        plugin_base_class = PluginLoader.find_plugin(plugin_type)
        for plugin_name in plugin_base_class.get_all_plugins(class_only=False):
            plugin = plugin_base_class.load_plugin(plugin_name)
            if plugin.VERSION is not None:
                config_data.update_setting(plugin_base_class.get_setting(plugin, 'version'))

    # Test function get_setting of class ConfigData
    assert config_data.get_setting('version', plugin_base_class('shell')) is not None
    assert config_data.get

# Generated at 2022-06-20 13:34:12.626488
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    # no return value, no exception
    try:
        config_data.get_settings()
    except:
        assert False, "Shouldn't have thrown an exception"


# Generated at 2022-06-20 13:34:20.587921
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    conf = ConfigData()
    # test with plugin None
    conf.update_setting(Setting("1", "string", "", "", ""), plugin=None)
    assert conf.get_settings()[0].name == "1"
    assert conf.get_settings()[0].plugin is None

    # test with plugin
    plugin = Plugin("2", "string", "string")
    conf.update_setting(Setting("2", "string", "", "", ""), plugin=plugin)
    assert conf.get_settings(plugin)[0].name == "2"
    assert conf.get_settings(plugin)[0].plugin.type == "2" and conf.get_settings(plugin)[0].plugin.name == "string"


# Generated at 2022-06-20 13:34:24.899818
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("doesnt_exist", plugin=None) == None
    assert config_data.get_setting("doesnt_exist", "doesnt_exist") == None


# Generated at 2022-06-20 13:34:25.817787
# Unit test for constructor of class ConfigData
def test_ConfigData():
    assert ConfigData()


# Generated at 2022-06-20 13:34:28.478897
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    assert isinstance(data, ConfigData)

    assert len(data._global_settings) == 0
    assert len(data._plugins) == 0


# Generated at 2022-06-20 13:34:41.864420
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.plugins.loader import find_plugin_filenames, PluginLoader
    from ansible.plugins.inventory import InventoryModule

    config_data = ConfigData()

    inv_plugins = PluginLoader(
        'Inventory',
        'ansible.plugins.inventory',
        C.DEFAULT_INVENTORY_PLUGIN_PATH,
        'inventory_plugins',
        required_base_class=InventoryModule
    )

    inv_plugins.subdirs = find_plugin_filenames(C.DEFAULT_INVENTORY_PLUGIN_PATH, 'inventory_plugins')

    for plugin in inv_plugins.all(class_only=True):
        settings = config_data.get_settings(plugin)
       

# Generated at 2022-06-20 13:34:47.688154
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    config_setting1 = ConfigSetting('host_key_checking', 'boolean')
    config_setting1.value = 'False'
    config_data.update_setting(config_setting1, None)

    config_setting2 = ConfigSetting('ansible_user', 'string')
    config_setting2.value = 'centos'
    config_data.update_setting(config_setting2, HostPattern('*', 'all'))

    config_setting3 = ConfigSetting('ansible_port', 'integer')
    config_setting3.value = '22'
    config_data.update_setting(config_setting3, HostPattern('*', 'all'))

    config_setting4 = ConfigSetting('ansible_ssh_private_key_file', 'path')

# Generated at 2022-06-20 13:34:53.444651
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Initialize test instance
    configdata = ConfigData()

    # Verify empty dict can be returned for empty instance    
    assert(configdata.get_settings() == [])

    # Verify non-empty dict can be returned for non-empty instance
    configdata.update_setting("setting")
    assert(configdata.get_settings() == ["setting"])


# Generated at 2022-06-20 13:34:58.526333
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    config_data.update_setting(Setting('host_key_checking', 'False'), Plugin('connection', 'ssh'))
    assert config_data.get_setting('host_key_checking').value == 'False'
    assert config_dat

# Generated at 2022-06-20 13:35:07.155702
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    assert cd.get_setting('missing') is None
    assert cd.get_setting('missing', 'plugin') is None
    assert cd.get_setting('missing', ['plugin']) is None
    assert cd.get_setting('missing', 'plugin', 'type') is None
    assert cd.get_setting('missing', 'plugin', 'type', '/from') is None


# Generated at 2022-06-20 13:35:10.452997
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert config_data
    assert isinstance(config_data, ConfigData)


# Generated at 2022-06-20 13:35:17.482546
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin(type="connection", name="local")
    setting = Setting(name="gather_timeout", value="30")
    setting1 = Setting(name="gather_timeout_extra", value="10")
    config_data.update_setting(setting)
    config_data.update_setting(setting1, plugin)
    assert config_data._global_settings['gather_timeout'].value == '30'
    assert config_data._plugins['connection']['local']['gather_timeout_extra'].value == '10'


# Generated at 2022-06-20 13:35:18.775021
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-20 13:35:23.264793
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    data.update_setting(Setting('test_setting', 'True', 'test_category'))
    data.update_setting(Setting('test_setting2', '42', 'test_category'))
    assert len(data.get_settings()) == 2


# Generated at 2022-06-20 13:35:25.168554
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:35:35.432216
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    data = ConfigData()

    from .setting import Setting

    # Test global setting
    setting = Setting('name', 'value', '')
    data.update_setting(setting)
    assert len(data._global_settings) == 1
    assert data.get_setting('name') == setting
    assert data.get_setting(setting.name) == setting

    # Test plugin setting
    from .plugin import Plugin
    plugin = Plugin('action', 'shell')
    setting = Setting('name', 'value', '')
    data.update_setting(setting, plugin)
    assert len(data._plugins['action'][plugin.name]) == 1
    assert data.get_setting(setting.name, plugin) == setting
    assert data.get_setting(setting.name) == setting

    # Test plugin setting

# Generated at 2022-06-20 13:35:42.591744
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('name', 'value', 'foo')
    config_data.update_setting(setting, 'plugin.name')
    assert config_data._plugins['foo']['plugin.name']['name'] == 'value'


# Generated at 2022-06-20 13:35:44.571421
# Unit test for constructor of class ConfigData
def test_ConfigData():
    conf = ConfigData()
    assert conf._global_settings == {}
    assert conf._plugins == {}

# Generated at 2022-06-20 13:35:54.161284
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(ConfigDataSetting(name='config_data_1', plugin=ConfigDataPlugin(type='type_1', name='name_1')))
    config_data.update_setting(ConfigDataSetting(name='config_data_2', plugin=ConfigDataPlugin(type='type_1', name='name_2')))
    config_data.update_setting(ConfigDataSetting(name='config_data_3', plugin=ConfigDataPlugin(type='type_2', name='name_1')))
    config_data.update_setting(ConfigDataSetting(name='config_data_4', plugin=ConfigDataPlugin(type='type_2', name='name_2')))
    assert len(config_data.get_settings()) == 4

# Generated at 2022-06-20 13:36:02.290834
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:36:08.049427
# Unit test for constructor of class ConfigData
def test_ConfigData():
    cfg = ConfigData()
    assert(cfg.get_setting(None, None) is None)


# Generated at 2022-06-20 13:36:15.843434
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    model = ConfigData()
    model._global_settings = {
        "authorize_password": "authorize_password",
        "authorize_username": "authorize_username"
    }

# Generated at 2022-06-20 13:36:19.199286
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Test 1
    assert config_data.get_settings() == []

test_ConfigData_get_settings()


# Generated at 2022-06-20 13:36:26.229095
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

    config_data._global_settings['foo'] = 'bar'
    config_data._global_settings['foo1'] = 'bar1'
    assert config_data.get_settings() == ['bar', 'bar1']


# Generated at 2022-06-20 13:36:29.036704
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    data = [['', '', '', '']]

    config_data.update_setting('', '', '', '')
    assert data == config_data.get_settings()

# Generated at 2022-06-20 13:36:40.471110
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_list = []
    setting_list.append(Setting('setting1', 'value1'))
    setting_list.append(Setting('setting2', 'value2'))
    setting_list.append(Setting('setting1', 'value3', 'strat', 'strat_setting1'))
    setting_list.append(Setting('setting2', 'value4', 'strat', 'strat_setting1'))
    setting_list.append(Setting('setting2', 'value5', 'filter', 'filter_setting1'))

    for setting in setting_list:
        config_data.update_setting(setting, Plugin(setting.type, setting.name))

    setting_list_copy = []
    setting_list_copy.append(Setting('setting1', 'value1'))
    setting

# Generated at 2022-06-20 13:36:45.493492
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()

    assert config is not None

# Generated at 2022-06-20 13:36:47.103915
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert isinstance(config_data, ConfigData)


# Generated at 2022-06-20 13:36:51.321011
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()
    config.update_setting(ConfigSetting('setting1'))
    config.update_setting(ConfigSetting('setting2'))
    config.update_setting(ConfigSetting('setting3'))
    config.update_setting(ConfigSetting('setting4'))
    config.update_setting(ConfigSetting('setting5'))

    assert config.get_setting('setting1')
    assert not config.get_setting('setting10')



# Generated at 2022-06-20 13:37:06.631578
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    plugin = Plugin("shell", "shell")
    config_data = ConfigData()
    setting = Setting("SHELL", "/bin/bash", False)
    config_data.update_setting(setting)
    assert config_data.get_setting("SHELL") is not None
    assert config_data.get_setting("SHELL") == setting
    setting.value = "/bin/zsh"
    config_data.update_setting(setting)
    assert config_data.get_setting("SHELL") == setting
    setting = Setting("SHELL", "/bin/zsh", True)
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting("SHELL", plugin) is not None
    assert config_data.get_setting("SHELL", plugin) == setting
    setting.value = "/bin/sh"

# Generated at 2022-06-20 13:37:07.261893
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass

# Generated at 2022-06-20 13:37:13.550806
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    from ansible.cli.galaxy import ConfigOption

    config_option = ConfigOption('test', 'string', 'hello')
    assert config_data.get_setting('test') is None
    config_data.update_setting(config_option)
    assert config_data.get_setting('test') is not None

    config_option = ConfigOption('test', 'string', 'hello')
    assert config_data.get_setting('test', object()) is None
    config_data.update_setting(config_option, object())
    assert config_data.get_setting('test', object()) is not None


# Generated at 2022-06-20 13:37:17.933361
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.module_utils.ansible_release import __version__
    from ansible.plugins.loader import setting_loader

    plugin_type = 'default'
    plugin_name = 'ansible'
    config_data = setting_loader.init_config_data()
    config_data.update_setting(setting_loader.Setting(name='ANSIBLE_VERSION', value=__version__))
    settings = config_data.get_settings(setting_loader.Plugin(name=plugin_name, type=plugin_type))

    assert len(settings) > 0

# Generated at 2022-06-20 13:37:22.375780
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    assert cd.get_settings() == []
    assert cd.get_settings('core') == []
    assert cd.get_settings('') == []
    assert cd.get_settings('core', '*)') == []

    cd.update_setting(Setting(name=''))
    assert len(cd.get_settings()) == 1

    cd.update_setting(Setting(name=''), Plugin(type='core', name='*'))
    assert len(cd.get_settings('core')) == 1
    assert len(cd.get_settings('')) == 1
    assert len(cd.get_settings('core', '*)')) == 1


# Generated at 2022-06-20 13:37:31.593334
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Build test data

    # Build local instance to test
    config_data = ConfigData()

    # Build global test setting
    test_setting = {
        "name": "test_setting_1",
        "short_desc": "this is a test setting",
        "description": "this is a test setting",
        "type": "string",
        "default": "default test value",
        "aliases": ["tst_set_1"],
        "ini": ["test_section", "test_key1"]
    }

    # Build global test setting

# Generated at 2022-06-20 13:37:41.347894
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    setting = config_data.get_setting("name")
    assert not setting

    class Plugin(object):
        def __init__(self, type, name):
            self.type = type
            self.name = name

    plugin = Plugin("my_type", "my_name")
    setting = config_data.get_setting("name", plugin)
    assert not setting


# Generated at 2022-06-20 13:37:52.052424
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    plugin1 = Plugin('fip', 'dpdk')
    plugin2 = Plugin('fip', 'mlxd')
    plugin3 = Plugin('vip', 'mlxd')

    setting1 = PluginSetting('priority', '3', plugin1)
    setting2 = PluginSetting('priority', '4', plugin2)
    setting3 = PluginSetting('priority', '1', plugin3)
    setting4 = PluginSetting('priority', '0', None)

    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting3)
    config_data.update_setting(setting4)

    assert setting1 == config_data.get_setting(setting1.name, plugin1)
    assert setting2 == config_data.get_

# Generated at 2022-06-20 13:38:01.920385
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    assert len(config_data.get_settings()) == 0
    config_data.update_setting(Type=None, Name="name1", Value=1)
    config_data.update_setting(Type=None, Name="name2", Value="a string")
    assert len(config_data.get_settings()) == 2
    setting = config_data.get_setting("name1")
    assert setting.name == "name1"
    assert setting.value == 1
    setting2 = config_data.get_setting("name2")
    assert setting2.name == "name2"
    assert setting2.value == "a string"

# Generated at 2022-06-20 13:38:12.868425
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from collections import namedtuple
    from ansible import constants as C
    testConfigData = ConfigData()
    PluginNamedTuple = namedtuple('Plugin', 'type name')
    plugin1 = PluginNamedTuple(type='lookup', name='passwd')
    plugin2 = PluginNamedTuple(type='lookup', name='file')
    plugin3 = PluginNamedTuple(type='shell', name='sh')
    plugin4 = PluginNamedTuple(type='shell', name='bash')
    testConfigData.update_setting(setting=Setting('LOOKUP_PASSWD_FILE', C.DEFAULT_LOOKUP_PASSWD_FILE, plugin=plugin1))

# Generated at 2022-06-20 13:38:24.088882
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()
    core_plugin_loader = PluginLoader('ansible.plugins.lookup', 'LookupModule', 'lookup_plugins')
    all_lookup_plugins = list(core_plugin_loader.all())

    for lookup_plugin in all_lookup_plugins:
        lookup_plugin_for_test = core_plugin_loader.get(lookup_plugin.name)
        config_data.update_setting(lookup_plugin_for_test.get_option('free_form'))

    assert 'free_form' in config_data.get_settings(lookup_plugin_for_test)



# Generated at 2022-06-20 13:38:37.901099
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    assert c.get_setting('TEST') is None
    assert c.get_setting('TEST', 'plugin') is None
    assert c.get_setting('TEST', 'collection.plugin') is None

    s = Setting('TEST', 'foo', 'Foo value.', 'global')
    c.update_setting(s)

    assert c.get_setting('TEST') == s
    assert c.get_setting('TEST', 'plugin') is None
    assert c.get_setting('TEST', 'collection.plugin') is None

    s2 = Setting('TEST', 'foo', 'Foo value.', 'bar')
    c.update_setting(s2, 'plugin')

    assert c.get_setting('TEST') == s

# Generated at 2022-06-20 13:38:39.231599
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    cd = ConfigData()
    assert cd.get_setting('setting') == None

# Generated at 2022-06-20 13:38:44.928405
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cd.update_setting(Setting('ANSIBLE_MODULE_ARGS', 'ANSIBLE_MODULE_ARGS', 'foo', 'module.params'), plugin=Plugin('module', 'foo'))
    assert cd.get_setting('ANSIBLE_MODULE_ARGS', plugin=Plugin('module', 'foo')).value == 'foo'
    assert cd.get_setting('ANSIBLE_MODULE_ARGS', plugin=Plugin('module', 'bar')) is None


# Generated at 2022-06-20 13:38:51.211160
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    config.update_setting(Setting('name', 'value'))
    config.update_setting(Setting('name2', 'value2'), Plugin('core', 'connection'))
    config.update_setting(Setting('name3', 'value3'), Plugin('core', 'shell'))

    assert config.get_setting('name') == Setting('name', 'value')
    assert config.get_setting('name2', Plugin('core', 'connection')) == Setting('name2', 'value2')
    assert config.get_setting('name3', Plugin('core', 'shell')) == Setting('name3', 'value3')
    assert config.get_setting('name3', Plugin('core', 'connection')) is None
    assert config.get_setting('name', Plugin('core', 'shell')) is None

# Unit test

# Generated at 2022-06-20 13:39:01.303222
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    assert len(configData._global_settings) == 0
    setting1 = {'setting1':'setting1_value'}
    configData.update_setting(setting1)

    assert (len(configData._global_settings) == 1) and (configData._global_settings['setting1'] == 'setting1_value')

    setting2 = {'setting2':'setting2_value'}
    configData.update_setting(setting2, plugin = 'plugin')


# Generated at 2022-06-20 13:39:05.347507
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('default', 'this is a test'))
    assert config_data.get_setting('default').value == 'this is a test'


# Generated at 2022-06-20 13:39:15.827284
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Case 1: update global setting
    config_data = ConfigData()
    setting = {}
    setting["name"] = "ANSIBLE_HOST_KEY_CHECKING"
    setting["value"] = "FALSE"
    config_data.update_setting(setting)

    assert config_data._global_settings.get("ANSIBLE_HOST_KEY_CHECKING").name == "ANSIBLE_HOST_KEY_CHECKING"
    assert config_data._global_settings.get("ANSIBLE_HOST_KEY_CHECKING").value == "FALSE"

    # Case 2: update setting of plugins
    plugin = {}
    plugin["type"] = "action"
    plugin["name"] = "script"
    setting["name"] = "ANSIBLE_ACTION_PLUGINS"
    setting["value"] = "/tmp/action_plugins"


# Generated at 2022-06-20 13:39:22.709039
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    
    test_config_data = ConfigData()
    setting = Setting(name = 'test_setting', value = 'test_value', plugin = Plugin('test_plugin', 'test_type'))
    test_config_data.update_setting(setting)
    assert test_config_data.get_setting('test_setting').value == 'test_value'


# Generated at 2022-06-20 13:39:25.848845
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    test_data = ConfigData()
    test_data.update_setting(Setting("foo", "bar"))
    assert "bar" == test_data.get_settings()[0].value


# Generated at 2022-06-20 13:39:46.234198
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    # update_setting(setting, plugin=None)
    # Setting name(s) as key, value and plugin(s) as value
    # Returns None

# Generated at 2022-06-20 13:39:52.221522
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    global_configuration = {
        "config_key1": "config_value1",
        "config_key2": "config_value2"
    }

    plugin_configuration = {
        "config_key3": "config_value3",
        "config_key4": "config_value4"
    }


    config_data = ConfigData()

    for config_key, config_value in global_configuration.items():
        global_setting = Setting(config_key, config_value)
        config_data.update_setting(global_setting)

    for config_key, config_value in plugin_configuration.items():
        plugin_setting = Setting(config_key, config_value)
        plugin = Plugin("test", "test")
        config_data.update_setting(plugin_setting, plugin)


# Generated at 2022-06-20 13:40:03.428432
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config = ConfigData()

    # Test with global setting
    setting = Setting('s1', {})
    config.update_setting(setting)
    assert config.get_setting('s1') is not None

    # Test with plugin type setting
    plugin = Plugin('t1', '')
    setting = Setting('s2', {})
    config.update_setting(setting, plugin)
    assert config.get_setting('s2', plugin) is not None

    # Test with plugin setting
    plugin = Plugin('t1', 'p1')
    setting = Setting('s3', {})
    config.update_setting(setting, plugin)
    assert config.get_setting('s3', plugin) is not None

    # Test with global setting and deleted plugin type
    setting = Setting('s4', {})

# Generated at 2022-06-20 13:40:07.633321
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin(type='action', name='consul_kv')
    setting = Setting(name='key')
    config_data.update_setting(setting, plugin=plugin)

    assert len(config_data.get_settings(plugin=plugin)) == 1
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-20 13:40:14.489710
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()

    setting_name = 'test_setting'
    plugin = ConfigPlugin('a', 'b', 'c')
    setting = ConfigSetting(setting_name)
    configData.update_setting(setting, plugin=plugin)

    result = configData.get_setting(setting_name)
    assert result is None

    result = configData.get_setting(setting_name, plugin=plugin)
    assert result.name == setting_name


# Generated at 2022-06-20 13:40:25.638216
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    settings = {
        'module_defaults': {
            'default_test_setting': 'module_default_test_setting',
            'test_setting': 'module_test_setting',
        },
        'module_additional': {
            'test_setting': 'module_additional_test_setting'
        }
    }
    config_data = ConfigData()
    config_data._global_settings = {
        'default_test_setting': 'default_test_setting',
        'test_setting': 'test_setting',
    }
    config_data._plugins = {
        'module': {
            'defaults': settings['module_defaults'],
            'additional': settings['module_additional']
        }
    }

    settings = config_data.get_settings()

# Generated at 2022-06-20 13:40:27.339173
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()

    assert config._global_settings == {}
    assert config._plugins == {}


# Generated at 2022-06-20 13:40:31.401898
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()


# Generated at 2022-06-20 13:40:39.528859
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader

    loader = PluginLoader('callback', 'tests/unit/utils/plugins/callback', 'callback_plugins')
    plugin = loader.get('dummy')
    plugin.path = '/home/user1/ansible/plugins/callback/dummy.py'

    config_data = ConfigData()
    setting1 = Setting(name='setting1', plugin=plugin)
    setting2 = Setting(name='setting2', plugin=plugin)
    setting3 = Setting(name='setting3', plugin=plugin)

    config_data.update_setting(setting1)
    config_data.update_setting(setting2, plugin)
    config_data.update_setting(setting3, plugin)

    settings = config_data.get_settings()
    assert len(settings) == 1

    settings = config_data

# Generated at 2022-06-20 13:40:44.362617
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()
    assert config._global_settings == {}
    assert config._plugins == {}


# Generated at 2022-06-20 13:40:57.154965
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    pass
    # config_data = ConfigData()
    # config_data.update_setting({'name': 'plugin_name','value': 'plugin_value','plugin_name':'plugin','plugin_type':'plugin_type','plugin_args': None})

# Generated at 2022-06-20 13:41:04.743666
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    ansible.module_utils.config_data = ConfigData()
    assert ansible.module_utils.config_data._global_settings == {}
    assert ansible.module_utils.config_data._plugins == {}

    class Plugin(object):

        def __init__(self):
            self.type = None
            self.name = None

    stage_no_global_settings = ansible.module_utils.config_data._global_settings.copy()
    stage_no_plugins = ansible._modules.config_data._plugins.copy()

    setting_val = "true"
    setting_name = "foo"
    setting_type = "bool"
    setting_scope = "core"
    setting = Setting(setting_name, setting_type, setting_scope, setting_val)

    ansible.module_utils.config_data

# Generated at 2022-06-20 13:41:08.855159
# Unit test for constructor of class ConfigData
def test_ConfigData():
    pass
    # c1 = ConfigData()
    # assert c1 is not None
    # assert c1._global_settings == {}
    # assert c1._plugins == {}


# Generated at 2022-06-20 13:41:14.166360
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cdata = ConfigData()

    cdata.update_setting(Setting('bar', '1'))
    assert(cdata.get_setting('bar') is not None)

    cdata.update_setting(Setting('foo', '2'), Plugin('test', 'test'))
    assert(cdata.get_setting('foo', Plugin('test', 'test')) is not None)


# Generated at 2022-06-20 13:41:25.390287
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cfgdata = ConfigData()

    cfgdata.update_setting(Setting('foo', 'bar', 'global', 'global'))
    cfgdata.update_setting(Setting('foo', 'baz', 'global', 'test'))
    cfgdata.update_setting(Setting('foo', 'qux', 'test', 'test'))

    assert cfgdata.get_setting('foo')['name'] == 'foo'
    assert cfgdata.get_setting('foo', Plugin('test', 'test'))['name'] == 'foo'
    assert cfgdata.get_setting('foo', Plugin('global', 'test'))['name'] == 'foo'

    assert cfgdata.get_setting('foo')['value'] == 'bar'
    assert cfgdata.get_setting('foo', Plugin('test', 'test'))

# Generated at 2022-06-20 13:41:30.123523
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin_name = "test_plugin"
    setting_name = "test_setting"
    setting = config_data.get_setting(setting_name, plugin_name)
    assert setting is None

    setting = config_data.get_settings(plugin_name)
    assert setting == []


# Generated at 2022-06-20 13:41:39.087868
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    config_data.update_setting(Setting(name='test'))

    assert len(config_data._global_settings) == 1
    assert config_data._global_settings['test'].name == 'test'
    assert config_data._plugins == {}

    config_data.update_setting(Setting(name='test2'))

    assert len(config_data._global_settings) == 2
    assert config_data._global_settings['test'].name == 'test'
    assert config_data._global_settings['test2'].name == 'test2'
    assert config_data._plugins == {}

    plugin = Plugin(type='test_type', name='test_name')
    config_data.update

# Generated at 2022-06-20 13:41:44.345304
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert not data.get_settings()
    assert not data.get_settings(None)
    assert not data.get_settings(Plugin(type=None, name=None))
    assert not data.get_settings(Plugin(None, None))


# Generated at 2022-06-20 13:41:48.049774
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    cd.update_setting(Setting(name='foo', value='bar'))
    assert cd.get_setting(name='foo') == 'bar'


# Generated at 2022-06-20 13:41:50.233444
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:42:03.890929
# Unit test for constructor of class ConfigData
def test_ConfigData():
    data = ConfigData()
    
    return True


# Generated at 2022-06-20 13:42:18.519442
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansiblelint import AnsibleLintRule, StringMatch, StringIgnoreCaseMatch, is_disabled

    class Test_ConfigData_update_setting_Plugin(object):
        type = 'test'
        name = 'test_plugin'

    class Test_ConfigData_update_setting_Plugin2(object):
        type = 'test'
        name = 'test_plugin'

    class Test_ConfigData_update_setting_Plugin3(object):
        type = 'test'
        name = 'test_plugin2'

    class Test_ConfigData_update_setting_Plugin4(object):
        type = 'test2'
        name = 'test_plugin'

    class Test_ConfigData_update_setting_Rule(AnsibleLintRule):
        id = 'TEST_CONFIGDATA_UPDATE_SETTING'
        short

# Generated at 2022-06-20 13:42:24.900456
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    c = ConfigData()
    from units.mock.loader import DummyModule
    from units.mock.path import mock_unfrackpath_noop
    from units.compat.mock import patch
    from ansible.plugins.loader import get_all_plugin_loaders, get_plugin_loader
    from ansible.plugins.loader import PluginLoader

    m = DummyModule()
    p = PluginLoader('action', 'foo', 'units/mock/plugins', 'action')


# Generated at 2022-06-20 13:42:29.189934
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {'foo': 'bar'}
    assert(config_data.get_settings() == 'bar')

# Generated at 2022-06-20 13:42:33.524371
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting_1 = Setting(name="test_setting", value="test_value")
    config_data.update_setting(setting_1)
    assert config_data.get_setting("test_setting") is not None



# Generated at 2022-06-20 13:42:35.625634
# Unit test for constructor of class ConfigData
def test_ConfigData():
    # test initialization
    config_data = ConfigData()
    assert config_data
    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:42:42.069420
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    setting1 = {
        'name': 'setting1',
        'value': 'value1'
    }

    setting2 = {
        'name': 'setting2',
        'value': 'value2'
    }

    config_data = ConfigData()
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    settings = config_data.get_settings()
    return settings

# Generated at 2022-06-20 13:42:51.879538
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.config.setting import Setting
    from ansible.config.plugin import PluginType

    config_data = ConfigData()

    test_setting_1 = Setting("setting_1", "value_1", desc="Setting 1")
    test_setting_2 = Setting("setting_2", "value_2", desc="Setting 2")
    test_setting_3 = Setting("setting_3", "value_3", desc="Setting 3")

    config_data.update_setting(test_setting_1)
    config_data.update_setting(test_setting_2)
    config_data.update_setting(test_setting_1, PluginType("plugin_type"))
    config_data.update_setting(test_setting_2, PluginType("plugin_type", "plugin_name"))

# Generated at 2022-06-20 13:42:56.940229
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    global_config_data = ConfigData()
    global_config_data.update_setting('test')
    assert global_config_data.get_setting('test') == 'test'
    plugin_config_data = ConfigData()
    plugin_config_data.update_setting('test1', 'test')
    assert plugin_config_data.get_setting('test1', 'test') == 'test1'


# Generated at 2022-06-20 13:43:02.408094
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting(name="setting_first", value=1))
    config_data.update_setting(Setting(name="setting_second", value="2"))
    assert len(config_data.get_settings()) == 2

