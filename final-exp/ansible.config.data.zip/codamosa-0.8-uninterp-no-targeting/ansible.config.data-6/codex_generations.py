

# Generated at 2022-06-20 13:33:21.590547
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    setting1 = {"name": "setting1", "value": "value1"}
    setting2 = {"name": "setting2", "value": "value2"}
    setting3 = {"name": "setting3", "value": "value3"}
    settings = [setting1, setting2]
    config_data._plugins["type1"] = {}
    config_data._plugins["type1"]["name1"] = {}
    config_data._plugins["type1"]["name1"]["setting1"] = setting1
    config_data._plugins["type1"]["name1"]["setting2"] = setting2
    config_data._plugins["type1"]["name2"] = {}
    config_data._plugins["type1"]["name2"]["setting1"] = setting1
   

# Generated at 2022-06-20 13:33:23.661698
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}



# Generated at 2022-06-20 13:33:35.359121
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    settings_lists = settings_list()
    config_data = ConfigData()
    for plugin in settings_lists:
        for setting in settings_lists[plugin]:
            config_data.update_setting(setting, plugin)

    assert len(config_data.get_settings()) == 3
    assert len(config_data.get_settings(Plugin('callback', 'minimal'))) == 1
    assert len(config_data.get_settings(Plugin('system_warning', 'simple'))) == 1
    assert len(config_data.get_settings(Plugin('authorized_key_module'))) == 1



# Generated at 2022-06-20 13:33:36.683995
# Unit test for constructor of class ConfigData
def test_ConfigData():

    obj = ConfigData()
    assert(obj)


# Generated at 2022-06-20 13:33:44.109084
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('host', '192.168.0.1'))
    settings = config_data.get_settings()
    assert len(settings) == 1
    assert settings[0].name == 'host'
    assert settings[0].value == '192.168.0.1'

    # Expect blank list
    settings = config_data.get_settings(Plugin('action', 'test'))
    assert settings == []


# Generated at 2022-06-20 13:33:47.773539
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert {} == config_data._global_settings
    assert {} == config_data._plugins


# Generated at 2022-06-20 13:33:59.084174
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    import ansible.parsing.plugin_docs

    config = ConfigData()

    assert config.get_setting('FOO') is None
    assert config.get_setting('FOO', ansible.parsing.plugin_docs.PluginDocs()) is None

    config.update_setting(ConfigSetting('FOO', 'BAR'))
    assert config.get_setting('FOO') is not None
    assert config.get_setting('FOO').value == 'BAR'
    assert config.get_setting('FOO', ansible.parsing.plugin_docs.PluginDocs()) is None

    config.update_setting(ConfigSetting('FOO', 'BAR'), ansible.parsing.plugin_docs.PluginDocs())
    assert config.get_setting('FOO') is not None
    assert config.get_setting

# Generated at 2022-06-20 13:34:12.026774
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Arrange
    config_data = ConfigData()
    setting_global = {'name': 'connection_timeout', 'value': '60'}
    setting_plugin_type = {'name': 'connection_timeout', 'value': '30'}
    setting_plugin_type_name = {'name': 'connection_timeout', 'value': '20'}

    # Act
    config_data.update_setting(setting_global)
    config_data.update_setting(setting_plugin_type, 'network_cli')
    config_data.update_setting(setting_plugin_type_name, 'network_cli', 'ios')

    # Assert
    global_setting = config_data.get_setting('connection_timeout')
    assert global_setting.name == 'connection_timeout'
    assert global_setting.value == '60'

# Generated at 2022-06-20 13:34:20.731425
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    #Creating instances of Setting class
    setting_1 = Setting(name='setting_1', value='value_1')
    setting_2 = Setting(name='setting_2', value='value_2')
    setting_3 = Setting(name='setting_3', value='value_3')
    setting_4 = Setting(name='setting_4', value='value_4')

    #Creating instances of Plugin class
    plugin_1 = Plugin(type='type_1', name='name_1')
    plugin_2 = Plugin(type='type_2', name='name_2')

    #Creating instance of ConfigData class
    config_data = ConfigData()

    #set global_settings and plugins for config_data
    config_data.update_setting(setting_1)
    config_data.update_setting(setting_2, plugin_1)


# Generated at 2022-06-20 13:34:31.483319
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    settings = {}
    config_data = ConfigData()

    assert config_data.get_setting('foo') is None
    assert settings == {}

    # A bit complex but we need the check that setting is returned as
    # a reference to the original object.

    # Not finding a setting will not remove existing settings
    assert config_data.get_setting('foo') is None
    settings.update({'foo': True})
    config_data.update_setting(settings['foo'])
    assert config_data.get_setting('foo') == settings['foo']
    assert config_data.get_setting('foo') is settings['foo']
    assert config_data.get_setting('foo') == settings.get('foo')
    assert config_data.get_setting('foo') is settings.get('foo')

# Generated at 2022-06-20 13:34:44.784574
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # New ConfigData instance
    config_data = ConfigData()

    # Mock a setting
    setting = {
        'name': 'test',
        'foo': 'bar',
    }

    # Mock a plugin
    plugin = {'type': 'test_type',
              'name': 'test_name'}

    # Print the setting
    print("\nSetting: ", setting)

    # Update the setting for the ConfigData
    config_data.update_setting(setting, plugin)

    # Get the setting for the plugin
    setting_plugin = config_data.get_setting("test", plugin)

    # Print the setting for the plugin
    print("Setting for plugin: ", setting_plugin)

    # Get the setting for the ConfigData
    setting_data = config_data.get_setting("test")

    # Print the setting for the

# Generated at 2022-06-20 13:34:57.666167
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    
    # TEST 1: retrieving global settings
    config_data = ConfigData()
    setting = config_data.get_setting('my_setting')
    assert(setting == None)
    
    # TEST 2: retrieving settings for nonexistent plugin
    config_data = ConfigData()
    setting = config_data.get_setting('my_setting','my_plugin')
    assert(setting == None)

    # TEST 3: retrieving settings for existent plugin
    config_data = ConfigData()
    config_data.update_setting('my_setting', 'my_plugin')
    setting = config_data.get_setting('my_setting','my_plugin')
    assert(setting == 'my_setting')


# Generated at 2022-06-20 13:35:05.678531
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    class Plugin:
        def __init__(self, type, name):
            self.type = type
            self.name = name

    class Setting:
        def __init__(self, name):
            self.name = name

    cd = ConfigData()

    # Test global settings
    setting1 = Setting('hostfile')
    setting2 = Setting('remote_user')
    cd.update_setting(setting1)
    cd.update_setting(setting2)
    assert len(cd.get_setting(setting1.name)) == 2
    assert cd.get_setting(setting1.name)[0].name == setting1.name
    assert cd.get_setting(setting1.name)[1].name == setting2.name

    # Test plugins settings
    setting3 = Setting('hostfile')
    setting4 = Setting('remote_user')

# Generated at 2022-06-20 13:35:12.110528
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test 1: Get non-existing global setting
    global_setting = config_data.get_setting("non-existing-setting")
    assert global_setting is None

    # Test 2: Get non-existing plugin setting
    plugin = Plugin("action", "module", "module_utils/basic.py")
    plugin_setting = config_data.get_setting("non-existing-setting", plugin)
    assert plugin_setting is None



# Generated at 2022-06-20 13:35:15.399661
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0
    config_data.update_setting(Setting('NONE',None,None,None))
    assert len(config_data.get_settings()) == 1

# Generated at 2022-06-20 13:35:25.170025
# Unit test for constructor of class ConfigData
def test_ConfigData():
    plugin_type = "localhost"
    plugin_name = "local"
    global_setting_name = "gather_facts"
    setting_name = "fact_path"

    global_setting = Setting(global_setting_name, plugin_type, plugin_name)
    global_setting.value = "./fact_path"

    plugin = Plugin(plugin_type, plugin_name)

    setting = Setting(setting_name, plugin_type, plugin_name)
    setting.value = "/fact_path"

    config_data = ConfigData()
    config_data.update_setting(global_setting)
    config_data.update_setting(setting, plugin)

    assert config_data.get_setting(global_setting_name) == global_setting
    assert config_data.get_setting(setting_name, plugin) == setting


# Generated at 2022-06-20 13:35:27.822256
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()
    assert not config_data._global_settings
    assert not config_data._plugins


# Generated at 2022-06-20 13:35:30.146748
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config_data = ConfigData()

    assert config_data._global_settings == {}
    assert config_data._plugins == {}


# Generated at 2022-06-20 13:35:31.217623
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config = ConfigData()


# Generated at 2022-06-20 13:35:33.406354
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
# TODO: Add unit test to test_ConfigData_get_setting
    pass # Replace this line 1 with your code


# Generated at 2022-06-20 13:35:41.203445
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    test_cd = ConfigData()
    test_cs = ConfigSetting(name='setting1', value='setting1 value', plugin='host_list')

# Generated at 2022-06-20 13:35:48.222527
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    my_setting = Setting(name='new_setting', value=None)

    assert(my_setting.name == 'new_setting')
    assert(my_setting.value == None)

    my_config_data = ConfigData()
    my_config_data.update_setting(my_setting)
    
    assert(my_config_data.get_setting(name='new_setting') == my_setting)

# Generated at 2022-06-20 13:35:50.673597
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert not config_data._global_settings
    assert not config_data._plugins


# Generated at 2022-06-20 13:35:54.555694
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-20 13:36:06.529929
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    # Test with a setting from global configuration
    config = ConfigData()

    setting1 = ConfigSetting(name='test1', value='value_test1')
    config.update_setting(setting1)

    setting = config.get_setting('test1')
    assert(setting is setting1)

    # Test with a setting from a plugin
    plugin = ConfigPlugin(type='test', name='test1')
    setting2 = ConfigSetting(name='toto', value='titi')
    config.update_setting(setting2, plugin=plugin)

    setting = config.get_setting('toto', plugin=plugin)
    assert(setting is setting2)

    # Test with a setting from a plugin (using a plugin (type, name) string)
    plugin = ConfigPlugin(type='test', name='test1')

# Generated at 2022-06-20 13:36:09.851308
# Unit test for constructor of class ConfigData
def test_ConfigData():

    expected_global_settings = {}
    expected_plugins = {}

    config_data = ConfigData()

    if config_data._global_settings != expected_global_settings:
        raise AssertionError()
    if config_data._plugins != expected_plugins:
        raise AssertionError()


# Generated at 2022-06-20 13:36:23.287831
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    cd = ConfigData()

    cd.update_setting(Setting('foo', 'bar'))
    assert cd.get_setting('foo') == Setting('foo', 'bar')
    cd.get_setting('foo').value = 'bar2'
    assert cd.get_setting('foo') == Setting('foo', 'bar2')
    assert cd.get_setting('baz') is None

    cd.update_setting(Setting('bar', 'baz'), Plugin(Plugin.CORE, 'some_core_plugin'))
    assert cd.get_setting('bar') == Setting('bar', 'baz')
    cd.get_setting('bar', plugin=Plugin(Plugin.CORE, 'some_core_plugin')).value = 'baz2'

# Generated at 2022-06-20 13:36:30.180177
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()

    class Plugin:
        def __init__(self, name, plugin_type):
            self.name = name
            self.type = plugin_type

    plugin1 = Plugin('name1', 'type1')
    plugin2 = Plugin('name2', 'type2')

    class Setting:
        def __init__(self, name, value):
            self.name = name
            self.value = value

        def get_name(self):
            return self.name

        def get_value(self):
            return self.value

    setting1 = Setting('name1', 'value1')
    setting2 = Setting('name2', 'value2')
    setting3 = Setting('name3', 'value3')
    setting4 = Setting('name4', 'value4')

    # Check init

# Generated at 2022-06-20 13:36:41.531682
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    cd = ConfigData()
    s1 = Setting()
    s1.name='foo'
    cd.update_setting(s1)
    s2 = Setting()
    s2.name='bar'
    s2.plugin.type='lookup'
    s2.plugin.name='some_lookup'
    cd.update_setting(s2)
    assert(cd.get_setting('foo',None) is not None)
    assert(cd.get_setting('foo',None).name == 'foo')
    assert('foo' in cd.get_settings(None))
    assert(cd.get_setting('bar',s2.plugin) is not None)
    assert(cd.get_setting('bar',s2.plugin).name == 'bar')
    assert('bar' in cd.get_settings(s2.plugin))

# Generated at 2022-06-20 13:36:43.849944
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config = ConfigData()
    assert len(config.get_settings()) == 0
    assert len(config.get_settings(plugin='name')) == 0
    assert len(config.get_settings(plugin='name', setting='type')) == 0


# Generated at 2022-06-20 13:36:50.059282
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data._global_settings == {}

# Generated at 2022-06-20 13:36:50.691992
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    pass

# Generated at 2022-06-20 13:36:53.446312
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    settings = config_data.get_settings()
    assert isinstance(settings, list)
    assert len(settings) == 0


# Generated at 2022-06-20 13:37:01.501862
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert config.get_setting("foo") is None
    assert config.get_setting("foo", AnsiblePlugin("bar", "baz")) is None

    assert config.get_setting("foo").name == "foo"
    assert config.get_setting("foo", AnsiblePlugin("bar", "baz")).name == "foo"

    assert config.get_setting("foo") != "foo"
    assert config.get_setting("foo", AnsiblePlugin("bar", "baz")) != "foo"


# Generated at 2022-06-20 13:37:08.228499
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    test_plugin_type = 'test'
    test_plugin_name = 'test_plugin'
    test_setting_name = 'test_setting'
    test_setting_value = 'value'

    config_data = ConfigData()
    setting = Setting(test_setting_name, test_setting_value)
    config_data.update_setting(setting)
    assert config_data.get_setting(test_setting_name) == setting
    assert config_data.get_setting(test_setting_name, Plugin(test_plugin_type, test_plugin_name)) is None


# Generated at 2022-06-20 13:37:11.891666
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    # Test search for global settings
    setting_list = config_data.get_settings()
    assert setting_list == []

    # Test search for plugin settings
    setting_list = config_data.get_settings(('name', 'type'))
    assert setting_list == []



# Generated at 2022-06-20 13:37:20.746441
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    from ansible.module_utils._text import to_bytes

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()

    # create a global setting
    config_data.update_setting(Setting('my_setting', 'my_value'))

    # create a connection setting
    config_data.update_setting(
        Setting('my_setting', 'new_value2'), PluginLoader().get('connection', 'local'))

    # create a network_os setting
    config_data.update_setting(
        Setting('my_setting', 'new_value3'), PluginLoader().get('network_os', 'ios'))

    # create a cli transport setting

# Generated at 2022-06-20 13:37:21.818595
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    test = ConfigData()
    assert test.get_setting('ANSIBLE_CONFIG') is None


# Generated at 2022-06-20 13:37:31.384253
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    settings1 = [
        {'name': 'foo1', 'value': 'bar1', 'plugin_type': None, 'plugin_name': None}
    ]
    settings2 = [
        {'name': 'foo2', 'value': 'bar2', 'plugin_type': 'a', 'plugin_name': 'a'}
    ]
    settings3 = [
        {'name': 'foo3', 'value': 'bar3', 'plugin_type': 'b', 'plugin_name': 'b'}
    ]
    settings4 = [
        {'name': 'foo4', 'value': 'bar4', 'plugin_type': 'a', 'plugin_name': 'b'}
    ]

# Generated at 2022-06-20 13:37:36.072863
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data_obj = ConfigData()
    settings = []
    assert(config_data_obj.get_settings() == settings)
    with open('test/data/ansible_sample_settings.yml') as f:
        settings = yaml.safe_load(f)
        for setting in settings:
            config_data_obj.update_setting(setting)
        assert(config_data_obj.get_settings() == settings)
    f.close()


# Generated at 2022-06-20 13:37:52.953404
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from units.mock.loader import DictDataLoader

    from units.mock.path import mock_unfrackpath_noop

    from ansible.plugins import PluginLoader

    config_data = ConfigData()

    constant_plugin = PluginLoader('constant', 'ansible.plugins.test.test_plugin', config_data, '', '', None)

    mock_plugins = {'test': {'simple': {}, 'with_requires': {},
                             'with_deprecation': {}, 'with_run': {},
                             'no_require_one': {},
                             'no_require_two': {},
                             'bad_require_one': {},
                             'bad_require_two': {},
                             'bad_require_three': {},
                             'constant': constant_plugin}}



# Generated at 2022-06-20 13:37:55.510727
# Unit test for constructor of class ConfigData
def test_ConfigData():
    # when
    config = ConfigData()

    # then
    assert config._global_settings == {}
    assert config._plugins == {}


# Generated at 2022-06-20 13:37:57.976612
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    settings = data.get_settings()
    assert len(settings) == 0

# Generated at 2022-06-20 13:37:59.566936
# Unit test for constructor of class ConfigData
def test_ConfigData():

    config = ConfigData()

    assert isinstance(config, ConfigData)

# Generated at 2022-06-20 13:38:01.262092
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    assert config_data is not None


# Generated at 2022-06-20 13:38:12.344129
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    from ansible.plugins.inventory import InventoryPlugin
    from ansible.plugins.cache import CachePlugin
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.boolean import boolean
    config_data = ConfigData()
    setting = Setting(
        name="test",
        description="test description",
        default=True,
        env_var="TEST_ENV",
        ini_section="test_ini_section",
        ini_key="test_ini_key",
        yaml_key="test_yaml_key",
    )
    config_data.update_setting(setting)

    assert setting.name == config_data.get_setting(setting.name).name
    assert setting.default == config_data.get_setting(setting.name, InventoryPlugin()).default
    assert setting.value

# Generated at 2022-06-20 13:38:19.629558
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    cd = ConfigData()
    plugin = Plugin('name', 'type')
    cd.update_setting(Setting('setting_name', 'setting_value', plugin))
    assert cd.get_setting('setting_name', plugin) == Setting('setting_name', 'setting_value', plugin)


# Generated at 2022-06-20 13:38:27.372160
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
        config_data = ConfigData()
        config_data.update_setting(Setting('setting1', '1'))
        config_data.update_setting(Setting('setting2', '2'))
        config_data.update_setting(Setting('setting3', '3'))
        config_data.update_setting(Setting('setting4', '4'), Plugin('role', 'role_a'))
        config_data.update_setting(Setting('setting5', '5'), Plugin('role', 'role_a'))
        config_data.update_setting(Setting('setting6', '6'), Plugin('role', 'role_b'))
        config_data.update_setting(Setting('setting7', '7'), Plugin('module', 'module_a'))

# Generated at 2022-06-20 13:38:30.740627
# Unit test for constructor of class ConfigData
def test_ConfigData():
    configdata = ConfigData()
    assert len(configdata._global_settings) == 0
    assert len(configdata._plugins) == 0


# Generated at 2022-06-20 13:38:37.556666
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    data = ConfigData()

    section_variable_setting = SectionVariableSetting(
        'playbook', 'play.yml', 'localhost', 'MyVar', 'foo', 'ansible', 'vault')

    data.update_setting(section_variable_setting)

    assert data.get_setting('MyVar') is not None
    assert data.get_setting('MyVar').name == 'MyVar'
    assert data.get_setting('MyVar').value == 'foo'



# Generated at 2022-06-20 13:38:49.995669
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()



# Generated at 2022-06-20 13:38:57.154365
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from collections import namedtuple
    from ansible.config.setting import Setting

    Plugin = namedtuple('Plugin', ['type', 'name'])

    config_data = ConfigData()

    setting = Setting('test_setting')
    config_data.update_setting(setting)

    plugin = Plugin(type='test_type', name='test_name')
    setting = Setting('test_setting')
    config_data.update_setting(setting, plugin=plugin)

    assert config_data.get_setting('test_setting') == setting
    assert config_data.get_setting('test_setting', plugin=plugin) == setting

# Generated at 2022-06-20 13:39:00.814954
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    configData = ConfigData()
    setting = ('SECTION1', 'SECTION2', 'KEY1', 'KEY2', 'VALUE1', 'VALUE2')
    configData.update_setting(setting, None)
    value = configData.get_setting('KEY1', None)
    assert value == 'VALUE1'

# Generated at 2022-06-20 13:39:05.298728
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    setting = Setting("log_path", "my_log_path")
    config_data = ConfigData()
    config_data.update_setting(setting)
    assert config_data.get_setting("log_path").value == 'my_log_path'

# Generated at 2022-06-20 13:39:15.828944
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config = ConfigData()

    # No global setting, no plugin setting
    assert config.get_setting('foo') is None

    # Global setting, no plugin setting
    config.update_setting(ConfigSetting(name='foo', value='global_setting'))
    assert config.get_setting('foo') is not None
    assert config.get_setting('foo').value == 'global_setting'

    # Global setting, plugin setting
    from collections import namedtuple
    Plugin = namedtuple('Plugin', ['name', 'type'])
    plugin = Plugin(type='p1_type', name='p1_name')
    config.update_setting(ConfigSetting(name='foo', value='p1_type_p1_name_setting'), plugin=plugin)
    assert config.get_setting('foo') is not None
    assert config.get_

# Generated at 2022-06-20 13:39:23.865444
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    # Create a ConfigData object
    config_data = ConfigData()
    # Update a setting of plugin_type 'test_plugin_type' with plugin_name 'test_plugin_name'
    config_data.update_setting(Setting('test_plugin_type', 'test_plugin_name', 'test_setting'))
    # Update a setting of plugin_type 'test_plugin_type' with plugin_name 'test_plugin_name1'
    config_data.update_setting(Setting('test_plugin_type', 'test_plugin_name1', 'test_setting'))
    # Update a setting of plugin_type 'test_plugin_type1' with plugin_name 'test_plugin_name'
    config_data.update_setting(Setting('test_plugin_type1', 'test_plugin_name', 'test_setting'))
   

# Generated at 2022-06-20 13:39:33.762590
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    #Test for global setting, should not be in plugins by any chance
    config_data = ConfigData()
    global_setting = {}
    global_setting['name'] = 'key'
    global_setting['value'] = 'value'
    global_setting['plugin_name'] = None
    config_data.update_setting(global_setting)
    assert config_data._global_settings['key'] == 'value'
    assert config_data._plugins == {}

    #Test for plugin setting
    config_data = ConfigData()
    plugin_setting = {}
    plugin_setting['name'] = 'key'
    plugin_setting['value'] = 'value'
    plugin_setting['plugin_name'] = 'PluginTests.test_plugins.test_plugin.TestPlugin'

    config_data.update_setting(plugin_setting)

# Generated at 2022-06-20 13:39:35.225639
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    pass

# Generated at 2022-06-20 13:39:35.888658
# Unit test for constructor of class ConfigData
def test_ConfigData():
    c = ConfigData()
    assert c is not None



# Generated at 2022-06-20 13:39:39.116413
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    configdata = ConfigData()

    #Case1: test for global setting
    setting = configdata.get_setting('modified_variables_layout', None)
    assert setting.name == 'modified_variables_layout'
    assert setting.value == 'nested'

    #Case2: test for plugin.type = "callback"
    setting = configdata.get_setting('stdout', 'callback')
    assert setting.name == 'stdout'
    assert setting.value == 'json'


# Generated at 2022-06-20 13:39:48.676406
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    assert config.get_setting("pipeline_functional", "pipeline_functional") == None

# Generated at 2022-06-20 13:40:02.080053
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.cli.collections.config_data.config_data_setting import ConfigDataSetting

    config_data = ConfigData()

    cd_setting = ConfigDataSetting(name='test1', value='foo')
    config_data.update_setting(cd_setting)

    cd_setting = ConfigDataSetting(name='test2', value='bar')
    config_data.update_setting(cd_setting, plugin=None)

    cd_setting = ConfigDataSetting(name='test3', value='baz')
    config_data.update_setting(cd_setting, plugin=None)

    for key in config_data._global_settings:
        assert config_data._global_settings[key].name == key


# Generated at 2022-06-20 13:40:09.469490
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Create config data object
    config_data = ConfigData()

    # Create plugin objects
    plugin_1 = Plugin("Module", "test")
    plugin_2 = Plugin("Module", "test_2")

    # Create setting objects
    setting_1 = Setting("key_1", "value_1")
    setting_2 = Setting("key_2", "value_2")
    setting_3 = Setting("key_3", "value_3")

    # Test adding one global setting
    config_data.update_setting(setting_1)
    assert setting_1 in config_data.get_settings()

    # Test adding one setting for two plugins
    config_data.update_setting(setting_2, plugin_1)
    config_data.update_setting(setting_2, plugin_2)
    assert setting_2 in config_data

# Generated at 2022-06-20 13:40:19.504847
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    data = ConfigData()

    # Test
    data.update_setting('user')
    data.update_setting('host_key_checking', 'paramiko')

    assert(data.get_setting('user') == 'user')
    assert(data.get_setting('host_key_checking', 'paramiko') == 'host_key_checking')
    assert(data.get_setting('host_key_checking', 'cryptography') == None)

# Generated at 2022-06-20 13:40:22.922561
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = {'name': 'value'}
    plugin = {'type': 'type', 'name': 'name'}
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['type']['name']['value'] == {'name': 'value'}
    assert config_data._global_settings == {}


# Generated at 2022-06-20 13:40:31.348402
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    import collections
    import pytest
    from units.compat.mock import patch, Mock

    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils._text import to_bytes

    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager

    from ansible.plugins.loader import get_all_plugin_loaders

    from ansible.utils.display import Display

    from ansible.utils.vault import VaultLib

# Generated at 2022-06-20 13:40:36.553937
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    # No global plugin
    assert config_data.get_settings() == []

    setting = object()
    config_data._global_settings = {'a': setting}

    # Check global plugin
    assert config_data.get_settings() == [setting]


# Generated at 2022-06-20 13:40:44.578773
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    # Test case 1
    config_data = ConfigData()
    config_data.update_setting(Setting('ansible_connection', 'ssh', 'local'))
    config_data.update_setting(Setting('ansible_python_interpreter', '/usr/bin/python3', 'local'))
    assert config_data.get_setting('ansible_connection').name == 'ansible_connection'
    assert config_data.get_setting('ansible_python_interpreter').name == 'ansible_python_interpreter'

    # Test case 2
    config_data = ConfigData()
    config_data.update_setting(Setting('ansible_connection', 'ssh', 'local'))
    config_data.update_setting(Setting('ansible_python_interpreter', '/usr/bin/python3', 'local'))

# Generated at 2022-06-20 13:40:58.137913
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible import constants as const

    config_data = ConfigData()

    # Add a global setting but ensure that it isn't returned by get_settings(plugin)
    setting = const.ConfigSetting('deprecation_warnings', 'deprecation_warnings', 'bool', 'DEFAULT_DEPRECATION_WARNINGS',
                                  'Whether to warn when running deprecated modules', default_value=True, const_value=True)
    config_data.update_setting(setting)

    settings = config_data.get_settings(plugin=None)
    assert len(settings) == 1
    assert settings[0].name == 'deprecation_warnings'

    settings = config_data.get_settings(plugin=const.Plugin('become', 'sudo'))
    assert len(settings) == 0

    # Now add a setting for the sudo become

# Generated at 2022-06-20 13:41:00.398259
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    data = ConfigData()
    assert (type(data.get_settings()) == list)
    assert (data.get_settings() == [])


# Generated at 2022-06-20 13:41:17.534235
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    print("config is:")
    print(config)
    print("config._global_settings is:")
    print(config._global_settings)
    print("config._plugins is:")
    print(config._plugins)
    print("config.get_setting('display_failed_stderr') is:")
    print(config.get_setting('display_failed_stderr'))
    print("config.get_setting('display_failed_stderr','shell') is:")
    print(config.get_setting('display_failed_stderr','shell'))
    print("config.get_setting('display_failed_stderr','test') is:")
    print(config.get_setting('display_failed_stderr','test'))

test_ConfigData_get_setting()

# Generated at 2022-06-20 13:41:27.486969
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    c = ConfigData()
    assert c.get_settings() == []
    s = Setting()
    c.update_setting(s)
    assert c.get_settings() == [s]
    p = Plugin()
    p.type = 'Inventory'
    p.name = 'hosts'
    assert c.get_settings(p) == []
    c.update_setting(s, p)
    assert c.get_settings(p) == [s]


# Generated at 2022-06-20 13:41:35.635627
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    # GIVEN
    config_data = ConfigData()
    # WHEN
    setting = Setting('test_setting')
    plugin = Plugin('test_plugin')
    config_data.update_setting(setting)
    config_data.update_setting(setting, plugin)
    # THEN
    assert config_data.get_setting('test_setting', None) == setting
    assert config_data.get_setting('test_setting', plugin) == setting
    assert config_data.get_settings(None) == [setting]
    assert config_data.get_settings(plugin) == [setting]



# Generated at 2022-06-20 13:41:48.488616
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config = ConfigData()
    setting1 = config.update_setting({"plugin": None, "name": "foo", "value": "bar"})
    setting2 = config.update_setting({"plugin": None, "name": "foo", "value": "foo"})
    assert setting1 == setting2
    setting3 = config.update_setting({"plugin": "CLI", "name": "foo", "value": "bar"}, "CLI")
    setting4 = config.update_setting({"plugin": "CLI", "name": "foo", "value": "foo"}, "CLI")
    assert setting3 == setting4
    setting5 = config.update_setting({"plugin": "CLI", "name": "foo", "value": "bar"}, ["CLI"])

# Generated at 2022-06-20 13:42:01.396124
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    
    def test_ConfigData_get_settings_none():
        config_data = ConfigData()
        config_data._global_settings = {}
        
        assert config_data.get_settings() == []

    def test_ConfigData_get_settings_global():
        setting1 = Setting('setting1', DEFAULT, 'global')
        setting2 = Setting('setting2', DEFAULT, 'global')
        setting3 = Setting('setting3', DEFAULT, 'global')
        setting4 = Setting('setting4', DEFAULT, 'global')

        settings = [setting1, setting2, setting3, setting4]

        config_data = ConfigData()
        config_data._global_settings = settings

        assert config_data.get_settings() == settings        

    def test_ConfigData_get_settings_plugin():

        setting1 = Setting

# Generated at 2022-06-20 13:42:11.404206
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    # Create a ConfigData object
    cd = ConfigData()

    # Add a global setting
    setting1 = ConfigSetting(name='host_key_checking', value='False')
    cd.update_setting(setting1)

    # Add a setting specific to a plugin
    setting2 = ConfigSetting(name='host_key_checking', value='True')
    plugin = Plugin(type='connection', name='local')
    cd.update_setting(setting2, plugin=plugin)

    # Retrieve all settings
    settings = cd.get_settings()

    # Make sure there are 2 settings
    assert len(settings) == 2

    # Make sure the settings have the right values
    assert settings[0].name == 'host_key_checking'
    assert settings[0].value == 'False'

# Generated at 2022-06-20 13:42:19.839535
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    from ansible.module_utils.ansible_release import __version__ as current_version

    config = ConfigData()
    config.update_setting(Setting('callback_whitelist', 'stdout,debug'))
    config.update_setting(Setting('retry_files_enabled', True))
    config.update_setting(Setting('bin_ansible_callbacks', False))
    config.update_setting(Setting('retries', 5))

    config.update_setting(Setting('sudo_user', 'root', Plugin('connection', 'local')))
    config.update_setting(Setting('remote_user', 'user', Plugin('connection', 'ssh')))
    config.update_setting(Setting('force_color', True, Plugin('callback', 'minimal')))


# Generated at 2022-06-20 13:42:23.390692
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    import ansible.module_utils.config_data_removed_in_20
    config_data = ansible.module_utils.config_data_removed_in_20.ConfigData()
    config_data.update_setting('test')


# Generated at 2022-06-20 13:42:26.499856
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    my_data = ConfigData()
    assert my_data.get_setting("foo") is None
    setting1 = Setting("foo", "bar")
    my_data.update_setting(setting1)
    assert my_data.get_setting("foo") == setting1
    assert my_data.get_setting("bar") is None

# Generated at 2022-06-20 13:42:29.483224
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    xxx = ConfigData()
    assert xxx.get_setting(name="a", plugin=None) is None


# Generated at 2022-06-20 13:42:50.923221
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    configdata = ConfigData()
    setting = Setting(name='test_setting1', value='1', origin='origin1', level='plugin')
    plugin = Plugin(name='test_plugin', type='test_type')
    plugin2 = Plugin(name='test_plugin2', type='test_type2')
    configdata.update_setting(setting, plugin)
    setting2 = Setting(name='test_setting2', value='2', origin='origin2', level='global')
    configdata.update_setting(setting2)
    setting3 = Setting(name='test_setting2', value='2', origin='origin2', level='plugin')
    configdata.update_setting(setting3, plugin2)
    settings = configdata.get_settings()
    assert setting2 in settings
    assert setting3 not in settings
    assert setting not in settings

# Generated at 2022-06-20 13:42:54.256424
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('my_setting') == None


# Generated at 2022-06-20 13:43:01.441960
# Unit test for constructor of class ConfigData
def test_ConfigData():
    config_data = ConfigData()
    if config_data._global_settings:
        assert False, "ConfigData constructor should initialize global settings to an empty dict."
    if config_data._plugins:
        assert False, "ConfigData constructor should initialize plugins to an empty dict."


# Generated at 2022-06-20 13:43:06.576135
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='ansible_host', value='1'))

    assert config_data.get_setting('ansible_host')
    assert config_data.get_setting('ansible_host').value == '1'

