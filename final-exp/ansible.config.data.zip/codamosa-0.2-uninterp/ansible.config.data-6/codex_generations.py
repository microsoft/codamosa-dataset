

# Generated at 2022-06-16 20:23:03.525615
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:23:07.294352
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:12.500534
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    config_data.update_setting(Setting('foo', 'baz'))
    assert config_data.get_setting('foo') == Setting('foo', 'baz')


# Generated at 2022-06-16 20:23:15.650966
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:17.816291
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:19.652569
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:23:22.829041
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    assert config_data.get_setting('bar') is None


# Generated at 2022-06-16 20:23:28.733929
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    config_data.update_setting(Setting('foo', 'quux'), Plugin('foo', 'bar'))

    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    assert config_data.get_setting('baz') == Setting('baz', 'qux')
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) == Setting('foo', 'quux')
    assert config_data.get_setting('baz', Plugin('foo', 'bar')) is None


# Generated at 2022-06-16 20:23:32.107921
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') == None
    assert config_data.get_setting('foo', 'bar') == None


# Generated at 2022-06-16 20:23:38.513598
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    config_data.update_setting(Setting('setting2', 'value2'))
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    config_data.update_setting(Setting('setting1', 'value3'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value3')


# Generated at 2022-06-16 20:23:52.082284
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'))
    config_data.update_setting(Setting('setting5', 'value5'))
    config_data.update_setting(Setting('setting6', 'value6'))
    config_data.update_setting(Setting('setting7', 'value7'))
    config_data.update_setting(Setting('setting8', 'value8'))
    config_data.update_setting(Setting('setting9', 'value9'))

# Generated at 2022-06-16 20:23:57.681245
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')

    config_data.update_setting(Setting('foo', 'baz'), Plugin('foo', 'bar'))
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) == Setting('foo', 'baz')


# Generated at 2022-06-16 20:24:04.119458
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    assert config_data.get_setting('setting3') == None


# Generated at 2022-06-16 20:24:07.571086
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:12.179778
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_settings() == [setting]


# Generated at 2022-06-16 20:24:19.114225
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    assert config_data.get_setting('baz') == Setting('baz', 'qux')
    assert config_data.get_setting('quux') is None


# Generated at 2022-06-16 20:24:21.297050
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:25.333205
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:33.489132
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:24:35.081242
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:44.345624
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:47.867336
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == 'test_value'


# Generated at 2022-06-16 20:24:50.617716
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:58.964813
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'))
    config_data.update_setting(Setting('setting5', 'value5'))
    config_data.update_setting(Setting('setting6', 'value6'))
    config_data.update_setting(Setting('setting7', 'value7'))
    config_data.update_setting(Setting('setting8', 'value8'))
    config_data.update_setting(Setting('setting9', 'value9'))

# Generated at 2022-06-16 20:25:00.755781
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:08.209019
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    setting = ConfigSetting('foo', 'bar', 'baz')
    config_data.update_setting(setting)
    assert config_data._global_settings == {'foo': setting}
    assert config_data._plugins == {}

    plugin = Plugin('foo', 'bar')
    setting = ConfigSetting('foo', 'bar', 'baz')
    config_data.update_setting(setting, plugin)
    assert config_data._global_settings == {'foo': setting}
    assert config_data._plugins == {'foo': {'bar': {'foo': setting}}}



# Generated at 2022-06-16 20:25:11.650259
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('setting_name', 'setting_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('setting_name') == setting


# Generated at 2022-06-16 20:25:14.876838
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:25:17.907989
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin('test_type', 'test_name')
    setting = Setting('test_setting')
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings(plugin) == [setting]


# Generated at 2022-06-16 20:25:19.259468
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:31.693693
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:34.809924
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:36.645160
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:44.372405
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', Plugin('foo', 'bar')))
    config_data.update_setting(Setting('baz', 'qux', Plugin('foo', 'bar')))
    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings(Plugin('foo', 'bar'))) == 2


# Generated at 2022-06-16 20:25:47.251382
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='foo', value='bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting


# Generated at 2022-06-16 20:25:48.616622
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:51.017358
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:56.192749
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin('test_plugin', 'test_type')
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('test_setting', plugin) == setting


# Generated at 2022-06-16 20:26:07.454835
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))

# Generated at 2022-06-16 20:26:08.812353
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:32.462667
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:34.470645
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:39.318334
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.action import ActionBase

    config_data = ConfigData()

    # Test with no plugin
    assert config_data.get_settings() == []

    # Test with a plugin
    plugin = PluginLoader.get('action', 'ping')
    assert isinstance(plugin, ActionBase)
    assert config_data.get_settings(plugin) == []

# Generated at 2022-06-16 20:26:40.971717
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:47.073329
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('a', 'b', 'c'))
    config_data.update_setting(Setting('d', 'e', 'f'))
    config_data.update_setting(Setting('g', 'h', 'i'))
    assert len(config_data.get_settings()) == 3
    assert config_data.get_settings()[0].name == 'a'
    assert config_data.get_settings()[1].name == 'd'
    assert config_data.get_settings()[2].name == 'g'


# Generated at 2022-06-16 20:26:49.728239
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:53.965465
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert config_data.get_settings() == [Setting('foo', 'bar'), Setting('baz', 'qux')]


# Generated at 2022-06-16 20:27:02.647016
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test with no plugin
    assert config_data.get_setting('foo') is None

    # Test with a plugin
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.action import ActionBase
    plugin = PluginLoader.load_plugin(ActionBase, 'ping')
    assert config_data.get_setting('foo', plugin) is None

    # Test with a plugin and a global setting
    from ansible.config.setting import Setting
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting
    assert config_data.get_setting('foo', plugin) == setting

    # Test with a plugin and a plugin setting
    setting = Setting('foo', 'bar')
    config_data

# Generated at 2022-06-16 20:27:06.450290
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:11.549600
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') is not None
    assert config_data.get_setting('foo').name == 'foo'
    assert config_data.get_setting('foo').value == 'bar'


# Generated at 2022-06-16 20:27:54.800740
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:05.778733
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    config_data.update_setting(Setting('setting2', 'value2'), Plugin('type1', 'name1'))
    assert config_data.get_setting('setting2', Plugin('type1', 'name1')) == Setting('setting2', 'value2')
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('type1', 'name2'))
    assert config_data.get_setting('setting3', Plugin('type1', 'name2')) == Setting('setting3', 'value3')

# Generated at 2022-06-16 20:28:08.850166
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:11.942236
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:28:18.688695
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data._global_settings['foo'].name == 'foo'
    assert config_data._global_settings['foo'].value == 'bar'
    config_data.update_setting(Setting('foo', 'baz'), Plugin('foo', 'bar'))
    assert config_data._plugins['foo']['bar']['foo'].name == 'foo'
    assert config_data._plugins['foo']['bar']['foo'].value == 'baz'


# Generated at 2022-06-16 20:28:21.899071
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:26.450509
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('setting_name', 'setting_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('setting_name') == setting


# Generated at 2022-06-16 20:28:34.539332
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo2', 'bar2'))
    config_data.update_setting(Setting('foo3', 'bar3'))
    config_data.update_setting(Setting('foo4', 'bar4'))
    config_data.update_setting(Setting('foo5', 'bar5'))
    config_data.update_setting(Setting('foo6', 'bar6'))
    config_data.update_setting(Setting('foo7', 'bar7'))
    config_data.update_setting(Setting('foo8', 'bar8'))
    config_data.update_setting(Setting('foo9', 'bar9'))

# Generated at 2022-06-16 20:28:37.606532
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:39.294487
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:52.195088
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:29:54.966036
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:05.270226
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test with plugin = None
    setting = config_data.get_setting('foo')
    assert setting is None

    # Test with plugin = None
    config_data.update_setting(Setting('foo', 'bar'))
    setting = config_data.get_setting('foo')
    assert setting.name == 'foo'
    assert setting.value == 'bar'

    # Test with plugin = None
    setting = config_data.get_setting('bar')
    assert setting is None

    # Test with plugin = None
    config_data.update_setting(Setting('bar', 'foo'))
    setting = config_data.get_setting('bar')
    assert setting.name == 'bar'
    assert setting.value == 'foo'

    # Test with plugin = None
    setting = config_data

# Generated at 2022-06-16 20:30:09.002328
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:18.114321
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.connection import ConnectionBase

    config_data = ConfigData()

    # Test for global setting
    setting = config_data.get_setting('ANSIBLE_CONFIG')
    assert setting is None

    # Test for plugin setting
    plugin = PluginLoader.get('connection', 'local')
    setting = config_data.get_setting('ANSIBLE_CONNECTION_TIMEOUT', plugin)
    assert setting is None

    # Test for non-existent plugin setting
    plugin = PluginLoader.get('connection', 'non-existent')
    setting = config_data.get_setting('ANSIBLE_CONNECTION_TIMEOUT', plugin)
    assert setting is None


# Generated at 2022-06-16 20:30:20.742742
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:27.027229
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin1', 'type2'))

# Generated at 2022-06-16 20:30:29.578720
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:31.110690
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:30:34.352390
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    assert config_data.get_settings(plugin=None) == []
    assert config_data.get_settings(plugin=Plugin('foo', 'bar')) == []
