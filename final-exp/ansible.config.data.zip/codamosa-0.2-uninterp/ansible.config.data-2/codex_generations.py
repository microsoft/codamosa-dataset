

# Generated at 2022-06-16 20:23:10.435089
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = Setting('test', 'test', 'test')
    config_data.update_setting(setting)
    assert len(config_data.get_settings()) == 1
    assert config_data.get_settings()[0].name == 'test'
    assert config_data.get_settings()[0].value == 'test'
    assert config_data.get_settings()[0].plugin == 'test'


# Generated at 2022-06-16 20:23:13.275866
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:20.453558
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin1', 'type2'))

# Generated at 2022-06-16 20:23:21.996669
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:23:28.636198
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'))
    config_data.update_setting(Setting('setting5', 'value5'))
    config_data.update_setting(Setting('setting6', 'value6'))
    config_data.update_setting(Setting('setting7', 'value7'))
    config_data.update_setting(Setting('setting8', 'value8'))
    config_data.update_setting(Setting('setting9', 'value9'))

# Generated at 2022-06-16 20:23:38.238637
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin2', 'plugin_type2'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'plugin_type1'))

    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    assert config_data.get_setting

# Generated at 2022-06-16 20:23:41.248734
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:43.229009
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:45.049905
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:46.849711
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:23:56.274878
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    config_data.update_setting(Setting('setting2', 'value2'))
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    config_data.update_setting(Setting('setting1', 'value3'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value3')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')


# Generated at 2022-06-16 20:23:59.905914
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:11.811807
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()

    # Test with no plugin
    assert config_data.get_settings() == []

    # Test with a plugin
    plugin = PluginLoader.get('action', 'pause')
    assert config_data.get_settings(plugin) == []

    # Test with a plugin and a setting
    setting = plugin.get_option('seconds')
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings(plugin) == [setting]

    # Test with a plugin and a setting
    setting = plugin.get_option('seconds')
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings(plugin) == [setting]

    # Test with a plugin and a setting
    setting = plugin.get

# Generated at 2022-06-16 20:24:15.713390
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar', 'baz')


# Generated at 2022-06-16 20:24:18.965897
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:21.249697
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:26.443450
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin('test_plugin', 'test_type')
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings(plugin) == [setting]


# Generated at 2022-06-16 20:24:34.139386
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', Plugin('test', 'test')))
    config_data.update_setting(Setting('baz', 'qux', Plugin('test', 'test')))
    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings(Plugin('test', 'test'))) == 2


# Generated at 2022-06-16 20:24:38.581822
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:24:48.843748
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting_1', 'value_1'))
    config_data.update_setting(Setting('setting_2', 'value_2'))
    config_data.update_setting(Setting('setting_3', 'value_3'))
    config_data.update_setting(Setting('setting_4', 'value_4'), Plugin('plugin_1', 'type_1'))
    config_data.update_setting(Setting('setting_5', 'value_5'), Plugin('plugin_1', 'type_1'))
    config_data.update_setting(Setting('setting_6', 'value_6'), Plugin('plugin_2', 'type_1'))

# Generated at 2022-06-16 20:24:56.829688
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:06.715538
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('a', 'b'))
    config_data.update_setting(Setting('c', 'd'))
    config_data.update_setting(Setting('e', 'f'))
    config_data.update_setting(Setting('g', 'h'))
    config_data.update_setting(Setting('i', 'j'))
    config_data.update_setting(Setting('k', 'l'))
    config_data.update_setting(Setting('m', 'n'))
    config_data.update_setting(Setting('o', 'p'))
    config_data.update_setting(Setting('q', 'r'))
    config_data.update_setting(Setting('s', 't'))

# Generated at 2022-06-16 20:25:10.950987
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_settings()[0].name == 'test_setting'
    assert config_data.get_settings()[0].value == 'test_value'


# Generated at 2022-06-16 20:25:13.951333
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    configData = ConfigData()
    configData.update_setting(Setting('foo', 'bar'))
    assert configData.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:16.146752
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    assert config_data.get_settings(plugin=None) == []


# Generated at 2022-06-16 20:25:25.651455
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'plugin_type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin2', 'plugin_type2'))
    config_data.update

# Generated at 2022-06-16 20:25:29.595976
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin3', 'type2'))

# Generated at 2022-06-16 20:25:32.886351
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:36.406658
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test', 'test', 'test', 'test')
    config_data.update_setting(setting)
    assert config_data._global_settings['test'] == setting


# Generated at 2022-06-16 20:25:46.830427
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Test with no plugin
    assert len(config_data.get_settings()) == 0

    # Test with a plugin
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader('cache', 'memory', '', '', '', '', '')
    assert len(config_data.get_settings(plugin)) == 0

    # Test with a plugin and a setting
    from ansible.config.setting import Setting
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting, plugin)
    assert len(config_data.get_settings(plugin)) == 1
    assert config_data.get_settings(plugin)[0].name == 'foo'
    assert config_data.get_settings(plugin)[0].value == 'bar'


# Generated at 2022-06-16 20:25:54.626035
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='test_setting', value='test_value'))
    assert config_data.get_setting('test_setting') == Setting(name='test_setting', value='test_value')


# Generated at 2022-06-16 20:26:05.192511
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))

# Generated at 2022-06-16 20:26:13.398280
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'))
    config_data.update_setting(Setting('setting5', 'value5'))
    config_data.update_setting(Setting('setting6', 'value6'))
    config_data.update_setting(Setting('setting7', 'value7'))
    config_data.update_setting(Setting('setting8', 'value8'))
    config_data.update_setting(Setting('setting9', 'value9'))

# Generated at 2022-06-16 20:26:16.139232
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("foo", "bar"))
    assert config_data.get_setting("foo") == Setting("foo", "bar")


# Generated at 2022-06-16 20:26:18.770350
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:26:21.742525
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', 'bar') is None


# Generated at 2022-06-16 20:26:23.827823
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:26.614453
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting


# Generated at 2022-06-16 20:26:32.120994
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:35.197656
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:42.696290
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:44.161844
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:45.735713
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:48.031306
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', 'bar') is None


# Generated at 2022-06-16 20:26:51.658130
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:54.509343
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:57.238451
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:02.394175
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('setting1', 'value1')
    config_data.update_setting(setting)
    assert config_data.get_setting('setting1') == setting
    plugin = Plugin('plugin1', 'type1')
    setting = Setting('setting2', 'value2')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('setting2', plugin) == setting


# Generated at 2022-06-16 20:27:13.631958
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin2', 'type1'))

# Generated at 2022-06-16 20:27:16.021874
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:27:21.985042
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:27:25.382301
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:27.967997
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='foo', value='bar'))
    assert config_data.get_setting('foo') == Setting(name='foo', value='bar')


# Generated at 2022-06-16 20:27:32.958236
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:44.049144
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'))
    config_data.update_setting(Setting('setting5', 'value5'))
    config_data.update_setting(Setting('setting6', 'value6'))
    config_data.update_setting(Setting('setting7', 'value7'))
    config_data.update_setting(Setting('setting8', 'value8'))
    config_data.update_setting(Setting('setting9', 'value9'))

# Generated at 2022-06-16 20:27:45.761999
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:27:49.911303
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') is not None
    assert config_data.get_setting('foo').name == 'foo'
    assert config_data.get_setting('foo').value == 'bar'


# Generated at 2022-06-16 20:27:52.931218
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:54.940228
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:58.298140
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:16.682712
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin1', 'type2'))

# Generated at 2022-06-16 20:28:19.254342
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:28:23.869278
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_settings()[0].name == 'test_setting'
    assert config_data.get_settings()[0].value == 'test_value'


# Generated at 2022-06-16 20:28:27.788544
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:30.395171
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:33.933413
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:36.995832
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:42.542796
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    settings = config_data.get_settings()
    assert len(settings) == 2
    assert settings[0].name == 'foo'
    assert settings[0].value == 'bar'
    assert settings[1].name == 'baz'
    assert settings[1].value == 'qux'


# Generated at 2022-06-16 20:28:54.047492
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin2', 'type1'))

# Generated at 2022-06-16 20:28:57.074352
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:19.745838
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:22.107115
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == 'bar'


# Generated at 2022-06-16 20:29:24.853344
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:30.766592
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    config_data.update_setting(Setting('foo', 'baz'), Plugin('foo', 'bar'))
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) == Setting('foo', 'baz')


# Generated at 2022-06-16 20:29:34.519216
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2


# Generated at 2022-06-16 20:29:37.250570
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:45.297212
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting('setting1')
    assert config_data.get_setting('setting1') == 'setting1'
    config_data.update_setting('setting2')
    assert config_data.get_setting('setting2') == 'setting2'
    config_data.update_setting('setting3')
    assert config_data.get_setting('setting3') == 'setting3'
    config_data.update_setting('setting4')
    assert config_data.get_setting('setting4') == 'setting4'
    config_data.update_setting('setting5')
    assert config_data.get_setting('setting5') == 'setting5'
    config_data.update_setting('setting6')

# Generated at 2022-06-16 20:29:48.347170
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:52.482983
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:56.760707
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting
    plugin = Plugin('foo', 'bar')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('foo', plugin) == setting


# Generated at 2022-06-16 20:30:38.986533
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:30:41.479543
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:30:43.648489
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:48.353376
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("foo", "bar"))
    assert config_data.get_setting("foo") == Setting("foo", "bar")


# Generated at 2022-06-16 20:30:57.157246
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):

        def run(self, tmp=None, task_vars=None):
            return super(ActionBase, self).run(tmp, task_vars)

    class TestPlugin(object):

        type = 'action'
        name = 'test'

    config_data = ConfigData()

    plugin_loader = PluginLoader(config_data, 'action', 'test')
    plugin_loader._add_directory('./')
    plugin_loader._find_plugins()
    plugin_loader._load_plugins()

    plugin = TestPlugin()
    plugin_loader._plugins[plugin.type][plugin.name] = TestAction

    assert len(config_data.get_settings(plugin)) == 0

    config_

# Generated at 2022-06-16 20:31:04.291152
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'plugin_type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'plugin_type1'))

# Generated at 2022-06-16 20:31:05.959373
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:31:12.004213
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    config_data.update_setting(Setting('setting2', 'value2'))
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    config_data.update_setting(Setting('setting1', 'value3'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value3')


# Generated at 2022-06-16 20:31:23.034371
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3', Plugin('plugin1', 'plugin_type1')))
    config_data.update_setting(Setting('setting4', 'value4', Plugin('plugin2', 'plugin_type1')))
    config_data.update_setting(Setting('setting5', 'value5', Plugin('plugin3', 'plugin_type2')))
    config_data.update_setting(Setting('setting6', 'value6', Plugin('plugin4', 'plugin_type2')))

    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')

# Generated at 2022-06-16 20:31:26.037813
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
