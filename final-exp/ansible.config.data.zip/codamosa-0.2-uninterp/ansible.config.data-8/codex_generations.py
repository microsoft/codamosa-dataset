

# Generated at 2022-06-16 20:23:01.324468
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:04.123258
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data._global_settings['foo'].value == 'bar'


# Generated at 2022-06-16 20:23:06.195395
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:10.334617
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='foo', value='bar'))
    assert config_data.get_setting('foo') == Setting(name='foo', value='bar')


# Generated at 2022-06-16 20:23:13.233035
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:14.857823
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:17.422768
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:18.994688
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:26.776594
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3', Plugin('plugin1', 'type1')))
    config_data.update_setting(Setting('setting4', 'value4', Plugin('plugin2', 'type2')))
    config_data.update_setting(Setting('setting5', 'value5', Plugin('plugin3', 'type3')))
    config_data.update_setting(Setting('setting6', 'value6', Plugin('plugin4', 'type4')))
    config_data.update_setting(Setting('setting7', 'value7', Plugin('plugin5', 'type5')))

# Generated at 2022-06-16 20:23:29.497020
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("foo", "bar"))
    assert config_data.get_setting("foo") == Setting("foo", "bar")


# Generated at 2022-06-16 20:23:34.939612
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:40.156611
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    config_data.update_setting(Setting('setting2', 'value2'), Plugin('plugin1', 'type1'))
    assert config_data.get_setting('setting2', Plugin('plugin1', 'type1')) == Setting('setting2', 'value2')
    assert config_data.get_setting('setting2') is None


# Generated at 2022-06-16 20:23:43.328809
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:53.229396
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'qux'))
    config_data.update_setting(Setting('baz', 'qux', 'baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings(Plugin('baz', 'qux'))) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[1].name == 'baz'

# Generated at 2022-06-16 20:23:56.305034
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_settings()[0].name == 'test_setting'
    assert config_data.get_settings()[0].value == 'test_value'


# Generated at 2022-06-16 20:23:59.896356
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:11.810361
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('type1', 'name1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('type1', 'name1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('type1', 'name1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('type2', 'name2'))

# Generated at 2022-06-16 20:24:14.050603
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:24.041904
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin1', 'type2'))

# Generated at 2022-06-16 20:24:25.823146
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:33.299936
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:35.955296
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:43.030228
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert config_data.get_settings() == [{'name': 'foo', 'value': 'bar'}, {'name': 'baz', 'value': 'qux'}]


# Generated at 2022-06-16 20:24:44.014849
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:48.599990
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:24:53.313345
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    assert len(config_data.get_settings()) == 3


# Generated at 2022-06-16 20:25:03.933989
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin1', 'type2'))

# Generated at 2022-06-16 20:25:07.018217
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting


# Generated at 2022-06-16 20:25:12.854046
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3', Plugin('plugin1', 'plugin_type1')))
    config_data.update_setting(Setting('setting4', 'value4', Plugin('plugin2', 'plugin_type2')))
    config_data.update_setting(Setting('setting5', 'value5', Plugin('plugin1', 'plugin_type1')))
    config_data.update_setting(Setting('setting6', 'value6', Plugin('plugin2', 'plugin_type2')))

# Generated at 2022-06-16 20:25:15.697910
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting


# Generated at 2022-06-16 20:25:26.432781
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:28.086702
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:31.977113
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:36.738844
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='foo', value='bar', origin='baz')
    plugin = Plugin(type='foo', name='bar')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['foo']['bar']['foo'] == setting


# Generated at 2022-06-16 20:25:47.206205
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    # Test 1: Update global setting
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')

    # Test 2: Update plugin setting
    config_data.update_setting(Setting('setting2', 'value2'), Plugin('plugin1', 'plugin_type1'))
    assert config_data.get_setting('setting2', Plugin('plugin1', 'plugin_type1')) == Setting('setting2', 'value2')

    # Test 3: Update global setting with same name as plugin setting
    config_data.update_setting(Setting('setting2', 'value3'))
    assert config_data.get_setting('setting2') == Setting('setting2', 'value3')

# Generated at 2022-06-16 20:25:49.733654
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:52.008269
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:54.121141
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:55.561661
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:26:00.545447
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert config_data.get_settings() == [Setting('foo', 'bar'), Setting('baz', 'qux')]


# Generated at 2022-06-16 20:26:21.010860
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:25.158246
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='foo', value='bar'))
    assert config_data.get_setting('foo') == Setting(name='foo', value='bar')
    assert config_data.get_setting('bar') is None


# Generated at 2022-06-16 20:26:27.736799
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:39.147307
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting_1', 'value_1'))
    assert config_data.get_setting('setting_1') == Setting('setting_1', 'value_1')
    config_data.update_setting(Setting('setting_1', 'value_2'))
    assert config_data.get_setting('setting_1') == Setting('setting_1', 'value_2')
    config_data.update_setting(Setting('setting_2', 'value_2'), Plugin('plugin_1', 'type_1'))
    assert config_data.get_setting('setting_2', Plugin('plugin_1', 'type_1')) == Setting('setting_2', 'value_2')

# Generated at 2022-06-16 20:26:47.302088
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin1', 'type2'))

# Generated at 2022-06-16 20:26:51.562126
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:54.408766
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:57.102727
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:58.699241
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:27:05.729696
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'))
    config_data.update_setting(Setting('setting5', 'value5'))
    config_data.update_setting(Setting('setting6', 'value6'))
    config_data.update_setting(Setting('setting7', 'value7'))
    config_data.update_setting(Setting('setting8', 'value8'))
    config_data.update_setting(Setting('setting9', 'value9'))

# Generated at 2022-06-16 20:27:38.852688
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == 'bar'


# Generated at 2022-06-16 20:27:42.872775
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:46.921455
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data._global_settings['foo'].name == 'foo'
    assert config_data._global_settings['foo'].value == 'bar'


# Generated at 2022-06-16 20:27:49.586120
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:00.952268
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting_1', 'value_1'))
    config_data.update_setting(Setting('setting_2', 'value_2'))
    config_data.update_setting(Setting('setting_3', 'value_3'))
    config_data.update_setting(Setting('setting_4', 'value_4'))
    config_data.update_setting(Setting('setting_5', 'value_5'))
    config_data.update_setting(Setting('setting_6', 'value_6'))
    config_data.update_setting(Setting('setting_7', 'value_7'))
    config_data.update_setting(Setting('setting_8', 'value_8'))

# Generated at 2022-06-16 20:28:06.029482
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:28:15.350384
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("setting_1", "value_1"))
    config_data.update_setting(Setting("setting_2", "value_2"))
    config_data.update_setting(Setting("setting_3", "value_3"), Plugin("plugin_1", "plugin_type_1"))
    config_data.update_setting(Setting("setting_4", "value_4"), Plugin("plugin_2", "plugin_type_2"))
    config_data.update_setting(Setting("setting_5", "value_5"), Plugin("plugin_1", "plugin_type_1"))

    assert config_data.get_setting("setting_1") == Setting("setting_1", "value_1")

# Generated at 2022-06-16 20:28:17.732589
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("foo", "bar"))
    assert config_data.get_setting("foo") == Setting("foo", "bar")


# Generated at 2022-06-16 20:28:20.943837
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:24.070003
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('name', 'value'))
    assert config_data.get_setting('name') == Setting('name', 'value')


# Generated at 2022-06-16 20:29:30.117173
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:33.353237
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:42.468512
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data._global_settings['foo'].value == 'bar'
    config_data.update_setting(Setting('foo', 'baz'))
    assert config_data._global_settings['foo'].value == 'baz'
    config_data.update_setting(Setting('foo', 'baz', Plugin('action', 'ping')))
    assert config_data._global_settings['foo'].value == 'baz'
    assert config_data._plugins['action']['ping']['foo'].value == 'baz'
    config_data.update_setting(Setting('foo', 'bar', Plugin('action', 'ping')))

# Generated at 2022-06-16 20:29:46.793604
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data._global_settings['test_setting'].name == 'test_setting'
    assert config_data._global_settings['test_setting'].value == 'test_value'


# Generated at 2022-06-16 20:29:51.187943
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:52.776835
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:29:54.581503
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:29:57.213655
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:59.003951
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:30:09.838439
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'))
    config_data.update_setting(Setting('setting5', 'value5'))
    config_data.update_setting(Setting('setting6', 'value6'))
    config_data.update_setting(Setting('setting7', 'value7'))
    config_data.update_setting(Setting('setting8', 'value8'))
    config_data.update_setting(Setting('setting9', 'value9'))

# Generated at 2022-06-16 20:32:57.019091
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'plugin_type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'plugin_type1'))