

# Generated at 2022-06-16 20:23:01.325998
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:04.491824
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')


# Generated at 2022-06-16 20:23:13.858178
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', Plugin('foo', 'bar')))
    config_data.update_setting(Setting('baz', 'qux', Plugin('foo', 'bar')))
    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings(Plugin('foo', 'bar'))) == 2
    assert len(config_data.get_settings(Plugin('foo', 'baz'))) == 0


# Generated at 2022-06-16 20:23:16.924655
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:19.724630
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:22.591376
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:23:24.766542
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:27.564788
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin('test', 'test')
    setting = Setting('test', 'test')
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings(plugin) == [setting]


# Generated at 2022-06-16 20:23:30.018924
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:34.196811
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    setting = Setting('name', 'value')
    config_data.update_setting(setting)
    assert config_data.get_setting('name') == setting


# Generated at 2022-06-16 20:23:49.175745
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting_1', 'value_1'))
    config_data.update_setting(Setting('setting_2', 'value_2'))
    config_data.update_setting(Setting('setting_3', 'value_3'), Plugin('plugin_1', 'plugin_type_1'))
    config_data.update_setting(Setting('setting_4', 'value_4'), Plugin('plugin_2', 'plugin_type_2'))

    assert config_data.get_setting('setting_1') == Setting('setting_1', 'value_1')
    assert config_data.get_setting('setting_2') == Setting('setting_2', 'value_2')

# Generated at 2022-06-16 20:23:54.979965
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {'a': 1, 'b': 2}
    config_data._plugins = {'c': {'d': {'e': 3, 'f': 4}}}
    assert config_data.get_settings() == [1, 2]
    assert config_data.get_settings(plugin=None) == [1, 2]
    assert config_data.get_settings(plugin='c') == []
    assert config_data.get_settings(plugin='c.d') == [3, 4]
    assert config_data.get_settings(plugin='c.d.e') == []


# Generated at 2022-06-16 20:23:58.844235
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:24:01.912427
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:03.748944
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:07.220458
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:09.372934
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:12.080309
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:22.994980
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('name1', 'value1'))
    config_data.update_setting(Setting('name2', 'value2'))
    config_data.update_setting(Setting('name3', 'value3'), Plugin('type1', 'name1'))
    config_data.update_setting(Setting('name4', 'value4'), Plugin('type1', 'name1'))
    config_data.update_setting(Setting('name5', 'value5'), Plugin('type2', 'name2'))
    config_data.update_setting(Setting('name6', 'value6'), Plugin('type2', 'name2'))

    assert config_data.get_setting('name1') == Setting('name1', 'value1')

# Generated at 2022-06-16 20:24:24.954298
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:35.320243
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:24:44.530767
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:24:52.159662
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:24:58.388350
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:25:00.355729
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:03.710624
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:06.783959
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:10.196079
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:25:13.032933
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:16.022037
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:44.189911
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type2'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin3', 'type3'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin4', 'type4'))

# Generated at 2022-06-16 20:25:45.970635
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:47.658786
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:54.317325
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    config_data.update_setting(Setting('setting2', 'value2'))
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    config_data.update_setting(Setting('setting1', 'value3'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value3')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')


# Generated at 2022-06-16 20:25:55.755010
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:25:58.708406
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:02.600270
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar', 'baz')


# Generated at 2022-06-16 20:26:05.805143
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:08.927326
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:11.105785
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:47.856481
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:50.601207
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:53.427581
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:02.213484
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting1 = Setting(name='setting1', value='value1')
    setting2 = Setting(name='setting2', value='value2')
    setting3 = Setting(name='setting3', value='value3')
    setting4 = Setting(name='setting4', value='value4')
    setting5 = Setting(name='setting5', value='value5')
    setting6 = Setting(name='setting6', value='value6')
    config_data.update_setting(setting1)
    config_data.update_setting(setting2)
    config_data.update_setting(setting3)
    config_data.update_setting(setting4, Plugin('type1', 'name1'))
    config_data.update_setting(setting5, Plugin('type1', 'name1'))
    config_

# Generated at 2022-06-16 20:27:11.660961
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:27:13.473704
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:21.809257
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    config_data.update_setting(Setting('test_setting2', 'test_value2'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'test_setting'
    assert config_data.get_settings()[1].name == 'test_setting2'


# Generated at 2022-06-16 20:27:23.780494
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:27:26.758139
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('name', 'value'))
    assert config_data.get_setting('name') == Setting('name', 'value')


# Generated at 2022-06-16 20:27:28.397860
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:28:35.268516
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:37.191050
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:28:45.297009
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'))
    config_data.update_setting(Setting('setting5', 'value5'))
    config_data.update_setting(Setting('setting6', 'value6'))
    config_data.update_setting(Setting('setting7', 'value7'))
    config_data.update_setting(Setting('setting8', 'value8'))
    config_data.update_setting(Setting('setting9', 'value9'))

# Generated at 2022-06-16 20:28:47.348051
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:49.318529
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:28:53.283030
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:55.049036
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:28:57.073334
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:29:00.185232
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:04.218074
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:31:35.745441
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3', Plugin('plugin_type', 'plugin_name')))
    config_data.update_setting(Setting('setting4', 'value4', Plugin('plugin_type', 'plugin_name')))

    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    assert config_data.get_setting('setting3') is None
    assert config_data.get_setting('setting4') is None
    assert config_data.get_

# Generated at 2022-06-16 20:31:37.037879
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-16 20:31:39.207116
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('name', 'value'))
    assert config_data.get_setting('name') == Setting('name', 'value')


# Generated at 2022-06-16 20:31:42.890725
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:31:46.109375
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == 'test_value'


# Generated at 2022-06-16 20:31:48.936469
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test with no plugin
    assert config_data.get_setting('foo') is None

    # Test with a plugin
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader('action', 'ping', '', '', '', '', '', '')
    assert config_data.get_setting('foo', plugin) is None


# Generated at 2022-06-16 20:31:50.452276
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:31:51.976464
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:31:59.989770
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting_1', 'test_value_1'))
    config_data.update_setting(Setting('test_setting_2', 'test_value_2'))
    config_data.update_setting(Setting('test_setting_3', 'test_value_3'))
    config_data.update_setting(Setting('test_setting_4', 'test_value_4'))
    config_data.update_setting(Setting('test_setting_5', 'test_value_5'))
    config_data.update_setting(Setting('test_setting_6', 'test_value_6'))
    config_data.update_setting(Setting('test_setting_7', 'test_value_7'))
    config_data.update_setting

# Generated at 2022-06-16 20:32:03.960883
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')
