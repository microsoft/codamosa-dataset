

# Generated at 2022-06-16 20:23:02.243738
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:12.411728
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test with no plugin
    setting = config_data.get_setting('foo')
    assert setting is None

    # Test with a plugin
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader('cache').get('memory')
    setting = config_data.get_setting('foo', plugin)
    assert setting is None

    # Test with a plugin and a setting
    from ansible.config.setting import Setting
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting, plugin)
    setting = config_data.get_setting('foo', plugin)
    assert setting.name == 'foo'
    assert setting.value == 'bar'


# Generated at 2022-06-16 20:23:17.494392
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test', 'test_value')
    plugin = Plugin('test_plugin', 'test_type')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['test_type']['test_plugin']['test'].name == 'test'
    assert config_data._plugins['test_type']['test_plugin']['test'].value == 'test_value'


# Generated at 2022-06-16 20:23:19.364293
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:23:21.876494
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == 'bar'


# Generated at 2022-06-16 20:23:28.557725
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Test with no plugin
    settings = config_data.get_settings()
    assert len(settings) == 0

    # Test with a plugin
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader('action', 'test', 'test_action', 'TestAction', 'test_action.py', 'TestAction', 'TestAction', 'test_action.py')
    settings = config_data.get_settings(plugin)
    assert len(settings) == 0

    # Test with a plugin and a global setting
    from ansible.config.setting import Setting
    setting = Setting('test_setting', 'test_value', 'test_description')
    config_data.update_setting(setting)
    settings = config_data.get_settings(plugin)
    assert len(settings) == 1


# Generated at 2022-06-16 20:23:36.754307
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test 1: Get a global setting
    setting = config_data.get_setting('ANSIBLE_CONFIG')
    assert setting is not None
    assert setting.name == 'ANSIBLE_CONFIG'
    assert setting.value == '/etc/ansible/ansible.cfg'

    # Test 2: Get a setting for a plugin
    setting = config_data.get_setting('host_key_checking', plugin=Plugin('connection', 'local'))
    assert setting is not None
    assert setting.name == 'host_key_checking'
    assert setting.value == 'False'


# Generated at 2022-06-16 20:23:40.470939
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("foo", "bar"))
    assert config_data.get_setting("foo") == Setting("foo", "bar")


# Generated at 2022-06-16 20:23:42.215601
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:23:44.241562
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:23:48.575402
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:50.490706
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:51.909593
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:55.356216
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name="test_setting", value="test_value"))
    assert config_data.get_setting(name="test_setting") == Setting(name="test_setting", value="test_value")


# Generated at 2022-06-16 20:24:06.667151
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3', Plugin('plugin1', 'plugin_type1')))
    config_data.update_setting(Setting('setting4', 'value4', Plugin('plugin1', 'plugin_type1')))
    config_data.update_setting(Setting('setting5', 'value5', Plugin('plugin2', 'plugin_type1')))
    config_data.update_setting(Setting('setting6', 'value6', Plugin('plugin2', 'plugin_type1')))

# Generated at 2022-06-16 20:24:10.011228
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("foo", "bar"))
    assert config_data.get_setting("foo") == Setting("foo", "bar")


# Generated at 2022-06-16 20:24:19.968548
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:24:22.617091
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:25.822672
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting


# Generated at 2022-06-16 20:24:27.844535
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:34.677717
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:36.144374
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:45.412891
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('name', 'value'))
    assert config_data._global_settings['name'].name == 'name'
    assert config_data._global_settings['name'].value == 'value'
    config_data.update_setting(Setting('name', 'value'), Plugin('type', 'name'))
    assert config_data._plugins['type']['name']['name'].name == 'name'
    assert config_data._plugins['type']['name']['name'].value == 'value'


# Generated at 2022-06-16 20:24:47.439057
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:50.986809
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='test_setting', value='test_value'))
    assert config_data.get_setting('test_setting') == Setting(name='test_setting', value='test_value')


# Generated at 2022-06-16 20:24:52.669874
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:54.288745
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:24:57.825965
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert config_data.get_settings() == [Setting('foo', 'bar'), Setting('baz', 'qux')]


# Generated at 2022-06-16 20:25:07.433280
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3', Plugin('plugin1', 'type1')))
    config_data.update_setting(Setting('setting4', 'value4', Plugin('plugin2', 'type2')))
    config_data.update_setting(Setting('setting5', 'value5', Plugin('plugin3', 'type3')))
    config_data.update_setting(Setting('setting6', 'value6', Plugin('plugin4', 'type4')))
    config_data.update_setting(Setting('setting7', 'value7', Plugin('plugin5', 'type5')))

# Generated at 2022-06-16 20:25:10.510052
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:20.582248
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:23.038517
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:24.379244
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:25.750555
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo').value == 'bar'


# Generated at 2022-06-16 20:25:37.017298
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))

# Generated at 2022-06-16 20:25:42.213144
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert config_data.get_settings() == []

    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))

    assert config_data.get_settings() == [Setting('foo', 'bar'), Setting('baz', 'qux')]



# Generated at 2022-06-16 20:25:51.322227
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='setting1', value='value1'))
    config_data.update_setting(Setting(name='setting2', value='value2'))
    config_data.update_setting(Setting(name='setting3', value='value3'), Plugin('type1', 'name1'))
    config_data.update_setting(Setting(name='setting4', value='value4'), Plugin('type2', 'name2'))

    assert config_data.get_setting('setting1') == Setting(name='setting1', value='value1')
    assert config_data.get_setting('setting2') == Setting(name='setting2', value='value2')

# Generated at 2022-06-16 20:25:54.353160
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:55.792338
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:57.566698
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:08.927847
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data._global_settings['foo'].value == 'bar'


# Generated at 2022-06-16 20:26:11.105865
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:14.127791
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:15.800082
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:20.915568
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2


# Generated at 2022-06-16 20:26:24.398969
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='foo', value='bar'))
    assert config_data.get_setting('foo') == Setting(name='foo', value='bar')


# Generated at 2022-06-16 20:26:26.272938
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    assert config_data.get_settings(None) == []
    assert config_data.get_settings(Plugin('test_type', 'test_name')) == []


# Generated at 2022-06-16 20:26:28.096903
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2


# Generated at 2022-06-16 20:26:34.032363
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    plugin = Plugin('test_plugin', 'test_type')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['test_type']['test_plugin']['test_setting'] == setting


# Generated at 2022-06-16 20:26:35.865335
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:26:46.804296
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:26:49.464265
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:51.822727
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:56.167679
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert config_data.get_settings() == [Setting('foo', 'bar'), Setting('baz', 'qux')]


# Generated at 2022-06-16 20:27:03.467569
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    config_data.update_setting(Setting('setting2', 'value2'))
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    config_data.update_setting(Setting('setting1', 'value3'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value3')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')


# Generated at 2022-06-16 20:27:11.348263
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Test with no plugin
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_settings() == [setting]

    # Test with plugin
    setting = Setting('test_setting', 'test_value')
    plugin = Plugin('test_plugin', 'test_type')
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings(plugin) == [setting]


# Generated at 2022-06-16 20:27:12.948199
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:27:17.485303
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting(name='setting1', value='value1'))
    config_data.update_setting(Setting(name='setting2', value='value2'))
    config_data.update_setting(Setting(name='setting3', value='value3'))
    config_data.update_setting(Setting(name='setting4', value='value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting(name='setting5', value='value5'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting(name='setting6', value='value6'), Plugin('plugin2', 'type1'))

# Generated at 2022-06-16 20:27:21.451941
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:24.814104
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:49.628451
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:27:54.482585
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('bar', 'baz'))
    config_data.update_setting(Setting('baz', 'foo'))
    assert len(config_data.get_settings()) == 3


# Generated at 2022-06-16 20:27:57.613640
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test', 'test', 'test')
    config_data.update_setting(setting)
    assert config_data._global_settings['test'] == setting


# Generated at 2022-06-16 20:27:59.575806
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:28:02.740554
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting


# Generated at 2022-06-16 20:28:04.295961
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:28:07.113607
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:16.269991
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'plugin_type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin2', 'plugin_type1'))
    config_data.update

# Generated at 2022-06-16 20:28:18.501249
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:21.683746
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:00.184933
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2


# Generated at 2022-06-16 20:29:02.757455
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:29:05.917784
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:14.474891
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin1', 'type2'))

# Generated at 2022-06-16 20:29:18.111885
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')


# Generated at 2022-06-16 20:29:20.748246
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:27.196132
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test for global setting
    setting = config_data.get_setting('default_module_name')
    assert setting is None

    # Test for plugin setting
    setting = config_data.get_setting('default_module_name', 'action')
    assert setting is None

    # Test for plugin setting
    setting = config_data.get_setting('default_module_name', 'action', 'copy')
    assert setting is None


# Generated at 2022-06-16 20:29:30.510605
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:29:34.008112
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')


# Generated at 2022-06-16 20:29:36.868245
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:15.061854
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:30:16.540068
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:30:23.883920
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='setting1', value='value1'))
    assert config_data._global_settings['setting1'].value == 'value1'
    assert config_data.get_setting('setting1').value == 'value1'
    assert config_data.get_settings()[0].value == 'value1'
    config_data.update_setting(Setting(name='setting2', value='value2'), Plugin(type='type1', name='name1'))
    assert config_data._plugins['type1']['name1']['setting2'].value == 'value2'
    assert config_data.get_setting('setting2', Plugin(type='type1', name='name1')).value == 'value2'
    assert config_data.get_settings

# Generated at 2022-06-16 20:30:26.182843
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data._global_settings['test_setting'] == setting


# Generated at 2022-06-16 20:30:30.012264
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert config_data.get_settings() == [Setting('foo', 'bar'), Setting('baz', 'qux')]


# Generated at 2022-06-16 20:30:32.596949
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:34.145114
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:30:35.465111
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:30:37.014437
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:30:38.429085
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:31:57.012918
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():

    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        pass

    action_plugin = PluginLoader('ActionModule', 'TestAction', TestAction, 'test_action')

    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value', action_plugin))
    assert config_data.get_setting('test_setting', action_plugin) is not None
    assert config_data.get_setting('test_setting', action_plugin).name == 'test_setting'
    assert config_data.get_setting('test_setting', action_plugin).value == 'test_value'
    assert config_data.get_setting('test_setting', action_plugin).plugin == action_plugin


# Generated at 2022-06-16 20:32:05.867964
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data._global_settings == {}
    assert config_data._plugins == {}

    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data._global_settings == {'test_setting': setting}
    assert config_data._plugins == {}

    plugin = Plugin('test_type', 'test_name')
    config_data.update_setting(setting, plugin)
    assert config_data._global_settings == {'test_setting': setting}
    assert config_data._plugins == {'test_type': {'test_name': {'test_setting': setting}}}



# Generated at 2022-06-16 20:32:08.719532
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:32:11.673679
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:32:19.773358
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    config_data.update_setting(Setting('quux', 'corge'), Plugin('test', 'test'))
    config_data.update_setting(Setting('grault', 'garply'), Plugin('test', 'test'))
    config_data.update_setting(Setting('waldo', 'fred'), Plugin('test', 'test'))

    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings(Plugin('test', 'test'))) == 3
    assert len(config_data.get_settings(Plugin('test', 'test2'))) == 0


# Generated at 2022-06-16 20:32:21.777799
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:32:23.655777
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:32:32.343070
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:32:33.549100
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:32:35.344904
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
