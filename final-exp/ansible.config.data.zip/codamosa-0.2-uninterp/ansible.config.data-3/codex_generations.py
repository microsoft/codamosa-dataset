

# Generated at 2022-06-16 20:23:01.287032
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('setting_name', 'setting_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('setting_name') == setting


# Generated at 2022-06-16 20:23:04.080700
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:12.715724
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('name1', 'value1'))
    config_data.update_setting(Setting('name2', 'value2'))
    assert config_data.get_setting('name1') == Setting('name1', 'value1')
    assert config_data.get_setting('name2') == Setting('name2', 'value2')
    assert config_data.get_setting('name3') is None
    assert config_data.get_settings() == [Setting('name1', 'value1'), Setting('name2', 'value2')]


# Generated at 2022-06-16 20:23:15.842806
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting


# Generated at 2022-06-16 20:23:17.457725
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:20.272543
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:26.456578
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test with no plugin
    assert config_data.get_setting('foo') is None

    # Test with plugin
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader('action', 'foo', 'test_plugins/action', 'TestActionModule')
    assert config_data.get_setting('foo', plugin) is None

    # Test with plugin and setting
    from ansible.config.setting import Setting
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('foo', plugin) == setting


# Generated at 2022-06-16 20:23:32.520384
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {'a': 'b'}
    config_data._plugins = {'c': {'d': {'e': 'f'}}}
    assert config_data.get_settings() == [{'a': 'b'}]
    assert config_data.get_settings('c', 'd') == [{'e': 'f'}]

# Generated at 2022-06-16 20:23:34.238188
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:36.679455
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:52.040658
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'qux'))
    config_data.update_setting(Setting('baz', 'qux', 'baz', 'qux'))
    config_data.update_setting(Setting('baz', 'qux', 'baz', 'qux'))
    config_data.update_setting(Setting('baz', 'qux', 'baz', 'qux'))
    assert len(config_data.get_settings()) == 2
   

# Generated at 2022-06-16 20:23:54.520970
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', 'bar') is None


# Generated at 2022-06-16 20:23:58.596333
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', 'bar') is None
    assert config_data.get_setting('foo', 'bar', 'baz') is None


# Generated at 2022-06-16 20:24:09.619462
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', plugin=None) is None
    assert config_data.get_setting('foo', plugin='bar') is None
    assert config_data.get_setting('foo', plugin='bar', type='baz') is None
    assert config_data.get_setting('foo', plugin='bar', type='baz', value='qux') is None
    assert config_data.get_setting('foo', plugin='bar', type='baz', value='qux', origin='quux') is None
    assert config_data.get_setting('foo', plugin='bar', type='baz', value='qux', origin='quux', cache=True) is None

# Generated at 2022-06-16 20:24:18.236041
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo', 'bar'), Plugin('test', 'test'))

    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    assert config_data.get_setting('foo', Plugin('test', 'test')) == Setting('foo', 'bar')
    assert config_data.get_setting('foo', Plugin('test', 'test2')) == None


# Generated at 2022-06-16 20:24:21.622224
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:24.204446
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:24:27.361428
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:30.619102
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:32.570359
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:39.652352
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:42.732393
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:44.292392
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:47.781493
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:24:50.528280
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:58.896680
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3', Plugin('plugin1', 'plugin_type1')))
    config_data.update_setting(Setting('setting4', 'value4', Plugin('plugin2', 'plugin_type1')))
    config_data.update_setting(Setting('setting5', 'value5', Plugin('plugin3', 'plugin_type2')))

    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    assert config_data.get_setting

# Generated at 2022-06-16 20:25:05.927820
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()

    # Test with a global setting
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting

    # Test with a plugin setting
    plugin = Plugin('test_plugin', 'test_type')
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('test_setting', plugin) == setting


# Generated at 2022-06-16 20:25:12.273965
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin3', 'type2'))

# Generated at 2022-06-16 20:25:21.624273
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('name1', 'value1'))
    config_data.update_setting(Setting('name2', 'value2'))
    config_data.update_setting(Setting('name3', 'value3'))
    assert config_data.get_setting('name1') == Setting('name1', 'value1')
    assert config_data.get_setting('name2') == Setting('name2', 'value2')
    assert config_data.get_setting('name3') == Setting('name3', 'value3')
    assert config_data.get_setting('name4') is None


# Generated at 2022-06-16 20:25:24.034836
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:44.004127
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'))
    config_data.update_setting(Setting('setting5', 'value5'))
    config_data.update_setting(Setting('setting6', 'value6'))
    config_data.update_setting(Setting('setting7', 'value7'))
    config_data.update_setting(Setting('setting8', 'value8'))
    config_data.update_setting(Setting('setting9', 'value9'))

# Generated at 2022-06-16 20:25:52.581912
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    config_data.update_setting(Setting('test_setting2', 'test_value2'))
    config_data.update_setting(Setting('test_setting3', 'test_value3'))
    config_data.update_setting(Setting('test_setting4', 'test_value4'))
    config_data.update_setting(Setting('test_setting5', 'test_value5'))
    config_data.update_setting(Setting('test_setting6', 'test_value6'))
    config_data.update_setting(Setting('test_setting7', 'test_value7'))
    config_data.update_setting(Setting('test_setting8', 'test_value8'))


# Generated at 2022-06-16 20:25:54.315303
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:56.965061
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:00.734736
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:26:04.019844
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:06.783753
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []
    assert config_data.get_settings(plugin=None) == []


# Generated at 2022-06-16 20:26:10.148377
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2


# Generated at 2022-06-16 20:26:12.767140
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='test_setting', value='test_value'))
    assert config_data.get_setting('test_setting') == Setting(name='test_setting', value='test_value')


# Generated at 2022-06-16 20:26:14.865103
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:36.308137
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:43.738127
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo').value == 'bar'
    assert config_data.get_setting('foo', Plugin('foo', 'bar')).value == 'bar'
    config_data.update_setting(Setting('foo', 'baz', Plugin('foo', 'bar')))
    assert config_data.get_setting('foo').value == 'bar'
    assert config_data.get_setting('foo', Plugin('foo', 'bar')).value == 'baz'



# Generated at 2022-06-16 20:26:49.553529
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test with a global setting
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting

    # Test with a plugin setting
    plugin = Plugin('foo', 'bar')
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('foo', plugin) == setting


# Generated at 2022-06-16 20:26:53.515056
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    plugin = Plugin('test_plugin', 'test_type')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('test_setting', plugin) == setting


# Generated at 2022-06-16 20:26:55.177711
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:26:57.888963
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:00.790355
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='foo', value='bar', origin='test')
    config_data.update_setting(setting)
    assert config_data._global_settings['foo'] == setting


# Generated at 2022-06-16 20:27:06.937757
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('name', 'value'))
    assert config_data._global_settings['name'].name == 'name'
    assert config_data._global_settings['name'].value == 'value'
    assert config_data._global_settings['name'].plugin is None
    config_data.update_setting(Setting('name', 'value', Plugin('type', 'name')))
    assert config_data._plugins['type']['name']['name'].name == 'name'
    assert config_data._plugins['type']['name']['name'].value == 'value'
    assert config_data._plugins['type']['name']['name'].plugin.type == 'type'

# Generated at 2022-06-16 20:27:10.668770
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:15.107225
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    config_data.update_setting(Setting('setting2', 'value2'), Plugin('plugin1', 'type1'))
    assert config_data.get_setting('setting2', Plugin('plugin1', 'type1')) == Setting('setting2', 'value2')


# Generated at 2022-06-16 20:28:07.150317
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting_1', 'value_1'))
    config_data.update_setting(Setting('setting_2', 'value_2'))
    config_data.update_setting(Setting('setting_3', 'value_3'), Plugin('plugin_1', 'plugin_type_1'))
    config_data.update_setting(Setting('setting_4', 'value_4'), Plugin('plugin_1', 'plugin_type_1'))
    config_data.update_setting(Setting('setting_5', 'value_5'), Plugin('plugin_2', 'plugin_type_1'))
    config_data.update_setting(Setting('setting_6', 'value_6'), Plugin('plugin_2', 'plugin_type_1'))
    config_data.update

# Generated at 2022-06-16 20:28:12.524746
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    config_data.update_setting(Setting('foo', 'baz'))
    assert config_data.get_setting('foo') == Setting('foo', 'baz')


# Generated at 2022-06-16 20:28:14.117918
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:28:15.867600
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:28:20.533151
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Test with empty config data
    assert config_data.get_settings() == []

    # Test with global setting
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data.get_settings() == [setting]

    # Test with plugin setting
    plugin = Plugin('foo', 'bar')
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings(plugin) == [setting]



# Generated at 2022-06-16 20:28:23.616361
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:33.350924
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', Plugin('foo', 'bar')))
    config_data.update_setting(Setting('baz', 'qux', Plugin('foo', 'bar')))
    config_data.update_setting(Setting('foo', 'bar', Plugin('baz', 'qux')))
    config_data.update_setting(Setting('baz', 'qux', Plugin('baz', 'qux')))
    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings(Plugin('foo', 'bar'))) == 2

# Generated at 2022-06-16 20:28:34.568527
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:28:43.464641
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    from ansible.module_utils.common.collections import ImmutableDict

    config_data = ConfigData()

    assert config_data.get_setting('foo') is None

    config_data.update_setting(ImmutableDict(name='foo', value='bar'))

    assert config_data.get_setting('foo') == ImmutableDict(name='foo', value='bar')

    config_data.update_setting(ImmutableDict(name='foo', value='baz'), plugin=ImmutableDict(type='action', name='copy'))

    assert config_data.get_setting('foo') == ImmutableDict(name='foo', value='bar')

# Generated at 2022-06-16 20:28:45.003160
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:29:30.896947
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:29:34.046228
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:41.087850
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:29:43.162677
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:48.287723
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'), Plugin('foo', 'bar'))

    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    assert config_data.get_setting('baz') is None
    assert config_data.get_setting('baz', Plugin('foo', 'bar')) == Setting('baz', 'qux')
    assert config_data.get_setting('baz', Plugin('foo', 'baz')) is None


# Generated at 2022-06-16 20:29:53.136808
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin('test_type', 'test_name')
    setting = Setting('test_setting')
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings(plugin) == [setting]


# Generated at 2022-06-16 20:29:53.842140
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:29:55.787032
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:29:57.722964
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:30:00.985310
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'


# Generated at 2022-06-16 20:31:28.939587
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []

# Generated at 2022-06-16 20:31:30.733929
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:31:32.529436
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:31:39.904391
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))

    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')

# Generated at 2022-06-16 20:31:43.453439
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:31:46.721925
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:31:47.732344
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:31:48.814365
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:31:58.053393
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin2', 'plugin_type2'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin3', 'plugin_type3'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin4', 'plugin_type4'))

# Generated at 2022-06-16 20:32:00.645222
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
