

# Generated at 2022-06-16 20:23:04.011174
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'plugin_type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'plugin_type1'))

# Generated at 2022-06-16 20:23:06.004569
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:08.441072
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:11.558135
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:14.362351
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:17.037332
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:23:23.356908
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'quux'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'quuz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'quuz', 'corge'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'quuz', 'corge', 'grault'))

# Generated at 2022-06-16 20:23:30.737717
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting_1', 'value_1'))
    config_data.update_setting(Setting('setting_2', 'value_2'))
    config_data.update_setting(Setting('setting_3', 'value_3'), Plugin('plugin_1', 'plugin_type_1'))
    config_data.update_setting(Setting('setting_4', 'value_4'), Plugin('plugin_2', 'plugin_type_2'))
    config_data.update_setting(Setting('setting_5', 'value_5'), Plugin('plugin_3', 'plugin_type_3'))
    assert config_data.get_setting('setting_1') == Setting('setting_1', 'value_1')
    assert config_data.get_setting('setting_2')

# Generated at 2022-06-16 20:23:34.029801
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:23:38.108950
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:51.192767
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin3', 'type2'))

    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')

# Generated at 2022-06-16 20:23:53.869631
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:23:56.934379
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:58.991256
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:24:02.078692
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:14.361777
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo2', 'bar2'))
    config_data.update_setting(Setting('foo3', 'bar3'))
    config_data.update_setting(Setting('foo4', 'bar4'))
    config_data.update_setting(Setting('foo5', 'bar5'))
    config_data.update_setting(Setting('foo6', 'bar6'))
    config_data.update_setting(Setting('foo7', 'bar7'))
    config_data.update_setting(Setting('foo8', 'bar8'))
    config_data.update_setting(Setting('foo9', 'bar9'))

# Generated at 2022-06-16 20:24:24.271537
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    config_data.update_setting(Setting('foo', 'baz'))
    assert config_data.get_setting('foo') == Setting('foo', 'baz')
    config_data.update_setting(Setting('foo', 'bar'), Plugin('foo', 'bar'))
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) == Setting('foo', 'bar')
    config_data.update_setting(Setting('foo', 'baz'), Plugin('foo', 'bar'))
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) == Setting('foo', 'baz')


# Generated at 2022-06-16 20:24:27.459214
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:36.371253
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()

    # Test with plugin=None
    setting = config_data.get_setting('foo')
    assert setting is None

    # Test with plugin.type not in config_data._plugins
    plugin = Plugin('bar', 'baz')
    setting = config_data.get_setting('foo', plugin)
    assert setting is None

    # Test with plugin.name not in config_data._plugins[plugin.type]
    config_data._plugins[plugin.type] = {}
    setting = config_data.get_setting('foo', plugin)
    assert setting is None

    # Test with setting.name not in config_data._plugins[plugin.type][plugin.name]
    config_data._plugins[plugin.type][plugin.name] = {}
    setting = config_data.get_setting('foo', plugin)

# Generated at 2022-06-16 20:24:47.963180
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'plugin_type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'plugin_type1'))

# Generated at 2022-06-16 20:25:00.331877
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert config_data.get_setting('foo').value == 'bar'
    assert config_data.get_setting('baz').value == 'qux'
    assert config_data.get_setting('baz').name == 'baz'
    assert config_data.get_setting('baz').plugin is None
    assert config_data.get_setting('baz').plugin_type is None
    assert config_data.get_setting('baz').plugin_name is None
    assert config_data.get_setting('baz').plugin_path is None
    assert config_data.get_setting('baz').plugin_version is None
   

# Generated at 2022-06-16 20:25:02.961905
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == 'bar'


# Generated at 2022-06-16 20:25:13.612155
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin2', 'plugin_type2'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin3', 'plugin_type3'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin4', 'plugin_type4'))

# Generated at 2022-06-16 20:25:16.146179
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    setting = Setting('test', 'test', 'test')
    config_data.update_setting(setting)
    assert config_data.get_settings() == [setting]


# Generated at 2022-06-16 20:25:18.617965
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:25:26.137418
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Test with no plugin
    assert config_data.get_settings() == []

    # Test with a plugin
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader('cache', 'memory', 'CacheModule', 'memory', 'memory')
    assert config_data.get_settings(plugin) == []

    # Test with a plugin and a setting
    from ansible.config.setting import Setting
    setting = Setting('cache_timeout', '60', 'integer', 'seconds', 'CacheModule', 'memory')
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings(plugin) == [setting]


# Generated at 2022-06-16 20:25:28.608482
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', 'bar') is None


# Generated at 2022-06-16 20:25:40.025691
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('setting1', 'value1')
    config_data.update_setting(setting)
    assert config_data._global_settings['setting1'].name == 'setting1'
    assert config_data._global_settings['setting1'].value == 'value1'
    assert config_data._global_settings['setting1'].plugin is None
    assert config_data._global_settings['setting1'].plugin_type is None
    assert config_data._global_settings['setting1'].plugin_name is None
    assert config_data._global_settings['setting1'].plugin_version is None
    assert config_data._global_settings['setting1'].plugin_path is None
    assert config_data._global_settings['setting1'].plugin_class is None
    assert config_data

# Generated at 2022-06-16 20:25:41.882652
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:25:45.364882
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test', 'test', 'test', 'test')
    config_data.update_setting(setting)
    assert config_data._global_settings['test'] == setting


# Generated at 2022-06-16 20:25:56.537267
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('bar', 'foo'))
    config_data.update_setting(Setting('foo', 'bar', Plugin('bar', 'foo')))
    config_data.update_setting(Setting('bar', 'foo', Plugin('bar', 'foo')))

    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    assert config_data.get_setting('bar') == Setting('bar', 'foo')
    assert config_data.get_setting('foo', Plugin('bar', 'foo')) == Setting('foo', 'bar', Plugin('bar', 'foo'))

# Generated at 2022-06-16 20:25:59.638926
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:10.077316
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'plugin_type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin2', 'plugin_type1'))
    config_data.update

# Generated at 2022-06-16 20:26:12.702834
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='test_setting', value='test_value'))
    assert config_data.get_setting('test_setting') == Setting(name='test_setting', value='test_value')


# Generated at 2022-06-16 20:26:16.015195
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:20.340573
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:23.444592
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:24.461973
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:25.995201
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:29.055286
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin('test', 'test')
    setting = Setting('test', 'test')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['test']['test']['test'] == setting
    assert config_data._plugins['test']['test']['test'].name == 'test'
    assert config_data._plugins['test']['test']['test'].value == 'test'


# Generated at 2022-06-16 20:26:39.882273
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:26:42.769274
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data._global_settings['foo'].value == 'bar'


# Generated at 2022-06-16 20:26:45.144581
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:46.724201
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:49.343579
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:50.816966
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:59.922230
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'plugin_type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin2', 'plugin_type2'))
    config_data.update

# Generated at 2022-06-16 20:27:01.611051
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("foo") is None
    assert config_data.get_setting("foo", "bar") is None


# Generated at 2022-06-16 20:27:06.304604
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:12.385377
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    plugin = Plugin('test_plugin', 'test_type')
    config_data.update_setting(setting)
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('test_setting') == setting
    assert config_data.get_setting('test_setting', plugin) == setting


# Generated at 2022-06-16 20:27:33.558101
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:36.613180
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:37.829365
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:27:41.399132
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:46.833155
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    plugin = Plugin('test', 'test')
    config_data.update_setting(setting)
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('foo') == setting
    assert config_data.get_setting('foo', plugin) == setting


# Generated at 2022-06-16 20:27:53.032540
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') is not None
    assert config_data.get_setting('foo').name == 'foo'
    assert config_data.get_setting('foo').value == 'bar'
    assert config_data.get_setting('foo').plugin is None
    assert config_data.get_setting('foo').plugin_type is None
    assert config_data.get_setting('foo').plugin_name is None


# Generated at 2022-06-16 20:27:56.605561
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:28:04.563817
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:28:07.905369
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:11.774822
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:28:47.401735
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:28:48.514028
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:28:51.912826
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    config.update_setting(Setting('a', 'b'))
    assert config.get_setting('a') == Setting('a', 'b')


# Generated at 2022-06-16 20:28:55.411798
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='test_setting', value='test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:29:00.352810
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert config_data.get_settings() == [Setting('foo', 'bar'), Setting('baz', 'qux')]


# Generated at 2022-06-16 20:29:02.704148
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == 'bar'


# Generated at 2022-06-16 20:29:12.496283
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    config_data.update_setting(Setting('foo', 'baz'))
    assert config_data.get_setting('foo') == Setting('foo', 'baz')
    config_data.update_setting(Setting('foo', 'bar'), Plugin('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'baz')
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) == Setting('foo', 'bar')
    config_data.update_setting(Setting('foo', 'baz'), Plugin('foo', 'bar'))
    assert config_data.get_

# Generated at 2022-06-16 20:29:14.352017
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:29:17.689356
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:21.589390
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test', 'test'))
    assert config_data.get_setting('test') is not None
    assert config_data.get_setting('test').name == 'test'
    assert config_data.get_setting('test').value == 'test'


# Generated at 2022-06-16 20:30:06.381259
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:30:08.283355
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:30:14.117210
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting(name='foo', value='bar')
    config_data.update_setting(setting)
    assert config_data._global_settings['foo'].value == 'bar'
    plugin = Plugin(type='foo', name='bar')
    setting = Setting(name='foo', value='bar')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['foo']['bar']['foo'].value == 'bar'


# Generated at 2022-06-16 20:30:17.039917
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:19.354442
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:20.769853
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:30:26.745428
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    assert config_data.get_setting('setting3') is None


# Generated at 2022-06-16 20:30:35.404841
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'))
    config_data.update_setting(Setting('setting5', 'value5'))
    config_data.update_setting(Setting('setting6', 'value6'))
    config_data.update_setting(Setting('setting7', 'value7'))
    config_data.update_setting(Setting('setting8', 'value8'))
    config_data.update_setting(Setting('setting9', 'value9'))

# Generated at 2022-06-16 20:30:41.110561
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    config_data.update_setting(Setting('setting2', 'value2'), Plugin('plugin1', 'type1'))
    assert config_data.get_setting('setting2', Plugin('plugin1', 'type1')) == Setting('setting2', 'value2')
    assert config_data.get_setting('setting2') == None


# Generated at 2022-06-16 20:30:42.505593
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:31:29.354911
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Test with no plugin
    settings = config_data.get_settings()
    assert len(settings) == 0

    # Test with a plugin
    from ansible.plugins.loader import PluginLoader
    plugin = PluginLoader('action', 'ping', '', '', '', '', '', '', '', '', '')
    settings = config_data.get_settings(plugin)
    assert len(settings) == 0


# Generated at 2022-06-16 20:31:32.690828
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:31:39.331789
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    config_data.update_setting(Setting('setting2', 'value2'))
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    config_data.update_setting(Setting('setting1', 'value3'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value3')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')


# Generated at 2022-06-16 20:31:42.973508
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:31:45.565167
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:31:48.688149
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    assert config_data.get_setting('setting3') is None


# Generated at 2022-06-16 20:31:51.170349
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:31:54.870416
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:31:57.381665
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:32:05.062032
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'qux'))
    config_data.update_setting(Setting('baz', 'qux', 'baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings(Plugin('baz', 'qux'))) == 2
