

# Generated at 2022-06-16 20:23:00.878485
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) is None


# Generated at 2022-06-16 20:23:11.739883
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin2', 'type1'))

# Generated at 2022-06-16 20:23:13.440288
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:16.012569
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:17.632714
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:19.525530
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:22.034341
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:29.382796
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin1', 'type2'))

# Generated at 2022-06-16 20:23:33.298194
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:35.907407
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:48.480677
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'qux'))

# Generated at 2022-06-16 20:23:56.647336
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin2', 'plugin_type2'))

    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    assert config_data.get_setting('setting3', Plugin('plugin1', 'plugin_type1')) == Setting('setting3', 'value3')
    assert config_

# Generated at 2022-06-16 20:24:00.045834
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:03.095712
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:15.514682
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin2', 'type1'))

# Generated at 2022-06-16 20:24:17.459020
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:24.563248
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:24:26.306641
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:34.324202
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:24:45.678303
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    config_data.update_setting(Setting('foo', 'bar', 'baz'))

# Generated at 2022-06-16 20:24:52.796618
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:24:55.406022
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:05.861639
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin2', 'type1'))

# Generated at 2022-06-16 20:25:07.765851
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:17.134455
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin3', 'type2'))

# Generated at 2022-06-16 20:25:20.819375
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:23.595665
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:25:25.919106
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:28.001047
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:32.378168
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting("foo", "bar", "baz"))
    assert config_data.get_setting("foo") == Setting("foo", "bar", "baz")


# Generated at 2022-06-16 20:25:43.563798
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_settings() == [Setting('test_setting', 'test_value')]


# Generated at 2022-06-16 20:25:46.101372
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', 'bar') is None


# Generated at 2022-06-16 20:25:48.800173
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting


# Generated at 2022-06-16 20:25:51.128557
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:54.119704
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:55.561522
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:58.473033
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():

    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:01.913323
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting


# Generated at 2022-06-16 20:26:05.193645
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:06.744808
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:17.270269
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:21.157349
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:26:22.952361
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:24.670992
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:27.372600
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:32.272082
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:34.076105
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert len(config_data.get_settings()) == 0


# Generated at 2022-06-16 20:26:43.213012
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    config_data.update_setting(Setting('foo', 'quux'), Plugin('action', 'ping'))
    config_data.update_setting(Setting('baz', 'quuz'), Plugin('action', 'ping'))
    config_data.update_setting(Setting('foo', 'corge'), Plugin('connection', 'local'))
    config_data.update_setting(Setting('baz', 'grault'), Plugin('connection', 'local'))
    assert config_data.get_settings() == [Setting('foo', 'bar'), Setting('baz', 'qux')]

# Generated at 2022-06-16 20:26:45.734194
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', 'bar') is None


# Generated at 2022-06-16 20:26:48.380356
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:58.788487
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:01.026058
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config = ConfigData()
    setting = Setting('test_setting', 'test_value', 'test_description')
    config.update_setting(setting)
    assert config.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:27:13.061681
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin2', 'type1'))

# Generated at 2022-06-16 20:27:17.572322
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:21.172932
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', 'bar') is None


# Generated at 2022-06-16 20:27:25.381266
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()

    # Test for global settings
    assert config_data.get_settings() == []

    # Test for plugin settings
    assert config_data.get_settings(plugin=Plugin('test_type', 'test_name')) == []


# Generated at 2022-06-16 20:27:26.907144
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:27:31.573829
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:34.830201
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:39.239501
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    plugin = Plugin('test_plugin', 'test_type')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['test_type']['test_plugin']['test_setting'] == setting


# Generated at 2022-06-16 20:28:05.940436
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin1', 'type2'))

# Generated at 2022-06-16 20:28:09.860238
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    plugin = Plugin('test_plugin', 'test_type')
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting, plugin)
    assert config_data.get_settings(plugin) == [setting]


# Generated at 2022-06-16 20:28:18.532505
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting_1', 'value_1'))
    config_data.update_setting(Setting('setting_2', 'value_2'))
    config_data.update_setting(Setting('setting_3', 'value_3'), Plugin('plugin_1', 'plugin_type_1'))
    config_data.update_setting(Setting('setting_4', 'value_4'), Plugin('plugin_2', 'plugin_type_1'))
    config_data.update_setting(Setting('setting_5', 'value_5'), Plugin('plugin_1', 'plugin_type_2'))
    config_data.update_setting(Setting('setting_6', 'value_6'), Plugin('plugin_2', 'plugin_type_2'))


# Generated at 2022-06-16 20:28:29.747195
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    config_data.update_setting(Setting('foo', 'baz'))
    assert config_data.get_setting('foo') == Setting('foo', 'baz')
    config_data.update_setting(Setting('foo', 'baz'), Plugin('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'baz')
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) == Setting('foo', 'baz')
    config_data.update_setting(Setting('foo', 'bar'), Plugin('foo', 'bar'))
    assert config_data.get

# Generated at 2022-06-16 20:28:40.529503
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin1', 'type2'))

# Generated at 2022-06-16 20:28:42.872519
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:45.057904
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:46.903545
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:28:48.739826
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:53.236951
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:29:11.954357
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:29:14.029599
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data.get_setting('foo') == setting


# Generated at 2022-06-16 20:29:17.425692
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:20.115489
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:23.917158
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:25.545694
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:29:29.323270
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:29:30.982823
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:29:34.934229
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) is None


# Generated at 2022-06-16 20:29:37.421489
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:13.750450
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == 'bar'


# Generated at 2022-06-16 20:30:17.517497
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) is None


# Generated at 2022-06-16 20:30:22.391162
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[1].name == 'baz'


# Generated at 2022-06-16 20:30:32.407255
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo', 'bar'))

# Generated at 2022-06-16 20:30:33.956465
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:30:36.768230
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_setting('test_setting') == Setting('test_setting', 'test_value')


# Generated at 2022-06-16 20:30:38.195499
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:30:40.886195
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:43.122170
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:46.501435
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:31:57.994364
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:31:59.689272
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None


# Generated at 2022-06-16 20:32:08.103500
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {'a': 1, 'b': 2}
    config_data._plugins = {'c': {'d': {'e': 3, 'f': 4}}}
    assert config_data.get_settings() == [1, 2]
    assert config_data.get_settings(plugin=None) == [1, 2]
    assert config_data.get_settings(plugin=ConfigData()) == [1, 2]
    assert config_data.get_settings(plugin=ConfigData()) == [1, 2]
    assert config_data.get_settings(plugin=ConfigData()) == [1, 2]
    assert config_data.get_settings(plugin=ConfigData()) == [1, 2]

# Generated at 2022-06-16 20:32:09.824527
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:32:11.673930
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:32:18.229693
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:32:21.376690
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:32:23.621621
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:32:28.278283
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:32:30.033462
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
