

# Generated at 2022-06-16 20:23:12.500808
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    from ansible.plugins.loader import PluginLoader

    config_data = ConfigData()

    # Test with no plugin
    settings = config_data.get_settings()
    assert len(settings) == 0

    # Test with a plugin
    plugin = PluginLoader.get('cache', 'memory')
    settings = config_data.get_settings(plugin)
    assert len(settings) == 0

    # Test with a plugin and a setting
    from ansible.config.setting import Setting
    setting = Setting('cache_dir', '/tmp/ansible_cache')
    config_data.update_setting(setting, plugin)
    settings = config_data.get_settings(plugin)
    assert len(settings) == 1
    assert settings[0].name == 'cache_dir'
    assert settings[0].value == '/tmp/ansible_cache'

# Generated at 2022-06-16 20:23:15.650624
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:18.641082
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:23:21.373351
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:23.355729
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:25.601356
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:27.826426
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:34.269078
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {'a': 1, 'b': 2}
    config_data._plugins = {'c': {'d': {'e': 3, 'f': 4}}}
    assert config_data.get_settings() == [1, 2]
    assert config_data.get_settings(plugin=None) == [1, 2]
    assert config_data.get_settings(plugin=object) == [1, 2]
    assert config_data.get_settings(plugin=object()) == [1, 2]
    assert config_data.get_settings(plugin=object(type='c', name='d')) == [3, 4]
    assert config_data.get_settings(plugin=object(type='c', name='e')) == [1, 2]

# Generated at 2022-06-16 20:23:38.476908
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:41.487660
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:45.892273
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:47.835775
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:23:51.314974
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:23:53.672339
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:23:56.694393
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    plugin = Plugin('test_plugin', 'test_type')
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['test_type']['test_plugin']['test_setting'] == setting


# Generated at 2022-06-16 20:24:00.434770
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar', 'baz'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar', 'baz')


# Generated at 2022-06-16 20:24:03.950060
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:24:09.322778
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') is not None
    assert config_data.get_setting('foo').name == 'foo'
    assert config_data.get_setting('foo').value == 'bar'


# Generated at 2022-06-16 20:24:17.853681
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data._global_settings = {'setting1': 1, 'setting2': 2}
    config_data._plugins = {'type1': {'name1': {'setting3': 3, 'setting4': 4}}}
    assert config_data.get_settings() == [1, 2]
    assert config_data.get_settings(plugin=None) == [1, 2]
    assert config_data.get_settings(plugin=Plugin('type1', 'name1')) == [3, 4]


# Generated at 2022-06-16 20:24:22.062558
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    plugin = Plugin('test', 'test')
    setting = Setting('test', 'test', 'test')
    config_data.update_setting(setting, plugin)
    assert config_data.get_setting('test', plugin) == setting


# Generated at 2022-06-16 20:24:30.134342
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:24:32.026177
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:33.643740
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:39.195872
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting('setting1')
    assert config_data._global_settings['setting1'] == 'setting1'
    config_data.update_setting('setting2', 'plugin')
    assert config_data._plugins['plugin']['plugin']['setting2'] == 'setting2'


# Generated at 2022-06-16 20:24:41.151010
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:24:51.132859
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    assert config_data.get_settings() == []

    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_settings() == [Setting('foo', 'bar')]

    config_data.update_setting(Setting('foo', 'baz'))
    assert config_data.get_settings() == [Setting('foo', 'baz')]

    config_data.update_setting(Setting('foo', 'baz'), Plugin('foo', 'bar'))
    assert config_data.get_settings() == [Setting('foo', 'baz')]
    assert config_data.get_settings(Plugin('foo', 'bar')) == [Setting('foo', 'baz')]


# Generated at 2022-06-16 20:24:57.578966
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('foo', 'bar', 'baz', 'baz'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    assert config_data.get_setting('foo', Plugin('baz', 'baz')) == Setting('foo', 'bar', 'baz', 'baz')
    assert config_data.get_setting('foo', Plugin('baz', 'baz1')) is None


# Generated at 2022-06-16 20:25:06.930785
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin2', 'type2'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type2'))

    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')

# Generated at 2022-06-16 20:25:10.002842
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:18.797845
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin2', 'plugin_type2'))
    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    assert config_data.get_setting('setting3', Plugin('plugin1', 'plugin_type1')) == Setting('setting3', 'value3')
    assert config_

# Generated at 2022-06-16 20:25:24.899712
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:27.807518
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert config_data.get_settings() == [{'name': 'foo', 'value': 'bar'}, {'name': 'baz', 'value': 'qux'}]


# Generated at 2022-06-16 20:25:30.541072
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:25:38.653409
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('foo', 'bar')
    config_data.update_setting(setting)
    assert config_data._global_settings['foo'].name == 'foo'
    assert config_data._global_settings['foo'].value == 'bar'
    plugin = Plugin('foo', 'bar')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['foo']['bar']['foo'].name == 'foo'
    assert config_data._plugins['foo']['bar']['foo'].value == 'bar'


# Generated at 2022-06-16 20:25:48.660499
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin1', 'type2'))

# Generated at 2022-06-16 20:25:51.086901
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:25:57.191160
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type2'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin3', 'type3'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin4', 'type4'))

# Generated at 2022-06-16 20:26:00.997515
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='test', value='test'))
    assert config_data.get_setting('test') == Setting(name='test', value='test')


# Generated at 2022-06-16 20:26:04.273174
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:26:06.690384
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    plugin = Plugin('test_plugin', 'test_type')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['test_type']['test_plugin']['test_setting'] == setting


# Generated at 2022-06-16 20:26:18.770120
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:26:28.425001
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin2', 'plugin_type2'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'plugin_type2'))

    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    assert config_data.get_setting

# Generated at 2022-06-16 20:26:32.797857
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:26:42.164191
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'))
    config_data.update_setting(Setting('setting5', 'value5'))
    config_data.update_setting(Setting('setting6', 'value6'))
    config_data.update_setting(Setting('setting7', 'value7'))
    config_data.update_setting(Setting('setting8', 'value8'))
    config_data.update_setting(Setting('setting9', 'value9'))

# Generated at 2022-06-16 20:26:44.281295
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', 'bar') is None


# Generated at 2022-06-16 20:26:48.290347
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    plugin = Plugin('test_plugin', 'test_type')
    config_data.update_setting(setting, plugin)
    assert config_data._plugins['test_type']['test_plugin']['test_setting'] == setting


# Generated at 2022-06-16 20:26:58.358195
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'), Plugin('plugin1', 'plugin_type1'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin2', 'plugin_type2'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'plugin_type1'))

    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')
    assert config_data.get_setting('setting2') == Setting('setting2', 'value2')
    assert config_data.get_setting

# Generated at 2022-06-16 20:27:00.262794
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:02.646881
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:06.449964
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:27.320279
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():

    config_data = ConfigData()

    # Test 1: get_settings with no plugin
    assert len(config_data.get_settings()) == 0

    # Test 2: get_settings with plugin
    assert len(config_data.get_settings(plugin=Plugin('test', 'test'))) == 0

    # Test 3: get_settings with plugin
    config_data.update_setting(Setting('test', 'test'))
    assert len(config_data.get_settings()) == 1
    assert len(config_data.get_settings(plugin=Plugin('test', 'test'))) == 0

    # Test 4: get_settings with plugin
    config_data.update_setting(Setting('test', 'test'), plugin=Plugin('test', 'test'))
    assert len(config_data.get_settings()) == 1

# Generated at 2022-06-16 20:27:32.219909
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='foo', value='bar'))
    assert config_data._global_settings['foo'].value == 'bar'


# Generated at 2022-06-16 20:27:43.500266
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1', 'global'))
    config_data.update_setting(Setting('setting2', 'value2', 'global'))
    config_data.update_setting(Setting('setting3', 'value3', 'global'))
    config_data.update_setting(Setting('setting4', 'value4', 'global'))
    config_data.update_setting(Setting('setting5', 'value5', 'global'))
    config_data.update_setting(Setting('setting6', 'value6', 'global'))
    config_data.update_setting(Setting('setting7', 'value7', 'global'))
    config_data.update_setting(Setting('setting8', 'value8', 'global'))
    config_data.update

# Generated at 2022-06-16 20:27:46.339220
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:27:54.496588
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin2', 'type2'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin3', 'type3'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin4', 'type4'))

# Generated at 2022-06-16 20:27:56.408556
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting("foo") is None


# Generated at 2022-06-16 20:28:00.376637
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting(name='foo', value='bar'))
    assert config_data.get_setting('foo') == Setting(name='foo', value='bar')


# Generated at 2022-06-16 20:28:05.466178
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:07.149816
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:28:11.298392
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:34.162785
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == 'bar'


# Generated at 2022-06-16 20:28:43.167230
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    config_data.update_setting(Setting('foo', 'baz'))
    assert config_data.get_setting('foo') == Setting('foo', 'baz')
    config_data.update_setting(Setting('foo', 'bar'), Plugin('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'baz')
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) == Setting('foo', 'bar')
    config_data.update_setting(Setting('foo', 'baz'), Plugin('foo', 'bar'))
    assert config_data.get_

# Generated at 2022-06-16 20:28:45.869638
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:49.398331
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:28:53.417512
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    config_data.update_setting(Setting('foo', 'bar', Plugin('foo', 'bar')))
    config_data.update_setting(Setting('baz', 'qux', Plugin('foo', 'bar')))
    assert len(config_data.get_settings()) == 2
    assert len(config_data.get_settings(Plugin('foo', 'bar'))) == 2


# Generated at 2022-06-16 20:28:55.131346
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:28:59.533867
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('test_setting', 'test_value'))
    assert config_data.get_settings()[0].name == 'test_setting'
    assert config_data.get_settings()[0].value == 'test_value'


# Generated at 2022-06-16 20:29:02.244108
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:05.840068
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('setting_name', 'setting_value')
    config_data.update_setting(setting)
    assert config_data._global_settings['setting_name'] == setting


# Generated at 2022-06-16 20:29:09.250598
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:52.483331
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:29:55.260656
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:00.905755
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin2', 'type1'))

# Generated at 2022-06-16 20:30:03.225988
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:30:07.328698
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting


# Generated at 2022-06-16 20:30:10.368070
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:30:17.824462
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[0].value == 'bar'
    assert config_data.get_settings()[1].name == 'baz'
    assert config_data.get_settings()[1].value == 'qux'


# Generated at 2022-06-16 20:30:20.415551
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('name', 'value'))
    assert config_data.get_setting('name') == Setting('name', 'value')


# Generated at 2022-06-16 20:30:23.589265
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2


# Generated at 2022-06-16 20:30:25.094644
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    assert config_data.get_settings() == []


# Generated at 2022-06-16 20:31:05.920622
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')


# Generated at 2022-06-16 20:31:13.224393
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == 'bar'
    config_data.update_setting(Setting('foo', 'baz'))
    assert config_data.get_setting('foo') == 'baz'
    config_data.update_setting(Setting('foo', 'baz'), Plugin('foo', 'bar'))
    assert config_data.get_setting('foo') == 'baz'
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) == 'baz'
    config_data.update_setting(Setting('foo', 'bar'), Plugin('foo', 'bar'))
    assert config_data.get_setting('foo') == 'baz'
    assert config_data

# Generated at 2022-06-16 20:31:23.493660
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1', 'description1'))
    config_data.update_setting(Setting('setting2', 'value2', 'description2'), Plugin('type1', 'name1'))
    config_data.update_setting(Setting('setting3', 'value3', 'description3'), Plugin('type2', 'name2'))
    config_data.update_setting(Setting('setting4', 'value4', 'description4'), Plugin('type1', 'name1'))
    config_data.update_setting(Setting('setting5', 'value5', 'description5'), Plugin('type2', 'name2'))
    config_data.update_setting(Setting('setting6', 'value6', 'description6'), Plugin('type1', 'name1'))
   

# Generated at 2022-06-16 20:31:34.012287
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'))
    config_data.update_setting(Setting('setting5', 'value5'))
    config_data.update_setting(Setting('setting6', 'value6'))
    config_data.update_setting(Setting('setting7', 'value7'))
    config_data.update_setting(Setting('setting8', 'value8'))
    config_data.update_setting(Setting('setting9', 'value9'))

# Generated at 2022-06-16 20:31:45.215947
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'bar')
    config_data.update_setting(Setting('foo', 'baz'))
    assert config_data.get_setting('foo') == Setting('foo', 'baz')
    config_data.update_setting(Setting('foo', 'baz'), Plugin('foo', 'bar'))
    assert config_data.get_setting('foo') == Setting('foo', 'baz')
    assert config_data.get_setting('foo', Plugin('foo', 'bar')) == Setting('foo', 'baz')
    config_data.update_setting(Setting('foo', 'bar'), Plugin('foo', 'baz'))

# Generated at 2022-06-16 20:31:46.320142
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    assert config_data.get_setting('foo') is None
    assert config_data.get_setting('foo', 'bar') is None


# Generated at 2022-06-16 20:31:48.081932
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('setting_name', 'setting_value')
    config_data.update_setting(setting)
    assert config_data._global_settings['setting_name'] == setting


# Generated at 2022-06-16 20:31:57.350042
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3', Plugin('plugin1', 'type1')))
    config_data.update_setting(Setting('setting4', 'value4', Plugin('plugin2', 'type1')))
    config_data.update_setting(Setting('setting5', 'value5', Plugin('plugin1', 'type2')))
    config_data.update_setting(Setting('setting6', 'value6', Plugin('plugin2', 'type2')))

    assert config_data.get_setting('setting1') == Setting('setting1', 'value1')

# Generated at 2022-06-16 20:32:06.635089
# Unit test for method get_setting of class ConfigData
def test_ConfigData_get_setting():
    config_data = ConfigData()
    config_data.update_setting(Setting('setting1', 'value1'))
    config_data.update_setting(Setting('setting2', 'value2'))
    config_data.update_setting(Setting('setting3', 'value3'))
    config_data.update_setting(Setting('setting4', 'value4'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting5', 'value5'), Plugin('plugin1', 'type1'))
    config_data.update_setting(Setting('setting6', 'value6'), Plugin('plugin2', 'type1'))
    config_data.update_setting(Setting('setting7', 'value7'), Plugin('plugin2', 'type1'))

# Generated at 2022-06-16 20:32:12.818579
# Unit test for method get_settings of class ConfigData
def test_ConfigData_get_settings():
    config_data = ConfigData()
    config_data.update_setting(Setting('foo', 'bar'))
    config_data.update_setting(Setting('baz', 'qux'))
    assert len(config_data.get_settings()) == 2
    assert config_data.get_settings()[0].name == 'foo'
    assert config_data.get_settings()[1].name == 'baz'


# Generated at 2022-06-16 20:32:59.166719
# Unit test for method update_setting of class ConfigData
def test_ConfigData_update_setting():
    config_data = ConfigData()
    setting = Setting('test_setting', 'test_value')
    config_data.update_setting(setting)
    assert config_data.get_setting('test_setting') == setting
