

# Generated at 2022-06-22 07:47:44.008072
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    data_url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    x = ITVBTCCIE(data_url, data_url)
    assert x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:47:49.990305
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._match_id(url + '/') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:47:55.431720
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() == 'ITVBTCC'
    assert ITVBTCCIE.ie_key() == ITVBTCCIE.ie_key()
    assert ITVBTCCIE.ie_key() == ITVBTCCIE().ie_key()
    assert ITVBTCCIE.ie_key() != ITV.ie_key()


# Generated at 2022-06-22 07:47:58.567504
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor_test(ITVBTCCIE, 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:48:10.456808
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/coronation-street/2a4787a0004'
    ieg = ITVIE(
        params={'referrer': 'http://www.itv.com/player/itv/hub'})
    
    assert ieg.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/%s_default/index.html?videoId=%s', \
        'ITVIE class should have BRIGHTCOVE_URL_TEMPLATE property'
    assert ieg.GEO_COUNTRIES == ['GB']
    
    # Test ITVIE.suitable()

# Generated at 2022-06-22 07:48:11.148274
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE

# Generated at 2022-06-22 07:48:21.639347
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    webpage = '<!DOCTYPE HTML><html></html>'
    params = '<div id="video" class="responsive-video js-responsiveVideo" data-playlist-url="https://www.itv.com/itvplayer/video/playlist/2a4547a0012" data-video-id="2a4547a0012" data-video-hmac="79d087b8-4f4a-4ec4-b4d7-8aab5f5d9c54" data-locale="" data-player-env="production"></div>'

# Generated at 2022-06-22 07:48:24.129639
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Tests constructor of class ITVIE
    ITVIE # IGNORE:W0104 pylint:disable=W0104


# Generated at 2022-06-22 07:48:30.434412
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.suitable('https://www.itv.com/hub/liar/2a4547a0012')
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'



# Generated at 2022-06-22 07:48:39.759799
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video = ITVIE()
    assert video.geo_verification_headers() == {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-GB,en-US;q=0.8,en;q=0.6',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36',
    }

# Generated at 2022-06-22 07:48:55.800741
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class_ = ITVBTCCIE
    assert class_._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert class_._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert class_._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-22 07:48:57.662359
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE == ''

# Generated at 2022-06-22 07:49:01.464753
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', {
        'skip_download': True,
    })

# Generated at 2022-06-22 07:49:05.453254
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-22 07:49:10.470011
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie and ie.constructor

# Generated at 2022-06-22 07:49:15.977313
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "http://www.itv.com/hub/liar/2a4547a0012"
    itv_ie = ITVIE()
    assert itv_ie.suitable(url)
    assert itv_ie.video_url(url).startswith("http://hls.media.itv.com/")
    assert itv_ie.video_url(url).endswith("m3u8")

# Generated at 2022-06-22 07:49:17.645735
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie is not None

# Generated at 2022-06-22 07:49:21.412374
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = ITVIE()._match_id(url)
    assert video_id == '2a4547a0012'

# Generated at 2022-06-22 07:49:23.314570
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # test constructors
    itvbtccie = ITVBTCCIE()
    itvbtccie.BRIGHTCOVE_URL_TEMPLATE = 'TESTTESTTESTTESTTESTTEST'
    itvbtccie = ITVBTCCIE()



# Generated at 2022-06-22 07:49:23.826970
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:49:52.927387
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert (ITVBTCCIE() == ITVBTCCIE())

# Generated at 2022-06-22 07:49:59.617716
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Initiating class ITVBTCCIE
    it = ITVBTCCIE()
    # Testing variable BRIGHTCOVE_URL_TEMPLATE
    assert it.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:50:02.375758
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    a = ITVBTCCIE()
    assert a.PLAYLIST_TITLE == 'BTCC'

# Generated at 2022-06-22 07:50:08.493670
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor_inst = ITVBTCCIE()
    assert info_extractor_inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:50:13.938044
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        itv_btcc_ie = ITVBTCCIE(None)
    except TypeError:
        print("Constructor of class ITVBTCCIE requires 1 argument")
        print("TypeError Exception successfully thrown")
        return True
    else:
        print("Exception not thrown")
        return False

ITVHubIE = ITVBTCCIE

# Generated at 2022-06-22 07:50:20.959316
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    tv = ITVBTCCIE()
    tv._match_id('www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    tv._download_webpage('www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    tv.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 07:50:24.709422
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"

# Generated at 2022-06-22 07:50:33.956653
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE._match_id(url) == '2a4547a0012'

    video_id = '2a4547a0012'
    info = {
        'id': '2a4547a0012',
        'ext': 'mp4',
        'title': 'Liar - Series 2 - Episode 6',
        'description': 'md5:d0f91536569dec79ea184f0a44cca089',
        'series': 'Liar',
        'season_number': 2,
        'episode_number': 6,
    }
    assert ITVIE._real_extract(url) == info


# Generated at 2022-06-22 07:50:44.347285
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE()._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE()._TESTS[0]['info_dict']['id'] == '2a4547a0012'
    assert ITVIE()._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert ITVIE()._TESTS[0]['info_dict']['title'] == 'Liar - Series 2 - Episode 6'

# Generated at 2022-06-22 07:50:47.826792
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE == ITVBTCCIE(InfoExtractor())

# Generated at 2022-06-22 07:51:29.965375
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.constructor_name() == 'ITVBTCCIE'

# Generated at 2022-06-22 07:51:33.097639
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:51:43.704013
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = ITVBTCCIE._match_id(url)
    assert playlist_id == 'btcc-2018-all-the-action-from-brands-hatch'
    webpage = ITVBTCCIE._download_webpage(ITVBTCCIE(), url, playlist_id)
    assert '<h2 class="article-content__title">BTCC 2018: All the action from Brands Hatch</h2>' in webpage
    assert '<div class="article-content__headline__title">BTCC 2018: All the action from Brands Hatch</div>' in webpage

# Generated at 2022-06-22 07:51:51.267101
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        class ITVBTCCIE(InfoExtractor):
            _VALID_URL = r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
            BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

        ITVBTCCIE()
    except Exception:
        return False
    return True

# Generated at 2022-06-22 07:51:52.892660
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('itv:hub:liar:2a4547a0012')

# Generated at 2022-06-22 07:51:59.059848
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert re.findall(
        ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % "5774724675001",
        ITVBTCCIE._html_search_regex(
            ITVBTCCIE._TEST['url'],
            ITVBTCCIE._VALID_URL,
            'url',
            'players.brightcove.net',
            Flags=re.IGNORECASE).decode('utf-8'), count=1)

# Generated at 2022-06-22 07:52:04.520021
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_url = 'https://www.itv.com/hub/dont-tell-the-bride/2a5159a0024'
    ie = ITVIE()
    ie.suitable(video_url)

# Generated at 2022-06-22 07:52:16.174373
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Tests for URL https://www.itv.com/hub/liar/2a4547a0012
    # URL is correct?
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    # URL is in GEO_COUNTRIES?
    assert ITVIE._GEO_COUNTRIES == ['GB']
    # Is there constructor of class ITVIE?
    assert ITVIE(InfoExtractor)._downloader.params['geo_verification_headers']
    # Id is correct?

# Generated at 2022-06-22 07:52:20.333061
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert inst.extract_info()['id'] == '2a4547a0012'
    assert inst.GEO_COUNTRIES == ['GB']

# Generated at 2022-06-22 07:52:30.427774
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # object for ITVEntryIE
    ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    # assert the test case
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:53:53.376971
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    expected = {
        'id': '2a4547a0012',
        'ext': 'mp4',
        'title': 'Liar - Series 2 - Episode 6',
        'description': 'md5:d0f91536569dec79ea184f0a44cca089',
        'series': 'Liar',
        'season_number': 2,
        'episode_number': 6,
        'skip_download': True,
    }
    result = test._real_extract('https://www.itv.com/hub/liar/2a4547a0012')
    assert(result == expected)


# Generated at 2022-06-22 07:53:56.751573
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class ITVBTCCIE(object):pass
    ITVBTCCIE.unit_test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE.unit_test_expected_result = {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'BTCC 2018: All the action from Brands Hatch',
    }

# Generated at 2022-06-22 07:54:01.661874
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:54:06.996366
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    playlist_id = re.search(r"(?<=itv\.com/btcc/)[^/]+", url).group(0)
    webpage = "this is a webpage"
    return ITVBTCCIE()._real_extract(url)

# Generated at 2022-06-22 07:54:11.157603
# Unit test for constructor of class ITVIE
def test_ITVIE():
    func = ITVIE
    for test_dict in func._TESTS:
        assert isinstance(func(test_dict['info_dict']), ITVIE)
        assert func.BRIGHT_COVE_URL_TEMPLATE.search(test_dict['url'])


# Generated at 2022-06-22 07:54:16.683851
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    instance = ITVBTCCIE(url)
    assert instance.url == url
    assert instance.PLAYLIST_ID == "btcc-2018-all-the-action-from-brands-hatch"

# Generated at 2022-06-22 07:54:24.952430
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class TestITVBTCCIE(ITVBTCCIE):
        def __init__(self, *args, **kwargs):
            self._download_webpage = lambda *args, **kwargs: '<html></html>' # noqa
        def _real_extract(self, *args, **kwargs):
            self.assertEqual((self.BRIGHTCOVE_URL_TEMPLATE % '7010480178001'),
                             'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=7010480178001')
            return self.playlist_result([], '', '')

# Generated at 2022-06-22 07:54:25.628731
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(InfoExtractor())

# Generated at 2022-06-22 07:54:28.604468
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    return ITVBTCCIE()._test_extract({
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
    })

# Generated at 2022-06-22 07:54:35.077826
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class_instance = ITVIE('itv.com', 'Liar - Series 2 - Episode 6')
    assert class_instance._VALID_URL == 'https?://(?:www\.)?itv\.com/(?!.*(?:hub|itvplayer|itvcom)).+'
    assert class_instance._TESTS[0]['info_dict']['title'] == 'Liar - Series 2 - Episode 6'
    assert class_instance._TESTS[0]['params']['skip_download'] == True

# Generated at 2022-06-22 07:57:05.491195
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:57:10.694271
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Test to check if the constructor of class ITVIE is working correctly
    """
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ie = ITVIE(url)
    assert ie.url == url
    assert ie.video_id == '2a4547a0012'


# Generated at 2022-06-22 07:57:14.409550
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['playlist_mincount'] == len(ITVBTCCIE(ITVBTCCIE())._real_extract(ITVBTCCIE._TEST['url'])['entries'])

# Generated at 2022-06-22 07:57:21.793718
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE();
    assert obj._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)';
    assert obj._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    };