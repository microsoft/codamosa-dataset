

# Generated at 2022-06-22 07:47:40.772815
# Unit test for constructor of class ITVIE
def test_ITVIE():
    t = ITVIE()
    t._real_extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-22 07:47:42.738544
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert type(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE) is str

# Generated at 2022-06-22 07:47:52.710485
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    playlist_id = "btcc-2018-all-the-action-from-brands-hatch"


# Generated at 2022-06-22 07:48:04.448776
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # This constructor is different to others in that it doesn't raise an exception if the URL is invalid
    # The invalid URL is correct in that it doesn't match the regex, but this is not wrong.
    # It is a valid URL for the site and does return a valid page.
    # As the site returns a valid page for the URL and the purpose of the constructor is simply to
    # determine the video and page ID, the url should not be considered to be invalid and the constructor
    # should not raise an AssertionError or any other exception.
    # If you are wondering what the difference is between this and the expected behaviour for other sites,
    # it is that other sites will return a 404 error for an invalid URL, whereas this will return a valid
    # page.
    itvbtcc = ITVBTCCIE()

# Generated at 2022-06-22 07:48:08.511802
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE_ORIGINAL = ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/%s/HkiHLnNRx_default/index.html?videoId=%s'
    # simple test
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    result = ITVBTCCIE()._real_extract(url)
    assertNotEquals(result['title'], None)
    assertNotEquals(result['id'], None)
    assertNotEquals(result['entries'], None)

   

# Generated at 2022-06-22 07:48:12.525657
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:16.476009
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE != None
    except AssertionError:
        raise AssertionError('Error: BRIGHTCOVE_URL_TEMPLATE is not defined in class ITVBTCCIE')

# Generated at 2022-06-22 07:48:20.768269
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('test')
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:48:24.463966
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:25.686159
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.__name__ == 'ITV'

# Generated at 2022-06-22 07:48:38.529099
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie.url_result == itvie._default_url_result
    assert itvie.url_result('some url')[0]['url'] == 'some url'

# Generated at 2022-06-22 07:48:41.031146
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVIE())._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-22 07:48:49.354676
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Check that constructor of class ITVBTCCIE is not being affected by
    # changes in the constructor of its parent class.
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    play_list = ITVBTCCIE()._real_extract(url)
    assert play_list['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert play_list['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert play_list['_type'] == 'playlist'
    assert play_list['entries']

# Generated at 2022-06-22 07:48:55.593890
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert info_extractor._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-22 07:49:00.035070
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:49:02.818683
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor = ITVBTCCIE('itv:btcc');
    assert([] == constructor.__dict__['_TESTS'])

# Generated at 2022-06-22 07:49:14.103567
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    video_id = "2a4547a0012"
    class test_class(InfoExtractor):
        pass
    test_class.IE_NAME = "ITV"
    test_class.IE_DESC = "ITV"
    test_class._VALID_URL = r'https?://(?:www\.)?itv\.com/hub/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:49:17.832098
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-22 07:49:29.251304
# Unit test for constructor of class ITVIE
def test_ITVIE():
    sucessful_urls = ['https://www.itv.com/hub/liar/2a4547a0012']
    unsuccessful_urls = ['https://www.itv.com/hub/through-the-keyhole/2a2271a0033', 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034', 'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024']

    for url in sucessful_urls:
        extractor = ITVIE(ITVIE.suitable(url), url)
        assert extractor is not None
    for url in unsuccessful_urls:
        extractor = ITVIE(ITVIE.suitable(url), url)
        assert extractor

# Generated at 2022-06-22 07:49:30.173980
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:49:59.510327
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # arguments for constructor
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    # test
    assert ITVIE(url, video_id).url == url

# Generated at 2022-06-22 07:50:01.330155
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert isinstance(itv, ITVIE)

# Generated at 2022-06-22 07:50:02.320517
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE

# Generated at 2022-06-22 07:50:04.584484
# Unit test for constructor of class ITVIE
def test_ITVIE():
	object = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-22 07:50:08.894683
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:50:10.040118
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)

# Generated at 2022-06-22 07:50:12.287363
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    youtube_ie = ITVBTCCIE()
    assert youtube_ie is not None

# Generated at 2022-06-22 07:50:23.905095
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """ test case for ITVIE """
    URL = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITV = ITVIE()
    ITV._downloader.cache.store = {}
    ITV._download_webpage = lambda *args: 'web page'
    ITV._extract_m3u8_formats = lambda *args: [
        {'url': 'https://www.itv.com/hub/liar/2a4547a0012'},
        {'url': 'https://www.itv.com/hub/liar/2a4547a0012'},
        {'url': 'https://www.itv.com/hub/liar/2a4547a0012'}]
    info = ITV._real_extract(URL)
    assert info

# Generated at 2022-06-22 07:50:31.914621
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Check if ITVIE parsed correctly.
    """
    # Create a new ITVIE object
    inst = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    # Check if its url is https://www.itv.com/hub/liar/2a4547a0012
    assert inst.url == 'https://www.itv.com/hub/liar/2a4547a0012'
    # Check if its video id is 2a4547a0012
    assert inst.video_id == '2a4547a0012'

# Generated at 2022-06-22 07:50:35.519097
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class ITVTester(ITVIE):
        def _real_extract(self, url):
            return self._extract_video(url)
    return ITVTester

# Generated at 2022-06-22 07:51:52.528748
# Unit test for constructor of class ITVIE
def test_ITVIE():

    def testwrng(expectederrormsg, url):
        try:
            ITVIE(None)
            ITVIE(url)
            assert False
        except Exception as e:
            assert e.message == expectederrormsg

    ITVIE(None)
    url1 = 'https://www.itv.com/hub/the-jacqueline-wilson-collection/2a1510a0039'
    ITVIE(url1)

    url2 = 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033'
    testwrng('Unable to extract data from ITVEmbed',url2)
    url3 = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'

# Generated at 2022-06-22 07:51:54.122496
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:51:57.929545
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:52:06.065171
# Unit test for constructor of class ITVIE
def test_ITVIE():
	itv_url = 'https://www.itv.com/hub/liar/2a4547a0012'
	ie = ITVIE.ie_key()

	assert(ie.suitable(itv_url) == True)
	assert(ie.extract(itv_url)['id'] == '2a4547a0012')

# Generated at 2022-06-22 07:52:07.926921
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .test_itv import ITVIE_test
    ITVIE_test('ITVIE')



# Generated at 2022-06-22 07:52:18.379005
# Unit test for constructor of class ITVIE
def test_ITVIE():
  from .youtube import YoutubeIE
  from .pladform import PladformBaseIE
  V = [('https://www.itv.com/hub/liar/2a4547a0012', ITVIE._VALID_URL),
       ('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034', ITVIE._VALID_URL)]
  IE = [YoutubeIE, ITVIE, ITVBTCCIE, PladformBaseIE]
  for (url, regex) in V:
    for ie in IE:
      if ie.suitable(url):
        assert re.match(regex, url) is not None
        break
    else:
      assert False

# Generated at 2022-06-22 07:52:29.041338
# Unit test for constructor of class ITVIE

# Generated at 2022-06-22 07:52:34.411051
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
  url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
  info_dict = {
              'id': 'btcc-2018-all-the-action-from-brands-hatch',
              'title': 'BTCC 2018: All the action from Brands Hatch',
              }
  assert ITVBTCCIE._TEST['url'] == url
  assert ITVBTCCIE._TEST['info_dict'] == info_dict

# Generated at 2022-06-22 07:52:37.568978
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['url'] == ITVBTCCIE(
    )._VALID_URL.match(ITVBTCCIE._TEST['url']).group(0)

# Generated at 2022-06-22 07:52:41.438988
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    infoExtractor = ITVBTCCIE()
    assert infoExtractor._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert infoExtractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:55:11.107102
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.IE_NAME == 'itv'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ITVIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 07:55:11.711093
# Unit test for constructor of class ITVIE
def test_ITVIE():            
    ITVIE()

# Generated at 2022-06-22 07:55:13.940723
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE({'geo_ip_blocks': [
        '193.113.0.0/16', '54.36.162.0/23', '159.65.16.0/21']})

# Generated at 2022-06-22 07:55:20.318887
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    res = ITVBTCCIE().url_result(url)
    assert res['_type'] == 'playlist'
    assert 'entries' in res['_result']
    assert 'btcc-2018-all-the-action-from-brands-hatch' in res['_result']



# Generated at 2022-06-22 07:55:32.894197
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert info_extractor._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert info_extractor._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert info_extractor._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-22 07:55:39.606039
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    smuggle_url_template = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    ie = ITVBTCCIE()
    # Test when class ITVBTCCIE exists
    ie_tests = ie.extract(url)
    # Test when class ITVBTCCIE is not exists
    ie = ITVIE()
    ie_tests = ie.extract(url)

# Generated at 2022-06-22 07:55:42.164375
# Unit test for constructor of class ITVIE
def test_ITVIE():
	assert ITVIE(None)._FORMAT_IDS == (ITVIE.ie_key(), BrightcoveNewIE.ie_key())

# Generated at 2022-06-22 07:55:54.144635
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE_example_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE_example_id = '2a4547a0012'
    ITVIE_example_title = 'Liar - Series 2 - Episode 6'
    ITVIE_example_description = 'md5:d0f91536569dec79ea184f0a44cca089'
    ITVIE_example_series = 'Liar'
    ITVIE_example_season_number = 2
    ITVIE_example_episode_number = 6

    video = ITVIE(ITVIE_example_url)
    assert video.video_id == ITVIE_example_id
    assert video.title == ITVIE_example_title
    assert video.description == ITVIE_example_description
    assert video.series == ITV

# Generated at 2022-06-22 07:56:01.677489
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']
    assert len(ie._TESTS) == 4

# Generated at 2022-06-22 07:56:07.808183
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from you_get.extractors import itv
    from you_get.extractors import itvbtcc
    # Test for ITVIE
    itv_instance = itv.ITVIE()
    itv_instance.url = 'http://www.itv.com/hub/liar/2a4547a0012'
    itv_instance.video_id = '2a4547a0012'
    itv_instance._match_id()
    # Test for ITVBTCCIE
    itvbtcc_instance = itvbtcc.ITVBTCCIE()
    itvbtcc_instance.url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtcc_instance.playlist_id