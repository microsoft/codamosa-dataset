

# Generated at 2022-06-22 07:47:48.459432
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert itvie is not None
    assert itvie.SUCCESS
    assert itvie.itv_id == '2a4547a0012'
    assert itvie.title == 'Liar - Series 2 - Episode 6'
    assert itvie.description == 'Laura\'s killer is finally revealed - but are Andrew\'s crimes about to come to light too?'
    assert itvie.duration == 3600
    assert itvie.series == 'Liar'
    assert itvie.season_number == 2
    assert itvie.episode_number == 6


# Generated at 2022-06-22 07:47:50.786991
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # test if class can be initialised
    ie = ITVBTCCIE()
    assert ie is not None

# Generated at 2022-06-22 07:47:57.198615
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVVideo = ITVIE({'geo_verification_headers': {}})
    video = ITVVideo(ITVVideo.extract_info('http://www.itv.com/hub/liar/2a4547a0012'))
    assert(video.id == '2a4547a0012')
    assert(video.title == 'Liar - Series 2 - Episode 6')
    assert(video.thumbnail == 'https://itv.scene7.com/is/image/itv/prod/image/Liarc1x1_2x')
    assert(video.description == 'md5:d0f91536569dec79ea184f0a44cca089')
    assert(video.duration == 'PT54M0S')
    assert(video.series == 'Liar')

# Generated at 2022-06-22 07:48:09.255836
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = url='http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE()
    ITVBTCCIE(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '56789')
    ITVBTCCIE(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '456789')
    ITVBTCCIE(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '45678901')
    ITVBTCCIE(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '4567890123')

# Generated at 2022-06-22 07:48:16.482189
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    assert i.title == 'Liar - Series 2 - Episode 6', ("Title is '%s' not 'Liar - Series 2 - Episode 6'" % i.title)
    assert i.description.startswith("Andrew Earlham's body is discovered in the Kent"), ("Description is '%s' not starting with 'Andrew Earlham's body is discovered in the Kent'" % i.description)
    assert i.id == '2a4547a0012', ("video id is '%s' not '2a4547a0012'" % i.id)
    assert i.ext == 'mp4', ("video extension is '%s' not 'mp4'" % i.ext)

# Generated at 2022-06-22 07:48:21.420628
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    BTCC = ITVBTCCIE()
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    BTCC._download_webpage = lambda url, playlist_id: None
    BTCC._match_id = lambda url: 'btcc-2018-all-the-action-from-brands-hatch'
    BTCC._og_search_title = lambda webpage, fatal: 'BTCC 2018: All the action from Brands Hatch'
    BTCC._real_extract(test_url)

# Generated at 2022-06-22 07:48:33.267382
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Extracting a valid URL
    assert ITVIE._valid_url(ITVIE._TESTS[0]['url'], ITVIE._VALID_URL)
    # Testing a valid URL with an unavailable video
    assert not ITVIE._valid_url(ITVIE._TESTS[1]['url'], ITVIE._VALID_URL)
    # Testing a valid URL with an InvalidVodcrid error
    assert not ITVIE._valid_url(ITVIE._TESTS[2]['url'], ITVIE._VALID_URL)
    # Testing a valid URL with a ContentUnavailable video
    assert not ITVIE._valid_url(ITVIE._TESTS[3]['url'], ITVIE._VALID_URL)
    # Testing a random string

# Generated at 2022-06-22 07:48:45.623809
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        import brightcove
    except ImportError:
        brightcove = None

    itvbtccie = ITVBTCCIE()
    assert 'Brightcove' == itvbtccie.ie_key()
    assert 'default' == itvbtccie._API_KEY
    assert 'http://players.brightcove.net/%s/default/index.html?videoId=%s' % (itvbtccie._API_KEY, itvbtccie._VIDEO_ID_RE) == itvbtccie._TEMPLATE
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == itvbtccie._BRIGHTCOVE_URL_TEMPLATE
    assert brightcove == itvbtccie._brightcove
    assert ITVBTCCIE._TEST

# Generated at 2022-06-22 07:48:47.114053
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 07:48:47.964211
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:49:03.278896
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """ Unit test for constructor of class ITVBTCCIE """
    itvbtccie = ITVBTCCIE()
    assert itvbtccie

# Generated at 2022-06-22 07:49:06.682647
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from tests.test_ITVIE import ITVExtractorUnitTest

    inst = ITVExtractorUnitTest()

    inst.test_itvbtccie(ITVBTCCIE)

# Generated at 2022-06-22 07:49:10.181026
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert isinstance(instance, ITVBTCCIE)

# Generated at 2022-06-22 07:49:20.788748
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    brightcove_url_template = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    # Download webpage
    webpage = '<div class="hub-page__content"></div>'
    # Extract list of entries

# Generated at 2022-06-22 07:49:25.025222
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:49:30.088914
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Function to test ITVBTCCIE class constructor

# Generated at 2022-06-22 07:49:33.355253
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE_instance = ITVIE()
    assert ITVIE_instance
    assert isinstance(ITVIE_instance, ITVIE)
    assert hasattr(ITVIE_instance, "_real_extract")


# Generated at 2022-06-22 07:49:37.689761
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVE = ITVIE()
    assert ITVE._VALID_URL == ITVE.VALID_URL
    assert ITVE.BRIGHTCOVE_URL_TEMPLATE == ITVE.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-22 07:49:42.225655
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    # test invalid URL
    invalid_url = 'https://www.itv.com/hub/liar/2a4547a0012.html'
    try:
        ie.match_id(invalid_url)
    except ValueError:
        pass
    else:
        raise ValueError('Exception not raised for invalid URL')

# Generated at 2022-06-22 07:49:46.179053
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
  assert ITVBTCCIE()._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:50:20.812554
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    entry = ITVBTCCIE()._real_extract(
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert len(entry['entries']) == 9

# Generated at 2022-06-22 07:50:26.065081
# Unit test for constructor of class ITVIE
def test_ITVIE():
    unit = ITVIE()
    assert unit._VALID_URL is ITVIE._VALID_URL
    assert unit._GEO_COUNTRIES is ITVIE._GEO_COUNTRIES
    assert unit._TESTS is ITVIE._TESTS


# Generated at 2022-06-22 07:50:27.847716
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-22 07:50:30.213639
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert isinstance(ie, ITVIE)

    # Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-22 07:50:36.279484
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ref = {
        'title': 'BTCC 2018: All the action from Brands Hatch',
        'id': 'btcc-2018-all-the-action-from-brands-hatch'
    }
    assert ITVBTCCIE()._real_extract(url) == ref

# Generated at 2022-06-22 07:50:45.144386
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE.ie_key() == 'ITVBTCC'
    assert ITVBTCCIE.ie_key(id='abcdef') == 'ITVBTCC'
    assert ITVBTCCIE._type == 'playlist'
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:50:50.350663
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert info_extractor._GEO_COUNTRIES == ['GB']

# Unit test

# Generated at 2022-06-22 07:50:55.627946
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    d = ITVBTCCIE()
    result = d.BRIGHTCOVE_URL_TEMPLATE % '12345'
    assert result == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=12345'

# Generated at 2022-06-22 07:51:03.537651
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itv = ITVBTCCIE()
    # pass the url to the constructor
    itv._real_extract(url)
    assert itv.BRIGHTCOVE_URL_TEMPLATE.__str__() == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:51:05.976365
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/', {'geo_countries': ['GB']}, 'GB')

# Generated at 2022-06-22 07:52:15.763673
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class ITVBTCCIE(ITVBTCCIE):
        pass

    itvbtccie = ITVBTCCIE(ITVBTCCIE._downloader, ITVBTCCIE._TEST)
    assert itvbtccie._match_id(ITVBTCCIE._TEST['url']) == ITVBTCCIE._TEST['info_dict']['id']
    assert itvbtccie._real_extract(ITVBTCCIE._TEST['url'])['title'] == ITVBTCCIE._TEST['info_dict']['title']

# Generated at 2022-06-22 07:52:17.252655
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(context=None, ie_key=None, *args, **kwargs)

# Generated at 2022-06-22 07:52:27.426685
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCC_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCC_playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCC_content = '<html><head></head><body></body></html>'
    url_expected_output = ITVBTCC_url.replace('btcc-2018-all-the-action-from-brands-hatch',
                                              'HkiHLnNRx_default/index.html?videoId=')
    test_url = ITVBTCCIE()
    test_url._download_webpage = lambda url, playlist_id: ITVBTCC_content

# Generated at 2022-06-22 07:52:29.578582
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test ITVIE constructor."""
    info_extractor = ITVIE()
    info_extractor.report_warning = lambda *args: None

# Generated at 2022-06-22 07:52:33.268406
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    title = ie.BRIGHTCOVE_URL_TEMPLATE %'5909362426001'
    new_url = ie.construct_url(title)
    assert(new_url == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5909362426001')

# Generated at 2022-06-22 07:52:35.252116
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)
    ITVBTCCIE(None)

# Generated at 2022-06-22 07:52:36.276705
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE().constructor(
        'http://www.itv.com/hub/liar/2a4547a0012'
    )

# Generated at 2022-06-22 07:52:41.340971
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ITVBTCCIE('http://www.itv.com/btcc/races/brands-hatch-indy-race-one-highlights')

# Generated at 2022-06-22 07:52:50.753387
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()
    IE.extract('https://www.itv.com/hub/liar/2a4547a0012')
    IE.extract('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    IE.extract('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    IE.extract('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')


# Generated at 2022-06-22 07:52:54.418740
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert 'BTCC 2018: All the action from Brands Hatch' in ie._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:55:35.905208
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itvbtccie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    assert itvbtccie.BRIGHTCOVE

# Generated at 2022-06-22 07:55:47.575136
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()

    # Test cases for _VALID_URL
    valid_url_tests = [
        # valid url
        ('https://www.itv.com/hub/liar/2a4547a0012', '2a4547a0012' ),
        # invalid url
        ('https://www.itv.com/hub/liar/2a4547a', None),
        ('https://www.itv.com/hub/liar/2a4547a0012/', None)
    ]

    # Test cases for _real_extract
    webpage = r'<script type="application/ld+json">' \
              r'{"@context":"http://schema.org","@type":"VideoObject","headline":"Headline"}}' \
              r'</script>'


# Generated at 2022-06-22 07:55:49.769026
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert isinstance(info_extractor, ITVIE)

# Generated at 2022-06-22 07:55:53.138059
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-22 07:55:56.292604
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:55:58.256311
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(downloader=None)

# Generated at 2022-06-22 07:56:05.512889
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Probably this is the correct way to test
    # ITVIE()._extract_instances(ITVIE()._html_search_regex(r'<title>(.*?)</title>', '<title>ITV</title>', 'title'))
    assert ITVIE()._html_search_regex(r'<title>(.*?)</title>', '<title>ITV</title>', 'title') == 'ITV'
    assert ITVIE()._search_regex(ITVIE._VALID_URL, 'https://www.itv.com/hub/liar/2a4547a0012', 'id') == '2a4547a0012'

# Generated at 2022-06-22 07:56:06.236524
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:56:08.388969
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIETest = ITVIE('http://www.itv.com/hub/thunderbirds-are-go')
    ITVIETest.test()

# Generated at 2022-06-22 07:56:20.168766
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from cStringIO import StringIO
    from urlparse import urlparse

    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    webpage = StringIO("""
<html>
<div class='video-wrapper' data-video-id='5713576814001'></div>
<div class='video-wrapper' data-video-id='5713576814002'></div>
<div class='video-wrapper' data-video-id='5713576814003'></div>
</html>
""")

    IE = ITVBTCCIE()
    info = IE._real_extract(url)

    assert info['id'] == 'btcc-2018-all-the-action-from-brands-hatch'