

# Generated at 2022-06-22 07:47:40.625486
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-22 07:47:44.636851
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = url_or_none('https://www.itv.com/hub/liar/2a4547a0012')
    assert ITVIE.suitable(url)
    assert ITVIE.suitable(url, url)

# Generated at 2022-06-22 07:47:48.737075
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # URL is accessible by geo-location
    assert ITVBTCCIE.suitable(url)


# Generated at 2022-06-22 07:47:51.738335
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:48:01.821125
# Unit test for constructor of class ITVIE
def test_ITVIE():
	test_input = {
		'url': 'https://www.itv.com/hub/liar/2a4547a0012',
		'info_dict': {
			'id': '2a4547a0012',
			'ext': 'mp4',
			'title': 'Liar - Series 2 - Episode 6',
			# 'description': 'md5:d0f91536569dec79ea184f0a44cca089',
			'series': 'Liar',
			'season_number': 2,
			'episode_number': 6,
		},
		'params': {
			# m3u8 download
			'skip_download': True,
		},
	}
	# test_input = {

# Generated at 2022-06-22 07:48:07.137207
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IE = ITVBTCCIE(None)
    # Multiple definitions of BRIGHTCOVE_URL_TEMPLATE
    assert(IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-22 07:48:13.326150
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test for constructor of ITVBTCCIE
    itvbtccie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert itvbtccie._VALID_URL == ITVBTCCIE._VALID_URL
    assert itvbtccie._TEST == ITVBTCCIE._TEST

# Generated at 2022-06-22 07:48:15.260508
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert isinstance(itv_ie, ITVIE)



# Generated at 2022-06-22 07:48:18.518648
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:21.997871
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:48:43.053848
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        # Only run this test when the BTCC is ongoing
        from .brightcove import BrightcoveNewIE
        BrightcoveNewIE._TESTS[0]['skip'] = True
        ITVBTCCIE(InfoExtractor())
    except IndexError:
        try:
            from .brightcove import BrightcoveNewIE
        except IndexError:
            from .itv import ITVBTCCIE
        finally:
            BrightcoveNewIE._TESTS[0]['skip'] = False

# Generated at 2022-06-22 07:48:46.506961
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-22 07:48:53.117657
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .testcases import BaseTestCase
    from ytdl import YoutubeDL
    class TestITVIE(BaseTestCase):
        def test_testcases(self):
            with YoutubeDL(params={}) as ydl:
                ydl.add_default_info_extractors()
                self.assertTrue(
                    'itv' in list(map(lambda e: e.IE_NAME, ydl.get_info_extractors())))
    TestITVIE().run(result=None)

# Generated at 2022-06-22 07:48:56.475174
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert ie.playlist_title == "Liar"

# Generated at 2022-06-22 07:49:08.009501
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?itv\\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-22 07:49:11.990507
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE(None)

    # Test for constructor without parameter
    assert info_extractor != None

    # Test for constructor with parameter
    assert ITVBTCCIE('test_parameter') != None


# Generated at 2022-06-22 07:49:14.628388
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Test the constructor of class ITVBTCCIE
    """
    assert ITVBTCCIE(_downloader=None).ie_key() == 'ITVBTCC'

# Generated at 2022-06-22 07:49:19.285908
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert(itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')


# Generated at 2022-06-22 07:49:24.757356
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import unittest
    class TestITVIE(unittest.TestCase):
        def test_constructor(self):
            itv = ITVIE(None)
            assert itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:49:27.084961
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test empty object
    obj = ITVBTCCIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE != None
    assert obj._VALID_URL != None
    assert obj._TESTS != None



# Generated at 2022-06-22 07:50:05.904816
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtcc = ITVBTCCIE()
    test_valid_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert itvbtcc._VALID_URL == \
           'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itvbtcc._TEST['url'] == \
           'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:50:08.217263
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE.suitable(url)

# Generated at 2022-06-22 07:50:14.266960
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    entry = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert entry.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert entry

# Generated at 2022-06-22 07:50:15.226437
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert issubclass(ITVBTCCIE, InfoExtractor)

# Generated at 2022-06-22 07:50:17.278686
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()

# Generated at 2022-06-22 07:50:21.640609
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE("https://www.itv.com/hub/liar/2a4547a0012")._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:50:24.716578
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-22 07:50:25.736898
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test for constructor of class ITVIE
    print(ITVIE)

# Generated at 2022-06-22 07:50:27.466192
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # This test will fail if you are not in the UK ;)
    IE = ITVBTCCIE(None)
    assert IE.geo_countries() == ['GB']

# Generated at 2022-06-22 07:50:36.704455
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = ITVIE._TESTS[0]['url']
    video_id = ITVIE._TESTS[0]['info_dict']['id']
    webpage = ITVIE._download_webpage(ITVIE(), url, video_id)
    params = extract_attributes(ITVIE._search_regex(
        r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params'))
    ios_playlist_url = params.get('data-video-playlist') or params['data-video-id']
    hmac = params['data-video-hmac']
    headers = ITVIE.geo_verification_headers()

# Generated at 2022-06-22 07:51:49.494688
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE()(ITVBTCCIE._TEST['url'])
    assert len(result['entries']) == ITVBTCCIE._TEST['playlist_mincount']
    for video_id in re.findall(r'data-video-id=["\'](\d+)', ITVBTCCIE._TEST['info_dict']['webpage_html_with_properties']):
        assert video_id == result['entries'][0]['id']

# Generated at 2022-06-22 07:51:51.582788
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.IE_NAME == 'ITV'
    assert ie.IE_DESC == 'ITV Player'

# Generated at 2022-06-22 07:51:59.447116
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    video_id = '5823712511001'
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # Ensure that the constructor is actually doing something
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

    # Ensure that the constructor is actually doing something
    assert str(ITVBTCCIE._TEST['url']) == url


# Generated at 2022-06-22 07:52:04.227224
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE()
    except NameError as e:
        assert e.args[0] == "name 'BrightcoveNewIE' is not defined"

# Generated at 2022-06-22 07:52:06.772376
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(url)

# Generated at 2022-06-22 07:52:11.954699
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    unit_test_class = ITVBTCCIE()
    assert unit_test_class.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:52:16.117966
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId='


# Generated at 2022-06-22 07:52:18.825658
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')


# Generated at 2022-06-22 07:52:20.078323
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
        assert ITVBTCCIE()

# Generated at 2022-06-22 07:52:22.952854
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert re.search(r'brightcove', ie.BRIGHTCOVE_URL_TEMPLATE) is not None

# Generated at 2022-06-22 07:54:50.986597
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-22 07:54:56.396853
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Constructor of class ITVIE."""
    ie = ITVIE(None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/4040943777001/HkcNnf5yr_default/index.html?videoId=%s'


# Generated at 2022-06-22 07:55:01.134052
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    cie = ITVBTCCIE()
    assert cie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:55:02.388155
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None)._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-22 07:55:10.799312
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist = ITVBTCCIE()._real_extract(url)
    assert playlist['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert playlist['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert len(playlist['entries']) == 9

# Generated at 2022-06-22 07:55:14.594987
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE(1, 0, 0)(url)

# Generated at 2022-06-22 07:55:19.035573
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert inst._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:55:25.251863
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ie = ITVIE()
    ie.initialize(url)
    ie.extract(url)
    # Unit test for constructor of class ITVBTCCIE
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    ie.initialize(url)
    ie.extract(url)

# Generated at 2022-06-22 07:55:27.782741
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.__name__ == 'ITVIE'
    assert ITVIE.__doc__ != None


# Generated at 2022-06-22 07:55:31.387198
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'