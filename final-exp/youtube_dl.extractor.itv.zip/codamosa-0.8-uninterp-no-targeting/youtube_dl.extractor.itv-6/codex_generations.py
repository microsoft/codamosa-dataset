

# Generated at 2022-06-22 07:47:39.364523
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 07:47:42.135478
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert isinstance(ie, ITVIE)

# Generated at 2022-06-22 07:47:51.039364
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    params = {
        'data-video-id': '2a4547a0012',
        'data-video-hmac': 'Ft8WMeF9gDZP4NOtExgepw',
        'data-video-playlist': 'https://www.itv.com/itvplayer/video/2a4547a0012',
    }
    assert ITVIE._match_id(url) == video_id
    assert ITVIE._extract_params(url) == params

# Generated at 2022-06-22 07:48:00.053592
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc_ie = ITVBTCCIE()
    assert btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert btcc_ie.playlist_mincount == 9
    assert btcc_ie.playlist_result == btcc_ie._build_playlist
    assert btcc_ie._real_extract == btcc_ie.extract
    assert btcc_ie.url_result == btcc_ie._build_url
    assert btcc_ie._match_id == btcc_ie._match_id
    assert btcc_ie.is_suitable == btcc_ie._is_

# Generated at 2022-06-22 07:48:05.886729
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = ('https://www.itv.com/hub/peston-on-sunday/2a4571a0003?'
           'P_p_auth=0Vu-myt1&_P_p_auth_s_s=epg')
    instance = ITVIE(url)
    assert instance.id == '2a4571a0003'

# Generated at 2022-06-22 07:48:10.213081
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:20.859114
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:29.801397
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Valid ITVIE page
    webpage = 'https://www.itv.com/hub/paul-o-grady-for-the-love-of-dogs/2a3023a0045'
    url = ITVIE._url_for_page(webpage)
    assert url == 'https://www.itv.com/hub/paul-o-grady-for-the-love-of-dogs/2a3023a0045'
    assert ITVIE._id_for_page(webpage) == '2a3023a0045'

# Generated at 2022-06-22 07:48:32.083191
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Assert that ITVBTCCIE has no constructor parameters
    assert ITVBTCCIE.__init__.__code__.co_argcount == 1

# Generated at 2022-06-22 07:48:44.464961
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-22 07:48:58.503479
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    return ITVBTCCIE(InfoExtractor())


# Generated at 2022-06-22 07:49:01.121094
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:49:05.562013
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Test the ITVBTCCIE constructor
    """
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:49:10.846806
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    result = ie.BRIGHTCOVE_URL_TEMPLATE % '5829222991001'
    assert result == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5829222991001'
    return 0


# Generated at 2022-06-22 07:49:17.824375
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_video_id='2a4547a0012'
    test_url='https://www.itv.com/hub/liar/2a4547a0012'

    # Test the constructor:
    assert ITVIE._TESTS[0]['url'] == test_url
    assert ITVIE._TESTS[0]['info_dict']['id'] == test_video_id

    # Test the extractor:
    result_video_id=ITVIE._real_extract(ITVIE,'https://www.itv.com/hub/liar/2a4547a0012')['id']
    assert result_video_id == test_video_id

# Generated at 2022-06-22 07:49:29.129061
# Unit test for constructor of class ITVIE
def test_ITVIE():
    expected_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    expected_id = "2a4547a0012"
    expected_title = "Liar - Series 2 - Episode 6"
    expected_description = "Watch Liar - Series 2 - Episode 6 from ITV"
    expected_thumbnail = 'https://itv.img-edge.com/image?handle=image&name=itv-image&quality=30&format=jpg&width=700&height=700&imageAlign=fit&source=%2Fvideo%2Fimages%2Fp07fhv69%2Fstill_1.jpg'

    i = ITVIE()
    # Test with URL
    info = i.extract(expected_url)
    # Check expected values

# Generated at 2022-06-22 07:49:39.774932
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    m = ITVBTCCIE()
    assert ITVBTCCIE._VALID_URL == 'https?://(?:www\\.)?itv\\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert m._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    return

# Generated at 2022-06-22 07:49:40.391453
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:49:41.325386
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE.test()

# Generated at 2022-06-22 07:49:46.643391
# Unit test for constructor of class ITVIE
def test_ITVIE():
    title = "Liar - Series 2 - Episode 6"
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    video = ITVIE()._call_api(url)
    assert video.title == title

# Generated at 2022-06-22 07:50:16.501017
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Given
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    # When
    ITVBTCCIE(url)
    # Then
    # Assert no exception is generated


# Generated at 2022-06-22 07:50:19.973784
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Unit test for constructor of class ITVBTCCIE
    """

    # Test for constructor of class ITVBTCCIE
    play = ITVBTCCIE()
    assert type(play) is ITVBTCCIE

# Generated at 2022-06-22 07:50:26.483382
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:50:30.444196
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    test_id = ie._match_id(test_url)
    assert test_id == '2a4547a0012'

# Generated at 2022-06-22 07:50:41.619340
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    # Verify the video is uploaded.
    assert 'https://' in i._real_extract('https://www.itv.com/hub/liar/2a4547a0012')['formats'][0]['url']
    # Test for invalid request
    # Video is unavailable for itv user
    assert i._real_extract('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')['_type'] == 'url_transparent'
    # Test for invalid request
    # ContentUnavailable (used in extractor.py)

# Generated at 2022-06-22 07:50:53.631389
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'
    webpage_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    webpage = """
    <html>
        <script>
            var obj = {
                'somefield': 'somevalue',
                'data-video-id': 'somevalue',
                'data-video-playlist': 'somevalue',
                'data-video-hmac': 'somevalue'
            };
        </script>
    </html>
    """

    # test with valid url
    video = ITVIE({})._real_extract(webpage_url)
    assert video['id'] == video_id
    assert video['title'] == 'Liar - Series 2 - Episode 6'
    assert video['duration'] == 63

    #

# Generated at 2022-06-22 07:51:03.602339
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_case = ITVIE()
    test_case._download_webpage = lambda url, video_id, note='Downloading webpage', errnote='Unable to download webpage': '<div class="video__player" data-video-id="2a4547a0012" data-video-hmac="a2f0c35a3d92a64c0f8df0d5538fe7e4" data-video-title="Liar - Series 2 - Episode 6" data-video-playlist="https://itv.api.brightcove.com/v1/franchises/33/playlists/2a4547a0012?embedded=true&amp;width=100%" id="video" data-video-asset-id="475838">'

# Generated at 2022-06-22 07:51:08.961438
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # we expect an exception to be thrown because the URL is invalid
    ITVBTCCIE().url_result(url)

# Generated at 2022-06-22 07:51:12.735108
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test loading ITV channel
    r = ITVIE().extract('https://www.itv.com/hub/liar/2a4547a0012')
    assert(r['id'] == '2a4547a0012')

# Generated at 2022-06-22 07:51:17.478176
# Unit test for constructor of class ITVIE
def test_ITVIE():
    _ITV_SAMPLE_URL = 'http://www.itv.com/hub/through-the-keyhole/2a2271a0033'
    iTVIE = ITVIE()
    assert(iTVIE.url_result('http://www.itv.com/hub/through-the-keyhole/2a2271a0033'))

# Generated at 2022-06-22 07:52:13.128768
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/1a4547a0012')

# Generated at 2022-06-22 07:52:21.172848
# Unit test for constructor of class ITVIE
def test_ITVIE():
        # Test case of ITV video
        ITVIE(None).extract('https://www.itv.com/hub/liar/2a4547a0012')
        # Test case of unavailable video
        ITVIE(None).extract('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')
        # Test case of video with invalid VOD CRID
        ITVIE(None).extract('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')

# Generated at 2022-06-22 07:52:21.833118
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:52:22.896593
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE != None

# Generated at 2022-06-22 07:52:25.182393
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE._downloader)._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-22 07:52:29.313580
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Tests the constructor of class ITVIE
    """
    # Testing format default
    ie = ITVIE('https://www.bfmtv.com/videos/')
    assert ie.format == 'bestvideo+bestaudio[protocol!=http_dash_segments]/best'


# Generated at 2022-06-22 07:52:32.455216
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # In order to create instance of ITVIE it's needed to pass an url and an ID
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012', '2a4547a0012')

# Generated at 2022-06-22 07:52:37.090195
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    m = re.match(ITVIE._VALID_URL, url)
    assert(m and m.group('id') == '2a4547a0012')

# Generated at 2022-06-22 07:52:41.341556
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE()
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:52:47.316740
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # ITVExtractor is the class of the module ITV.py, but ITVIE is in
    # the file common.py, so we need to refer it as common.ITVIE
    assert(common.ITVIE)

if __name__ == '__main__':
    # Run the unit test
    test_ITVIE()

# Generated at 2022-06-22 07:55:10.661828
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	with open('tests/samples/BTCC.html') as file:
		html = file.read()
	assert type(ITVBTCCIE('')._search_regex(r'data-video-id=["\'](\d+)', html, '')) == list

# Generated at 2022-06-22 07:55:11.568900
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(InfoExtractor)

# Generated at 2022-06-22 07:55:12.146512
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:55:19.349646
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test if the constructor of class ITVBTCCIE properly extracts playlist_id from the given url
    # Test case: URL format http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch
    # Test method: Compares playlist_id extracted by constructor with known value "btcc-2018-all-the-action-from-brands-hatch"
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = ITVBTCCIE(url)._match_id(url)

# Generated at 2022-06-22 07:55:22.203359
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._TEST == ITVBTCCIE._TEST

# Generated at 2022-06-22 07:55:26.013277
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .brightcove import BrightcoveNewIE
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE.index('%s') > 0
    assert ITVBTCCIE.ie_key() == BrightcoveNewIE.ie_key()

# Generated at 2022-06-22 07:55:32.684689
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    doc = ITVBTCCIE(
        "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch",
        "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert doc.extract()

# Generated at 2022-06-22 07:55:35.157006
# Unit test for constructor of class ITVIE
def test_ITVIE():
#	logging.basicConfig(level=logging.INFO)
#	logging.getLogger('youtube_dl.utils').setLevel(logging.INFO)
	ITVIE()

# Generated at 2022-06-22 07:55:37.443914
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test1 = ITVIE()
    test2 = ITVIE()
    test3 = ITVIE()
    test4 = ITVIE()
    test5 = ITVIE()
    test6 = ITVIE()
    test7 = ITVIE()



# Generated at 2022-06-22 07:55:39.393766
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE.startswith('http://')