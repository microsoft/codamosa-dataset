

# Generated at 2022-06-22 07:47:44.147136
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert itvbtccie._real_initialize() == True

# Generated at 2022-06-22 07:47:46.275759
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-22 07:47:48.918533
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class_ = globals()['ITVBTCCIE']
    assert issubclass(class_, ITVIE)
    assert issubclass(class_, InfoExtractor)

# Generated at 2022-06-22 07:47:59.360422
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_obj = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert test_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert test_obj._match_id("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch") == "btcc-2018-all-the-action-from-brands-hatch"

# Generated at 2022-06-22 07:48:00.485236
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-22 07:48:04.449267
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    itv_ie = ITVIE(url)
    assert itv_ie.url == url

# Generated at 2022-06-22 07:48:07.847599
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE('a', 'b', 'c')
    assert(len(itv.IE_NAME) > 0)
    assert(len(itv.FILE_EXTENSIONS) > 0)

# Generated at 2022-06-22 07:48:11.766540
# Unit test for constructor of class ITVIE
def test_ITVIE():
    with open('output.txt', 'w') as file_output:
        print('unit test for constructor of class ITVIE', file=file_output)
        print(ITVIE._TESTS, file=file_output)


# Generated at 2022-06-22 07:48:13.384889
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert isinstance(instance, ITVBTCCIE)

# Generated at 2022-06-22 07:48:13.760051
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:48:39.360671
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.IE_NAME == 'itv'

# Generated at 2022-06-22 07:48:50.291812
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Unit test for the constructor of class ITVBTCCIE
    """
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    video_id = 'btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:48:53.376819
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:49:05.450602
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE('https://www.itv.com/hub/liar/2a4547a0012', '')
    assert i.suitable()
    assert i.__class__ is ITVIE
    assert i._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:49:06.262422
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test whether the constructor of class ITVBTCCIE works well.
    ITVBTCCIE()

# Generated at 2022-06-22 07:49:17.680519
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = ITVBTCCIE._TEST['url']
    test_player_url = ITVBTCCIE._TEST['player_url']
    test_playlist_id = ITVBTCCIE._TEST['playlist_id']
    test_playlist_count = ITVBTCCIE._TEST['playlist_count']
    test_playlist_mincount = ITVBTCCIE._TEST['playlist_mincount']
    test_entry_count = ITVBTCCIE._TEST['entry_count']

    entry = ITVBTCCIE().url_result(test_url)

    assert entry.playlist_id == test_playlist_id
    assert entry.playlist_count == test_playlist_count
    assert entry.playlist_mincount == test_playlist_mincount

# Generated at 2022-06-22 07:49:20.176010
# Unit test for constructor of class ITVIE
def test_ITVIE():
    iv = ITVIE({})
    assert isinstance(iv, InfoExtractor)

# Generated at 2022-06-22 07:49:27.194153
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Check that ITVBTCCIE constructor succeeds
    # when invoked using ITVBTCCIE(ie)
    IE_KEY = 'ITVBTCCIE'
    EXPECTED_CLASS = ITVBTCCIE

    # Create our IE
    iev = ITVBTCCIE(InfoExtractor(IE_KEY))

    # Check that class is correct
    assert isinstance(iev, EXPECTED_CLASS)

    # check that ie key is correct
    assert iev._ies[IE_KEY]._VALID_URL == EXPECTED_CLASS._VALID_URL

# Generated at 2022-06-22 07:49:29.410641
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_verification_headers() == {'X-Forwarded-For': '194.82.188.112'}

# Generated at 2022-06-22 07:49:40.765020
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-22 07:50:37.244557
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None, "No url provided")
    ITVIE(None, "https://www.itv.com/hub/through-the-keyhole/2a2271a0033")

# Generated at 2022-06-22 07:50:38.860800
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()

# Generated at 2022-06-22 07:50:42.858737
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor = ITVBTCCIE.__bases__[0].__init__.im_func
    assert constructor(ITVBTCCIE, 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == None

# Generated at 2022-06-22 07:50:45.729988
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE({}, {}, ITVIE._TESTS[0]).run()
    assert test.result == ITVIE._TESTS[0]['info_dict']

# Generated at 2022-06-22 07:50:47.580595
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert isinstance(itv_ie, ITVIE)

# Generated at 2022-06-22 07:50:49.053678
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Test: ITVIE class construction
    """
    ITVIE()

# Generated at 2022-06-22 07:50:55.071317
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._match_id(url+'/') == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._match_id(url+'#') == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._match_id(url+'/') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:50:55.660713
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:50:56.510625
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()



# Generated at 2022-06-22 07:51:00.551173
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_cie = ITVBTCCIE()
    assert test_cie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:53:14.983525
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    parse = ITVBTCCIE.suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')[0]
    assert parse('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:53:23.460587
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # This URL is for ongoing race of 2018 BTCC
    race_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE(ITVBTCCIE._downloader)._match_id(race_url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE(ITVBTCCIE._downloader).suitable(race_url)
    assert not ITVBTCCIE(ITVBTCCIE._downloader).suitable(
        'http://www.itv.com/hub/benidorm/2a2891a0062')

# Generated at 2022-06-22 07:53:25.239637
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE



# Generated at 2022-06-22 07:53:28.837615
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    test = ie.BRIGHTCOVE_URL_TEMPLATE % '5866953099001'
    # The test string is also the expected result
    assert ie.BRIGHTCOVE_URL_TEMPLATE % '5866953099001' == test

# Generated at 2022-06-22 07:53:32.849502
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()._real_extract(
        "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    )

# Generated at 2022-06-22 07:53:34.748313
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')

# Generated at 2022-06-22 07:53:41.778522
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import unittest
    from itv import ITVIE

    class TestITVIE(unittest.TestCase):
        def test_constructor_should_assign_url(self):
            ie = ITVIE(url='http://www.itv.com/hub/liar/2a4547a0012')
            self.assertEqual(ie.url, 'http://www.itv.com/hub/liar/2a4547a0012')
            
    unittest.main()

# Generated at 2022-06-22 07:53:44.029295
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE is ITVBTCCIE().__class__

# Generated at 2022-06-22 07:53:45.727573
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-22 07:53:47.968129
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test:
    #  ITVIE() should be an instance of InfoExtractor
    assert isinstance(ITVIE(), InfoExtractor)
