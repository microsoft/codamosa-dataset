

# Generated at 2022-06-22 07:47:39.255295
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:47:41.417488
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert str(ie) == "<ITVBTCCIE 'itv.com/btcc'>"

# Generated at 2022-06-22 07:47:42.140867
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:47:44.290565
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-22 07:47:46.431018
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IT = ITVBTCCIE()
    assert IT.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 07:47:50.437267
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE();
    assert isinstance(instance, ITVBTCCIE)
    assert ITVBTCCIE.__mro__ == (ITVBTCCIE, InfoExtractor)


# Generated at 2022-06-22 07:47:56.960768
# Unit test for constructor of class ITVIE

# Generated at 2022-06-22 07:48:09.034725
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    video_id = '5899838378001'
    url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s' % video_id
    url = ITVBTCCIE._resolve_redirects(url)
    assert url == 'https://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s' % video_id
    brightcove_new = ITVBTCCIE()._build_brightcove_url(url, {})
    assert brightcove_new.startswith('http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=')
    assert Bright

# Generated at 2022-06-22 07:48:12.579601
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL != ITVBTCCIE._VALID_URL
    assert ITVIE._TESTS != ITVBTCCIE._TEST
    assert ITVIE._TEST



# Generated at 2022-06-22 07:48:22.906115
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert(
        ITVBTCCIE._valid_url(
            'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', ITVBTCCIE)
    )
    assert(
        ITVBTCCIE._valid_url(
            'http://www.itv.com/btcc/brands-hatch/qualifying/2018/1', ITVBTCCIE)
    )
    assert(
        ITVBTCCIE._valid_url(
            'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', ITVBTCCIE)
    )

# Generated at 2022-06-22 07:48:46.458903
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()

    # Test URLs
    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ie._match_id(test_url) == '2a4547a0012'
    assert ie._match_id('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'
    assert ie._match_id('https://www.itv.com/hub/liar/2a4547a0012/') == '2a4547a0012'
    assert ie._match_id('https://www.itv.com/hub/liar/2a4547a0012/player') == '2a4547a0012'

# Generated at 2022-06-22 07:48:50.662055
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:53.537892
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVBTCCIE()
    expected = r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    observed = x._VALID_URL
    assert expected == observed

# Generated at 2022-06-22 07:48:54.543203
# Unit test for constructor of class ITVIE
def test_ITVIE():
    if ITVIE is None:
        assert False, 'No ITVIE found'

# Generated at 2022-06-22 07:48:56.940708
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-22 07:49:08.749429
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVIE()
    assert x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert x.geo_verification_headers()['Accept'] == 'application/vnd.itv.vod.playlist.v2+json'
    assert x.geo_verification_headers()['Client-Version'] == '3.1.3'
    assert x.geo_verification_headers()['Accept-Language'] == 'en-GB'
    assert x.geo_verification_headers()['DeviceView'] == 'default'
    assert x.geo_verification_headers()['Connection'] == 'keep-alive'
    assert x.geo

# Generated at 2022-06-22 07:49:13.314830
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE(None)._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:49:18.115324
# Unit test for constructor of class ITVIE
def test_ITVIE():

    itv = ITVIE()
    assert itv.geo_verification_headers() == {
        'X-GeoIP': 'GB:LON:51.4:-0.3',
        'X-GeoIP-Country-Code': 'GB',
        'X-Forwarded-For': 'GB:LON:51.4:-0.3',
    }

# Generated at 2022-06-22 07:49:22.250839
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == ITVBTCCIE._VALID_URL
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 07:49:25.775244
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # just an object of class ITVIE
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-22 07:49:58.320158
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video = ITVIE()
    assert video.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-22 07:50:01.320658
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')._TEST


# Generated at 2022-06-22 07:50:02.283223
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE() is not None

# Generated at 2022-06-22 07:50:10.105496
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie_var = ITVIE()
    assert ie_var._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie_var._TESTS[1]['url'] == 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033'
    assert ie_var._TESTS[1]['only_matching']
    assert ie_var._TESTS[2]['url'] == 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    assert ie_var._TESTS[2]['only_matching']
    assert ie_var._TES

# Generated at 2022-06-22 07:50:22.341319
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    webpage = '<html></html>'
    ios_playlist_url = '%s-ios.json' % video_id
    ios_playlist = '{"Playlist":{"Video":{"MediaFiles":[{"Href":"https://url.com/video.mp4"}]}}}'
    info = []

# Generated at 2022-06-22 07:50:23.479477
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:50:24.318151
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:50:28.253876
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    a = ITVBTCCIE()
    assert a.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:50:29.232845
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE()
    except Exception:
        assert False

# Generated at 2022-06-22 07:50:30.356064
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() == 'itv:btcc'

# Generated at 2022-06-22 07:51:32.024279
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE(InfoExtractor._downloader)
    assert(i.geo_verification_headers() != {})
    assert(i.geo_blocked(u'GB') == False)
    assert(i.geo_blocked(u'US') == False)
    assert(i.geo_blocked(u'ZZ') == True)

# Generated at 2022-06-22 07:51:38.593138
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE();
    assert test._TEST['url'] == test.BRIGHTCOVE_URL_TEMPLATE % test._TEST['id']
    assert test._TEST.get('info_dict').get('title') == test._TEST['title']
    assert test._TEST['playlist_mincount'] is not None

# Generated at 2022-06-22 07:51:41.183300
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE('http://www.itv.com/hub/woman-of-steel/2a4530a0018')
    except ImportError:
        return

# Generated at 2022-06-22 07:51:45.182537
# Unit test for constructor of class ITVIE
def test_ITVIE():
    invalid_url = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    assert ITVIE(None)._check_valid_url(invalid_url)

# Generated at 2022-06-22 07:51:57.041747
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class ITVBTCCIE_Test(ITVBTCCIE):
        def __init__(self, _):
            self.args = _
            self.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    test_obj = ITVBTCCIE_Test('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert test_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert test_obj._VAL

# Generated at 2022-06-22 07:52:06.618068
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:52:08.417633
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-22 07:52:10.899288
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-22 07:52:22.203508
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.ie_key() == 'ITVBTCC'
    assert ie.SUFFIX == 'btcc.com'

# Generated at 2022-06-22 07:52:26.180632
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info = ITVBTCCIE()
    assert (info.BRIGHTCOVE_URL_TEMPLATE ==
            'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-22 07:54:45.144599
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .common import TestCase
    from .utils import get_xml
    from .compat import mock

    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

    t = TestCase({
        'url': url,
        '_type': 'playlist',
        'playlist_mincount': 9,
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'BTCC 2018: All the action from Brands Hatch'
    })

    with mock.patch('youtube_dl.downloader.http.HttpFD', wraps=t.test_result()):
        ITVBTCCIE()

# Generated at 2022-06-22 07:54:46.997944
# Unit test for constructor of class ITVIE
def test_ITVIE():
    msg = "Constructor for class ITVIE"
    assert ITVIE is ITVIE(msg), msg

# Generated at 2022-06-22 07:54:56.231666
# Unit test for constructor of class ITVIE
def test_ITVIE():
    #The object is created with the attributes of ITVIE
    itv = ITVIE()

    #The attributes are checked
    assert itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:55:01.453656
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-22 07:55:02.127586
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()

# Generated at 2022-06-22 07:55:04.754750
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Unit test for constructor of class ITVIE

    """
    itvie_object  = ITVIE()
    print(itvie_object._VALID_URL)
    print(itvie_object._TESTS)


# Generated at 2022-06-22 07:55:08.580089
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE('https://www.itv.com/hub/liar/2a4547a0012',
                lambda _: 'foobar')
    itv.download = lambda *args, **kwargs: 'foobar'
    itv._extract_brightcove_url = lambda *args, **kwargs: 'foobar'

    itv.test()

# Generated at 2022-06-22 07:55:18.135525
# Unit test for constructor of class ITVIE

# Generated at 2022-06-22 07:55:24.118449
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvBTCCIE = ITVBTCCIE()
    assert itvBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:55:35.580927
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'
    webpage = 'http://www.example.com'
    params = '<div data-video-id="2a4547a0012" data-video-hmac="e3d88d3fed45445097ff39b11a9d8462" id="video">'
    params = extract_attributes(params)

    info_dict = {
        'id': video_id,
        'ext': 'mp4',
        'title': 'Liar - Series 2 - Episode 6',
        'description': 'md5:d0f91536569dec79ea184f0a44cca089',
        'series': 'Liar',
        'season_number': 2,
        'episode_number': 6}

    itvie = ITVIE()

    assert itv