

# Generated at 2022-06-22 07:47:46.033095
# Unit test for constructor of class ITVIE
def test_ITVIE():
    if ITVIE.suitable("https://www.itv.com/hub/liar/2a4547a0012"):
        assert ITVIE("https://www.itv.com/hub/liar/2a4547a0012")._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
        assert ITVIE("https://www.itv.com/hub/liar/2a4547a0012")._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-22 07:47:55.516978
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/broadchurch/2a2c1f00004'
    html = download_webpage(url)
    assert(re.search(r'<[^>]+data-video-id\s*=\s*"BcY3Y3Y3Y3Y3Y"[^>]*>', html) != None)

# Generated at 2022-06-22 07:48:00.141642
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:01.808858
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert 'ITVBTCCIE' in dir(ITVBTCCIE)

# Generated at 2022-06-22 07:48:04.147802
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert(itv_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')

# Generated at 2022-06-22 07:48:15.701727
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itvie._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert itvie._TESTS[0]['info_dict']['id'] == '2a4547a0012'
    assert itvie._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert itvie._TESTS[0]['info_dict']['title'] == 'Liar - Series 2 - Episode 6'


# Generated at 2022-06-22 07:48:17.489590
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Test ITVIE constructor
    """
    assert ITVIE._STREAM_IMPLIES_HLS

# Generated at 2022-06-22 07:48:22.415706
# Unit test for constructor of class ITVIE
def test_ITVIE():
    _constructor_test(ITVIE(),
        ['https://www.itv.com/hub/liar/2a4547a0012', 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033'],
        'http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034',
        'http://www.itv.com/hub/james-martins-saturday-morning/2a5159a000z')



# Generated at 2022-06-22 07:48:24.938602
# Unit test for constructor of class ITVIE
def test_ITVIE():
    for test in ITVIE._TESTS:
        yield (test_ITVIE_constructor, test['url'], ITVIE)


# Generated at 2022-06-22 07:48:31.570998
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Can't instantiate interface
    try:
        ITVBTCCIE()
    except TypeError as err:
        assert 'Can\'t instantiate abstract' in str(err)
    # Can't instantiate because of unimplemented abstract method
    try:
        ITVBTCCIE._real_extract(None, None)
    except NotImplementedError as err:
        assert 'Please implement' in str(err)

# Generated at 2022-06-22 07:48:48.142420
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Smoke test:
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE()._real_extract(url)

# Generated at 2022-06-22 07:49:00.116450
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test the constructor of the class ITVBTCCIE
    assert ITVBTCCIE.__name__ == 'ITVBTCCIE'
    # Test whether the url is correct
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE._TEST['url'] == url

# Generated at 2022-06-22 07:49:04.124284
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:49:15.190458
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_cases = ['http://www.itv.com/hub/big-cats/2a2261a0012',
                  'http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034',
                  'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034',
                  'http://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024',
                  'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024']
    for test in test_cases:
        test_inst = ITVBTCCIE()
        assert test_inst.suitable(test)

# Generated at 2022-06-22 07:49:16.372143
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE()
    assert instance

# Generated at 2022-06-22 07:49:18.279345
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE(None)
    assert isinstance(instance, ITVBTCCIE)

# Generated at 2022-06-22 07:49:21.482270
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-22 07:49:25.305747
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:49:25.820552
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("test")

# Generated at 2022-06-22 07:49:32.272847
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    global ITVBTCCIE
    inject_parameters = {}
    ITVBTCCIE = type('ITVBTCCIE', (ITVBTCCIE,), inject_parameters)
    assert ITVBTCCIE
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:50:04.626487
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # test to ensure instance of ITVBTCCIE is initialized properly
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:50:16.099875
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert x._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert x._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert x._TEST['info_dict'] == {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}
    assert x._TEST['playlist_mincount'] == 9

# Generated at 2022-06-22 07:50:21.493995
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None)._VALID_URL == ITVBTCCIE._VALID_URL
    assert ITVBTCCIE(None)._TEST == ITVBTCCIE._TEST
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 07:50:25.254888
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test if construction of ITVBTCCIE was successful"""
    playlist = ITVBTCCIE()
    assert playlist._VALID_URL
    assert playlist._TEST
    assert playlist.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 07:50:25.890369
# Unit test for constructor of class ITVIE
def test_ITVIE():
    pass

# Generated at 2022-06-22 07:50:29.008474
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # run unit test before running the class unit test
    from .test_brightcove import test_brightcove_new
    test_brightcove_new(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '5799804583001', '5799804583001')

    test_class_unit(ITVBTCCIE, 'ITVBTCCIE')

# Generated at 2022-06-22 07:50:31.740087
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:50:35.682935
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    ie = ITVIE()
    t = ie._real_extract(url)
    assert t

# Generated at 2022-06-22 07:50:44.892387
# Unit test for constructor of class ITVIE
def test_ITVIE():
    def test_urls_and_id(url, expectedID):
        assert ITVIE._match_id(url) == expectedID
    test_urls_and_id("http://www.itv.com/hub/liar/2a4547a0012", "2a4547a0012")
    test_urls_and_id("https://www.itv.com/hub/liar/2a4547a0012", "2a4547a0012")
    test_urls_and_id("http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034", "2a5159a0034")

# Generated at 2022-06-22 07:50:48.530047
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    itvie = ITVIE()
    itvie._real_extract(test_url)


# Generated at 2022-06-22 07:51:56.108282
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .. import ITVBTCCIE
    try:
        ITVBTCCIE(None, ITVBTCCIE._VALID_URL).extract()
    except AssertionError as e:
        return False, "AssertionError: %s" % e
    except Exception as e:
        return False, "Exception: %s" % e
    return True

# Generated at 2022-06-22 07:51:57.060252
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('downloader', 'www.itv.com', 'demo.com')

# Generated at 2022-06-22 07:52:08.435889
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    webpage = '<html><p data-video-id="5713194768001"></p></html>'
    playlist_entries = [
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5713194768001',
    ]

    itv = ITVBTCCIE()

# Generated at 2022-06-22 07:52:09.076274
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:52:21.072410
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-22 07:52:30.929195
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_pb = ITVIE()
    # Test methods with no arguments
    assert itv_pb.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itv_pb.BAD_URL == 'http://www.itv.com'
    assert itv_pb.VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    # Test methods with arguments

# Generated at 2022-06-22 07:52:33.228486
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtcc_ie = ITVBTCCIE()
    assert itvbtcc_ie is not None

# Generated at 2022-06-22 07:52:39.325771
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE()
    assert instance.IE_NAME == "itv:itv"
    assert instance._VALID_URL == ITVIE._VALID_URL
    assert instance._TESTS == ITVIE._TESTS
    assert instance.BRIGHTCOVE_URL_TEMPLATE == ITVIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 07:52:51.446075
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    assert test._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert test._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-22 07:52:58.363972
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.IE_NAME == 'itv'
    assert ie.IE_DESC == 'ITV'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:55:20.422187
# Unit test for constructor of class ITVIE
def test_ITVIE():
    '''
     Test the constructor oif ITVIE class
    '''
    ITVIE()

# Generated at 2022-06-22 07:55:32.894005
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Here is class to be tested
    from ..utils import ExtractorError
    from .common import InfoExtractor
    from .ITVIE import ITVBTCCIE
    # Disable geo verification since it fails in Travis
    ITVBTCCIE.geo_verification_headers = lambda self: {}
    ie = ITVBTCCIE(InfoExtractor())

    # Test if url is not matched
    url = "https://www.itv.com/"
    match = ie._VALID_URL_RE.match(url)
    assert match is None

    # Test if valid url is matched
    url = "https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    match = ie._VALID_URL_RE.match(url)

# Generated at 2022-06-22 07:55:35.350482
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    assert video.video_id == "2a4547a0012"

# Generated at 2022-06-22 07:55:36.373931
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)

# Generated at 2022-06-22 07:55:39.659039
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE.IE_NAME)._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-22 07:55:50.784409
# Unit test for constructor of class ITVIE
def test_ITVIE():
    t = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert(t._match_id('http://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012')
    assert(t._match_id('http://www.itv.com/hub/liar/2a4547a0012/other/stuff') == '2a4547a0012')
    assert(t._match_id('http://www.itv.com/hub/liar/2a4547a0012?query') == '2a4547a0012')

# Generated at 2022-06-22 07:55:54.539511
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.suitable('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:56:05.539334
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import unittest
    from . import brightcove

    class TestITVBTCCIE(unittest.TestCase):
        def test_constructor_smuggle_referrer(self):
            testUrl = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
            ie = ITVBTCCIE(testUrl, 'test')
            self.assertEqual(ie.BRIGHTCOVE_URL_TEMPLATE, 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-22 07:56:09.051610
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE()
    except TypeError as e:
        assert 'required positional argument' in str(e)
    # Test to pass MPEG-TS download to constructor of class ITVIE
    ITVIE(download_mp4=False)

# Generated at 2022-06-22 07:56:12.782227
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Instantiation tests for the ITVIE."""
    # Basic test 1:
    # Tests that test_ITVIE() can be initialised.
    test = ITVIE()
    assert test