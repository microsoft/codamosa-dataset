

# Generated at 2022-06-22 07:47:50.504462
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:47:53.305870
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    c = ITVBTCCIE(None)
    assert c._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:47:59.528763
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_case = ITVBTCCIE()
    assert test_case._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert test_case._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:48:01.641065
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_ = ITVBTCCIE._TEST
    assert('playlist_mincount' in test_.keys())

# Generated at 2022-06-22 07:48:06.045250
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:08.009735
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-22 07:48:18.892317
# Unit test for constructor of class ITVIE
def test_ITVIE():
	from ytdl.extractor import InfoExtractor
	from ytdl.compat import str
	from ytdl.YoutubeDL import YoutubeDL
	from ytdl.cachedurl import CachedUrl
	from ytdl.cache import Cache
	from ytdl.cache import DBWrapper
	from ytdl.cache import UrlInfo
	from ytdl.cache import url_translate_path
	from ytdl.extractor.common import InfoExtractor
	from ytdl.utils import ExtractorError
	from ytdl.extractor.common import SearchInfoExtractor

# Generated at 2022-06-22 07:48:20.422540
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    return ie


# Generated at 2022-06-22 07:48:23.611680
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test for ITVIE.__init__()
    # Check the class is initialised correctly
    info_extractor = ITVIE('')
    assert isinstance(info_extractor, ITVIE)

# Generated at 2022-06-22 07:48:29.106535
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = "https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._match_id(test_url)



# Generated at 2022-06-22 07:48:48.811923
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE(ITVBTCCIE._downloader)
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:51.958317
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(url)._real_extract(url)

# Generated at 2022-06-22 07:48:54.784493
# Unit test for constructor of class ITVIE
def test_ITVIE():
	url = "https://www.itv.com/hub/liar/2a4547a0012"
	ie = ITVIE()
	result = ie._real_extract(url)
	expected = result['id']
	assert expected == '2a4547a0012'


# Generated at 2022-06-22 07:49:06.374465
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    expect_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5762587144001'
    expect_result = 'http://www.douyu.tv/'
    expect_smuggle = {
        'geo_ip_blocks': ['193.113.0.0/16', '54.36.162.0/23', '159.65.16.0/21'],
        'referrer': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
    }

# Generated at 2022-06-22 07:49:11.711876
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/peston-on-sunday/2a4621a0009')._real_extract(None)
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')._real_extract(None)

# Generated at 2022-06-22 07:49:14.349307
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(None).IE_NAME == ITVIE.ie_key()
    assert ITVBTCCIE(None).IE_NAME == ITVBTCCIE.ie_key()


# Generated at 2022-06-22 07:49:25.213291
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    BTCC_URL = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    BTCC_RE = r'data-video-id="(\d+)"'
    BTCC_VIDEO_ID = '5693423915001'
    BTCC_TITLE = 'BTCC 2018: All the action from Brands Hatch'
    BTCC_DESCRIPTION = 'md5:b0cddfead2c2a06f9f2a98c5fb3b3d00'
    BTCC_BRIGHTCOVE_URL = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    BTCC_BRIGHTCOVE_URL_

# Generated at 2022-06-22 07:49:32.773622
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtcc_ie = ITVBTCCIE()
    assert 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=3590865228001&referrer=http%3A%2F%2Fwww.itv.com%2Fbtcc%2Fraces%2Fbtcc-2018-all-the-action-from-brands-hatch' \
        == itvbtcc_ie.BRIGHTCOVE_URL_TEMPLATE % '3590865228001'

# Generated at 2022-06-22 07:49:38.282717
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ex = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert str(ex) == '<ITVBTCCIE http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch>'

# Generated at 2022-06-22 07:49:43.261702
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Basic test
    info = ITVIE(ITVExtractorTest())
    assert info.test()

    # Test on a video with 'ContentUnavailable'
    info = ITVIE(ITVExtractorTest({
        'url': 'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024',
    }))
    assert info.test()

# Generated at 2022-06-22 07:50:17.367379
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(downloader=None) is not None


# Generated at 2022-06-22 07:50:20.563437
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(InfoExtractor).suitable(url)

# Generated at 2022-06-22 07:50:21.209932
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:50:28.780874
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)
    assert ie.name() == 'ITVBTCCIE'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:50:30.186242
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-22 07:50:30.935283
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()

# Generated at 2022-06-22 07:50:39.114882
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert ITVIE("https://www.itv.com/hub/through-the-keyhole/2a2271a0033")
    assert ITVIE("https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034")
    assert ITVIE("https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024")


# Generated at 2022-06-22 07:50:49.833708
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Another test method to test constructor of class ITVBTCCIE
    """
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_obj = ITVBTCCIE()
    assert test_obj._downloader.params['hls_prefer_native'] is True
    assert test_obj.url == test_url
    assert test_obj._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:50:55.481134
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Testing with a new example
    ITV = ITVIE({})
    ITV.suitable({'url': 'https://www.itv.com/hub/liar/2a4547a0012'})
    ITV.extract({'url': 'https://www.itv.com/hub/liar/2a4547a0012'})

# Generated at 2022-06-22 07:51:00.193631
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == ITVBTCCIE._VALID_URL
    assert ITVBTCCIE()._TEST == ITVBTCCIE._TEST
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-22 07:52:16.157075
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/hub/btcc-2018-all-the-action-from-brands-hatch/2a7d59a0004')



# Generated at 2022-06-22 07:52:27.000589
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    webpage = '<html><head><title>Video list</title></head><body><div data-video-id="1234567"></div></body></html>'


# Generated at 2022-06-22 07:52:32.034967
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    m = ITVIE._VALID_URL.match(url)
    assert type(m) == type(ITVIE._VALID_URL)
    assert(m.groupdict()['id']) == video_id

# Generated at 2022-06-22 07:52:41.443374
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BR_DESC(r'<[^>]+id="video"[^>]*>') == r'(?s)(<[^>]+id="video"[^>]*>)'
    assert ie.BR_DESC(r'<[^>]+id="video"[^>]*>') == r'(?s)(<[^>]+id="video"[^>]*>)'
    assert ie.BR_DESC(r'[^(]*\(unescape\("([^"]+)"\)\)') == r'[^(]*\(unescape\("([^"]+)"\)\)'

# Generated at 2022-06-22 07:52:42.834124
# Unit test for constructor of class ITVIE
def test_ITVIE():
    #test instantiation of ITVIE class
    extractor = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert(extractor.__class__.__name__ == 'ITVIE')

# Generated at 2022-06-22 07:52:54.156922
# Unit test for constructor of class ITVIE
def test_ITVIE():
    testIE = ITVIE()
    result = testIE.extract(u'https://www.itv.com/hub/liar/2a4547a0012')
    assert result.get(u'id') == u'2a4547a0012'
    assert result.get(u'title') == u'Liar - Series 2 - Episode 6'
    assert result.get(u'description') == u'Andy and Laura face the consequences of the fire.'
    assert result.get(u'upload_date') == u'20190815'
    assert result.get(u'duration') == 2588
    assert len(result.get(u'view_count')) > 1
    assert result.get(u'thumbnail') == u'https://img.itv.com/image/file/195601_PA.jpg'


# Generated at 2022-06-22 07:52:57.373792
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # We specifically call the ITVIE constructor since we want to test that
    # the ITVIE constructor calls the superclass constructor.
    assert ITVIE.__name__ == "ITVIE"

# Generated at 2022-06-22 07:53:01.917517
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE
    assert ITVIE._VALID_URL is not None
    assert ITVIE._GEO_COUNTRIES == ['GB']
    assert ITVIE._TESTS

# Generated at 2022-06-22 07:53:07.011397
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:53:18.340833
# Unit test for constructor of class ITVIE
def test_ITVIE():
    result = ITVIE()

# Generated at 2022-06-22 07:56:04.970905
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    if ITVBTCCIE(ITVIE())._downloader is not None:
        assert ITVBTCCIE(ITVIE())._downloader.params['geo_verification_headers']['x-forwarded-for'] == '193.113.0.0/16, 54.36.162.0/23, 159.65.16.0/21'
    assert ITVBTCCIE(ITVIE())._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:56:07.322414
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE.ie_key()).ie_key() == ITVBTCCIE.ie_key()

# Generated at 2022-06-22 07:56:07.931989
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:56:11.853455
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvIE = ITVIE()
    itvIE2 = ITVIE()
    itvIE3 = ITVIE()
    assert itvIE.count_extract_element == 0

# Generated at 2022-06-22 07:56:15.848232
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class TestClass(ITVIE):
        def __init__(self, *args, **kwargs):
            print(self.__class__.__name__)
            super(TestClass, self).__init__(*args, **kwargs)

    if __name__ == '__main__':
        TestClass()

# Generated at 2022-06-22 07:56:21.943981
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # create an instance of the class ITVIE
    test_ITVIE = ITVIE()
    url = 'https://www.itv.com/hub/the-brits-are-coming/2a2263a0017'
    # test_ITVIE.suitable(url)
    # extract information from a web page of ITV
    test_ITVIE._real_extract(test_ITVIE._download_webpage(url, '1'))

# Generated at 2022-06-22 07:56:23.946450
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/dancing-on-ice/2a24c47a0007')

# Generated at 2022-06-22 07:56:24.370087
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()

# Generated at 2022-06-22 07:56:32.589394
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # ITVBTCCIE has multiple videos on a webpage, so we test its playlist
    # extraction here
    playlist = ITVBTCCIE()._real_extract(
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert playlist['_type'] == 'playlist'
    assert playlist['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert playlist['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert playlist['entries']
    assert len(playlist['entries']) == 9

# Generated at 2022-06-22 07:56:34.234758
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Build an instance of ITVIE to test its constructor
    """
    ITVIE(object)
