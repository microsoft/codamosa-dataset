

# Generated at 2022-06-22 07:47:38.504703
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVE = ITVIE("")
    assert ITVE


# Generated at 2022-06-22 07:47:49.700819
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie_class = ITVIE
    ie_test = ie_class.test
    #test_urls = ie_test._TESTS
    test_urls = [
        'https://www.itv.com/hub/the-jeremy-kyle-show/2a2898a0000',
        'https://www.itv.com/hub/liar/2a4547a0012',
        'https://www.itv.com/hub/through-the-keyhole/2a2271a0033',
        'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034',
    ]
    for test_url in test_urls:
        ie = ie_class.suitable(test_url)

# Generated at 2022-06-22 07:48:01.801839
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Test ITVBTCCIE constructor.
    """
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

    ie = ITVBTCCIE()
    result = ie.url_result(test_url)

    assert ie._VALID_URL == result.ie._VALID_URL, "Result's valid_url does not match ITVBTCCIE's valid_url: %s" % result.ie._VALID_URL

# Generated at 2022-06-22 07:48:02.462466
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE

# Generated at 2022-06-22 07:48:13.269755
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-22 07:48:16.362450
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'
    p = ITVIE()
    params = [
        ('id', video_id),
        ('ext', 'mp4'),
        ('title', 'Liar - Series 2 - Episode 6'),
        ('description', 'md5:d0f91536569dec79ea184f0a44cca089'),
        ('series', 'Liar'),
        ('season_number', 2),
        ('episode_number', 6),
         ]
    assert p.extract('https://www.itv.com/hub/liar/2a4547a0012') == dict(params)


# Generated at 2022-06-22 07:48:18.510251
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('http://www.itv.com/hub/liar/2a4547a0012')._GEO_COUNTRIES == []
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')._GEO_COUNTRIES == ['GB']



# Generated at 2022-06-22 07:48:20.395883
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()
 

# Generated at 2022-06-22 07:48:21.773695
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL


# Generated at 2022-06-22 07:48:25.619124
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"

# Generated at 2022-06-22 07:48:42.899137
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccIE = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert isinstance(itvbtccIE, ITVBTCCIE)

# Generated at 2022-06-22 07:48:49.528930
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Check General ITVBTCCIE constructor
    from .anvato import AnvatoIE
    assert ITVBTCCIE.__bases__[0] == AnvatoIE
    # Check if constructor is overriden
    for constr in [BrightcoveNewIE, ITVIE]:
        assert ITVBTCCIE.__bases__[0] is not constr



# Generated at 2022-06-22 07:48:53.506422
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(InfoExtractor)._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:48:59.377295
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    video_id = '5927244823001'
    video_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s' % video_id
    url = ITVBTCCIE.url_result(video_url, video_id)
    assert url.id == video_id


# Generated at 2022-06-22 07:49:05.284444
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    with open("tests/ITVBTCCIE_test.html") as f:
        html = f.read()
    assert ITVBTCCIE._real_extract(ITVBTCCIE(), "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch", html=html)


# Generated at 2022-06-22 07:49:13.465168
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # This gives AssertionError: 
    # assert 'http://www.itv.com/hub/through-the-keyhole/2a2271a0033' in ITVIE._TESTS
    # assert 'http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034' in ITVIE._TESTS
    # assert 'http://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024' in ITVIE._TESTS
    assert ITVIE._TESTS

# Generated at 2022-06-22 07:49:13.972174
# Unit test for constructor of class ITVIE
def test_ITVIE():
  assert ITVIE

# Generated at 2022-06-22 07:49:16.983449
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL
    assert ITVIE()._TESTS == ITVIE._TESTS


# Generated at 2022-06-22 07:49:27.337598
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._GEO_COUNTRIES == ['GB']
    assert len(ITVIE._TESTS) == 4

# Generated at 2022-06-22 07:49:29.793720
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'itv'


# Generated at 2022-06-22 07:50:00.839915
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_ITVBTCCIE = ITVBTCCIE()
    assert test_ITVBTCCIE.brightcove_new_ie.ie_key() == 'BrightcoveNew'

# Generated at 2022-06-22 07:50:03.560331
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE("")
    itv.geo_verification_headers()
    assert ('Accept' in itv.geo_verification_headers())

# Generated at 2022-06-22 07:50:11.770850
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test that ITVIE is working
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    brightcove_new_ie = BrightcoveNewIE.ie_key()
    info_extractor = ITVIE.ie_key()
    assert info_extractor.suitable(url)
    info_extractor.extract(url, video_id)

# Generated at 2022-06-22 07:50:18.388221
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .common import assertEqual
    # Disable async tests
    #assertEqual(ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')._type, 'tv')
    assertEqual(ITVIE('https://www.itv.com/hub/lorraine/2a52701')._type, 'tv')

# Generated at 2022-06-22 07:50:23.103958
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie.br.BRIGHTCOVE_URL_TEMPLATE == ITVIE.BRIGHTCOVE_URL_TEMPLATE
    assert itv_ie.BRIGHTCOVE_URL_TEMPLATE == ITVIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 07:50:24.363127
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()



# Generated at 2022-06-22 07:50:25.968188
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Tests that class ITVIE is correctly initialized
    ITVIE(None, {'valid': 'url', 'invalid': 'url'})

# Generated at 2022-06-22 07:50:31.868009
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_ITVBTCCIE = ITVBTCCIE.get_info_extractor('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert test_ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert test_ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:50:32.345905
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:50:41.321468
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        {'geo_ip_blocks': [
            '193.113.0.0/16', '54.36.162.0/23', '159.65.16.0/21'
            ],
        'referrer': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'})

# Generated at 2022-06-22 07:51:49.981209
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    _test(ITVBTCCIE)

# Generated at 2022-06-22 07:51:53.469316
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_ITVBTCCIE = ITVBTCCIE
    assert test_ITVBTCCIE._TEST['info_dict']['id'] == test_ITVBTCCIE._TEST['id']


# Generated at 2022-06-22 07:52:01.930254
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url_input = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    webpage = 'data-video-id="5813204428001"'
    entry_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5813204428001'
    func = ITVBTCCIE()._real_extract

    assert func(url_input)['id'] == playlist_id
    assert func(url_input)['_type'] == 'playlist'

# Generated at 2022-06-22 07:52:07.558938
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:52:09.240543
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .. import ITVIE

# Generated at 2022-06-22 07:52:21.123561
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class TestITVBTCCIE(ITVBTCCIE):
        def _real_initialize(self):
            pass

        def _download_webpage(self, url, video_id, *args, **kwargs):
            return '<html><div data-video-id="12345"></div></html>'

    test_ITVBTCCIE = TestITVBTCCIE()


# Generated at 2022-06-22 07:52:30.307981
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # ITVIE(dict)
    # create a new instance of the ITVIE class with an empty dictionary
    test_ITVIE = ITVIE({})
    assert(test_ITVIE is not None)

    # ITVIE(dict)
    # create a new instance of the ITVIE class with a nonexistent key of the
    # dictionary
    test_ITVIE = ITVIE({'unexistent_key': 'value'})
    assert(test_ITVIE is not None)

    # ITVIE(dict)
    # create a new instance of the ITVIE class with the 'url' key of the
    # dictionary that maps to a empty string
    test_ITVIE = ITVIE({'url': ''})
    assert(test_ITVIE is not None)

# Generated at 2022-06-22 07:52:32.911550
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE({})
    ie.playlist_result(['entries'], 'test_playlist_id', 'test_playlist_title')

# Generated at 2022-06-22 07:52:36.789150
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    output = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert output.get_real_url()

# Generated at 2022-06-22 07:52:39.181901
# Unit test for constructor of class ITVIE
def test_ITVIE():
    #check that the ITVIE constructor throws an exception
    with pytest.raises(TypeError):
        itv = ITVIE()

# Generated at 2022-06-22 07:55:11.570015
# Unit test for constructor of class ITVIE
def test_ITVIE():
	assert ITVIE._TESTS[1] == {
		'url': 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033',
		'only_matching': True,
	}



# Generated at 2022-06-22 07:55:13.769046
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE(url)._match_id(url) == '2a4547a0012'

# Generated at 2022-06-22 07:55:23.883894
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'

    webpage = '''
        <html>
            <body>
                <script>document.write = function(data) {
                    document.getElementById('video').setAttribute('data-video-id', '2a4547a0012');
                    document.getElementById('video').setAttribute('data-video-hmac', 'random_hmac');
                }</script>
                <div id="video"></div>
            </body>
        </html>
        '''

    # Tests the constructor of class ITVIE, which creates an accessor
    # object that can be used to fetch downloadable formats of an ITV video.
    ie = ITVIE(url)
   

# Generated at 2022-06-22 07:55:35.432252
# Unit test for constructor of class ITVIE
def test_ITVIE():
    
    # Import package
    import re

    # Create instances of ITVIE class
    ITVIE_Test_1 = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    ITVIE_Test_2 = ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    ITVIE_Test_3 = ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    ITVIE_Test_4 = ITVIE('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')
    
    
    # Test _VALID_URL
    assert ITVIE_Test_1._VALID

# Generated at 2022-06-22 07:55:39.024541
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-22 07:55:40.986385
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert isinstance(info_extractor, ITVBTCCIE)

# Generated at 2022-06-22 07:55:51.932269
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ie._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:55:54.542629
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'ITV'



# Generated at 2022-06-22 07:56:04.437448
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert itvbtccie._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert itvbtccie._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert itvbtccie._TEST['playlist_mincount'] == 9



# Generated at 2022-06-22 07:56:15.755930
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Unit tests for the constructor of class ITVBTCCIE
    """

    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"

    itvBTCCIE = ITVBTCCIE()
    itvBTCCIE._init(itvBTCCIE)

    print("Testing constructor of class ITVBTCCIE", end="\n")

    assert itvBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'