

# Generated at 2022-06-22 07:47:40.624954
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IT = ITVBTCCIE()
    assert str(IT.BRIGHTCOVE_URL_TEMPLATE) == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:47:44.115259
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(None)._real_extract('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')


# Generated at 2022-06-22 07:47:45.408090
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE.suite()

# Generated at 2022-06-22 07:47:53.976812
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor_object = ITVIE('test')
    assert info_extractor_object._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert info_extractor_object._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-22 07:47:56.713522
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-22 07:48:08.756855
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import unittest
    class TestITVBTCCIE(unittest.TestCase):
        def test_itvbtccie(self):
            self.assertEqual(ITVBTCCIE._VALID_URL,
                             r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)')
            self.assertEqual(ITVBTCCIE._TEST['url'],
                             'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
            self.assertEqual(ITVBTCCIE._TEST['info_dict']['title'],
                             'BTCC 2018: All the action from Brands Hatch')
    unitt

# Generated at 2022-06-22 07:48:11.765942
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/itvplayer/video/item/itv-news-london-at-ten',['GB']).extract()

# Generated at 2022-06-22 07:48:18.306555
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert info_extractor._TEST == {'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'info_dict': {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}, 'playlist_mincount': 9}

# Generated at 2022-06-22 07:48:30.068287
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .itv import ITVIE
    from .brightcove import BrightcoveNewIE

    playlist = ITVIE(None)

    assert playlist.video_id == "2a4547a0012"
    assert playlist.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"

# Generated at 2022-06-22 07:48:35.024883
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Constructor method to test ITVIE class, which fetches and parses webpage to
    extract media URL
    """
    # Example site to test
    url = 'http://www.itv.com/hub/cornwall-with-caroline-quinlan/2a1935a0122'

    # Create an instance of ITVIE class
    test = ITVIE()
    # Call constructor method and return media URL
    current_media_url = test._real_extract(url)['formats'][0]['url']

    # Example media URL
    example_media_url = 'http://link.theplatform.com/s/GKhwuB/' \
                        'media/guid/2408552655/1475140464000?player=flash1'

    # Assert that media URL is equal to example media URL


# Generated at 2022-06-22 07:49:03.887587
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IT = ITVIE()
    assert IT._VALID_URL == IT._TESTS[0]['url']
    assert IT._match_id(IT._TESTS[0]['url']) == IT._TESTS[0]['info_dict']['id']

# Generated at 2022-06-22 07:49:15.021572
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'
    url = 'https://www.itv.com/hub/liar/' + video_id
    # check if ITVIE is constructed successfully
    obj = ITVIE()
    assert obj._VALID_URL == ITVIE._VALID_URL
    assert obj._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert obj._TESTS == ITVIE._TESTS
    assert obj._TEST == ITVIE._TEST
    # check if method _real_extract works as expected
    webpage = obj._download_webpage(url, video_id)
    params = extract_attributes(obj._search_regex(
        r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params'))


# Generated at 2022-06-22 07:49:18.305016
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor._VALID_URL == ITVIE._VALID_URL
    assert info_extractor._TEST == ITVIE._TEST


# Generated at 2022-06-22 07:49:20.856265
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Fails if the constructor raises an error
    ITVBTCCIE(None)

# Generated at 2022-06-22 07:49:28.637464
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033') == None
    assert ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034') == None
    assert ITVIE('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024') == None

# Generated at 2022-06-22 07:49:33.595129
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    p = ITVIE(url)
    assert p.video_id == video_id
    assert p.url == url


# Generated at 2022-06-22 07:49:44.086845
# Unit test for constructor of class ITVIE

# Generated at 2022-06-22 07:49:45.850581
# Unit test for constructor of class ITVIE
def test_ITVIE():
    '''
    Test the creation of ITVIE object
    '''
    ie = ITVIE()
    assert ie

# Generated at 2022-06-22 07:49:49.934785
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE()
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:49:56.582236
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:50:52.204850
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test constructor
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:51:02.540798
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj=ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert obj.IE_NAME == 'itv'
    assert obj.ROOT_URL == 'https://www.itv.com'
    assert obj.VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:51:03.562601
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance

# Generated at 2022-06-22 07:51:08.962168
# Unit test for constructor of class ITVIE
def test_ITVIE():
	test_url = 'http://www.itv.com/hub/liar/2a4547a0012'
	def test_instance(IE):
		assert isinstance(IE, ITVIE)
	test_instance(ITVIE(test_url))

# Generated at 2022-06-22 07:51:10.877957
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:51:14.964079
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:51:19.653927
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Should use _real_extract of instance of ITVBTCCIE
    ITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')


# Generated at 2022-06-22 07:51:23.250741
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE()._real_extract(url)

# Generated at 2022-06-22 07:51:24.796468
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-22 07:51:26.644762
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE()
    assert test.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 07:53:42.692318
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # URL of webpage with video information
    url = 'https://www.itv.com/hub/liar/2a4547a0012'

    # Creating instance of ITVIE class
    instance = ITVIE()

    # FOR TESTING PURPOSE:
    # Assigning value to instance variable _VALID_URL for testing purpose
    instance._VALID_URL = r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

    # CALLING METHOD _real_extract by passing URL of webpage
    instance._real_extract(url)

    # FOR TESTING PURPOSE:
    # Assigning value to instance variable _VALID_URL for testing purpose

# Generated at 2022-06-22 07:53:48.350780
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:53:59.223533
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .brightcove import BrightcoveNewIE
    from .common import InfoExtractor
    from .itv import ITVIE
    from .itvbtcc import ITVBTCCIE
    import inspect

    class TestClass(object):
        """This is a dummy class for testing."""
        def __init__(self, value):
            self.value = value

    assert TestClass(6) == TestClass(6)
    assert TestClass(8) != TestClass(6)

    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:54:04.638333
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert isinstance(ie._real_extract(url), list)

# Generated at 2022-06-22 07:54:10.172096
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    with ITVBTCCIE() as itvbtccie:
        video_id = '5876000627001'
        assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE % video_id == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5876000627001'



# Generated at 2022-06-22 07:54:11.879774
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Instantiate the class and test its constructor
    ITVBTCCIE()

# Generated at 2022-06-22 07:54:15.322200
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Basic test for ITVIE"""
    result = ITVIE('https://www.brightcove.com/en/video-cloud/')
    assert result.__class__.__name__ == 'ITVIE'

# Generated at 2022-06-22 07:54:18.954532
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-22 07:54:20.148641
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-22 07:54:23.622855
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"

# Generated at 2022-06-22 07:57:01.254674
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE("test name")
    assert info_extractor.name == "test name"


# Generated at 2022-06-22 07:57:04.229919
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Regular video
    ITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:57:06.069555
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-22 07:57:15.603886
# Unit test for constructor of class ITVIE
def test_ITVIE():
    expected_url = 'https://link.theplatform.com/s/itv/player/' + \
                   'embed?id=c2xmB5Qjy2mI&pid=5q3p6blRei6Z&tpid=1582188683001'
    r = ITVIE()

# Generated at 2022-06-22 07:57:17.812035
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.BRIGHTCOVE_URL_TEMPLATE