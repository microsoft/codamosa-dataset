

# Generated at 2022-06-22 07:47:41.049317
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-22 07:47:51.585891
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvbtccie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:47:57.205874
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    assert instance._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert instance._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-22 07:48:09.255823
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE(None)._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:48:09.956627
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:48:20.660872
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    IE = ITVBTCCIE()
    IE.IE_NAME = ITVBTCCIE.ie_key()
    assert IE.ie_key() == 'ITV:BTCC'
    playlist_id = IE._match_id(url)
    assert(playlist_id != None)
    assert(playlist_id == 'btcc-2018-all-the-action-from-brands-hatch')
    assert(IE._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)')

# Generated at 2022-06-22 07:48:24.772184
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE('fake', 'fake')
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:25.889619
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    InfoExtractor('ITVBTCCIE')

# Generated at 2022-06-22 07:48:27.360826
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-22 07:48:33.900449
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    # This test fails as the current version of youtube-dl
    # seems to discard the download parameter.
    #assert ie._TESTS[0]['params'] == {'skip_download': True}

# Generated at 2022-06-22 07:49:00.105110
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE()._real_extract(url)

# Generated at 2022-06-22 07:49:05.173791
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    a = ITVBTCCIE(123)
    assert isinstance(a, ITVBTCCIE)
    assert a.BRIGHTCOVE_URL_TEMPLATE =='http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:49:05.595636
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:49:09.090165
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._real_extract("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-22 07:49:13.211851
# Unit test for constructor of class ITVIE
def test_ITVIE():
    m = ITVIE()
    assert m._VALID_URL == ITVIE._VALID_URL
    assert m._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert m._TESTS == ITVIE._TESTS


# Generated at 2022-06-22 07:49:15.440745
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE



# Generated at 2022-06-22 07:49:20.668366
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    a = ITVBTCCIE()
    a.BRIGHTCOVE_URL_TEMPLATE
    assert(a.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-22 07:49:21.331979
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-22 07:49:24.756994
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == \
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:49:30.551262
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_video_id = '2a4547a0012'
    url = 'https://www.itv.com/hub/liar/%s' % itv_video_id
    result = ITVIE._get_video_info(url=url)

    assert isinstance(result, dict)
    assert result.get('id') == itv_video_id
    assert result.get('title') == 'Liar - Series 2 - Episode 6'
    assert result.get('duration') > 0
    assert result.get('url')
    assert result.get('ext') == 'mp4'
    assert result.get('series') == 'Liar'
    assert result.get('season_number') == 2
    assert result.get('episode_number') == 6
    assert result.get('thumbnails')

# Generated at 2022-06-22 07:50:08.036780
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # InvalidVodcrid, ContentUnavailable
    invalid_vodcrids = ['2a5159a0034', '2a2898a0024']
    # url1, url2
    urls = [('https://www.itv.com/hub/liar/2a4547a0012', '2a4547a0012'),
            ('https://www.itv.com/hub/through-the-keyhole/2a2271a0033', '2a2271a0033')]
    for vodcrid, url in urls:
        assert vodcrid in ITVIE()._real_extract(url)['id']

# Generated at 2022-06-22 07:50:08.625106
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:50:09.201313
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:50:10.316412
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE()
    assert isinstance(instance, ITVIE)

# Generated at 2022-06-22 07:50:13.060076
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-22 07:50:24.806281
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Suffix for "InvalidVodcrid"  link
    invalidVodcridSuffix = "2a5159a0034"
    # Suffix for "ContentUnavailable"
    contentUnavailableSuffix = "2a2898a0024"
    url = "https://www.itv.com/hub/james-martins-saturday-morning/" + invalidVodcridSuffix
    try:
        ITVIE()._real_extract(url)
    except:
        assert True
    url = "https://www.itv.com/hub/whos-doing-the-dishes/" + contentUnavailableSuffix
    try:
        ITVIE()._real_extract(url)
    except:
        assert True
    # Normal valid URL

# Generated at 2022-06-22 07:50:30.349806
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    result = ITVBTCCIE()._real_extract(url)
    print('test_ITVBTCCIE result: %s' % result)
    assert len(result['entries']) == 9

### Not tested yet
# ITV Player

# Generated at 2022-06-22 07:50:33.580552
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    result = ITVBTCCIE(url)._real_extract(url)

# Generated at 2022-06-22 07:50:44.099108
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-22 07:50:46.378365
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie.geo_verification_headers() != {}



# Generated at 2022-06-22 07:51:52.892657
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .common import InfoExtractor
    from .brightcove import BrightcoveNewIE
    m = ITVIE()
    assert m.brightcove_new_ie == BrightcoveNewIE.ie_key()

# Generated at 2022-06-22 07:51:53.685057
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)

# Generated at 2022-06-22 07:52:01.000723
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    a = ITVBTCCIE("https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert a.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"
    assert a._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:52:06.172615
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:52:07.553323
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)

# Generated at 2022-06-22 07:52:17.070217
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccie = ITVBTCCIE()
    url_result = itvbtccie._real_extract(url)
    assert url_result['url'] == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5923578926001'
    assert url_result['ie_type'] == 'BrightcoveNew'
    assert url_result['_type'] == 'url'

# Generated at 2022-06-22 07:52:22.121431
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE(None, 'http://www.itv.com/btcc/')
    except TypeError as ex:
        assert 'missing 1 required positional argument' in str(ex)
    except:
        assert 'missing 1 required positional argument' in str(ex)
        raise


# Generated at 2022-06-22 07:52:32.453880
# Unit test for constructor of class ITVIE

# Generated at 2022-06-22 07:52:38.837308
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_obj = ITVBTCCIE(ITVBTCCIE())
    result = ITVBTCCIE._real_extract(test_obj, url)
    for entry in result['entries']:
        assert(entry['title'] != '')


# Generated at 2022-06-22 07:52:43.326519
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '123456789' == \
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=123456789'

# Generated at 2022-06-22 07:55:11.900619
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']
    assert ie._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-22 07:55:13.535699
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        itv = ITVIE({})
    except Exception:
        raise Exception('Failed to create ITVIE class')



# Generated at 2022-06-22 07:55:23.844678
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class TestITVBTCCIE(ITVBTCCIE):
        _TEST = {
            'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
            'info_dict': {
                'id': 'btcc-2018-all-the-action-from-brands-hatch',
                'title': 'BTCC 2018: All the action from Brands Hatch',
            },
            'playlist_mincount': 9,
            'skip': 'Blocked in some countries',
        }

        def _real_extract(self, url):
            raise NotImplementedError("Not implemented")

    ie = TestITVBTCCIE()
    ie_result = ie.extract()

# Generated at 2022-06-22 07:55:32.473039
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor.url_result('http://www.itv.com/hub/liar/2a4547a0012')
    #test for unavailable videos
    assert ITVIE().url_result('http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    assert ITVIE().url_result('http://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')

# Generated at 2022-06-22 07:55:37.985646
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Instantiate your class
    class_name = 'ITVBTCCIE'
    itvbtccie_instance = globals()[class_name]()
    # call the _real_extract() method of the class
    result = itvbtccie_instance._real_extract(itvbtccie_instance._TEST['url'])
    # compare with expected result(s).
    assert result['id'] == itvbtccie_instance._TEST['info_dict']['id']
    # invoke other methods of your class to do more sophisticated tests.


# Generated at 2022-06-22 07:55:39.055154
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()


# Generated at 2022-06-22 07:55:39.711732
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE({})

# Generated at 2022-06-22 07:55:44.036660
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    info_extractor = ITVBTCCIE()
    info_extractor._real_extract(url)

# Generated at 2022-06-22 07:55:46.008812
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE()
    except Exception as ex:
        # Verify no exception is raised
        raise Exception("ITVBTCCIE() raises exception %s" % repr(ex))

# Generated at 2022-06-22 07:55:48.204261
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')