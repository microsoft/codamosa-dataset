

# Generated at 2022-06-22 07:47:39.468540
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL

# Generated at 2022-06-22 07:47:50.347892
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor = ITVBTCCIE('test_ITVBTCCIE').__init__
    assert constructor('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert constructor('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch/') is None
    assert constructor('http://www.itv.com/btcc/btcc-2018-all-the-action-from-brands-hatch') is None
    assert constructor('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch/?a=1') is None

# Generated at 2022-06-22 07:47:54.823574
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:06.376148
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITV_URL = 'https://www.itv.com/hub/liar/2a4547a0012'
    instance = ITVIE({"geo_countries": ['GB']})
    saved_url_handle = instance._downloader.urlopen
    ITVIE._download_webpage = lambda self, url: 'url_check'
    assert instance.url_result(ITV_URL, 'ITV', '2a4547a0012')['url'] == ITV_URL
    instance._downloader.urlopen = saved_url_handle
    # Test geo_countries
    instance = ITVIE({})
    assert instance.geo_countries == []
    instance = ITVIE({"geo_countries": ['GB']})
    assert instance.geo_countries == ['GB']

# Generated at 2022-06-22 07:48:10.226855
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # test for constructor of class ITVBTCCIE
    assert ITVBTCCIE.__name__ == 'ITVBTCCIE'
    # test for constructor of class ITVIE
    assert ITVIE.__name__ == 'ITVIE'

# Generated at 2022-06-22 07:48:12.163623
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE()._real_extract(url)

# Generated at 2022-06-22 07:48:12.852993
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:48:14.789584
# Unit test for constructor of class ITVIE
def test_ITVIE():
    example_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(context)._real_extract(example_url)


# Generated at 2022-06-22 07:48:19.986185
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test with a valid ID
    p=ITVIE('http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    assert p.video_id == '2a5159a0034'
    # Test with an invalid ID
    p=ITVIE('http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034/')
    assert p.video_id == '2a5159a0034'
    # Test with a bad ID
    assert ITVIE.suitable('http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034/d') is False


# Generated at 2022-06-22 07:48:31.777432
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import unittest

    class TestITVBTCCIE(unittest.TestCase):
        def test_constructor(self):
            from itv_btcc_ie import ITVBTCCIE
            from bs4 import BeautifulSoup

            input_text = """
                <!doctype html>
                <html>
                    <head>
                        <title>foo</title>
                    </head>
                    <body>
                        <div data-video-id="v1"></div>
                        <div data-video-id="v2"></div>
                    </body>
                </html>
            """
            ie = ITVBTCCIE()
            result = ie._real_extract(input_text)
            self.assertEqual(len(result['entries']), 2)

# Generated at 2022-06-22 07:48:49.444842
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:50.993838
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    BrightcoveNewIE()

# Generated at 2022-06-22 07:48:57.922935
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor.IE_NAME == ITVIE._VALID_URL[-21:-6]
    assert info_extractor.IE_DESC == 'ITV', "IE should be ITV"
    assert info_extractor._VALID_URL == ITVIE._VALID_URL
    assert info_extractor._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES

# Generated at 2022-06-22 07:49:08.226856
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # test constructor with valid URL
    ITMBTCCIE_valid = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ITMBTCCIE_valid.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

    # test constructor with invalid URL
    ITMBTCCIE_invalid = ITVBTCCIE('http://www.itv.com/btcc')
    assert ITMBTCCIE_invalid == None


# Generated at 2022-06-22 07:49:16.357589
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test cases for ITVIE."""
    fake_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    real_url = 'http://www.itv.com/hub/through-the-keyhole/2a2271a0033'
    unavailable_url = 'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024'
    assert ITVIE._VALID_URL == fake_url
    assert ITVIE._VALID_URL == real_url
    assert ITVIE._VALID_URL == unavailable_url

# Generated at 2022-06-22 07:49:27.132282
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._extract_video_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ie._extract_video_id('https://www.itv.com/btcc/silverstone/highlights-from-silverstone') == 'highlights-from-silverstone'

# Generated at 2022-06-22 07:49:31.967816
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # This url is related to a real ITV programme "This Morning".
    url = 'https://www.itv.com/hub/This-Morning/2a5549a3006'
    # We do not expect the extractor to raise an error.
    ITVIE._real_extract(ITVIE(), url)

# Generated at 2022-06-22 07:49:33.993293
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .test import TestITVBTCCIE
    TestITVBTCCIE("test_ITVBTCCIE")

# Generated at 2022-06-22 07:49:35.039962
# Unit test for constructor of class ITVIE
def test_ITVIE():
    object = ITVIE()
    print(object)

# Generated at 2022-06-22 07:49:42.917165
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("http://www.itv.com/hub/liar/2a4547a0012", None, {})
    ITVIE("http://www.itv.com/hub/through-the-keyhole/2a2271a0033", None, {})
    ITVIE("http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034", None, {})
    ITVIE("http://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024", None, {})

test_ITVIE()

# Generated at 2022-06-22 07:50:13.595776
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(url)

# Generated at 2022-06-22 07:50:16.026095
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    info_extractor.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert info_extractor

# Generated at 2022-06-22 07:50:25.468551
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Unit test for ITVIE(): This will test the constructor of ITVIE
    """

    # Testing a valid url which should return a ITVIE object
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE_obj = ITVIE(url)
    print('Testing a valid url')
    print(ITVIE_obj)
    # Test a valid url with a invalid class name
    print('Testing a valid url with a invalid class name')
    ITVIE_obj = ITVIE(url, 'InvalidIE')
    # This should return an error

    # Testing a invalid url which should return a ITVIE object
    url = 'https://www.itv.com/hub/liar/'
    print('Testing a invalid url')
    ITVIE_obj = ITVIE(url)


# Generated at 2022-06-22 07:50:25.942180
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-22 07:50:28.317333
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:50:29.257735
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE()
    assert isinstance(instance, ITVIE)


# Generated at 2022-06-22 07:50:32.851258
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:50:43.190661
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test constructor of class ITVIE"""
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    ITVIE('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')


# Generated at 2022-06-22 07:50:52.642345
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info = ITVBTCCIE()._real_extract(ITVBTCCIE._TEST['url'])

    count = 0
    found = False
    for entry in info['entries']:
        if entry['_type'] == 'url':
            count += 1
            if 'players.brightcove.net' in entry['url']:
                found = True
    assert count == ITVBTCCIE._TEST['playlist_mincount']
    assert found
    assert info['id'] == ITVBTCCIE._TEST['info_dict']['id']
    assert info['title'] == ITVBTCCIE._TEST['info_dict']['title']

# Generated at 2022-06-22 07:50:56.468679
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert not ITVBTCCIE.suitable('http://www.itv.com/')
    assert ITVBTCCIE.suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:51:58.077711
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-22 07:52:00.660437
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:52:04.025190
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012', {})


# Generated at 2022-06-22 07:52:08.968234
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ytdl = ITVIE()
    # Test fields
    assert ytdl._VALID_URL == ITVIE._VALID_URL
    assert ytdl._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert ytdl._TESTS == ITVIE._TESTS


# Generated at 2022-06-22 07:52:19.025984
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test constructing ITVIE instances"""
    # Just making sure that the ITVIE constructor doesn't crash
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012').extract()
    ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033').extract()
    ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034').extract()
    ITVIE('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024').extract()

# Generated at 2022-06-22 07:52:29.623708
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_obj = ITVBTCCIE()
    assert test_obj
    assert hasattr(test_obj, '_VALID_URL') and test_obj._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert hasattr(test_obj, '_TEST') and test_obj._TEST
    assert hasattr(test_obj, 'BRIGHTCOVE_URL_TEMPLATE') and test_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:52:35.918841
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    original_url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    smuggle_url = "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5796325524001"
    smuggle_url = smuggle_url + "&referrer=" + original_url
    smuggle_url = smuggle_url + "&geo_ip_blocks=193.113.0.0/16,54.36.162.0/23,159.65.16.0/21"
    action_class = ITVBTCCIE()
    action_class._real_extract(original_url)

# Generated at 2022-06-22 07:52:48.106560
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # assert(ITVIE._VALID_URL == "https?://(?:www\.)?itv\.com/hub/(?P<id>[^?#]+)")
    assert(ITVIE._TESTS[0]['url'] == "https://www.itv.com/hub/liar/2a4547a0012")
    assert(ITVIE._TESTS[0]['info_dict']['id'] == "2a4547a0012")
    assert(ITVIE._TESTS[0]['info_dict']['ext'] == "mp4")
    assert(ITVIE._TESTS[0]['info_dict']['title'] == "Liar - Series 2 - Episode 6")

# Generated at 2022-06-22 07:52:53.186360
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    _test = ITVBTCCIE(ITVBTCCIE._downloader)
    assert _test._VALID_URL == ITVBTCCIE._VALID_URL
    assert _test._TEST == ITVBTCCIE._TEST
    assert _test.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 07:52:58.311489
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert ITVIE._VALID_URL == info_extractor._VALID_URL
    assert ITVIE._GEO_COUNTRIES == info_extractor._GEO_COUNTRIES
    assert ITVIE._TESTS == info_extractor._TESTS


# Generated at 2022-06-22 07:55:21.809183
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/the-x-factor/2a4547a0012')


# Generated at 2022-06-22 07:55:28.384421
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Initializing unit test class
    video_url = 'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    unit_test = ITVBTCCIE()
    
    # Asserting test case
    assert unit_test._match_id(video_url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:55:29.285330
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVExtractor = ITVBTCCIE()

# Generated at 2022-06-22 07:55:31.450595
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE().extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:55:38.981666
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import unittest
    import pytest

    @pytest.mark.usefixtures('mock_network')
    class ITVBTCCIETestCase(unittest.TestCase):
        def test_btcc(self):
            # Check NetworkResponse mock
            with self.assertRaises(AssertionError):
                yt = ITVBTCCIE()
                yt.url = 'http://www.itv.com/hub/peston-on-sunday/2a4885a0042'
                self.assertEqual(yt._download_webpage(None, None), None)
            # Check JSON-LD extraction
            with self.assertRaises(AssertionError):
                yt = ITVBTCCIE()

# Generated at 2022-06-22 07:55:42.704465
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Only testing the constructor, as the VideoData feeds are so volatile
    ITVIE('http://www.itv.com/hub/dancing-on-ice/2a4630a0065', {}, {'geo_countries': []})

# Generated at 2022-06-22 07:55:45.199908
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "http://www.itv.com/hub/liar/2a4547a0012"
    ITVIE(url)



# Generated at 2022-06-22 07:55:46.995699
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-22 07:55:48.798354
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-22 07:55:53.802128
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    playlist = ITVBTCCIE()
    assert playlist.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'