

# Generated at 2022-06-22 07:47:49.494210
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccIE = ITVBTCCIE()
    assert itvbtccIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvbtccIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itvbtccIE._TEST['url'] == url

# Generated at 2022-06-22 07:47:51.589079
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    print(itvie)
    return itvie


# Generated at 2022-06-22 07:47:52.080627
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:47:54.341621
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE()._real_extract(test_urls.REAL_INFO[0])


# Generated at 2022-06-22 07:47:58.123098
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE()
    assert instance.suitable(ITVIE._VALID_URL) is True
    assert instance.suitable(ITVIE._VALID_URL.replace('itv', 'ITV')) is True


# Generated at 2022-06-22 07:48:04.002466
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    # Correct instance created
    assert ie.__class__.__name__ == 'ITVBTCCIE'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:07.523067
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"

    ITVBTCCIE(url)

# Generated at 2022-06-22 07:48:12.482515
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # if this raises an exception, the class's __init__ method may have been
    # broken by a code change
    ITVBTCCIE()(url)

# Generated at 2022-06-22 07:48:14.838224
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 07:48:15.494128
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE = ITVIE()

# Generated at 2022-06-22 07:48:40.911834
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_item = ITVIE()
    print(test_item)

if __name__ == "__main__":
    test_ITVIE()

# Generated at 2022-06-22 07:48:46.660804
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:48.370974
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)

# Generated at 2022-06-22 07:48:57.301993
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE().extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert result['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert len(result['entries']) == 9
    for entry in result['entries']:
        assert 'brightcove' in entry['url']
        assert 'itv.com' in entry['url']
        assert 'referrer' in entry['url']

# Generated at 2022-06-22 07:48:58.301696
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:48:58.804881
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(object())

# Generated at 2022-06-22 07:49:00.009341
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-22 07:49:02.455003
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-22 07:49:13.416762
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/the-chase/2a3098a0015'
    class ITVIE_Test(ITVIE):
        def _download_webpage(self, *args, **kwargs):
            if self._downloader.params.get('test_id', None) != 'unit_test':
                self.to_screen('Unit test of ITVIE is NOT under progress.')
                return None
            else:
                return super(ITVIE_Test, self)._download_webpage(*args, **kwargs)
    itvIE_Test = ITVIE_Test({})
    res = itvIE_Test.extract(url)
    assert res['id'] == '2a3098a0015'

# Generated at 2022-06-22 07:49:16.265182
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Provide some values to avoid error while constructor
    # of ITVBTCCIE instance.
    ie = ITVBTCCIE(None, None, None)
    assert ie
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-22 07:50:22.383790
# Unit test for constructor of class ITVIE

# Generated at 2022-06-22 07:50:22.749555
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:50:24.460950
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("")
    ITVIE("", {"geo_verification_headers": True})

# Generated at 2022-06-22 07:50:25.118786
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:50:28.253851
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    #test for wrapping class ITVBTCCIE
    dic = ITVBTCCIE('ITVBTCCIE', 'itv.com')
    assert dic.name == 'ITVBTCCIE'

# Generated at 2022-06-22 07:50:30.942596
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    ITVIE(None)._test_extract_info(url, 'http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-22 07:50:34.082818
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:50:36.776750
# Unit test for constructor of class ITVIE
def test_ITVIE():
    _ITVIE = ITVIE("")
    assert isinstance(_ITVIE, ITVIE) is True

# Generated at 2022-06-22 07:50:38.362335
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
  pass

# Generated at 2022-06-22 07:50:42.261413
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-22 07:51:52.228818
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test for the ITVBTCCIE class
    ITVBTCCIE()

# Generated at 2022-06-22 07:51:58.609635
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    cie = ITVBTCCIE()
    assert cie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert cie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:52:06.406016
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Initialize an instance of ITVBTCCIE
    itvbtccie = ITVBTCCIE()
    # Perform tests
    assert '-default' in itvbtccie.BRIGHTCOVE_URL_TEMPLATE
    assert '-default' not in itvbtccie.BRIGHTCOVE_URL_TEMPLATE.replace('%s', '12345')

# Generated at 2022-06-22 07:52:14.645308
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_cases = [
        (
        ITVBTCCIE,
        {
            'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
            'result': 'btcc-2018-all-the-action-from-brands-hatch',
        }),
    ]

    for itvcie, test in test_cases:
        assert itvcie(None)._match_id(test['url']) == test['result']

# Generated at 2022-06-22 07:52:25.589634
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import os
    import inspect
    import shutil
    import tempfile

    def remove_directory(directory):
        """Remove directory recursively."""
        for root, dirs, files in os.walk(directory, topdown=False):
            for name in files:
                os.remove(os.path.join(root, name))
            for name in dirs:
                os.rmdir(os.path.join(root, name))

    def get_temp_dir():
        """Create and get a temporary directory."""
        temp_dir = tempfile.mkdtemp()
        remove_directory(temp_dir)
        os.mkdir(temp_dir)
        return temp_dir

    # Get the directory of the video file

# Generated at 2022-06-22 07:52:28.186871
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() == 'itv:btcc'
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:52:32.724366
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:52:34.089611
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Constructor test
    iptv = ITVIE()

# Generated at 2022-06-22 07:52:38.216635
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:52:40.521436
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test ITVBTCCIE constructor
    # This should not fail
    ies = ITVBTCCIE.ie_key()
    assert ies == ITVBTCCIE

# Generated at 2022-06-22 07:55:15.450957
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()
    ITVBTCCIE(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-22 07:55:16.782880
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE()
    assert obj is not None

# Generated at 2022-06-22 07:55:18.992819
# Unit test for constructor of class ITVIE
def test_ITVIE():
    testObj = ITVIE(InfoExtractor(), params={})
    assert testObj


# Generated at 2022-06-22 07:55:21.022182
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')



# Generated at 2022-06-22 07:55:32.945459
# Unit test for constructor of class ITVIE
def test_ITVIE():
    def assert_url(expected, url):
        assert expected == ITVIE._BASE_URL + 'hub/' + url

    # using the constructor to parse test URLs
    ie = ITVIE()

    # Check if parsing is correct
    assert_url('liar/2a4547a0012', 'liar/2a4547a0012')
    assert_url('liar/2a4547a0012', '/liar/2a4547a0012')
    assert_url('liar/2a4547a0012', 'http://www.itv.com/hub/liar/2a4547a0012')
    assert_url('liar/2a4547a0012', 'http://www.itv.com/hub/liar/2a4547a0012/')

# Generated at 2022-06-22 07:55:34.085180
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print('ITVIE instance created')
    ITVIE({}, {}, {})

# Generated at 2022-06-22 07:55:34.786147
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:55:39.691809
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE.suitable(url)
    assert ITVIE(None)._VALID_URL == ITVIE._VALID_URL
    assert ITVIE(None)._TESTS == ITVIE._TESTS

# Generated at 2022-06-22 07:55:43.446483
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012','2a4547a0012','https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-22 07:55:44.197098
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

