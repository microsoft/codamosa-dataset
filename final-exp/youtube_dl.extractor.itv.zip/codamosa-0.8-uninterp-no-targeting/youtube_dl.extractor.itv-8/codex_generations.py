

# Generated at 2022-06-22 07:47:41.205666
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert ITVBTCCIE._VALID_URL == itv_btcc_ie._VALID_URL

# Generated at 2022-06-22 07:47:51.701199
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-22 07:48:03.675007
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-22 07:48:05.876280
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert type(dict(info_extractor)) == dict


# Generated at 2022-06-22 07:48:14.680168
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert(ITVIE(None).get_id('http://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012')
    assert(ITVIE(None).get_id('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012')
    assert(ITVIE(None)._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')

# Generated at 2022-06-22 07:48:16.863510
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034")

# Generated at 2022-06-22 07:48:23.094856
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itv_btcc_ie = ITVBTCCIE(fake_info_extractor())
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itv_btcc_ie._match_id(test_url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:48:31.571357
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = "http://www.itv.com/btcc/races/2018-all-the-action-from-silverstone"
    test_class = ITVBTCCIE
    inst = test_class()
    assert inst._match_id(test_url) == inst._TEST['info_dict']['id']
    assert inst._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:48:35.686844
# Unit test for constructor of class ITVIE

# Generated at 2022-06-22 07:48:45.225627
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    entry = ITVBTCCIE()
    assert entry._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert entry._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert entry._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert entry._TEST['playlist_mincount'] == 9

# Generated at 2022-06-22 07:49:00.179220
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert ITVIE._VALID_URL == info_extractor._VALID_URL
    assert ITVIE._TESTS == info_extractor._TESTS

# Generated at 2022-06-22 07:49:03.744453
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:49:05.879310
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # ITVBTCCIE constructor test
    assert ITVBTCCIE.ie_key() == 'itv:btcc'

# Generated at 2022-06-22 07:49:15.569690
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    video_id = 'btcc-2018-all-the-action-from-brands-hatch'
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    brightcove_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5747884522001'

    assert ITVBTCCIE._match_id(url) == video_id
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '5747884522001' == brightcove_url

# Generated at 2022-06-22 07:49:19.805401
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import itvbtccie
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(itvbtccie.IE())._real_extract('http://www.itv.com/btcc/races/%s' % playlist_id)

# Generated at 2022-06-22 07:49:24.922123
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    The constructor of ITVIE should be able to create an ITVIE from any type
    of URL.
    """
    # This URL is taken from a missing video
    expected_url = 'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024'
    return ITVIE(expected_url)

# Generated at 2022-06-22 07:49:30.716257
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert 'ITVBTCCIE' in globals()
    inst = ITVBTCCIE()
    assert '/btcc' in inst._VALID_URL
    assert inst.BRIGHTCOVE_URL_TEMPLATE.find('%s') > 0
    assert inst.BRIGHTCOVE_URL_TEMPLATE.find('/index.html') > 0

# Generated at 2022-06-22 07:49:41.543628
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Unit test for common case
    valid_url = "https://www.itv.com/hub/liar/2a4547a0012"
    itv = ITVIE(ITVIE(), valid_url)
    assert itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:49:45.898211
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_verification_headers()
    assert ie.geo_verification_headers()['x-ipcountry'] == 'GB'

# Generated at 2022-06-22 07:49:49.648618
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:50:11.880701
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_id = 'btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(test_url, test_id)._real_extract(test_url)

# Generated at 2022-06-22 07:50:14.610670
# Unit test for constructor of class ITVIE
def test_ITVIE():
	test_ITV_instance = ITVIE()
	test_ITV_instance.geo_verification_headers()
	test_ITV_instance.test()

# Generated at 2022-06-22 07:50:15.279165
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()

# Generated at 2022-06-22 07:50:20.269853
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    itvbtccie.BRIGHTCOVE_URL_TEMPLATE
    itvbtccie.BRIGHTCOVE_URL_TEMPLATE % '5888373025001'

# Generated at 2022-06-22 07:50:21.688436
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ''' Test the constructor of class ITVIE '''

    ITVIE()

# Generated at 2022-06-22 07:50:32.194995
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():

    yt=ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert yt.BRIGHTCOVE_URL_TEMPLATE=='http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert yt._TEST['url']=='http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert yt._TEST['info_dict']['id']=='btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:50:43.447822
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:50:48.233426
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE()
    res = inst._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert res['playlist_mincount'] == 9
    assert res['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-22 07:50:49.686615
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .. import ITVIE
    itv = ITVIE()
    assert itv is not None

# Generated at 2022-06-22 07:51:01.032428
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ITVBTCCIE()._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-22 07:51:41.576893
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # When ITVIE is created, it should not throw an error
    ITVIE()

# Generated at 2022-06-22 07:51:43.750563
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE.ie_key())._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-22 07:51:55.660951
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Unit test for ITVBTCCIE constructor."""

    # Validate a valid URL is correctly parsed
    ITVBTCCIE(None, 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

    # Validate non-btcc URLs are ignored
    ITVBTCCIE(None, 'http://www.itv.com/news/')
    ITVBTCCIE(None, 'http://www.itv.com/btcc/')

    # Validate a valid URL is correctly parsed with a trailing slash
    ITVBTCCIE(None, 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch/')

    # Validate a valid URL is correctly parsed with an additional path

# Generated at 2022-06-22 07:51:56.311717
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:52:02.950598
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:52:15.363974
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import sys
    from .brightcove import BrightcoveNewIE
    from .common import InfoExtractor

    assert ITVBTCCIE.__bases__[0] == InfoExtractor
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE.ie_key() == 'ITVBTCC'
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:52:19.328645
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'



# Generated at 2022-06-22 07:52:23.231486
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:52:24.637620
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:52:30.393492
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    html_webpage = '<html><head><title>BTCC 2018: All the action from Brands Hatch</title></head><body>'
    html_webpage += '<div data-video-id="5726999685001"></div><div data-video-id="5726999685001"></div>'
    html_webpage += '<div data-video-id="5726999685002"></div><div data-video-id="5726999685002"></div>'
    html_webpage += '</body></html>'

    result = ITVBTCCIE()._real_extract(url)


# Generated at 2022-06-22 07:53:49.519921
# Unit test for constructor of class ITVIE
def test_ITVIE():
    with open('test_data/itv.txt', 'r') as myfile:
        data=myfile.read()
    extractor = ITVIE.IE_NAME
    result = ITVIE()._real_extract(extractor(ITVIE, data))
    print(result)

# Generated at 2022-06-22 07:53:53.180541
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_obj = ITVIE()
    expected_results = ITVIE._TESTS
    computed_results = test_obj._real_extract(expected_results[0]['url'])
    assert(expected_results[0]['info_dict'] == computed_results)

# Generated at 2022-06-22 07:54:02.021607
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itvbtccie._downloader.cache.load('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:54:12.640256
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = ITVIE._match_id(url)
    ie = ITVIE()
    webpage = ie._download_webpage(url, video_id)
    params = extract_attributes(ie._search_regex(
            r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params'))
    ios_playlist_url = params.get('data-video-playlist') or params['data-video-id']
    hmac = params['data-video-hmac']
    headers = ie.geo_verification_headers()

# Generated at 2022-06-22 07:54:13.631485
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert isinstance(ITVIE(), ITVIE)

# Generated at 2022-06-22 07:54:16.584650
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:54:20.843035
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    t = ITVBTCCIE('https://www.itv.com/hub/test/test')
    assert(t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-22 07:54:27.871332
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # constructor of class ITVIE is tested
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-22 07:54:31.902043
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itv._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-22 07:54:32.833950
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE().constructor()

# Generated at 2022-06-22 07:57:14.487594
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    return ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:57:18.606659
# Unit test for constructor of class ITVIE
def test_ITVIE():
	url = "https://www.itv.com/hub/liar/2a4547a0012"
	index = ITVIE()._real_extract(url)
	assert(index['id'] == "2a4547a0012")

# Generated at 2022-06-22 07:57:23.954755
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    except Exception as error:
        assert (
            "missing data-video-hmac from params and a non-empty playlist is unavailable" in str(error)
        )