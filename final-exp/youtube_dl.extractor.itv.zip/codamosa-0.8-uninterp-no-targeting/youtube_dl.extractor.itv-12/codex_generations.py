

# Generated at 2022-06-22 07:47:46.035321
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # ITV : Subtitle URL is None
    info_dict = {
        'id': '2a4547a0012',
        'ext': 'mp4',
        'title': 'Liar - Series 2 - Episode 6',
        'description': 'md5:d0f91536569dec79ea184f0a44cca089',
        'series': 'Liar',
        'season_number': 2,
        'episode_number': 6,
    }
    url = 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-22 07:47:54.401490
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    data = {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
    }
    x = ITVBTCCIE(data)
    assert x._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert x._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert x._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:48:06.321618
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_cases = [{
        'url' : 'https://www.itv.com/hub/liar/2a4547a0012',
        'name' : 'Liar - Series 2 - Episode 6',
        'description' : 'md5:d0f91536569dec79ea184f0a44cca089',
        'series' : 'Liar',
        'season_number' : 2,
        'episode_number' : 6,
        #'episode_id' : '2a4547a0012',
        #'tbr' : 506.4937
    }]
    for test_case in test_cases:
        result = ITVIE._extract_info(test_case['url'])
        assert result['name'] == test_case['name']
        assert result['description'] == test_case

# Generated at 2022-06-22 07:48:17.441496
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()
    assert(IE.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s")
    assert(IE.geo_verification_headers != None)
    assert(IE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')
    assert(IE._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012')
    assert(IE._TESTS[0]['info_dict']['id'] == '2a4547a0012')

# Generated at 2022-06-22 07:48:20.079803
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE('ITVBTCCIE', ITVBTCCIE._VALID_URL)
    assert test._TEST == ITVBTCCIE._TEST

# Generated at 2022-06-22 07:48:30.226651
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ie._TEST['playlist_mincount'] == 9

# Generated at 2022-06-22 07:48:42.534441
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info = ITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-22 07:48:49.607284
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    channel = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert channel.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:48:56.501788
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._valid_url('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'ITVBTCC')
    assert ie._valid_url('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'ITVBTCC') is False
    assert ie._valid_url('http://http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'ITVBTCC') is False

# Generated at 2022-06-22 07:48:57.558212
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:49:22.155412
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-22 07:49:24.007210
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.__class__.__name__ == 'ITVIE'

# Generated at 2022-06-22 07:49:32.339387
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    url = 'http://www.itv.com/btcc/races/' + playlist_id
    webpage = ie._download_webpage(url, playlist_id)

# Generated at 2022-06-22 07:49:33.096989
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)

# Generated at 2022-06-22 07:49:33.734418
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-22 07:49:35.573512
# Unit test for constructor of class ITVIE
def test_ITVIE():
    constructor = ITVIE()
    assert constructor._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-22 07:49:39.512955
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Check get_duration for ITVIE
    iTVIE = ITVIE(None)
    assert iTVIE.get_duration('PT00H29M36S') == 1776
    assert iTVIE.get_duration('PT00H27M18S') == 1638

# Generated at 2022-06-22 07:49:41.236556
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-22 07:49:48.613231
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:49:59.733241
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import shutil
    import tempfile

    # create temporary directory to store the results
    temp_dir = tempfile.mkdtemp()
    playlists_dir = temp_dir + 'test_ITVBTCCIE/'
    shutil.rmtree(playlists_dir, ignore_errors=True)

    # prepare to test
    info_extractor = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

    # do the test (fetch and extract the information)
    playlist = info_extractor.extract(url)

    print(playlist.keys())
    # show the results
    print('\n==Playlist==')

# Generated at 2022-06-22 07:50:54.825184
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # testing with a past video about the news
    test_class = ITVIE(None)

    test_class._VALID_URL = "http://www.itv.com/news/update/2013-11-25/london-fire-no-reports-of-injuries/"

# Generated at 2022-06-22 07:50:59.027087
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test if ITVIE can be instantiated
    # Constructor parameters: (url, ie)
    ie = ITVIE(
        'https://www.itv.com/itvplayer/video/liar/series-1/episode-1/'
    )
    assert isinstance(ie, ITVIE)



# Generated at 2022-06-22 07:51:03.974057
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')._TEST == ITVBTCCIE._TEST
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')



# Generated at 2022-06-22 07:51:06.483762
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == ITVIE._VALID_URL
    assert ie.__name__ == ITVIE.__name__

# Generated at 2022-06-22 07:51:09.205926
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-22 07:51:10.990137
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert isinstance(info_extractor, ITVBTCCIE)

# Generated at 2022-06-22 07:51:20.878158
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class Test(ITVIE):
        def __init__(self, url, headers=None):
            super(Test, self).__init__()
            self.url = url
            self.headers = headers or {}

        def downloadurl(self, url):
            return "%s headers=%s" % (url, self.headers)

        def _download_webpage(self, *args, **kwargs):
            return "%s %s" % (args, kwargs)

    test = Test("http://www.itv.com/hub/liar/2a4547a0012")
    assert test._real_extract(test.url) == 'http://www.itv.com/hub/liar/2a4547a0012 headers={}'

# Generated at 2022-06-22 07:51:21.671689
# Unit test for constructor of class ITVIE
def test_ITVIE(): ITVIE()

# Generated at 2022-06-22 07:51:23.593549
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-22 07:51:32.910035
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    unit_test = ITVBTCCIE(ITVBTCCIE())
    unit_test.url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-22 07:53:45.627773
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    expected = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
    actual = ITVBTCCIE(123)
   

# Generated at 2022-06-22 07:53:49.616178
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtcc_ie = ITVBTCCIE()
    itvbtcc_ie.url_result(url)

# Generated at 2022-06-22 07:54:00.519792
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE()
    assert inst._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert inst._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-22 07:54:03.574104
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._download_webpage('https://www.itv.com/hub/liar/2a4547a0012', '2a4547a0012')


# Generated at 2022-06-22 07:54:04.978035
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    expected = ITVIE
    assert type(ie) == expected

# Generated at 2022-06-22 07:54:09.929216
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test complete
    assert ITVIE(None).__class__.__name__ == ITVIE.__class__.__name__
    # Test parameter
    assert ITVIE(None)._VALID_URL == ITVIE._VALID_URL
    # Test test cases
    assert ITVIE(None)._TESTS == ITVIE._TESTS

# Generated at 2022-06-22 07:54:14.744208
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:54:23.838908
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    scraper = ITVBTCCIE()
    assert scraper.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert scraper.BRIGHTCOVE_URL_TEMPLATE != 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert scraper._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:54:26.029400
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Tests the ITVIE constructor
    ITVIE('2a4547a0012')

# Generated at 2022-06-22 07:54:30.528252
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test1 = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert test1.VALID_URL == ITVIE._VALID_URL
    assert test1.GEO_COUNTRIES == ITVIE._GEO_COUNTRIES

