

# Generated at 2022-06-24 12:37:08.991854
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:37:16.805392
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # test creating an ITVIE object

    test = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

    assert test.url == 'http://www.itv.com/hub/liar/2a4547a0012'
    assert test._VALID_URL == 'https?://(?:www\\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert test._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:37:17.884753
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE({}, 'http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:37:22.196918
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    def is_ITVBTCCIE_instance(obj):
        return isinstance(obj, ITVBTCCIE)

    class_file_path = 'ITVBTCCIE.py'
    assert any(map(is_ITVBTCCIE_instance, get_class_instances('ITVBTCCIE', [class_file_path])))

# Generated at 2022-06-24 12:37:27.652167
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    expected = '2a4547a0012'

    ITVIE_obj = ITVIE()
    ITVIE_id = ITVIE_obj._match_id(url)
    assert ITVIE_id == expected


# Generated at 2022-06-24 12:37:38.355087
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Tested URL: http://www.itv.com/hub/traffic-cops/1a4435a0014
    testFileDir = os.path.dirname(os.path.realpath(__file__))
    webpage = open(testFileDir + '/test_videos/traffic-cops.html', 'rb').read().decode('utf-8')
    params = extract_attributes(re.search(r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params')) # (?s) is used to make '.' matches newlines
    ios_playlist_url = params.get('data-video-playlist') or params['data-video-id']
    hmac = params['data-video-hmac']

# Generated at 2022-06-24 12:37:41.449604
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:44.924390
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_e = ITVBTCCIE('http://www.itv.com/hub/the-color-run/2a8036a0056')
    assert i_e.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:55.889115
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert inst._GEO_COUNTRIES == ['GB']
    assert len(inst._TESTS) == 4

# Generated at 2022-06-24 12:38:01.965334
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_case = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    obj = ITVBTCCIE()
    _obj = obj.ITVBTCCIE(test_case)
    # Checking if the object obj has been initialized correctly
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == _obj.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:38:07.850692
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    page = "btcc-2018-all-the-action-from-brands-hatch"
    video ='5578927926001'
    url_validate = ITVBTCCIE._VALID_URL
    url_match = ITVBTCCIE._match_id(url)
    webpage = ITVBTCCIE._download_webpage(url, ITVBTCCIE._match_id(url))
    entries = ITVBTCCIE._og_search_title(webpage, fatal=False)
    entries_re = ITVBTCCIE._search_regex(r'data-video-id=["\'](\d+)', webpage, video)
    video_id = ITVBTCC

# Generated at 2022-06-24 12:38:15.801269
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'

    # Get the sample of web page from the actual URL
    url = 'https://www.itv.com/hub/liar/%s' % video_id

# Generated at 2022-06-24 12:38:16.463986
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IT = ITVIE()

# Generated at 2022-06-24 12:38:27.825747
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # ITvBTCCIE was a playlist extractor and it was broken for awhile due to
    # the change of how playlist extractors work, thus we add a check here
    # to avoid broken playlist extractor again
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITvBTCCIE = ITVBTCCIE()
    assert isinstance(ITvBTCCIE, ITVBTCCIE)
    playlist_result = ITvBTCCIE._real_extract(url)
    entries = playlist_result['entries']
    assert len(entries) > 0
    first_entry = entries[0]
    assert first_entry.get('id') is not None
    assert first_entry.get('title') is not None
    assert first

# Generated at 2022-06-24 12:38:35.527203
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from ..constructor import ios_version
    url = "https://www.itv.com/hub/emmerdale/2a2271a0033"

# Generated at 2022-06-24 12:38:43.177844
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE.suitable(url)
    assert ITVBTCCIE._type(url) == 'video'

    assert ITVBTCCIE._TEST['url'] == url
    test_dict = ITVBTCCIE._TEST['info_dict']
    assert test_dict['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert test_dict['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-24 12:38:44.724208
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert isinstance(itvie, ITVIE)


# Generated at 2022-06-24 12:38:47.232243
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    res = ie.extract_url(r'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    print(res)

# Generated at 2022-06-24 12:38:47.791052
# Unit test for constructor of class ITVIE
def test_ITVIE():
	pass

# Generated at 2022-06-24 12:38:57.204406
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url1 = 'https://www.itv.com/hub/liar/2a4547a0012'
    result1 = ITVIE._build_request(test_url1)
    ITVExtractorRequest1 = True
    if result1.url != test_url1:
        ITVExtractorRequest1 = False
    assert ITVExtractorRequest1 is True

    test_url2 = 'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024'
    result2 = ITVIE._build_request(test_url2)
    ITVExtractorRequest2 = True
    if result2.url != test_url2:
        ITVExtractorRequest2 = False
    assert ITVExtractorRequest2 is True


# Generated at 2022-06-24 12:39:03.092032
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert result.title == 'BTCC 2018: All the action from Brands Hatch'
    assert result.description is None
    assert result.id == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:39:05.854684
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	assert(ITVBTCCIE._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)')

# Generated at 2022-06-24 12:39:13.302177
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    temp_constructor = ITVBTCCIE
    ITVBTCCIE._TESTS[0]['expected_warnings'] = ['geo_restricted']
    res = temp_constructor._TESTS[0]['result']
    ITVBTCCIE._TESTS[0]['result'] = lambda x: res(x, 'geo_restricted')
    ITVBTCCIE._TESTS[0]['result'] = ITVBTCCIE._TESTS[0]['result'](ITVBTCCIE)
    ITVBTCCIE = temp_constructor

# Generated at 2022-06-24 12:39:16.573137
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .test_common_itvbtcc import _test_itvbtcc

    _test_itvbtcc(ITVIE)

# Generated at 2022-06-24 12:39:21.862586
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # ITVIE._download_webpage is mocked to not download webpage
    itv_ie = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert itv_ie._match_id(itv_ie.url) == '2a4547a0012'
    assert itv_ie._real_extract(itv_ie.url)['id'] == '2a4547a0012'

# Generated at 2022-06-24 12:39:22.424415
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:39:22.991660
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:39:23.942370
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()

# Generated at 2022-06-24 12:39:32.195780
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    testURL = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    info = ITVBTCCIE()._real_extract(testURL)
    assert "btcc-2018-all-the-action-from-brands-hatch" == info["id"]
    assert "BTCC 2018: All the action from Brands Hatch" == info["title"]

# Generated at 2022-06-24 12:39:34.481229
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test for constructor of class ITVIE"""
    # Arrange
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    from .. import ITVIE
    # Act
    ie = ITVIE(url)
    # Assert
    assert ie.url == url

# Generated at 2022-06-24 12:39:44.698665
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:39:46.936469
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:39:51.587115
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """ test for ITVIE """
    ITVIE({}, 'http://www.itv.com/hub/liar/2a4547a0012')._real_extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:39:52.184398
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:39:56.444241
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Arrange
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # Act
    ITVBTCCIE()._real_extract(url)
    # Assert
    pass # No exception

# Generated at 2022-06-24 12:39:59.910383
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE()
    except TypeError:
        print('ITVBTCCIE has been constructed')
        return True
    else:
        print('ITVBTCCIE has not been constructed')
        return False

#Unit test for method _real_extract of class ITVBTCCIE

# Generated at 2022-06-24 12:40:04.532878
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class ITVBTCCIE_test(ITVBTCCIE):
        def _real_extract(self,url):
            itvie = ITVBTCCIE_test(url)
            return itvie
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie_test = ITVBTCCIE_test(url)
    assert ie_test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:14.887310
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst= ITVIE()
    inst.IE_NAME = "<?>"
    inst._VALID_URL = re.compile('<?>')
    inst._TESTS = []
    inst._GEO_COUNTRIES = []
    inst._download_webpage = lambda *args, **kwargs: "<html></html>"
    inst._match_id = lambda *args, **kwargs: "<?>"
    inst._download_json = lambda *args, **kwargs: {}
    inst._search_regex = lambda *args, **kwargs: {}
    inst._html_search_meta = lambda *args, **kwargs: {}
    inst._json_ld = lambda *args, **kwargs: {}
    inst._search_json_ld = lambda *args, **kwargs: {}

# Generated at 2022-06-24 12:40:24.574110
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    d = ITVBTCCIE()
    assert d._TYPE == 'playlist'
    assert d._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert d._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    assert d.BRIGHTCOVE_URL_TEM

# Generated at 2022-06-24 12:40:27.187478
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE('http://www.itv.com/hub/peston-on-sunday/1a5035a0024', {}, None)
        assert False, "Exception not thrown in ITVIE constructor"
    except:
        pass

# Generated at 2022-06-24 12:40:30.869075
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    c = ITVIE()
    c.url_result(url)
    c._download_webpage(url, '2a4547a0012')
    c.url_result(url)
    print(c._match_id(url))
    print(c._real_extract(url))

# Generated at 2022-06-24 12:40:33.396149
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # check whether ITVBTCCIE exists, otherwise 'getattr' will fail
    ITVBTCCIE


# Generated at 2022-06-24 12:40:36.562408
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert list(ITVIE._build_br_regex(r'itv\.com', 'GB').match('blah blah blah').groups()) == ['', 'GB']

# Generated at 2022-06-24 12:40:45.829317
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    url2 = 'https://www.itv.com/hub/liar/2a4547a0012?autoplay=true'
    assert ITVIE._is_valid_url(url)
    assert ITVIE._is_valid_url(url2, url)
    IE = ITVIE(url)
    IE = ITVIE(url2, url)
    IE = ITVIE(ITVIE(url))
    assert IE.video_id == '2a4547a0012'
    assert 'json.dumps' in IE._download_json.func_code.co_code

# Generated at 2022-06-24 12:40:46.547956
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        m = ITVBTCCIE({})
    except TypeError:
        pass

# Generated at 2022-06-24 12:40:47.829573
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert(issubclass(ITVBTCCIE, InfoExtractor))

# Generated at 2022-06-24 12:40:54.753682
# Unit test for constructor of class ITVIE
def test_ITVIE():
    object = ITVIE()
    assert object.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert object._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert object._TESTS[1]['url'] == 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033'
    assert object._TESTS[2]['url'] == 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'

# Generated at 2022-06-24 12:41:03.891597
# Unit test for constructor of class ITVIE
def test_ITVIE():
    #test_url = 'https://www.itv.com/hub/coronation-street/2a4101a0002'
    test_url = "https://www.itv.com/hub/the-good-karma-hospital/2a2550a0033"
    #test_url = "https://www.itv.com/hub/coronation-street/2a4101a0002/player"
    #test_url = 'https://www.itv.com/hub/coronation-street/2a4101a0002?playlist=series/coronation-street/2a4101&partial=true'
    #test_url = "http://www.itv.com/hub/coronation-street/1a2337"
    #test_url = 'https://www.itv.com/

# Generated at 2022-06-24 12:41:08.219962
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    except Exception:
        assert False

# Generated at 2022-06-24 12:41:10.576960
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == ITVIE._VALID_URL
    assert itvie._TESTS == ITVIE._TESTS

# Generated at 2022-06-24 12:41:13.746728
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE(None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:41:15.746325
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(None), "ITVIE constructor should be callable "


# Generated at 2022-06-24 12:41:24.745833
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'


# Generated at 2022-06-24 12:41:35.297666
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    # Raise error for invalid parameter
    with pytest.raises(ValueError):
        instance = ITVBTCCIE('Invalid parameter')
    # Raise error for invalid parameter
    with pytest.raises(ValueError):
        instance.BRIGHTCOVE_URL_TEMPLATE = 'Invalid parameter'
    # Raise error for invalid parameter
    with pytest.raises(ValueError):
        instance.BTCC_URL_TO_BRIGHTCOVE_IDS = {'Invalid parameter': 'Invalid parameter'}
    # Raise error for invalid parameter
    with pytest.raises(ValueError):
        instance.BTCC_URL_TO_BRIGHTCOVE_IDS = [('Invalid parameter', 'Invalid parameter')]

# Generated at 2022-06-24 12:41:36.278125
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('', '')


# Generated at 2022-06-24 12:41:38.522898
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():

    # Get test subjects
    subject = ITVBTCCIE()

    # Do testing
    assert subject._VALID_URL
    assert subject._TESTS

# Generated at 2022-06-24 12:41:42.615480
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class_itvbtccie = ITVBTCCIE(InfoExtractor())
    assert class_itvbtccie._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:41:43.546231
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:41:49.291317
# Unit test for constructor of class ITVIE
def test_ITVIE():
    #the example url of this ITVIE is http://www.itv.com/hub/liar/2a4547a0012
    #right now I have no idea even it is valid or not
    #but I can parse it, so it is a valid page in itv.com
    me = ITVIE()
    me.url_result('http://www.itv.com/hub/liar/2a4547a0012','2a4547a0012')

# Generated at 2022-06-24 12:41:58.276021
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    itv = ITVIE()
    assert(itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')
    assert(itv._match_id('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012')
    assert(itv._real_extract(itv_url).get('title') == 'Liar - Series 2 - Episode 6')

# Generated at 2022-06-24 12:42:00.909666
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_obj = ITVBTCCIE()
    assert test_obj.BRIGHTCOVE_URL_TEMPLATE.find('%s') >= 0

# Generated at 2022-06-24 12:42:09.259928
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btccPlayListURL = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    req = ITVBTCCIE()
    assert req._real_initialize() == True
    assert req._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert req._TEST.get('url') == btccPlayListURL
    assert req._TEST.get('info_dict').get('id') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:42:10.496699
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor = ITVBTCCIE()


# Generated at 2022-06-24 12:42:15.681584
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:42:16.320299
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()


# Generated at 2022-06-24 12:42:21.331857
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor = ITVBTCCIE
    assert ITVBTCCIE._TEST['info_dict']['id'] == constructor._TEST['info_dict']['id']
    assert ITVBTCCIE._TEST['info_dict']['title'] == constructor._TEST['info_dict']['title']
    assert ITVBTCCIE._TEST['playlist_mincount'] == constructor._TEST['playlist_mincount']

# Generated at 2022-06-24 12:42:24.698146
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:29.886922
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test ITVBTCCIE constructor"""
    itvbtccie = ITVBTCCIE()
    assert 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=x'\
        in itvbtccie.BRIGHTCOVE_URL_TEMPLATE % 'x'

# Generated at 2022-06-24 12:42:30.533428
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:42:37.587452
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE(None)
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert info_extractor._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert info_extractor._TESTS[0]['info_dict']['id'] == '2a4547a0012'
    assert info_extractor._TESTS[0]['info_dict']['title'] == 'Liar - Series 2 - Episode 6'

# Generated at 2022-06-24 12:42:48.046952
# Unit test for constructor of class ITVIE

# Generated at 2022-06-24 12:42:50.780556
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:42:52.754566
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL
    ITVIE(None, ITVIE._VALID_URL)

# Generated at 2022-06-24 12:42:54.683704
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()
    assert IE.ie_key() == 'ITV'


# Generated at 2022-06-24 12:42:58.830727
# Unit test for constructor of class ITVIE
def test_ITVIE():
    constructor_test({
        'url': 'https://www.itv.com/hub/liar/2a4547a0012',
        'current_page_url': 'https://www.itv.com/hub/liar/2a4547a0012',
        'current_page_id': '2a4547a0012',
    })

# Generated at 2022-06-24 12:43:01.142356
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	constructor_of_ITVBTCCIE  = ITVBTCCIE(InfoExtractor)
	assert constructor_of_ITVBTCCIE.__class__.__name__ == 'ITVBTCCIE'



# Generated at 2022-06-24 12:43:03.158970
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	x = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
	assert len(x.entries) == 9
	
	

# Generated at 2022-06-24 12:43:11.642382
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_class = ITVBTCCIE()
    test_class._real_extract(test_url)
    assert test_class._match_id(test_url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert test_class._og_search_title(test_class._download_webpage(test_url, 'btcc-2018-all-the-action-from-brands-hatch'), fatal=False)



# Generated at 2022-06-24 12:43:13.680661
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE({})._GEO_COUNTRIES == ['GB']


# Generated at 2022-06-24 12:43:14.595458
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-24 12:43:21.381769
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.suitable('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    assert ITVIE.suitable('https://www.itv.com/hub/liar/2a4547a0012')
    assert ITVIE.suitable('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    assert ITVIE.suitable('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')
    assert ITVIE.suitable('https://www.itv.com/hub/the-voice/6a4774a0021')

# Generated at 2022-06-24 12:43:29.108376
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE(ITVBTCCIE._downloader)
    info = ie.extract(url)
    assert info['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert info['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert len(info['entries']) == 9

# Generated at 2022-06-24 12:43:32.023154
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Unit test for constructor of class ITVBTCCIE"""
    ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")


# Generated at 2022-06-24 12:43:34.529623
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().match(r'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:43:35.754341
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj_ITVIE = ITVIE()
    assert obj_ITVIE

# Generated at 2022-06-24 12:43:41.176158
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert itv_ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itv_ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:43:46.967728
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    The test_ITVIE() test is used to verify that the ITVIE module has been
    imported properly.
    """
    # Call the constructor of the class ITVIE
    test_ITVIE = ITVIE()

    # Verify that the ITVIE object is an instance of the class InfoExtractor
    test_ITVIE._real_extract("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:43:55.181701
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._GEO_COUNTRIES == ['GB']
    assert len(ITVIE._TESTS) == 4

# Generated at 2022-06-24 12:44:01.584735
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    testCases = [{
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'playlist_id': 'btcc-2018-all-the-action-from-brands-hatch'
    }]

    for testCase in testCases:
        playlist_id = ITVBTCCIE._match_id(testCase['url'])
        assert playlist_id == testCase['playlist_id']

# Generated at 2022-06-24 12:44:02.856390
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(InfoExtractor)._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-24 12:44:05.640304
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "https://www.itv.com/hub/sport/btcc/1a6068a0003"
    assert ITVBTCCIE._VALID_URL.match(url).groupdict()['id'] == 'btcc-2016-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:44:12.463329
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_info_dict = {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'BTCC 2018: All the action from Brands Hatch',
    }
    instance = ITVBTCCIE()
    assert instance
    assert isinstance(instance, ITVBTCCIE)
    assert instance.suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:44:14.091284
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	my = ITVBTCCIE()
	assert isinstance(my, ITVBTCCIE), 'Constructor uses wrong type'

# Generated at 2022-06-24 12:44:14.483321
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)

# Generated at 2022-06-24 12:44:19.051037
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE();
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-24 12:44:20.297471
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # just testing a constructor, not interested in actual results
    ie = ITVIE()

# Generated at 2022-06-24 12:44:24.266462
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:44:25.238840
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()


# Generated at 2022-06-24 12:44:32.635618
# Unit test for constructor of class ITVIE
def test_ITVIE():
    P1 = "https://www.itv.com/hub/liar/2a4547a0012"
    P2 = "https://www.itv.com/hub/through-the-keyhole/2a2271a0033"
    P3 = "https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034"
    P4 = "https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024"

    itvie = ITVIE()
    itvie.geo_verification_headers = None

    video = itvie._real_extract(P1)
    assert video['id'] == '2a4547a0012'

# Generated at 2022-06-24 12:44:35.611502
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	assert ITVBTCCIE("http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5676914583001")

# Generated at 2022-06-24 12:44:39.250009
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVExtractor = ITVIE('ITVIE')
    ITVExtractor.suitable({'url': 'https://www.itv.com/hub/good-morning-britain/2a70a00b8712'})
    assert ITVExtractor.IE_NAME == 'itv:video'

# Generated at 2022-06-24 12:44:49.586040
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:44:51.008934
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import itv
    assert isinstance(itv.ITVBTCCIE(), object)

# Generated at 2022-06-24 12:44:56.995105
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from pprint import pprint
    itv_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    x = ITVIE.ITVIE(None)
    extractor = x._real_extract(itv_url)
    pprint(extractor)
    assert extractor['id'] == '2a4547a0012'

# Generated at 2022-06-24 12:44:57.626883
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:44:59.234555
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(ITVBTCCIE._TEST)

# Generated at 2022-06-24 12:45:01.877894
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/loose-women/2a3827aa3115'
    inst = ITVIE()
    inst.extract(url)

# Generated at 2022-06-24 12:45:03.246961
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE().playlist_result(None, None, None)



# Generated at 2022-06-24 12:45:11.104506
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # extractor = ITVIE()
    # url = 'https://www.itv.com/hub/liar/2a4547a0012'
    # print(extractor.suitable(url))
    # print(extractor.extract(url))
    # print(extractor.extract(url))
    # print(extractor._extract_from_url('https://www.itv.com/hub/strictly-come-dancing/itv/videos/seann-walsh-katya-jones-kiss-skit', 'https://www.itv.com/hub/strictly-come-dancing/itv/videos/seann-walsh-katya-jones-kiss-skit'))
    pass

# Generated at 2022-06-24 12:45:12.852280
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # We test the constructor of ITVIE
    ITVIE(InfoExtractor())._download_json

# Generated at 2022-06-24 12:45:17.874415
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == ITVIE._VALID_URL
    assert ie._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert ie._TESTS == ITVIE._TESTS
# Unit test to see if the constructor of ITVIE works
test_ITVIE()


# Generated at 2022-06-24 12:45:22.994371
# Unit test for constructor of class ITVIE
def test_ITVIE():
    it = ITVIE()
    assert it._VALID_URL == ITVIE._VALID_URL
    assert it._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert it._TESTS == ITVIE._TESTS

# Generated at 2022-06-24 12:45:27.135756
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:36.746899
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test with correct URL and correct input parameter, expected value is True
    test_case_1 = ITVIE._VALID_URL.match('https://www.itv.com/hub/liar/2a4547a0012')
    assert test_case_1 == True

    # Test with incorrect URL and incorrect input parameter, expected value is False
    test_case_2 = ITVIE._VALID_URL.match('https://www.itvcom/hub/liar/2a4547a0012')
    assert test_case_2 == False

    # Test with incorrect input parameter and incorrect output, expected value is False
    # test_case_3 = ITVIE._real_extract('https://www.itv.com/hub/liar/2a4547a0012')
    # assert test_case_3 == False

# Generated at 2022-06-24 12:45:40.828166
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(None)._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE(None)._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:45:43.031123
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.get_fields()['ITV'] == ITVIE

# Generated at 2022-06-24 12:45:50.305868
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    ITVIE('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')

# Generated at 2022-06-24 12:45:56.777422
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from youtube_dl import YoutubeDL
    from youtube_dl.extractor import InfoExtractor
    from youtube_dl.downloader.http import HttpFD
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError
    from youtube_dl.extractor import gen_extractors_by_ie

    URL = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    i = ITVIE()
    c = i._real_extract(URL)

    # getting information needed to retrieve the video
    ios_playlist_url = c['formats'][0]['url']
    hmac = c['formats'][0]['http_headers']['hmac']

# Generated at 2022-06-24 12:45:57.592751
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('ITVBTCCIE')

# Generated at 2022-06-24 12:46:01.166989
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE()
    assert ITVIE._VALID_URL == obj._VALID_URL, "Invalid _VALID_URL"
    assert list(ITVIE._TESTS[0].keys()) == ['url', 'info_dict', 'params'], "Invalid test case"

# Generated at 2022-06-24 12:46:07.327291
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info = ITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert info['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert info['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-24 12:46:09.016006
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_countries == ie._GEO_COUNTRIES

# Generated at 2022-06-24 12:46:10.605637
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:46:12.696331
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE(None)
    except:
        print("ITVIE is successfuly Made")

# Generated at 2022-06-24 12:46:14.332935
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:46:19.160864
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
        Test creation of ITVBTCCIE Class
    """
    ITVExtractor = ITVBTCCIE(InfoExtractor)
    assert ITVExtractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:21.117036
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test the constructor of ITVIE."""
    itv_ie = ITVIE(None)
    assert isinstance(itv_ie, ITVIE)

# Generated at 2022-06-24 12:46:24.681657
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    new_obj = ITVBTCCIE(url)
    assert new_obj.url == url

# Generated at 2022-06-24 12:46:27.043222
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:36.168190
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test for the test case for this class
    ITVBTCCIE_test = ITVBTCCIE()
    # Output of extraction method.
    remote_url = ITVBTCCIE_test._real_extract(
        ITVBTCCIE_test._TEST['url'])['entries'][0]['url']
    # Check that the url was correctly smuggled
    assert 'geo_ip_blocks' in remote_url
    assert 'referrer' in remote_url
    # Check that the title matched the expected value
    assert ITVBTCCIE_test._TEST['info_dict']['title'] == ITVBTCCIE_test._real_extract(
        ITVBTCCIE_test._TEST['url'])['title']

# Generated at 2022-06-24 12:46:39.169718
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert(instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:46:40.366560
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from . import ie
    assert ie.ITVIE is ITVIE


# Generated at 2022-06-24 12:46:42.579732
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc = ITVBTCCIE()
    assert itv_btcc == ITVBTCCIE()
    assert itv_btcc != ITVIE()


# Generated at 2022-06-24 12:46:45.785201
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_instance = ITVIE(InfoExtractor)
    assert test_instance.geo_verification_headers() == {
        'x-forwarded-for': '193.113.112.1, 54.36.162.39, 159.65.16.148'
    }

# Generated at 2022-06-24 12:46:56.266088
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:46:57.066576
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-24 12:46:58.306192
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:47:02.754884
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'