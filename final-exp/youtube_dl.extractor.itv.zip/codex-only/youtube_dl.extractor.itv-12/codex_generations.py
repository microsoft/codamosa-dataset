

# Generated at 2022-06-24 12:37:08.138389
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:09.039455
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:37:13.213180
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    assert test._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert test.SUITABLE_DEFAULT == 'm3u8'


# Generated at 2022-06-24 12:37:16.709521
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE()
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    vid = info.url_result(url, video_id = '2a4547a0012')
    assert vid.url == url
    assert vid.id == '2a4547a0012'
    assert vid.title == 'Liar - Series 2 - Episode 6'

# Generated at 2022-06-24 12:37:17.115949
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)

# Generated at 2022-06-24 12:37:24.469985
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    assert i._real_extract(url) is not None
    assert i.BRIGHTCOVE_URL_TEMPLATE is not None
    assert i._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == playlist_id

# Generated at 2022-06-24 12:37:27.844011
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:37:38.525074
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Example: https://www.itv.com/presscentre/ep1week6/btcc
    url = 'https://www.itv.com/presscentre/ep1week6/btcc'
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:37:40.309360
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    i = ITVBTCCIE()
    i.extract(url)


# Generated at 2022-06-24 12:37:43.763318
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_obj = ITVBTCCIE()
    assert test_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:47.375950
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Unit test for constructor of class ITVBTCCIE
    """
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', {
    })

# Generated at 2022-06-24 12:37:51.420279
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert(ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', dict()).BRIGHTCOVE_URL_TEMPLATE);

# Generated at 2022-06-24 12:37:54.839875
# Unit test for constructor of class ITVIE
def test_ITVIE():
    t = ITVIE()
    t.params = {}
    t.geo_verification_headers = lambda *a, **kw: {}
    t.extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:37:59.019453
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class Request:
        def __init__(self, headers):
            self.headers = headers
        def add_header(self, name, value):
            self.headers[name] = value

    request = Request({})
    ITVIE(request)
    assert request.headers['Accept'] == 'application/vnd.itv.vod.playlist.v2+json'

# Generated at 2022-06-24 12:38:01.309813
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE()
    except:
        pass

# Generated at 2022-06-24 12:38:05.141287
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-24 12:38:08.711688
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(InfoExtractor).suitable(url)
    ITVIE(InfoExtractor).extract(url)

# Generated at 2022-06-24 12:38:16.366746
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = ITVBTCCIE._match_id(url)

    webpage = ITVBTCCIE._download_webpage(url, playlist_id)


# Generated at 2022-06-24 12:38:23.998982
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    def constructor_test(url, expected_id):
        actual_id = ITVBTCCIE(ITVIE())._match_id(url)
        assert actual_id == expected_id, 'The ID %s was expected, but instead got %s.' % (expected_id, actual_id)

    constructor_test('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:38:28.681746
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:38:38.092492
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	from .itv import ITVBTCCIE
	from .brightcove import BrightcoveNewIE
	from .. import struct

	url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
	ie = ITVBTCCIE("ITVBTCCIE", url)
	assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
	assert ie.IE_NAME == 'BrightcoveNew'
	assert ie.playlist_id == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:38:39.713515
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL


# Generated at 2022-06-24 12:38:46.113623
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.BP_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.extract('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:38:47.825756
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).ie_key() == 'ITVBTCCIE'

# Generated at 2022-06-24 12:38:51.126931
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/the-spotlight/2a2602a0017'
    ie = ITVIE()
    assert ie.suitable(url)
    assert ie.extract(url) is None

# Generated at 2022-06-24 12:38:54.743744
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == \
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:01.875743
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch');
    assert instance._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)';
    assert instance.VICEOS_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s';
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s';


# Generated at 2022-06-24 12:39:06.923276
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert hasattr(itvbtccie, "_VALID_URL")
    assert hasattr(itvbtccie, "_TEST")
    assert hasattr(itvbtccie, "BRIGHTCOVE_URL_TEMPLATE")
    assert hasattr(itvbtccie, "_real_extract")


# Generated at 2022-06-24 12:39:08.623911
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE.extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:39:13.102371
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()

    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:39:15.230221
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)

# Generated at 2022-06-24 12:39:19.261596
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    ie = ITVIE()
    print('Creating ITVIE...')
    assert ie._match_id(url) == '2a5159a0034'
    print('Validated ITVIE successfully...')

# Generated at 2022-06-24 12:39:22.762639
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # following code results in the constructor of ITVBTCCIE being called
    (ITVBTCCIE.suitable(url), url)

# Generated at 2022-06-24 12:39:24.731613
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    # check if object is created
    assert itvbtccie is not None

# Generated at 2022-06-24 12:39:34.427209
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie_test = ITVBTCCIE()
    assert itvbtccie_test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s', 'property BRIGHTCOVE_URL_TEMPLATE should be equal to http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:44.663109
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    webpage = 'dummy_page'
    ie = ITVBTCCIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'dummy_url'


# Generated at 2022-06-24 12:39:50.440962
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor_test(
        'ITVBTCCIE',
        ie = ITVBTCCIE,
        expected_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        expected_playlist_id = 'btcc-2018-all-the-action-from-brands-hatch',
        expected_playlist_mincount = 9
    )

# Generated at 2022-06-24 12:39:54.682132
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() == 'ITVBTCC'
    assert ITVBTCCIE.ie_key(validate_url='http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'ITVBTCC'

# Generated at 2022-06-24 12:39:55.602973
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    I = ITVBTCCIE
    assert I._TEST == ITVBTCCIE.__dict__['_TEST']

# Generated at 2022-06-24 12:39:56.218318
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:39:57.807457
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE != ""

# Generated at 2022-06-24 12:39:59.945765
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:40:02.395336
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:06.041272
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:40:07.973478
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == ITVEIE._VALID_URL


# Generated at 2022-06-24 12:40:10.835363
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert obj._match_id(obj._VALID_URL) == '2a4547a0012'

# Generated at 2022-06-24 12:40:13.872281
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Arrange
    # Acts
    itvbtccie = ITVBTCCIE()
    
    # Assert
    assert isinstance(itvbtccie, ITVBTCCIE)


# Generated at 2022-06-24 12:40:14.842974
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITBFCCIE = ITVBTCCIE()

# Generated at 2022-06-24 12:40:16.918055
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-24 12:40:18.428196
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert isinstance(ie, ITVIE)

# Generated at 2022-06-24 12:40:25.876285
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    print("Unit test for ITVBTCCIE")
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    ie = ITVBTCCIE()
    extractor = ie.suitable(url)
    assert isinstance(extractor, ITVBTCCIE)
    assert extractor.IE_NAME == 'ITVBtcc'
    assert extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:29.254309
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class_under_test = ITVBTCCIE('test')
    assert class_under_test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:40:31.271166
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    # Test that the subclass of InfoExtractor is created
    if ie is None:
        print('Test ITVBTCCIE not pass')
    else:
        print('Test ITVBTCCIE  pass')

# Generated at 2022-06-24 12:40:32.603537
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST_URL == ITVBTCCIE._VALID_URL



# Generated at 2022-06-24 12:40:39.195667
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test ITVBTCCIE constructor."""

    url_test = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie_test = ITVBTCCIE(url_test)
    assert ie_test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:49.330471
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._check_valid_url('http://example.com/hub/liar/2a4547a0012');
    assert ITVIE()._check_valid_url('http://example.com/hub/liar/2a4547a0012/preview');
    assert not ITVIE()._check_valid_url('http://example.com/hub/liar/2a4547a0012/episode-guide');
    assert not ITVIE()._check_valid_url('http://example.com/hub/liar/2a4547a0012/episodes');
    assert not ITVIE()._check_valid_url('http://example.com/tv');
    assert not ITVIE()._check_valid_url('http://example.com/tv/liar');
    assert not ITVIE()._check_valid_url

# Generated at 2022-06-24 12:40:54.742787
# Unit test for constructor of class ITVIE
def test_ITVIE():
    if not ITVIE()._downloader.params.get('geo_verification_headers'):
        # Cannot test without GeoRestrictedError
        return
    ITVIE()._downloader.params.update({
        'geo_verification_headers': {
            'X-Forwarded-For': '151.229.248.2, 151.229.240.2',
        },
    })

# Generated at 2022-06-24 12:40:58.987260
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = ITVIE._match_id(url)
    assert video_id == '2a4547a0012'

# Generated at 2022-06-24 12:41:02.654583
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'

# Unit tests for itv.com url regex

# Generated at 2022-06-24 12:41:13.537746
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Testing with a fake trailer of:
    # https://www.itv.com/hub/penn-and-teller-fool-us/2a2752a0003
    test_case = ITVIE()
    test_case._download_webpage = lambda *args: {'data': '<div generic-playlist-root data-playlist-url="https://www.itv.com/api/v8/playlist/videos/2a2752a0003/ios-playlist-v2.json">'}

# Generated at 2022-06-24 12:41:23.729926
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import sys
    sys.path.insert(0, "..")
    from YoutubeDL import YoutubeDL
    print("==== Running test_ITVBTCCIE: ====\n")
    extractor = ITVBTCCIE()
    result = extractor.suitable("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    if not result:
        print("    ERROR: URL not recognized as ITVBTCCIE")
        print("    URL being tested was: http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
        print("")
        print("==== test_ITVBTCCIE finished ====\n")

# Generated at 2022-06-24 12:41:29.385647
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch').BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:35.632467
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    assert ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')


# Generated at 2022-06-24 12:41:41.331610
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class TestITVBTCCIE(ITVBTCCIE):
        def _download_webpage(self, url, video_id):
            with open('test/testdata/test_itvbtcc.txt', 'rb') as f:
                return f.read().decode('utf-8')

    t = TestITVBTCCIE()
    t.initialize()
    t._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:41:45.521393
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_cie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert itv_btcc_cie is not None

# Generated at 2022-06-24 12:41:50.450485
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    # Download the webpage to run the test
    webpage = self._download_webpage(test_url, video_id)
    params = extract_attributes(self._search_regex(
        r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params'))
    ios_playlist_url = params.get('data-video-playlist') or params['data-video-id']

# Generated at 2022-06-24 12:41:54.498281
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    itv_ie.extract("https://www.itv.com/hub/liar/2a4547a0012", download=False)

# Generated at 2022-06-24 12:42:01.109454
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()

# Generated at 2022-06-24 12:42:01.698211
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:42:05.433105
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ie = ITVIE()
    params = ie._real_extract(url)
    # print params
    assert len(params) != 0


# Generated at 2022-06-24 12:42:08.580235
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVExtractor = ITVIE() # constructor for ITVIE class
    assert ITVExtractor.__class__ == ITVIE # confirms that ITVExtractor is an instance of ITVIE

# Generated at 2022-06-24 12:42:09.248608
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:42:12.497034
# Unit test for constructor of class ITVIE
def test_ITVIE():
    _ITVIE = ITVIE()
    _ITVIE._real_initialize()
    return _ITVIE

# Generated at 2022-06-24 12:42:16.735747
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:18.331077
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    c = ITVBTCCIE()
    assert type(c).__name__ == 'ITVBTCCIE'

# Generated at 2022-06-24 12:42:19.087982
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()


# Generated at 2022-06-24 12:42:30.526393
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class_ITVIE = ITVIE()
    class_ITVIE._TESTS
    class_ITVIE = ITVIE()
    class_ITVIE._TESTS
    class_ITVIE = ITVIE()
    class_ITVIE._TESTS
    class_ITVIE = ITVIE()
    class_ITVIE._TESTS
    class_ITVIE = ITVIE()
    class_ITVIE._TESTS
    class_ITVIE = ITVIE()
    class_ITVIE._TESTS
    class_ITVIE = ITVIE()
    class_ITVIE._TESTS
    class_ITVIE = ITVIE()
    class_ITVIE._TESTS
    class_ITVIE = ITVIE()
    class_ITVIE._TESTS
   

# Generated at 2022-06-24 12:42:34.196350
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	"""Unit test for ITVBTCCIE"""
	assert ITVEIE.BTCC_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:42:45.107106
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert ITVBTCCIE._TEST['playlist_mincount'] == 9

# Generated at 2022-06-24 12:42:47.088663
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)._real_extract(ITVIE._TESTS[0]['url'])

# Generated at 2022-06-24 12:42:50.750935
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:42:53.210353
# Unit test for constructor of class ITVIE
def test_ITVIE():
	obj = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
	obj.extract()

# Generated at 2022-06-24 12:42:57.714575
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE('c3VuZHZvdGU6MjAwM0B1c2luZXNzLmVzLnNtYXJ0ZGV2aWNlLmRvbWFpbnMuaXR2LmNvbQ', 3, 2)
    assert obj.name == 'ITVIE'

# Generated at 2022-06-24 12:43:02.094195
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .common import SINGLE_RESULT_BASE_CLASS
    class TestITVBTCCIE(ITVBTCCIE, SINGLE_RESULT_BASE_CLASS):
        pass

    test_ITVBTCCIE('ITVBTCCIE', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'ITVBTCCIE')

# Generated at 2022-06-24 12:43:05.836905
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:43:15.938575
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ITVBTCCIE()._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:43:17.716957
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)._real_extract("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:43:20.244662
# Unit test for constructor of class ITVIE
def test_ITVIE():
	test_ITVIE = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:43:23.660419
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.SUCCESS == ie._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')


# Generated at 2022-06-24 12:43:26.998912
# Unit test for constructor of class ITVIE
def test_ITVIE():
	try:
		test_class = ITVIE()
		test_class.test_ITVIE()
	except:
		print("Test function not found") 

# Generated at 2022-06-24 12:43:28.764791
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE.new()
    assert ie is not None
    assert isinstance(ie, ITVBTCCIE)

# Generated at 2022-06-24 12:43:33.004269
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.GEO_COUNTRIES == ('GB',) # pylint: disable=no-member
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-24 12:43:39.388344
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Unit test for constructor of class ITVIE
    # TODO(byron): Write more unit tests for this extractor
    # test objects and expected properties of resulting objects
    TEST_OBJECTS = [
        {
            'url': 'https://www.itv.com/hub/lorraine/2a4547a0012',
            'expected_id': '2a4547a0012',
        },
    ]

    for obj in TEST_OBJECTS:
        itv_ie = ITVIE(ITVIE(), obj['url'])
        assert(itv_ie._VALID_URL == ITVIE._VALID_URL)
        assert(itv_ie._match_id(obj['url']) == obj['expected_id'])

# Generated at 2022-06-24 12:43:44.703488
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    top_item = ITVBTCCIE('https://www.itv.com/hub/itv-racing-live/1a2684',
                         downloader=None)
    assert top_item is not None
    assert top_item.BRIGHTCOVE_URL_TEMPLATE is not None
    assert top_item._download_webpage is not None
    assert top_item._match_id is not None
    assert top_item._real_extract is not None
    assert top_item._og_search_title is not None
    assert top_item.playlist_result is not None
    assert top_item.url_result is not None

# Generated at 2022-06-24 12:43:52.359877
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    expected_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5738306362001'
    expected_title = 'BTCC 2018: All the action from Brands Hatch'

    constructor = ITVBTCCIE()
    ie = constructor._real_extract(url)
    playlist_url = ie['entries'][0]['url']
    playlist_title = list(ie['entries'])[0]['title']

    assert playlist_url == expected_url
    assert playlist_title == expected_title

# Generated at 2022-06-24 12:43:58.245101
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	# Instantiating a class with an argument
	assert repr(ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')) == '<ITVBTCCIE http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch>'


# Generated at 2022-06-24 12:44:02.777560
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = ITVIE._match_id(url)
    webpage = ITVIE._download_webpage(url, video_id)
    params = extract_attributes(ITVIE._search_regex(
        r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params'))
    ios_playlist_url = params.get('data-video-playlist') or params['data-video-id']
    hmac = params['data-video-hmac']
    headers = ITVIE.geo_verification_headers()

# Generated at 2022-06-24 12:44:05.808027
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    import pprint
    result = pprint.pformat(itvbtccie)
    expected = pprint.pformat("<class 'youtube_dl.extractor.itv.ITVBTCCIE'>" )
    assert result == expected

# Generated at 2022-06-24 12:44:07.380236
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:44:14.892414
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE().url_result('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert result.meta == {
        'geo_ip_blocks': ['193.113.0.0/16', '54.36.162.0/23', '159.65.16.0/21'],
        'referrer': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    }

# Generated at 2022-06-24 12:44:17.798611
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:44:18.340597
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE

# Generated at 2022-06-24 12:44:22.110189
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:44:23.982223
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE().test()

test_ITVIE()


# Generated at 2022-06-24 12:44:25.319892
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Must create object of class ITVIE
    assert(ITVIE)



# Generated at 2022-06-24 12:44:29.189772
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:44:30.070184
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    ile = ITVBTCCIE()

# Generated at 2022-06-24 12:44:31.273053
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    return i

# Generated at 2022-06-24 12:44:33.161419
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_obj = ITVIE(InfoExtractor)
    assert 'itv' == test_obj.IE_NAME

# Generated at 2022-06-24 12:44:41.388228
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvBTCCIE = ITVBTCCIE()
    assert itvBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:44:51.321096
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE_url = ITVBTCCIE._TEST['url']
    ITVBTCCIE_playlist_id = ITVBTCCIE._TEST['info_dict']['id']
    ITVBTCCIE_playlist_title = ITVBTCCIE._TEST['info_dict']['title']
    assert ITVBTCCIE(None)._match_id(ITVBTCCIE_url) == ITVBTCCIE_playlist_id

# Generated at 2022-06-24 12:45:02.726907
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:45:07.268335
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test if constructor of ITVIE is working.
    ie = ITVIE()
    assert ie._VALID_URL == ITVIE._VALID_URL
    assert ie._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ITVIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:45:09.541874
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # ITVBTCCIE constructor is fully tested by test_itv and test_brightcove_backstage.
    pass

# Generated at 2022-06-24 12:45:11.828972
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:45:14.219519
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IT = ITVIE()
    IT.set_downloader(None)

    # assert isinstance(IT, ITVIE)


test_ITVIE()

# Generated at 2022-06-24 12:45:16.864523
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']



# Generated at 2022-06-24 12:45:20.037709
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:25.237431
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ie._match_id == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:45:31.980049
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test = ITVBTCCIE(url, 'barce');
    print('Type of test is %s, and value is %s' % (type(test), test))
    if isinstance(test, ITVBTCCIE):
        print('test is a ITVBTCCIE instance')
    else:
        print('test is not a ITVBTCCIE instance')

# Generated at 2022-06-24 12:45:32.485704
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:45:33.350666
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE()
    assert inst

# Generated at 2022-06-24 12:45:36.226464
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('itvbtcc', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')._real_initialize()

# Generated at 2022-06-24 12:45:39.219254
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE().url_result('http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=4823462859001', ie='BrightcoveNew')

# Generated at 2022-06-24 12:45:50.983723
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert info_extractor.url == "https://www.itv.com/hub/liar/2a4547a0012"
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:45:54.100683
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # Test constructor of class ITVBTCCIE with url as parameter
    ie = ITVBTCCIE(url)
    # Test _real_extract() method of ITVBTCCIE class 
    # with url as parameter
    ie._real_extract(url)

# Generated at 2022-06-24 12:45:56.953462
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = ITVBTCCIE._match_id(url)
    ie = ITVBTCCIE(ITVBTCCIE._build_url_result(url))
    assert ie.playlist_id == playlist_id

# Generated at 2022-06-24 12:45:59.364958
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Check ITVIE is able to create a public facing ITVIE object
    itv_ie = ITVIE()
    # Confirm ITVIE object is of class ITVIE
    assert isinstance(itv_ie, ITVIE)



# Generated at 2022-06-24 12:46:03.670656
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test the constructor of ITVIE"""

    # Case where video link to non-existent video
    fake_url = "http://blahblah.net/blah/2a5159a0034"
    result = ITVIE.suitable(fake_url)
    assert result is False

# Generated at 2022-06-24 12:46:05.089411
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == ITVIE.VALID_URL


# Generated at 2022-06-24 12:46:07.767366
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .brightcove import BrightcoveNewIE
    assert ITVBTCCIE.ie_key() == BrightcoveNewIE.ie_key() == 'brightcove:new'

# Generated at 2022-06-24 12:46:11.700848
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class ITVIE_TEST(ITVIE):
        class ITVIE_TEST_IE(InfoExtractor):
            _VALID_URL = r'%s' % ITVIE._VALID_URL
        ie = ITVIE_TEST_IE()
        itvtests = ITVIE_TEST(ie)
        assert itvtests is not None

# Generated at 2022-06-24 12:46:12.817993
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None)

# Generated at 2022-06-24 12:46:22.211685
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert obj._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:46:25.755517
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()

    # test invalid arguments
    with pytest.raises(TypeError):
        ie = ITVIE(url=None, video_id=None, video_object=None)

    # test valid class init
    assert ie != None

# Generated at 2022-06-24 12:46:26.314263
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:46:29.901149
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    a = ITVBTCCIE()
    r = a._real_extract(url)
    assert(r['playlist_mincount'] == 9)

# Generated at 2022-06-24 12:46:33.300606
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = 'https://www.itv.com/hub/the-big-bang-theory/2a4276a0013'
    itv_ie = ITVIE()
    itv_ie._download_webpage(test_url, '2a4276a0013')
    assert itv_ie._match_id(test_url) == '2a4276a0013'

# Generated at 2022-06-24 12:46:36.373361
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # test ITVIE
    ITVIE_obj = ITVIE()
    ITVIE_obj.extract('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-24 12:46:40.048059
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']


# Generated at 2022-06-24 12:46:48.273449
# Unit test for constructor of class ITVIE

# Generated at 2022-06-24 12:46:53.491855
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVIE()
    assert(x._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')
    assert(x._GEO_COUNTRIES == ['GB'])

# Generated at 2022-06-24 12:47:00.488680
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # check if the format is valid
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    # check the invalid formats
    ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    ITVIE('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')

# Generated at 2022-06-24 12:47:04.635632
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(None)._real_extract(url)

# Generated at 2022-06-24 12:47:06.410589
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE()
    except NameError as e:
        print("NameError: " + str(e))