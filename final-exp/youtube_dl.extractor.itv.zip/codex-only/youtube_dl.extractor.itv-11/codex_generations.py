

# Generated at 2022-06-24 12:37:05.091704
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # singleton of ITVIE
    class my_ITVIE(ITVIE):
        # override the constructor
        def __init__(self):
            pass

    my_itvie = my_ITVIE()
    # Assert that constructor is a singleton
    assert (my_itvie is my_ITVIE())

# Generated at 2022-06-24 12:37:07.629416
# Unit test for constructor of class ITVIE
def test_ITVIE():
	ie = ITVIE()
	assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-24 12:37:16.580965
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ITVBTCCIE._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # _real_extract()
    # _real_extract()
    # _real_extract()
    # _real_extract()

# Generated at 2022-06-24 12:37:22.390056
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    class_instance = ITVBTCCIE(url)
    url_result = class_instance._real_extract(url)
    playlist_url = url_result['entries'][0]['url']
    assert re.match(r'^http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index\.html\?videoId=\d+$', playlist_url)

# Generated at 2022-06-24 12:37:27.843568
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Unit test for constructor"""
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    assert ITVBTCCIE()._match_id(url) == "btcc-2018-all-the-action-from-brands-hatch"

# Generated at 2022-06-24 12:37:31.898948
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE().suitable(url)
    assert ITVIE().IE_NAME == 'itv'


# Generated at 2022-06-24 12:37:36.697197
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert str(type(i)) == "<class 'youtube_dl.extractor.itv.ITVBTCCIE'>"
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:41.487611
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    # Test constructor
    itvIE = ITVIE()
    assert itvIE._VALID_URL == ITVIE._VALID_URL
    assert itvIE._TESTS == ITVIE._TESTS
    # Test _real_extract method
    itvIE._real_extract(url)

# Generated at 2022-06-24 12:37:48.301053
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    ITVIE("https://www.itv.com/hub/through-the-keyhole/2a2271a0033")
    ITVIE("https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034")
    ITVIE("https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024")


# Generated at 2022-06-24 12:37:51.617471
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(None)._VALID_URL == ITVIE._VALID_URL
    assert ITVIE(None)._TESTS == ITVIE._TESTS


# Generated at 2022-06-24 12:37:54.315796
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:37:56.410477
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(url)


# Generated at 2022-06-24 12:37:57.816948
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # For coverage test of constructor of class ITVBTCCIE
    ITvBTCCIE()

# Generated at 2022-06-24 12:37:58.706595
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-24 12:38:02.075805
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None, 'http://www.itv.com/hub/liar/2a4547a0012')._real_extract(None)

# Generated at 2022-06-24 12:38:05.439237
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # only test for constructor for now
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:38:14.661436
# Unit test for constructor of class ITVIE

# Generated at 2022-06-24 12:38:20.353373
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    To test the class, run:

    ```
    python -m youtube_dl.extractor.itv
    ```

    from youtube_dl/tests/
    """
    import unittest
    class TestConstructor(unittest.TestCase):
        def test(self):
            # All these tests should pass
            tests = [
                (
                    'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
                    'btcc-2018-all-the-action-from-brands-hatch',
                )
            ]

            for test in tests:
                test_url, test_id = test

# Generated at 2022-06-24 12:38:30.717707
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert i._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert i._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert i._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert i._TEST['playlist_mincount'] == 9
    assert i.BRIGHTCOVE_URL_T

# Generated at 2022-06-24 12:38:36.106717
# Unit test for constructor of class ITVIE
def test_ITVIE():
    iv = ITVIE('https://www.itv.com/hub/emmerdale/2a4044a0024', {'geo_countries': ['GB']})
    assert iv.geo_verification_headers().get('x-forwarded-for') == '193.113.0.0,54.36.162.0,159.65.16.0'

# Generated at 2022-06-24 12:38:38.745294
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/hub/itv4/2a8f826a0012'
    ie = ITVBTCCIE(url)


# Generated at 2022-06-24 12:38:47.264490
# Unit test for constructor of class ITVIE
def test_ITVIE():
    new_ITVIE = ITVIE()
    new_ITVIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert new_ITVIE._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert new_ITVIE._TESTS[0]['info_dict']['id'] == '2a4547a0012'
    assert new_ITVIE._TESTS[0]['info_dict']['title'] == 'Liar - Series 2 - Episode 6'

# Generated at 2022-06-24 12:38:48.482403
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test that constructor of ITVBTCCIE() works
    assert ITVBTCCIE()

# Generated at 2022-06-24 12:38:51.847903
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    

# Generated at 2022-06-24 12:38:53.520650
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:38:59.319780
# Unit test for constructor of class ITVIE
def test_ITVIE():
    sample = ITVIE('http://www.itv.com/hub/liar/2a4547a0012', 'https://www.itv.com/hub/liar/2a4547a0012')
    assert sample.brightcove_id == '2a4547a0012'
    assert sample.title == 'Liar - Series 2 - Episode 6'
    assert sample.url == 'http://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-24 12:39:04.755909
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test IVE constructor"""
    # Test with valid URL
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL
    assert ITVIE()._TESTS[0] == ITVIE._TESTS[0]
    assert ITVIE()._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES


# Generated at 2022-06-24 12:39:08.357027
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert x.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"

# Generated at 2022-06-24 12:39:12.570812
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"

# Generated at 2022-06-24 12:39:17.309340
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    m = ITVBTCCIE()
    assert m.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:20.724352
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == \
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:28.508372
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    webpage = 'None'
    entries = [
        i.url_result(
            'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5471248492001',
            ie=BrightcoveNewIE.ie_key(), video_id='5471248492001')
        # video_id=5471248492001 - first video in playlist
    ]

    title = 'BTCC 2018: All the action from Brands Hatch'

    # Assert
    assert(playlist_id == i._match_id(i._VALID_URL.format(id=playlist_id)))


# Generated at 2022-06-24 12:39:34.176688
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccie = ITVBTCCIE(ITVBTCCIE.IE_NAME, url)
    return itvbtccie

# Generated at 2022-06-24 12:39:36.018057
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance._VALID_URL == ITVBTCCIE._VALID_URL
    assert instance._TEST == ITVBTCCIE._TEST



# Generated at 2022-06-24 12:39:39.683472
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Existing video
    ITVBTCCIE(None)._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:39:42.627851
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVIE()
    assert x.ITVIE_URL is not None
    assert x.ITVIE_URL == 'https://itv-api.itv.com/player/video/%s'

# Generated at 2022-06-24 12:39:44.778643
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012","BrightcoveNew")

# Generated at 2022-06-24 12:39:45.901844
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('', '')._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-24 12:39:48.432786
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # make sure ITVBTCCIE can be created
    assert ITVBTCCIE(ITVBTCCIE.IE_NAME)

# Generated at 2022-06-24 12:39:49.792551
# Unit test for constructor of class ITVIE
def test_ITVIE():
	extractor = ITVIE()
	print(extractor)

# Generated at 2022-06-24 12:39:51.866762
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Unit test for constructor of class ITVIE
    tester = ITVIE({'geo_countries': ['BT', 'GB']})
    assert tester

# Generated at 2022-06-24 12:39:55.011341
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvIE = ITVIE()
    assert itvIE.ie_key() == 'itv:video'
    assert itvIE.GEO_COUNTRIES == ['GB']


# Generated at 2022-06-24 12:39:57.046390
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE.find('%s') != -1
    assert ITVBTCCIE.ie_key() == 'brightcove:new'

# Generated at 2022-06-24 12:40:01.354475
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    # test all patterns
    patterns = [
        "https://www.itv.com/hub/liar/2a4547a0012",
        "https://www.itv.com/hub/through-the-keyhole/2a2271a0033"
        "https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034"
        "https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024"
        ]
    for p in patterns:
        assert ie._VALID_URL == ie._match_id(p)

# Generated at 2022-06-24 12:40:02.052324
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(ITVIE())

# Generated at 2022-06-24 12:40:06.557041
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    c = ITVBTCCIE()
    assert c._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:40:11.585504
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itvie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:40:14.821065
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Check if a constructor of ITVBTCCIE works."""
    ITVBTCCIE('ITVBTCCIE', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:40:18.153760
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test ITVIE constructor."""
    _ITVIE = ITVIE(ITVIE.ie_key())
    assert _ITVIE.ie_key() == 'ITV'
    assert _ITVIE.ie_name() == 'ITV'

# Generated at 2022-06-24 12:40:20.472907
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Test the constructor of class ITVIE
    """
    ITVE = ITVIE()
    ITVE.initialize()



# Generated at 2022-06-24 12:40:21.440413
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE != ''

# Generated at 2022-06-24 12:40:23.100038
# Unit test for constructor of class ITVIE
def test_ITVIE():
    iev = ITVIE()
    assert iev.__class__.__name__ == 'ITVIE'

# Generated at 2022-06-24 12:40:24.704761
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv._TESTS[1]['url'] == 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033'
    assert itv._TESTS[1]['only_matching'] == True

# Generated at 2022-06-24 12:40:26.179786
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    info_extractor._download_webpage('anything', 'anything')

# Generated at 2022-06-24 12:40:27.666618
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.__name__ == "ITVBTCCIE"

# Generated at 2022-06-24 12:40:28.811485
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor



# Generated at 2022-06-24 12:40:29.625576
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    basic_unit_test(ITVBTCCIE, [], {})


# Generated at 2022-06-24 12:40:30.529787
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:40:31.549754
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_countries == ie._GEO_COUNTRIES

# Generated at 2022-06-24 12:40:34.279278
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    It is important to ensure that the ITVIE constructor correctly handles any
    change in the provider.
    """

    itv = ITVIE()
    assert the_type_of(itv) == ITVIE
    assert type(itv) == ITVIE
    assert type(itv) is ITVIE

# Generated at 2022-06-24 12:40:41.953441
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_dict = {'url': 'https://www.itv.com/hub/beowulf-return-to-the-shieldlands/2a2980a0011',
               'info_dict': {},
               'params': {'skip_download': True}}

    ITVIE_obj = ITVIE()

    assert ITVIE_obj.suitable(test_dict['url'])
    assert ITVIE_obj.IE_NAME == 'itv:hub'
    assert ITVIE_obj._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:40:46.131860
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:46.692738
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()
    ITVBTCCIE()

# Generated at 2022-06-24 12:40:48.633059
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info = ITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert len(info['entries']) == 9



# Generated at 2022-06-24 12:40:55.899478
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IT = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert IT.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert IT.BRIGHTCOVE_URL_TEMPLATE ==  ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:41:04.332402
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IETF = ITVBTCCIE(
        _download_json=
        lambda url, id: {
            'items': [{
                'id': '5578130147001',
                'name': 'BTCC 2018: All the action from Brands Hatch',
                'description': 'md5:b487d4f8c4d4e0a59f5d0311acbcefe8',
            }]
        },
        _download_webpage=
        lambda url, id: {
            'items': [{
                'id': '5578130147001',
                'name': 'BTCC 2018: All the action from Brands Hatch',
                'description': 'md5:b487d4f8c4d4e0a59f5d0311acbcefe8',
            }]
        })
    #

# Generated at 2022-06-24 12:41:08.109024
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert isinstance(ITVBTCCIE._get_ie(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '123'), ITVBTCCIE)

# Generated at 2022-06-24 12:41:10.334782
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:13.252580
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(downloader=None).suitable(url)
    ITVIE(downloader=None).extract(url)

# Generated at 2022-06-24 12:41:15.377294
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE()
    except:
        raise Exception('Constructor of class ITVBTCCIE failed')

# Generated at 2022-06-24 12:41:20.333187
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Create instance of ITVIE
    test_video = ITVIE()
    # Get the video id
    test_video_id = test_video._match_id("https://www.itv.com/hub/liar/2a4547a0012")
    assert test_video_id == '2a4547a0012'

# Generated at 2022-06-24 12:41:25.255169
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .itv import ITVIE

    # Test valid URL
    valid_url = "http://www.itv.com/hub/liar/2a4547a0012"
    assert ITVIE._match_id(valid_url) is not None, "Valid URL match error"

    # Test invalid URL
    invalid_url = "http://www.itv.com/hub/liar/"
    assert ITVIE._match_id(invalid_url) is None, \
        "Invalid URL match error"

# Generated at 2022-06-24 12:41:36.530404
# Unit test for constructor of class ITVIE
def test_ITVIE():
    if not ITVIE.suitable('https://www.itv.com/hub/coronation-street/2a1032a0032'):
        print ('https://www.itv.com/hub/coronation-street/2a1032a0032')
        print (ITVIE.suitable('https://www.itv.com/hub/coronation-street/2a1032a0032'))
        raise Exception()
    if not ITVIE.suitable('https://www.itv.com/hub/liar/2a4547a0012'):
        raise Exception()
    if not ITVIE.suitable('https://www.itv.com/hub/through-the-keyhole/2a2271a0033'):
        raise Exception()

# Generated at 2022-06-24 12:41:39.996127
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_countries == ['GB']
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:41.108417
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import doctest
    doctest.testmod(ITVBTCCIE)

# Generated at 2022-06-24 12:41:45.302534
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None).url_result('http://www.itv.com/hub/liar/2a4547a0012')
    ITVIE(None).url_result('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')

# Generated at 2022-06-24 12:41:52.176962
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    video_id = '5235849417001'
    res = ITVBTCCIE()._real_extract(url)
    assert res['id'] == playlist_id
    assert len(res['entries']) == 9
    assert res['entries'][0]['url'] == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % video_id
    assert res['entries'][0]['ie_key'] == 'BrightcoveNew'
    assert res['entries'][0]['id'] == video_id

# Generated at 2022-06-24 12:41:55.174335
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)

# Generated at 2022-06-24 12:42:03.402625
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012', {
            'id': '2a4547a0012',
            'ext': 'mp4',
            'title': 'Liar - Series 2 - Episode 6',
            'description': 'md5:d0f91536569dec79ea184f0a44cca089',
            'series': 'Liar',
            'season_number': 2,
            'episode_number': 6,
        },
        {
            # m3u8 download
            'skip_download': True,
        })

# Generated at 2022-06-24 12:42:14.133755
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE != None
    assert ie.BRIGHTCOVE_URL_TEMPLATE != ''
    assert ie.BRIGHTCOVE_URL_TEMPLATE != 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'.replace('/', '\\')

# Generated at 2022-06-24 12:42:14.898239
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:42:18.886314
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE()._real_extract('https://www.itv.com/hub/liar/2a4547a0012')
    assert info['id'] == '2a4547a0012'
    assert info['title'] == 'Liar - Series 2 - Episode 6'
    assert info['description'] == 'md5:d0f91536569dec79ea184f0a44cca089'
    assert info['series'] == 'Liar'
    assert info['season_number'] == 2
    assert info['episode_number'] == 6
    assert info['duration'] == 2879

# Generated at 2022-06-24 12:42:23.339302
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvIE = ITVIE()
    assert itvIE._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:42:24.742685
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from . import ITVBTCCIE
    ITVBTCCIE(None)

# Generated at 2022-06-24 12:42:34.268175
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ITVBTCCIE._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:42:39.238797
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie.suitable(url)
    assert ie._VALID_URL == ie._real_extract(url)['_type']

# Generated at 2022-06-24 12:42:42.962802
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    assert test._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)', 'Pass'

# Generated at 2022-06-24 12:42:43.602881
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:42:47.135782
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch';
    # The object constructor should accept a URL.
    ITVBTCCIE(url)

# Generated at 2022-06-24 12:42:54.155090
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    
    instance = ITVIE(url)
    
    assert instance._match_id(url) == '2a4547a0012'
    assert instance._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert instance._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:42:56.346106
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    res = ITVBTCCIE()
    assert(res.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:43:02.095233
# Unit test for constructor of class ITVIE
def test_ITVIE():
    constructor_test(ITVIE, [
        'https://www.itv.com/hub/liar/2a4547a0012',
        'https://www.itv.com/hub/through-the-keyhole/2a2271a0033',
        'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034',
        'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024'])


# Generated at 2022-06-24 12:43:05.833157
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"

# Generated at 2022-06-24 12:43:06.469998
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:43:07.864746
# Unit test for constructor of class ITVIE
def test_ITVIE():
    constructor_test(ITVIE, '2342342342342')


# Generated at 2022-06-24 12:43:10.979508
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    ITVIE().suitable(url)


# Generated at 2022-06-24 12:43:12.038566
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:43:13.996339
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie is not None

# Generated at 2022-06-24 12:43:14.560855
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:43:20.826708
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Testing class constructor ITVIE
    """
    itv = ITVIE()
    assert itv.suitable('http://www.itv.com/hub/liar/2a4547a0012')
    assert itv.suitable('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    assert itv.suitable('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    assert not itv.suitable('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')


# Generated at 2022-06-24 12:43:22.648654
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:43:23.301747
# Unit test for constructor of class ITVIE
def test_ITVIE():
    pass

# Generated at 2022-06-24 12:43:33.241067
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert ITVIE('https://www.itv.com/hub/emmerdale/100000007495736')
    assert ITVIE('https://www.itv.com/hub/james-martin-saturday-morning/2a5159a0034')
    assert ITVIE('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')
    assert ITVIE('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024', 'tp')

# Generated at 2022-06-24 12:43:37.958907
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test constructor for ITVBTCCIE
    assert ITVBTCCIE(InfoExtractor()).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:44.612055
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = ITVBTCCIE._match_id(url)
    webpage = ITVBTCCIE._download_webpage(ITVBTCCIE, url, playlist_id)
    entries = [
        ITVBTCCIE.url_result(
            smuggle_url(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % video_id, {
                'referrer': url,
            }), ie=BrightcoveNewIE.ie_key(), video_id=video_id)
        for video_id in re.findall(r'data-video-id=["\'](\d+)', webpage)]

    title = ITVBTCCIE._

# Generated at 2022-06-24 12:43:50.941999
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    for url in ("http://www.itv.com/btcc/old-and-new-battle-at-snetterton",
                "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"):
        info_dict = ITVBTCCIE._real_extract(ITVBTCCIE(), url)
        assert info_dict['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
        assert info_dict['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-24 12:43:51.618103
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()

# Generated at 2022-06-24 12:43:52.284605
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:44:02.006997
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # runs the _real_extract and checks that it returns a list with items of
    # the expected item-length (which is hardcoded as 9 right now).
    # If the length of the returned list is 9, the test will pass and return true
    btcc = ITVBTCCIE()
    webpage = btcc._download_webpage('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:44:04.482962
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE()
    itv._real_extract('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:44:05.684404
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE()
    assert(test)



# Generated at 2022-06-24 12:44:08.792844
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '5894671857001'
    # Will raise error if constructor not correct
    ITVBTCCIE.suitable(url)

# Generated at 2022-06-24 12:44:15.986651
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')._real_extract()
    ITVIE('http://www.itv.com/hub/through-the-keyhole/2a2271a0033')._real_extract()
    ITVIE('http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')._real_extract()
    ITVIE('http://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')._real_extract()

# Generated at 2022-06-24 12:44:18.005243
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/2018-brands-hatch-super-sunday-race-1')

# Generated at 2022-06-24 12:44:22.110747
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie_instance = ITVBTCCIE()
    assert ie_instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:44:27.244987
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    print('Unit test for constructor of class ITVBTCCIE')

    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    print('Testing URL: %s' % url)
    print('Testing constructor')
    ITVBTCCIE(url)
    print('Pass')

# Generated at 2022-06-24 12:44:30.445655
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE().url_result(url)

# Generated at 2022-06-24 12:44:31.656961
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE is not None


# Generated at 2022-06-24 12:44:34.278894
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:44:38.236371
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

test_classes = [ITVIE, ITVBTCCIE]

# Generated at 2022-06-24 12:44:39.258484
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE(None)



# Generated at 2022-06-24 12:44:49.237897
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itvbtccie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:44:53.381799
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:44:59.761701
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_class = ITVBTCCIE('test-btcc')
    assert test_class.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert test_class.BRIGHTCOVE_ID_TEMPLATE == '%s'

# Generated at 2022-06-24 12:45:01.593824
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    temp = ITVBTCCIE.__init__(ITVBTCCIE)
    assert temp is None

# Generated at 2022-06-24 12:45:05.574347
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:09.253961
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert x.SUFFIX == '?itv-crid=2a4547a0012'


# Generated at 2022-06-24 12:45:12.281175
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE(object_to_test=None)._real_extract(url)

# Generated at 2022-06-24 12:45:16.334824
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
        itvbtccie = ITVBTCCIE()
        assert itvbtccie.brighcove_url_template == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:18.275107
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE()
    except:
        raise AssertionError("Unit test failed for ITVIE constructor")

# Generated at 2022-06-24 12:45:20.403703
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('2a4547a0012') == ITVIE('https://www.itv.com/hub/liar/2a4547a0012');

# Generated at 2022-06-24 12:45:31.714782
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    # Test for BRIGHTCOVE_URL_TEMPLATE
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    # Test for BRIGHTCOVE_URL_TEMPLATE
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    # Test for TESTS

# Generated at 2022-06-24 12:45:38.775519
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import unittest
    import itv

    class TestITVIE(unittest.TestCase):
        def test_ITVIE(self):
            ie = itv.ITVIE()
            self.assertEqual(ie.name, 'itv')
            self.assertTrue(ie.geo_verification_headers())
            self.assertEqual(ie.age_limit, 0)
            self.assertIsNone(ie.article_id)
            self.assertIsNone(ie.item_title)
            self.assertEqual(ie._get_base_class(), itv.ITVIE)

    unittest.main()

test_ITVIE()

# Generated at 2022-06-24 12:45:50.526935
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from ..utils import load_json
    ie = ITVBTCCIE()
    ie_info = ie.extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert(ie_info['id'] == 'btcc-2018-all-the-action-from-brands-hatch')
    assert(ie_info['title'] == 'BTCC 2018: All the action from Brands Hatch')
    # Tests only one of the entries, the first one
    assert(ie_info['entries'][0]['id'] == '5858961106001')
    assert(ie_info['entries'][1]['id'] == '5858961110001')
    assert(len(ie_info['entries']) == 9)

# Generated at 2022-06-24 12:45:53.007334
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE()._match_id(url)

# Generated at 2022-06-24 12:45:58.002872
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert list(ie._GENERIC_IE._POSSIBLE_BRIGHTCOVE_URLS) == [
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    ]
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:46:08.710433
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url_test_1 = 'http://www.itv.com/hub/liar/2a4547a0012'
    url_test_2 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVIE_test = ITVIE()
    ITVBTCCIE_test = ITVBTCCIE()

    assert ITVIE_test._match_id(url_test_1) == '2a4547a0012'
    assert ITVIE_test._match_id(url_test_2) is None
    assert ITVBTCCIE_test._match_id(url_test_1) is None

# Generated at 2022-06-24 12:46:17.959560
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:46:20.416772
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvIE = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert itvIE is not None

# Generated at 2022-06-24 12:46:21.347690
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Test ITVIE

# Generated at 2022-06-24 12:46:22.637656
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-24 12:46:27.857963
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    see https://github.com/ytdl-org/youtube-dl/pull/16374#issuecomment-420863575
    """
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:29.003325
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.name == 'ITV'

# Generated at 2022-06-24 12:46:31.433150
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:46:37.081551
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test ITVIE constructor"""
    ie = ITVIE("")
    ie.BRIGHTCOVE_URL_TEMPLATE
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    # no exception should be raised
    assert True

# Generated at 2022-06-24 12:46:45.472994
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.example.com'
    id = 'btcc-2018-all-the-action-from-brands-hatch'
    title = 'BTCC 2018: All the action from Brands Hatch'
    ext = 'mp4'
    description = 'md5:d0f91536569dec79ea184f0a44cca089'
    series = 'Liar'
    season_number = 2
    episode_number = 6
    itvie = ITVIE(url)
    assert itvie.url == url
    assert itvie.info_dict['id'] == id
    assert itvie.info_dict['title'] == title
    assert itvie.info_dict['ext'] == ext
    assert itvie.info_dict['description'] == description

# Generated at 2022-06-24 12:46:49.009399
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    ITVIE('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')

# Generated at 2022-06-24 12:46:56.861381
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # ITVBTCCIE._VALID_URL does not match this URL,
    # but it matches the parent class ITVIE._VALID_URL
    url = 'http://www.itv.com/hub/adam-looking-for-eve/2a5168a0018'
    result = ITVBTCCIE()._real_extract(url)
    assert result['url'] == 'http://www.itv.com/hub/adam-looking-for-eve/2a5168a0018'

# Generated at 2022-06-24 12:47:02.755092
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    b = ITVBTCCIE()
    assert b.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert b._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
