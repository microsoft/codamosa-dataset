

# Generated at 2022-06-24 12:37:07.586160
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor


# Generated at 2022-06-24 12:37:10.095876
# Unit test for constructor of class ITVIE
def test_ITVIE():
	temp = ITVIE(ITVIE._downloader)
	return

# Generated at 2022-06-24 12:37:19.965225
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    base_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:37:25.200832
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    infoExtractor = ITVBTCCIE()
    assert infoExtractor._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert infoExtractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert infoExtractor._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:37:26.907226
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()


# Generated at 2022-06-24 12:37:30.347108
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.IE_NAME == 'itv:brightcove'

# Generated at 2022-06-24 12:37:40.295070
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.SUCCESS == {
        'info_dict': {
            'id': '',
            'url': '',
            'display_id': '',
            'ext': '',
            'title': '',
            'description': '',
            'series': '',
            'season_number': 0,
            'episode_number': 0
        },
        'params': {
            'format': 'bestvideo+bestaudio',
            'skip_download': 'False'
        }
    }
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']
    assert ie

# Generated at 2022-06-24 12:37:43.762157
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = re.sub(r'itv\.com/hub/', 'itv.com/hub/fake_type/', ITVIE._TESTS[0]['url'])
    assert ITVIE(test_ITVIE.__name__)._match_id(url) is not None

# Generated at 2022-06-24 12:37:45.971775
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-24 12:37:47.217101
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_for_class(ITVBTCCIE)

# Generated at 2022-06-24 12:37:48.593426
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_ITVIE = ITVIE()
    assert ITVIE is ITVIE

# Generated at 2022-06-24 12:37:58.771479
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Arrange
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    # Act
    ITVIE(request=None, downloader=None)
    # Assert
    assert ITVIE(request=None, downloader=None)._VALID_URL == ITVIE._VALID_URL
    assert ITVIE(request=None, downloader=None)._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert ITVIE(request=None, downloader=None)._TESTS == ITVIE._TESTS
    assert ITVIE(request=None, downloader=None)._real_extract(url) == ITVIE._real_extract(ITVIE(request=None, downloader=None), url)



# Generated at 2022-06-24 12:38:02.138380
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-thruxton')

# Generated at 2022-06-24 12:38:03.706678
# Unit test for constructor of class ITVIE
def test_ITVIE():
    testcase = ITVIE()
    testcase.test_suite()


# Generated at 2022-06-24 12:38:11.196329
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    def constructor_test(url, expected_video_id):
        ie = ITVBTCCIE(ITVBTCCIE._create_getinfo_rs(dict(url=url)))
        assert isinstance(ie, ITVBTCCIE)
        assert ie.video_id == expected_video_id
    constructor_test('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
                     'btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:38:13.573512
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    except ImportError:
        pass

# Generated at 2022-06-24 12:38:25.595993
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_itvie = ITVIE(None)._get_iplayer_info()
    assert test_itvie._API_URL == "https://itv.api.mashery.com/v1/api/itvonline"
    assert test_itvie._GEO_COUNTRIES == ['GB']
    assert test_itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:38:26.671108
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == "ITV"

# Generated at 2022-06-24 12:38:28.433212
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccIE = ITVBTCCIE()
    assert(isinstance(itvbtccIE, ITVBTCCIE))

# Generated at 2022-06-24 12:38:30.818713
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:38:41.306666
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ''' Test for constructor of class ITVIE '''
    obj = ITVIE()
    assert obj._ITVIE__VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert obj._ITVIE__GEO_COUNTRIES == ['GB']
    assert isinstance(obj._ITVIE__TESTS, list)
    assert len(obj._ITVIE__TESTS) == 4
    assert obj._ITVIE__TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-24 12:38:44.554380
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE(None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:38:45.805641
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.suitable("https://www.itv.com/hub/liar/2a4547a0012")



# Generated at 2022-06-24 12:38:50.813535
# Unit test for constructor of class ITVIE
def test_ITVIE():
    #test the constructor of the class ITVIE
    ie = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert ie.get_domain() == 'itv.com'
    assert ie.get_id() == '2a4547a0012'
    assert isinstance(ie.get_data(), dict)

# Generated at 2022-06-24 12:38:59.590111
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_videoID = '5695123737001'
    expected_webpage_URL = 'http://www.itv.com/btcc/races'
    expected_webpage_title = 'BTCC races'
    expected_video_title = 'BTCC: 2018: All the action from Thruxton'
    expected_video_description = 'The best moments from this weekend\'s BTCC action at Thruxton.'
    expected_playlist_entries = [
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5695123737001'
    ]
    expected_playlist_title = 'BTCC: 2018: All the action from Thruxton'

# Generated at 2022-06-24 12:39:01.334606
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE()
    print(obj)

# Generated at 2022-06-24 12:39:02.153777
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:39:04.934407
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE()
    assert itv._TEST['url'] == itv._match_id(itv._TEST['url'])
#TODO Add ITVCatchUpIE and ITVPlayerIE

# Generated at 2022-06-24 12:39:05.533830
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:39:15.612722
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE('',{})
    assert obj._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert obj._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:39:16.798172
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE.test()
    ITVBTCCIE.test()

# Generated at 2022-06-24 12:39:23.448976
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    obj = ie.suitable('https://www.itv.com/hub/liar/2a4547a0012')
    if obj:
        url = 'https://www.itv.com/hub/liar/2a4547a0012'
        video_id  = ie._match_id(url)
        webpage = ie._download_webpage(url, video_id)

# Generated at 2022-06-24 12:39:35.788170
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from . import ITVIE
    from . import ITVIE
    from . import ITVIE
    from . import ITVIE
    from . import ITVIE
    from . import ITVIE
    from . import ITVIE
    from . import ITVIE
    itv = ITVIE({'geo_verification_headers': {'header': 'value'}, 'params':{'name':'value'}})
    gbh = itv.geo_verification_headers
    assert gbh['header'] == 'value'
    assert gbh['Accept'] == 'application/vnd.itv.vod.playlist.v2+json'
    assert gbh['Content-Type'] == 'application/json'

# Generated at 2022-06-24 12:39:37.856232
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    u = ITVBTCCIE.ITVBTCCIE()
    assert u

# Generated at 2022-06-24 12:39:38.420862
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:39:47.478288
# Unit test for constructor of class ITVIE
def test_ITVIE():
	url = 'https://www.itv.com/hub/liar/2a4547a0012'
	video_id = ITVIE._match_id(url)	
	webpage = ITVIE._download_webpage(url, video_id)
	params = extract_attributes(ITVIE._search_regex(
            r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params'))
	ios_playlist_url = params.get('data-video-playlist') or params['data-video-id']
	hmac = params['data-video-hmac']
	headers = ITVIE.geo_verification_headers()

# Generated at 2022-06-24 12:39:49.135714
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVIE()
    x.constructor()

# Generated at 2022-06-24 12:39:52.856273
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL
    assert ITVIE()._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert ITVIE()._TESTS == ITVIE._TESTS


# Generated at 2022-06-24 12:39:59.685368
# Unit test for constructor of class ITVIE
def test_ITVIE():
    data = ITVIE('https://www.itv.com/hub/liar/2a4547a0012').get_data()
    assert data['id'] == '2a4547a0012'
    assert data['title'] == 'Liar - Series 2 - Episode 6'
    assert data['description'] == 'md5:d0f91536569dec79ea184f0a44cca089'
    assert data['series'] == 'Liar'
    assert data['season_number'] == 2
    assert data['episode_number'] == 6


# Generated at 2022-06-24 12:40:00.179860
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:40:03.058322
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:09.080791
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Check constructor takes a URL and returns
    # an ITVBTCCIE object
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    ie = ITVBTCCIE(ITVBTCCIE._create_ie(), url)
    assert(isinstance(ie, ITVBTCCIE))

# Generated at 2022-06-24 12:40:13.905437
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert str(itv) == 'ITVBTCCIE url=http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:40:14.520614
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:40:17.329432
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BTCC_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:18.118992
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:40:19.292564
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print(ITVIE())

# Generated at 2022-06-24 12:40:22.828806
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012','Liar - Series 2 - Episode 6','md5:d0f91536569dec79ea184f0a44cca089','Liar',2,6,'mp4')

# Generated at 2022-06-24 12:40:23.877011
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)

# Generated at 2022-06-24 12:40:24.672867
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert x

# Generated at 2022-06-24 12:40:29.884966
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    "Unit test for constructor of class ITVBTCCIE"
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:40:31.799720
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class MyITVIE(ITVIE):
        pass

    assert MyITVIE(ITVIE.IE_NAME)._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-24 12:40:32.298068
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:40:33.330237
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-24 12:40:37.345700
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None, None).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:37.882033
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:40:48.158321
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()

    assert info_extractor._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:40:59.480960
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    selenium_webdriver = 'selenium.webdriver.firefox.webdriver.WebDriver'
    selenium_webdriver_ctor_args = [ 'firefox' ]
    selenium_webdriver_ctor_kwargs = { 'firefox_binary': '/usr/bin/firefox-esr' }
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    autoplay = True
    # This is the number of videos that ITVBTCCIE will find.
    expected_video_count = 9
    # Create instance of ITVBTCCIE.

# Generated at 2022-06-24 12:41:04.709397
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # See: https://github.com/ytdl-org/youtube-dl/pull/15206#issuecomment-365478885
    assert ITVBTCCIE({}).extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:41:11.549502
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    entry = itvbtccie._real_extract("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert entry["id"] == "btcc-2018-all-the-action-from-brands-hatch"
    assert entry["title"] == "BTCC 2018: All the action from Brands Hatch"

# Generated at 2022-06-24 12:41:12.838134
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-24 12:41:23.116605
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    class_name = 'ITVBTCCIE'
    class_obj = ITVBTCCIE(url)
    assert class_obj.url == url, 'url property of class %s is not correct' % class_name
    assert class_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s', 'BRIGHTCOVE_URL_TEMPLATE of class %s is not correct' % class_name

# Generated at 2022-06-24 12:41:34.829556
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    constructor = ITVIE.__init__
    this_file = __file__.split('\\')[-1]
    assert ie.extractor_key() == 'itv'
    assert ie.ie_key() == 'itv'
    assert ie.host() == 'www.itv.com'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ITVIE.BRIGHTCOVE_URL_TEMPLATE
    assert constructor.__annotations__ == {
        'url': str,
        'return': None,
        'populate_videos_list': True,
        'youtube_ie': str,
        'youtube_dl': dict,
        'params': dict,
    }
    assert ie.BRIGHTCOVE_URL_TEMPLATE in ITVIE.IE

# Generated at 2022-06-24 12:41:36.293873
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test with valid input
    example_input = ITVIE(None)
    # Test with invalid input
    invalid_input = ITVIE(None)

# Generated at 2022-06-24 12:41:37.248002
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'ITV'

# Generated at 2022-06-24 12:41:39.689281
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:41:43.073021
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = info_extractor._match_id(url)
    assert video_id == '2a4547a0012'

# Generated at 2022-06-24 12:41:47.523178
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL
    assert ITVBTCCIE()._VALID_URL == ITVBTCCIE._VALID_URL
    assert ITVIE().IE_NAME == ITVIE._NAME
    assert ITVBTCCIE().IE_NAME == ITVBTCCIE._NAME

# Generated at 2022-06-24 12:41:48.086032
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:41:56.310769
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc = ITVBTCCIE()
    dump_config(itv_btcc)
    assert itv_btcc.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itv_btcc.geo_verification_headers == ITVIE.geo_verification_headers
    assert itv_btcc._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES

# Generated at 2022-06-24 12:41:58.742339
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.__class__.__name__ == 'ITVIE'

# Generated at 2022-06-24 12:42:07.622377
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    site = ITVBTCCIE()
    site.ITVBTCCIE()
    assert site._downloader is not None
    assert site._match_id(url) == "btcc-2018-all-the-action-from-brands-hatch"
    assert site.BRIGHTCOVE_URL_TEMPLATE == \
           'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
# Unit tests for method _real_extract in class ITVBTCCIE

# Generated at 2022-06-24 12:42:13.840366
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    e = ITVBTCCIE()
    expected = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5726631414001'
    assert e.BRIGHTCOVE_URL_TEMPLATE % '5726631414001' == expected

# Generated at 2022-06-24 12:42:15.808787
# Unit test for constructor of class ITVIE
def test_ITVIE():
    for url in ITVIE._TESTS:
        ITVIE(dict())._download_webpage(url['url'], video_id='2a4547a0012')


# Generated at 2022-06-24 12:42:17.587532
# Unit test for constructor of class ITVIE
def test_ITVIE():
    f = ITVIE('http://www.itv.com/hub/'
              'the-only-way-is-essex/1a1148a0011')
    assert f.__class__ == ITVIE

# Generated at 2022-06-24 12:42:20.274882
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    e = ITVBTCCIE()
    assert e._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:42:24.278758
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    t = ITVBTCCIE()
    assert t._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:42:27.007665
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_ITVBTCCIE_instance = ITVBTCCIE()
    assert test_ITVBTCCIE_instance.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-24 12:42:35.693112
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    unit = ITVBTCCIE()
    assert unit._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert unit._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:42:39.552700
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    asserTv = ITVBTCCIE()
    asserTv._match_id("https://www.itv.com/btcc/");
    asserTv.BRIGHTCOVE_URL_TEMPLATE;


# Generated at 2022-06-24 12:42:49.562777
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()

    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:42:54.818140
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test constructor of class ITVBTCCIE"""
    obj = ITVBTCCIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# test = test_ITVBTCCIE()
# test

# Generated at 2022-06-24 12:43:01.073654
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE()
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert inst._match_id(inst._VALID_URL) == TVBTCCIE._match_id(TVBTCCIE._VALID_URL)
    assert inst._real_extract(inst._TEST['url']).keys() == TVBTCCIE._TEST['info_dict'].keys()

# Generated at 2022-06-24 12:43:05.352728
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    runner = ITVBTCCIE.test('btcc-2018-all-the-action-from-brands-hatch')
    assert(runner.data['playlist'][1]['id'] == "5675356896001")
    assert(runner.data['title'] == "BTCC 2018: All the action from Brands Hatch")

# Generated at 2022-06-24 12:43:15.687569
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.ie_key() == 'ITVBTCC'
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvbtccie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:43:24.339705
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Example for constructor of class ITVIE
    example = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    obj_attributes = ['url', '_VALID_URL', '_TESTS', '_GEO_COUNTRIES']
    for i in obj_attributes:
        assert hasattr(example, i) is True, "Attribute %s is missing" % (i)
    assert example._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)', 'URL pattern is not match'

# Generated at 2022-06-24 12:43:26.130643
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'ITV'


# Generated at 2022-06-24 12:43:34.058320
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683002/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683002/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:40.902694
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class Obj(object):
        pass
    loader = ITVBTCCIE.__base__(Obj())

    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE._TEST == {'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'info_dict': {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'BTCC 2018: All the action from Brands Hatch'
    }, 'playlist_mincount': 9}
    assert ITVBTCCIE

# Generated at 2022-06-24 12:43:42.886234
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE(object(), '', '')
    assert ie._GEO_COUNTRIES == ['GB']
    assert ie._TESTS

# Generated at 2022-06-24 12:43:51.721269
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .common import parse_duration
    from .brightcove import BrightcoveNewIE
    for url in [
            'https://www.itv.com/hub/liar/2a4547a0012',
            'https://www.itv.com/hub/though-the-keyhole/2a2271a0033',
            'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034',
            'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024']:
        ie = ITVIE()
        item = ie.extract(url)
        assert item['id'] == ie._match_id(url)
        assert item['formats']
        assert item['title']

# Generated at 2022-06-24 12:43:52.403933
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE() == ITVBTCCIE

# Generated at 2022-06-24 12:43:54.502299
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVExtractor = ITVIE('ITVIE')
    assert 'ITVIE' == ITVExtractor.ie_key()


# Generated at 2022-06-24 12:43:55.871998
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # can't reliably test it without accessing geo restricted playlist
    pass

# Generated at 2022-06-24 12:44:00.159775
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'

    infoExtractor = ITVIE()

    assert url == infoExtractor._VALID_URL
    assert 'Liar' == infoExtractor._TESTS[0]['info_dict']['title']

# Generated at 2022-06-24 12:44:00.728709
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:44:03.345005
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    example_object = ITVBTCCIE(ITVIE._downloader)
    # testing if example_object is an instance of ITVBTCCIE or not
    assert isinstance(example_object, ITVBTCCIE)

# Generated at 2022-06-24 12:44:04.597067
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(InfoExtractor())._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:44:08.606343
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    itvbtccie = ITVBTCCIE()
    assert isinstance(itvbtccie, ITVBTCCIE)


# Generated at 2022-06-24 12:44:12.102071
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '5786246372001'
    exp = ITVBTCCIE(ITVBTCCIE._build_url(url, {}))
    assert exp

# Generated at 2022-06-24 12:44:13.105252
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test if ITVIE can be created
    ITVIE()

# Generated at 2022-06-24 12:44:15.663314
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE();
    expected_instance_id = 'itv.com/btcc';
    assert(ie._WORKING_IE_NAME == expected_instance_id);
    # Construct a fresh instance
    ie = ITVBTCCIE();
    assert(ie._WORKING_IE_NAME == expected_instance_id);

# Generated at 2022-06-24 12:44:19.512294
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test on an ITV BTCC page
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    BTCC_ie = ITVBTCCIE._match_id(url)
    assert BTCC_ie is not None

# Generated at 2022-06-24 12:44:23.793754
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	test_ITVBTCCIE = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
	assert test_ITVBTCCIE



# Generated at 2022-06-24 12:44:33.944798
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from ..compat import compat_cookiejar
    from ..utils import ExtractorError

    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_url_not_valid = 'http://www.itv.com/btcc/races/'
    test_url_not_working = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands'

    ie = ITVBTCCIE()
    res = ie.suitable(test_url)
    assert res == True

    ie = ITVBTCCIE()
    res = ie.suitable(test_url_not_valid)
    assert res == False

    ie = ITVBTCCIE()


# Generated at 2022-06-24 12:44:35.795231
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie= ITVIE.ie2info()
    instance = ITVIE()
    assert( ie == instance.info())

# Generated at 2022-06-24 12:44:38.111297
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE()
    inst.BRIGHTCOVE_URL_TEMPLATE
    inst._download_webpage
    inst._real_extract

# Generated at 2022-06-24 12:44:39.544331
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """ test the ITVIE class builder """
    instance = ITVIE()

# Generated at 2022-06-24 12:44:43.024218
# Unit test for constructor of class ITVIE
def test_ITVIE():
    unit_test = ITVIE()
    assert unit_test._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-24 12:44:48.661647
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvIE = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    assert itvIE.get("url") == "http://www.itv.com/hub/liar/2a4547a0012"
    assert itvIE.get("video_id") == "2a4547a0012"

# Generated at 2022-06-24 12:44:50.234666
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    m = ITVBTCCIE()
    print(m.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-24 12:44:52.865478
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE()
    assert inst._VALID_URL == ITVIE._VALID_URL
    assert inst._TESTS == ITVIE._TESTS

# Generated at 2022-06-24 12:45:00.169314
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE(request=None, url=url)
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._downloader is None

# Generated at 2022-06-24 12:45:05.673915
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    result = ITVBTCCIE()._real_extract(url)
    assert result['url'] == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5839882470001'

# Generated at 2022-06-24 12:45:10.843479
# Unit test for constructor of class ITVIE
def test_ITVIE():
    unit = ITVIE()
    # Testing for the URL of a typical ITV show.
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert re.match(ITVIE._VALID_URL, url) is not None
    assert unit._match_id(url) == '2a4547a0012'


# Generated at 2022-06-24 12:45:20.647883
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE._TESTS.append(
        {
            'url': 'http://www.itv.com/hub/the-voice-uk/2a3283a0056',
            'info_dict': {
                'id': '2a3283a0056',
                'ext': 'mp4',
                'title': 'The Voice UK - Series 7 - Episode 9',
                'description': 'md5:8e71a935b7fb1cc19d1e213e8b6eb07c',
                'series': 'The Voice UK',
                'season_number': 7,
                'episode_number': 9,
            },
            'params': {
                # m3u8 download
                'skip_download': True,
            }
        }
    )


# Generated at 2022-06-24 12:45:31.899367
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITV_URL = 'https://www.itv.com/hub/liar/2a4547a0012'
    itv = ITVIE()
    assert itv._match_id(ITV_URL) == '2a4547a0012'
    assert itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itv._GEO_COUNTRIES == ['GB']
    assert itv._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-24 12:45:37.843132
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    expected_url = 'http://www.itv.com/hub/ghost-adventures/2a7a76a0011'
    url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5727153471001'
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '5727153471001' == url
    assert ITVBTCCIE()._get_suggested_target_for_url(url) == expected_url

# Generated at 2022-06-24 12:45:38.741288
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-24 12:45:43.439019
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    I = ITVBTCCIE()
    assert I.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:45.702776
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVIE()
    print(x._VALID_URL)

# Generated at 2022-06-24 12:45:48.318600
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    ITVIE(url)
    assert True


# Generated at 2022-06-24 12:45:52.618821
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test the constructor
    instance = ITVIE(None)

    assert instance._VALID_URL == ITVIE._VALID_URL

    assert instance._TESTS == ITVIE._TESTS

    assert instance._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES


# Generated at 2022-06-24 12:45:58.228250
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE({'geo_countries': set()})._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE({'geo_countries': set(['GB'])})._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:46:07.145546
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('https://www.itv.com/hub/britains-brightest-family/6a1034aa0020')
    assert ie._valid_url(ie.BRIGHTCOVE_URL_TEMPLATE % '5768007800001')
    assert ie._valid_url('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') is True
    assert ie._real_extract(ie.BRIGHTCOVE_URL_TEMPLATE % '5768007800001') is True


# Generated at 2022-06-24 12:46:10.891755
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    print('\nTest constructor of class ITVBTCCIE')
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE(url)
    assert ie.valid_url(url)

# Generated at 2022-06-24 12:46:20.716791
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE._TEST == {'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
                               'info_dict': {'id': 'btcc-2018-all-the-action-from-brands-hatch',
                                             'title': 'BTCC 2018: All the action from Brands Hatch'},
                               'playlist_mincount': 9}

# Generated at 2022-06-24 12:46:29.837147
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .free_the_movies import FreeTheMoviesIE
    assert(ITVBTCCIE._downloader is None)
    assert(ITVBTCCIE._available() == True)
    assert(ITVBTCCIE.ie_key() == 'itvbtcc:')
    assert(ITVBTCCIE._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    })

# Generated at 2022-06-24 12:46:37.122954
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE(ITVBTCCIE._downloader).correct_url(url) == url
    assert ITVBTCCIE._match_id('www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:46:45.556434
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ie._TESTS[0]['info_dict']['id'] == '2a4547a0012'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert ie._TESTS[0]['params']['skip_download'] == True

# Generated at 2022-06-24 12:46:48.879690
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from datetime import datetime
    ITVIE_obj = ITVIE()
    example_datetime_str = '2019-09-04T03:42:34.000Z'
    example_datetime_obj = ITVIE_obj.parse_iso8601(example_datetime_str)
    assert(type(example_datetime_obj) is datetime)
    assert(type(ITVIE_obj._sort_formats([])) is list)


# Generated at 2022-06-24 12:46:59.874716
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    assert i._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:47:06.134938
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE('btcc-2018-all-the-action-from-brands-hatch')
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:47:10.522440
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test basic constructor of class ITVIE
    url = 'https://www.itv.com/hub/coronation-street/2a21167a0196'
    video_id = '2a21167a0196'
    class_ = ITVIE
    instance = class_(url)
    assert instance.__class__.__name__ == 'ITVIE'