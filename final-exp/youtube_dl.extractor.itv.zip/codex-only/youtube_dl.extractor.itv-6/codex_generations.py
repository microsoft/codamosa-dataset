

# Generated at 2022-06-24 12:37:08.334772
# Unit test for constructor of class ITVIE
def test_ITVIE():
	test_url = 'https://www.itv.com/hub/liar/2a4547a0012'
	ITVIE = ITVIE(test_url)
	assert ITVIE.url == test_url, 'URL string has been assigned correctly'
	assert IVTIE.ext == 'mp4', 'Extention is mp4'


# Generated at 2022-06-24 12:37:12.250161
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:16.628399
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    

# Generated at 2022-06-24 12:37:24.047493
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .test import get_testcases
    itv_btcc_test = get_testcases(ITVBTCCIE)
    if not itv_btcc_test:
        raise Exception("test for ITVBTCCIE not found")
    for result in itv_btcc_test:
        if '_TEST' not in result:
            continue
        # test calls _real_extract which calls _download_webpage
        # and _download_webpage uses a cache and _download_json
        # caches results but _download_json returns cached results
        # only if response is not modified so we need to bypass
        # the cache
        result['test']._download_webpage = result['test']._real_download
        result['test']._download_json = result['test']._real_download

# Generated at 2022-06-24 12:37:27.407049
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')


# Generated at 2022-06-24 12:37:31.633443
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .itvbtcc import ITVBTCCIE
    # Construct an instance of ITVBTCCIE
    itvbtcc_instance = ITVBTCCIE(None)
    assert isinstance(itvbtcc_instance, ITVBTCCIE)

# Generated at 2022-06-24 12:37:32.563898
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:37:35.935081
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    ITVBTCCIE(None)._real_extract(url)

# Generated at 2022-06-24 12:37:43.723014
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    extractor = ITVBTCCIE(url)
    assert extractor.BRIGHTCOVE_URL_TEMPLATE in extractor.urls
    assert 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5917203466001' in extractor.urls
    assert extractor.urls[0] == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5917203466001'

# Generated at 2022-06-24 12:37:44.251514
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:37:46.151520
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Constructor test
    """
    ITVIE(InfoExtractor)._test_constructor()


# Generated at 2022-06-24 12:37:46.991126
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:37:47.630126
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:37:58.119137
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    infoExtractor = ITVBTCCIE()
    assert infoExtractor._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert infoExtractor._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:38:03.225973
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        from .common import test_url_re
    except ImportError:
        test_url_re = None
    if test_url_re:
        test_url_re(ITVBTCCIE._VALID_URL, ITVBTCCIE._TEST['url'])

# Generated at 2022-06-24 12:38:08.200355
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Create an instance of ITVIE
    try:
        ITVIE()
        raise RuntimeError("should be failed before")
    except TypeError:
        pass
    itv_ie = ITVIE("1")
    assert "ItvBaseInfoExtractor" == itv_ie._downloader.__class__.__name__

# Generated at 2022-06-24 12:38:09.935795
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:38:11.349871
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(InfoExtractor())._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-24 12:38:13.904770
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert(itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')
    assert(itv._TESTS[0]['info_dict']['title'] == 'Liar - Series 2 - Episode 6')

# Generated at 2022-06-24 12:38:25.996560
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class_ = ITVBTCCIE
    assert class_.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert class_._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert class_._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert class_._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert class_._TEST['playlist_mincount'] == 9

# Generated at 2022-06-24 12:38:27.395192
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()
    assert isinstance(IE, ITVIE)


# Generated at 2022-06-24 12:38:33.211891
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Constructor of ITVBTCCIE calls ITVIE.__init__
    # The url.split('/')[3] is used to retrieve the id
    # This test checks whether the url.split('/')[3] works as expected
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._match_id(test_url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:38:42.695435
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    video_id = 'L-H1wzR8_'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    url = 'http://www.itv.com/btcc/' + playlist_id
    url_template = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    expected_url = 'https://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s&referrer=https%3A%2F%2Fwww.itv.com%2Fbtcc%2F' % playlist_id
    title = 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-24 12:38:45.823624
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    sut = ITVBTCCIE()
    assert sut.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:38:54.923990
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import unittest
    from youtube_dl.extractor.itv import ITVBTCCIE

    class TestITVBTCCIE(unittest.TestCase):
        def setUp(self):
            self.ie = ITVBTCCIE('ITVBTCCIE')

        def test_instantiate(self):
            self.assertEqual('http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5662214235001', self.ie._search_regex(
                r'data-video-id=["\'](\d+)', 'data-video-id="5662214235001"', 'url'))

    unittest.main()

# Generated at 2022-06-24 12:38:58.123973
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	ie = ITVBTCCIE()
	assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:04.003103
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    tester = ITVBTCCIE()
    tester.suite()
    ret = tester._real_extract(url)
    assert ret['id'] == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:39:07.236358
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:11.969868
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:39:22.719350
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .test_html import FakeTestCase
    from .test_brightcove import TestBrightcoveNewIE
    itvBTCCIE = ITVBTCCIE()
    fakeTestCase = FakeTestCase(itvBTCCIE, {'ITVBTCCIE': itvBTCCIE})
    testBrightcoveNew = TestBrightcoveNewIE()

    assert itvBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:39:23.615841
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    print(itv)

# Generated at 2022-06-24 12:39:32.100654
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE()
    assert test._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'
    assert test._match_id('https://www.itv.com/hub/dci-banks/1a8097a0147') == '1a8097a0147'

# Generated at 2022-06-24 12:39:42.480309
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE(None)
    # Test ITV.es website
    itv.extract('http://www.itv.com/hub/capital-london/2a9462')
    itv.extract('http://www.itv.com/hub/lorraine/2a2112')
    itv.extract('http://www.itv.com/hub/latin-america-gets-talent/1a3681a0001')
    itv.extract('http://www.itv.com/hub/lorraine/2a2112')
    itv.extract('http://www.itv.com/hub/lorraine/2a2112')
    itv.extract('http://www.itv.com/hub/lorraine/2a2112')

    # Test ITV.es website

# Generated at 2022-06-24 12:39:46.619454
# Unit test for constructor of class ITVIE
def test_ITVIE():    # noqa; pylint: disable=invalid-name
    iev = ITVIE()
    assert iev._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert iev._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:39:52.582431
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # init
    test_instance = ITVBTCCIE()
    # check ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE
    assert test_instance.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"

# Generated at 2022-06-24 12:39:56.488640
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:59.028473
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    url_path = ITVBTCCIE.url_result(url, video_id='')
    url_path.return_values = url
    ITVBTCCIE.url_result(url)

# Generated at 2022-06-24 12:40:01.377619
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE('hello')
    except Exception as e:
        print(e)

    try:
        ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    except Exception as e:
        print(e)

# Generated at 2022-06-24 12:40:04.737040
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE('2a4547a0012')
    assert ie.url == 'https://www.itv.com/hub/liar/2a4547a0012'


# Generated at 2022-06-24 12:40:15.063609
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']
    assert ie._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-24 12:40:17.510136
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:40:20.753846
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:40:23.821907
# Unit test for constructor of class ITVIE
def test_ITVIE():
    tv_ie = ITVIE('')
    assert tv_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:40:25.012397
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test constructor of ITVIE."""
    _ITVIE = ITVIE()

# Generated at 2022-06-24 12:40:32.745864
# Unit test for constructor of class ITVIE
def test_ITVIE():
    module = __import__('itv')
    test_cases = [
        # link - only-matching
        {
            'url': 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033',
            'only_matching': True,
        },
        # link - invalid-vodcrid
        {
            'url': 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034',
            'only_matching': True,
        },
        # link - unavailable-content
        {
            'url': 'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024',
            'only_matching': True,
        }
    ]

# Generated at 2022-06-24 12:40:35.956862
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert ITVBTCCIE._VALID_URL == i._VALID_URL
    assert ITVBTCCIE._TESTS == i._TESTS

# Generated at 2022-06-24 12:40:37.385911
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.__class__ == ITVIE

# Generated at 2022-06-24 12:40:43.259243
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:45.043153
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE(None)
    assert ie.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-24 12:40:50.762824
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test for ITVIE constructor
    if (not ITVIE.working()):
        pytest.xfail(ITVIE._WORKING + ' is False')
    ie = ITVIE()
    assert ie._VALID_URL == ITVIE._VALID_URL
    assert ie._TESTS == ITVIE._TESTS
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ITVIE.BRIGHTCOVE_URL_TEMPLATE
    assert ie.GEO_COUNTRIES == ITVIE._GEO_COUNTRIES

# Generated at 2022-06-24 12:41:01.603266
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:41:06.469319
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE(IE_NAME)
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie

# Generated at 2022-06-24 12:41:09.102588
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL[3].startswith('https://(?:www\.)?itv\.com/hub/')

# Generated at 2022-06-24 12:41:10.367873
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'ITV'



# Generated at 2022-06-24 12:41:17.128453
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Test if the constructor of class ITVIE works.
    """
    from . import ITVIE

    # Test case 1
    ITVIE = ITVIE.ITVIE()
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

    # Test case 2
    ITVIE = ITVIE.ITVIE()
    assert ITVIE._GEO_COUNTRIES == 'GB'

    # Test case 3
    ITVIE = ITVIE.ITVIE()
    assert ITVIE._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'

    # Test case 4

# Generated at 2022-06-24 12:41:21.112232
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_verification_headers()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:23.561777
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test importing ITVIE class
    assert ITVIE is not None
    # Test getting an instance of ITVIE class
    itv_ie = ITVIE()
    assert isinstance(itv_ie, ITVIE)
    assert itv_ie.BRIGHTCOVE_URL_TEMPLATE is not None



# Generated at 2022-06-24 12:41:25.604907
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE
    assert 'ITVIE' in ITVIE.ie_key()

# Generated at 2022-06-24 12:41:26.780533
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE("")

# Generated at 2022-06-24 12:41:30.720591
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:31.518874
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:41:33.330025
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL
    

# Generated at 2022-06-24 12:41:36.355985
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE.suitable(url)

# Generated at 2022-06-24 12:41:38.284672
# Unit test for constructor of class ITVIE
def test_ITVIE():
    return ITVIE(None)._download_webpage('http://www.itv.com/hub/family-guy/2a918f000001', None)

# Generated at 2022-06-24 12:41:40.033258
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    t = ITVBTCCIE()
    assert '<div class="video-player__wrapper">' in t.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:41:42.208745
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(url)

# Generated at 2022-06-24 12:41:43.425595
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IE = ITVBTCCIE()
    return IE

# Generated at 2022-06-24 12:41:46.278849
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    ie = ITVIE()
    ie.extract(url)

# Generated at 2022-06-24 12:41:48.209364
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE()._real_extract(url)

# Generated at 2022-06-24 12:41:49.679072
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:41:50.204895
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:41:59.910673
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        import mock
    except ImportError as e:
        e.args = tuple(['%s (you may install mock with "pip install mock")' % e.args[0]])
        raise
    url = 'http://www.itv.com/btcc/btcc-2018-donington-park-race-day'
    ie = ITVBTCCIE()
    with mock.patch.object(InfoExtractor, 'url_result', return_value=True) as url_result:
        ie.url_result = url_result
        with mock.patch.object(InfoExtractor, '_download_webpage',
                               return_value='<html></html>') as dw:
            ie._download_webpage = dw
            ie._real_extract(url)
            assert ie.url_result.call_count

# Generated at 2022-06-24 12:42:00.529897
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:42:08.627254
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor_ITVIE = ITVIE()
    assert info_extractor_ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    # _VALID_URL must contain the regular expression
    # pattern of the valid URLS
    assert len(ITVIE._TESTS) == 4
    # _TESTS is a list of dictionaries to test the
    # function _real_extract()
    assert ITVIE._GEO_COUNTRIES == ['GB']
    # _GEO_COUNTRIES list all the geo restricted countries
    # to download the video


# Generated at 2022-06-24 12:42:11.892972
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_verification_headers() == {'X-Country-Code': 'GB'}

# Generated at 2022-06-24 12:42:13.437827
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(InfoExtractor())

# Generated at 2022-06-24 12:42:16.391369
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .common import expectedFail
    expectedFail(lambda: ITVBTCCIE('http://www.itv.com/hub/itv-racing-action/2a3361a0011'))



# Generated at 2022-06-24 12:42:19.793205
# Unit test for constructor of class ITVIE
def test_ITVIE():
    '''
    Unit test for ITVIE
    '''

    itv_test = ITVIE(ITVIE.IE_NAME)
    assert type(itv_test) == ITVIE
    assert itv_test.IE_NAME == 'ITV'
    assert itv_test.ie_key() == 'itv'



# Generated at 2022-06-24 12:42:30.609489
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.param_name == "itv_video_id"
    assert ie.param_form_id == "itv_video_id"
    assert ie.param_label == "URL or ITV Video ID"
    assert ie.param_t.template == "bulk_download_button"
    assert ie.param_t.args == {'message': 'Download the video in bulk',
                               'prefix_path': '',
                               'args': [['itv_video_id']],
                               'additional_args': [{'name': '-o',
                                                    'value': 'ITV Video ID [video]/%(title)s.%(ext)s'}],
                               'path_formatter': 'ITV_path'}

# Generated at 2022-06-24 12:42:32.205372
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test guard for ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE being initialized
    pass

# Generated at 2022-06-24 12:42:35.385071
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert i.__class__.__name__ == 'ITVBTCCIE'



# Generated at 2022-06-24 12:42:36.650162
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:42:41.290169
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE().test(ITVBTCCIE._TEST)
    assert test['playlist'][0]['url'] == r'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5876418108001'

# Generated at 2022-06-24 12:42:45.691960
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    input_url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    obj = ITVBTCCIE(ITVBTCCIE.create_from_url(input_url))
    assert obj._match_id(input_url) is not None

# Generated at 2022-06-24 12:42:52.596141
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video = ITVIE()
    assert ITVIE._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._GEO_COUNTRIES == ['GB']
    assert ITVIE.__name__ == 'ITVIE'
    assert hasattr(video, '_real_initialize')
    assert hasattr(video, '_real_extract')
    assert callable(video._real_initialize)
    assert callable(video._real_extract)


# Generated at 2022-06-24 12:42:55.287867
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    klass = ITVBTCCIE()
    obj = klass.url_result(url)
    assert obj.url == url
    assert obj.__class__ == klass

# Generated at 2022-06-24 12:43:02.539035
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    o = ITVBTCCIE()
    assert o.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert o._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert o._TEST['info_dict'] == {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}
    assert o._TEST['playlist_mincount'] == 9

# Generated at 2022-06-24 12:43:12.933404
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    webpage = '<html></html>'

# Generated at 2022-06-24 12:43:14.475359
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        from itv_utils import ITVIE
    except:
        raise ImportError


    ITVInstance = ITVIE()

    # Assert instance creation
    assert ITVInstance


if __name__ == "__main__":
    test_ITVIE()

# Generated at 2022-06-24 12:43:18.185055
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url="http://www.itv.com/hub/racing/1a569a0003"
    ie=ITVBTCCIE()
    result=ie._real_extract(test_url)
    assert result['id']=='btcc-2018-all-the-action-from-brands-hatch'


# Generated at 2022-06-24 12:43:23.150641
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch').BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:26.948900
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:43:35.420309
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    match = ITVBTCCIE._VALID_URL.match(url)
    id = match.group('id')
    match = re.search(r'data-video-id=["\'](\d+)', id)
    video_id = match.group(1)
    ie = ITVBTCCIE()

# Generated at 2022-06-24 12:43:36.645112
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_class = ITVIE("ITVIE", {}, {})
    assert test_class

# Generated at 2022-06-24 12:43:39.197277
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        re.compile('0f91536569dec79ea184f0a44cca089')
    except re.error:
        pass

# Generated at 2022-06-24 12:43:45.140663
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE('', '')
    assert itvbtccie is not None
    # Test that the BRIGHTCOVE_URL_TEMPLATE is as expected
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:45.711441
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:43:46.581553
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()

# Generated at 2022-06-24 12:43:47.467148
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    d = ITVBTCCIE()
    assert d

# Generated at 2022-06-24 12:43:50.192624
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:43:54.897761
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Basic tests for ITVIE
    itv_ie = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert itv_ie.video_id == '2a4547a0012'
    # Test for ITVBTCCIE
    itv_btcc_ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert itv_btcc_ie.video_id == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:43:58.506557
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert(x.url == "https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:44:01.204867
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(ITVBTCCIE._downloader)._download_webpage('http://www.itv.com/hub/liar/2a4547a0012', '2a4547a0012')

# Generated at 2022-06-24 12:44:03.148801
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    assert i._VALID_URL == ITVIE._VALID_URL
    assert i._TESTS == ITVIE._TESTS

# Generated at 2022-06-24 12:44:04.887148
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_verification_headers() == {'X-Country-Code': 'GB'}

# Generated at 2022-06-24 12:44:14.812455
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = 'http://www.itv.com/hub/liar/2a4547a0012'
    itv = ITVIE()
    itv._VALID_URL = ITVIE._VALID_URL
    itv._TEST = ITVIE._TEST
    itv._download_webpage = lambda x: 'abc'
    itv._search_regex = lambda x, y, z: 'params'
    itv._download_json = lambda x, y, z: {'Playlist': {'Video': {'Base': '', 'MediaFiles': [{'Href': '/sample.m3u8'}]}}}

# Generated at 2022-06-24 12:44:17.507954
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % "123" == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=123"

# Generated at 2022-06-24 12:44:18.377380
# Unit test for constructor of class ITVIE
def test_ITVIE():
    p = ITVIE()
    assert p != None

# Generated at 2022-06-24 12:44:29.156966
# Unit test for constructor of class ITVIE
def test_ITVIE():
    cls = ITVIE
    query = cls._search_regex
    qp = cls._search_regex
    download_json = cls._download_json
    determine_ext = cls._determine_ext
    smuggle_url = cls._smuggle_url
    geo_verification_headers = cls._geo_verification_headers
    search_json_ld = cls._search_json_ld
    parse_json = cls._parse_json
    search_regex = cls._search_regex
    clean_html = cls._clean_html
    extract_attributes = cls._extract_attributes
    extract_all = cls._extract_all
    sort_formats = cls._sort_formats
    url_result = cls._url_result
    html

# Generated at 2022-06-24 12:44:33.210525
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL
    assert ITVIE()._TESTS == ITVIE._TESTS
    assert ITVIE()._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES



# Generated at 2022-06-24 12:44:40.712869
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Unit test for ITVIE constructor with valid url to ITV online video."""
    ie = ITVIE()
    vid_id = ie.extract('https://www.itv.com/hub/liar/2a4547a0012')
    assert vid_id is not None
    assert vid_id['id'] == '2a4547a0012'
    assert re.match(r'Liar - Series 2 - Episode 6$', vid_id['title']) is not None
    assert re.match(r'A shocked Laura is torn between the truth and protecting Andrew\. Meanwhile, ...', vid_id['description']) is not None
    assert vid_id['duration'] == 2994

# Generated at 2022-06-24 12:44:47.219692
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    q = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert 'BTCC 2018: All the action from Brands Hatch' == q.playlist_result(q._entries, q._playlist_id, q._title)
    assert q.BRIGHTCOVE_URL_TEMPLATE == q._BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:44:47.875717
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:44:57.972532
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    expected_IE_id = 'itv'
    expected_title = 'Liar - Series 2 - Episode 6'
    expected_description = 'md5:d0f91536569dec79ea184f0a44cca089'
    expected_series = 'Liar'
    expected_season_number = 2
    expected_episode_number = 6
    expected_subtitles = {
        'en': [{
            'ext': 'vtt',
            'url': 'https://content.video.itv.com/subtitles/2a4547a0012/en/outband/webvtt/subs.vtt',
        }],
    }
    expected_duration = 2921

    ITVTest

# Generated at 2022-06-24 12:45:05.390787
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc = ITVBTCCIE()
    btcc.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    # assert that the URL_TEMPLATE variable is correctly set
    assert btcc.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:07.768787
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:45:11.076663
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    match = itvie._VALID_URL.match(url)
    assert match
    assert match.group('id') == '2a4547a0012'

# Generated at 2022-06-24 12:45:15.407838
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    actual = ITVBTCCIE._build_brighcove_url('8578513939001')
    expected = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=8578513939001'
    assert actual == expected

# Generated at 2022-06-24 12:45:17.221030
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:45:25.754310
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itvbtccie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    assert itvbtccie.BRIGHTCOVE

# Generated at 2022-06-24 12:45:31.318847
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie._match_id(url) == playlist_id

# Generated at 2022-06-24 12:45:32.271188
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-24 12:45:35.482569
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_url = 'http://www.itv.com/hub/liar/2a4547a0012'
    x = ITVIE(video_url)
    assert x.video_id == '2a4547a0012'

# Generated at 2022-06-24 12:45:39.219359
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Test constructor of class ITVIE.
    """
    canary = ITVIE()
    assert canary.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:46.461015
# Unit test for constructor of class ITVIE
def test_ITVIE():
    t = ITVIE()
    assert(t._match_id('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012')
    assert(t._match_id('https://www.itv.com/hub/through-the-keyhole/2a2271a0033') == '2a2271a0033')


# Generated at 2022-06-24 12:45:47.463518
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE(): ITVIE(ITVBTCCIE)

# Generated at 2022-06-24 12:45:52.334884
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    vec = itv.extract(url)
    print(vec)
    assert(vec['id'] == '2a4547a0012')
    assert(vec['title'] == 'Liar - Series 2 - Episode 6')
    assert(vec['description'] == 'md5:d0f91536569dec79ea184f0a44cca089')
    assert(vec['series'] == 'Liar')
    assert(vec['season_number'] == 2)
    assert(vec['episode_number'] == 6)

# Generated at 2022-06-24 12:45:55.972152
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('2a4547a0012')._data_playlist_url == '2a4547a0012'
    assert ITVIE('http://www.itv.com/hub/liar/2a4547a0012')._data_playlist_url == '2a4547a0012'

# Generated at 2022-06-24 12:45:56.480433
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:45:57.247452
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(None)

# Generated at 2022-06-24 12:45:59.682961
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert url is not None


# Generated at 2022-06-24 12:46:02.301205
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._constructor_test(
        ITVIE._VALID_URL,
        ITVIE._TESTS[0],
    )

# Generated at 2022-06-24 12:46:04.624269
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None).to_screen('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:46:05.200541
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()

# Generated at 2022-06-24 12:46:06.352727
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    pass

# Generated at 2022-06-24 12:46:08.439122
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test ITVBTCCIE"""
    ITVBTCCIE()._real_extract(ITVBTCCIE._TEST['url'], '')

# Generated at 2022-06-24 12:46:09.364892
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE({}, {})

# Generated at 2022-06-24 12:46:11.245876
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Assert that the constructor of ITVBTCCIE is not None
    assert ITVBTCCIE() is not None, "An ITVBTCCIE was created!"

# Generated at 2022-06-24 12:46:14.275553
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    r = ITVBTCCIE({}).suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert r is True

# Generated at 2022-06-24 12:46:19.118270
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    youtube = ITVBTCCIE()
    # Test YouTubeBTCCIE constructor
    assert youtube.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

    # Test YouTubeBTCCIE constructor

    # Test YouTubeBTCCIE constructor

# Generated at 2022-06-24 12:46:19.684507
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:46:28.988088
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Test for constructor of ITVBTCCIE
    """
    # test for ITVBTCCIE._real_extract
    ITVExtractor = ITVBTCCIE()
    ITVExtractor._real_extract('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    ITVExtractor._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    # test for ITVBTCCIE._match_id
    ITVExtractor._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    ITVExtractor._match

# Generated at 2022-06-24 12:46:34.547955
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url_test = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    result = ITVBTCCIE._real_extract(ITVBTCCIE(), url_test)
    assert playlist_id == result['id']

# Generated at 2022-06-24 12:46:35.962586
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv is not None

# Generated at 2022-06-24 12:46:42.705422
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv.suitable('https://www.itv.com/hub/liar/2a4547a0012')
    assert itv.suitable('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    assert itv.suitable('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    assert itv.suitable('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')


# Generated at 2022-06-24 12:46:44.949858
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print('%s %s %s' % (ITVIE._VALID_URL, ITVIE._GEO_COUNTRIES, ITVIE._TESTS))


# Generated at 2022-06-24 12:46:46.366386
# Unit test for constructor of class ITVIE
def test_ITVIE():
    a = ITVIE()
    print(a.BRIGHTCOVE_URL_TEMPLATE)


# Generated at 2022-06-24 12:46:48.091022
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print(ITVIE.__name__)
    print(ITVIE.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-24 12:46:48.812446
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:46:59.485138
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"

    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/3a9e9e17-ea71-4239-898d-e8510a29c551/HkiHLnNRx_default/index.html?videoId=%s'
    result = ITVBTCCIE()._real_extract(url)
    assert(result['id'] == 'btcc-2018-all-the-action-from-brands-hatch')
    assert(result['title'] == 'BTCC 2018: All the action from Brands Hatch')



# Generated at 2022-06-24 12:47:01.648545
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE_test = ITVIE()
    assert ITVIE_test != None

# Generated at 2022-06-24 12:47:11.597102
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    s = ITVBTCCIE(ITVIE(), 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert (s.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')