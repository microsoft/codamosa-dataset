

# Generated at 2022-06-24 12:37:05.060877
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL
    assert ITVIE()._TESTS == ITVIE._TESTS

# Generated at 2022-06-24 12:37:08.210962
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:37:13.114213
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_obj = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert test_obj.url == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert test_obj.video_id == '2a4547a0012'
    assert test_obj.BRIGHT_URL == test_obj.url


# Generated at 2022-06-24 12:37:16.994592
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:18.925667
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .itv import ITVIE
    url = 'http://www.itv.com/hub/midsomer-murders/2a508a6026'
    ITVIE(url)

# Generated at 2022-06-24 12:37:20.044374
# Unit test for constructor of class ITVIE
def test_ITVIE():
    return ITVIE()._parse_json([], '', fatal=True)


# Generated at 2022-06-24 12:37:21.543372
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test constructor of class ITVIE
    # ensure that ITVIE has been imported.
    ITVIE

# Generated at 2022-06-24 12:37:29.704833
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVExtractor = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVExtractor._download_webpage = lambda self, url, playlist_id: url
    ITVExtractor._og_search_title = lambda self, webpage, fatal: webpage
    assert (ITVExtractor._real_extract(ITVExtractor, url)['entries'][0]) == (
        ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '5766736890001')

# Generated at 2022-06-24 12:37:33.816553
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE()
    assert info.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-24 12:37:35.795962
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import doctest
    print("test ITVBTCCIE()")
    doctest.testmod()

# Generated at 2022-06-24 12:37:38.439020
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:37:39.000679
# Unit test for constructor of class ITVIE
def test_ITVIE():
    t = ITVIE()

# Generated at 2022-06-24 12:37:46.005481
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    title = 'Liar - Series 2 - Episode 6'
    description = 'md5:d0f91536569dec79ea184f0a44cca089'
    series = 'Liar'
    season_number = 2
    episode_number = 6
    content_url = 'https://api.itv.com/hub/itvplayer/asset/2a4547a0012'
    content_id = '2a4547a0012'
    content_type = 'urn:vod:video'
    content_name = 'Liar - Series 2 - Episode 6'
    content_title = 'Liar - Series 2 - Episode 6'

# Generated at 2022-06-24 12:37:48.067201
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:37:58.440889
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert not re.match(ITVBTCCIE._VALID_URL, 'https://www.itv.com/btcc') is None
    assert re.match(ITVBTCCIE._VALID_URL, 'https://www.itv.com/btcc') is not None
    # regexp is from regexp_valid_url in extractor.py
    assert re.match(r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') is not None

# Generated at 2022-06-24 12:38:02.250174
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-24 12:38:06.662812
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._build_brighcove_url("1") == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=1' # noqa


# Generated at 2022-06-24 12:38:07.910264
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")


# Generated at 2022-06-24 12:38:11.777217
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    iTVBTCCIE = ITVBTCCIE()
    assert iTVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:38:16.259667
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE._build_url_result(
        "https://www.itv.com/hub/liar/2a4547a0012", "2a4547a0012",
        "https://www.itv.com/hub/liar/2a4547a0012").result
    assert info['id'] == "2a4547a0012"
    assert info['url'] == "https://www.itv.com/hub/liar/2a4547a0012"


# Generated at 2022-06-24 12:38:20.722852
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "http://www.itv.com/hub/liar/2a4547a0012"
    ITVIE(ITVIE._downloader)._real_initialize()
    ITVIE(ITVIE._downloader)._real_extract(url)

# Generated at 2022-06-24 12:38:25.490904
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Creating an object of class ITVBTCCIE
    obj = ITVBTCCIE()

    # Testing constructor of class ITVBTCCIE
    # Creating an object of class ITVIE
    assert type(obj) == ITVBTCCIE

    # Testing whether obj holds a reference to ITVIE
    assert ITVIE == obj._parent_class

# Generated at 2022-06-24 12:38:26.110683
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE("")

# Generated at 2022-06-24 12:38:34.453049
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert obj._GEO_COUNTRIES == ['GB']
    assert obj._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:38:35.981347
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE()
    instance.constructor(instance._TESTS[0]['url'])

# Generated at 2022-06-24 12:38:38.271085
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccIE = ITVBTCCIE()
    assert itvbtccIE._TEST['url'] == itvbtccIE._VALID_URL

# Generated at 2022-06-24 12:38:46.078554
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'

    entry = ITVBTCCIE._build_brigthcove_url(url, playlist_id)
    assert entry['ie_key'] == 'BrightcoveNew'
    assert 'referrer' in entry['url']
    assert entry['video_id'] == '5869345827001'

    webpage = entry['_webpage']
    assert webpage == ITVBTCCIE._download_webpage(url, playlist_id)


# Generated at 2022-06-24 12:38:51.935298
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        result = ITVBTCCIE().result()
    except ImportError:
        # BrightcoveNewIE is not available for testing -> skip
        pass
    else:
        assert result.get('_type', 'unknown') == 'playlist'
        assert result.get('id', 'unknown') == 'btcc-2018-all-the-action-from-brands-hatch'
        assert len(result.get('entries', [])) == 9

# Generated at 2022-06-24 12:39:00.419768
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # While testing ITVIE, we can also test ITVBTCCIE, which is a subclass of ITVIE
    assert [2, 3] == [i for i in range(1, 4) if i % 2 == 0]  # a test to verify python is working
    for xtest in ITVIE._TESTS + ITVBTCCIE._TEST:
        url = xtest['url']
        if url.find('itv.com/hub/') > -1:
            itvie = ITVIE(None)
            # Test the constructor
            assert(itvie._match_id(url))
            webpage = itvie._download_webpage(url, video_id=itvie._match_id(url))

# Generated at 2022-06-24 12:39:04.265596
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:05.943769
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    actual = ITVBTCCIE.__name__ == 'ITVBTCCIE'
    expected = True
    assert actual == expected

# Generated at 2022-06-24 12:39:11.694617
# Unit test for constructor of class ITVIE
def test_ITVIE():
    b = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    assert b.url == "http://www.itv.com/hub/liar/2a4547a0012"
    assert b.title == "Liar"
    assert b.ext == "mp4"
    assert b.params == {'skip_download': True}

# Generated at 2022-06-24 12:39:13.220363
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'itv:itv'

# Generated at 2022-06-24 12:39:23.700927
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_case = {
        'url': 'https://www.itv.com/hub/liar/2a4547a0012',
        'info_dict': {
            'id': '2a4547a0012',
            'ext': 'mp4',
            'title': 'Liar - Series 2 - Episode 6',
            'description': 'md5:d0f91536569dec79ea184f0a44cca089',
            'series': 'Liar',
            'season_number': 2,
            'episode_number': 6,
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }
    class_itv_ie = ITVIE()

# Generated at 2022-06-24 12:39:28.557836
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE, 'BRIGHTCOVE_URL_TEMPLATE attribute should not be None'

# Generated at 2022-06-24 12:39:29.671799
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE is not None


# Generated at 2022-06-24 12:39:33.711250
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    _ = ITVBTCCIE(ITVBTCCIE._downloader, url).extract()

# Generated at 2022-06-24 12:39:36.064855
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL(
        'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:39:46.232107
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Assert that the constructor of class ITVBTCCIE hasn't changed
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

    # Check if ITVBTCCIE has been updated after values of the constructor were changed

# Generated at 2022-06-24 12:39:57.268226
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import tempfile
    import unittest

    _TEST = {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

    class TestITVBTCCIE(unittest.TestCase):
        def setUp(self):
            self.ie = ITVBTCCIE()


# Generated at 2022-06-24 12:40:03.078230
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE(None)
    assert obj._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert obj._TEST == {'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'info_dict': {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}, 'playlist_mincount': 9}

# Generated at 2022-06-24 12:40:08.671717
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    class MockClass(object):
        def __init__(self):
            self.url = url
    obj = ITVIE()
    assert obj._match_id(MockClass()) == '2a4547a0012'


# Generated at 2022-06-24 12:40:18.476102
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    dummmy_url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:40:20.054350
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_object = ITVIE()
    assert isinstance(test_object, ITVIE)

# Generated at 2022-06-24 12:40:20.938302
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'ITV'

# Generated at 2022-06-24 12:40:22.959837
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')._VALID_URL is True

# Generated at 2022-06-24 12:40:30.500325
# Unit test for constructor of class ITVIE
def test_ITVIE():
    sample_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    sample_url2 = 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033'
    sample_url3 = 'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024'
    sample_url4 = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    # Test for _VALID_URL
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-24 12:40:31.356831
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Constructor will fail if ITVIE._VALID_URL is not a compilable regexp
    ITVIE()

# Generated at 2022-06-24 12:40:36.556117
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert hasattr(ITVBTCCIE, '_VALID_URL')
    assert hasattr(ITVBTCCIE, '_TEST')
    assert hasattr(ITVBTCCIE, 'BRIGHTCOVE_URL_TEMPLATE')
    assert hasattr(ITVBTCCIE, '_real_extract')
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:40:37.229541
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:40:47.500444
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    iTVBTCCIE = ITVBTCCIE('ITVBTCCIE', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert iTVBTCCIE.ie_key() == 'BrightcoveNew'
    assert iTVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert iTVBTCCIE._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:40:49.532000
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TESTS[0]['url'] == ITVBTCCIE(ITVIE())._TESTS[0]['url']


# Generated at 2022-06-24 12:40:52.805857
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:40:59.993586
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    c = ITVBTCCIE()
    assert c.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert c.geo_blocked() == True
    assert c.geo_verification_headers() == {
        'X-Forwarded-For': '193.113.0.0', # One of the acceptable blocks
    }

# Generated at 2022-06-24 12:41:04.453357
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test constructor of class line ITVBTCCIE"""

    assert isinstance(ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'), ITVBTCCIE)

# Generated at 2022-06-24 12:41:10.414994
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = ITVBTCCIE._TEST['url']
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._match_id(test_url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert itvbtccie.IE_NAME in ITVBTCCIE.ie_key()

# Generated at 2022-06-24 12:41:21.589128
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        import json
        import os.path
        import urllib

        from pycaption import (
            SAMIReader,
            WebVTTReader
        )
    except:
        print('Warning. Cannot import json or pycaption or urllib or os.path.')

    test_data_file = 'test_data/test_data.json'
    youtube_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    geo_restricted_url = 'http://www.itv.com/hub/the-voice/2a5463aa5071'
    geo_restricted_data = json.load(open(test_data_file, 'r'))

# Generated at 2022-06-24 12:41:27.646555
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie._VALID_URL == ITVBTCCIE._VALID_URL
    assert ie._TEST == ITVBTCCIE._TEST
    assert ie._match_url(url).group() == ie._match_id(url)
    assert ie._match_url(url) == ie._match_id(url)

# Generated at 2022-06-24 12:41:37.418415
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = ITVBTCCIE._VALID_URL % 'btcc-2018-all-the-action-from-brands-hatch'
    expected = {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'BTCC 2018: All the action from Brands Hatch',
        '_type': 'playlist',
    }
    assert ITVBTCCIE._TEST['info_dict'] == expected
    assert ITVBTCCIE._TEST['info_dict'] == ITVBTCCIE._real_extract(ITVBTCCIE._VALID_URL % 'btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:41:38.286482
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    a = ITVBTCCIE()
    assert a

# Generated at 2022-06-24 12:41:40.205047
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-24 12:41:42.895593
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:44.911762
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert isinstance(instance, ITVBTCCIE)

# Generated at 2022-06-24 12:41:49.491101
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/benidorm/2a4548a0036'
    ie = ITVIE()
    obj = ie.suitable(url)
    assert obj is not False
    assert obj.__name__ == ie.__class__.__name__
    assert ie._TESTS[0]['info_dict'] == ie._real_extract(url)

# Generated at 2022-06-24 12:41:52.545373
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test for initializing ITVIE
    assert ITVIE(_FAKE_TEST_RESPONSE, _FAKE_TEST_URL, _FAKE_TEST_CONTENT)



# Generated at 2022-06-24 12:42:00.526360
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_obj = ITVIE('test')
    assert test_obj._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert test_obj._GEO_COUNTRIES == ['GB']
    assert len(test_obj._TESTS) == 4
    assert test_obj._download_webpage('https://www.itv.com/hub/liar/2a4547a0012', '2a4547a0012')
    assert test_obj._match_id('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'

# Generated at 2022-06-24 12:42:04.199127
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Test the constructor of class ITVBTCCIE
    """
    url = 'http://www.itv.com/btcc/races/all-the-action-from-brands-hatch'
    instance = ITVBTCCIE()
    match_id = instance._match_id(url)
    assert match_id == 'all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:42:10.956394
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'

    webpage = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'


# Generated at 2022-06-24 12:42:11.373477
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:42:16.127741
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    expected_title = "BTCC 2018: All the action from Brands Hatch"
    ie = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert ie.title == expected_title



# Generated at 2022-06-24 12:42:24.178568
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccie = ITVBTCCIE()

    # Test for non-regex URL
    assert itvbtccie._VALID_URL == ITVBTCCIE._VALID_URL

    # Test for regex matching
    assert re.match(ITVBTCCIE._VALID_URL, url)

    # The _match_id() should return the playlist ID
    assert itvbtccie._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'



# Generated at 2022-06-24 12:42:25.155792
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()

# Generated at 2022-06-24 12:42:30.395155
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # when
    itv = ITVIE()
    # then
    assert itv._GEO_COUNTRIES == ['GB']
    assert itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-24 12:42:32.604253
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # test that constructor creates expected object
    test_ITVIE = ITVIE('')
    assert type(test_ITVIE) is ITVIE


# Generated at 2022-06-24 12:42:38.766456
# Unit test for constructor of class ITVIE
def test_ITVIE():
    if __name__ == '__main__':
        ITVExtractor = ITVIE()
        ITVExtractor._download_webpage = lambda url, video_id: open('test.html').read()
        ITVExtractor._download_json = lambda url, video_id, data={}, headers={}: open('test.json').read()
        ITVExtractor._search_regex = lambda pattern, string, name, default=NO_DEFAULT, group='', flags=0: re.search(pattern, string, flags=flags).group(group)

# Generated at 2022-06-24 12:42:49.163822
# Unit test for constructor of class ITVIE
def test_ITVIE():
    infoExtractor = ITVIE()
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    infoExtractor._download_webpage = mock.Mock(return_value="")
    infoExtractor.geo_verification_headers = mock.Mock(return_value="")
    infoExtractor._download_json = mock.Mock(return_value="")
    infoExtractor._search_regex = mock.Mock(return_value="")
    infoExtractor._html_search_meta = mock.Mock(return_value="")

    infoExtractor._real_extract(url)
    assert infoExtractor._download_webpage.call_count == 1
    assert infoExtractor.geo_verification_headers.call_count == 1
    assert infoExtractor

# Generated at 2022-06-24 12:42:54.154475
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    webpage = 'http://www.itv.com/news/2016-11-22/its-fighting-fit-fog-but-what-is-it/'
    ie = ITVBTCCIE(ITVBTCCIE._create_get_video_info_extractor(webpage))
    assert ie.get_video_info() is None

# Generated at 2022-06-24 12:42:55.950371
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE(None, None)
    assert ie is not None


# Generated at 2022-06-24 12:42:58.871199
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE(None)._real_extract("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    except:
        assert False

# Generated at 2022-06-24 12:43:01.966234
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test the constructor of class ITVBTCCIE."""
    demo = ITVBTCCIE()
    assert demo._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:43:06.508421
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvBTCCIE = ITVBTCCIE()
    assert itvBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:12.435542
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_video = 'https://www.itv.com/hub/lorraine/2a4488a3001'

    # The assert statement below will be True if there is an error during
    # construction, which means that it fails to extract the video.
    # The following error is expected if the constructor is successful:
    # AssertionError: dict expected, not NoneType
    assert ITVIE().extract_info(test_video, None) is not None

# Generated at 2022-06-24 12:43:16.019750
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE()
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:16.676887
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE()
    assert not obj is None

# Generated at 2022-06-24 12:43:19.282438
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")


# Generated at 2022-06-24 12:43:24.293816
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Test ITVIE constructor
    """
    assert ITVIE._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE._TESTS[0]['info_dict']['id'] == '2a4547a0012'

# Generated at 2022-06-24 12:43:25.278523
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:43:27.985511
# Unit test for constructor of class ITVIE
def test_ITVIE():
    b = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    b.test()

test_ITVIE()

# Generated at 2022-06-24 12:43:36.186581
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    This test is to test the constructor of the class ITVIE
    """
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    id = '2a4547a0012'
    extractor = ITVIE
    expected_id = id
    expected_url = url
    expected_title = 'Liar - Series 2 - Episode 6'
    expected_description = 'md5:d0f91536569dec79ea184f0a44cca089'
    expected_series = 'Liar'
    expected_season_number = 2
    expected_episode_number = 6
    test_ITVIE = extractor(test_ITVIE)
    test_ITVIE._download_webpage = lambda url: 'webpage'
    test_ITVIE._search_re

# Generated at 2022-06-24 12:43:38.389261
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert isinstance(instance, ITVBTCCIE)

# Generated at 2022-06-24 12:43:45.703802
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'
    url = 'https://www.itv.com/hub/liar/' + video_id
    video = ITVIE().url_result(url)
    assert video.video_id == video_id
    assert video.title == 'Liar - Series 2 - Episode 6'
    assert video.description == 'md5:d0f91536569dec79ea184f0a44cca089'
    assert video.series == 'Liar'
    assert video.season_number == 2
    assert video.episode_number == 6

# Generated at 2022-06-24 12:43:48.876942
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-24 12:43:52.532482
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
        Test constructor of class ITVBTCCIE
    """

    itvbtccie = ITVBTCCIE()

    # test for default value
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:55.475819
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)._build_brightcove_url('1234', 'http://www.itv.com/hub/liar/2a4547a0012')
    return


# Generated at 2022-06-24 12:44:04.767265
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    # Testing with a valid URL
    result = ie.extract('https://www.itv.com/hub/liar/2a4547a0012')
    assert result['id'] == '2a4547a0012'
    assert result['title'] == 'Liar - Series 2 - Episode 6'
    assert result['description'] == 'Laura Nielson suspects there may be more to Andrew Earlham’s disappearance than meets the eye. Laura’s brother Tom is confronted over the car accident, and Andrew’s killer plans are almost complete.'
    assert result['series'] == 'Liar'
    # Testing with a URL which is unavailable for streaming
    result = ie.extract('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')

# Generated at 2022-06-24 12:44:05.604591
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-24 12:44:15.514137
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:44:16.298895
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()

# Generated at 2022-06-24 12:44:26.581252
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # test brightcove link
    _, youtube_url = ITVIE._extract_brightcove_url(
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5464951450001')
    assert youtube_url == 'https://www.youtube.com/watch?v=_WmR8TlTcT0'

    # test json_ld
    webpage = '{"@type":"BreadcrumbList",' \
              '"itemListElement":[{"@type":"ListItem","item":{"@type":"TVEpisode",' \
              '"name":"Episode 4","@context":"http://schema.org"}}]}'
    json_ld = ITVIE._parse_json(webpage, None)

# Generated at 2022-06-24 12:44:29.375294
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    instance = ITVIE()
    instance._match_id(url)
    instance._download_webpage(url, "2a4547a0012")

# Generated at 2022-06-24 12:44:39.176873
# Unit test for constructor of class ITVIE

# Generated at 2022-06-24 12:44:41.985238
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE(url)

# Generated at 2022-06-24 12:44:42.896369
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE().IE_NAME == 'itv'

# Generated at 2022-06-24 12:44:45.134862
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None)._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:44:51.017002
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE()
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert "geo_ip_blocks" in itv.BRIGHTCOVE_URL_TEMPLATE
    assert "referrer" in itv.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:44:53.891423
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvIE = ITVIE()
    print ("itvIE object of ITVIE in itv.py is constructed")
    print ("itvIE = ", itvIE)

# Generated at 2022-06-24 12:44:56.894191
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVE = ITVIE()
    ITVE.geo_verification_headers()
    ITVE.geo_bypass_country()

# Generated at 2022-06-24 12:45:06.859392
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from . import extraction_executor
    from .extractor.common import _TEST_URL
    from ..utils import str_to_int
    i = ITVIE()
    i._download_webpage = lambda *args, **kwargs: _TEST_URL
    i._search_regex = lambda *args: r'<script type="application/ld\+json">\s*{(.*?)}\s*</script>'
    i._json_ld = lambda x, y, z: json.loads(x)
    i._search_json_ld = lambda *args: json.loads(r'{}')
    i.extract(r'https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:45:17.273612
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    # Passing a string to constructor
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    # Passing a function to constructor
    ie = ITVBTCCIE(lambda: 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:22.597390
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:45:33.142699
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    btcc = ITVBTCCIE()
    btcc.url = url
    webpage = btcc._download_webpage(url, "test")
    video_ids = re.findall(r'data-video-id=["\'](\d+)', webpage)
    count = 0
    for video_id in video_ids:
        count += 1
        test_url = "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s" % video_id
        # Test BTCC Brightcove New

# Generated at 2022-06-24 12:45:34.202045
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie

# Generated at 2022-06-24 12:45:37.670239
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # this will test that the argument of the class ITVIE, which is the URL, is valid
    ie = ITVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:45:39.610837
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    #from pprint import pprint
    #print(pprint(ie._JSON_LD_RE))

# Generated at 2022-06-24 12:45:50.620600
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    def test_constructor(self, url, expected_playlist_id, expected_playlist_count):
        playlist_id, playlist_count = ITVBTCCIE._extract_playlist_id(url)
        assert playlist_id == expected_playlist_id, \
            'Expected playlist id is "%s", actually got "%s"' % (expected_playlist_id, playlist_id)
        assert expected_playlist_count == playlist_count, \
            'Expected playlist_id count is %d, actually got %d' % (
                expected_playlist_count, playlist_count)
    # Normal page
    test_constructor(None, 'btcc-2018-all-the-action-from-brands-hatch', 9)

# Generated at 2022-06-24 12:45:54.093783
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    except Exception as e:
        print(e)

# Generated at 2022-06-24 12:45:55.356197
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert(isinstance(ie, ITVBTCCIE))

# Generated at 2022-06-24 12:46:00.394472
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

    expected = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s' % '5802592034001'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == expected

# Generated at 2022-06-24 12:46:03.213340
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE(None)
    assert isinstance(ie, BrightcoveNewIE)
    assert isinstance(ie, ITVIE)



# Generated at 2022-06-24 12:46:12.447852
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE(ITVBTCCIE._downloader)
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')
    assert(ie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)')
    assert(ie._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:46:21.073435
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ie._TESTS[0]['info_dict']['id'] == '2a4547a0012'
    assert ie._TESTS[0]['info_dict']['title'] == 'Liar - Series 2 - Episode 6'
    assert ie._TESTS[0]['params']['skip_download'] == True

# Generated at 2022-06-24 12:46:29.277147
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # test for the old way
    data = '<div class="media-player__video" data-video-id="5416300814001"></div>'
    assert r'result(entries, playlist_id, title)' == ITVBTCCIE()._real_extract(test_ITVBTCCIE.__name__, data)
    # test for the new way
    data = '<div class="media-player__video" data-video-id="5416300814001" data-adverts-enabled="true"></div>'
    assert r'result(entries, playlist_id, title)' == ITVBTCCIE()._real_extract(test_ITVBTCCIE.__name__, data)

# Generated at 2022-06-24 12:46:32.967691
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    c = ITVBTCCIE()
    assert c.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:46:39.418378
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Example url with common content
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    video = ie.extract(url)
    assert video['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert video['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert len(video['entries']) == 9

# Generated at 2022-06-24 12:46:41.275485
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034")

# Generated at 2022-06-24 12:46:42.134207
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(ITVExtractor.InfoExtractor)

# Generated at 2022-06-24 12:46:43.383535
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE(None)
    assert isinstance(instance, ITVIE)

# Generated at 2022-06-24 12:46:44.947382
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	instance = ITVBTCCIE()
	assert isinstance(instance, ITVBTCCIE)


# Generated at 2022-06-24 12:46:47.897113
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    match = ITVIE._VALID_URL.match(url)
    assert ITVIE(match)._TITLE == 'Liar - Series 2 - Episode 6'

# Generated at 2022-06-24 12:46:59.062600
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    unit = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    assert unit._match_id(url) == playlist_id
    assert unit._match_id('https://www.itv.com/btcc/interviews-archive/robtc-interview-with-tom-ingram-after-his-race-three-win') == 'robtc-interview-with-tom-ingram-after-his-race-three-win'

# Generated at 2022-06-24 12:47:03.889584
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVExtractor = ITVIE()
    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVExtractor._match_id(test_url) == "2a4547a0012"
