

# Generated at 2022-06-24 12:37:09.863298
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE('www.itv.com/hub/liar/2a4547a0012')
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ie._TESTS[0]['params']['skip_download'] 


# Generated at 2022-06-24 12:37:11.835093
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVIE()).NUM_CONTAINERS

# Generated at 2022-06-24 12:37:15.102663
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Testing constructor of ITVIE()
    video = ITVIE()
    assert video.IE_NAME == 'itv'
    assert video.IE_DESC == "ITV Player"
    assert video.GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:37:16.488655
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.constructor()._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:37:23.959066
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_provider = ITVBTCCIE()
    assert info_provider._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert info_provider._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    assert info_provider.BRIGHTCOVE_URL_T

# Generated at 2022-06-24 12:37:24.561585
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:37:29.232999
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    result = ie._real_extract(url)
    assert result == ITVBTCCIE._TEST

# Generated at 2022-06-24 12:37:29.995495
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:37:31.899862
# Unit test for constructor of class ITVIE
def test_ITVIE():
    unit_test = ITVIE()
    print(unit_test)

# Generated at 2022-06-24 12:37:35.272734
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    e = ie.extract(url)
    return e

# Generated at 2022-06-24 12:37:36.916283
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE(ITVExtractor.IE_NAME)
    assert isinstance(test, ITVIE)

# Generated at 2022-06-24 12:37:44.194258
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkixzKG8x_default/index.html?videoId=%s'

    expected = ITVBTCCIE(ITVBTCCIE.IE_NAME, False).extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

    assert 'playlist' == expected.get('_type')
    assert 'BTCC 2018: All the action from Brands Hatch' == expected.get('title')
    assert 9 == len(expected.get('entries'))

# Generated at 2022-06-24 12:37:50.866837
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None).assert_jsonld_matches_dict({
        'description': 'd0f91536569dec79ea184f0a44cca089',
        'id': '2a4547a0012',
        'episodeNumber': 6,
        'series': 'Liar',
        'seasonNumber': 2,
        '@context': 'http://schema.org',
        '@type': 'TVEpisode',
    })

# Generated at 2022-06-24 12:37:53.406180
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    it = ITVIE()
    it.suitable(test_url)
    it.extract(test_url)

# Generated at 2022-06-24 12:37:57.349305
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    tester = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:38:00.858234
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.ie_key() == 'ITV'
    assert ie.up() is False
    assert ie.working() is False



# Generated at 2022-06-24 12:38:05.541009
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    constructor = ITVBTCCIE.get_IE(url)
    obj = constructor(url)
    assert obj.__class__ == ITVBTCCIE

# Generated at 2022-06-24 12:38:10.524903
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    test class ITVBTCCIE
    """
    itvBTCCIE = ITVBTCCIE("https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert itvBTCCIE.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"
    assert itvBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:38:15.587878
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    _test_class_name = 'ITVBTCCIE'
    _test_url = 'http://www.itv.com/btcc/races/btcc-2017-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:38:17.198149
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert isinstance(ie, ITVIE)



# Generated at 2022-06-24 12:38:17.911349
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:38:19.827284
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class ITVBTCCIE_test(ITVBTCCIE):
        def _download_webpage(self, *args, **kwargs):
            raise NotImplementedError('this is a unit test')
    return ITVBTCCIE_test()

# Generated at 2022-06-24 12:38:29.584020
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_data = {
        "url": "https://www.itv.com/hub/liar/2a4547a0012",
        "info_dict": {
            "id": "2a4547a0012",
            "ext": "mp4",
            "title": "Liar - Series 2 - Episode 6",
            "description": "md5:d0f91536569dec79ea184f0a44cca089",
            "series": "Liar",
            "season_number": 2,
            "episode_number": 6,
        },
        "params": {
            # m3u8 download
            "skip_download": True,
        },
    }
    ITVIE()._test_extract_videos(test_data)

# Generated at 2022-06-24 12:38:32.880874
# Unit test for constructor of class ITVIE
def test_ITVIE():
    constructor = str(ITVIE)
    re.search(
        r'^<class ITVIE at 0x[0-9A-F]{14}>$',
        constructor)



# Generated at 2022-06-24 12:38:37.719677
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IT = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert IT.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:38:43.897818
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    a = ITVBTCCIE(ITVBTCCIE._downloader)
    a.url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    a.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"
    a._real_extract(a.url)

# Generated at 2022-06-24 12:38:48.532140
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info = ITVBTCCIE()._real_extract(
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    videos = info['entries']
    assert len(videos) == 9
    assert 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5780971266001' in videos[0]['url']

# Generated at 2022-06-24 12:38:52.982089
# Unit test for constructor of class ITVIE
def test_ITVIE():
    my_ITVIE = ITVIE()
    import datetime
    my_ITVIE.download(url='https://www.itv.com/hub/liar/2a4547a0012',
                      params={'skip_download':True},
                      date=datetime.datetime(2017, 10, 1))
    print(my_ITVIE)

# Generated at 2022-06-24 12:38:57.121904
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE(ITVIE())
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:38:59.986107
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:10.939536
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert instance._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:39:14.521211
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:19.710152
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # From: http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch
    expected_result = {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'BTCC 2018: All the action from Brands Hatch',
    }

    class TestITVBTCCIE(ITVBTCCIE):
        def _real_extract(self, url):
            return self.playlist_result(
                [],
                expected_result['id'],
                expected_result['title'])

    result = TestITVBTCCIE().extract(expected_result['id'])
    assert(result == expected_result)

# Generated at 2022-06-24 12:39:29.300120
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ITVBTCCIE._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:39:33.401145
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:43.254635
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert obj._VALID_URL == "https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)"
    assert obj._GEO_COUNTRIES == ["GB"]
    assert obj._TITLE_RE == "You need a modern browser to watch this video."

# Generated at 2022-06-24 12:39:45.031816
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(ITVBTCCIE._downloader)._real_extract(ITVBTCCIE._TEST['url'])

# Generated at 2022-06-24 12:39:49.814216
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = ITVBTCCIE()._TEST['url']
    test_out = ITVBTCCIE()._TEST
    test_out['info_dict']['url'] = test_out['_TEST']['url']
    test_out['info_dict']['playlist'] = [test_out['info_dict']['url']]
    item_to_check = ITVBTCCIE()._real_extract(url)
    for item in item_to_check:
        if isinstance(item, dict):
            assert item == test_out['info_dict']

# Generated at 2022-06-24 12:39:52.583129
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:39:55.006422
# Unit test for constructor of class ITVIE
def test_ITVIE():
	result = ITVIE().extract('https://www.itv.com/hub/liar/2a4547a0012')

	print(result)

# Generated at 2022-06-24 12:39:57.725666
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:39:59.532926
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['info_dict'] == ITVBTCCIE()._real_extract(ITVBTCCIE._TEST['url'])

# Generated at 2022-06-24 12:40:04.873074
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST == {'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'info_dict': {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}, 'playlist_mincount': 9}

# Generated at 2022-06-24 12:40:15.160280
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie_test = ITVBTCCIE(ITVBTCCIE._downloader, ITVBTCCIE._VALID_URL)

    expected_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5792573537001'
    expected_video_id = '5792573537001'
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

    assert itv_btcc_ie_test._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert itv_btcc_ie_test.BRIGHTCOVE_URL_TEMPL

# Generated at 2022-06-24 12:40:16.489523
# Unit test for constructor of class ITVIE
def test_ITVIE():
    InfoExtractor.test('ITVIE')


# Generated at 2022-06-24 12:40:18.485037
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Unit test for constructor of class ITVBTCCIE
    expected = ITVBTCCIE(ITVBTCCIE._downloader, ITVBTCCIE._VALID_URL)
    assert expected

# Generated at 2022-06-24 12:40:20.428310
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    User story
    test the constructor of class ITVIE
    """
    assert ITVIE(None)

# Generated at 2022-06-24 12:40:22.109890
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Unit test for constructor of class ITVBTCCIE
    """
    assert ITVBTCCIE

# Generated at 2022-06-24 12:40:23.048102
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()

# Generated at 2022-06-24 12:40:30.570173
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVE = ITVIE()

# Generated at 2022-06-24 12:40:35.859535
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccIE = ITVBTCCIE()
    assert itvbtccIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:40:40.446374
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_video_url = 'http://www.itv.com/hub/BTCC/2a8033a0041'
    downloader = InfoExtractor(ITVBTCCIE)
    test_IE = ITVBTCCIE(downloader, test_video_url)
    assert test_IE.name == ITVBTCCIE.ie_key()
    assert test_IE.btcc_url_template == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:40:45.564295
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        # To avoid depending on ITVBTCCIE, an extra try catch is added
        from . import ITVBTCCIE
        ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    except:
        pass

# Generated at 2022-06-24 12:40:47.195543
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-24 12:40:48.398829
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
   test = ITVBTCCIE()
   assert isinstance(test, ITVBTCCIE)

# Generated at 2022-06-24 12:40:48.912050
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:40:52.539583
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .common import InfoExtractor, IENoTestCase
    class ITVIENoTestCase(IENoTestCase):
        def __init__(self, *args, **kwargs):
            super(ITVIENoTestCase, self).__init__(*args, **kwargs)
            self.ie = ITVIE(InfoExtractor)
    return ITVIENoTestCase

# Generated at 2022-06-24 12:40:53.010339
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE({})

# Generated at 2022-06-24 12:40:55.578148
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert itv_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:40:59.611081
# Unit test for constructor of class ITVIE
def test_ITVIE():
    '''
    Unit test for constructor of class ITVIE
    '''    
    parser = ITVIE()

    assert(parser.brigthcove_url_template == parser.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-24 12:41:03.813617
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert(instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:41:14.128940
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # constructs an example object;
    # please be aware that the object URL and playlist_id are subject to change
    # if so, please update the URL and playlist_id below
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    example_obj = ITVBTCCIE(ITVBTCCIE._downloader, url)
    # tests whether example_obj is an instance of ITVBTCCIE
    assert isinstance(example_obj, ITVBTCCIE)
    # tests whether the instance example_obj is a subclass of InfoExtractor
    assert issubclass(ITVBTCCIE, InfoExtractor)
    # tests that _VAL

# Generated at 2022-06-24 12:41:18.518508
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE()
    assert test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:22.446086
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE('http://www.itv.com/itvplayer/video/', {})
    assert(itv.get_base_url() == 'http://www.itv.com/itvplayer/video/')
    assert(itv.get_video_id() == '')

# Generated at 2022-06-24 12:41:22.909865
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:41:26.936885
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-24 12:41:37.796163
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .. import ITVIE
    from urllib import parse
    """Test constructor of class ITVIE, in the case of an ITV video"""
    # video URL provided by user
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    # create instance of class ITVIE
    itvIE = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    # call function _real_extract()
    # test if parameters are constructed correctly
    assert itvIE._real_extract(url)
    # test if function _download_webpage() is called with correct arguments
    itvIE._download_webpage(url, '2a4547a0012')
    # test if function _download_json() is called with correct arguments
    it

# Generated at 2022-06-24 12:41:40.527166
# Unit test for constructor of class ITVIE
def test_ITVIE():
    global ITVIE
    ITVIE('https://www.itv.com/hub/luther/2a4329a0010')
    ITVIE('https://www.itv.com/hub/luther/2a4329a0010?autoplay=true')

# Generated at 2022-06-24 12:41:42.282399
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')



# Generated at 2022-06-24 12:41:47.960354
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    obj = ITVBTCCIE(ITVIE)
    assert obj._match_id(url) == playlist_id


# Generated at 2022-06-24 12:41:50.393545
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # just check that class can be instantiated
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:41:54.929621
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv.extract('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034') == None

# Generated at 2022-06-24 12:41:55.617139
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE().suite()

# Generated at 2022-06-24 12:41:56.677701
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Make sure that no exception is raised
    ITVBTCCIE()

# Generated at 2022-06-24 12:42:03.446397
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVIE('test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test')
    assert(x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:42:04.448759
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    #Constructor of class ITVBTCCIE should not throw any exceptions
    ITVBTCCIE()

# Generated at 2022-06-24 12:42:06.181132
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == ITVIE.__module__.split('.')[-1]

# Generated at 2022-06-24 12:42:07.448594
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()

# Generated at 2022-06-24 12:42:13.989518
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE(extract_info)
    info_dict = ie.extract(url)
    #print(info_dict)
    assert len(info_dict['entries']) == 9

# Generated at 2022-06-24 12:42:16.503122
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    c = ITVBTCCIE(None)
    assert c._VALID_URL == ITVBTCCIE._VALID_URL
    assert c.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:42:19.096640
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	assert ITVBTCCIE()._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:42:30.525151
# Unit test for constructor of class ITVIE
def test_ITVIE():
	ie = ITVIE()
	assert hasattr(ie, 'geo_verification_headers')
	assert hasattr(ie, '_call_api')
	assert hasattr(ie, '_extract_formats')
	assert hasattr(ie, '_extract_from_json')
	assert hasattr(ie, '_extract_from_playlist')
	assert hasattr(ie, '_extract_from_webpage')
	assert hasattr(ie, '_extract_json')
	assert hasattr(ie, '_extract_json_ld')
	assert hasattr(ie, '_extract_m3u8_formats')
	assert hasattr(ie, '_extract_playlist')
	assert hasattr(ie, '_login')

# Generated at 2022-06-24 12:42:31.569213
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:42:41.987588
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # First, test with a valid video page
    video_id = '2a2898a0024'
    url = 'https://www.itv.com/hub/whos-doing-the-dishes/' + video_id
    itv_ie = ITVIE()

    assert itv_ie._match_id(url) == video_id
    assert itv_ie._valid_url(url, video_id)

    assert itv_ie.IE_NAME == 'ITV'

    # Second, test with an invalid video page
    video_id = 'invalid'
    url = 'https://www.itv.com/hub/' + video_id
    itv_ie = ITVIE()

    assert itv_ie._match_id(url) == video_id
    assert not itv_ie._valid_

# Generated at 2022-06-24 12:42:43.739521
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info = ITVBTCCIE()
    assert info._type == 'url_transparent'



# Generated at 2022-06-24 12:42:48.999391
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:51.558878
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    obj = ITVIE()
    obj._real_extract(url)

# Generated at 2022-06-24 12:42:56.493213
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert isinstance(x, ITVBTCCIE)
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:57.877120
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE()._real_extract(url)

# Generated at 2022-06-24 12:43:03.585596
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE.url_result(smuggle_url(r'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5662100920001', {'geo_ip_blocks': ['193.113.0.0/16', '54.36.162.0/23', '159.65.16.0/21'], 'referrer': 'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'}), ie='BrightcoveNew', video_id='5662100920001')

# Generated at 2022-06-24 12:43:08.051900
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Arrange
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

    # Act
    ITVBTCCIE()

    # Assert
    assert ITVBTCCIE._VALID_URL == url

# Generated at 2022-06-24 12:43:08.666406
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:43:14.039505
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')._VALID_URL == \
           r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:43:19.157260
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Exercise the constructor of ITVBTCCIE.
    url = 'http://www.itv.com/news/london/update/2018-07-05/man-arrested-on-suspicion-of-murder-after-woman-83-found-dead-in-wembley/'
    # ITVBTCCIE should not be used for other ITV url except BTCC ones.
    assert ITVBTCCIE(ITVBTCCIE.IE_NAME, ITVBTCCIE._VALID_URL) is not None

# Generated at 2022-06-24 12:43:22.600153
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(ITVExtractor())._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/(?!player/)(?:[^/]+/)*[0-9a-zA-Z]+'


# Generated at 2022-06-24 12:43:26.332184
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert "ITVIE" == itv.ie_key()
    assert "itv" in itv.IE_DESC
# test end


# Generated at 2022-06-24 12:43:33.946318
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL[1:-1] != 'hub/'
    assert ITVIE._TESTS[1]['url'].endswith('/2a2271a0033')
    assert ITVIE._TESTS[2]['url'].endswith('/2a5159a0034')
    assert ITVIE._TESTS[3]['url'].endswith('/2a2898a0024')
    assert ITVIE._TESTS[3]['url'].endswith('/2a2898a0024')
    assert ITVIE._TESTS[0]['params'].keys() == ['skip_download']

# Generated at 2022-06-24 12:43:35.206450
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()



# Generated at 2022-06-24 12:43:38.433017
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # pylint: disable=star-args
    assert ITVBTCCIE(ITVBTCCIE.ie_key(), ITVBTCCIE._VALID_URL)._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:43:44.736151
# Unit test for constructor of class ITVIE
def test_ITVIE():
    if hasattr(ITVIE, '_download_webpage'):
        ITVIE._download_webpage = lambda *args: None
    if hasattr(ITVIE, '_download_json'):
        ITVIE._download_json = lambda *args: None
    if hasattr(ITVIE, '_json_ld'):
        ITVIE._json_ld = lambda *args: None
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL


# Generated at 2022-06-24 12:43:46.344358
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-24 12:43:49.468951
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    url = 'http://www.itv.com/hub/liar/2a4547a0012'

    assert info_extractor._match_id(url) == '2a4547a0012'


# Generated at 2022-06-24 12:43:54.973688
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_obj = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert test_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert test_obj.url == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert test_obj.playlist_id == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:43:57.340325
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .brightcove import BrightcoveNewIE
    assert ITVIE.constructor == ITVIE
    assert BrightcoveNewIE.constructor == ITVIE

# Generated at 2022-06-24 12:44:06.198649
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class MockITVBTCCIE(ITVBTCCIE):
        def _download_webpage(self, *args, **kwargs):
            return '<html> <body> <data data-video-id="123"></body></html>'

    class MockBrightcoveNewIE:
        IE_NAME = 'example'
        def __call__(self, *args, **kwargs):
            return 'BTCC item'


# Generated at 2022-06-24 12:44:09.490730
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert "itv.com" in itv._VALID_URL
    assert "itv.com" in itv._TESTS[0]['url']


# Generated at 2022-06-24 12:44:18.211564
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    test_url = 'https://www.itv.com/btcc/race1080p/'
    test_id = ''
    test_title = ''
    # Following is the Brightcove metadata for the test video

# Generated at 2022-06-24 12:44:28.970260
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import urllib
    from io import StringIO
    from http.server import BaseHTTPRequestHandler
    from http.server import HTTPServer
    import requests
    import urllib.parse
    
    YouTube = False
    ITVBTCC = True
    class HTTPRequestHandler2(BaseHTTPRequestHandler):

        def do_GET(self):
            if self.path.startswith('/btcc/'):
                with open('tests/playlist.txt') as f:
                    self.send_response(200)
                    self.send_header('Content-type', 'text/javascript')
                    self.end_headers()
                    self.wfile.write(f.read().encode('utf8'))
            else:
                with open('tests/test.mp4') as f:
                    self.send_response(200)
                    self

# Generated at 2022-06-24 12:44:38.875229
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:44:39.502985
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()

# Generated at 2022-06-24 12:44:40.502966
# Unit test for constructor of class ITVIE
def test_ITVIE():
    a = ITVIE()
    assert a

# Generated at 2022-06-24 12:44:47.821030
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	assert ITVBTCCIE._TEST == {
		'url' : 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
		'info_dict' : {
			'id' : 'btcc-2018-all-the-action-from-brands-hatch',
			'title' : 'BTCC 2018: All the action from Brands Hatch'
		},
		'playlist_mincount' : 9
	}

# Generated at 2022-06-24 12:44:49.543853
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert 'brightcove_new' in ie.ie_key()

# Generated at 2022-06-24 12:44:50.080780
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE

# Generated at 2022-06-24 12:44:54.345734
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE(None)
    assert x.BRIGHTCOVE_URL_TEMPLATE is \
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:44:55.651624
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # ITVBTCCIE()
    pass

# Generated at 2022-06-24 12:44:57.211064
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Use unittest to ensure ITVIE is a subclass of InfoExtractor.
    :return:
    """
    itv_ie = ITVIE()
    assert isinstance(itv_ie, InfoExtractor)

# Generated at 2022-06-24 12:45:01.257768
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE(InfoExtractor())

    assert ie._VALID_URL == ITVIE._VALID_URL
    assert ie._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert ie._TESTS == ITVIE._TESTS

# Generated at 2022-06-24 12:45:03.007745
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvIAE = ITVBTCCIE()
    assert itvIAE != None
    return itvIAE

# Generated at 2022-06-24 12:45:04.532274
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import unittest

    print('Testing ITVBTCCIE')
    unittest.TestCase().assertTrue(ITVBTCCIE, 'Could not create ITVBTCCIE')



# Generated at 2022-06-24 12:45:08.469814
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    assert ITVIE._match_id(url) == video_id
    assert ITVIE._match_id(None) is None


# Generated at 2022-06-24 12:45:10.611077
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Check that ITVBTCCIE constructor don't throw error."""
    ITVBTCCIE('btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:45:14.069032
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .common import test_constructor
    test_constructor(ITVBTCCIE, 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:45:23.519853
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import unittest
    class TestITVBTCCIE(unittest.TestCase):
        """Test ITVBTCCIE constructor."""
        def setUp(self):
            self.itvbtccie = ITVBTCCIE(None)

        def test_video_id_extraction(self):
            """Test video id extraction from url."""
            video_id = '6341206572001'
            url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s' % video_id

# Generated at 2022-06-24 12:45:26.260310
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert 'BTCC 2018: All the action from Brands Hatch' in ITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:45:33.947904
# Unit test for constructor of class ITVIE
def test_ITVIE():
    extractor = ITVIE()
    extractor.url = 'https://www.itv.com/hub/liar/2a4547a0012'
    extractor.video_id = '2a4547a0012'
    extractor.webpage = '<html></html>'
    extractor.video_data = '{}'
    extractor.formats = [{'url': 'https://video.itv.com/hub/video/playlist.m3u8?video=2a4547a0012&app=itvplayer&protocol=https'}]

# Generated at 2022-06-24 12:45:40.878764
# Unit test for constructor of class ITVIE

# Generated at 2022-06-24 12:45:42.667587
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert(instance)

# Generated at 2022-06-24 12:45:44.545918
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-24 12:45:54.875562
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class TestITVBTCCIE(ITVBTCCIE):
        def _download_webpage(*args, **kwargs):
            return '''\
<div class="cta" data-video-id="5865378484001">
    <div class="cta__track">
        <a class="cta__link" href="#" title="Race 3">
            <span>Race 3</span>
        </a>
    </div>
</div>
'''
    ie = TestITVBTCCIE()
    # test class constructor
    assert isinstance(ie, ITVBTCCIE)
    # test ie_key()
    assert ie.ie_key() == 'ITVBTCC'
    # test real_extract()

# Generated at 2022-06-24 12:46:01.499416
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:46:02.745300
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:46:04.175306
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # Check that the constructor works
    assert ITVIE(None)

# Generated at 2022-06-24 12:46:13.082594
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = "https://www.itv.com/hub/crime-stories/2a4629a0022"

# Generated at 2022-06-24 12:46:16.718743
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:19.506056
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")._real_extract("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:46:28.838251
# Unit test for constructor of class ITVIE
def test_ITVIE():
    t = ITVIE()
    assert ITVIE._VALID_URL == r"https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)"
    assert t._GEO_COUNTRIES == ['GB']
    assert ITVIE._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-24 12:46:29.732018
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()

# Generated at 2022-06-24 12:46:30.968881
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.__name__ == 'ITVBTCCIE'

# Generated at 2022-06-24 12:46:40.671447
# Unit test for constructor of class ITVIE
def test_ITVIE():
    unit_test_info = ITVIE()._TESTS[0]
    assert (ITVIE._VALID_URL) == "https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)"
    assert (unit_test_info["url"]) == "https://www.itv.com/hub/liar/2a4547a0012"
    assert (unit_test_info["info_dict"]["id"]) == "2a4547a0012"
    assert (unit_test_info["info_dict"]["title"]) == "Liar - Series 2 - Episode 6"

# Generated at 2022-06-24 12:46:42.579416
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # smoke test
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:46:44.824464
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:51.568125
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # From test case
    result = ITVIE("""http://www.itv.com/hub/liar/2a4547a0012?utm_source=itv.com&amp;utm_medium=Hub_Teaser_MoreLike_Show&amp;utm_content=Liarseries2&amp;utm_campaign=Hub_Teaser_MoreLike_Show""")
    assert result.video_id == "2a4547a0012"
    assert result.video_type == "ITV"
    assert result.site_name == "ITV"
    assert result.base_url == "http://www.itv.com"

    # From test case
    result = ITVIE("""https://www.itv.com/hub/through-the-keyhole/2a2271a0033""")
    assert result.video_

# Generated at 2022-06-24 12:46:59.485245
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from ..context import ytdl
    from ..utils import download_script
    from .common import fake_urlopen
    from . import mock

    new_instance = ytdl.YoutubeDL(params={'verbose': True})
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtcc_info = new_instance.extract_info(url)
    assert(itvbtcc_info['id'] == url[31:])



# Generated at 2022-06-24 12:47:02.407008
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv.br == '1582188683001'
    assert itv.ie_key() == 'ITV'

# Generated at 2022-06-24 12:47:05.478183
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')