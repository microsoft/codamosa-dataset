

# Generated at 2022-06-24 12:37:04.128818
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')



# Generated at 2022-06-24 12:37:04.585839
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('url')

# Generated at 2022-06-24 12:37:06.086840
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE._downloader)._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:37:08.661463
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVIE.suitable(url)
    assert ITVBTCCIE.suitable(url)

# Generated at 2022-06-24 12:37:11.277276
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        itv_ie = ITVIE()
        assert itv_ie
    except TypeError as e:
        assert False, e

# Generated at 2022-06-24 12:37:13.419476
# Unit test for constructor of class ITVIE
def test_ITVIE():
	instance = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
	print(instance)

# Generated at 2022-06-24 12:37:13.817345
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:37:18.317598
# Unit test for constructor of class ITVIE
def test_ITVIE():
	# Test whether the constructor of ITVIE can correctly handle a given URL.
    test_url = "https://www.itv.com/hub/liar/2a4547a0012"
    ie = ITVIE()
    assert ie._match_id(test_url) == "2a4547a0012"

# Generated at 2022-06-24 12:37:20.539901
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import doctest
    from .brightcove import BrightcoveNewIE
    doctest.testmod(BrightcoveNewIE, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 12:37:24.080104
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == ITVBTCCIE._VALID_URL

if __name__ == '__main__':
    test_ITVBTCCIE()

# Generated at 2022-06-24 12:37:28.155923
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Check correct constructor of class ITVIE
    itv_ie = ITVIE()
    assert(itv_ie.ie_key().lower() == 'itv')
    assert(itv_ie.ie_key() == 'ITV' )

# Generated at 2022-06-24 12:37:31.938566
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    e = ITVBTCCIE()
    assert not e.BRIGHTCOVE_URL_TEMPLATE
    assert e.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:37:33.216623
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    item = ITVBTCCIE()
    assert isinstance(item, ITVBTCCIE)

# Generated at 2022-06-24 12:37:35.891115
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        test = ITVIE(InfoExtractor())._TESTS[0]
    except IndexError:
        return False
    #  Passing
    return True

# Generated at 2022-06-24 12:37:44.226477
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    def test_ITVBTCCIE_with_id(id):
        url = 'http://www.itv.com/btcc/races/' + id
        assert ITVBTCCIE(IE_NAME)._match_id(url) == id

    def test_ITVBTCCIE_with_ids(dict_id_list):
        for id in dict_id_list.keys():
            test_ITVBTCCIE_with_id(id)
            playlist = ITVBTCCIE(IE_NAME)._real_extract(url)
            assert playlist['id'] == id
            assert playlist['title'] == dict_id_list.get(id)


# Generated at 2022-06-24 12:37:47.578730
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # A preliminary test for the constructor of class ITVBTCCIE
    # to make sure the class ITVBTCCIE is constructed successfully.
    itvbtcc_ie = ITVBTCCIE()

# Generated at 2022-06-24 12:37:58.040436
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:38:02.193409
# Unit test for constructor of class ITVIE
def test_ITVIE():
    a = ITVIE()
    assert a._VALID_URL == "https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)"

# Generated at 2022-06-24 12:38:04.589019
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = ITVBTCCIE()._TEST['url']
    assert ITVBTCCIE._VALID_URL.match(url)

# Generated at 2022-06-24 12:38:07.144803
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012''')

# Generated at 2022-06-24 12:38:07.893919
# Unit test for constructor of class ITVIE
def test_ITVIE():
    if __name__ == '__main__':
        test_ITVIE()

# Generated at 2022-06-24 12:38:10.338122
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # ITVIE supports only certain geo countries.
    supported = ITVIE(None)._GEO_COUNTRIES
    expected = ['GB']
    assert supported == expected

# Generated at 2022-06-24 12:38:15.552396
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
	assert ITVBTCCIE._TEST == {'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'info_dict': {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}, 'playlist_mincount': 9}

# Generated at 2022-06-24 12:38:23.998597
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class itv_ie(ITVIE):
        def _download_json(self, *args, **kwargs):
            return {
                'Title': 'Liar - Series 2 - Episode 6',
                'Synopsis': 'md5:d0f91536569dec79ea184f0a44cca089',
                'SeriesTitle': 'Liar',
                'SeasonNumber': 2,
                'EpisodeNumber': 6,
            }

    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    itv_ie(urllib.request.Request(url))

# Generated at 2022-06-24 12:38:26.408204
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/long-lost-family/2a4440a0047')

# Generated at 2022-06-24 12:38:28.501567
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    classname = ie.__class__.__name__
    assert classname == 'ITVBTCCIE'

# Generated at 2022-06-24 12:38:36.470846
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ITVBTCCIE._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:38:44.110829
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE(ITVBTCCIE.IE_NAME, ITVBTCCIE.IE_KEY)._match_id(url) == playlist_id
    assert ITVBTCCIE(ITVBTCCIE.IE_NAME, ITVBTCCIE.IE_KEY)._real_extract(url).get('title') == "BTCC 2018: All the action from Brands Hatch"

# Generated at 2022-06-24 12:38:49.524360
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:38:53.497366
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE(None)
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:38:54.572550
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():

    ITVBTCCIE()



# Generated at 2022-06-24 12:38:59.311560
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Basic test for ITVBTCCIE, just checking that constructor does not cause some error
    for url in [
            'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
            'http://www.itv.com/btcc/btcc-2018-all-the-action-from-brands-hatch',
    ]:
        ITVBTCCIE(url)

# Generated at 2022-06-24 12:39:03.614814
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()
    assert IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:07.188362
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE()
    assert result
    assert result.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:10.768554
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL.match('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:39:14.401371
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    IT = ITVBTCCIE()
    returns = IT.suitable(url)
    assert returns == False

# Generated at 2022-06-24 12:39:19.516392
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    item = ITVBTCCIE()
    assert item.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:27.780486
# Unit test for constructor of class ITVIE

# Generated at 2022-06-24 12:39:33.264664
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE._downloader).suitable(ITVBTCCIE._TEST['url'])
    assert ITVBTCCIE(ITVBTCCIE._downloader).suitable('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')

# Generated at 2022-06-24 12:39:34.509825
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    assert isinstance(i, ITVIE)

# Generated at 2022-06-24 12:39:41.156595
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    title='BTCC 2018: All the action from Brands Hatch'
    url='http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    expected='http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5785589553001'
    url_result=ITVBTCCIE()._real_extract(url)[0].url

    assert url_result == expected

# Generated at 2022-06-24 12:39:42.963133
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Constructor of ITVIE can be called without argument.
    assert ITVIE()



# Generated at 2022-06-24 12:39:49.790169
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print("ITVIE")
    print("Testing constructor")
    tester = ITVIE("test", "test")
    print("Testing _VALID_URL set")
    assert tester._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    print("Testing _GEO_COUNTRIES set")
    assert tester._GEO_COUNTRIES == ['GB']
    print("Testing _TESTS set")

# Generated at 2022-06-24 12:39:53.897510
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_object = ITVBTCCIE(None)
    assert (test_object.BRIGHTCOVE_URL_TEMPLATE ==
            'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:39:56.837225
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Arrange
    test_case_name = 'ITVIE.__init__'
    # Act
    ITVIE(InfoExtractor)
    # Assert
    # The call to ITVIE should not raise an exception

# Generated at 2022-06-24 12:39:58.630335
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Check that the code to instantiate a new instance of the
    ITVIE class hasn't changed and so is compatible with the
    test cases defined in the class
    """
    itv_ie = ITVIE()


# Generated at 2022-06-24 12:40:00.981161
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_obj = ITVIE()
    assert test_obj._GEO_COUNTRIES[0] == 'GB'
    assert test_obj._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-24 12:40:11.549389
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Basic test for ITVIE
    """
    info_extractor = ITVIE()
    res = info_extractor._real_extract(u'https://www.itv.com/hub/liar/2a4547a0012')
    assert res['id'] == '2a4547a0012', '%r should holds the vedio id' % res['id']
    assert res['title'] == 'Liar - Series 2 - Episode 6', '%r should holds the vedio title' % res['title']
    assert res['description'] == 'md5:d0f91536569dec79ea184f0a44cca089', '%r should holds the vedio description' % res['description']
    assert len(res['subtitles']) > 0, 'There should be at least one subtitle'

# Generated at 2022-06-24 12:40:18.875790
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    assert test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=2a4547a0012' in str(test._real_extract('https://www.itv.com/hub/liar/2a4547a0012'))

# Generated at 2022-06-24 12:40:21.386687
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert x.url_result is not None
    assert x.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-24 12:40:23.512519
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:40:28.110680
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ile = ITVBTCCIE()
    data = ile.extract(url)
    assert len(data['entries']) == 9
    assert data['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert data['_type'] == 'playlist'

# Generated at 2022-06-24 12:40:30.974951
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .itvbtcc import ITVBTCCIE
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:36.006634
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:39.580352
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:40:40.173438
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)

# Generated at 2022-06-24 12:40:42.899210
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:40:43.511710
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    TNTIE.test()

# Generated at 2022-06-24 12:40:45.384739
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:46.299352
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE() # Just test it doesn't crash

# Generated at 2022-06-24 12:40:48.552582
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:40:51.118616
# Unit test for constructor of class ITVIE
def test_ITVIE():
    if not ITVIE.suitable('https://www.itv.com/hub/liar/2a4547a0012'):
        raise Exception('Didn\'t pass test of constructor of ITVIE')
    return True


# Generated at 2022-06-24 12:40:52.694998
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    if len(ie.BRIGHTCOVE_URL_TEMPLATE) == 0:
        assert False

# Generated at 2022-06-24 12:40:57.556577
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    v = ITVBTCCIE()
    assert v._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*([^/?#&]+)'

assert ITVBTCCIE.__name__ == "ITVBTCCIE"


# Generated at 2022-06-24 12:40:58.616016
# Unit test for constructor of class ITVIE
def test_ITVIE():
    _ = ITVIE()



# Generated at 2022-06-24 12:41:01.846817
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # testing class ITVIE 
    ITVIE("url", {}, {}).__init__("url", {"id": "2a4547a0012"}, {})
    ITVIE("url", {}, {})._real_extract("url", "url")


# Generated at 2022-06-24 12:41:03.238923
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('ITVBTCCIE')
    assert ie

# Generated at 2022-06-24 12:41:04.077444
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:41:06.918071
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # ITVIE uses BrightcoveNewIE under the hood
    test_ITVBTCCIE()

# Generated at 2022-06-24 12:41:09.985083
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ie = ITVIE(InfoExtractor())
    ie._match_id(url)

# Generated at 2022-06-24 12:41:12.202372
# Unit test for constructor of class ITVIE
def test_ITVIE():       
    ie = ITVIE()
    # Check that constructor of ITVIE class is working properly
    ie.has_working_constructor = True
    print("ITVIE constructor is working")


# Generated at 2022-06-24 12:41:14.820025
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    return ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-24 12:41:16.441299
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()

# Generated at 2022-06-24 12:41:17.901482
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    instances = [instance]

# Generated at 2022-06-24 12:41:25.808409
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ios_playlist_url = 'https://www.itv.com/data/vod/en/itv-player/liar/series-2/episode-6/playlist/%s/playlist.json' % video_id
    hmac = '4f639c4aeeb942c499d1e5606935c2a6'
    parameters = 'data-video-id="' + video_id + '" ' + 'data-video-playlist="' + ios_playlist_url + '" ' + 'data-video-hmac="' + hmac + '"'

# Generated at 2022-06-24 12:41:29.787037
# Unit test for constructor of class ITVIE
def test_ITVIE():
    t = ITVIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"


# Generated at 2022-06-24 12:41:33.181428
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    assert ie.__class__.__name__ == "ITVIE"

# Generated at 2022-06-24 12:41:33.807459
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:41:40.337286
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_input = 'https://www.itv.com/hub/liar/2a4547a0012'
    test_output = ITVIE()
    assert test_output._VALID_URL == ITVIE._VALID_URL
    assert test_output.suitable(test_input) == True
    assert test_output.IE_DESC == 'ITV'
    assert test_output.ie_key() == 'ITV'
    assert test_output.VIDEO_EXTENSIONS == ['mov', 'mp4', 'm4v']


# Generated at 2022-06-24 12:41:40.859294
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:41:44.540431
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvIE = ITVIE()
    assert itvIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:41:47.960785
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE(): # IGNORE:C01111
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:49.451782
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(InfoExtractor())._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:41:59.380533
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class_ = ITVIE
    assert class_.__name__ == 'ITVIE'
    assert class_.__doc__ == 'ITV (ITV Hub)'
    assert class_._VALID_URL == "https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)"

# Generated at 2022-06-24 12:42:02.432383
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE().suitable(url)

# Generated at 2022-06-24 12:42:07.151145
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_ITVBTCCIE.__name__ = 'test_' + ITVBTCCIE.__name__
    extractor = ITVBTCCIE(ITVIE())
    assert extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:08.479586
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE().extract('2a4547a0012')

# Generated at 2022-06-24 12:42:13.891709
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Constructor test
    IE = ITVIE()
    # For the moment, this is the only test
    assert IE.get_id('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'

# Generated at 2022-06-24 12:42:19.326501
# Unit test for constructor of class ITVIE
def test_ITVIE():
	assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
	assert ITVIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:42:20.488113
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:42:22.764301
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst_itv_ie = ITVIE()
    assert inst_itv_ie != None


# Generated at 2022-06-24 12:42:32.644102
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Initialise the class
    itvbtccie = ITVBTCCIE()

    # Run a general test on the class
    assert itvbtccie.suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert itvbtccie.suitable('https://www.itv.com/BTCC/interviews/a-brands-hatch-victory-would-be-emotional')
    assert itvbtccie.suitable('https://www.itv.com/BTCC/interviews/a-brands-hatch-victory-would-be-emotional')

# Generated at 2022-06-24 12:42:33.947989
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    it = ITVBTCCIE()
    assert it is not None


# Generated at 2022-06-24 12:42:36.939386
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Tests setup and basic functionality of ITVIE"""

    ie = ITVIE()
    assert ie.IE_NAME == 'itv.com'


# Generated at 2022-06-24 12:42:37.932195
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE()

# Generated at 2022-06-24 12:42:41.020278
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')



# Generated at 2022-06-24 12:42:44.271620
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:53.110477
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_ITVBTCCIE._TEST = {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    assert ITVBTCCIE._VALID_URL is\
           'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:42:55.217043
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE()
    assert itv._TEST['url'] == itv._VALID_URL

# Generated at 2022-06-24 12:42:56.827993
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:42:57.715432
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()

# Generated at 2022-06-24 12:43:02.625402
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # unit test for regular episode
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

    # unit test for invalid available product
    # ITVIE('https://www.itv.com/hub/liar/2a4547a0011')

    # unit test for unavailable video
    # ITVIE('https://www.itv.com/hub/liar/2a4547a0013')

# Generated at 2022-06-24 12:43:13.271458
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE_instance = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    assert IE_instance.VIMEO_HELP == []
    assert IE_instance.VIMEO_API_BASE == "https://player.vimeo.com/api/v2"
    assert IE_instance.VIMEO_API_RATES == "info%2C+files%2C+captions%2C+texttracks"
    assert IE_instance.VIMEO_LOGIN_URL == "https://www.vimeo.com/log_in"
    assert IE_instance.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/%s/default_default/index.html?videoId=%s"

# Generated at 2022-06-24 12:43:13.867243
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:43:15.105635
# Unit test for constructor of class ITVIE
def test_ITVIE():
    extractor = ITVIE()
    assert extractor


# Generated at 2022-06-24 12:43:19.492157
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    instance = ITVBTCCIE(ITVBTCCIE._build_url_result(url, {}))
    assert isinstance(instance, ITVBTCCIE)
    assert ITVBTCCIE.ie_key() in itv_ie.IE_DESC

# Generated at 2022-06-24 12:43:23.520546
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')

# Generated at 2022-06-24 12:43:28.407771
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    URL = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._match_id(URL) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:43:35.670848
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']
    assert ie._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ie._TESTS[1]['url'] == 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033'
    assert ie._TESTS[2]['url'] == 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'


# Generated at 2022-06-24 12:43:46.004557
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:43:48.538339
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE({})._extract_playlist(
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:43:51.474124
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Accept a string and an array of strings as first arguments
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012').geo_countries == ['GB']
    assert ITVIE(['https://www.itv.com/hub/liar/2a4547a0012']).geo_countries == ['GB']

# Generated at 2022-06-24 12:43:52.622718
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtcc_ie = ITVBTCCIE()
    isinstance(itvbtcc_ie, ITVBTCCIE)

# Generated at 2022-06-24 12:43:55.920899
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url_itv_btcc = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(url_itv_btcc)

# Generated at 2022-06-24 12:44:00.892581
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test whether all video ids match the pattern
    video_ids = re.findall(r'data-video-id=["\'](\d+)', open(test_ITVBTCCIE.__code__.co_filename).read())
    for video_id in video_ids:
        assert re.match(r'^\d+$', video_id)

# Generated at 2022-06-24 12:44:04.110238
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:44:13.965441
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    url_a = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5797319162001'
    url_b = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5797319152001'
    url_c = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5797319150001'

# Generated at 2022-06-24 12:44:23.340852
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_cases = [
        {
            'params': {
                'data-video-playlist': 'expected_ios_playlist_url',
                'data-video-id': '',
                'data-video-hmac': 'expected_hmac',
            },
            'expected_ios_playlist_url': 'expected_ios_playlist_url',
        },
        {
            'params': {
                'data-video-playlist': '',
                'data-video-id': 'expected_ios_playlist_url',
                'data-video-hmac': 'expected_hmac',
            },
            'expected_ios_playlist_url': 'expected_ios_playlist_url',
        },
    ]
    parser = ITVIE(None)

# Generated at 2022-06-24 12:44:24.757571
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE("url")._VALID_URL


# Generated at 2022-06-24 12:44:29.158926
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert(itv.geo_countries == itv._GEO_COUNTRIES)
    assert(itv._VALID_URL == itv.VALID_URL)
    assert(itv._TESTS == itv.TESTS)

# Generated at 2022-06-24 12:44:29.827288
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None).extract(None)

# Generated at 2022-06-24 12:44:31.803000
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITBTCC = ITVBTCCIE()
    assert ITBTCC is not None


# Generated at 2022-06-24 12:44:33.679176
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:44:37.687141
# Unit test for constructor of class ITVIE
def test_ITVIE():
	print('Unit test for ITVIE')
	url = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
	SCRAPER = ITVIE()
	result = SCRAPER.url_result(url=url)
	print(result)

# Generated at 2022-06-24 12:44:46.013456
# Unit test for constructor of class ITVIE
def test_ITVIE():
    for param in ITVIE._TESTS:
        youtube_id = param["id"]
        info0 = param["info_dict"]
        assert 'id' in info0
        #print(param)
        info = ITVIE()._real_extract(param["url"])
        #print(info)
        assert info["id"] == ""
        assert info["title"] == ""
        assert info["description"] == ""
        assert info["duration"] is None
        assert info["episode_number"] == ""
        assert info["season_number"] == ""
        assert info["series"] == ""
    print("test_ITVIE passed")


# Generated at 2022-06-24 12:44:48.025414
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:44:48.668855
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:44:52.119244
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    infoExtractor = ITVBTCCIE(None)
    assert infoExtractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:44:53.434082
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.__name__ == 'ITVIE'

# Generated at 2022-06-24 12:44:54.993694
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() == 'ITVBTCC'

# Generated at 2022-06-24 12:44:57.047969
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Constructor for ITVIE shoud NOT have any errors
    i = ITVIE()

# Generated at 2022-06-24 12:45:00.369552
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Test that constructor of class ITVIE works.
    """
    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(test_url)

# Generated at 2022-06-24 12:45:02.140314
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._constructor(None)('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:45:04.867684
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE.IE_map.get('ITV')
    assert IE.__name__ == 'ITVIE'
    assert IE._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert IE._GEO_COUNTRIES == ['GB']


# Generated at 2022-06-24 12:45:05.343228
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()

# Generated at 2022-06-24 12:45:09.808100
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE(None)
    assert isinstance(instance, ITVBTCCIE)
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:11.015956
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import doctest
    doctest.testmod(ITVBTCCIE)

# Generated at 2022-06-24 12:45:19.311942
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE()._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE()._match_id(url+'/') == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE()._match_id(url+'?') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:45:30.666460
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:45:32.394285
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVIE()).IE_NAME == ITVBTCCIE.ie_key()

# Generated at 2022-06-24 12:45:35.945492
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:46.461934
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_ie = ITVIE()
    assert test_ie.geo_verification_headers() == {'Host': 'geo-ip-services.itv.com'}
    assert ITVIE()._GEO_COUNTRIES == ['GB']
    assert test_ie.extract_url_info('https://www.itv.com/hub/liar/2a4547a0012') == \
        {'_type': 'url_transparent', 'id': '2a4547a0012', 'url': 'https://www.itv.com/hub/liar/2a4547a0012', 'title': 'Liar - Series 2 - Episode 6', 'ext': 'mp4'}

# Generated at 2022-06-24 12:45:56.129710
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # define test function
    def t(c, v, e):
        assert ITVBTCCIE._valid_url(c, v) == (c, e)
    # use test function
    t('h', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
    })
    t('h', 'http://www.itv.com/btcc/race-highlights/races/btcc-2018-all-the-action-from-brands-hatch', {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
    })

# Generated at 2022-06-24 12:45:57.202076
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('ITVBTCCIE', expect_warning=False)

# Generated at 2022-06-24 12:46:06.537689
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    if itvie is None:
        raise AssertionError("ITVIE couldn't be instantiated")
    if itvie._VALID_URL is None:
        raise AssertionError("ITVIE has no _VALID_URL regex")
    if itvie._download_webpage is None:
        raise AssertionError("ITVIE has no _download_webpage method")
    if itvie._match_id is None:
        raise AssertionError("ITVIE has no _match_id method")
    if itvie._real_extract is None:
        raise AssertionError("ITVIE has no _real_extract method")


# Generated at 2022-06-24 12:46:09.682225
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    assert test._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:46:19.291151
# Unit test for constructor of class ITVIE
def test_ITVIE():
    s = ITVIE()
    # Test for baseurl
    assert s.baseurl is None
    # Test for basetitle
    assert s.basetitle is None
    # Test for title delim
    assert s.title_delim is None
    # Test for name
    assert s.name() == 'itv'
    # Test for description
    assert s.description() == 'Watch content from ITV Player, ITV on Demand and live ITV'
    # Test for type
    assert s.type() == 'generic'
    # Test for url
    assert s.valid_url('http://www.itv.com/videos/a-normal-url')
    assert s.valid_url('http://www.itv.com/news/a-normal-url')
    assert not s.valid_url('http://www.itv.com')


# Generated at 2022-06-24 12:46:20.891548
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:46:29.962139
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvbtccie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:46:30.422292
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:46:40.222438
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_str = """<script>
    var btcc = function btcc() {
        return [{P: "btcc-2018-all-the-action-from-brands-hatch"}];
    }
    var btcc_videos = function btcc_videos() {
        return [{
            id: "5803520363001",
            title: "BTCC 2018: All the action from Brands Hatch",
            tags: "btcc,racing",
            contents: [{
                src: "https://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5803520363001",
                type: "text/html"
            }]
        }];
    }
    </script>"""
    test_playlist = ITV

# Generated at 2022-06-24 12:46:43.466383
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:46:45.031453
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITV('www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:46:49.689039
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.suitable('https://www.itv.com/hub/liar/2a4547a0012')
    assert ie.IE_NAME == 'ITV: Video'
    assert ie.IE_DESC == 'ITV: Video'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'


# Generated at 2022-06-24 12:46:52.636346
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import inspect
    class_ = ITVIE()
    assert inspect.ismethod(class_._real_extract) == True

# Generated at 2022-06-24 12:46:59.912904
# Unit test for constructor of class ITVIE
def test_ITVIE():
    t = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert t._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert t._GEO_COUNTRIES == ['GB']
    assert t.url == "https://www.itv.com/hub/liar/2a4547a0012"
    assert t.video_id == "2a4547a0012"

# Generated at 2022-06-24 12:47:04.584063
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'