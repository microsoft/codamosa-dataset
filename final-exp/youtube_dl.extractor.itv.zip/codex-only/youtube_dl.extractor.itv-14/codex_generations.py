

# Generated at 2022-06-24 12:37:06.694980
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "111"
    ITVIE(url)


# Generated at 2022-06-24 12:37:08.451021
# Unit test for constructor of class ITVIE
def test_ITVIE():
    #Test fixture for ITVIE
    itv_ie = ITVIE()
    #Test instance of ITVIE
    assert itv_ie is not None


# Generated at 2022-06-24 12:37:12.164924
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    obj = ITVBTCCIE(url)
    assert obj.__class__ == ITVBTCCIE

# Generated at 2022-06-24 12:37:15.102638
# Unit test for constructor of class ITVIE
def test_ITVIE():

    test_url = "https://www.itv.com/hub/liar/2a4547a0012"
    extractor = ITVIE()
    extractor.extract(test_url)

# Generated at 2022-06-24 12:37:17.798859
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    playlist_id = 'btcc-2018-all-the-action-from-thruxton'
    url = 'http://www.itv.com/btcc/races/%s' % playlist_id
    assert i._match_id(url) == playlist_id

# Generated at 2022-06-24 12:37:20.446233
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE()
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:22.328902
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    InfoExtractor('ITVBTCCIE')

# Generated at 2022-06-24 12:37:23.952313
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    assert isinstance(i, InfoExtractor)


# Generated at 2022-06-24 12:37:26.290003
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test constructor of class ITVBTCCIE
    constructorCheck = ITVBTCCIE(None, False)
    assert constructorCheck

# Generated at 2022-06-24 12:37:26.965127
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:37:28.441617
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie is not None

# Generated at 2022-06-24 12:37:32.353569
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Simple test to verify that constructor of ITVIE class works.
    """
    ITVIE('http://www.itv.com/hub/the-queens-green-planet/2a5332a0474')

test_ITVIE()

# Generated at 2022-06-24 12:37:33.601258
# Unit test for constructor of class ITVIE
def test_ITVIE():
    unit = ITVIE()
    assert unit


# Generated at 2022-06-24 12:37:34.867182
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(downloader=None)

# Generated at 2022-06-24 12:37:38.912696
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE(None)
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:41.634768
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:37:45.779711
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc_ie_inst = ITVBTCCIE()
    assert btcc_ie_inst._VALID_URL == ITVBTCCIE._VALID_URL
    assert btcc_ie_inst.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:37:53.721015
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    # Check number of tests
    assert len(ie._TESTS) == 4
    # Check json data extraction
    for expected in ie._TESTS:
        test_url = expected['url']
        if 'info_dict' in expected:
            info = ie.extract(test_url)
            for key, value in expected['info_dict'].items():
                if value is None:
                    continue
                assert info[key] == value, '%s != %s' % (info[key], value)

# Generated at 2022-06-24 12:38:03.324889
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "http://www.itv.com/hub/meet-the-parents/2a3332a0003"
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._GEO_COUNTRIES == ['GB']
    assert ITVIE._TESTS[0].keys() == ['url', 'info_dict', 'params']
    assert ITVIE._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE._TESTS[0]['params'].keys() == ['skip_download']

# Generated at 2022-06-24 12:38:13.436892
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.__name__ == 'ITVBTCCIE'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:38:14.012215
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:38:16.969138
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .test_brightcove import BrightcoveNewTestIE
    BrightcoveNewTestIE().test_constructor(ITVBTCCIE)

# Generated at 2022-06-24 12:38:17.866256
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE

# Generated at 2022-06-24 12:38:20.674141
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-24 12:38:27.440661
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.__name__ == 'ITVBTCCIE'
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:38:35.690254
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    instance = type(ie).__new__(type(ie))
    type(ie).__init__(instance, {})

    assert instance._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert instance._TEST == {'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'info_dict': {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}, 'playlist_mincount': 9}

# Generated at 2022-06-24 12:38:42.030004
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST['url'] == url
    assert ie._TEST['playlist_mincount'] == 9

# Generated at 2022-06-24 12:38:49.233232
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:38:52.984350
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:38:56.813787
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-24 12:39:00.834992
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:02.857943
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:39:03.445973
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:39:06.632729
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    a = ITVBTCCIE()
    assert a._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:39:16.346903
# Unit test for constructor of class ITVIE
def test_ITVIE():
    _test_ITVIE = ITVIE(_download_webpage)
    _test_ITVIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    _test_ITVIE.BRIGHTCOVE_EMBED_URL = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

    assert _test_ITVIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert _test_

# Generated at 2022-06-24 12:39:16.931323
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:39:20.288424
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class args:
        pass

    print("Running constructor test for ITVIE")
    instance = ITVIE(args())
    if instance == None:
        print("Constructor for ITVIE failed")
        return False
    print("Constructor for ITVIE successful")
    return True


# Generated at 2022-06-24 12:39:24.742026
# Unit test for constructor of class ITVIE
def test_ITVIE():
    logger = ITVIE("", {})
    assert logger.url == "https://www.itv.com"
    assert logger.method == "GET"
    assert logger.headers["User-Agent"] == "Mozilla/5.0"
    assert logger.headers["Accept-Language"] == "en-US,en;q=0.5"


# Generated at 2022-06-24 12:39:28.644568
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:39:36.057825
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.url_result(
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default'
        '/index.html?videoId=5720948214001') == {
        '_type': 'url',
        'url': 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5720948214001',
        'ie_key': 'BrightcoveNew',
        'video_id': '5720948214001',
    }

# Generated at 2022-06-24 12:39:40.775180
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc_itv = ITVBTCCIE()
    assert btcc_itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:42.579162
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVIE({'geo_countries': ['GB']})
    assert x._GEO_BYPASS == True

# Generated at 2022-06-24 12:39:43.986161
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL.startswith('https?://')

# Generated at 2022-06-24 12:39:45.108399
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVE = ITVBTCCIE()
    assert ITVE != None

# Generated at 2022-06-24 12:39:45.939362
# Unit test for constructor of class ITVIE
def test_ITVIE():
	itv_ie = ITVIE()


# Generated at 2022-06-24 12:39:49.974552
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL
    assert ITVIE()._TESTS[0]['url'] == ITVIE._TESTS[0]['url']



# Generated at 2022-06-24 12:39:53.130541
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    iev = ITVIE()
    assert iev._match_id(url) == '2a4547a0012'



# Generated at 2022-06-24 12:39:55.566251
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE('https://www.youtube.com')
    assert ie.geo_verification_headers()['X-Forwarded-For']

# Generated at 2022-06-24 12:39:56.937537
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()
    assert 'itv.com' in IE.IE_NAME
    assert 'itv.com' in IE.IE_DESC
    assert IE._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-24 12:40:02.553404
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE()
    itv.BRIGHTCOVE_URL_TEMPLATE %= "12345" # Assign some default value for testing
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    result = itv.url_result(smuggle_url(itv.BRIGHTCOVE_URL_TEMPLATE % "12345", {"geo_ip_blocks": ["193.113.0.0/16", "54.36.162.0/23", "159.65.16.0/21"], "referrer": url}), ie="brightcove", video_id="12345")
    assert isinstance(result, ITVBTCCIE)

# Generated at 2022-06-24 12:40:07.552956
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE(None)._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert result['_type'] == 'playlist'

# Generated at 2022-06-24 12:40:08.983090
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)

# Generated at 2022-06-24 12:40:09.955305
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == "itv"

# Generated at 2022-06-24 12:40:12.551093
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert ie.__class__ is ITVIE

# Generated at 2022-06-24 12:40:20.240872
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    urls = [
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'http://www.itv.com/btcc/races/quail-motor-cycle-gathering-2018-highlights',
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch2',
    ]
    for url in urls:
        ITVBTCCIE._real_extract(ITVBTCCIE(), url)

# Generated at 2022-06-24 12:40:23.839588
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # setup-test
    test_instance = ITVBTCCIE("")
    # test-case
    assert (ITVBTCCIE._TEST.get("url") in test_instance.BRIGHTCOVE_URL_TEMPLATE)
    # tear-down

# Generated at 2022-06-24 12:40:25.679861
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(InfoExtractor())._extract_url('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:40:26.193630
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:40:33.714613
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .test_btcc import check_brightcove_id_exists
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itv_btcc_ie = ITVBTCCIE()
    itv_btcc_ie._download_webpage = lambda *args: ''
    itv_btcc_ie._og_search_title = lambda : 'BTCC 2018: All the action from Brands Hatch'
    itv_btcc_ie._html_search_regex = lambda *args, **kwargs: '5958653006001'
    itv_btcc_ie.url = url

    btcc_playlist = itv_btcc_ie.extract(url)

    assert btcc_playlist

# Generated at 2022-06-24 12:40:38.854574
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/players/HkiHLnNRx/HkiHLnNRx_default/index.html?videoId=%s'
    return ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:40:40.466207
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test class constructor
    obj = ITVBTCCIE()
    assert isinstance(obj, ITVBTCCIE)

# Generated at 2022-06-24 12:40:45.530982
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    unit test case for constructor of class ITVIE (version:2020.11.16)
    """
    # 1. create ITVIE object
    ITV_OBJ = ITVIE()

    # 2. assert the value of member variables
    assert ITV_OBJ._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITV_OBJ.BRIGHTCOVE_URL_TEMPLATE is None
    assert ITV_OBJ._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:40:49.705457
# Unit test for constructor of class ITVIE
def test_ITVIE():
	test = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
	assert test._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
	assert test._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:40:55.958815
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = ITVIE._match_id(url)
    assert video_id == '2a4547a0012'
    webpage = ITVIE._download_webpage(ITVIE(), url, video_id)
    assert ITVIE._search_regex(r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params')
    assert ITVIE._search_meta(['og:title', 'twitter:title'], webpage)
    assert ITVIE._html_search_meta(['og:title', 'twitter:title'], webpage)

# Generated at 2022-06-24 12:41:04.327477
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    cie = ITVBTCCIE()
    assert cie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert cie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:41:07.099313
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_instance = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:41:08.089140
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'itv.com'
    assert ITVIE.ie_key() != 'ITV'

# Generated at 2022-06-24 12:41:13.747282
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    data = ITVIE()._real_extract(url)
    assert(data['id'] == video_id)
    assert(data['title'] == 'Liar - Series 2 - Episode 6')
    assert(data['formats'])
    assert(data['duration'] == 2132)
    assert(data['series'] == 'Liar')

# Generated at 2022-06-24 12:41:20.333158
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    result = ITVBTCCIE()._real_extract(test_url)
    assert len(result['entries']) == 9
    assert result['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert result['title'] is None

# Generated at 2022-06-24 12:41:24.909778
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = ITVIE._build_url("https://www.itv.com/hub/liar/2a4547a0012")
    assert url == "https://www.itv.com/hub/liar/2a4547a0012"
    url = ITVIE._build_url("https://www.itv.com/hub/liar/2a4547a0012", "https://www.itv.com")
    assert url == "https://www.itv.com/hub/liar/2a4547a0012"
    url = ITVIE._build_url("/hub/liar/2a4547a0012", "https://www.itv.com")
    assert url == "https://www.itv.com/hub/liar/2a4547a0012"
    url = ITV

# Generated at 2022-06-24 12:41:26.534508
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVExtractor = ITVIE()
    return ITVExtractor

# Generated at 2022-06-24 12:41:27.994558
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-24 12:41:30.665874
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Constructor to create instance of class ITVBTCCIE
    ITVBTCCIE(InfoExtractor,ITVBTCCIE._TEST)

# Generated at 2022-06-24 12:41:34.830298
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ydl = YoutubeDL({})
    ie = ITVIE(ydl, {})
    # YouTubeDLCache is a dummy class
    assert(isinstance(ie.ydl_cache, YoutubeDLCache))
    assert(isinstance(ie.cache_storage, YoutubeDLCacheStorage))

# Generated at 2022-06-24 12:41:36.941679
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IT = ITVBTCCIE({}, {})
    assert IT.BRIGHTCOVE_URL_TEMPLATE
    assert IT.url_result

# Generated at 2022-06-24 12:41:37.858854
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE({}).ie_key() == 'itv:itv'

# Generated at 2022-06-24 12:41:39.343288
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from test_develop import itvIE
    assert issubclass(ITVBTCCIE, itvIE)

# Generated at 2022-06-24 12:41:44.777580
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extract_now_itv_btcc = ITVBTCCIE()
    info_extract_now_itv_btcc.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    info_extract_now_itv_btcc.BRIGHTCOVE_URL_TEMPLATE = 'https://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:41:55.550898
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    playlist = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    webpage = playlist._download_webpage(url, playlist_id)
    entries = [
        playlist.url_result(
            smuggle_url(playlist.BRIGHTCOVE_URL_TEMPLATE % video_id, {
                'referrer': url,
            }),
            ie=BrightcoveNewIE.ie_key(), video_id=video_id)
        for video_id in re.findall(r'data-video-id=["\'](\d+)', webpage)]

# Generated at 2022-06-24 12:42:00.332720
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:08.965021
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        from itv.extractor import itvbtcc
        from itv.compat import compat_urllib_request
        from itv.utils import (
            clean_html,
            determine_ext,
            extract_attributes,
            get_element_by_class,
            JSON_LD_RE,
            merge_dicts,
            parse_duration,
            smuggle_url,
            url_or_none,
        )
    except:
        return 0

    test_obj = itvbtcc.ITVBTCCIE()
    assert test_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert test_obj._T

# Generated at 2022-06-24 12:42:15.589983
# Unit test for constructor of class ITVIE
def test_ITVIE():
	url = 'https://www.itv.com/hub/liar/2a4547a0012'
	instance = ITVIE()
	assert (instance._VALID_URL == ITVIE._VALID_URL)
	assert (instance._TESTS == ITVIE._TESTS)
	assert (instance._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES)

# Generated at 2022-06-24 12:42:17.884129
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:24.078889
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ie._BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:42:25.432749
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst=ITVBTCCIE()
    assert isinstance(inst, ITVBTCCIE)

# Generated at 2022-06-24 12:42:34.793770
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    InfoExtractor.entry_protocol = 'mock'

    InfoExtractor.mock_entries = {
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5644893284001':
            {'title': 'BTCC 2018 - Full Race Highlights - Oulton Park Race 1', 'id': '5644893284001'}
    }

    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    info = {}
    info['Title'] = 'BTCC 2018: All the action from Brands Hatch'

    # With mock_entries, no actual download is made. We can't tell the URL of
    # the thumbnail that

# Generated at 2022-06-24 12:42:45.783950
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:42:56.747576
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE(object(), object())
    import datetime
    title = ie.BRIGHTCOVE_URL_TEMPLATE % "5795081729001"

# Generated at 2022-06-24 12:42:59.179619
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    The ITVIE constructor has been converted to use a single regex to match both
    URLs and video ids. Since the test for that regex was done under the ITV
    test fixture, the only test needed here is to ensure that the regex continues
    to fail when it shouldn't, and won't fail when it shouldn't.
    """
    ITVIE.suite()

# Generated at 2022-06-24 12:43:00.801629
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:43:01.725691
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst= ITVBTCCIE()

# Generated at 2022-06-24 12:43:03.520645
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() in IE_NAME_MAP
    assert ITVIE.ie_key() == 'itv'

# Generated at 2022-06-24 12:43:05.447825
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:43:06.222475
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:43:08.001982
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    print('ITVIE() unit test passed!')

test_ITVIE()

# Generated at 2022-06-24 12:43:09.328959
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Import ITVIE class to test constructor"""
    ITVIE()

# Generated at 2022-06-24 12:43:11.387708
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None)._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:43:19.836053
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .. import get_testcases_from_file
    file_name = 'btcc'
    testcases = get_testcases_from_file(file_name)
    for testcase in testcases:
        testcase['result']['_type'] = 'playlist'

# Generated at 2022-06-24 12:43:30.419871
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtcc_ie = ITVBTCCIE()
    assert itvbtcc_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itvbtcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:37.904803
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    instance = ITVBTCCIE(
        ITVExtractor,
        None,
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

    assert instance.ITVExtractor == ITVExtractor
    assert instance.id == 'btcc-2018-all-the-action-from-brands-hatch'
    assert instance.url == test_url
    assert instance.title == 'BTCC 2018: All the action from Brands Hatch'
    assert instance._TESTS[0]['url'] == test_url

# Generated at 2022-06-24 12:43:41.709500
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test instantiation of ITVBTCCIE from ITVBTCCIE class
    x = ITVBTCCIE()
    assert x._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:43:45.576697
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ie = ITVIE()
    assert ie._VALID_URL == ITVIE._VALID_URL
    assert ie._TESTS == ITVIE._TESTS
    assert ie.suitable(url)
    assert ie._real_extract('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-24 12:43:46.068682
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key()

# Generated at 2022-06-24 12:43:51.958765
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:43:55.429164
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-24 12:44:00.764230
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE(
        'http://www.itv.com/hub/liar/2a4547a0012',
        'http://www.itv.com/hub/liar/2a4547a0012'
    )
    assert test._match_id('http://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'

# Generated at 2022-06-24 12:44:03.694714
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()._real_extract("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert ie.playlist_mincount == 9

# Generated at 2022-06-24 12:44:08.822646
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITNBTCCIE = ITVBTCCIE()
    ITNBTCCIE_match_ID = ITVBTCCIE._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert type(ITNBTCCIE_match_ID) == str
    ITNBTCCIE_match_ID_type = type(ITNBTCCIE_match_ID)
    assert ITNBTCCIE_match_ID_type == str
    ITNBTCCIE_match_ID_type_string = str(ITNBTCCIE_match_ID_type)
    assert type(ITNBTCCIE_match_ID_type_string) == str

# Generated at 2022-06-24 12:44:10.137520
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_video_id = '2a4547a0012'
    ITVIE(None)._real_extract('https://www.itv.com/hub/liar/%s' % test_video_id)

# Generated at 2022-06-24 12:44:15.184247
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    e = ITVIE()
    # Test that the constructor works
    assert e.GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert e.VALID_URL == ITVIE._VALID_URL
    assert e.TESTS == ITVIE._TESTS

# Generated at 2022-06-24 12:44:18.161109
# Unit test for constructor of class ITVIE
def test_ITVIE():
    sample_url = "https://www.itv.com/hub/liar/2a4547a0012"
    itv_ie = ITVIE()
    itv_ie._match_id(sample_url)


# Generated at 2022-06-24 12:44:23.536286
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE("url", "name")
    assert (instance.params['data-video-playlist'] == 'hub/%2B/2a4547a0012')
    assert (instance.params['data-video-hmac'] == 'x5xCCnG8wSAeKTza6Fyf+mBk6h8=')

# Generated at 2022-06-24 12:44:26.781752
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert obj.__class__.__name__ == "ITVBTCCIE"

# Generated at 2022-06-24 12:44:30.172646
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	# Test for ITVBTCCIE constructor
        # test for non-existent URL
	assert(ITVBTCCIE("") is None)
	# test for proper URL
	assert(ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch") is not None)

# Generated at 2022-06-24 12:44:34.125475
# Unit test for constructor of class ITVIE
def test_ITVIE():
	ie = ITVIE()
	assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-24 12:44:35.977837
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE({})
    except:
        print("ITVIE needs a better test.")
    return True

# Generated at 2022-06-24 12:44:42.906600
# Unit test for constructor of class ITVIE
def test_ITVIE():
    TestClass = ITVIE
    TestClass._TESTS = []

    TestClass.TEST_CASES.append((
        'https://www.itv.com/hub/coronation-street/2a1055a0065',
        'https://www.itv.com/hub/coronation-street/2a1055a0065'))

    TestClass.TEST_CASES.append((
        'https://www.itv.com/hub/coronation-street/2a1055a0065?cid=BEWU',
        'https://www.itv.com/hub/coronation-street/2a1055a0065'))


# Generated at 2022-06-24 12:44:52.385912
# Unit test for constructor of class ITVIE
def test_ITVIE():
	video_tests = {
		r'https://www.itv.com/hub/liar/2a4547a0012': '2a4547a0012',
		r'https://www.itv.com/hub/through-the-keyhole/2a2271a0033': '2a2271a0033',
		r'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034': '2a5159a0034',
		r'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024': '2a2898a0024'
	}
	test_video_test = ITVIE()

# Generated at 2022-06-24 12:44:53.536500
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert "ITVIE" in globals()

# Generated at 2022-06-24 12:45:01.211255
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-24 12:45:02.964189
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_object = ITVIE()
    assert test_object.IE_NAME == 'itv'

# Generated at 2022-06-24 12:45:07.145174
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Unit test for constructor ITVBTCCIE
    """
    from .common import TestIE
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_ie = TestIE(test_url)
    test_ie.test()

# Generated at 2022-06-24 12:45:17.623254
# Unit test for constructor of class ITVIE
def test_ITVIE():
    valid_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    itvie = ITVIE()
    assert itvie._match_id(valid_url) == '2a4547a0012'
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itvie._GEO_COUNTRIES == ['GB']
    assert len(itvie._TESTS) == 4
    assert itvie._TESTS[0]['url'] == valid_url
    assert itvie._TESTS[0]['info_dict']['id'] == '2a4547a0012'

# Generated at 2022-06-24 12:45:22.159409
# Unit test for constructor of class ITVIE
def test_ITVIE():
    a = ITVIE()
    assert a.IE_NAME == 'itv'
    assert a.BUILD_ID == 'itv'
    assert a.GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:45:25.492631
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE()
    assert obj.__class__.__name__ == 'ITVBTCCIE'
    assert issubclass(obj.__class__, InfoExtractor)

# Generated at 2022-06-24 12:45:26.934960
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert(ITVIE.__name__ == 'ITVIE')

# Generated at 2022-06-24 12:45:32.022013
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """ test for ITVIE class constructor """
    class_instance = ITVIE()
    assert class_instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert class_instance.geo_countries() == ['GB']

# Generated at 2022-06-24 12:45:35.224031
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    info = ITVIE()._real_extract(url)
    assert info['id'] == '2a4547a0012'

# Generated at 2022-06-24 12:45:36.057323
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('ITVBTCCIE')

# Generated at 2022-06-24 12:45:46.053471
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    instance._download_webpage('http://www.itv.com/hub/liar/2a4547a0012', '2a4547a0012')
    instance._download_json('2a4547a0012', '2a4547a0012')
    instance._sort_formats()
    instance._search_json_ld('', '')
    instance._search_regex('','','','','','','','','','','','')
    instance.download_webpage_handle()
    instance.extract()
    instance.extract_macro()

# Generated at 2022-06-24 12:45:47.087677
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(object)


# Generated at 2022-06-24 12:45:54.655869
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url1 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    url2 = 'http://www.itv.com/btcc/championship/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'

    assert ITVBTCCIE()._match_id(url1) == playlist_id
    assert ITVBTCCIE()._match_id(url2) == playlist_id

# Generated at 2022-06-24 12:45:57.373685
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert (ITVBTCCIE()).suitable(test_url)

# Generated at 2022-06-24 12:46:00.854004
# Unit test for constructor of class ITVIE
def test_ITVIE():
	try:
		ITVIE()._real_extract('https://www.itv.com/hub/liar/2a4547a0012')
	except Exception:
		print("Test was not successful.")
		return False
	return True


# Generated at 2022-06-24 12:46:03.364870
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE('ITVBTCCIE')
    assert info_extractor

# Generated at 2022-06-24 12:46:04.773747
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    unit = ITVBTCCIE()
    assert isinstance(unit, ITVBTCCIE)
    assert isinstance(unit, InfoExtractor)
    assert isinstance(unit, ITVIE)


# Generated at 2022-06-24 12:46:06.037444
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # ITVBTCCIE should accept a valid URL
    assert ITVBTCCIE._VALID_URL.findall(ITVBTCCIE._TEST['url']) is not None

# Generated at 2022-06-24 12:46:07.380868
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:46:07.935462
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('', {})

# Generated at 2022-06-24 12:46:09.292340
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert ITVBTCCIE == i.__class__

# Generated at 2022-06-24 12:46:09.860750
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:46:18.762125
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url1 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-silverstone'
    test_url2 = 'http://www.itv.com/btcc/brands-hatch/races/races-2017-all-the-action-from-brands-hatch'
    ITVBTCCIE_instance = ITVBTCCIE()

    assert ITVBTCCIE_instance._match_id(test_url1) == 'btcc-2018-all-the-action-from-silverstone'
    assert ITVBTCCIE_instance._match_id(test_url2) == 'races-2017-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:46:20.656702
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()

# Generated at 2022-06-24 12:46:29.801289
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:46:31.048860
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    construct_test('ITVBTCCIE', ITVBTCCIE)

# Generated at 2022-06-24 12:46:40.738361
# Unit test for constructor of class ITVIE
def test_ITVIE():
	from urllib import urlopen
	from urlparse import urlparse
	from sys import modules
	from re import findall, sub
	from json import loads, dumps
	from os import getenv, mkdir, system

	modules['determine_ext'] = determine_ext
	modules['clean_html'] = clean_html
	modules['extract_attributes'] = extract_attributes
	modules['get_element_by_class'] = get_element_by_class
	modules['JSON_LD_RE'] = JSON_LD_RE
	modules['merge_dicts'] = merge_dicts
	modules['parse_duration'] = parse_duration
	modules['smuggle_url'] = smuggle_url
	modules['url_or_none'] = url_or_none


# Generated at 2022-06-24 12:46:42.299081
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._GEO_COUNTRIES[0] == 'GB'
    ITVIE

# Generated at 2022-06-24 12:46:43.215637
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'ITV'

# Generated at 2022-06-24 12:46:43.771106
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IT = ITVIE()

# Generated at 2022-06-24 12:46:49.509988
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert info_extractor._html_search_regex(ITVBTCCIE._VALID_URL,
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=6009076627001') == '6009076627001'

# Generated at 2022-06-24 12:46:53.441207
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    c = itv_ie.__class__
    c.__dict__ = ITVIE.__dict__
    print(itv_ie.__class__.__dict__)

# Generated at 2022-06-24 12:46:55.130366
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    # Should return URL in this case
    assert(ie)

# Generated at 2022-06-24 12:46:55.743482
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:46:56.077874
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:46:58.513012
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert isinstance(ie, ITVIE)

# Generated at 2022-06-24 12:47:00.350098
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('test', 'test')._real_extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:47:01.426555
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:47:03.501683
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVIE()).ie_key() == 'itv:itvbtcc'

# Generated at 2022-06-24 12:47:12.579432
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert x._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    y = ITVBTCCIE(itvBTCCUrlTemplate='http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')