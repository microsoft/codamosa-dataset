

# Generated at 2022-06-24 12:37:08.138806
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:37:11.419267
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert 'itv' in str(ie)
    assert 'ITV' in str(ie)
    assert ie.info_dict is not None


# Generated at 2022-06-24 12:37:13.192506
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE()
        assert False
    except Exception:
        assert True

# Generated at 2022-06-24 12:37:16.896293
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc = ITVBTCCIE()
    assert btcc._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert btcc.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:17.298023
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:37:20.802433
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btccie = ITVBTCCIE()
    assert itv_btccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:30.076621
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    temp = ITVBTCCIE(dict(url=url, geo_verification_headers={}))
    assert temp.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert temp.geo_verification_headers == {}
    assert temp._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:37:35.047249
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    inspect = ITVBTCCIE()
    inspect.construct_playlist_result(url, {'id': 'btcc-2018-all-the-action-from-brands-hatch'})

# Generated at 2022-06-24 12:37:35.626585
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:37:36.564664
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert x

# Generated at 2022-06-24 12:37:44.688514
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/brands-hatch-2018-btcc-race-3-action-replay'
    expected_brightcove_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=58094790590001'
    assert ITVBTCCIE(ITVBTCCIE.IE_NAME, {})._match_id('http://www.itv.com/btcc/races') == None
    assert ITVBTCCIE(ITVBTCCIE.IE_NAME, {})._match_id(test_url) == 'brands-hatch-2018-btcc-race-3-action-replay'

# Generated at 2022-06-24 12:37:55.661134
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    ITVIE._TESTS[0].update({
        'url': url,
        'only_matching': True,
    })
    ITVIE._download_webpage = ITVIE._download_webpage_test
    ITVIE._download_json = ITVIE._download_json_test
    ITVIE._download_json_test = ITVIE._download_json_test_static
    ITVIE._download_webpage_test = ITVIE._download_webpage_test_static
    # ITVIE._extract_m3u8_formats = ITVIE._extract_m3u8_formats_test
    # ITVIE._extract_m3u8

# Generated at 2022-06-24 12:37:59.018346
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    _ = ITVBTCCIE._match_id(url)
    # _real_extract(url) should be tested instead of __init__.


# Generated at 2022-06-24 12:38:03.971161
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012', {'geo_countries': [], 'geo_bypass_ip_blocks': []})._VALID_URL == ITVIE._VALID_URL


# Generated at 2022-06-24 12:38:13.873932
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:38:16.820590
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE().extract_info('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-24 12:38:22.505705
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.IE_NAME == 'itv:hub'
    assert ie.IE_DESC == 'ITV Hub'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-24 12:38:32.383873
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    btcc = ITVBTCCIE()
    btcc._downloader = None
    btcc._download_webpage = lambda *x: x
    assert btcc.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    result = btcc._real_extract(url)
    assert result['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert result['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert result

# Generated at 2022-06-24 12:38:33.412276
# Unit test for constructor of class ITVIE
def test_ITVIE():
    pass



# Generated at 2022-06-24 12:38:35.067429
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:38:37.720206
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/coronation-street/2a4731a0032?playlist=1'
    ie = ITVIE(url)
    assert ie.url == url

# Generated at 2022-06-24 12:38:39.742046
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE()._real_extract('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    except:
        raise AssertionError('Unit test failed')

# Generated at 2022-06-24 12:38:40.858976
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    temp = ITVBTCCIE()

# Generated at 2022-06-24 12:38:43.486818
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert obj.geo_countries() == ['GB']



# Generated at 2022-06-24 12:38:44.271242
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE



# Generated at 2022-06-24 12:38:46.491867
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:38:52.389222
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    c = ITVBTCCIE()
    r = c._real_extract(url)
    assert r['id'] == "btcc-2018-all-the-action-from-brands-hatch"
    assert r['title'] == "BTCC 2018: All the action from Brands Hatch"
    assert r['playlist'] != []

# Generated at 2022-06-24 12:39:00.710666
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():

    video_ids = [
        '5938126219001',
        '5938126219001',
        '5938126219001',
        '5938126219001',
        '5938126384001',
        '5938126384001',
        '5938126384001',
        '5938126384001',
        '5938126384001',
        '5938126294001',
        '5938126294001',
        '5938126294001',
        '5938126294001',
        '5938126294001',
        '5938081667001',
        '5938081667001',
        '5938081667001']

    for video_id in video_ids:
        ie = ITVBTCCIE()
        ie

# Generated at 2022-06-24 12:39:11.229100
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:39:14.097344
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(InfoExtractor).match_url('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:39:15.690288
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-24 12:39:19.348095
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Create ITVIE with certain url"""
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video = ITVIE().url_result(url)
    assert video is not None, "cannot create ITVIE with url %s" % url



# Generated at 2022-06-24 12:39:24.662662
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Some old videos are no longer available
    # That's why we can't test it as usual
    videoID = '5836703976001'
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    res = BrightcoveNewIE()._extract_brightcove_url(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % videoID, url)
    assert res == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s" % videoID

# Generated at 2022-06-24 12:39:35.353631
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    actual_result = ie._real_extract(url)
    expected_result = {'id': '2a4547a0012', 'ext': 'mp4', 'title': 'Liar - Series 2 - Episode 6',
                       'description': 'md5:d0f91536569dec79ea184f0a44cca089', 'series': 'Liar',
                       'season_number': 2, 'episode_number': 6}
    assert expected_result == actual_result


# Generated at 2022-06-24 12:39:39.065582
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test construction of class ITVIE
    ITVIE(InfoExtractor._downloader)._download_webpage('https://www.itv.com/hub/liar/2a4547a0012', None)

# Generated at 2022-06-24 12:39:44.222239
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    r = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert(r.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:39:46.232007
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test constructor of class ITVIE"""
    ITVIE("http://www.itv.com/hub/liar/2a4547a0012", {})

# Generated at 2022-06-24 12:39:57.267534
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test what happens when an ITVBTCCIE object is created and the
    # URL is valid
    t = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert t._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:40:00.602820
# Unit test for constructor of class ITVIE
def test_ITVIE():
	test = ITVIE()
	assert test._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
	assert test._GEO_COUNTRIES == ['GB']
    # to be added

# Generated at 2022-06-24 12:40:02.905842
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:07.816674
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:14.194339
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvIE = ITVIE( 'http://www.itv.com/hub/liar/2a4547a0012')
    assert itvIE is not None
    if not isinstance(itvIE, ITVIE):
        raise Exception ('ITVIE constructor returned unexpected object type')
    assert itvIE.video_id == '2a4547a0012'
    assert itvIE.url == 'http://www.itv.com/hub/liar/2a4547a0012'



# Generated at 2022-06-24 12:40:16.117109
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:40:22.288215
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor._valid_url("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch", ITVBTCCIE._VALID_URL)
    assert not info_extractor._valid_url("https://www.itv.com/hub/liar/2a4547a0012", ITVBTCCIE._VALID_URL)

# Generated at 2022-06-24 12:40:24.128638
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE(None, {})
    assert ie.__class__.__name__ == 'ITVIE'


# Generated at 2022-06-24 12:40:28.773574
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video = ITVIE()
    assert video.__class__.__name__ == 'ITVIE'
    assert video._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert video._GEO_COUNTRIES == ['GB']
    assert len(video._TESTS) == 4


# Generated at 2022-06-24 12:40:35.267673
# Unit test for constructor of class ITVIE
def test_ITVIE():
    iev = ITVIE()
    result = ITVIE._download_webpage('https://www.itv.com/hub/liar/2a4547a0012', '2a4547a0012')
    assert(result is not None)
    result = ITVIE._search_regex(r'(?s)(<[^>]+id="video"[^>]*>)', result, 'params')
    assert(result is not None)
    result = extract_attributes(result)
    assert(result is not None)
    result = result['data-video-playlist']
    assert(result is not None)
    result = result + '.json'
    assert(result is not None)

# Generated at 2022-06-24 12:40:37.677511
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    if ie:
        print("Success")
        return True
    return False

# Generated at 2022-06-24 12:40:41.045761
# Unit test for constructor of class ITVIE
def test_ITVIE():
    URL = 'http://www.itv.com/hub/liar/2a4547a0012'
    I = ITVIE(object)
    assert I._match_id(URL) == '2a4547a0012'

# Generated at 2022-06-24 12:40:44.202689
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor_test(ITVBTCCIE, 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:40:45.475535
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert(isinstance(ie, ITVBTCCIE))

# Generated at 2022-06-24 12:40:48.439988
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.suitable('https://www.itv.com/hub/liar/2a4547a0012')
    assert ITVIE.suitable('https://www.itv.com') == False



# Generated at 2022-06-24 12:40:49.033181
# Unit test for constructor of class ITVIE
def test_ITVIE():
  ie = ITVIE()

# Generated at 2022-06-24 12:40:51.902625
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._real_extract('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')

# Generated at 2022-06-24 12:40:57.016139
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:59.206490
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/tipping-point/2a4547a0032')


# Generated at 2022-06-24 12:41:00.504461
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    t = type(i)
    assert t is ITVIE

# Generated at 2022-06-24 12:41:09.377948
# Unit test for constructor of class ITVIE
def test_ITVIE():

    ITV_URL = 'https://www.itv.com/hub/emmerdale/2a1849a0045'
    videos = ITVIE().extract(ITV_URL)
    assert videos[0]['url'] == 'https://mcdn.itv.com/contents/15c6d92d-8d9e-4a6a-bf3a-1d8ec4dfcfc4/a46dccff-f6a8-4a7c-b2c6-7ca17b8e7837/h264/manifest.f4m'

# Generated at 2022-06-24 12:41:15.470080
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = ITVBTCCIE._TEST['url']
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ITVBTCCIE._match_id(url) == ITVBTCCIE._TEST['info_dict']['id']
    assert ITVBTCCIE._TEST['info_dict']['title'] == ITVBTCCIE._og_search_title(ITVBTCCIE._download_webpage(url, ITVBTCCIE._match_id(url)), fatal=False)

# Generated at 2022-06-24 12:41:21.047965
# Unit test for constructor of class ITVIE
def test_ITVIE():
    extra_info = {
        'title': 'Liar - Series 2 - Episode 6',
        'description': 'md5:d0f91536569dec79ea184f0a44cca089',
        'series': 'Liar',
        'season_number': 2,
        'episode_number': 6,
    }
    test_class = ITVIE('http://www.itv.com/hub/liar/2a4547a0012', 'Liar', extra_info)
    assert test_class.url == 'http://www.itv.com/hub/liar/2a4547a0012'
    assert test_class.video_id == '2a4547a0012'
    assert test_class.title is None
    assert test_class.description is None

# Generated at 2022-06-24 12:41:26.558116
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    # Need to check BRIGHTCOVE_URL_TEMPLATE, which is constructed
    # from the url_result method with the url_or_none argument
    # being the result of the smuggle_url method. So, just checking
    # the url_result method is sufficient.
    assert ie.url_result('btcc-2018-all-the-action-from-brands-hatch') == {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'btcc-2018-all-the-action-from-brands-hatch',
    }

# Generated at 2022-06-24 12:41:37.505960
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    extractor = ITVIE()
    extractor._match_id(url)
    webpage = extractor._download_webpage(url, '2a4547a0012', headers=extractor.geo_verification_headers())

# Generated at 2022-06-24 12:41:38.506801
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.__name__ == 'ITVBTCCIE'

# Generated at 2022-06-24 12:41:42.982270
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    obj = ITVBTCCIE()
    assert obj._VALID_URL == ITVBTCCIE._VALID_URL
    assert obj._TEST == ITVBTCCIE._TEST
    assert obj._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:41:54.376864
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    assert test._VALID_URL == ITVIE._VALID_URL
    assert test._TESTS == ITVIE._TESTS
    assert test.BRIGHTCOVE_URL_TEMPLATE == ITVIE.BRIGHTCOVE_URL_TEMPLATE
    assert test._real_extract == ITVIE._real_extract
    assert test._search_regex == ITVIE._search_regex
    assert test._parse_json == ITVIE._parse_json
    assert test._search_json_ld == ITVIE._search_json_ld
    assert test._html_search_meta == ITVIE._html_search_meta
    assert test._match_id == ITVIE._match_id
    assert test._download_json == ITVIE._download_json
    assert test._download_webpage == ITV

# Generated at 2022-06-24 12:41:55.300855
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'itv:hub'


# Generated at 2022-06-24 12:41:55.835966
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:41:57.937880
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:41:59.305330
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    foo = ITVBTCCIE()

# Generated at 2022-06-24 12:42:00.335153
# Unit test for constructor of class ITVIE
def test_ITVIE():
    a=ITVIE()

# Generated at 2022-06-24 12:42:03.966723
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:09.877172
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:12.100855
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('test_ITVIE', '2a4547a0012')

# Generated at 2022-06-24 12:42:21.187607
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    unit_test = ITVBTCCIE()
    assert unit_test._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert unit_test._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert unit_test._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert unit_test._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-24 12:42:31.380044
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = ITVBTCCIE._TEST['url']
    test_id = ITVBTCCIE._TEST['info_dict']['id']
    test_video_id = '5819534802001'
    test_re_video_id = r'data-video-id=["\']%s' % test_video_id
    itvbtccie = ITVBTCCIE()

    # Test whether it returns an instance of ITVBTCCIE
    assert isinstance(itvbtccie, ITVBTCCIE)

    # Test whether it return the same URL
    assert itvbtccie._match_id(test_url) == test_id

    webpage = itvbtccie._download_webpage(test_url, test_id)

    # Test whether it returns the video id

# Generated at 2022-06-24 12:42:34.831044
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    result = ie.suitable('foo')
    assert not result
    result = ie.suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert result


# Generated at 2022-06-24 12:42:37.662206
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE();
    assert ie._GEO_BYPASS is True
    assert ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:42:42.271696
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie.GEO_COUNTRIES
    assert ie.SUBTITLE_LANGS
    assert ie.extract('') is None
    assert ie.suitable('') is False

# Generated at 2022-06-24 12:42:46.952946
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    p = ITVBTCCIE(url)
    assert p.playlist_id == 'btcc-2018-all-the-action-from-brands-hatch'



# Generated at 2022-06-24 12:42:54.509502
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._GEO_COUNTRIES == ['GB']
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:43:02.589101
# Unit test for constructor of class ITVIE

# Generated at 2022-06-24 12:43:08.794467
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test the constructor of the BrightcoveIE"""
    l = ITVBTCCIE()
    e = l.extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert e['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert e['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-24 12:43:12.835399
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # Case 1: Test simple creation of ITVIE Object
    init = ITVIE()
    assert init.IE_NAME == 'itv'

    # Case 2: Test creation with input 
    init = ITVIE('')
    assert init.IE_NAME == 'itv'

# Generated at 2022-06-24 12:43:16.020234
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():

    ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

if __name__== "__main__":
    test_ITVBTCCIE()

# Generated at 2022-06-24 12:43:19.035702
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(object)
    assert ITVIE._VALID_URL == url


# Generated at 2022-06-24 12:43:25.934520
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert x._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:43:34.816555
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from youtube_dl.downloader.http import HttpFD

    itv = ITVIE()

# Generated at 2022-06-24 12:43:36.728470
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # given
    from ytdl.extractor.ITVIE import ITVIE
    instance = ITVIE()

    # then
    assert instance is not None

# Generated at 2022-06-24 12:43:38.626282
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE({})._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:43:39.387553
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i

# Generated at 2022-06-24 12:43:48.957149
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # Test for ITVIE constructor with ONLY ITV _VALID_URL
    itvIE = ITVIE(
        _VALID_URL=r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    )
    # Test if ITVIE constructor's value is successfuly set in _VALID_URL
    assert itvIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    # Test for ITVIE constructor's OTHER THAN _VALID_URL parameters
    # Test for _GEO_COUNTRIES
    assert itvIE._GEO_COUNTRIES == ['GB']
   

# Generated at 2022-06-24 12:43:51.789398
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:53.484429
# Unit test for constructor of class ITVIE
def test_ITVIE():
    c = ITVIE()
    c.challenge()
    assert c.entitlements
    assert c.device
    assert c.user
    assert c.variant_availability
    assert c.client

# Generated at 2022-06-24 12:43:54.744073
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    extractor = ITVBTCCIE()

# Generated at 2022-06-24 12:44:04.186198
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # To prevent failures with ITV's servers, we supply our own strings
    # to `_download_webpage`
    # In order to test this, we need to define a local class which
    # uses our own "downloader"
    class MyInfoExtractor(ITVIE):
        def _download_webpage(self, url, video_id):
            return self._get_testdata_file_contents('response.html')

        def _download_json(self, url, video_id, data, headers):
            return self._get_testdata_file_contents('playlist.json')

        def _real_extract(self, url):
            webpage = self._download_webpage(url, video_id)

# Generated at 2022-06-24 12:44:09.099928
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE()
    assert info.get_params() == {}
    assert info._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:44:17.931266
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = "2a4547a0012"

# Generated at 2022-06-24 12:44:22.067075
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ytb = ITVBTCCIE()
    assert ytb.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:44:23.148956
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:44:24.122911
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()
    return True


# Generated at 2022-06-24 12:44:32.367975
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccie = ITVBTCCIE()
    entries = itvbtccie._real_extract(url)
    print("=="*35)
    for entry in entries['entries']:
        print("entry['id']:%s" % entry['id'])
    print("=="*35)
    title = entries['title']
    print("title:%s" % title)

if __name__ == '__main__':
    test_ITVBTCCIE()

# Generated at 2022-06-24 12:44:36.522711
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test
    IT = ITVBTCCIE()
    assert IT.BRIGHTCOVE_URL_TEMPLATE
    assert IT._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:44:37.772496
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVExtractor = ITVIE()
    assert ITVExtractor


# Generated at 2022-06-24 12:44:48.317928
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ITVBTCCIE()._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:44:50.877783
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE()(url)

# Generated at 2022-06-24 12:44:51.913133
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE is not None

# Generated at 2022-06-24 12:44:58.933809
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    video = ITVBTCCIE()
    res = video.construct_url(video, "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert res == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5723475510001"

# Generated at 2022-06-24 12:45:05.757717
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # If ITVBTCCIE is changed, please make sure the result of
    # this test is still correct, or update the test if necessary.
    # Because ITVBTCCIE is very simple, it's probably best
    # to just return this function.
    itvbtccie = ITVBTCCIE()
    assert (
        ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE ==
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:45:16.240652
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE._build_brightcove_urls(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE,
        '5830406619001', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')[0]

# Generated at 2022-06-24 12:45:17.831489
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("test_ITVIE")


# Generated at 2022-06-24 12:45:30.229618
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITV_TEST_URL = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITV_TEST_VIDEO_ID = '2a4547a0012'
    ITV_TEST_SERIES = 'Liar'
    ITV_TEST_SEASON_NUMBER = 2
    ITV_TEST_EPISODE_NUMBER = 6
    ITV_TEST_TITLE = 'Liar - Series 2 - Episode 6'
    ITV_TEST_DESCRIPTION = 'md5:d0f91536569dec79ea184f0a44cca089'

    extractor = ITVIE()
    info =  extractor.extract(ITV_TEST_URL)

    assert info['id'] == ITV_TEST_VIDEO_ID
    assert info['series'] == ITV_T

# Generated at 2022-06-24 12:45:30.869012
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:45:33.224967
# Unit test for constructor of class ITVIE
def test_ITVIE():
    a = ITVIE(None)._real_extract("https://www.itv.com/hub/liar/2a4547a0012")
    print(a)

# Generated at 2022-06-24 12:45:38.388746
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    class_ = ITVBTCCIE
    args = [url]
    expected = {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'BTCC 2018: All the action from Brands Hatch',
    }
    return class_(*args), expected


# Generated at 2022-06-24 12:45:50.127085
# Unit test for constructor of class ITVIE
def test_ITVIE():
    result = ITVIE()
    assert ITVIE._VALID_URL == "https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)"
    assert ITVIE._GEO_COUNTRIES == ["GB"]

# Generated at 2022-06-24 12:45:50.712882
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:45:59.062085
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = ITVBTCCIE._TEST['info_dict']['id']
    playlist_mincount = ITVBTCCIE._TEST['playlist_mincount']
    info_dict = ITVBTCCIE._TEST['info_dict']
    test_dict = {'url': url, 'playlist_id': playlist_id, 'playlist_mincount': playlist_mincount, 'info_dict': info_dict}
    x = ITVBTCCIE()
    x._downloader = test_dict
    test_dict.update({'extractor': x})
    assert ITVBTCCIE._TEST == test_dict

# Generated at 2022-06-24 12:46:00.685711
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('', 'https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:46:11.053320
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    if ie is None:
        assert False, 'ITVBTCCIE constructor is none'
    else:
        assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s', 'BRIGHTCOVE_URL_TEMPLATE does not match'

# Generated at 2022-06-24 12:46:13.379083
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    print(info_extractor.BRIGHTCOVE_URL_TEMPLATE)



# Generated at 2022-06-24 12:46:17.023433
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:26.656233
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Checks if ITVIE's constructor can properly assign ITVIE's instance variables
    itvie = ITVIE()

    instanceVariable_itvie = [ '_VALID_URL',
                               '_TESTS',
                               '_GEO_COUNTRIES',
                               'BRIGHTCOVE_URL_TEMPLATE',
                               'IE_NAME',
                               '_NETRC_MACHINE',
                               '_GEO_BYPASS',
                               '_GEO_COUNTRIES',
                               '_GEO_IP_BLOCKS']
    # Assigns the variable 'instanceVariable_itvbtccie' the instance variable names of ITVBTCCIE
    instanceVariable_itvbtccie = sorted(list(itvie.__dict__.keys()))
    # Test if 'instance

# Generated at 2022-06-24 12:46:28.963905
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(ITVBTCCIE._downloader)._real_extract(ITVBTCCIE._TEST['url'], ITVBTCCIE._TEST['name'])

# Generated at 2022-06-24 12:46:38.701214
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    example_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    expected_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5816144839001'

    # Constructor of class ITVBTCCIE
    ie = ITVBTCCIE.ie_key()(example_url)

    # Test ie_key
    eq_(ie.ie_key(), 'ITVBTCC')

    # Test url_result
    eq_(ie.url_result(example_url).url, example_url)

    # Test _valid_url
    eq_(ie._valid_url(example_url, 'ITVBTCC'), expected_url)



# Generated at 2022-06-24 12:46:40.285035
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:46:45.192590
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Tested using the following URL
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    asser_true(ITVBTCCIE.suitable(url))
    asser_false(ITVBTCCIE('test').suitable(url))
    asser_true(ITVBTCCIE('test').suitable(url))

# Generated at 2022-06-24 12:46:47.522167
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_class = ITVBTCCIE(url)

    assert test_class.url == url


# Generated at 2022-06-24 12:46:51.239286
# Unit test for constructor of class ITVIE
def test_ITVIE():
    my_itv = ITVIE()
    assert my_itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:46:52.808991
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()

# Generated at 2022-06-24 12:46:55.735872
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')


# Generated at 2022-06-24 12:46:56.381621
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._ITVIE()

# Generated at 2022-06-24 12:47:00.910809
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    expected = ITVBTCCIE._TEST
    result = ITVBTCCIE._real_extract(ITVBTCCIE(), url)
    assert(result['title'] == expected['title'])
    assert(result['id'] == expected['id'])

# Generated at 2022-06-24 12:47:02.311150
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE()
        assert True
    except:
        assert False

# Generated at 2022-06-24 12:47:04.221568
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    # Nothing to do


# Generated at 2022-06-24 12:47:12.846785
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'
    ITVExtractor = ITVIE()
    assert ITVExtractor._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVExtractor._GEO_COUNTRIES == ['GB']