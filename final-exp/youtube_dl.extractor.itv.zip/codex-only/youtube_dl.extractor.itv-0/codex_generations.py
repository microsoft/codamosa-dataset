

# Generated at 2022-06-24 12:37:04.967986
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    print(itv)



# Generated at 2022-06-24 12:37:07.091350
# Unit test for constructor of class ITVIE
def test_ITVIE():
	# Is this an instance of ITVIE class
	assert isinstance(ITVIE(), ITVIE)
	# Is this an instance of ITVBTCCIE class
	assert isinstance(ITVBTCCIE(), ITVBTCCIE)

# Generated at 2022-06-24 12:37:08.783215
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from . import _test_cases
    for _test_case in _test_cases:
        assert ITVBTCCIE().extract(_test_case)

# Generated at 2022-06-24 12:37:12.426077
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:18.671916
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = ITVIE._match_id(url)
    webpage = ITVIE._download_webpage(url, video_id)
    params = extract_attributes(ITVIE._search_regex(r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params'))

    ios_playlist_url = params.get('data-video-playlist') or params['data-video-id']
    hmac = params['data-video-hmac']
    headers = ITVIE.geo_verification_headers()

# Generated at 2022-06-24 12:37:24.207721
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    unit_test = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert unit_test._TEST['url'] == unit_test._VALID_URL
    assert unit_test._TEST['info_dict'] == unit_test._real_extract(unit_test._TEST['url'])['entries'][0]['url']

# Generated at 2022-06-24 12:37:24.773112
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:37:28.155932
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    # Check that constructor creates an instance of the correct class
    assert isinstance(ie, ITVBTCCIE)


# Generated at 2022-06-24 12:37:29.003858
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()
    BrightcoveNewIE()

# Generated at 2022-06-24 12:37:39.533254
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    IE = ITVIE()
    assert(IE._match_id('...') == None)
    assert(IE._match_id(url) == '2a4547a0012')
    webpage = IE._download_webpage(url, '2a4547a0012')
    params = extract_attributes(IE._search_regex(
        r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params'))
    assert(params is not None)
    assert('data-video-playlist' in params)
    assert('data-video-id' in params)
    assert('data-video-hmac' in params)


# Generated at 2022-06-24 12:37:41.297125
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test for constructor of class ITVIE
    ie = ITVIE()
    assert ie.__class__.__name__ == 'ITVIE'

# Generated at 2022-06-24 12:37:46.198417
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    return True

# Generated at 2022-06-24 12:37:55.272098
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    test_url_res = "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5793277067001"
    url = ITVBTCCIE._real_extract(ITVBTCCIE(), test_url)
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % "5793277067001" == url['entry_data']['url_transparent']

# Generated at 2022-06-24 12:37:58.299922
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:38:10.435237
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:38:17.335456
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvIE = ITVIE()
    assert itvIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itvIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:38:25.546141
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Unit test for class ITVBTCCIE."""
    # Test with a TV show that has an episode.
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    playlist_id = "btcc-2018-all-the-action-from-brands-hatch"
    class_object = ITVBTCCIE()
    assert class_object._match_id(url) == playlist_id
    assert class_object._real_extract(url)

# Generated at 2022-06-24 12:38:29.220881
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test for constructor of class ITVBTCCIE"""
    from . import ITVBTCCIE
    instance = ITVBTCCIE.ITVBTCCIE(ITVBTCCIE.ITVBTCCIE._create_ytdl_instance())
    assert instance is not None

# Generated at 2022-06-24 12:38:36.345753
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    '''
    Test the constructor of ITVBTCCIE.
    :return:
    '''
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:38:45.598517
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    ie_obj = ITVBTCCIE(url, True, "")
    # Test that the constructor set the correct properties of the object
    assert ie_obj._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:38:49.386776
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-24 12:38:58.693982
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ie._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ie

# Generated at 2022-06-24 12:39:03.614976
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._VALID_URL(url) is True
    assert ITVBTCCIE._TEST['url'] == url
    return None

# Generated at 2022-06-24 12:39:08.251935
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    test_info = ITVIE()._real_extract(test_url)
    assert test_info == {'id': '2a5159a0034',
                         'title': 'James Martin\'s Saturday Morning',
                         'ext': 'mp4',
                         'description': 'md5:d0f91536569dec79ea184f0a44cca089',
                         'series': 'James Martin\'s Saturday Morning'}

# Generated at 2022-06-24 12:39:16.173477
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert result._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:39:17.394007
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHT_RED_URL is None

# Generated at 2022-06-24 12:39:26.153407
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # The URL is important; the constructor will fail if the URL does not match
    # the above regular expression
    yt = ITVBTCCIE(ITVBTCCIE._create_get_url_instance(None, "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"))
    assert yt.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert yt._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert yt._TEST

# Generated at 2022-06-24 12:39:28.863232
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('itv://video/2a4547a0012')


# Generated at 2022-06-24 12:39:39.567444
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ie._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ie._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert ie._TEST['playlist_mincount'] == 9

# Generated at 2022-06-24 12:39:44.411875
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.NAME == 'itv'
    assert ie.IE_NAME == 'itv:hub'
    assert ie._VALID_URL == ITVIE._VALID_URL
    assert ie._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert ie._TESTS == ITVIE._TESTS



# Generated at 2022-06-24 12:39:50.387532
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    def construct_ITVBTCCIE(url):
        xt = ITVBTCCIE(
            downloader=None,
            download_mode='test-file',
            test=True,
            expected_warnings=['URL could not be fetched']
        )
        xt._prepare_url(url)
        return xt


# Generated at 2022-06-24 12:39:59.761696
# Unit test for constructor of class ITVIE
def test_ITVIE():
    _ITVIE_data = {
      '_type': 'url',
      'url': 'https://www.itv.com/hub/liar/2a4547a0012',
      'ie_key': 'ITV',
      'id': '2a4547a0012',
      'extractor': 'ITV'
    }
    itv = ITVIE(_ITVIE_data)
    assert itv._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itv.name == 'ITV'
    assert itv._GEO_COUNTRIES == ['GB']
    assert itv.IE_NAME == 'itv'
    assert itv.IE_

# Generated at 2022-06-24 12:40:06.152379
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:40:08.073950
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie != None


# Generated at 2022-06-24 12:40:12.928928
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test extract video id from ITV.com video page
    video_id = 'c00169z0'
    url = 'http://www.itv.com/itvplayer/video/{0}'.format(video_id)
    ITVIE.IE_NAME = 'itv'
    assert ITVIE(ITVIE.create_ie())._match_id(url) == video_id

# Generated at 2022-06-24 12:40:19.484776
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = 'https://www.itv.com/hub/peston-on-sunday/2a9232a0014'
    test_url2 = 'https://www.itv.com/hub/liar/2a4547a0012'
    test_obj = ITVIE()
    assert test_obj._match_id(test_url) == '2a9232a0014'
    assert test_obj._match_id(test_url2) == '2a4547a0012'

# Generated at 2022-06-24 12:40:22.815872
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:40:25.679775
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:28.192163
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        assert ITVBTCCIE(None)._match_id(None) == None
    except:
        print("Test: ITVBTCCIE, constructor exception")
        assert False


# Generated at 2022-06-24 12:40:29.520456
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_urls = ["https://www.itv.com/hub/liar/2a4547a0012"]
    for url in test_urls:
        ITVIE(url)

# Generated at 2022-06-24 12:40:30.614518
# Unit test for constructor of class ITVIE
def test_ITVIE():
    if ITVIE() != ITVIE():
        print("Not Singleton")

# Generated at 2022-06-24 12:40:34.810567
# Unit test for constructor of class ITVIE
def test_ITVIE():
    t = ITVIE(ITVExtractor._downloader)
    assert(t._VALID_URL == ITVIE._VALID_URL)
    assert(t._downloader == ITVExtractor._downloader)


# Generated at 2022-06-24 12:40:37.986630
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(url)

# Generated at 2022-06-24 12:40:45.476493
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    IE = ITVBTCCIE()
    playlist_id = IE._match_id(url)
    obj = IE._real_extract(url)
    assert obj['id'] == playlist_id
    assert obj['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert obj['entries'][0]['id'] == '5702098122001'

# Generated at 2022-06-24 12:40:46.157841
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie

# Generated at 2022-06-24 12:40:53.268645
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    webpage = '<html></html>'
    expected_instance = ITVBTCCIE(ITVBTCCIE._downloader, {})._real_extract(url)
    actual_instance = ITVBTCCIE(ITVBTCCIE._downloader, {})
    actual_instance.initialize()
    actual_instance.report_download_webpage(url, url, webpage)
    actual_instance._real_extract(url)
    assert expected_instance == actual_instance

# Generated at 2022-06-24 12:40:57.073480
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:41:00.709267
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.ITVBTCCIE_BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:09.730408
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    testObj = ITVBTCCIE()
    assert testObj._TEST['url'] == url
    assert testObj._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert testObj._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert testObj._TEST['playlist_mincount'] == 9

# Generated at 2022-06-24 12:41:10.956846
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE({}).IE_NAME == 'itv'

# Generated at 2022-06-24 12:41:14.225353
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Assert that all the test cases pass
    for i in ITVBTCCIE._TEST['playlist']:
        assert 'brightcove.com' in i, 'check if the template is used'

# Generated at 2022-06-24 12:41:15.421739
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE().suite()



# Generated at 2022-06-24 12:41:24.656743
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Unit test for constructor of class ITVIE
    """
    ITVIE_object = ITVIE('http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    assert(ITVIE_object._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')
    assert(ITVIE_object._TESTS[2]['url'] == 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')

# Generated at 2022-06-24 12:41:25.604221
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE != ITVBTCCIE

# Generated at 2022-06-24 12:41:31.286488
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:41:34.722884
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE.suitable(url)
    assert ITVBTCCIE(url)

# Generated at 2022-06-24 12:41:36.088096
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert isinstance(ITVIE(), ITVIE)


# Generated at 2022-06-24 12:41:37.191906
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.has('ITVIE')


# Generated at 2022-06-24 12:41:46.237108
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()
    assert(IE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')

# Generated at 2022-06-24 12:41:47.606592
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:41:50.076980
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE.IE_NAME, ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE).IE_NAME == ITVBTCCIE.IE_NAME

# Generated at 2022-06-24 12:41:51.351197
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._constructor()

# Generated at 2022-06-24 12:41:55.959382
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    brightcove_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    i = ITVBTCCIE()
    i.BRIGHTCOVE_URL_TEMPLATE = brightcove_url
    i.BRIGHTCOVE_URL_TEMPLATE % '5766770136001'

# Generated at 2022-06-24 12:41:59.698420
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Unit test for constructor of class ITVIE
    """
    # Test for case with empty params
    ITVIE(InfoExtractor())._extract_playlist('params')


# Generated at 2022-06-24 12:42:03.490863
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert 'BTCC' in ITVBTCCIE._valid_url(
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        ITVBTCCIE()
    )


# Generated at 2022-06-24 12:42:06.032759
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

test_ITVIE()

# Generated at 2022-06-24 12:42:17.865121
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_res = ITVBTCCIE._TEST
    itv_btcc_ie = ITVBTCCIE()
    itv_btcc_ie._download_webpage = lambda url, id: test_res['url']
    itv_btcc_ie._og_search_title = lambda webpage, fatal: test_res['info_dict']['title']
    itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    itv_btcc_ie._match_id = lambda url: test_res['url']
    itv_btcc_ie._download_webpage = lambda url, id: test_res['url']
    itv

# Generated at 2022-06-24 12:42:18.505395
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:42:29.710536
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    url_template = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    json_ld = itvbtccie._extract_json_ld(url, playlist_id)
    # Check that extract_json_ld returns a json object
    assert(len(json_ld) > 0)
    # Check that the playlist id matches the id parsed from the url

# Generated at 2022-06-24 12:42:30.357075
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:42:34.984686
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test ITVIE constructor arguments."""
    ie = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    assert ie.url == "http://www.itv.com/hub/liar/2a4547a0012"
    assert ie.GEOPROBE_URL == "http://www.itv.com/probe"
    assert ie.GEOCOUNTRIES == ['GB']

# Generated at 2022-06-24 12:42:39.495101
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()

    assert ie.BRIGHTCOVE_URL_TEMPLATE =='http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:41.238851
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    global ITVBTCCIE
    ITVBTCCIE


# Generated at 2022-06-24 12:42:49.727018
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    obj = ITVBTCCIE(
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert obj._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == (
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:42:58.252130
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvBTCCIE = ITVBTCCIE()
    assert(itvBTCCIE._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert(itvBTCCIE._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch')
    assert(itvBTCCIE._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch')
    assert(itvBTCCIE._TEST['playlist_mincount'] == 9)

# Generated at 2022-06-24 12:42:59.441037
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(InfoExtractor())

# Generated at 2022-06-24 12:43:01.518044
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestITVBTCCIE))
    return suite


# Generated at 2022-06-24 12:43:08.615164
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    # test case 1
    expected = "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5795938456001"
    test = ITVBTCCIE()
    actual = test.BRIGHTCOVE_URL_TEMPLATE % '5795938456001'
    assert actual == expected, actual

# Generated at 2022-06-24 12:43:12.638183
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie_obj = ITVIE()
    assert ie_obj._VALID_URL == "https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)"


# Generated at 2022-06-24 12:43:20.501934
# Unit test for constructor of class ITVIE
def test_ITVIE():
    TV_URL = "http://www.itv.com/hub/take-me-out/1a1384a0007"
    ie = ITVIE()
    assert ie._VALID_URL == ITVIE._VALID_URL
    assert ie._TESTS == ITVIE._TESTS
    assert ie._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ITVIE.BRIGHTCOVE_URL_TEMPLATE
    assert ie._real_extract(TV_URL) is not None
    assert ie._match_id(TV_URL) == "1a1384a0007"

# Generated at 2022-06-24 12:43:22.697824
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE()
        ITVBTCCIE()
        _ = True
    except:
        _ = False
    assert _

# Generated at 2022-06-24 12:43:28.407881
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccIE = ITVBTCCIE()

    title = itvbtccIE._og_search_title(webpage = None)
    assert title is None

    title = itvbtccIE._og_search_title(webpage = '<html><head><meta property="og:title" content="abc"></head></html>')
    assert title == 'abc'

# Generated at 2022-06-24 12:43:34.815896
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_verification_headers() == {
        'Accept': 'application/vnd.itv.vod.playlist.v2+json',
        'Content-Type': 'application/json',
        'hmac': '514BBF7D5B5B9E7C8F5FA599BA7C5D08',
        'x-ipcountry': 'GB',
        'x-itv-product': 'itvweb',
        'x-itv-product-version': '4.1',
        'x-itv-show-id': '',
    }

# Generated at 2022-06-24 12:43:35.712695
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()

# Generated at 2022-06-24 12:43:40.449161
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class TestITVBTCCIE(ITVBTCCIE):
        def _download_webpage(self, *args, **kwargs):
            return '2017-11-12'
    inst = TestITVBTCCIE()
    assert inst._real_extract('url')["id"] == 'btcc-2017-11-12'

# Generated at 2022-06-24 12:43:49.816354
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    _ITVBTCCIE = ITVBTCCIE()
    assert _ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert _ITVBTCCIE._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    assert _ITVBTCCIE.BR

# Generated at 2022-06-24 12:43:50.624184
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE is ITVBTCCIE



# Generated at 2022-06-24 12:43:54.822974
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    obj = ITVBTCCIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert obj._match_id(url) == playlist_id

# Generated at 2022-06-24 12:43:55.826594
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE.playlist_mincount = 1

# Generated at 2022-06-24 12:44:02.520508
# Unit test for constructor of class ITVIE
def test_ITVIE():
    m = ITVIE()
    assert m.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert m.prefer_video_id is True
    assert m.geo_verification_headers() == {'x-forwarded-for': '151.231.208.55'}
    assert m.geo_bypass_country == 'GB'


# Generated at 2022-06-24 12:44:05.179224
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    infoExtractor = ITVBTCCIE()
    assert infoExtractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:44:07.866139
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # just to check if it works.  (At the time of writing, it does.)
    # No need to run it on travis-ci.
    x = ITVBTCCIE()

# Generated at 2022-06-24 12:44:14.644547
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test instance creation
    a = ITVBTCCIE()
    # Test class definition attributes
    assert(a._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)')
    assert(a.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:44:17.360926
# Unit test for constructor of class ITVIE
def test_ITVIE():
    extractor = ITVIE()
    assert extractor._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:44:18.544939
# Unit test for constructor of class ITVIE
def test_ITVIE():
    return ITVIE(ITVEmbedIE.extractor_key(), "", {})

# Generated at 2022-06-24 12:44:19.612205
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE.__init__()

# Generated at 2022-06-24 12:44:25.362975
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    result = ITVBTCCIE()._real_extract(url)
    assert result['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert len(result['entries']) == 9

# Generated at 2022-06-24 12:44:27.630241
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST == ITVBTCCIE()._TEST

# Generated at 2022-06-24 12:44:29.720552
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['url'] == ITVBTCCIE(None)._VALID_URL

# Generated at 2022-06-24 12:44:30.356101
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()

# Generated at 2022-06-24 12:44:32.420147
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-24 12:44:33.860025
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():

    assert ITVBTCCIE(ITVBTCCIE.IE_NAME, None)._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:44:36.478130
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class test:
        def __init__(self, value):
            self.value = value
    t = test(5)
    ITVIE(t, t)

# Generated at 2022-06-24 12:44:40.318205
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    sample_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie.extract(sample_url) is not None

# Generated at 2022-06-24 12:44:41.232324
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-24 12:44:51.572697
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:45:02.585924
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()

    URL = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccie._download_webpage = lambda *args, **kwargs: ''
    itvbtccie._og_search_title = lambda *args, **kwargs: ''
    result = itvbtccie._real_extract(URL)

    assert result['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert result['url'] == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5837404713001'

# Generated at 2022-06-24 12:45:09.722906
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.suitable('https://www.itv.com/hub/liar/2a4547a0012') is True
    assert ITVIE.suitable('https://www.itv.com/hub/liar/2a4547a0012/') is True
    assert ITVIE.suitable('https://www.itv.com/hub/liar/2a4547a0012?autoplay=true') is True
    assert ITVIE.suitable('https://www.itv.com/hub/liar/') is False
    assert ITVIE.suitable('https://www.itv.com/hub/') is False

# Generated at 2022-06-24 12:45:13.204347
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    inst = ITVIE()
    assert inst._match_id(url) == '2a4547a0012'
    assert inst.suitable(url) == True

# Generated at 2022-06-24 12:45:22.748856
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test class ITVBTCCIE"""
    from .ITVIE import ITVIE
    from .brightcove import BrightcoveNewIE
    from ..utils import parse_duration

    test_ITVBTCCIE = ITVBTCCIE()
    test_ITV = ITVIE()
    test_BrightcoveNew = BrightcoveNewIE()

    assert "HTTP Error 403" in test_ITVBTCCIE._real_extract(test_ITVBTCCIE._TEST['url'])[1]['entries'][0]['ie_key']
    assert "unit test" == test_ITVBTCCIE._real_extract(test_ITVBTCCIE._TEST['url'])[1]['entries'][0]['title']
    assert "itv:btcc" in test_ITVBTCCIE._

# Generated at 2022-06-24 12:45:23.527860
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:45:25.021056
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:45:26.055657
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()
    

# Generated at 2022-06-24 12:45:31.901870
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
  import re
  # Test 1:
  # Extract playlist from example webpage:
  #  http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch
  # This webpage contains 9 videos
  extractor = ITVBTCCIE()

# Generated at 2022-06-24 12:45:32.381780
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:45:35.945783
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Just make sure the class constructor does not crash
    # as it might if the tests are run for the first time
    # without the test_utils.py file in the parent directory
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:45:47.555960
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:45:49.361193
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.ie_key() == 'ITVBTCC'

# Generated at 2022-06-24 12:45:51.029588
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE({})
    assert isinstance(itv_ie, ITVIE)


# Generated at 2022-06-24 12:45:53.468013
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://itv.com/hub/liar/2a4547a0012'
    ITVIE()._real_extract(url)

# Generated at 2022-06-24 12:45:53.943049
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:45:55.227328
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test the constructor
    assert ITVIE('1') is not None


# Generated at 2022-06-24 12:46:01.676619
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvIE = ITVIE()
    assert itvIE.url_result('http://redirector.cdn.theplatform.com/storage/1yF8UdleGj3q', 'redirector.cdn.theplatform.com')
    assert itvIE.url_result('https://redirector.cdn.theplatform.com/storage/xDKkNNZufgf9', 'redirector.cdn.theplatform.com')

# Generated at 2022-06-24 12:46:04.773728
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Video of the afore-mentioned URL.
    ITVIE(None)._real_extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:46:06.307216
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor


# Generated at 2022-06-24 12:46:08.753738
# Unit test for constructor of class ITVIE
def test_ITVIE():
    re_obj = ITVIE.IE_NAME
    assert re_obj.match('itv')
    assert re_obj.match('ITV')


# Generated at 2022-06-24 12:46:12.017527
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:16.055735
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ydl = ITVBTCCIE()
    assert ydl._VALID_URL.name == "ITVBTCCIE"
    assert ydl._TEST["url"] == "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"

# Generated at 2022-06-24 12:46:16.887787
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv

# Generated at 2022-06-24 12:46:26.517391
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    entries = ITVBTCCIE._build_entries("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert len(entries) == 9
    assert entries[0].url == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5808145391001"
    assert entries[0].video_id == '5808145391001'
    assert entries[8].url == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5808150431001"
    assert entries[8].video_id == '5808150431001'

# Generated at 2022-06-24 12:46:33.482758
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from ..utils import ExtractorError
    c = ITVBTCCIE()
    assert c._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert c._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    assert c.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:46:37.594393
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(IE_NAME, True).suitable(url)
    ITVBTCCIE(IE_NAME, True).extract(url)

# Generated at 2022-06-24 12:46:40.681166
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE(0)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:43.591525
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:46:46.744861
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Simple test to check if constructor of ITVBTCCIE works
    p = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    p.to_screen()

# Generated at 2022-06-24 12:46:47.826419
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """ Test that ITVIE constructor creates the correct object structure. """
    ITVIE('')

# Generated at 2022-06-24 12:46:49.248980
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE(None)
    except Exception as e:
        assert e

# Generated at 2022-06-24 12:46:55.533840
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
# Check that the constructor object has the correct attributes.
# This test assumes that the URL of the object is
# 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE = ITVBTCCIE()
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:46:59.760466
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
# enddef test_ITVBTCCIE()


# Generated at 2022-06-24 12:47:10.562129
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    itv = ITVIE()
    assert(itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')
    assert(itv._GEO_COUNTRIES == ['GB'])
    assert(itv._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012')
    assert(itv._TESTS[0]['info_dict']['id'] == '2a4547a0012')