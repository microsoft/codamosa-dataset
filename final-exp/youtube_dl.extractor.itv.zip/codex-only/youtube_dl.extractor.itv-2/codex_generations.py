

# Generated at 2022-06-24 12:37:09.049529
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    iTvBTCCIE = ITVBTCCIE('', ITVBTCCIE._VALID_URL)
    assert iTvBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:11.501771
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.IE_NAME == 'itv:hub'

# Generated at 2022-06-24 12:37:16.220519
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:37:19.113687
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    res = ITVBTCCIE()
    assert res._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:37:20.424616
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
  # Ensure class ITVBTCCIE is initialised
  assert ITVBTCCIE

# Generated at 2022-06-24 12:37:24.766072
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:32.806039
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Test instantiation of class ITVIE().
    """
    class test_ITVIE(ITVIE):
        """
        Test ITVIE class.
        """
        def _download_json(self, *args, **kwargs):
            """
            Mock download_json method.
            """
            return 'didnt use super class download_json'

        def _extract_m3u8_formats(self, *args, **kwargs):
            """
            Mock extract_m3u8_formats method.
            """
            return 'didnt use super class extract_m3u8_formats'

    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-24 12:37:37.509515
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class TestITVBTCCIE(ITVBTCCIE):
        def _download_webpage(self, url, video_id):
            return ''

    assert TestITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:37:38.481578
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IE = ITVBTCCIE()

# Generated at 2022-06-24 12:37:39.652287
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btccie = ITVBTCCIE()
    assert btccie._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:37:43.168226
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"

# Generated at 2022-06-24 12:37:45.691620
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    ITVIE()._real_extract(url)

# Generated at 2022-06-24 12:37:47.726385
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE('abc')
    assert ie.geo_countries == ITVIE._GEO_COUNTRIES

# Generated at 2022-06-24 12:37:58.190378
# Unit test for constructor of class ITVIE

# Generated at 2022-06-24 12:38:07.391750
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Test ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    """
    ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")._real_extract("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-24 12:38:12.892339
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE is not 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:38:24.662058
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Example of a video
    playlist_url = 'https://www.itv.com/hub/liar/2a4547a0012#player'
    subtitle_url = 'https://url/to/subtitles.vtt'
    
    itvie = ITVIE(None, ITVIE._VALID_URL)
    itvie.initialize_geo_bypass({'countries': {'GB'}})
    
    # Custom function to replace _download_webpage
    def _download_webpage_test(self, url, video_id):
        assert url == 'https://www.itv.com/hub/liar/2a4547a0012'
        assert video_id == '2a4547a0012'

# Generated at 2022-06-24 12:38:26.357025
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert isinstance(instance, ITVBTCCIE)

# Generated at 2022-06-24 12:38:28.097712
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    with ITVBTCCIE() as ie:
        assert ie.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-24 12:38:35.703157
# Unit test for constructor of class ITVIE
def test_ITVIE():
    my_obj = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert my_obj._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert my_obj._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:38:38.316253
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(ITVIE._downloader)._real_initialize(url)

# Generated at 2022-06-24 12:38:40.254772
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:38:41.776041
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test instantiation of ITVBTCCIE constructor
    assert ITVBTCCIE is not None

# Generated at 2022-06-24 12:38:49.088776
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test itv.co.uk video
    test = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert test.url == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert test.video_id == '2a4547a0012'
    assert test.title == 'Liar - Series 2 - Episode 6'
    # Test itv.com video
    test = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert test.url == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert test.video_id == '2a4547a0012'

# Generated at 2022-06-24 12:38:49.660083
# Unit test for constructor of class ITVIE
def test_ITVIE():
    pass

# Generated at 2022-06-24 12:38:58.878230
# Unit test for constructor of class ITVIE
def test_ITVIE():
	# expected outputs
	url = "https://www.itv.com/hub/liar/2a4547a0012"
	video_id = "2a4547a0012"
	expected_output = "Liar - Series 2 - Episode 6"
	expected_output2 = "md5:d0f91536569dec79ea184f0a44cca089"
	expected_output3 = "Liar"
	expected_output4 = 2
	expected_output5 = 6

	# actual output
	ie = ITVIE()
	actual_output = ie._real_extract(url)
	actual_output2 = actual_output['description']
	actual_output3 = actual_output['series']
	actual_output4 = actual_output['season_number']

# Generated at 2022-06-24 12:39:06.827190
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012').video_id == '2a4547a0012'
    ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    ITVIE('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')

# Generated at 2022-06-24 12:39:14.159327
# Unit test for constructor of class ITVIE
def test_ITVIE():
    p = ITVIE()
    # test if _VALID_URL is the prefix of URL
    assert p._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    
    # test if _TESTS['url'] is the URL
    assert p._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    
    

# Generated at 2022-06-24 12:39:15.689292
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor_test(ITVBTCCIE)

# Generated at 2022-06-24 12:39:19.684936
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url1 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    result1 = ITVBTCCIE()
    result1._real_extract(test_url1)
    assert len(result1.entries) == 9

# Generated at 2022-06-24 12:39:21.460422
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012', {})

# Generated at 2022-06-24 12:39:26.187075
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    _obj = ITVBTCCIE(url)
    assert(_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:39:38.373916
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:39:41.106327
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(url)

# Generated at 2022-06-24 12:39:44.461486
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._downloader.params['geo_ip_blocks'] == [
        '193.113.0.0/16', '54.36.162.0/23', '159.65.16.0/21'
    ]

# Generated at 2022-06-24 12:39:45.749282
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE._downloader)

# Generated at 2022-06-24 12:39:46.327235
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:39:54.822359
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    module = get_extractor_module('ITVBTCCIE')
    assert isinstance(module, ITVBTCCIE)
    assert module.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert module.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:58.541046
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ie.playlist_id == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:40:05.333433
# Unit test for constructor of class ITVIE
def test_ITVIE():
    crid = '2a4547a0012'
    data = ITVIE()._real_extract('https://www.itv.com/hub/liar/%s'%crid)
    assert data['title']=='Liar - Series 2 - Episode 6'
    assert data['id']==crid
    assert 'Liar' in data['description']
    assert data['description'].count('\n')==2
    assert data['series']=='Liar'
    assert data['episode_number']==6
    assert data['season_number']==2
    assert len(data['formats'])==3
    assert len(data['subtitles']['en'])==1
    assert data['subtitles']['en'][0]['ext']=='vtt'

# Generated at 2022-06-24 12:40:07.918525
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Constructor of class ITVIE should return the correct instance.
    """
    assert ITVIE().class_is_instantiable()

# Generated at 2022-06-24 12:40:10.119058
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    assert ITVBTCCIE._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:40:11.123210
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)._html_get_attribute()

# Generated at 2022-06-24 12:40:21.114900
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE.ie_key()
    assert IE.suitable('https://www.itv.com/hub/liar/2a4547a0012') == True
    assert IE.suitable('https://www.itv.com/hub/through-the-keyhole/2a2271a0033') == False
    assert IE.suitable('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034') == False
    assert IE.suitable('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024') == False

# Generated at 2022-06-24 12:40:24.490252
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:40:28.540452
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # Constructor is tested because of the Brightcove URL template
    assert ITVBTCCIE()._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:40:29.626057
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # When this test fails please remove it or improve it.
    ITVBTCCIE()

# Generated at 2022-06-24 12:40:34.599121
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import unittest
    from functools import partial
    from .common import FakeYDL
    from .test_brightcove import MockBrightcoveIE_test, MockBrightcoveLegacyIE_test

    class TestITVBTCCIE(unittest.TestCase):
        def test_smuggle_url(self):
            ie = ITVBTCCIE()
            self.assertEqual(
                ie.BRIGHTCOVE_URL_TEMPLATE % '1234567890',
                'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=1234567890')

# Generated at 2022-06-24 12:40:37.838814
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test if constructor of class ITVBTCCIE can be called
    ietester = ITVBTCCIE()
    assert ietester.__class__.__name__ == 'ITVBTCCIE'


# Generated at 2022-06-24 12:40:48.122723
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
        Test ITVIE constructor
    """
    test_cases = [
        [
            "https://www.itv.com/hub/liar/2a4547a0012",
            "Liar - Series 2 - Episode 6"
        ],
        [
            "https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034",
            "James Martin's Saturday Morning"
        ],
        [
            "https://www.itv.com/hub/david-attenboroughs-flying-monsters/2a2898a0024",
            "David Attenborough's Flying Monsters"
        ]
    ]
    for url, title in test_cases:
        res = ITVIE.suitable(url)

# Generated at 2022-06-24 12:40:58.324408
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.name == 'ITV'
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']
    assert ie._extract_urls('https://www.itv.com/hub/liar') == ['https://www.itv.com/hub/liar/']
    assert ie.IE_NAME == 'itv'
    assert ie.__doc__ == 'ITVIE'
    assert ie.SDK == 'native_sdk'


# Generated at 2022-06-24 12:40:59.136966
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('sometest_video_id')

# Generated at 2022-06-24 12:41:10.496167
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itv._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:41:16.371889
# Unit test for constructor of class ITVIE
def test_ITVIE():
    tester = ITVIE()
    assert tester.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert tester.GEO_COUNTRIES == ['GB']
    assert tester._TESTS[0]['url'] == 'url' == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert tester._TESTS[0]['info_dict']['id'] == '2a4547a0012'



# Generated at 2022-06-24 12:41:25.037497
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvBTCCIE = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert itvBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:41:28.376246
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().extract(
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:41:32.597670
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._m3u8_re._pattern == 'https?://itv.vo.llnwd.net/e1/chunklist/(\\d+)\\.m3u8'

# Generated at 2022-06-24 12:41:34.881503
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE.suitable('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-24 12:41:41.025994
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import sys
    import os
    import re
    import json
    import tempfile

    from .brightcove import BrightcoveNewIE

    ITVE_module = sys.modules[__name__]

    # Filling the necessary structures for extractor to work

# Generated at 2022-06-24 12:41:44.709108
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:41:48.117373
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:49.867372
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('itv', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:41:51.143809
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('')

# Generated at 2022-06-24 12:41:55.764145
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'
    webpage = '<html><body><div class="video-player" id="video" data-playlist-url="https://www.itv.com/playlist/json/{}/hmac/{}" data-video-id="" data-video-hmac="" data-player-config="" data-config="" data-site-section=""></div></body></html>'.format(video_id, '1234')
    assert ITVIE(ITVIE.IE_NAME)._real_extract(webpage, video_id)

# Generated at 2022-06-24 12:41:56.265520
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('')

# Generated at 2022-06-24 12:41:58.148645
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert 'brightcove' in ITVBTCCIE.ie_key()

# Generated at 2022-06-24 12:41:59.551838
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:42:05.935672
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE_test = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    assert "Found good ITV Hub link" == ITVIE_test.extract("http://www.itv.com/hub/liar/2a4547a0012")
    assert "Didn't find good ITV Hub link" == ITVIE_test.extract("https://www.itv.com/hub/through-the-keyhole/2a2271a0033")


# Generated at 2022-06-24 12:42:07.731163
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:42:19.018907
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:42:21.533793
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Simple test for class ITVBTCCIE
    # This method is not being used
    pass

# Generated at 2022-06-24 12:42:24.556255
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE._downloader, ITVBTCCIE._TEST['url'])._match_id('btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:42:27.845511
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # test to see if the ITVIE constructor can accept arguments and can also
    # check if the ITVIE class itself can be instantiated.
    instance = ITVIE()
    assert isinstance(instance, ITVIE)

# Generated at 2022-06-24 12:42:29.977606
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:42:32.873718
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:42:33.375622
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:42:34.673858
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    a = ITVBTCCIE()
    assert a is not None

# Generated at 2022-06-24 12:42:37.089233
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:42:38.461001
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_instantiate_module(ITVBTCCIE)

# Generated at 2022-06-24 12:42:43.449728
# Unit test for constructor of class ITVIE
def test_ITVIE():
        print("\nTesting constructor of ITVIE")
        try:
            print("\nCreating an ITVIE")
            ITVIE()
        except Exception as err:
            print("FAILED",err)
            success = False
        else:
            print("SUCCESS")
            success = True
        return success


# Generated at 2022-06-24 12:42:48.748236
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    object = ITVBTCCIE('http://www.itv.com/btcc', 'btcc-2018-all-the-action-from-brands-hatch')
    assert object.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:53.037709
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:54.947527
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TESTS[0]['url'] == ITVBTCCIE._TEST['url']

# Generated at 2022-06-24 12:42:55.710303
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE() == ITVIE()

# Generated at 2022-06-24 12:42:56.889614
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-24 12:42:59.492950
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['info_dict']['title'] == ITVBTCCIE(
        ITVBTCCIE.IE_NAME)._download_webpage(
            'http://www.itv.com/hub/btcc/1a4718a0046',
            'btcc-2018-all-the-action-from-brands-hatch'
        )['title']

# Generated at 2022-06-24 12:43:01.514836
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:43:02.071773
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:43:03.518207
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()
    ITVBTCCIE(InfoExtractor())

# Generated at 2022-06-24 12:43:04.502113
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()

# Generated at 2022-06-24 12:43:12.342667
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('http://www.itv.com/hub/liar/2a4547a0012')._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE('http://www.itv.com/hub/liar/2a4547a0012')._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-24 12:43:13.203105
# Unit test for constructor of class ITVIE
def test_ITVIE():
    pass

# Generated at 2022-06-24 12:43:16.141222
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:18.458506
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test that ITVBTCCIE doesn't fail on downloading video
    # from webpage mentioned in ITVBTCCIE._TEST
    itv = ITVBTCCIE()
    itv.download(itv._TEST['url'])

# Generated at 2022-06-24 12:43:25.635787
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert '2a4547a0012' == i._match_id(i._url)
    assert i.BRIGHTCOVE_URL_TEMPLATE is ITVIE.BRIGHTCOVE_URL_TEMPLATE
    assert i.GEEO_COUNTRIES is ITVIE._GEO_COUNTRIES
    assert i.VALID_URL is ITVIE._VALID_URL

# Generated at 2022-06-24 12:43:30.081980
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVExtractor = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert ITVExtractor._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:43:34.201460
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVExtractor = ITVIE({}, {}, None, None)
    assert ITVExtractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?%s'
    assert ITVExtractor.GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:43:36.872308
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_url = r'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE.suitable(itv_url)
    assert ITVIE._match_id(itv_url) == '2a4547a0012'

# Generated at 2022-06-24 12:43:39.027548
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    return ITVBTCCIE()._match_id(test_url)

# Generated at 2022-06-24 12:43:45.547483
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:43:53.338798
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    info_dict = {
        'id': '2a4547a0012',
        'ext': 'mp4',
        'title': 'Liar - Series 2 - Episode 6',
        'description': 'md5:d0f91536569dec79ea184f0a44cca089',
        'series': 'Liar',
        'season_number': 2,
        'episode_number': 6,
    }
    params = {'skip_download': True}

    obj = ITVIE()
    obj._downloader = FakeDownloader()
    obj._download_webpage = lambda *args, **kwargs: repr(args) + repr(kwargs)

# Generated at 2022-06-24 12:43:56.809231
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        from unittest import mock
    except ImportError:
        from unittest import mock

    r = ITVBTCCIE()
    assert r is not None # This is a dummy test

# Generated at 2022-06-24 12:43:58.245582
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ive = ITVIE()
    assert ive.__name__ == 'ITV'

# Generated at 2022-06-24 12:43:59.884349
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_obj = ITVIE()
    assert isinstance(test_obj, ITVIE)



# Generated at 2022-06-24 12:44:01.685120
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class_inst = ITVBTCCIE({})
    assert class_inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:44:02.231890
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE()
    assert result

# Generated at 2022-06-24 12:44:05.348134
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    ITVIE('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')
    ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')


# Generated at 2022-06-24 12:44:10.108181
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test that ITVBTCCIE can be constructed.
    # This is necessary since ITVBTCCIE inherits from ITVIE.
    extraction_test = ITVBTCCIE(ITVEmbedIE._downloader, {'test_suite': 'test_suite'})
    assert isinstance(extraction_test, ITVBTCCIE)

# Generated at 2022-06-24 12:44:13.105837
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024'
    ITVIE()
    ITVIE.suitable(url)

# Generated at 2022-06-24 12:44:14.905410
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._build_brigthcove_url('12345') == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=12345'

# Generated at 2022-06-24 12:44:25.192375
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert instance._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:44:29.423309
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034','http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=6085558232001'),

# Generated at 2022-06-24 12:44:31.803005
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE().extract(url)

# Generated at 2022-06-24 12:44:38.807241
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    sample_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._VALID_URL == ITVBTCCIE.VALID_URL
    assert ITVBTCCIE._TEST == ITVBTCCIE.TEST
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE
    ie = ITVBTCCIE()
    assert ie._real_extract(sample_url)

# Generated at 2022-06-24 12:44:43.067840
# Unit test for constructor of class ITVIE
def test_ITVIE():
            url = 'https://www.itv.com/hub/liar/2a4547a0012'
            print("URL of ITV",url)
            assert ITVIE._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:44:52.473549
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:45:02.110536
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()

    # Test no content
    assert itv._real_extract('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024') == 'ContentUnavailable'

    # Test invalid VOD CRID
    assert itv._real_extract('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034') == 'InvalidVodcrid'

    # Test error
    assert itv._real_extract('https://www.itv.com/hub/liar/2a4547a0012') == 'm3u8 download'

# Generated at 2022-06-24 12:45:05.711177
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE.suite().run(ITVBTCCIE(ITVBTCCIE()).extract(url))

# Generated at 2022-06-24 12:45:07.479282
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Simple test to check the constructor of ITVBTCCIE class
    """
    ITVBTCCIE()

# Generated at 2022-06-24 12:45:12.190209
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test constructor of class ITVIE
    info_extractor = ITVIE()
    assert info_extractor._VALID_URL == ITVIE._VALID_URL
    assert info_extractor._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert info_extractor._TESTS == ITVIE._TESTS

# Generated at 2022-06-24 12:45:19.700508
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test class constructor."""
    # Constructing a test object
    test_object = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    # Testing that URL has been assigned correctly
    assert test_object._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    # Testing that _GEO_COUNTRIES has been assigned correctly
    assert test_object._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:45:27.793904
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVE = ITVIE()
    # Valid tv show
    ITVE._real_extract('https://www.itv.com/hub/liar/2a4547a0012')
    # Tv show with different url
    ITVE._real_extract('https://www.itv.com/hub/googlebox/2a4547a0012')
    # Tv show not in UK
    ITVE._real_extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:45:28.562779
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()

# Generated at 2022-06-24 12:45:30.460062
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE("ITVBTCC")

# Generated at 2022-06-24 12:45:32.189708
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:45:33.057685
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()


# Generated at 2022-06-24 12:45:35.609711
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:45:38.659633
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test for constructor of class ITVBTCCIE."""
    ITVBTCCIE.suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:45:40.215868
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() == 'itv_btcc'

# Generated at 2022-06-24 12:45:45.089369
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:45:50.794487
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from six.moves import reload_module
    from six import PY3
    reload_module(ITVIE)
    if PY3:
        assert ITVIE._GEO_COUNTRIES is ITVIE.__class__._GEO_COUNTRIES
    else:
        assert ITVIE._ITVIE__GEO_COUNTRIES is ITVIE.__class__._ITVIE__GEO_COUNTRIES

# Generated at 2022-06-24 12:45:55.971976
# Unit test for constructor of class ITVIE
def test_ITVIE():
    vid = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    
    assert vid.url == "https://www.itv.com/hub/liar/2a4547a0012"
    assert vid.host == "www.itv.com"
    assert vid.id == "2a4547a0012"


# Generated at 2022-06-24 12:45:57.637757
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['info_dict']['title'] == ITVBTCCIE(None)._TEST['info_dict']['title']

# Generated at 2022-06-24 12:45:58.159756
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:46:00.090091
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:46:07.669697
# Unit test for constructor of class ITVIE
def test_ITVIE():
    #code for unit test, not real data
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    test = ITVIE()
    # test _match_id
    assert test._match_id(url) == "2a4547a0012"
    # test _real_extract, but this is hard to test, as it will give different value each time
    assert test._real_extract(url)["id"] == "2a4547a0012"


# Generated at 2022-06-24 12:46:08.267817
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:46:15.249429
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test the ITVIE constructor
    IE = ITVIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert IE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:46:16.440189
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/coronation-street/2a5597a0022')

# Generated at 2022-06-24 12:46:18.688111
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:20.985878
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE(None, '')
    except TypeError as e:
        assert 'Required argument \'ie\' (pos 1)' in str(e)

# Generated at 2022-06-24 12:46:23.820316
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        instance = ITVBTCCIE()
        assert type(instance) is ITVBTCCIE
    except:
        print("Exception raised when creating ITVBTCCIE instance")

# Generated at 2022-06-24 12:46:25.102768
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE('','','', '')
    assert test

# Generated at 2022-06-24 12:46:26.481715
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Simple test to ensure that ITVIE class can be created
    """
    ITVIE()

# Generated at 2022-06-24 12:46:33.229234
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert inst.BROWSER_HEADERS_URL == r'http://www.itv.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert inst._GEO_COUNTRIES == ['GB']
    assert len(inst._TESTS) == 4


# Generated at 2022-06-24 12:46:37.244938
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # ITVIE(InfoExtractor).__init__(self)
    test_ITVIE = ITVIE(InfoExtractor)
    print('Testing of ITVIE class:')
    print(test_ITVIE)
    print('END of ITVIE Class Testing')


# Generated at 2022-06-24 12:46:44.702511
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_values = {
        {
            'url': None,
            'should_pass': False
        },
        {
            'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
            'should_pass': True
        }
    }

    for test_value in test_values:
        try:
            ITVBTCCIE(test_value['url'])
            if not test_value['should_pass']:
                raise Exception('Expected ITVBTCCIE to throw exception')
        except:
            if test_value['should_pass']:
                raise Exception('Expected ITVBTCCIE to not throw exception')

# Generated at 2022-06-24 12:46:46.210074
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:46:50.060687
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvBTCCIE = ITVBTCCIE()

    assert(itvBTCCIE.BRIGHTCOVE_URL_TEMPLATE ==
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:46:55.686552
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITB = ITVBTCCIE()
    assert ITB._TEST == ITVBTCCIE._TEST
    assert ITB._VALID_URL == ITVBTCCIE._VALID_URL
    assert ITB.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:46:58.884287
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE
    assert ie.geo_countries == ITVIE._GEO_COUNTRIES

# Generated at 2022-06-24 12:47:04.548805
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE()
    assert test._VALID_URL == "https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)"
    assert test._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:47:13.010367
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import unittest
    class TestITVBTCCIE(unittest.TestCase):
        def setUp(self):
            self.URL = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
            self.expect_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5814310250001'
            self.expect_video_id = '5814310250001'
        def test_init(self):
            current_video_url = None
            current_video_id = None
            ie = ITVBTCCIE()
            assert ie is not None
            ie_result = ie._real_extract(self.URL)
