

# Generated at 2022-06-24 12:37:12.001883
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:37:13.767992
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.suitable('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:37:20.182902
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data', 'test_itvbtcc_data.inp')
    with open(file_path, 'r') as f:
        test_data = json.load(f)
    for test in test_data:
        e = ITVBTCCIE()
        actual = e._real_extract(test['url'])
        expected = test['expected']
        assert actual.keys() == expected.keys()
        for key in actual.keys():
            if key == 'entries':
                assert len(actual[key]) == len(expected[key])
                for i, value in enumerate(actual[key]):
                    assert value['id'] == expected[key][i]

# Generated at 2022-06-24 12:37:21.268565
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.__name__ == 'ITVBTCCIE'

# Generated at 2022-06-24 12:37:30.625988
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie.playlist_id == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:37:32.069072
# Unit test for constructor of class ITVIE
def test_ITVIE():
    unit = ITVIE()
    assert unit


# Generated at 2022-06-24 12:37:41.449560
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:37:43.727025
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Instantiate an ITVIE obj
    # If this does not throw an exception it is good enough for us
    try:
        ITVIE()
    except:
        assert False

# Generated at 2022-06-24 12:37:45.560044
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:37:48.349317
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert(ITVBTCCIE.BRIGHT_COVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-24 12:37:55.187087
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:58.227337
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:38:01.949941
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:38:03.971452
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:38:04.658082
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:38:09.485420
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # pylint: disable=protected-access
    assert re.match(r'http://players\.brightcove\.net/1582188683001/HkiHLnNRx_default/index\.html\?videoId=', ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-24 12:38:12.892365
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class_btcc = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert class_btcc.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:38:15.774472
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    data = ITVBTCCIE('btcc-2018-all-the-action-from-brands-hatch')
    assert data is not None

# Generated at 2022-06-24 12:38:21.494799
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:38:22.546574
# Unit test for constructor of class ITVIE
def test_ITVIE():
    pass


# Generated at 2022-06-24 12:38:25.824410
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    result = info_extractor._real_extract("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert result['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert result['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert len(result['entries']) == 9

# Generated at 2022-06-24 12:38:27.249288
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Tests for class ITVIE()."""

    ITVIE()



# Generated at 2022-06-24 12:38:28.190269
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()


# Generated at 2022-06-24 12:38:35.761904
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')._download_webpage()
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')._download_webpage().encode('utf-8')
    re.search(r'(?s)(<[^>]+id="video"[^>]*>)', ITVIE('http://www.itv.com/hub/liar/2a4547a0012')._download_webpage().encode('utf-8'), 'params')

# Generated at 2022-06-24 12:38:45.081587
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    info_extractor._download_webpage = lambda url: (url, 200)
    info_extractor._download_json = lambda url, video_id, headers, data: (url, 200)
    info_extractor._search_json_ld = lambda page, video_id, default: None
    info_extractor._json_ld = lambda item, video_id, fatal=True: {
        'series': 'Liar',
        'season_number': 2,
        'episode_number': 6,
    }

    info = info_extractor._real_extract('http://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-24 12:38:49.296537
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    t = ITVBTCCIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:38:53.854096
# Unit test for constructor of class ITVIE
def test_ITVIE():
    iev = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert iev.url == "https://www.itv.com/hub/liar/2a4547a0012"
    assert iev.url_id == "2a4547a0012"

# Generated at 2022-06-24 12:39:04.642741
# Unit test for constructor of class ITVIE
def test_ITVIE():
    initial_test = ITVIE( 'http://www.itv.com/hub/liar/2a4547a0012' )
    assert initial_test._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:39:05.943385
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie in globals().values()

# Generated at 2022-06-24 12:39:08.053507
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-24 12:39:11.566850
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Unit test for constructor of class ITVBTCCIE
    print("test_ITVBTCCIE()")
    itvbtccie = ITVBTCCIE()
    print(itvbtccie)

# Generated at 2022-06-24 12:39:16.649892
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = ITVIE.VALID_URL
    url = url.replace(r'https?://', 'https://')
    url = url.replace('/hub/', '/hub/liar/')
    url = url.replace('com/hub/liar/2a4547a0012', 'com/hub/liar/')
    url = url.replace(r'//(?:www\.)?', '//www.')
    assert ITVIE.VALID_URL == url

# Generated at 2022-06-24 12:39:25.535781
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from unit.test_downloader import FakeYDL
    from unit.extractor.common import (
        TestExtractor,
        TestIE,
        HELLO_WORLD_SOURCE_CODE,
    )
    from unit.helper import ExtractorTestCase
    import tests.mock as mock

    def mock_content_0(url):
        return HELLO_WORLD_SOURCE_CODE

    def mock_content_1(url):
        return HTML

    mock.mock_get(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '123', mock_content_1)
    mock.mock_get(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '456', mock_content_1)

# Generated at 2022-06-24 12:39:27.924842
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/news/hub/2019-06-02/lorry-driver-who-mown-down-and-killed-cyclist-in-hit-and-run-jailed/'
    ITVIE()(url)

# Generated at 2022-06-24 12:39:32.014042
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # instantiate class
    ITVBTCCIE()
    # instantiate class with hard coded url
    ITVBTCCIE(url='http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:39:33.180104
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    

# Generated at 2022-06-24 12:39:34.426697
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-24 12:39:44.661740
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    subentry_dict = {
        'title': 'BTCC 2018: All the action from Brands Hatch',
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        '_type': 'url',
        'url': 're:http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html\?videoId=\d+',
        'ie_key': 'BrightcoveNew',
    }
    playlist = ITVBTCCIE().extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert subentry_dict in playlist['entries']

# Generated at 2022-06-24 12:39:54.775730
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itv_btcc_ie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    assert itv_btcc

# Generated at 2022-06-24 12:39:56.489488
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.__class__.__name__ == 'ITVBTCCIE'

# Generated at 2022-06-24 12:39:57.020911
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE().name == 'itv'

# Generated at 2022-06-24 12:40:02.862432
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from . import ITVBTCCIE

    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(None)._extract_info(url)

    ie = ITVBTCCIE(None)
    ie._extract_info(url)
    assert ie.video_id == playlist_id

    #url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    #playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    #ie = ITVBT

# Generated at 2022-06-24 12:40:04.217512
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	pass

# Generated at 2022-06-24 12:40:14.559819
# Unit test for constructor of class ITVIE
def test_ITVIE():
    temp = ITVIE
    assert temp._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:40:24.284517
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import unittest

    class ITVBTCCIETest(unittest.TestCase):
        def test_constructor(self):
            valid_urls = [
                'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
            ]
            for url in valid_urls:
                result = ITVBTCCIE(ITVBTCCIE.create_ie()).suitable(url)
                self.assertTrue(
                    result, msg='URL {} should be valid'.format(url))

            invalid_urls = [
                'http://www.itv.com/itvplayer/',
                'http://www.itv.com/hub/thor-ragnarok/episode-1'
            ]

# Generated at 2022-06-24 12:40:26.705490
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Test that tests if constructor of ITVBTCCIE works as expected
    """
    assert ITVBTCCIE('races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:40:27.865132
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert type(ITVBTCCIE()) is ITVBTCCIE

# Generated at 2022-06-24 12:40:29.701113
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    The constructor should accept a url and return an ITVBTCCIE object.
    """
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')


# Generated at 2022-06-24 12:40:30.254524
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()



# Generated at 2022-06-24 12:40:34.720489
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url='http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie.match_url(url)
    assert ie._VALID_URL == "https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)"
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    playlist_id = ie._match_id(url)

# Generated at 2022-06-24 12:40:38.515868
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_obj = ITVBTCCIE()
    assert test_obj._TEST['url'] == url



# Generated at 2022-06-24 12:40:43.775240
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IE = ITVBTCCIE()
    assert IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert IE.ie_key() == 'BrightcoveNew'

# Generated at 2022-06-24 12:40:46.171916
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE(ITVBTCCIE._create_get_url_instance())
    assert isinstance(itvbtccie, ITVBTCCIE)

# Generated at 2022-06-24 12:40:49.201421
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    video_id = '6151371311001'
    entry = ITVBTCCIE({}, ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % video_id)._real_extract({'url': 'http://not_used', 'ie_key': BrightcoveNewIE.ie_key(), 'video_id': video_id})
    assert BrightcoveNewIE.ie_key() == entry['ie_key']
    assert entry['id'] == video_id



# Generated at 2022-06-24 12:40:53.059346
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:54.462522
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IEBTCC = ITVBTCCIE()
    assert IEBTCC

# Generated at 2022-06-24 12:41:00.829936
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Using a random URL from the ITV website
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

    class ITVBTCCIE_Tester(ITVBTCCIE):
        def __init__(self):
            self.result = ITVBTCCIE(FakeYDL())._real_extract(url)

    ITVBTCCIE_Tester()

# Generated at 2022-06-24 12:41:03.198067
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Purpose: Create an instance of this class
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:41:06.517454
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Providing this test to suppress pycodestyle
    assert ITVIE(InfoExtractor())._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:41:08.779167
# Unit test for constructor of class ITVIE
def test_ITVIE():
    __test__ = True
    itv = ITVIE()
    assert itv.classname == 'ITVIE'

# Generated at 2022-06-24 12:41:10.410578
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IE = ITVBTCCIE()
    assert(IE.get_GEO_COUNTRIES() == [])

# Generated at 2022-06-24 12:41:12.593740
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE('https://www.itv.com/hub/liar/2a4547a0012', None)
    assert instance


# Generated at 2022-06-24 12:41:22.890688
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # some IP blocks ITV accepts
    geo_ip_blocks = ["193.113.0.0/16", "54.36.162.0/23", "159.65.16.0/21"]

    # the following is test case from ITVBTCCIE
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"

    _ = ITVBTCCIE().url_result(smuggle_url(
        ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % "5698555458001",
        { "geo_ip_blocks": geo_ip_blocks, "referrer": url }),
        ie=BrightcoveNewIE.ie_key(), video_id="5698555458001")

# Generated at 2022-06-24 12:41:34.548210
# Unit test for constructor of class ITVIE
def test_ITVIE():
	url = 'https://www.itv.com/hub/liar/2a4547a0012'
	ie = ITVIE(ITVIE._create_get_playlist(),url)
	assert ie.login_page == 'https://account.itv.com/login'
	assert ie.webpage_url == url
	assert ie.video_id == '2a4547a0012'
	assert ie.headers == {'Accept': 'application/json', 'Content-Type': 'application/json'}

# Generated at 2022-06-24 12:41:37.029782
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(None).url_result(ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE % '5815793143001')

# Generated at 2022-06-24 12:41:40.742127
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Unit test for constructor of class ITVBTCCIE."""
    ITVBTCCIE_sample = ITVBTCCIE("ITVBTCCIE")
    assert ITVBTCCIE_sample.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:41.893858
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # basic test
    ITVIE([], {})._get_itv_playlist_url

# Generated at 2022-06-24 12:41:44.017728
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = ITVBTCCIE._TEST['url']
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._match_id(url) == ITVBTCCIE._TEST['info_dict']['id']

# Generated at 2022-06-24 12:41:47.484883
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtcc_ie = ITVBTCCIE()
    assert  itvbtcc_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:41:53.994550
# Unit test for constructor of class ITVIE
def test_ITVIE():
	assert(ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')

# Generated at 2022-06-24 12:41:55.960661
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # args
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    # return 
    ITVIE(url)


# Generated at 2022-06-24 12:41:57.647524
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .common import merge_dicts
    ITVIE = ITVIE()
    return ITVIE

# Generated at 2022-06-24 12:42:04.162449
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:08.503699
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test ITVIE constructor."""
    URL = "https://www.itv.com/hub/liar/2a4547a0012"
    _ITVIE = ITVIE(info_dict={"test": "yes"})
    assert _ITVIE._match_id(URL) == "2a4547a0012"
    assert _ITVIE._valid_url(URL, "ITVIE")

# Generated at 2022-06-24 12:42:19.290701
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from ..compat import compat_b64decode
    from ..utils import determine_ext
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    # Test for bytes in PY3
    assert determine_ext('http://www.itv.com/itvplayer/video/null-ll%c3%b6l%c3%b6l%c3%b6l') == 'mp4'
    assert determine_ext(compat_b64decode('aHR0cDovL3d3dy5pdHYuY29tL2l0dnBsYXllci92aWRlby9udWxsLWxs8J+WgPCfloDwn5aA')) == 'mp4'

# Generated at 2022-06-24 12:42:30.653702
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    regex = ITVBTCCIE._VALID_URL
    assert regex.match('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert regex.match('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch/')
    assert regex.match('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert regex.match('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch/')

# Generated at 2022-06-24 12:42:34.300510
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # testing with iTV video
    itv_url = 'https://www.itv.com/hub/jeremy-kyles-crime-stories/2a4547a0053'
    print(ITVIE()._real_extract(itv_url))



# Generated at 2022-06-24 12:42:43.691004
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test with a real world example
    itv = ITVIE()
    episode_id = '2a4547a0012'
    episode_url = 'https://www.itv.com/hub/liar/{}'.format(episode_id)
    episode = itv.url_result(episode_url)
    assert episode is not None
    assert ITVIE.suitable(episode_url)
    assert isinstance(episode, ITVIE)
    assert episode.IE_NAME == 'ITV'
    assert episode.VALID_URL == ITVIE._VALID_URL
    assert itv.working == True
    assert itv.result_type == "entries"

    

# Generated at 2022-06-24 12:42:49.276147
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    playlist_id='btcc-2018-all-the-action-from-brands-hatch'
    url = 'http://www.itv.com/btcc/races/{}'.format(playlist_id)
    playlist_url = ITVBTCCIE._VALID_URL
    assert playlist_id == ITVBTCCIE._match_id(url)
    assert re.match(playlist_url, url)



# Generated at 2022-06-24 12:42:50.239288
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-24 12:42:52.582249
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_object = ITVBTCCIE()
    assert test_object._TEST['url'] == test_object.test_result()['url']

# Generated at 2022-06-24 12:43:01.587550
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # This unit test checks whether the brightcove video has expected referrer
    # and expected geo_ip_blocks
    ITVBTCCIE._downloader = None
    itvbtccie = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    webpage = itvbtccie._download_webpage(url, 'btcc-2018-all-the-action-from-brands-hatch')
    itvbtccie._real_extract(url)
    for video_id in re.findall(r'data-video-id=["\'](\d+)', webpage):
        assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE % video_id in ITVBTCC

# Generated at 2022-06-24 12:43:12.091443
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.IE_NAME == "itv:vod"
    assert ie.IE_DESC == "ITV Hub"
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:43:19.983366
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test wrong argument of constructor
    # Should raise error
    invalidArgs = [
        '', 'aa', {'a': 1}
    ]

    for arg in invalidArgs:
        try:
            ITVIE(arg)
        except:
            pass
        else:
            assert True == False, "constructor of ITVIE class should raise error when wrong argument"

    # Test correct argument of constructor
    # Should not raise error
    validArgs = [
        'a',
        {'name': 'a'},
        {'name': 'a', 'password': 'b'}
    ]

    for arg in validArgs:
        try:
            ITVIE(arg)
        except:
            assert True == False, "constructor of ITVIE class should not raise error when correct argument"

# Generated at 2022-06-24 12:43:22.963389
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    # Check if the name field is set correctly
    if ie.name != 'itv:btcc':
        print('Name of ITVBTCCIE is not set correctly')

# Generated at 2022-06-24 12:43:25.837438
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("", "")

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-24 12:43:28.895539
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._real_extract('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'


# Generated at 2022-06-24 12:43:31.102730
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    btcc_path = "BTCC 2018:"
    btcc_result = itv_btcc_ie.url_result(btcc_path)
    btcc_result.get_info()

# Generated at 2022-06-24 12:43:34.573970
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._TEST['id'] == ITVBTCCIE._match_id(url)

# Generated at 2022-06-24 12:43:36.477253
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    ITVIE().url_result(url)

# Generated at 2022-06-24 12:43:46.799988
# Unit test for constructor of class ITVIE

# Generated at 2022-06-24 12:43:49.887832
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:51.420933
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'https://www.itv.com/btcc/races/2018-season-review'
    assert ITVBTCCIE().suitable(url)

# Generated at 2022-06-24 12:43:53.234273
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie.geo_verification_headers()
    assert itv_ie.download_dash
    assert itv_ie.download_hls

# Generated at 2022-06-24 12:43:54.841545
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE()
    assert instance.__class__ == ITVIE

# Generated at 2022-06-24 12:43:58.461533
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:59.755701
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert x is not None

# Generated at 2022-06-24 12:44:02.048988
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == ITVIE._VALID_URL
    assert ie._TESTS == ITVIE._TESTS


# Generated at 2022-06-24 12:44:04.596610
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE.suitable(url)
    assert ITVBTCCIE._VALID_URL.match(url)

# Generated at 2022-06-24 12:44:13.104557
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    _ITVBTCCIE = ITVBTCCIE()
    assert ITVBTCCIE._TEST['url'] == _ITVBTCCIE._get_url('btcc-2018-all-the-action-from-brands-hatch')
    assert ITVBTCCIE._TEST['playlist_mincount'] == len(
        _ITVBTCCIE._entries(
            _ITVBTCCIE._download_webpage(
                _ITVBTCCIE._get_url(ITVBTCCIE._TEST['info_dict']['id']),
                ITVBTCCIE._TEST['info_dict']['id']
            )
        )
    )

# Generated at 2022-06-24 12:44:15.353525
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    obj = ITVIE()
    result = obj._real_extract(url)

# Generated at 2022-06-24 12:44:18.377094
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-24 12:44:29.156977
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test: `ITVBTCCIE()`"""
    import itvbtcc
    # Test with test_video data
    video_data = itvbtcc.test_video
    video_data['ext'] = video_data['_type']
    video_data['url'] = video_data['code']
    video_data['webpage_url'] = video_data['embed']
    video_data['webpage_url_basename'] = ''
    video_data['id'] = ''
    video_data['id_basename'] = ''
    video_data['thumbnail'] = ''
    video_data['duration'] = 1290
    video_data['age_limit'] = 0

# Generated at 2022-06-24 12:44:31.176408
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    obj.download("http://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:44:32.229636
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.IE_KEY == 'ITV'

# Generated at 2022-06-24 12:44:33.987157
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.__class__.__name__ == 'ITVBTCCIE'

# Generated at 2022-06-24 12:44:36.611801
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvIE = ITVIE()
    assert itvIE.extract_data['playlist'] == None
    assert itvIE.extract_data['playlist_count'] == None

# Generated at 2022-06-24 12:44:39.687003
# Unit test for constructor of class ITVIE
def test_ITVIE():
    yt = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert yt._match_id == '2a4547a0012'

# Generated at 2022-06-24 12:44:41.020951
# Unit test for constructor of class ITVIE
def test_ITVIE():
    iTVIE = ITVIE()
    assert iTVIE is not None

# Generated at 2022-06-24 12:44:42.683364
# Unit test for constructor of class ITVIE
def test_ITVIE():  # noqa
    extractor = ITVIE()
    assert extractor.geo_verification_headers() != {}

# Generated at 2022-06-24 12:44:44.287252
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-24 12:44:52.981680
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert info_extractor._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:44:54.039588
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()


# Generated at 2022-06-24 12:44:57.861540
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE('itv')
    assert info_extractor.IE_NAME == 'itv'
    assert ITVIE.ie_key() in info_extractor.GENERIC_IE_KEY

# Generated at 2022-06-24 12:45:05.666756
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    #Create new instance
    create_instance = ITVBTCCIE()
    #Test real URL
    real_url_test_input = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    create_instance._real_extract(real_url_test_input)
    #Test invalid URL
    invalid_url_test_input = 'http://www.itv.com/btco'
    if create_instance._match_id(invalid_url_test_input):
        raise ValueError('Invalid URL input must return None')

# Generated at 2022-06-24 12:45:09.443060
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/Tut/2a2271a0033'
    video = ITVIE()._real_extract(url)
    assert video.get('title') == 'Tut'

# Generated at 2022-06-24 12:45:11.376541
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.__class__.__name__ == 'ITVBTCCIE'

# Generated at 2022-06-24 12:45:16.187275
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL is ITVBTCCIE._VALID_URL
    assert ie._TEST is ITVBTCCIE._TEST
    assert ie._downloader is None
    assert ie.BRIGHTCOVE_URL_TEMPLATE is ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:45:17.623584
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._GEO_COUNTRIES == ['GB']


# Generated at 2022-06-24 12:45:28.983598
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc = ITVBTCCIE()
    assert itv_btcc.BRIGHTCOVE_URL_TEMPLATE.startswith('http://players')
    assert 'brightcove' in itv_btcc.BRIGHTCOVE_URL_TEMPLATE
    assert '1582188683001' in itv_btcc.BRIGHTCOVE_URL_TEMPLATE
    assert 'HkiHLnNRx_default' in itv_btcc.BRIGHTCOVE_URL_TEMPLATE
    assert itv_btcc.BRIGHTCOVE_URL_TEMPLATE.endswith('index.html?videoId=%s')

# Generated at 2022-06-24 12:45:31.965053
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i._TEST['url'] == i.BRIGHTCOVE_URL_TEMPLATE % i._TEST['info_dict']['id']

# Generated at 2022-06-24 12:45:39.843389
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE(ITVBTCCIE.IE_NAME, url)
    assert ie._VALID_URL == url
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._TEST['url'] == url
    assert ie._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:45:43.287267
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE() # create instance of ITVIE
    assert ie # assert that the instance is created


if __name__ == 'main':
    test_ITVIE()

# Generated at 2022-06-24 12:45:46.357644
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    print("Unit test for Constructor ITVBTCCIE")
    obj = ITVBTCCIE()
    assert obj is not None


# Generated at 2022-06-24 12:45:50.395733
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    extractor = ITVIE()
    result = extractor._real_extract({'url': test_url})
    assert result['id'] == '2a4547a0012'

# Generated at 2022-06-24 12:45:59.094247
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    expected_result = {
        'id': '2a4547a0012',
        'ext': 'mp4',
        'title': 'Liar - Series 2 - Episode 6',
        'description': 'md5:d0f91536569dec79ea184f0a44cca089',
        'series': 'Liar',
        'season_number': 2,
        'episode_number': 6
    }
    original_json_ld = ITVIE._json_ld
    original_search_regex = ITVIE._search_regex

    # Replace _json_ld
    def _json_ld(self, item, video_id, fatal=True):
        return expected_result


# Generated at 2022-06-24 12:46:09.548279
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE()
    assert re.search(r'^http://players\.brightcove\.net/1582188683001/HkiHLnNRx_default/index\.html\?videoId=', result.BRIGHTCOVE_URL_TEMPLATE)
    assert result._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:46:13.211846
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    item = ITVBTCCIE()
    assert item.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:14.106059
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Create a instance of class ITVIE
    ITVIE()

# Generated at 2022-06-24 12:46:23.998629
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:46:27.697869
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_instance = ITVIE()
    assert test_instance._VALID_URL == ITVIE._VALID_URL
    assert test_instance._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert test_instance._TESTS == ITVIE._TESTS


# Generated at 2022-06-24 12:46:30.514190
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:32.257980
# Unit test for constructor of class ITVIE
def test_ITVIE():
    '''
    This function is a dummy test for ITVIE
    '''
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:46:35.093564
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from inspect import isclass

    ITVIE_class = ITVIE # Make testable static class method in constructor
    assert isclass(ITVIE_class)


# Generated at 2022-06-24 12:46:42.855368
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

    # Unit test for _VALID_URL field of class ITVBTCCIE
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

    # Unit test for _TEST field of class ITVBTCCIE

# Generated at 2022-06-24 12:46:43.431620
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:46:46.264266
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-24 12:46:52.185666
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE(url)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:56.461072
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie._VALID_URL == re.compile(r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')

# Generated at 2022-06-24 12:46:59.730832
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv.IE_NAME == 'ITV'
    assert itv.VALID_URL == ITVIE._VALID_URL
    assert itv.GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert itv.TESTS == ITVIE._TESTS


# Generated at 2022-06-24 12:47:10.522413
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie=ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'