

# Generated at 2022-06-24 12:37:04.758729
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    e = ITVBTCCIE()
    assert e.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-24 12:37:05.440338
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST

# Generated at 2022-06-24 12:37:08.138345
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    data = ITVIE()._real_extract(url)
    assert data['title'] == 'Liar - Series 2 - Episode 6'

# Generated at 2022-06-24 12:37:12.864356
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist = ITVBTCCIE()._real_extract(url)
    assert playlist['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert len(playlist['entries']) >= 9

# Generated at 2022-06-24 12:37:15.119345
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print("Unit test for ITVIE")
    video_url = "https://www.itv.com/hub/liar/2a4547a0012"
    ITV = ITVIE()
    print(ITV)
    ITV._download_webpage(video_url, video_id)
    print("Finish")

# Generated at 2022-06-24 12:37:17.302297
# Unit test for constructor of class ITVIE
def test_ITVIE():
    Test = ITVIE()
    assert Test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

test_ITVIE()


# Generated at 2022-06-24 12:37:21.677519
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test ITV Destructor
    ITV = ITVIE()

    # Test ITV Destructor for is_suitable
    assert not ITVIE.suitable('http://www.itv.com/hub/take-me-out/48a5087a002')
    assert ITVIE.suitable('https://www.itv.com/hub/liar/2a4547a0012')
    assert ITVIE.suitable('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    assert ITVIE.suitable('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')

# Generated at 2022-06-24 12:37:26.187901
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:26.918212
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE.test()

# Generated at 2022-06-24 12:37:29.312690
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-24 12:37:39.205074
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert info_extractor._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-24 12:37:42.816376
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # For unregistered users, ITV uses a different URL.
    # See https://github.com/rg3/youtube-dl/issues/12484
    ITVIE()._download_webpage(
        'https://www.itv.com/itvplayer/liar/series-2/episode-6', '2a4547a0012')

# Generated at 2022-06-24 12:37:52.425861
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Unit test for constructor of class ITVBTCCIE
    """
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:54.384873
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    testcase = ITVBTCCIE(ITVIE())
    assert isinstance(testcase, ITVBTCCIE)

# Generated at 2022-06-24 12:38:01.990812
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import platform
    import random
    import time
    import uuid

    from youtube_dl.utils import url_basename
    from .common import compat_urllib_request

    default_headers = {
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'User-Agent': 'Mozilla/5.0 ({0}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'.format(platform.platform()),
    }

    # pylint: disable=protected-access
    def _build_request(url, headers):
        return compat_urllib_request.Request

# Generated at 2022-06-24 12:38:05.390212
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Constructor of ITVIE should be called with regex of ITVIE._VALID_URL
    assert ITVIE._VALID_URL == ITVIE(ITVIE._VALID_URL)._VALID_URL

# Generated at 2022-06-24 12:38:07.424644
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-24 12:38:10.247793
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Construct an object of the class ITVIE without raising an exception.
    """
    ITVIE("http://www.itv.com/hub/liar/2a4547a0012")



# Generated at 2022-06-24 12:38:15.552706
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    itv_btcc_ie = ITVBTCCIE()

# Test cases for class ITVIE

# Generated at 2022-06-24 12:38:17.020603
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE()
    assert isinstance(instance, ITVIE)

# Generated at 2022-06-24 12:38:20.119214
# Unit test for constructor of class ITVIE
def test_ITVIE():
    iTV = ITVIE(None)
    # Make sure I'm inheriting InfoExtractor
    assert isinstance(iTV, InfoExtractor)



# Generated at 2022-06-24 12:38:30.511138
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ie._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert (ie.BRIGHTCOVE_URL_TEMPLATE % '5744447810001') == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5744447810001'
   

# Generated at 2022-06-24 12:38:38.619107
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert obj._match_id(obj._VALID_URL) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    return True


# Generated at 2022-06-24 12:38:39.208194
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:38:42.407093
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVIE({})
    assert x._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:38:45.862194
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVExtractor = ITVBTCCIE(None, 'itv.com')
    assert ITVExtractor._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:38:48.740595
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info = ITVBTCCIE()._real_extract(ITVBTCCIE._TEST['url'])
    assert len(info['entries']) == ITVBTCCIE._TEST['playlist_mincount']

# Generated at 2022-06-24 12:38:52.478726
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    brightcove = ITVBTCCIE()
    assert brightcove.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:38:53.080708
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	pass

# Generated at 2022-06-24 12:38:54.527239
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import doctest
    doctest.testmod(ITVIE)


# Generated at 2022-06-24 12:38:56.112222
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:38:57.325658
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE("")
    print(ie._VALID_URL)

# Generated at 2022-06-24 12:39:00.166530
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    res = ITVBTCCIE()
    assert res.BRIGHTCOVE_URL_TEMPLATE ==\
           'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:10.941083
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Exercise the constructor of ITVBTCCIE
    ie = ITVBTCCIE()._real_extract("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-24 12:39:20.912349
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class_ = ITVIE
    example_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    example_url2 = 'http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    assert class_._match_id(example_url) == '2a4547a0012'
    assert class_._match_id(example_url2) == '2a5159a0034'
    assert class_._valid_url(example_url) is True
    assert class_._valid_url(example_url2) is True
    assert class_._valid_url('http://www.itv.com/hub/emmerdale/') is False

# Generated at 2022-06-24 12:39:24.226349
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:30.605054
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Unit test for constructor of class ITVIE
    """
    # check default options
    ie = ITVIE()
    assert ie._GEO_COUNTRIES == ['GB']
    assert ie._WORKING == True
    assert ie._downloader is None
    assert ie._geo_verification_headers is None
    assert ie._is_ssl is None
    assert ie._player_cache is None
    assert ie._player_cache_result is None
    assert ie._is_html5_sdk is None
    assert ie._html5_sdk_sd_url is None
    assert ie._html5_sdk_hd_url is None
    assert ie._html5_sdk_embed_code is None

# Generated at 2022-06-24 12:39:34.049010
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .brightcove import BrightcoveNewIE
    _ITVBTCCIE = ITVBTCCIE()
    assert isinstance(_ITVBTCCIE, ITVBTCCIE)


# Generated at 2022-06-24 12:39:44.235372
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/([0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:39:46.794797
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test if ITVBTCCIE properly constructed
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(url)

# Generated at 2022-06-24 12:39:51.128601
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor_test(ITVBTCCIE, {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
    })

# Generated at 2022-06-24 12:40:00.351496
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()

    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:40:03.738943
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE().url_result(
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'btcc-2018-all-the-action-from-brands-hatch',
        'https://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5610791726001',
    )

# Generated at 2022-06-24 12:40:04.784410
# Unit test for constructor of class ITVIE
def test_ITVIE():
  assert(ITVIE({}) != None)

# Generated at 2022-06-24 12:40:05.225826
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:40:13.250950
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE()._real_extract('https://www.itv.com/hub/liar/2a4547a0012')
    assert info["id"] == "2a4547a0012"
    assert info["title"] == "Liar - Series 2 - Episode 6"
    assert info["duration"] == 2748.739
    assert info["series"] == "Liar"
    assert info["season_number"] == 2
    assert info["episode_number"] == 6
    assert info["description"] == "The police investigate DI Andrew Earlham's death. A family is torn apart."


# Generated at 2022-06-24 12:40:23.097912
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_cases = [
        # Test case using the newest version of BrightcoveNewIE
        {
            'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
            'info_dict': {
                'id': 'btcc-2018-all-the-action-from-brands-hatch',
                'title': 'BTCC 2018: All the action from Brands Hatch',
            },
        },
    ]

    test_case = test_cases[0]
    url = test_case['url']

# Generated at 2022-06-24 12:40:30.935459
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']
    assert ie._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-24 12:40:39.466961
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_ = ITVBTCCIE('test', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert test_.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert test_.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:47.995340
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    tests = [{
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }]
    obj = ITVBTCCIE()
    for test in tests:
        assert obj._real_extract(test['url']) == test['info_dict']

# Generated at 2022-06-24 12:40:50.031323
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "http://www.itv.com/hub/liar/2a4547a0012"
    ITVIE()


# Generated at 2022-06-24 12:41:01.352445
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '5767697037001')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:02.670770
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE



# Generated at 2022-06-24 12:41:05.531580
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    if ie is None:
        raise RuntimeError


# Generated at 2022-06-24 12:41:07.605731
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()._get_brightcove_id("HkiHLnNRx_default")

# Generated at 2022-06-24 12:41:11.840491
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    def test_factory(url):
        ie = ITVBTCCIE()
        return ie.extract(url)

    sample_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_factory(sample_url)



# Generated at 2022-06-24 12:41:18.655323
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie.suitable(url)
    assert ie._downloader.params['geo_ip_blocks'] == [
        '193.113.0.0/16', '54.36.162.0/23', '159.65.16.0/21'
    ]

# Generated at 2022-06-24 12:41:26.199258
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch?vid=tvc:itvcom:btcc:races:btcc-2018-all-the-action-from-brands-hatch:episode-01:episode-01:77179&amp;bitrate=900&amp;width=638&amp;height=357')

# Generated at 2022-06-24 12:41:37.205814
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE()._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:41:40.373726
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert type(instance) == ITVBTCCIE
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:49.809260
# Unit test for constructor of class ITVIE
def test_ITVIE():
    def new_ITVIE(url):
        return ITVIE(url, ie=InfoExtractor.ie_key())

    assert new_ITVIE('https://www.itv.com/hub/liar/2a4547a0012').get('id') == '2a4547a0012'
    assert new_ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033').get('id') == '2a2271a0033'
    assert new_ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034').get('id') == '2a5159a0034'

# Generated at 2022-06-24 12:41:56.256977
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btccie = ITVBTCCIE()

    # Check the class constants are still valid
    assert btccie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert (btccie.BRIGHTCOVE_URL_TEMPLATE
            == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

    # Check the class methods have not been swapped around or removed
    assert hasattr(btccie, '_real_extract')
    assert hasattr(btccie, ' _match_id')
    assert hasattr(btccie, ' _og_search_title')


# Generated at 2022-06-24 12:42:02.002100
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccie = ITVBTCCIE()
    match = itvbtccie._match_id(url)
    assert match == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:42:03.827277
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:42:10.750582
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    suf = ITVBTCCIE(None)._ITVBTCCIE__get_constructor_params()

    assert suf.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert suf._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:42:15.375404
# Unit test for constructor of class ITVIE
def test_ITVIE():
  '''
  Test ITVIE for sample videos
  '''
  from .test_videos import TestVideos
  from . import ITVIE
  from . import VideoExtractor
  from . import extractor
  from . import context
  from . import utils
  import re
  import unittest
  import sys
  
  url_sample = "https://www.itv.com/hub/liar/2a4547a0012"
  type(ITVIE)
  ve_instance = ITVIE()
  ve_instance.url = url_sample
  type(ve_instance)
  type(ve_instance.url)
  ve_instance.suitable(url_sample)
  #ve_instance.gather_info()

# Generated at 2022-06-24 12:42:18.844489
# Unit test for constructor of class ITVIE
def test_ITVIE():
    constructor = ITVIE()
    # check if class is able to validate video urls
    assert ITVIE._VALID_URL == "https?://(?:www\\.)?itv\\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)"
    # check if class is able to download info from a video url
    constructor._download_json("https://www.itv.com/hub/liar/2a4547a0012", "2a4547a0012")

# Generated at 2022-06-24 12:42:30.211664
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    iTVBTCCIE = ITVBTCCIE()
    assert iTVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert iTVBTCCIE._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    assert iTVBTCCIE.BRIGHTCOVE

# Generated at 2022-06-24 12:42:33.414688
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    ITVIE("https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034")



# Generated at 2022-06-24 12:42:36.939973
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Unit test for ITVIE constructor
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(url)


# Generated at 2022-06-24 12:42:40.792840
# Unit test for constructor of class ITVIE
def test_ITVIE():
    t = ITVIE()
    assert t._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:42:50.238717
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(None)._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE(None)._GEO_COUNTRIES == ['GB']
    assert ITVIE(None)._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-24 12:42:56.743405
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    
    # Create an instance of class ITVIE
    ie = ITVIE()
    webpage = ie._download_webpage(url, 'test_video')
    params = extract_attributes(ie._search_regex(
            r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params'))
    ios_playlist_url = params.get('data-video-playlist') or params['data-video-id']
    hmac = params['data-video-hmac']
    headers = ie.geo_verification_headers()

# Generated at 2022-06-24 12:42:58.954606
# Unit test for constructor of class ITVIE
def test_ITVIE():
        # Call the constructor of ITVIE.
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-24 12:42:59.935745
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:43:01.017508
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.__doc__ is not None


# Generated at 2022-06-24 12:43:03.259048
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:13.954929
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    instance = ie.ie_key()
    assert (instance == 'brightcove:new')
    assert (ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')
    assert (ie._VALID_URL == '(?i)https?://(?:www\\.)?itv\\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)')

# Generated at 2022-06-24 12:43:14.601878
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE()
    except:
        assert False
    assert True

# Generated at 2022-06-24 12:43:15.468522
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:43:18.428847
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie= ITVIE()
    assert itv_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:43:19.322796
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVExtractor = ITVBTCCIE()

# Generated at 2022-06-24 12:43:28.034923
# Unit test for constructor of class ITVIE
def test_ITVIE():
    with open('test_data/test_json_schema_search') as f:
        test_json_schema_search = f.read()
    with open('test_data/test_webpage') as f:
        test_webpage = f.read()
    video_id='2a4547a0012'
    assert ITVIE._match_id(video_id,test_webpage)==video_id
    assert ITVIE._match_id(video_id,test_json_schema_search)==video_id
    assert ITVIE._real_extract({'url':video_id})

# Generated at 2022-06-24 12:43:28.642959
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:43:36.626452
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('http://www.itv.com/hub/liar/2a4547a0012')._match_id('http://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'
    assert ITVIE('http://www.itv.com/hub/through-the-keyhole/2a2271a0033')._match_id('http://www.itv.com/hub/through-the-keyhole/2a2271a0033') == '2a2271a0033'

# Generated at 2022-06-24 12:43:40.366656
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/tipping-point/1a5033a0040"
    video_info = ITVIE()
    info = video_info.extract(url)
    assert ('id' in info)

# Generated at 2022-06-24 12:43:44.778943
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'fake_url'
    ie = ITVIE(url)
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-24 12:43:47.054496
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:43:53.081014
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()

    class TestClass(object):
        def __init__(self, obj):
            self.obj = obj
    assert (ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId='), "[FAIL] ITVIE.BRIGHTCOVE_URL_TEMPLATE should equal 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=' but equals " + ie.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-24 12:43:54.646104
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:43:55.284918
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:43:59.574685
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Unit test for ITVIE
    """
    itv_ie = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert itv_ie.geo_verification_headers()[0][0] == 'X-Forwarded-For'

# Generated at 2022-06-24 12:44:08.606783
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:44:09.444841
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE("")

# Generated at 2022-06-24 12:44:14.514066
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    obj = ITVBTCCIE(None)

    # Test matching
    assert obj._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

    # Test extraction
    obj._real_extract(url)

# Generated at 2022-06-24 12:44:17.237354
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert instance.url == "https://www.itv.com/hub/liar/2a4547a0012"

# Generated at 2022-06-24 12:44:18.758289
# Unit test for constructor of class ITVIE

# Generated at 2022-06-24 12:44:29.590285
# Unit test for constructor of class ITVIE
def test_ITVIE():
    constructor_test(ITVIE, 'http://www.itv.com/hub/liar/2a4547a0012')
    constructor_test(ITVIE, 'http://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    constructor_test(ITVIE, 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    constructor_test(ITVIE, 'http://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')
    constructor_test(ITVBTCCIE, 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:44:39.321376
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-24 12:44:41.718075
# Unit test for constructor of class ITVIE
def test_ITVIE():
	print(ITVIE('https://www.itv.com/hub/liar/2a4547a0012', {}, True))

test_ITVIE()

# Generated at 2022-06-24 12:44:42.307569
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:44:43.199576
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()

# Generated at 2022-06-24 12:44:45.476543
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	"""
	Test case for constructor of class ITVBTCCIE
	"""
	return ITVBTCCIE(None)

# Generated at 2022-06-24 12:44:49.413105
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:44:52.770120
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(url)

# Generated at 2022-06-24 12:44:54.242999
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test ITVIE"""
    ITVIE(None)



# Generated at 2022-06-24 12:44:57.259995
# Unit test for constructor of class ITVIE
def test_ITVIE():
  #ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
  return True

# Generated at 2022-06-24 12:45:00.522578
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/x-factor/3b3bad68051')
    ITVIE('https://www.itv.com/hub/x-factor/2a4547a0012')

# Generated at 2022-06-24 12:45:01.167022
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:45:03.292067
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_ITVIE = ITVIE()
    # if assertTrue, test passes
    assert(test_ITVIE)


# Generated at 2022-06-24 12:45:08.374360
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE()
    assert test._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert test._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:45:09.881293
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_obj = ITVIE(InfoExtractor())
    assert isinstance(test_obj, ITVIE)


# Generated at 2022-06-24 12:45:12.577835
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert ITVIE._TESTS[0] == itvie.extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:45:17.476890
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert itv.url == "https://www.itv.com/hub/liar/2a4547a0012"
    assert itv.video_id == "2a4547a0012"

# Generated at 2022-06-24 12:45:30.183627
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    url_templete = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'

    response = ITVBTCCIE()._download_webpage(url, playlist_id)
    video_id = re.findall(r'data-video-id=["\'](\d+)', response)[0]
    url = ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % video_id

# Generated at 2022-06-24 12:45:33.310035
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    obj = ITVIE()
    obj.suitable(url)
    obj.extract(url)



# Generated at 2022-06-24 12:45:35.861246
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert(itv.name == 'ITV')

# Generated at 2022-06-24 12:45:37.498769
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:45:39.134844
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test ITVIE constructor
    itv_ie = ITVIE()
    assert isinstance(itv_ie, ITVIE)

# Generated at 2022-06-24 12:45:48.726872
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE._TEST['info_dict'] = {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}
    test_results = ITVBTCCIE._TEST.copy()
    test_results['info_dict']['id'] = ITVBTCCIE._TEST['info_dict']['id']
    test_results['info_dict']['title'] = ITVBTCCIE._TEST['info_dict']['title']
    assert(ITVBTCCIE._TEST == test_results)

# Generated at 2022-06-24 12:45:51.823693
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('ITVBTCCIE', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:45:59.775907
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:46:06.209086
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    video_id = 'btcc-2018-all-the-action-from-brands-hatch'
    BrightcoveNewIE.ie_key()
    #Video_id is the same as playlist_id
    assert ITVBTCCIE._match_id(url) == video_id

# Generated at 2022-06-24 12:46:14.173515
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE("www.itv.com/hub/liar/2a4547a0012")
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    webpage = ie._download_webpage(url, video_id)
    params = extract_attributes(ie._search_regex(
                r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params'))

    ios_playlist_url = params.get('data-video-playlist') or params['data-video-id']
    hmac = params['data-video-hmac']
    headers = ie.geo_verification_headers()

# Generated at 2022-06-24 12:46:24.087284
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:27.454736
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # Arrange
    # Constructor
    ITV = ITVIE()
    # Act
    # Assert
    # Test to see if '<class' is in the first part of the string
    assert '<class' in str(ITV).split(' ', 1)[0]

# Generated at 2022-06-24 12:46:35.264523
# Unit test for constructor of class ITVIE
def test_ITVIE():
	""" Test constructor of class ITVIE """
	video_id = '2a4547a0012'
	url = 'https://www.itv.com/hub/liar/' + video_id
	assert ITVIE._match_id(url) == video_id
	page = '<html><body><script>var data-my-param = "test";</script></body></html>'
	assert ITVIE._search_regex(r'(?s)(<[^>]+id="video"[^>]*>)', page, 'params').strip() == '<script>var data-my-param = "test";</script>'

# Generated at 2022-06-24 12:46:39.118492
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.IE_NAME == 'ITVBTCCIE'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:42.001348
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE._ITVIE__new__(None)
    assert info.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:48.272756
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video = ITVIE()._real_extract('https://www.itv.com/hub/liar/2a4547a0012')
    assert video['id'] == '2a4547a0012'
    assert video['ext'] == 'mp4'
    assert video['title'] == 'Liar - Series 2 - Episode 6'
    assert video['description'] == 'md5:d0f91536569dec79ea184f0a44cca089'
    assert video['series'] == 'Liar'
    assert video['season_number'] == 2
    assert video['episode_number'] == 6
    

# Generated at 2022-06-24 12:46:53.071949
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:47:00.488367
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_urls = [
        'https://www.itv.com/hub/liar/2a4547a0012',
        'https://www.itv.com/hub/through-the-keyhole/2a2271a0033',
        'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034',
        'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024'
    ]
    for url in test_urls:
        _ = ITVIE(url)

# Generated at 2022-06-24 12:47:10.676624
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    id = "2a4547a0012"
    geocountries = ['GB']
    tests = [{
        'url': url,
        'info_dict': {
            'id': id,
            'ext': 'mp4',
            'title': 'Liar - Series 2 - Episode 6',
            'description': 'md5:d0f91536569dec79ea184f0a44cca089',
            'series': 'Liar',
            'season_number': 2,
            'episode_number': 6,
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }]
    result = ITVIE._build_branch_