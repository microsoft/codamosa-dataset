

# Generated at 2022-06-24 12:37:02.933646
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print('ITVIE initialized.')

# Generated at 2022-06-24 12:37:05.244710
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    entry = ITVBTCCIE()
    entry_url = entry._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    entry_url
# end unit test

# Generated at 2022-06-24 12:37:12.113666
# Unit test for constructor of class ITVIE
def test_ITVIE():
    yt = ITVIE()
    yt.extract('https://www.itv.com/hub/liar/2a4547a0012')
    yt.extract('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    yt.extract('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    yt.extract('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')

# Generated at 2022-06-24 12:37:16.132331
# Unit test for constructor of class ITVIE
def test_ITVIE():
    _ITVIE = ITVIE()
    assert _ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:37:19.338717
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:37:24.100458
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.IE_NAME == 'itv:btcc'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:37:29.465258
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    ie = ITVBTCCIE()
    web_page = ie._download_webpage(url, "btcc-2018-all-the-action-from-brands-hatch")
    assert web_page

# Generated at 2022-06-24 12:37:39.942869
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ie._TEST['info_dict'] == {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}
    assert ie._TEST['playlist_mincount'] == 9

# Generated at 2022-06-24 12:37:42.959257
# Unit test for constructor of class ITVIE
def test_ITVIE():
	url = 'https://www.itv.com/hub/liar/2a4547a0012'
	extractor = ITVIE()
	assert(extractor.match_id(url) == '2a4547a0012')

# Generated at 2022-06-24 12:37:45.083275
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie.name == 'itv:btcc'

# Generated at 2022-06-24 12:37:56.060070
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE('someid', 'someurl')
    assert IE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:37:57.962644
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()

    # Check if class instance is initialized
    assert info_extractor is not None

# Generated at 2022-06-24 12:38:00.673861
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test instantiation of ITVBTCCIE class
    itvbtccie = ITVBTCCIE()

# Generated at 2022-06-24 12:38:04.984616
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = ITVBTCCIE._match_id(url)
    return ITVBTCCIE(url, playlist_id)

# Generated at 2022-06-24 12:38:08.150110
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    g = ITVIE()
    g.extract(url)

# Generated at 2022-06-24 12:38:09.127248
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:38:10.858336
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.__class__.__name__ == 'ITVIE'


# Generated at 2022-06-24 12:38:13.159743
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert not ITVBTCCIE()._VALID_URL('http://www.itv.com/btcc/nope')

# Generated at 2022-06-24 12:38:14.534986
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Unit test for constructor of class ITVIE
    """
    ITVIE()

# Generated at 2022-06-24 12:38:18.919722
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    iv = ITVIE(url)
    assert (iv.name() == 'ITVIE')

# Generated at 2022-06-24 12:38:29.444726
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    data_json = {
        'Playlist': {
            'Video': {
                'Title': 'The Voice UK',
                'Subtitle': 'Series 1 - Episode 1',
                'Synopses': {
                    'Small': 'Will.i.am, Danny O\'Donoghue, Jessie J and Tom Jones search for a singer to win a record deal.',
                },
                'EpisodeNumber': 1,
                'SeriesNumber': 1,
                'SeasonNumber': 1,
            },
        },
    }
    info = itv._info_from_json(data_json)

# Generated at 2022-06-24 12:38:34.253772
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_obj = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert test_obj._VALID_URL == "https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)"

# Generated at 2022-06-24 12:38:39.635228
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # To exercise the code path in ITVBTCCIE.__init__
    ITVBTCCIE(None).suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    ITVBTCCIE(None).extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:38:42.490466
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    input = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(input)

# Generated at 2022-06-24 12:38:44.022028
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TESTS[0].get('playlist_mincount') == 9

# Generated at 2022-06-24 12:38:47.815044
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructorTest(ITVBTCCIE, {
        '__name__' : 'ITVBTCCIE',
        'url' : 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'playlist_mincount' : 9,
        'info_dict' : {
            'id' : 'btcc-2018-all-the-action-from-brands-hatch',
            'title' : 'BTCC 2018: All the action from Brands Hatch'
        }
    })

# Generated at 2022-06-24 12:38:52.938936
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    obj = ITVBTCCIE()
    assert obj._TEST['url'] == url
    assert obj._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:38:56.788348
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Unit test for itv constructor. This is a test for a case where
    the json-ld is not present
    """
    result = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert result._JSON_LD_RE == JSON_LD_RE

# Generated at 2022-06-24 12:38:59.624468
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:39:06.826370
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    current_class = ITVBTCCIE('https://itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    current_class_dict = current_class.__dict__
    assert 'brightcove_channel' in current_class_dict
    assert 'brightcove_id_2' in current_class_dict
    assert 'brightcove_url_templates' in current_class_dict
    assert 'video_id' in current_class_dict

# Generated at 2022-06-24 12:39:14.519979
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert itvbtccie._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert itvbtccie._valid_url('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
                                ITVBTCCIE)

# Generated at 2022-06-24 12:39:15.658644
# Unit test for constructor of class ITVIE
def test_ITVIE():
    validate_class_construction(ITVIE, 'itv', 'https://www.itv.com/hub/good-morning-britain/2a5198a0028')

# Generated at 2022-06-24 12:39:22.073846
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() == 'itv:btcc'
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:39:24.304616
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:39:33.753784
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    inst = ITVBTCCIE()
    inst.url = url
    # assert if the class constructor was succesful
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:39:35.538739
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # 1) Test that a new instance of ITVBTCCIE can be constructed and then
    # accessed without causing an exception
    ITVBTCCIE()
    return True

# Generated at 2022-06-24 12:39:44.661204
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test inheritance and call of super
    url = ITVBTCCIE._TEST['url']
    _ = ITVBTCCIE(info_extractors=[ITVIE])
    playlist = ITVBTCCIE(info_extractors=[ITVIE])._real_extract(url)
    assert playlist['_type'] == 'playlist'
    assert playlist['entries']
    assert len(playlist['entries']) == ITVBTCCIE._TEST['playlist_mincount']
    assert playlist['title'] == ITVBTCCIE._TEST['info_dict']['title']
    assert playlist['id'] == ITVBTCCIE._TEST['info_dict']['id']

# Generated at 2022-06-24 12:39:50.987285
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE()
    assert test._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert test._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert test._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert test._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert test._TEST['playlist_mincount'] == 9
    assert test.BRIGHTCOVE_URL_T

# Generated at 2022-06-24 12:39:57.725900
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor = ITVBTCCIE
    assert constructor._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert constructor._TEST['info_dict'] == {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'BTCC 2018: All the action from Brands Hatch',
    }
    assert constructor._TEST['playlist_mincount'] == 9

# Generated at 2022-06-24 12:39:59.885285
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .brightcove import BrightcoveNewIE
    IE = ITVIE(BrightcoveNewIE)
    ff = IE._make_ffmpeg_extract_multiple_formats({}, {}, '', '', {})
    assert ff

# Generated at 2022-06-24 12:40:06.255245
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor_ITVBTCCIE = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    webpage_content = '<html><head><meta property="og:title" content="BTCC 2018: All the action from Brands Hatch"></head><body><div data-video-id="3000016852001"></div></body></html>'

# Generated at 2022-06-24 12:40:07.301337
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE("a", "b", "c", "d", "e", "f")

# Generated at 2022-06-24 12:40:08.783484
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Constructor test for ITVBTCCIE
    ITVBTCCIE()

# Generated at 2022-06-24 12:40:09.580290
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # check if ITVIE creates an instance of ITVIE
    ITVIE()


# Generated at 2022-06-24 12:40:13.672098
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVBTCCIE().extract('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ITVIE().extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:40:23.480601
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:40:31.041463
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE().url_result('http://www.itv.com/hub/the-chase/2a2937a3005', 'the-chase')
    ITVBTCCIE().url_result('http://www.itv.com/hub/the-chase/2a2937a3005?autostart=true', 'the-chase')
    ITVBTCCIE().url_result('http://www.itv.com/hub/the-chase/2a2937a3005?autoplay=true', 'the-chase')
    ITVBTCCIE().url_result('http://www.itv.com/hub/the-chase/2a2937a3005?autoStart=true', 'the-chase')

# Generated at 2022-06-24 12:40:33.195294
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie._VALID_URL
    assert ie._TEST
    assert ie._real_extract is not None

# Generated at 2022-06-24 12:40:35.209447
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:40:38.843129
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:40.464035
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:40:44.157754
# Unit test for constructor of class ITVIE
def test_ITVIE():
    result = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert isinstance(result, ITVIE)


# Generated at 2022-06-24 12:40:52.314942
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_cases = [{
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'playlist_id': 'btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch'
        }}]
    for test_case in test_cases:
        playlist_id = test_case['playlist_id']
        expected_title = test_case['info_dict']['title']
        ie = ITVBTCCIE(ITVBTCCIE._build_url(test_case['url']))

# Generated at 2022-06-24 12:40:54.784966
# Unit test for constructor of class ITVIE
def test_ITVIE():
	url = 'https://www.itv.com/hub/liar/2a4547a0012'
	ITVIE()._real_extract(url)

# Generated at 2022-06-24 12:41:03.891852
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class_ = ITVBTCCIE
    # it seems to be crucial that
    # class_.BRIGHTCOVE_URL_TEMPLATE
    # is present in the class definition
    # https://github.com/ytdl-org/youtube-dl/issues/21692
    assert(len(class_.BRIGHTCOVE_URL_TEMPLATE) > 10)
    # it is also crucial that
    # _VALID_URL = r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    # is present in the class definition
    # https://github.com/ytdl-org/youtube-dl/issues/21720
    assert(len(class_._VALID_URL) > 10)

# Generated at 2022-06-24 12:41:07.201361
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_verification_headers() == {'itv-viewer-country': 'GB'}

# Generated at 2022-06-24 12:41:13.537858
# Unit test for constructor of class ITVIE
def test_ITVIE():

    ITVIE_test = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    ITVIE_test.extract('https://www.itv.com/hub/liar/2a4547a0012')

    ITVIE_test = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    ITVIE_test.extract('http://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-24 12:41:17.764850
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Arrange
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"

    # Assert
    ITVBTCCIE(url)

# Generated at 2022-06-24 12:41:20.338296
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(
        InfoExtractor())._VALID_URL == r'https?://(www\.)?itv\.com/hub/[^/]+/\w+'

# Generated at 2022-06-24 12:41:21.360480
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)

# Generated at 2022-06-24 12:41:21.818925
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:41:29.888824
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import sys
    if sys.version_info[0] >= 3:
        # without this, doctests fail with the error:
        # ImportError: Failed to import test module: doctest
        # doctest does not work with python 3
        __test__ = {}
    else:
        __test__ = {"ITVBTCCIE": r'''
        >>> from itv import ITVBTCCIE
        >>> ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
        '''}

# Generated at 2022-06-24 12:41:33.286685
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Instantiating the ITVIE class
    ITVIE = ITVIE()

    # Checking for the ITVIE class constructor
    assert(ITVIE.SUCCESS == True)

# Generated at 2022-06-24 12:41:41.948291
# Unit test for constructor of class ITVIE
def test_ITVIE():
        inst = ITVIE()
        assert inst.__class__ is ITVIE
        assert inst._download_webpage.__class__ is ITVIE._download_webpage.__class__
        assert inst._match_id.__class__ is ITVIE._match_id.__class__
        assert inst._real_extract.__class__ is ITVIE._real_extract.__class__
        assert inst._html_search_meta.__class__ is ITVIE._html_search_meta.__class__
        assert inst._search_regex.__class__ is ITVIE._search_regex.__class__
        assert inst._json_ld.__class__ is ITVIE._json_ld.__class__
        assert inst._sort_formats.__class__ is ITVIE._sort_formats.__class__
        assert inst._extract_m

# Generated at 2022-06-24 12:41:48.569061
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Create an instance of class ITVIE
    itv_video = ITVIE()
    # Call _match_id method of ITVIE
    assert itv_video._match_id("https://www.itv.com/hub/liar/2a4547a0012") == "2a4547a0012"
    assert itv_video._match_id("https://www.itv.com/hub/through-the-keyhole/2a2271a0033") == "2a2271a0033"

# Generated at 2022-06-24 12:41:52.081087
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:57.824122
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie.suitable(url)
    assert ie.extract_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:41:59.648993
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    t = ITVBTCCIE()
    assert t is not None

# Generated at 2022-06-24 12:42:01.461672
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE(ITVBTCCIE._TEST)
    assert isinstance(test, ITVBTCCIE)

# Generated at 2022-06-24 12:42:07.693226
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    URL = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._TEST['url'] == URL
    assert ITVBTCCIE._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-24 12:42:18.978041
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Arrange
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    expect_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5875567626001'
    expect_playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    expect_title = 'BTCC 2018: All the action from Brands Hatch'

    # Act
    itvbtccie = ITVBTCCIE()
    actual_playlist = itvbtccie._real_extract(url)

    # Assert
    assert actual_playlist['entries'][0]['url'] == expect_url

# Generated at 2022-06-24 12:42:23.844322
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE._downloader).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:25.942897
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE("https://www.itv.com/hub/liar/2a4547a0012") != None


# Generated at 2022-06-24 12:42:28.870449
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Constructor of class ITVIE should not raise an exception.
    """
    ITVIE("http://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-24 12:42:35.753576
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TESTS[0].get('url') == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:42:41.849200
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor._VALID_URL.match('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert not info_extractor._VALID_URL.match('https://www.itv.com/hub/coronation-street/1a2568a0139')

# Generated at 2022-06-24 12:42:45.152553
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == \
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:49.128595
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Tests constructor
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:59.079075
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    sut = ITVBTCCIE()
    assert ("http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5792606420001",
            "5792606420001") == sut.url_result.result(sut.BRIGHTCOVE_URL_TEMPLATE % "5792606420001")
    assert ("http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5792606420001",
            "5792606420001") == sut.url_result.result(sut.BRIGHTCOVE_URL_TEMPLATE % "5792606420001")

# Generated at 2022-06-24 12:42:59.946868
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_ITVBTCCIE = ITVBTCCIE()

# Generated at 2022-06-24 12:43:02.625197
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    obj_itv = ITVIE(url)
    assert obj_itv is not None


# Generated at 2022-06-24 12:43:07.378533
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itv_ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:43:17.222900
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # provide URL and test case for constructor
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ITVBTCCIE._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    # provide variables for constructor
    ITVExtractorObj = ITVBTCCIE

# Generated at 2022-06-24 12:43:22.008087
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('http://www.itv.com', {})
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-24 12:43:32.312830
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    headers = ITVIE().geo_verification_headers()
    headers.update({
        'Accept': 'application/vnd.itv.vod.playlist.v2+json',
        'Content-Type': 'application/json',
        'hmac': '8175e55058daea76e7f2859edea65b8d68ee09ef',
    })

# Generated at 2022-06-24 12:43:34.820926
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Instantiate ITVIE class with url
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    ITVIE(url)

# Generated at 2022-06-24 12:43:39.757430
# Unit test for constructor of class ITVIE
def test_ITVIE():
    my_ITVIE = ITVIE(ITVIE._downloader)
    my_ITVIE._downloader = ITVIE._downloader
    my_ITVIE.to_screen = ITVIE.to_screen
    my_ITVIE.report_warning = ITVIE.report_warning
    my_ITVIE.report_error = ITVIE.report_error

# Generated at 2022-06-24 12:43:41.836265
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(InfoExtractor())._real_extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:43:43.310255
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE(None, {})
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-24 12:43:47.220531
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s', 'Constructor of class ITVIE not working'

# Generated at 2022-06-24 12:43:48.145391
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    assert test._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:43:49.430304
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:43:50.947004
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['url'] == ITVBTCCIE(ITVBTCCIE())._TEST['url']

# Generated at 2022-06-24 12:43:53.551518
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE._download_json('https://www.itv.com/hub/liar/2a4547a0012/2016/episode-6-series-2', '2a4547a0012', '{}')
    assert info['Playlist']['Video']['Title'] == 'Liar - Series 2 - Episode 6'

# Generated at 2022-06-24 12:43:57.886931
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_object = ITVIE()
    assert test_object.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:58.827836
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(InfoExtractor())

# Generated at 2022-06-24 12:44:04.445234
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._VALID_URL == "https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)"
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"

# Generated at 2022-06-24 12:44:05.646201
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie

# Generated at 2022-06-24 12:44:08.793448
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(None)._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:44:17.792123
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Check:
    1. Given meta-data in JSON-LD format is parsed correctly
    2. Given meta-data in JSON format is parsed correctly
    3. Given missing meta-data, an exception is thrown
    """
    s = '<script type="application/ld+json">{ "test": "json-ld" }</script>'
    i = ITVIE()
    assert i._extract_metadata_from_script(s) == { 'test': 'json-ld' }

    s = '<script type="application/json">{ "test": "json" }</script>'
    i = ITVIE()
    assert i._extract_metadata_from_script(s) == { 'test': 'json' }

    s = '<script type="application/json">{ "test": "json',
    i = ITVIE

# Generated at 2022-06-24 12:44:23.890846
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE()
    except TypeError as e:
        assert str(e) == '__init__() missing 1 required positional argument: \'url\''
    # Now check with url
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(url)

# Generated at 2022-06-24 12:44:26.412334
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv= ITVIE()
    # Check test video
    itv.extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:44:28.304193
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    print(test._VALID_URL)
    print(ITVIE._VALID_URL)


# Generated at 2022-06-24 12:44:31.460358
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """ITVIE should initialize correctly with no errors"""
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:44:36.477775
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVExtractor = ITVBTCCIE()
    assert ITVExtractor._VALID_URL == ITVBTCCIE._VALID_URL
    assert ITVExtractor._TEST == ITVBTCCIE._TEST
    assert ITVExtractor.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:44:37.874978
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """ITVBTCCIE"""
    ITVBTCCIE()

# Generated at 2022-06-24 12:44:47.584120
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_instance = ITVBTCCIE()
    if test_instance.BRIGHTCOVE_URL_TEMPLATE != 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s':
        raise AssertionError("Expected 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s', but got '%s'" % (test_instance.BRIGHTCOVE_URL_TEMPLATE, 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'))

# Generated at 2022-06-24 12:44:49.896974
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    ITVBTCCIE(old_extractor=ITVBTCCIE())._real_extract(url)

# Generated at 2022-06-24 12:44:50.448464
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:44:53.486307
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_video = "I am a test video string"
    test_ITVIE = ITVIE(test_video)
    assert test_ITVIE.url == test_video

# Generated at 2022-06-24 12:44:55.048891
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    sample = ITVBTCCIE()
    assert sample



# Generated at 2022-06-24 12:44:56.675552
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-24 12:45:00.763604
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IE = ITVBTCCIE(None)
    assert IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:09.805539
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    BTCC_URL = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    BTCC_VIDEO_ID = '5936487301001'
    BTCC_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:12.098435
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:45:12.733665
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:45:16.765909
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-24 12:45:19.014448
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")


# Generated at 2022-06-24 12:45:19.636815
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()

# Generated at 2022-06-24 12:45:21.711956
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == ITVIE.IE_NAME + ':' + ITVIE._VALID_URL

# Generated at 2022-06-24 12:45:26.314152
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ytbtccie = ITVBTCCIE()
    assert ytbtccie._real_extract(url)

# Generated at 2022-06-24 12:45:29.824447
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # ITVBTCCIE is a subclass of ITVIE.
    # This test assures that ITVIE.BRIGHTCOVE_URL_TEMPLATE is available for ITVBTCCIE
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:45:32.313037
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/jeremy-vine/2a8af5a0016'
    ITVIE()._real_extract(url)

# Generated at 2022-06-24 12:45:40.043498
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._match_id(
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._match_id(
        'http://www.itv.com/btcc/car/honda-civic/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:45:48.635498
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Random video of URL
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # Initialize constructor of ITVBTCCIE class
    ITVBTCCIE()
    # Instantiation of ITVBTCCIE class
    itvbtcc = ITVBTCCIE()
    # Now call extraction method of class ITVBTCCIE with url of video
    extractor = itvbtcc._real_extract(url)
    # Print the output
    print(extractor)

# Generated at 2022-06-24 12:45:50.305359
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')



# Generated at 2022-06-24 12:45:50.896997
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:45:59.424580
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    playID = 'btcc-2018-all-the-action-from-brands-hatch'
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    pl = ITVBTCCIE._build_playlist(playID, url)
    assert len(pl['entries']) >= 9 # there are at least this many videos
    for e in pl['entries']:
        assert re.match(r'^https?://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html\?videoId=\d+$', e['url']) is not None
        assert len(e['ie_key']) == 1

# Generated at 2022-06-24 12:46:04.125546
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE()
    test_url = "https://www.itv.com/hub/liar/2a4547a0012"
    assert obj.suitable(test_url) == True
    obj._download_webpage(test_url, "2a4547a0012")

# Generated at 2022-06-24 12:46:11.052757
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ies = (ITVBTCCIE(), ITVBTCCIE('btcc'))
    for itv_btcc_ie in itv_btcc_ies:
        assert itv_btcc_ie.IE_NAME == 'itvbtcc'
        assert itv_btcc_ie.IE_DESC == 'ITV BTCC'
        assert itv_btcc_ie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:46:15.742749
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert instance._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-24 12:46:17.696839
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:46:18.762897
# Unit test for constructor of class ITVIE
def test_ITVIE():
    return ITVIE.get_ITVIE()

# Generated at 2022-06-24 12:46:22.308490
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Checking whether constructor of class ITVBTCCIE is working
    a = ITVBTCCIE()
    assert isinstance(a, ITVBTCCIE)

# Generated at 2022-06-24 12:46:31.018878
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test1 = ITVIE('itv.com/hub/liar/2a4547a0012')
    assert test1._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert test1._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:46:35.223014
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE(None)
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:42.898789
# Unit test for constructor of class ITVIE

# Generated at 2022-06-24 12:46:43.474071
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:46:49.348113
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:46:54.584811
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:59.833924
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    # Test for http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch
    assert ie.url_result(ie.BRIGHTCOVE_URL_TEMPLATE % '5877128974001',
        'BrightcoveNew', '5877128974001') == {
        'id': '5877128974001',
        'display_id': '5877128974001',
        'url': ie.BRIGHTCOVE_URL_TEMPLATE % '5877128974001',
        'ie_key': 'BrightcoveNew',
        'title': None,
        'description': None,
        'thumbnail': None,
        'age_limit': 0,
    }

# Generated at 2022-06-24 12:47:10.639443
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_item = {
        'url': 'https://www.itv.com/hub/liar/2a4547a0012',
        'info_dict': {
            'id': '2a4547a0012',
            'ext': 'mp4',
            'title': 'Liar - Series 2 - Episode 6',
            'description': 'md5:d0f91536569dec79ea184f0a44cca089',
            'series': 'Liar',
            'episode_number': 6
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

    test_response = [test_item]
    ITVIE()._TESTS = test_response