

# Generated at 2022-06-24 12:37:06.551561
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:37:10.284833
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    i.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    print(i.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-24 12:37:12.339424
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test that arguments in constructor matches the constructors of all the
    # other extractors.
    ITVIE('http://url.com/whatever')

# Generated at 2022-06-24 12:37:13.765540
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(ITVBTCCIE._downloader)

# Generated at 2022-06-24 12:37:15.144842
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-24 12:37:23.553714
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IT = ITVBTCCIE()
    assert IT.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert IT._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:37:27.603523
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test to confirm ITVIE exists
    ITVIE()
    # Test to confirm ITVIE loads the right extractor
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')



# Generated at 2022-06-24 12:37:28.995111
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_verification_headers() is not None

# Generated at 2022-06-24 12:37:32.949358
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class_ = ITVIE()
    assert class_.__name__ == ITVIE.__name__
    assert class_.BRIGHTCOVE_URL_TEMPLATE == ITVIE.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-24 12:37:42.183460
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvbtccie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itvbtccie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:37:44.239176
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    # Tests if class ITVIE is a subclass of InfoExtractor
    assert issubclass(test.__class__, InfoExtractor)

# Generated at 2022-06-24 12:37:46.152460
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    itv_ie.geo_verification_headers()

# Generated at 2022-06-24 12:37:57.100497
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    #assert ITVIE._TESTS == [{
    #    'url': 'https://www.itv.com/hub/liar/2a4547a0012',
    #    'info_dict': {
    #        'id': '2a4547a0012',
    #        'ext': 'mp4',
    #        'title': 'Liar - Series 2 - Episode 6',
    #        'description': 'md5:d0f91536569dec79ea184f0a44cca089',
    #        'series': 'Liar',
    #        'season_number': 2,
   

# Generated at 2022-06-24 12:37:59.648673
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE.ie_key())._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-24 12:38:01.580889
# Unit test for constructor of class ITVIE
def test_ITVIE():
    check_ITVIE = ITVIE()
    assert check_ITVIE

# Generated at 2022-06-24 12:38:03.173528
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .common import args_string
    assert args_string(ITVBTCCIE())

# Generated at 2022-06-24 12:38:07.049470
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITest = ITVBTCCIE('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ITest

# Generated at 2022-06-24 12:38:08.759201
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Basic test to construct class ITVIE
    """
    ITVIE()


# Generated at 2022-06-24 12:38:10.104134
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    downloads2variables = {'btcc-2018-all-the-action-from-brands-hatch'}
    for dl in downloads2variables:
        assert dl

# Generated at 2022-06-24 12:38:12.411296
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')


# Generated at 2022-06-24 12:38:19.859620
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_obj = ITVIE()
    assert test_obj._GEO_COUNTRIES == ['GB']
    assert test_obj._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert test_obj._TESTS[0]['params'] == {'skip_download': True}


# Generated at 2022-06-24 12:38:30.341736
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE_Constructor = ITVBTCCIE()
    assert ITVBTCCIE_Constructor._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ITVBTCCIE_Constructor._TEST == {'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'info_dict': {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}, 'playlist_mincount': 9}
    assert ITVBTCCIE_Constructor.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-24 12:38:39.156693
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    video_id = 'btcc-2018-all-the-action-from-brands-hatch'
    inst = ITVBTCCIE(ITVBTCCIE.IE_NAME)
    inst._downloader = None
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert inst._match_id(url) == video_id

# Generated at 2022-06-24 12:38:40.043488
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('','')

# Generated at 2022-06-24 12:38:48.164921
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Constructor of the class ITVIE
    inst = ITVIE()

    # Check extracted value
    assert inst._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert inst._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:38:57.607023
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE(None, 'http://www.itv.com/hub/liar/2a4547a0012')
    assert info._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:39:02.862211
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url_ITV = 'https://www.itv.com/hub/liar/2a4547a0012'
    test_ITV = ITVIE()
    test_ITV.suitable(test_url_ITV) # test suitability
    test_ITV.extract(test_url_ITV)  # test extract()

# Generated at 2022-06-24 12:39:04.413857
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    global ITVBTCCIE
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:39:12.345472
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert (ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')
    assert (ie.geo_verification_headers()['x-forwarded-for'] == '193.113.0.0')
    assert (ie.geo_verification_headers()['x-forwarded-for'][0:10] == '193.113.0')
    return True

# Generated at 2022-06-24 12:39:13.649313
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test class constructor."""
    ITVBTCCIE()

# Generated at 2022-06-24 12:39:21.732091
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    ie = ITVBTCCIE()

# Generated at 2022-06-24 12:39:22.124314
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE

# Generated at 2022-06-24 12:39:23.022641
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()



# Generated at 2022-06-24 12:39:23.905178
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.__name__ == 'ITV'

# Generated at 2022-06-24 12:39:27.602178
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    inst = ITVBTCCIE(None)
    res = inst._real_extract(url)
    assert isinstance(res.get('id'), str)
    assert isinstance(res.get('entry_count'), int)

# Generated at 2022-06-24 12:39:30.540779
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:39:32.998042
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['url'] in ITVBTCCIE.__dict__['_VALID_URL']

# Generated at 2022-06-24 12:39:37.707471
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    expected = ITVBTCCIE()
    itv = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert json.loads(itv.__str__()) == json.loads(expected.__str__())



# Generated at 2022-06-24 12:39:40.223908
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:39:43.936368
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ie.IE_NAME == 'ITV:BTCC'

# Generated at 2022-06-24 12:39:45.269117
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)

# Generated at 2022-06-24 12:39:47.155887
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:39:50.394374
# Unit test for constructor of class ITVIE
def test_ITVIE():
    expected = ITVIE(InfoExtractor._downloader)._TESTS[0]
    actual = ITVIE(InfoExtractor._downloader)

# Generated at 2022-06-24 12:39:57.180458
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Constructor
    # Test for a valid url
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE(url)._VALID_URL == ITVIE._VALID_URL
    # Test for null url
    url = None
    assert ITVIE(url)._VALID_URL == ITVIE._VALID_URL
    # Test for empty string url
    url = ''
    assert ITVIE(url)._VALID_URL == ITVIE._VALID_URL


# Generated at 2022-06-24 12:39:59.765935
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import unittest
    class TestITVBTCCIE(unittest.TestCase):
        def test_ITVBTCCIE(self):
            self.assertTrue(ITVBTCCIE)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestITVBTCCIE)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-24 12:40:00.540359
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.__name__ == 'ITVBTCCIE'

# Generated at 2022-06-24 12:40:02.333063
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._TEST.get('title') == ie._real_extract(ie._TEST.get('url'))['title']

# Generated at 2022-06-24 12:40:07.912562
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_playlist_mincount = 9
    test_info_dict = {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'BTCC 2018: All the action from Brands Hatch',
    }

    t = ITVBTCCIE()

    test_res = t._real_extract(url)

    assert test_res['id'] == test_info_dict['id']
    assert test_res['title'] == test_info_dict['title']
    assert len(test_res['entries']) == test_playlist_mincount

# Generated at 2022-06-24 12:40:13.904011
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btccie = ITVBTCCIE()
    assert itv_btccie.IE_NAME == 'itv:btcc'
    assert itv_btccie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert list(itv_btccie._GEO_COUNTRIES) == ['GB']

# Generated at 2022-06-24 12:40:16.848900
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._get_base_url() == "http://players.brightcove.net/"
    assert ITVBTCCIE._valid_url(url, ITVBTCCIE._VALID_URL) != False


# Generated at 2022-06-24 12:40:25.129574
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    url = r'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = r'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:40:26.624532
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVIE()
    assert(x.IE_NAME == ITVIE.IE_NAME)

# Generated at 2022-06-24 12:40:31.629328
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034').video_id == '2a5159a0034'
    assert ITVIE('http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034').webpage_url == 'http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'



# Generated at 2022-06-24 12:40:32.953305
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE.find('%s') != -1

# Generated at 2022-06-24 12:40:35.064667
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	# Note : Test for constructor of class ITVBTCCIE
	ITVBTCCIE()


# Generated at 2022-06-24 12:40:38.481286
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:40:40.464243
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() == ITVBTCCIE.ie_key(type='brightcove_new') == 'ITVBTCC'

# Generated at 2022-06-24 12:40:41.509714
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """ Test constructor of ITVBTCCIE """
    ie = ITVBTCCIE()
    assert ie.IE_NAME == 'itv:itvbtcc'

# Generated at 2022-06-24 12:40:43.503408
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST.keys() == {'url', 'info_dict', 'playlist_mincount'}

# Generated at 2022-06-24 12:40:48.037527
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    info_extractor = ITVBTCCIE.ie_key()(url)
    assert info_extractor._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-24 12:40:52.366660
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:40:59.567213
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class ITVBTCCIE_test(ITVBTCCIE):
        def __init__(self, test, **kwargs):
            return ITVBTCCIE.__init__(self, test, **kwargs)

    # test for empty object
    ITVBTCCIE_test(None)

    # test for object with url
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE_test(url)

# Generated at 2022-06-24 12:41:01.921125
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    assert test.BRIGHTCOVE_URL_TEMPLATE == 'https', 'The URL to be downloaded'

# Generated at 2022-06-24 12:41:07.099170
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IT = ITVBTCCIE()
    assert IT.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    


# Generated at 2022-06-24 12:41:09.773908
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._download_webpage('https://www.itv.com/hub/liar/2a4547a0012', '2a4547a0012')

# Generated at 2022-06-24 12:41:12.632648
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:41:13.170643
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()

# Generated at 2022-06-24 12:41:15.241587
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:41:22.688853
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import unittest
    url = u'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    unittest.TextTestRunner().run(unittest.TestSuite([
        unittest.FunctionTestCase(
            lambda: ITVBTCCIE._match_id(url)),
        unittest.FunctionTestCase(
            lambda: ITVBTCCIE._real_extract(url)),
    ]))

if __name__ == '__main__':
    test_ITVBTCCIE()

# Generated at 2022-06-24 12:41:23.124952
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:41:32.794359
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('2a4547a0012')._match_id('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'
    #assert ITVIE('2a4547a0012')._match_id('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'
    #assert not ITVIE('2a4547a0012')._match_id('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0013'

# Generated at 2022-06-24 12:41:34.174667
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None).type()
    ITVIE(None).__name__

# Generated at 2022-06-24 12:41:39.995677
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE)._TEST == {
            'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
            'info_dict': {
                'id': 'btcc-2018-all-the-action-from-brands-hatch',
                'title': 'BTCC 2018: All the action from Brands Hatch',
            },
            'playlist_mincount': 9,
        }

# Generated at 2022-06-24 12:41:49.411201
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        # Constructor of the class
        resource_obj = ITVIE()
    except Exception as e:
        print(e)

# Generated at 2022-06-24 12:41:53.384360
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # check ITVIE constructor, some data is hardcoded
    class TestITVIE(ITVIE, object):
        pass
    ie = TestITVIE()
    assert ie._TEST == ITVIE._TEST
    assert ie._VALID_URL == ITVIE._VALID_URL
    # ensure class ITVIE is unchanged
    assert ITVIE(None)._TEST == _TESTS
    assert ITVIE(None)._VALID_URL == _VALID_URL

# Generated at 2022-06-24 12:42:00.958885
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    # Tested link is selected arbitrarily
    assert ITVIE._match_id(url) == '2a4547a0012'
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE._TESTS[1]['url'] == 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033'
    assert ITVIE._TESTS

# Generated at 2022-06-24 12:42:04.200613
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:06.301453
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-24 12:42:17.863780
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    playlist_id = 'a-playlist-id'
    url = 'http://www.itv.com/btcc/%s' % playlist_id
    # Construct a testcase for class ITVBTCCIE
    testcase = type('ITVBTCCIENTest', (object,), {'_match_id': lambda self, input_url: playlist_id, '_download_webpage': lambda self, url, playlist_id: '<div data-video-id="100">'})()
    # Initialize an instance of ITVBTCCIE
    itvbtccie = ITVBTCCIE()
    # Initialize the extractor
    itvbtccie.initialize()
    # Extract information from the testcase with the given id
    info_dict = itvbtccie.extract(url)
    # Check if the playlist id is

# Generated at 2022-06-24 12:42:19.980602
# Unit test for constructor of class ITVIE
def test_ITVIE():
    'Test ITVIE constructor'
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012', {})

# Generated at 2022-06-24 12:42:23.106588
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None, 'http://www.itv.com/hub/liar/2a4547a0012') is not None

# Generated at 2022-06-24 12:42:28.327151
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class Sample(ITVIE):
        def _real_extract(self, url):
            return {'url': url, 'id': self._match_id(url)}

    sample = Sample()
    assert sample._match_id('http://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'



# Generated at 2022-06-24 12:42:31.797185
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'
    assert ITVIE()._match_id(ITVIE.ie_key(), 'http://www.itv.com/hub/liar/2a4547a0012') == video_id


# Generated at 2022-06-24 12:42:39.599856
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:41.568821
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtcc = ITVBTCCIE()
    assert itvbtcc.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:42:49.386054
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE()
    inst.extract(
        'https://www.itv.com/hub/liar/2a4547a0012')
    inst.extract(
        'https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    inst.extract(
        'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    inst.extract(
        'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')


# Generated at 2022-06-24 12:42:59.198100
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import xml.etree.ElementTree
    import requests
    import json
    import os
    import sys

    #Test data
    playlist_url = "https://www.itv.com/hub/itv/2a4547a0019"
    r = requests.get(playlist_url)
    data = r.json()
    video_data = data['Playlist']['Video']
    ios_base_url = video_data.get('Base')

    class Video():
        def __init__(self):
            self.formats = []

    video = Video()

    itv = ITVIE

    for media_file in video_data.get('MediaFiles'):
        href = media_file.get('Href')
        if ios_base_url:
            href = ios_base_url + href

# Generated at 2022-06-24 12:43:01.372269
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:43:03.651347
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert isinstance(instance, ITVBTCCIE)
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-24 12:43:14.342826
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'


# Generated at 2022-06-24 12:43:15.357781
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE
    expected_result = ITVIE._VALID_URL
    assert instance._VALID_URL == expected_result

# Generated at 2022-06-24 12:43:18.614761
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:43:19.491174
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()
    ITVBTCCIE()

# Generated at 2022-06-24 12:43:30.250360
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    video_id = '5870999315001'
    item = ITVBTCCIE.url_result(
        smuggle_url(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % video_id, {
            'referrer': 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034',
        }), ie=BrightcoveNewIE.ie_key(), video_id=video_id)

# Generated at 2022-06-24 12:43:37.786671
# Unit test for constructor of class ITVIE
def test_ITVIE():
    with open("test_data/itv_page.txt") as f:
        webpage = f.read()

# Generated at 2022-06-24 12:43:38.238357
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-24 12:43:40.162073
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test construction of ITVIE class
    class TestITVIE(object):
        def __init__(self):
            self.ie = ITVIE()

    assert TestITVIE()

# Generated at 2022-06-24 12:43:49.237032
# Unit test for constructor of class ITVIE
def test_ITVIE():
    with open('test.html', 'r') as f:
        test_ITVIE = ITVIE(dict())
        test_ITVIE._download_webpage = lambda x, y: f
        test_ITVIE._search_regex = lambda x, y, z: y
        test_ITVIE._html_search_meta = lambda x, y: y
        test_ITVIE._search_json_ld = lambda x, y, z: z
        test_ITVIE._parse_json = lambda x, y, z: z
        test_ITVIE._extract_m3u8_formats = lambda x, y, z, **a: [{'test': 'success'}]
        test_ITVIE._real_extract('test')

# Generated at 2022-06-24 12:43:58.199091
# Unit test for constructor of class ITVIE
def test_ITVIE():
    data = {
       "title": "Liar - Series 2 - Episode 6",
       "description": "Laura’s suspicions about her father and Rose are growing, and she wants to know why Andrew has started seeing Dr Garrett. In the midst of all this, Andrew is about to discover he has a stalker in the form of Rose. Can she be trusted? Laura goes to see Rose and gets more than she bargained for."
    }

# Generated at 2022-06-24 12:43:59.487947
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-24 12:44:01.797838
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')



# Generated at 2022-06-24 12:44:06.226983
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print("Testing ITVIE constructor")
    print("Testing ITVIE constructor with 2a4547a0012")
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    print("Testing ITVIE constructor with 2a2271a0033")
    ITVIE("https://www.itv.com/hub/through-the-keyhole/2a2271a0033")
    print("Testing ITVIE constructor with 2a5159a0034")
    ITVIE("https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034")
    print("Testing ITVIE constructor with 2a2898a0024")

# Generated at 2022-06-24 12:44:10.982982
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE()
    obj.video_id = '2a4547a0012'
    url = obj._url()
    assert url == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert obj._match_id(url) == '2a4547a0012'

# Generated at 2022-06-24 12:44:14.260556
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE('https://www.itv.com/hub/liar/2a4547a0012', None, None)
    assert IE.title is None
    assert IE.description is None
    assert IE.duration is None

# Generated at 2022-06-24 12:44:17.030969
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "http://www.itv.com/hub/liar/2a4547a0012"
    ie = ITVIE(ITVIE._create_get_info_extractor(url))
    assert ie.url == url


# Generated at 2022-06-24 12:44:20.934856
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # In the constructor, the parameter 'ie' is constructed as
    # 'itvbtcc:%s' % ie_key(), however, the 'ie_key()' method will
    # return a class name without 'IE' suffix.
    assert ITVBTCCIE.ie_key() == 'ITVBTCC'



# Generated at 2022-06-24 12:44:31.705383
# Unit test for constructor of class ITVIE
def test_ITVIE():
    tester = ITVIE()
    assert tester.name == 'ITV'
    assert tester._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert tester.GEO_COUNTRIES == ['GB']

# Generated at 2022-06-24 12:44:34.678053
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(None)._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:44:37.942426
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    new_object = ITVBTCCIE()
    assert(new_object._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-24 12:44:38.734841
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:44:40.502896
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    a = ITVBTCCIE(ITVBTCCIE._downloader)
    assert a


# Generated at 2022-06-24 12:44:42.853249
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch');

# Generated at 2022-06-24 12:44:50.508437
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class Test(object):
        def __init__(self, init_test=None):
            self.test = init_test

    # Run the method to tests its functionality
    test = Test(Test)
    test.test = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    # Assert if the object test (expected object returned from method) is an instance of ITVBTCCIE
    assert(isinstance(test.test, ITVBTCCIE))


# Generated at 2022-06-24 12:44:51.634264
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(InfoExtractor())

# Generated at 2022-06-24 12:45:01.544766
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # test constructor of class ITVBTCCIE
    ie_object = ITVIE()
    # test method _real_extract(url) called by constructor
    assert len(ie_object._real_extract('https://www.itv.com/hub/liar/2a4547a0012')) == 9
    
    # test constructor of class ITVBTCCIE
    ie_object = ITVBTCCIE()
    # test method _real_extract(url) called by constructor
    assert len(ie_object._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')) == 2

# Generated at 2022-06-24 12:45:10.428386
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    This is a unit test for ITVIE.
    """
    # Define ITV object
    itv = ITVIE()
    # Define url to be tested in ITV object
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    # Extract video_id from url
    video_id = itv._match_id(url)
    # Download page
    webpage = itv._download_webpage(url, video_id)
    # Extract params
    params = extract_attributes(re.search(
        r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params').group(0))
    # Extract data-video-playlist
    ios_playlist_url = params.get('data-video-playlist')
   

# Generated at 2022-06-24 12:45:17.068202
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    ITVIE('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')

# Generated at 2022-06-24 12:45:18.885871
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test the constructor of class ITVBTCCIE
    itvbtccie = ITVBTCCIE()

# Generated at 2022-06-24 12:45:23.161075
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE()).brc_url_template == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:26.054963
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL
    assert ITVIE().TESTS == ITVIE._TESTS


# Generated at 2022-06-24 12:45:28.314129
# Unit test for constructor of class ITVIE
def test_ITVIE():
    m = ITVIE()
    m.extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:45:31.023087
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor.IE_DESC == 'ITV'

# Generated at 2022-06-24 12:45:31.669210
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-24 12:45:33.676421
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Basicly, test whether the class can be constructed
    ITVIE('http://www.itv.com/hub/david-attenboroughs-galapagos/2a2799a0184')

# Generated at 2022-06-24 12:45:36.999372
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    
    info = ITVBTCCIE()
    info.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/1582188683001/"
    
    print ("All unit tests are passed!")
    
test_ITVBTCCIE()

# Generated at 2022-06-24 12:45:41.677741
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    result = ITVBTCCIE()._real_extract(url)
    assert 'playlist_mincount' in result
    assert result['playlist_mincount'] == 9

# Generated at 2022-06-24 12:45:43.608308
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['playlist_mincount'] == 9

# Generated at 2022-06-24 12:45:48.635668
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:45:50.959612
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(ITVBTCCIE._TEST['info_dict'])._real_extract(url)

# Generated at 2022-06-24 12:45:54.740052
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:01.428415
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import urllib2

# Generated at 2022-06-24 12:46:06.061606
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()
    assert IE.__class__.__name__ == 'ITVIE'
    assert IE.IE_NAME == 'ITV'
    assert IE._VALID_URL == ITVIE._VALID_URL
    assert IE._TESTS == ITVIE._TESTS

# Generated at 2022-06-24 12:46:07.124346
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """test constructor of class ITVIE"""
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-24 12:46:10.192246
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE(ITVIE())
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    info_extractor.url_result(url, 'test')

# Generated at 2022-06-24 12:46:19.893327
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE()
    obj.init()
    obj._fetch_page(
        'https://www.itv.com/hub/liar/2a4547a0012',
        '2a4547a0012',
        headers=obj.geo_verification_headers(
            'https://www.itv.com/hub/liar/2a4547a0012'))
    obj._parse_json(
        '{"A": "B"}',
        '',
        fatal=True)

# Generated at 2022-06-24 12:46:21.163399
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() == 'ITVBTCC'

# Generated at 2022-06-24 12:46:29.061179
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/hub/all-star-musical/2a6612a0001"
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:38.808761
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from . import SparkTestCase
    from . import ITVBTCCIE

# Generated at 2022-06-24 12:46:41.682767
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-24 12:46:42.223378
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-24 12:46:44.151415
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    old_instance = ITVBTCCIE()
    new_instance = ITVBTCCIE()
    assert old_instance is not new_instance

# Generated at 2022-06-24 12:46:50.997801
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert info_extractor.IE_NAME == "itv:btcc"

# Generated at 2022-06-24 12:46:57.937119
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ie.suitable(test_url)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-24 12:46:59.713160
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-24 12:47:01.556765
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    # assert i
    pass

# Generated at 2022-06-24 12:47:03.642211
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(ITVExtractor())._VALID_URL == ITVIE._VALID_URL


# Generated at 2022-06-24 12:47:05.386047
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['info_dict'] == ITVBTCCIE()._real_extract(ITVBTCCIE._TEST['url'])['entries'][0]['info_dict']