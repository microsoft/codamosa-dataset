

# Generated at 2022-06-12 17:46:10.050271
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._real_extract('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-12 17:46:16.382682
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_video_id = "2a4547a0012"
    class_ = ITVIE
    result = class_(None)
    assert result._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert test_video_id in result._TESTS[0]['url']
    assert result._GEO_COUNTRIES == ['GB']


# Generated at 2022-06-12 17:46:17.636679
# Unit test for constructor of class ITVIE
def test_ITVIE():
        tester = ITVIE()
        print(tester)

# Generated at 2022-06-12 17:46:20.684795
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert isinstance(instance, ITVBTCCIE)
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-12 17:46:22.902958
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:46:35.091885
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class ITV_test(ITVIE):
        _VALID_URL = r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

        def _real_initialize(self):
            pass

    ITV_test_ = ITV_test(
        'http://www.itv.com/hub/liar/2a4547a0012',
        'https://www.itv.com/hub/liar/2a4547a0012',
        'https://www.itv.com/hub/liar/2a4547a0012',
        {'skip_download': True})


# Generated at 2022-06-12 17:46:35.657584
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE() is not None


# Generated at 2022-06-12 17:46:37.068543
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()._test_playlists()


# Generated at 2022-06-12 17:46:41.225587
# Unit test for constructor of class ITVIE
def test_ITVIE():
    m = ITVIE()
    assert m.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:46:41.832732
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-12 17:47:11.638182
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE._downloader)._VALID_URL == ITVBTCCIE._VALID_URL
    assert ITVBTCCIE(ITVBTCCIE._downloader)._TEST == ITVBTCCIE._TEST
    assert ITVBTCCIE(ITVBTCCIE._downloader).BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 17:47:13.357006
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.ie_key() == 'ITV'


# Generated at 2022-06-12 17:47:15.468712
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie

# Generated at 2022-06-12 17:47:25.153349
# Unit test for constructor of class ITVIE
def test_ITVIE():
    _ITVIE = ITVIE()
    test = {
        'url': 'https://www.itv.com/hub/liar/2a4547a0012',
        'info_dict': {
            'id': '2a4547a0012',
            'ext': 'mp4',
            'title': 'Liar - Series 2 - Episode 6',
            'description': 'md5:d0f91536569dec79ea184f0a44cca089',
            'series': 'Liar',
            'season_number': 2,
            'episode_number': 6,
        },
    }
    assert _ITVIE._real_extract(test['url']) == test['info_dict']

# Generated at 2022-06-12 17:47:26.772754
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(downloader=None)

# Generated at 2022-06-12 17:47:27.700394
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(None)._real_initialize()

# Generated at 2022-06-12 17:47:28.888598
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    c = ITVBTCCIE()

# Generated at 2022-06-12 17:47:31.872072
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:47:34.629759
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    ITVIE(url)

test_ITVIE()

# Generated at 2022-06-12 17:47:43.875612
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    exp_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5822886086001'
    ie = ITVBTCCIE()
    url = ie._url_result(test_url, 'exp_url', '5822886086001')
    assert url.url == exp_url
    assert url.ie_key() == 'BrightcoveNew'
    assert url.video_id == '5822886086001'

# Generated at 2022-06-12 17:48:36.377227
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor_test(ITVBTCCIE, {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    })

# Generated at 2022-06-12 17:48:46.175124
# Unit test for constructor of class ITVIE
def test_ITVIE():

    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    inst = ITVIE()
    inst.source_url = url
    inst.source_url = inst._match_id(url)
    inst.content_id = inst._match_id(url)
    inst.source_url = inst._match_id(url)
    inst.match_id = inst._match_id(url)
    inst.id = inst._match_id(url)
    inst.content_id = inst._match_id(url)
    inst.match_id = inst._match_id(url)
    inst._real_extract()


# Generated at 2022-06-12 17:48:48.461479
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:48:57.316368
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Constructor of class ITVBTCCIE is a bit special
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = ITVBTCCIE._match_id(url)
    playlist = ITVBTCCIE(ITVBTCCIE._create_get_info_extractor(playlist_id)())

    assert playlist.BRIGHTCOVE_URL_TEMPLATE
    assert playlist.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:58.178127
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	ITVBTCCIE()

# Generated at 2022-06-12 17:49:06.436800
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    class_name = ie.__class__.__name__
    assert isinstance(ie, ITVBTCCIE), 'Instance of class %s expected, but instance of class %s created' % (class_name, ie.__class__.__name__)
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:49:08.972422
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:49:09.566824
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:49:12.167284
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test ITVIE class constructor"""
    ITVIE("http://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-12 17:49:13.813162
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert 'itv' in itv._downloader.IE_DESC

# Generated at 2022-06-12 17:50:10.553670
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test the ITVIE constructor when it is a show."""
    ITVIE('https://www.itv.com/hub/emmerdale/2a2905a0013')


# Generated at 2022-06-12 17:50:17.168207
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class_ = ITVIE
    # Instantiate a ITVIE class
    hypothetical_itv_IE = class_('itv:%s' % '2a4547a0012')
    # Make sure the class hasn't changed
    assert isinstance(hypothetical_itv_IE, ITVIE)
    # Make sure the class is using the correct _VALID_URL regex
    assert hypothetical_itv_IE._VALID_URL == (
        r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')

# Generated at 2022-06-12 17:50:18.928670
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert str(ie) == 'itv.com BTCC info extractor'

# Generated at 2022-06-12 17:50:21.859178
# Unit test for constructor of class ITVIE
def test_ITVIE():
    t = ITVIE()
    assert t.IE_NAME == 'itv'
    assert t.BRIGHTCOVE_URL_TEMPLATE == ''


# Generated at 2022-06-12 17:50:24.997611
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url1 = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE._match_id(url1) == '2a4547a0012'

# Generated at 2022-06-12 17:50:27.065407
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012", {'skip_download': True})

# Generated at 2022-06-12 17:50:32.779183
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    data = ITVIE()._real_extract(url)
    assert data['id'] == '2a4547a0012'
    assert data['title'] == 'Liar - Series 2 - Episode 6'
    assert data['series'] == 'Liar'
    assert data['season_number'] == 2
    assert data['episode_number'] == 6
    assert data['duration'] == 7266.0
    assert data['description'] == 'md5:d0f91536569dec79ea184f0a44cca089'

# Generated at 2022-06-12 17:50:35.722051
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    with ie.build_opener() as opener:
        ie._opener = opener
        ie._downloader = mock.Mock()
        ie._downloader.cache.load, ie._downloader.cache.store = (
            lambda *args: None, lambda *args: None)
        ie._real_initialize()

# Generated at 2022-06-12 17:50:39.518355
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:50:44.292286
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)')
    assert(ie._TEST['info_dict'] == {'id': 'btcc-2018-all-the-action-from-brands-hatch','title': 'BTCC 2018: All the action from Brands Hatch'})

# Generated at 2022-06-12 17:52:11.125227
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # constructor of class ITVIE
    itv_ie = ITVIE()

    # Unit test for _VALID_URL
    # valid URL, including '&'
    assert itv_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

    # Unit test for _GEO_COUNTRIES
    assert itv_ie._GEO_COUNTRIES == ['GB']

    # Unit test for _TESTS

# Generated at 2022-06-12 17:52:13.383180
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None, url='https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:52:15.358957
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')

# Generated at 2022-06-12 17:52:21.579806
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert btcc.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert btcc._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:52:23.429232
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    t = ITVBTCCIE()
    assert t.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:52:29.015749
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():

    i = ITVBTCCIE()

    i.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:52:33.179906
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == ITVIE._VALID_URL
    assert ie._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert ie._TESTS == ITVIE._TESTS

# Generated at 2022-06-12 17:52:41.291049
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # Initialise a new ITVIE object
    itv_object = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

    # Assert that video_id was correctly set
    assert itv_object._video_id == '2a4547a0012'

    # Assert that the _VALID_URL property has been correctly set
    assert itv_object._VALID_URL == 'https?://(?:www\\.)?itv\\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

    # Assert that expected GEO countries have been correctly set
    assert itv_object._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:52:45.218999
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    instance = ITVBTCCIE()
    result = instance._real_extract(test_url)
    assert len(result['entries']) == 9

# Generated at 2022-06-12 17:52:48.292510
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:55:26.909212
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvIE = ITVIE()
    assert itvIE._VALID_URL == "https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)"


# Generated at 2022-06-12 17:55:27.581708
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE.test()


# Generated at 2022-06-12 17:55:31.022545
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE()._real_extract('http://www.itv.com/hub/liar/2a4547a0012')
    assert info['id'] == '2a4547a0012'
    assert info['title'] == 'Liar - Series 2 - Episode 6'
    assert info['description'] == 'md5:d0f91536569dec79ea184f0a44cca089'
    assert info['series'] == 'Liar'
    assert info['season_number'] == 2
    assert info['episode_number'] == 6

# Generated at 2022-06-12 17:55:31.777404
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE({})._VALID_URL

# Generated at 2022-06-12 17:55:41.898049
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = "2a2271a0033"

# Generated at 2022-06-12 17:55:42.515137
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:55:44.953536
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE({})._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
