

# Generated at 2022-06-12 17:46:11.493436
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_object = ITVIE()
    assert (test_object._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')

# Generated at 2022-06-12 17:46:15.730258
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert(instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')
    assert(instance.IE_NAME == 'itv:btcc')



# Generated at 2022-06-12 17:46:25.225347
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._GEO_COUNTRIES == ['GB']
    assert ITVIE._TESTS[0]['url'] == url
    assert ITVIE._TESTS[0]['info_dict']['id'] == '2a4547a0012'
    assert ITVIE._TESTS[0]['info_dict']['title'] == 'Liar - Series 2 - Episode 6'

# Generated at 2022-06-12 17:46:25.846564
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:46:32.135115
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    inst = ITVBTCCIE()
    result = inst._real_extract(url)
    # The playlist length is 9, which is hardcoded,
    # and is not likely to change
    assert len(result['entries']) == 9

# Generated at 2022-06-12 17:46:43.118598
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    expected_result = {
        'id': u'2a4547a0012',
        'ext': u'mp4',
        'title': u'Liar - Series 2 - Episode 6',
        'description': u'md5:d0f91536569dec79ea184f0a44cca089',
        'series': u'Liar',
        'season_number': 2,
        'episode_number': 6,
    }

    itv = ITVIE()
    assert(itv.suitable(url))
    assert(itv.extract(url) == expected_result)

# Generated at 2022-06-12 17:46:51.109383
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert(btcc.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')
    assert(btcc._valid_url('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == True)
    assert(btcc._valid_url('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == True)
   

# Generated at 2022-06-12 17:46:58.015115
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    if ITVIE().suitable(url):
        assert ITVIE().suitable(url) == True, "ITVIE is suitable for url"
        assert ITVIE()._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)', "ITVIE._VALID_URL: " + ITVIE()._VALID_URL
    

# Generated at 2022-06-12 17:47:03.341238
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # ITVIE inherits InfoExtractor, which is an abstract class so
    # we can only test if methods throw exceptions.
    obj = ITVIE()
    obj._download_webpage = lambda url, video_id: ''
    with obj._downloader.tmp_filename() as tmp_file:
        obj._dump_webpage(tmp_file, 'foo')

# Generated at 2022-06-12 17:47:07.623153
# Unit test for constructor of class ITVIE
def test_ITVIE():
    results = ITVIE()._extract_url_and_id('https://www.itv.com/hub/liar/2a4547a0012')
    assert results == ('https://www.itv.com/hub/liar/2a4547a0012', '2a4547a0012')

# Generated at 2022-06-12 17:47:26.211028
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    # download webpage and get video_id
    video_id = ITVIE._match_id(url)

    # instantiate ITVIE object and call _real_extract method
    itv = ITVIE()
    info_dict = itv._real_extract(url)

    # extract video_id from the result
    assert info_dict['id'] == video_id
    assert info_dict['title'] == 'Liar - Series 2 - Episode 6'


# Generated at 2022-06-12 17:47:26.751969
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:47:29.367300
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    url = 'http://www.itv.com/btcc'
    info_extractor.url_result(url, type='regular')

# Generated at 2022-06-12 17:47:33.840832
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """ITVIE test constructor."""

    ITVE = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert ITVE.name == 'ITVIE'

# Generated at 2022-06-12 17:47:35.477699
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # This is a URL for a valid ITV.com video
    ITVIE('2a4547a0012')

# Generated at 2022-06-12 17:47:40.408451
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video = ITVIE(url)

    assert video.url == url
    assert video.valid_url == url
    assert video.video_id == '2a4547a0012'
    assert video.geo_countries == ['GB']

# Generated at 2022-06-12 17:47:51.124618
# Unit test for constructor of class ITVIE
def test_ITVIE():
	ie = ITVIE()
	assert(ie.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s")
	assert(ie.geo_verification_headers() == {'x-forwarded-for': '31.54.159.189'})
	assert(ie.geo_bypass() == True)
	assert(ie._GEO_COUNTRIES == ['GB'])
	assert(ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')
	assert(ie.get_brightcove_id('html') == None)

# Generated at 2022-06-12 17:47:52.080905
# Unit test for constructor of class ITVIE
def test_ITVIE():
    constructor_test(ITVIE)
    constructor_test(ITVBTCCIE)

# Generated at 2022-06-12 17:47:58.813399
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_cases = [('https://www.itv.com/hub/liar/2a4547a0012', True),
            ('https://www.itv.com/hub/through-the-keyhole/2a2271a0033', True),
            ('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034', True),
            ('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024', True),
            ('https://www.itv.com/hub/britains-biggest-diamonds/2a3875a0030', False),
            ('https://www.itv.com/hub/search-for-a-star', False)]


# Generated at 2022-06-12 17:48:04.616025
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = ITVIE._VALID_URL % '2a4547a0012'
    result = ITVIE(url).get_result()
    assert result['id'] == '2a4547a0012'
    assert result['title'] == 'Liar - Series 2 - Episode 6'
    assert result['description'] == 'md5:d0f91536569dec79ea184f0a44cca089'
    

# Generated at 2022-06-12 17:48:21.883326
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # since this test would require mocking some API responses,
    # it is excluded from the regular tests
    itv_btcc_ie = ITVBTCCIE()
    assert (itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE ==
        "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s")

# Generated at 2022-06-12 17:48:25.694702
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:48:26.321177
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(object)

# Generated at 2022-06-12 17:48:31.072612
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test for self.BRIGHTCOVE_URL_TEMPLATE
    BRIGHTCOVE_PLAYER_URL = "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId="
    BRIGHTCOVE_VIDEO_ID = '1582188656001'
    ITVIE()._real_extract(BRIGHTCOVE_PLAYER_URL + BRIGHTCOVE_VIDEO_ID)

# Generated at 2022-06-12 17:48:39.826961
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    if ITVBTCCIE is not ITVBTCCIE:   # avoid pyflakes unsed import warning
        raise Exception("Must remove ITVBTCCIE from import list of YoutubePlaylistsIE.")
    # The url of BTCC playlist at ITV website contains %20 blanks
    url = 'http://www.itv.com/btcc/races/btcc%202018%20overview'
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '5800057882001' in ITVBTCCIE()._real_extract(url)['entries'][0]['url']
    # The url without %20 blanks
    url = 'http://www.itv.com/btcc/races/btcc-2018-overview'
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPL

# Generated at 2022-06-12 17:48:44.271500
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    ie = ITVIE()
    assert ie._match_id(url) == "2a4547a0012"
    assert ie._real_extract(url)['title'] == "Liar - Series 2 - Episode 6"

# Generated at 2022-06-12 17:48:55.100052
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    main_page = '<html><head>'\
        '<meta property="og:title" content="ITV BTCC">'\
        '<meta property="og:url" content="http://www.itv.com/btcc/">'\
        '<meta property="og:type" content="website">'\
        '<meta property="og:description" content="ITV BTCC">'\
        '<meta property="og:image" content="http://www.itv.com/hub/btcc/2a3592a">'\
        '</head><body></body></html>'

# Generated at 2022-06-12 17:48:58.327896
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._real_extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:48:59.762525
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.api_url == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:49:01.669222
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE({'geo_verification_headers': {'x-forwarded-for': '8.8.8.8'}})

# Generated at 2022-06-12 17:49:20.667895
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    To test whether the class is well constructed
    """
    url = url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    actual_url = ITVBTCCIE._VALID_URL
    expected_url = 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert actual_url == expected_url

# Generated at 2022-06-12 17:49:21.595991
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-12 17:49:24.627138
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert result

# Generated at 2022-06-12 17:49:31.073593
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()

    # Check if tests are running
    # TODO: move to more appropriate place
    if IE._downloader is None:
        IE._downloader = mock_downloader()

    # Test for class method valid_url
    assert not IE.valid_url("http://itv.com/hub/i am a fake url")
    assert IE.valid_url("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-12 17:49:41.232209
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from ytdl.extractor import YouTubeIE
    from ytdl.extractor.common import InfoExtractor
    from ytdl.extractor.brightcove import BrightcoveNewIE
    #Test object initialization
    IE = ITVIE(InfoExtractor._downloader, 'https://www.itv.com/hub/liar/2a4547a0012')
    #Test objct of class BrightcoveNewIE
    br = BrightcoveNewIE(InfoExtractor._downloader, 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5718295156001')
    #Test object of class YoutubeIE

# Generated at 2022-06-12 17:49:44.448497
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == ITVIE._VALID_URL
    assert ie._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert ie._TESTS == ITVIE._TESTS

# Generated at 2022-06-12 17:49:45.351032
# Unit test for constructor of class ITVIE
def test_ITVIE():
    a = ITVIE()
    assert a

# Generated at 2022-06-12 17:49:50.463984
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor_test = ITVBTCCIE()
    assert info_extractor_test._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert info_extractor_test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:49:52.123847
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    initial = {
        "title": 'title',
        "url": 'url',
    }
    created = ITVBTCCIE(initial)
    assert "title" in created
    assert "url" in created


# Generated at 2022-06-12 17:49:53.155035
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert ITVIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:50:33.802099
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import inspect
    members = inspect.getmembers(InfoExtractor)
    members = dict(members)
    assert members["ITVIE"][1].__name__ == "ITVIE"


# Generated at 2022-06-12 17:50:36.251183
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._real_extract("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-12 17:50:38.043136
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE == type(ITVBTCCIE())

# Generated at 2022-06-12 17:50:45.952820
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print('Test for ITV.com')
    ITVIE_test = ITVIE()
    ITVIE_test._downloader.params['geo_bypass'] = True
    print('Collect info for "Liar - Series 2 - Episode 6"')
    IVTIE_info = ITVIE_test.url_result('http://www.itv.com/hub/liar/2a4547a0012')
    ITVIE_test._downloader.process_info(IVTIE_info)
    print('Collect info for "Through the Keyhole"')
    ITVIE_test.url_result('http://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    print('Collect info for "James Martins Saturday Morning"')

# Generated at 2022-06-12 17:50:48.153821
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:50:49.928853
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()
    ITVBTCCIE()

# Generated at 2022-06-12 17:50:54.727088
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info = ITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert info['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert info['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-12 17:50:59.830978
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE()
    assert inst._BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert inst._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    return 0

# Generated at 2022-06-12 17:51:02.166815
# Unit test for constructor of class ITVIE
def test_ITVIE():
    extractor = ITVIE()
    assert ITVIE.__name__ == 'ITVIE'

# Generated at 2022-06-12 17:51:03.596109
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:52:23.041868
# Unit test for constructor of class ITVIE
def test_ITVIE():
    '''
    Test for ITV (itv.com)
    '''
    ITVIE()._get_videos_info('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:52:26.756811
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.IE_NAME == ITVIE.IE_NAME
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ITVIE.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-12 17:52:37.726529
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert obj._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-12 17:52:39.544361
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(ITVBTCCIE._TEST)

# Generated at 2022-06-12 17:52:42.237571
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(None)._real_extract(url)

# Generated at 2022-06-12 17:52:45.607508
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:52:51.026690
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    ie = ITVBTCCIE(url)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-12 17:52:52.402993
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Arrange
    itv_ie = ITVIE()
    # Act
    # Assert
    assert itv_ie



# Generated at 2022-06-12 17:52:56.211933
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE("https://www.itv.com/hub/liar/2a4547a0012")._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:53:05.736077
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    class_ = ITVBTCCIE(cachedir='')
    assert class_._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'