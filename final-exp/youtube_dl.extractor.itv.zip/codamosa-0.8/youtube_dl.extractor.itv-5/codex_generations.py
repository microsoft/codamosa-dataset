

# Generated at 2022-06-12 17:46:15.886458
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvbtccie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:46:17.790300
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert result._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:46:19.671993
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012", None)

# Generated at 2022-06-12 17:46:20.288997
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-12 17:46:29.663516
# Unit test for constructor of class ITVIE
def test_ITVIE():
    actual_video_id = '2a4547a0012'
    expected_video_id = 'bf47a9e0-3e3b-0132-8edb-4437f60823e2'

    itvIEInstance = ITVIE()
    actual_extracted_video_id = itvIEInstance._get_video_id('https://www.itv.com/hub/liar/2a4547a0012')

    assert(actual_video_id == actual_extracted_video_id)
    assert(expected_video_id == itvIEInstance._get_video_id(actual_video_id))


# Generated at 2022-06-12 17:46:33.298670
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE()._real_extract(url)

# Generated at 2022-06-12 17:46:35.234660
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    tst = ITVBTCCIE()
    assert tst is not None

# Generated at 2022-06-12 17:46:38.890697
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012', 'https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-12 17:46:41.646867
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:46:49.618284
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Arrange
    from .test_common import TestMain
    from .test_brightcove import TestBrightcoveNew
    from .brightcove import BrightcoveNewIE
    from .brightcove_legacy import BrightcoveLegacyIE

    # Act
    ITVIE.IE_NAME = 'ITV'
    ITVIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    BrightcoveNewIE.ie_key = lambda: 'brightcove_new'
    BrightcoveLegacyIE.ie_key = lambda: 'brightcove_legacy'

    # Assert
    ITVIE.test = lambda self: TestMain(self).run()
   

# Generated at 2022-06-12 17:47:04.550353
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:47:14.218965
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert(itv_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')
    assert(itv_ie._GEO_COUNTRIES == ['GB'])

# Generated at 2022-06-12 17:47:17.620004
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # test a valid url
    # test an invalid url, e.g. 'https://www.itv.com/hub/itv'
    pass

# Generated at 2022-06-12 17:47:22.234172
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert(itvbtccie.BRIGHTCOVE_URL_TEMPLATE) ==  'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:47:24.383772
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']
    assert len(ie._TESTS) == 4


# Generated at 2022-06-12 17:47:27.051118
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """make sure it's constructed properly"""
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:47:29.195798
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE('', '')
    assert itv.geo_countries == itv._GEO_COUNTRIES

# Generated at 2022-06-12 17:47:34.382542
# Unit test for constructor of class ITVIE
def test_ITVIE():
    xt = ITVIE(None)
    assert xt.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:47:35.169581
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()

# Generated at 2022-06-12 17:47:46.085450
# Unit test for constructor of class ITVIE
def test_ITVIE():
    with open('test/test_data/itv.json') as f:
        itv_json = json.load(f)
    with open('test/test_data/itv_ios_playlist_sherlock.json') as f:
        ios_playlist_json = json.load(f)
    with open('test/test_data/itv_ios_playlist_emmerdale.json') as f:
        ios_playlist_json_em = json.load(f)
    with open('test/test_data/itv_ios_playlist_liar.json') as f:
        ios_playlist_json_liar = json.load(f)

# Generated at 2022-06-12 17:48:16.086794
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-12 17:48:16.519380
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:48:19.483030
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Unit test for constructor of class ITVBTCCIE
    """
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:22.789800
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE('http://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')
    except Exception:
        print("Exception raised in constructor")
        assert False

# Generated at 2022-06-12 17:48:27.098576
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(InfoExtractor()).extract(url)

# Generated at 2022-06-12 17:48:29.348291
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    TV = ITVBTCCIE()
    assert TV
    assert ITVBTCCIE._VALID_URL
    assert ITVBTCCIE._TEST
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 17:48:30.750723
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')

# Generated at 2022-06-12 17:48:34.834328
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    except:
        return False
    return True

# Generated at 2022-06-12 17:48:38.311036
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Tests that constructor of ITVBTCCIE correctly assigns values to the variables."""
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:44.004996
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()

    assert (ie.IE_NAME) == 'itv:btcc'
    # ie.BRIGHTCOVE_URL_TEMPLATE is not a static attribute
    assert (ie.BRIGHTCOVE_URL_TEMPLATE) == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:49:40.856824
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    if ITVBTCCIE is not None:
        ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-12 17:49:44.794328
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # test ITVIE.__init__()
    ITVIE.__init__()
    # test ITVIE._real_extract()
    test1 = ITVIE()
    test1._real_extract('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-12 17:49:51.638034
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    entries = [
        {
            'id': '5857509540001',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        }
    ]
    for e in entries:
        assert ITVBTCCIE.url_result(
            'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == e
        assert BrightcoveNewIE._extract_brightcove_url(
            ITVBTCCIE.url_result('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')) == e

# Generated at 2022-06-12 17:49:54.342843
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url='http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

    def test_ITVBTCCIE(self, url):
        ITVBTCCIE(self, url)

    test_ITVBTCCIE(test_url)

# Generated at 2022-06-12 17:50:01.314239
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    inst = ITVIE(ITVIE())
    assert inst._VALID_URL == ITVIE._VALID_URL
    inst._match_id(url)
    inst._real_extract(url)

# Generated at 2022-06-12 17:50:01.805423
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-12 17:50:03.910056
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE()
    assert obj.geo_countries == ['GB']

# Generated at 2022-06-12 17:50:04.753508
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE()
    assert obj

# Generated at 2022-06-12 17:50:07.264049
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(InfoExtractor())._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:50:08.754257
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    c = ITVBTCCIE({"geo_blocked": False})
    assert c

# Generated at 2022-06-12 17:52:46.327850
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert ITVIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVIE._GEO_COUNTRIES == ['GB']


# Generated at 2022-06-12 17:52:47.108796
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('4')

# Generated at 2022-06-12 17:52:50.256995
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._GEO_COUNTRIES == ['GB']

# Unit tests for constructor of class ITVBTCCIE

# Generated at 2022-06-12 17:52:57.403275
# Unit test for constructor of class ITVIE
def test_ITVIE():
    v_id = '2a4547a0012'
    v_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    title = 'Liar - Series 2 - Episode 6'
    desc = 'md5:d0f91536569dec79ea184f0a44cca089'
    assert ITVIE({})._real_extract({'url': v_url, 'ie_key': 'ITV'}) == {
        'id': v_id,
        'title': title,
        'description': desc,
        'episode_number': 6,
        'season_number': 2,
        'series': 'Liar',
    }


# Generated at 2022-06-12 17:52:58.302045
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(ITVIE())



# Generated at 2022-06-12 17:52:58.822229
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-12 17:53:00.438212
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.__name__ == 'ITVIE'

# Generated at 2022-06-12 17:53:02.784991
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    if len(instance._TESTS) == 1:
        print('Unit test for ITVBTCCIE OK')


# Generated at 2022-06-12 17:53:09.993064
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        TEST = ITVBTCCIE._TEST
    except AttributeError:
        return

    url = TEST['url']
    playlist_id = TEST['info_dict']['id']

    webpage_test = {}
    webpage_test['webpage'] = 'BTCC 2018: All the action from Brands Hatch'
    webpage_test['url'] = url
    webpage_test['playlist_id'] = playlist_id

    webpage_test['mincount'] = TEST.get('playlist_mincount', len(webpage_test['webpage']))

    webpage = webpage_test['webpage']
    playlist_id = webpage_test['playlist_id']


# Generated at 2022-06-12 17:53:11.769048
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        a = ITVBTCCIE()
        assert True
    except:
        assert False