

# Generated at 2022-06-12 17:46:09.640697
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()

# Generated at 2022-06-12 17:46:12.584314
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert inst._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-12 17:46:15.811856
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:46:24.292247
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE(ITVBTCCIE.IE_NAME)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.BTCC_URL_TEMPLATE == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ie.BTCC_RE == 'http://www.itv.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:46:29.223418
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import unittest
    class ITVIETest(unittest.TestCase):

        def test_itvie(self):
            self.assertTrue(ITVIE("itv-test").test_test_test("test"))
    unittest.main()

test_ITVIE()

# Generated at 2022-06-12 17:46:34.481951
# Unit test for constructor of class ITVIE
def test_ITVIE(): 
    ie = ITVIE('http://www.itv.com/hub/britains-best-home-cook/2a4614a0009')
    assert ie.URL == 'https://www.itv.com/hub/britains-best-home-cook/2a4614a0009'

# Generated at 2022-06-12 17:46:36.955769
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._real_extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:46:47.046969
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # A constructor of class ITVBTCCIE
    instance1 = ITVBTCCIE()
    # The attributes of the instance of class ITVBTCCIE
    # print("instance1.BRIGHTCOVE_URL_TEMPLATE:", instance1.BRIGHTCOVE_URL_TEMPLATE)
    assert instance1.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    # print("instance1.VALID_URL:", instance1.VALID_URL)

# Generated at 2022-06-12 17:46:50.445709
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:46:56.264599
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class ConstrTest(ITVBTCCIE):
        def __init__(self, *args, **kwargs):
            super(ConstrTest, self).__init__(*args, **kwargs)

        def _real_extract(self, *args, **kwargs):
            pass

    ConstrTest('http://www.itv.com/hub/paul-o-gradys-australia/2a2536a0006')._real_extract()

# Generated at 2022-06-12 17:47:10.913724
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print ("Testing ITVIE")
    ITVIE()
    print ("test passed")
test_ITVIE()


# Generated at 2022-06-12 17:47:11.786596
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE({},{})

# Generated at 2022-06-12 17:47:13.795156
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._real_extract("http://www.itv.com/hub/liar/2a4547a0012")


# Generated at 2022-06-12 17:47:17.497585
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    vo = ITVBTCCIE("")
    assert vo.__class__.__name__ == 'ITVBTCCIE'

# Generated at 2022-06-12 17:47:27.283449
# Unit test for constructor of class ITVIE
def test_ITVIE():
    for url, expectations in ITVIE._TESTS:
        test = ITVIE(ITVIE())
        test._downloader = object
        test.to_screen = lambda x: None
        test._cache = None
        test._real_initialize()
        test.initialize()
        test.extract(url)
        test.report_download_webpage(url)
        assert expectations['id'] == test._match_id(url), "{0} != {1}".format(expectations['id'], test._match_id(url))

# Generated at 2022-06-12 17:47:36.038007
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    print("ITVIE:")
    print("Id = " + ie.id)
    print("Title = " + ie.title)
    print("Ext = " + ie.ext)
    print("Description = " + ie.description)
    print("Series = " + ie.series)
    print("Season_number = " + str(ie.season_number))
    print("Episode_number = " + str(ie.episode_number))

# Generated at 2022-06-12 17:47:37.096853
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()


# Generated at 2022-06-12 17:47:41.217997
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test ITVIE constructor
    url = 'http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    test_obj = ITVIE(url)
    assert test_obj is not None

# Generated at 2022-06-12 17:47:44.976470
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-12 17:47:53.309824
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._TEST['info_dict'] == {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'BTCC 2018: All the action from Brands Hatch',
    }
    assert ITVBTCCIE._TEST['playlist_mincount'] == 9


# Generated at 2022-06-12 17:48:20.915841
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert isinstance(info_extractor, ITVIE)


# Generated at 2022-06-12 17:48:25.642045
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:26.653499
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE(None)

# Generated at 2022-06-12 17:48:29.911541
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:48:30.855476
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from . import ITVBTCCIE
    x = ITVBTCCIE()

# Generated at 2022-06-12 17:48:31.887534
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert ITVIE.__module__ == 'youtube_dl.extractor.itv'

# Generated at 2022-06-12 17:48:34.298906
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    # Default value of BRIGHTCOVE_URL_TEMPLATE
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:38.421725
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor.__class__ == ITVBTCCIE
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-12 17:48:45.700796
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result_holder = {}
    def _test_itv_btcc_constructor(self, **kwargs):
        result_holder['kwargs'] = kwargs

    original_constructor = ITVBTCCIE.__init__
    ITVBTCCIE.__init__ = _test_itv_btcc_constructor
    try:
        ie = ITVBTCCIE()
        assert result_holder['kwargs']['http_headers'] == ie.geo_verification_headers()
    finally:
        ITVBTCCIE.__init__ = original_constructor

# Generated at 2022-06-12 17:48:47.770050
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE(None)
    assert itvbtccie != None

# Generated at 2022-06-12 17:49:40.412085
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['url'] == ITVBTCCIE._VALID_URL % ITVBTCCIE._TEST['info_dict']['id']

# Generated at 2022-06-12 17:49:45.621242
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    assert test._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:49:47.225364
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class MyIE(ITVIE):
        pass

    MyIE.ie_key()



# Generated at 2022-06-12 17:49:49.208978
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    for test_url in ITVBTCCIE._TESTS:
        instance = ITVBTCCIE(test_url)
        assert test_url['url'] == instance._TEST['url']

# Generated at 2022-06-12 17:49:52.655009
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    c = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    c.url = url
    assert(c._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch')


# Generated at 2022-06-12 17:50:01.691570
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITB = ITVBTCCIE()
    assert ITB._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ITB.BRIGHTCOVE_URL_TEMPLATE ==  'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:50:04.408690
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Constructor of ITVBTCCIE class should also be called
    # with an object as argument
    assert isinstance(ITVBTCCIE(ITVBTCCIE()), ITVBTCCIE)

# Generated at 2022-06-12 17:50:10.672148
# Unit test for constructor of class ITVIE
def test_ITVIE():
    #Test with video URL
    video_url = "https://www.itv.com/hub/liar/2a4547a0012"
    ie = ITVIE(InfoExtractor())
    assert ie._match_id(video_url) == "2a4547a0012"
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

    #Test with playlist URL
    playlist_url = "https://www.itv.com/hub/through-the-keyhole/2a2271a0033"
    ie = ITVIE(InfoExtractor())
    assert ie._match_id(playlist_url) == "2a2271a0033"
    assert ie._

# Generated at 2022-06-12 17:50:11.920063
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'ITV'



# Generated at 2022-06-12 17:50:21.367585
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Basic test for constructor of ITVBTCCIE class."""
    IE_BTCC = ITVBTCCIE()
    assert IE_BTCC._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert IE_BTCC._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert IE_BTCC._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-12 17:52:45.572245
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .constructor_test import ConstructorTest
    return ConstructorTest(ITVIE)


# Generated at 2022-06-12 17:52:48.905304
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:52:54.624462
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from . import ITVBTCCIE
    from . import BrightcoveNewIE
    from . import smuggle_url
    from .common import InfoExtractor
    from .brightcove import BrightcoveNewIE

    iTVBTCCIE = ITVBTCCIE()
    assert iTVBTCCIE.brIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert isinstance(iTVBTCCIE.brIGHTCOVE_URL_TEMPLATE, str)
    assert isinstance(iTVBTCCIE.BRIGHTCOVE_URL_TEMPLATE, str)

# Generated at 2022-06-12 17:52:58.083565
# Unit test for constructor of class ITVIE
def test_ITVIE():
    object = ITVIE()
    assert object._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert object._GEO_COUNTRIES == ['GB']


# Generated at 2022-06-12 17:53:01.291244
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:53:04.281923
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE()
    assert test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:53:06.378928
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = ITVBTCCIE._TEST['url']
    assert ITVBTCCIE._VALID_URL.match(url) is not None

# Generated at 2022-06-12 17:53:10.704652
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_btcc = ITVBTCCIE()
    assert test_btcc.BRIGHTCOVE_URL_TEMPLATE.split('%s')[0] == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId='
    assert test_btcc._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:53:17.136734
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._VALID_URL == ITVBTCCIE._TEST['url']
    print(ITVBTCCIE._TEST['url'])
    print(ITVBTCCIE._TEST['info_dict'])
    print(ITVBTCCIE._TEST['playlist_mincount'])
    regex = re.compile(ITVBTCCIE._VALID_URL)
    print(regex.match(ITVBTCCIE._TEST['url']))



# Generated at 2022-06-12 17:53:19.506260
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITV_URL = 'https://www.itv.com/hub/liar/2a4547a0012'
    test_itv = ITVIE()
    assert test_itv._VALID_URL == ITVIE._VALID_URL