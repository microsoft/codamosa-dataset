

# Generated at 2022-06-12 17:46:17.477241
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    d = ITVBTCCIE()
    assert d._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert d._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert d._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert d.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:46:28.784857
# Unit test for constructor of class ITVIE
def test_ITVIE():
    TestClass = type('TestClass', (object,), {
        '_real_extract': ITVIE._real_extract,
        '_download_webpage': lambda self, url, video_id: {
            'url': url,
            'video_id': video_id,
        }
    })

    # Existing video
    sample_url = 'https://www.itv.com/hub/liar/2a4547a0012'

    expected_result = {
        'url': sample_url,
        'video_id': '2a4547a0012',
    }

    test_obj = TestClass()
    assert test_obj._download_webpage(sample_url, '2a4547a0012') == expected_result

# Generated at 2022-06-12 17:46:30.366477
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    s = ITVBTCCIE()
    assert isinstance(s, ITVBTCCIE)

# Generated at 2022-06-12 17:46:32.774582
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class options:
        geo_verification_proxy = ''
    instance = ITVIE(options)
    assert instance is not None

# Generated at 2022-06-12 17:46:35.142264
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # create instance of ITVBTCCIE class
    itvbtccie = ITVBTCCIE()

# Generated at 2022-06-12 17:46:35.704274
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()

# Generated at 2022-06-12 17:46:36.333904
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)

# Generated at 2022-06-12 17:46:40.404528
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Unit test for constructor of class ITVBTCCIE
    """
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:46:48.909033
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # The URL for ITVIE
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE_test = ITVIE()
    ITVIE_test._download_webpage = lambda url: 'data'
    ITVIE_test.geo_verification_headers = lambda: {}
    ITVIE_test.extract_origin_url = lambda url: 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE_test._match_id = ITVIE._match_id
    ITVIE_test._real_extract = ITVIE._real_extract

    # Check that the instance of the object ITVIE_test is correct
    assert ITVIE_test._download_webpage
    assert ITVIE_test.geo_verification_headers

# Generated at 2022-06-12 17:46:58.209975
# Unit test for constructor of class ITVIE
def test_ITVIE():
    infoExtractorClass = ITVIE()
    assert infoExtractorClass._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert infoExtractorClass._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:47:14.581112
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # tests the ctor of ITVIE
    itvie = ITVIE(None)
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itvie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:47:20.427550
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IT = ITVIE('http://www.itv.com','1','1','1','1','1','1','1','1','1')
    assert(IT._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')

# Generated at 2022-06-12 17:47:23.875979
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITBBC = ITVBTCCIE()
    assert ITBBC.brighcove_url_template() == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:47:25.829869
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE()
    assert isinstance(itv, ITVIE)
    assert isinstance(itv, ITVBTCCIE)

# Generated at 2022-06-12 17:47:27.899459
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:47:37.833152
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .test import TestIE
    instance = ITVBTCCIE(TestIE().test_result())
    instance.BRIGHTCOVE_URL_TEMPLATE = None
    instance.BRIGHTCOVE_URL_TEMPLATE = ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert instance._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert instance._real_extract(url)

# Generated at 2022-06-12 17:47:38.849745
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()

# Generated at 2022-06-12 17:47:41.855859
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:47:51.824261
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:47:52.916954
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert isinstance(ie, ITVIE)


# Generated at 2022-06-12 17:48:06.513879
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:48:09.285457
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    return ITVBTCCIE

# Generated at 2022-06-12 17:48:16.752051
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
    'playlist_mincount': 9,
    }

# Generated at 2022-06-12 17:48:22.194333
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_cases = [
        # (is_valid_url, containing_page)
        (False, 'not a ITV URL'),
        (False, '''
<html>
  <a href="https://www.itv.com/hub/liar/2a4547a0012">test</a>
</html>
'''),
        (True, '''
<html>
  <a href="https://www.itv.com/hub/liar/2a4547a0012">test</a>
</html>
'''),
        (True, 'https://www.itv.com/hub/liar/2a4547a0012'),
    ]

    for is_valid_url, containing_page in test_cases:
        assert ITVIE._isURL(containing_page) == is_valid_url

# Generated at 2022-06-12 17:48:31.555812
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert obj._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:35.148470
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:37.382978
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # BrightcoveNewIE is used for extraction of the final video
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE.format("abc") == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=abc'

# Generated at 2022-06-12 17:48:44.652484
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # The json.loads below would raise a ValueError exception if class ITVIE is not called
    data = '{"explicit_content_check":false,"url":"https://www.itv.com/hub/liar/2a4547a0012","_ui":{"__SYS_PLAYER_DIGITAL_VIDEO":[],"__SYS_PLAYER_DIGITAL_AUDIO":[]},"channel_namespace":"__SYS_PLAYER_DIGITAL_VIDEO","ui_ns_set":true}'
    json.loads(data)

# Generated at 2022-06-12 17:48:46.228680
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE()
    assert obj.__class__.__name__ == "ITVIE"

# Generated at 2022-06-12 17:48:50.394293
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()
    assert IE.name == 'itv'
    assert IE.IE_NAME == 'itv'
    assert IE.BRIGHTCOVE_URL_TEMPLATE is None


# Generated at 2022-06-12 17:49:09.759629
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert i._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-12 17:49:10.555248
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE()
    assert isinstance(instance, ITVIE)

# Generated at 2022-06-12 17:49:11.385032
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(None)._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-12 17:49:12.473811
# Unit test for constructor of class ITVIE
def test_ITVIE():
  assert ITVIE.__bases__[0].__name__ == 'InfoExtractor'


# Generated at 2022-06-12 17:49:16.138563
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:49:22.618383
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    test_info = ITVBTCCIE()._real_extract(url)
    assert test_info is not None
    assert test_info["title"] == "BTCC 2018: All the action from Brands Hatch"
    assert test_info["id"] == "btcc-2018-all-the-action-from-brands-hatch"
    assert len(test_info["entry"]) == 9



# Generated at 2022-06-12 17:49:33.005595
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    assert test._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert test._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:49:43.511295
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test url to be used in test_urls
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

    # Declarations for unit test
    ITVBTCCIE_test = ITVBTCCIE()
    playlist_id = ITVBTCCIE_test._match_id(url)
    webpage = ITVBTCCIE_test._download_webpage(url, playlist_id)

# Generated at 2022-06-12 17:49:45.923106
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    instance = ITVIE(url)
    assert instance is not None


# Generated at 2022-06-12 17:49:47.531746
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:50:28.647135
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()

# Generated at 2022-06-12 17:50:30.591337
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE()
    inst._match_id(inst._VALID_URL)
    inst.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 17:50:34.667890
# Unit test for constructor of class ITVIE
def test_ITVIE():

    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ob_itv_ie = ITVIE()
    re_match = re.match(r'https?://(?:www\.)?itv\.com/hub/(?P<id>[^/]+)/(?P<display_id>[0-9a-zA-Z]+)', url)
    assert ob_itv_ie._match_id(url) == re_match.group('display_id')

# Generated at 2022-06-12 17:50:38.276089
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    ITVIE('http://www.itv.com/hub/through-the-keyhole/2a2271a0033')

if __name__ == '__main__':
    test_ITVIE()

# Generated at 2022-06-12 17:50:39.920190
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_instance = ITVIE()
    assert isinstance(itv_instance, ITVIE)

# Generated at 2022-06-12 17:50:42.500073
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test ITVIE constructor."""
    assert (ITVIE._valid_url(ITVIE._VALID_URL, ITVIE._GEO_COUNTRIES)
            is not None)


# Generated at 2022-06-12 17:50:44.782209
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'

    assert ITVIE._VALID_URL.match(url)
   

# Generated at 2022-06-12 17:50:55.436385
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE(None)
    assert info._VALID_URL is ITVIE._VALID_URL

# Generated at 2022-06-12 17:50:57.278994
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    # test if the class constructor is valid
    assert i.__class__.__name__ == 'ITVIE'

# Generated at 2022-06-12 17:51:07.269833
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test case
    url = ITVBTCCIE._TEST['url']
    # Expected output
    playlist_id = ITVBTCCIE._TEST['info_dict']['id']
    title = ITVBTCCIE._TEST['info_dict']['title']
    mincount = ITVBTCCIE._TEST['playlist_mincount']
    # Test: constructor
    assert ITVBTCCIE(None)._match_id(url) == playlist_id, "Failed to match %s with id" % (url,)
    assert ITVBTCCIE(None)._TEST['info_dict']['title'] == title
    assert ITVBTCCIE(None)._TEST['playlist_mincount'] == mincount

# Generated at 2022-06-12 17:52:25.027621
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-12 17:52:31.003289
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    #get the instance of ITVIE
    ITVIE(object)
    #get the webpage for that url
    webpage = ITVIE._download_webpage(ITVIE,url,ITVIE._match_id(ITVIE,url))
    #extract the attributes from the webpage
    params = extract_attributes(ITVIE._search_regex(
        ITVIE, r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params'))
    print(params)
    

# Generated at 2022-06-12 17:52:32.103681
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE

# Generated at 2022-06-12 17:52:40.174932
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # 
    # Note that the urls can change in the future
    # 
    test_urls = [
        'https://www.itv.com/hub/liar/2a4547a0012',
        'https://www.itv.com/hub/through-the-keyhole/2a2271a0033',
        'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034',
        'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024'
    ]
    for url in test_urls:
        ITVIE()._real_extract(url)

# Generated at 2022-06-12 17:52:46.328506
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Unit test for constructor of class ITVIE, testing regex matching
    """
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    itv = ITVIE()
    match = itv._match_id(url)
    assert match == '2a4547a0012'
    match = itv._extract_brightcove_id(url)
    assert match == '2a4547a0012'

# Generated at 2022-06-12 17:52:48.550000
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # There is no other way to test a class constructor
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:52:49.397685
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie != None

# Generated at 2022-06-12 17:52:51.719197
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IE_NAME = 'itv:btcc'
    ie = ITVBTCCIE(ITVBTCCIE.create_ie(IE_NAME))
    assert ie.IE_NAME == IE_NAME


# Generated at 2022-06-12 17:52:52.422214
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    print(ITVBTCCIE)


# Generated at 2022-06-12 17:52:54.170524
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert hasattr(ITVBTCCIE, "suitable")
    assert hasattr(ITVBTCCIE, "_real_extract")

# Generated at 2022-06-12 17:55:40.792565
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    ITVIE("https://www.itv.com/hub/through-the-keyhole/2a2271a0033")
    ITVIE("https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034")
    ITVIE("https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024")

# Generated at 2022-06-12 17:55:42.404126
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.ie_key() == 'ITV'


# Generated at 2022-06-12 17:55:43.767291
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(None)._real_extract(ITVBTCCIE._TEST['url'])

# Generated at 2022-06-12 17:55:44.238410
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-12 17:55:50.871503
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ie._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ie._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch/') == 'btcc-2018-all-the-action-from-brands-hatch'