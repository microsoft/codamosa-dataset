

# Generated at 2022-06-12 17:46:17.638898
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch
    # this url contains 9 brightcove video
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    url_result = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5835549904001'
    class_test = ITVBTCCIE()
    assert class_test._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:46:22.489702
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    # create an instance of ITVIE
    instance = ITVIE(url)
    # extract video id
    video_id = instance._match_id(url)
    # check video id is equal to test video id
    assert video_id == '2a4547a0012'

# Generated at 2022-06-12 17:46:34.427910
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
        Unit test for constructor of class ITVBTCCIE
    """
    import sys
    import unittest

    if sys.version_info < (3,6):
        class NewITVBTCCIE_TestCase(unittest.TestCase):
            def test_now_requires_python36(self): pass
            test_now_requires_python36.__doc__ = "Requires >= Python 3.6"

        del NewITVBTCCIE_TestCase

    else:
        # Test requires Python 3.6
        from datetime import datetime, timezone

        class NewITVBTCCIE_TestCase(unittest.TestCase):
            def setUp(self):
                self.parser = ITVBTCCIE()


# Generated at 2022-06-12 17:46:40.754757
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034")
    ITVIE("http://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024")
    ITVIE("http://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-12 17:46:42.459052
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE(None)
    assert ie
    assert isinstance(ie, ITVIE)
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, BrightcoveNewIE)

# Generated at 2022-06-12 17:46:44.694863
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # check if constructor raises an error when no _VALID_URL given
    url = 'http://www.itv.com'
    ITVBTCCIE(url)

# Generated at 2022-06-12 17:46:48.628395
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE(ITVBTCCIE._build_fake_extractor({}, url))
    assert ie._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:46:51.004626
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert '5890527328001' == itvie._match_id('https://www.itv.com/hub/liar/2a4547a0012')



# Generated at 2022-06-12 17:46:51.931493
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()


# Generated at 2022-06-12 17:46:53.768877
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Unit test for constructor of class ITVBTCCIE"""
    assert ITVBTCCIE is not None

# Generated at 2022-06-12 17:47:16.101757
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    id = ITVIE._match_id(url)
    assert id == '2a4547a0012'
    assert ITVIE._is_valid_url(url, id)
    assert ITVIE._is_valid_url(url, '123') is False
    assert ITVIE._is_valid_url(url, '2a4547a0012')

    assert ITVBTCCIE._is_valid_url(
        'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:47:21.495904
# Unit test for constructor of class ITVIE
def test_ITVIE():
    iev = ITVIE()
    assert iev._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert iev._GEO_COUNTRIES == ['GB']


# Generated at 2022-06-12 17:47:22.143780
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-12 17:47:23.440670
# Unit test for constructor of class ITVIE
def test_ITVIE():
    b = ITVIE()
    assert b._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:47:28.589585
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-12 17:47:34.589076
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IE = ITVBTCCIE()
    assert IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s', "Unexpected value for BRIGHTCOVE_URL_TEMPLATE"

# Generated at 2022-06-12 17:47:36.216073
# Unit test for constructor of class ITVIE
def test_ITVIE():
    Obj = ITVIE()
    # assert that the ITVIE class has been instantiated
    assert Obj is not None

# Generated at 2022-06-12 17:47:43.621600
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    for url, title in [("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch", "BTCC 2018: All the action from Brands Hatch")]:
        i = ITVBTCCIE(url)
        assert i._TEST['info_dict']['title'] == title
        assert i._TEST['info_dict']['id'] == i._match_id(url)

"""
ITVBTCCIE short test
"""

# Generated at 2022-06-12 17:47:47.426116
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    _constructor = ITVBTCCIE
    IE_NAME = 'itv:btcc'
    IE_KEY = 'itv:btcc'
    test_instances = (_constructor, IE_KEY, IE_NAME)
    return test_instances


# Generated at 2022-06-12 17:47:48.685376
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    c = ITVBTCCIE()

# Generated at 2022-06-12 17:48:11.737360
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE_init = ITVIE()

# Generated at 2022-06-12 17:48:18.989016
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .test.test_suite import load_tests
    from .test.test_suite import make_test_request
    tests = load_tests(__name__, make_test_request)
    itv_btcc_ie = ITVBTCCIE()

# Generated at 2022-06-12 17:48:22.180994
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:26.798675
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IE = ITVBTCCIE()
    assert IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:31.960310
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('ITVIE','https://www.itv.com/hub/liar/2a4547a0012',{
            'id': '2a4547a0012',
            'ext': 'mp4',
            'title': 'Liar - Series 2 - Episode 6',
            'description': 'md5:d0f91536569dec79ea184f0a44cca089',
            'series': 'Liar',
            'season_number': 2,
            'episode_number': 6,
        })


# Generated at 2022-06-12 17:48:35.333437
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(InfoExtractor())._VALID_URL == ITVIE._VALID_URL
    assert ITVBTCCIE(InfoExtractor())._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-12 17:48:36.772361
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVExtractor = ITVIE
    ITVExtractor([1, ], {1: 1})

# Generated at 2022-06-12 17:48:37.726396
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-12 17:48:41.551613
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    t = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

    assert t._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert t._real_extract(url)['title'] == 'BTCC 2018: All the action from Brands Hatch'
    return t

# Generated at 2022-06-12 17:48:45.055244
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:49:31.686010
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()._real_extract(
        "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-12 17:49:34.718336
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # This will give a failed test as it is possible for the constructor to
    # raise an error, but the only error it raises is for no matches, which isn’t
    # the case here.
    print(ITVIE(7))


# Generated at 2022-06-12 17:49:39.333160
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Unit test for constructor of class ITVBTCCIE
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'


# Generated at 2022-06-12 17:49:41.026718
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:49:46.697845
# Unit test for constructor of class ITVIE
def test_ITVIE():
	assert ITVIE()._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
	assert ITVIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-12 17:49:49.030370
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVExtractor = ITVBTCCIE()
    ITVExtractor.extract(url)
    ID = ITVExtractor.playlist_result()[0]
    print(ID)

# Generated at 2022-06-12 17:49:49.821037
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-12 17:49:50.609800
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-12 17:49:51.255466
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE is ITVIE

# Generated at 2022-06-12 17:49:56.043381
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info=ITVIE._real_extract('http://www.itv.com/hub/liar/2a4547a0012')
    assert info.get('title') == 'Liar - Series 2 - Episode 6'
    assert info.get('series') == 'Liar'
    assert info.get('season_number') == 2
    assert info.get('episode_number') == 6
    assert info.get('duration') == 2895
    assert info.get('description') == 'md5:d0f91536569dec79ea184f0a44cca089'
    assert info.get('id') == '2a4547a0012'

# Generated at 2022-06-12 17:52:18.922278
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    test.BRIGHTCOVE_URL_TEMPLATE = ''
    test._download_webpage = lambda *args: open('test/data/itv_btcc.html').read()

# Generated at 2022-06-12 17:52:24.756107
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Default constructor
    channel = ITVIE()
    assert channel._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

    # Custom constructor
    channel = ITVIE(
        'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    )
    assert channel._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:52:29.906358
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc = ITVBTCCIE()
    video_id = '5719408653001'
    assert btcc.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert btcc.url_result(smuggle_url(btcc.BRIGHTCOVE_URL_TEMPLATE % video_id))['id'] == video_id

# Generated at 2022-06-12 17:52:36.523827
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    print("Testing ITVBTCCIE constructor")
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccie = ITVBTCCIE(ITVBTCCIE._downloader)
    try:
        itvbtccie.suitable(url)
    except RegexNotFoundError:
        print("Suitable or _VALID_URL did not match")


# Generated at 2022-06-12 17:52:37.070131
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-12 17:52:40.266824
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:52:48.457029
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # From http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(None).suitable(test_url)
    ITVBTCCIE(None)._real_extract(test_url)

# Usage of class ITVBTCCIE
ITVBTCCIE(None).extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:52:49.977702
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert isinstance(
        ITVIE('http://www.itv.com/hub/liar/2a4547a0012'), ITVIE)

# Generated at 2022-06-12 17:52:52.545752
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:53:02.252573
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    if ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE is not None:
        assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
        # If BRIGHTCOVE_URL_TEMPLATE is None, the following test will fail