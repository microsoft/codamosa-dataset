

# Generated at 2022-06-12 17:46:09.518447
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(ITVIE._downloader)

# Generated at 2022-06-12 17:46:20.023404
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert i._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-12 17:46:22.010460
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    info = ie.IE_NAME
    assert info == "ITV"

# Generated at 2022-06-12 17:46:25.736874
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    

# Generated at 2022-06-12 17:46:26.537596
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(1)

# Generated at 2022-06-12 17:46:29.128627
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._real_extract('http://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-12 17:46:41.457869
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    b = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert (b._URL_TEMPLATE == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert (b._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)')

# Generated at 2022-06-12 17:46:43.795969
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(ITVBTCCIE._downloader, ITVBTCCIE._VALID_URL, ITVBTCCIE._TEST)

# Generated at 2022-06-12 17:46:45.879556
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    name = 'ITVBTCCIE'
    class_name = 'ITVBTCCIE'
    class_code = inspect.getsource(sys.modules[__name__])

# Generated at 2022-06-12 17:46:51.423890
# Unit test for constructor of class ITVIE
def test_ITVIE():
    pass_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    fail_url = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    pass_params = ITVIE._test_suite()[0].get('params')
    fail_params = ITVIE._test_suite()[3].get('params')
    pass_object = ITVIE(pass_url, pass_params)
    fail_object = ITVIE(fail_url, fail_params)
    assert isinstance(pass_object, ITVIE)
    assert isinstance(fail_object, ITVIE)

# Generated at 2022-06-12 17:47:27.356583
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert x.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert x._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert x._TEST['info_dict'] == {'id':'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}

# Generated at 2022-06-12 17:47:33.790170
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    item = ITVBTCCIE('http://www.itv.com/btcc/races/2018/brands-hatch')
    assert item.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-12 17:47:38.676695
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/'\
        'btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtcc = ITVBTCCIE()
    assert itvbtcc._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:47:49.691910
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # test for _VALID_URL
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    # test for _GEO_COUNTRIES
    assert ITVIE._GEO_COUNTRIES == ['GB']
    # test for _TESTS

# Generated at 2022-06-12 17:47:52.740923
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:47:59.291356
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:48:00.580850
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE().ie_key() == "ITV"


# Generated at 2022-06-12 17:48:09.255700
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    assert IE.IE_NAME == "itv"
    assert IE.SUCCESS == True
    assert IE.IE_DESC == "ITV Hub"
    assert IE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert IE._TESTS[0].get('url') == url
    assert IE._TESTS[0].get('info_dict').get('id') == '2a4547a0012'
    assert IE._TESTS[0].get('info_dict').get('ext') == 'mp4'
    assert IE

# Generated at 2022-06-12 17:48:11.463112
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE().url_result(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % 1565652849, 'BrightcoveNew', '1565652849')

# Generated at 2022-06-12 17:48:14.734769
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-12 17:48:52.314573
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert info_extractor._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:49:01.140106
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .brightcove import (
        BrightcoveLegacyIE,
        BrightcoveNewIE,
    )
    from .common import InfoExtractor
    from .itv import ITVIE
    from .youtube import YoutubeIE

    assert ITVIE.suitable('https://www.itv.com/hub/liar/2a4547a0012') == True
    assert ITVIE.suitable('https://www.xhamster.com/hub/liar/2a4547a0012') == False
    assert ITVIE.suitable('https://www.youtube.com/watch?v=BaW_jenozKc') == False

    assert isinstance(ITVIE(), InfoExtractor)
    assert isinstance(ITVIE(), ITVIE)
    assert isinstance(ITVIE(), YoutubeIE) == False
    assert isinstance

# Generated at 2022-06-12 17:49:03.025352
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE(ITVBTCCIE._downloader)
    except:
        assert False


# Generated at 2022-06-12 17:49:06.692661
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_object = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert test_object.url == "https://www.itv.com/hub/liar/2a4547a0012"
    assert test_object.video_id == "2a4547a0012"


# Generated at 2022-06-12 17:49:11.706897
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtcc_ie = ITVBTCCIE()
    assert itvbtcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s', "Correct URL template"

# Generated at 2022-06-12 17:49:12.641194
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(InfoExtractor())

# Generated at 2022-06-12 17:49:15.414047
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.suitable('http://www.itv.com/hub/liar/2a4547a0012')
    assert not ie.suitable('http://www.itv.com/hub/liar/2a4547a0012/player')

# Generated at 2022-06-12 17:49:18.737408
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE()
    assert test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:49:19.560886
# Unit test for constructor of class ITVIE
def test_ITVIE():
    _ITVIE = ITVIE()


# Generated at 2022-06-12 17:49:20.455191
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()


# Generated at 2022-06-12 17:50:36.370077
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itvie._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
                                                                                  

# Generated at 2022-06-12 17:50:42.076008
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtcc_ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert itvbtcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:50:45.450493
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    assert i.__class__.__name__ == 'ITVIE'
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:50:51.934124
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = ITVBTCCIE._match_id(url)
    # Test whether class ITVBTCCIE will raise error when created
    ITVBTCCIE(url)
    # Make sure the playlist_id is correct
    assert playlist_id == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:50:52.442143
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)

# Generated at 2022-06-12 17:50:56.002235
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE({})
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-12 17:51:07.065633
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE()
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    test = {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    assert inst._TEST == test

# Generated at 2022-06-12 17:51:12.337085
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Basic test for ITVIE constructor
    """
    # Basic constructor test
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(
        {
            'geo_countries': ['GB'],
        }
    ).extract(url)

# Generated at 2022-06-12 17:51:19.964538
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .common import fake_httpretry_download
    playlist_url = 'http://link.theplatform.com/s/HNK2IC/media/guid/2408566859/2016-11-19/f512c9d8-a7b5-47a0-b68e-c8e47fc2032a?form=json&manifest=m3u&trim=true'
    IE = ITVIE()
    res = IE._download_json(playlist_url, '2a4547a0012', headers=IE.geo_verification_headers(),
                            note='Downloading ios_playlist', errnote='Unable to download ios_playlist')
    assert res['Playlist']['Video']['Title'] == 'Liar - Series 2 - Episode 6'
    assert not fake_

# Generated at 2022-06-12 17:51:23.822501
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:54:03.788015
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:54:11.828175
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """constructor of class ITVBTCCIE"""

    dl = ITVBTCCIE()
    assert dl._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert dl._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-12 17:54:18.692485
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .common import FORMAT_URL
    test = ITVIE()
    # test media_id
    media_id = '2a4547a0012'
    # test url
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    # test regex of _VALID_URL
    assert re.match(test._VALID_URL, url)
    # test _real_extract()
    output = test._real_extract(url)
    assert output['id'] == media_id
    assert output['title'] == "Liar - Series 2 - Episode 6"
    assert output['description'] == "md5:d0f91536569dec79ea184f0a44cca089"
    assert output['series'] == "Liar"
    assert output['season_number']

# Generated at 2022-06-12 17:54:21.105975
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test what happens when parent constructor is called with the
    # list of all the valid URL formats.
    instance = ITVIE(None)
    for valid_url in ITVIE._TESTS:
        assert instance.suitable(valid_url["url"])

# Generated at 2022-06-12 17:54:22.194929
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL


# Generated at 2022-06-12 17:54:23.753056
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .test_itv import _test_ITVBTCCIE
    _test_ITVBTCCIE()

# Generated at 2022-06-12 17:54:26.744810
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(None)._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:54:30.494527
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:54:31.547386
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().ie_key() == 'ITVBTCC'

# Generated at 2022-06-12 17:54:33.024298
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # This tests the constructor of class ITVBTCCIE
    # It checks whether the constructor raises TypeError exception
    # when a URL which is not a string type is provided
    
    with pytest.raises(TypeError):
        ITVBTCCIE(1)