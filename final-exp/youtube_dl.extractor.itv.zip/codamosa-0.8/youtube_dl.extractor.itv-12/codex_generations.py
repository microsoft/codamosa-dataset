

# Generated at 2022-06-12 17:46:12.584319
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    it = ITVBTCCIE()
    assert(it.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')


# Generated at 2022-06-12 17:46:14.732094
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE().ie_key() == 'itv:html5'

# Generated at 2022-06-12 17:46:18.676510
# Unit test for constructor of class ITVIE
def test_ITVIE():
    unit = ITVIE()
    assert unit.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:46:24.508045
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE.suitable(url)
    assert ITVIE._VALID_URL == ITVIE.VALID_URL
    assert ITVIE._GEO_COUNTRIES == ITVIE.GEO_COUNTRIES
    assert ITVIE.BRIGHTCOVE_URL_TEMPLATE == ITVIE._BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 17:46:25.685676
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()



# Generated at 2022-06-12 17:46:29.661869
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IT = ITVBTCCIE()
    assert IT._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:46:31.244809
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    tags = ITVBTCCIE._extract_rss('http://www.itv.com/btcc/rss', 'btcc')

# Generated at 2022-06-12 17:46:36.115141
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert(i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-12 17:46:38.890607
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert "ITVBTCCIE" == itv_btcc_ie.IE_NAME

# Generated at 2022-06-12 17:46:39.562647
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE



# Generated at 2022-06-12 17:46:54.874301
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == ITVIE.__name__
    return ITVIE('hub/china-nights/2a2620a0035')

# Generated at 2022-06-12 17:47:04.324176
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie_ITVIE = ITVIE()
    ie_ITVIE._valid_url('http://www.itv.com/hub/liar/2a4547a0012')
    ie_ITVIE._valid_url('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    ie_ITVIE._valid_url('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    ie_ITVIE._valid_url('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')


# Generated at 2022-06-12 17:47:11.913803
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test the constructor
    test_class = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert test_class.url == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert test_class.video_id == '2a4547a0012'
    assert test_class._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-12 17:47:18.696207
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_cases = [
        {'url': 'https://www.itv.com/hub/liar/2a4547a0012',
         'expected_id': '2a4547a0012'},
        {'url': 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034',
         'expected_id': '2a5159a0034'},
    ]
    for test_case in test_cases:
        itv_ie = ITVIE()
        itv_ie.extract(test_case['url'])
        assert itv_ie._match_id(test_case['url']) == test_case['expected_id']
        assert itv_ie._download_webpage.request.url == test_case['url']

# Generated at 2022-06-12 17:47:19.975464
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None) is not None

# Generated at 2022-06-12 17:47:28.738298
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    info = ITVBTCCIE()._real_extract(url)

# Generated at 2022-06-12 17:47:31.114022
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Make sure this does not raise any exception
    ITVIE()

# Generated at 2022-06-12 17:47:40.896688
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:47:42.162390
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-12 17:47:51.997917
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    assert instance._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert instance._GEO_COUNTRIES == ['GB']
    assert instance.IE_NAME == 'itv'

# Generated at 2022-06-12 17:48:20.536839
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012','')

# Generated at 2022-06-12 17:48:23.130572
# Unit test for constructor of class ITVIE
def test_ITVIE():
	ie = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
	assert isinstance(ie, ITVIE)


# Generated at 2022-06-12 17:48:27.095952
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie.ie_key() == 'ITV'
    assert itv_ie.ie_key() in ITVIE._ies


# Generated at 2022-06-12 17:48:34.994297
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('https://www.itv.com/hub/the-jeremy-kyle-show/2a69f2a0054')._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/the-jeremy-kyle-show/2a69f2a0054' # noqa: E501
    assert ITVBTCCIE('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)' # noqa: E501

# Generated at 2022-06-12 17:48:36.181473
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:48:38.384777
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    app = ITVBTCCIE(ITVIE())

# Generated at 2022-06-12 17:48:43.563419
# Unit test for constructor of class ITVIE
def test_ITVIE():
    #test ITVIE constructor
    itvie = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert itvie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itvie._downloader is not None

# Generated at 2022-06-12 17:48:48.113322
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Simple test to check constructor
    e = ITVBTCCIE(None)
    assert e.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-12 17:48:57.141051
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Given
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # When
    itv = ITVBTCCIE(url).construct()
    # Then
    assert itv.url == url
    assert itv.playlist_id == 'btcc-2018-all-the-action-from-brands-hatch'
    assert itv.referrer == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert itv.geo_ip_blocks == ['193.113.0.0/16', '54.36.162.0/23', '159.65.16.0/21']
    assert it

# Generated at 2022-06-12 17:49:04.372565
# Unit test for constructor of class ITVIE
def test_ITVIE():
    #test first, second and third test
    ITVIE()._real_extract('https://www.itv.com/hub/liar/2a4547a0012')
    ITVIE()._real_extract('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    ITVIE()._real_extract('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    ITVIE()._real_extract('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')


# Generated at 2022-06-12 17:50:02.523006
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE('url', ITVBTCCIE._TEST)
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:50:09.251576
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():

    iTVBTCCIE = ITVBTCCIE()
    assert iTVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == \
            'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

    # Passing nothing
    results = iTVBTCCIE._real_extract("")
    assert results == None

    # Passing random URL
    results = iTVBTCCIE._real_extract("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert results['_type'] == 'playlist'

# Generated at 2022-06-12 17:50:16.982307
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    test_result = itvbtccie._TEST
    url = test_result.get('url')
    if url:
        playlist_id = test_result.get('info_dict', {}).get('id')
        playlist_mincount = test_result.get('playlist_mincount')
        # extract playlist
        playlist_entries = itvbtccie._real_extract(url)
        if playlist_entries:
            if playlist_id:
                assert playlist_id == playlist_entries.get('id')
            if playlist_mincount:
                assert len(playlist_entries.get('entries')) >= playlist_mincount


# Generated at 2022-06-12 17:50:23.200476
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "http://www.itv.com/hub/Emmerdale/2a2048a0067?ns_source=Facebook&ns_mchannel=social&ns_campaign=1448_Emmerdale&ns_linkname=emmerdale-on-itv&ns_fee=0"
    itv_ie = ITVIE()
    itv_ie.extract(url)
    assert itv_ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:50:31.941803
# Unit test for constructor of class ITVIE

# Generated at 2022-06-12 17:50:32.954312
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    return ITVBTCCIE.test()

# Generated at 2022-06-12 17:50:38.136895
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:50:39.096807
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('test', '{}')

# Generated at 2022-06-12 17:50:40.845350
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE(None)
    assert instance.__class__ == ITVBTCCIE

# Generated at 2022-06-12 17:50:41.962695
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.name == "ITV.com"

# Generated at 2022-06-12 17:53:25.488923
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itv_btccIE = ITVBTCCIE()
    assert itv_btccIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:53:27.565294
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test initialisation of ITVIE class
    result = ITVIE()

    # Test that ITVIE class is a subclass of InfoExtractor
    assert issubclass(type(result), InfoExtractor)

# Generated at 2022-06-12 17:53:30.167906
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-12 17:53:30.682936
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import ITVIE

# Generated at 2022-06-12 17:53:31.790950
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_ITVIE_real_extract()
    test_ITVBTCCIE_real_extract()

# Generated at 2022-06-12 17:53:34.618512
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Function for test
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL
    assert ITVIE()._TESTS == ITVIE._TESTS
    assert ITVIE._GEO_COUNTRIES == ['GB']


# Generated at 2022-06-12 17:53:37.584237
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE()
    except Exception as e:
        print(str(e))
        print('ITVBTCCIE is not properly constructed')

# Generated at 2022-06-12 17:53:40.010811
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_class= ITVIE()
    assert test_class._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert test_class._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:53:42.312635
# Unit test for constructor of class ITVIE
def test_ITVIE():
	print('Testing ITVIE constructor')
	i = ITVIE()
	#try:
	#	i.report_warning('Uh oh.')
	#except Exception as e:
	#	print('Received expected exception')
	#	print(e)
	#else:
	#	raise Exception('Expected exception not raised')

# Generated at 2022-06-12 17:53:45.159225
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtcc = ITVBTCCIE()
    itvbtcc._VALID_URL = ITVBTCCIE._VALID_URL
    check = re.match(ITVBTCCIE._VALID_URL, test_url)
    assert check is not None