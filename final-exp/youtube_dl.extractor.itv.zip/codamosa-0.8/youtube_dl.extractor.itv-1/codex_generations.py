

# Generated at 2022-06-12 17:46:09.647569
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-12 17:46:20.071660
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtcc = ITVBTCCIE()
    assert itvbtcc._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itvbtcc._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    assert itvbtcc.BRIGHTCOVE_URL_T

# Generated at 2022-06-12 17:46:23.251262
# Unit test for constructor of class ITVIE
def test_ITVIE():
    '''Set up the unit test for ITVIE.'''
    ITVIE()._download_webpage(
        'http://www.itv.com/hub/liar/2a4547a0012', '2a4547a0012')

# Generated at 2022-06-12 17:46:26.531371
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert type(ie).__name__ == 'ITVBTCCIE'
    assert ie._type == 'playlist'
    assert ie._downloader.params['noplaylist'] == True

# Generated at 2022-06-12 17:46:32.179708
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert obj.BTCC_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:46:33.831578
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:46:35.529525
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._search_json_ld({}, None, default={})

# Generated at 2022-06-12 17:46:36.176345
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:46:43.185784
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.video_id == 'btcc-2018-all-the-action-from-brands-hatch'
    # test the main function
    ie_result = ie._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ie._TYPE == ie_result['_type']
    assert ie.ie_key() == ie_result['_type']
    assert ie.title == ie_result['title']
    assert ie.id == ie_

# Generated at 2022-06-12 17:46:45.664421
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .brightcove import BrightcoveNewIE
    itv = ITVIE()
    brightcove = BrightcoveNewIE()
    assert itv.BRIGHTCOVE_URL_TEMPLATE == brightcove.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-12 17:47:10.606995
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:47:16.192744
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Create and verify constructor of ITVBTCCIE class
    assert ITVBTCCIE._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-12 17:47:18.329516
# Unit test for constructor of class ITVIE
def test_ITVIE():
    '''
    Unit test for constructor of class ITVIE
    '''
    ITVIE()


# Generated at 2022-06-12 17:47:20.380327
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:47:28.965952
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class Test(object):
        def __init__(self, video_ids):
            self.video_ids = video_ids

        def __call__(self, match):
            instrumented_video_id = self.video_ids.pop(0)
            if instrumented_video_id != match.group(1):
                raise ValueError('invalid match %r, expected %r' % (match.group(1), instrumented_video_id))
            return 'data-video-id="%s"' % instrumented_video_id


# Generated at 2022-06-12 17:47:40.311598
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Unit test for constructor of class ITVIE.
    """

    url = 'https://www.itv.com/hub/emmerdale/2a4737a0045'
    video_id = '2a4737a0045'

    ITVIE(InfoExtractor())._real_extract(url)
    webpage = ITVIE(InfoExtractor())._download_webpage(url, video_id)
    params = ITVIE(InfoExtractor())._search_regex(
        r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params')
    params = ITVIE(InfoExtractor()).extract_attributes(params)
    ios_playlist_url = params.get('data-video-playlist') or params['data-video-id']
    h

# Generated at 2022-06-12 17:47:50.853761
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # ITVBTCCIE cannot be instantiated
    if not hasattr(ITVBTCCIE, '_download_webpage'):
        return
    # The test case
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # Instantiate and call method _real_extract of class ITVBTCCIE
    ie = ITVBTCCIE()
    wpt = ie._download_webpage(url, 'mock_id')

    # Unit test for method _real_extract of class ITVBTCCIE
    def test_extract():
        if wpt['id'] != 'btcc-2018-all-the-action-from-brands-hatch':
            print('error')
        else:
            print('ok')



# Generated at 2022-06-12 17:47:54.948617
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:01.238217
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:09.546854
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    with open('test/testdata/test_btcc.html', 'rb') as f:
        webpage = f.read()
    inst = ITVBTCCIE()

# Generated at 2022-06-12 17:48:41.525948
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert(itv_btcc_ie)
    # Test title is the same as url after processing
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    expect_title = "BTCC 2018: All the action from Brands Hatch"
    playlist_id = itv_btcc_ie._match_id(url)
    assert(playlist_id == expect_title)

# Generated at 2022-06-12 17:48:53.176427
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.__name__ == 'ITV'
    assert ITVIE._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:49:01.300828
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    p = ITVBTCCIE()
    assert p._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert p._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert p._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert p.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:49:03.179360
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Checks if the class ITVIE is initializing correctly
    """
    ITVIE('http://www.itv.com')

# Generated at 2022-06-12 17:49:07.044809
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    return ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:49:12.579972
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .test_downloader import TestDownloader
    from .test_downloader import MockHttpDl
    from .test_downloader import TestDownloaderRule

    TestDownloader.params['youtube_include_dash_manifest'] = False

    url = ITVBTCCIE._TEST['url']
    # Test playlist
    dl = MockHttpDl([TestDownloaderRule({
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'file': 'test/data/test_btcc_playlist.txt',
    })])
    ie = ITVBTCCIE()

# Generated at 2022-06-12 17:49:18.339551
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    '''
    Test the constructor of class ITVBTCCIE
    '''
    url = 'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    video_id = 'btcc-2018-all-the-action-from-brands-hatch'
    itvbtcc_ie = ITVBTCCIE(ITVBTCCIE._create_ie())
    itvbtcc_ie.url = url
    itvbtcc_ie.video_id = video_id
    itvbtcc_ie.webpage_url = url

# Generated at 2022-06-12 17:49:21.553107
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_obj = ITVBTCCIE()
    assert test_obj._match_id('btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'



# Generated at 2022-06-12 17:49:24.586665
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:49:29.304830
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()
    assert IE.IE_NAME == 'itv.com'
    assert IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:50:42.811138
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE()

# Generated at 2022-06-12 17:50:45.035443
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    except:
        assert False

# Generated at 2022-06-12 17:50:46.131142
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:50:50.633788
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVBTCCIE)
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:50:52.735829
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE()
    except TypeError:
        pass
    else:
        raise RuntimeError('ITVIE() class should require one parameter')

# Generated at 2022-06-12 17:50:56.687901
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc_ie = ITVBTCCIE(None)
    assert btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:51:00.904467
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    if ITVBTCCIE.__doc__ is None:
        ITVBTCCIE.__doc__ = ""
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(ITVBTCCIE))
    unittest.TextTestRunner().run(suite)

if __name__ == "__main__":
    test_ITVBTCCIE()

# Generated at 2022-06-12 17:51:02.718080
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE



# Generated at 2022-06-12 17:51:03.123441
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-12 17:51:03.708623
# Unit test for constructor of class ITVIE
def test_ITVIE():
    pass


# Generated at 2022-06-12 17:53:29.412008
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-12 17:53:34.328275
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # A valid url that has a playlist on itv.com
    url_1 = "http://www.itv.com/hub/lorraine/2a2535a0094"
    itvie = ITVIE()
    assert itvie.suitable(url_1) == True
    # An invalid url that has an invalid playlist url on itv.com
    url_2 = "http://www.itv.com/hub/through-the-keyhole/2a2271a0033"
    assert itvie.suitable(url_2) == False

# Generated at 2022-06-12 17:53:36.619348
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print("Testing ITVIE")
    link = ITVIE("")
    print("ITVIE end")

# Generated at 2022-06-12 17:53:45.949622
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    youtube_ie = ITVBTCCIE()
    assert youtube_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert youtube_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert youtube_ie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:53:48.462235
# Unit test for constructor of class ITVIE
def test_ITVIE():
    s = ITVIE().suitable
    assert(s('https://www.itv.com/hub/emmerdale/2a2898a0024'))

# Generated at 2022-06-12 17:53:57.099465
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        # Uncomment for see the effect of false positive
        # ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
        # ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=962631778001'
        ITVBTCCIE()
    except:
        import traceback
        traceback.print_exc()
        assert False

# Generated at 2022-06-12 17:54:00.197252
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    if hasattr(ITVBTCCIE, 'IE_NAME'):
        assert ITVBTCCIE.IE_NAME == 'itv:btcc'
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 17:54:03.286992
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert x.URL == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-12 17:54:04.173764
# Unit test for constructor of class ITVIE
def test_ITVIE():
    pass


# Generated at 2022-06-12 17:54:04.764605
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()