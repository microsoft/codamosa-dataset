

# Generated at 2022-06-12 17:46:18.028792
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # Test the str method:
    #  ITVIE(
    #    _type='url',
    #    ie_key='itv',
    #    ie_key_map=
    #     {'brightcove:new': <class 'youtube_dl.extractor.brightcove.BrightcoveNewIE'>,
    #      'itv': <class 'youtube_dl.extractor.itv.ITVIE'>},
    #    ie_key_type=<class 'str'>,
    #    url='https://www.itv.com/hub/liar/2a4547a0012')
    print("ITVIE = " + str(ITVIE("https://www.itv.com/hub/liar/2a4547a0012")))

    # Test the url attribute:
    # 'https

# Generated at 2022-06-12 17:46:24.006215
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie.IE_NAME == 'itv.com'
    assert itv_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:46:28.935158
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE()._match_id(test_url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:46:30.859785
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Default constructor
    itvbtccie = ITVBTCCIE()
    # Overriding constructor
    itvbtccie = ITVBTCCIE('test')


# Generated at 2022-06-12 17:46:43.076180
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class Obj(object):
        pass
    info = Obj()
    info.id = "btcc-2018-all-the-action-from-brands-hatch"

# Generated at 2022-06-12 17:46:43.919938
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE == ITVBTCCIE.construct_class_for_test()

# Generated at 2022-06-12 17:46:45.141927
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-12 17:46:48.484703
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist = ITVBTCCIE()._real_extract(url)
    assert playlist['id'] == playlist['title']

# Generated at 2022-06-12 17:46:49.625795
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.__name__ == 'ITVBTCCIE'

# Generated at 2022-06-12 17:46:58.898766
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Create an object for testing
    itv_ie = ITVIE()
    
    # Create an instance of ITVIE for the expected behaviour to be compared to
    expected = ITVIE()
    
    # The actual behaviour of ITVIE using the URL from _TESTS[0]
    try:
        actual = ITVIE().extract('https://www.itv.com/hub/liar/2a4547a0012')
    except:
        # The exception is not important, only the fact that it was raised
        actual = Exception
    
    # The expected value for this instance of ITVIE

# Generated at 2022-06-12 17:47:18.301316
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_obj = ITVIE()
    try:
        assert test_obj._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    except AssertionError:
        raise AssertionError('Invalid url defined')

# Generated at 2022-06-12 17:47:27.861187
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_ITVBTCCIE = ITVBTCCIE()
    assert test_ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert test_ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:47:29.019919
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()

# Generated at 2022-06-12 17:47:40.337790
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE(ITVIE(), {}, 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert itv_btcc_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:47:44.228093
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:47:48.240012
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE(): 
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_ITVBTCCIE = ITVBTCCIE()
    test_ITVBTCCIE._real_extract(url)

# Generated at 2022-06-12 17:47:49.242567
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    
    real_extract = ITVBTCCIE
    # Test for ITVBTCCIE
    assert real_extract



# Generated at 2022-06-12 17:47:55.544688
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class ITVBTCCIE(ITVIE, ITVBTCCIE):
        pass

    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvbtccie.itv_video_url == 'itv://getObjects?objectType=Video&sort=CreationDate&filter=Vodcrid%3D%22%s%22&pageSize=10&page=1'
    assert itvbtccie.itv_search_url == 'itv://search?q=%s&variantAvailability=%s&pageSize=10&page=1'
    assert itv

# Generated at 2022-06-12 17:48:01.144337
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")._real_extract("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-12 17:48:09.487343
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test that ITVBTCCIE is initialized with a regex matching BTCC videos
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE(None)
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    # Test that ITVBTCCIE is initialized with a regex matching any BTCC videos
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-12 17:48:40.736841
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:43.897442
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # This test is to check that ITVIE is a valid constructor for it's superclass, InfoExtractor.
    ie = ITVIE(InfoExtractor())
    result = ie.SUFFIX
    expected = 'itv'
    assert result == expected

# Generated at 2022-06-12 17:48:47.984003
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:51.637469
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-12 17:49:00.863825
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034"
    video_id = "2a5159a0034"

# Generated at 2022-06-12 17:49:04.296011
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE(ITVBTCCIE._create_get_playlist())
    info_extractor._real_extract(ITVBTCCIE._TEST['url'])
    expect(info_extractor.title == 'BTCC 2018: All the action from Brands Hatch')

# Generated at 2022-06-12 17:49:05.351839
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE in globals()
    assert ITVIE is ITVIE

# Generated at 2022-06-12 17:49:06.409263
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.ie_key() == "itv"

# Generated at 2022-06-12 17:49:15.897944
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """ Unit test to check ITVBTCCIE contructor """
    IT = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert IT.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert IT._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:49:24.415090
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    test_cases = {
        'https://www.itv.com/hub/liar/2a4547a0012',
        'https://www.itv.com/hub/through-the-keyhole/2a2271a0033',
        'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034',
        'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024',
    }
    for url in test_cases:
        assert info_extractor._valid_url(url, 'ITVIE')


# Generated at 2022-06-12 17:50:28.793162
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:50:31.276980
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = ITVIE.construct_from_url('http://www.itv.com/hub/liar/2a4547a0012')
    assert url == "https://www.itv.com/hub/liar/2a4547a0012"

# Generated at 2022-06-12 17:50:36.138959
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    i.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    x = i.BRIGHTCOVE_URL_TEMPLATE % '6007752146001'
    assert x

# Generated at 2022-06-12 17:50:40.962307
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test constructor for ITVBTCCIE"""

    # Check that instance has class variables
    inst = ITVBTCCIE()
    for var in ['_VALID_URL', '_TEST']:
        assert hasattr(inst, var)

    # Check that instance has method
    assert hasattr(inst, '_real_extract')

# Generated at 2022-06-12 17:50:42.909317
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    assert instance != None


# Generated at 2022-06-12 17:50:47.870216
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    iTVIE = ITVIE(url)
    print(iTVIE._match_id(url))
    print(iTVIE._download_webpage(url, iTVIE._match_id(url)))

# Generated at 2022-06-12 17:50:57.541010
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    brightcove_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    ITVBTCCIE(object)._real_extract(url)
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == brightcove_url


# Generated at 2022-06-12 17:51:07.795880
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """ITVBTCCIE test"""
    print('\n' + '-'*20)
    print('test for ITV_BTCC_IE')
    print('-'*20)
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    try:
        print(('video_id:', ITVBTCCIE._match_id(url)))
    except:
        print('error:')
        print(traceback.format_exc())
    try:
        print(('playlist_id:', ITVBTCCIE(url)._match_id(url)))
    except:
        print('error:')
        print(traceback.format_exc())
    print('-'*20)

# Generated at 2022-06-12 17:51:09.350882
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    return ITVBTCCIE

# Generated at 2022-06-12 17:51:10.082404
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:53:35.966495
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_id = 'btcc-2018-all-the-action-from-brands-hatch'
    instance = ITVBTCCIE(FakeYDL())
    instance.url = test_url
    assert instance._match_id(test_url) == test_id

# Generated at 2022-06-12 17:53:45.479846
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import unittest
    class TestITVBTCCIE(unittest.TestCase):
        def test_construct(self):
            test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
            it = ITVBTCCIE(ITVIE())
            entry = it.url_result(test_url, 'ITVBTCCIE')
            self.assertIn('ITV', entry['extractor'])
            self.assertIn('Brightcove', entry['extractor'])
            self.assertEqual(
                entry['url'],
                'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5856271098001')

   

# Generated at 2022-06-12 17:53:50.506510
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video = ITVIE()
    video._download_webpage = lambda *a, **k: '<html></html>'
    video._search_regex = lambda p, s, n: '<video id="video" data-video-id="videoID" data-video-hmac="hmac" data-video-playlist="playlistURL">'

# Generated at 2022-06-12 17:53:56.010950
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie_obj = ITVBTCCIE()
    # Ensure that it is an instance of class base_IE
    assert isinstance(ie_obj, InfoExtractor)
    # Tests for the class constructor
    assert hasattr(ie_obj, 'BRIGHTCOVE_URL_TEMPLATE')


# Generated at 2022-06-12 17:54:00.589016
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    # Call _real_extract method with url as parameter
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    result = itv._real_extract(url)
    # Check extracted video id by comparing it with expected value
    assert result['id'] == '2a4547a0012'
    # Check extracted video title by comparing it with expected value
    assert result['title'] == 'Liar - Series 2 - Episode 6'

# Generated at 2022-06-12 17:54:02.136945
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "http://www.itv.com/hub/liar/2a4547a0012"
    ITV = ITVIE()
    ITV._match_id
    ITV._real_extract(url)

# Generated at 2022-06-12 17:54:04.210469
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:54:07.146269
# Unit test for constructor of class ITVIE
def test_ITVIE():
    '''
    This Unit test was created for testing ITVIE class constructor
    '''

    print("**** Creating a new ITVIE object using ITVIE class constructor **** \n")
    newITVIE = ITVIE()
    return newITVIE


# Generated at 2022-06-12 17:54:15.084351
# Unit test for constructor of class ITVIE

# Generated at 2022-06-12 17:54:17.537661
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url    = 'https://www.itv.com/hub/liar/2a4547a0012'
    embed  = ITVIE(url)
    assert embed.url == url
    assert embed.extract() == embed._real_extract(url)