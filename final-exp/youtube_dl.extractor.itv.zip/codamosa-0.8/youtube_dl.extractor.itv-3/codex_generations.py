

# Generated at 2022-06-12 17:46:10.051471
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert str(type(ie)) == "<class 'youtube_dl.extractor.itv.ITVBTCCIE'>"

# Generated at 2022-06-12 17:46:10.691270
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 17:46:12.920929
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test ITVIE"""
    unit_test_ITVIE = ITVIE()
    assert unit_test_ITVIE != None


# Generated at 2022-06-12 17:46:23.593011
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert ITVIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:46:28.059970
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # import ipdb; ipdb.set_trace()
    ITV_class = ITVIE()
    ITV_class._TESTS[0]['info_dict']['id']

if __name__ == "__main__":
    test_ITVIE()

# Generated at 2022-06-12 17:46:34.507140
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVExtractor = ITVBTCCIE.constructor
    ITVExtractor.IE_NAME = 'ITVBTCCIE' # pylint: disable=multiple-statements
    ITVExtractor.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s' # pylint: disable=line-too-long
    ITVExtractor.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s' # pylint: disable=line-too-long
    ITVExtractor.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 17:46:36.835624
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert re.match(ITVBTCCIE._VALID_URL, ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '123')

# Generated at 2022-06-12 17:46:38.383635
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-12 17:46:43.031141
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # get constructor of class ITVBTCCIE
    ie = ITVBTCCIE()
    # test if constructor is working
    assert(ie._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'))

# Generated at 2022-06-12 17:46:47.191627
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    url = info_extractor._VALID_URL % playlist_id
    info_extractor._real_extract(url)
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert info_extractor._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:47:04.845862
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:47:08.109389
# Unit test for constructor of class ITVIE
def test_ITVIE():
    videoid = '2a4547a0012'
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE._match_id(url) == videoid

# Generated at 2022-06-12 17:47:14.028808
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    if __name__ == '__main__':
        # Run the following code to perform a unit test ;)
        from __main__ import BrightcoveNewIE
        from .test_html import test_smuggle_url
        # import here for the reason:
        # https://github.com/ytdl-org/youtube-dl/issues/16355#issuecomment-522880736
        import pytest
        pytest.main(['-x', '-vv', __file__])

# Generated at 2022-06-12 17:47:22.639490
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE()
    assert obj['_VALID_URL'] == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert obj['_GEO_COUNTRIES'] == ['GB']
    obj = ITVBTCCIE()
    assert obj['_VALID_URL'] == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:47:27.575813
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_ITVBTCCIE.obj = ITVBTCCIE()
    test_ITVBTCCIE.obj.url = url

    test_ITVBTCCIE.obj._real_extract(url)

    assert type(test_ITVBTCCIE.obj) is ITVBTCCIE

# Generated at 2022-06-12 17:47:34.072721
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .BrightcoveNew import BrightcoveNewIE
    from .common import InfoExtractor
    ie = InfoExtractor(None, ITVIE()._downloader)
    assert isinstance(ie._ies['itv'], ITVIE)
    assert isinstance(ie._ies['brightcove:1582188683001'], BrightcoveNewIE)



# Generated at 2022-06-12 17:47:43.094928
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    class_itv = ITVIE()
    assert class_itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert class_itv._GEO_COUNTRIES == ['GB']
    assert class_itv._match_id(url) == '2a4547a0012'
    assert class_itv._real_extract(url)['title'] == 'Liar - Series 2 - Episode 6'

# Generated at 2022-06-12 17:47:46.265672
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() in [BrightcoveNewIE.ie_key()]
    assert ITVBTCCIE.ie_key() in [BrightcoveNewIE.ie_key()]

# Generated at 2022-06-12 17:47:48.730398
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IT = ITVBTCCIE(None)
    assert isinstance(IT, ITVBTCCIE)
    assert IT.__class__ == ITVBTCCIE

# Generated at 2022-06-12 17:47:51.467904
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    obj = ITVIE()
    obj._real_extract(url)

# Generated at 2022-06-12 17:48:05.522444
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE == ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:48:08.313123
# Unit test for constructor of class ITVIE
def test_ITVIE():
    
    # Create instance of class ITVIE as itv_ie
    itv_ie = ITVIE()

    # Create instance of class ITVBTCCIE as itvbtcc_ie
    itvbtcc_ie = ITVBTCCIE()

# Generated at 2022-06-12 17:48:15.041713
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_verification_headers() == {
        'X-Forwarded-For': '193.113.0.0,54.36.162.0,159.65.16.0'
    }
    assert ie.geo_verification_headers() == {
        'X-Forwarded-For': '193.113.0.0,54.36.162.0,159.65.16.0'
    }

# Generated at 2022-06-12 17:48:24.595381
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    IT = ITVBTCCIE()
    assert(IT._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch')
    webpage = IT._download_webpage(url, 'btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:48:34.142472
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Constructor without geo-restriction takes the following keyword arguments:
    #   ie, expected_ie, expected_title, expected_description,
    #   expected_series, expected_season_number, expected_episode_number,
    #   expected_thumbnail, expected_duration.
    ITVEI = ITVIE(
        expected_title="Liar - Series 2 - Episode 6",
        expected_description="md5:d0f91536569dec79ea184f0a44cca089",
        expected_series="Liar",
        expected_season_number=2,
        expected_episode_number=6,
        expected_duration=5520)

    # Check for class attributes of ITVIE
    assert ITVEI.ie_key() == "ITV"

# Generated at 2022-06-12 17:48:34.993403
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance

# Generated at 2022-06-12 17:48:36.011289
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_case = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert(test_case)

# Generated at 2022-06-12 17:48:37.923402
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE({'geo_countries': ['GB']})
    assert instance.geo_countries == ['GB']

# Generated at 2022-06-12 17:48:39.760755
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(None)._real_extract(test_url)

# Generated at 2022-06-12 17:48:50.745627
# Unit test for constructor of class ITVIE

# Generated at 2022-06-12 17:49:24.032169
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    input_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    expected_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5705661914001'
    expected_video_id = '5705661914001'
    expected_title = 'BTCC 2018: All the action from Brands Hatch'
    expected_playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    expected_referrer = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

    itv_bt

# Generated at 2022-06-12 17:49:28.266028
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie.geo_verification_headers().get('Accept-Language') == 'pt-BR,pt;q=0.8,en-US;q=0.6,en;q=0.4'

# Generated at 2022-06-12 17:49:30.029885
# Unit test for constructor of class ITVIE
def test_ITVIE():

    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-12 17:49:31.487514
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).ie_key() == 'ITVBTCC'

# Generated at 2022-06-12 17:49:34.803314
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:49:36.576255
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    call=ITVBTCCIE.__init__()

# Generated at 2022-06-12 17:49:42.803763
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    c = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    # It was very hard to write this because ITVBTCCIE is an abstract class.
    # Extending ITVBTCCIE to create an instance of ITVBTCCIE seems like a convoluted way to
    # do this, but I don't know of any other way to do it with ITVBTCCIE being abstract.
    pass

# Generated at 2022-06-12 17:49:46.105862
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() in InfoExtractor._ies
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:49:53.376626
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:50:05.861677
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    newIE = ITVIE(None)
    assert newIE.IE_NAME == 'ITV'
    assert newIE.ie_key() == 'ITV'
    assert newIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/.+'
    assert newIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert newIE._TESTS[0]['url'] == url
    assert newIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:51:13.887423
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from . import ITVBTCCIE
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:51:14.581010
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-12 17:51:16.181781
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE({})._VALID_URL == ITVIE._VALID_URL


# Generated at 2022-06-12 17:51:17.282204
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE()
    assert isinstance(instance, ITVIE)

# Generated at 2022-06-12 17:51:20.385860
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE('https://www.itv.com/hub/peston-on-sunday/2a3631a0037',{})
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/peston-on-sunday/2a3631a0037'

# Generated at 2022-06-12 17:51:26.251067
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = info_extractor._match_id(url)
    assert video_id == '2a4547a0012'
    webpage = info_extractor._download_webpage(url, video_id)
    assert webpage is not None
    assert video_id in webpage


# Generated at 2022-06-12 17:51:34.192188
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE()
    assert inst._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert inst._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }


# Generated at 2022-06-12 17:51:37.439811
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    testurl = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._match_id(testurl) == 'btcc-2018-all-the-action-from-brands-hatch'

import os
import unittest


# Generated at 2022-06-12 17:51:38.990601
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-12 17:51:48.597355
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class DummyDisplay(object):
        def __init__(self, sort_func):
            self.sort_func = sort_func
        def sort(self, list, key=None, reverse=False):
            return self.sort_func(list, key=key, reverse=reverse)
    d = DummyDisplay(sorted)
    itv = ITVBTCCIE(d)
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itv.suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == True
    assert itv.su

# Generated at 2022-06-12 17:54:16.199318
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    webpage = " <html></html>"
    expected_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=6135028766001'

    inst = ITVBTCCIE()
    inst._download_webpage = lambda x, y : webpage

# Generated at 2022-06-12 17:54:22.115917
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_obj = ITVIE()

# Generated at 2022-06-12 17:54:23.300590
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test ITV class's constructor
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:54:25.795401
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test for missing/invalid parameters
    with pytest.raises(ExtractorError):
        # Missing `url` in params
        assert ITVIE(None, None) is not None
    with pytest.raises(ExtractorError):
        # Invalid `url` in params
        assert ITVIE(None, None, 'Invalid') is not None



# Generated at 2022-06-12 17:54:28.677826
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert(ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-12 17:54:31.821672
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:54:33.197121
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()


# Generated at 2022-06-12 17:54:35.837655
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:54:39.733589
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_IE = ITVIE('ItvIE', ITVIE.ie_key())
    assert test_IE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:54:40.379168
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()
