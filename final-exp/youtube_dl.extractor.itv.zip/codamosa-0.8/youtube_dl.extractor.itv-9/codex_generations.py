

# Generated at 2022-06-12 17:46:17.475537
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test if all elements of ITVIE._TESTS are correct
    for test in ITVIE._TESTS:
        url = test['url']
        video_id = ITVIE._VALID_URL.match(url).group(1)
        # Get webpage
        webpage = ITVIE._download_webpage(ITVIE(), url, video_id)
        # Get info_dict
        info_dict = ITVIE._real_extract(ITVIE(), url)
        assert info_dict['id'] == ITVIE._TESTS[0]['info_dict']['id']
        assert info_dict['title'] == ITVIE._TESTS[0]['info_dict']['title']
        assert info_dict['series'] == ITVIE._TESTS[0]['info_dict']['series']
        assert info

# Generated at 2022-06-12 17:46:20.396661
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test class
    instance = ITVIE()
    assert instance.name != None
    assert instance.ie != None
    assert instance.test != None

    # Test instance
    assert ITVIE({}) != None

# Generated at 2022-06-12 17:46:31.649747
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    expected = ITVBTCCIE._TEST
    assert ie._VALID_URL == ITVBTCCIE._VALID_URL
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE
    assert ie._TESTS == []
    assert ie._TEST == expected
    assert ie._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == expected['info_dict']['id']


# Generated at 2022-06-12 17:46:43.754865
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_info = {
        'example': 'https://www.itv.com/hub/liar/2a4547a0012',
        'result': {
            'id': '2a4547a0012',
            'ext': 'mp4',
            'title': 'Liar - Series 2 - Episode 6',
            'description': 'md5:d0f91536569dec79ea184f0a44cca089',
            'series': 'Liar',
            'season_number': 2,
            'episode_number': 6,
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }
    ITVIE(test_info['example'], 'ITVIE').test_video_info(test_info)


# Generated at 2022-06-12 17:46:47.916697
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert ie.video_id == '2a4547a0012'
    assert ie.url == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ie.playlist_id == '2a4547a0012'


# Generated at 2022-06-12 17:46:51.592876
# Unit test for constructor of class ITVIE
def test_ITVIE():
	assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
	assert ITVIE._GEO_COUNTRIES == ['GB']


# Generated at 2022-06-12 17:46:56.253083
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        # Test to write the constructor of class ITVIE
        # the constructor will raise a exception if it failed
        ITVIE({})
    except:
        # If a exception happend, it means the test failed
        assert False, "The constructor of ITVIE raised a exception"
    else:
        # If there is no exception, it means the test passed
        pass
        

# Generated at 2022-06-12 17:46:59.656708
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IT = ITVIE()
    assert IT._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:47:09.171748
# Unit test for constructor of class ITVIE
def test_ITVIE():
    expected_info = {'id': '2a4547a0012',
                     'ext': 'mp4',
                     'title': 'Liar - Series 2 - Episode 6',
                     'description': 'md5:d0f91536569dec79ea184f0a44cca089',
                     'series': 'Liar',
                     'season_number': 2,
                     'episode_number': 6}

    instance = ITVIE()
    assert isinstance(instance, ITVIE)

    info = instance._real_extract('https://www.itv.com/hub/liar/2a4547a0012')

    for key in info:
        assert info[key] == expected_info[key]

# Generated at 2022-06-12 17:47:10.726520
# Unit test for constructor of class ITVIE
def test_ITVIE():
	assert ITVIE(None).__class__.__name__ == "ITVIE"

# Generated at 2022-06-12 17:47:30.964747
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.__name__ == 'ITVIE'
    assert ITVIE.ie_key() == 'ITV'
    assert ITVIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVIE._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:47:31.340320
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE



# Generated at 2022-06-12 17:47:35.834222
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch').PLAYLIST_ID == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:47:44.489926
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # pylint: disable=protected-access
    try:
        assert (ITVBTCCIE(None)._TEST['url'] ==
                ITVBTCCIE._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
        assert ITVBTCCIE._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    except:
        return False
    return True

# Generated at 2022-06-12 17:47:47.467964
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """This is a test for constructor of class ITVIE."""
    instance = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    print(instance)

# Generated at 2022-06-12 17:47:50.984966
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')._real_extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:47:58.083407
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Create instance of class ITVIE and verify correct initialization
    ITVIE_instance = ITVIE()
    assert ITVIE_instance._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:48:00.287572
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITBTCCIE = ITVBTCCIE('test');
    ITBTCCIE._real_initialize()

# Generated at 2022-06-12 17:48:02.392661
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('ITVBTCC', ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-12 17:48:05.363007
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
        return False
    except TypeError:
        # OK
        return True

# Generated at 2022-06-12 17:48:35.110685
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE.ie_key())._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-12 17:48:38.317400
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/'
          'liar/2a4547a0012').assert_equal(ITVIE(
              'https://www.itv.com/hub/'
              'liar/2a4547a0012').result())

# Generated at 2022-06-12 17:48:41.410918
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Test to check if ITVIE (an InfoExtractor) can be constructed
    """
    ies = [
        ITVIE,
    ]
    for ie in ies:
        ie(None)

# Generated at 2022-06-12 17:48:44.892641
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Creation of new object of class ITVIE with URL.
    """
    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(test_url)

# Generated at 2022-06-12 17:48:55.451681
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Testcase 1
    # input_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    info = ITVIE()._real_extract('https://www.itv.com/hub/liar/2a4547a0012')

    # Check for assertion: info['id'] == '2a4547a0012'
    assert info['id'] == '2a4547a0012'

    # Check for assertion: info['title'] == 'Liar - Series 2 - Episode 6'
    assert info['title'] == 'Liar - Series 2 - Episode 6'

    # Check for assertion: info['description']
    assert 'md5:d0f91536569dec79ea184f0a44cca089' in info['description']

    # Check for assertion: info['series']

# Generated at 2022-06-12 17:48:58.397946
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constr = ITVBTCCIE(dict())
    assert constr._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-12 17:48:59.082506
# Unit test for constructor of class ITVIE
def test_ITVIE():
    pass

# Generated at 2022-06-12 17:49:00.945603
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    ITVIE(url)

# Generated at 2022-06-12 17:49:02.831542
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034")

# Generated at 2022-06-12 17:49:14.564191
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ie._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:50:21.600810
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['url'] == ITVBTCCIE._VALID_URL
    assert ITVBTCCIE._TEST['playlist_mincount'] == 9
    assert ITVBTCCIE._TEST['info_dict'] == {'title': 'BTCC 2018: All the action from Brands Hatch', 'id': 'btcc-2018-all-the-action-from-brands-hatch'}

# Generated at 2022-06-12 17:50:23.200773
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
  assert ITVBTCCIE.__name__ == "ITVBTCCIE"


# Generated at 2022-06-12 17:50:29.206244
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
	extractor = ITVBTCCIE()
	# The following line will assert when the constructor fails
	# as it should not fail, an empty list is returned.
	s = extractor.extract(test_url)
	assert s['_type'] == 'playlist', 'The type of the response is not playlist'

# Generated at 2022-06-12 17:50:31.332701
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # The constructor's test
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:50:33.690681
# Unit test for constructor of class ITVIE
def test_ITVIE():
    if 'ITV can only be used in GB' in str(ITVIE().suitable):
        return "Tests are only run in GB"
    else:
        return "Tests failed"

# Generated at 2022-06-12 17:50:42.631383
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._TEST['url'] == url
    assert ITVBTCCIE._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert ITVBTCCIE._TEST['playlist_mincount'] == 9
    assert ITVBTCCIE._VALID_URL == 'https?://(?:www\\\\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:50:45.844464
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    stream = ITVBTCCIE()._download_webpage(url, 'btcc-2018-all-the-action-from-brands-hatch')
    print(stream)

# Generated at 2022-06-12 17:50:48.329949
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == 'https?://(?:www\\.)?itv\\.com/hub/[^/]+/([0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:50:52.811596
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IE = ITVBTCCIE()
    assert IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:50:58.184812
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # When ITVIE() is created, it will automatically find and use the
    # extractors it should use.
    ie = ITVIE()
    assert ie._downloader is None
    # test a itv.com url to ensue ITVBTCCIE was constructor
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    assert isinstance(ie._real_extract(url), dict)

# Generated at 2022-06-12 17:53:38.066650
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-12 17:53:42.711221
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IT = ITVBTCCIE()
    assert IT._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert IT._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-12 17:53:43.197830
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:53:44.596725
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Simple test to make sure that class ITVBTCCIE is instantiable
    """
    ITVIE()

# Generated at 2022-06-12 17:53:45.067967
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE

# Generated at 2022-06-12 17:53:45.735049
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com')

# Generated at 2022-06-12 17:53:46.754975
# Unit test for constructor of class ITVIE
def test_ITVIE():
	url = ITVIE()
	assert isinstance(url,ITVIE)

# Generated at 2022-06-12 17:53:49.736493
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE('example')
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:53:55.059906
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    obj = ITVBTCCIE()
    res = obj._real_extract(url)
    assert res.get('playlist_count') == 9

# Generated at 2022-06-12 17:53:57.341296
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Single instance of ITVIE
    itv = ITVIE()

    # Test if instance is created
    assert itv is not None

    # Test if instance has expected class
    assert type(itv) == ITVIE