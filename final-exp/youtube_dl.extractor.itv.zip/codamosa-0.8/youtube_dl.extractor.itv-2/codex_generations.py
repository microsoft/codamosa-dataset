

# Generated at 2022-06-12 17:46:17.346984
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Basic test cases."""
    itv_btcc_ie = ITVBTCCIE()
    assert ITVBTCCIE._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:46:20.735314
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:46:21.868945
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test that ITVIE doesn't raise an exception
    ITVIE(InfoExtractor)

# Generated at 2022-06-12 17:46:29.477000
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVE = ITVBTCCIE()
    assert ITVE._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-12 17:46:37.011382
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccie = ITVBTCCIE()
    if itvbtccie._match_id(url):
        ret = "ok"
    else:
        ret = "error"
    print(ret)

if __name__ == "__main__":
    test_ITVBTCCIE()

# Generated at 2022-06-12 17:46:45.904578
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # test constructor of class ITVBTCCIE
    itvBTCCIE = ITVBTCCIE(ITVIE())
    itvBTCCIE.urls = [test_url]
    itvBTCCIE.params['playliststart'] = 1
    itvBTCCIE.params['playlistend'] = 10
    # test the _real_extract function
    itvBTCCIE.download()
    # test the playlist_result function
    assert len(itvBTCCIE.result['entries']) == 10

# Generated at 2022-06-12 17:46:48.714147
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test that id -> id
    assert ITVIE()._match_id('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'

# Generated at 2022-06-12 17:46:54.832798
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # When testing ITVIE, ITV's policies are different than Brightcove
    # Brightcove is usually used for testing so the rules for Brightcove are
    # used for testing. Here, ITV's rules are different, therefore, we need
    # to test ITVIE with the rules that ITV uses.
    ITVIE(None)

    # Make sure nothing crashes, even though the object will be useless
    # This is to make sure nothing crashes when we use this constructor
    # Hopefully this will be passed, even though it will not do anything

# Generated at 2022-06-12 17:47:00.564062
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/long-lost-family/2a3870a0081')     # vod.brightcove.com/services
    ITVIE('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024') # unavailable
    ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034') # invalid vodcrid

# Generated at 2022-06-12 17:47:06.553165
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE._VALID_URL = re.compile(r'(?P<id>[0-9a-zA-Z]+)')
    assert ITVIE._is_valid_url(url, ITVIE._VALID_URL) is True

# Generated at 2022-06-12 17:47:32.068974
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    assert 'GB' in i._GEO_COUNTRIES

# Generated at 2022-06-12 17:47:34.752094
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(url, 'ITVIE')



# Generated at 2022-06-12 17:47:40.159626
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    m = ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '0'
    print(m)

test_ITVBTCCIE()

# Generated at 2022-06-12 17:47:48.240022
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE()._real_extract('https://www.itv.com/hub/liar/2a4547a0012')
    assert info['id'] == '2a4547a0012'
    assert info['ext'] == 'mp4'
    assert info['title'] == 'Liar - Series 2 - Episode 6'
    assert info['description'] == 'md5:d0f91536569dec79ea184f0a44cca089'
    assert info['series'] == 'Liar'
    assert info['season_number'] == 2
    assert info['episode_number'] == 6

# Generated at 2022-06-12 17:47:49.223105
# Unit test for constructor of class ITVIE
def test_ITVIE():
    infoExtractor = ITVIE("test", "")
    assert infoExtractor.geo_bypass_countries == ITVIE._GEO_COUNTRIES

# Generated at 2022-06-12 17:47:50.470708
# Unit test for constructor of class ITVIE
def test_ITVIE():
    iftttIE = ITVIE()

# Generated at 2022-06-12 17:47:57.732847
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert not test.has_been_tested
    test.has_been_tested = True
    assert test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert test.valid_url == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:48:00.158440
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 17:48:03.907877
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:09.587371
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    assert i.GEO_COUNTRIES == ['GB']
    assert i.BRIGHT_COVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert i.IE_NAME == 'itv.com'
    assert i.VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:49:00.019119
# Unit test for constructor of class ITVIE
def test_ITVIE():

    i = ITVIE();

# Generated at 2022-06-12 17:49:01.174750
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-12 17:49:06.027118
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:49:11.267698
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pl_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie.extract(pl_url)['id'] == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:49:14.331784
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_object = ITVIE()
    test_object._download_webpage()
    test_object._extract_m3u8_formats()
    test_object._search_json_ld()
    test_object._html_search_meta()

# Generated at 2022-06-12 17:49:18.377635
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert (info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')



# Generated at 2022-06-12 17:49:27.936361
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    e = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert e._match_id == 'btcc-2018-all-the-action-from-brands-hatch'
    assert e._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert e.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:49:31.151055
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    #ITVBTCCIE
    assert ITVBTCCIE._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:49:41.232187
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE('ITVBTCCIE', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvbtccie._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:49:43.546099
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012', {}).extract()

# Generated at 2022-06-12 17:50:55.598300
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()

# Generated at 2022-06-12 17:50:56.160988
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:51:01.427605
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtcc_ie = ITVBTCCIE()
    assert itvbtcc_ie.suitable(url)
    # Test for match_id
    playlist_id = itvbtcc_ie._match_id(url)
    assert playlist_id == 'btcc-2018-all-the-action-from-brands-hatch'
    # Test for _real_extract
    playlist = itvbtcc_ie._real_extract(url)

# Generated at 2022-06-12 17:51:06.571746
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = r'https://www.itv.com/hub/liar/2a4547a0012'
    itvIE = ITVIE()
    match = itvIE._VALID_URL.match(url)
    assert match
    assert match.group('id') == '2a4547a0012'
    assert itvIE._real_extract(url)

# Generated at 2022-06-12 17:51:13.921464
# Unit test for constructor of class ITVIE
def test_ITVIE():
    videos = ITVIE()._real_extract('https://www.itv.com/hub/liar/2a4547a0012')
    assert videos['id'] == '2a4547a0012'
    assert videos['title'] == 'Liar - Series 2 - Episode 6'
    assert videos['series'] == 'Liar'
    assert videos['season_number'] == 2
    assert videos['episode_number'] == 6
    assert videos['description'] == 'Liar - Series 2 - Episode 6'
    assert videos['duration'] == 2160

# Generated at 2022-06-12 17:51:21.017440
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/good-mornings-25th-anniversary/2a2673a0105'
    ITVIE(None)._real_extract(url)
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(None)._real_extract(url)
    url = 'http://www.itv.com/hub/through-the-keyhole/2a2271a0033'
    ITVIE(None)._real_extract(url)
    url = 'http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    ITVIE(None)._real_extract(url)

# Generated at 2022-06-12 17:51:24.888699
# Unit test for constructor of class ITVIE
def test_ITVIE():
	f = ITVIE()
	assert f._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-12 17:51:33.527683
# Unit test for constructor of class ITVIE

# Generated at 2022-06-12 17:51:36.494430
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert i.url == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert i.video_id == '2a4547a0012'

# Generated at 2022-06-12 17:51:41.142347
# Unit test for constructor of class ITVIE
def test_ITVIE():
    infoExtractor = ITVIE()
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    expected_id = '2a4547a0012'
    expected_title = 'Liar - Series 2 - Episode 6'
    video_id = infoExtractor._match_id(url)
    assert video_id == expected_id
    assert re.search(infoExtractor._VALID_URL, url) is not None

# Generated at 2022-06-12 17:54:01.605334
# Unit test for constructor of class ITVIE
def test_ITVIE():
    iev = ITVIE()
    assert iev._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:54:05.327045
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

test_ITVBTCCIE()

# Generated at 2022-06-12 17:54:08.843846
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034"
    ITVIE._VALID_URL = re.compile(ITVIE._VALID_URL)
    ITVIE()._real_extract(url)

# Generated at 2022-06-12 17:54:13.721838
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import datetime
    time1 = datetime.datetime.now()
    print(ITVIE._TESTS[0])
    test_video = ITVIE(
        ITVIE._TESTS[0],
        ITVIE._TESTS[0]['url'],
        ITVIE._TESTS[0]['info_dict']
    )
    time2 = datetime.datetime.now()
    print((time2-time1).total_seconds())

# Generated at 2022-06-12 17:54:18.692687
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    ie.url = url
    ie._download_webpage = lambda url, video_id: 'data-video-id="123"'
    ie.BRIGHTCOVE_URL_TEMPLATE = 'fake URL'
    entries = [e for e in ie._real_extract(url)]
    assert entries[0]['id'] == '123'
    assert entries[0]['url'] == 'fake URL'

# Generated at 2022-06-12 17:54:21.074081
# Unit test for constructor of class ITVIE
def test_ITVIE():
  test_string = "https://www.itv.com/hub/liar/2a4547a0012"
  assert ITVIE()._match_id(test_string) == "2a4547a0012"


# Generated at 2022-06-12 17:54:22.571464
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:54:31.718850
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.__name__ == 'ITVBTCCIE'
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:54:33.538682
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url='http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE(url)._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:54:35.653435
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(
        "{'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',}"
    )