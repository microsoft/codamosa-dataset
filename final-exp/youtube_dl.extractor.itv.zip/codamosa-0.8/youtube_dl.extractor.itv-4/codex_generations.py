

# Generated at 2022-06-12 17:46:10.477212
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(InfoExtractor)._real_extract(url)

# Generated at 2022-06-12 17:46:12.879082
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")


# Generated at 2022-06-12 17:46:15.002823
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012', {
          'skip_download': True})

# Generated at 2022-06-12 17:46:15.611734
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE

# Generated at 2022-06-12 17:46:19.711744
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:46:31.331416
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._match_id(url) == playlist_id
    assert ITVBTCCIE._match_id(ITVBTCCIE._VALID_URL % playlist_id) == playlist_id
    assert ITVBTCCIE._match_id(ITVBTCCIE._TEST['url']) == playlist_id
    assert ITVBTCCIE._match_id(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '5695157745001') == playlist_id

# Generated at 2022-06-12 17:46:36.169443
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert itvie != None, 'Can not construct ITVIE'
    assert itvie.video_id != None, 'Can not extract video id'


# Generated at 2022-06-12 17:46:41.136818
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    unit_test = ITVBTCCIE()
    result = unit_test.url_result(test_url)
    print(result)

# Generated at 2022-06-12 17:46:44.812720
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    u = ITVBTCCIE()
    assert u.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:46:45.941712
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE()
    except:
        assert False


# Generated at 2022-06-12 17:47:03.096853
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Unit test for constructor of class ITVBTCCIE"""

    test_object = ITVBTCCIE(None)
    assert test_object._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:47:07.405611
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:47:11.543499
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # ITVBTCCIE(info_extractor)
    # return a ITVBTCCIE instance with info_extractor as a parameter
    ie = ITVBTCCIE(InfoExtractor)
    # assert equal the type of ie with ITVBTCCIE
    assert ie.__class__ == ITVBTCCIE

# Generated at 2022-06-12 17:47:12.875016
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert hasattr(ITVBTCCIE, '_real_extract')



# Generated at 2022-06-12 17:47:17.163225
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    original_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    expected_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5751674476001'
    assert ITVBTCCIE()._real_extract(original_url)[0]['url'] == expected_url

# Generated at 2022-06-12 17:47:17.789141
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:47:27.503821
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:47:39.383187
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_ITVIE = ITVIE(None)
    assert test_ITVIE._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert test_ITVIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:47:50.224281
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from . import ITVBTCCIE
    from .extractor.brightcove import BrightcoveNewIE
    btcc_ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert btcc_ie.BR

# Generated at 2022-06-12 17:47:52.775565
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    test if the ITVIE constructor runs with url.
    """
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    ITVIE(url)

# Generated at 2022-06-12 17:48:22.104875
# Unit test for constructor of class ITVIE
def test_ITVIE():
    infoextractor = ITVIE()

    assert infoextractor.constructor(infoextractor, 'https://www.itv.com/hub/liar/2a4547a0012')

    assert infoextractor.constructor(infoextractor, 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033')

    assert infoextractor.constructor(infoextractor, 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')

    assert infoextractor.constructor(infoextractor, 'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')


# Generated at 2022-06-12 17:48:22.666871
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video = ITVIE()

# Generated at 2022-06-12 17:48:31.072629
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    global ITVBTCCIE
    ITVBTCCIE = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = "https://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=%s"
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % (5845371991001)
    ITVBTCCIE._real_extract(ITVBTCCIE)

# Generated at 2022-06-12 17:48:36.180315
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch');
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'



# Generated at 2022-06-12 17:48:45.779843
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class AssertionError(Exception):
        pass
    def assertEqual(actual, expected):
        if actual != expected:
            raise AssertionError('%s != %s' % (actual, expected))

    # The following assert statements are copied from the above class
    # definition (not including 'from __future__ import unicode_literal')
    # with 'pass' replaced by 'raise AssertionError()' and 'assert '
    # removed. This function is for testing the constructor and attribute
    # assignments of class ITVBTCCIE. A normal unit test, e.g. using
    # assertEqual(), cannot be used because it assumes that the
    # constructor of ITVBTCCIE has been executed.
    class ITVBTCCIE(InfoExtractor):
        def __init__(self):
            raise AssertionError()
        _VAL

# Generated at 2022-06-12 17:48:56.051148
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-12 17:49:05.068656
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    # This test is to check whether the hosts ITVBTCCIE accepts are
    # being added in the valid hosts of BrightCoveNewIE.
    info_dict = {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'BTCC 2018: All the action from Brands Hatch',
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
    }
    assert ie.suitable(info_dict['url'])
    info = ie.extract(info_dict['url'])
    assert info
    assert info['id'] == info_dict['id']
    assert info['title'] == info_dict['title']

# Generated at 2022-06-12 17:49:07.146758
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    obj = ITVIE()
    obj.suitable(url)
    obj.url_result(url)

# Generated at 2022-06-12 17:49:12.559009
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:49:13.505185
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert(instance)

# Generated at 2022-06-12 17:50:09.572949
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() == 'itv:btcc'

# Generated at 2022-06-12 17:50:11.880754
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE("https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-12 17:50:14.678950
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvIE = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert itvIE.geo_verification_headers()["x-country-code"] == "GB"

# Generated at 2022-06-12 17:50:21.203175
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # get an instance of ITVIE
    itv = ITVIE()
    # get the id from the url
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    class_name = itv.__class__.__name__
    assert(class_name == 'ITVIE')
    # get the id from the url
    video_id = itv._match_id(url)
    assert(video_id == '2a4547a0012')

# Generated at 2022-06-12 17:50:22.225311
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()
    return


# Generated at 2022-06-12 17:50:26.672389
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:50:31.584266
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE({})
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-12 17:50:38.811971
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    ITVIE("https://www.itv.com/hub/LiAR/2a4547a0012")
    ITVIE("https://www.itv.com/hub/the-voice/2a527ba0049")
    ITVIE("https://www.itv.com/hub/the-voice/2a527ba0049")
    ITVIE("https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034")
    ITVIE("https://www.itv.com/hub/liar-series-2/2a4547a0013")
    ITVIE("https://www.itv.com/hub/catchphrase/psext")
   

# Generated at 2022-06-12 17:50:41.270667
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE()._real_extract(url)

# Generated at 2022-06-12 17:50:42.630850
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie.ie_key() == 'ITV'

# Generated at 2022-06-12 17:53:10.657606
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-12 17:53:19.568052
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .azmedien import AzMedienIE
    from .brightcove import BrightcoveNewIE
    from .francetv import FranceTVIE
    from .kaltura import KalturaIE
    from .naver import NaverIE
    from .sportbox import SportBoxIE
    from .tvnow import TVNowIE


# Generated at 2022-06-12 17:53:21.633247
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:53:22.083554
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-12 17:53:23.894154
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(InfoExtractor('')).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:53:24.423590
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-12 17:53:29.703816
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Unit test for constructor of class ITVBTCCIE
    playlist_url = 'http://www.itv.com/hub/all-star-mr-and-mrs/2a2898a0024'
    itvbtccie = ITVBTCCIE(ITVIE(), playlist_url)
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:53:33.632745
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ex = ITVIE()
    ex.geo_verification_headers()
    ex.report_warning()
    ex.report_warning('message')
    ex.raise_geo_restricted(exception='error')
    ex.url_result(url='url', ie='ie')
    ex.extract_info(url='url', webpage='webpage', video_id='video_id', js_to_json=True)

# Generated at 2022-06-12 17:53:39.588941
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Unit test for constructor of class ITVIE
    import unittest
    import ITVExtractor

    class TestITVExtractor(unittest.TestCase):
        def testITVIEInstance(self):
            instance = ITVExtractor.ITVIE()
            # self.assertEquals(type(instance).__name__, 'ITVIE')

    unittest.main()

test_ITVIE()

# Generated at 2022-06-12 17:53:40.986478
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    ITVIE(url)