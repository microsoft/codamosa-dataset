

# Generated at 2022-06-12 17:46:18.122298
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Check we are testing a new version of class ITVIE
    ITVIE_old = InfoExtractor._call_api(
        'https://www.itv.com/hub/liar/2a4547a0012',
        {
            'headers': {
                'User-Agent': 'Mozilla/5.0 (iPad; CPU OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3'
            }
        },
        'ITVIE')[1]
    assert ITVIE_old is not ITVIE, "Old class is the same as new class"
    assert ITVIE_old.ie_key == 'ITV', "Old class does not support ITV"
    # Create a new instance of ITVIE


# Generated at 2022-06-12 17:46:22.877181
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    with open('../bin/test/test_ITVBTCCIE.html') as f:
        html = f.read()
    assert ITVBTCCIE._real_extract(ITVBTCCIE, 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', html) == True

# Generated at 2022-06-12 17:46:35.090811
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_cases = [
        {
            "title": "BTCC 2018: All the action from Brands Hatch",
            "playlist_id": "btcc-2018-all-the-action-from-brands-hatch",
            "playlist_mincount": 9,
        },
        {
            "title": "BTCC 2018: All the action from Donington Park",
            "playlist_id": "btcc-2018-all-the-action-from-donington-park",
            "playlist_mincount": 6,
        }
    ]

    for case in test_cases:
        playlist_id = case["playlist_id"]
        title = case["title"]
        entries_min_count = case["playlist_mincount"]

        url = "http://www.itv.com/btcc/races/"

# Generated at 2022-06-12 17:46:41.314768
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    a = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert a.BTCC_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-12 17:46:49.416613
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE('btcc-2018-all-the-action-from-brands-hatch')
    assert info_extractor._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'
    assert info_extractor._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch/thursdays-report') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:46:50.587239
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_class = ITVIE()
    assert test_class


# Generated at 2022-06-12 17:46:51.553204
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(None).ITVBTCCIE()

# Generated at 2022-06-12 17:46:56.205775
# Unit test for constructor of class ITVIE
def test_ITVIE():
    fixture = 'tests/fixtures/itv.html'
    i = ITVIE(InfoExtractor())
    i._download_webpage = lambda url, video_id: open(fixture, encoding='utf-8').read()
    i._real_extract('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:47:06.028126
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    instance.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    instance.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    instance.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:47:09.196151
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:47:23.831349
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-12 17:47:30.837543
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    def test_ITVBTCCIE_constructor_json_list(playlist_id, playlist_entries=[], start=0, end=0):
        playlist_entries_json = [
            {
                'start': start_pos,
                'end': end_pos,
                'permalink': perma_link,
                'product': product_id
            }
            for start_pos, end_pos, perma_link, product_id in playlist_entries
        ]
        itvbtcc_ie = ITVBTCCIE(
            'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
        assert itvbtcc_ie.playlist_id == playlist_id
        assert itvbtcc_ie.playlist_start

# Generated at 2022-06-12 17:47:40.820982
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()

# Generated at 2022-06-12 17:47:45.066835
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:47:48.805354
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # ITVBTCCIE objects should be constructed with URL and no other parameters
    # and if the URL is non-empty
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:47:50.785583
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print(ITVIE)

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-12 17:47:51.670911
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE()
    assert test

# Generated at 2022-06-12 17:48:03.092409
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test normal case
    video_id = 'btcc-2018-all-the-action-from-brands-hatch'
    url = 'http://www.itv.com/btcc/races/' + video_id
    x = ITVBTCCIE()
    x._download_webpage = lambda url, video_id: '<html><body><div data-video-id="12345"></div><div data-video-id="67890"></div><div data-video-id="123"></div></body></html>'
    assert x.extract(url)
    # Test case when data-video-id is missing

# Generated at 2022-06-12 17:48:04.659140
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['url'] == ITVBTCCIE('ITVBTCCIE')._TEST['url']

# Generated at 2022-06-12 17:48:07.500458
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:41.120816
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    infoExtractor = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch.html")
    assert infoExtractor._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert infoExtractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:52.611732
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.__name__ == 'ITVBTCCIE'
    btcc = ITVBTCCIE()
    assert btcc.__class__.__name__ == 'ITVBTCCIE'
    assert btcc._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:49:01.260826
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    url = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    webpage = ie._download_webpage(url, None)
    params = extract_attributes(ie._search_regex(
        r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params'))
    ios_playlist_url = params.get('data-video-playlist') or params['data-video-id']
    hmac = params['data-video-hmac']
    headers = ie.geo_verification_headers()

# Generated at 2022-06-12 17:49:02.520217
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.__name__ == 'ITVBTCCIE'

# Generated at 2022-06-12 17:49:09.382609
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # YouTube
    try:
        import youtube_dl.extractor.youtube
        ITVIE('https://www.itv.com/hub/itv/2a42b2004c')
        ITVIE('http://www.itv.com/hub/itv/2a42b2004c')
    except Exception:
        raise AssertionError('Could not find YouTube class')
    # Brightcove
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    # Brightcove plugins
    ITVIE('http://www.itv.com/hub/dancing-on-ice/2a4758a0207')
    # BTCC

# Generated at 2022-06-12 17:49:10.461237
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:49:13.968318
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # Creating an object of ITVIE class
    ie = ITVIE()

    # Testing the different constructors of ITVIE class
    assert(ie._real_extract(ie._TESTS[0]['url']) == ie._TESTS[0]['info_dict'])

# Generated at 2022-06-12 17:49:18.655023
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE)
    assert(str(ITVBTCCIE( {} ).BRIGHTCOVE_URL_TEMPLATE) == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-12 17:49:21.888416
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    info = ie.extract(test_ITVBTCCIE.test_url)
    assert len(info['entries']) == 9

test_ITVBTCCIE.test_url = ITVBTCCIE._TEST['url']

# Generated at 2022-06-12 17:49:25.746177
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    obj = ITVBTCCIE()
    obj._match_id(url)

# Generated at 2022-06-12 17:50:03.707235
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    cie = ITVBTCCIE()
    assert cie._TEST.get('url') == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert cie._TEST.get('info_dict') == {'id': 'btcc-2018-all-the-action-from-brands-hatch',
                                          'title': 'BTCC 2018: All the action from Brands Hatch'}


# Generated at 2022-06-12 17:50:10.237762
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Usage: $ python -m testtools.run ITVBTCCIE
    # set PYTHONPATH=../youtube_dl
    # To run a single test:
    # $ python -m testtools.run ITVBTCCIE.test_ITVBTCCIE
    from testtools import TestCase
    from testtools.matchers import Equals, MatchesException
    import youtube_dl.extractor.itv as ITVBTCCIE

    class ITVBTCCIETest(TestCase):
        # subTest method is available in python >= 3.4
        def test_ITVBTCCIE(self):
            # Check if an exception is raised if no parameters are passed
            self.assertThat(ITVBTCCIE.ITVBTCCIE, MatchesException(TypeError))

            # Check if an exception is raised if wrong parameters are passed
            self

# Generated at 2022-06-12 17:50:12.596004
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor_passed = ITVBTCCIE(None, None) is not None
    assert constructor_passed, 'Failed to construct ITVBTCCIE'

# Generated at 2022-06-12 17:50:16.333819
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Test ITVBTCCIE constructor.
    """
    test = ITVBTCCIE(None)
    assert test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:50:18.669612
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert inst.entries is None

# Generated at 2022-06-12 17:50:23.237449
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:50:27.775045
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    TestClass = ITVBTCCIE()
    assert(re.match(r'HkiHLnNRx_', TestClass.BRIGHTCOVE_PLAYER_ID))
    assert(re.match(r'1582188683001', TestClass.BRIGHTCOVE_ACCOUNT_ID))

# Generated at 2022-06-12 17:50:30.895761
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert i.PARAMS_RE == r'(?s)(<[^>]+id="video"[^>]*>)'
    assert isinstance(i.geo_verification_headers, staticmethod)

# Generated at 2022-06-12 17:50:38.649716
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    itv_ie = ITVIE()
    response = itv_ie._download_webpage(url, '2a4547a0012')
    params = extract_attributes(itv_ie._search_regex(
        r'(?s)(<[^>]+id="video"[^>]*>)', response, 'params'))
    ios_playlist_url = params.get('data-video-playlist') or params['data-video-id']
    hmac = params['data-video-hmac']
    headers = itv_ie.geo_verification_headers()

# Generated at 2022-06-12 17:50:42.322962
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    expected_id = '2a4547a0012'
    ie = ITVIE()
    info = ie.extract(url)
    assert info['id'] == expected_id


# Generated at 2022-06-12 17:52:06.689319
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(InfoExtractor)._download_webpage(
        "https://www.itv.com/hub/liar/2a4547a0012", "2a4547a0012")

# Generated at 2022-06-12 17:52:10.617022
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    ITVBTCCIE(params = {'geo_verify_ip_blocks': '193.113.0.0/16'})
    assert ITVIE._GEO_COUNTRIES == ['GB']
    assert ITVBTCCIE._GEO_COUNTRIES == None


# Generated at 2022-06-12 17:52:12.988800
# Unit test for constructor of class ITVIE
def test_ITVIE():
    #ITVIE constructor should throw no exceptions
    ITVIE()

# Generated at 2022-06-12 17:52:13.633367
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-12 17:52:17.150352
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_ITVBTCCIE = ITVBTCCIE()
    assert test_ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:52:22.846690
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Create a new instance of class ITVIE
    iTV_IE = ITVIE()
    # Check the value of _VALID_URL
    assert (iTV_IE._VALID_URL == r'https?://(?:www\.)?itv.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)')
    # Check the value of _GEO_COUNTRIES
    assert (iTV_IE._GEO_COUNTRIES == ['GB'])
    # Check the number of elements of the list
    assert (len(iTV_IE._TESTS) == 4)

# Generated at 2022-06-12 17:52:25.160310
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test for constructor of class ITVBTCCIE"""
    class_instance = ITVBTCCIE()
    assert class_instance

# Generated at 2022-06-12 17:52:30.637738
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """This test is to test whether the class ITVIE can construct an instance
    successfully.
    """
    ITVIE()._download_webpage(
        'https://www.itv.com/hub/liar/2a4547a0012', '2a4547a0012')
    ITVIE()._download_webpage(
        'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:52:40.266827
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    video_id = '3727083132001'

    # These need to be run first
    BrightcoveNewIE.test()

    # Create an instance of class ITVBTCCIE
    instance = ITVBTCCIE()

    # Check that the correct video is extracted
    info = instance.extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

    # Check number of videos in playlist
    assert len(info['entries']) == 9

    # Check that the reconstructed URL of the video is the same as the original

# Generated at 2022-06-12 17:52:43.732870
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:55:31.333589
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE(InfoExtractor())
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:55:31.785288
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:55:35.225502
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:55:44.166074
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    m = ITVBTCCIE()
    assert m.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert m._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:55:46.058699
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')