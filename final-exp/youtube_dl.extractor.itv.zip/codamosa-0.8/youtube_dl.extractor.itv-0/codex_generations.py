

# Generated at 2022-06-12 17:46:04.472077
# Unit test for constructor of class ITVIE
def test_ITVIE():
    constructor_test(ITVIE, 'gb')

# Generated at 2022-06-12 17:46:05.918120
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE()
    #assert test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId='


# Generated at 2022-06-12 17:46:07.919204
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-12 17:46:17.979146
# Unit test for constructor of class ITVIE
def test_ITVIE():
    x = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert x.IE_NAME == "itv:vod"
    assert x.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"
    assert x.VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert x.GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:46:21.296894
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:46:23.779047
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('http://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-12 17:46:28.280465
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:46:39.290610
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from unittest import makeSuite, TestCase
    from .test_brightcove import test_brightcove_url_result
    test_cases = (
        (ITVBTCCIE, 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'btcc-2018-all-the-action-from-brands-hatch', 9),
    )
    suite = makeSuite(TestCaseClass)
    for constructor, url, playlist_id, playlist_mincount in test_cases:
        test_brightcove_url_result(constructor, url, playlist_id, playlist_mincount)
    return suite

# Generated at 2022-06-12 17:46:45.331708
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist = ITVBTCCIE()._real_extract(url)
    assert playlist['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert playlist['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert len(playlist['entries']) == 9

# Generated at 2022-06-12 17:46:45.817214
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:47:04.944209
# Unit test for constructor of class ITVIE
def test_ITVIE():
   infoExtractor = ITVIE()
   assert infoExtractor.__class__.__name__ == 'ITVIE'
   assert infoExtractor._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
   assert 'GB' in infoExtractor._GEO_COUNTRIES


# Generated at 2022-06-12 17:47:09.555621
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from ITVIE import ITVIE
    from ITVBTCCIE import ITVBTCCIE
    url = 'https://www.itv.com/hub/betty-blue-eyes/2a2816a0006'
    assert ITVIE.suitable(url)
    assert ITVBTCCIE.suitable(url) == False

# Generated at 2022-06-12 17:47:11.625550
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        test = ITVIE()
        print(test)
    except:
        print('ITVIE class creation failed.')

# Generated at 2022-06-12 17:47:13.076182
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:47:17.746012
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._download_webpage('https://www.itv.com/hub/liar/2a4547a0012','2a4547a0012','', '')

# Generated at 2022-06-12 17:47:21.992358
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Tests the ITVIE constructor
    """
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    class_ = ITVIE(url)
    assert class_._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-12 17:47:24.707632
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert video.extractor_key == 'live-itv:itv'

# Generated at 2022-06-12 17:47:25.621612
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(InfoExtractor())

# Generated at 2022-06-12 17:47:28.738195
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Test the constructor function of ITVBTCCIE
    """
    instance = ITVBTCCIE()
    assert re.search(instance._VALID_URL, 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-12 17:47:40.130089
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itvie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:47:57.626925
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itv_btcc_ie = ITVBTCCIE()
    assert isinstance(itv_btcc_ie, ITVBTCCIE)
    assert isinstance(itv_btcc_ie, InfoExtractor)
    assert itv_btcc_ie._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert itv_btcc_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itv_btcc_ie._TEST

# Generated at 2022-06-12 17:48:02.182706
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print(ITVIE(None)._build_request({
        'url': 'https://www.itv.com/hub/liar/2a4547a0012',
        'video_id': '2a4547a0012'
    }))


# Generated at 2022-06-12 17:48:10.457313
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class_ = ITVBTCCIE(None)
    assert class_._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert class_._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert class_._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert class_._TEST['playlist_mincount'] == 9

# Generated at 2022-06-12 17:48:18.127197
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    expected_ID = 'btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE(url)
    playlist_id = ie._match_id(url)
    assert playlist_id == expected_ID
    entries = [
        ie.url_result(
            ie.BRIGHTCOVE_URL_TEMPLATE % video_id,
            ie=BrightcoveNewIE.ie_key(), video_id=video_id)
        for video_id in re.findall(r'data-video-id=["\'](\d+)', ie.webpage)]

# Generated at 2022-06-12 17:48:19.528713
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-12 17:48:23.173325
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:48:26.364314
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['info_dict']
    assert ITVBTCCIE._TEST['playlist_mincount']

# Generated at 2022-06-12 17:48:34.993660
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-12 17:48:35.830777
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-12 17:48:38.711337
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test making sure the constructor of ITVIE behaves as expected
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(None)._real_extract(url)
test_ITVIE()

# Generated at 2022-06-12 17:49:04.774732
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from youtube_dl.downloader.f4m import F4MDownloader
    f4m_downloader = F4MDownloader(params=None)
    f4m_downloader.params = None
    assert f4m_downloader is not None

# Generated at 2022-06-12 17:49:05.295374
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-12 17:49:07.079200
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/the-secret-life-of-the-zoo/2a2336a0071')


# Generated at 2022-06-12 17:49:09.109336
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # The constructor of ITVIE
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012', 'https://www.itv.com/hub/liar/2a4547a0012', False, False)

# Generated at 2022-06-12 17:49:12.126281
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._match_id('http://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'

# Generated at 2022-06-12 17:49:15.767172
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    id = 'btcc-2018-all-the-action-from-brands-hatch'
    url = 'http://www.itv.com/btcc/races/%s' % id
    ie = ITVBTCCIE()
    res = ie._real_extract(url)
    assert res['id'] == id
    assert len(res['entries']) == 9

# Generated at 2022-06-12 17:49:18.776653
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvBTCCIE = ITVBTCCIE(None, None)
    assert itvBTCCIE.PLAYLIST_TITLE is not None
    assert itvBTCCIE.BRIGHTCOVE_URL_TEMPLATE is not None



# Generated at 2022-06-12 17:49:22.013207
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:49:30.494466
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    unit_test_ITVBTCCIE = ITVBTCCIE()
    unit_test_ITVBTCCIE._match_id(url='http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    unit_test_ITVBTCCIE._real_extract(url='http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    unit_test_ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-12 17:49:35.277598
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE().extract('http://www.itv.com/hub/liar/2a4547a0012')
    assert info['id'] == '2a4547a0012'
    assert info['title'] == 'Liar - Series 2 - Episode 6'
    assert info['description'] == 'md5:d0f91536569dec79ea184f0a44cca089'
    assert info['series'] == 'Liar'
    assert info['season_number'] == 2
    assert info['episode_number'] == 6

# Generated at 2022-06-12 17:50:43.666816
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:50:46.983287
# Unit test for constructor of class ITVIE
def test_ITVIE():
    instance = ITVIE()
    assert instance.url_result(u'http://www.itv.com/hub/liar/2a4547a0012') == {
        'url': u'http://www.itv.com/hub/liar/2a4547a0012',
        'ie_key': u'ITV', 'id': u'2a4547a0012'}

# Generated at 2022-06-12 17:50:50.677515
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Check that ITVIE is constructed correctly
    # ITVIE(InfoExtractor)
    assert ITVIE.__name__ == 'ITVIE'
    assert ITVIE.__doc__ == 'Information extractor for itv.com'


# Generated at 2022-06-12 17:50:52.664234
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert x.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"

# Generated at 2022-06-12 17:50:59.027437
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # Test that ITVIE can be constructed with a valid URL
    test_valid_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    test_valid_class = ITVIE(test_valid_url)
    assert test_valid_class._match_id(test_valid_url) == '2a4547a0012'
    assert test_valid_class._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:51:08.090836
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    video_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE(
    ).suitable(video_url), \
        'Video URL http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch not suitable for ITVBTCCIE'
    assert not ITVIE(
    ).suitable(video_url), \
        'Video URL http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch suitable for ITVIE'



# Generated at 2022-06-12 17:51:13.061962
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    downloader = ITVIE()
    downloader._download_webpage = lambda url, filename: '<html></html>'
    downloader.download(url)
    assert downloader._downloader

# Generated at 2022-06-12 17:51:20.468389
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-12 17:51:30.164862
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .compat import urlparse
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ie = ITVIE()
    id = '2a4547a0012'
    title = 'Liar - Series 2 - Episode 6'
    description = 'md5:d0f91536569dec79ea184f0a44cca089'
    series = 'Liar'
    season_number = 2
    episode_number = 6
    formats = []
    subtitles = {}
    duration = None
    info = {'id': id, 'ext': 'mp4', 'title': title, 'description': description, 'series': series, 'season_number': season_number, 'episode_number': episode_number, 'formats': formats, 'subtitles': subtitles, 'duration': duration}

# Generated at 2022-06-12 17:51:32.196860
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    config = ITVBTCCIE()._orig_extract_config()
    assert config['itv']['geo_countries'] == ['GB']

# Generated at 2022-06-12 17:54:01.917205
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    extractor = ITVBTCCIE()
    assert extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert extractor._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert extractor._TEST['info_dict'] == {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'BTCC 2018: All the action from Brands Hatch'
    }
    assert extractor._TEST['playlist_mincount'] == 9

# Generated at 2022-06-12 17:54:06.503106
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc = ITVBTCCIE()
    result = btcc.url_result(btcc.BRIGHTCOVE_URL_TEMPLATE % '5903613128001',
                             BrightcoveNewIE.ie_key())
    assert '5903613128001' in result['url']
    assert 'referrer' in result['url']

# Generated at 2022-06-12 17:54:09.178461
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')


# Generated at 2022-06-12 17:54:13.755161
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    inst = ITVBTCCIE(ITVBTCCIE._create_get_url_instance(url))
    assert inst.urls == [url]
    assert inst.playlist_id == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-12 17:54:16.500805
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class_ = ITVIE()
    assert class_._VALID_URL == '^https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)$', 'The REGEXP for ITV URLs is not correct'
    


# Generated at 2022-06-12 17:54:18.928011
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # test ITVIE is a subclass of InfoExtractor
    assert issubclass(ITVIE, InfoExtractor)

    # test ITVIE constructor
    itv_ie = ITVIE()
    assert itv_ie._VALID_URL == ITVIE._VALID_URL


# Generated at 2022-06-12 17:54:19.821993
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert isinstance(ie, ITVIE)

# Generated at 2022-06-12 17:54:25.080715
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-12 17:54:28.076226
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-12 17:54:36.213973
# Unit test for constructor of class ITVIE
def test_ITVIE():
    def test_instance(URL):
        inst = ITVIE(ITVIE.suitable(URL))
        return inst
    assert ITVIE.suitable('http://www.itv.com/hub/liar/2a4547a0012')
    assert not ITVIE.suitable('http://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    assert not ITVIE.suitable('http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    assert not ITVIE.suitable('http://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')