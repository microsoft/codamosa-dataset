

# Generated at 2022-06-26 12:10:45.611829
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert i_t_v_b_t_c_c_i_e_0



# Generated at 2022-06-26 12:10:48.298912
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()
    assert i_t_v_b_t_c_c_i_e_0 != None


# Generated at 2022-06-26 12:10:49.819546
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE() != None


# Generated at 2022-06-26 12:10:51.549926
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e = ITVIE()

# Generated at 2022-06-26 12:10:52.937502
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVExtractor = ITVIE()



# Generated at 2022-06-26 12:10:54.781705
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()


# Generated at 2022-06-26 12:10:56.242653
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # construction
    assert ITVIE()



# Generated at 2022-06-26 12:10:58.089655
# Unit test for constructor of class ITVIE
def test_ITVIE():
  i_t_v_i_e_ = ITVIE()

# Generated at 2022-06-26 12:10:58.985145
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_i_e = ITVIE()

# Generated at 2022-06-26 12:11:01.822330
# Unit test for constructor of class ITVIE
def test_ITVIE():
    valid_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(valid_url)

# Generated at 2022-06-26 12:11:14.947173
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-26 12:11:18.383853
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:11:19.318619
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(1)

# Generated at 2022-06-26 12:11:24.985765
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:11:29.085442
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    res = ITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert res['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert res['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-26 12:11:30.298580
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-26 12:11:36.090943
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:11:45.743815
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.__class__ == ITVIE
    assert isinstance(ie._VALID_URL, str)
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert isinstance(ie._TESTS, list)

# Generated at 2022-06-26 12:11:49.111184
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ie = ITVIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'ITV Hub'

# Generated at 2022-06-26 12:11:59.845617
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    inst = ITVBTCCIE(None)
    assert inst._VALID_URL == ITVBTCCIE._VALID_URL
    assert inst._TEST == ITVBTCCIE._TEST
    assert inst.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE
    assert inst._real_extract(url)

# Generated at 2022-06-26 12:12:31.565573
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import os
    import tempfile
    from ydl.downloader.external.ffmpeg import FFmpegPostProcessor
    from ydl.downloader.external.execexternal import FFMpegPostProcessor
    from ydl.downloader.http import HttpFD
    from ydl.utils import ISO639Utils, FileDownloader
    from .testcases import SiteTestCase
    from .test_common import TestDownload
    
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    index = SiteTestCase()._TESTS[0]


# Generated at 2022-06-26 12:12:33.603630
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Method for testing ITVIE
    test_string = '<script type="application/ld+json">\
      \n            {\n                "@context": "http://schema.org",\n'
    ITVIE(test_string)

test_ITVIE()

# Generated at 2022-06-26 12:12:37.178424
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL
    assert ITVIE()._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES

# Generated at 2022-06-26 12:12:40.518933
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-26 12:12:47.524499
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITau = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ITau.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:50.713702
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    def TestITVBTCCIE():
        TestITVIE = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
        return TestITVIE

    assert isinstance(TestITVBTCCIE(), ITVBTCCIE)

# Generated at 2022-06-26 12:12:52.358295
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:12:54.345543
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    print(video.get_info())
    print('Done')

# Generated at 2022-06-26 12:12:58.069699
# Unit test for constructor of class ITVIE
def test_ITVIE():
	assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
	assert ITVIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-26 12:13:01.562817
# Unit test for constructor of class ITVIE
def test_ITVIE():
    m = ITVIE()
    assert m.test(test_ITVIE.__name__)

# Generated at 2022-06-26 12:13:53.023948
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')



# Generated at 2022-06-26 12:13:54.888149
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:14:01.907442
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_values = {
        "url": "http://www.itv.com/hub/liar/2a4547a0012",
        "id": "2a4547a0012",
        "title": "Liar - Series 2 - Episode 6"
    }
    itv_ie = ITVIE()
    assert itv_ie.suitable(test_values["url"])
    assert itv_ie._VALID_URL == "https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)"
    assert itv_ie._match_id(test_values["url"]) == test_values["id"]
    assert itv_ie._TESTS[0]["url"] == test_values["url"]
    assert it

# Generated at 2022-06-26 12:14:03.997074
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE('url')
    assert itv.__class__ == ITVIE

# Generated at 2022-06-26 12:14:05.672818
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()

# Generated at 2022-06-26 12:14:11.857277
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-26 12:14:16.891096
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    tv = ITVIE()
    assert isinstance(tv, ITVIE)

    # Test for class ITVBTCCIE

# Generated at 2022-06-26 12:14:22.956734
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/hub/the-chase/2a2569a0040'
    info_dict = ITVBTCCIE()._real_extract(test_url)
    pass


# Generated at 2022-06-26 12:14:32.612372
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    extractor = ITVBTCCIE()
    expected = r'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html\?videoId=5444579622001'
    assert extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert extractor._TEST['url'] == url

# Generated at 2022-06-26 12:14:36.350396
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-26 12:16:44.548560
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info = ITVIE()._real_extract("https://www.itv.com/hub/liar/2a4547a0012")
    assert info['id'] == '2a4547a0012'
    assert info['duration'] == 843
    assert info['title'] == "Liar - Series 2 - Episode 6"
    assert info['description'] == 'md5:d0f91536569dec79ea184f0a44cca089'
    assert info['series'] == 'Liar'
    assert info['season_number'] == 2
    assert info['episode_number'] == 6

# Generated at 2022-06-26 12:16:50.022329
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    entry = ITVBTCCIE()
    assert entry.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:16:56.323391
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    unit_test = ITVBTCCIE()
    assert unit_test._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert unit_test._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert unit_test._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert unit_test._TEST['playlist_mincount'] == 9

# Generated at 2022-06-26 12:17:04.382880
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc_ie = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert btcc_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:17:08.524496
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    match = ITVIE._VALID_URL.match(url)
    assert match
    assert match.group('id') == '2a4547a0012'
    assert ITVIE.BRIGHTCOVE_URL_TEMPLATE is None
    assert ITVIE._GEO_COUNTRIES == ['GB']
    assert '<div class="player-container__container">' in ITVIE._download_webpage(url, 'DummyID')

# Generated at 2022-06-26 12:17:15.169316
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    if __name__ == '__main__':
        print("\nUnit test class ITVBTCCIE")

    itvbtccie = ITVBTCCIE()
    itvbtccie._download_webpage("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch", "btcc-2018-all-the-action-from-brands-hatch")
    for videoId in re.findall(r'data-video-id=["\'](\d+)', itvbtccie.webpage):
        print(itvbtccie._match_id(itvbtccie.BRIGHTCOVE_URL_TEMPLATE % videoId))

    print("\nfinish test class ITVBTCCIE")

# Generated at 2022-06-26 12:17:22.610715
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('smuggle_url', {'geo_ip_blocks': [], 'referrer': 'url'})('https://www.itv.com/hub/liar/2a4547a0012')
    ITVIE('smuggle_url', {'geo_ip_blocks': [], 'referrer': 'url'})('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')

# Generated at 2022-06-26 12:17:25.961455
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "http://www.itv.com/hub/liar/2a4547a0012"
    ITVIE(url)

# Generated at 2022-06-26 12:17:32.774435
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class ITVIETest(ITVIE):
        def _download_webpage(self, url, video_id, note='Downloading webpage'):
            return '<meta name="twitter:title" content="Liar - Series 2 - Episode 6">'
    assert ITVIETest()._real_extract('http://www.itv.com/hub/liar/2a4547a0012')['title'] == 'Liar - Series 2 - Episode 6'


# Generated at 2022-06-26 12:17:41.362753
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'