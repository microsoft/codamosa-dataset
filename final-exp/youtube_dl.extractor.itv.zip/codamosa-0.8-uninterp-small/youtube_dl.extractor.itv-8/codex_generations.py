

# Generated at 2022-06-26 12:10:46.620628
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert i_t_v_b_t_c_c_i_e_0
    assert type(i_t_v_b_t_c_c_i_e_0) == ITVBTCCIE


# Generated at 2022-06-26 12:10:47.620025
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_case_0()

# Generated at 2022-06-26 12:10:50.701556
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()


# Generated at 2022-06-26 12:10:52.308893
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()



# Generated at 2022-06-26 12:10:53.991165
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE



# Generated at 2022-06-26 12:10:56.098133
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_0 = ITVIE()


# Generated at 2022-06-26 12:10:57.506990
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-26 12:11:05.994698
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
  assert i_t_v_b_t_c_c_i_e_0.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
  assert i_t_v_b_t_c_c_i_e_0._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:11:17.591007
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e = ITVBTCCIE()
    assert 'ITVBTCCIE' == i_t_v_b_t_c_c_i_e.__class__.__name__
    assert 'i_t_v_b_t_c_c_i_e.py' == i_t_v_b_t_c_c_i_e.__class__.__module__
    assert '1582188683001' == i_t_v_b_t_c_c_i_e.BRIGHTCOVE_ACCOUNT_ID
    assert 'HkiHLnNRx' == i_t_v_b_t_c_c_i_e.BRIGHTCOVE_POLICY_KEY
    assert 'default' == i

# Generated at 2022-06-26 12:11:21.829005
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Argument url must be of type string
    with pytest.raises(TypeError):
        assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-26 12:11:36.508841
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)

# Generated at 2022-06-26 12:11:39.663674
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """ Basic unit tests for ITVIE
    """
    from .common import test_infoextractor
    test_infoextractor(ITVIE)
    test_infoextractor(ITVBTCCIE)

# Generated at 2022-06-26 12:11:48.834440
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # test every field in ITVIE._TESTS
    for test in ITVIE._TESTS:
        ie = ITVIE()
        info_dict = ie.extract(test['url'])
        assert info_dict['title'] == test['info_dict']['title']
        assert info_dict['id'] == test['info_dict']['id']
        assert info_dict['description'] == test['info_dict']['description']
        assert info_dict['ext'] == test['info_dict']['ext']

# Generated at 2022-06-26 12:11:58.029784
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL
    assert ITVIE()._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert ITVIE()._TESTS == ITVIE._TESTS
    assert ITVIE()._extract_url('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'

# Generated at 2022-06-26 12:12:10.024157
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    # The user agent is a randomly generated string that should have no effect on the tests
    itv_ie._downloader.user_agent = 'User-Agent: QuickTime/7.7.1 (qtver=7.7.1;cpu=IA32;os=Mac 10,5,8)'
    # This is the source of the test data, it will be used for the mock download
    source_url = 'https://www.itv.com/hub/pudsey-the-dog-the-movie/2a4988a0029'
    # This is where the test data will be downloaded to
    output_dir = os.path.dirname(os.path.realpath(__file__))
    # This is the output file path

# Generated at 2022-06-26 12:12:14.776926
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:18.164436
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:12:28.377001
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv.suitable('https://www.itv.com/hub/liar/2a4547a0012')
    assert itv.suitable('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    assert itv.suitable('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    assert itv.suitable('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')

# Generated at 2022-06-26 12:12:40.149051
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_m3u8_url = 'http://itv-hls-uk-open-f.akamaihd.net/i/open/2015/05/28/Video_PACKAGE_5568aab0-f9df-4a32-b437-dc15b16a35a7/20150528_1730_5568aab0-f9df-4a32-b437-dc15b16a35a7_,36,45,.mp4.csmil/master.m3u8'
    test_hmac_sha256 = 'C6E67E6CC41DDC3CF83B758B04D8E4BA2793D4F4948CD4207E01F29FADDA17C6'
    test_headers = {'hmac': test_hmac_sha256}

# Generated at 2022-06-26 12:12:43.973229
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    e = ITVIE()
    assert e.match_url(url)

# Generated at 2022-06-26 12:13:11.990328
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    expected = ITVBTCCIE(ITVBTCCIE._downloader, {'url': 'http://www.itv.com/hub/liar/2a4547a0012'})
    assert expected._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-26 12:13:15.577241
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')

# Generated at 2022-06-26 12:13:18.797037
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-26 12:13:23.858109
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:13:32.281230
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_input = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_output = ITVBTCCIE()
    assert ITVBTCCIE._VALID_URL == ''
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == ''
    ITVBTCCIE._VALID_URL = r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert test

# Generated at 2022-06-26 12:13:34.437042
# Unit test for constructor of class ITVIE
def test_ITVIE():
	assert ITVIE("https://www.itv.com/hub/liar/2a4547a0012")._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-26 12:13:36.253626
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('btcc-2018-all-the-action-from-brands-hatch') is not None

# Generated at 2022-06-26 12:13:48.721862
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ITVBTCCIE._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-26 12:13:52.128638
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.__class__.__name__ == 'ITVIE'


# Generated at 2022-06-26 12:14:01.010118
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Check for failed init
    for input_url in [
        None,
        '',
        'http://youtube.com/watch?v=BaW_jenozKc',
    ]:
        try:
            # This will raise an exception if it fails
            ITVIE(input_url)
        except Exception as e:
            print('Failed to initialize ITVIE with %s. Reason: %s' % (input_url, e))
            # Since the test failed, make the test fail so we can see why
            assert(input_url is None)

    # Check for successful init

# Generated at 2022-06-26 12:15:11.617111
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE('ITVBTCCIE', [], {}, {'geo_countries': ['GB']})
    assert itvbtccie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itvbtccie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert itvbtccie._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-26 12:15:17.011413
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == "https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)"

# Generated at 2022-06-26 12:15:22.469463
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    inst = ITVBTCCIE(url)
    assert inst.suitable(url)
    assert inst.valid_url(url)
    assert inst._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-26 12:15:25.513742
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    t = ITVBTCCIE()
    assert t.VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-26 12:15:33.641661
# Unit test for constructor of class ITVIE
def test_ITVIE():
    sample_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    url = ITVIE().url_result(sample_url)
    
    # Test for constructor
    assert url.__class__.__name__ == 'ITVIE'

    # Test for IE key
    assert url.ie_key() == 'ITV'

    # Test for video id
    assert url.video_id == '2a4547a0012'

    # Test for video id
    assert url.video_id == '2a4547a0012'

    # Test for thumbnail
    assert url.thumbnail == None

    # Test for description
    assert url.description == None

    # Test for description
    assert url.description == None

    # Test for title
    assert url.title == None

# Generated at 2022-06-26 12:15:39.636538
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test the constructor of this class
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    e = ITVBTCCIE()
    e._real_extract(url)

# Generated at 2022-06-26 12:15:41.370417
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:15:48.478532
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc_ie = ITVBTCCIE()
    url = ITVBTCCIE._TEST['url']
    assert btcc_ie._match_id(url) == ITVBTCCIE._TEST['info_dict']['id']
    assert btcc_ie._real_extract(url) == ITVBTCCIE._TEST



# Generated at 2022-06-26 12:15:56.242754
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itvie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-26 12:15:58.875342
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/take-me-out/2a3488a3058')

# Generated at 2022-06-26 12:18:31.872508
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-26 12:18:37.486601
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # For debug and testing purposes only
    from .brightcove import BrightcoveNewIE as _BrightcoveNewIE
    _BrightcoveNewIE.embed_re = re.compile(
        r'''(?x)<iframe[^>]+?src=["\'](?P<url>(?:https?:)?//players\.brightcove\.net/(?:[^/]+/)+index\.html\?videoId=[^"\']+)''')

# Generated at 2022-06-26 12:18:42.635583
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
   ie = ITVBTCCIE()
   assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:18:43.448456
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)

# Generated at 2022-06-26 12:18:48.900432
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print("Testing ITVIE:")
    ITV = ITVIE()
    test_data = { 
        'url': 'https://www.itv.com/hub/liar/2a4547a0012'
    }
    if ITV._VALID_URL == ITV._match_id(test_data['url']):
        print("Test case 1 : ITVIE - Constructor - Passed.")
    else:
        print("Test case 1 : ITVIE - Constructor - Failed.")



# Generated at 2022-06-26 12:18:54.778783
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    url2 = "https://www.itv.com/hub/through-the-keyhole/2a2271a0033"
    url3 = "https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034"
    url4 = "https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024"
    ITVIE(url)
    ITVIE(url2)
    ITVIE(url3)
    ITVIE(url4)


# Generated at 2022-06-26 12:18:56.050853
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .test_exceptions import name_exception
    name_exception(ITVIE)

# Generated at 2022-06-26 12:18:57.337803
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE



# Generated at 2022-06-26 12:18:59.954462
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    unit = ITVBTCCIE()
    assert unit.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:19:06.565029
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .common import FakeYDL
    from .brightcove import _extract_brightcove_url
    fake_ydl = FakeYDL()
    fake_ydl.add_info_extractor(ITVBTCCIE)
    fake_ydl.add_info_extractor(BrightcoveNewIE)
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    fake_ydl.extract_info(url)
    results = fake_ydl.extract_info(url)
    assert results['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert results['entries'][0]['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert _extract_