

# Generated at 2022-06-26 12:10:47.911841
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance0 = ITVBTCCIE();
    assert instance0


# Generated at 2022-06-26 12:10:49.606233
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass


# Generated at 2022-06-26 12:10:55.144027
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    itv_ie = ITVIE()
    assert itv_ie._TESTS[0]["url"] == url


# Generated at 2022-06-26 12:11:04.056436
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # First test
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    video_id = "2a4547a0012"
    i_t_v_i_e_0 = ITVIE()
    i_t_v_i_e_0._match_id(url)
    i_t_v_i_e_0._real_extract(url)
    # Second test 
    url = "https://www.itv.com/hub/through-the-keyhole/2a2271a0033"
    i_t_v_i_e_1 = ITVIE()
    i_t_v_i_e_1._match_id(url)
    i_t_v_i_e_1._real_extract(url)

# Generated at 2022-06-26 12:11:08.068192
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

# Generated at 2022-06-26 12:11:09.844479
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_0 = ITVIE()


# Generated at 2022-06-26 12:11:14.625479
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert i_t_v_b_t_c_c_i_e_0.BRIGHTCOVE_URL_TEMPLATE ==  'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:11:18.098435
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert test_case_0().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:11:29.191791
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Instantiation of ITVBTCCIE class
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

    # Assertion of parameter's values
    assert i_t_v_b_t_c_c_i_e_0._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:11:37.455481
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.i_t_v_b_t_c_c_i_e_0.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:11:53.184713
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE == ITVIE.ie_key()
    assert 'itv' == ITVIE.ie_key()

# Generated at 2022-06-26 12:12:01.687241
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test ITVBTCCIE constructor."""
    url = 'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    IE = ITVBTCCIE()
    result = IE.extract(url)
    assert(result['id'] == 'btcc-2018-all-the-action-from-brands-hatch')
    assert(result['title'] == 'BTCC 2018: All the action from Brands Hatch')

# Generated at 2022-06-26 12:12:11.224891
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    meta = {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    testobj = ITVBTCCIE(meta)
    assert isinstance(testobj, ITVBTCCIE)
    assert testobj._TEST['info_dict']['id'] == testobj._VALID_URL

# Generated at 2022-06-26 12:12:13.025057
# Unit test for constructor of class ITVIE
def test_ITVIE():
	assert ITVIE.__name__ == 'ITVIE'

# Generated at 2022-06-26 12:12:21.577711
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Instantiates ITVIE with the specified URL
    itv = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

    # Checks the URL that was used to instantiate ITVIE with the
    # constructor's actual parameter
    if(itv._url == "https://www.itv.com/hub/liar/2a4547a0012"):
        print("test_ITVIE: URL Constructor Test Passed!")
    else:
        print("test_ITVIE: URL Constructor Test Failed!")

    # Checks the _VALID_URL that was used to instantiate ITVIE with the
    # constructor's actual parameter

# Generated at 2022-06-26 12:12:28.584617
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()
    assert IE.IE_NAME == 'itv'
    assert IE.IE_DESC == 'ITV'
    assert ITVIE._VALID_URL == IE._VALID_URL
    assert ITVIE._TESTS == IE._TESTS
    assert ITVIE.BRIGHTCOVE_URL_TEMPLATE == IE.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-26 12:12:33.735539
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.brighcove_url_template() == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:36.950186
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE.IE_NAME, ITVBTCCIE._VALID_URL) is not None


# Generated at 2022-06-26 12:12:49.586093
# Unit test for constructor of class ITVIE
def test_ITVIE():
	assert ITVIE.ie_key() == 'ITV'
	assert ITVIE.ie_key() == ITVIE.ie_key()
	assert ITVIE._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
	assert ITVIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-26 12:12:51.420748
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE().ie_key() == "ITV"


# Generated at 2022-06-26 12:13:20.657801
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_info = ITVIE()._TESTS[0]
    test_url = test_info['url']
    actual = ITVIE()._real_extract(test_url)
    test_info_dict = test_info['info_dict']
    for key, value in test_info_dict.items():
        assert actual[key] == value, 'extraction error on {}, expected {}, actual {}'.format(key, value, actual[key])


# Generated at 2022-06-26 12:13:25.772191
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:13:26.488595
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._VALID_URL()

# Generated at 2022-06-26 12:13:31.136228
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:13:33.071568
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() == 'ITVBTCC'

# Generated at 2022-06-26 12:13:33.864773
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_ITVBTCCIE()
    test_ITVIE()

# Generated at 2022-06-26 12:13:41.151635
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITB = ITVBTCCIE()
    ITB._download_webpage = lambda u1, u2: None
    ITB._match_id = lambda u1: "races/btcc-2018-all-the-action-from-brands-hatch"
    ITB._og_search_title = lambda s: "BTCC 2018: All the action from Brands Hatch"
    ITB.BRIGHTCOVE_URL_TEMPLATE = "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"
    ITB.BRIGHTCOVE_URL_TEMPLATE = "http://test-test.test"
    ITB.BRIGHTCOVE_URL_TEMPLATE = "http://test-test.test"


# Generated at 2022-06-26 12:13:44.330347
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(ITVBTCCIE._downloader, ITVBTCCIE._VALID_URL)

# Generated at 2022-06-26 12:13:46.192765
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    # test_ITVBTCCIE should not throw any error
    ITVBTCCIE()._real_extract(url)

# Generated at 2022-06-26 12:13:47.559320
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('2a4547a0012')

# Generated at 2022-06-26 12:15:03.087016
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .common import InfoExtractor
    from .brightcove import BrightcoveNewIE

    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie.PLAYLIST_TITLE == 'BTCC %s'

# Generated at 2022-06-26 12:15:08.993442
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() == 'ITVBTCC'
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:15:13.906610
# Unit test for constructor of class ITVIE
def test_ITVIE():
    '''Create instance of class ITVIE and test its constructor.'''
    # Create instance using constructor
    instance = ITVIE()
    # Test if instance is created correctly
    assert instance

# Generated at 2022-06-26 12:15:24.042820
# Unit test for constructor of class ITVIE

# Generated at 2022-06-26 12:15:27.261826
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-26 12:15:30.788920
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc = ITVBTCCIE()
    assert itv_btcc.BRIGHTCOVE_URL_TEMPLATE.find('players.brightcove.net') != -1

# Generated at 2022-06-26 12:15:40.101801
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE("")
    assert ie.VALID_URL == ITVIE._VALID_URL
    assert ie.GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert ie.TESTS == ITVIE._TESTS
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-26 12:15:52.300838
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # try to build ITVIE class with invalid URL
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    brightcove_id = '2a4547a0012'
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    # create an object of ITVIE
    itv = ITVIE(BrightcoveNewIE(), url)
    # Check the type of itv object
    assert isinstance(itv, ITVIE)
    assert itv.brightcove_id == brightcove_id

# Generated at 2022-06-26 12:15:54.991022
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    playlist = ITVBTCCIE('', {}).suite()
    assert playlist.test_default()

# Generated at 2022-06-26 12:15:59.700700
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Unit test for constructor of class ITVIE"""
    obj = ITVIE()
    assert obj._VALID_URL == ITVIE._VALID_URL
    assert obj._TESTS == ITVIE._TESTS

# Generated at 2022-06-26 12:18:31.878914
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc_class = class_with_constructor_test(ITVBTCCIE)
    assert btcc_class is ITVBTCCIE

# Generated at 2022-06-26 12:18:40.783672
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    francois_url = extract_attributes(ie._search_regex(
        r'(?s)(<[^>]+id="video"[^>]*>)',
        ie._download_webpage('https://www.itv.com/hub/francois-goes-to-south-africa/2a2458a0019', 'francois'),
        'params'))['data-video-playlist']
    assert francois_url == 'http://mercury.itv.com/PlaylistService/PlaylistService.svc/Playlist/2a2458a0019/ios'

# Generated at 2022-06-26 12:18:45.285651
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE()._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-26 12:18:45.810472
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-26 12:18:48.802697
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE(ITVBTCCIE._downloader, 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:18:53.964671
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Unit test for constructor of class ITVBTCCIE
    """
    test_url = 'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:18:56.261982
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITB = ITVBTCCIE()
    ITB._match_id("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-26 12:18:56.862494
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie_ITVBTCCIE = ITVBTCCIE()

# Generated at 2022-06-26 12:18:57.896209
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.__name__ == 'ITVBTCCIE'

# Generated at 2022-06-26 12:18:58.388734
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()