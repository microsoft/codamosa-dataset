

# Generated at 2022-06-26 12:10:47.009090
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert 'ITVIE()'


# Generated at 2022-06-26 12:10:47.993271
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert test_case_0()

# Generated at 2022-06-26 12:10:51.619306
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Case 1:
    # test_case_0 is an ITVIE object
    assert type(test_case_0) == ITVIE


# Generated at 2022-06-26 12:10:53.000576
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert(ITVIE)


# Generated at 2022-06-26 12:11:03.440258
# Unit test for constructor of class ITVIE
def test_ITVIE():
    v_u_l_0 = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert v_u_l_0 == ITVIE._VALID_URL

# Generated at 2022-06-26 12:11:05.728256
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e = ITVBTCCIE()

# Generated at 2022-06-26 12:11:07.735058
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE() is not None


# Generated at 2022-06-26 12:11:13.273477
# Unit test for constructor of class ITVIE

# Generated at 2022-06-26 12:11:16.042414
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e = ITVBTCCIE()

# Generated at 2022-06-26 12:11:18.380677
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()

# Generated at 2022-06-26 12:11:38.830401
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test constructor of class ITVIE."""
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ie = ITVIE(url)
    assert ie.url_id == '2a4547a0012'
    assert ie.video_id == '2a4547a0012'

# Generated at 2022-06-26 12:11:50.656022
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from youtube_dl.downloader.common import FileDownloader
    JsonLdExtractorTest = type(
        'JsonLdExtractorTest', (unittest.TestCase,), dict(
            test_BTCC_URL='http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'))
    json_ld_test = JsonLdExtractorTest()
    json_ld_test.test_BTCC_URL = json_ld_test.test_BTCC_URL.replace('http://', 'https://')
    json_ld_test.test_BTCC_URL_2 = json_ld_test.test_BTCC

# Generated at 2022-06-26 12:12:03.382766
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Tests the constructor of class ITVBTCCIE. Based on the
    # constructor test of class ITVIE.
    #
    # Checks the class of ITVBTCCIE correctly returns the url
    # and permalink of a video. Also checks that the video is
    # a 'playlist', which means it is a collection of videos
    #
    # Args:
    #   url: the url of a video to test the constructor
    #   expectPlaylist: should return true if the video is
    #       a collection of multiple videos
    #   expectPermalink: the expected permalink of the video

    def test(url, expectPlaylist, expectPermalink):
        ie = ITVBTCCIE()
        result = ie.url_result(url)


# Generated at 2022-06-26 12:12:08.232482
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    c = ITVBTCCIE()
    assert c.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:12.787678
# Unit test for constructor of class ITVIE
def test_ITVIE():
    '''
    Simple test for ITVIE constructor
    :return:
    '''
    test_ITV = ITVIE()
    test_ITV._GET_TITLE = lambda x,y: "bbc"
    test_ITV._GET_DESCRIPTION = lambda x: "description"
    test_ITV._extract_duration = lambda x: "10"
    assert ITVIE._TESTS[0] == test_ITV._real_extract(ITVIE._TESTS[0]["url"])
    #  print(test_ITV._real_extract(test_ITV._TESTS[0]["url"]))

# Generated at 2022-06-26 12:12:13.987004
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'ITV'

# Generated at 2022-06-26 12:12:14.782340
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv

# Generated at 2022-06-26 12:12:22.369501
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    web_page = 'webpage'

# Generated at 2022-06-26 12:12:29.027462
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    entry = ITVBTCCIE()._real_extract(url)
    assert len(entry['entries']) == 9
    assert entry['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert entry['title'] == 'BTCC 2018: All the action from Brands Hatch'

# Generated at 2022-06-26 12:12:34.934558
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    videoID = ITVIE()._match_id(url)
    assert videoID == '2a4547a0012'


# Generated at 2022-06-26 12:13:05.597334
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:13:10.305746
# Unit test for constructor of class ITVIE
def test_ITVIE():
    global ITVIE
    ITVIE = ITVIE("http://www.itv.com/hub/jeremy-kyle/2a2447a0016")

# Generated at 2022-06-26 12:13:15.577384
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('http://www.itv.com/hub/liar/2a4547a0012')._TEST['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-26 12:13:21.889703
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITV = ITVIE()
    assert ITV._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-26 12:13:28.948946
# Unit test for constructor of class ITVIE
def test_ITVIE():

    # Test with valid url
    ITVIE.test(test_url="http://www.itv.com/hub/emmerdale/2a5159a0014")

    # Test with invalid url
    ITVIE.test(test_url="http://www.itv.com/hub/emmerdale")

    # Test with non-existing url
    ITVIE.test(test_url="http://www.itv.com/hub/emmerdale/1f43d34000")

# Generated at 2022-06-26 12:13:36.300511
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	playlist_id = 'playlist_id'
	entries = [
            'entry_1',
            'entry_2'
            ]

	# Test for assert
	#assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:13:39.026234
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test to see if the ITVBTCCIE class can be constructed."""
    ITVBTCCIE()

# Generated at 2022-06-26 12:13:49.957669
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test to see if the class is created succesfully
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE._download_webpage = lambda self, *args, **kargs: 'webpage'
    ITVIE._search_regex = lambda self, *args, **kargs: 'param'
    ITVIE._download_json = lambda self, *args, **kargs: 'ios_playlist'
    ITVIE._search_json_ld = lambda self, *args, **kargs: 'info'
    ITVIE._parse_json = lambda self, *args, **kargs: 'json_ld'
    ITVIE._extract_m3u8_formats = lambda self, *args, **kargs: 'formats'
    ITVIE._html_search_

# Generated at 2022-06-26 12:13:56.890184
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCC = ITVBTCCIE()
    video_id = "5790305903001"
    assert(ITVBTCC.BRIGHTCOVE_URL_TEMPLATE % video_id == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5790305903001")


# Generated at 2022-06-26 12:14:04.064688
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-26 12:15:06.720648
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-26 12:15:14.737786
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IE = ITVBTCCIE()
    assert IE.__name__ == "ITV BTCC"
    assert IE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert IE.ie_key() == 'ITVBTCC'
    assert IE.SUCCESS == 'SUCCESS'
    assert isinstance(IE.expected_warnings, list)
    assert IE._login_valid == True
    assert isinstance(IE._downloader, object)

# Generated at 2022-06-26 12:15:24.336056
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')._GEO_COUNTRIES == ['GB']
    assert ITVIE('https://www.itv.com/hub/through-the-keyhole/2a2271a0033')._TESTS[0]['url'] == 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033'

# Generated at 2022-06-26 12:15:29.921597
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Unit test for ITVBTCCIE

    This unit test checks expected behaviors when the ITVBTCCIE is
    constructed.
    """
    itvbtcc_ie = ITVBTCCIE()
    print(itvbtcc_ie)

# Generated at 2022-06-26 12:15:42.677852
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itvie._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert itvie._TESTS[0]['info_dict']['id'] == '2a4547a0012'
    assert itvie._TESTS[1]['url'] == 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033'

# Generated at 2022-06-26 12:15:47.300322
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:15:53.280254
# Unit test for constructor of class ITVIE
def test_ITVIE():
    video_id = '2a4547a0012'
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    actual_url = 'https://www.itv.com/service/player/' + video_id
    itv_ie = ITVIE()
    expected_url = itv_ie._download_webpage(url, video_id)
    assert actual_url == expected_url

# Generated at 2022-06-26 12:16:03.892084
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-26 12:16:04.893488
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-26 12:16:14.830772
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itvie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-26 12:18:52.398336
# Unit test for constructor of class ITVIE
def test_ITVIE():
    class_ = ITVIE('www.itv.com/hub/liar/2a4547a0012')
    assert class_.__name__ == 'ITVIE'
    assert class_.url == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert class_.valid_url == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert class_.valid_url == 'https://www.itv.com/hub/liar/2a4547a0012'



# Generated at 2022-06-26 12:18:53.117927
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(None)

# Generated at 2022-06-26 12:18:57.383844
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Test constructor of class ITVIE have an error."""
    from .brightcove import BrightcoveNewIE
    ITVIE._download_webpage = lambda *args, **kwargs: None
    ITVIE.BRIGHTCOVE_URL_TEMPLATE = ITVIE.BRIGHTCOVE_URL_TEMPLATE % \
        'b071e3ec-dc3a-4645-bea7-dfbecefd6f48'
    ITVIE._real_extract = \
        lambda *args, **kwargs: ITVIE.url_result(ITVIE.BRIGHTCOVE_URL_TEMPLATE,
        ie=BrightcoveNewIE.ie_key())
    iTVIE = ITVIE()
    assert type(iTVIE) == ITVIE

# Generated at 2022-06-26 12:18:58.719284
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-26 12:19:00.870824
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # unit test to create an object of class ITVIE
    _test_IE = ITVIE(ITVIE.name, {'geo_countries': ['GB']})
    assert hasattr(_test_IE, '_download_webpage')



# Generated at 2022-06-26 12:19:07.410130
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import os
    import json
    from .common import TOKEN_CMPT_VIDEO_ANNOTATION_KEY, TEST_DIR
    from .brightcove import BrightcoveNewIE
    from .youtube import YoutubeIE

    ITVExtractor = type(
        'ITVExtractor',
        (YoutubeIE, BrightcoveNewIE, ITVIE),
        dict(
            (k, v) for k, v in globals().items() if k.isupper()
            and k.endswith('_RE')
        )
    )

    test_cases = os.path.join(TEST_DIR, 'itv_tests.json')
    with open(test_cases) as f:
        tests = json.load(f)

    ie = ITVExtractor()
    for item in tests:
        ie._parse_

# Generated at 2022-06-26 12:19:11.200077
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_class = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    test_class.geo_verification_headers()
    test_class.geo_verification_headers() == test_class.geo_verification_headers() # tests that it is constant

# Generated at 2022-06-26 12:19:13.446076
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Simple test for constructor of class ITVBTCCIE
    # Test if it's not broken
    ITVBTCCIE('http://www.itv.com/btcc/races/brands-hatch-2018-race-one-report')

# Generated at 2022-06-26 12:19:19.341560
# Unit test for constructor of class ITVIE
def test_ITVIE():
	"""Tests for ITVIE"""
	test_urls = [
		'https://www.itv.com/hub/my-bonnie-baby/2a5208a0027',
		'http://www.itv.com/hub/penny-worth-episode-5-series-1/2a5209a0013',
		'http://www.itv.com/hub/live-from-space-with-steve-austin/series-1/2a5207a0022'
		]
	for url in test_urls:
		test_obj = ITVIE(url)
		test_obj.test()
	print ("passed")

# Generated at 2022-06-26 12:19:20.084872
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE().constructor()