

# Generated at 2022-06-26 12:10:46.741257
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-26 12:10:50.285982
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_instance = ITVIE()
    assert(test_instance._VALID_URL == ITVIE._VALID_URL)
    assert(test_instance._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES)
    assert(test_instance._TESTS == ITVIE._TESTS)


# Generated at 2022-06-26 12:10:59.936330
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()
    assert i_t_v_b_t_c_c_i_e_0._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    return i_t_v_b_t_c_c_i_e_0

# Generated at 2022-06-26 12:11:01.258814
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-26 12:11:06.030058
# Unit test for constructor of class ITVIE
def test_ITVIE():
    extractor = ITVIE()
    assert extractor.BRIGHTCOVE_URL_TEMPLATE == "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"

# Generated at 2022-06-26 12:11:09.712833
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e = ITVIE()
    assert i_t_v_i_e.geo_countries == []


# Generated at 2022-06-26 12:11:18.709105
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._VALID_URL == "https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)"

# Generated at 2022-06-26 12:11:19.526797
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass


# Generated at 2022-06-26 12:11:20.915598
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    r = ITVBTCCIE()


# Generated at 2022-06-26 12:11:23.197291
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e = ITVIE()


# Generated at 2022-06-26 12:11:41.091507
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # pylint: disable=protected-access
    ITVIE._GEO_COUNTRIES = ['GB']
    assert ITVIE._get_geo_country_codes() == ['GB']
    ITVIE._GEO_COUNTRIES = []
    assert ITVIE._get_geo_country_codes() == []

# Generated at 2022-06-26 12:11:45.211747
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    obj = ITVIE()
    obj.get_url(url)

# Generated at 2022-06-26 12:11:49.149743
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:02.619336
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Parameter test_playlist_type is either "single" or "playlist".
    It makes sure that each field is properly initialized.
    """
    test_id_prefix = "2a4547a"
    test_video_id = test_id_prefix + "0012"
    test_url = "https://www.itv.com/hub/liar/" + test_video_id
    video_ie = ITVIE(ITVIE._create_ie_instance())
    video_ie.extract(test_url)
    assert video_ie.url == test_url
    assert video_ie.video_id == test_video_id
    assert video_ie.ie_key() == "ITV"
    assert video_ie._VALID_URL == ITVIE._VALID_URL



# Generated at 2022-06-26 12:12:09.023497
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == ITVIE._VALID_URL
    assert ie._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert ie._TESTS == ITVIE._TESTS
    assert ie.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:12:13.136978
# Unit test for constructor of class ITVIE
def test_ITVIE():

    ITV = ITVIE()
    ITV_test = ITVIE()
    assert ITV_test.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:19.839235
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ie._TEST['info_dict'] == {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        }
    assert ie._TEST['playlist_mincount'] == 9

# Generated at 2022-06-26 12:12:20.642943
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-26 12:12:28.202024
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test that ITVBTCCIE constructor is valid with arguments
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(
        playlist_id=playlist_id,
        url=url,
    )

# Generated at 2022-06-26 12:12:31.595781
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(ITVBTCCIE._downloader, ITVBTCCIE._VALID_URL)

# Generated at 2022-06-26 12:12:57.863213
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE == type(ITVIE({}))

# Generated at 2022-06-26 12:12:59.440760
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-26 12:13:04.973521
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_obj = ITVIE()

    if test_obj.__class__.__name__:
        print(test_obj.__class__.__name__)

    if test_obj._VALID_URL:
        print(test_obj._VALID_URL)

# Generated at 2022-06-26 12:13:15.373514
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert not ie.is_suitable('http://www.itv.com/hub/liar/2a4547a0012')
    assert ie.is_suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ie.is_suitable('http://www.itv.com/btcc/races/all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:13:15.957676
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-26 12:13:23.608821
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    str1 = "http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5850399972001"
    str2 = "https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    str3 = "https://www.itv.com/btcc/thruxton-race-report-action-from-the-fastest-track-on-the-calendar"
    str4 = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    obj = ITVBTCCIE()
    assert (obj.BRIGHTCOVE_URL_TEMPLATE == str1)

# Generated at 2022-06-26 12:13:32.134467
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    ie.url = r'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert (ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s') == True

# Generated at 2022-06-26 12:13:34.029693
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.__name__ == 'ITVIE'


# Generated at 2022-06-26 12:13:36.826610
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:13:39.883175
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.ie_key() == 'ITV'



# Generated at 2022-06-26 12:14:47.923487
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # unit test for constructor of class ITVIE
    ie = ITVIE(None)

    # extract test
    # ITV should not be blocked in UK
    assert ie._is_blocked(ie._VALID_URL) == False

# Generated at 2022-06-26 12:14:50.635423
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-26 12:14:58.220510
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE(ITVIE())
    instance._downloader = Mock()
    assert not instance.suitable(None)
    assert instance.suitable('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')


# Generated at 2022-06-26 12:15:05.298718
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btccIE = ITVBTCCIE()
    assert btccIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert btccIE._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert btccIE._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert btccIE._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert btccIE._T

# Generated at 2022-06-26 12:15:14.173711
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

    assert info_extractor._VALID_URL == ITVBTCCIE._VALID_URL

    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

    assert info_extractor._TEST['url'] == ITVBTCCIE._TEST['url']

    assert info_extractor._TEST['info_dict'] == ITVBTCCIE._TEST['info_dict']

    assert info_extractor._TEST['playlist_mincount'] == ITVBTCCIE._TEST['playlist_mincount']

    assert info_extractor._real_

# Generated at 2022-06-26 12:15:22.727904
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE
    ex = IE('https://www.itv.com/hub/victoria/2a5015a0012','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','')
    ex._download_webpage('https://www.itv.com/hub/victoria/2a5015a0012', '2a5015a0012')
    ex._match_id('https://www.itv.com/hub/victoria/2a5015a0012')

# Generated at 2022-06-26 12:15:28.563300
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    url = 'http://www.itv.com/btcc/races/' + playlist_id
    assert ITVBTCCIE._match_id(url) == playlist_id

# Generated at 2022-06-26 12:15:32.403221
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE().suitable(url)
    assert ITVBTCCIE()._real_extract(url)['id'] == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-26 12:15:43.450525
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Check that the ITVIE constructor captures the ITV videos from the webpage
    info_dict = {
        "url": "https://www.itv.com/hub/liar/2a4547a0012",
        "info_dict": {
            "id": "2a4547a0012",
            "ext": "mp4",
            "title": "Liar - Series 2 - Episode 6",
            "description": "md5:d0f91536569dec79ea184f0a44cca089",
            "series": "Liar",
            "season_number": 2,
            "episode_number": 6,
        },
    }

    ydl = Youtubedl(info_dict)
    ydl.download('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-26 12:15:45.540404
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'ITV'

# Generated at 2022-06-26 12:17:01.092897
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    str_0 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    var_0 = ITVBTCCIE()
    str_1 = 'id'
    var_1 = ITVBTCCIE()
    var_2 = var_0._real_extract(str_0)[str_1]
    pass

if __name__ == '__main__':
    print(test_case_0())

# Generated at 2022-06-26 12:17:13.228738
# Unit test for constructor of class ITVIE
def test_ITVIE():
    str_0 = 'https://www.itv.com/hub/liar/2a4547a0012'
    i_t_v_i_e_0 = ITVIE()
    str_1 = 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033'
    i_t_v_i_e_1 = ITVIE()
    str_2 = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    i_t_v_i_e_2 = ITVIE()
    str_3 = 'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024'

# Generated at 2022-06-26 12:17:23.440737
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    str_0 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()
    str_1 = 'id'
    i_t_v_b_t_c_c_i_e_1 = ITVBTCCIE()
    str_2 = 'btcc-2018-all-the-action-from-brands-hatch'
    assert i_t_v_b_t_c_c_i_e_1._real_extract(str_0)[str_1] == str_2


# Generated at 2022-06-26 12:17:32.436129
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    str_0 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()
    str_1 = 'id'
    i_t_v_b_t_c_c_i_e_1 = ITVBTCCIE()
    var_0 = var_3._real_extract(str_0)[str_1]


# Generated at 2022-06-26 12:17:34.424664
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert 'id' in ITVBTCCIE()._real_extract(str_a)

# Generated at 2022-06-26 12:17:43.952071
# Unit test for constructor of class ITVIE
def test_ITVIE():
    str_0 = 'https://www.itv.com/hub/liar/2a4547a0012'
    i_t_v_i_e_0 = ITVIE()
    str_1 = 'id'
    i_t_v_i_e_1 = ITVIE()
    i_t_v_i_e_2 = ITVIE()
    i_t_v_i_e_3 = ITVIE()
    var_0 = i_t_v_i_e_2._real_extract(str_0)[str_1]

# Generated at 2022-06-26 12:17:46.631707
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    arg_1 = ITVBTCCIE()
    assert arg_1.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:17:52.488994
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    str_0 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()
    str_1 = 'id'
    i_t_v_b_t_c_c_i_e_1 = ITVBTCCIE()
    var_0 = var_3._real_extract(str_0)[str_1]


# Generated at 2022-06-26 12:17:59.219972
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    str_0 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()
    str_1 = 'id'
    i_t_v_b_t_c_c_i_e_1 = ITVBTCCIE()
    var_0 = var_3._real_extract(str_0)[str_1]


# Generated at 2022-06-26 12:18:00.861517
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert True == isinstance(var_3, ITVBTCCIE)


# Generated at 2022-06-26 12:20:07.835016
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass


# Generated at 2022-06-26 12:20:09.818855
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert test_case_0() == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-26 12:20:15.516194
# Unit test for constructor of class ITVIE
def test_ITVIE():
    str_0 = 'https://www.itv.com/hub/liar/2a4547a0012'
    i_t_v_i_e_0 = ITVIE()
    str_1 = 'id'
    i_t_v_i_e_1 = ITVIE()
    assert(i_t_v_i_e_1._real_extract(str_0)[str_1] == '2a4547a0012')


# Generated at 2022-06-26 12:20:19.567249
# Unit test for constructor of class ITVIE
def test_ITVIE():
    str_0 = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    u_r_l_i_e_0 = URLIE()
    str_1 = 'id'
    u_r_l_i_e_1 = URLIE()
    var_0 = var_3._real_extract(str_0)[str_1]


# Generated at 2022-06-26 12:20:20.211535
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()


# Generated at 2022-06-26 12:20:24.210551
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    str_0 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    i_t_v_b_t_c_c_i_e_1 = ITVBTCCIE()
    assert i_t_v_b_t_c_c_i_e_0._valid_url(str_0)

# Generated at 2022-06-26 12:20:25.114289
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert True

# Generated at 2022-06-26 12:20:32.530784
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    str_0 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()
    str_1 = 'id'
    i_t_v_b_t_c_c_i_e_1 = ITVBTCCIE()
    var_0 = var_7._match_id(str_0)
    str_2 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    i_t_v_b_t_c_c_i_e_2 = ITVBTCCIE()