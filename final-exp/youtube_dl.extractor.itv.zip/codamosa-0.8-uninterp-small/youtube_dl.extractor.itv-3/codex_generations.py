

# Generated at 2022-06-26 12:10:47.747002
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Construct an object of ITVIE
    i_t_v_i_e_0 = ITVIE()
    # Check if the i_t_v_i_e_0 object is an instance of ITVIE
    assert isinstance(i_t_v_i_e_0, ITVIE)


# Generated at 2022-06-26 12:10:52.170891
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

test_case_0()
test_ITVBTCCIE()

# Generated at 2022-06-26 12:10:55.143861
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    print(ITVBTCCIE().__doc__)
    assert ITVBTCCIE().__doc__

# Generated at 2022-06-26 12:10:57.079794
# Unit test for constructor of class ITVIE

# Generated at 2022-06-26 12:11:00.196674
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Check that ITVIE can be instantiated
    i_t_v_i_e = ITVIE()
    # Check that ITVIE has not failed
    assert i_t_v_i_e is not None


# Generated at 2022-06-26 12:11:02.006556
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e = ITVIE()


# Generated at 2022-06-26 12:11:03.758929
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test the case where the constructor succeeds
    assert(ITVIE())


# Generated at 2022-06-26 12:11:04.535959
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-26 12:11:06.880050
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_case_0()

# Generated at 2022-06-26 12:11:09.224799
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

# Generated at 2022-06-26 12:11:37.563942
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

# Generated at 2022-06-26 12:11:40.030439
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

# Generated at 2022-06-26 12:11:44.777010
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e = ITVBTCCIE()

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-26 12:11:49.519327
# Unit test for constructor of class ITVIE
def test_ITVIE():
    dummy_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    i_t_v_i_e_0 = ITVIE()
    i_t_v_i_e_0._real_extract(dummy_url)
    print('[UnitTest] Tested TestCase 0')


# Generated at 2022-06-26 12:11:50.590527
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor = ITVBTCCIE()
    constructor.URL_TEMPLATE

# Generated at 2022-06-26 12:11:53.481162
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

# Generated at 2022-06-26 12:11:54.993945
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.__doc__



# Generated at 2022-06-26 12:11:59.108013
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()
    assert ITVIE._VALID_URL
    assert ITVIE._GEO_COUNTRIES
    assert ITVIE._TESTS


# Generated at 2022-06-26 12:12:01.106896
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()


# Generated at 2022-06-26 12:12:01.765777
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie_0 = ITVBTCCIE();

# Generated at 2022-06-26 12:12:32.511218
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE(None)
    assert IE_DESC == ie.ie_key()
    assert ie._VALID_URL == ie.valid_url()


# Generated at 2022-06-26 12:12:37.495540
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    u = ITVBTCCIE(mock.Mock())
    assert u.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:43.898559
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(
        InfoExtractor()).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:47.542138
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        _test_ITVIE = ITVIE() # pylint:disable=assignment-from-no-return
    except Exception:
        _test_ITVIE = None
        pass

    if not _test_ITVIE:
        print("ITVIE - FAIL: Could not create object")

# Generated at 2022-06-26 12:12:56.354982
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert ITVBTCCIE._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._TEST['playlist_mincount'] == 9

# Generated at 2022-06-26 12:12:57.106900
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()

# Generated at 2022-06-26 12:13:01.121633
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._valid_url(ITVBTCCIE._VALID_URL, ITVBTCCIE._TEST['url'])

# Generated at 2022-06-26 12:13:05.861665
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    data = ITVIE()._real_extract(url)
    assert data['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'


# Generated at 2022-06-26 12:13:07.496496
# Unit test for constructor of class ITVIE
def test_ITVIE():
    constructor_test(ITVIE)


# Generated at 2022-06-26 12:13:19.235106
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	test_video_id = "5920190286001"
	test_url = ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % test_video_id
	ie = ITVBTCCIE()

	assert ie.suitable(test_url)

	expected_video_id = test_video_id
	result = ie._extract_url(test_url)
	assert result['id'] == expected_video_id

	assert ie.BRIGHTCOVE_URL_TEMPLATE.startswith('http')
	test_url = "https://"+ie.BRIGHTCOVE_URL_TEMPLATE[7:] % test_video_id
	result = ie._extract_url(test_url)
	assert result['id'] == expected_video_id

# Generated at 2022-06-26 12:14:24.892880
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE = ITVBTCCIE()
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:14:32.030226
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE
    assert info_extractor.__name__ == 'ITVBTCCIE'
    assert info_extractor._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-26 12:14:38.199994
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i = ITVBTCCIE()
    assert i.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:14:45.001700
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    t = ITVBTCCIE()
    t._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert t.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-26 12:14:47.637644
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(InfoExtractor())._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-26 12:14:53.414397
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Calling constructor
    itv = ITVIE()

    # Providing a valid URL
    #URL_valid = 'https://www.itv.com/hub/jeremy-kyle/2a2124a0072'
    URL_valid = 'https://www.itv.com/hub/coronation-street/1a8314'
    assert itv._real_extract(URL_valid)

    # Providing an invalid URL
    URL_invalid = 'https://www.itv.com/hub/jeremy-kyle/2a2124a0072'
    assert itv._real_extract(URL_invalid)


# Generated at 2022-06-26 12:14:59.711768
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    assert ITVBTCCIE()._match_id(url) == "btcc-2018-all-the-action-from-brands-hatch"

# Generated at 2022-06-26 12:15:08.179481
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE(ITVBTCCIE.create_ie(), url)
    instance = ITVBTCCIE(ie, url)

    assert instance is not None
    assert instance.ie == ie
    assert instance.url == url

# Generated at 2022-06-26 12:15:08.522888
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-26 12:15:10.044425
# Unit test for constructor of class ITVIE
def test_ITVIE():
    r = ITVIE(None)
    assert r._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-26 12:17:39.043613
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-26 12:17:40.077749
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_verification_headers() == {'Host': 'geo.itv.com'}

# Generated at 2022-06-26 12:17:47.407967
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert instance._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:17:49.972495
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_cases = ['itv.com', 'www.itv.com', 'www.itv.com/hub/', 'hub.itv.com']
    for url in test_cases:
        assert ITVIE(url)._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-26 12:17:52.590251
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor_ITV = ITVIE()
    assert isinstance(info_extractor_ITV, ITVIE)


# Generated at 2022-06-26 12:17:53.746994
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert list(ITVBTCCIE.IE_KEY) == ['brightcoveNew']

# Generated at 2022-06-26 12:17:54.316213
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(object)

# Generated at 2022-06-26 12:17:59.932343
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert itv._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itv._GEO_COUNTRIES == ['GB']


# Generated at 2022-06-26 12:18:02.440453
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:18:06.833294
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    testurl = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    btccie = ITVBTCCIE()
    assert btccie._match_id(testurl) == "btcc-2018-all-the-action-from-brands-hatch"