

# Generated at 2022-06-26 12:10:47.049316
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE()
    assert isinstance(obj, ITVIE)


# Generated at 2022-06-26 12:10:48.032951
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE("")


# Generated at 2022-06-26 12:10:52.721050
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print("""
    Args:
        None
    Returns:
        instance of ITVIE
    Raises:
        None
    """)
    i_t_v_i_e_0 = ITVIE()


# Generated at 2022-06-26 12:10:55.737057
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e = ITVBTCCIE()

# Generated at 2022-06-26 12:10:58.817779
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Create a new instance of class ITVBTCCIE
    i_t_v_b_t_c_c_i_e = ITVBTCCIE()


# Generated at 2022-06-26 12:11:02.618249
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_1 = ITVIE(i_t_v_i_e_0)
    assert isinstance(i_t_v_i_e_1, ITVIE)


# Generated at 2022-06-26 12:11:04.405714
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert isinstance(instance, ITVBTCCIE)

# Generated at 2022-06-26 12:11:11.504108
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    site = 'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    title = 'BTCC 2018: All the action from Brands Hatch'
    assert ITVBTCCIE.parse_url(site) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE.parse_title(site) == title

# Generated at 2022-06-26 12:11:13.458174
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print('Testing constructor of class ITVIE...')
    assert ITVIE()
    print('Done!')


# Generated at 2022-06-26 12:11:21.761429
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE()._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-26 12:11:47.667172
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Check type of object
    assert type(i_t_v_i_e_0) == ITVIE


# Generated at 2022-06-26 12:11:50.922966
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print("Unit test for constructor of ITVIE.")
    i_t_v_i_e_0 = ITVIE()


# Generated at 2022-06-26 12:11:56.406757
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

if __name__ == '__main__':
    test_case_0()
    test_ITVBTCCIE()

# Generated at 2022-06-26 12:12:05.953084
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():

    test_url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    extracted_info = {
        'id':'btcc-2018-all-the-action-from-brands-hatch',
        'title':'BTCC 2018: All the action from Brands Hatch'
    }
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

    info = i_t_v_b_t_c_c_i_e_0._real_extract(test_url)

    assert(info['id'] == extracted_info['id'])
    assert(info['title'] == extracted_info['title'])

# Generated at 2022-06-26 12:12:16.205218
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert (ITVBTCCIE._VALID_URL == 'https?://(?:www\\.)?itv\\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)')
    assert (ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')
    # TODO: check _TEST
    assert (ITVBTCCIE._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:12:28.906232
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    info_dict = {
            'id': '2a4547a0012',
            'ext': 'mp4',
            'title': 'Liar - Series 2 - Episode 6',
            'description': 'md5:d0f91536569dec79ea184f0a44cca089',
            'series': 'Liar',
            'season_number': 2,
            'episode_number': 6,
    }
    # m3u8 download
    SkipDownload = True
    params = {
        'skip_download': SkipDownload
    }

# Generated at 2022-06-26 12:12:31.806495
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()

# Generated at 2022-06-26 12:12:37.141689
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert isinstance(ITVIE()._VALID_URL, str)
    assert isinstance(ITVIE()._TESTS, list)
    assert isinstance(ITVIE()._GEO_COUNTRIES, list)

# Test function _real_extract

# Generated at 2022-06-26 12:12:49.708094
# Unit test for constructor of class ITVIE

# Generated at 2022-06-26 12:12:51.554221
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert('ITVIE' == ITVIE.__name__)


# Generated at 2022-06-26 12:13:18.509929
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    assert obj.__class__.__name__ == ITVIE.__name__

# Generated at 2022-06-26 12:13:23.458612
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    webpage = '<html><body><div data-video-id="test"></div></body></html>'
    playlist = ITVBTCCIE()._real_extract(url)
    entries = playlist['entries']
    asser

# Generated at 2022-06-26 12:13:28.912394
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itv.IE_NAME == 'itv'
    assert itv.IE_DESC == 'ITV Player and ITV Hub'

# Generated at 2022-06-26 12:13:38.796295
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Define a fake youtube page and test if class ITVBTCCIE can parse it properly."""


# Generated at 2022-06-26 12:13:44.474415
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = ITVIE('ITVIE')._get_url_from_vid('2a4547a0012')
    assert url == 'https://www.itv.com/hub/liar/2a4547a0012'


# Generated at 2022-06-26 12:13:45.867618
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    parser = ITVBTCCIE()
    assert parser

# Generated at 2022-06-26 12:13:48.036746
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE().url_result(url)

# Generated at 2022-06-26 12:13:52.199290
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')

# Generated at 2022-06-26 12:13:55.958355
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Create an instance of ITVIE
    itv = ITVIE()

    # Check that it is an instance of InfoExtractor
    assert(isinstance(itv, ITVIE))



# Generated at 2022-06-26 12:13:56.811810
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(InfoExtractor())._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-26 12:15:03.175189
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-26 12:15:09.401736
# Unit test for constructor of class ITVIE
def test_ITVIE():
    expected_instance = ITVIE(
        "https://www.itv.com/hub/liar/2a4547a0012")
    assert expected_instance.url == "https://www.itv.com/hub/liar/2a4547a0012"
    assert expected_instance.video_id == '2a4547a0012'

# Generated at 2022-06-26 12:15:22.782608
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-26 12:15:28.628988
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE._VALID_URL == ITVIE.valid_url(url)
    test = ITVIE.suitable(url)
    assert test is not False


# Generated at 2022-06-26 12:15:31.816755
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.__name__ == 'ITV'
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-26 12:15:39.021794
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:15:41.965116
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert("2a4547a0012" == i.id)


# Generated at 2022-06-26 12:15:51.818580
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    ITVIE('http://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    ITVIE('http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    ITVIE('http://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024')

# Generated at 2022-06-26 12:15:59.306027
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    object = ITVBTCCIE(url, 'test_ITVBTCCIE', False)
    print(object.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-26 12:16:03.184766
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    unit = ITVBTCCIE()
    assert unit.BRIGHTCOVE_URL_TEMPLATE
    assert unit.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:18:42.305834
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-26 12:18:50.312177
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()

    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    webpage = '<meta property="og:title" content="Liar - Series 2 - Episode 6">'
    assert ie._download_webpage(url, video_id, note='Download webpage') == webpage

    ios_playlist_url = 'https://www.itv.com/itvplayer/video/2a4547a0012?ContentId=2a4547a0012'
    hmac = 'rz7Vu5PS/0Cm8YmUj4LfCW+6U4WsbX9A6gB+lzcn0ZU='
    headers = ie.geo_verification_

# Generated at 2022-06-26 12:18:52.207507
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._download_webpage('https://www.itv.com/hub/liar/2a4547a0012', 'test_id')

test_ITVIE()

# Generated at 2022-06-26 12:18:54.591181
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print("Testing constructor of ITVIE")
    ITVIE('https://www.itv.com/hub/kiss-chase/2a4547a0012')._real_extract(
        'https://www.itv.com/hub/kiss-chase/2a4547a0012'
    )

# Generated at 2022-06-26 12:18:56.778343
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:19:03.267140
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test test_url in class ITVBTCCIE
    # Input:
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    # Expected output:
    expected = {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'playlist_mincount': 9,
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        }
    }

    # Actual output:

# Generated at 2022-06-26 12:19:04.502371
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    unit_test = ITVBTCCIE()
    unit_test._assert_true(True)

# Generated at 2022-06-26 12:19:06.897771
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = 'https://www.itv.com/hub/james-martins-saturday-morning/2a2898a0025'
    assert ITVIE()._match_id(test_url) == '2a2898a0025'

# Generated at 2022-06-26 12:19:13.340277
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    itvIE = ITVIE()
    assert itvIE._VALID_URL == ITVIE._VALID_URL
    assert itvIE._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES
    assert itvIE._TESTS == ITVIE._TESTS
    assert itvIE.BRIGHTCOVE_URL_TEMPLATE is None
    assert itvIE._match_id(url) == '2a4547a0012'
    assert itvIE._real_extract(url)



# Generated at 2022-06-26 12:19:15.927613
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    p = ITVBTCCIE()

    assert p.geo_verification_headers() == {'Accept-Language': 'en-GB;q=0.9,en;q=0.8'}