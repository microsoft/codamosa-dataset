

# Generated at 2022-06-26 12:10:51.943421
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Test the functionality of ITVIE extractor class.
    """
    t_u_p_l_e_0 = 'https://www.itv.com/hub/liar/2a4547a0012'
    i_t_v_i_e_0 = ITVIE()
    assert i_t_v_i_e_0._match_id(t_u_p_l_e_0)
    assert i_t_v_i_e_0._match_id('https://www.itv.com/hub/liar/2a4547a0012') == '2a4547a0012'

# Generated at 2022-06-26 12:11:03.017676
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    if TEST == "unit":
        if __name__ == "__main__":
            arg_parser = argparse.ArgumentParser(
                description='Check that a class constructor works.'
            )
            arg_parser.add_argument('--clazz', help='Class name', required=True)
            arg_parser.add_argument('method', help='Method name')
            arg_parser.add_argument('args', nargs=argparse.REMAINDER,
                help='Arguments to method')
            args = arg_parser.parse_args()
            clazz = eval(args.clazz)
            method = eval('clazz.%s' % args.method)
            method(*args.args)
            print('%s.%s executed' % (args.clazz, args.method))


# Generated at 2022-06-26 12:11:09.082421
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_0 = ITVIE(ITVBTCCIE, ITVBTCCIE.ie_key(), ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE, ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE, ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE)


# Generated at 2022-06-26 12:11:19.396436
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    t_v_b_t_c_c_i_e = ITVBTCCIE()
    assert t_v_b_t_c_c_i_e._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:11:20.776771
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()


# Generated at 2022-06-26 12:11:21.628048
# Unit test for constructor of class ITVIE
def test_ITVIE():
    t = ITVIE()

# Generated at 2022-06-26 12:11:23.948178
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_ = ITVIE()

# Generated at 2022-06-26 12:11:24.868520
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert isinstance(i_t_v_b_t_c_c_i_e_0, ITVBTCCIE)


# Generated at 2022-06-26 12:11:25.997402
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert 'ITVBTCCIE'


# Generated at 2022-06-26 12:11:27.118876
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_0 = ITVIE()


# Generated at 2022-06-26 12:11:43.767996
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(None).url_result(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % '5674039172001')

# Generated at 2022-06-26 12:11:46.389920
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("http://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-26 12:11:49.778348
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    except:
        assert Exception

# Generated at 2022-06-26 12:11:54.078672
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(
        "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

# Generated at 2022-06-26 12:11:59.358583
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-26 12:12:07.634401
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert(ITVBTCCIE._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')=='btcc-2018-all-the-action-from-brands-hatch')
    assert(ITVBTCCIE._match_id('http://www.itv.com/btcc/2018/races/btcc-2018-all-the-action-from-brands-hatch')=='btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:12:11.609990
# Unit test for constructor of class ITVIE
def test_ITVIE():
    cls = ITVIE
    inst = cls()
    assert inst.BRIGHTCOVE_URL_TEMPLATE == ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:12:13.873030
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    print(ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE)



# Generated at 2022-06-26 12:12:21.769479
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:12:26.217912
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    if not ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE:
        assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE != None

# Generated at 2022-06-26 12:12:58.731987
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():

    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    web_page = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    data_video_ids = re.findall(r'data-video-id=["\'](\d+)', web_page)
    videos_count = len(data_video_ids)

    playlist = ITVBTCCIE._real_extract(ITVBTCCIE(), url)

    assert len(playlist['entries']) == videos_count
    assert playlist['id'] == playlist_

# Generated at 2022-06-26 12:13:04.377491
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:13:07.594039
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Check that it doesn't expect to load anything.
    try:
        ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    except NameError:
        assert False, 'Test for ITVIE failed'

# Generated at 2022-06-26 12:13:18.995030
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test assertion of ITVBTCCIE
    with ITVBTCCIE() as ie:
        assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
        assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
        assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:13:27.360641
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_URL_TEMPLATE != 'http://players.brightcove.net/xxxxxxxxxxxxx/xxxxxxxxxxxxx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:13:38.150016
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvbtccie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-26 12:13:42.258605
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE().get_info(ITVBTCCIE()._TEST['url'],
                         ITVBTCCIE()._TEST['info_dict'])

# Generated at 2022-06-26 12:13:44.825655
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE()

# Generated at 2022-06-26 12:13:47.815259
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:13:52.482463
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') is not None

# Generated at 2022-06-26 12:15:04.197472
# Unit test for constructor of class ITVIE
def test_ITVIE():
    print ("Testing ITVIE")
    print ("----------------------------------------")
    ITVIE_class = ITVIE()
    ITVIE_class._sort_formats([{'url': 'http://www.itv.com/hub/liar/2a4547a0012',
                                'info_dict': {'Title': 'Liar - Series 2 - Episode 6'}},
                               {'url': 'http://www.itv.com/hub/liar/2a4547a0011'},
                               {'url': 'http://www.itv.com/hub/liar/2a4547a0010'},
                               {'url': 'http://www.itv.com/hub/liar/2a4547a0009'}])

# Generated at 2022-06-26 12:15:05.556258
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:15:07.581868
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:15:10.753825
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    testurl = r'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(None).construct_url(testurl)

# Generated at 2022-06-26 12:15:19.715860
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    YDStreamExtractor.info_extractors[ITVBTCCIE.ie_key()] = ITVBTCCIE
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')._VALID_URL == r'http://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*([^/?#&]+)'

# Generated at 2022-06-26 12:15:21.279474
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-26 12:15:32.555355
# Unit test for constructor of class ITVIE
def test_ITVIE():
    extraction_test = ITVIE()
    extraction_test._VALID_URL = ITVIE._VALID_URL
    extraction_test._TESTS[_TESTS.index(x)]['url'] = ITVIE._TESTS[_TESTS.index(x)]['url']
    extraction_test._TESTS[_TESTS.index(x)]['info_dict']['id'] = ITVIE._TESTS[_TESTS.index(x)]['info_dict']['id']
    extraction_test._TESTS[_TESTS.index(x)]['info_dict']['title'] = ITVIE._TESTS[_TESTS.index(x)]['info_dict']['title']

# Generated at 2022-06-26 12:15:38.060868
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()._VALID_URL == ITVBTCCIE._VALID_URL
test_ITVBTCCIE.test = [
    (test_ITVBTCCIE, ITVBTCCIE)
]


# Generated at 2022-06-26 12:15:44.973700
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    _test = ITVBTCCIE()
    assert _test._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert _test._TEST == {'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'info_dict': {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}, 'playlist_mincount': 9}

# Generated at 2022-06-26 12:15:47.861424
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from . import BBCCoUkIE
    BBCCoUkIE("http", "www.itv.com")

# Generated at 2022-06-26 12:18:26.807819
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .brightcove import BrightcoveNewIE
    testurl = 'https://www.itv.com/hub/liar/2a4547a0012'
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    i = ITVIE(BrightcoveNewIE())
    # Test ITVIE.__init__
    assert isinstance(i, ITVIE)
    # Test ITVIE._real_extract
    # Check the method type
    assert callable(ITVIE._real_extract)
    # Check the return type
    assert isinstance(i._real_extract(testurl), dict)
    # Check structure of return dictionary
    assert "id" in i._real_extract(testurl)

# Generated at 2022-06-26 12:18:30.693220
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    result = ITVBTCCIE()._real_extract(url)
    assert result["id"] == "btcc-2018-all-the-action-from-brands-hatch"
    assert result["title"] == "BTCC 2018: All the action from Brands Hatch"

# Generated at 2022-06-26 12:18:31.816878
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor=ITVIE()

# Generated at 2022-06-26 12:18:33.164331
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE()
    assert isinstance(result, ITVBTCCIE)

# Generated at 2022-06-26 12:18:38.636981
# Unit test for constructor of class ITVIE
def test_ITVIE():
    yie = ITVIE()
    assert yie.__name__ == "ITVIE"
    assert ITVIE.__name__ == "ITVIE" 
    assert yie.BROWSER == "Safari"
    assert yie.VERSION == "5"
    assert yie.OS == "Windows NT"
    assert yie.OS_VERSION == "6.1"
    assert yie.DEVICE_TYPE == "desktop"

# Generated at 2022-06-26 12:18:42.067167
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE({})
    assert itv_ie.ie_key() == 'ITV'

# Generated at 2022-06-26 12:18:44.164546
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._real_extract("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-26 12:18:48.701974
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Test constructor for ITVBTCCIE.
    """
    # use any non-empty string as the id
    id = "btcc-2018-all-the-action-from-brands-hatch"
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ITVBTCCIE(url, id)

# Generated at 2022-06-26 12:18:55.037942
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvbtccie = ITVBTCCIE()
    itvbtccie._download_webpage = lambda url: '<html></html>'
    itvbtccie._download_json = lambda url, video_id, note, errnote: {
    }
    itvbtccie._real_extract(url)
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:19:01.296587
# Unit test for constructor of class ITVBTCCIE