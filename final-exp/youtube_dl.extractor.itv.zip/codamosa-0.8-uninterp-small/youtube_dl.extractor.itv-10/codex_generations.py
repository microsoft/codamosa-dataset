

# Generated at 2022-06-26 12:10:46.412706
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e = ITVIE()

# Generated at 2022-06-26 12:10:48.944117
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'


# Generated at 2022-06-26 12:10:51.827750
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e = ITVBTCCIE()

# Generated at 2022-06-26 12:10:54.062911
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert i_t_v_i_e_0._downloader is not None

# Generated at 2022-06-26 12:11:02.726905
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    info_dict = {
        'id': '2a4547a0012',
        'ext': 'mp4',
        'title': 'Liar - Series 2 - Episode 6',
        'description': 'md5:d0f91536569dec79ea184f0a44cca089',
        'series': 'Liar',
        'season_number': 2,
        'episode_number': 6,
    }
    params = {
        # m3u8 download
        'skip_download': True,
    }

# Generated at 2022-06-26 12:11:04.528631
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = ITVBTCCIE._TEST['url']
    ITVBTCCIE(url)

# Generated at 2022-06-26 12:11:07.416813
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e = ITVIE()



# Generated at 2022-06-26 12:11:08.740600
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert (ITVBTCCIE() is not None)

# Generated at 2022-06-26 12:11:09.804601
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()


# Generated at 2022-06-26 12:11:11.662983
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Constructor of ITVIE
    i_t_v_i_e = ITVIE()


# Generated at 2022-06-26 12:11:26.938174
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    assert test._download_json, "_download_json method is not implemented"


# Generated at 2022-06-26 12:11:28.278676
# Unit test for constructor of class ITVIE
def test_ITVIE():
	assert ITVIE.__name__ == 'ITVIE'

# Generated at 2022-06-26 12:11:41.753547
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itv = ITVBTCCIE()
    assert itv._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itv._TEST['url'] == url
    assert itv._TEST['info_dict'] == {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}
    assert itv._TEST['playlist_mincount'] == 9
    assert itv.BRIGHTCOVE_URL_TEMPL

# Generated at 2022-06-26 12:11:51.531546
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = ITVBTCCIE()._VALID_URL
    p = re.compile(url)
    assert p.match('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert p.match('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert not p.match('https://www.itv.com/btcc/races/btcc2018-all-the-action-from-brands-hatch')
    assert not p.match('https://www.itv.com/btcc/races/btcc-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:12:03.962108
# Unit test for constructor of class ITVIE

# Generated at 2022-06-26 12:12:14.746488
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():

    # Test constructor of class ITVBTCCIE
    # Test 1: arguments are valid (playlist_id, url)
    assert ITVBTCCIE('btcc-2018-all-the-action-from-brands-hatch', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

    # Test 2: arguments are invalid - playlist_id is missing
    try:
        ITVBTCCIE('', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    except AssertionError:
        pass

    # Test 3: arguments are invalid - url is missing

# Generated at 2022-06-26 12:12:16.993937
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    name = "ITVBTCCIE"
    obj = ITVBTCCIE()
    assert obj.name == name

# Generated at 2022-06-26 12:12:20.502657
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVBTCCIE.IE_NAME, ITVBTCCIE.IE_KEY)()._VALID_URL == ITVBTCCIE._VALID_URL

# Generated at 2022-06-26 12:12:24.174091
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():  # noqa
    from .test_youtube import YoutubeIE
    assert BrightcoveNewIE.ie_key() == YoutubeIE.ie_key()

# Generated at 2022-06-26 12:12:28.273788
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('')
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:55.086574
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:55.551923
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-26 12:13:02.864152
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.IE_NAME == 'itv:btcc'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:13:11.859328
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    This is a test for the constructor of the class ITVIE, which utilises
    the test data in the _TESTS field.

    Returns:
        A dictionary containing, among other things, the title and description
        of each video.
    """
    ie = ITVIE()
    downloaded = ie.download_json('http://itv.com/ITVPlayer/video/')
    json_body = downloaded['body']
    json_dict = json.loads(json_body.decode('utf-8'))
    data = json_dict['data']
    results = {}

    for playlist in data:
        pid = playlist['pid']
        weburl = playlist['weburl']
        title = playlist['title']
        description = playlist['desc']
        url = 'http://www.itv.com/hub/' + pid

# Generated at 2022-06-26 12:13:17.646526
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE.IE_NAME in ITVBTCCIE.suitable(url)
    assert ITVBTCCIE.IE_NAME not in ITVBTCCIE.suitable('http://www.youtube.com')

# Generated at 2022-06-26 12:13:20.225692
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # get the test object using the constructor
    obj = ITVBTCCIE()
    assert obj is not None

# Generated at 2022-06-26 12:13:22.633659
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-26 12:13:29.054737
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url='https://www.itv.com/hub/liar/2a4547a0012'
    itvie=ITVIE()
    itvie.countries=["GB"]
    itvie._downloader=None
    itvie._match_id(test_url)
    assert itvie._match_id(test_url) == "2a4547a0012"


# Generated at 2022-06-26 12:13:31.074577
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['url'] == ITVBTCCIE._VALID_URL

# Generated at 2022-06-26 12:13:38.961479
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_info_dict = {
        'id': 'btcc-2018-all-the-action-from-brands-hatch',
        'title': 'BTCC 2018: All the action from Brands Hatch',
    }
    result = ie.extract(url)
    assert test_info_dict.get('id') == result.get('id')
    assert test_info_dict.get('title') == result.get('title')
    assert (9) == len(result.get('entries'))

# Generated at 2022-06-26 12:14:48.346112
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    test_obj = ITVBTCCIE()

    # Test for "constructor" of class ITVBTCCIE
    assert test_obj._constructor_test(test_url)

    ## Test for "extract" of class ITVBTCCIE
    entries = test_obj.extract(test_url)

    # Test for playlist_count
    entries_count = len(entries)
    playlist_count = 9
    assert entries_count == playlist_count

# Generated at 2022-06-26 12:14:53.683956
# Unit test for constructor of class ITVIE
def test_ITVIE():
    TEST_VIDEO_ID = '2a4547a0012'
    TEST_VIDEO_URL = 'https://www.itv.com/hub/liar/2a4547a0012'

    # Check sane path of video download
    video_info = ITVIE()._real_extract(TEST_VIDEO_URL)
    assert video_info['id'] == TEST_VIDEO_ID
    assert video_info['title'] is not None
    assert video_info['description'] is not None

    # Check metadata extract from JSON-LD
    assert 'series' in video_info
    assert 'season_number' in video_info
    assert 'episode_number' in video_info

# Generated at 2022-06-26 12:14:57.189601
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from .itv import ITVIE
    assert "ITVIE" == ITVIE.ie_key()

# Generated at 2022-06-26 12:14:59.609217
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')


# Generated at 2022-06-26 12:15:09.077540
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    # test ITVIE instance implements _real_extract method
    assert getattr(itv_ie, '_real_extract', None)
    # test ITVIE instance implements _real_extract method
    assert getattr(itv_ie, '_real_extract', None)
    # test ITVIE instance implements _real_extract method
    assert getattr(itv_ie, '_real_extract', None)

# Generated at 2022-06-26 12:15:22.782040
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    btcc = ITVBTCCIE()
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert btcc.suitable(url)
    assert btcc.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert btcc.ie_key() == 'brightcove:new'
    assert btcc._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:15:29.921061
# Unit test for constructor of class ITVIE
def test_ITVIE():
    _valid_url = ITVIE._VALID_URL
    ITVIE._VALID_URL = 'http://www.itv.com/hub/[^/]+/(?P<id>[^/]+)/(?P<path>.*)'
    ITVIE(InfoExtractor())._test_file()
    ITVIE._VALID_URL = _valid_url

# Generated at 2022-06-26 12:15:31.112874
# Unit test for constructor of class ITVIE
def test_ITVIE():
    dl = ITVIE()
    assert dl is not None


# Generated at 2022-06-26 12:15:35.427009
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(
        ITVIE._downloader).ie_key() == 'itv:player:vod'

# Generated at 2022-06-26 12:15:37.925566
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(ITVEmbedIE())._VALID_URL == ITVEmbedIE._VALID_URL

# Generated at 2022-06-26 12:18:12.530366
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    t = ITVBTCCIE()
    t.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-26 12:18:14.647105
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE("www.itv.com/hub/liar/2a4547a0012")
    assert ie.url == "https://www.itv.com/hub/liar/2a4547a0012"
    assert ie.video_id == "2a4547a0012"


# Generated at 2022-06-26 12:18:17.887234
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test constructor class ITVBTCCIE"""
    btcc_ie = ITVBTCCIE()
    btcc_ie.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:18:27.716101
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    expected_result = 'https://link.theplatform.com/s/igL2VC/media/guid/2409718587/1522448375168?mbr=true'

# Generated at 2022-06-26 12:18:33.357104
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Check that each valid URL's video_id is the same as what's in its URL.
    valid_urls = [
        'http://www.itv.com/btcc/races/brands-hatch-2018-day-one-as-it-happened',
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-silverstone-day-two',
    ]
    for url in valid_urls:
        playlist_id = ITVBTCCIE._match_id(url)
        assert(playlist_id == ITVBTCCIE(url)._id)

# Generated at 2022-06-26 12:18:35.230415
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()._real_extract(r'https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-26 12:18:46.252096
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    _, id = ITVBTCCIE._extract_url(url)
    url_result = ITVBTCCIE.url_result(
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5785176723001',
        ie=BrightcoveNewIE.ie_key(), video_id='5785176723001')
    playlist_result = ITVBTCCIE.playlist_result(
        [url_result], id, 'BTCC 2018: All the action from Brands Hatch')
    ie = ITVBTCCIE()
    assert ie._match_id(url) == id


# Generated at 2022-06-26 12:18:48.470517
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # regular
    instance = ITVIE(None)
    # with GeoRestriction
    instance = ITVIE(None, 'GB')

# Generated at 2022-06-26 12:18:49.190119
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._downloader is not None

# Generated at 2022-06-26 12:18:51.409117
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test constructing class ITVBTCCIE"""
    c = ITVBTCCIE()
    assert c.name == 'ITVBTCCIE'