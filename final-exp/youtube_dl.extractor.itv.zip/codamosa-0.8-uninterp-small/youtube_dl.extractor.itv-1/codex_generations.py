

# Generated at 2022-06-26 12:10:48.661624
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

# Generated at 2022-06-26 12:10:50.362653
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()

# Generated at 2022-06-26 12:10:51.414383
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-26 12:11:02.806510
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL is "https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)"
    assert ITVIE._GEO_COUNTRIES is ['GB']

# Generated at 2022-06-26 12:11:04.081805
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie_0 = ITVBTCCIE()

# Generated at 2022-06-26 12:11:05.570078
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert i_t_v_i_e_0 is not None


# Generated at 2022-06-26 12:11:08.092826
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert i_t_v_i_e_0 != None


# Generated at 2022-06-26 12:11:09.805387
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert(callable(ITVIE))


# Generated at 2022-06-26 12:11:11.662816
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e = ITVBTCCIE()

# Generated at 2022-06-26 12:11:12.901236
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert test_case_0



# Generated at 2022-06-26 12:11:27.702682
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE({})

# Generated at 2022-06-26 12:11:29.567014
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE is not None

# Generated at 2022-06-26 12:11:33.533887
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from . import ExtractorError
    with ExtractorError.raise_on(2):  # raises on warning
        ITVBTCCIE()

# Generated at 2022-06-26 12:11:36.871493
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-26 12:11:38.784983
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-26 12:11:42.119314
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVBTCCIE()
    assert IE.itag_id_map == {}
    assert IE.format_id == 'Hls'

# Generated at 2022-06-26 12:11:51.226345
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_itv = ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    assert test_itv.params == {'id': 'video'}
    assert test_itv.video_id == "2a4547a0012"
    assert test_itv.url == "https://www.itv.com/hub/liar/2a4547a0012"
    assert test_itv._TEST == ITVIE._TEST
    assert test_itv._VALID_URL == ITVIE._VALID_URL
    assert test_itv._GEO_COUNTRIES == ITVIE._GEO_COUNTRIES



# Generated at 2022-06-26 12:11:57.783776
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:12:03.420036
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itv_ie._TEST[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
# End unit test

# Generated at 2022-06-26 12:12:06.774450
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()

    assert ie._VALID_URL, "ITVIE._VALID_URL is empty"
    assert ie._GEO_COUNTRIES, "ITVIE._GEO_COUNTRIES is empty"
    assert ie._TESTS, "ITVIE._TESTS is empty"

# Generated at 2022-06-26 12:12:39.420630
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class TestITVBTCCIE(ITVBTCCIE):
        def _download_webpage(self, *args, **kwargs):
            return kwargs['url']
    instance = TestITVBTCCIE()
    assert instance._download_webpage('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch').startswith('http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=')

# Generated at 2022-06-26 12:12:49.737312
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.IE_NAME == 'itv:btcc'
    assert ie.IE_DESC == 'ITV BTCC'
    assert ie.VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie.BRIGHTCOVE_USER_ID == '1582188683001'

# Generated at 2022-06-26 12:12:52.593149
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')
    assert(ie.ie_key() == 'BrightcoveNew')

# Generated at 2022-06-26 12:12:57.739538
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE().construct_format_request(
        {"id":"2a4547a0012", "ext":"mp4", "title":"Liar - Series 2 - Episode 6",
        "description":"md5:d0f91536569dec79ea184f0a44cca089", "series":"Liar",
        "season_number":2, "episode_number":6},
        ["2a4547a0012"], {"skip_download":True})

# Generated at 2022-06-26 12:12:58.766691
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-26 12:13:09.851531
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL.match('https://www.itv.com/hub/liar/2a4547a0012') is not None
    assert ITVIE._VALID_URL.match('https://www.itv.com/hub/through-the-keyhole/2a2271a0033') is not None
    assert ITVIE._VALID_URL.match('https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034') is not None
    assert ITVIE._VALID_URL.match('https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024') is not None

# Generated at 2022-06-26 12:13:12.365542
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:13:16.003240
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:13:22.568661
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert ie.get_id() == "2a4547a0012"
    assert ie.get_title() == "Liar - Series 2 - Episode 6"

# Generated at 2022-06-26 12:13:28.167543
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE(ITVIE._downloader)._VALID_URL == ITVIE._VALID_URL
    assert ITVIE(ITVIE._downloader).BRIGHTCOVE_URL_TEMPLATE == ITVIE.BRIGHTCOVE_URL_TEMPLATE
    assert ITVIE(ITVIE._downloader)._TESTS

# Generated at 2022-06-26 12:14:35.185099
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-26 12:14:36.909642
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-26 12:14:40.894740
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = ITVBTCCIE._TEST['url']
    playlist_id = ITVBTCCIE._TEST['info_dict']['id']
    title = ITVBTCCIE._TEST['info_dict']['title']

    assert ITVBTCCIE(None)._match_id(test_url) == playlist_id
    assert ITVBTCCIE(None)._real_extract(test_url).get('title') == title

# Generated at 2022-06-26 12:14:49.156059
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE('ITVBTCCIE', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:14:57.485898
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    _, expected_id = ITVIE._extract_url_info(url)
    assert ITVIE._VALID_URL == ITVIE._VALID_URL_TEMPLATE % expected_id
    assert expected_id == '2a4547a0012'

# Generated at 2022-06-26 12:15:01.180258
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    ie = ITVBTCCIE(ITVBTCCIE._downloader)
    info, ie = ie._extract_info(url, "/tmp/save_file", True)

# Generated at 2022-06-26 12:15:04.178621
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from extractor import youtube_dl
    tester = youtube_dl.YoutubeDL()
    result = tester.extract_info(ITVBTCCIE._TEST['url'], download=False)
    assert result['entries'][0]['ie_key'] == 'ITVBTCC'

# Generated at 2022-06-26 12:15:08.993941
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:15:11.668099
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie

# Generated at 2022-06-26 12:15:14.706889
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    InfoExtractor(ITVBTCCIE.ie_key())._real_extract(ITVBTCCIE._TEST['url'])

# Generated at 2022-06-26 12:17:45.946606
# Unit test for constructor of class ITVIE

# Generated at 2022-06-26 12:17:53.622303
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_class = ITVBTCCIE("https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert test_class._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert test_class._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert test_class._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert test_class._TEST['playlist_mincount'] == 9

# Generated at 2022-06-26 12:18:03.992617
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    unit_test = ITVBTCCIE()
    assert unit_test._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert unit_test._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-26 12:18:05.283725
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert x


# Generated at 2022-06-26 12:18:08.503257
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    assert test.url_result('http://www.itv.com/hub/liar/2a4547a0012') == {'url': 'http://www.itv.com/hub/liar/2a4547a0012'}


# Generated at 2022-06-26 12:18:10.491101
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test ITVIE constructor with URL
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-26 12:18:11.674378
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE()
    assert 'ITV' in obj.IE_NAME


# Generated at 2022-06-26 12:18:12.803474
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE()
    assert inst.__class__.__name__ == 'ITVIE'


# Generated at 2022-06-26 12:18:15.177485
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:18:24.679160
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IE = ITVBTCCIE('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert IE.VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'