

# Generated at 2022-06-26 12:10:52.666699
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert test_case_0._downloader.params["noprogress"] == True
    assert test_case_0._type == "playlist"
    assert test_case_0._downloader.params["usenetrc"] == False
    assert test_case_0._downloader.params["retries"] == 10
    assert test_case_0._downloader.params["nooverwrites"] == False
    assert test_case_0._downloader.params["ignoreerrors"] == False
    assert test_case_0._downloader.params["forceurl"] == False
    assert test_case_0._downloader.params["forcethumbnail"] == False
    assert test_case_0._downloader.params["forceduration"] == False
    assert test_case_0._downloader.params["forcetitle"] == False

# Generated at 2022-06-26 12:10:55.069973
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e = ITVIE()


# Generated at 2022-06-26 12:10:57.009443
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()


# Generated at 2022-06-26 12:11:01.136608
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ITVIE._GEO_COUNTRIES == ['GB']
    assert len(ITVIE._TESTS) == 4


# Generated at 2022-06-26 12:11:04.405041
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(url, i_t_v_i_e_0)

# Generated at 2022-06-26 12:11:06.459114
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    n = ITVBTCCIE()

# Generated at 2022-06-26 12:11:08.332986
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e = ITVIE()


# Generated at 2022-06-26 12:11:10.273568
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e = ITVBTCCIE()


# Generated at 2022-06-26 12:11:11.758494
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert i_t_v_i_e_0


# Generated at 2022-06-26 12:11:13.961891
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

# Generated at 2022-06-26 12:11:28.279353
# Unit test for constructor of class ITVIE
def test_ITVIE():
	assert ITVIE('https://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-26 12:11:32.641927
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE(None)
    except TypeError:
        pass
    else:
        raise Exception('ITVIE with None value is not raising TypeError')

# Generated at 2022-06-26 12:11:38.459687
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:11:39.193490
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE({})

# Generated at 2022-06-26 12:11:43.837817
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')._real_extract('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-26 12:11:46.467539
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVExtractor = ITVBTCCIE()
        assert True
    except:
        assert False

# Generated at 2022-06-26 12:11:53.625524
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE("ITVIE", "https://www.itv.com/hub/liar/2a4547a0012")
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert info_extractor._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert info_extractor._TESTS[0]['info_dict']['id'] == '2a4547a0012'
    assert info_extractor._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert info_extractor._

# Generated at 2022-06-26 12:11:57.096063
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE(None)
    assert (itv_ie._GEO_COUNTRIES == ['GB'])

# Generated at 2022-06-26 12:11:57.456293
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-26 12:12:06.638201
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    def _test_sample(url, e_title, e_total_items):
        playlist_id = ITVBTCCIE._match_id(url)
        playlist_webpage = ITVBTCCIE._download_webpage(None, url, playlist_id)
        #print(playlist_webpage)
        
        playlist_result = ITVBTCCIE.playlist_result(None, playlist_id=playlist_id,
                                                    playlist_title=ITVBTCCIE._og_search_title(playlist_webpage, fatal=False))
        assert playlist_result["id"] == e_title
        assert playlist_result["entries"].__len__() == e_total_items

    table = [('brands-hatch', 'BTCC 2018: All the action from Brands Hatch', 9)]

# Generated at 2022-06-26 12:12:33.214987
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012','2a4547a0012')


# Generated at 2022-06-26 12:12:34.606666
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST

# Generated at 2022-06-26 12:12:42.975308
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE()
    assert inst._GEO_COUNTRIES == ['GB']
    assert inst._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-26 12:12:51.823156
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    ITVIE('https://www.itv.com/hub/dancing-on-ice/2a4545a0040')
    ITVIE('https://www.itv.com/hub/dancing-on-ice/2a4545a0040?autoplay=true')
    ITVIE('https://www.itv.com/hub/emmerdale/2a4545a0020')
    ITVIE('https://www.itv.com/hub/coronation-street/2a4545a0011')
    ITVIE('https://www.itv.com/hub/loose-women/2a4547a0012')

# Generated at 2022-06-26 12:12:57.846059
# Unit test for constructor of class ITVIE
def test_ITVIE():
    values = {
        'title': 'Test',
        'season_number': 1,
        'series': 'test',
        'episode': 'test episode',
        'episode_number': 1,
    }
    info = ITVIE._json_ld(values)
    assert info['title'] == values['title']
    assert info['season_number'] == values['season_number']
    assert info['series'] == values['series']
    assert info['episode_title'] == values['episode']
    assert info['episode_number'] == values['episode_number']

# Generated at 2022-06-26 12:13:01.334901
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert x._VALID_URL
    assert x._TEST

# Generated at 2022-06-26 12:13:05.674337
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_obj = ITVBTCCIE()
    assert(test_obj.BRIGHTCOVE_URL_TEMPLATE=='http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-26 12:13:07.977767
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-26 12:13:17.722336
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i = ITVIE()
    #Test invalid URL
    i.test_invalid_url()
    #Test no data
    i.test_lazy_extraction_of_no_data()
    #Test multiple searches
    i.test_search_multiple_results()
    #Test empty format list
    i.test_empty_format_list()
    #Test exception
    i.test_exception_on_unsupported_version()
    #Test extraction
    i.test_extraction(0)
    #Test case-insensitive extractor
    i.test_case_insensitive_extraction()

# Generated at 2022-06-26 12:13:29.567669
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class FakeITVBTCCIE(ITVBTCCIE):
        def _download_webpage(self, url, video_id, note, errnote=None, fatal=True):
            return '<html><div class="brightcove" data-video-id="ref:12345"></div></html>'

    class FakeBrightcoveNewIE(InfoExtractor):
        def _real_extract(self, url):
            raise self.raise_geo_restricted(
                'IPs not allowed', countries=['GB'])

    actual = FakeITVBTCCIE()._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:14:34.004234
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_obj = ITVIE()
    assert test_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:14:36.117480
# Unit test for constructor of class ITVIE
def test_ITVIE():
    global ITVIE
    ITVIE = ITVIE()


# Generated at 2022-06-26 12:14:40.869794
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/hub/racing/1a5312a0019'
    result = ITVBTCCIE._new_extractor(url)
    assert result == ITVBTCCIE

    url = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    result = ITVBTCCIE._new_extractor(url)
    assert result != ITVBTCCIE

# Generated at 2022-06-26 12:14:42.457281
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    a = ITVBTCCIE()
    assert a != None

# Generated at 2022-06-26 12:14:43.375122
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE

# Generated at 2022-06-26 12:14:49.389325
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    url_res = ITVBTCCIE._match_id(url)
    assert url_res == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-26 12:14:55.307381
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from youtube_dl.extractor.itv import ITVIE
    test_ITVIE = ITVIE('http://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034')
    assert isinstance(test_ITVIE, ITVIE)

# Generated at 2022-06-26 12:15:00.142402
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    info_extractor = ITVBTCCIE()

    assert info_extractor._VALID_URL.rstrip('/?') == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*[^/?#&]+'

# Generated at 2022-06-26 12:15:07.146680
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    oe = ITVBTCCIE()
    initialised = oe.initialised

    assert oe.initialised != initialised
    obj = ITVBTCCIE(url)
    assert obj

# Generated at 2022-06-26 12:15:10.267862
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-26 12:17:30.602192
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    constructor_test(ITVBTCCIE, [
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'])

# Generated at 2022-06-26 12:17:32.212932
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        assert ITVBTCCIE('btcc-2018-all-the-action-from-brands-hatch')
    except Exception:
        assert False

# Generated at 2022-06-26 12:17:44.852516
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test = ITVBTCCIE()
    assert test._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert test._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-26 12:17:47.816392
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') is not None

# Generated at 2022-06-26 12:17:48.528803
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-26 12:17:49.863029
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL

test_ITVIE()

# Generated at 2022-06-26 12:18:00.363138
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    c = ITVBTCCIE()
    assert c.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert c._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:18:03.379765
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    tester = ITVBTCCIE()
    assert tester._VALID_URL == 'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:18:04.451304
# Unit test for constructor of class ITVIE
def test_ITVIE():
    InfoExtractor('ITVIE')

# Generated at 2022-06-26 12:18:12.254029
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_cases = (
        (ITVBTCCIE, {
            'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
            'info_dict': {
                'id': 'btcc-2018-all-the-action-from-brands-hatch',
                'title': 'BTCC 2018: All the action from Brands Hatch',
            }
        }),
    )
    for (IE, test) in test_cases:
        ie = IE(downloader=None)
        info_dict = ie.extract(test['url'])