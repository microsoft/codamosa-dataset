

# Generated at 2022-06-26 12:10:45.192237
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_0 = ITVIE()


# Generated at 2022-06-26 12:10:46.778422
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e = ITVBTCCIE()


# Generated at 2022-06-26 12:10:48.112307
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 12:10:49.964408
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Test case 0
    test_case_0()

if __name__ == '__main__':
    #test_test_case_0()
    pass

# Generated at 2022-06-26 12:10:52.240359
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_0 = ITVIE()


# Generated at 2022-06-26 12:10:57.509510
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from unit_test_suite import UnitTestSuite
    suite = UnitTestSuite()
    suite.add_test(ITVBTCCIE("test_case_0"), "test_case_0")
    return suite



# Generated at 2022-06-26 12:10:58.337744
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert 'ITVBTCCIE' == ITVBTCCIE.__name__


# Generated at 2022-06-26 12:10:59.858697
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()


# Generated at 2022-06-26 12:11:00.671536
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass



# Generated at 2022-06-26 12:11:06.452141
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    i_t_v_i_e_0 = ITVIE()

    assert i_t_v_i_e_0._match_id(url) == video_id

# Generated at 2022-06-26 12:11:26.974820
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE([{
            'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
            'info_dict': {
                'id': 'btcc-2018-all-the-action-from-brands-hatch',
                'title': 'BTCC 2018: All the action from Brands Hatch',
            },
            'playlist_mincount': 9,
        }])

# Generated at 2022-06-26 12:11:38.553039
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ie._TEST['info_dict']['id'] == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ie._TEST['info_dict']['title'] == 'BTCC 2018: All the action from Brands Hatch'
    assert ie._TEST['playlist_mincount'] == 9

# Generated at 2022-06-26 12:11:42.469465
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:11:48.955775
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE()._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE()._VALID_URL == ITVBTCCIE._VALID_URL


# Generated at 2022-06-26 12:11:57.008380
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    video_id = info_extractor._match_id('https://www.itv.com/hub/liar/2a4547a0012')
    assert video_id == '2a4547a0012'


# Generated at 2022-06-26 12:12:06.507375
# Unit test for constructor of class ITVBTCCIE

# Generated at 2022-06-26 12:12:07.535592
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(ITVIE())._download_webpage('', '')

# Generated at 2022-06-26 12:12:08.830173
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE()

# Generated at 2022-06-26 12:12:17.069487
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Test a video where video_id is not matched in the downloaded webpage
    ITVIE(url='https://www.itv.com/hub/through-the-keyhole/2a2271a0033')._real_extract(url='https://www.itv.com/hub/through-the-keyhole/2a2271a0033')
    ITVIE(url='https://www.itv.com/hub/through-the-keyhole/2a2271a0033')._real_extract(url='https://www.itv.com/hub/through-the-keyhole/2a2271a0033')

# Generated at 2022-06-26 12:12:22.828442
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE()
    assert itv.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:53.146465
# Unit test for constructor of class ITVIE
def test_ITVIE():
	print("*** Starting tests ***")


# Generated at 2022-06-26 12:12:54.723375
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('ITVIE', 'http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-26 12:13:02.229787
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE()
    print(result.BRIGHTCOVE_URL_TEMPLATE)

if __name__ == '__main__':
    #test_ITVBTCCIE()
    ITVBTCCIE().download_playlist('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:13:11.555847
# Unit test for constructor of class ITVIE
def test_ITVIE():
	itv_ie = ITVIE()

	assert itv_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
	assert itv_ie._API_BASE == 'https://www.itv.com/itvplayer/video/'
	assert itv_ie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-26 12:13:12.538111
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-26 12:13:22.300145
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    ie = ITVIE(url)
    assert ie.url == url
    assert ie.video_id == "2a4547a0012"
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert ie._GEO_COUNTRIES == ['GB']
    assert len(ie._TESTS) == 2

# Generated at 2022-06-26 12:13:31.482477
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    c = ITVBTCCIE(ITVBTCCIE._build_url_result(url))
    assert c.url == url
    assert c._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert c._match_id("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch") == "btcc-2018-all-the-action-from-brands-hatch"

# Generated at 2022-06-26 12:13:35.584909
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITBTCC = ITVBTCCIE()
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == ITBTCC.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-26 12:13:40.446659
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE().extract('http://www.itv.com/news/2017-08-14/three-people-found-dead-at-home-in-sussex/')

# Generated at 2022-06-26 12:13:41.274110
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()

# Generated at 2022-06-26 12:14:45.100895
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:14:50.933000
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE().suitable(test_url)
    assert ITVBTCCIE().valid_url(test_url)
    assert ITVBTCCIE()._match_id(test_url) == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-26 12:14:53.399130
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVIE()).IE_NAME == ITVBTCCIE.IE_NAME

# Generated at 2022-06-26 12:15:01.405986
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert "84894f06c9a9e4d4a4c8f05634ebc6aa" == itv._extract_brightcove_id("http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5570327961001")
    assert "2a4547a0012" == itv._extract_id("https://www.itv.com/hub/liar/2a4547a0012")

# Generated at 2022-06-26 12:15:03.298514
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE(None)
    assert isinstance(inst, ITVBTCCIE)
    assert isinstance(inst, InfoExtractor)

# Generated at 2022-06-26 12:15:04.740582
# Unit test for constructor of class ITVIE
def test_ITVIE():
    e = ITVIE()
    assert e

# Generated at 2022-06-26 12:15:09.321339
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Basic unit test for class ITVBTCCIE
    assert hasattr(ITVBTCCIE, '_real_extract') == True
    assert hasattr(ITVBTCCIE, 'BRIGHTCOVE_URL_TEMPLATE') == True

# Generated at 2022-06-26 12:15:11.294810
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-26 12:15:12.062671
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE

# Generated at 2022-06-26 12:15:14.172690
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/dinner-date/2a3756a0007'
    itv_ie = ITVIE(url)
    print(itv_ie)


# Generated at 2022-06-26 12:17:39.035698
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    IT = ITVBTCCIE()
    assert IT.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:17:40.534208
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()


# Generated at 2022-06-26 12:17:44.556437
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    result = ITVBTCCIE()._real_extract(url)
    # the order of videos may change next time, so we check only for the count
    assert len(result['entries']) >= 9

# Generated at 2022-06-26 12:17:49.440136
# Unit test for constructor of class ITVIE
def test_ITVIE():
    expected = {
        'id': '2a4547a0012',
        'ext': 'mp4',
        'title': 'Liar - Series 2 - Episode 6',
        'description': 'md5:d0f91536569dec79ea184f0a44cca089',
        'series': 'Liar',
        'season_number': 2,
        'episode_number': 6,
        'params': {
            'skip_download': True,
        },
    }
    result = ITVIE()._real_extract({
        'url': 'https://www.itv.com/hub/liar/2a4547a0012',
    })

    for key in expected.keys():
        assert expected[key] == result[key]

# Generated at 2022-06-26 12:17:54.732672
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = ITVBTCCIE()._get_urls_from_webpage(ITVBTCCIE._TEST['url'], ITVBTCCIE._TEST['info_dict']['id'])
    expected_url = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5850768703001'
    assert url == expected_url

# Generated at 2022-06-26 12:17:56.952044
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    try:
        ITVBTCCIE()
    except Exception:
        assert False

# Generated at 2022-06-26 12:17:58.039890
# Unit test for constructor of class ITVIE
def test_ITVIE():
   ITVIE([])._get_available_subtitles({})

# Generated at 2022-06-26 12:18:04.609445
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    obj = ITVBTCCIE()
    info = obj.extract(url)
    assert(info['id'] == 'btcc-2018-all-the-action-from-brands-hatch')
    assert(info['title'] == 'BTCC 2018: All the action from Brands Hatch')
    assert(len(info['entries']) == 9)

# Generated at 2022-06-26 12:18:11.439535
# Unit test for constructor of class ITVIE
def test_ITVIE():
    with open("test_data/json_itv.json", "r") as f:
        web_page = f.read()
    with open("test_data/json_itv_playlist.json", "r") as f:
        playlist = f.read()
    itv = ITVIE("http://www.itv.com/itvplayer/beowulf", {}, "http://www.itv.com/itvplayer/beowulf", httpretty.GET, None)
    itv.httpretty_register()
    itv.httpretty_response(web_page, playlist=playlist)
    print(itv.result())
test_ITVIE()

# Generated at 2022-06-26 12:18:14.337556
# Unit test for constructor of class ITVIE
def test_ITVIE():
    with open('./test/test_data/itv.json') as file_object:
        json_data = json.load(file_object)
    test_ie = ITVIE()
    result = test_ie.suitable(json_data['url'])
    assert result