

# Generated at 2022-06-26 12:10:45.280385
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_0 = ITVIE()

# Generated at 2022-06-26 12:10:46.536638
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_0 = ITVIE()


# Generated at 2022-06-26 12:10:47.870894
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_0 = ITVIE()


# Generated at 2022-06-26 12:10:52.721370
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:10:55.143460
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert_raises(AttributeError, ITVIE, 'ITVIE', None)

# Generated at 2022-06-26 12:10:57.905295
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert getattr(ITVBTCCIE, '_TEST', None) is not None
    assert getattr(ITVBTCCIE, 'BRIGHTCOVE_URL_TEMPLATE', None) is not None


# Generated at 2022-06-26 12:11:02.519014
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from itvcom import ITVIE
    test_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    test_video_id = '2a4547a0012'
    i_t_v_i_e = ITVIE(test_url)
    assert test_video_id in i_t_v_i_e._VALID_URL


# Generated at 2022-06-26 12:11:03.823418
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_case_0()

# Generated at 2022-06-26 12:11:09.399096
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert i_t_v_b_t_c_c_i_e_0.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

test_case_0()

# Generated at 2022-06-26 12:11:10.686002
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e = ITVIE()

# Generated at 2022-06-26 12:11:27.555825
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """Test for the constructor of class ITVBTCCIE"""
    actual_result1 = ITVBTCCIE(ITVBTCCIE._TEST)
    expected_result1 = ITVBTCCIE._TEST
    assert actual_result1.BRIGHTCOVE_URL_TEMPLATE == expected_result1["url"]

# Generated at 2022-06-26 12:11:33.127351
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:11:36.255334
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    res = ITVBTCCIE()
    assert res.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:11:41.908118
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    data = ITVBTCCIE()._real_extract(
        'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert data['playlist'][0]['url'] == 'https://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5799232080001'

# Generated at 2022-06-26 12:11:43.404340
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()

# Generated at 2022-06-26 12:11:44.277665
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-26 12:11:45.722183
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()

# Generated at 2022-06-26 12:11:47.120192
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().constructor_test()

# Generated at 2022-06-26 12:11:57.509308
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE("https://www.itv.com/hub/liar/2a4547a0012")
    ITVIE("https://www.itv.com/hub/through-the-keyhole/2a2271a0033")
    ITVIE("https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034")
    ITVIE("https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024")

# Generated at 2022-06-26 12:12:09.960709
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/hub/itv-racing/2a2458a0056'
    video_id = '2a2458a0056'
    playlist_id = 'itv-racing'
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._match_id(url) == playlist_id

    webpage = itvbtccie._download_webpage(url, playlist_id)

# Generated at 2022-06-26 12:12:38.335898
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie= ITVIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:43.900283
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE(None)
    assert ie.BTCC_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:48.406863
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv_btcc_ie = ITVBTCCIE()
    assert itv_btcc_ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:58.125625
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    ITVBTCCIE is not used in any extractor list. However, some sites (e.g.,
    http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch)
    has a link to the ITVBTCCIE page.
    The ITVBTCCIE page has a http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html
    link, which is a valid URL for the BrightcoveNewIE.
    The ITVBTCCIE page is not on the extractor list. This test aims to check
    whether the ITVBTCCIE constructor works well and whether the ITVBTCCIE
    parses the BrightcoveNewIE link well.
    """

# Generated at 2022-06-26 12:13:01.051831
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(None).ie_key() == 'ITVBTCC'

# Generated at 2022-06-26 12:13:04.324205
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:13:06.788677
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.geo_verification_headers() == {'X-Forwarded-For': '193.113.0.0'}

# Generated at 2022-06-26 12:13:08.776641
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
     assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-26 12:13:16.259412
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Create the unit test
    dis = ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    # Run the unit test
    dis._real_extract('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:13:19.427781
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtcc_IE = ITVBTCCIE()
    assert itvbtcc_IE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:14:31.052361
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._TEST['url'] == url
    url_info = ITVBTCCIE._TEST['info_dict']
    url_id = ITVBTCCIE._TEST['info_dict']['id']
    url_title = ITVBTCCIE._TEST['info_dict']['title']
    assert ITVBTCCIE._TEST['url'] == url
    assert ITVBTCCIE._TEST['playlist_mincount'] == 9

    # Constructor using class variables
    assert ITVBTCCIE(ITVBTCCIE._TEST)._TEST == ITVBTCCIE._TEST
    # Constructor using class methods
    assert ITVBTCC

# Generated at 2022-06-26 12:14:35.399040
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE()._real_extract('https://www.itv.com/hub/This Morning/4a6360a0079')
    except:
        assert False

# Generated at 2022-06-26 12:14:40.462954
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    video_id = '5813003595001'
    video_url = ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE % video_id
    url = ITVBTCCIE.url_result(video_url, video_id=video_id)
    assert url.url_result['ie_key'] == BrightcoveNewIE.ie_key()
    assert url.url_result['video_id'] == video_id

# Generated at 2022-06-26 12:14:51.877156
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:14:57.784553
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(None)._process_extract_result(ITVIE(None)._real_extract(itv_url))

# Generated at 2022-06-26 12:14:59.028793
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()
    ITVBTCCIE()

# Generated at 2022-06-26 12:15:05.749925
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvBTCCIE = ITVBTCCIE()
    assert itvBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:15:14.371683
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    irtv = ITVBTCCIE()
    assert(irtv._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)')

# Generated at 2022-06-26 12:15:20.142833
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE('www.itv.com/hub/britains-brightest-family')
    info_extractor._real_extract("www.itv.com/hub/britains-brightest-family")


# Generated at 2022-06-26 12:15:24.986058
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    class_ = ITVBTCCIE
    assert class_._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert class_.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:18:01.606334
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    webpage = '<html><div data-video-id="5864782081001"><div data-video-id="5864782081002"></div><div data-video-id="5864782081003"></div><div data-video-id="5864782081004"></div><div data-video-id="5864782081005"></div><div data-video-id="5864782081006"></div><div data-video-id="5864782081007"></div><div data-video-id="5864782081008"></div><div data-video-id="5864782081009"></div></div></html>'
    url_id = ITVBT

# Generated at 2022-06-26 12:18:04.670886
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # Check construction of class ITVBTCCIE
    url = "https://www.itv.com/hub/itv-racing/1a1721a0001"
    assert ITVBTCCIE.suitable(url)

# Generated at 2022-06-26 12:18:05.911147
# Unit test for constructor of class ITVIE
def test_ITVIE():
    result = ITVIE.ie_key()
    assert result == 'ITV'

# Generated at 2022-06-26 12:18:08.821233
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    instance = ITVBTCCIE()
    assert instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:18:09.794526
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)


# Generated at 2022-06-26 12:18:10.341580
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE(None)

# Generated at 2022-06-26 12:18:11.124533
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()

# Generated at 2022-06-26 12:18:12.912822
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    itvIE = ITVIE(url)
    assert itvIE.provider_name == 'ITV'

# Generated at 2022-06-26 12:18:19.286203
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    model_obj = ITVBTCCIE(None, 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert model_obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:18:21.561782
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(url)