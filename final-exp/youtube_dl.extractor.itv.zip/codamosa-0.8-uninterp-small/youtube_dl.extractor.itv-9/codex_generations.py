

# Generated at 2022-06-26 12:10:45.271429
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_0 = ITVIE()


# Generated at 2022-06-26 12:10:53.018517
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .brightcove import BrightcoveNewIE
    from .common import InfoExtractor
    from .itv import ITVIE
    from .ooyala import OoyalaIE
    from .theplatform import ThePlatformIE

    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

    assert ITVBTCCIE.__doc__ == 'ITV BTCC videos'


# Generated at 2022-06-26 12:10:56.025077
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

# Generated at 2022-06-26 12:11:01.210728
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url_1 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    title_1 = 'BTCC 2018: All the action from Brands Hatch'
    assert i_t_v_b_t_c_c_i_e_0._match_id(url_1) == title_1


# Generated at 2022-06-26 12:11:09.780632
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url_i_t_v_b_t_c_c_i_e_0 = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

    # Test case ITVBTCCIE.test_case_0()
    i_t_v_b_t_c_c_i_e_0.test_case_0()

# Generated at 2022-06-26 12:11:14.766379
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():

    # Test case #0
    global i_t_v_b_t_c_c_i_e_0
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()


# Generated at 2022-06-26 12:11:20.247700
# Unit test for constructor of class ITVIE

# Generated at 2022-06-26 12:11:26.123908
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVExtractor = ITVBTCCIE()
    ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:11:28.344247
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e = ITVIE()


# Generated at 2022-06-26 12:11:29.716356
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_case_0()

# Generated at 2022-06-26 12:11:44.920402
# Unit test for constructor of class ITVIE
def test_ITVIE():
    mr_y = ITVIE('')
    assert mr_y.name == "itv"

# Generated at 2022-06-26 12:11:52.859616
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itv._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-26 12:12:04.609808
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = ITVBTCCIE._match_id(url)
    webpage = ITVBTCCIE._download_webpage(ITVBTCCIE(), url, playlist_id)

# Generated at 2022-06-26 12:12:08.225071
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVExtractorCreator = ITVBTCCIE
    instance = ITVExtractorCreator()
    assert isinstance(instance, ITVBTCCIE)
    assert instance._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:12:13.204595
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == \
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:17.391559
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # If this test fails, then the ITVBTCCIE constructor has changed, and
    # the _VALID_URL regex needs to be updated.
    instance = ITVBTCCIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:12:20.434693
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie.ie_key() == 'itv', "Wrong name of IE"

# Generated at 2022-06-26 12:12:30.734841
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    assert itvbtccie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert itvbtccie._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }
    assert itvbtccie.BRIGHTCOVE

# Generated at 2022-06-26 12:12:31.534663
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()

# Generated at 2022-06-26 12:12:41.346454
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:13:07.630552
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie is not None

# Generated at 2022-06-26 12:13:19.298618
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Testing the cases when we have access to the data
    # (1) ITVIE should not have seekable videos
    # (2) ITVIE should have allowed countries
    # (3) ITVIE should have allowed formats
    # (4) ITVIE should have allowed subtitles
    # (5) ITVIE should have allowed duration
    # (6) ITVIE should have allowed description
    # (7) ITVIE should have allowed metadata for title, series, episode_number and season_number
    itv_class = ITVIE({})
    assert itv_class.seekable == ['never']
    assert itv_class.geo_countries == ['GB']
    assert itv_class.allowed_ext == ['mp4']
    assert itv_class.allowed_subtitles == ['en']

# Generated at 2022-06-26 12:13:27.240117
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # testing the constructor
    # Creation of a ITVIE instance
    test_itv = ITVIE('http://www.itv.com/hub/liar/2a4547a0012')
    assert test_itv.url == 'http://www.itv.com/hub/liar/2a4547a0012'
    assert type(test_itv) is ITVIE
# Run test
#test_ITVIE()

# Generated at 2022-06-26 12:13:30.715545
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """
    Construct an instance of ITVIE and call test_video_id method
    """

    ITVIE().test_video_id('2a4547a0012')

# Generated at 2022-06-26 12:13:33.756282
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.SUCCESSFUL_EXTRACTIONS == 0
    assert ie.total_extractions == 0

# Generated at 2022-06-26 12:13:41.130963
# Unit test for constructor of class ITVIE
def test_ITVIE():
    params = {"data-video-id":"2a4547a0012",
              "data-playlist-url":"https://www.itv.com/itvplayer/liar/2a4547a0012",
              "data-video-hmac":"Cxzs8PkCBiJHkYrMlujZDmIq3Hs="}
    itv = ITVIE(InfoExtractor())
    itv._search_regex(r'(?s)(<[^>]+id="video"[^>]*>)', 'dummy webpage', 'params')
    extract_attributes(params)
    itv.geo_verification_headers()
    itv._download_json('https://www.itv.com/itvplayer/liar/2a4547a0012', 'dummy')


# Generated at 2022-06-26 12:13:44.331267
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    t = ITVBTCCIE([]).__class__
    assert t.__name__ == 'ITVBTCCIE'

# Generated at 2022-06-26 12:13:49.233887
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    playlist_id = ITVBTCCIE._match_id(url)
    test_module = ITVBTCCIE()
    assert playlist_id == 'btcc-2018-all-the-action-from-brands-hatch'
    webpage = test_module._download_webpage(url, playlist_id)
    assert webpage != ''

# Generated at 2022-06-26 12:13:55.673616
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE()._result(ITVBTCCIE._TEST)
    assert result['playlist'][1]['url'] == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5999860350001'

# Generated at 2022-06-26 12:14:02.151023
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = url_or_none('https://www.itv.com/hub/liar/1a4547a0012')
    info_dict = {
        'id': '1a4547a0012',
        'ext': 'mp4',
        'title': 'Liar - Series 1 - Episode 6',
        'description': 'md5:e88b55f554908d71e87c87b0d8b9dea6',
        'series': 'Liar',
        'season_number': 1,
        'episode_number': 6,
    }
    params = {
        # m3u8 download
        'skip_download': True,
    }

# Generated at 2022-06-26 12:15:04.810083
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    x = ITVBTCCIE()
    assert x._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-26 12:15:07.552141
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    obj = ITVBTCCIE()
    obj._real_extract(url)

# Generated at 2022-06-26 12:15:11.740589
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        # Creating an object of ITVIE
        obj = ITVIE()
    except Exception as e:
        print('Error while creating object of class ITVIE, error is:', e)
        # returning None, so that an assertion error will occur
        return None
    # returning the object of class ITVIE, no assertion error will occur
    return obj


# Generated at 2022-06-26 12:15:20.809877
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    instance = ITVBTCCIE(ITVBTCCIE.IE_NAME)
    instance.download(url)
    assert instance.processedUrl == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5840392435001'

# Generated at 2022-06-26 12:15:22.078219
# Unit test for constructor of class ITVIE
def test_ITVIE():
    new_itv_ie = ITVIE()

# Generated at 2022-06-26 12:15:32.823615
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Check the constructor of class ITVBTCCIE.
    """
    info_extractor = ITVBTCCIE()
    assert info_extractor._VALID_URL == "https?://(?:www\\.)?itv\\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)"
    assert info_extractor._TEST == {'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch', 'info_dict': {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}, 'playlist_mincount': 9}
    assert info_extractor.BRIGHTCOVE_URL

# Generated at 2022-06-26 12:15:39.907332
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itvie = ITVIE()
    assert itvie.SUPPORTED_FORMATS == ['hls', 'hls-aes', 'hls-aes-outband-webvtt']
    assert itvie.geo_verification_headers() == {'x-forwarded-for': '0.0.0.0'}

# Generated at 2022-06-26 12:15:41.015874
# Unit test for constructor of class ITVIE
def test_ITVIE():
    inst = ITVIE()
    assert inst._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-26 12:15:45.717070
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:15:52.673055
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:18:14.210080
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE % '54321' == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=54321'
    assert ie.BRIGHTCOVE_URL_TEMPLATE % '12345' == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=12345'

# Generated at 2022-06-26 12:18:19.286006
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE()
    # Test the following variables are initialized properly
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE =="http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s"

# Generated at 2022-06-26 12:18:27.526276
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_url = "https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034"
    video_id = ITVIE._match_id(test_url)
    info_dict = ITVIE._real_extract(ITVIE(), test_url)
    assert(info_dict['id'] == video_id)
    assert(info_dict['title'] == 'James Martin’s Saturday Morning')
    assert(info_dict['description'] == 'md5:a4b134cbde55c49e9e9decf6f19c2a2a')
    assert(info_dict['duration'] == 'PT30M')

# Generated at 2022-06-26 12:18:28.475895
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    from .test_static_tests import TestStaticTests
    TestStaticTests.run_single_test(ITVBTCCIE)


# Generated at 2022-06-26 12:18:31.733768
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    inst = ITVBTCCIE(youtube_ie=None)
    assert inst._VALID_URL == "https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)"

# Generated at 2022-06-26 12:18:33.374117
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('http://www.itv.com/hub/liar/2a4547a0012')

# Generated at 2022-06-26 12:18:36.582732
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_obj = ITVBTCCIE()
    assert test_obj._VALID_URL == 'https?://(?:www\\.)?itv\\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:18:46.467769
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert ie._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'
    assert ie._VALID_URL == 'https?://(?:www\\.)?itv\\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:18:50.500278
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():

    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    itvBTCCIE = ITVBTCCIE()
    itvBTCCIE.urls = [url]
    webpage = itvBTCCIE._download_webpage(url, itvBTCCIE._match_id(url))

    return

# Generated at 2022-06-26 12:18:53.057640
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._TEST['info_dict']['id'] == ITVBTCCIE._match_id(url)