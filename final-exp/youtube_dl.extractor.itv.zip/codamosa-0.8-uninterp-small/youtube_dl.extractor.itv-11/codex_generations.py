

# Generated at 2022-06-26 12:10:48.073257
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert i_t_v_b_t_c_c_i_e_0.valid_url(test_case_0) == True

test_case_1 = "http://www.itv.com/hub/the-princess-diaries-2-royal-engagement/2a2623a0016"


# Generated at 2022-06-26 12:10:49.390923
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

# Generated at 2022-06-26 12:10:50.901494
# Unit test for constructor of class ITVIE
def test_ITVIE():
    pass


# Generated at 2022-06-26 12:10:52.999954
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_0 = ITVIE()

# Generated at 2022-06-26 12:10:54.852706
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_object = ITVIE()



# Generated at 2022-06-26 12:10:56.870076
# Unit test for constructor of class ITVIE
def test_ITVIE():
    i_t_v_i_e_0 = ITVIE()


# Generated at 2022-06-26 12:11:04.908237
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    # The BrightcoveNewIE constructor is invoked using the line below
    i_t_v_b_t_c_c_i_e = ITVBTCCIE()
    #test_case_0()
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    video_id = info_extractor._match_id(url)
    webpage = info_extractor._download_webpage(url, video_id)
    params = extract_attributes(info_extractor._search_regex(
        r'(?s)(<[^>]+id="video"[^>]*>)', webpage, 'params'))

# Generated at 2022-06-26 12:11:17.328715
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # cases that are in _VALID_URL
    assert 'https://www.itv.com/hub/liar/2a4547a0012' == ITVIE()._VALID_URL
    assert 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033' == ITVIE()._VALID_URL
    assert 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034' == ITVIE()._VALID_URL
    assert 'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024' == ITVIE()._VALID_URL

    # cases that are not in _VALID_URL

# Generated at 2022-06-26 12:11:28.936774
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ITVBTCCIE._TEST == {
        'url': 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch',
        'info_dict': {
            'id': 'btcc-2018-all-the-action-from-brands-hatch',
            'title': 'BTCC 2018: All the action from Brands Hatch',
        },
        'playlist_mincount': 9,
    }

# Generated at 2022-06-26 12:11:29.795558
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    pass

# Generated at 2022-06-26 12:11:45.723046
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:11:48.731245
# Unit test for constructor of class ITVIE

# Generated at 2022-06-26 12:11:53.631414
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from io import BytesIO
    response = ITVIE.url_result(BytesIO(b'data'))
    assert response == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-26 12:12:04.079192
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    video_id = '2a4547a0012'
    itvIE = ITVIE()
    assert itvIE._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itvIE._download_webpage(url, video_id) is not None
    breakpoint()
    assert itvIE._match_id(url) == video_id
    assert itvIE._real_extract(url)['id'] == video_id


# Generated at 2022-06-26 12:12:05.636700
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE()


# Generated at 2022-06-26 12:12:07.566731
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie
    assert ie._VALID_URL

# Generated at 2022-06-26 12:12:08.360182
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-26 12:12:11.287294
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    assert ITVIE(url).url == url

# Generated at 2022-06-26 12:12:14.459469
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    assert ie.countries == ['GB']
    assert ie.age_limit is None
    assert ie.IE_NAME == 'ITV'

# Generated at 2022-06-26 12:12:17.697047
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:12:46.123855
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    inst = ITVBTCCIE(None)
    assert inst._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 12:12:52.540469
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    (ITVBTCCIE(None).url_result(
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5830169005001',
        ie='BrightcoveNew',
        video_id='5830169005001')).handle_ie_result(None)

    (ITVBTCCIE(None).url_result(
        'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=5830169005001',
        ie='BrightcoveNew',
        video_id='5830169005001',
    )).handle_ie_result(None)

# Generated at 2022-06-26 12:13:04.266961
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    playlist_id = "btcc-2018-all-the-action-from-brands-hatch"

# Generated at 2022-06-26 12:13:07.031185
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class_name = ITVBTCCIE.__name__
    class_ = globals()[class_name]
    assert class_ is not None
    obj = class_(None)
    assert obj is not None

# Generated at 2022-06-26 12:13:11.281911
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE(InfoExtractor())._download_webpage('https://www.itv.com/hub/britains-brightest-family/1a7851a0069', 'blah')

# Generated at 2022-06-26 12:13:21.071072
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itvbtccie = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")
    assert itvbtccie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert itvbtccie._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-26 12:13:22.433093
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE.ie_key() == 'ITV'

# Generated at 2022-06-26 12:13:25.423936
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    ITVIE(url)

# Generated at 2022-06-26 12:13:30.267873
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE('https://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')
    assert ie.ITVBTCCIE_BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:13:32.626769
# Unit test for constructor of class ITVIE
def test_ITVIE():
    from itv import ITVIE
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    temp = ITVIE(url=url)
    is_instance = isinstance(temp, ITVIE)
    assert is_instance


# Generated at 2022-06-26 12:14:38.631883
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012";
    i = ITVIE();
    i._match_id(url)
    print(i._VALID_URL);

# Generated at 2022-06-26 12:14:47.923874
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Basic test for constructor of class ITVBTCCIE
    """
    instance = ITVBTCCIE("http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch")

    assert(instance._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)')

# Generated at 2022-06-26 12:14:54.728037
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    """
    Unit test for constructor of class ITVBTCCIE
    """
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    assert ITVBTCCIE(None)._match_id(url) == 'btcc-2018-all-the-action-from-brands-hatch'


# Generated at 2022-06-26 12:15:00.740829
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Check the class constructor."""
    ITVIE(None)._download_webpage = lambda self, *args, **kwargs: '<html></html>'
    assert ITVIE(None)._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-26 12:15:04.666413
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    import pytest
    with pytest.raises(TypeError):
        ITVBTCCIE() # TypeError: Can't instantiate abstract class ITVBTCCIE with abstract methods _real_extract

# Generated at 2022-06-26 12:15:12.494042
# Unit test for constructor of class ITVIE
def test_ITVIE():
    v = ITVIE()
    assert v._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert v._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'
    assert v._TESTS[0]['info_dict']['id'] == '2a4547a0012'
    assert v._TESTS[0]['info_dict']['ext'] == 'mp4'



# Generated at 2022-06-26 12:15:14.368723
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE().BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:15:18.149984
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    ITVIE(url)

# Generated at 2022-06-26 12:15:20.590344
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE = ITVIE()
    # Test properties
    assert IE.IE_NAME == 'itv'

# Generated at 2022-06-26 12:15:22.443413
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.ie_key() == 'ITV:BTCC'


# Generated at 2022-06-26 12:17:45.265128
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    obj = ITVBTCCIE()
    obj_1 = ITVBTCCIE()
    obj_2 = ITVBTCCIE()
    assert obj.BRIGHTCOVE_URL_TEMPLATE == obj_1.BRIGHTCOVE_URL_TEMPLATE
    assert obj.BRIGHTCOVE_URL_TEMPLATE == obj_2.BRIGHTCOVE_URL_TEMPLATE

# Generated at 2022-06-26 12:17:48.589170
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    BTCC_url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    print (ITVBTCCIE()._real_extract(BTCC_url))
    assert True

# Generated at 2022-06-26 12:17:51.806478
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Equivalent to ITVIE(InfoExtractor).__init__()
    # This test is only necessary to check that the constructor does not raise
    # any exception.
    ITVIE(InfoExtractor()).__init__()

# Generated at 2022-06-26 12:17:57.049805
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    # This is arbitrary playlist_id.
    # Please don't change unless url becomes invalid.
    playlist_id = "btcc-2018-all-the-action-from-brands-hatch"

    assert ITVBTCCIE._TEST["url"] == ITVBTCCIE._VALID_URL % playlist_id
    assert ITVBTCCIE._TEST["info_dict"]["id"] == playlist_id

# Generated at 2022-06-26 12:18:06.350022
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url_1 = 'https://www.itv.com/hub/liar/2a4547a0012'
    url_2 = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    url_3 = 'https://www.itv.com/hub/whos-doing-the-dishes/2a2898a0024'
    url_4 = 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033'
    extractor = ITVIE()

    assert extractor._match_id(url_1) == '2a4547a0012'
    assert extractor._match_id(url_2) == '2a5159a0034'
    assert extractor._match_id

# Generated at 2022-06-26 12:18:14.178781
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    ie = ITVBTCCIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?itv\.com/btcc/(?:[^/]+/)*(?P<id>[^/?#&]+)'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:18:25.532026
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    r = ITVBTCCIE()
    assert r._match_id('http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'
    assert r._match_id('http://www.itv.com/itvplayer/video/btcc-2018-all-the-action-from-brands-hatch') == 'btcc-2018-all-the-action-from-brands-hatch'

# Generated at 2022-06-26 12:18:27.875591
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = ITVIE._VALID_URL
    m = re.match(ITVIE._VALID_URL, url)
    video_id = m.group('id')
    cls = ITVIE
    cls(url)

# Generated at 2022-06-26 12:18:28.881040
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE()._VALID_URL == ITVIE._VALID_URL

# Generated at 2022-06-26 12:18:29.871317
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.__name__ == 'ITVBTCCIE'