

# Generated at 2022-06-26 12:10:51.485096
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()
    its_args = i_t_v_b_t_c_c_i_e_0.args
    its_args['BRIGHTCOVE_URL_TEMPLATE'] == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'
    assert True


# Generated at 2022-06-26 12:10:54.994960
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert ITVIE._VALID_URL() is not None
    assert ITVIE._TESTS() is not None


# Generated at 2022-06-26 12:10:57.507104
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

# Generated at 2022-06-26 12:10:58.534258
# Unit test for constructor of class ITVIE
def test_ITVIE():
    assert test_case_0() == None, 'Constructor for class ITVIE failed.'


# Generated at 2022-06-26 12:11:03.899088
# Unit test for constructor of class ITVIE
def test_ITVIE():
    if (ITVIE()._VALID_URL == 'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    ):
        return True
    else:
        return False


# Generated at 2022-06-26 12:11:07.322275
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()


# Generated at 2022-06-26 12:11:09.475507
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

# Generated at 2022-06-26 12:11:10.457063
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE != None

# Generated at 2022-06-26 12:11:12.464533
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e_0 = ITVBTCCIE()

# Generated at 2022-06-26 12:11:14.671331
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    i_t_v_b_t_c_c_i_e = ITVBTCCIE()

# Generated at 2022-06-26 12:11:41.176995
# Unit test for constructor of class ITVIE
def test_ITVIE():
    with open('test.html', 'r') as f:
        webpage = f.read()
    itvie = ITVIE('http://www.itv.com/hub/liar/2a4547a0012', webpage)
    assert itvie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itvie._GEO_COUNTRIES == ['GB']

# Generated at 2022-06-26 12:11:51.166326
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    class_ = ITVBTCCIE
    class_.BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

    # test constructor of derived class
    class__ = ITVBTCCIE()
    assert class__.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'

# Generated at 2022-06-26 12:11:57.782684
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE()
    test_url = 'http://www.itv.com/hub/liar/2a4547a0012'
    test_video_id = '2a4547a0012'
    assert test._match_id(test_url) == test_video_id

# Generated at 2022-06-26 12:12:06.875615
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test = ITVIE('ITVIE', {
        'url': 'http://www.itv.com/hub/jeremy-clarkson/2a5168a0032',
        'info_dict': {
            'id': '2a5168a0032',
            'ext': 'mp4',
            'title': 'Jeremy Clarkson - Series 20 - Episode 3',
            'description': 'md5:d0f91536569dec79ea184f0a44cca089',
            'series': 'Jeremy Clarkson',
            'season_number': 20,
            'episode_number': 3,
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    })

# Generated at 2022-06-26 12:12:08.705673
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    test_ITVBTCCIE = ITVBTCCIE()
    assert test_ITVBTCCIE is not None

# Generated at 2022-06-26 12:12:11.611206
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE(ITVEditorialIE())._VALID_URL == ITVBTCCIE._VALID_URL


# Generated at 2022-06-26 12:12:15.945383
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    result = ITVBTCCIE()
    assert(result.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s')

# Generated at 2022-06-26 12:12:18.383043
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # Tests to make sure that ITVIE is created, and that the super has
    # been called.

    assert ITVIE is not None
    assert InfoExtractor is not None

# Generated at 2022-06-26 12:12:29.503231
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # NOTE: there is no way to run just this test
    # NOTE: 'itv.com' is blocked in China
    # print('Test ITV Addon')
    # print(' url: %s' % url)
    # print(' url: %s' % url1)
    # print(' url: %s' % url2)
    #
    # itv_ie = ITVAddon()
    # print(' Extract:')
    # print(itv_ie.extract(url))
    # print(itv_ie.extract(url1))
    # print(itv_ie.extract(url2))

    # TODO(WD): check
    # itv_ie.extract(url3)
    return

# Generated at 2022-06-26 12:12:32.022271
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE


# Generated at 2022-06-26 12:13:08.448594
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    url = "http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch"
    object = ITVBTCCIE(ITVBTCCIE._downloader, [], dict(url=url))
    object.playlist_id = 'btcc-2018-all-the-action-from-brands-hatch'
    object.url = url
    object.webpage_url = url

# Generated at 2022-06-26 12:13:15.260156
# Unit test for constructor of class ITVIE
def test_ITVIE():
    info_extractor = ITVIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'

# Generated at 2022-06-26 12:13:16.217360
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv = ITVIE()
    assert itv.GEO_COUNTRIES == ['GB']

# Generated at 2022-06-26 12:13:18.284265
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE_test = ITVBTCCIE()
    ITVBTCCIE_test._download_webpage = lambda self, url, video_id: None


# Generated at 2022-06-26 12:13:22.432067
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE('ITVBTCCIE', 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch')

# Generated at 2022-06-26 12:13:28.381610
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE('http://www.itv.com/hub/x-factor/2a4644a0043')
    assert obj.geo_countries == ['GB']
    assert obj.geo_verification_headers()['X-Forwarded-For'] == '193.113.0.0'
    assert obj.geo_bypass() is False


# Generated at 2022-06-26 12:13:38.587442
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'http://www.itv.com/hub/liar/2a4547a0012'
    e = ITVIE()
    assert e.match_url(url)
    assert e._match_id(url) == '2a4547a0012'
    url = 'https://www.itv.com/hub/through-the-keyhole/2a2271a0033'
    assert e.match_url(url)
    assert e._match_id(url) == '2a2271a0033'
    url = 'https://www.itv.com/hub/james-martins-saturday-morning/2a5159a0034'
    assert e.match_url(url)
    assert e._match_id(url) == '2a5159a0034'

# Generated at 2022-06-26 12:13:43.260068
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie._VALID_URL == ITVBTCCIE._VALID_URL
    assert ie._TEST == ITVBTCCIE._TEST

# Generated at 2022-06-26 12:13:48.832035
# Unit test for constructor of class ITVIE
def test_ITVIE():
    #test invalid vodcrid
    itv = ITVIE()
    assert ITVIE._TESTS[1]['only_matching'] == itv._real_extract(ITVIE._TESTS[1]['url']).get('only_matching')
    #test content unavailable
    assert ITVIE._TESTS[2]['only_matching'] == itv._real_extract(ITVIE._TESTS[2]['url']).get('only_matching')

# Generated at 2022-06-26 12:13:54.277514
# Unit test for constructor of class ITVIE
def test_ITVIE():
    # I created this code to test the ITVIE class in a different file
    # The goal is to maintain the structure of the file itv.py intact, but
    # being able to add the testing code of ITVIE.
    import urllib.parse
    import json

    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    itv_ie = ITVIE()

    m = urllib.parse.urlparse(url)
    m_q = urllib.parse.parse_qs(m.query)

    id = itv_ie._match_id(url)
    webpage = itv_ie._download_webpage(url, id)


# Generated at 2022-06-26 12:15:03.786823
# Unit test for constructor of class ITVIE
def test_ITVIE():
    obj = ITVIE
    assert obj._VALID_URL == "https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)"

# Generated at 2022-06-26 12:15:11.110473
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ITVIE('https://mediaplayer.itv.com/service/1.3/videojson/%7B%22video%22:%7B%22istv%22:%22true%22,%22crid%22:%222a4547a0012%22%7D%7D?authCode=QXNkZmFzZGxmbnNkYWZoYXNkZmhrYWxm&r_=undefined', True)



# Generated at 2022-06-26 12:15:11.871352
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ITVBTCCIE()

# Generated at 2022-06-26 12:15:15.448997
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE(ITVBTCCIE.IE_NAME, ITVBTCCIE.ie_key())
    assert isinstance(ie, ITVBTCCIE)


# Generated at 2022-06-26 12:15:17.579055
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    ie = ITVBTCCIE()
    assert ie

# Generated at 2022-06-26 12:15:25.097849
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    class FakeResult:
        def __init__(self, id, url):
            self.id = id
            self.url = url
    def FakeUrlResult(id, url):
        return FakeResult(id, url)
    class FakeExtractor:
        def url_result(id, url):
            return FakeUrlResult(id, url)
    class FakeIE:
        ie_key = 'BrightcoveNew'
        ie = FakeExtractor

    # Only tests 2 cases because the rest are dealt with by BrightcoveNewIE

# Generated at 2022-06-26 12:15:31.575898
# Unit test for constructor of class ITVIE
def test_ITVIE():
    itv_ie = ITVIE()
    assert itv_ie._VALID_URL == r'https?://(?:www\.)?itv\.com/hub/[^/]+/(?P<id>[0-9a-zA-Z]+)'
    assert itv_ie._TESTS[0]['url'] == 'https://www.itv.com/hub/liar/2a4547a0012'

# Generated at 2022-06-26 12:15:42.475825
# Unit test for constructor of class ITVIE
def test_ITVIE():
    url = 'https://www.itv.com/hub/liar/2a4547a0012'
    a = ITVIE(url)
    assert a.url ==  'https://www.itv.com/hub/liar/2a4547a0012'
    assert a.id == '2a4547a0012'
    assert a.title == 'Liar - Series 2 - Episode 6'
    assert a.description == 'md5:d0f91536569dec79ea184f0a44cca089'
    assert a.series == 'Liar'
    assert a.season_number == 2
    assert a.episode_number == 6

# Generated at 2022-06-26 12:15:47.088613
# Unit test for constructor of class ITVIE
def test_ITVIE():
    IE_ITV = ITVIE("http://www.itv.com/hub/liar/2a4547a0012")
    print(IE_ITV)


# Generated at 2022-06-26 12:15:50.780664
# Unit test for constructor of class ITVIE
def test_ITVIE():
    test_case = ITVIE('https://www.itv.com/hub/liar/2a4547a0012')
    assert isinstance(test_case, ITVIE) == True

# Generated at 2022-06-26 12:18:28.277880
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import inspect
    funcArgs = inspect.getfullargspec(ITVIE.__init__).args
    # confirm that the constructor takes the same arguments as InfoExtractor
    assert funcArgs == InfoExtractor.__init__.__code__.co_varnames

# Generated at 2022-06-26 12:18:33.653634
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
	print('\n')
	print('=Running test_ITVBTCCIE()=')
	print('\n')
	#IMPORT EXTRACTOR
	from .itv import ITVBTCCIE
	url				= 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
	info_dict 		= {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}
	playlist_mincount = 9

# Generated at 2022-06-26 12:18:36.582647
# Unit test for constructor of class ITVIE
def test_ITVIE():
    try:
        ITVIE(None)._real_extract({})
        assert False, "Shouldn't reach this line"
    except AssertionError:
        assert True
    else:
        assert False

# Generated at 2022-06-26 12:18:39.902400
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1582188683001/HkiHLnNRx_default/index.html?videoId=%s'


# Generated at 2022-06-26 12:18:45.803378
# Unit test for constructor of class ITVIE
def test_ITVIE():
    """Unit test for constructor of class ITVIE"""
    url = "https://www.itv.com/hub/liar/2a4547a0012"
    itv_result = ITVIE()
    itv_result._real_initialize(url)
    assert itv_result._downloader is not None
    assert itv_result._TYPE == "itv"

# Generated at 2022-06-26 12:18:46.148653
# Unit test for constructor of class ITVIE
def test_ITVIE():
    pass

# Generated at 2022-06-26 12:18:50.886569
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    assert ITVBTCCIE._TEST['url'] == 'http://www.itv.com/btcc/races/btcc-2018-all-the-action-from-brands-hatch'
    assert ITVBTCCIE._TEST['playlist_mincount'] == 9
    assert ITVBTCCIE._TEST['info_dict'] == {'id': 'btcc-2018-all-the-action-from-brands-hatch', 'title': 'BTCC 2018: All the action from Brands Hatch'}


# Generated at 2022-06-26 12:18:52.123729
# Unit test for constructor of class ITVBTCCIE
def test_ITVBTCCIE():
    itv = ITVBTCCIE()
    assert isinstance(itv, ITVBTCCIE)

# Generated at 2022-06-26 12:18:56.510825
# Unit test for constructor of class ITVIE
def test_ITVIE():
    import unittest
    # Testing an episode with one video urls
    class ITVTest(unittest.TestCase):
        def test_regular(self):
            url = "https://www.itv.com/hub/liar/2a4547a0012"
            tv = ITVIE()
            self.assertEqual(tv._match_id(url), '2a4547a0012')
            self.assertEqual(tv._VALID_URL, ITVIE._VALID_URL)
    suite = unittest.TestLoader().loadTestsFromTestCase(ITVTest)
    unittest.TextTestRunner(verbosity=2).run(suite)

test_ITVIE()

# Generated at 2022-06-26 12:19:03.029397
# Unit test for constructor of class ITVIE
def test_ITVIE():
    ie = ITVIE()
    # test for a standard ITV video
    webpage = 'https://www.itv.com/hub/liar/2a4547a0012'
    info_dict = {
        'id': '2a4547a0012',
        'ext': 'mp4',
        'title': 'Liar - Series 2 - Episode 6',
        'description': 'md5:d0f91536569dec79ea184f0a44cca089',
        'series': 'Liar',
        'season_number': 2,
        'episode_number': 6,
    }
    params = {
        # m3u8 download
        'skip_download': True,
    }
    test = [webpage, info_dict, params]