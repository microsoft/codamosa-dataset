

# Generated at 2022-06-21 10:52:56.355170
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'tests', 'test-data', 'dict-out')
    template_name = 'test'
    context = {'cookiecutter': {'name': 'foo'}}

    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)

    assert context == context_loaded

# Generated at 2022-06-21 10:52:58.282390
# Unit test for function load
def test_load():
    context = load(os.path.join('tests', 'fixtures'), 'with_hooks')
    assert 'cookiecutter' in context


# Generated at 2022-06-21 10:53:05.187532
# Unit test for function get_file_name
def test_get_file_name():
    # Test that if template name ends with ".json" extension,
    #  suffix will not be added
    assert get_file_name('replay', 'test.json')\
        == 'replay/test.json'

    # Test that if template name does not end with ".json" extension,
    #  suffix will be added
    assert get_file_name('replay', 'test')\
        == 'replay/test.json'

# Generated at 2022-06-21 10:53:09.893419
# Unit test for function load
def test_load():
    # Arrange
    replay_dir = 'fake-replay-dir'
    template_name = 'fake-template-name'
    # Act
    context = load(replay_dir, template_name)
    # Assert
    assert context.startswith('Error')


# Generated at 2022-06-21 10:53:18.510397
# Unit test for function load
def test_load():
    replay_dir = 'c:/Users/Li_lab/Cookiecutter/test_replay'
    template_name = 'test_template'
    context = dict(cookiecutter = dict(first_name = 'Yue', last_name = 'Jiang', email = 'jiangyue@mail.nankai.edu.cn',
                                       year = '2020'))
    dump(replay_dir, template_name, context)
    if __name__ == "__main__":
        load(replay_dir, template_name)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-21 10:53:25.769663
# Unit test for function get_file_name
def test_get_file_name():
    """Test for function get_file_name."""
    replay_dir = '~/replay_dir'
    template_name = 'my_new_project'
    assert get_file_name(replay_dir, template_name) == '~/replay_dir/my_new_project.json'
    template_name = 'my_new_project.json'
    assert get_file_name(replay_dir, template_name) == '~/replay_dir/my_new_project.json'

# Generated at 2022-06-21 10:53:33.642254
# Unit test for function load
def test_load():
    replay_dir = os.path.join('/tmp', 'cookiecutter-replay')
    template_name = 'fake_template'
    context = {
        'cookiecutter': {
            'fake_key': 'fake_value',
        }
    }

    try:
        dump(replay_dir, template_name, context)
        loaded_context = load(replay_dir, template_name)

        assert loaded_context.get('cookiecutter') == context.get('cookiecutter')
    finally:
        file_name = get_file_name(replay_dir, template_name)
        if os.path.isfile(file_name):
            os.remove(file_name)


# Generated at 2022-06-21 10:53:38.104975
# Unit test for function dump
def test_dump():
    replay_dir = '~/.cookiecutters/'
    template_name = 'cookiecutter-django/'
    context = {'cookiecutter': {'something': 'nothing'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:53:41.228133
# Unit test for function load
def test_load():
    """Unit test for function load in replay.py."""
    load('/Users/shiqizhang/git/cookiecutter-pypackage', 'cookiecutter-pypackage')
    return True


# Generated at 2022-06-21 10:53:43.781149
# Unit test for function get_file_name
def test_get_file_name():
	path = get_file_name('foo', 'bar')
	assert(path == 'foo/bar.json')


# Generated at 2022-06-21 10:53:56.871325
# Unit test for function load
def test_load():
    import pytest
    d = {}
    with pytest.raises(IOError):
        load(d, 'abc.json')

    d['replay_dir'] = '.'
    with pytest.raises(TypeError) as exception:
        load(d, 23)

    assert str(exception.value) == 'Template name is required to be of type str'

    d['template_name'] = 'test_load.json'
    with pytest.raises(ValueError) as exception:
        load(d, 'test_load.json')

    assert str(exception.value) == 'Context is required to contain a cookiecutter key'

    import json
    import os


# Generated at 2022-06-21 10:54:02.101661
# Unit test for function load
def test_load():
    replay_dir="/home/xlx/tmp/cookiecutter/lizhenghuan"
    template_name="ted1.json"
    #all the content in the json file will be return to variable context
    context = load(replay_dir, template_name)
    print (context)
    print (context['cookiecutter'])
    print (context['cookiecutter']['repo_name'])

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-21 10:54:05.861465
# Unit test for function load
def test_load():
    context = load(replay_dir='some_dir', template_name='some_template')
    assert context == {'cookiecutter': {}}


# Generated at 2022-06-21 10:54:08.238793
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/'
    template_name = 'myTemplate'
    context = {
        "cookiecutter": {
            "full_name": "Awesome Name",
            "email": "awesome@email.com"
        }
    }
    assert dump(replay_dir, template_name, context) is None
    assert os.path.exists(os.path.join(replay_dir, template_name + '.json'))


# Generated at 2022-06-21 10:54:11.691955
# Unit test for function get_file_name
def test_get_file_name():
    """Test for function get_file_name."""
    assert get_file_name(replay_dir='/home/test_user',
                         template_name='test_template') == '/home/test_user/test_template.json'


# Generated at 2022-06-21 10:54:20.041661
# Unit test for function dump
def test_dump():
    """Test that dump works as expected."""
    sample_context = {
        "cookiecutter": {
            "replay_dir": "replay",
            "full_name": "Audrey Roy",
            "email": "audreyr@example.com",
            "github_username": "audreyr",
        }
    }
    sample_template_name = 'fake-repo'
    replay_dir = sample_context['cookiecutter']['replay_dir']

    dump(replay_dir=replay_dir,
         template_name=sample_template_name,
         context=sample_context)

    # test that load works
    loaded_context = load(replay_dir=replay_dir,
                          template_name=sample_template_name)


# Generated at 2022-06-21 10:54:28.601048
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_replays')
    template_name = 'test_replay'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert '{"name": null}' == context['cookiecutter']


# Generated at 2022-06-21 10:54:34.699675
# Unit test for function load
def test_load():
    # test wrong input type
    try:
        load(1, 'abc')
        assert(False)
    except Exception as e:
        print('Passed: should error when wrong type input')
        assert(isinstance(e, TypeError))
        
    # test wrong missing key
    try:
        load('data', 'test.json')
        assert(False)
    except Exception as e:
        print('Passed: should error when wrong missing key')
        assert(isinstance(e, ValueError))

    # test right input
    try:
        load('data', 'test.json')
        assert(True)
    except Exception as e:
        print('Failed: should success when right input')
        
    return


# Generated at 2022-06-21 10:54:43.821959
# Unit test for function dump
def test_dump():
    import json
    import os
    import shutil
    import tempfile
    import unittest

    from cookiecutter.replay import dump, load

    class TestReplayDump(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def load_replay_file(self, template_name):
            replay_file = get_file_name(self.tempdir, template_name)
            with open(replay_file, 'r') as infile:
                contents = json.load(infile)
            return contents


# Generated at 2022-06-21 10:54:45.053403
# Unit test for function load
def test_load():
    # TBD
    print('test')
    return

# Generated at 2022-06-21 10:54:55.131136
# Unit test for function dump
def test_dump():
    template_name = 'test_name'
    context = {'test_key': 'value'}
    replay_dir = 'test_dump'
    dump(replay_dir, template_name, context)
    context1 = load(replay_dir, template_name)
    os.remove(get_file_name(replay_dir, template_name))
    print(context)
    print(context1)
    if context == context1:
        print('test_dump passed')
    else:
        print('test_dump failed')



# Generated at 2022-06-21 10:54:58.231731
# Unit test for function load
def test_load():
    """Unit test for function load."""
    result = load('tests/fixtures/replay', 'foobar')
    assert result == {'cookiecutter': {'foo': 'bar'}}



# Generated at 2022-06-21 10:54:59.685368
# Unit test for function load
def test_load():
    try:
        load('./test_data/replay', 'fakereplay')
    except ValueError as err:
        return
    assert False


# Generated at 2022-06-21 10:55:07.365871
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.dirname(os.path.abspath(__file__))
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)

# Generated at 2022-06-21 10:55:15.406256
# Unit test for function dump
def test_dump():
    """Test that the dump() function works."""
    replay_dir = "test_replays"
    template_name = "test_template"
    context = dict(
        cookiecutter={
            "hello": "goodbye"
        }
    )
    if make_sure_path_exists(replay_dir):
        dump(replay_dir, template_name, context)
        with open(get_file_name(replay_dir, template_name), 'r') as file:
            assert file.read() == json.dumps(context, indent=2)



# Generated at 2022-06-21 10:55:18.981052
# Unit test for function dump
def test_dump():
    replay_dir = 'replay_test'
    template_name = 'replay_test'
    context = {'cookiecutter': {'full_name': 'Foo Bar', 'email': 'foo@bar.com'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:55:25.439031
# Unit test for function dump
def test_dump():
    """Tests that the data is dumped."""
    template_name = 'cc_dummy_project'
    replay_dir = os.path.expanduser('~/.cookiecutter_replay')
    context = {'cookiecutter': {'full_name': 'Audrey Roy Greenfeld'}}
    dump(replay_dir, template_name, context)

    # checks if the replay directory is created
    if not os.path.exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))

    # checks if the replay file is created
    if not os.path.exists(get_file_name(replay_dir, template_name)):
        raise IOError('Unable to create replay file at {}'.format(replay_dir))

    # checks that

# Generated at 2022-06-21 10:55:34.655201
# Unit test for function load
def test_load():
    """Unit test for function load"""
    replay_dir = 'tests/files/fake-replay'
    template_name = 'fake-project'


# Generated at 2022-06-21 10:55:42.009879
# Unit test for function dump
def test_dump():
    """Test replay dump function."""
    from tempfile import mkdtemp
    from shutil import rmtree

    temp_dir = mkdtemp()

    template_name = 'template'
    dict_context = dict(cookiecutter)

    try:
        dump(temp_dir, template_name, dict_context)
    except OSError:
        assert False
    else:
        assert True

    rmtree(temp_dir)


# Generated at 2022-06-21 10:55:47.692191
# Unit test for function load
def test_load():
    file_name = get_file_name('C:\\Users\\me\\Downloads\\cookiecutter-flask-master', 'cookiecutter-flask')
    load_context = load('C:\\Users\\me\\Downloads\\cookiecutter-flask-master', 'cookiecutter-flask')
    assert load_context['cookiecutter']['project_name'] == 'Flask Boilerplate'

# Generated at 2022-06-21 10:55:59.247112
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.dirname(__file__), 'tests/fake-replay-dir/')
    template_name = 'fake-project'
    # context = {
    #     'cookiecutter': {
    #         'repo_dir': '.',
    #     },
    #     'full_name': 'Jason Crowe',
    #     'email': 'jasongcrowe@gmail.com',
    # }
    context = {
        'cookiecutter': {
            'repo_dir': '.',
        },
    }

    # assert make_sure_path_exists(replay_dir) == True
    assert isinstance(template_name, str)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context

    replay_

# Generated at 2022-06-21 10:56:10.037025
# Unit test for function load
def test_load():
    import json
    import os

# Generated at 2022-06-21 10:56:13.077827
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "replay"
    template_name = "template_name"
    file_name = "replay/template_name.json"
    assert get_file_name(replay_dir, template_name) == file_name

import pytest
import shutil


# Generated at 2022-06-21 10:56:20.487229
# Unit test for function dump
def test_dump():
    replay = {'cookiecutter': {'full_name': 'test'}}
    template_name = 'test'
    dump('test', template_name, replay)

    assert 'test/.cookiecutters/test.json' in os.listdir('test/.cookiecutters')
    os.remove('test/.cookiecutters/test.json')
    os.rmdir('test/.cookiecutters')
    os.rmdir('test')


# Generated at 2022-06-21 10:56:25.615019
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay'
    test_context = { 'test': 'string', 'test2': 5 }

    dump(replay_dir, 'test_dump', test_context)
    context = load(replay_dir, 'test_dump')

    assert test_context == context


# Generated at 2022-06-21 10:56:28.409143
# Unit test for function load
def test_load():
    context = load(replay_dir, template_name)
    assert type(context) is dict
    assert 'cookiecutter' in context


# Generated at 2022-06-21 10:56:33.042882
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.expanduser('~'), 'Desktop')
    context = {"cookiecutter": {"company_name": "Megacorp, Inc."}}
    template_name = 'test'

    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    os.remove(replay_file)



# Generated at 2022-06-21 10:56:37.980630
# Unit test for function load
def test_load():
    context = load('/Users/lhs/Desktop/cookiecutter-python/cookiecutter-python/', 'pymodule')
    print(context['cookiecutter']['project_slug'])

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-21 10:56:47.516833
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    # Unit test with normal context
    replay_dir_1 = 'tests/test-output/'
    template_name_1 = 'Template'


# Generated at 2022-06-21 10:56:49.353088
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    template_name = 'template'
    assert get_file_name(replay_dir, template_name) == './template.json'



# Generated at 2022-06-21 10:57:06.750941
# Unit test for function dump
def test_dump():
    ctx = {'cookiecutter': {'foo': 'test_foo'}}
    # Store cookie cutter replay file in /home/user
    test_replay_dir = os.path.expanduser("~")
    # Check if replay file already exist, if so remove it
    test_replay_file = os.path.join(test_replay_dir, "cookiecutter_test.json")
    if os.path.isfile(test_replay_file):
        os.remove(test_replay_file)
    # test_dump function
    dump(test_replay_dir, "cookiecutter_test", ctx)
    assert os.path.isfile(test_replay_file) == True
    # Remove replay file after test
    os.remove(test_replay_file)

# Unit

# Generated at 2022-06-21 10:57:11.597648
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/dev/replay'
    template_name = 'cc_template'
    expected_file_name = '/home/dev/replay/cc_template.json'
    assert get_file_name(replay_dir, template_name) == expected_file_name


# Generated at 2022-06-21 10:57:18.730556
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    context = {
        'cookiecutter': {
            'github_username': 'audreyr',
            'project_name': 'cookiecutter-pypackage',
            'release_date': '2013-09-17',
            'version': '0.1.0'
        }
    }
    replays_path = 'tests/test-replays'

    if not make_sure_path_exists(replays_path):
        raise IOError('Unable to create replay dir at {}'.format(replays_path))

    dump(replays_path, 'test_dump', context)
    assert os.path.exists(os.path.join(replays_path, 'test_dump.json'))


# Generated at 2022-06-21 10:57:29.028668
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/files/replay-dir'
    template_name = 'tests/files/replay-dir/cookiecutter.json'
    result = load(replay_dir, template_name)
    true_result = {
        'cookiecutter': {
            'full_name': 'Sher Minn C',
            'email': 'shermin.chow@gmail.com',
            'github_user': 'freakingneat',
            'project_name': 'project_name',
            'project_slug': 'project_slug',
            'project_short_description': 'Project short description',
            'pypi_username': 'sherminchow',
            'release_date': '2015-12-30'
        }
    }

# Generated at 2022-06-21 10:57:35.603689
# Unit test for function dump
def test_dump():
    def test_0_normal_use(self):
        """Test that dump runs without exception and test the written file."""
        replay_dir = 'test-replay-dir'
        template_name = 'zope/zope_app'


# Generated at 2022-06-21 10:57:39.548545
# Unit test for function load
def test_load():
    """Testing load function."""
    file_name = "./demo/template.json"
    with open(file_name, 'r') as infile:
        context = json.load(infile)
        print(context)


# Generated at 2022-06-21 10:57:45.803430
# Unit test for function get_file_name
def test_get_file_name():
    path = os.path.abspath(__file__)
    new_path = path + "/test_get_file_name/"
    if not os.path.exists(new_path):
        os.makedirs(new_path)

    assert get_file_name(new_path, "testName") == get_file_name(new_path, "testName.json") == new_path + "testName.json"

# Generated at 2022-06-21 10:57:52.247240
# Unit test for function load
def test_load():
    try:
        load('wrong_dir', 't')
    except: 
        pass
    try:
        load('./tests', 'wrong')
    except:
        pass
    
    try:
        load('./tests', 'test')
        print ('SUCCESS')
    except:
        pass
    try:
        load('./tests', 'test_replay_name')
        print ('SUCCESS')
    except:
        pass

# Generated at 2022-06-21 10:58:03.865608
# Unit test for function get_file_name
def test_get_file_name():

    #Test Case1 : Replay directory not exist
    replay_dir = 'not_exist_dir'
    template_name = 'fake_template_name'
    expected_result = 'not_exist_dir/fake_template_name.json'
    actual_result = get_file_name(replay_dir, template_name)
    if actual_result != expected_result:
        print('test_get_file_name Case1 failed')

    # Test Case2 : Replay directory exist
    replay_dir = './test'
    template_name = 'fake_template_name'
    expected_result = './test/fake_template_name.json'
    actual_result = get_file_name(replay_dir, template_name)

# Generated at 2022-06-21 10:58:07.164001
# Unit test for function load
def test_load():
    replay_dir=os.path.dirname(os.path.abspath(__file__))
    template_name='python_cli'
    context=load(replay_dir,template_name)
    print(context)
    return None


# Generated at 2022-06-21 10:58:27.078158
# Unit test for function dump
def test_dump():
    replay_dir = './'
    template_name = 'python_package'

# Generated at 2022-06-21 10:58:29.957771
# Unit test for function get_file_name
def test_get_file_name():
    file_name = get_file_name('test','test')
    assert file_name == 'test/test.json'


# Generated at 2022-06-21 10:58:32.522437
# Unit test for function dump
def test_dump():
    """testing dump() function."""
    try:
        dump("", "", {"cookiecutter": {}})
    except TypeError as e:
        print("Error Occured")



# Generated at 2022-06-21 10:58:37.647810
# Unit test for function load
def test_load():
    """Unit test for function load."""
    ctx = {'cookiecutter': {'name': 'eskimotiger'}}
    dir = "/Users/qingfeng/.cookiecutters/"
    template_name = 'python-template'
    dump(dir, template_name, ctx)
    assert load(dir, template_name) == ctx


# Generated at 2022-06-21 10:58:41.930601
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '{{ cookiecutter.project_slug }}'
    template_name = 'template_name'
    suffix = '.json' if not template_name.endswith('.json') else ''
    file_name = '{}{}'.format(template_name, suffix)
    assert replay_dir == '{{ cookiecutter.project_slug }}'
    assert template_name == 'template_name'
    assert suffix == '.json' 
    assert file_name == 'template_name.json'
    assert os.path.join(replay_dir,file_name) == '{{ cookiecutter.project_slug }}.json'


# Generated at 2022-06-21 10:58:51.559216
# Unit test for function dump
def test_dump():
    # Create dictionary to be added.
    context = {"cookiecutter": {'full_name': 'Daniel Persson', 'email': 'daniel@example.com'}}
    replay_dir = 'tests/files/replay'
    template_name = 'example'
    # Dump dictionary to file.
    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)
    # Check if file exists and is not empty.
    if os.stat(replay_file).st_size == 0:
        raise Exception('The file is empty.')
    # Check if file can be opened.
    try:
        with open(replay_file, 'r') as infile:
            pass
    except IOError:
        raise Exception('Cannot open file')

# Generated at 2022-06-21 10:59:00.519374
# Unit test for function dump
def test_dump():
    test_replay_dir = '/tmp/.cookiecutters_replay'
    test_template_name = 'test_template'
    test_context = {'cookiecutter': {'test_key': 'test_value'}}
    dump(test_replay_dir, test_template_name, test_context)

    assert os.path.exists(get_file_name(test_replay_dir, test_template_name))
    assert os.path.isdir(test_replay_dir)


# Generated at 2022-06-21 10:59:03.957545
# Unit test for function dump
def test_dump():
    context = {'name': 'crossin', 'email': 'test@test.com'}
    dump('/Users/crossin/Downloads/test/', 'test', context)



# Generated at 2022-06-21 10:59:07.608438
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for get_file_name."""
    assert get_file_name('/tmp', 'my-repo') == "/tmp/my-repo.json"
    assert get_file_name('/tmp', 'my-repo.json') == "/tmp/my-repo.json"


# Generated at 2022-06-21 10:59:19.547243
# Unit test for function dump
def test_dump():
    from cookiecutter import replay
    replay_dir = './tests/files/test-replay'
    template_name = './tests/files/test-template'

# Generated at 2022-06-21 10:59:46.322079
# Unit test for function get_file_name
def test_get_file_name():
    """Verify that get_file_name function returns expected file name."""
    assert get_file_name('/home/user/replay', 'python-package') == '/home/user/replay/python-package.json'
    assert get_file_name('/home/user/replay', 'python-package.json') == '/home/user/replay/python-package.json'



# Generated at 2022-06-21 10:59:50.341534
# Unit test for function get_file_name
def test_get_file_name():
    test_dir = os.path.expanduser('~')
    test_template_name = 'PyPI-Publish'

    test_file_name = get_file_name(test_dir, test_template_name)
    assert test_file_name == os.path.expanduser('~/PyPI-Publish.json')

# Generated at 2022-06-21 10:59:57.139554
# Unit test for function dump
def test_dump():
    # create a directory
    import tempfile
    temp_dir = tempfile.mkdtemp()
    replay_dir = os.path.join(temp_dir, 'replay_dir')
    template_name = 'template'
    context={'cookiecutter': {'first_name': 'Audrey', 'last_name': 'Roy'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(replay_dir)

    # create a directory to replace
    replay_dir = os.path.join(temp_dir, 'replay_dir')
    template_name = 'template'
    context={'cookiecutter': {'first_name': 'Audrey', 'last_name': 'Roy'}}
    dump(replay_dir, template_name, context)

# Generated at 2022-06-21 10:59:59.653178
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/', 'test.json') == '/test.json'
    assert get_file_name('/', 'test') == '/test.json'


# Generated at 2022-06-21 11:00:08.193941
# Unit test for function get_file_name
def test_get_file_name():
    """Test for function get_file_name()."""
    #
    # Input value: replay_dir = "replay_example"
    #              template_name = "template_1"
    # Expected output: os.path.join(replay_dir, "template_1.json")
    #
    replay_dir = os.path.join("replay_example")
    make_sure_path_exists(replay_dir)
    template_name = "template_1"
    file_name = get_file_name(replay_dir, template_name)
    file_name_result = os.path.join("replay_example", "template_1.json")
    assert(file_name == file_name_result)
    os.removedirs("replay_example")

    #
    # Input value

# Generated at 2022-06-21 11:00:12.358755
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '~/.cookiecutter_replay'
    template_name = 'pypackage'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '~/.cookiecutter_replay/pypackage.json', 'Wrong file name'

# Generated at 2022-06-21 11:00:17.822228
# Unit test for function load
def test_load():
    assert(type(load(replay_dir,'/Users/tony/Desktop/Cookiecutter')) == dict)
    assert(len(load(replay_dir,'/Users/tony/Desktop/Cookiecutter')) > 0)
    assert('cookiecutter' in load(replay_dir,'/Users/tony/Desktop/Cookiecutter'))


# Generated at 2022-06-21 11:00:19.930025
# Unit test for function get_file_name
def test_get_file_name():
    template_name = "test"
    replay_dir = "/tmp/cookiecutter-replay"
    get_file_name(replay_dir, template_name)


# Generated at 2022-06-21 11:00:24.715319
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay', 'test') == 'replay/test.json'
    assert get_file_name('replay', 'test.json') == 'replay/test.json'
    assert get_file_name('replay/', 'test.json') == 'replay/test.json'


# Generated at 2022-06-21 11:00:26.717044
# Unit test for function load
def test_load():
    assert load(replay_dir='.', template_name='filename') == None


# Generated at 2022-06-21 11:01:15.444696
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = "test_load"
    load(replay_dir, template_name)



# Generated at 2022-06-21 11:01:18.442120
# Unit test for function load
def test_load():
    """Unit test function."""
    template_name = "replay"
    replay_dir = "./tests/files"
    context = load(replay_dir, template_name)


# Generated at 2022-06-21 11:01:24.363952
# Unit test for function get_file_name
def test_get_file_name():
    test_replay_dir = "/Users/apple/workspace/Cookiecutter/cookiecutter/tests/test_files"
    test_template_name = "test_template"
    result = get_file_name(test_replay_dir, test_template_name)
    print(result)
    assert result == "/Users/apple/workspace/Cookiecutter/cookiecutter/tests/test_files/test_template.json"


# Generated at 2022-06-21 11:01:33.451094
# Unit test for function load
def test_load():
    replay_dir = './tests/files/cookiecutter-load/replay'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014/07/22'


# Generated at 2022-06-21 11:01:40.656370
# Unit test for function load
def test_load():
    print("----Testing load----")
    if(load('.', 'cookiecutter-pypackage') == {'cookiecutter': {'full_name': 'Audrey Roy Greenfeld', 'email': 'audreyr@example.com', 'project_name': 'cookiecutter-pypackage'}}):
        print("----load passed----")
    else:
        print("----load failed----")


# Generated at 2022-06-21 11:01:44.864071
# Unit test for function load
def test_load():
    """Unit test for function load

    Call function load to get a replay context.
    """
    # Call function load to get a replay context
    context = load(r'./replay', 'cookiecutter-pypackage')

    # Print the replay context
    print(context)



# Generated at 2022-06-21 11:01:47.579080
# Unit test for function load
def test_load():
    replay_dir = 'tests/files/tests/replay'
    template_name = 'tests'
    context = load(replay_dir, template_name)
    print(context)



# Generated at 2022-06-21 11:01:51.657855
# Unit test for function load
def test_load():
    context = load('/Users/rohitsinha/PycharmProjects/cookiecutter-graphene/tests/test-load-replay', 'test-load-replay')
    assert isinstance(context, dict)
    assert 'cookiecutter' in context

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-21 11:01:54.146949
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/opt', 'bob') == '/opt/bob.json'
    assert get_file_name('/opt', 'bob.json') == '/opt/bob.json'

# Generated at 2022-06-21 11:01:58.462123
# Unit test for function load
def test_load():
  context = load("C:\\users\\hbrad\\projetos", "templates\\python-package")
  print(context)

# test_load()