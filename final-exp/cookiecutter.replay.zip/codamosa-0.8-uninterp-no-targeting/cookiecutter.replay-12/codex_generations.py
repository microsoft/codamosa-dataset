

# Generated at 2022-06-21 10:53:00.529008
# Unit test for function load
def test_load():
        template_name = "python-app"
        replay_dir = ""
        try:
            replay_context = load(replay_dir,template_name)
        except:
            print("Testing load function: no exception raised, test passed")
        else:
            print("Testing load function: exception raised, test passed")
            

# Generated at 2022-06-21 10:53:08.209694
# Unit test for function load
def test_load():
    template_name = '{{ cookiecutter.project_name }}'
    replay_dir = '{{ cookiecutter.replay_dir }}'
    context = {
        'cookiecutter': {
            'project_name': 'julian',
            'replay_dir': 'replays'
        }
    }
    dump(replay_dir, template_name, context)

    actual = load(replay_dir, template_name)
    assert actual == context

# Generated at 2022-06-21 10:53:12.058718
# Unit test for function load
def test_load():
    replay_dir = '~/.cookiecutter_replay'
    template_name = 'python_boilerplate'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context



# Generated at 2022-06-21 10:53:16.346866
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""

    # Check a replay file with no suffix
    replay_dir = "replay"
    template_name = "test_template"
    replay_file = get_file_name(replay_dir, template_name)
    assert replay_file == "replay/test_template.json"

    # Check a replay file with a suffix
    replay_dir = "replay"
    template_name = "test_template.json"
    replay_file = get_file_name(replay_dir, template_name)
    assert replay_file == "replay/test_template.json"


# Generated at 2022-06-21 10:53:19.212068
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('.cookiecutters', 'foo') == \
        '.cookiecutters/foo.json'



# Generated at 2022-06-21 10:53:21.803993
# Unit test for function get_file_name
def test_get_file_name():
    """Get the name of file."""
    template_name = 'abc'
    replay_dir = '/tmp/replay/'
    assert get_file_name(replay_dir, template_name) == '/tmp/replay/abc.json'

# Generated at 2022-06-21 10:53:32.383759
# Unit test for function dump
def test_dump():
    """Test the dump function with a simple replay file."""
    replay_dir = os.path.join(os.path.expanduser('~'),
                              '.cookiecutters')
    template_name = 'cookiecutter-pypackage'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'project_name': 'cookiecutter-pypackage'
        }
    }

    test_replay_file = os.path.join(replay_dir, 'cookiecutter-pypackage.json')

    # Cleanup test replay file
    if os.path.exists(test_replay_file):
        os.remove(test_replay_file)


# Generated at 2022-06-21 10:53:38.293522
# Unit test for function load
def test_load():
    """Test loading replay file."""
    replay_dir = '/home/vagrant/uploads/replay'
    template_name = 'python_boilerplate'
    context = load(replay_dir, template_name)
    # Test a random key
    assert context['cookiecutter']['email'] == 'hi@example.com', 'Not loading replay file correctly'


# Generated at 2022-06-21 10:53:42.485694
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/tmp/cookiecutters', 'foo-bar') == '/tmp/cookiecutters/foo-bar.json'
    assert get_file_name('/tmp/cookiecutters', 'foo-bar.json') == '/tmp/cookiecutters/foo-bar.json'



# Generated at 2022-06-21 10:53:47.997977
# Unit test for function load
def test_load():
    template_name = 'hello'
    replay_dir = 'test_replay'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context, "The context does not contain 'cookiecutter'"
    assert '_template' in context['cookiecutter'], "The context['cookiecutter'] does not contain '_template'"
    assert not template_name in context['cookiecutter']['_template'], "template_name is in context['cookiecutter']['_template']"


# Generated at 2022-06-21 10:53:56.594419
# Unit test for function load
def test_load():
    """Unit test for function load.

    Sign: None -> dict
    """
    from tempfile import gettempdir
    from os import path

    replay_dir = gettempdir()
    template_name = path.join(replay_dir, 'test')
    context = {'cookiecutter': {'name': 'ivan'}}

    dump(replay_dir, template_name, context)
    assert context == load(replay_dir, template_name)


# Generated at 2022-06-21 10:54:02.175299
# Unit test for function get_file_name
def test_get_file_name():
    '''
    In the test, I used an existing replay dir and an existing context
    to test the correctness of this function.
    '''
    replay_dir = '/Users/Yi/cookiecutter-pytest/tests/test-replay/'
    template_name = 'cookiecutter-pypackage'

    assert get_file_name(replay_dir, template_name) == '/Users/Yi/cookiecutter-pytest/tests/test-replay/cookiecutter-pypackage.json'

# Generated at 2022-06-21 10:54:06.750576
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'C:\\Users\\Jeremy\\Desktop\\replay_test\\'
    template_name = 'test'
    result = get_file_name(replay_dir, template_name)
    print(result)

# Generated at 2022-06-21 10:54:16.223759
# Unit test for function dump
def test_dump():
    """Unit test for function dump()."""
    import os, shutil
    replay_dir = 'tests/files/unit_tests/replay_dir'
    shutil.rmtree(replay_dir)
    os.makedirs(replay_dir)
    template_name = 'test_template'
    context = {'cookiecutter': {'test_name1': 'test_value1', 'test_name2': 'test_value2'}}
    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)
    shutil.rmtree(replay_dir)



# Generated at 2022-06-21 10:54:20.816820
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/replay'
    template_name = 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    context = {
        "cookiecutter": {
            "repo_name": "example_repo",
            "project_name": "Example Project",
            "project_slug": "example_project",
            "author_name": "Your Name",
            "email": "you@example.com",
            "description": "A short description of the project.",
            "domain_name": "example.com",
            "version": "0.1.0",
            "timezone": "UTC",
            "use_pycharm": "y",
            "license": "MIT",
        }
    }
    dump(replay_dir, template_name, context)

# Generated at 2022-06-21 10:54:33.929835
# Unit test for function load

# Generated at 2022-06-21 10:54:36.561648
# Unit test for function get_file_name
def test_get_file_name():
    filename =  get_file_name("dir", "dir")
    assert filename == "dir/dir.json"


# Generated at 2022-06-21 10:54:39.739430
# Unit test for function load
def test_load():
    replay_dir = '/Users/ruan/tmp_project/tmp'
    template_name = 'test.json'
    context = load(replay_dir, template_name)
    assert context['cookiecutter'] == {}

# Generated at 2022-06-21 10:54:47.671023
# Unit test for function dump
def test_dump():
    replay_dir = './tests/test_dump_replay'
    template_name = 'tests/test_dump'
    context = {
        'cookiecutter': {
            'full_name': 'Test Dump',
            'email': 'test@email.com'
        }
    }
    dump(replay_dir, template_name, context)
    expected_file_name = get_file_name(replay_dir, template_name)
    assert os.path.isfile(expected_file_name) == True



# Generated at 2022-06-21 10:54:52.445607
# Unit test for function dump
def test_dump():
    _replay_dir = os.path.abspath('./replay_dir')
    _template_name = 'test_template'
    _context = {'cookiecutter': {'a': 1}}
    dump(_replay_dir, _template_name, _context)


# Generated at 2022-06-21 10:55:01.718712
# Unit test for function dump
def test_dump():
    test_dict = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    replayedict = {'cookiecutter': test_dict}
    # Create a new directory to dump temp files
    replay_dir = 'tmp_replay'
    template_name = 'tmp_template'
    dump(replay_dir, template_name, replayedict)
    replay = load(replay_dir, template_name)
    assert replay == replayedict
    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-21 10:55:04.148434
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('.', 'test_template') == './test_template.json'
    assert get_file_name('.', 'test_template.json') == './test_template.json'

# Generated at 2022-06-21 10:55:13.435479
# Unit test for function load
def test_load():
    cwd = os.path.abspath(os.path.dirname(__file__))
    raw_path = os.path.join(cwd, '..', '..',)
    template_dir = os.path.join(raw_path, 'tests', 'test-templates', 'fake-repo-tmpl')
    context = load(template_dir, template_dir)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'

# Generated at 2022-06-21 10:55:16.021478
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "replay"
    file_name = "example.json"
    assert get_file_name(replay_dir,file_name) == os.path.join(replay_dir, file_name)

# Generated at 2022-06-21 10:55:18.476927
# Unit test for function load
def test_load():
    assert load(replay_dir='/Users/xin/Desktop/Cookiecutter/cookiecutter-3/cookiecutter/replay', template_name='test.json')['cookiecutter'] == 'cookiecutter'

# Generated at 2022-06-21 10:55:21.031455
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'C:\\Users\\Yi\\CODE\\cookiecutter\\'
    template_name = 'tem'
    my_file = get_file_name(replay_dir, template_name)

    print(my_file)

# Generated at 2022-06-21 10:55:26.716821
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir_1 = os.path.abspath("../tests")
    template_name_1 = "cookiecutter-pypackage"
    file_name_1 = get_file_name(replay_dir_1, template_name_1)
    assert file_name_1 == os.path.join(replay_dir_1, "cookiecutter-pypackage.json")
    template_name_2 = "cookiecutter-pypackage.json"
    file_name_2 = get_file_name(replay_dir_1, template_name_2)
    assert file_name_2 == os.path.join(replay_dir_1, "cookiecutter-pypackage.json")


# Generated at 2022-06-21 10:55:30.430964
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'path/to/replay'
    template_name = 'my_template'
    assert get_file_name(replay_dir, template_name) == 'path/to/replay/my_template.json'


# Generated at 2022-06-21 10:55:37.712800
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'home/foo/bar'
    template_name = 'baz.txt'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'home/foo/bar/baz.txt.json'
    template_name = 'baz.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'home/foo/bar/baz.json'


# Generated at 2022-06-21 10:55:44.473407
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.expanduser('~/.cookiecutter_replay')
    template_name = 'cookiecutter-pypackage'
    assert os.path.join(replay_dir, template_name + '.json') == get_file_name(replay_dir, template_name)
    template_name += '.json'
    assert os.path.join(replay_dir, template_name) == get_file_name(replay_dir, template_name)


# Generated at 2022-06-21 10:55:55.292202
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/test/dev/cookiecutter'
    template_name = 'abcd'
    expected_result = '/home/test/dev/cookiecutter/abcd.json'
    result = get_file_name(replay_dir, template_name)
    assert result == expected_result
    template_name = 'abcd.json'
    expected_result = '/home/test/dev/cookiecutter/abcd.json'
    result = get_file_name(replay_dir, template_name)
    assert result == expected_result


# Generated at 2022-06-21 10:55:58.941258
# Unit test for function dump
def test_dump():
    replay_dir = '/Users/fernandaquagliata/PycharmProjects/cookiecutter-django-crud/cookiecutter_replays'
    template_name = 'my_dump'
    context = {'cookiecutter': {'name': 'Fernanda'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:56:03.667205
# Unit test for function load
def test_load():
    context = load(r"/Users/yizhang/PycharmProjects/Cookiecutter_Homework/cookiecutter/replay", "cookiecutter")
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-21 10:56:09.964060
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    replay_dir = 'tests'
    template_name = 'template'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'tests/template.json'

    template_name = 'template.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'tests/template.json'



# Generated at 2022-06-21 10:56:14.081426
# Unit test for function get_file_name
def test_get_file_name():
    test_replay_dir = './tests/files/'
    test_template_name = 'test_template'
    expected_output = '{}{}'.format(test_replay_dir, test_template_name + '.json')
    actual_output = get_file_name(test_replay_dir, test_template_name)
    assert actual_output == expected_output

if __name__ == "__main__":
    test_get_file_name()

# Generated at 2022-06-21 10:56:16.112979
# Unit test for function load
def test_load():
    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-21 10:56:20.127526
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/cookiecutter_replay_dir'
    template_name = 'template'
    assert get_file_name(replay_dir, template_name) == '/cookiecutter_replay_dir/template.json'

# Generated at 2022-06-21 10:56:28.262024
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    replay_dir = '/Users/paul.rudin/cookiecutter'

    expected_output = '/Users/paul.rudin/cookiecutter/https://github.com/audreyr/cookiecutter-pypackage.git.json'

    output = get_file_name(replay_dir, template_name)
    assert output == expected_output, "Expected {} but got {}".format(expected_output, output)

# Generated at 2022-06-21 10:56:34.142766
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    context = {
        "cookiecutter": {
            "author_email": "harry@harry.com",
            "author_name": "harry",
            "year": "2020",
            "version": "0.1.0"
        }
    }

    replay_dir = './test_dump'
    template_name = './test_dump/test_dump'

    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)

    assert context == context_loaded


# Generated at 2022-06-21 10:56:42.362620
# Unit test for function dump
def test_dump():
    path = os.getcwd() + '\\proj1\\'
    name = 'proj1'
    json_file = {
        'cookiecutter': {
            'author_name': 'abc',
            'project_name': 'proj1',
            'repo_name': 'proj1'
        }
    }
    dump(path, name, json_file)
    assert os.path.exists(path+name+'.json')
    assert os.path.isfile(path+name+'.json')


# Generated at 2022-06-21 10:56:50.790539
# Unit test for function dump
def test_dump():
    replay_dir = 'demo'
    template_name = 'demo_testdump_replay'
    context = {'cookiecutter': {'a': 1, 'b':2}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:56:53.123943
# Unit test for function dump
def test_dump():
    dump('./fixtures/test-output/', 'test-replay', {'cookiecutter':'dump'})


# Generated at 2022-06-21 10:57:05.352536
# Unit test for function dump
def test_dump():
    """
    Unit test for function dump.

    test_dump()
    """
    from cookiecutter import replay
    from cookiecutter import utils

    REPLAY_DIR = 'tests/test-replay'
    TEMPLATE_NAME = 'tests/fake-repo-tmpl'
    CONTEXT = {
        'cookiecutter': {
            'hello': 'world',
            'number': 42,
            'foo': True,
            'bar': False,
        }
    }
    replay.dump(REPLAY_DIR, TEMPLATE_NAME, CONTEXT)
    assert utils.file_exists(replay.get_file_name(REPLAY_DIR, TEMPLATE_NAME))
    utils.rmtree(REPLAY_DIR)



# Generated at 2022-06-21 10:57:06.076877
# Unit test for function load
def test_load():
    pass

# Generated at 2022-06-21 10:57:16.286128
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter import replay
    replay_dir = os.path.join(os.getcwd(), 'tests/test-replay/')

# Generated at 2022-06-21 10:57:21.765081
# Unit test for function get_file_name
def test_get_file_name():
    # Get the name of file
    replay_dir = '~/cookiecutter-templates/'
    template_name = 'cookiecutter-pypackage'
    assert get_file_name(replay_dir, template_name) == '~/cookiecutter-templates/cookiecutter-pypackage.json'

test_get_file_name()

# Generated at 2022-06-21 10:57:23.923048
# Unit test for function load
def test_load():
    """Test the load function."""
    assert load('replay_dir', 'template_name')


# Generated at 2022-06-21 10:57:32.350921
# Unit test for function dump
def test_dump():
    replay_dir = os.path.abspath('./tests/test_replay')
    template_name = 'test_template'
    context = {
        'cookiecutter': {
            'key1': 'val1',
            'key2': ['val2_1', 'val2_2', 'val2_3']
        }
    }
    file_name = '{}.json'.format(template_name)
    expected_replay_file = os.path.join('tests', 'test_replay', file_name)

    # Round 1: Create a new file
    dump(replay_dir, template_name, context)
    assert os.path.exists(expected_replay_file)

    # Round 2: Existing file should be overwritten

# Generated at 2022-06-21 10:57:35.593369
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/root', 'template1') == '/root/template1.json'
    assert get_file_name('/root', 'template1.json') == '/root/template1.json'



# Generated at 2022-06-21 10:57:40.339073
# Unit test for function load
def test_load():
    context = load('tests/fixtures/fake-replay-dir/', 'fake-template-repo')

    assert isinstance(context, dict), 'Replay should be of type dict'

    assert 'cookiecutter' in context, 'Context should contain a cookiecutter key'



# Generated at 2022-06-21 10:57:49.860481
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = 'file_name'
    template_name = 'file.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'file_name/file.json'



# Generated at 2022-06-21 10:57:55.377973
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name"""
    # get_file_name(replay_dir, template_name)
    replay_dir = 'static'
    template_name = 'cookiecutter-pypackage'
    result = get_file_name(replay_dir, template_name)
    assert result == 'static\\cookiecutter-pypackage.json'
    assert not result == 'static\\cookiecutter-pypackage'
    assert isinstance(result, str)


# Generated at 2022-06-21 10:57:57.600362
# Unit test for function load
def test_load():
    ctx = load('./', './tests/test-template/test-template.json')
    assert ctx
    assert ctx['project_name'] == 'example'
    assert ctx['_template'] == './tests/test-template/'


# Generated at 2022-06-21 10:58:04.086862
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/home/mra"
    template_name = "cookiecutter-pypackage-minimal"
    file_name = "cookiecutter-pypackage-minimal.json"
    if get_file_name(replay_dir, template_name) == file_name:
        print("Unit test for function get_file_name is successfull")
    else:
        print("Unit test for function get_file_name is failed")

# Generated at 2022-06-21 10:58:08.119218
# Unit test for function dump
def test_dump():
    import tempfile
    from cookiecutter.main import cookiecutter
    template = 'tests/test-repo-tmpl'
    context = {
        'full_name': 'Vinicius Santana',
        'email': 'vinicius.santana@outlook.com',
        'github_username': 'ViniciusSantana',
        'project_name': 'A test project',
        'project_slug': 'a-test-project',
        'pypi_username': 'ViniciusSantana',
        'release_date': '2018-01-01',
        'year': '2018',
        'version': '1.2.3',
    }
    replay_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 10:58:11.461734
# Unit test for function load
def test_load():
    test_context = load('replay', 'audrey-test')
    assert 'audrey-test' in test_context
    assert test_context['audrey-test']['repo_name'] == 'test'

# Generated at 2022-06-21 10:58:21.534341
# Unit test for function dump
def test_dump():
    replay_dir = '/Users/peng/gestalt-docs/cookiecutter-gestalt-markdown'
    template_name = 'gestalt-markdown'

# Generated at 2022-06-21 10:58:25.710245
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/tests-data/replay'
    template_name = 'replay'
    context = load(replay_dir, template_name)
    assert context['cookiecutter'] == "I'm a replay file"
    assert context['extra1'] == 'extra 1'

# Generated at 2022-06-21 10:58:36.615475
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    # Test whether get_file_name get the file_name correctly
    template_name = "sample.json"
    replay_dir = os.getcwd()
    file_path = os.path.join(replay_dir, template_name)

    test_file_path = get_file_name(replay_dir, template_name)
    assert file_path == test_file_path

    # Test file name with no suffix ".json"
    template_name = "sample"
    file_path = os.path.join(replay_dir, template_name) + '.json'

    test_file_path = get_file_name(replay_dir, template_name)
    assert file_path == test_file_path

    # Test whether get_file_name raise error

# Generated at 2022-06-21 10:58:37.151838
# Unit test for function load
def test_load():
    json.load()

# Generated at 2022-06-21 10:58:56.171313
# Unit test for function get_file_name
def test_get_file_name():
    """Test for function get_file_name in cookies."""
    replay_dir = "path/to/replay_dir"
    template_name = "template1"
    template_name_json = "template1.json"
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, "template1.json")
    assert get_file_name(replay_dir, template_name_json) == os.path.join(replay_dir, "template1.json")

# Generated at 2022-06-21 10:59:01.098923
# Unit test for function load
def test_load():
    replay_dir = 'tests/fake-repo-tmpl'
    template_name = 'fake_qa'
    context = load(replay_dir, template_name)
    assert context is not None
    assert 'cookiecutter' in context
    assert 'project_name' in context['cookiecutter']


# Generated at 2022-06-21 10:59:07.407296
# Unit test for function load
def test_load():
    test_dir = os.path.dirname(__file__)
    tests_dir = os.path.abspath(os.path.join(test_dir, os.path.pardir))
    replay_dir= os.path.join(tests_dir, 'replay')
    template_name = 'tests/fake-repo-pre'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context



# Generated at 2022-06-21 10:59:19.249079
# Unit test for function dump
def test_dump():
    """test function."""
    # asserts
    assert make_sure_path_exists('test_replay') == True
    assert make_sure_path_exists('test_replay') == False
    assert make_sure_path_exists('./test_replay') == True
    assert make_sure_path_exists('~/test_replay') == True


# Generated at 2022-06-21 10:59:24.910290
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay_dir', 'template') == 'replay_dir/template.json'
    assert get_file_name('replay_dir', 'template.json') == 'replay_dir/template.json'
    assert get_file_name('replay_dir', 'template.json.json') == 'replay_dir/template.json.json'

# Generated at 2022-06-21 10:59:28.104068
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "test_replay"
    template_name = "test_template"
    assert get_file_name(replay_dir, template_name) == "test_replay/test_template.json"



# Generated at 2022-06-21 10:59:31.654464
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('foo/', 'bar') == 'foo/bar.json'
    assert get_file_name('foo/', 'bar.json') == 'foo/bar.json'
    assert get_file_name('foo/', 'bar.yaml') == 'foo/bar.yaml.json'

# Generated at 2022-06-21 10:59:37.069369
# Unit test for function dump
def test_dump():
    """
    Test the dump function in cookiecutter.replay
    """
    REPLAY_DIR = '/tmp/tests/cookiecutter/replay'
    TEMPLATE_NAME = 'fake-template'
    CONTEXT = {
        'cookiecutter': {
            'full_name': 'ACME',
            'email': 'acme@example.com',
        }
    }
    dump(REPLAY_DIR, TEMPLATE_NAME, CONTEXT)
    assert os.path.exists(get_file_name(REPLAY_DIR, TEMPLATE_NAME))


# Generated at 2022-06-21 10:59:40.714851
# Unit test for function load
def test_load():
    """Tests if load() works in replay.py"""
    # Load in the json file with saved information
    context = load("replay", "my-project")

    # Check to see if the json file has been accessed
    assert context is not None
    assert context

# Generated at 2022-06-21 10:59:48.210414
# Unit test for function load
def test_load():
    path = os.path.abspath(os.path.dirname(__file__))
    replay_dir = os.path.abspath(os.path.join(path, '../test/'))
    template = 'foobar'
    context = {'cookiecutter': {'foo': 'bar'}}
    replay_file = get_file_name(replay_dir, template)
    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)
    r_context = load(replay_dir, template)
    assert r_context == context
    os.remove(replay_file)


# Generated at 2022-06-21 11:00:20.331381
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    test_replay_dir_1 = '/test/replay/'
    test_template_name_1 = 'replay_template'
    expected_file_name_1 = '/test/replay/replay_template.json'
    assert get_file_name(test_replay_dir_1, test_template_name_1) == expected_file_name_1

    test_replay_dir_2 = '/test/replay/'
    test_template_name_2 = 'replay_template.json'
    expected_file_name_2 = '/test/replay/replay_template.json'
    assert get_file_name(test_replay_dir_2, test_template_name_2) == expected_file_name_2




# Generated at 2022-06-21 11:00:23.255570
# Unit test for function load
def test_load():
    if load('/home/test/test/test', 'test.json').cookiecutter is not None:
        return True
    else:
        return False


# Generated at 2022-06-21 11:00:27.534855
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'testcases/replaygithub_dir'
    template_name = 'test.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'testcases/replaygithub_dir/test.json'


# Generated at 2022-06-21 11:00:29.669315
# Unit test for function load
def test_load():
    template_name = 'example_cookiecutter'
    replay_dir = 'replay'
    assert isinstance(load(replay_dir, template_name), dict)


# Generated at 2022-06-21 11:00:34.127099
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('./tests/replay', 'cookiecutter-jenkins') == './tests/replay/cookiecutter-jenkins.json'
    assert get_file_name('./tests/replay', 'cookiecutter-dummy-master.json') == './tests/replay/cookiecutter-dummy-master.json'

# Generated at 2022-06-21 11:00:39.717969
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for get_file_name."""
    assert get_file_name('/tmp', 'cc_test') == '/tmp/cc_test.json'
    assert get_file_name('/tmp/', 'cc_test.json') == '/tmp/cc_test.json'
    assert get_file_name('/tmp', 'cc_test.json') == '/tmp/cc_test.json'
    assert get_file_name('/tmp/', 'cc_test') == '/tmp/cc_test.json'


# Generated at 2022-06-21 11:00:42.167078
# Unit test for function get_file_name
def test_get_file_name():
  replay_dir='/Users/sarvesh/Documents/workspace/python'
  template_name='template1'
  print(get_file_name(replay_dir, template_name))



# Generated at 2022-06-21 11:00:46.238497
# Unit test for function dump
def test_dump():
    replay_dir = os.path.expanduser('~/.cookiecutter_replay/')
    template_name = 'test'
    context = {'cookiecutter': {'project_name': 'test'}}
    try:
        dump(replay_dir, template_name, context)
    except Exception as e:
        print(e)



# Generated at 2022-06-21 11:00:55.453559
# Unit test for function get_file_name
def test_get_file_name():
	# TEST 1: generate name for file - returns 1 as it works as expected
	assert get_file_name("/home/cookiecutter/replays", "cjdns") == '/home/cookiecutter/replays/cjdns.json'
	
	# TEST 2: generate name for file with .json suffix - returns 1 as it works as expected
	assert get_file_name("/home/cookiecutter/replays", "cjdns.json") == '/home/cookiecutter/replays/cjdns.json'
	
	# TEST 3: passing template_name of type int - returns 0 as it raises TypeError
	try:
		get_file_name("/home/cookiecutter/replays", 123)
	except TypeError:
		assert 0
	except:
		assert 1
	

# Generated at 2022-06-21 11:01:02.026118
# Unit test for function dump
def test_dump():
    replay_dir = "/Users/fangjiazhi/Desktop/replay"
    template_name = "test"
    context = {"cookiecutter": {
        "cookiecutter.replay_dir": "../",
        "cookiecutter.output_dir": "../../{{cookiecutter.repo_name}}"
    }}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 11:01:53.623334
# Unit test for function load
def test_load():
    replay_dir = '/home/mqp/code/cookiecutter'
    template_name = 'replay-default'
    context = load(replay_dir, template_name)
    print(context)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-21 11:01:59.530925
# Unit test for function dump
def test_dump():
    print("dump")
    # prepare
    template_name = "test"
    replay_dir = "replay/"
    context = {'cookiecutter': {'name': 'Daniel', 'project_name': 'TestProject'}}
    # execute
    dump(replay_dir, template_name, context)
    # assert
    print("dump done")


# Generated at 2022-06-21 11:02:06.274227
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = './tests/test-replay'
    template_name = 'test'
    expected = './tests/test-replay/test.json'
    assert get_file_name(replay_dir, template_name) == expected
# end of function test_get_file_name



# Generated at 2022-06-21 11:02:08.791416
# Unit test for function dump
def test_dump():
    template_name = "test"
    context = {"cookiecutter": {}}
    replay_dir = 'test'
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 11:02:12.780130
# Unit test for function get_file_name
def test_get_file_name():
    try:
        replay_dir = os.path.join(os.path.expanduser('~'), 'cc_replay')
        assert replay_dir == get_file_name('~/cc_replay', 'test_template')
    except IOError as e1:
        print(e1)


# Generated at 2022-06-21 11:02:14.490142
# Unit test for function load
def test_load():
    context = load('~/.cookiecutters', 'qing-cookiecutter-demo')

# Generated at 2022-06-21 11:02:25.353271
# Unit test for function load
def test_load():
    """Test load function."""
    r = load('tests/test-data/fake-replay/', 'fake-project')
    assert r['cookiecutter']['full_name'] == 'Audrey Roy'
    assert r['cookiecutter']['email'] == 'audreyr@example.com'
    assert r['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert r['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert r['cookiecutter']['repo_name'] == 'cookiecutter-pypackage'
    assert r['cookiecutter']['version'] == '0.1.0'
    assert r['cookiecutter']['license'] == 'MIT license'

# Generated at 2022-06-21 11:02:28.367886
# Unit test for function get_file_name
def test_get_file_name():
    name = "TestName"
    dir = "TestDir"
    f = get_file_name(dir, name)
    flag = False
    if f == dir + "/"+ name + ".json":
        flag = True
    return flag

# Generated at 2022-06-21 11:02:32.513209
# Unit test for function get_file_name
def test_get_file_name():
    """Assert file name."""
    replay_dir = '/Users/hongwei/cc/replay_dir/'
    template_name = 'cookiecutter-pypackage'
    file_name = 'cookiecutter-pypackage.json'
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, file_name)



# Generated at 2022-06-21 11:02:34.649120
# Unit test for function get_file_name
def test_get_file_name():
    pass

