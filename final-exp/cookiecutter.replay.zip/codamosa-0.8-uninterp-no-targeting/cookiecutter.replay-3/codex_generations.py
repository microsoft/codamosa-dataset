

# Generated at 2022-06-21 10:53:01.294878
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join(os.getcwd(), 'replay')
    template_name = 'test'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, 'test.json')

    template_name = 'test.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, 'test.json')



# Generated at 2022-06-21 10:53:06.109976
# Unit test for function dump
def test_dump():
    replay_dir = '{{ cookiecutter.replay_dir }}'
    template_name = '{{ cookiecutter.replay_dir }}'
    context = {"cookiecutter": "test_dump"}
    dump(replay_dir, template_name, context)
    


# Generated at 2022-06-21 10:53:11.539802
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'cookiecutter-pypackage'
    replay_dir = '~/code/cookiecutter-replay'
    file_name = get_file_name(replay_dir, template_name)

    assert file_name == '~/code/cookiecutter-replay/cookiecutter-pypackage.json'


# Generated at 2022-06-21 10:53:14.057856
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay_dir', 'template_name') == 'replay_dir/template_name.json'

# Generated at 2022-06-21 10:53:16.041655
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'my_dir'
    template_name = 'my_template_name'
    assert('my_dir/my_template_name.json' == get_file_name(replay_dir, template_name))

# Generated at 2022-06-21 10:53:20.041044
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'a': '1', 'b.c': '2'}}
    template_name = 'test'
    replay_dir = 'tests/test-replay'
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name)) == True
    os.remove(get_file_name(replay_dir, template_name))
    os.rmdir(replay_dir)


# Generated at 2022-06-21 10:53:30.660021
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    sample_replay_dir = os.path.join(os.getcwd(), 'sample_replay_dir')
    sample_template_name = 'sample_template_name'
    assert get_file_name(sample_replay_dir, sample_template_name) ==\
           os.path.join(sample_replay_dir, sample_template_name + '.json')

    sample_template_name = 'sample_template_name.json'
    assert get_file_name(sample_replay_dir, sample_template_name) ==\
           os.path.join(sample_replay_dir, sample_template_name)



# Generated at 2022-06-21 10:53:34.270679
# Unit test for function get_file_name
def test_get_file_name():

    actual = get_file_name('/home/replay', 'test')
    expected = '/home/replay/test.json'

    assert actual == expected


# Generated at 2022-06-21 10:53:39.361220
# Unit test for function get_file_name
def test_get_file_name():
    
    # Check if file name has .json at the end
    assert(get_file_name('dir','file') == 'dir/file.json')
    
    # Check if file name does not have .json at the end
    assert(get_file_name('dir','file.json') == 'dir/file.json')


# Generated at 2022-06-21 10:53:41.777229
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "test_folder"
    template_name = "test_name"
    get_file_name(replay_dir, template_name)

# Generated at 2022-06-21 10:53:51.776795
# Unit test for function dump
def test_dump():
    replay_dir = "test_dump"
    template_name = "test_template"
    context = {"cookiecutter": "test_context"}
    dump(replay_dir, template_name, context)

    # Check that we have test_dump folder
    assert os.path.exists(replay_dir)
    # Check that we have file in the folder
    assert os.listdir(replay_dir)

    # Check that we have created replay file
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)

    # Check that we have correct content of replay file
    with open(replay_file, 'r') as infile:
        assert json.load(infile) == context

    # We have to remove created replay_dir


# Generated at 2022-06-21 10:53:56.640530
# Unit test for function load

# Generated at 2022-06-21 10:54:04.614515
# Unit test for function load
def test_load():
    print("test_load")

    # Initial values
    replay_dir = 'test_files/test'
    template_name = 'test'

    # Call function
    context = load(replay_dir, template_name)

    # Verify result
    assert context['cookiecutter']['replay_dir'] == replay_dir
    assert context['cookiecutter']['full_name'] == 'Test'
    assert context['cookiecutter']['email'] == 'test@test.com'
    assert context['cookiecutter']['bcc_address'] == 'test@test.com'
    assert context['cookiecutter']['github_username'] == 'test'
    assert context['cookiecutter']['project_name'] == 'Test project'

# Generated at 2022-06-21 10:54:15.290744
# Unit test for function dump
def test_dump():

    def insert_test_data(test_dict, template_name):
        print("Input test dict = \n{}\n".format(test_dict))
        dump("test_replay", template_name, test_dict)
        print("Output test dict = \n{}\n".format(load("test_replay", template_name)))

    insert_test_data({
        "cookiecutter": {
            "project_name": "test_project_name"
        },
        "other": "other"
    }, "test1")

    insert_test_data({
        "cookiecutter": {
            "project_name": "test_project_name",
            "project_slug": "test_project_slug"
        },
        "other": "other"
    }, "test2")

    insert_test_data

# Generated at 2022-06-21 10:54:18.857690
# Unit test for function dump
def test_dump():
    test_file = 'test_replay.json'
    test_dict = {'cookiecutter' : {'test_key' : 'test_value'}}

    dump('tests', test_file, test_dict)

    assert load('tests', test_file) == test_dict

    os.remove(os.path.join('tests', test_file))

# Generated at 2022-06-21 10:54:31.777473
# Unit test for function dump
def test_dump():
    from cookiecutter.main import cookiecutter as cookiecutter_main
    from cookiecutter.replay import dump
    from unittest.mock import patch

    replay_dir = 'tests/fake-repo-pre/'

    with patch('cookiecutter.main.generate_context') as mock_generate_context:
        mock_generate_context.return_value = {
            'cookiecutter': {
                'full_name': 'Audrey Roy',
                'email': 'audreyr@example.com',
                'github_username': 'audreyr',
                'project_name': 'cookiecutter-pypackage',
                'repo_name': 'audreyr/cookiecutter-pypackage',
            }
        }


# Generated at 2022-06-21 10:54:42.436641
# Unit test for function get_file_name
def test_get_file_name():
    # Test for replay_dir
    replay_dir = 'replay_dir' 
    template_name = 'cc_full'
    result = get_file_name(replay_dir,template_name)
    assert result == 'replay_dir/cc_full.json'
    # Test for template_name
    template_name = 'replay'
    result = get_file_name(replay_dir,template_name)
    assert result == 'replay_dir/replay.json'
    template_name = 'replay.json'
    result = get_file_name(replay_dir,template_name)
    assert result == 'replay_dir/replay.json'
    template_name = 'replay.json.json'

# Generated at 2022-06-21 10:54:49.246013
# Unit test for function load
def test_load():
    cwd = os.getcwd()
    test_replay_dir = os.path.join(cwd, 'tests', 'test-replay-files')
    # template_name = 'Django-1.11'
    template_name = 'Django-1.10'

    
    test_load = load(test_replay_dir, template_name)
    print('test_load:')
    print(test_load)
    print()



# Generated at 2022-06-21 10:54:56.934695
# Unit test for function dump
def test_dump():
    replay_dir = "replay_dir"
    template_name = "template_name"
    context = {
            "cookiecutter": {
                "project_name": "cookiecutter-pypackage",
                "replay_file": "replay_file",
                "author_name": "Audrey Roy Greenfeld",
                "email": "aroy@alum.mit.edu",
            }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:55:05.804042
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'full_name': 'Monty Python',
            'email': 'monty@python.org',
            'github_username': 'montypython',
            'project_name': 'string cheese incident',
            'project_slug': 'string-cheese-incident',
            'project_license': 'MIT',
            'pypi_username': 'montypython'
        },
    }

    try:
        dump('./test_dump', 'string-cheese-incident', context)
    except:
        pass

    try:
        dump('./test_dump/test_dump', 'string-cheese-incident', context)
    except:
        pass


# Generated at 2022-06-21 10:55:17.278054
# Unit test for function dump
def test_dump():
    import os
    import shutil
    path = os.path.dirname(os.path.realpath(__file__))
    dump(path, 'test', {'cookiecutter': {'hello': 'world'}})
    load(path, 'test')
    import tests.test_context as context
    context.COOKIECUTTER_HOME = os.path.join(path, 'test')
    from cookiecutter.main import cookiecutter
    cookiecutter(context.TEST_TEMPLATE, replay=True)
    os.remove(os.path.join(path, 'test.json'))
    shutil.rmtree(os.path.join(path, 'test'))
    # cookiecutter(context.TEST_TEMPLATE, replay=True)

# Generated at 2022-06-21 10:55:19.690742
# Unit test for function load
def test_load():
    """Read json data from file."""
    context = load('/Users/odewahn/learn/cookiecutter/cookiecutter/tests/test-repo/', 'json')
    print(context)


# Generated at 2022-06-21 10:55:22.564434
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name(replay_dir='replay', template_name='template_1') == 'replay/template_1.json'
    assert get_file_name(replay_dir='replay', template_name='template_1.json') == 'replay/template_1.json'

# Generated at 2022-06-21 10:55:26.964062
# Unit test for function load
def test_load():
    context = load('/home/sandbox/cookiecutter-django/.cookiecutter-replay', 'sandbox/cookiecutter-django')
    assert context == {'cookiecutter': {'full_name': 'Sandbox', 'email': 'sb@example.com', 'project_name': 'My Project', 'project_slug': 'my_project', 'project_short_description': 'A short description of the project.', 'pypi_username': 'sandbox', 'github_username': 'sandbox', 'domain_name': 'example.com', 'version': '0.1.0'}}

# Generated at 2022-06-21 10:55:34.227968
# Unit test for function load
def test_load():
    """Test function load."""
    actual = {}
    actual = load('/tmp', 'cc_test1')
    expected = {}
    expected['cc_test1'] = {'cookiecutter': {'key1': 'value1', 'key2': 'value2'}}
    try:
        assert actual == expected
        print ("get_context: Test Pass!")
    except AssertionError as e:
        print ("get_context: Test Fail!")

    # test.expected.json does not exist
    actual = {}
    actual = load('/tmp', 'cc_test2')
    expected = {}
    try:
        assert actual == expected
        print ("get_context: Test Fail!")
    except AssertionError as e:
        print ("get_context: Test Pass!")



# Generated at 2022-06-21 10:55:38.139971
# Unit test for function load
def test_load():
    dump('test/test', 'loadtest', {'cookiecutter': 'test'})
    context = load('test/test', 'loadtest')
    assert context == {'cookiecutter': 'test'}


# Generated at 2022-06-21 10:55:42.605394
# Unit test for function load
def test_load():
    replay_dir = os.path.abspath(os.path.dirname(__file__))
    template_name = 'test_template'
    result = load(replay_dir, template_name)
    assert result['cookiecutter']


# Generated at 2022-06-21 10:55:49.084504
# Unit test for function get_file_name
def test_get_file_name():
    """Test if get_file_name is returning the right file_name with suffix."""
    replay_dir = 'test_cookiecutter'
    template_name = 'cookiecutter-pypackage'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'test_cookiecutter/cookiecutter-pypackage.json'

test_get_file_name()

# Generated at 2022-06-21 10:55:55.282786
# Unit test for function dump
def test_dump():
    replay_dir = '.'
    template_name = 'test'
    context = {'cookiecutter': {'test': True}}

    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)

    assert loaded_context == context
    os.remove(get_file_name(replay_dir, template_name))

# Unit test to test if context contains cookiecutter key

# Generated at 2022-06-21 10:56:00.421099
# Unit test for function get_file_name
def test_get_file_name():
    """
    Test if the function return the correct result.

    If it passed, then the test is successful.
    If it failed, then the function is wrong.
    """

    replay_dir = os.getcwd()

    template_name = "test"

    result = get_file_name(replay_dir, template_name)

    check = True

    if( (result != os.path.join(os.getcwd(), "test.json")) and \
        (result != os.path.join(os.getcwd(), "test")) ):
        check = False

    assert check == True

# Generated at 2022-06-21 10:56:11.521104
# Unit test for function load

# Generated at 2022-06-21 10:56:16.429950
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    from os import environ
    from os.path import join
    from tempfile import gettempdir

    replay_dir = join(gettempdir(), 'cookiecutter')
    template_name = 'cookiecutter-pypackage'

    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))

    replay_file = get_file_name(replay_dir, template_name)
    expected = join(replay_dir, 'cookiecutter-pypackage.json')

    assert replay_file == expected, 'failed test_get_file_name()'


# Generated at 2022-06-21 10:56:28.310588
# Unit test for function dump
def test_dump():
    replay_dir = os.path.expanduser('~/.cookiecutter_replay')
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com', 'github_username': 'audreyr', 'project_name': 'cookiecutter-pypackage', 'project_slug': 'cookiecutter-pypackage', 'pypi_username': 'audreyr', 'release_date': '2012-12-25', 'version': '0.1.0', 'command_line_interface': 'click'}}
    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)

# Generated at 2022-06-21 10:56:33.236424
# Unit test for function dump
def test_dump():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    context_dict = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    template_name = 'cookiecutter-pypackage'
    dump(tmpdir, template_name, context_dict)
    data_from_file = json.load(open(os.path.join(tmpdir, template_name + '.json')))
    assert data_from_file == context_dict

# Generated at 2022-06-21 10:56:36.445280
# Unit test for function get_file_name
def test_get_file_name():
    assert(get_file_name('', 'template') == 'template.json')
    assert(get_file_name('', 'template.json') == 'template.json')


# Generated at 2022-06-21 10:56:40.068173
# Unit test for function load
def test_load():
    with open("test_data_file.json", 'r') as infile:
        context = json.load(infile)
    print(context)
    #assert_equal(context,context)


# Generated at 2022-06-21 10:56:44.087731
# Unit test for function dump
def test_dump():
    from cookiecutter.main import cookiecutter
    ctx = cookiecutter('tests/test-repo-pre/', no_input=True, output_dir='.')
    dump('tests/test-repo-pre/', 'tests/test-repo-pre/', ctx)


# Generated at 2022-06-21 10:56:46.384761
# Unit test for function load
def test_load():
    replay_dir =  "tests/test-replay/"
    template_name = "test-template"
    print(load(replay_dir, template_name))


# Generated at 2022-06-21 10:56:53.027115
# Unit test for function dump
def test_dump():
    context = dict()
    context['cookiecutter'] = dict()
    context['cookiecutter']['full_name'] = 'Mehnaz Kabir'
    context['cookiecutter']['email'] = 'm.kabir@auckland.ac.nz'
    context['cookiecutter']['project_name'] = "Test_Project"
    context['cookiecutter']['repo_name'] = "Test_Repository"
    context['cookiecutter']['licenese'] = "MIT License"
    context['cookiecutter']['version'] = '0.1.0'
    
    dump('/home/makabir/Documents/Autograder_Project/cookiecutter-autograder/', 'default', context)
    

# Generated at 2022-06-21 10:57:01.658288
# Unit test for function load
def test_load():
    """Test for function load."""
    template_name = 'test'
    context = {
        "cookiecutter": {
            "full_name": "Roman Zolotarev",
            "email": "rz@daemon.io",
            "company": "Daemon",
            "project_name": "Test Project"
        }
    }
    replay_dir = 'replay'
    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert context == loaded_context



# Generated at 2022-06-21 10:57:12.295039
# Unit test for function dump
def test_dump():
    dir_name = 'tests/files/test-replay'
    template_name = 'Test'
    cookiecutter = {'repo_dir': '.'}
    context = {'cookiecutter': cookiecutter}

    dump(dir_name, template_name, context)
    loaded_context = load(dir_name, template_name)

    yield assert_true, 'cookiecutter' in loaded_context

    yield assert_equal, loaded_context['cookiecutter']['repo_dir'], '.'


# Generated at 2022-06-21 10:57:21.394991
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test_dump/'
    template_name = 'test_dump'

# Generated at 2022-06-21 10:57:30.236384
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    replay_dir = os.path.join(os.path.dirname(__file__), '.tests')
    # Make sure test directory exists
    if not os.path.isdir(replay_dir):
        os.makedirs(replay_dir)
    # py.test doesn't like directories with '.', so we'll create a fake
    # one for testing purposes.
    template_name = 'test_template'
    context = {'cookiecutter': {'_copy_without_render': ['test.txt']}}
    dump(replay_dir, template_name, context)
    # if we can successfully load the file, dump worked.
    load(replay_dir, template_name)

# Generated at 2022-06-21 10:57:34.086114
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/test/dir', 'ze-template') == '/test/dir/ze-template.json'
    assert get_file_name('/test/dir', 'ze-template.json') == '/test/dir/ze-template.json'

# Generated at 2022-06-21 10:57:45.054952
# Unit test for function load
def test_load():
    # Test default case
    replay_dir = 'test_files'
    template_name = 'simple'
    context = load(replay_dir, template_name)
    expected_context = {
        "cookiecutter": {
            "full_name": "Audrey Roy Greenfeld",
            "repo_name": "audreyr/cookiecutter-pypackage",
            "email": "test@test.test",
            "project_name": "test",
            "project_short_description": "Test project!",
            "release_date": "2013-09-17",
            "version": "0.1.0",
            "year": "2014"
        }
    }
    assert context == expected_context
    
    # Test template name of type int
    template_name = 1

# Generated at 2022-06-21 10:57:54.888864
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = os.path.expanduser('~')
    template_name = 'jquery'
    result = get_file_name(replay_dir, template_name)
    expected = os.path.expanduser('~') + 'jquery.json'
    assert result == expected
    template_name = 'jquery.json'
    result = get_file_name(replay_dir, template_name)
    expected = os.path.expanduser('~') + 'jquery.json'
    assert result == expected
    template_name = 'jquery.json'
    result = get_file_name(replay_dir, template_name)
    expected = os.path.expanduser('~') + 'jquery.json'
    assert result

# Generated at 2022-06-21 10:58:03.087171
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'project_name': 'Gruber',
            'project_slug': 'Gruber',
            'repo_name': 'Gruber',
            'author_name': 'Gruber',
            'email': 'Gruber@example.com',
            'description': 'All your base are belong to us'
        }
    }
    dump('tests/test-output/replay/', 'cookiecutter-pypackage', context)
    print("Unit test for function dump - Done")


# Generated at 2022-06-21 10:58:08.300646
# Unit test for function dump
def test_dump():
    """Test for function dump."""
    replay_dir = 'tests/files/test-replay'
    template_name = 'does-not-exist'
    context = {'cookiecutter': {'foo': 'bar'}}

    dump(replay_dir, template_name, context)

    assert os.path.exists('tests/files/test-replay/does-not-exist.json')

    os.remove('tests/files/test-replay/does-not-exist.json')



# Generated at 2022-06-21 10:58:09.987528
# Unit test for function dump
def test_dump():
    template_name = 'test'
    replay_dir = './test_dump/'
    context = {'cookiecutter': {'test1': 'test2', 'test2': 'test3'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    pass


# Generated at 2022-06-21 10:58:15.007838
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutter_replay')
    template_name = 'pypackage'

    file_name = get_file_name(replay_dir, template_name)

    assert file_name == os.path.join(replay_dir, template_name + '.json')


# Generated at 2022-06-21 10:58:27.356744
# Unit test for function dump
def test_dump():
    replay_dir = "test_replay_dir"
    template_name = "test_template_name"
    context = {"cookiecutter": {"full_name": "John Doe", "email": "johndoe@example.com"}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, template_name + ".json"))
    os.remove(os.path.join(replay_dir, template_name + ".json"))
    os.removedirs(replay_dir)


# Generated at 2022-06-21 10:58:38.293721
# Unit test for function dump

# Generated at 2022-06-21 10:58:41.619367
# Unit test for function load
def test_load():
    replay_dir = 'C:\\Users\\bunny\\PycharmProjects\\Cookie\\cc_test\\replay\\'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-21 10:58:43.041955
# Unit test for function load
def test_load():
    context = load('.','cookiecutter.json')
    print(context)

test_load()

# Generated at 2022-06-21 10:58:46.199492
# Unit test for function dump
def test_dump():
    from cookiecutter.main import cookiecutter
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdir:
        context = cookiecutter('.', no_input=True, replay_dir='./tmp/cc_replay')
        dump('./tmp/cc_replay', '.', context)
        assert load('./tmp/cc_replay', '.') == context

# Generated at 2022-06-21 10:58:58.675839
# Unit test for function dump
def test_dump():
    replay_dir= '../test'
    template_name='test-gamma'
    context={'cookiecutter': {'full_name': 'Firstname Lastname',
                          'email': 'flastname@example.com',
                          'github_username': 'flastname',
                          'project_name': 'cookiecutter-gamma',
                          'repo_name': 'cookiecutter-gamma'},
        '_copy_without_render': ['.travis.yml', '.yaml-version', 'test_cookiecutter.py'],
        '_copy_without_render_text': [],
        '_repo_name': 'cookiecutter-gamma'}
    dump(replay_dir,template_name,context)

# Generated at 2022-06-21 10:59:04.155265
# Unit test for function get_file_name
def test_get_file_name():
    """Test the get_file_name function."""
    template_name = '{{ cookiecutter.repo_name }}'
    replay_dir = 'fake-replay'
    assert get_file_name(replay_dir, template_name) == 'fake-replay' + os.sep + '{{ cookiecutter.repo_name }}.json'


# Generated at 2022-06-21 10:59:11.396920
# Unit test for function load
def test_load():
    """Unit test for load function."""
    replay_dir = '/test/test'
    template_name = 'test.json'
    context = {
        'cookiecutter': {
            'key': {
                'a': '1',
                'b': '2'
            },
            'key2': 'test'
        }
    }
    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert context['cookiecutter']['key']['a'] == loaded_context['cookiecutter']['key']['a']
    assert context['cookiecutter']['key2'] == loaded_context['cookiecutter']['key2']


# Generated at 2022-06-21 10:59:23.680278
# Unit test for function dump
def test_dump():
    # Replay Dir exists
    replay_dir = 'replay_test'
    template_name = 'test_dump.json'
    context = {'cookiecutter': {'key': 'test_value'}}
    dump(replay_dir, template_name, context)
    with open(replay_dir+'/'+template_name, 'r') as infile:
        string = infile.read()
        assert string == '{\n  "cookiecutter": {\n    "key": "test_value"\n  }\n}'
    # Replay Dir doesn't exist
    replay_dir = 'replay_test_2'
    dump(replay_dir, template_name, context)

# Generated at 2022-06-21 10:59:29.333481
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/sls-cookiecutter-test'
    template_name = 'template'
    context = {
        'cookiecutter': {
            'project_name': 'example'
        }
    }

    dump(replay_dir, template_name, context)
    result = load(replay_dir, template_name)
    assert result.get('cookiecutter').get('project_name') == 'example'



# Generated at 2022-06-21 10:59:42.762766
# Unit test for function dump
def test_dump():
    replay_dir = 'replay'
    template_name = 'template_name'
    context = {'cookiecutter': {}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:59:51.319983
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    os.chdir(os.path.dirname(__file__))
    if os.path.exists('fake-replay'):
        import shutil
        shutil.rmtree('fake-replay')
    os.mkdir('fake-replay')
    json_file = os.path.join('fake-replay', 'input.json')

# Generated at 2022-06-21 10:59:58.081195
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr'
        }
    }
    replay_dir = '/tmp'
    template_name = 'Python-Package'
    dump(replay_dir, template_name, context)
    with open('/tmp/Python-Package.json') as replay_file:
        assert 'Audrey Roy Greenfeld' in replay_file.read()


# Generated at 2022-06-21 11:00:06.833663
# Unit test for function dump
def test_dump():
    """
    test dump function, ensure format of file is valid.
    """
    replay_dir = "/tmp"
    template_name = "test"
    context = {'cookiecutter':{'name':'cookiecutter'}}
    dump(replay_dir, template_name, context)
    f = open(get_file_name(replay_dir, template_name), 'r')
    data = f.readlines()
    assert data[0] == '{\n'
    assert data[1] == '  "cookiecutter": {\n'
    assert data[2] == '    "name": "cookiecutter"\n'
    assert data[3] == '  }\n'
    assert data[4] == '}\n'


# Generated at 2022-06-21 11:00:17.230824
# Unit test for function dump
def test_dump():
    replay_dir = "replay_test_dump"
    template_name = 'test1'
    context = {
        "cookiecutter":{
            "answer1": "answer1",
            "answer2": "answer2",
            "answer3": "answer3"
        }
    }
    dump(replay_dir, template_name, context)
    # print(get_file_name(replay_dir, template_name))
    
    with open(get_file_name(replay_dir, template_name), 'r') as infile:
        new_context = json.load(infile)

    assert context == new_context
    # Delete the file test1.json in the directory replay_test_dump after the test

# Generated at 2022-06-21 11:00:21.226253
# Unit test for function dump
def test_dump():
    replay_dir = '/tmp/replay_dir'
    template_name = 'template_name'
    context = {
        'cookiecutter': {
            'context': 'context'
        }
    }
    dump(replay_dir, template_name, context)
    new_context = load(replay_dir, template_name)
    assert new_context == context

# Generated at 2022-06-21 11:00:30.895267
# Unit test for function dump
def test_dump():
    context = {
        "cookiecutter": {
            "project_name": "test-project",
            "repo_name": "test-repo",
            "author_name": "test-author",
            "email": "test-email",
            "release_date": "test-release-date",
            "year": "test-year",
            "description": "test-description",
            "project_short_description": "test-project-short-description",
            "open_source_license": "test-open-source-license",
            "repo_url": "test-repo-url",
        }
    }
    dump('/tmp', 'test-template', context)
    assert(get_file_name('/tmp', 'test-template') == "/tmp/test-template.json")

# Generated at 2022-06-21 11:00:38.089635
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    # Check for invalid types for replay_dir, template_name, and context
    replay_dir = 1
    template_name = 1
    context = 1
    try:
        dump(replay_dir, template_name, context)
    except TypeError as e:
        assert e.args[0] == 'Directory name is required to be of type str'
    try:
        dump(replay_dir, template_name, context)
    except TypeError as e:
        assert e.args[0] == 'Template name is required to be of type str'
    try:
        dump(replay_dir, template_name, context)
    except TypeError as e:
        assert e.args[0] == 'Context is required to be of type dict'

    # Check for invalid replay_dir


# Generated at 2022-06-21 11:00:40.881181
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replays'
    template_name = 'Jinja2'
    assert get_file_name(replay_dir, template_name) == 'replays/Jinja2.json'


# Generated at 2022-06-21 11:00:43.849123
# Unit test for function dump
def test_dump():
    os.mkdir('tests')
    os.mkdir('tests/replay_dir')
    dump('tests/replay_dir', 'tests/replay_dir/test_file',
         {'cookiecutter': {'test': 'test', 'test2': 'test2'}})
    os.remove('tests/replay_dir/test_file.json')
    os.rmdir('tests/replay_dir')
    os.rmdir('tests')


# Generated at 2022-06-21 11:01:14.189085
# Unit test for function load
def test_load():
    context = load('/home/aviral/study/sem-2/CSCI-6360/lab2/cookiecutter/tests/test_replay/', 'TEST_COOKIECUTTER_REPLAY')
    assert context['cookiecutter']['full_name'] == "Your Name Here"


# Generated at 2022-06-21 11:01:20.489795
# Unit test for function dump
def test_dump():
    template_name = 'test_template'
    replay_dir = 'test_dir'
    context = {'cookiecutter': {'test_key': 'test_value'}}

    dump(replay_dir, template_name, context)

    with open(os.path.join(replay_dir, template_name+'.json'), 'r') as f:
        assert json.load(f)['cookiecutter']['test_key'] == 'test_value'


# Generated at 2022-06-21 11:01:28.250507
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'replay')
    template_name = 'cookiecutter-pypackage'
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, 'cookiecutter-pypackage.json')
    template_name = 'cookiecutter-pypackage.json'
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, 'cookiecutter-pypackage.json')

# Generated at 2022-06-21 11:01:32.497274
# Unit test for function dump
def test_dump():
    template_name = 'test_template'
    context = {'cookiecutter': '{{test_cookiecutter}}'}
    dump(os.getcwd(), template_name, context)
    assert load(os.getcwd(), template_name) == context
    os.remove(get_file_name(os.getcwd(), template_name))


# Generated at 2022-06-21 11:01:34.847839
# Unit test for function dump
def test_dump():
    try:
        dump(None,None,None)
    except TypeError:
        pass


# Generated at 2022-06-21 11:01:40.557123
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'abc': 'xyz'}}
    replay_dir = '{{cookiecutter.temp_folder}}'
    template_name = '{{cookiecutter.project_name}}'
    dump(replay_dir, template_name, context)



# Generated at 2022-06-21 11:01:50.218505
# Unit test for function dump
def test_dump():
    """Test function dump."""
    context_record = {
        'cookiecutter': {
            'full_name': 'Harshal Patil',
            'email': 'example@example.com',
            'github_username': 'test'
        }
    }
    if os.path.exists("/tmp/replay"):
        os.system("rm -rf /tmp/replay")
    os.makedirs("/tmp/replay")
    dump("/tmp/replay","test_dump",context_record)
    if os.path.exists("/tmp/replay/test_dump.json"):
        os.system("rm -rf /tmp/replay")
        return True
    else:
        os.system("rm -rf /tmp/replay")
        return False


# Generated at 2022-06-21 11:01:55.216316
# Unit test for function load
def test_load():
    test_file = get_file_name(replay_dir='.', template_name='nananano')
    test_context = {'cookiecutter': {'project_name': 'dummy'}}
    with open(test_file, 'w') as outfile:
        json.dump(test_context, outfile, indent=2)
    assert load('.', 'nananano') == {'cookiecutter': {'project_name': 'dummy'}}

# Generated at 2022-06-21 11:02:01.354454
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    template_name = 'test_template'
    replay_dir = 'tests/replay'
    context = {'cookiecutter': {'full_name': 'Samuel Colvin'}}
    dump(replay_dir, template_name, context)

    result = load(replay_dir, template_name)
    assert result == context

# Generated at 2022-06-21 11:02:08.871444
# Unit test for function dump
def test_dump():
    # Arrange
    context = {}
    context['cookiecutter'] = {'context': {'project_name': 'HelloWorld', 'package_name': 'helloworld'}}

    # Act
    dump('/home/pow/tests/replay', 'helloworld', context)

    # Assert
    with open('/home/pow/tests/replay/helloworld.json', 'r') as infile:
        data = json.load(infile)
        assert(data == context)
