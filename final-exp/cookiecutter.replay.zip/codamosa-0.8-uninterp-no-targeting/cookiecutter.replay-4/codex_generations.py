

# Generated at 2022-06-21 10:52:59.864755
# Unit test for function load
def test_load():
    replay_dir = '/home/karenchan/Desktop/UCI/Sophomore Year/Sophomore Spring/INF-130/Projects/project-3-cookiecutter-karenchanl/src/cookiecutter/tests/test-replay'
    template_name = 'test-replay'
    context = load(replay_dir, template_name)
    assert context == {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com', 'github_username': 'audreyr', 'project_name': 'example', 'project_slug': 'example', 'pypi_username': 'audreyr', 'year': '2013'}}
    assert type(context) is dict

# Generated at 2022-06-21 10:53:03.373494
# Unit test for function get_file_name
def test_get_file_name():
    """
    Test the get_file_name function.

    """
    directory = '/tmp'
    name = 'test'
    assert get_file_name(directory, name) == '/tmp/test.json'

# Generated at 2022-06-21 10:53:08.702030
# Unit test for function load
def test_load():
    import pytest
    context = load('.', 'tests/fake.json')
    with pytest.raises(Exception):
        load('.', 'tests/fake.yaml')
    with pytest.raises(Exception):
        load('.', 'tests/empty.json')


# Generated at 2022-06-21 10:53:11.989159
# Unit test for function dump
def test_dump():
    import io
    import json
    import unittest
    from cookiecutter.replay import dump
    from cookiecutter.replay import load

    # Create a dummy directory to write json file
    test_dir = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'tmp'
    )
    os.makedirs(test_dir)

    # Define data to be written
    template_name = '{{cookiecutter.project_name}}'
    context = {
        'cookiecutter': {
            'project_name': 'foobar',
            'repo_name': 'barfoo',
            'author_name': 'foo bar',
            'description': 'test project',
        }
    }

    # Write data to file

# Generated at 2022-06-21 10:53:20.644158
# Unit test for function dump
def test_dump():
    context = {
        "project_name": "{{ cookiecutter.project_slug }}",
        "project_slug": "{{ cookiecutter.project_slug }}",
        "cookiecutter": {
            "project_name": "{{ cookiecutter.project_slug }}",
            "project_slug": "{{ cookiecutter.project_slug }}"
        }
    }
    replay_dir = "."
    template_name = "test_template"
    dump(replay_dir, template_name, context)
    context_load = load(replay_dir, template_name)
    assert context_load == context

# Generated at 2022-06-21 10:53:27.007052
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    replay_dir = '/home/user/cookiecutter'
    template_name = 'cookiecutter-pypackage'
    assert get_file_name(replay_dir, template_name) == '/home/user/cookiecutter/cookiecutter-pypackage.json'


# Generated at 2022-06-21 10:53:30.656376
# Unit test for function load
def test_load():
    template_name = 'cookiecutter-pypackage'
    replay_dir = '../../'
    context = load(replay_dir, template_name)
    print("context: {}".format(context))
    assert context == 'cookiecutter'



# Generated at 2022-06-21 10:53:42.440560
# Unit test for function dump
def test_dump():
    context = {}

# Generated at 2022-06-21 10:53:48.049334
# Unit test for function dump
def test_dump():
    """
    Test dump function
    """
    d = 'a/b/c.json'
    tn = 'cookiecutter-pypackage'
    c = {'cookiecutter': {'name': 'Test'}}
    dump(d, tn, c)
    with open(d, 'r') as f:
        l = f.read()
        assert c == eval(l)


# Generated at 2022-06-21 10:53:57.085168
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'test-replay-dir'
    template_name_1 = 'test-template'
    template_name_2 = 'test-template.json'

    file_name_1 = get_file_name(replay_dir, template_name_1)
    assert(file_name_1 == 'test-replay-dir/test-template.json')

    file_name_2 = get_file_name(replay_dir, template_name_2)
    assert(file_name_2 == 'test-replay-dir/test-template.json')
    

# Generated at 2022-06-21 10:54:01.487620
# Unit test for function dump
def test_dump():
    template_name = "test.json"
    context = {'cookiecutter' : {'replay' : 'test'}}
    replay_dir = "."

    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:54:13.277541
# Unit test for function dump

# Generated at 2022-06-21 10:54:19.056690
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    tname = 'tpl'
    try:
        context = {
            'cookiecutter': {
                'author_name': 'blah',
            }
        }

        dump(tmpdir, tname, context)

        context2 = load(tmpdir, tname)
        assert context == context2
    finally:
        shutil.rmtree(tmpdir)



# Generated at 2022-06-21 10:54:20.551922
# Unit test for function load
def test_load():
    re_file = load("replay", "demo")


# Generated at 2022-06-21 10:54:29.926387
# Unit test for function dump
def test_dump():
	import os
	path = os.getcwd()
	cwd = path+'/tests/test_project'
	repo_dir = 'file://'+path
	context = {'cookiecutter': {'project_name': 'Test Project'}}
	replay_dir = cwd+'/'+'{{cookiecutter.project_name}}'
	template = '.'
	dump(replay_dir, template, context)
	assert('test_project.json' in os.listdir(replay_dir))
	

# Generated at 2022-06-21 10:54:36.080512
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import shutil
    import tempfile
    context = {'cookiecutter': {}}

    with tempfile.TemporaryDirectory() as temp_dir:
        dump(temp_dir, 'test', context)
        replay_file = get_file_name(temp_dir, 'test')
        assert os.path.exists(replay_file)



# Generated at 2022-06-21 10:54:40.139859
# Unit test for function get_file_name
def test_get_file_name():
    # Test values
    dir_name = '/home/user/dir'
    template_name = 'template_name'
    json_template_name = 'template_name.json'

    return_name_template = get_file_name(dir_name, template_name)
    return_name_json_template = get_file_name(dir_name, json_template_name)

    # Test values return
    assert (return_name_template ==  '/home/user/dir/template_name.json')
    assert (return_name_json_template == '/home/user/dir/template_name.json')

    # Test exceptions
    with pytest.raises(TypeError):
        get_file_name('/home/user/dir', 1)

    with pytest.raises(IOError):
        get_file_name

# Generated at 2022-06-21 10:54:42.098795
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('.', 'template_name') == './template_name.json'



# Generated at 2022-06-21 10:54:52.192063
# Unit test for function dump
def test_dump():
    """test function dump by comparing before and after writing to the file."""
    replay_test_dir = './replay_test_dir'
    template_test_name = 'test_template_name'
    test_file = get_file_name(replay_test_dir, template_test_name)
    dump(replay_test_dir, template_test_name, {'cookiecutter': {}})
    test_file_content = json.load(open(test_file, 'r'))
    assert test_file_content == {'cookiecutter': {}}
    os.remove(test_file)
    os.rmdir(replay_test_dir)


# Generated at 2022-06-21 10:55:02.760272
# Unit test for function load
def test_load():
    template_name = 'pocoo/cookiecutter-flask'
    replay_dir = os.path.expanduser('~/.cookiecutters/')
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Test'
    assert context['cookiecutter']['repo_name'] == 'test'
    assert context['cookiecutter']['author_name'] == 'Travis CI'
    assert context['cookiecutter']['email'] == 'travis@example.com'
    assert context['cookiecutter']['description'] == 'An example Flask app'
    assert context['cookiecutter']['open_source_license'] == 'MIT'
    assert context['cookiecutter']['use_pytest'] == 'y'


# Generated at 2022-06-21 10:55:10.390123
# Unit test for function load
def test_load():
    os.chdir(os.path.expanduser('~'))
    path = 'Documents/GitRepos/CookieCutter/replays'
    template_name = 'example_cookiecutter_template'
    context = load(path, template_name)
    print(context)

    return


# Generated at 2022-06-21 10:55:14.633205
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('', 'template') == 'template.json'
    assert get_file_name('', 'template.json') == 'template.json'
    assert get_file_name('replay', 'template') == 'replay/template.json'
    assert get_file_name('replay', 'template.json') == 'replay/template.json'

# Generated at 2022-06-21 10:55:20.294502
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = os.path.join(os.path.expanduser("~"), ".cookiecutters")
    template_name = "gh:audreyr/cookiecutter-pypackage"
    expected = os.path.join(replay_dir, "gh:audreyr/cookiecutter-pypackage.json")
    actual = get_file_name(replay_dir, template_name)
    assert expected == actual


# Generated at 2022-06-21 10:55:23.798642
# Unit test for function load
def test_load():
    replay_dir = "/Users/singha53/Desktop/CSCI5253/TermProject/data/repl"
    template_name="cookiecutter-pypackage/"
    context = load(replay_dir, template_name)
    print(context)



# Generated at 2022-06-21 10:55:26.940301
# Unit test for function load
def test_load():
    context = load(os.path.expanduser('~/.cookiecutters'), 'sadf')
    print(context)



# Generated at 2022-06-21 10:55:33.795771
# Unit test for function dump
def test_dump():
    """
    Test for dump.

    Dump a context to a replay file.
    """
    if not make_sure_path_exists('test-replay'):
        raise IOError('Unable to create replay dir at {}'.format('test-replay'))

    context = {
        'cookiecutter': {
            'full_name': 'Tuan Anh Nguyen',
            'email': 'tuan2906@gmail.com'
        },
        'project_name': 'cookiecutter.replay'
    }

    dump('test-replay', 'test-project', context)


# Generated at 2022-06-21 10:55:42.425305
# Unit test for function load
def test_load():
    replay_dir = 'replays'
    template_name = 'cookiecutter-pypackage'

    if not isinstance(template_name, str):
        raise TypeError('Template name is required to be of type str')

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

    return context

# Generated at 2022-06-21 10:55:49.310301
# Unit test for function load
def test_load():
    # Test for file which does not contain cookiecutter variable
    context = load(replay_dir='./', template_name='potato')
    if context['cookiecutter']:
        raise ValueError('Not the expected result when load')
    # Test for file which contains cookiecutter variable
    context = load(replay_dir='./', template_name='po')
    if not context['cookiecutter']:
        raise ValueError('Not the expected result when load')


# Generated at 2022-06-21 10:55:52.842912
# Unit test for function get_file_name
def test_get_file_name():
    expected = '/tmp/tests/cookiecutter-tests/data/files/example.json'
    actual = '/tmp/tests/cookiecutter-tests/data/files/example'
    assert get_file_name(actual, 'example') == expected

# Generated at 2022-06-21 10:55:56.954675
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("/Users/sherrysun/Workspace/experiment/metadata/cookiecutter/cloned/grhino",
                         "grhino") == "/Users/sherrysun/Workspace/experiment/metadata/cookiecutter/cloned/grhino/grhino.json", "Error"

# Generated at 2022-06-21 10:56:06.981200
# Unit test for function load
def test_load():
    context=load('/Users/xiaohuaic/Documents/Courses/CMU-MHCI/Fall2017/Project/Project/cookiecutter-django-rest-framework-template-master/cookiecutter.replay', 'cookiecutter-django-rest-framework-template-master')
    print(context['cookiecutter'])

# Generated at 2022-06-21 10:56:08.972223
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name(replay_dir = 'replay', template_name = 't') == 'replay/t.json'


# Generated at 2022-06-21 10:56:13.396622
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tests/files/replay'
    template_name = 'tests/files/seq_escape/{{cookiecutter.sequence_no}}-{{cookiecutter.name}}'
    res = get_file_name(replay_dir, template_name)
    assert res=='tests/files/replay/tests/files/seq_escape/{{cookiecutter.sequence_no}}-{{cookiecutter.name}}.json'


# Generated at 2022-06-21 10:56:16.227793
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name(".","templatename") == os.path.join(".","templatename.json")


# Generated at 2022-06-21 10:56:17.408422
# Unit test for function load
def test_load():
    pass


# Generated at 2022-06-21 10:56:29.201236
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/files/replay'
    template_name = 'tests/fake-repo-pre'

# Generated at 2022-06-21 10:56:41.069931
# Unit test for function load
def test_load():
    context = load("/Users/gaochen/Documents/Github/cookiecutter-pypackage/forTest/generated-file", "test_a")
    assert context["cookiecutter"]["full_name"] == "gao chen"
    assert context["cookiecutter"]["package_name"] == "test_a"
    assert context["cookiecutter"]["project_short_description"] == "Test project number a"
    assert context["cookiecutter"]["project_name"] == "Test project number a"
    assert context["cookiecutter"]["use_pytest"] == "y"
    assert context["cookiecutter"]["open_source_license"] == "MIT license"
    assert context["cookiecutter"]["command_line_interface"] == "No command-line interface"

    context = load

# Generated at 2022-06-21 10:56:47.327882
# Unit test for function dump
def test_dump():
    # create a replay_dir
    replay_dir = 'tests/test-replay'
    template_name = 'test_template'
    context = {'cookiecutter': {'full_name': 'Test Name', 'email': 'test@test.com'}}
    dump(replay_dir, template_name, context)
    # check if the file is created
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)
    


# Generated at 2022-06-21 10:56:53.614986
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    # Test dump: Successful
    test_dir = '/tmp/cookiecutter/test_dump'
    template_name = 'test_template'
    context = {"cookiecutter": {"name": "test"}, "test": 1}
    dump(test_dir, template_name, context)
    context_loaded = load(test_dir, template_name)
    assert context == context_loaded

    # Test dump: Template name is not of type str
    template_name = 123
    context = {"cookiecutter": {"name": "test"}, "test": 1}
    try:
        dump(test_dir, template_name, context)
        assert False, 'Should not reach here!'
    except TypeError:
        assert True

    # Test dump: Context is not of type dict
    template_name

# Generated at 2022-06-21 10:57:00.745279
# Unit test for function get_file_name
def test_get_file_name():
    """Test the get_file_name function."""
    replay_dir = '~/.cookiecutter_replay'
    template_name = 'cookiecutter-pypackage'
    suffix = '.json'
    file_name = get_file_name(replay_dir, template_name)
    expected_file_name = os.path.join(replay_dir, template_name + suffix)
    assert file_name == expected_file_name



# Generated at 2022-06-21 10:57:10.267828
# Unit test for function get_file_name
def test_get_file_name():
    assert(get_file_name('/tmp/replay_dir', 'xyz.json') == '/tmp/replay_dir/xyz.json')
    assert(get_file_name('/tmp/replay_dir', 'xyz') == '/tmp/replay_dir/xyz.json')


# Generated at 2022-06-21 10:57:14.955054
# Unit test for function load
def test_load():
    code_gen_dir_path = os.path.join(os.getcwd(), "code_generation")
    template_name = "test.json"
    file_content = load(code_gen_dir_path, template_name)
    print(file_content)

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-21 10:57:25.758972
# Unit test for function dump
def test_dump():
    from cookiecutter import main
    from cookiecutter.main import cookiecutter
    from cookiecutter.main import cookiecutter_json
    import tempfile
    import collections
    import pytest
    import os
    import shutil
    import random
    import json
    random_string = "asdf"
    random_dict = {random_string: ['a','b','c']}
    random_key = "{{cookiecutter['key']}}"
    directory = tempfile.mkdtemp()
    replay_dir = os.path.join(directory, "replay")
    config_file_name = "config.yaml"
    replay_file_name = "some_name.json"
    replay_file = os.path.join(replay_dir, replay_file_name)

# Generated at 2022-06-21 10:57:33.504145
# Unit test for function dump
def test_dump():
    from cookiecutter.main import cookiecutter
    from tempfile import mkdtemp
    from os.path import join, isfile
    import shutil

    # Create a temporary folder for replay files
    replay_dir = mkdtemp()

    # Call cookiecutter function to create replay file
    # Render the dummy template
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'email': 'a@b.com', 'full_name': 'A B'}}
    cookiecutter(template_name, replay_dir=replay_dir, no_input=True, extra_context=context)

    # Get the replay file name
    replay_file = get_file_name(replay_dir, template_name)

    # Verify if a file was generated

# Generated at 2022-06-21 10:57:38.547676
# Unit test for function get_file_name
def test_get_file_name():
    """The function get_file_name should return the absolute path of file"""
    template_name = 'customer-microservice'
    replay_dir = 'wso2-cookiecutter-test/test'
    assert get_file_name(replay_dir, template_name) == 'wso2-cookiecutter-test/test/customer-microservice.json'

# Generated at 2022-06-21 10:57:39.788663
# Unit test for function dump
def test_dump():
    assert 0


# Generated at 2022-06-21 10:57:50.704383
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import json
    import os
    import pytest
    import shutil
    from cookiecutter.replay import load

    class TestException(Exception):
        """Test Exception."""

    @pytest.fixture(scope='function')
    def replay_dir(request):
        """Create a temporary replay directory."""
        temp_dir = tempfile.mkdtemp()

        def teardown():
            shutil.rmtree(temp_dir)
        request.addfinalizer(teardown)
        return temp_dir

    @pytest.fixture(scope='function')
    def fixture_templates(request):
        """Create a temporary replay directory."""


# Generated at 2022-06-21 10:57:53.128332
# Unit test for function load
def test_load():
    print(load('/mnt/e/PycharmProjects/Cookiecutter/tests/test-replay/', 'test-replay'))


# Generated at 2022-06-21 10:57:59.031757
# Unit test for function load
def test_load():
    assert load(replay_dir="./tests/test-replay/", template_name="test-template.json") == {
        'cookiecutter': {
            'full_name': 'Firstname Lastname',
            'email': 'firstname.lastname@gmail.com',
            'github_username': 'firstnamelastname'
        }
    }



# Generated at 2022-06-21 10:58:01.340846
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    # Test if get_file_name returns the correct string
    result = get_file_name('/tmp', 'template')
    assert result == '/tmp/template.json'

    # Test if get_file_name data type is correct
    result = get_file_name('/tmp', 'template')
    assert isinstance(result, str)

# Generated at 2022-06-21 10:58:17.849208
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = 'tests/test-replay'
    template_name = 'foobar'
    context = {'cookiecutter':{'project_name':'foobar'}}
    replay_file = get_file_name(replay_dir, template_name)
    dump(replay_dir, template_name, context)
    assert os.path.exists(replay_file)
    os.remove(replay_file)


# Generated at 2022-06-21 10:58:22.875143
# Unit test for function dump
def test_dump():
    """Unit test for dump."""
    replay_dir = '/tmp'
    template_name = 'test_dump'
    context = {
        'cookiecutter': {'test': {}}
    }
    dump(replay_dir, template_name, context)
    actual = load(replay_dir, template_name)
    assert actual == context, 'Loaded context does not match.'


# Generated at 2022-06-21 10:58:30.357457
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.getcwd(), 'test_replay_files')
    template_name = 'test-cookiecutter-project'

    # Get a sample context from the project directory
    context_path = os.path.join(
        os.getcwd(),
        'test_replay_files',
        'test-cookiecutter-project',
        'cookiecutter.json')
    with open(context_path, 'r') as infile:
        context = json.load(infile)

    replay_file = dump(replay_dir, template_name, context)

    # Assert file exists
    assert os.path.exists(replay_file)

    # Assert file can be loaded
    loaded_context = load(replay_dir, template_name)
    assert loaded

# Generated at 2022-06-21 10:58:35.769249
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    template_name = 'Test'
    context = {'cookiecutter': {'full_name': 'Test',
                                'email': 'test@cookiecutter.io',
                                'foo': 'bar'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:58:39.962160
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tests/files/test-read-write'
    template_name = 'existing_project_replay.json'
    replay_file = get_file_name(replay_dir, template_name)
    assert replay_file == 'tests/files/test-read-write/existing_project_replay.json'



# Generated at 2022-06-21 10:58:43.232572
# Unit test for function dump
def test_dump():
    template_name = 'test_dump'
    context = {'cookiecutter': 'test_dump'}
    dump(replay_dir='./', template_name=template_name, context=context)
    print('Cookiecutter data is dumped into {}.json'.format(template_name))


# Generated at 2022-06-21 10:58:48.893391
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    test_replay_dir = 'tests/test-output/'
    test_template_name = 'cookiecutter-pypackage'
    test_file_name = 'cookiecutter-pypackage.json'

    assert get_file_name(test_replay_dir, test_template_name) == os.path.join(test_replay_dir, test_file_name)

# Generated at 2022-06-21 10:59:01.398373
# Unit test for function dump
def test_dump():
    from jinja2 import Template
    from cookiecutter.generate import generate_context, generate_files
    from cookiecutter.main import cookiecutter
    from cookiecutter.config import DEFAULT_CONFIG, parse_config
    from cookiecutter.exceptions import UnknownExtension
    import shutil
    # Test case 1
    # Test if it generate successfully in replay_dir which is specified
    # Test if the context is correct
    tmp_dir = 'test/test_dir'
    replay_dir = 'test/test_replay_dir'
    cookiecutter('test/test-generate-files', replay_dir=replay_dir, no_input=True)
    assert os.path.isdir(replay_dir)

# Generated at 2022-06-21 10:59:10.208693
# Unit test for function get_file_name
def test_get_file_name():
    # Case 1: replay_dir = ''
    replay_dir = ''
    template_name = 'abcd'
    suffix = '.json'
    print(get_file_name(replay_dir, template_name))
    assert get_file_name(replay_dir, template_name) == 'abcd.json'

    # Case 2: replay_dir = '', template_name = 'abcd.json'
    replay_dir = ''
    template_name = 'abcd.json'
    print(get_file_name(replay_dir, template_name))
    assert get_file_name(replay_dir, template_name) == 'abcd.json'

    # Case 3: replay_dir = 'replay_dir', template_name = 'abcd'
    replay_dir = 'replay_dir'

# Generated at 2022-06-21 10:59:15.806737
# Unit test for function dump
def test_dump():
    from cookiecutter.main import cookiecutter
    context = cookiecutter("gh:audreyr/cookiecutter-pypackage", no_input=True)
    dump("replay", "cookiecutter-pypackage", context)
    assert(os.path.isfile("replay/cookiecutter-pypackage.json"))


# Generated at 2022-06-21 10:59:36.314384
# Unit test for function get_file_name
def test_get_file_name():
    expected = 'my_file.json'
    result = get_file_name("tmp", "my_file")
    assert result == expected


# Generated at 2022-06-21 10:59:42.191764
# Unit test for function load
def test_load():
    try:
        load('.', 'cookiecutter.json')
    except ValueError:
        # Pass
        pass
    else:
        assert False, "Should raise ValueError."

    try:
        load('.', 'tests/files/fake-repo-pre/')
    except IOError:
        # Pass
        pass
    else:
        assert False, "Should raise IOError."

# Generated at 2022-06-21 10:59:47.981103
# Unit test for function load
def test_load():
    """
    Test the load function.
    """
    import os
    import json

    json_file = "test.json"
    replacements = {'test': 'test'}

    with open(json_file, 'w') as f:
        data = json.dump(replacements, f, indent=2)

    context = load("./", json_file)

    assert 'test' in context
    assert context['test'] == 'test'

    os.remove(json_file)


# Generated at 2022-06-21 10:59:51.320265
# Unit test for function dump
def test_dump():
    dump('/Users/pc/Desktop/cookiecutter-jupyter/cookiecutter-jupyter/.cookiecutters', 'cookiecutter-jupyter', {'cookiecutter':{'project_name':'test', 'project_slug':'test'}})


# Generated at 2022-06-21 10:59:55.670682
# Unit test for function get_file_name
def test_get_file_name():
    assert os.path.join('replay', 'test.json') == get_file_name('replay', 'test')
    assert os.path.join('replay', 'test.json') == get_file_name('replay', 'test.json')

try:
    from unittest.mock import Mock, patch
except ImportError as _:
    from mock import Mock, patch

# Generated at 2022-06-21 10:59:59.525732
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'examples'
    template_name = 'cookiecutter-pypackage'
    full_path = os.path.join(replay_dir, template_name + '.json')
    assert full_path == get_file_name(replay_dir, template_name)


# Generated at 2022-06-21 11:00:01.932563
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load'
    replay.load(replay_dir, template_name)


# Generated at 2022-06-21 11:00:07.160739
# Unit test for function dump
def test_dump():
    template_name = 'test'
    context = {
        'cookiecutter': {
            'full_name': 'mona',
            'email': 'mona@xyz.com',
            'project_name': 'test-project'
        }
    }
    dump('/tmp/replay', template_name, context)
    assert os.path.isfile(get_file_name('/tmp/replay', template_name))



# Generated at 2022-06-21 11:00:11.367992
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "~/.cookiecutter_replay"
    template_name = "my_template"
    replay_file = "~/.cookiecutter_replay/my_template.json"

    assert replay_file == get_file_name(replay_dir, template_name) 


# Generated at 2022-06-21 11:00:20.977698
# Unit test for function dump
def test_dump():
    os.chdir('/home/tianji/Documents/cookiecutter-biendata')
    try:
        os.mkdir('./tests/test-replay')
    except FileExistsError:
        pass
    try:
        os.mkdir('./tests/test-replay/python')
    except FileExistsError:
        pass

    replay_dir = './tests/test-replay/python'
    template_name = 'cookiecutter-python'

# Generated at 2022-06-21 11:01:03.782575
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.getcwd()
    template_name = "context"
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == "./context.json"


# Generated at 2022-06-21 11:01:05.915326
# Unit test for function load
def test_load():

    context = load('replay/', 'test')
    assert 'test' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    # print context['cookiecutter']


# Generated at 2022-06-21 11:01:07.188023
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name(replay_dir="replay", template_name="template") == "replay/template.json"


# Generated at 2022-06-21 11:01:11.134303
# Unit test for function load
def test_load():
    import cookiecutter
    context = cookiecutter.replay.load('.cookiecutter_replay', 'context')
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'

# Generated at 2022-06-21 11:01:15.445271
# Unit test for function load
def test_load():
    context = load(replay_dir='/home/zsun/HG/cookiecutter-bioinformatics/cookiecutter-bioinformatics/cookiecutter_replay/bb2',template_name='bb2')
    print(context)


# Generated at 2022-06-21 11:01:19.868789
# Unit test for function get_file_name
def test_get_file_name():
    # Configuring inputs
    replay_dir = '/home/david/test'
    template_name = 'ansible-role-test'
    expected = '/home/david/test/ansible-role-test.json'
    output = get_file_name(replay_dir, template_name)
    assert output == expected


# Generated at 2022-06-21 11:01:29.615192
# Unit test for function dump
def test_dump():
    from tempfile import mkdtemp
    from shutil import rmtree

    template_name = 'test_template'
    context = {
        'cookiecutter': {
            'test_1': 'value_1',
            'test_2': {'test_3': 'value_3'}
        }
    }
    test_dir = mkdtemp()

    try:
        dump(test_dir, template_name, context)

        # Test file exists
        assert os.path.join(test_dir, template_name + '.json')

        # Test file is valid json
        context_loaded = load(test_dir, template_name)
        assert context_loaded == context
    finally:
        rmtree(test_dir)

# Generated at 2022-06-21 11:01:41.234347
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'url': 'https://github.com/audreyr/cookiecutter-pypackage',
            'project_name': 'FSND-Capstone',
            'repo_name': 'FSND-Capstone',
            'project_short_description': 'FSND-Capstone',
            '_template': 'https://github.com/udacity/FSND-Capstone.git',
            'version': '0.1.0',
            'release_date': '2017/10/30',
            'year': '2017'
        }
    }
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')

# Generated at 2022-06-21 11:01:44.640510
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/path/to/', 'hello') == '/path/to/hello.json'
    assert get_file_name('/path/to/', 'hello.json') == '/path/to/hello.json'

# Generated at 2022-06-21 11:01:51.456837
# Unit test for function get_file_name
def test_get_file_name():
    # create directory
    tmp_replay_dir = 'tmp_replay'
    if not make_sure_path_exists(tmp_replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(tmp_replay_dir))
    
    file_name = get_file_name(tmp_replay_dir,"test")
    assert "tmp_replay/test.json" == file_name
    file_name = get_file_name(tmp_replay_dir,"test.json")
    assert "tmp_replay/test.json" == file_name
