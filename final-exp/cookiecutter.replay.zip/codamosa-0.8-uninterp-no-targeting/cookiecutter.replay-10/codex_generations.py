

# Generated at 2022-06-21 10:53:01.203688
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = os.getcwd()
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'full_name': 'Audrey Roy Greenfeld'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, 'cookiecutter-pypackage.json'))
    with open(os.path.join(replay_dir, 'cookiecutter-pypackage.json'), 'r') as json_file:
        data = json.load(json_file)
        assert data == context



# Generated at 2022-06-21 10:53:13.302939
# Unit test for function load
def test_load():
    # make template_name = "cookiecutter-pypackage"
    # make context = {'cookiecuteer':{"full_name": "faker1", "email": "faker2", "project_name": "faker3", "repo_name": "faker4"},"_template": "cookiecutter-pypackage"}
    # the result is:
    # 'cookiecutter' key value is: {'email': 'faker2', 'full_name': 'faker1', 'project_name': 'faker3', 'repo_name': 'faker4'}, 
    # '_template' key value is: 'cookiecutter-pypackage'
    # load result: True
    context = load(None,"cookiecutter-pypackage")

# Generated at 2022-06-21 10:53:18.969438
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Foo Bar'
    assert context['cookiecutter']['project_slug'] == 'foo_bar'
    assert context['cookiecutter']['repo_name'] == 'foobar'
    assert context['cookiecutter']['pypi_username'] == 'foobar'
    assert context['cookiecutter']['author_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'

# Generated at 2022-06-21 10:53:30.420026
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name."""
    template_name = 'cookiecutter-pypackage'
    replay_dir = os.getcwd()
    assert get_file_name(replay_dir, template_name) == os.path.join(os.getcwd(), 'cookiecutter-pypackage.json')

    template_name = 'cookiecutter-pypackage.json'
    replay_dir = os.getcwd()
    assert get_file_name(replay_dir, template_name) == os.path.join(os.getcwd(), 'cookiecutter-pypackage.json')

    template_name = 'cookiecutter-pypackage'
    replay_dir = ''
    assert get_file_name(replay_dir, template_name) == os.path

# Generated at 2022-06-21 10:53:40.547779
# Unit test for function dump
def test_dump():
    expected_context = {"cookiecutter": {"_template": "https://github.com/audreyr/cookiecutter-pypackage.git"}}
    replay_dir = '~/.cookiecutter_replay'
    template_name = 'https:__github.com_audreyr_cookiecutter-pypackage.git'

    try:
        dump(replay_dir, template_name, expected_context)
        context = load(replay_dir, template_name)
    finally:
        os.remove(get_file_name(replay_dir, template_name))

    assert context == expected_context


# Generated at 2022-06-21 10:53:42.762814
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = 'tests'
    replay_file = get_file_name(replay_dir, 'replay_file')
    assert replay_file == 'tests/replay_file.json'


# Generated at 2022-06-21 10:53:46.487959
# Unit test for function load
def test_load():
    context = load("/home/alan/repos/cookiecutter-flask", "cookiecutter.json")
    assert(context['cookiecutter']['project_name'] == 'Flask Basic App')

# Generated at 2022-06-21 10:53:54.698596
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join("test_replay_dir", "replay_dir")
    context = {'cookiecutter': {'full_name': 'Paul Gowder', 'email': 'paul.gowder@gmail.com'}}
    dump(replay_dir, "paul-gowder-cookiecutter-gh-template", context)
    assert os.path.exists(os.path.join(replay_dir, "paul-gowder-cookiecutter-gh-template.json"))


# Generated at 2022-06-21 10:54:00.329821
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {
        'full_name': 'John Smith',
        'email': 'john@example.com',
        'github_username': 'jsmith',
        'project_name': 'Test Project'
    }}
    template_name = "cookiecutter-pypackage"
    replay_dir = "replay"
    result = dump(replay_dir, template_name, context)
    print(result)


# Generated at 2022-06-21 10:54:02.975764
# Unit test for function get_file_name
def test_get_file_name():
    #input
    replay_dir = 'directory'
    template_name = 'default'

    file_name = get_file_name(replay_dir, template_name)

    assert file_name == 'directory/default.json'


# Generated at 2022-06-21 10:54:15.290907
# Unit test for function dump
def test_dump():
    dir = 'cookiecutter'
    name = 'cookiecutter'
    context = {'cookiecutter':{'project_name':'cookiecutter','author_name':'cookiecutter','author_email':'cookiecutter','open_source_license':'cookiecutter','github_account':'cookiecutter','github_project':'cookiecutter','repo_name':'cookiecutter','date':'cookiecutter'}}
    dump(dir, name, context)

    with open(get_file_name(dir, name), 'r') as infile:
        json_context = json.load(infile)
    assert json_context == context, 'dump context error'
    os.remove(get_file_name(dir, name))
    os.rmdir(dir)


# Generated at 2022-06-21 10:54:16.745819
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'foobar'
    context = load(replay_dir, template_name)


# Generated at 2022-06-21 10:54:26.178072
# Unit test for function dump
def test_dump():
    replay_dir = "tests/test-output/replay"
    template_name = "tests/fake-repo-pre/{{cookiecutter.repo_name}}"
    context = {
        "cookiecutter": {
            "repo_name": "foobar",
            "project_name": "Python Boilerplate",

        }
    }

    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-21 10:54:31.537938
# Unit test for function get_file_name
def test_get_file_name():
    # when the file name is a string
    assert get_file_name('', 'string') == 'string.json'
    # when the file name is a json
    assert get_file_name('', 'json.json') == 'json.json'


# Generated at 2022-06-21 10:54:37.074418
# Unit test for function load
def test_load():
    template_name = "test"
    replay_dir = "/tmp/"
    context = {}
    context['cookiecutter'] = {'name': 'test'}

    dump(replay_dir, template_name, context)

    contexts = load(replay_dir, template_name)
    print(contexts)



# Generated at 2022-06-21 10:54:41.816114
# Unit test for function load
def test_load():
    replay_dir = "C:\\Users\\rongr\\Documents\\GitHub\\cookiecutter-pypackage-minimal\\{{cookiecutter.repo_name}}"
    template_name = ".cookiecutter"
    context = load(replay_dir, template_name)
    print(context)
    print(context["cookiecutter"])


# Generated at 2022-06-21 10:54:53.172233
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(
            os.path.expanduser('~'),
            '.cookiecutters'
            )
    template_name = 'test_template'

# Generated at 2022-06-21 10:54:58.458437
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = './'
    template_name = 'test1.json'
    assert get_file_name(replay_dir, template_name) == './test1.json'
    template_name = 'test2'
    assert get_file_name(replay_dir, template_name) == './test2.json'


# Generated at 2022-06-21 10:55:03.437277
# Unit test for function load
def test_load():
    replay_dir ='/Users/anastasiia_shcherbina/Cookiecutter/cookicutter-replay/replay'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert(context['cookiecutter']['full_name'] =='Anastasiia Shcherbina')


# Generated at 2022-06-21 10:55:08.014891
# Unit test for function get_file_name
def test_get_file_name():
    expected_output = 'replay/cookiecutter-pypackage.json'
    output = get_file_name('replay', 'cookiecutter-pypackage')

    assert output == expected_output


# Generated at 2022-06-21 10:55:11.184671
# Unit test for function load
def test_load():
    context = load("replay", "mde-project-template")
    assert 'cookiecutter' in context

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-21 10:55:19.909300
# Unit test for function dump
def test_dump():
    '''
    Dump unit tests
    '''
    replay_dir = './'
    template_name = 'test'
    context = {}
    context['cookiecutter'] = {}

    dump(replay_dir, template_name, context)
    from_file_context = load(replay_dir, template_name)
    assert(context == from_file_context)

    assert(isinstance(template_name, str))

    template_name = 5
    try:
        dump(replay_dir, template_name, context)
    except TypeError:
        assert(1 == 1)
    else:
        assert(1 == 0)

    template_name = 'test'
    try:
        dump(replay_dir, template_name, [])
    except TypeError:
        assert(1 == 1)

# Generated at 2022-06-21 10:55:24.746674
# Unit test for function dump

# Generated at 2022-06-21 10:55:34.447121
# Unit test for function load
def test_load():
    assert load('/Users/user/work/be-pays-engine/cookiecutter-django-crud/tests/fake-repo-pre', '/Users/user/work/be-pays-engine/cookiecutter-django-crud/tests/fake-repo-pre/fake_project_slug') == {'cookiecutter': {'app_name': 'helloworld', 'project_name': 'helloworld', 'project_slug': 'helloworld', 'year': '2015', 'author_name': 'Audrey Roy', 'email': 'audreyr@gmail.com', 'description': 'helloworld description', 'domain_name': 'helloworld.com', 'version': '0.1.0', 'timezone': 'UTC', 'use_pycharm': 'n'}}

# Generated at 2022-06-21 10:55:41.867714
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join("/home", "hongbo", "code", "cctest", "test_cookiecutter")
    template_name = "cookiecutter-pypackage-hongbo"
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, template_name + ".json")

if __name__ == '__main__':
    test_get_file_name()

# Generated at 2022-06-21 10:55:50.109101
# Unit test for function dump
def test_dump():
    """Test dump."""
    replay_dir = "test"
    template_name = "test"
    context = {'cookiecutter': 'test'}
    dump(replay_dir, template_name, context)
    test_file = get_file_name(replay_dir, template_name)
    with open(test_file, 'r') as infile:
        test_context = json.load(infile)
    assert test_context == context
    os.remove(test_file)
    os.rmdir(replay_dir)


# Generated at 2022-06-21 10:55:57.661011
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/home/user/replay"
    template_name = "python-package"
    file_name_with_suffix = get_file_name(replay_dir, template_name)
    assert file_name_with_suffix == "/home/user/replay/python-package.json"
    template_name = "python-package.json"
    file_name_without_suffix = get_file_name(replay_dir, template_name)
    assert file_name_without_suffix == "/home/user/replay/python-package.json"


# Generated at 2022-06-21 10:56:03.050942
# Unit test for function get_file_name
def test_get_file_name():
    input_replay_dir = "Any Dir"
    input_template_name = "Any Name"
    expected_result = "Any Dir/Any Name.json"
    actual_result = get_file_name(input_replay_dir, input_template_name)
    assert actual_result == actual_result


# Generated at 2022-06-21 10:56:07.026079
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("replay", "test_1") == "replay/test_1.json"
    assert get_file_name("replay", "test_2.json") == "replay/test_2.json"


# Generated at 2022-06-21 10:56:08.976215
# Unit test for function load
def test_load():
    replay_dir = os.getcwd()
    template_name = '{{cookiecutter.repo_name}}'
    context = load(replay_dir, template_name)
    print(context)



# Generated at 2022-06-21 10:56:17.833844
# Unit test for function get_file_name
def test_get_file_name():

    replay_dir = './replay'
    template_name = 'cookiecutter-pypackage'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == './replay/cookiecutter-pypackage.json'

    template_name = 'cookiecutter-pypackage.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == './replay/cookiecutter-pypackage.json'


# Generated at 2022-06-21 10:56:18.937069
# Unit test for function dump
def test_dump():
    assert True


# Generated at 2022-06-21 10:56:27.538916
# Unit test for function load
def test_load():
    from cookiecutter.utils import rmtree
    from shutil import copytree, copyfile

    replay_dir = "tests/test-load"
    rmtree(replay_dir)
    copytree("tests/fixtures/fake-repo", replay_dir)
    template_name = "fake-repo"
    context = load(replay_dir, template_name)
    print(context)
    assert(type(context) == dict)
    assert(context["cookiecutter"]["full_name"] == "Audrey Roy")
    rmtree(replay_dir)

# Generated at 2022-06-21 10:56:32.286103
# Unit test for function load
def test_load():
    replay_dir = os.path.dirname(os.path.abspath(__file__))
    template_name = 'replay'
    context = load(replay_dir, template_name)
    print (context['cookiecutter'])
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-21 10:56:37.721933
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = '/home/xiexiang/test'
    template_name = 'django-app'
    context = {'cookiecutter':{'name':'test-app'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:56:41.743359
# Unit test for function load
def test_load():
    replay_dir = '~/cookiecutter-replay'
    template_name = 'template-name'
    loaded_context = load(replay_dir, template_name)
    assert loaded_context['cookiecutter']['full_name'] == 'your_name'

# Generated at 2022-06-21 10:56:46.508938
# Unit test for function load
def test_load():

    def temp_file(name, content):
        with open(name, "w") as f:
            f.write(content)

    temp_file("test_file", '{"cookiecutter": {"key": "value"}}')
    result = load(".", "test_file")
    assert result == {"cookiecutter": {"key": "value"}}
    os.remove("test_file")



# Generated at 2022-06-21 10:56:52.816948
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    from cookiecutter.main import cookiecutter

    template_name = 'cookiecutter-pypackage'
    replay_dir = './test'

    cookiecutter(template_name, replay_dir=replay_dir, no_input=True)
    cookiecutter(template_name, replay_dir=replay_dir, no_input=True)

    assert os.path.exists(replay_dir)
    assert os.path.exists(replay_dir + '/' + template_name + '.json')



# Generated at 2022-06-21 10:57:02.824884
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/'
    template_name = 'fake-repo-pre'

    context={'cookiecutter': {'full_name': 'Pablo', 'email': 'p@p.com',
        'project_name': 'faker'}}
    try:
        dump(replay_dir, template_name, context)
    except IOError as e:
        assert False, "Failed to dump replay file"
    except TypeError as e:
        assert False, "Failed to dump replay file"
    except ValueError as e:
        assert False, "Failed to dump replay fil"



# Generated at 2022-06-21 10:57:10.362571
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'project_slug': 'pyspark-example',
            'open_source_license': 'Apache Software License 2.0'
        }
    }
    replay_dir = '~/.cookiecutters'
    template_name = 'https://github.com/pahud/cookiecutter-pyspark-example'
    dump(replay_dir, template_name, context)
    print(replay_dir + '/' + template_name + '.json')

# Generated at 2022-06-21 10:57:16.316800
# Unit test for function dump
def test_dump():
    test_data = {
        'a':1,
        'b':2
    }
    test_file = "test_file.json"
    dump(".", test_file, test_data)
    with open(test_file, 'r') as f:
        d = json.load(f)
        assert d == test_data
    os.remove(test_file)


# Generated at 2022-06-21 10:57:27.286581
# Unit test for function load
def test_load():
    """Test load function."""
    # Setup
    test_dict = {
        "cookiecutter": {
            "replay_dir": "tests/test-replay",
            "no_input": True
        }
    }
    test_template_name = 'fake-template'
    dump(test_dict["cookiecutter"]["replay_dir"], test_template_name, test_dict)

    # Actual test
    result = load(test_dict["cookiecutter"]["replay_dir"], test_template_name)

    # Teardown
    os.remove(get_file_name(test_dict["cookiecutter"]["replay_dir"], test_template_name))

    # Assertions
    assert(len(result.keys()) == 1)

# Generated at 2022-06-21 10:57:28.794739
# Unit test for function load
def test_load():
  context = load("/Users/azeroth/Desktop/template1","test")
  print(context)

test_load()

# Generated at 2022-06-21 10:57:35.040498
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    text = 'test.json'
    replay_dir = 'tests'
    try:
        file_name = get_file_name(replay_dir, text)
        assert file_name == 'tests/test.json'
    except:
        raise ValueError('Wrong file_name: {0}'.format(file_name))

    text = 'test'
    replay_dir = 'tests'
    try:
        file_name = get_file_name(replay_dir, text)
        assert file_name == 'tests/test.json'
    except:
        raise ValueError('Wrong file_name: {0}'.format(file_name))


# Generated at 2022-06-21 10:57:46.196772
# Unit test for function load
def test_load():
    """Unit test for load function"""
    # Create a temp directory
    import tempfile
    path = tempfile.mkdtemp()

    # Create a valid json file
    import datetime
    data = {'cookiecutter':
                {'full_name': 'Test User',
                 'email': 'test@user.com',
                 'project_name': 'Unit Test',
                 'project_slug': 'unit-test',
                 'package_name': 'unit_test',
                 'release_date': datetime.date.today().isoformat(),
                 'year': datetime.datetime.now().year,
                    }
            }
    with open(os.path.join(path, 'test.json'), 'w') as outfile:
        json.dump(data, outfile, indent=2)

    # Test load
   

# Generated at 2022-06-21 10:57:49.534780
# Unit test for function dump
def test_dump():
    replay_dir = "../replay/"
    template_name = "../template/"
    context = {'context': "context"}

    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:57:53.446452
# Unit test for function dump
def test_dump():
    template_name = 'test'
    replay_dir = '/tmp'
    context = {'cookiecutter': {'name': 'alice'}}
    dump(replay_dir, template_name, context)
    assert(load(replay_dir, template_name)== context)


# Generated at 2022-06-21 10:58:04.782669
# Unit test for function dump
def test_dump():
    import tempfile
    import os

    # Test context
    _cookiecutter = {}
    _cookiecutter['replay'] = True

    context = {}
    context['cookiecutter'] = _cookiecutter
    context['project_name'] = 'Test Project Name'
    context['project_slug'] = 'test_project_slug'
    context['project_short_description'] = 'Test project short description'
    context['replay_dir'] = tempfile.mkdtemp()

    # Test dump
    dump(
        replay_dir=context['replay_dir'],
        template_name='fake_template',
        context=context
    )

    # Check if file exists

# Generated at 2022-06-21 10:58:10.969417
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import sys
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    try:
        test_file_name = os.path.join(temp_dir, 'testsave.json')
        test_context = {'test_key': 'test_val'}

        dump(temp_dir, 'testsave', test_context)
        with open(test_file_name, 'r') as infile:
            assert test_context == json.load(infile)
    finally:
        try:
            os.remove(test_file_name)
        except OSError:
            pass
        shutil.rmtree(temp_dir, ignore_errors=True)



# Generated at 2022-06-21 10:58:15.552572
# Unit test for function load
def test_load():
    template_name = 'py-pack-proj'
    replay_dir = "replay"

    context = load(replay_dir, template_name)
    print(context)
    print(context.get('cookiecutter'))
    print(context.get('cookiecutter').get('package_name'))


# Generated at 2022-06-21 10:58:23.442020
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for get_file_name function."""
    replay_dir = '/tmp/cookiecutter-replay/'
    template_name = 'template'
    expected_replay_file = '/tmp/cookiecutter-replay/template.json'
    actual_replay_file = get_file_name(replay_dir, template_name)
    assert actual_replay_file == expected_replay_file



# Generated at 2022-06-21 10:58:24.732372
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "test"
    template_name = "test"
    test_output = get_file_name(replay_dir, template_name)
    assert test_output == "test/test.json"

# Generated at 2022-06-21 10:58:33.870022
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'empty-cookiecutter-project'
    context = {'cookiecutter': {'author': 'Nilay Mehta', 'email': 'nilayhmehta@gmail.com', 'full_name': 'Nilay Mehta', 'github_username': 'nilayhmehta'}}
    dump(replay_dir, template_name, context)
    expected_path = 'tests/files/test-replay/empty-cookiecutter-project.json'
    assert os.path.exists(expected_path) == True
    os.remove(expected_path)



# Generated at 2022-06-21 10:58:38.500637
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = './'
    template_name = 'template-repository'
    #result = './template-repository.json'
    assert get_file_name(replay_dir, template_name) == './template-repository.json'



# Generated at 2022-06-21 10:58:46.477526
# Unit test for function load
def test_load():
    """Unit test for function load."""
    # Test valid input
    input_template_name = 'template_name'
    input_context = {
        'cookiecutter': {
            'foo': 'bar'
        }
    }
    dump('/tmp', input_template_name, input_context)
    result_context = load('/tmp', input_template_name)
    assert input_context == result_context

    # Test invalid input
    invalid_input_template_name = 'template_name'
    invalid_input_context = {
        'not_cookiecutter': {
            'foo': 'bar'
        }
    }
    dump('/tmp', invalid_input_template_name, invalid_input_context)

# Generated at 2022-06-21 10:58:51.361519
# Unit test for function dump
def test_dump():
    replay_dir = "C:\\Users\\c_lxx\\Dropbox\\cookiecutter-examples\\demo\\"
    template_name = "template2"
    context = {'cookiecutter': {'repo_name': 'myproject'}}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-21 10:58:58.320560
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/replay-data/'
    template_name = 'my-awesome-project'
    context = {
        "cookiecutter": {
            "author_name": "Test",
            "email": "test@test.com"
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:59:02.963866
# Unit test for function load
def test_load():
    try:
        c=load('E:\Projects\python\cookiecutter-master\cookiecutter-master\tests\test-data\fake-replay', 'example_python')
    except ValueError:
        print('Context is required to contain a cookiecutter key')

test_load()

# Generated at 2022-06-21 10:59:05.426429
# Unit test for function load
def test_load():
    """Unit test for function load."""
    assert load('replays', 'test_load') == {'cookiecutter': {'replay': 'True'}}


# Generated at 2022-06-21 10:59:08.863974
# Unit test for function load
def test_load():
    replay_dir = 'C:/Users/wentaoyan/Desktop/replay'
    template_name = 'cookiecutter-pypackage-min'
    context = load(replay_dir, template_name)
    print(context)


if __name__ == "__main__":
    test_load()

# Generated at 2022-06-21 10:59:18.685084
# Unit test for function dump
def test_dump():
    json_data = {'cookiecutter': {'name': 'dummy_name'}}
    replay_dir = 'tests/test_replay_dir'
    template_name = 'dummy_template_name'
    dump(replay_dir, template_name, json_data)

    expected_json_data = load(replay_dir, template_name)

    os.remove(replay_dir+'/'+template_name)



# Generated at 2022-06-21 10:59:20.094331
# Unit test for function load
def test_load():
    load('./cookiecutter.json', '')


# Generated at 2022-06-21 10:59:26.668987
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name"""
    replay_dir = 'fake_dir'
    template_name = 'fake_template_name'

    assert replay_dir == 'fake_dir'
    assert template_name == 'fake_template_name'

    expected = 'fake_dir/fake_template_name.json'
    result = get_file_name(replay_dir, template_name)
    assert result == expected



# Generated at 2022-06-21 10:59:34.930433
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    template_name = 'test_template'
    replay_dir = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'tests', 'test-repo-tmpl')

# Generated at 2022-06-21 10:59:44.726757
# Unit test for function dump
def test_dump():
    replay_file = 'test.json'
    open(replay_file, 'w').close()
    replay_context = {
        "cookiecutter": {
            "full_name": "Audrey Roy Greenfeld",
            "email": "audreyr@example.com",
            "github_username": "audreyr",
            "project_name": "sampleproject",
            "project_slug": "sampleproject",
            "project_short_description": "A short description of the project.",
            "pypi_username": "audreyr",
            "version": "0.1",
            "_template": "{{cookiecutter.repo_name}}",
            "release_date": "2014-08-13"
        }
    }
    dump('', replay_file, replay_context)
    assert os.path

# Generated at 2022-06-21 10:59:52.473179
# Unit test for function get_file_name
def test_get_file_name():

    # The replay_dir and template_name to use in the test.
    replay_dir = '/home/user'
    template_name = 'myreplay'

    # Assert that the test replay_dir and template_name are of type string.
    assert isinstance(replay_dir, str) and isinstance(template_name, str)

    # Create the replay file name to be tested.
    replay_file_name = get_file_name(replay_dir, template_name)

    # Assert that the replay file name is the expected value.
    assert replay_file_name == '/home/user/myreplay.json'



# Generated at 2022-06-21 10:59:58.123457
# Unit test for function dump
def test_dump():
    """Test to dump data to file."""
    replay_dir = '/tmp/test_cookiecutter'
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'project_name': 'my_pypackage'}}
    dump(replay_dir, template_name, context)
    dumped_context = load(replay_dir, template_name)
    assert(context == dumped_context)



# Generated at 2022-06-21 11:00:07.124362
# Unit test for function load
def test_load():
    """Test load function."""
    from cookiecutter.main import cookiecutter

    context = {
        'full_name': 'Test User',
        'email': 'test@example.org',
        'cookiecutter': {
            'full_name': 'Test User',
            'email': 'test@example.org',
            'replay_dir': 'tests/test-replay',
            'no_input': True
        }
    }

    replay_dir = os.path.abspath('tests/test-replay')
    template_name = 'tests/fake-repo-pre/'

    # Create replay file first before testing load function
    dump(replay_dir, template_name, context)

    # Check that load returns the same context that was dumped

# Generated at 2022-06-21 11:00:16.842491
# Unit test for function load
def test_load():
    template_name = 'test_load.json'
    replay_dir = 'test_load'
    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))
        
    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'w') as outfile:
        json.dump({1:1}, outfile, indent=2)

    try:
        context = load(replay_dir, template_name)
    except Exception:
        print("OK")
    os.remove(replay_file)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-21 11:00:20.677020
# Unit test for function dump
def test_dump():
    from cookiecutter.prompt import read_user_choice
    from cookiecutter.main import cookiecutter
    context = cookiecutter(".", no_input=True, replay=True, replay_dir="testing")
    assert make_sure_path_exists("testing") 
    assert dump("testing", ".", context) == None



# Generated at 2022-06-21 11:00:31.423094
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = '{}/{}'.format(os.path.dirname(os.getcwd()), '.cookiecutters')
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'full_name': 'Audrey Roy Greenfeld'}}
    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)
    assert context_loaded == {'cookiecutter': {'full_name': 'Audrey Roy Greenfeld'}}

# Generated at 2022-06-21 11:00:35.566561
# Unit test for function get_file_name
def test_get_file_name():
    assert(get_file_name("/tmp","foo") == "/tmp/foo.json")
    assert(get_file_name("/tmp","foo.json") == "/tmp/foo.json")
    assert(get_file_name("/tmp/","foo.json") == "/tmp/foo.json")
    assert(get_file_name("/tmp/","foo") == "/tmp/foo.json")

# Generated at 2022-06-21 11:00:36.374778
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-21 11:00:44.318710
# Unit test for function dump
def test_dump():
    # Test 1: success
    import tempfile
    # context = '{{cookiecutter.lower_case_var}}'# load the cookiecutter.json
    # template_name = 'test_template'# load the template name
    replay_dir = tempfile.gettempdir()# get the place to store the data
    # replay_file = '{}/{}.json'.format(replay_dir, template_name)
    context = json.load('{{cookiecutter.lower_case_var}}')
    dump(replay_dir, template_name, context)# call the dump function
    assert os.path.exists(replay_file)
    # clean up
    os.remove(replay_file)
    
    # test 2: raise IOError - make_sure_path_exists failed
    # raised by function

# Generated at 2022-06-21 11:00:48.050554
# Unit test for function dump
def test_dump():
    replay_dir = 'tmp'
    template_name = 'my-template'
    context = {
        'cookiecutter': {
            'name': 'John Doe',
            'version': '1.2.3',
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 11:00:50.172413
# Unit test for function load
def test_load():
    replay_dir = os.getcwd()
    template_name = 'cookiecutter-pypackage'
    load(replay_dir, template_name)


# Generated at 2022-06-21 11:00:56.056321
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/replay'
    template_name = 'sample-template'
    context = {'cookiecutter': {'cookie': 'chocolate chip'}}
    replay_file = get_file_name(replay_dir, template_name)

    dump(replay_dir, template_name, context)
    assert os.path.exists(replay_file)
    os.remove(replay_file)


# Generated at 2022-06-21 11:01:03.524067
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'test'
    template_name = 'hello'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, 'hello.json')
    template_name = 'hello.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, 'hello.json')


# Generated at 2022-06-21 11:01:11.098740
# Unit test for function dump
def test_dump():
    from tempfile import mkdtemp
    from shutil import rmtree
    from textwrap import dedent

    template_name = 'mytesttemplate'

# Generated at 2022-06-21 11:01:14.977869
# Unit test for function dump
def test_dump():
    replay_dir = r"/home/yuqi/PycharmProjects/test/tests/test_replay"
    dump(replay_dir, "hello", {"x": "a", "y": "b"})



# Generated at 2022-06-21 11:01:30.027638
# Unit test for function dump
def test_dump():
    replay_dir = '~/replay_dir'
    template_name = 'test_dump'
    context = 'replay_value'
    dump(replay_dir, template_name, context)
    if load(replay_dir, template_name) == 'replay_value':
        print('test_dump pass')


# Generated at 2022-06-21 11:01:36.675460
# Unit test for function load
def test_load():
    # Test a valid json file
    replay_dir = os.path.join(os.path.dirname(__file__), 'files', 'replays')
    assert load(replay_dir, '_0.1.1-rc.1')['cookiecutter']['full_name'] == 'audreyr'
    # Test a non-existing file
    assert load(replay_dir, 'non-existing-file') == {}

# Generated at 2022-06-21 11:01:41.281656
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    res = get_file_name("", "foo")
    assert res == "foo.json"

    res = get_file_name("", "foo.json")
    assert res == "foo.json"



# Generated at 2022-06-21 11:01:43.230213
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name(replay_dir='tmp',template_name='t') == os.path.join('tmp', 't.json')



# Generated at 2022-06-21 11:01:47.498588
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/tmp', 'awesome') == '/tmp/awesome.json'
    assert get_file_name('/tmp', 'awesome.json') == '/tmp/awesome.json'
    assert get_file_name('/tmp', 'awesome.zip') == '/tmp/awesome.zip.json'

# Generated at 2022-06-21 11:01:55.799374
# Unit test for function load
def test_load():
    # Test to make sure that the function load returns the right values in a dictionary
    replay_dir = '/Users/jesuscarrera/PycharmProjects/cookiecutter_selenium_test/cookiecutter_selenium_test/tests/fake-repo-pre/'
    template_name = 'selenium-test-master'

# Generated at 2022-06-21 11:02:07.778530
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile
    import shutil
    import json

    # 1. Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # 2. Create a replay object
    replay_dir = tmp_dir
    template_name = 'python_cookiecutter'

    full_path = os.path.join(tmp_dir, template_name + '.json')
    print(full_path)

    assert os.path.exists(full_path) is False


# Generated at 2022-06-21 11:02:11.054009
# Unit test for function load
def test_load():
    replay_file = os.path.join(os.getcwd() , 'default.json')
    with open(replay_file,'r') as infile:
        context = json.load(infile)
    assert 'cookiecutter' in context

# Generated at 2022-06-21 11:02:15.262965
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    template = "{{cookiecutter.name}}"
    context = {'cookiecutter': {'name': 'Test'}, 'custom_value': 'custom'}
    dump('./', 'test', context)
    assert os.path.isfile('./test.json')
    assert context == load('./', 'test')
    os.remove('./test.json')


# Generated at 2022-06-21 11:02:20.928769
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = './test/replay'
    template_name = 'test_cookiecutter_project'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == "./test/replay/test_cookiecutter_project.json"


# Generated at 2022-06-21 11:02:54.053626
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile
    import datetime
    from cookiecutter.main import cookiecutter

    template_name = 'a'
    now = datetime.datetime.now()
    output_dir = tempfile.mkdtemp()
    template_dir = os.path.join(output_dir, 'a')
    os.mkdir(template_dir)

    context = {
        'cookiecutter': {
            'foo': 'bar',
            '_template': template_name,
            '_date': now
        }
    }
