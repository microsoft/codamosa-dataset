

# Generated at 2022-06-21 10:52:58.839045
# Unit test for function load
def test_load():
    '''Unit test for function load'''
    replay_dir = "abc"
    template_name = "abc"
    context = load(replay_dir,template_name)


# Generated at 2022-06-21 10:53:04.567166
# Unit test for function dump
def test_dump():
    """
    Unit test for the function dump.
    """
    replay_dir = "D:/test_directory"
    template_name = "test_template"
    context = {"cookiecutter": {
        "author_name": "Test"
    }}

    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:53:13.298369
# Unit test for function load
def test_load():
    """Tests load()."""
    import json
    import os
    import cookiecutter.replay as replay

    # Write some sample json to a file
    with open('test_load.json', 'w') as outfile:
        json.dump({'relpath':'cookiecutter-pypackage', 'cookiecutter': {}}, outfile, indent=2)

    context = replay.load('.', 'test_load')

    # Clean up
    os.remove('test_load.json')

    assert context['relpath'] == 'cookiecutter-pypackage'


# Generated at 2022-06-21 10:53:18.971451
# Unit test for function dump
def test_dump():
    #init replay_dir
    replay_dir = "C:/Users/ZHANGJ40/Desktop/cookiecutter_test/cookiecutter/replay"
    #init template_name
    template_name = "test_dump"
    #init context
    context = {
        "cookiecutter": {
            "license": "MIT",
            "project_name": "test_dump",
            "repo_name": "zj",
            "project_slug": "test_dump",
            "author_name": "zj",
            "email": "zhangj40@126.com",
            "description": "test dump function",
            "domain_name": "example.com",
            "version": "0.1.0",
            "timezone": "UTC"
        }
    }
    #test dump

# Generated at 2022-06-21 10:53:28.878347
# Unit test for function get_file_name
def test_get_file_name():
    original_file_name = 'file.json'
    expected_file_name = 'file.json'

    replay_dir = 'tmp'

    file_name = get_file_name(replay_dir, original_file_name)

    assert file_name == os.path.join(replay_dir, expected_file_name)

    original_file_name = 'file.txt'
    expected_file_name = 'file.json'

    file_name = get_file_name(replay_dir, original_file_name)

    assert file_name == os.path.join(replay_dir, expected_file_name)


# Generated at 2022-06-21 10:53:32.456155
# Unit test for function dump
def test_dump():
    """Test function dump."""
    pass



# Generated at 2022-06-21 10:53:40.394898
# Unit test for function get_file_name
def test_get_file_name():
    """Get the name of file."""
    replay_dir='C:/Users/Administrator/Documents/cookiecutter'
    template_name='C:/Users/Administrator/Documents/cookiecutter/template1'
    suffix = '.json' if not template_name.endswith('.json') else ''
    file_name = '{}{}'.format(template_name, suffix)
    replay_file = os.path.join(replay_dir, file_name)
    assert get_file_name(replay_dir, template_name) == replay_file

# Generated at 2022-06-21 10:53:45.707274
# Unit test for function load
def test_load():
    """Unit test for the load function."""
    replay_dir = 'C:\\Dev\\cookiecutter-examples\\cookiecutter-pypackage'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    
    return context


# Generated at 2022-06-21 10:53:54.194524
# Unit test for function dump
def test_dump():
    path = os.path.join(os.path.dirname(__file__), 'test')
    template_name = 'test_template'
    context = {
        'cookiecutter': {
            'full_name': "Juan C. Montoya",
            'email': "juan23@gmail.com",
            'github_username': "jcmoyan",
        }
    }

    dump(path, template_name, context)

    context_loaded = load(path, template_name)

    assert(context == context)

# Generated at 2022-06-21 10:54:00.534146
# Unit test for function dump
def test_dump():
    from cookiecutter import replay
    import json
    import os
    import shutil

    if os.path.exists('./tests/test-output/replay'):
        shutil.rmtree('./tests/test-output/replay')

    replay_dir = os.path.abspath('./tests/test-output/replay')
    template_name = 'test-template'
    context = {
        'cookiecutter': {
            'full_name': 'Test User',
            'email': 'test@example.com',
            'project_name': 'Test Project',
        }
    }

    replay.dump(replay_dir, template_name, context)

    assert(os.path.exists('./tests/test-output/replay/test-template.json'))

   

# Generated at 2022-06-21 10:54:09.465601
# Unit test for function dump
def test_dump():
    """Unit test of function dump."""
    test_file = './tests/test_dump.json'
    context = {'cookiecutter': {'name': 'unit_test_name', 'version': '0.0.0'}}
    dump('./tests/', 'test_dump', context)
    data = load('./tests/','test_dump')
    assert data == context
    os.remove(test_file)

# Generated at 2022-06-21 10:54:17.773600
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'full_name': 'James Bond',
            'email': '007@mi6.uk'
        }
    }
    replay_dir = 'tests/test_replay'
    template_name = 'tests/fake-repo-tmpl'

    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, 'fake-repo-tmpl.json'))
    assert context == load(replay_dir, template_name)
    os.remove(os.path.join(replay_dir, 'fake-repo-tmpl.json'))


# Generated at 2022-06-21 10:54:24.682873
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tests/test_replay_dir'
    # test when no suffix
    assert get_file_name(replay_dir, 'test') == 'tests/test_replay_dir/test.json'
    # test when has suffix
    assert get_file_name(replay_dir, 'test.json') == 'tests/test_replay_dir/test.json'


# Generated at 2022-06-21 10:54:33.818221
# Unit test for function get_file_name
def test_get_file_name():
    # test for no suffix
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    assert get_file_name(replay_dir, template_name) == 'test_replay_dir/test_template_name.json'
    # test for suffix
    template_name = 'test_template_name.json'
    assert get_file_name(replay_dir, template_name) == 'test_replay_dir/test_template_name.json'


# Generated at 2022-06-21 10:54:39.496470
# Unit test for function dump
def test_dump():
    template_name = 'TestFile'
    context = {'cookiecutter': {'name': 'Hello', 'age': '25'}}
    replay_dir = 'Test'

    dump(replay_dir, template_name, context)

    assert os.path.isfile(replay_dir+'/'+template_name+".json")



# Generated at 2022-06-21 10:54:46.618310
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name in replay module."""
    replay_dir = 'replays'
    template_name = 'template'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'replays/template.json'
    with open(file_name, 'w') as outfile:
        json.dump({'cookiecutter': {}}, outfile, indent=2)
    os.remove(file_name)



# Generated at 2022-06-21 10:54:55.180119
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for get_file_name."""
    replay_dir = ''
    template_name = 'test'

    # Get file_name with .json as suffix
    file_name = get_file_name(replay_dir, template_name)

    # Set expected_file_name
    expected_file_name = os.path.join(replay_dir, '{}.json'.format(template_name))

    assert file_name == expected_file_name, \
        'get_file_name failed to return expected file_name'



# Generated at 2022-06-21 10:54:56.361514
# Unit test for function load
def test_load():
    print("testing load...")


# Generated at 2022-06-21 10:55:01.002666
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    replay_dir = '/cookiecutter_replays'
    template_name = 'abcd'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/cookiecutter_replays/abcd.json'


# Generated at 2022-06-21 10:55:07.920034
# Unit test for function load
def test_load():
    import json
    import os
    import sys
    import time

    # Create a temporary directory to store the test cookiecutter.json file
    replay_dir = os.path.abspath(os.path.join(os.path.curdir, 'tests/files/test-replay-dir/'))
    # Get the complete file name of the cookiecutter.json file
    template_name = 'cookiecutter.json'

    # If a replay file for the test cookiecutter.json file exists, delete it
    if os.path.isfile(os.path.join(replay_dir, template_name + '.json')):
        os.remove(os.path.join(replay_dir, template_name + '.json'))

    # Load the replay file, it should be none

# Generated at 2022-06-21 10:55:14.988569
# Unit test for function get_file_name
def test_get_file_name():
    given_file_name = "cookiecutter"
    expected_result = "/tmp/cookiecutter.json"
    actual = get_file_name("/tmp", given_file_name)
    assert actual == expected_result
    actual = get_file_name("/tmp", "cookiecutter.json")
    assert actual == expected_result
    given_file_name = ""
    expected_result = "/tmp/"
    actual = get_file_name("/tmp", given_file_name)
    assert actual == expected_result


# Generated at 2022-06-21 10:55:22.888953
# Unit test for function dump
def test_dump():
    # positive case
    context = {'name': 'cookiecutter_name', 'version': '0.1', 'description': 'cookiedir'}
    replay_dir = 'replay/'
    template_name = 'python_cli'
    dump(replay_dir, template_name, context)

    # negative case: context should be dictionary

# Generated at 2022-06-21 10:55:32.455119
# Unit test for function dump
def test_dump():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import path

    replay_dir = mkdtemp()
    template_name = 'my_sweet_template'
    context = {
        'cookiecutter': {
            'full_name': 'Your Name',
            'email': 'your@email.com'
        }
    }
    dump(replay_dir, template_name, context)

    file_path = path.join(replay_dir, template_name + '.json')

    with open(file_path, 'r') as infile:
        assert json.load(infile) == context

    rmtree(replay_dir)


# Generated at 2022-06-21 10:55:36.983119
# Unit test for function get_file_name
def test_get_file_name():
    test_dir = 'test'
    template_name = 'template'
    file_name = template_name + '.json'
    file_name_2 = file_name + '.json'
    assert get_file_name(test_dir, template_name) == os.path.join(test_dir, file_name)
    assert get_file_name(test_dir, file_name) == os.path.join(test_dir, file_name)
    assert get_file_name(test_dir, file_name_2) == os.path.join(test_dir, file_name)

# Generated at 2022-06-21 10:55:45.882282
# Unit test for function dump
def test_dump():
    # Create a directory to dump the json file
    replay_dir = os.path.join(os.path.dirname(__file__), 'tests/dump')
    if not os.path.exists(replay_dir):
        os.makedirs(replay_dir)

    template_name = 'test'
    context = {"cookiecutter": {"interactive": True}}
    replay_file = get_file_name(replay_dir, template_name)
    try:
        dump(replay_dir, template_name, context)
        assert isinstance(replay_file, str)
        assert os.path.exists(replay_file)
    except IOError:
        raise IOError


# Generated at 2022-06-21 10:55:50.524370
# Unit test for function get_file_name
def test_get_file_name():
    template_name = "foo"
    replay_dir = os.path.expanduser("~/.cookiecutters")
    result = get_file_name(replay_dir, template_name)
    assert result == os.path.join(replay_dir, template_name+'.json')

# Generated at 2022-06-21 10:55:55.073358
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/code/my-project'
    template_name = 'my_cool_template'
    expected = '/code/my-project/my_cool_template.json'

    actual = get_file_name(replay_dir, template_name)

    assert expected == actual


# Generated at 2022-06-21 10:55:57.792372
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/tmp', 'test_template') == '/tmp/test_template.json'
    assert get_file_name('/tmp', 'test_template.json') == '/tmp/test_template.json'

# Generated at 2022-06-21 10:56:05.014418
# Unit test for function dump
def test_dump():
    import tempfile
    if name == 'main':
        replay_dir = tempfile.mkdtemp()
        template_name = 'cookiecutter-pypackage'
        context = {
            'cookiecutter': {
                'replay': True,
                'no_input': True,
            }
        }
        dump(replay_dir, template_name, context)
        assert True


# Generated at 2022-06-21 10:56:10.521951
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir='.cookiecutters'
    template_name='my_template'
    file_name='my_template.json'
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, file_name)
    template_name='my_template.json'
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, template_name)



# Generated at 2022-06-21 10:56:17.348406
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name"""
    assert get_file_name('path', 'template') == 'path/template.json'
    assert get_file_name('path', 'template.json') == 'path/template.json'

# Generated at 2022-06-21 10:56:24.889113
# Unit test for function dump
def test_dump():
    context={
        "cookiecutter": {
            "full_name": "test",
            "email": "test@test.com",
            "github_username": "test-test"
        }
    }

    try:
        dump('test_replays', 'test_template', context)
    except:
        assert False

    with open('test_replays/test_template.json') as infile:
        try:
            json.load(infile)
        except:
            assert False


# Generated at 2022-06-21 10:56:31.275396
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    assert dump(None, None, None) == IOError
    assert dump(None, 1, None) == TypeError
    assert dump(None, 'template_name.json', None) == TypeError
    assert dump(None, 'template_name.json', {}) == ValueError
    assert dump(None, 'template_name.json', {
        'cookiecutter': 'cookiecutter'
    }) == None


# Generated at 2022-06-21 10:56:37.826965
# Unit test for function dump
def test_dump():
    replay_dir = "tests/test-output/replay"
    template_name = "replay1"
    context = {"cookiecutter": {"test_cookiecutter": "test"}}
    dump(replay_dir, template_name, context)
    assert os.path.exists("tests/test-output/replay/replay1.json")


# Generated at 2022-06-21 10:56:42.596855
# Unit test for function load
def test_load():
    """Test that the load function returns the correct context."""
    replay_dir = os.path.join(os.getcwd(), 'tests', 'test-replay')
    template_name = 'dummy'
    assert load(replay_dir, template_name)['cookiecutter']['full_name'] == 'First Last'

# Generated at 2022-06-21 10:56:47.887269
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('foo', 'bar') == 'foo/bar.json'
    assert get_file_name('foo', 'bar.json') == 'foo/bar.json'
    assert get_file_name('foo', 'bar.json.json') == 'foo/bar.json.json'
    assert get_file_name('foo/bar/baz', 'bar.json.json') == 'foo/bar/baz/bar.json.json'

# Generated at 2022-06-21 10:56:51.713565
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'foo'
    replay_dir = '/tmp/cookiecutter'
    expected_name = '/tmp/cookiecutter/foo.json'
    actual_name = get_file_name(replay_dir, template_name)
    assert actual_name == expected_name



# Generated at 2022-06-21 10:56:55.538121
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/foo/bar', 'template') == '/foo/bar/template.json'
    assert get_file_name('/foo/bar', 'template.json') == '/foo/bar/template.json'

# Generated at 2022-06-21 10:56:58.956137
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay', 'name') == 'replay/name.json'
    assert get_file_name('replay', 'name.json') == 'replay/name.json'

# Generated at 2022-06-21 10:57:02.557363
# Unit test for function load
def test_load():
    template_name = 'cookiecutter-pypackage'
    c = load(template_name)
    assert type(c) is dict
    assert "cookiecutter" in c


# Generated at 2022-06-21 10:57:10.653617
# Unit test for function load
def test_load():
    result = load('C:\\Users\\yhs\\Desktop\\Thesis', 'test')
    assert type(result) == dict
    print(result)

# Generated at 2022-06-21 10:57:16.560632
# Unit test for function dump
def test_dump():
    replay_dir = '~/.cookiecutter_replay'
    template_name = 'cookiecutter-pypackage'
    context = {
        'cookiecutter': {
            'full_name': 'Your Name',
            'email': 'your@email.com',
            'project_name': 'Your new Python project',
            'project_slug': 'your-new-python-project',
        }
    }
    dump(replay_dir, template_name, context)

# Generated at 2022-06-21 10:57:27.503580
# Unit test for function dump
def test_dump():
    """Test function dump."""
    temp_dir = '.'
    template_name = 'my_template'
    context = {'cookiecutter': {'key1': 'value1', 'key2': 'value2'}}
    dump(temp_dir, template_name, context)
    with open(get_file_name(temp_dir, template_name), 'r') as infile:
        data = json.load(infile)
    assert data == context
    with open(get_file_name(temp_dir, template_name), 'w') as outfile:
        json.dump(data, outfile, indent=2)
    try:
        os.remove(get_file_name(temp_dir, template_name))
    except:
        print('Failed to delete file')


# Generated at 2022-06-21 10:57:33.890833
# Unit test for function dump
def test_dump():
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['repo_dir'] = '/Users/yangboz/git/git_repos/cookiecutter-couchbase-demo'
    replay_dir = '/Users/yangboz/git/git_repos/cookiecutter-couchbase-demo/.cookiecutters'
    template_name = 'https://github.com/yangboz/cookiecutter-couchbase-demo.git'
    dump(replay_dir=replay_dir,
         template_name=template_name,
         context=context)

if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-21 10:57:44.830052
# Unit test for function load
def test_load():
    # setup
    replay_dir = 'tests/test-replay'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-21 10:57:48.043884
# Unit test for function load

# Generated at 2022-06-21 10:57:53.050995
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'my-template'
    replay_dir = '/path/to/replay_dir'
    exp_file_name = '/path/to/replay_dir/my-template.json'

    file_name = get_file_name(replay_dir, template_name)
    assert file_name == exp_file_name


# Generated at 2022-06-21 10:58:03.347724
# Unit test for function load
def test_load():
    test_context = {
        'cookiecutter': {
            'full_name': 'Test Name',
            'email': 'testemail@test.com',
            'github_username': 'testghuser',
            'project_name': 'testproject',
            'project_short_description': 'test short description',
            'pypi_username': 'testpypi',
            'release_date': 'testdate',
            'year': 'testyear'
        }
    }
    replay_dir = '/tmp/cookiecutter-replay/'
    template_name = 'template_replay'
    dump(replay_dir, template_name, test_context)
    load(replay_dir, template_name)

# Generated at 2022-06-21 10:58:10.275194
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {}, 'project_name': 'test'}
    template_name = 'test_template_name'
    replay_dir = 'cookiecutter-replay'
    file_name = get_file_name(replay_dir, template_name)
    if os.path.exists(file_name):
        os.remove(file_name)

    dump(replay_dir, template_name, context)

    assert os.path.exists(file_name)
    with open(file_name, 'r') as infile:
        context_read = json.load(infile)

    assert context == context_read
    if os.path.exists(file_name):
        os.remove(file_name)


# Generated at 2022-06-21 10:58:13.555499
# Unit test for function load
def test_load():
    print (load('C:/Users/Yankan Wu/Documents/GitHub/cookiecutter-pypackage',
          'cookiecutter-pypackage'))


# Generated at 2022-06-21 10:58:31.589533
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'replay'))
    template_name = 'cookiecutter-pypackage'
    template_name_with_suffix = 'cookiecutter-pypackage.json'
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, template_name_with_suffix)

# Generated at 2022-06-21 10:58:33.727959
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("replay", "template_name") == "replay/template_name.json"


# Generated at 2022-06-21 10:58:35.524129
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name function."""

    assert get_file_name("/", "random_name") == "/random_name.json"
    assert get_file_name("/", "random_name.json") == "/random_name.json"


# Generated at 2022-06-21 10:58:43.995225
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    import os
    import shutil
    import uuid
    import sys
    import logging
    import click

    logger = logging.getLogger(__name__)
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

    template_path = os.path.join(os.getcwd(), 'tests', 'test-data', 'cookiecutters', 'test-cookiecutter-repo')
    replay_dir = os.path.join(os.getcwd(), 'tests', 'replays')
    username = os.getlogin()


# Generated at 2022-06-21 10:58:54.718484
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name"""
    replay_dir = "C:/Users/quannguyen/Desktop/UCP/Git/Cookiecutter/tests/test-replay"
    template_name = "https://github.com/TWChennai/my-first-cookiecutter"
    
    if os.path.exists(replay_dir):
        file_name = get_file_name(replay_dir, template_name)
        assert file_name == 'C:/Users/quannguyen/Desktop/UCP/Git/Cookiecutter/tests/test-replay\\https___github.com_TWChennai_my-first-cookiecutter.json'
    else:
        assert False

# Generated at 2022-06-21 10:58:57.584213
# Unit test for function get_file_name
def test_get_file_name():
    """test_get_file_name."""
    assert get_file_name('test', 'test') == 'test/test.json'



# Generated at 2022-06-21 10:59:03.412786
# Unit test for function dump
def test_dump():
    from cookiecutter.main import cookiecutter # import main.py from main directory
    replay_dir = "_replay"
    template_name = "my_template"
    dict = {'cookiecutter': {'version': '1.4.0'}}
    dump(replay_dir, template_name, dict)

    assert os.path.isfile("_replay/my_template.json")


# Generated at 2022-06-21 10:59:07.489118
# Unit test for function get_file_name
def test_get_file_name():

    replay_dir = "some/path/to/replay/dir"
    template_name = "some_template"
    expected_name = "some/path/to/replay/dir/some_template.json"

    name = get_file_name(replay_dir, template_name)

    assert expected_name == name



# Generated at 2022-06-21 10:59:10.797272
# Unit test for function load
def test_load():
    with open('data/test_context.json','r') as f:
        test_context = json.load(f)
    assert load('data', 'test_context') == test_context

# Generated at 2022-06-21 10:59:16.018045
# Unit test for function load
def test_load():
    # Load the service template
    replay_dir = '.'
    template_name = 'serviceTemplate'
    context = load(replay_dir, template_name)

    # Load the project template
    replay_dir = '.'
    template_name = 'projectTemplate'
    context = load(replay_dir, template_name)

# Generated at 2022-06-21 10:59:44.411792
# Unit test for function load
def test_load():
    replay_dir = '~/.cookiecutter_replay'
    template_name = 'Lets-start-with-a-template'

# Generated at 2022-06-21 10:59:50.035501
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'test'
    replay_dir = os.getcwd()
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, template_name+'.json')


# Generated at 2022-06-21 10:59:53.715263
# Unit test for function dump
def test_dump():
    from tempfile import mkdtemp
    import shutil
    temp_dir = mkdtemp()
    try:
        dump(temp_dir, 'example', {'cookiecutter': 'example'})
        assert True
    except Exception as error:
        print(str(error))
        assert False
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-21 10:59:57.782852
# Unit test for function get_file_name
def test_get_file_name():
	# Check that the json extension is added
	assert os.path.join('test', 'file.json') == get_file_name('test', 'file')
	# Check that a missing extension is added
	assert os.path.join('test', 'file.json') == get_file_name('test', 'file.json')


# Generated at 2022-06-21 11:00:06.871742
# Unit test for function dump
def test_dump():
    """Test_dump."""
    # Test case 1
    try:
        replay_dir = ""
        reult = dump(replay_dir, "test", {})
    except Exception as error:
        print('Test case 1: '+str(error))
        print('test case 1 passed')
    else:
        print('Test case 1 failed')
    
    # Test case 2
    try:
        replay_dir = "."
        reult = dump(replay_dir, "test", {})
    except Exception as error:
        print('Test case 2: '+str(error))
        print('Test case 2 passed')
    else:
        print('Test case 2 failed')
    
    # Test case 3

# Generated at 2022-06-21 11:00:10.745137
# Unit test for function get_file_name
def test_get_file_name():
    if get_file_name('cookiecutter-pypackage', 'cookiecutter-pypackage') == 'cookiecutter-pypackage/cookiecutter-pypackage.json':
        assert True
    else:
        assert False


# Generated at 2022-06-21 11:00:20.472475
# Unit test for function dump
def test_dump():
    """Test dump function."""
    from click.testing import CliRunner
    from cookiecutter.main import cookiecutter
    from cookiecutter.prompt.prompt import preset_answers
    from cookiecutter.replay import dump

    runner = CliRunner()
    result = runner.invoke(cookiecutter, [
        'tests/test-repo-pre/{{cookiecutter.repo_name}}',
        '--no-input',
        '-o', '/tmp/{{cookiecutter.repo_name}}',
        '-f',
        '-c', 'tests/test-replay',
    ], input='\n'.join(['y'] * 10))

    assert result.exit_code == 0

    dump('tests/test-replay', 'bakerydemo', preset_answers)

# Generated at 2022-06-21 11:00:27.413316
# Unit test for function load
def test_load():
    """Test for load."""
    from cookiecutter.main import cookiecutter

    template_name = 'my-new-project'
    template_dir = 'tests/files/test-template'
    replay_dir = 'tests/files/replay'
    replay_file = get_file_name(replay_dir, template_name)
    os.remove(replay_file)

    # Create replay
    cookiecutter(template_dir)
    load(replay_dir, template_name)

# Generated at 2022-06-21 11:00:32.613920
# Unit test for function load
def test_load():
    template_name = "python-package"
    replay_dir = "cookiecutter-replay"
    actual_context = load(replay_dir, template_name)
    expected_context = {"cookiecutter": {"full_name": "Logan Dey",
                                         "email": "logan.dey@gmail.com",
                                         "project_name": "my-project",
                                         "py_module_name": "my_project"}}
    assert actual_context == expected_context



# Generated at 2022-06-21 11:00:36.826478
# Unit test for function load
def test_load():
    """Test the function load."""
    path = os.path.abspath(os.path.dirname(__file__))
    replay_dir = os.path.join(path, 'tests/replay')
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context



# Generated at 2022-06-21 11:01:11.274798
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name"""

    # Case 1: Success Case
    replay_dir = '/tmp/cookiecutter/'
    template_name = 'jinja2-json'
    test = get_file_name(replay_dir, template_name)
    assert test == '/tmp/cookiecutter/jinja2-json.json'

    # Case 2: Success Case
    replay_dir = '/tmp/cookiecutter/'
    template_name = 'jinja2-json.json'
    test = get_file_name(replay_dir, template_name)
    assert test == '/tmp/cookiecutter/jinja2-json.json'

    # Case 1: Failure Case
    replay_dir = '/tmp/cookiecutter/'
    template_name = False

# Generated at 2022-06-21 11:01:16.778033
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name using a given file name and replay directory."""
    replay_dir = '/example/dir'
    template_name = 'cookiecutter-pypackage'
    assert (get_file_name(replay_dir, template_name) ==
            '/example/dir/cookiecutter-pypackage.json')


# Generated at 2022-06-21 11:01:21.227711
# Unit test for function dump
def test_dump():
    with open('test_dump.json', 'w') as outfile:
        json.dump({"cookiecutter": "cookiecutter_test"}, outfile, indent=2)
    test_value = load('.', 'test_dump')
    assert test_value['cookiecutter'] == 'cookiecutter_test'


# Generated at 2022-06-21 11:01:25.474373
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = '.'
    template_name = 'foo/bar'
    file_name = get_file_name(replay_dir, template_name)
    assert 'foo-bar.json' == file_name

# Generated at 2022-06-21 11:01:30.907217
# Unit test for function load
def test_load():
    """check load function works as expect."""
    rd = 'tests/test-data/replay/'
    cn = 'bootstrap-cookiecutter-pypackage'
    cf = load(rd, cn)
    #print(cf)
    #print(type(cf))
    assert 'cookiecutter' in cf
    assert '_template' in cf


# Generated at 2022-06-21 11:01:40.617066
# Unit test for function dump
def test_dump():
    template_name = 'foo'
    replay_dir = 'bar'
    context = {'cookiecutter': {'email': 'test@test.com'}}
    file_name = '{}.json'.format(template_name)
    expected_file_path = os.path.join(replay_dir, file_name)
    result = dump(replay_dir, template_name, context)

    assert result == expected_file_path
    assert os.path.exists(result)
    assert os.path.isfile(result)
    os.remove(result)



# Generated at 2022-06-21 11:01:50.255055
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.dirname(__file__), 'replay_test')
    template_name = 'test_template'
    context = {'cookiecutter': {'github_user': 'test'}}

    # Empty replay directory
    try:
        os.remove(os.path.join(replay_dir, 'test_template.json'))
    except Exception:
        pass
    assert not os.listdir(replay_dir)

    # Store data in new json file
    dump(replay_dir, template_name, context)
    assert len(os.listdir(replay_dir)) == 1

    # Load data from json file
    loaded_context = load(replay_dir, template_name)
    assert loaded_context['cookiecutter']['github_user']

# Generated at 2022-06-21 11:01:52.474913
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test: get_file_name."""
    test_name = "template"
    assert get_file_name("", test_name) == "template.json"

# Generated at 2022-06-21 11:01:59.534581
# Unit test for function dump
def test_dump():
    """Example of unit test with pytest."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay-dump')
    template_name = 'test-replay.json'

# Generated at 2022-06-21 11:02:05.065999
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = './tests'
    template_name = 'test_template'
    file_name = get_file_name(replay_dir, template_name)
    assert os.path.join(replay_dir, 'test_template.json') == file_name
