

# Generated at 2022-06-21 10:52:59.202795
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('foo', 'bar') == 'foo/bar.json'
    assert get_file_name('foo', 'bar.json') == 'foo/bar.json'
    assert get_file_name('foo/', 'bar') == 'foo/bar.json'
    assert get_file_name('foo/', 'bar.json') == 'foo/bar.json'

# Generated at 2022-06-21 10:53:07.100556
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-dir'
    template_name = 'test-data'
    context = {'cookiecutter': {'full_name': 'test-user'}}

    dump(replay_dir, template_name, context)
    assert (replay_dir in 'tests/files/test-dir')
    assert (template_name == 'test-data')
    assert (context == {'cookiecutter': {'full_name': 'test-user'}})



# Generated at 2022-06-21 10:53:18.461259
# Unit test for function dump
def test_dump():
    replay_dir = 'replay-tests'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-21 10:53:29.599960
# Unit test for function load
def test_load():
    """Test the load function."""
    import context
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    replay_dir = os.path.join(temp_dir, 'replay')
    template_name = 'test_template'

    full_path = get_file_name(replay_dir, template_name)

    assert (
        full_path == os.path.join(temp_dir, 'replay', 'test_template.json')
    )

    dump(replay_dir, template_name, context.context)

    assert os.path.isfile(full_path)

    context_loaded = load(replay_dir, template_name)

    assert context_loaded == context.context

    shutil.rmtree(temp_dir)



# Generated at 2022-06-21 10:53:34.902244
# Unit test for function get_file_name
def test_get_file_name():
    """Test the function get_file_name."""
    replay_dir = '.'
    template_name = 't.json'
    assert "t.json" == get_file_name(replay_dir, template_name)


# Generated at 2022-06-21 10:53:39.138896
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'cookie/file.json'
    template_name = 'template_name'

    filename = get_file_name(replay_dir, template_name)
    assert filename == 'cookie/file.json/template_name.json'



# Generated at 2022-06-21 10:53:46.489546
# Unit test for function get_file_name
def test_get_file_name():
    expected = './replay/examples/example_repo.json'
    result = get_file_name('./replay', 'examples/example_repo')
    assert result == expected

    # Function should handle the case where the file name has the '.json' suffix already
    expected = './replay/examples/example_repo.json'
    result = get_file_name('./replay', 'examples/example_repo.json')
    assert result == expected



# Generated at 2022-06-21 10:53:50.829445
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tests/replay_test'
    template_name = 'python_boilerplate'
    assert get_file_name(replay_dir, template_name) == 'tests/replay_test\\python_boilerplate.json'

# Generated at 2022-06-21 10:53:52.995821
# Unit test for function dump
def test_dump():
    re = get_file_name('replay', 'abc')
    print(re)


# Generated at 2022-06-21 10:53:54.745344
# Unit test for function load
def test_load():
    load('/home/naveed/Cookiecutter-testing', 'template-name')



# Generated at 2022-06-21 10:54:01.561710
# Unit test for function dump
def test_dump():
    """Test dump() function."""
    # set up test directory
    replay_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'test_dump_dir'
    )

    # make sure that directory doesn't exist
    if os.path.exists(replay_dir):
        os.system('rm -rf {}'.format(replay_dir))

    # start testing
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'cookiecutter-pypackage',
        }
    }


# Generated at 2022-06-21 10:54:06.706210
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'template_name'
    replay_dir = 'replay_dir'
    print(get_file_name(replay_dir,template_name))

if __name__ == '__main__':
    test_get_file_name()

# Generated at 2022-06-21 10:54:07.957808
# Unit test for function load
def test_load():
    """Test load function."""
    return

# Generated at 2022-06-21 10:54:12.598364
# Unit test for function dump
def test_dump():
    template = '{{cookiecutter.project_name}}'
    replay_dir = '../tests/files/replay'
    context ={
        'cookiecutter': {
            'project_name' : 'Test_name'
        }
    }
    dump(replay_dir,template,context)


# Generated at 2022-06-21 10:54:17.209910
# Unit test for function load
def test_load():
    """Test for function load"""
    # Wrong type of template_name
    assert ValueError == type(load('replay', 1))
    # Missing 'cookiecutter' in context
    assert ValueError == type(load('replay', 'template_name'))
    # Correct input
    assert dict == type(load('replay', 'template_name'))



# Generated at 2022-06-21 10:54:23.687782
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'name': 'sagarmuralidharan'}}
    replay_dir = os.path.join('home', 'sagarmuralidharan', 'replay')
    template_name = 'my-replay'
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:54:36.276890
# Unit test for function dump
def test_dump():
    replay_dir = "./tests/fake_repo_pre/cookiecutter-pypackage-min/replay"
    template_name = 'cookiecutter-pypackage-min'

# Generated at 2022-06-21 10:54:44.562360
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    from datetime import date
    from os import remove
    from os.path import exists

    replay_dir = 'test'
    template_name = 'cookiecutter-pypackage'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'project_name': 'cookiecutter-pypackage',
            'project_slug': 'cookiecutter-pypackage',
            'year': date.today().year,
            'release_date': date.today().strftime('%Y-%m-%d')
        }
    }

    dump(replay_dir, template_name, context)

# Generated at 2022-06-21 10:54:50.816009
# Unit test for function dump
def test_dump():
    import tempfile
    result = None
    with tempfile.TemporaryDirectory() as replay_dir:
        dump(replay_dir, 'test.json', {
            'cookiecutter': {
                'hello': 'world'
            }})
        result = load(replay_dir, 'test.json')
    assert result['cookiecutter']['hello'] == 'world'


# Generated at 2022-06-21 10:54:53.264103
# Unit test for function load
def test_load():
    """Load json data from file."""
    res = load(".", ".")
    assert res == {'cookiecutter': {}}


# Generated at 2022-06-21 10:54:57.952237
# Unit test for function load
def test_load():
    template_name = 'test'
    expected = {'cookiecutter': {'test': 'value'}}
    actual = load('.', template_name)
    assert(expected == actual)


# Generated at 2022-06-21 10:55:06.435418
# Unit test for function dump
def test_dump():
    # create a dir for test
    import tempfile
    dirpath = tempfile.mkdtemp()
    template_name = 'test.json'
    context = {'cookiecutter': {'name': 'test_name', 'version': 'test_version'}}
    # call function dump
    dump(dirpath, template_name, context)
    # get file path
    file_path = get_file_name(dirpath, template_name)
    # assert file is created
    assert os.path.exists(file_path)
    # assert file content is the same as context
    with open(file_path, 'r') as infile:
        file_context = json.load(infile)
    assert file_context == context
    # delete created dir
    import shutil
    shutil.rmtree(dirpath)

# Generated at 2022-06-21 10:55:11.343299
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/does/not/exist"
    template_name = "{{ cookiecutter.repo_name }}"

    file_name = get_file_name(replay_dir, template_name)

    assert file_name == "/does/not/exist/{{ cookiecutter.repo_name }}.json"


# Generated at 2022-06-21 10:55:14.314888
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("./tmp", "template") == "./tmp/template.json"
    assert get_file_name("./tmp", "template.json") == "./tmp/template.json"


# Generated at 2022-06-21 10:55:17.566535
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('test/test_dir', 'test_name') == 'test/test_dir/test_name.json'
    assert get_file_name('test/test_dir', 'test_name.json') == 'test/test_dir/test_name.json'

# Generated at 2022-06-21 10:55:26.085127
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay/dir', 'cc_template') == \
        'replay/dir/cc_template.json'
    assert get_file_name('replay/dir', 'cc_template.json') == \
        'replay/dir/cc_template.json'
    assert get_file_name('replay/dir', 'cc_template.json.json') == \
        'replay/dir/cc_template.json.json'
    assert get_file_name('replay/dir', 'cc_template.json.json.json') == \
        'replay/dir/cc_template.json.json.json'

# Generated at 2022-06-21 10:55:30.351780
# Unit test for function load
def test_load():
    inputs = {'test': 1}
    filepath = '/tmp/test.json'
    with open(filepath, 'w') as f:
        f.write(json.dumps(inputs))
    assert load('/tmp','test.json') == inputs



# Generated at 2022-06-21 10:55:34.709075
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/home/cookiecutter/replay"
    template_name = "my-repo"
    result = get_file_name(replay_dir, template_name)
    assert result == "/home/cookiecutter/replay/my-repo.json"


# Generated at 2022-06-21 10:55:43.759812
# Unit test for function dump
def test_dump():
    """Unit tests for functions dump."""
    import tempfile
    t = tempfile.mkdtemp()
    template_name = 'template_with_replay'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}

    try:
        dump(t, template_name, context)
        assert os.path.exists(os.path.join(t,template_name + '.json'))

        result = load(t, template_name)
        assert result == context

    finally:
        os.remove(os.path.join(t,template_name + '.json'))
        os.rmdir(t)

# Generated at 2022-06-21 10:55:55.284603
# Unit test for function load
def test_load():
    template_name = 'ckpt_resnet50'
    cookiecutter = {
        'project_directory': "C:\\ckpt_resnet50",
        'ckpt_path': 'C:\\ckpt_resnet50\\chkpt.h5',
        'model_name': 'resnet50',
        'modifies': 'conv5_block3_out',
        'allow_overwrite': 'true',
        'output_dir': 'C:\\ckpt_resnet50\\perturbations',
        'output_prefix': 'perturbation_'
    }
    context = { 'cookiecutter': cookiecutter }
    replay_dir = 'test_replay' # Relative pathname
    dump(replay_dir, template_name, context)

# Generated at 2022-06-21 10:56:07.269406
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    scenario1 = {
        'replay_dir': '/tmp/cookiecutter-replay',
        'template_name': 'myfirsttemplate',
        'answers': {
            'repo_name': 'okokokok',
            'project_name': 'hahahahahha',
        }
    }
    assert get_file_name(scenario1['replay_dir'], scenario1['template_name']) == '/tmp/cookiecutter-replay/myfirsttemplate.json'


# Generated at 2022-06-21 10:56:12.380208
# Unit test for function dump
def test_dump():
    # Check for valid value
    replay_dir =  '~/Downloads/test'
    template_name = 'cookiecutter-pypackage'
    context = {
        "cookiecutter": {
            "full_name": "Ankit Singh",
            "email": "ankitsingh0410@gmail.com",
            "project_name": "test",
        },
    }

    # Expected Output
    filename = 'cookiecutter-pypackage.json'
    file_path = os.path.expanduser(replay_dir)

    dump(replay_dir, template_name, context)
    assert(os.path.exists(os.path.join(file_path, filename)))



# Generated at 2022-06-21 10:56:16.112773
# Unit test for function load
def test_load():
    replay_dir = "~/Desktop"
    template_name = "cc_replay"
    outfile = get_file_name(replay_dir, template_name)
    context = {}
    with open(outfile, 'w') as outfile:
        json.dump(context, outfile, indent=2)
    data = load(replay_dir, template_name)
    assert(len(data) == 0)
    for key, val in data.items():
        assert(key == None)
        assert(val == None)


# Generated at 2022-06-21 10:56:16.495018
# Unit test for function dump
def test_dump():
    pass

# Generated at 2022-06-21 10:56:18.557211
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("foo", "bar") == "foo/bar.json"



# Generated at 2022-06-21 10:56:27.589477
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.replay import dump, load

    context = cookiecutter('tests/fake-repo-tmpl', no_input=True)
    dump('/tmp', 'tests/fake-repo-tmpl', context)

    loaded_context = load('/tmp', 'tests/fake-repo-tmpl')
    assert context == loaded_context

    loaded_context = load('/tmp', 'tests/fake-repo-tmpl.json')
    assert context == loaded_context

# Generated at 2022-06-21 10:56:29.552473
# Unit test for function load
def test_load():
    result = load('FakeDirectory', 'FakeTemplateName')
    assert result == {'cookiecutter':{}}

# Generated at 2022-06-21 10:56:37.027856
# Unit test for function load
def test_load():
    replay_file = 'test_replay.json'
    # Create a replay file for testing
    with open(replay_file, 'w') as outfile:
        json.dump({'cookiecutter': {'answer': 'test'}}, outfile, indent=2)
    context = load('', replay_file)
    os.remove(replay_file)
    assert context['cookiecutter']['answer'] == 'test'

test_load()

# Generated at 2022-06-21 10:56:46.968417
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'foo'
    replay_dir = os.getcwd()
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, 'foo.json')

    template_name = 'foo.json'
    replay_dir = os.getcwd()
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, 'foo.json')

    template_name = 'foo'
    replay_dir = '~/cookiecutter-replay'
    file_name = get_file_name(replay_dir, template_name)

# Generated at 2022-06-21 10:56:51.660366
# Unit test for function get_file_name
def test_get_file_name():

    replay_dir = '/path/to/replay'
    template_name = 'testme'
    result = get_file_name(replay_dir, template_name)
    assert result == os.path.join(replay_dir, 'testme.json')

    replay_dir = '/path/to/replay'
    template_name = 'testme.json'
    result = get_file_name(replay_dir, template_name)
    assert result == os.path.join(replay_dir, 'testme.json')

# Generated at 2022-06-21 10:57:00.300522
# Unit test for function get_file_name
def test_get_file_name():
    """Testing the function get_file_name."""
    # Name of the directory to save the replay file
    replay_dir = "replay"
    template_name = "my_project"
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'replay/my_project.json'


# Generated at 2022-06-21 10:57:12.441562
# Unit test for function dump
def test_dump():
    import shutil
    from tempfile import mkdtemp
    
    replay_dir = mkdtemp()
    template_name = 'template1'
    context = {'cookiecutter': {'question': 'answer'}}
    
    # Check if file does not exist
    replay_file = get_file_name(replay_dir, template_name)
    assert(not os.path.isfile(replay_file))
    
    dump(replay_dir, template_name, context)
    
    # Check if file exist
    assert(os.path.isfile(replay_file))
    
    # Check if file has the correct content
    # Open the file again and read the content
    with open(replay_file, 'r') as infile:
        content = json.load(infile)
    
   

# Generated at 2022-06-21 10:57:16.591695
# Unit test for function get_file_name
def test_get_file_name():
    """Test the get_file_name function."""
    suffix = '.json'
    template_name = 'template_name'
    replay_dir = 'replay_dir'

    returned = get_file_name(replay_dir, template_name)

    expected = os.path.join(replay_dir, template_name + suffix)
    assert returned == expected


# Generated at 2022-06-21 10:57:20.627411
# Unit test for function load
def test_load():
    with open('./tests/test_load_should_fail.json', 'r') as infile:
        context = json.load(infile)
        assert context == {'cookiecutter': {'full_name': 'Audrey Roy'}}

# Generated at 2022-06-21 10:57:30.245429
# Unit test for function get_file_name
def test_get_file_name():
    """Test cases for get filename."""

# Generated at 2022-06-21 10:57:40.816852
# Unit test for function dump
def test_dump():
    from datetime import datetime

    print ("\nTest the dump function\n")
    replay_dir = 'replay_test'
    template_name = 'flask_app'
    context = {'cookiecutter': {'config_file': 'None',
                                'extra_context': {'project_name': 'Flask App',
                                                  'project_slug': 'flask_app',
                                                  'project_description': 'This is a Flask App project.',
                                                  'open_source_license': 'MIT license',
                                                  'use_pycharm': 'y',
                                                  'use_docker': '',
                                                  'use_heroku': '',
                                                  'date_time': datetime(2020, 9, 8)},
                                'no_input': 'False'}}

# Generated at 2022-06-21 10:57:51.826651
# Unit test for function dump
def test_dump():
    "This function tests the dump function in replay.py"
    import shutil
    import os.path

    replay_dir = 'testreplay'
    if os.path.isdir(replay_dir):
        shutil.rmtree(replay_dir)
    template_name = 'testtemplate'
    context = { 'cookiecutter': {'var1': 'value1', 'var2': 'value2'} }

    dump(replay_dir, template_name, context)

    expected_file = 'testreplay/testtemplate.json'
    expected_contents = '''{
  "cookiecutter": {
    "var1": "value1",
    "var2": "value2"
  }
}'''

    assert os.path.isfile(expected_file)

# Generated at 2022-06-21 10:57:54.575865
# Unit test for function load
def test_load():
    replay_dir = "./tests/test-replay"
    template_name = "test_load"
    data = load(replay_dir, template_name)
    if data:
        assert data
    else:
        assert False


# Generated at 2022-06-21 10:57:57.527306
# Unit test for function load
def test_load():
    assert load('tests/test-load', 'fake-template') == {'cookiecutter': {'project_slug': 'fake-project'}}



# Generated at 2022-06-21 10:58:06.325818
# Unit test for function dump
def test_dump():
    """Test Function dump."""
    import tempfile
    template_name = 'foobar'
    temp_dir = tempfile.gettempdir()

    context = {
        'cookiecutter': {
            'project_name': 'foo',
            'project_slug': 'bar'
        }
    }

    dump(temp_dir, template_name, context)
    file_name = get_file_name(temp_dir, template_name)
    with open(file_name, 'r') as json_file:
        saved_context = json.load(json_file)

    os.remove(file_name)

    assert saved_context == context

# Generated at 2022-06-21 10:58:16.857382
# Unit test for function load
def test_load():
    context = load('/home/avis/ProjectAILab/CookieCutter-Python/tests/test_replay/', 'test')
    assert(str(context) == "{'cookiecutter': {'full_name': 'Monty Python', 'project_name': 'Holy Grail', 'email': 'monty@python.net'}}")


# Generated at 2022-06-21 10:58:18.889455
# Unit test for function get_file_name
def test_get_file_name():
    f = get_file_name("/tmp", "test")
    assert f == "/tmp/test.json", "file name is not correct"

# Generated at 2022-06-21 10:58:27.690893
# Unit test for function dump
def test_dump():
    """Test if dump works correctly."""
    replay_dir = 'C:\\Users\\Administrator\\AppData\\Local\\cookiecutters'
    template_name = 'pypackage'

# Generated at 2022-06-21 10:58:36.702596
# Unit test for function dump
def test_dump():
    """
    Test the dump function.
    """
    replay_dir = 'tests/files/fake-replay-dir'
    context = {
        'cookiecutter': {
            'tests': {
                'test_input': 'John Smith',
            },
        },
    }
    template = 'tests/fake-repo-pre/'

    dump(replay_dir, template, context)

    replay_file = get_file_name(replay_dir, template)

    with open(replay_file, 'r') as infile:
        replay_context = json.load(infile)

    assert replay_context == context

# Generated at 2022-06-21 10:58:44.744667
# Unit test for function load
def test_load():
    with open('test_rep.json', 'r') as infile:
        context = json.load(infile)

    #print(context)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

    return context


#def load_all(replay_dir):
#    """Read json data from file."""
#    if not isinstance(replay_dir, str):
#        raise TypeError('Replay dir is required to be of type str')

#    if not make_sure_path_exists(replay_dir):
#        raise IOError('Replay dir does not exist at {}'.format(replay_dir))


#    #replay_dir = get_file_name(replay_dir, template_name)

#    with open

# Generated at 2022-06-21 10:58:49.279381
# Unit test for function dump
def test_dump():
    template_name = 'template_name'
    context = {'cookiecutter': "test"}
    replay_dir = '~/tmp/cookiecutter'
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    


# Generated at 2022-06-21 10:58:53.070778
# Unit test for function dump
def test_dump():
    
    context = {'cookiecutter': {'project_name': 'blog'}}
    dump("/home/etienne/Documents/ESGI/6A/python/Cookiecutter/tests", "en", context)


# Generated at 2022-06-21 10:58:58.574829
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': 'Foo'}
    replay_dir = os.path.join('tests', 'files', 'fake-replay-dir')
    template_name = 'bar'
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:59:06.831357
# Unit test for function dump
def test_dump():
    template_name = 'cookiecutter-pypackage-minimal'
    replay_dir = os.path.join('test', 'fake-replay-dir')

    context = {'cookiecutter': {'name': 'foobar'}}
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'r') as infile:
        result = json.load(infile)

    os.remove(replay_file)
    os.rmdir(replay_dir)

    assert result == context



# Generated at 2022-06-21 10:59:18.298525
# Unit test for function load
def test_load():
    # test
    context = load(os.path.sep.join(os.path.abspath(__file__).split(os.path.sep)[:-2]),
          'cookiecutter-pylibrary')
    assert isinstance(context, dict) and 'cookiecutter' in context
    # failure caused by type
    try:
        context = load(os.path.sep.join(os.path.abspath(__file__).split(os.path.sep)[:-2]),
              False)
    except TypeError as e:
        print(e)
    context = load(os.path.sep.join(os.path.abspath(__file__).split(os.path.sep)[:-2]),
          'cookiecutter-pylibrary')
    assert isinstance(context, dict)

# Generated at 2022-06-21 10:59:35.622641
# Unit test for function dump
def test_dump():
    """Test for dump."""
    replay_dir = 'test_replays'
    template_name = 'test'
    context = {'cookiecutter': {'test': '{{cookiecutter.test}}'}}
    dump(replay_dir, template_name, context)

    file_path = get_file_name(replay_dir, template_name)
    if not os.path.exists(file_path):
        raise Exception('File does not exist at {}'.format(file_path))

    # Cleanup the replay file after test
    os.remove(file_path)


# Generated at 2022-06-21 10:59:45.690527
# Unit test for function load
def test_load():
    import os
    import shutil
    replay_dir = 'TEST_REPLAY_DIR'
    template_name = 'TEST_TEMPLATE_NAME'
    context = {
        'cookiecutter': {
            'full_name': 'TEST_FULL_NAME',
            'email': 'TEST_EMAIL'
        }
    }
    try:
        os.mkdir(replay_dir)
        dump(replay_dir, template_name, context)
        new_context = load(replay_dir, template_name)
        assert new_context['cookiecutter']['full_name'] == context['cookiecutter']['full_name']
        assert new_context['cookiecutter']['email'] == context['cookiecutter']['email']
    finally:
        shutil

# Generated at 2022-06-21 10:59:49.416686
# Unit test for function load
def test_load():
    try:
        load('/home/zhengyb/git/langest', 'test')
    except ValueError as e:
        print(e)


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-21 10:59:53.443693
# Unit test for function load
def test_load():
    test_replay_dir = os.path.join(os.path.dirname(__file__), 'test_replay')
    template_name = 'python_cli'
    context = load(test_replay_dir, template_name)
    assert context
    assert 'cookiecutter' in context
    assert context['cookiecutter']['full_name'] == 'TEST'


# Generated at 2022-06-21 10:59:56.447878
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("/home/ubuntu/CookieCutter", "test1")=="/home/ubuntu/CookieCutter/test1.json"
    assert get_file_name("/home/ubuntu/CookieCutter", "test2.json")=="/home/ubuntu/CookieCutter/test2.json"



# Generated at 2022-06-21 11:00:05.694008
# Unit test for function get_file_name
def test_get_file_name():
    nominal_file_name = '~/.cookiecutter_replay/nominal_template.json'
    nominal_template_name = 'nominal_template'
    nominal_replay_dir = '~/.cookiecutter_replay'
    file_name = get_file_name(nominal_replay_dir, nominal_template_name)
    assert file_name == nominal_file_name

    bad_file_name = '~/.cookiecutter_replay/bad_template.json.json'
    bad_template_name = 'bad_template.json'
    bad_replay_dir = '~/.cookiecutter_replay'
    file_name = get_file_name(bad_replay_dir, bad_template_name)
    assert file_name == bad_file_name


# Generated at 2022-06-21 11:00:07.087994
# Unit test for function load

# Generated at 2022-06-21 11:00:11.103367
# Unit test for function load
def test_load():
    """Unit test for function load."""
    t_n = "test_load"
    t_c = {'cookiecutter': {"project_name": '{{cookiecutter.name}}'}}
    r_d = "cookiecutter/tests/test-replay"
    dump(r_d, t_n, t_c)
    r_c = load(r_d, t_n)
    os.remove(get_file_name(r_d, t_n))
    assert r_c == t_c



# Generated at 2022-06-21 11:00:16.059344
# Unit test for function load
def test_load():
    replay_dir = "tests/user/replay"
    template_name = "tests/fake-repo-pre/{{cookiecutter.repo_name}}"
    context = load(replay_dir, template_name)
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

# Generated at 2022-06-21 11:00:21.629098
# Unit test for function load
def test_load():
    """Test for function load."""
    template_name = 'cookiecutter-pypackage-min'
    replay_path = os.path.abspath('cookiecutter.json')
    with open(replay_path, 'r') as f:
        expected_context = json.load(f)
    os.remove(replay_path)    
    
    replay_dir = 'tests/files'
    context = load(replay_dir, template_name)
    assert context == expected_context


# Generated at 2022-06-21 11:00:45.492865
# Unit test for function load
def test_load():
    result = load('test', 'replay')
    print(result)

test_load()

# Generated at 2022-06-21 11:00:50.052868
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/Users/zhouzheng/Workspace/cookiecutter/tests/test-replay'
    template_name = 'test.json'
    replay_file = get_file_name(replay_dir, template_name)
    assert(replay_file == '/Users/zhouzheng/Workspace/cookiecutter/tests/test-replay/test.json')


# Generated at 2022-06-21 11:01:01.109816
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-load/'
    template_name = 'tpl-for-test'

# Generated at 2022-06-21 11:01:09.717012
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    # Test with full path
    replay_dir = '/home/user/'
    template_name = '/home/user/template'

    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/home/user/template.json'

    # Test with no path but json name
    replay_dir = '/home/user/'
    template_name = 'template.json'

    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/home/user/template.json'

    # Test with no path but non json name
    replay_dir = '/home/user/'
    template_name = 'template'


# Generated at 2022-06-21 11:01:17.821121
# Unit test for function get_file_name
def test_get_file_name():
    """test for get_file_name(replay_dir, template_name)"""
    assert get_file_name('/test/testreplay', 'test_template') == '/test/testreplay/test_template.json', "test_template.json file is not created properly"
    assert get_file_name('/test/testreplay', 'test_template.json') == '/test/testreplay/test_template.json', "test_template.json file is not created properly"


# Generated at 2022-06-21 11:01:20.755968
# Unit test for function get_file_name
def test_get_file_name():
    expected_value = '/home/tempuser/replay/xyz.json'
    test_value = get_file_name('/home/tempuser/replay', 'xyz')
    assert expected_value == test_value

# Generated at 2022-06-21 11:01:23.260331
# Unit test for function load
def test_load():
    test_load_context = load(os.curdir, 'test')
    assert test_load_context == {'cookiecutter': {'name': 'test'}}


# Generated at 2022-06-21 11:01:24.994862
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("home","abc.json")==("home/abc.json")

# Generated at 2022-06-21 11:01:30.538369
# Unit test for function dump
def test_dump():
	replay_dir = "C:/Users/julie/Desktop/replay.json"
	template_name = "C:/Users/julie/Desktop/cookiecutter-pypackage-min/{{cookiecutter.project_name}}"
	context = "{{cookiecutter.repo_name}}"
	dump(replay_dir, template_name, context)
	

# Generated at 2022-06-21 11:01:36.999703
# Unit test for function get_file_name
def test_get_file_name():
    """ Unit test for get_file_name"""
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    file_name = 'file_name'
    assert replay_dir == os.path.dirname(get_file_name(replay_dir, file_name))
    assert file_name.endswith('.json')



# Generated at 2022-06-21 11:02:40.433488
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/tmp/cookiecutter-tests"
    template_name = "fake-template"

    expected = os.path.join(replay_dir, template_name + ".json")

    assert get_file_name(replay_dir, template_name) == expected

    template_name = "fake-template.json"
    assert get_file_name(replay_dir, template_name) == expected


# Generated at 2022-06-21 11:02:44.316331
# Unit test for function load
def test_load():
    replay_file = get_file_name('replay','template')
    context = {'cookiecutter':{'test':'test'}}
    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)
    assert load('replay','template') == {'cookiecutter': {'test': 'test'}}

# Generated at 2022-06-21 11:02:45.949153
# Unit test for function load
def test_load():
    """test_load."""
    assert load("test_load", "test_load") is not None


# Generated at 2022-06-21 11:02:52.588924
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    # Arrange + Act
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    file_name = get_file_name(replay_dir, template_name)

    # Assert
    assert file_name == os.path.join(replay_dir, 'test_template_name.json')
