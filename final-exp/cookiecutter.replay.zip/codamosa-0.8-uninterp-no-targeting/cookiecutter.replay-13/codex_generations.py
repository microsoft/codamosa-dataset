

# Generated at 2022-06-21 10:52:54.756606
# Unit test for function dump

# Generated at 2022-06-21 10:52:57.297153
# Unit test for function get_file_name
def test_get_file_name():
    result = get_file_name('/test/replay', 'test')
    print(result)
    assert result == '/test/replay/test.json'



# Generated at 2022-06-21 10:53:01.936312
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/home/dungnb/cookiecutter/replay"
    template_name = "email"
    assert get(replay_dir, template_name) == \
           "/home/dungnb/cookiecutter/replay/email.json"

# Generated at 2022-06-21 10:53:07.198337
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    replay_dir = 'dir'
    template_name = 'template'
    suffix = '.json'
    file_name = 'dir/template.json'
    assert get_file_name(replay_dir, template_name) == file_name


# Generated at 2022-06-21 10:53:18.564200
# Unit test for function dump
def test_dump():
    template_name = os.path.join(os.path.dirname(os.path.abspath(__file__)),
        "test_dict_tpl")
    replay_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
        "replay")

# Generated at 2022-06-21 10:53:29.777620
# Unit test for function dump

# Generated at 2022-06-21 10:53:38.690640
# Unit test for function load
def test_load():
    """Test load method."""
    assert make_sure_path_exists(replay_dir)
    template_name = 'b2'
    context = {'cookiecutter': {'name': 'bar', 'version': '1.1.0'}}

    replay_file = dump(replay_dir, template_name, context)

    context_read = load(replay_dir, replay_file)
    assert context_read == context

    os.remove(replay_file)


# Generated at 2022-06-21 10:53:42.171841
# Unit test for function load
def test_load():
    template_name = "cookiecutter-pypackage"
    replay_dir = "/Users/jjn/workspace/cookiecutter-django/"
    context = load(replay_dir, template_name)

# Generated at 2022-06-21 10:53:51.162694
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        template = 'https://github.com/cookiecutter-django/cookiecutter-django.git'

# Generated at 2022-06-21 10:53:56.819846
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    context = {
        'cookiecutter': {
            'full_name': 'Your Name',
            'email': 'you@example.com',
        }
    }

    dump('.', 'cookiecutter-pypackage', context)
    assert os.path.isfile('./cookiecutter-pypackage.json')



# Generated at 2022-06-21 10:54:01.262454
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for get_file_name()."""
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutter_replay')
    expected_return = os.path.join(replay_dir, 'foobar.json')
    template_name = 'foobar'

    actual_return = get_file_name(replay_dir, template_name)

    assert actual_return == expected_return


# Generated at 2022-06-21 10:54:03.887893
# Unit test for function load
def test_load():
    context = load('.','cookiecutter-pypackage')
    print(context)
    assert('cookiecutter' in context)


# Generated at 2022-06-21 10:54:07.365881
# Unit test for function load
def test_load():
    context = load(replay_dir = 'tmp', template_name = 'sample-template')
    assert 'cookiecutter' in context
    return True


# Generated at 2022-06-21 10:54:17.213084
# Unit test for function dump
def test_dump():
    test_dict = {
        'cookiecutter': {
            'project_name': 'test',
            'project_slug': 'test'
        }
    }
    test_dir = '/test/test/test'
    test_name = 'test'

    # Test empty dir
    dump(test_dir, test_name, test_dict)
    assert os.path.isfile(get_file_name(test_dir, test_name))

    # Test existing dir
    dump(test_dir, test_name, test_dict)
    assert os.path.isfile(get_file_name(test_dir, test_name))

    # Test empty name
    try:
        dump(test_dir, '', test_dict)
    except TypeError:
        pass

    # Test non dict

# Generated at 2022-06-21 10:54:29.368411
# Unit test for function load
def test_load():
    """Test for function load."""
    template_name = "What is your template name? [template]: "
    replay_dir = "/home/sherlock1/Cookiecutter-Test"

    if not isinstance(template_name, str):
        raise TypeError('Template name is required to be of type str')

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

    return context


# Generated at 2022-06-21 10:54:38.173133
# Unit test for function load
def test_load():
    """Unit test for function load."""
    try:
        _ = load('', 'template')
        assert False
    except TypeError as e:
        assert str(e) == 'Template name is required to be of type str'

    try:
        _ = load('', 2)
        assert False
    except TypeError as e:
        assert str(e) == 'Template name is required to be of type str'

    try:
        _ = load('name', 'template')
        assert False
    except ValueError as e:
        assert str(e) == 'Context is required to contain a cookiecutter key'



# Generated at 2022-06-21 10:54:43.525943
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import tempfile
    d = tempfile.mkdtemp()
    save_file = os.path.join(d, 'test.json')
    save_content = {"cookiecutter": {"boo": "bar"}}
    with open(save_file, 'w') as outfile:
        json.dump(save_content, outfile, indent=2)
    result = load(d, 'test')
    assert result == save_content


# Generated at 2022-06-21 10:54:45.623109
# Unit test for function load
def test_load():
    assert load('./replays','cookiecutter-pypackage')



# Generated at 2022-06-21 10:54:56.128068
# Unit test for function load
def test_load():
    """Test load method."""
    data = {
        "cookiecutter": {
            "project_name": "Project Name",
            "project_slug": "project-name",
            "_template": "tests/test-template-full/"
        }
    }
    replay_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'cookiecutter_replay')
    template_name = 'tests/test-template-full/'
    dump(replay_dir, template_name, data)
    assert load(replay_dir, template_name) == data
    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-21 10:54:58.232987
# Unit test for function load
def test_load():
    """Unit test for function load."""
    assert load('test_load', 'test_load') == {'cookiecutter': {}}



# Generated at 2022-06-21 10:55:07.289905
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = "/home/subramanian/CookieCutterTests/Django-Rest-App"
    template_name = "wesley-khalifa/django-rest-app"
    assert get_file_name(replay_dir, template_name) == "/home/subramanian/CookieCutterTests/Django-Rest-App/wesley-khalifa/django-rest-app.json"
    template_name = "wesley-khalifa/django-rest-app.json"
    assert get_file_name(replay_dir, template_name) == "/home/subramanian/CookieCutterTests/Django-Rest-App/wesley-khalifa/django-rest-app.json"

# Generated at 2022-06-21 10:55:14.752327
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('dir-name/dir-name2', 'template-name') == os.path.join('dir-name/dir-name2', 'template-name.json')
    assert get_file_name('dir-name\dir-name2', 'template-name') == os.path.join('dir-name\dir-name2', 'template-name.json')
    assert get_file_name('', 'template-name.json') == os.path.join('', 'template-name.json')
    assert get_file_name('', 'template-name') == os.path.join('', 'template-name.json')
    assert get_file_name('', 'template-name.txt') == os.path.join('', 'template-name.txt')

# Generated at 2022-06-21 10:55:17.375193
# Unit test for function load
def test_load():
    print('unit test for function load()')
    context = load('/Users/chenyun/Desktop/hw4_team4/replay_dir', 'cookiecutter-pypackage')
    print(context)

# Generated at 2022-06-21 10:55:28.230622
# Unit test for function dump
def test_dump():
    from cookiecutter import replay
    from . import fake_context

    # Check if function TypeError is raising
    # when input is not a string
    try:
        replay.dump('example', 1, fake_context.fake_context)
    except TypeError:
        pass
    else:
        raise AssertionError('Expected to raise TypeError')

    # Check if function TypeError is raising
    # when context is not a dictionary
    try:
        replay.dump('example', 'example', 'example')
    except TypeError:
        pass
    else:
        raise AssertionError('Expected to raise TypeError')

    # Check if function ValueError is raising
    # when context is not a dictionary

# Generated at 2022-06-21 10:55:31.122335
# Unit test for function load
def test_load():
    # Test the function load
    print('test load')
    context = load('/Users/xiechengxu/.cookiecutters/cookiecutter-django', 'cookiecutter-django')
    print(context)


# Generated at 2022-06-21 10:55:33.649849
# Unit test for function dump
def test_dump():
    file_name = get_file_name('test')
    assert file_name.endswith('.json')
    assert file_name.endswith('.json')
    assert 'test' in file_name


# Generated at 2022-06-21 10:55:37.755155
# Unit test for function dump
def test_dump():
    replay_dir = 'test'
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'full_name': 'Mahtab', 'email': 'Mahtab@gmail.com', 'github_username': 'mahtab', 'project_name': 'mahtab', 'project_slug': 'mahtab', 'pypi_username': 'mahtab123', 'version': '0.1', 'select_license': 'MIT', 'year': '2019', 'description': '--no-input'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:55:45.547200
# Unit test for function dump
def test_dump():
    replay_dir = "tests/replay/test_load/"
    template_name = "test_dump"
    context = {
        "cookiecutter": {
            "hello": "world",
            "project_name": "Cookiecutter Project",
            "use_pytest": "y",
            "use_pypi_deployment_with_travis": "y",
            "command_line_interface": "click",
            "use_docker": "n",
            "open_source_license": "MIT license"
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:55:49.202638
# Unit test for function load
def test_load():
    if not isinstance(load(replay_dir, template_name), dict):
        raise TypeError('Context is required to be of type dict')


# Generated at 2022-06-21 10:55:54.015977
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'test_template'
    replay_dir = 'replay_directory'
    file_name = get_file_name(replay_dir, template_name)
    expected_filename = 'replay_directory/test_template.json'
    assert file_name == expected_filename


# Generated at 2022-06-21 10:55:58.022132
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    assert get_file_name('/tmp', 'github') == '/tmp/github.json'
    assert get_file_name('/tmp', 'github.json') == '/tmp/github.json'

# Generated at 2022-06-21 10:56:06.787351
# Unit test for function dump
def test_dump():
    template_name = "myproject"
    info = {}
    info['cookiecutter'] = {}
    info['cookiecutter']['repo_dir'] = "myproject"
    info['cookiecutter']['full_name'] = "khtsoi"
    info['cookiecutter']['email'] = "khtsoi@gmail.com"

# Generated at 2022-06-21 10:56:11.522133
# Unit test for function dump
def test_dump():
    outfile = 'test.json'
    template_name = 'template'
    context = {'cookiecutter': {'hello': 'world'}}

    # Dump the test context
    dump(template_name, context)

    # Load the dumped replay data
    replay_data = load(template_name)

    # Ensure the data is what was dumped
    assert replay_data == context

    # Clean up the replay file
    os.remove(outfile)

# Generated at 2022-06-21 10:56:18.399817
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'test_template'
    context = {'cookiecutter': {'key': 'value'}}

    dump(replay_dir, template_name, context)

    expected_file_name = os.path.join(replay_dir, 'test_template.json')
    assert os.path.exists(expected_file_name)
    os.remove(expected_file_name)


# Generated at 2022-06-21 10:56:24.544693
# Unit test for function dump
def test_dump():
    replay_dir = str(os.getcwd())
    template_name = 'cookiey'
    context = {'cookiecutter': {'name': 'Anika', 'surname': 'Bastiasen'}}
    dump(replay_dir, template_name, context)
    assert(os.path.exists(get_file_name(replay_dir, template_name)))


# Generated at 2022-06-21 10:56:26.732993
# Unit test for function load
def test_load():
    template_name = 'dummy'
    replay_dir = 'dummy_dir/replay'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-21 10:56:33.832557
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_file = 'tests/test_replay.json'
    context = dict(cookiecutter=dict(full_name='Audrey Roy Greenfeld'))
    dump('tests/test_replay_dir', 'tests/test_replay', context)
    assert os.path.exists(replay_file)
    with open(replay_file, 'r') as infile:
        assert infile.read().strip() == json.dumps(context, indent=2).strip()
    os.remove(replay_file)
    os.rmdir('tests/test_replay_dir')


# Generated at 2022-06-21 10:56:39.602102
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "./CookieCutter/replay"
    template_name = "wangshuguang"

# Generated at 2022-06-21 10:56:44.046358
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/tmp', 'test') == '/tmp/test.json'
    assert get_file_name('/tmp', 'test.json') == '/tmp/test.json'
    assert get_file_name('/tmp', 'test.json.json') == '/tmp/test.json.json'


# Generated at 2022-06-21 10:56:51.546053
# Unit test for function load
def test_load():
    a=load('','cookiecutter-pypackage')
    data=a['cookiecutter']
    assert 'project_name' in data.keys()
    assert 'project_slug' in data.keys()
    assert 'project_short_description' in data.keys()
    assert 'release_date' in data.keys()
    assert 'version' in data.keys()
    assert 'full_name' in data.keys()
    assert 'email' in data.keys()
    assert 'github_username' in data.keys()
    assert 'project_license' in data.keys()
    assert 'version' in data.keys()
    assert 'Select open source license' in data.keys()
    assert 'Select command line framework:' in data.keys()
    assert 'Select use Travis:' in data.keys()

# Generated at 2022-06-21 10:57:00.843074
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = os.getcwd()
    template_name = 'cookiecutter-pypackage'
    context = {"cookiecutter" : {"_copy_without_render" : ["pytest.ini"]}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-21 10:57:13.111100
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'test')
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'full_name': 'Ross James', 'email': 'ross@nebrija.edu', 'github_username': 'rossjames', 'project_name': 'my_project', 'project_slug': 'my_project', 'release_date': '2016-02-23', 'version': '0.1.0', 'open_source_license': 'MIT', 'pypi_username': 'rjames89'}}

# Generated at 2022-06-21 10:57:18.001896
# Unit test for function load
def test_load():
    """Test function load."""
    assert isinstance(load("/Users/hongyu/Desktop/cookiecutter-data-science/tests/fixtures/fake-repo-tmpl/", "fake-repo"), dict)
    assert load("/Users/hongyu/Desktop/cookiecutter-data-science/tests/fixtures/fake-repo-tmpl/", "fake-repo").get('cookiecutter') is not None

# Generated at 2022-06-21 10:57:22.481099
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "test_directory"
    template_name = "test_template"
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, template_name + ".json")


# Generated at 2022-06-21 10:57:26.732248
# Unit test for function dump
def test_dump():
    replay_dir = 'C:\\Users\\Asus\\Desktop\\backup\\play'     
    template_name = 'test'
    context = {'cookiecutter' : {'name' : 'test'}}
    dump(replay_dir, template_name, context)
    

# Generated at 2022-06-21 10:57:31.278392
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = 'tests/files/replay_dir'
    assert get_file_name(replay_dir, 'foobar') == 'tests/files/replay_dir/foobar.json'
    assert get_file_name(replay_dir, 'foobar.json') == 'tests/files/replay_dir/foobar.json'


# Generated at 2022-06-21 10:57:33.446538
# Unit test for function load
def test_load():
    """test_load()."""
    # TODO: create a dummy file to parse
    context = load('./cookiecutter_test')

# Generated at 2022-06-21 10:57:44.335602
# Unit test for function dump
def test_dump():
    """Test the function."""
    import sys
    import tempfile
    import shutil

    replay_dir = tempfile.mkdtemp()
    sys.path.append(replay_dir)
    template_name = 'pantry_raider'
    context = {
        'author_name': 'AUTHOR',
        'email': 'EMAIL',
        'license': 'LICENSE',
        'project_name': 'PROJECT NAME',
        'project_short_description': 'PROJECT SHORT DESCRIPTION',
        'repo_name': 'REPO NAME',
        'cookiecutter': {'replay': 'yes'}
    }


# Generated at 2022-06-21 10:57:47.371703
# Unit test for function get_file_name
def test_get_file_name():
    p = get_file_name('tests/fake-repo-tmpl/', 'fake-project')
    assert p == 'tests/fake-repo-tmpl/fake-project.json'



# Generated at 2022-06-21 10:57:56.347089
# Unit test for function load
def test_load():
    import os
    import json
    from cookiecutter.main import cookiecutter
    from cookiecutter.replay import load

    template_folder = '/tmp/tests/cookiecutter-pypackage-{{cookiecutter.repo_name}}'
    cookiecutter(template_folder, no_input=True, overwrite_if_exists=True)
    context = load('/tmp/tests', 'cookiecutter-pypackage-{{cookiecutter.repo_name}}')

# Generated at 2022-06-21 10:58:05.513611
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    from cookiecutter import replay

    replay_dir = "./test_replay"
    template_name = "test_template"

    filename = replay.get_file_name(replay_dir, template_name)

    if (filename == "./test_replay/test_template.json"):
        print("Unit test for function get_file_name passed.")
    else:
        print("Unit test for function get_file_name failed.")


# Generated at 2022-06-21 10:58:10.766583
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name."""
    dir = 'replay'
    template_name = '{{ cookiecutter.repo_name }}'
    assert get_file_name(dir, template_name) == 'replay/{{ cookiecutter.repo_name }}.json'


# Generated at 2022-06-21 10:58:15.490661
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join(os.getcwd(),'tests','files')
    template_name = 'test_template'
    filename = get_file_name(replay_dir,template_name)
    assert filename == os.path.join(replay_dir,'test_template.json')


# Generated at 2022-06-21 10:58:21.534087
# Unit test for function dump
def test_dump():
    """Unit test for dump()."""
    from shutil import rmtree
    import tempfile

    replay_dir = tempfile.mkdtemp()
    template_name = 'template_name'
    context = {'cookiecutter': {}}

    dump(replay_dir, template_name, context)
    result = load(replay_dir, template_name)

    assert result == context
    rmtree(replay_dir)


# Generated at 2022-06-21 10:58:27.218390
# Unit test for function dump
def test_dump():
    context = {
        "cookiecutter": {
            "full_name": "James",
            "email": "james@example.com",
            "github_username": "anonymous",
            "project_name": "test_project",
            "project_slug": "test_project",
            "project_short_description": "This is a test project.",
            "pypi_username": "anonymous"
        }
    }
    dump(".", "test_dump", context)


# Generated at 2022-06-21 10:58:37.255635
# Unit test for function get_file_name
def test_get_file_name():
    assert(get_file_name('/home/ddhong/101/sample', 'hello') == '/home/ddhong/101/sample/hello.json')
    assert(get_file_name('/home/ddhong/101/sample', 'hello.json') == '/home/ddhong/101/sample/hello.json')
    assert(get_file_name('/home/ddhong/101/sample', 'hello.txt') == '/home/ddhong/101/sample/hello.txt.json')
    assert(get_file_name('/home/ddhong/101/sample', 'hello.txt.json') == '/home/ddhong/101/sample/hello.txt.json.json')


# Generated at 2022-06-21 10:58:44.889488
# Unit test for function dump
def test_dump():

    import os
    import shutil
    from cookiecutter.utils import make_sure_path_exists

    replay_dir = os.path.join(os.getcwd(), 'tests/test-replay')
    if make_sure_path_exists(replay_dir):
        shutil.rmtree(replay_dir)

    template_name = 'test'

# Generated at 2022-06-21 10:58:49.085612
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('dir', 'test') == 'dir/test.json'
    assert get_file_name('dir', 'test.json') == 'dir/test.json'
    assert get_file_name('dir/', 'test.json') == 'dir/test.json'


# Generated at 2022-06-21 10:58:56.993184
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/Users/shashankmishra/Desktop/Code/cookiecutter-pylibrary"
    template_name = "cookiecutter-pylibrary"

    filename = get_file_name(replay_dir, template_name)
    assert(filename == "/Users/shashankmishra/Desktop/Code/cookiecutter-pylibrary/cookiecutter-pylibrary.json")

test_get_file_name()

# Generated at 2022-06-21 10:59:07.162630
# Unit test for function dump
def test_dump():

    # Create a replay directory (only for testing, will be removed)
    replay_dir = 'test_replay'
    os.makedirs(replay_dir)

    # Create a context
    context = {
        'cookiecutter': {
            'project_name': 'cookiecutter-django',
            'project_slug': 'cookiecutter-django',
            'author_name': "Your Name",
            'email': 'your_email@domain.com',
            'description': 'A short description of the project.'
        }
    }
    template_name = 'cookiecutter-django'

    # Dump the context
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))

    # Remove

# Generated at 2022-06-21 10:59:24.355530
# Unit test for function load
def test_load():
    import os
    import tempfile
    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    replay_dir = os.path.join(temp_dir, "replay_dir")
    # Create a temporary file with given content
    replay_file = os.path.join(replay_dir, "replay_file")
    test_content = {"k":"v","nested":{"k2":"v2"},"list":["l1","l2","l3"],"cookiecutter":{"foo":"bar"}}

# Generated at 2022-06-21 10:59:26.882680
# Unit test for function load
def test_load():
    context=load(replay_dir='/home/sujit/cookiecutter-exampledjango',template_name='sujit')
    print(context)

# Generated at 2022-06-21 10:59:30.446278
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/tmp/cookicutter/replay'
    template_name = 'django-project'

    replay_file = get_file_name(replay_dir, template_name)
    assert replay_file == '/tmp/cookicutter/replay/django-project.json'

# Generated at 2022-06-21 10:59:37.817512
# Unit test for function get_file_name
def test_get_file_name():
    # Template Name Suffix

    # Template Name Suffix End with json
    replay_dir = '.'
    template_name = '{{cookiecutter.repo_name}}.json'
    test_file_name = get_file_name(replay_dir, template_name)
    correct_file_name = './{{cookiecutter.repo_name}}.json'
    if not test_file_name == correct_file_name:
        raise ValueError('test_file_name is not equal to correct_file_name')
    print('test_get_file_name pass')

    # Template Name Suffix Not End with json
    template_name = '{{cookiecutter.repo_name}}'
    test_file_name = get_file_name(replay_dir, template_name)
    correct_file_name

# Generated at 2022-06-21 10:59:44.271060
# Unit test for function load
def test_load():

    # Create replay file with valid context
    template_name = 'foo_template'
    test_dir = 'testdir'
    context = {'cookiecutter':{'cookie':'chocolate'}}
    dump(test_dir, template_name, context)
    loaded_context = load(test_dir, template_name)
    assert loaded_context == context

    # Create replay file with invalid context
    template_name = 'bar_template'
    test_dir = 'testdir'
    context = {'cookies':{'cookie':'chocolate'}}
    dump(test_dir, template_name, context)
    try:
        load(test_dir, template_name)
    except ValueError as e:
        assert e.message == 'Context is required to contain a cookiecutter key'


# Generated at 2022-06-21 10:59:52.787104
# Unit test for function load
def test_load():
    """Unit test for function load"""
    context = {
        'cookiecutter': {
            'full_name': 'First Last',
            'email': 'me@example.com',
            'github_username': 'audreyr',
            'project_name': 'Foo',
            'project_slug': 'foo',
            'project_short_description': 'Awesome project'}
    }
    template_name = "test_cookiecutter.json"
    dump('.', template_name, context)
    loaded_context = load('.', template_name)
    assert loaded_context == context
    os.remove(template_name)


# Generated at 2022-06-21 10:59:55.346305
# Unit test for function load
def test_load():
	load('/Users/wuzhicheng/workspace/cookiecutter-joomla-template/', 'cookiecutter.json')

#test_load()

# Generated at 2022-06-21 11:00:02.830581
# Unit test for function dump
def test_dump():
    replay_dir = "replay_dir"
    template_name = "test"
    context = {"cookiecutter": {"test": "test"}}
    dump(replay_dir, template_name, context)

    assert os.path.exists(replay_dir)
    assert os.path.exists(os.path.join(replay_dir, template_name +".json"))
    assert load(replay_dir, template_name) == context

    os.remove(os.path.join(replay_dir, template_name+".json"))
    os.rmdir(replay_dir)


# Generated at 2022-06-21 11:00:07.579370
# Unit test for function dump
def test_dump():
    template_name = 'bower_package'
    replay_dir = 'testing'
    context = {
        'cookiecutter': {
            'package_name': '{{ cookiecutter.project_slug | replace("-", "_") }}',
        },
    }
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-21 11:00:10.338976
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tests/replay'
    template_name = 'abc'
    expected_file_name = 'tests/replay/abc.json'
    actual_file_name = get_file_name(replay_dir, template_name)
    assert expected_file_name == actual_file_name


# Generated at 2022-06-21 11:00:22.126772
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.dirname(__file__), 'tests', 'test_replay')
    template_name = 'test'
    for context in [{'cookiecutter': {'repo_dir': '/test/repo_dir'}},
                    {'cookiecutter': {'extra_context': {'repo_dir': '/test/repo_dir'}}}]:
        try:
            dump(replay_dir, template_name, context)
        except IOError as e:
            print('Unable to write ' + template_name + '.json to ' + replay_dir)
        else:
            assert(True)


# Generated at 2022-06-21 11:00:28.837042
# Unit test for function load
def test_load():
    print("Testing function load")
    test_context = {'cookiecutter': {"full_name": "Pratik Krishnan", "email": "pratik.krishnan@gmail.com"}}
    replay_dir = "~/replays"
    template_name = "template_name"

# Generated at 2022-06-21 11:00:33.912404
# Unit test for function load
def test_load():
    print("\n"+"="*20)
    print("Unit test for function load")
    replay_dir ="/Users/yanglu/Documents/GitHub/cookiecutter-pypackage/"
    template_name = "cookiecutter.json"
    context = load(replay_dir, template_name)

# Generated at 2022-06-21 11:00:37.797965
# Unit test for function get_file_name
def test_get_file_name():
    fname = get_file_name('replay_dir', 'template_name')
    assert fname == os.path.join('replay_dir', 'template_name.json')

    fname = get_file_name('replay_dir', 'template_name.json')
    assert fname == os.path.join('replay_dir', 'template_name.json')

# Generated at 2022-06-21 11:00:40.959531
# Unit test for function dump
def test_dump():
    #TODO: check if file exist in the replay folder
    print("testing dump")
    context = {'cookiecutter': {'project_name': 'test_dump'}}
    dump('../../replay', 'test-repo-dump', context)


# Generated at 2022-06-21 11:00:43.268729
# Unit test for function load
def test_load():
    replay_dir = os.getcwd() + '/tests/test-replay/'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Robyn Butler'
    assert context['cookiecutter']['email'] == 'robyn@example.com'

# Generated at 2022-06-21 11:00:48.774375
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '~/cookiecutter-replay'
    template_name = 'cookiecutter-pypackage'
    assert get_file_name(replay_dir, template_name) == '~/cookiecutter-replay/cookiecutter-pypackage.json'

    template_name = 'cookiecutter-pypackage.json'
    assert get_file_name(replay_dir, template_name) == '~/cookiecutter-replay/cookiecutter-pypackage.json'



# Generated at 2022-06-21 11:00:55.853990
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'repo_dir': '.',
            'replay_dir': '.',
            'context_file': 'cookiecutter.json'
        }
    }
    dump(context['cookiecutter']['replay_dir'], 'tempname', context)
    expected = json.dumps(context, sort_keys=True, indent=2)
    actual = json.dumps(load(context['cookiecutter']['replay_dir'], 'tempname'), sort_keys=True, indent=2)
    assert expected == actual


# Generated at 2022-06-21 11:01:02.620283
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'test_template'
    context = {'cookiecutter':'hi'}

    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)
    os.remove(replay_file)


# Generated at 2022-06-21 11:01:06.485244
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    # setup
    replay_dir = 'data/replay'
    template_name = 'bogus_data'

    # exec
    dump(replay_dir, template_name, {'cookiecutter':123})
    context = load(replay_dir, template_name)

    # assert
    assert(isinstance(context, dict))
    assert('cookiecutter' in context)
    assert(context['cookiecutter'] == 123)

# Generated at 2022-06-21 11:01:17.502825
# Unit test for function get_file_name
def test_get_file_name():
    """unittest for get_file_name"""
    file_name = get_file_name('./', 'test')
    assert file_name == './test.json'

    file_name = get_file_name('./', 'test.json')
    assert file_name == './test.json'



# Generated at 2022-06-21 11:01:20.846280
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "replay"
    template_name = "j2"
    filename = get_file_name(replay_dir, template_name)
    assert filename == "replay/j2.json"


# Generated at 2022-06-21 11:01:30.028647
# Unit test for function load
def test_load():
    replay_dir = 'tmp'
    template_name = 'test_load'
    context = {
        'cookiecutter': {
            'cookiecutter': {
                'replay_dir': 'tmp',
                'template': 'test_load',
                'extra_context': {
                    'foo': 'bar',
                },
            },
        }
    }
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['cookiecutter']['extra_context']['foo'] == 'bar'
    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-21 11:01:41.006114
# Unit test for function dump
def test_dump():
    replay_dir = '/Users/szhu/workspace-git/python-module'
    template_name = 'cookiecutter-bamproject'
    context = {
        'cookiecutter': {
            'project_name': 'BAMproject',
            'project_slug': 'bamproject',
            'project_short_description': 'BAM pipeline.',
            'author_name': 'Jason',
            'email': 'jma7@sanger.ac.uk',
            'release_date': '2016-06-06',
            'version': '0.1.0',
            'year': '2016',
        }
    }
    dump(replay_dir, template_name, context)
    return


# Generated at 2022-06-21 11:01:41.462937
# Unit test for function load
def test_load():
    pass

# Generated at 2022-06-21 11:01:45.981538
# Unit test for function load
def test_load():
    dict = {'cookiecutter': {'repo_dir': 'testrepo'}, 'test': 'test', 'test2': 'test2'}
    dump('testdir', 'test', dict)
    new_dict = load('testdir', 'test')
    assert dict == new_dict

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-21 11:01:52.182038
# Unit test for function dump
def test_dump():
	replay_dir = '/Users/xywang/Documents/CookieCutter'
	template_name = "TestInput"
	context = {
		'cookiecutter': {'full_name': 'Xinyu Wang', 'email': 'xinyuw@andrew.cmu.edu', 'replay_dir': '/Users/xywang/Documents/CookieCutter', 'replay_filename': 'TestInput.json', 'template_name': 'TestInput'}
	}
	dump(replay_dir, template_name, context)



# Generated at 2022-06-21 11:01:57.070990
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = '/tmp/cookiecutter'
    template_name = 'test_template'
    try:
        dump(replay_dir, template_name, {'cookiecutter': {'name': 'test_name'}})
        context = load(replay_dir, template_name)
        assert context['cookiecutter']['name'] == 'test_name'
    except:
        raise
    finally:
        os.remove(os.path.join(replay_dir, '{}.json'.format(template_name)))
        os.removedirs(replay_dir)



# Generated at 2022-06-21 11:02:05.430213
# Unit test for function dump
def test_dump():
    import tempfile
    import shutil
    file_name ='test'
    e = {"cookiecutter" : {"test" : "test"}}
    try:
        tmp=tempfile.mkdtemp()
        dump(tmp,file_name,e)
        f= open(tmp+"/test.json",'r')
        assert f.read() == '{\n  "cookiecutter": {\n    "test": "test"\n  }\n}\n'
    finally:
        shutil.rmtree(tmp)
    

# Generated at 2022-06-21 11:02:14.532219
# Unit test for function dump
def test_dump():
    """ Test dump function"""
    from cookiecutter.main import cookiecutter

    replay_dir='test_replay/'
    template_name='test.json'

    context={'cookiecutter':{'full_name': 'test', 'email': 'test@test.com'}}
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file) is True

    # test dump again and compare with previous file
    context={'cookiecutter':{'full_name': 'test2', 'email': 'test2@test.com'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 11:02:29.465308
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = '/Users/mingtao/cookiecutter-replay'
    template_name = 'python_package'
    assert get_file_name(replay_dir, template_name) == '/Users/mingtao/cookiecutter-replay/python_package.json'

    replay_dir = '/Users/mingtao/cookiecutter-replay'
    template_name = 'python_package.json'
    assert get_file_name(replay_dir, template_name) == '/Users/mingtao/cookiecutter-replay/python_package.json'


# Generated at 2022-06-21 11:02:34.920852
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "test"
    template_name = "test_template"
    path = get_file_name(replay_dir, template_name)
    assert path == 'test/test_template.json', "Expected path to be test/test_template.json, but was %s" % path



# Generated at 2022-06-21 11:02:43.468279
# Unit test for function dump
def test_dump():
    #test for successful dump
    replay_dir = 'C:\\Users\\Lina\\Desktop\\Code\\learning\\cookiecutter-learning\\cookiecutter-learning\\cookiecutter'
    template_name = 'test.json'
    context = {'cookiecutter' : {'project_name' : 'test' , 'github_username' : 'Lina'}, 
               'version' : '0.1'}
    try:
        dump(replay_dir, template_name, context)
    except ValueError as e:
        print(e.args)
    except Exception as e:
        print(e.args)
    #test for unsuccessful dump
    replay_dir = 'C:\\Users\\Lina\\Desktop\\Code\\learning\\cookiecutter-learning\\cookiecutter-learning\\cookiecutter'
    template_name

# Generated at 2022-06-21 11:02:51.000902
# Unit test for function dump
def test_dump():
    template_name = 'template'
    context = {'cookiecutter': 'cookiecutter'}
    replay_dir = os.getcwd() + '\\tests'
    replay_file = replay_dir + '\\' + template_name + '.json'
    dump(replay_dir, template_name, context)
    with open(replay_file, 'r') as infile:
        context_load = json.load(infile)
    assert context == context_load
    os.remove(replay_file)
