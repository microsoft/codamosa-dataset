

# Generated at 2022-06-21 10:53:00.394763
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    template_name = 'template_name'
    context = {'cookiecutter': {'project_name': 'project_name'}}
    replay_dir = os.path.join(os.getcwd(), 'replay')

    dump(replay_dir, template_name, context)

    assert os.path.exists(os.path.join(replay_dir, template_name))
    assert load(replay_dir, template_name) == context

    # remove replay dir
    for the_file in os.listdir(replay_dir):
        file_path = os.path.join(replay_dir, the_file)

# Generated at 2022-06-21 10:53:12.106620
# Unit test for function load
def test_load():
    replay_dir = 'test/test_load_dir'
    template_name = 'test.json'
    context = {
        'cookiecutter': {
            'first_name': 'Audrey',
            'last_name': 'Roy',
            'email': 'audreyr@example.com'
        },
    }
    dump(replay_dir, template_name, context)
    context2 = load(replay_dir, template_name)

    assert context == context2
    assert context2['cookiecutter']['first_name'] == 'Audrey'
    assert context2['cookiecutter']['last_name'] == 'Roy'
    assert context2['cookiecutter']['email'] == 'audreyr@example.com'


# Generated at 2022-06-21 10:53:14.866548
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-load'
    template_name = 'test'
    context = load(replay_dir, template_name)
    assert(context['cookiecutter'] == {'year': '2014', 'full_name': 'Audrey Roy Greenfeld', 'email': 'audreyr@example.com', 'github_username': 'audreyr'})
    



# Generated at 2022-06-21 10:53:22.162607
# Unit test for function dump
def test_dump():
    """Test for function dump."""
    replay_dir = '~/.cookiecutter_replay'
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'replay':True, 'full_name': 'Hengfeng Li', 'email': 'lihengfeng@dayan.cn', 'project_name': 'cookiecutter-pypackage'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:53:29.595300
# Unit test for function dump
def test_dump():
    """Test function dump."""
    test_dir = os.path.join(os.path.dirname(__file__), "test_dir")
    dump(test_dir, "test_dump_template", {"cookiecutter": "test_dump_context", "test_dump_key": "test_dump_value"})
    assert os.path.exists(os.path.join(test_dir, "test_dump_template.json"))
    return


# Generated at 2022-06-21 10:53:32.712336
# Unit test for function load
def test_load():
    result = load(None, None)
    assert result != None


# Generated at 2022-06-21 10:53:39.582224
# Unit test for function get_file_name
def test_get_file_name():
    # A suffix should be added to the file name
    replay_dir = '/tmp/'
    template_name = 'python-library'
    assert get_file_name(replay_dir, template_name) == '/tmp/python-library.json'
    # No suffix should be added to the file name
    template_name += '.json'
    assert get_file_name(replay_dir, template_name) == '/tmp/python-library.json'



# Generated at 2022-06-21 10:53:45.217896
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'cookiecutter.json'
    replay_path = os.path.join('~', 'cookiecutter', 'replay')
    replay_file = get_file_name(replay_path, template_name)
    assert replay_file == os.path.join('~', 'cookiecutter', 'replay', template_name)

# Generated at 2022-06-21 10:53:53.752307
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("replay", "test") == 'replay/test.json'
    assert get_file_name("replay", "test.json") == 'replay/test.json'

    try:
        assert get_file_name(1234, "test")
    except TypeError:
        print("Get file name needs directory to be a sting")

    try:
        assert get_file_name("replay", 1234)
    except TypeError:
        print("Get file name needs template name to be a string")


# Generated at 2022-06-21 10:53:57.620632
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    assert get_file_name(replay_dir, template_name) == 'replay_dir/template_name.json', 'Error generating file name'
    assert get_file_name(replay_dir, 'template_name.json') == 'replay_dir/template_name.json', 'Error generating file name'



# Generated at 2022-06-21 10:54:00.796693
# Unit test for function load

# Generated at 2022-06-21 10:54:05.967167
# Unit test for function dump
def test_dump():
    replay_dir = './tests/test-replay'
    context = dict(cookiecutter=dict(full_name='David Blewett'))
    template_name = 'test-template'

    dump(replay_dir,template_name,context)


# Generated at 2022-06-21 10:54:12.835813
# Unit test for function dump
def test_dump():
    from cookiecutter import replay
    replay.dump('replay', 'audreyr/cookiecutter-pypackage', {'foo':'bar'})
    assert os.path.exists('replay/audreyr/cookiecutter-pypackage.json')
    os.remove('replay/audreyr/cookiecutter-pypackage.json')
    os.rmdir('replay/audreyr')
    os.rmdir('replay')


# Generated at 2022-06-21 10:54:20.662068
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name"""
    replay_dir = 'test_dir'
    template_name = 'test_template'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'test_dir/test_template.json'
    replay_dir = 'test_dir'
    template_name = 'test_template.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'test_dir/test_template.json'
    replay_dir = 'C:\\test_dir'
    template_name = 'test_template.json'
    file_name = get_file_name(replay_dir, template_name)

# Generated at 2022-06-21 10:54:28.374451
# Unit test for function dump
def test_dump():
	replay_dir = '~/.cookiecutters/'
	template_name = 'wtf'
	context = {'cookiecutter':{'name':'shitty','path':'/home/shitty','replay':{'noinput':True}}}
	try:
		dump(replay_dir,template_name,context)
	except:
		assert 1==1


# Generated at 2022-06-21 10:54:33.905552
# Unit test for function load
def test_load():
    replay_dir = '../../tests/test-cookiecutter/foo/'
    template_name = 'cookiecutter.json'
    context = load(replay_dir, template_name)
    assert context == {
        'cookiecutter': {
            'full_name': 'Audrey Roy Greenfeld',
            'github_username': 'audreyr',
            'email': 'audreyr@example.com',
            'description': 'A short description of the project.',
            'project_name': '{{cookiecutter.repo_name}}',
            'repo_name': '{{cookiecutter.project_name}}'
        }
    }


# Generated at 2022-06-21 10:54:43.229255
# Unit test for function dump
def test_dump():
    if not make_sure_path_exists('/tmp'):
        raise IOError('Unable to create replay dir at {}'.format('/tmp'))
    context = {'cookiecutter': {'full_name': 'Your Name', 'email': 'Your email',
                                'github_username': 'Your GitHub username', 'project_name': 'Project name'}}
    template_name = 'https://github.com/OsciiArt/cookiecutter-osciiart-project.git'
    replay_dir = '/tmp'
    dump(replay_dir, template_name, context)
    assert os.path.exists('/tmp/https___github.com_OsciiArt_cookiecutter-osciiart-project.git.json')


# Generated at 2022-06-21 10:54:45.719619
# Unit test for function load
def test_load():
    c = load('C:\\Users\\Anna\\Desktop\\test', 'gt-python-course')
    print(c)
test_load()

# Generated at 2022-06-21 10:54:52.394945
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.dirname(__file__), 'test_replays')
    replay_file = get_file_name(replay_dir, 'test_template')

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

# Generated at 2022-06-21 10:54:56.817491
# Unit test for function load
def test_load():
    replay_dir = "/home/travis/build/cookiecutter-test/cookiecutter"
    template_name = "cookiecutter-django"
    context = load(replay_dir, template_name)
    print (context)



# Generated at 2022-06-21 10:55:03.137840
# Unit test for function load
def test_load():
    """Test replay.load."""
    replay_dir = '~/.cookiecutters'
    template_name = 'pytest'
    replay_file = os.path.join(replay_dir, template_name)
    context = load(replay_dir, template_name)
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-21 10:55:14.751448
# Unit test for function load
def test_load():
    assert load('/home/ynie/cookiecutter', 'cookiecutter-pypackage')

    replay_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'replay')
    assert os.path.exists(replay_dir)

    cc_dict = load(replay_dir, 'cookiecutter-pypackage')
    assert 'cookiecutter' in cc_dict
    assert 'project_name' in cc_dict['cookiecutter']
    assert 'full_name' in cc_dict['cookiecutter']

    cc_dict = load(replay_dir, 'cookiecutter-pypackage.json')
    assert 'cookiecutter' in cc_dict
    assert 'project_name' in cc_dict['cookiecutter']


# Generated at 2022-06-21 10:55:18.305064
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = './'
    template_name = 'cookiecutter-pypackage-min'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == './cookiecutter-pypackage-min.json'


# Generated at 2022-06-21 10:55:22.780882
# Unit test for function get_file_name
def test_get_file_name():

    replay_dir = "tests/test-output"
    template_name = "cookiecutter-pypackage"
    expected_file_name = replay_dir + "/" + template_name + ".json"
    actual_file_name = get_file_name(replay_dir, template_name)
    assert expected_file_name == actual_file_name


# Generated at 2022-06-21 10:55:33.212145
# Unit test for function dump
def test_dump():
    import shutil
    from tempfile import mkdtemp
    from cookiecutter.main import cookiecutter
    from cookiecutter.exceptions import FailedHookException

    replay_dir = mkdtemp()
    template_dir = os.path.dirname(os.path.abspath(__file__))

    args = {
        'no_input': True,
        'extra_context': {'repo_name': 'foo', 'repo_slug': 'foo'},
        'replay': True,
        'replay_dir': replay_dir
    }

    cookiecutter(template_dir, **args)

    context = load(replay_dir, 'foobar')
    print(context)

    cookiecutter(template_dir, **args)

    shutil.rmtree(replay_dir)

# Generated at 2022-06-21 10:55:40.985965
# Unit test for function load
def test_load():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    path_to_json = os.path.join(dir_path, '..', '..', 'tests', 'test-repo', '{{cookiecutter.repo_name}}.json')
    load(dir_path, '{{cookiecutter.repo_name}}.json')
    assert os.path.exists(path_to_json)
    os.remove(path_to_json)



# Generated at 2022-06-21 10:55:52.616869
# Unit test for function dump
def test_dump():
    replay_dir = 'D:\Github\cookiecutter-pypackage'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-21 10:55:56.395696
# Unit test for function load
def test_load():
    """Testing load."""
    contex = load('/Users/vumac/code/code_in_general/cookiecutter-draft-dodger/', 'cookiecutter.json')
    assert contex is not None
    assert contex['project_name']


# Generated at 2022-06-21 10:56:00.573588
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.getcwd(), "test")
    template_name = "test"
    context = {'cookiecutter': 'test'}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-21 10:56:06.786192
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/replay'
    template_name = 'tests/files/replay'
    context = {'cookiecutter':{'test': 'mytest'}}
    dump(replay_dir, template_name, context)
    new_context = load(replay_dir, template_name)
    assert new_context == context



# Generated at 2022-06-21 10:56:09.350524
# Unit test for function load
def test_load():
    context = load('C:/Users/Sudhanshu/Desktop/CookieCutter/test_replay', 'test.json')



# Generated at 2022-06-21 10:56:11.674144
# Unit test for function load
def test_load():
    print ("=============================")
    print ("Unit test function load...")
    print ("-------------------------")
    replay_dir = "."
    template_name = "python_package"
    context = load(replay_dir, template_name)
    print ("=============================")
    print (context)


# Generated at 2022-06-21 10:56:21.725876
# Unit test for function load
def test_load():
    """Unit test for function load."""
    assert load('.', 'hello_world.json') == {'cookiecutter':
                                             {'_template': 'hello_world',
                                              'name': 'foo'}}, "Should return the correct context."
    assert load('.', 'hello_world') == {'cookiecutter':
                                             {'_template': 'hello_world',
                                              'name': 'foo'}}, "Should return the correct context."
    assert load('.', 'hello_world') == {'cookiecutter':
                                             {'_template': 'hello_world',
                                              'name': 'foo'}}, "Should return the correct context."



# Generated at 2022-06-21 10:56:32.217386
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), "test_replay")
    template_name = "test_template"
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert context["cookiecutter"]
    assert context["cookiecutter"]["_template"] == "test_template"
    assert context["cookiecutter"]["_replay"] == replay_dir
    assert context["cookiecutter"]["full_name"] == "test_fullname"
    assert context["cookiecutter"]["email"] == "test_email"
    assert context["cookiecutter"]["github_username"] == "test_user"
    assert context["cookiecutter"]["project_name"]

# Generated at 2022-06-21 10:56:43.694321
# Unit test for function dump
def test_dump():
    replay_dir = os.path.abspath(os.path.join('tests', 'replay'))
    make_sure_path_exists(replay_dir)
    template_name = os.path.basename('tests/fake-repo-pre/')
    context = dict()
    context['cookiecutter'] = dict()
    context['cookiecutter']['full_name'] = "Nadia Alramli"
    context['cookiecutter']['email'] = "nadia@example.com"
    context['cookiecutter']['project_name'] = "Example"
    context['cookiecutter']['repo_name'] = "example"
    context['cookiecutter']['project_short_description'] = "Example Project"

# Generated at 2022-06-21 10:56:48.463465
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/fake-replay-dir'
    template_name = 'fake-repo-pre/{{cookiecutter.project_name}}'
    context = {'cookiecutter': {'project_name': 'foobar'}}

    try:
        dump(replay_dir, template_name, context)
    except Exception:
        raise AssertionError('dump() should not raise an exception.')


# Generated at 2022-06-21 10:56:53.234472
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name"""
    assert get_file_name('c:\\', 'LoanApplication') == \
        'c:\\LoanApplication.json'
    assert get_file_name('c:\\', 'ReviewLoanApplication') == \
        'c:\\ReviewLoanApplication.json'
    assert get_file_name('c:\\', 'LoanApplication.json') == \
        'c:\\LoanApplication.json'
    assert get_file_name('c:\\', 'ReviewLoanApplication.json') == \
        'c:\\ReviewLoanApplication.json'

# Generated at 2022-06-21 10:56:55.378956
# Unit test for function get_file_name
def test_get_file_name():
	assert get_file_name('/tmp/test', 'blah') == '/tmp/test/blah.json'

# Generated at 2022-06-21 10:57:05.304939
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""

    # test with relative path
    replay_dir = '.'
    template_name = 'sometemplate'
    expected_file_name = './sometemplate.json'
    returned_value = get_file_name(replay_dir, template_name)
    assert (returned_value == expected_file_name), \
        'Expected: %s, got %s' % (expected_file_name, returned_value)

    # test with absolute path
    replay_dir = '/some/absolute/path'
    template_name = 'sometemplate'
    expected_file_n

# Generated at 2022-06-21 10:57:14.628642
# Unit test for function dump
def test_dump():
    """Unit test for dump()."""
    import tempfile
    temp_replay_dir = tempfile.TemporaryDirectory()
    replay_dir = os.path.join(temp_replay_dir.name, 'cookies')
    template_name = "python_package"
    context = {"cookiecutter": {"project_name": "cookie_monster"}}
    dump(replay_dir, template_name, context)

    replay_file = os.path.join(replay_dir, template_name + '.json')
    with open(replay_file, 'r') as infile:
        replay = json.load(infile)

    assert replay == context


# Generated at 2022-06-21 10:57:24.704959
# Unit test for function load
def test_load():
    """Test load function."""
    template_name= 'template_name'
    replay_dir = 'replay_dir'
    context = {'cookiecutter': '1234'}
    replay_dir = get_file_name(replay_dir, template_name)
    with open(replay_dir, 'w') as outfile:
        json.dump(context, outfile, indent=2)
    load_response = load(replay_dir, template_name)
    assert context == load_response

# Generated at 2022-06-21 10:57:28.406619
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = ""
    template_name = "test"
    assert get_file_name(replay_dir, template_name) == "test.json"
    template_name = "test.json"
    assert get_file_name(replay_dir, template_name) == "test.json"


# Generated at 2022-06-21 10:57:31.455369
# Unit test for function load
def test_load():
    replay_dir = "./"
    template_name = "template.json"
    context = load(replay_dir, template_name)
    print (context)


# Generated at 2022-06-21 10:57:39.457302
# Unit test for function dump
def test_dump():
    template_dict = {'cookiecutter': {'project_name': 'test',
                                      'project_slug': 'test-slug'}}
    replay_dir = 'tests/test-replay'
    replay_file = os.path.join(replay_dir, 'cookiecutter-pypackage.json')
    try:
        dump(replay_dir, 'cookiecutter-pypackage.json', template_dict)
        assert os.path.isfile(replay_file)
    finally:
        os.remove(replay_file)


# Generated at 2022-06-21 10:57:49.675376
# Unit test for function dump
def test_dump():
    """Test dump function in replay.py."""
    replay_dir = 'tests/test-replay-dump'
    template_name = 'tests-replay-dump'
    context = {'cookiecutter': {'full_name': 'Snoop Dogg', 'email': 'snoop@dogg.com'}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile('{}/tests-replay-dump.json'.format(replay_dir)) == True, 'Dump failed to create file'
    assert 'Snoop' in open('{}/tests-replay-dump.json'.format(replay_dir)).read(), 'Dump failed to write to file'



# Generated at 2022-06-21 10:57:56.346783
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for functon get_file_name."""
    test_dir = '/tmp/cookiecutter/tests/replay'
    test_name = 'test_template'
    test_file_name = '{}.json'.format(test_name)
    test_json_file = '{}/{}'.format(test_dir, test_file_name)

    assert get_file_name(test_dir, test_name) == test_json_file

    test_name = 'test_template.json'
    assert get_file_name(test_dir, test_name) == test_json_file



# Generated at 2022-06-21 10:58:06.630718
# Unit test for function dump
def test_dump():
    import time
    import shutil

    # Create the directory that will hold the replay file
    replay_dir = 'tests/files'
    make_sure_path_exists(replay_dir)

    # Create the replay file
    template_name = 'tests/files/test'
    context = {
        'cookiecutter': {
            'full_name': 'Test User',
            'email': 'testuser@example.com',
            'github_username': 'test-user',
            'project_name': 'Test Project',
            'project_slug': 'test-project',
            'pypi_username': 'testuser',
            'version': '0.1.0',
            'release_date': time.strftime('%d/%m/%Y')
        }
    }


# Generated at 2022-06-21 10:58:08.073647
# Unit test for function get_file_name
def test_get_file_name():
    output = get_file_name('replay_dir', 'template_name')
    assert output == 'replay_dir/template_name.json'

# Generated at 2022-06-21 10:58:12.381766
# Unit test for function load
def test_load():
    """Test the load function."""
    template_name = "unittest_template"
    test_file = tempfile.TemporaryFile()
    test_file.write("{'cookiecutter': {'name': 'Test name'}}")
    load(test_file, template_name)


# Generated at 2022-06-21 10:58:17.532607
# Unit test for function load
def test_load():
    replay_dir = 'C:\\Users\\rkotarla\\Desktop\\Cookicutter\\cookiecutter-pypackage-min'
    template_name = 'cookiecutter-pypackage-min'
    context = load(replay_dir, template_name)
    assert(context['_template'] == 'cookiecutter-pypackage-min')


# Generated at 2022-06-21 10:58:26.967116
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'cookiecutter-pypackage'
    replay_dir = '/path/to/dir'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/path/to/dir/cookiecutter-pypackage.json', 'Test failed'

test_get_file_name()

# Generated at 2022-06-21 10:58:35.810856
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    template_name = 'test_template'
    replay_dir = '/tmp/replay_dir'
    context = {'cookiecutter': {'full_name': 'Audrey Roy Greenfeld'}}

    dump(replay_dir, template_name, context)

    assert os.path.exists(get_file_name(replay_dir, template_name))

    load(replay_dir, template_name)

    os.remove(get_file_name(replay_dir, template_name))

    assert not os.path.exists(get_file_name(replay_dir, template_name))

# Generated at 2022-06-21 10:58:40.575766
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    template_name = 'test_template'
    context = {'cookiecutter': {'test_value': '123'}}
    replay_dir = '.'

    dump(replay_dir, template_name, context)
    output = load(replay_dir, template_name)

    assert context == output

    os.remove('test_template.json')

# Generated at 2022-06-21 10:58:46.887214
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    replay_dir = os.path.join(os.path.dirname(__file__), "test_replay")
    template_name = "test_template"
    default_file_name = get_file_name(replay_dir, template_name)
    assert default_file_name == os.path.join(replay_dir, template_name + ".json")

    replay_dir = os.path.join(os.path.dirname(__file__), "test_replay")
    template_name = "test_template.json"
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, template_name)


# Generated at 2022-06-21 10:58:59.206043
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    # Check if replay_dir path needs to be created
    replay_dir = os.getcwd() + '/tests/test-replay/'
    template_name = 'test-template'
    context = {'cookiecutter': {'a':'1', 'b':2}}

    dump(replay_dir, template_name, context)

    assert os.path.isfile(replay_dir + template_name + '.json')

    # Check if replay_dir path does not need to be created
    replay_dir = os.getcwd() + '/tests/test-replay-2/'
    template_name = 'test-template-2'

    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:59:06.409060
# Unit test for function dump
def test_dump():
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    context = {'cookiecutter': {'name': 'name'}}
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    try:
        with open(replay_file) as data_file:
            data = json.load(data_file)
    except IOError:
        assert False
    else:
        assert data == context



# Generated at 2022-06-21 10:59:09.406327
# Unit test for function get_file_name
def test_get_file_name():
    d = dict()
    d["replay_dir"] = "./tests"
    d["template_name"] = "my_template"
    assert get_file_name(d["replay_dir"], d["template_name"]) == "./tests/my_template.json"

# Generated at 2022-06-21 10:59:12.339517
# Unit test for function get_file_name
def test_get_file_name():
    template_name = "test"
    replay_dir = "../replay"
    assert get_file_name(replay_dir, template_name) == '../replay/test.json'


# Generated at 2022-06-21 10:59:24.569490
# Unit test for function load
def test_load():
    template_name = 'mytemplate'
    replay_dir = 'myreplaydir'

    # set cookiecutter context
    context = {
        'cookiecutter':{'hello':'world'}
    }
    # file not found
    try:
        load(replay_dir, template_name)
    except IOError as e:
        assert 'Unable' in str(e)
    # create replay directory
    make_sure_path_exists(replay_dir)
    # wrong file format
    try:
        load(replay_dir, template_name+'.json')
    except IOError as e:
        assert 'No such' in str(e)
    # wrong context

# Generated at 2022-06-21 10:59:27.779536
# Unit test for function load
def test_load():
    context = load("/home/qijingtao/repo/cookiecutter-django", "qijingtao/django-project-template")

# Generated at 2022-06-21 10:59:41.253156
# Unit test for function dump
def test_dump():
    from pathlib import Path
    cookiecutter_json = {"cookiecutter": {"_template": "cookiecutter-pypackage"}}
    test_dump_path = Path('./cookiecutter_replay_unit_test_dump')
    replay_file = get_file_name(test_dump_path, 'cookiecutter-pypackage')
    dump(test_dump_path, 'cookiecutter-pypackage', cookiecutter_json)
    with open(replay_file, 'r') as f:
        assert f.readlines()[1:3] == ['  "_template": "cookiecutter-pypackage"\n', '}']
    os.remove(replay_file)


# Generated at 2022-06-21 10:59:44.438127
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'path/to/replay_dir'
    template_name = 'cookiecutter-pypackage'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, template_name + '.json')


if __name__ == '__main__':
    test_get_file_name()

# Generated at 2022-06-21 10:59:52.197640
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.getcwd()
    template_name = 'foo'
    file_name = get_file_name(replay_dir, template_name)
    expected_file_name = os.path.join(replay_dir, 'foo.json')
    assert file_name == expected_file_name
    template_name = 'foo.json'
    file_name = get_file_name(replay_dir, template_name)
    expected_file_name = os.path.join(replay_dir, 'foo.json')
    assert file_name == expected_file_name

# Generated at 2022-06-21 10:59:54.828937
# Unit test for function load
def test_load():
    replay = load('/opt/cookiecutter-django', 'cookiecutter-django')
    assert (replay == {'cookiecutter': {'replay': True}})

"""
self test
"""
if __name__ == '__main__':
    test_load()

# Generated at 2022-06-21 11:00:04.129693
# Unit test for function dump
def test_dump():
    template_name = 'example'
    replay_dir = 'C:/Users/zhengyu/Documents/GitHub/cookiecutter-example'
    context = {'cookiecutter': {'full_name': 'Zhengyu Pan',
                                'email': 'i@panzhenyu.com',
                                'github_username': 'zhengyu-pan',
                                'project_name': 'My_first_project',
                                'description': 'test',
                                'domain_name': 'myfirstproject',
                                'version': '0.1.0',
                                'timezone': 'Asia/Urumqi',
                                'open_source_license': 'MIT license',
                                'use_pycharm': 'y'}}
    dump(replay_dir, template_name, context)

# Unit test

# Generated at 2022-06-21 11:00:10.827072
# Unit test for function load
def test_load():
    # Sample Dict
    dict1 = {
        'cookiecutter': {
            'project_name': 'Cookiecutter Cookiecutter',
            'project_short_description': 'A cookiecutter for cookiecutters.',
            'repo_name': 'cookiecutter-cookiecutter',
            'author_name': 'Audrey Roy Greenfeld',
            'author_email': 'audreyr@example.com',
            'pypi_username': 'audreyr',
            },
        }
    # Write Dict to testfile
    temp_file = 'test_replay'
    with open(temp_file, 'w') as outfile:
        json.dump(dict1, outfile, indent=2)
    # Load Dict from testfile
    dict2 = load('', 'test_replay')


# Generated at 2022-06-21 11:00:20.542095
# Unit test for function dump
def test_dump():
    """Create a replay file given a context and dir."""
    context = {
        'cookiecutter': {
            '_template': 'default',
            'project_slug': 'my-first-project',
        }
    }

    replay_dir = '/tmp/replay_dir'
    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))

    template_name = 'gh:audreyr/cookiecutter-pypackage'
    template_slug = 'gh__audreyr_cookiecutter_pypackage'

    dump(replay_dir, template_name, context)
    context2 = load(replay_dir, template_name)


# Generated at 2022-06-21 11:00:26.151142
# Unit test for function load
def test_load():
    from cookiecutter.config import DEFAULT_CONFIG
    config_dict = DEFAULT_CONFIG
    config_dict['replay_dir'] = os.path.join(os.path.expanduser('~'), '.cookiecutters_replay')
    context = load(config_dict['replay_dir'], 'cookiecutter-pypackage')
    assert context is not None


# Generated at 2022-06-21 11:00:29.899752
# Unit test for function dump
def test_dump():

    replay_dir = "testing_dir1"
    template_name = "testing"
    context = {
        'cookiecutter': {
           'project_name': "testing_project"
        }
    }

    dump(replay_dir, template_name, context)



# Generated at 2022-06-21 11:00:34.839195
# Unit test for function get_file_name
def test_get_file_name():
	"""check if function get_file_name works properly"""
	assert get_file_name('../', 'test') == '../test.json'
	assert get_file_name('../', 'test.json') == '../test.json'
	assert get_file_name('../', 'test.json') == '../test.json'
	assert get_file_name('../', 'cookiecutter-pypackage-min') == '../cookiecutter-pypackage-min.json'


# Generated at 2022-06-21 11:00:51.045744
# Unit test for function dump
def test_dump():
    from cookiecutter import replay
    replay_dir = '~/.cookiecutter_replay'
    template_name = 'dummy_package'
    context = {'cookiecutter': {'_template': '{{cookiecutter.package_name}}'}}
    replay.dump(replay_dir, template_name, context)
    assert replay.load(replay_dir, template_name)
    os.remove(os.path.join(replay_dir, 'dummy_package.json'))


# Generated at 2022-06-21 11:00:52.037387
# Unit test for function load
def test_load():
    assert(load(".", "test"))

# Generated at 2022-06-21 11:01:01.327815
# Unit test for function get_file_name
def test_get_file_name():
    root_dir = os.path.join(os.getcwd(), 'cookiecutter')
    user_dir = os.path.join(root_dir, 'tests')
    test_dir = os.path.join(user_dir, 'test_json_file')
    replay_dir = os.path.join(test_dir, 'cookiecutter-replay')
    template_name = 'tests/test_json_file/{{cookiecutter.name}}'
    file_name = template_name + '.json'
    assert file_name == get_file_name(replay_dir, template_name)


# Generated at 2022-06-21 11:01:02.239780
# Unit test for function load
def test_load():
    pass


# Generated at 2022-06-21 11:01:05.127859
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('.', 'foobar') == './foobar.json'
    assert get_file_name('.', 'foobar.json') == './foobar.json'

# Generated at 2022-06-21 11:01:08.600342
# Unit test for function get_file_name
def test_get_file_name():
    assert(get_file_name('test', 'test') == 'test/test.json')
    assert(get_file_name('test', 'test.json') == 'test/test.json')
    assert(get_file_name('test/', 'test') == 'test/test.json')
    assert(get_file_name('test/', 'test.json') == 'test/test.json')

# Generated at 2022-06-21 11:01:14.647109
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/fixtures/test-dump'

    template_name = 'tests/fixtures/fake-repo-pre/'
    context = {'cookiecutter': {'name': 'fake-project', 'version': '0.1'}}

    dump(replay_dir, template_name, context)



# Generated at 2022-06-21 11:01:16.056502
# Unit test for function load
def test_load():
    replay_file = "C:\\Users\\hp\\Desktop\\Cookiecutter\\tests\\test-replay"
    template_name = "test_repo"
    context = load(replay_file,template_name)
    print(context)
    

# Generated at 2022-06-21 11:01:24.365337
# Unit test for function load
def test_load():
    """Test that load() works properly."""
    
    # create a temp directory
    import tempfile
    tempdir = tempfile.mkdtemp()
    
    # create a temp json file
    import tempfile
    import os 
    tempFile = os.path.join(tempdir, "temp.json")
    f = open(tempFile, "w")
    f.write('{"cookiecutter": "wow"}')
    f.close()
    
    # run load on the temp json file
    load(tempdir, "temp.json")
    
    # clean up the temp directory
    import shutil
    shutil.rmtree(tempdir)

# Generated at 2022-06-21 11:01:27.595430
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('abc', 'def.json') == 'abc/def.json'
    assert get_file_name('abc', 'def') == 'abc/def.json'


# Generated at 2022-06-21 11:01:43.905736
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = '/home/'
    template_name = 'template_name'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/home/template_name.json'



# Generated at 2022-06-21 11:01:46.561931
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('aaa', 'bbb') == 'aaa/bbb.json'
    assert get_file_name('aaa', 'bbb.json') == 'aaa/bbb.json'

# Generated at 2022-06-21 11:01:55.006014
# Unit test for function get_file_name
def test_get_file_name():
    """Ensure that get_file_name function is working as expected."""
    replay_dir = 'test_replay'
    template_name = 'cc_test'

    # Check if function returns the correct file with .json extension
    correct_file_name = os.path.join(replay_dir, template_name + '.json')
    assert get_file_name(replay_dir, template_name) == correct_file_name

    # Check if function returns the correct file without the .json extension
    correct_file_name = os.path.join(replay_dir, template_name)
    assert get_file_name(replay_dir, template_name + '.json') == correct_file_name

    # Check if function raises an exception if template_name is not a string
    template_name = 12

# Generated at 2022-06-21 11:02:07.328797
# Unit test for function dump
def test_dump():
    from cookiecutter import replay
    # Use replay directory that we define
    replay_dir = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        '..',
        'tests',
        'test-replay'
    )
    # Load dictionary data as context
    with open("test/test_context.json") as json_file:
        context = json.load(json_file)
    # Define template name
    template_name = "test-replay-filename"
    try:
        # Try to write json data to file
        replay.dump(replay_dir, template_name, context)
    except IOError:
        print("Unable to create replay dir at {}".format(replay_dir))

# Generated at 2022-06-21 11:02:13.869236
# Unit test for function dump
def test_dump():
    """Test for dump"""
    template_name = 'dummy'
    context = {
        'cookiecutter': {
            'full_name': 'Vinicius',
            'email': 'vinicius.b'.format('@', '.'),
            'github_username': 'vbf',
            'replay_dir': '~/.cookiecutters',
            'project_name': 'dummy_project',
            'project_slug': 'dummy_project',
        }
    }
    dump('~/.cookiecutters', template_name, context)


# Generated at 2022-06-21 11:02:19.302086
# Unit test for function load
def test_load():
    replay_dir = 'fixtures/cookiecutter.replay/replay'
    template_name = 'fixtures/cookiecutter.replay/cookiecutter.json'
    context = load(replay_dir, template_name)
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

# Generated at 2022-06-21 11:02:27.673128
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/tmp/replay_dir', 'template_name') == '/tmp/replay_dir/template_name.json'
    assert get_file_name('/tmp/replay_dir', 'template_name.json') == '/tmp/replay_dir/template_name.json'
    assert get_file_name('/tmp/replay_dir/', 'template_name') == '/tmp/replay_dir/template_name.json'
    assert get_file_name('/tmp/replay_dir/', 'template_name.json') == '/tmp/replay_dir/template_name.json'


# Generated at 2022-06-21 11:02:35.033037
# Unit test for function dump
def test_dump():
    template_name = 'parent_template'
    replay_dir = './tests/replay_test'
    home_dir = './tests/replay_test'
    replay_file = './tests/replay_test/parent_template.json'
    override = {'project_name': 'sample_project'}
    echo = 'yes'
    file_name = 'cookiecutter.json'
    json_file_name = './tests/templates/parent_template/cookiecutter.json'
    context = {'cookiecutter': {'template_name': 'parent_template', 'override': {'project_name': 'sample_project'}, 'echo': 'yes', 'file_name': 'cookiecutter.json'}}
    dump(replay_dir, template_name, context)

# Generated at 2022-06-21 11:02:40.232072
# Unit test for function load
def test_load():
    template_name = 'helloworld-master'
    replay_dir = '/workspace/cookiecutter/cookiecutter/tests/test-replay/'
    context = load(replay_dir, template_name)
    assert context is not None
    assert(len(context) == 1)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['project_name'] == 'Hello World'


# Generated at 2022-06-21 11:02:44.218307
# Unit test for function dump
def test_dump():
    dirname = os.path.abspath(os.path.join(os.path.dirname(__file__)))
    filename = 'test_dump'
    context = {'cookiecutter': {'name': 'test'}}
    dump(dirname, filename, context)

