

# Generated at 2022-06-21 10:53:09.943900
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'tests/files/replay')
    template_name = 'pypackage'

# Generated at 2022-06-21 10:53:14.013221
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('test_dir', 'test_template') == 'test_dir/test_template.json'
    assert get_file_name('test_dir', 'test_template.json') == 'test_dir/test_template.json'



# Generated at 2022-06-21 10:53:19.830623
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    template_name = 'test_template'
    replay_dir = os.path.join(os.path.dirname(__file__), 'test_replay')
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, 'test_template.json')


# Generated at 2022-06-21 10:53:23.847415
# Unit test for function dump
def test_dump():
    replay_dir = '../replay'
    template_name = '../test'
    context = {'key': 'value'}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:53:26.436231
# Unit test for function load
def test_load():
    import yaml
    context = load('.', 'tests/test-template/')
    print(yaml.safe_dump(context))

# Generated at 2022-06-21 10:53:28.868080
# Unit test for function load
def test_load():
    if __name__=="__main__":
        replay_dir="cookiecutter.replay.load()"
        template_name="cookiecutter.replay.load()"
        replay_file=get_file_name(replay_dir,template_name)
        print(replay_file)
        with open(replay_file,'r') as infile:
            context=json.load(infile)
        if 'cookiecutter' not in context:
            raise ValueError('Context is required to contain a cookiecutter key')
        return context


# Generated at 2022-06-21 10:53:39.183291
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/tmp/'
    template_name1 = 'template1'
    template_name2 = 'template2.json'
    file_name1 = 'template1.json'
    file_name2 = 'template2.json'

    assert(get_file_name(replay_dir, template_name1) == os.path.join(replay_dir, file_name1))
    assert(get_file_name(replay_dir, template_name2) == os.path.join(replay_dir, file_name2))


# Generated at 2022-06-21 10:53:41.567837
# Unit test for function load
def test_load():
    load(os.path.expanduser("~/Desktop/copypath.json"), "copypath.json")


# Generated at 2022-06-21 10:53:45.367588
# Unit test for function load
def test_load():
    replay_dir = template_name = 'test/test_context'
    context = load(replay_dir, template_name)
    print(context)
    assert isinstance(context, dict)


# Generated at 2022-06-21 10:53:56.870987
# Unit test for function load

# Generated at 2022-06-21 10:54:01.873636
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/username/replay_dir'
    template_name = 'template_name'
    res = get_file_name(replay_dir, template_name)
    exp = '/home/username/replay_dir/template_name.json'
    assert res == exp


# Generated at 2022-06-21 10:54:11.742356
# Unit test for function get_file_name
def test_get_file_name():
    # no suffix
    template_name = 'cookiecutter-python'
    replay_dir = 'tests/test-replay'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'tests/test-replay/cookiecutter-python.json'
    # with suffix
    template_name = 'cookiecutter-python.json'
    replay_dir = 'tests/test-replay'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'tests/test-replay/cookiecutter-python.json'

# Generated at 2022-06-21 10:54:20.070404
# Unit test for function dump
def test_dump():
    """test function dump."""
    import tempfile
    import os

    # test normal case
    replay_dir = tempfile.mkdtemp()
    template_name = 'test'
    context = {
        'cookiecutter': {'project_name': 'xxxx', 'project_slug': 'xxxx'}
    }
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'r') as infile:
        content = json.load(infile)

    assert content == context

    os.remove(replay_file)
    os.removedirs(replay_dir)

    # test raise error if template_name is not instance of str
    replay_dir = tempfile.mkdtemp

# Generated at 2022-06-21 10:54:32.916541
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'path/to/replay'
    template_name_without_json = 'gh:audreyr/cookiecutter-pypackage'
    assert get_file_name(replay_dir, template_name_without_json) == 'path/to/replay/gh:audreyr/cookiecutter-pypackage.json'

    template_name_with_json = 'gh:audreyr/cookiecutter-pypackage.json'
    assert get_file_name(replay_dir, template_name_with_json) == 'path/to/replay/gh:audreyr/cookiecutter-pypackage.json'

    template_name_with_json_and_slash = 'gh:audreyr/cookiecutter-pypackage.json/'
   

# Generated at 2022-06-21 10:54:37.475343
# Unit test for function load
def test_load():
    # Unit test for function load
    context = load('/home/eduardo/.cookiecutters', 'default')
    assert 'cookiecutter' in context
    assert context['cookiecutter']['full_name'] == 'Eduardo Naufel Schettino'

# Generated at 2022-06-21 10:54:41.166526
# Unit test for function load
def test_load():
    rd = "C:\\Users\\wangl\\PycharmProjects\\cookiecutter\\cookiecutter\\replay"
    tn = "replay.json"
    context = load(rd, tn)
    print(context)



# Generated at 2022-06-21 10:54:52.493663
# Unit test for function dump
def test_dump():
    """Test dump function."""
    from cookiecutter.main import cookiecutter

    from .exceptions import UnsupportedDictTypeError

    replay_dir = '/tmp/tests/cookiecutter-replay'
    template_name = 'audreyr/cookiecutter-pypackage'
    context_file = 'tests/test-context.json'
    default_context = {}

    # Make sure this directory doesn't exist before we start
    if os.path.isdir(replay_dir):
        raise IOError('Directory {} already exists'.format(replay_dir))

    # The function dump() can not be tested by running cookiecutter() directly.
    # We have to do some kludging with the sys.argv to make sure cookiecutter()
    # The replay dir contains the cache data.

# Generated at 2022-06-21 10:54:53.522551
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-21 10:54:59.879142
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = '/home/user/cookiecutters-replays'
    template_name = 'pypackage_setup.json'
    test_file_name = get_file_name(replay_dir, template_name)
    assert test_file_name == '/home/user/cookiecutters-replays/pypackage_setup.json'



# Generated at 2022-06-21 10:55:07.436930
# Unit test for function load
def test_load():
    """Test for load function."""
    template_name = 'cookiecutter-pypackage'
    correct_context = {
        'cookiecutter': {
            'replay_dir': '~/.cookiecutters',
            'no_input': False,
            'overwrite_if_exists': False,
            'output_dir': '.',
            'replay': False},
        'full_name': 'firstname lastname',
        'email': 'name@email.com',
        'github_username': 'githubusername',
        'project_name': 'projectname',
        'project_slug': 'projectslug',
        'release_date': '2014-12-26',
        'version': '0.1.0'
    }

# Generated at 2022-06-21 10:55:12.339786
# Unit test for function load
def test_load():
    assert(load("replay", "template_name")['cookiecutter']['project_name']=="#{{cookiecutter.project_name}}#")

if __name__ == '__main__':
        test_load()

# Generated at 2022-06-21 10:55:14.313002
# Unit test for function load
def test_load():
    """Test the load function."""
    assert load('/tmp', 'a') == {'cookiecutter': {}}


# Generated at 2022-06-21 10:55:20.118928
# Unit test for function dump
def test_dump():
    """Test dump function by writing to a json file."""
    import tempfile
    replay_dir = tempfile.mkdtemp()
    template_name = 'github/audreyr/cookiecutter-pypackage'
    context = {'cookiecutter': {
        'project_name': 'Python Boilerplate',
        'project_slug': 'python-boilerplate',
        'author_name': 'Audrey Roy',
        'email': 'audreyr@example.com',
        'description': 'A short description of the project.',
        'version': '0.1.0',
        'open_source_license': 'MIT license',
        'use_pypi_deployment_with_travis': 'y'
    }}

    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:55:25.038798
# Unit test for function load
def test_load():
    """Unit test for load function."""
    template_name = 'test_load'
    replay_dir = os.path.join(os.getcwd(), 'tests/files/replay/')

    # ----------
    # Create a context file
    context = {'cookiecutter': {'name': 'test'}}

    dump(replay_dir, template_name, context)

    # ----------
    # Test loading the context file
    loaded_context = load(replay_dir, template_name)

    assert isinstance(loaded_context, dict)
    assert isinstance(loaded_context['cookiecutter'], dict)

    # ----------
    # Clean up
    replay_file = get_file_name(replay_dir, template_name)
    os.remove(replay_file)


# Generated at 2022-06-21 10:55:32.021651
# Unit test for function dump
def test_dump():
    replay_dir = os.getcwd()
    template_name = 'example'
    context = {
        'cookiecutter': {
            'repository_name': 'test-repository-name'
        }
    }
    try:
        dump(replay_dir, template_name, context)
    except IOError as err:
        print(err)
    except TypeError as err:
        print(err)
    except ValueError as err:
        print(err)



# Generated at 2022-06-21 10:55:38.904193
# Unit test for function dump
def test_dump():
    replay_dir = './tests/test-output/replay'
    template_name = '{{cookiecutter.template_name}}'
    context = {'cookiecutter':
                {
                'template_name': 'test_template'
                }
            }
    
    dump(replay_dir, template_name, context)
    
    assert os.path.isfile('./tests/test-output/replay/{{cookiecutter.template_name}}.json')

# Generated at 2022-06-21 10:55:41.391786
# Unit test for function load
def test_load():
    print(load(replay_dir = '.', template_name = 'create_python_project'))


# Generated at 2022-06-21 10:55:51.952814
# Unit test for function get_file_name
def test_get_file_name():
    
    # first case
    replay_dir = '/home/cookiecutter'
    template_name = 'test.json'
    test_file_name = get_file_name(replay_dir, template_name)
    
    # checking if the test file name is equal to the given file name
    assert test_file_name == '/home/cookiecutter/test.json'

    # second case
    replay_dir = '/home/cookiecutter'
    template_name = 'test'
    test_file_name = get_file_name(replay_dir, template_name)
    
    # checking if the test file name is equal to the given file name
    assert test_file_name == '/home/cookiecutter/test.json'

# Generated at 2022-06-21 10:55:59.602030
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = './tests/files/fake-replay'
    template_name = 'fake-repo'
    context = {'cookiecutter': {'full_name': 'Firstname Lastname',
                                'email': 'name@example.com',
                                'repo_name': 'fake-repo',
                                'project_name': 'Project Name',
                                'project_short_description': 'A short description of the project.',
                                'pypi_username': 'your_username'}}
    dump(replay_dir, template_name, context)
    content_after_write = load(replay_dir, template_name)
    assert content_after_write == context


# Generated at 2022-06-21 10:56:10.037280
# Unit test for function dump
def test_dump():
    os.chdir('/Users/kushal/Desktop')
    replay_dir = 'cookiecutter'
    template_name = 'cookiecutter-pypackage-v0.1.5'
    context = {
        'cookiecutter': {
            'domain_name': 'Kushal',
            'repo_name': 'cookiecutter-pypackage',
            'description': 'A Python package project template',
            'author_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'year': '2014',
            'version': '0.1.4',
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:56:12.430299
# Unit test for function load
def test_load():
    assert load('~', 'myrepo') == load('~', 'myrepo')

# Generated at 2022-06-21 10:56:14.926256
# Unit test for function dump
def test_dump():
    assert dump(replay_dir='/tmp', template_name='/Users/rduvalwa2/GitHub/CookieCutter/python-library', context={})



# Generated at 2022-06-21 10:56:24.334187
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'test_template'
    replay_dir = "../tests/test-replay"
    prev_context = load(replay_dir, template_name)
    assert(prev_context['cookiecutter'] == {'full_name': 'Attila Farkas',
                                            'email': 'farkas.attila@gmail.com',
                                            'project_name': 'test',
                                            'description': 'Test project',
                                            'repo_name': 'test',
                                            'year': '2016'})


# Generated at 2022-06-21 10:56:30.891476
# Unit test for function dump
def test_dump():
    from cookiecutter.config import DEFAULT_REPLAY_DIR
    replay_dir = DEFAULT_REPLAY_DIR
    template_name = 'template'
    context = {'cookiecutter': {'author_name': 'Vu',
                                'project_name': 'test',
                                'project_slug': 'test',
                                'project_short_description': 'test'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:56:42.776282
# Unit test for function load
def test_load():
    # Test for two cases:
    #   - load the correct file
    #   - load the incorrect file

    # Test for correct settings
    replay_dir = ".cookiecutters_replay"
    template_name = "python-package"
    try:
        context = load(replay_dir, template_name)
    except FileNotFoundError:
        os.mkdir(replay_dir)
        context = load(replay_dir, template_name)
    except ValueError:
        template_dir = "cookiecutter-python-package"
        if not os.path.isdir(template_dir):
            os.mkdir(template_dir)
        with open(template_dir + "/cookiecutter.json", 'w') as f:
            f.write('{"cookiecutter": {"cookiecutter": ""}}')

# Generated at 2022-06-21 10:56:46.133471
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    template_name = 'json_name'
    return_value = get_file_name(replay_dir, template_name)
    expect_value = './json_name.json'
    assert (return_value == expect_value)


# Generated at 2022-06-21 10:56:50.322408
# Unit test for function load
def test_load():
    """Test load."""
    replay_dir = os.path.join('tests', 'files', 'replay')
    template_name = 'cheesecake'

    try:
        context = load(replay_dir, template_name)
    except:
        print('unsucess')
    else:
        print('success')
        for key, value in context.items():
            print(key, ' : ', value)


# Generated at 2022-06-21 10:56:55.294925
# Unit test for function dump
def test_dump():
    import os.path
    import shutil
    # Create file name for test
    replay_dir = os.path.abspath(".test_dump")
    template_name = "test_template"
    replay_file = os.path.join(replay_dir, template_name)
    # Open test results file
    with open(replay_file, "w") as json_file:
        # Set up test dictionary
        context = {"cookiecutter": {"test": "pass"}}
        json.dump(context, json_file, indent=2)
    # Run function under test
    dump(replay_dir, template_name, context)
    # Clean up test directory
    shutil.rmtree(replay_dir)


# Generated at 2022-06-21 10:56:59.265421
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('./src', 'template1') == './src/template1.json'
    assert get_file_name('./src', 'template2.json') == './src/template2.json'


# Generated at 2022-06-21 10:57:11.498440
# Unit test for function dump
def test_dump():
    """Test dump."""
    template_name = 'cookiecutter-pypackage'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'cookiecutter-pypackage',
            'repo_name': 'cookiecutter-pypackage',
            'project_short_description': 'A short description of the project.',
            'pypi_username': 'audreyr',
            'select_license': 'MIT license',
            'year': '2013'
        }
    }

    replay_dir = os.path.expanduser('~/.cookiecutter_replay')

# Generated at 2022-06-21 10:57:20.369478
# Unit test for function load
def test_load():
    """"Testcase"""
    replay_dir = os.getcwd()
    #template_name = 'cookiecutter-pypackage'
    template_name = 'cookiecutter-pypackage'
    ret_val = load(replay_dir, template_name)
    print("ret_val ", ret_val)
    #assert ret_val == 'cookiecutter-pypackage'



# Generated at 2022-06-21 10:57:27.689156
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name function
    """
    # Check that the function raise an error if no template_name given
    try:
        get_file_name('tmp', '')
        assert False
    except TypeError:
        assert True

    # Check that the function raise an error if no replay_dir given
    try:
        get_file_name('', 'example')
        assert False
    except TypeError:
        assert True

    # Check that the function return the correct path
    assert get_file_name('tmp', 'example') == 'tmp/example.json'

    # Check that the function return example.json, even if the user give
    # example.json as template_name
    assert get_file_name('tmp', 'example.json') == 'tmp/example.json'



# Generated at 2022-06-21 10:57:29.907035
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('test_cookiecutter', 'template.json') == 'test_cookiecutter/template.json'



# Generated at 2022-06-21 10:57:33.400360
# Unit test for function load
def test_load():
    template_name = 'ckcc-python/{{cookiecutter.repo_name}}'
    ckcc_json = load("./replay", template_name)
    print (ckcc_json)


# Generated at 2022-06-21 10:57:36.509169
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replay_dir'
    template_name = 'test_template'
    assert get_file_name(replay_dir, template_name) == 'replay_dir/test_template.json'



# Generated at 2022-06-21 10:57:47.701295
# Unit test for function load
def test_load():
    import json, os
    from cookiecutter.utils import make_sure_path_exists
    replay_dir = os.getcwd() + '/test-replay'
    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))
    template_name = 'new-project'
    context = {'cookiecutter': 'hahaha'}
    suffix = '.json' if not template_name.endswith('.json') else ''
    file_name = '{}{}'.format(template_name, suffix)
    re_file = os.path.join(replay_dir, file_name)

# Generated at 2022-06-21 10:57:50.610283
# Unit test for function load
def test_load():
    replay_dir = "./"
    template_name = "context.json"
    context = load(replay_dir, template_name)
    print(context)



# Generated at 2022-06-21 10:57:54.050096
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('test_dir', 'test_template') == 'test_dir/test_template.json'
    assert get_file_name('test_dir', 'test_template.json') == 'test_dir/test_template.json'

# Generated at 2022-06-21 10:57:59.320566
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/xyz'
    template_name = 'Replay_template'
    expected = '/home/xyz/Replay_template.json'
    actual = get_file_name(replay_dir,template_name)
    assert expected == actual

test_get_file_name()

# Generated at 2022-06-21 10:58:03.495237
# Unit test for function dump
def test_dump():
    replay_dir = "tests/test-output"
    # test if it raise the error when replay directory does not exist
    try:
        dump(replay_dir, "test", {})
        # if replay_dir does not exist, IOError is raised
        assert False
    except IOError as e:
        assert "Unable to create replay dir" in str(e)
        assert "tests/test-output" in str(e)

    # test if it raise the error when template_name is not string
    try:
        dump("", 1, {})
        # if template_name is not str, TypeError is raised
        assert False
    except TypeError as e:
        assert "is required to be of type str" in str(e)
        assert "str" in str(e)

    # test if it raise the error when context is

# Generated at 2022-06-21 10:58:15.007538
# Unit test for function get_file_name
def test_get_file_name():
    
    # Test when template_name ends with '.json
    assert '/var/tmp/replay/test.json' == get_file_name('/var/tmp/replay', 'test.json')

    # Test when template_name does not end with '.json
    assert '/var/tmp/replay/test.json' == get_file_name('/var/tmp/replay', 'test')
    
    

# Generated at 2022-06-21 10:58:18.541381
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = './'
    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))

    # test for name without .json suffix
    template_name = 'test'
    file = get_file_name(replay_dir, template_name)
    assert file == './test.json'

    # test for name with .json suffix
    template_name = 'test.json'
    file = get_file_name(replay_dir, template_name)
    assert file == './test.json'



# Generated at 2022-06-21 10:58:24.284350
# Unit test for function get_file_name
def test_get_file_name():
    print('Running Test')

    file_name = get_file_name('', 'filename')
    assert file_name == 'filename.json', 'file_name is not being set properly for file names that dont end in .json'

    file_name = get_file_name('', 'filename.json')
    assert file_name == 'filename.json', 'file name is not being set properly for file names that end in .json'

    print('Test Passed')


# Generated at 2022-06-21 10:58:31.344465
# Unit test for function dump
def test_dump():
    template = {'cookiecutter': {'name': 'test', 'version': '0.1.0'}}
    out_file = '/tmp/test_dump.json'
    dump('/tmp/', 'test_dump', template)
    with open(out_file, 'r') as out:
        content = out.read()
        assert content == '{\n  "cookiecutter": {\n    "name": "test", \n    "version": "0.1.0"\n  }\n}'


# Generated at 2022-06-21 10:58:35.607775
# Unit test for function dump
def test_dump():
    replay_dir = './replay_dir'
    template_name = './cookiecutter-django/'
    context = {
        'cookiecutter': {
            'project_name': 'test project',
            'repo_name': 'test_repo',
        }
    }

# Generated at 2022-06-21 10:58:44.061707
# Unit test for function load

# Generated at 2022-06-21 10:58:56.113663
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test get_file_name()."""
    replay_dir = '/tmp/'
    template_name = 'template-name'
    file_name = 'template-name.json'
    assert get_file_name(replay_dir, template_name) == '/tmp/template-name.json'

    replay_dir = '/tmp/replay'
    template_name = 'template-name'
    file_name = 'template-name.json'
    assert get_file_name(replay_dir, template_name) == '/tmp/replay/template-name.json'

    replay_dir = '/tmp/replay/'
    template_name = 'template-name'
    file_name = 'template-name.json'

# Generated at 2022-06-21 10:59:03.665946
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/replay-dir'
    template_name = 'my-project'
    replay_file = get_file_name(replay_dir, template_name)
    assert replay_file == '/replay-dir/my-project.json'

    replay_dir = '/replay-dir'
    template_name = 'my-project.json'
    replay_file = get_file_name(replay_dir, template_name)
    assert replay_file == '/replay-dir/my-project.json'

# Generated at 2022-06-21 10:59:11.347590
# Unit test for function dump
def test_dump():
    import shutil

    replay_dir = 'test/test_replay'

    if(make_sure_path_exists(replay_dir)):
        shutil.rmtree(replay_dir)

    template_name = 'test/test_template'

    context = {'cookiecutter': {'full_name': 'Zaiyang Li', 'email': 'me@zaiyangli.com', 'project_name': 'testproject'}}

    dump(replay_dir, template_name, context)

    # test dumped file

# Generated at 2022-06-21 10:59:20.475705
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = os.path.join(os.path.dirname('__file__'), 'tests', 'fake-replay-dir')
    template_name = 'template1'
    context = {
        'cookiecutter': {
            'name': 'Test'
        }
    }
    dump(replay_dir=replay_dir, template_name=template_name, context=context)
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.exists(replay_file)


# Generated at 2022-06-21 10:59:34.380348
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/Users/shyuepian/Desktop/test'
    template_name = 'shyue'
    filename = get_file_name(replay_dir,template_name)
    print(filename)

# Generated at 2022-06-21 10:59:38.728216
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("some_dir", "template_name") == "some_dir/template_name.json"
    assert get_file_name("some_other_dir", "template_name.json") == "some_other_dir/template_name.json"

# Unit tests for function dump

# Generated at 2022-06-21 10:59:41.332633
# Unit test for function load
def test_load():
    assert load('', '') == "template_name is required to be of type str"
    assert load('', ' ') == "Context is required to contain a cookiecutter key"



# Generated at 2022-06-21 10:59:47.905356
# Unit test for function dump
def test_dump():
    """This function is intended for testing purpose of function dump."""
    replay_dir = './tests/test-replay'
    template_name = './tests/fake-repo-pre'
    context = {'cookiecutter': {'full_name': 'Joe Smith', 'email': 'joe@example.com', 'project_name': 'Example Project', 'release_date': '2014-12-29'}}
    dump(replay_dir, template_name, context)
    context2 = load(replay_dir, template_name)
    assert context == context2


# Generated at 2022-06-21 10:59:50.904457
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'my-repo'

    replay_dir = 'replay'
    expected_path = 'replay/my-repo.json'

    assert (get_file_name(replay_dir, template_name) == expected_path)



# Generated at 2022-06-21 10:59:53.409142
# Unit test for function get_file_name
def test_get_file_name():
    path = os.path.join(os.getcwd(), 'replay')
    name = 'test_template'
    assert get_file_name(path, name) == os.path.join(path, name + '.json')


# Generated at 2022-06-21 10:59:57.061966
# Unit test for function dump
def test_dump():
    replay_dir, template_name, context = 'replay', 'test_key', {'test_key': 1}
    dump(replay_dir, template_name, context)
    file_name = get_file_name(replay_dir, template_name)
    with open(file_name, 'r') as infile:
        data = json.load(infile)

# Generated at 2022-06-21 11:00:02.492173
# Unit test for function load
def test_load():
    file_name = get_file_name('replay', 'template')
    with open(file_name, 'w') as outfile:
        json.dump({'cookiecutter':{'name':'template'}}, outfile, indent=2)
    context = load('replay', 'template')
    assert 'cookiecutter' in context
    assert context['cookiecutter'] == {'name':'template'}



# Generated at 2022-06-21 11:00:10.121369
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    from tempfile import TemporaryDirectory

    template_name = 'https://github.com/audreyr/cookiecutter-pypackage'

    with TemporaryDirectory() as replay_dir:
        context = {'cookiecutter': {
            'full_name': 'Dummy Name',
            'email': 'dummy@mail.com',
            'github_username': 'dummy',
            'project_name': 'dummy-project',
            'repo_name': 'dummy-project',
            'project_slug': 'dummy_project',
            'pypi_username': 'dummy-pypi'
        }}
        dump(replay_dir, template_name, context)

        recovered = load(replay_dir, template_name)
        assert context == recovered



# Generated at 2022-06-21 11:00:11.711825
# Unit test for function load
def test_load():
    context = load('.cookiecutters', 'python-library')
    assert 'cookiecutter' in context

# Generated at 2022-06-21 11:00:42.470051
# Unit test for function dump
def test_dump():
    # setup
    replay_dir = os.path.join(os.path.dirname(__file__), 'testreplay')
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-21 11:00:44.590416
# Unit test for function load
def test_load():
    """Unit test for function load."""
    try:
        load('replay', 'template')
    except ValueError as e:
        assert str(e) == 'Context is required to contain a cookiecutter key'

# Generated at 2022-06-21 11:00:48.050597
# Unit test for function get_file_name
def test_get_file_name():
    '''Unit test for function get_file_name().'''
    assert get_file_name('.', 'template_name') == './template_name.json'
    assert get_file_name('.', 'template_name.json') == './template_name.json'


# Generated at 2022-06-21 11:00:50.517117
# Unit test for function get_file_name
def test_get_file_name():
    template_name = "repo"
    replay_dir = "."
    assert get_file_name(replay_dir, template_name) == "./repo.json"


# Generated at 2022-06-21 11:00:53.110420
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('~/', 'puppet-roles-and-profiles') == os.path.join('~/','puppet-roles-and-profiles.json')



# Generated at 2022-06-21 11:00:59.688654
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("./test_replay_folder", "test_template_folder") == './test_replay_folder/test_template_folder.json'
    assert get_file_name("./test_replay_folder", "test_template_folder.json") == './test_replay_folder/test_template_folder.json'
    

# Generated at 2022-06-21 11:01:06.359367
# Unit test for function dump
def test_dump():
    """Test for dump method."""
    from cookiecutter.main import cookiecutter
    from tempfile import NamedTemporaryFile, mkdtemp
    replay_dir = mkdtemp()
    template_name = '{{cookiecutter.project_name}}'
    context = cookiecutter('.', replay_dir=replay_dir)
    dump(replay_dir, template_name, context)

    file_name = get_file_name(template_name)
    assert os.path.isfile(file_name)
    os.remove(file_name)



# Generated at 2022-06-21 11:01:17.275563
# Unit test for function load
def test_load():
    """Test the load function."""
    replay_dir = '/tmp/tests/cookiecutters'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)

# Generated at 2022-06-21 11:01:18.265265
# Unit test for function load
def test_load():
    assert load('path', 'template')


# Generated at 2022-06-21 11:01:25.517600
# Unit test for function get_file_name
def test_get_file_name():
    path = get_file_name(replay_dir = "./cookiecutter-replay", template_name = "cookiecutter-pytest-plugin")
    assert path == "./cookiecutter-replay/cookiecutter-pytest-plugin.json"

    path = get_file_name(replay_dir = "./cookiecutter-replay", template_name = "cookiecutter-pytest-plugin.json")
    assert path == "./cookiecutter-replay/cookiecutter-pytest-plugin.json"

test_get_file_name()

# Generated at 2022-06-21 11:02:24.976552
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/"
    template_name = "template01.json"
    res = get_file_name(replay_dir,template_name)
    assert(res == "/template01.json")


# Generated at 2022-06-21 11:02:30.016550
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    assert get_file_name('dir', 'template') == 'dir/template.json'
    assert get_file_name('dir', 'template.json') == 'dir/template.json'
    assert get_file_name('dir/', 'template') == 'dir/template.json'
    assert get_file_name('dir/', 'template.json') == 'dir/template.json'

# Generated at 2022-06-21 11:02:39.096286
# Unit test for function dump
def test_dump():
    """Unit test for function dump"""
    replay_dir = 'tests/test-output/replay/'
    template_name = 'temp'
    context = {'key1': 'value1', 'key2': 'value2'}
    try:
        dump(replay_dir, template_name, context)
    except:
        raise AssertionError()

    with open(get_file_name(replay_dir, template_name), 'r') as infile:
        assert infile.read() == '{\n  "key1": "value1", \n  "key2": "value2"\n}'


# Generated at 2022-06-21 11:02:45.810613
# Unit test for function dump
def test_dump():
    """Unit test for dump function."""
    import os
    import shutil
    from cookiecutter.replay import dump

    # Setup template name
    template_name = 'my-cookiecutter'

    # Setup Context
    context = {
        'cookiecutter': {
            'test': 'test',
        }
    }

    # Setup temporary directory
    temp_dir = 'test_dump'
    replay_dir = os.path.join(temp_dir, 'replay')

    # Call function
    dump(replay_dir, template_name, context)

    # Check replay file exists
    replay_file = os.path.join(replay_dir, '{}.json'.format(template_name))
    assert os.path.exists(replay_file)

    # Remove temporary directory
    shutil.r

# Generated at 2022-06-21 11:02:50.929571
# Unit test for function load
def test_load():
    replay_dir = 'C:/Users/Keshav/Documents/GitHub/keshavkummari/cookiecutter-pypackage-minimal/cookiecutter'
    template_name = 'cookiecutter'
    context = load(replay_dir, template_name)
    print(context)

# Generated at 2022-06-21 11:02:55.057915
# Unit test for function load
def test_load():
    import pdb; pdb.set_trace()
    replay_dir = 'replay'
    template_name = 'cookie_project'
    context = load(replay_dir,template_name)
    assert isinstance(context, dict)
    assert context['cookiecutter']
