

# Generated at 2022-06-21 10:52:56.252544
# Unit test for function load
def test_load():
    '''
    Unit test for function load
    '''
    try:
        load(".","abc")
    except ValueError as e:
        print("ERROR: ",e)



# Generated at 2022-06-21 10:52:57.536098
# Unit test for function load
def test_load():
    print(load('replay_dir', 'example.json'))


# Generated at 2022-06-21 10:53:09.842999
# Unit test for function dump
def test_dump():
    import tempfile
    from cookiecutter.replay import dump
    from cookiecutter import utils
    from cookiecutter import exceptions

    template_name = 'test_template'
    replay_dir = tempfile.mkdtemp()
    context = {'cookiecutter': {'name': 'test',
                                'version': '0.0.1'}}

    def test_1():
        if not os.path.exists(replay_dir):
            os.makedirs(replay_dir)

        dump(replay_dir, template_name, context)
        file_name = get_file_name(replay_dir, template_name)
        assert os.path.exists(file_name)

        content = utils.read_file(file_name)
        assert content == str(context)

       

# Generated at 2022-06-21 10:53:12.009081
# Unit test for function load
def test_load():
    assert isinstance(load('/', 'test'), dict)
    assert isinstance(load('/', 'test.json'), dict)



# Generated at 2022-06-21 10:53:16.416245
# Unit test for function load
def test_load():
    template_name = 'jeff/test'
    replay_dir = 'cookiecutter/replay'
    context = {'test': 'test'}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name)['test'] == context['test']

# Generated at 2022-06-21 10:53:19.956998
# Unit test for function load
def test_load():
    replay_dir = 'cookiecutter/replay'
    template_name = 'master_document'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context

# Generated at 2022-06-21 10:53:21.605868
# Unit test for function get_file_name
def test_get_file_name():
    test_file_name = get_file_name("test", "test")
    assert test_file_name == "test/test.json"

# Generated at 2022-06-21 10:53:25.352767
# Unit test for function load
def test_load():
    replay_dir = '{{cookiecutter.project_slug}}/'
    template_name = '{{cookiecutter.project_slug}}'
    load(replay_dir, template_name)


# Generated at 2022-06-21 10:53:29.914874
# Unit test for function load
def test_load():
    template_name = 'example-repo-name'
    replay_file = get_file_name(replay_dir, template_name)
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['repo_name'] == 'example-repo-name'

# Generated at 2022-06-21 10:53:36.117118
# Unit test for function get_file_name
def test_get_file_name():
    """get_file_name unit test."""
    assert get_file_name('/home/test', 'test') == '/home/test/test.json'

    assert get_file_name('/home/test', 'test.json') == '/home/test/test.json'


# Generated at 2022-06-21 10:53:42.838934
# Unit test for function get_file_name
def test_get_file_name():
    """Test for function get_file_name."""
    template_name = 'mock_template'
    file_name = get_file_name('', template_name)
    assert file_name == template_name + '.json'
    template_name = template_name + '.json'
    file_name = get_file_name('', template_name)
    assert file_name == template_name

# Generated at 2022-06-21 10:53:51.580458
# Unit test for function load
def test_load():
    """Test function load"""
    import os
    import tempfile
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    print(tmpdir)
    # Create the replay directory
    dirpath = os.path.join(tmpdir, "replay")
    print(dirpath)
    # Create the replay filepath
    filepath = os.path.join(dirpath, "test_load.json")
    print(filepath)
    # Create the replay file, because it does not exist. Argument 'w' is for write.
    # Write the replay file with json data

# Generated at 2022-06-21 10:53:54.788771
# Unit test for function load
def test_load():
    replay_dir = '/Users/fangli/Code/CookiecutterApp/tests/test-load'
    template_name = 'jinja2-cookiecutter'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['_template'] == template_name

# Generated at 2022-06-21 10:54:00.932595
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = './tests/test-replay/'
    default_file_name = 'cookiecutter.json'
    json_template = './tests/test-replay/cookiecutter.json'
    nonjson_template = './tests/test-replay/cookiecutter.nj'

    # test for default file name
    file_name = get_file_name(replay_dir, default_file_name)
    assert file_name == './tests/test-replay/cookiecutter.json'

    # test for file name with extension
    file_name = get_file_name(replay_dir, json_template)
    assert file_name == './tests/test-replay/cookiecutter.json'

    # test for file name without extension
    file_name = get_file_name

# Generated at 2022-06-21 10:54:05.095774
# Unit test for function load
def test_load():
    # Test 1
    try:
        load(None, None)
        assert False
    except (TypeError):
        assert True

    # Test 2
    try:
        load('test', None)
        assert False
    except (TypeError):
        assert True

    # Test 3
    try:
        load('test', 'test')
        assert False
    except (FileNotFoundError):
        assert True


# Generated at 2022-06-21 10:54:15.609079
# Unit test for function load
def test_load():
    template_name = 'my_template'
    my_context = {'cookiecutter': {'replay': True}}
    replay_dir = '.'
    if make_sure_path_exists(replay_dir):
        dump(replay_dir, template_name, my_context)
    else:
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))
    try:
        context = load(replay_dir, template_name)
        assert context == my_context
    except ValueError:
        try:
            context = load(replay_dir, template_name)
            assert context == my_context
        except:
            print("Error: No 'cookiecutter' in context")
    finally:
        os.remove(replay_file)

# Generated at 2022-06-21 10:54:17.035887
# Unit test for function dump
def test_dump():
    assert dump(replay_dir='./some/folder', template_name='some_string', context= {'some_key': 'some_value'}) == None


# Generated at 2022-06-21 10:54:20.974605
# Unit test for function get_file_name
def test_get_file_name():
    '''
    Test whether the function works as expected.
    :return:
    '''
    replay_dir = './tests/tests_files/replay/'
    template_name = 'the_name_of_the_cookiecutter_project'

    output = './tests/tests_files/replay/the_name_of_the_cookiecutter_project.json'
    assert get_file_name(replay_dir, template_name) == output



# Generated at 2022-06-21 10:54:32.400172
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    # test for default value
    replay_dir = './replay'
    template_name = 'tmp'
    file_name = 'tmp.json'

    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, file_name)
    # test for json file
    replay_dir = './replay'
    template_name = 'tmp.json'
    file_name = 'tmp.json'

    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, file_name)

# unit test for dump

# Generated at 2022-06-21 10:54:40.414265
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join(os.getcwd(), 'tests', 'test-replay')
    assert(get_file_name(replay_dir, 'test-replay') == replay_dir + os.path.sep + 'test-replay.json')
    assert(get_file_name(replay_dir, 'test-replay.json') == replay_dir + os.path.sep + 'test-replay.json')

if __name__ == '__main__':
    test_get_file_name()

# Generated at 2022-06-21 10:54:53.217003
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import shutil
    from cookiecutter import utils

    context = {'cookiecutter': {'project_name': 'Foo bar'}}

    template_name = 'test_dump'
    replay_dir = 'tests/files/test-replay'

    # Make sure the replay path exists
    utils.make_sure_path_exists(replay_dir)

    dump(replay_dir, template_name, context)

    # Remove the replay path and then recreate the replay path
    shutil.rmtree(replay_dir)
    utils.make_sure_path_exists(replay_dir)

    # Ensure that the replay file successfully loads
    assert load(replay_dir, template_name) == context

# Generated at 2022-06-21 10:54:57.580400
# Unit test for function load
def test_load():
   print(load('/home/yxiao2018/Documents/Yuxin/cookiecutter-laravel/tests/fixtures/test-replay/', 'cookiecutter-pypackage'))

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-21 10:55:01.764021
# Unit test for function load
def test_load():
    template_name = '{{cookiecutter.repo_name}}'
    replay_dir = '{{cookiecutter.replay_dir}}'
    context = load(replay_dir, template_name)
    assert type(context) is dict
    assert 'cookiecutter' in context



# Generated at 2022-06-21 10:55:13.435579
# Unit test for function dump
def test_dump():
    replay_dir = "test/test_dump"
    template_name = "cookiecutter-pypackage-tests"
    context = {
        "full_name": "Audrey Roy Greenfeld",
        "email": "audreyr@example.com",
        "github_username": "audreyr",
        "project_name": "Python Boilerplate",
        "project_slug": "python-boilerplate-tests",
        "release_date": "2014-10-14",
        "year": "2014",
        "pypi_username": "audreyr",
        "_template": "https://github.com/audreyr/cookiecutter-pypackage/zipball/master"
    }
    dump(replay_dir, template_name, context)

# Generated at 2022-06-21 10:55:19.168855
# Unit test for function load
def test_load():
    assert load('./tests/test-replay', "test_load") == {
        'cookiecutter': {
            'package_name': 'test-load',
            'project_name': 'test_load',
            'author_name': 'Me',
            'email': 'me@example.com',
            'release_date': '2015-05-14',
            'version': '0.1.0',
            'add_debug_statements': 'n'
        }
    }


# Generated at 2022-06-21 10:55:21.374432
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('foo', 'bar') == 'foo/bar.json'
    assert get_file_name('foo', 'bar.json') == 'foo/bar.json'



# Generated at 2022-06-21 10:55:27.015360
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "tmp"
    template_name_1 = "test_template_1"
    template_name_2 = "test_template_2.json"
    assert get_file_name(replay_dir, template_name_1) == "tmp/test_template_1.json"
    assert get_file_name(replay_dir, template_name_2) == "tmp/test_template_2.json"
    # Fail input with empty template_name
    try:
        get_file_name(replay_dir, "")
    except Exception:
        pass
    # Fail input with None template_name
    try:
        get_file_name(replay_dir, None)
    except Exception:
        pass



# Generated at 2022-06-21 10:55:27.938323
# Unit test for function get_file_name
def test_get_file_name():
    assert('template.json' == get_file_name('replay_dir', 'template.json'))

# Generated at 2022-06-21 10:55:32.962053
# Unit test for function dump
def test_dump():
    """dump test."""
    test = {'cookiecutter': {'foo': 'bar'}}
    dump_url = os.path.join(os.path.dirname(__file__), 'files', 'replay')
    dump(dump_url, "test_dump", test)
    assert load(dump_url, "test_dump") == test
    os.remove(os.path.join(dump_url, "test_dump.json"))



# Generated at 2022-06-21 10:55:43.870419
# Unit test for function dump
def test_dump():
    from cookiecutter import USER_CONFIG_PATH, CONFIG_FILE
    TEMPLATE_NAME = '{{cookiecutter.project_slug}}'
    replay_dir = os.path.join(USER_CONFIG_PATH, CONFIG_FILE)
    user_config_path = os.path.join(USER_CONFIG_PATH, CONFIG_FILE)
    context = {'cookiecutter': {'project_name': 'test_project_name', 'project_slug': 'test_project_slug',
                                'replay_dir':replay_dir, 'config_file':CONFIG_FILE,
                                'user_config_path':user_config_path}}
    dump(replay_dir=replay_dir, template_name=TEMPLATE_NAME, context=context)

# Generated at 2022-06-21 10:55:52.287078
# Unit test for function get_file_name
def test_get_file_name():
    # Given
    replay_dir = '/test/replay_dir'
    template_name = 'test_template_name'
    expected_result = '/test/replay_dir/test_template_name.json'
    # When
    result = get_file_name(replay_dir, template_name)
    # Then
    assert expected_result == result



# Generated at 2022-06-21 10:55:55.447458
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replay'
    template_name = 'myTemplate'
    assert get_file_name(replay_dir, template_name) == 'replay/myTemplate.json'

# Generated at 2022-06-21 10:55:57.258843
# Unit test for function load
def test_load():
    assert load('/home/karthic/cookiecutter/tests/test-replay', 'pypackage_jinja.json') is not None

# Generated at 2022-06-21 10:55:59.780952
# Unit test for function load
def test_load():
    assert load(os.getcwd(),'testfile') == {'cookiecutter': { 'name': 'cookiecutter'}}

# Generated at 2022-06-21 10:56:05.509900
# Unit test for function get_file_name
def test_get_file_name():
    """test function get_file_name."""
    name = get_file_name('/tmp', 'test.json')
    assert name == '/tmp/test.json'
    name = get_file_name('/tmp', 'test')
    assert name == '/tmp/test.json'

# Generated at 2022-06-21 10:56:13.539601
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = os.path.join(os.path.dirname(__file__), 'repo', 'bakes', 'cookie')
    # test sorting doesn't break dumps
    template_name = 'interactive'

# Generated at 2022-06-21 10:56:18.726496
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = "/tmp"
    template_name = "bar"
    expected_answer = "/tmp/bar.json"
    assert(get_file_name(replay_dir, template_name) == expected_answer)


# Generated at 2022-06-21 10:56:22.035753
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name"""
    print(get_file_name("./test/", "test"))
    print(get_file_name("./test/", "test.json"))
    

# Generated at 2022-06-21 10:56:24.283542
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/home/user/test', 'template') == '/home/user/test/template.json'

# Generated at 2022-06-21 10:56:27.391929
# Unit test for function load
def test_load():
    context = load(replay_dir=".", template_name="test_load")
    print(context)
    assert isinstance(context, dict)



# Generated at 2022-06-21 10:56:37.930541
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "tests/files/fake-replay-dir"
    template_name1 = "test.json"
    template_name2 = "test"
    assert get_file_name(replay_dir, template_name1) == "tests/files/fake-replay-dir/test.json"
    assert get_file_name(replay_dir, template_name2) == "tests/files/fake-replay-dir/test.json"

# Generated at 2022-06-21 10:56:41.522314
# Unit test for function load
def test_load():
    template_name = 'test'
    replay_file = get_file_name('.', template_name)
    context = load('.', template_name)
    assert 'cookiecutter' in context, 'Context is not loaded correctly'


# Generated at 2022-06-21 10:56:47.008094
# Unit test for function dump
def test_dump():
    replay_dir = '.'
    template_name = "test"
    context = {"cookiecutter": {}}
    assert not os.path.exists(get_file_name(replay_dir, template_name))
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-21 10:56:51.348431
# Unit test for function load
def test_load():
    context = load(os.path.expanduser('~/.cookiecutters'), 'pypackage')
    if not isinstance(context, dict):
        raise TypeError('Context is required to be of type dict')

    if '{{cookiecutter.project_name}}' not in context['cookiecutter']:
        raise ValueError('Context is required to contain a cookiecutter key')

# Generated at 2022-06-21 10:56:59.356672
# Unit test for function get_file_name
def test_get_file_name():
    """
    Check if the function get_file_name returns the expected
    """
    replay_dir = os.path.expanduser('~/.cookiecutters')
    template_name = 'cookiecutter-pypackage'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '~/.cookiecutters/cookiecutter-pypackage.json', 'Expected result is ~/.cookiecutters/cookiecutter-pypackage.json'


# Generated at 2022-06-21 10:57:07.384946
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = ''
    template_name = 'python_module'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'python_module.json'
    file_name = get_file_name(replay_dir, 'python_module.json')
    assert file_name == 'python_module.json'

if __name__ == '__main__':
    test_get_file_name()

# Generated at 2022-06-21 10:57:14.165724
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = '/home/yuanjie'
    template_name = 'demo'
    assert get_file_name(replay_dir, template_name) == '/home/yuanjie/demo.json'
    template_name = 'demo.json'
    assert get_file_name(replay_dir, template_name) == '/home/yuanjie/demo.json'

# Generated at 2022-06-21 10:57:23.233022
# Unit test for function dump
def test_dump():
    """Test dumping replay data to file."""
    try:
        os.mkdir('tests/files/to-dump')
    except OSError as e:
        if e.errno != 17:
            raise Exception

    replay_dir = 'tests/files/to-dump'
    template_name = 'example-repo'
    context = {'cookiecutter': 'example-repo/{{cookiecutter.project_name}}'}

    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)

    assert os.path.isfile(replay_file)



# Generated at 2022-06-21 10:57:27.325701
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'tests/files/fake-repo-pre'
    context = {'cookiecutter': {'full_name': 'Test'}}
    dump(replay_dir,template_name,context)


# Generated at 2022-06-21 10:57:29.143867
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/test/replay', 'template') == '/test/replay/template.json'



# Generated at 2022-06-21 10:57:45.966981
# Unit test for function dump
def test_dump():
    """Test function dump."""
    replay_dir = 'C:/Users/shaox/Desktop/cookie'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-21 10:57:50.746969
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('./tmp', 'cookiecutter-pypackage') == './tmp/cookiecutter-pypackage.json'
    assert get_file_name('./tmp', 'cookiecutter-pypackage.json') == './tmp/cookiecutter-pypackage.json'


# Generated at 2022-06-21 10:57:57.486908
# Unit test for function dump
def test_dump():
    replay_file = "tests/test-replay/test-templatedump.json"
    contextdata = {
            "cookiecutter": {
                "repo_dir": "testrepo",
                "full_name": "test full name",
                "email": "test@test.com",
                "project_name": "test project",
                "release_date": "2016/01/01"
                }
            }
    dump("tests/test-replay/", "test-templatedump", contextdata)
    contextload = load("tests/test-replay/", "test-templatedump")
    return os.path.exists(replay_file) and contextload==contextdata


# Generated at 2022-06-21 10:58:03.648987
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = './'
    template_name = 'cookiecutter.json'
    result = get_file_name(replay_dir, template_name)
    assert result == './cookiecutter.json'
    template_name = 'cookiecutter.json.json'
    result = get_file_name(replay_dir, template_name)
    assert result == './cookiecutter.json.json'


# Generated at 2022-06-21 10:58:05.867073
# Unit test for function load
def test_load():
	load("C:\\Users\\jerry\\Desktop\\cookiecutter-adexchange-data-api", "placeholder")


# Generated at 2022-06-21 10:58:11.430559
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    template_name = "project_name"
    replay_dir = "replay_dir.json"

    result_file_name = get_file_name(replay_dir, template_name)
    assert result_file_name == "replay_dir.json"+"/"+"project_name.json"

    template_name = "project_name.json"
    replay_dir = "replay_dir.json"

    result_file_name = get_file_name(replay_dir, template_name)
    assert result_file_name == "replay_dir.json" + "/" + "project_name.json"

test_get_file_name()

# Generated at 2022-06-21 10:58:15.681041
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for get_file_name."""
    replay_dir = './buzz/'
    template_name = 'xyz.json'
    path = get_file_name(replay_dir, template_name)
    assert path == './buzz/xyz.json'


# Generated at 2022-06-21 10:58:20.320166
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '~/my_directory'
    template_name = 'my_template'

    file_name = get_file_name(replay_dir, template_name)

    expected_file_name = '~/my_directory/my_template.json'

    assert(file_name == expected_file_name)

# Generated at 2022-06-21 10:58:24.539463
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/replay'
    template_name = 'tests/{{cookiecutter.name}}'
    context = {'cookiecutter': {'name': 'test'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists('tests/replay/tests.json')


# Generated at 2022-06-21 10:58:31.215125
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = r'C:\Users\jy\Desktop\MyTest'
    assert get_file_name(replay_dir, "default") == r'C:\Users\jy\Desktop\MyTest\default.json'
    assert get_file_name(replay_dir, "default.json") == r'C:\Users\jy\Desktop\MyTest\default.json'
    assert get_file_name(replay_dir, "default.j") == r'C:\Users\jy\Desktop\MyTest\default.j.json'
    assert get_file_name(replay_dir, "default.j1.2") == r'C:\Users\jy\Desktop\MyTest\default.j1.2.json'

# Generated at 2022-06-21 10:58:49.839548
# Unit test for function load
def test_load():
    template_name = 'template_name'
    replay_dir = '.'
    replay_file = get_file_name(replay_dir, template_name)
    t = {'a': 1, 'b': '2', 'c': [1,2,3], 'd': {'e': 'f', 'g': 2}}
    with open(replay_file, 'w') as outfile:
        json.dump(t, outfile, indent=2)
    context = load(replay_dir, template_name)
    print(context)
    assert context == t


# Generated at 2022-06-21 10:59:02.499042
# Unit test for function load
def test_load():
    import unittest
    import shutil

    class TestReplayJsonData(unittest.TestCase):

        def setUp(self):
            self.dir = os.path.join(os.path.dirname(__file__), 'test-replay')
            self.file_path = os.path.join(self.dir, 'test-replay.json')
            os.makedirs(self.dir)

        def tearDown(self):
            shutil.rmtree(self.dir)

        def test_valid_context_without_cookiecutter_key(self):
            with open(self.file_path, 'w') as infile:
                infile.write('{"full_name": "Nathaniel J. Smith"}')

# Generated at 2022-06-21 10:59:07.406960
# Unit test for function get_file_name
def test_get_file_name():
    result = get_file_name('.cj-replay', 'my-template')
    #TODO: os.path.sep?
    assert result == ".cj-replay/my-template.json"

    result = get_file_name('.cj-replay', 'my-template.json')
    assert result == ".cj-replay/my-template.json"



# Generated at 2022-06-21 10:59:16.519835
# Unit test for function load
def test_load():
    """Unit test for function load."""
    try:
        load('/tmp', None)
    except Exception as e:
        print(e)

    try:
        load('/tmp', '')
    except Exception as e:
        print(e)

    try:
        load('/tmp', 'foo')
    except Exception as e:
        print(e)

    try:
        load('/tmp', 'cookiecutter.json')
    except Exception as e:
        print(e)

    try:
        load('/tmp', 'cookiecutter.json')
    except Exception as e:
        print(e)



# Generated at 2022-06-21 10:59:22.484184
# Unit test for function load
def test_load():
    replay_dir = os.path.join(
        os.path.dirname(__file__), 'fixtures', 'replay'
    )
    template_name = 'pypackage'

    context = load(replay_dir, template_name)

    assert isinstance(context, dict)
    assert 'cookiecutter' in context

# Generated at 2022-06-21 10:59:25.549217
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/', 'template_name') == '/template_name.json'
    assert get_file_name('/', 'template_name.json') == '/template_name.json'

# Generated at 2022-06-21 10:59:27.904860
# Unit test for function get_file_name
def test_get_file_name():
    test = get_file_name('/home/student/Desktop/', 'sample-template')
    assert test == '/home/student/Desktop/sample-template.json'


# Generated at 2022-06-21 10:59:33.399248
# Unit test for function load
def test_load():
    my_dict = {"cookiecutter": {"blabla": "test"}}
    test_dir = 'tests/files/replay_dir'
    test_file = 'tests/files/replay_dir/template_name.json'
    # dump
    dump(test_dir, 'template_name', my_dict)
    # load
    assert load(test_dir, 'template_name') == my_dict
    # delete the created file
    os.system('rm {}'.format(test_file))

# Generated at 2022-06-21 10:59:35.600859
# Unit test for function load
def test_load():
    replay_dir = "/home/bruce/git/cookiecutter/tests/test-data/fake-replay"
    template_name = "fake-project"
    load(replay_dir,template_name)


# Generated at 2022-06-21 10:59:38.980068
# Unit test for function get_file_name
def test_get_file_name():
    file_path = get_file_name('./', 'cookie')
    assert file_path == './cookie.json'
    assert not file_path == './cookie/json'

# Generated at 2022-06-21 10:59:59.309769
# Unit test for function get_file_name
def test_get_file_name():
    # test_get_file_name_with_replay_dir_as_none()
    replay_dir = None
    template_name = 'get_file_name'
    exception_message = "Replay dir must not be None"
    try:
        get_file_name(replay_dir, template_name)
    except TypeError as e:
        assert str(e) == exception_message

    # test_get_file_name_with_replay_dir_as_string()
    replay_dir = 'get_file_name'
    template_name = 'get_file_name'
    expected_result = 'get_file_name.json'
    assert get_file_name(replay_dir, template_name) == expected_result

    # test_get_file_name_with_template_name_as

# Generated at 2022-06-21 11:00:06.193980
# Unit test for function load
def test_load():
    replay_dir = os.path.abspath(os.path.dirname(__file__))
    template_name = 'replay'
    context = load(replay_dir, template_name)
    assert context is not None
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert context['cookiecutter'] is not None
    assert isinstance(context['cookiecutter'], dict)
    assert 'full_name' in context['cookiecutter']
    assert context['cookiecutter']['full_name'] == 'Your name goes here'


# Generated at 2022-06-21 11:00:11.033994
# Unit test for function load
def test_load():
    replay_file = os.path.join("/home/mohsin/source/scripts/mine/git/cookiecutter-d3-visualization/tests/fake_replay_dir/", "fake_repo.json")
    with open(replay_file, 'r') as infile:
        context = json.load(infile)
    print(context)



# Generated at 2022-06-21 11:00:16.006526
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '~/cookiecutter_replay_test'
    template_name = 'cookiecutter-pypackage'
    expected = '~/cookiecutter_replay_test/cookiecutter-pypackage.json'
    assert get_file_name(replay_dir, template_name) == expected


# Generated at 2022-06-21 11:00:20.331064
# Unit test for function dump
def test_dump():
    """Test function dump."""
    template_name = 'test-template'
    replay_dir = '.'
    context = {'cookiecutter': {}}

    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    os.remove(replay_file)


# Generated at 2022-06-21 11:00:27.988343
# Unit test for function load
def test_load():
    res = load('/home/konark/workspace/cookiecutter/tests/test-output', 'fake-repo-pre/')

# Generated at 2022-06-21 11:00:30.726182
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("/home/user/documents", "template_name") == "/home/user/documents/template_name.json"


# Generated at 2022-06-21 11:00:31.537085
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-21 11:00:38.577776
# Unit test for function get_file_name
def test_get_file_name():
    """ Test function get_file_name."""
    # Test 1: Test default suffix
    expected = '/home/user/replay_dir/cookiecutter-pypackage.json'
    actual = get_file_name("/home/user/replay_dir", 'cookiecutter-pypackage')
    assert expected == actual, 'Test 1 failed'

    # Test 2: Test suffix forced to be added
    expected = '/home/user/replay_dir/cookiecutter-pypackage.json'
    actual = get_file_name("/home/user/replay_dir", 'cookiecutter-pypackage.py')
    assert expected == actual, 'Test 2 failed'

    # Test 3: Test suffix not added if already present

# Generated at 2022-06-21 11:00:41.430966
# Unit test for function load
def test_load():
    context = load('tests/test-load/replay', 'simple_repo')
    assert 'cookiecutter' in context
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'


# Generated at 2022-06-21 11:00:59.733073
# Unit test for function get_file_name
def test_get_file_name():
    """Test the function get_file_name
    """
    replay_dir = '/Users/bob/test_dir'
    template_name = 'sample-template'

    assert get_file_name(replay_dir, template_name) == '/Users/bob/test_dir/sample-template.json'


# Generated at 2022-06-21 11:01:08.550640
# Unit test for function dump
def test_dump():
    """Unit test for function dump.

    Function dump: Write json data to file
    """
    replay_dir = 'replay_dir_test'
    template_name = 'pytest_readme'
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['full_name'] = 'pytest'
    context['cookiecutter']['email'] = 'pytest@gmail.com'
    context['cookiecutter']['project_name'] = 'pytest_readme'
    context['cookiecutter']['project_short_description'] = 'pytest_readme'
    context['cookiecutter']['python_version'] = '3.5'

# Generated at 2022-06-21 11:01:17.184674
# Unit test for function dump
def test_dump():
    
    import tempfile
    import shutil
    
    replay_dir_name = '.cookiecutters'
    replay_dir = os.path.join(tempfile.mkdtemp(), replay_dir_name)
    template_name = 'simple'
    context = {'cookiecutter': {'cookie_buster': '1655282052'}}
    dump(replay_dir, template_name, context)
    
    # No exceptions raised
    shutil.rmtree(replay_dir)
    

# Generated at 2022-06-21 11:01:23.530974
# Unit test for function dump
def test_dump():
	context = {}
	context['cookiecutter'] = {}
	context['cookiecutter']['repo_dir'] = '/Users/sj/Documents/Github/cookiecutter-bsm'
	
	path = context['cookiecutter']['repo_dir']

	template_name = 'cookiecutter.json'

	replay_dir = os.path.join(path, '.cookiecutters_replay')

	dump(replay_dir, template_name, context)




# Generated at 2022-06-21 11:01:32.884092
# Unit test for function dump
def test_dump():
    import shutil
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tempdir:
        replay_dir = os.path.join(tempdir, 'replay')
        replay_file = get_file_name(replay_dir, 'mytemplate')
        context = {'cookiecutter': {'hello': 'world'}}
        dump(replay_dir, 'mytemplate', context)
        assert Path(replay_file).read_text() == '''\
{
  "cookiecutter": {
    "hello": "world"
  }
}'''
        dump(replay_dir, 'mytemplate.json', context)

# Generated at 2022-06-21 11:01:40.456443
# Unit test for function load
def test_load():
    replay_dir = './replay_dir'
    context = {
        'cookiecutter': {
            'full_name': 'Monty Python'
        },
    }
    template_name = './cookiecutter-pypackage'
    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert context == loaded_context

# Generated at 2022-06-21 11:01:41.867347
# Unit test for function load
def test_load():
    """Test load function."""
    pass



# Generated at 2022-06-21 11:01:47.273027
# Unit test for function get_file_name
def test_get_file_name():
	dir = '/'
	template = 'cookiecutter-pypackage'
	name1 = 'cookiecutter-pypackage.json'
	assert get_file_name(dir, template) == name1

	template2 = 'cookiecutter-pypackage.js'
	name2 = 'cookiecutter-pypackage.js'
	assert get_file_name(dir, template2) == name2


# Generated at 2022-06-21 11:01:50.572223
# Unit test for function dump
def test_dump():
    """Test dumping replay file."""
    replay_dir = 'tests/test-replay'
    dump(replay_dir, 'test_dump', {})
    assert os.path.exists('tests/test-replay/test_dump.json')



# Generated at 2022-06-21 11:01:56.838596
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    assert get_file_name('/tmp', 'foo') == '/tmp/foo.json'
    assert get_file_name('/tmp', 'foo.json') == '/tmp/foo.json'

    try:
        get_file_name(None, 'foo')
        assert False
    except TypeError:
        pass

    try:
        get_file_name('/tmp', None)
        assert False
    except TypeError:
        pass

    try:
        get_file_name(None, None)
        assert False
    except TypeError:
        pass


# Generated at 2022-06-21 11:02:39.899145
# Unit test for function load
def test_load():
    """Test idempotent replay"""
    try:
        os.mkdir('tests/test-replay')
    except FileExistsError:
        pass
    with open('tests/test-replay/test-context.json', 'w') as test_context_file:
        test_context_file.write('{"cookiecutter": {"full_name": "Test Name"}}')
    replay = load('tests/test-replay', 'test-context')
    assert isinstance(replay, dict)
    assert replay['cookiecutter']['full_name'] == "Test Name"
    with open('tests/test-replay/test-context.json', 'w') as test_context_file:
        test_context_file.write('{"cookiecutter": {"full_name": "Test Name"}}')

# Generated at 2022-06-21 11:02:41.341388
# Unit test for function load
def test_load():
  context = load("replay", "cookiecutter-pypackage")
  print(context)


# Generated at 2022-06-21 11:02:51.389229
# Unit test for function dump
def test_dump():
    replay_dir = '/Users/dev/temp'
    template_name = 'github.com/spilth/cookiecutter-pypackage-minimal'
    context = {'cookiecutter': {'full_name': 'Spilth', 'email': 'spilth@gmail.com', 'github_username': 'spilth',
                                'project_name': 'py_boilerplate', 'project_slug': 'py_boilerplate', 'project_short_description': 'Yet another Python package skeletons.', 'version': '0.1.0', 'release': '0.1.0', 'open_source_license': 'MIT license'}}

    dump(replay_dir, template_name, context)
