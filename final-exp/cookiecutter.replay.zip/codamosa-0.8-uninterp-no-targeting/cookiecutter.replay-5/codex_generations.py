

# Generated at 2022-06-21 10:53:09.499465
# Unit test for function dump
def test_dump():
    """test case for function dump()"""
    import tempfile
    from cookiecutter.environment import StrictEnvironment
    replay_dir = tempfile.mkdtemp()
    template_name='testcase1'
    template_path='testcase/testcase1'
    env = StrictEnvironment(context_file=replay_dir)
    context = env.get_context('testcase1')
    try:
        dump(replay_dir, template_name, context)
    except:
        return False

    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        r_context = json.load(infile)

    if context != r_context:
        return False
    return True

# Generated at 2022-06-21 10:53:12.438732
# Unit test for function get_file_name
def test_get_file_name():
    filename = "test"
    replay_dir = "C:/Users/mengmeng/Desktop/MISC/Omnibus_replay_package"
    print(get_file_name(replay_dir, filename))

# Generated at 2022-06-21 10:53:17.511188
# Unit test for function dump
def test_dump():
    replay_file = 'cookiecutter_replay.json'
    template_name = '.'
    context = {
        'cookiecutter': {
            'full_name': 'Habib Aroua',
            'repo_name': 'TODO'
        }
    }
    dump(replay_file, template_name, context)
    if os.path.isfile(replay_file):
        os.remove(replay_file)
        print('Unit test for function dump: ok')
    else:
        print('Unit test for function dump: not ok')


# Generated at 2022-06-21 10:53:20.571930
# Unit test for function load
def test_load():
    template_name = 'example'
    context = {'cookiecutter': {'full_name': 'test'}}
    dump('replay', template_name, context)
    assert load('replay', template_name) == context

test_load()

# Generated at 2022-06-21 10:53:25.821030
# Unit test for function load
def test_load():
    replay_dir = '~/cookiecutter-replay/'
    template_name = 'replay_test'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test Project'

# Generated at 2022-06-21 10:53:32.596880
# Unit test for function get_file_name
def test_get_file_name():
    test_dir = os.path.realpath(os.path.dirname(__file__))
    template_name = "test_template"
    file_name = get_file_name(test_dir, template_name)
    assert file_name == os.path.join(test_dir, template_name + ".json")
    template_name = "test_template.json"
    file_name = get_file_name(test_dir, template_name)
    assert file_name == os.path.join(test_dir, template_name)


# Generated at 2022-06-21 10:53:44.297979
# Unit test for function dump
def test_dump():
    replay_dir = '/tmp/replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'full_name': 'John Doe'}}

    # Test that cookiecutter key required
    no_cookiecutter_context = {'full_name': 'John Doe'}
    with pytest.raises(ValueError):
        dump(replay_dir, template_name, no_cookiecutter_context)
    # Test that template_name required to be a str
    with pytest.raises(TypeError):
        dump(replay_dir, 1234, context)
    # Test that context required to be a dictionary
    with pytest.raises(TypeError):
        dump(replay_dir, template_name, ['hello', 'world'])
    # Test that replay_dir location required

# Generated at 2022-06-21 10:53:46.624957
# Unit test for function load
def test_load():
    context = load('./', 'default')
    assert (context['cookiecutter']['project_name'] == 'my-project')


# Generated at 2022-06-21 10:53:52.996285
# Unit test for function load
def test_load():
    # Check the load function when the replay file doesn't exist
    try:
        context = load('/', 'test')
    except IOError:
        assert True

    # Check the load function when the replay file exist
    context = load('tests', 'example')
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'

# Generated at 2022-06-21 10:53:57.822720
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.getcwd(), 'dump')
    template_name = 'test'
    context = {
        'cookiecutter': {
            'project_name': 'testjson',
            'project_slug': 'testjson',
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:54:11.154508
# Unit test for function get_file_name
def test_get_file_name():

    replay_dir = 'here_is_my_replay_dir'
    template_name = 'here_is_my_template_name'

    # Make sure that this function creates a json file
    # if no suffix was given
    file_path = get_file_name(replay_dir, template_name)
    assert file_path == '{}/{}.json'.format(replay_dir, template_name)

    # Make sure that file will be overwrite
    # if it already contains the suffix
    file_path = get_file_name(replay_dir, '{}.json'.format(template_name))
    assert file_path == '{}/{}.json'.format(replay_dir, template_name)



# Generated at 2022-06-21 10:54:18.727707
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    template_name = 'cookiecutter-pypackage'
    expected_value = './cookiecutter-pypackage.json'
    actual_value = get_file_name(replay_dir, template_name)
    if actual_value != expected_value:
        raise AssertionError

    template_name = 'cookiecutter-pypackage.json'
    expected_value = './cookiecutter-pypackage.json'
    actual_value = get_file_name(replay_dir, template_name)
    if actual_value != expected_value:
        raise AssertionError


# Generated at 2022-06-21 10:54:31.732049
# Unit test for function load
def test_load():
    # Setup
    replay_dir = '/home/Wenhan/Research/cookiecutter/cookiecutter/work/replay' 
    template_name = 'demo'

    # Exercise
    context = load(replay_dir, template_name)

    # Verify
    if 'cookiecutter' not in context:
        return False
    if 'full_name' not in context['cookiecutter']:
        return False
    if 'name' not in context['cookiecutter']:
        return False
    if 'email' not in context['cookiecutter']:
        return False
    if 'project_name' not in context['cookiecutter']:
        return False
    if 'project_short_description' not in context['cookiecutter']:
        return False

# Generated at 2022-06-21 10:54:42.402331
# Unit test for function load
def test_load():
    test_json_1='{"cookiecutter":{"repo_dir":"F:\\test\\test_templates\\","context_file":"","default_context":false,"overwrite_if_exists":false,"abbreviations":null,"output_dir":"","config_file":"C:\\\\Users\\\\liuyen\\\\.cookiecutterrc","no_input":false,"verbose":false,"directory":"."},"cookiecutter":{"author_name":"","description":"Full-stack web app cookiecutter with an interactive CLI."},"package_name":"hello","email":"","version":"0.1.0","release":"0.1.0","year":"2017","project_short_description":"Short description of the project.","repo_name":"hello","open_source_license":"MIT license"}'
    #json_to_parse = json.loads(test_json_1)
    test_json_

# Generated at 2022-06-21 10:54:51.682081
# Unit test for function dump
def test_dump():
    """Test the function dump."""
    replay_dir = 'tests/files/replay'
    template_name = 'tests/files/twofiles-replay'
    context = {'cookiecutter': {
        'full_name': 'Audrey Roy',
        'email': 'audreyr@example.com',
        'github_username': 'audreyr',
        'project_name': 'nnn',
        'repo_name': 'yyy',
        'year': '2014',
        'pypi_username': 'ahaha'
    }}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-21 10:55:00.957309
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'full_name': 'fake name',
            'email': 'fake@email.com',
        }
    }
    template_name = 'fake_template'
    replay_dir = os.path.join(os.getcwd(), 'fake')
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.exists(replay_file)

    with open(replay_file, 'r') as infile:
        data = json.load(infile)

    assert data == context


# Generated at 2022-06-21 10:55:04.405953
# Unit test for function load
def test_load():
    context = load('/Users/jaehun/Desktop/cookiecutter-master-1/tests/test-generate-context', 'example')
    assert context['cool_feature'] == 'Yes'
    assert context['_template'] == 'example'
    assert context['cookiecutter'] == {}


# Generated at 2022-06-21 10:55:09.531772
# Unit test for function get_file_name
def test_get_file_name():
    expected_file_name = 'replay/dummy.json'
    given_replay_dir = 'replay'
    given_template_name = 'dummy'
    assert(expected_file_name == get_file_name(given_replay_dir, given_template_name))

# Generated at 2022-06-21 10:55:15.477874
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.getcwd(), 'tests/fixtures/fake-replay-dir')
    # Load the replay data
    context = load(replay_dir, 'fake-repo-pre')
    # Test the loaded data
    assert 'cookiecutter' in context
    # Test not existing load
    try:
        context = load(replay_dir, 'does_not_exist')
    except IOError:
        return True
    assert False, 'No exception raised for not existing file'



# Generated at 2022-06-21 10:55:18.438589
# Unit test for function get_file_name
def test_get_file_name():
    if get_file_name('/dummy', 'example') == '/dummy/example.json':
        print('test_get_file_name() passed')
    else:
        raise Exception('test_get_file_name() failed')


# Generated at 2022-06-21 10:55:20.895460
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('a', 'b') == 'a/b.json'



# Generated at 2022-06-21 10:55:29.907670
# Unit test for function dump
def test_dump():
    replay_dir = './tests/test-output/replay'
    template_name = 'test'
    context = {'cookiecutter': {'test1': 'test1'}}
    dump(replay_dir, template_name, context)
    file_name = get_file_name(replay_dir, template_name)
    with open(file_name, 'r') as infile:
        data = json.load(infile)
        if context == data:
            print('pass dump test')
            os.remove(file_name)
        else:
            print('fail dump test')


# Generated at 2022-06-21 10:55:31.342318
# Unit test for function load
def test_load():
    load("/Users/srika/PycharmProjects/cookiecutter", "srikanth")
    return True;

# Generated at 2022-06-21 10:55:34.625407
# Unit test for function dump
def test_dump():
    replay_dir = 'C:\\Users\\huynguyen\\Desktop\\test_dump'
    template_name = 'example.json'
    context = {'cookiecutter': {'key1': 'value1', 'key2': 'value2'}}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-21 10:55:41.962404
# Unit test for function get_file_name
def test_get_file_name():
    """test_get_file_name"""
    replay_dir = '/tmp/replay_dir'
    template_name = 'python_project'
    name = get_file_name(replay_dir, template_name)
    assert name == '/tmp/replay_dir/python_project.json'
    name = get_file_name(replay_dir, template_name+'.json')
    assert name == '/tmp/replay_dir/python_project.json'

# Generated at 2022-06-21 10:55:44.742151
# Unit test for function load
def test_load():
    replay_dir = "../replay"
    template_name = "cookiecutter-pytest2"
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-21 10:55:49.083635
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name function."""
    assert get_file_name('foo', 'bar') == 'foo/bar'
    assert get_file_name('foo', 'bar.json') == 'foo/bar.json'


# Generated at 2022-06-21 10:55:53.025089
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'test/test_folder'
    template_name = 'test_template'
    result = get_file_name(replay_dir,template_name)
    assert result == 'test/test_folder/test_template.json'


# Generated at 2022-06-21 10:55:54.483752
# Unit test for function load
def test_load():
    context = load('tests/test-replay', 'tests/fake-repo-pre/')

    if 'cookiecutter' not in context:
        raise ValuError('Context is required to contain a cookiecutter key')


# Generated at 2022-06-21 10:56:01.008796
# Unit test for function dump
def test_dump():
    # Set up variables
    replay_dir = 'tmp/replay'
    template_name = 'tmp/template'
    context = {
        'username': 'bob',
        'project_name': 'test',
        'cookiecutter': 'test'
    }

    # Test dump
    dump(replay_dir, template_name,  context)

    # Check if file exists
    file_exists = os.path.exists(get_file_name(replay_dir, template_name))
    assert file_exists

    # Check if json file correctly written
    with open(get_file_name(replay_dir, template_name), 'r') as infile:
        written_context = json.load(infile)
        assert context == written_context



# Generated at 2022-06-21 10:56:10.151902
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "replay"
    template_name_json = "file.json"
    template_name_other = "file.other"

    assert replay_dir + "/" + template_name_json == get_file_name(replay_dir, template_name_json)
    assert replay_dir + "/" + template_name_other + ".json" == get_file_name(replay_dir, template_name_other)

test_get_file_name()

# Generated at 2022-06-21 10:56:12.558464
# Unit test for function get_file_name
def test_get_file_name():
    path = os.path.abspath("replay")
    file_name = get_file_name(path, "test")
    assert("replay/test.json" == file_name)


# Generated at 2022-06-21 10:56:14.674415
# Unit test for function dump
def test_dump():
    context = {}
    dump('example','test',context)


if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-21 10:56:21.262071
# Unit test for function load
def test_load():
    context = load('replay/first-project', 'replay/first-project-replay.json')
    assert context['cookiecutter']['project_name'] == 'First Project'
    assert context['cookiecutter']['author_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'


# Generated at 2022-06-21 10:56:25.128332
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "replay_dir"
    template_name = "template_name"
    file_name = get_file_name(replay_dir, template_name)
    assert isinstance(file_name, str)

# Generated at 2022-06-21 10:56:29.894239
# Unit test for function get_file_name
def test_get_file_name():

    template_name = 'template_name'
    replay_dir = 'path/to/dir'

    result = get_file_name(replay_dir, template_name)

    expect = 'path/to/dir/template_name.json'

    assert result == expect

# Unit tests for function dump

# Generated at 2022-06-21 10:56:40.634389
# Unit test for function get_file_name
def test_get_file_name():
    suffix_existed_input = 'test.json'
    expected_output = 'test.json'
    assert expected_output == get_file_name(replay_dir='test', template_name=suffix_existed_input)

    suffix_not_existed_input = 'test'
    expected_output = 'test.json'
    assert expected_output == get_file_name(replay_dir='test', template_name=suffix_not_existed_input)

    template_name_not_str = 118
    expected_output = TypeError
    assert expected_output == type(get_file_name(replay_dir='test', template_name=template_name_not_str))


# Generated at 2022-06-21 10:56:43.522182
# Unit test for function load
def test_load():
    context = load('C:\\Users\\ylf\\Documents\\GitHub\\cookiecutter\\tests\\test-data\\replay\\', 'simple-json')
    print (context)


# Generated at 2022-06-21 10:56:49.944823
# Unit test for function dump
def test_dump():
    # Setup
    template_name = "test"
    context = {"cookiecutter": {"foo": "bar"}}
    replay_dir = "/home/plab/Desktop/test"
    file_name = "/home/plab/Desktop/test/test.json"

    dump(replay_dir, template_name, context)
    file = open(file_name, 'r')
    output = file.read()
    file.close()
    os.remove(file_name)

    assert output == '{\n  "cookiecutter": {\n    "foo": "bar"\n  }\n}'


# Generated at 2022-06-21 10:56:55.184675
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    expected_result1 = './some_template.json'
    expected_result2 = './another_template.json'
    assert get_file_name(replay_dir, 'some_template') == expected_result1
    assert get_file_name(replay_dir, 'another_template.json') == expected_result2


# Generated at 2022-06-21 10:57:07.602201
# Unit test for function load
def test_load():
    """Test the load() function."""
    replay_dir = os.path.join(os.getcwd(), 'replay')
    context = {'cookiecutter': 'foo'}
    template_name = 'bar'
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-21 10:57:14.000855
# Unit test for function dump
def test_dump():
    template_name = 'test'
    replay_dir = 'test'
    context = {
        'cookiecutter': {},
    }
    dump(replay_dir, template_name, context)
    assert(os.path.exists(replay_dir + '/' + template_name + '.json') == True)
    os.remove(replay_dir + '/' + template_name + '.json')


# Generated at 2022-06-21 10:57:24.605975
# Unit test for function dump
def test_dump():
    template_name = 'conde_home'
    context = {
        'project_name': 'conde-home',
        'repo_name': 'conde-home',
        'project_slug': 'conde-home',
        'author_name': 'Grace',
        'email': 'shanghai@grace.com',
        'description': 'Home of Conde',
        'domain_name': 'conde.com',
        'version': '0.1.0',
        'timezone': 'Europe/Amsterdam',
        'cookiecutter': {
            'replay_dir': '~/.cookiecutters_replay'
        }
    }
    dump(context['cookiecutter']['replay_dir'], template_name, context)


# Generated at 2022-06-21 10:57:28.163330
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/user/cookiecutter'
    template_name = 'some-template'
    result = '/home/user/cookiecutter/some-template.json'

    assert get_file_name(replay_dir,template_name) == result



# Generated at 2022-06-21 10:57:38.974333
# Unit test for function load
def test_load():
    import pytest
    from tempfile import mkdtemp
    from shutil import rmtree
    from os.path import join
    from os import remove

    temp_dir = mkdtemp()
    replay_file = join(temp_dir, 'example_repo.json')

    with open(replay_file, 'w') as infile:
        json.dump({'cookiecutter': {'a': 1, 'b': 2}}, infile)

    assert load(temp_dir, 'example_repo') == {'cookiecutter': {'a': 1, 'b': 2}}

    with pytest.raises(ValueError):
        load(temp_dir, 'example_repo') == {'a': 1, 'b': 2}

    remove(replay_file)
    rmtree(temp_dir)

# Generated at 2022-06-21 10:57:44.334565
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "C:/Users/v-jiadun/Documents/github/jd_cookiecutter/replay_files"
    template_name = "python-packaging"
    file_name = get_file_name(replay_dir, template_name)
    print("The file name is: "+ file_name)
    assert (file_name)


# Generated at 2022-06-21 10:57:52.802074
# Unit test for function dump
def test_dump():
    """Test for the dump function."""
    try:
        context = {
            "cookiecutter": {
                "Repo_name": "new_repo",
                "author_name": "Felix B. Klock II",
                "email": "fklock@fklock.com",
                "description": "A very simple project that illustrates "
                    "cookiecutter."
            }
        }
        dump(context)
    except TypeError:
        return True
    except ValueError:
        return True
    except IOError:
        return True
    except:
        return False
    return False



# Generated at 2022-06-21 10:58:00.201751
# Unit test for function dump
def test_dump():
    replay_dir = 'replay_test'
    template_name = 'example'
    context = {'cookiecutter': {'name': 'demo'}}
    dump(replay_dir, template_name, context)

    dump_file = get_file_name(replay_dir, template_name)
    if os.path.exists(dump_file):
        os.remove(dump_file)
    else:
        print("The file does not exist")



# Generated at 2022-06-21 10:58:05.663566
# Unit test for function load
def test_load():
    """Unit test for function load"""

# Generated at 2022-06-21 10:58:08.217874
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay_dir', 'template_name') == 'replay_dir/template_name.json'
    assert get_file_name('replay_dir', 'template_name.json') == 'replay_dir/template_name.json'


# Generated at 2022-06-21 10:58:22.917217
# Unit test for function dump
def test_dump():
    context = {
        "cookiecutter": {
            "full_name": "Audrey Roy",
            "email": "audreyr@example.com",
            "github_username": "audreyr",
            "project_name": "Cookiecutter Example",
            "project_slug": "cookiecutter-example",
            "pkg_name": "cookiecutter_example",
            "project_short_description": "A short description of the project.",
            "release_date": "2014-08-23",
        }
    }

    replay_dir = 'test_dump'
    template_name = 'cookiecutter-pypackage-test_dump'

    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:58:25.546804
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("foo", "zzz") == "foo/zzz.json"
    assert get_file_name("bar", "aaa.json") == "bar/aaa.json"

# Generated at 2022-06-21 10:58:29.343574
# Unit test for function load
def test_load():
    test_name = 'test'
    test_data = {"cookiecutter": "data"}
    replay_file = get_file_name('./cookiecutter_replay/', test_name)
    dump('./cookiecutter_replay/', test_name, test_data)
    test_data_new = load('./cookiecutter_replay/', test_name)
    assert(test_data_new == test_data)

# Generated at 2022-06-21 10:58:32.381071
# Unit test for function dump
def test_dump():
    info = {'cookiecutter': {'name': 'bob', 'age': '30'}}
    dump('/tmp', 'test', info)
    read = load('/tmp', 'test')
    assert info == read

# Generated at 2022-06-21 10:58:35.526622
# Unit test for function load
def test_load():
    assert load('./cookiecutter/replay', '{{cookiecutter.project_slug}}')['cookiecutter']['project_slug'] == 'my-first-blog'


# Generated at 2022-06-21 10:58:40.611998
# Unit test for function load
def test_load():
    """[Summary]
    
    Returns:
        [type]: [description]
    """
    template_name = "py."
    replay_dir = "cookiecutter"
    try:
        context = [load(replay_dir, template_name)]
        print(context)
    except TypeError:
        context = load(replay_dir, template_name)
        print(context)
    
    

# Generated at 2022-06-21 10:58:45.905373
# Unit test for function get_file_name
def test_get_file_name():
    """Function test_get_file_name() returns file name."""
    replaydir = "C:/Users/Acer/Desktop/replays"
    templatename = "C:/Users/Acer/Desktop/defaultproject"
    replay_file = get_file_name(replaydir, templatename)
    if replay_file == "C:/Users/Acer/Desktop/replays/C:/Users/Acer/Desktop/defaultproject/":
        print ("get_file_name returns file name")
    else:
        print ("get_file_name does not return file name")

#Unit test for function dump

# Generated at 2022-06-21 10:58:49.085770
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)

# Generated at 2022-06-21 10:58:52.422479
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('anydir', 'template') == 'anydir/template.json'
    assert get_file_name('anotherdir', 'template.json') == 'anotherdir/template.json'

# Generated at 2022-06-21 10:58:57.974190
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = ".cookiecutters"
    template_name = "bhunter/pylib"
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == ".cookiecutters/bhunter/pylib.json"

# Generated at 2022-06-21 10:59:09.188487
# Unit test for function load
def test_load():
    assert isinstance(load('replay', 'cookiecutter-pypackage'), dict)


# Generated at 2022-06-21 10:59:17.683008
# Unit test for function load
def test_load():
    replay_file = get_file_name('examples', 'replay.json')
    assert make_sure_path_exists('examples')
    with open(replay_file, 'w') as outfile:
        outfile.write('{"cookiecutter":{"noe":"edna"}}')
    with open(replay_file, 'r') as infile:
        context = json.load(infile)
    print(context)
    assert context == {'cookiecutter': {'noe': 'edna'}}
    os.remove(replay_file)

# Generated at 2022-06-21 10:59:27.362425
# Unit test for function load
def test_load():
    class TestContext(object):
        def __init__(self, cookiecutter):
            self.cookiecutter = cookiecutter

    import sys
    import os
    from cookiecutter import replay

    if len(sys.argv) < 2:
        print("Usage: %s <template_name>" % sys.argv[0])
        sys.exit(0)

    template_name = sys.argv[1]

    replay_dir = os.path.join(os.getcwd(), '.cookiecutters')
    context = replay.load(replay_dir, template_name)
    tester = TestContext(context.get('cookiecutter'))
    print(repr(tester))



# Generated at 2022-06-21 10:59:33.514307
# Unit test for function get_file_name
def test_get_file_name():
    """Testing get_file_name()."""
    replay_dir = './replay/'
    template_name = 'cookiecutter-pypackage'
    file_name_result = 'cookiecutter-pypackage.json'
    file_os_join_result = os.path.join(replay_dir, file_name_result)
    file_name = get_file_name(replay_dir=replay_dir, template_name=template_name)
    assert(file_os_join_result == file_name)


# Generated at 2022-06-21 10:59:35.210243
# Unit test for function load
def test_load():
    print(load('/Users/yinjia/PycharmProjects/cookiecutter/tests/test-replay', 'example-replay.json'))


# Generated at 2022-06-21 10:59:44.092585
# Unit test for function load
def test_load():
    replay_dir ='./'
    template_name = 'template'
    context = load(replay_dir, template_name)
    if not isinstance(context, dict):
        raise TypeError('Context is required to be of type dict')

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')
    json_file = get_file_name(replay_dir, 'template')
    with open(json_file, 'r') as json_data:
        data = json.load(json_data)
        if data != context:
            raise ValueError('load() data from file wrong:', data)
    print('load() test passed!')


# Generated at 2022-06-21 10:59:51.911716
# Unit test for function dump
def test_dump():
    dump(replay_dir='.',
        template_name='.')

    dump(replay_dir='.',
        template_name='.json.json')

    dump(replay_dir='.',
        template_name='.json',
        context={'cookiecutter':
            {'project_name': 'test_project'},
            'test_key': 'test_value'})

    dump(replay_dir='.',
        template_name='.')

    dump(replay_dir='.',
        template_name='.')



# Generated at 2022-06-21 11:00:01.181492
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-21 11:00:07.124813
# Unit test for function dump
def test_dump():
    try:
        os.remove(os.path.join('.', 'test_dump.txt'))
    except:
        pass
    replay_dir = '.'
    template_name = 'test_dump.txt'
    context = {
        'cookiecutter': {
            'name': 'blah'
        }
    }
    dump(replay_dir, template_name, context)
    assert os.path.isfile(os.path.join('.', 'test_dump.txt'))



# Generated at 2022-06-21 11:00:09.375846
# Unit test for function dump
def test_dump():
    """Test function dump."""
    dump('/tmp/', 'hello', {'cookiecutter': 'context'})



# Generated at 2022-06-21 11:00:33.781456
# Unit test for function load
def test_load():
    context = load(os.path.expanduser('~'), 'cookiecutter-pypackage')
    assert isinstance(context, dict)
    assert 'cookiecutter' in context

    suffix = '.json' if not 'cookiecutter-pypackage'.endswith('.json') else ''
    replay_file = '{}{}'.format('cookiecutter-pypackage', suffix)
    assert replay_file in os.listdir(os.path.expanduser('~'))

# Generated at 2022-06-21 11:00:41.976628
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import zipfile
    import shutil

    cwd = os.getcwd()
    replay_dir = os.path.join(cwd, 'tests', 'test-replay')

    template_repo_dir = os.path.join(cwd, 'tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')
    template_zip_path = os.path.join(cwd, 'tests', 'fake-repo-pre.zip')


# Generated at 2022-06-21 11:00:49.735292
# Unit test for function dump
def test_dump():
    from cookiecutter.config import get_user_config, DEFAULT_PATH
    from cookiecutter.replay import dump, load
    from cookiecutter import main

    replay_dir = 'fake-replay-dir'
    template_name = 'fake-template-name'

    load_config = get_user_config(DEFAULT_PATH)
    config_dict = {"replay_dir": replay_dir}
    config_dict.update(load_config)

    # Check the dump function dump to file
    try:
        dump(replay_dir, template_name, config_dict)
    finally:
        # remove dump file
        os.remove(get_file_name(replay_dir, template_name))



# Generated at 2022-06-21 11:00:50.556810
# Unit test for function load
def test_load():
    dir = '.'
    name = 'asd'
    print(load(dir, name))



# Generated at 2022-06-21 11:00:53.797964
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'template_name'
    replay_dir = 'replay_dir'
    result = get_file_name(replay_dir, template_name)
    print(result)

if __name__ == '__main__':
    test_get_file_name()

# Generated at 2022-06-21 11:00:55.450343
# Unit test for function load
def test_load():
    a = load('.','replay1')
    print(a)

# Generated at 2022-06-21 11:01:06.358179
# Unit test for function dump
def test_dump():
    print ("testing")
    replay_dir = "12333"
    template_name="test"
    context=[{"cookiecutter": {
        "project_slug": "hello-word",
        "full_name": "Your Name",
        "email": "yourname@mail.com",
        "github_username": "YourGithubUsername",
        "description": "A short description of the project.",
        "version": "0.1.0",
        "open_source_license": "MIT License",
        "year": "2017",
        "repo_name": "cookiecutter-hello-word",
        "use_pypi_deployment_with_travis": "n"}
        }]
    dump(replay_dir,template_name,context)

test_dump()

# Generated at 2022-06-21 11:01:10.482274
# Unit test for function load
def test_load():
    """Unit test for function load"""
    import json
    
    #unittest_filename = 'test_load.json'
    unittest_filename = 'poetry.json'
    unittest_dir = 'tests'
    
    context = load(unittest_dir,unittest_filename)
    print(json.dumps(context, indent=4))
    
if __name__ == '__main__':
    test_load()

# Generated at 2022-06-21 11:01:17.458441
# Unit test for function get_file_name
def test_get_file_name():
    assert(get_file_name('/', 'python-simple') == '/python-simple.json')
    assert(get_file_name('/', 'python-simple.json') == '/python-simple.json')
    assert(get_file_name('/foo', 'python-simple') == '/foo/python-simple.json')
    assert(get_file_name('/foo', 'python-simple.json') == '/foo/python-simple.json')


# Generated at 2022-06-21 11:01:19.551454
# Unit test for function get_file_name
def test_get_file_name():
    """Test get file name."""
    assert get_file_name('replay', 'Bago') == 'replay/Bago.json'


# Generated at 2022-06-21 11:02:12.358363
# Unit test for function dump
def test_dump():
    data = {
        "project_name": "test",
        "package_name": "test-package",
        "repo_name": "test-repo",
        "pypi_username": "testpypi",
        "description": 'A short description of the project.',
        "use_pytest": False,
        "open_source_license": 'MIT',
        "use_pyinvoke": False,
        "use_docker": False
    }

    import tempfile
    with tempfile.TemporaryDirectory() as replay_dir:
        dump(replay_dir, 'test', data)
        result = load(replay_dir, 'test')

        assert data == result


# Generated at 2022-06-21 11:02:17.075322
# Unit test for function load
def test_load():
    """Test load function."""
    context = load("/Users/jeremyhuang/Desktop/s1s2s3s4s5s6s7s8s9s10s11s12s13s14s15s16s17s18/", "cookiecutter-pylibrary")
    print(context)
    assert context["cookiecutter"]["use_pytest"] == "y"


# Generated at 2022-06-21 11:02:27.840836
# Unit test for function load
def test_load():
    context = load('/Users/yinlin/.cookiecutters', 'cookiecutter-pypackage')
    assert isinstance(context, dict)

# Generated at 2022-06-21 11:02:33.004939
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/tmp/replay'

    template_name = 'cookiecutter-example'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/tmp/replay/cookiecutter-example.json'

    template_name = 'cookiecutter-example.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/tmp/replay/cookiecutter-example.json'

# Generated at 2022-06-21 11:02:38.704077
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name.
    """
    replay_dir = 'replay'
    template_name = 'test_template'
    expected_file_name = '{}/{}.json'.format(replay_dir, template_name)
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == expected_file_name


# Generated at 2022-06-21 11:02:47.689996
# Unit test for function dump
def test_dump():
    replay_dir = "/home/jiaxin/PycharmProjects/cookiecutter/tests/test-replay"
    template_name = '/home/jiaxin/PycharmProjects/cookiecutter/tests/fake-repo-pre'
    project_dir = '/home/jiaxin/PycharmProjects/cookiecutter/tests/fake-repo-pre/{{cookiecutter.project_slug}}'

# Generated at 2022-06-21 11:02:53.292338
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'path/to/dir'
    template_name = 'my-dashed-template-name'

    file_name = get_file_name(replay_dir, template_name)

    expected_file_name = os.path.join(replay_dir, '{}.json'.format(template_name))

    assert file_name == expected_file_name