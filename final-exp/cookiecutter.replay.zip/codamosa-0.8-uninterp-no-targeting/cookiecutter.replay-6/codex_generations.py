

# Generated at 2022-06-21 10:52:57.825993
# Unit test for function load

# Generated at 2022-06-21 10:53:01.323502
# Unit test for function dump
def test_dump():
    test_context = {'cookiecutter': {
        'full_name': 'Peng Zhao',
        'email': 'peng.zhao@gmail.com',
        'github_username': 'empaker'
    }}
    dump(replay_dir=os.path.join('..', '..'), template_name='test', context=test_context)



# Generated at 2022-06-21 10:53:10.619073
# Unit test for function get_file_name
def test_get_file_name():
    get_file_name('tests/test-replay/', 'myreplay') == 'tests/test-replay/myreplay.json'
    get_file_name('tests/test-replay/', 'myreplay.json') == 'tests/test-replay/myreplay.json'
    get_file_name('tests/test-replay/', 'otherreplay.json') == 'tests/test-replay/otherreplay.json'
    get_file_name('tests/test-replay/', '') == 'tests/test-replay/.json'


# Generated at 2022-06-21 10:53:13.923758
# Unit test for function load
def test_load():
    replay_dir = "replay_dir"
    template_name = "cookiecutter-pypackage-minilib"
    context = load(replay_dir, template_name)


# Generated at 2022-06-21 10:53:22.939713
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/fake-replay-dir'
    template_name = 'fake-cookiecutter-template'

    # Test with context containing with cookiecutter key
    context = {'cookiecutter': {'full_name': 'Foo Bar'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))

    # Test with context not containing cookiecutter key
    context = {'full_name': 'Foo Bar'}
    try:
        dump(replay_dir, template_name, context)
        assert False
    except ValueError:
        assert True

    # Test with not a dict type context
    context = 'foo'

# Generated at 2022-06-21 10:53:29.549349
# Unit test for function dump
def test_dump():
	replay_dir = 'c:\\Users\\Chang\\Desktop\\p3'
	template_name = 'cookiecutter-pypackage'
	context = {'cookiecutter':{'full_name':'Chang','email':'changchang222777@gmail.com','project_name':'cookie','project_slug':'cookie'}}
	dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:53:34.072706
# Unit test for function load
def test_load():
    assert load(replay_dir='./replay', template_name='hello-world')['cookiecutter']['project_name'] == 'Hello world'



# Generated at 2022-06-21 10:53:38.105349
# Unit test for function get_file_name
def test_get_file_name():
    result = get_file_name('C:/Users/User/Desktop/QE/cookiecutter', 'cookiecutter')
    assert result == 'C:/Users/User/Desktop/QE/cookiecutter/cookiecutter.json'


# Generated at 2022-06-21 10:53:43.197008
# Unit test for function get_file_name
def test_get_file_name():
    
    # Test when template_name is empty
    assert get_file_name("./test", "") == './test/.json'
    
    # Test when template_name is not empty and end with '.json'
    assert get_file_name("./test", "test") == './test/test.json'
    
    # Test when template_name is not empty and not end with '.json'
    assert get_file_name("./test", "test.json") == './test/test.json'
    

# Generated at 2022-06-21 10:53:49.242885
# Unit test for function dump
def test_dump():
    context = dict()
    context['cookiecutter'] = dict()
    replay_dir = './test'
    template_name = 'example'
    replay_file = get_file_name(replay_dir, template_name)
    dump(replay_dir, template_name, context)
    with open(replay_file, 'r') as infile:
        result = json.load(infile)
    os.remove(replay_file)
    assert result == context


# Generated at 2022-06-21 10:53:59.120416
# Unit test for function dump
def test_dump():
    if not make_sure_path_exists('/tmp/tests'):
        raise IOError('Unable to create replay dir at {}')
    template_name = '{{cookiecutter.repo_name}}'
    context = {'cookiecutter': {'repo_name': 'test'}}
    dump('/tmp/tests', template_name, context)

    #print(get_file_name('/tmp/tests', template_name))
    assert os.path.exists(get_file_name('/tmp/tests', template_name)) == True
    os.remove(get_file_name('/tmp/tests', template_name))


# Generated at 2022-06-21 10:54:06.411773
# Unit test for function dump
def test_dump():
    import tempfile
    from cookiecutter.utils import rmtree
    from random import randint
    from string import ascii_lowercase
    import json

    # construct a random folder name
    rand_name1 = ''.join(ascii_lowercase[randint(0, 25)] for _ in range(6))
    rand_name2 = ''.join(ascii_lowercase[randint(0, 25)] for _ in range(6))
    rand_name3 = ''.join(ascii_lowercase[randint(0, 25)] for _ in range(6))
    rand_replay_dir = os.path.join(tempfile.gettempdir(), rand_name1, rand_name2, rand_name3)

# Generated at 2022-06-21 10:54:14.469817
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tests/test-data/replay'
    if not os.path.exists(replay_dir):
        os.makedirs(replay_dir)

    template_name = 'template'
    file_name = get_file_name(replay_dir, template_name)
    file_handler = open(file_name,'w')
    file_handler.write('test')
    file_handler.close()
    assert os.path.exists(file_name)
    os.remove(file_name)
    assert not os.path.exists(file_name)



# Generated at 2022-06-21 10:54:21.416490
# Unit test for function get_file_name
def test_get_file_name():
    assert os.path.join('.', 'my-template.json') == get_file_name('.', 'my-template')
    assert os.path.join('.', 'my-template.json') == get_file_name('.', 'my-template.json')

    assert os.path.join('c:\\path\\to\\replay\\dir', 'my-template.json') == get_file_name('c:\\path\\to\\replay\\dir', 'my-template')
    assert os.path.join('c:\\path\\to\\replay\\dir', 'my-template.json') == get_file_name('c:\\path\\to\\replay\\dir', 'my-template.json')

    assert os.path.join('/path/to/replay/dir', 'my-template.json') == get

# Generated at 2022-06-21 10:54:24.334093
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("/home/","csawyer/template") == '/home/csawyer/template.json'


# Generated at 2022-06-21 10:54:34.813785
# Unit test for function get_file_name
def test_get_file_name():
    # test for template_name ending with .json
    replay_dir = '/home/test/replay'
    template_name = '/home/test/template'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/home/test/replay/template.json'

    # test for template_name not ending with .json
    template_name = '/home/test/template.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/home/test/replay/template.json'


# Generated at 2022-06-21 10:54:38.894325
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'my-project'
    replay_dir = 'my_dir'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'my_dir/my-project.json'


# Generated at 2022-06-21 10:54:45.761898
# Unit test for function dump
def test_dump():
    replay_dir = "./tests/test-output/replay"
    template_name = "./tests/fake-repo-pre/{{cookiecutter.repo_name}}"
    context = {'cookiecutter': {'full_name': 'Test User', 'email': 'test@example.com', 'github_username': 'audreyr', 'project_name': 'Fake', 'repo_name': 'fake', 'project_short_description': 'A short description of the project.', 'pypi_username': 'testuser', 'command_line_interface': 'Click', 'version': '0.1.0', 'release_date': '2015-12-03', 'year': '2015', 'month': '12', 'day': '03', 'hour': '22', 'minute': '10'}}


# Generated at 2022-06-21 10:54:51.209522
# Unit test for function dump
def test_dump():
    replay_dir = 'test'
    context = {'name': 'Lei', 'number': '1'}
    template_name = 'test'
    dump(replay_dir, template_name, context)
    assert os.path.exists('{}/{}.json'.format(replay_dir, template_name))


# Generated at 2022-06-21 10:54:55.083741
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/user/cookiecutter_replay'
    assert get_file_name(replay_dir, 'template_name') == '/home/user/cookiecutter_replay/template_name.json'


# Generated at 2022-06-21 10:54:59.396944
# Unit test for function get_file_name
def test_get_file_name():
    actual = get_file_name('/', 'test')
    assert actual == '/test.json'

    actual = get_file_name('/', 'test.json')
    assert actual == '/test.json'

# Generated at 2022-06-21 10:55:10.873350
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('c:/projects/replay', 'repo-name') == 'c:/projects/replay/repo-name.json'
    assert get_file_name('c:/projects/replay', 'repo-name.json') == 'c:/projects/replay/repo-name.json'
    assert get_file_name('/projects/replay/', 'repo-name.json') == '/projects/replay/repo-name.json'
    assert get_file_name('projects/replay/', 'repo-name') == 'projects/replay/repo-name.json'
    assert get_file_name('replay', 'repo-name.json') == 'replay/repo-name.json'

# Generated at 2022-06-21 10:55:14.023805
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'cookiecutter-pypackage'
    new_file_name = get_file_name('.', template_name)
    assert(new_file_name == './cookiecutter-pypackage.json')


# Generated at 2022-06-21 10:55:21.978793
# Unit test for function dump
def test_dump():
    from cookiecutter import replay
    import tempfile
    replay_dir = tempfile.mkdtemp()
    template_name = 'basic_template'
    context = {'cookiecutter': {}}
    replay.dump(replay_dir, template_name, context)
    expected_file_path = os.path.join(replay_dir, template_name + '.json')
    assert os.path.isfile(expected_file_path)
    # Verify that replay_file contains correct data
    with open (expected_file_path, "r") as replay_file:
        replay_data = replay_file.read()
        assert '{}' in replay_data
    # remove temp replay directory
    os.rmdir(replay_dir)


# Generated at 2022-06-21 10:55:28.333390
# Unit test for function dump
def test_dump():
    """Test for function dump."""
    answer_file = open('./tests/test-dump/dump.json', 'r')
    answer = json.load(answer_file)

    dump('./tests/test-dump', 'dump', answer)
    replay = load('./tests/test-dump', 'dump')

    assert replay == answer


# Generated at 2022-06-21 10:55:32.096184
# Unit test for function get_file_name
def test_get_file_name():
    dir_name = '.'
    template_name = 'template'
    assert get_file_name(dir_name, template_name) == './template.json'
    template_name = 'template.json'
    assert get_file_name(dir_name, template_name) == './template.json'


# Generated at 2022-06-21 10:55:32.563419
# Unit test for function dump
def test_dump():
	pass

# Generated at 2022-06-21 10:55:36.140765
# Unit test for function load
def test_load():
    assert load('./', 'load_test') == {'cookiecutter': {'a': 1, 'b': 2}}
    assert load('./', 'load_test2') == {'cookiecutter': {'a': 1, 'b': 2, 'c': 3}}
    assert load('./', 'load_test3') == {'cookiecutter': {'a': 1, 'b': 2, 'c': 3, 'd': 4}}

# Generated at 2022-06-21 10:55:39.201792
# Unit test for function load
def test_load():
    assert isinstance(load('replay_dir', 'test_filename'), dict)
    assert load('replay_dir', 'test_filename')['cookiecutter'] is not None

# Generated at 2022-06-21 10:55:43.759101
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("test", "test") == "test/test.json"
    assert get_file_name("test", "test.json") == "test/test.json"
    assert get_file_name("test", "test.json.json") == "test/test.json.json"


# Generated at 2022-06-21 10:55:52.476346
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = '.cookiecutter_replay'
    template_name = 'tmp'
    context = dict()
    context['cookiecutter'] = dict()
    dump(replay_dir, template_name, context)

    content = load(replay_dir, template_name)
    assert content is not None, "content is None"
    os.remove(replay_dir + '/' + 'tmp.json')

# Generated at 2022-06-21 10:55:56.316296
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/foo/bar', 'baz') == '/foo/bar/baz.json'
    assert get_file_name('/foo/bar', 'baz.json') == '/foo/bar/baz.json'


# Generated at 2022-06-21 10:55:57.444129
# Unit test for function load
def test_load():
    """
    Unit test for function load
    """

# Generated at 2022-06-21 10:56:09.216145
# Unit test for function dump
def test_dump():
    base_dir = os.path.join(os.environ['BASE_DIR'], 'data')
    template_path = os.path.join(os.environ['TEMPLATES_DIR'], '{{ cookiecutter.repo_name }}')
    template_name = 'test'

    replay_dir = os.path.join(base_dir, '.cookiecutters')


# Generated at 2022-06-21 10:56:12.588409
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name()."""
    replay_dir = 'examples'
    template_name = 'example_cookiecutter_template'

    expected_file_name = 'example_cookiecutter_template.json'
    assert get_file_name(replay_dir, template_name) == expected_file_name


# Generated at 2022-06-21 10:56:18.399540
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay'
    context = {"cookiecutter":{"full_name": "Eiichiro ITO", "email": "eiichiro@eiichiroito.org"}}
    template_name = 'cookiecutter-pypackage-minimal'
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:56:29.935696
# Unit test for function dump
def test_dump():
    """Test dump function."""
    try:
        import tempfile
        tempdir = tempfile.mkdtemp(prefix='cookiecutter-')
        replay_dir = os.path.join(tempdir, 'replay')
        context = {
            'cookiecutter': {
                'full_name': 'Donald Duck',
                'email': 'donald@duck.com',
            }
        }
        dump(replay_dir, 'cookiecutter-pypackage', context)
        context = load(replay_dir, 'cookiecutter-pypackage')

        assert context['cookiecutter'] == {
            'full_name': 'Donald Duck',
            'email': 'donald@duck.com',
        }

    except OSError:
        assert False, 'Can not write to temp folder!'



# Generated at 2022-06-21 10:56:33.382495
# Unit test for function load
def test_load():
    """Unit test for function load ."""
    result = load('/home/dongderui/test/test/test', 'test')
    assert result['cookiecutter']['test'] == 1



# Generated at 2022-06-21 10:56:38.284438
# Unit test for function dump
def test_dump():
    a = {}
    a['cookiecutter'] = {'full_name': 'Pallavi Gupta'}
    replay_dir = 'C:\\Users\\pallavigupta\\Desktop\\a\\a'
    dump(replay_dir, 'test', a)



# Generated at 2022-06-21 10:56:43.348474
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join(os.path.expanduser('~'), 'cookiecutter-replay')
    template_name = 'foo/bar'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, template_name + '.json')



# Generated at 2022-06-21 10:56:55.479543
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    context = {
        'cookiecutter': {
            'name': 'Audrey Roy',
            'full_name': 'Audrey Roy Greenfeld',
            'email': 'aroy@example.com',
        }
    }
    assert isinstance(context, dict)
    template_name = 'data.json'
    assert isinstance(template_name, str)

    replay_dir = 'temp'
    if not os.path.exists(replay_dir):
        os.makedirs(replay_dir)


# Generated at 2022-06-21 10:56:58.049439
# Unit test for function load
def test_load():
    expected = {'cookiecutter': {}}
    actual = load("/tmp", "cookiecutter")
    assert expected == actual



# Generated at 2022-06-21 10:57:08.953434
# Unit test for function dump
def test_dump():
    replay_dir = os.path.abspath('test_dump')
    template_name = 'test_dump'
    context = {'cookiecutter': {'repo_name': 'Test_dump'}}
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        test_context = json.load(infile)

    assert context == test_context
    os.remove('test_dump/test_dump.json')
    os.removedirs('test_dump')

if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-21 10:57:13.109218
# Unit test for function load
def test_load():
    assert load("../tests/files/", "cookiecutter.json") == {'cookiecutter': {'repo_dir': '~/fake-repo', 'project_name': 'docopt', 'full_name': 'Audrey Roy'}}


# Generated at 2022-06-21 10:57:14.594588
# Unit test for function load
def test_load():
    context = load("C:\\Users\\Sun\\Desktop\\", "cookiecutter")
    assert context
    print("test_load success")


# Generated at 2022-06-21 10:57:17.296786
# Unit test for function dump
def test_dump():
    dump("test/test_replay_dir/", "example_template", "test_context")
    assert os.path.exists("test/test_replay_dir/example_template.json")



# Generated at 2022-06-21 10:57:21.357826
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = '.'+os.sep+'cookiecutter.json'
    context = load(replay_dir, template_name)
    print(context['cookiecutter'])



# Generated at 2022-06-21 10:57:30.828671
# Unit test for function dump

# Generated at 2022-06-21 10:57:41.339044
# Unit test for function dump
def test_dump():
    template_name = 'test_dump'
    context = {"cookiecutter": {
                    "replay": True,
                    "full_name": "Marvin",
                    "email": "marvin@backend.com",
                    "project_name": "marvin",
                    "repo_name": "marvin",
                    "project_short_description": "Marvin",
                    "version": "0.1.0",
                    "release": "0.1.0",
                    "year": "2018",
                    "month": "03",
                    "day": "11",
                    "time": "20:00:00",
                    "year_long": "2018",
                    "author_name": "Marvin",
                    "author_email": "marvin@backend.com"
            }}

# Generated at 2022-06-21 10:57:43.496378
# Unit test for function load
def test_load():
    """test load function"""
    # add unit test for function load
    pass


# Generated at 2022-06-21 10:57:55.229410
# Unit test for function dump
def test_dump():
    # Test data
    replay_dir = "../tests/test-replay"
    template_name = "test"
    context = {"cookiecutter": {"test_str": "str", "test_int": 1, "test_bool": False}, "test_list": ["1", "2", "3"]}

    # Execute function
    dump(replay_dir, template_name, context)

    # Test expected files created
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)

    # Test expected data in file

# Generated at 2022-06-21 10:58:04.086379
# Unit test for function load
def test_load():
    replay_dir = '/home/leiming/Documents/code_augmentation/code_augmentation/examples/function'
    template_name = 'returnStmt'
    context = load(replay_dir, template_name)
    for item in context['cookiecutter']['additional_files']:
        path = os.path.join(replay_dir, '{{cookiecutter.function_name}}/{{cookiecutter.function_name}}' + item['path'])
        print(path)
        file = open(path, 'w+')
        file.write(item['content'])
        file.close()



# Generated at 2022-06-21 10:58:06.018344
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test_replay/'
    #template_name = 'test_template'
    template_name = ''
    context = {'cookiecutter': {'project_name': 'test_project'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-21 10:58:08.148426
# Unit test for function load
def test_load():
    assert load(replay_dir, template_name)


# Generated at 2022-06-21 10:58:11.023596
# Unit test for function load
def test_load():
    templates_dir = "/home/cachem/.cookiecutters"
    template_name = "python-cli"
    context = load(templates_dir, template_name)
    cookiecutter = context["cookiecutter"]
    print(cookiecutter)
    project_name = cookiecutter["project_name"]
    print(project_name)



# Generated at 2022-06-21 10:58:14.878723
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    replay_dir = '/Users/yang/Desktop'
    template_name = 'test'
    assert get_file_name(replay_dir, template_name) == '/Users/yang/Desktop/test.json'



# Generated at 2022-06-21 10:58:17.723315
# Unit test for function load
def test_load():
    """Test for function load."""
    try:
        load('./', 'my_template')
    except ValueError:
        print('Passed.')


# Generated at 2022-06-21 10:58:19.825626
# Unit test for function get_file_name
def test_get_file_name():
    file_name = get_file_name('test/', 'test/test')
    assert file_name == 'test/test.json'


# Generated at 2022-06-21 10:58:23.674968
# Unit test for function load
def test_load():
    dir = '/Users/ahmed/Code/cookiecutter-django/cookiecutter-django/tests/test_data/'
    template_name = 'test'

    context = load(dir, template_name)
    assert context['cookiecutter']['project_name'] == 'test'


# Generated at 2022-06-21 10:58:28.075197
# Unit test for function load
def test_load():
    if 'replay_dir' not in os.environ:
        raise Exception('Need an env variable named "replay_dir"')
    replay_dir = os.environ['replay_dir']
    #template_name = os.environ['template_name']
    template_name = "https://github.com/cookiecutter/cookiecutter-pypackage.git"
    context = load(replay_dir, template_name)
    print(context)

# Generated at 2022-06-21 10:58:38.377614
# Unit test for function get_file_name
def test_get_file_name():
    test_template_name = 'cookiecutter-pypackage'
    test_replay_dir = 'test-dir'
    expected_output = 'test-dir/cookiecutter-pypackage.json'

    ret_name = get_file_name(test_replay_dir, test_template_name)

    assert ret_name == expected_output

# Generated at 2022-06-21 10:58:44.799710
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/tmp/cookiecutter', 'template_name') == '/tmp/cookiecutter/template_name.json'
    assert get_file_name('/tmp/cookiecutter', 'template_name.json') == '/tmp/cookiecutter/template_name.json'
    try:
        get_file_name('/tmp/cookiecutter/denieddir', 'template_name')
        assert False, 'invalid replay directory'
    except IOError:
        pass
    try:
        get_file_name('/tmp/cookiecutter', 1234)
        assert False, 'invalid template name'
    except TypeError:
        pass


# Generated at 2022-06-21 10:58:48.593632
# Unit test for function get_file_name
def test_get_file_name():
    print(get_file_name("replay_dir","template_name"))
    print(get_file_name("replay_dir","template_name.json"))
    print(get_file_name("replay_dir","template_name.json.json"))


# Generated at 2022-06-21 10:58:53.559439
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = 'directory'
    template_name = 'template'
    expected_file_name = replay_dir + '/' + template_name + '.json'
    assert get_file_name(replay_dir, template_name) == expected_file_name


# Generated at 2022-06-21 10:59:04.203751
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.getcwd(), 'replay')
    template_name = 'my_template'
    context = {
        'key1': 'value1',
        'key2': 'value2',
        'cookiecutter': {
            'email': 'test@test.com',
            'full_name': 'test test'
        }
    }
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)

    # Clean up
    os.remove(replay_file)


# Generated at 2022-06-21 10:59:04.943617
# Unit test for function load
def test_load():
    # TODO: to be added.
    pass


# Generated at 2022-06-21 10:59:06.534100
# Unit test for function load
def test_load():
    context = load('replay_dir','template_name')
    assert context == context
    return


# Generated at 2022-06-21 10:59:09.965524
# Unit test for function load
def test_load():
    replay_dir = '{{cookiecutter.project_name}}'
    template_name = '{{cookiecutter.repo_name}}'
    context = load(replay_dir,template_name)
    print (context)


# Generated at 2022-06-21 10:59:15.504872
# Unit test for function load
def test_load():
    replay_dir = '/home/wooyoung/Desktop/Github_repository/cookiecutter/tests/test-replay/'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-21 10:59:19.688309
# Unit test for function load
def test_load():
    """Test function load."""
    assert load(replay_dir='./tests/invalid-replay-dir', template_name='abc') == None

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-21 10:59:37.780136
# Unit test for function load
def test_load():
    # Create replay_dir
    replay_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tests', 'replay')
    if not os.path.exists(replay_dir):
        os.mkdir(replay_dir)
    # Create replay file
    filename = os.path.join(replay_dir, 'test.json')
    with open(filename, 'w') as outfile:
        outfile.write('{"cookiecutter" : {"test" : "test"}}')
    context = load(replay_dir, 'test')
    if not (context.get('cookiecutter') and context.get('cookiecutter').get('test') == "test") :
        raise ValueError('Failed to load replay file with valid context')

# Generated at 2022-06-21 10:59:44.646013
# Unit test for function dump
def test_dump():
    """Test that dump file is created and written out correctly."""
    replay_dir = "/tmp"
    template_name = "howdy"
    context = {"cookiecutter": {"project_name": "howdy"}}
    replay_file = get_file_name(replay_dir, template_name)
    assert dump(replay_dir, template_name, context) is None
    with open(replay_file, 'r') as infile:
        context_check = json.load(infile)
    os.remove(replay_file)

    assert context_check == context


# Generated at 2022-06-21 10:59:51.275591
# Unit test for function load
def test_load():
    d = os.path.abspath(
        os.path.dirname(
            os.path.dirname(__file__)
        )
    )
    replay_dir = os.path.join(d, 'tests', 'test-replay')
    template_name = 'test-template'
    c = load(replay_dir, template_name)

# Generated at 2022-06-21 10:59:57.711901
# Unit test for function dump
def test_dump():
    import jinja2
    import shutil
    import tempfile

    curdir = os.getcwd()
    temp_dir = tempfile.mkdtemp()
    template_dir = os.path.join(temp_dir, 'template')
    replay_dir = os.path.join(temp_dir, 'replay')
    replay_file = get_file_name(replay_dir, 'template')
    test_context = {'cookiecutter': 'This is a context'}


# Generated at 2022-06-21 11:00:06.839681
# Unit test for function dump
def test_dump():
    replay_dir = '../tests/test-dump-dir'
    template_name = 'test'
    context = {
        'test': 'test-context',
        'cookiecutter': {
            'test': 'test-cookiecutter'
        }
    }
    dump(replay_dir, template_name, context)
    # Check file exist
    assert os.path.isfile(get_file_name(replay_dir, template_name))
    # Load and check
    new_context = load(replay_dir, template_name)
    assert new_context['test'] == 'test-context'
    assert new_context['cookiecutter']['test'] == 'test-cookiecutter'
    # Remove file
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-21 11:00:09.861180
# Unit test for function dump
def test_dump():
    try:
        dump('/tmp/replay', 'test', {'cookiecutter': {'test': 'cookiecutter'}})
    except:
        return False
    return True

# Test for function load

# Generated at 2022-06-21 11:00:11.240697
# Unit test for function dump
def test_dump():
    dump('test', 'test', 'test')
    return True


# Generated at 2022-06-21 11:00:18.827434
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.getcwd(), 'test_replay_dump')
    template_name = 'test_replay_dump'
    context = {'cookiecutter': 'additional_context'}
    dump(replay_dir, template_name, context)

    with open('test_replay_dump.json', 'r') as infile:
        content = json.load(infile)

    assert content == {'cookiecutter': 'additional_context'}

    os.remove('test_replay_dump.json')



# Generated at 2022-06-21 11:00:24.065910
# Unit test for function load
def test_load():
    import pprint
    replay_dir = '/Users/m4tz/tmp/cookiecutter-replay'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    pprint.pprint(context)
    # This is not really a unit test, but a way of testing
    # what the configuration file looks like


# Generated at 2022-06-21 11:00:26.279440
# Unit test for function load
def test_load():
    context = load('/Users/fanhuizhi/.cookiecutters', 'fanhuizhi/simple-python-package-template')
    print(context)

# Generated at 2022-06-21 11:00:56.356567
# Unit test for function load
def test_load():
    template_name = 'confucianism'
    replay_dir = 'dummy-replay'
    context = {'cookiecutter': {'full_name': 'Kongzi', 'email': 'kongzi@china.com', 'project_name': 'Daxue'}}
    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)
    assert context_loaded['cookiecutter']['full_name'] == 'Kongzi'
    assert context_loaded['cookiecutter']['email'] == 'kongzi@china.com'
    assert context_loaded['cookiecutter']['project_name'] == 'Daxue'


# Generated at 2022-06-21 11:01:05.374006
# Unit test for function dump
def test_dump():
    # create some context for the replay file
    context = dict(
        cookiecutter={
            'full_name': 'Super Man',
        }
    )

    # create a temp dir to store replay file
    test_dir = '/tmp/cookiecutter-replay'
    template_name = 'creationix/cookiecutter-npm'

    dump(test_dir, template_name, context)

    replay_file = get_file_name(test_dir, template_name)

    assert os.path.exists(replay_file)

    expected_context = context

    assert expected_context == load(test_dir, template_name)

# Generated at 2022-06-21 11:01:08.138841
# Unit test for function load
def test_load():
    replay_dir = 'tests/files/replay'
    template_name = 'tests/files/replay/pytest_project'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-21 11:01:14.037279
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/Users/tanias.k.das/Desktop/cookiecutter/cookiecutter-django"
    template_name = "https://github.com/pydanny/cookiecutter-django"
    replay_file = get_file_name(replay_dir, template_name)

# Generated at 2022-06-21 11:01:21.446470
# Unit test for function dump
def test_dump():
    replay_dir = 'C:\\Users\\v-babus\\AppData\\Local\\Temp\\cookiecutter-test'
    template_name = 'try.json'
    try:
        context = {
            'cookiecutter': {
                'full_name': 'test',
                'email': 'test@test.com',
                'project_name': 'test',
            },
        }
        dump(replay_dir, template_name, context)
    except Exception as e:
        print(e)
        return False

    return True



# Generated at 2022-06-21 11:01:28.483189
# Unit test for function dump
def test_dump():
    """Unit test to verify directory creation and file dump."""
    path = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    dump(path, 'toots', {'cookiecutter': {'toots': 'toots'}})
    path = os.path.join(path, 'toots.json')
    with open(path, 'r') as infile:
        data = json.load(infile)
    assert data == {'cookiecutter': {'toots': 'toots'}}

# Generated at 2022-06-21 11:01:30.426979
# Unit test for function get_file_name
def test_get_file_name():
    get_file_name('dir', 'file')
    get_file_name('dir', 'file.json')

# Generated at 2022-06-21 11:01:41.232234
# Unit test for function load
def test_load():
    import json
    from .cookiecutter_replace import cookiecutter_replace
    from .cookiecutter_replace import dump

    replay_dir = 'tests/files/tests_replay_dir/'
    template_name = 'test'
    context = {}
    context['cookiecutter'] = {'name': 'Saurabh', 'version': '0.1.0'}

    dump(replay_dir, template_name, context)
    data = load(replay_dir, template_name)
    assert data['cookiecutter'] == {'name': 'Saurabh', 'version': '0.1.0'}
    assert 'cookiecutter' in data



# Generated at 2022-06-21 11:01:45.980138
# Unit test for function dump
def test_dump():
    #Check for a dictionary
    dict = {'name': 'Jatin'}
    replay_dir = 'C:/Users/Jatin/Documents/GitHub/Python/Projects/cookiecutter-pypackage/cookiecutter/replay/'
    template_name = 'Jatin'
    dump(replay_dir, template_name, dict)


# Generated at 2022-06-21 11:01:50.842741
# Unit test for function get_file_name
def test_get_file_name():
    template_name_1 = "temp1.json"
    template_name_2 = "temp2"
    replay_dir = "test"

    assert get_file_name(replay_dir,template_name_1) == replay_dir + "/" + template_name_1
    assert get_file_name(replay_dir,template_name_2) == replay_dir + "/" + template_name_2 + ".json"



# Generated at 2022-06-21 11:02:52.675123
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.expanduser('~/.cookiecutter_replay/')
    template_name = 'https://github.com/pydanny/cookiecutter-django'
    result = get_file_name(replay_dir, template_name)
    assert result == os.path.expanduser('~/.cookiecutter_replay/https://github.com/pydanny/cookiecutter-django.json')