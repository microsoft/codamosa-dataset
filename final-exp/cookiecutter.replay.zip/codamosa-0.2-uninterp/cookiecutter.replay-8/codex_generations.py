

# Generated at 2022-06-17 17:22:07.256250
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = './tests/test-load/'
    template_name = 'test-load'
    context = load(replay_dir, template_name)
    assert context == {'cookiecutter': {'full_name': 'Test Load', 'email': 'test@load.com'}}


# Generated at 2022-06-17 17:22:14.470381
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'name': 'test-load-replay'}}
    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)
    assert context == context_loaded


# Generated at 2022-06-17 17:22:24.019820
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:22:32.000775
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example Project'

# Generated at 2022-06-17 17:22:39.178062
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    replay_dir = 'tests/files/replay'
    template_name = 'tests/files/fake-repo-tmpl'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'tests/files/replay/fake-repo-tmpl.json'


# Generated at 2022-06-17 17:22:51.173197
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context['cookiecutter']['github_username'] == 'audreyr'

# Generated at 2022-06-17 17:23:00.032420
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:23:02.476843
# Unit test for function load
def test_load():
    context = load('/home/travis/build/audreyr/cookiecutter/tests/test-replay', 'pypackage')
    assert context['cookiecutter']['project_name'] == 'Python Package'


# Generated at 2022-06-17 17:23:12.599920
# Unit test for function dump
def test_dump():
    """Test for function dump."""
    replay_dir = './tests/files/test-replay'
    template_name = 'test-template'

# Generated at 2022-06-17 17:23:21.199668
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:23:33.980461
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load'
    template_name = 'test-load'

# Generated at 2022-06-17 17:23:37.909192
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'test_key': 'test_value'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:23:43.942903
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name function."""
    replay_dir = '.'
    template_name = 'test'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == './test.json'


# Generated at 2022-06-17 17:23:49.672024
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'test_replay_dir/test_template_name.json'


# Generated at 2022-06-17 17:23:58.053065
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:24:10.388844
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['repo_dir'] == 'fake-repo'
    assert context['cookiecutter']['full_repo_dir'] == 'tests/fake-repo-pre'
    assert context['cookiecutter']['project_slug'] == 'fake-project'
    assert context['cookiecutter']['project_name'] == 'Fake Project'
    assert context['cookiecutter']['project_dir'] == 'fake-project'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'

# Generated at 2022-06-17 17:24:15.088466
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:24:26.532729
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:24:34.955249
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example is a short description of the project.'

# Generated at 2022-06-17 17:24:40.860754
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'

# Generated at 2022-06-17 17:24:50.682246
# Unit test for function dump
def test_dump():
    replay_dir = './tests/test-output/replay'
    template_name = 'test-template'

# Generated at 2022-06-17 17:25:02.721999
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-04-14'
    assert context['cookiecutter']['year'] == '2014'

# Generated at 2022-06-17 17:25:13.279571
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'repo_name' in context['cookiecutter']
    assert 'repo_slug' in context['cookiecutter']
    assert 'project_short_description' in context['cookiecutter']

# Generated at 2022-06-17 17:25:21.851113
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.replay import load

    # Create a replay file
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    template_name = 'gh:audreyr/cookiecutter-pypackage'
    context = cookiecutter(
        template_name,
        no_input=True,
        replay_dir=replay_dir,
        config_file=DEFAULT_CONFIG,
    )

    # Load the replay file
    context = load(replay_dir, template_name)

    # Check that the replay file contains the expected keys
    assert 'cookiecutter' in context

# Generated at 2022-06-17 17:25:32.662377
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A Python package project template.'

# Generated at 2022-06-17 17:25:40.751488
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['release_date'] == '2013-06-01'

# Generated at 2022-06-17 17:25:51.713692
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:25:57.565462
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    assert get_file_name('/tmp', 'foo') == '/tmp/foo.json'
    assert get_file_name('/tmp', 'foo.json') == '/tmp/foo.json'
    assert get_file_name('/tmp', 'foo.bar') == '/tmp/foo.bar.json'

# Generated at 2022-06-17 17:26:00.755085
# Unit test for function load
def test_load():
    context = load('/Users/jianyuan/Desktop/cookiecutter-pypackage-minimal/tests/test-replay', 'cookiecutter-pypackage-minimal')
    print(context)


# Generated at 2022-06-17 17:26:08.078055
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-06'
    assert context['cookiecutter']['year'] == '2014'
    assert context['cookiecutter']['version'] == '0.1.0'

# Generated at 2022-06-17 17:26:21.639700
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:26:29.667941
# Unit test for function dump
def test_dump():
    """Test function dump."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:26:41.468344
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:26:47.631330
# Unit test for function load
def test_load():
    context = load('/Users/lizhe/Documents/GitHub/cookiecutter-pypackage-minimal/tests/test-replay/', 'cookiecutter-pypackage-minimal')
    print(context)


# Generated at 2022-06-17 17:26:53.284070
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'name': 'test-load-replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:27:02.263195
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-tmpl'

# Generated at 2022-06-17 17:27:09.236293
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context == {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com', 'github_username': 'audreyr'}}


# Generated at 2022-06-17 17:27:21.088600
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'full_name': 'Audrey Roy Greenfeld',
                                'email': 'audreyr@example.com',
                                'github_username': 'audreyr',
                                'project_name': 'cookiecutter-pypackage',
                                'project_slug': 'cookiecutter-pypackage',
                                'release_date': '2014-10-06',
                                'year': '2014',
                                'version': '0.1.0'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
   

# Generated at 2022-06-17 17:27:31.185268
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-test'
    assert context['cookiecutter']['release_date'] == '2014-12-31'

# Generated at 2022-06-17 17:27:42.153269
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context

# Generated at 2022-06-17 17:27:54.077422
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)

# Generated at 2022-06-17 17:28:03.582027
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-Pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-10-06'

# Generated at 2022-06-17 17:28:11.627368
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-example'
    assert context['cookiecutter']['release_date'] == '2014-10-27'

# Generated at 2022-06-17 17:28:22.796261
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-06'
    assert context['cookiecutter']['year'] == '2014'
   

# Generated at 2022-06-17 17:28:32.157179
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context['cookiecutter']['github_username'] == 'audreyr'

# Generated at 2022-06-17 17:28:41.550158
# Unit test for function load
def test_load():
    replay_dir = 'tests/files/replay'
    template_name = 'test-replay'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'

# Generated at 2022-06-17 17:28:53.761166
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/files/fake-replay-dir'
    template_name = 'fake-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:29:01.668999
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example is a short description of the project.'

# Generated at 2022-06-17 17:29:09.436129
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:29:17.025485
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'

# Generated at 2022-06-17 17:29:23.412704
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context


# Generated at 2022-06-17 17:29:32.300214
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'repo_name' in context['cookiecutter']
    assert 'project_short_description' in context['cookiecutter']
    assert 'version' in context['cookiecutter']
    assert 'release' in context['cookiecutter']

# Generated at 2022-06-17 17:29:38.626748
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:29:51.234990
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:29:59.100351
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example is a short description.'

# Generated at 2022-06-17 17:30:09.370595
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'

# Generated at 2022-06-17 17:30:16.570952
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Test Project'
    assert context['cookiecutter']['repo_name'] == 'test-project'
    assert context['cookiecutter']['project_slug'] == 'test_project'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'test_user'

# Generated at 2022-06-17 17:30:27.740773
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.replay import load
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.exceptions import FailedHookException

    # Create a project from a local template
    template = 'tests/test-hooks/'
    context = cookiecutter(
        template, no_input=True, replay=True, output_dir='.',
        config_file=DEFAULT_CONFIG, default_config=True
    )

    # Load the replay file
    replay_dir = utils.get_replay_dir()
    replay_file = get_file_name(replay_dir, template)
    context_loaded = load(replay_dir, template)

   

# Generated at 2022-06-17 17:30:39.991181
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example is a short description'

# Generated at 2022-06-17 17:30:52.400616
# Unit test for function load
def test_load():
    context = load('/home/ubuntu/cookiecutter-pypackage/tests/test-replay', 'cookiecutter-pypackage')
    assert context['cookiecutter']['project_name'] == 'Test Project'
    assert context['cookiecutter']['repo_name'] == 'test_project'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['author_name'] == 'Your Name'
    assert context['cookiecutter']['email'] == 'your@email.com'
    assert context['cookiecutter']['version'] == '0.1.0'
    assert context['cookiecutter']['release'] == '0.1.0'

# Generated at 2022-06-17 17:30:57.798406
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'


# Generated at 2022-06-17 17:31:01.585469
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'test'
    replay_dir = 'test_dir'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:31:07.644074
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:31:11.040934
# Unit test for function load
def test_load():
    context = load('/home/travis/build/audreyr/cookiecutter-pypackage/tests/test-replay', 'cookiecutter-pypackage')
    assert context['cookiecutter']['project_name'] == 'Cookiecutter PyPackage'


# Generated at 2022-06-17 17:31:20.385700
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:31:32.884228
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:31:43.223187
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {
        'cookiecutter': {
            'full_name': 'Test Load Replay',
            'email': 'test@load.replay',
            'github_username': 'test-load-replay',
            'project_name': 'test-load-replay',
            'project_slug': 'test_load_replay',
            'project_short_description': 'Test load replay',
            'pypi_username': 'test-load-replay',
            'release_date': '2015-12-25',
            'year': '2015',
            'version': '0.1.0',
        }
    }

# Generated at 2022-06-17 17:31:52.874212
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/files/replay'
    template_name = 'tests/files/replay/cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['author_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['description'] == 'A Python package project template.'

# Generated at 2022-06-17 17:32:01.498246
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example is a short description of the project.'