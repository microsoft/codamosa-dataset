

# Generated at 2022-06-17 17:22:25.850894
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "test_replay_dir"
    template_name = "test_template_name"
    assert get_file_name(replay_dir, template_name) == "test_replay_dir/test_template_name.json"


# Generated at 2022-06-17 17:22:29.561534
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'replay_dir/template_name.json'


# Generated at 2022-06-17 17:22:35.249393
# Unit test for function dump
def test_dump():
    """Test for function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:22:45.456571
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example is a short description'

# Generated at 2022-06-17 17:22:49.811813
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    assert get_file_name(replay_dir, template_name) == 'test_replay_dir/test_template_name.json'


# Generated at 2022-06-17 17:22:56.468791
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name function."""
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'replay_dir/template_name.json'

    template_name = 'template_name.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'replay_dir/template_name.json'


# Generated at 2022-06-17 17:23:04.777929
# Unit test for function load
def test_load():
    replay_dir = 'C:\\Users\\Administrator\\Desktop\\cookiecutter-pypackage-minimal\\cookiecutter-pypackage-minimal'
    template_name = 'cookiecutter.json'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-17 17:23:10.439387
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter import utils
    from cookiecutter.replay import dump, load

    # Create a temporary project directory
    project_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'files', 'test-replay')
    project_dir = os.path.normpath(project_dir)

    # Create a temporary replay directory
    replay_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'files', 'test-replay-replay')
    replay_dir = os.path.normpath(replay_dir)

    # Create a temporary

# Generated at 2022-06-17 17:23:17.360175
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'

# Generated at 2022-06-17 17:23:27.098655
# Unit test for function dump
def test_dump():
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'

# Generated at 2022-06-17 17:23:39.088426
# Unit test for function load
def test_load():
    """Test load function."""
    context = load('/home/joe/cookiecutter-pypackage', 'cookiecutter-pypackage')
    assert context['cookiecutter']['project_name'] == 'Cookiecutter PyPackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['author_name'] == 'Joe'
    assert context['cookiecutter']['email'] == 'joe@example.com'
    assert context['cookiecutter']['description'] == 'A Python package project template.'
    assert context['cookiecutter']['domain_name'] == 'example.com'
    assert context['cookiecutter']['version'] == '0.1.0'

# Generated at 2022-06-17 17:23:52.332534
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)

# Generated at 2022-06-17 17:24:02.054582
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:24:09.158847
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:24:14.360197
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load'
    context = {'cookiecutter': {'name': 'test-load'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:24:20.601764
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:24:30.375589
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:24:38.098341
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context['cookiecutter']['github_username'] == 'audreyr'

# Generated at 2022-06-17 17:24:50.578313
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:25:02.650946
# Unit test for function dump
def test_dump():
    """Test function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:25:13.895552
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:25:22.031484
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:25:28.249465
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load'
    template_name = 'test-load'
    context = {
        'cookiecutter': {
            'full_name': 'Test Load',
            'email': 'test@load.com',
            'project_name': 'test-load',
            'project_slug': 'test_load',
            'project_short_description': 'Test load',
            'pypi_username': 'test_load',
            'release_date': '2015-01-01',
            'version': '0.1.0',
            'year': '2015',
        }
    }
    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)
    assert context == context

# Generated at 2022-06-17 17:25:38.182140
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-test'
    assert context['cookiecutter']['release_date'] == '2014-10-27'

# Generated at 2022-06-17 17:25:51.052876
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'test'

# Generated at 2022-06-17 17:25:54.291900
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'test_key': 'test_value'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, template_name + '.json'))


# Generated at 2022-06-17 17:25:59.148259
# Unit test for function load
def test_load():
    replay_dir = '/Users/yunfei/Documents/GitHub/cookiecutter-pypackage/tests/test-replay'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-17 17:26:00.483120
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-17 17:26:07.842469
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)

# Generated at 2022-06-17 17:26:11.232434
# Unit test for function load
def test_load():
    context = load('/Users/jianxin/Desktop/cookiecutter-pypackage', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:26:23.180227
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:26:27.903551
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'repo_name' in context['cookiecutter']
    assert 'project_short_description' in context['cookiecutter']
    assert 'version' in context['cookiecutter']
    assert 'release' in context['cookiecutter']
    assert 'pypi_username' in context['cookiecutter']

# Generated at 2022-06-17 17:26:34.594781
# Unit test for function load
def test_load():
    context = load('/Users/yunfei/Desktop/cookiecutter-pypackage', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:26:42.754601
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = os.path.join(os.path.dirname(__file__), 'test_replay')
    template_name = 'test_template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Test User'
    assert context['cookiecutter']['email'] == 'test@example.com'
    assert context['cookiecutter']['project_name'] == 'Test Project'
    assert context['cookiecutter']['project_slug'] == 'test-project'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['release_date'] == '2015-06-01'

# Generated at 2022-06-17 17:26:54.589633
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = "tests/test-load-replay-dir"
    template_name = "test-load-template-name"

# Generated at 2022-06-17 17:26:59.689531
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:27:09.913637
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:27:21.126850
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/files/fake-replay-dir'
    template_name = 'fake-template-name'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'


# Generated at 2022-06-17 17:27:31.185719
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:27:36.416745
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import json
    import os
    import shutil
    import tempfile

    from cookiecutter.replay import load

    template_name = 'test_template'
    context = {'cookiecutter': {'test_key': 'test_value'}}

    replay_dir = tempfile.mkdtemp()
    replay_file = os.path.join(replay_dir, '{}.json'.format(template_name))

    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    assert load(replay_dir, template_name) == context

    shutil.rmtree(replay_dir)



# Generated at 2022-06-17 17:27:47.849049
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Pypackage'


# Generated at 2022-06-17 17:27:58.002464
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'full_name': 'Test User', 'email': 'test@example.com'}}

    dump(replay_dir, template_name, context)

    assert os.path.exists(get_file_name(replay_dir, template_name))

    os.remove(get_file_name(replay_dir, template_name))
    os.rmdir(replay_dir)


# Generated at 2022-06-17 17:28:04.107113
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-load-replay-dir'
    template_name = 'test-load-replay-dir'
    context = {'cookiecutter': {'name': 'test-load-replay-dir'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:28:10.054587
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.replay import load

    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'

    # Generate a project
    cookiecutter(template_name, replay_dir=replay_dir)

    # Load the replay file
    context = load(replay_dir, template_name)

    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test Project'

# Generated at 2022-06-17 17:28:11.968336
# Unit test for function load
def test_load():
    context = load('/Users/jianyuan/Desktop/cookiecutter-pypackage', 'cookiecutter-pypackage')
    print(context)


# Generated at 2022-06-17 17:28:18.001743
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/Users/yunfei/Desktop/cookiecutter-pypackage-minimal/tests/test_replay', 'cookiecutter-pypackage-minimal')
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Pypackage Minimal'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-pypackage-minimal'
    assert context['cookiecutter']['author_name'] == 'Yunfei'
    assert context['cookiecutter']['email'] == 'yunfei@example.com'
    assert context['cookiecutter']['description'] == 'A minimal Python package project.'

# Generated at 2022-06-17 17:28:22.130797
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-pypackage'

# Generated at 2022-06-17 17:28:25.710386
# Unit test for function load
def test_load():
    context = load('/Users/yunfeng/Documents/GitHub/cookiecutter-pypackage/tests/test-replay', 'cookiecutter-pypackage')
    print(context)


# Generated at 2022-06-17 17:28:28.900523
# Unit test for function load
def test_load():
    """Test function load."""
    context = load('/home/michael/Desktop/cookiecutter-pypackage-minimal/', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:28:40.676405
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:28:55.023286
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['release_date'] == '2013-06-01'

# Generated at 2022-06-17 17:29:05.452153
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'

# Generated at 2022-06-17 17:29:11.015077
# Unit test for function dump
def test_dump():
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    context = {'cookiecutter': {'test_key': 'test_value'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, template_name + '.json'))


# Generated at 2022-06-17 17:29:13.663947
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/Users/jianyuan/Desktop/cookiecutter-pypackage-minimal', 'cookiecutter-pypackage-minimal')
    print(context)


# Generated at 2022-06-17 17:29:25.687360
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:29:34.074367
# Unit test for function load
def test_load():
    replay_dir = './tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A Python package project template.'

# Generated at 2022-06-17 17:29:42.808578
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/files/replay'
    template_name = 'foobar'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-Pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-10-06'

# Generated at 2022-06-17 17:29:53.909853
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Test User'
    assert context['cookiecutter']['email'] == 'test@example.com'
    assert context['cookiecutter']['project_name'] == 'Test Project'
    assert context['cookiecutter']['project_slug'] == 'test_project'
    assert context['cookiecutter']['project_short_description'] == 'Test Project Description'
    assert context['cookiecutter']['release_date'] == '2015-05-01'
    assert context['cookiecutter']['year'] == '2015'

# Generated at 2022-06-17 17:30:00.067177
# Unit test for function load
def test_load():
    """Test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), 'replay')
    template_name = 'test_template'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-17 17:30:10.418637
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example Project'
    assert context

# Generated at 2022-06-17 17:30:24.376589
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'

# Generated at 2022-06-17 17:30:33.132442
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:30:40.728117
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-27'

# Generated at 2022-06-17 17:30:46.829338
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/home/david/cookiecutter-pypackage', 'cookiecutter-pypackage')
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'


# Generated at 2022-06-17 17:30:53.849189
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:31:02.191035
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:31:11.693571
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'

# Generated at 2022-06-17 17:31:22.200132
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)

# Generated at 2022-06-17 17:31:32.917133
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {
        'cookiecutter': {
            'full_name': 'Test Load Replay',
            'email': 'test@load.replay',
            'github_username': 'test-load-replay',
            'project_name': 'test-load-replay',
            'project_slug': 'test_load_replay',
            'project_short_description': 'Test load replay',
            'pypi_username': 'test-load-replay',
            'release_date': '2015-12-30',
            'version': '0.1.0',
            'open_source_license': 'MIT license',
        }
    }

   

# Generated at 2022-06-17 17:31:43.222827
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-27'
    assert context['cookiecutter']['year'] == '2014'
    assert context

# Generated at 2022-06-17 17:31:51.900608
# Unit test for function load
def test_load():
    """Test load function."""
    context = load('/Users/yunfei/Desktop/cookiecutter-pypackage-minimal/', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:32:00.763788
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = 'tests/test-replay'
    template_name = 'test_template'

# Generated at 2022-06-17 17:32:04.252556
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:32:13.377355
# Unit test for function load
def test_load():
    """Unit test for function load."""
    # Test for invalid template name
    try:
        load('replay', 123)
        assert False
    except TypeError:
        assert True

    # Test for invalid context
    try:
        load('replay', 'template_name')
        assert False
    except ValueError:
        assert True

    # Test for valid context
    context = {'cookiecutter': {'project_name': 'test'}}
    dump('replay', 'template_name', context)
    assert load('replay', 'template_name') == context


# Generated at 2022-06-17 17:32:17.364566
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/files/replay'
    template_name = 'tests/files/replay/test_replay'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'

# Generated at 2022-06-17 17:32:24.909605
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'