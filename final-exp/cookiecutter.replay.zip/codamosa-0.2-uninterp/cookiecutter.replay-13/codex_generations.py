

# Generated at 2022-06-17 17:22:34.591289
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'

# Generated at 2022-06-17 17:22:43.444614
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com'}}

    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)

    with open(replay_file, 'r') as infile:
        data = json.load(infile)

    assert data == context


# Generated at 2022-06-17 17:22:49.391188
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name function."""
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'replay_dir/template_name.json'


# Generated at 2022-06-17 17:22:58.913391
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'

# Generated at 2022-06-17 17:23:06.058828
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay-dir'
    template_name = 'test-load-template-name'
    context = {
        'cookiecutter': {
            'project_name': 'test-load-project-name',
            'repo_name': 'test-load-repo-name',
            'author_name': 'test-load-author-name',
            'email': 'test-load-email',
            'description': 'test-load-description',
            'domain_name': 'test-load-domain-name',
            'version': 'test-load-version',
            'open_source_license': 'test-load-open-source-license',
            'year': 'test-load-year',
        }
    }

# Generated at 2022-06-17 17:23:16.916645
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context

# Generated at 2022-06-17 17:23:23.603884
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'name': 'test-name'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:23:28.210139
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    replay_dir = 'tests/files/fake-replay-dir'
    template_name = 'fake-template-name'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'tests/files/fake-replay-dir/fake-template-name.json'


# Generated at 2022-06-17 17:23:38.784634
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'

# Generated at 2022-06-17 17:23:45.576769
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'test_replay_dir/test_template_name.json'


# Generated at 2022-06-17 17:23:57.260657
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:24:04.952518
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'


# Generated at 2022-06-17 17:24:08.888495
# Unit test for function load
def test_load():
    context = load('/Users/yunjie/Desktop/cookiecutter-pypackage-minimal/tests/test-replay', 'cookiecutter-pypackage-minimal')
    print(context)


# Generated at 2022-06-17 17:24:17.598790
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:24:23.338643
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/tmp', 'test') == '/tmp/test.json'
    assert get_file_name('/tmp', 'test.json') == '/tmp/test.json'
    assert get_file_name('/tmp', 'test.json.json') == '/tmp/test.json.json'


# Generated at 2022-06-17 17:24:29.080913
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert 'project_name' in context['cookiecutter']
    assert context['cookiecutter']['project_name'] == 'test-project'


# Generated at 2022-06-17 17:24:37.106092
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('./tests/test-replay', 'test-template')
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context['cookiecutter']['release_date'] == '2014-10-06'
    assert context['cookiecutter']['year']

# Generated at 2022-06-17 17:24:50.422486
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-10-03'
    assert context['cookiecutter']['version'] == '0.1.0'
   

# Generated at 2022-06-17 17:25:02.576933
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:25:07.509998
# Unit test for function load
def test_load():
    context = load('/Users/yunfeiguo/Documents/GitHub/cookiecutter-data-science/tests/test-replay', 'test-replay')
    print(context)


# Generated at 2022-06-17 17:25:12.299375
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'


# Generated at 2022-06-17 17:25:21.688614
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:25:26.883531
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Test Load Replay'
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:25:36.803367
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-27'
    assert context['cookiecutter']['year'] == '2014'
    assert context

# Generated at 2022-06-17 17:25:39.537931
# Unit test for function load
def test_load():
    context = load('/home/travis/build/cookiecutter-django/cookiecutter-django/tests/test_replay', 'cookiecutter-django')
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Django'


# Generated at 2022-06-17 17:25:48.626024
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:25:54.902186
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-test'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
   

# Generated at 2022-06-17 17:25:59.040915
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/Users/jianghao/Desktop/cookiecutter-pypackage-minimal/', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:26:03.166324
# Unit test for function load
def test_load():
    replay_dir = 'test_replay'
    template_name = 'test_template'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)
    assert context == context_loaded
    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-17 17:26:07.306089
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-load-replay-dir'
    template_name = 'test-load-template'
    context = {'cookiecutter': {'test-load-key': 'test-load-value'}}

    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)

    assert context == loaded_context


# Generated at 2022-06-17 17:26:16.329718
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-10-03'
    assert context['cookiecutter']['version'] == '0.1.0'

# Generated at 2022-06-17 17:26:18.496896
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/Users/jianghao/Desktop/cookiecutter-pypackage-minimal/', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:26:25.434389
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'test_template'
    replay_dir = 'tests/test-replay'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:26:34.766931
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/files/replay'
    template_name = 'tests/files/replay/default'
    context = load(replay_dir, template_name)

# Generated at 2022-06-17 17:26:42.794213
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:26:51.418265
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load'
    template_name = 'test-load'
    context = {'cookiecutter': {'name': 'test-load'}}
    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)
    assert context_loaded == context

# Generated at 2022-06-17 17:27:01.617033
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:27:05.316073
# Unit test for function load
def test_load():
    # Test for invalid template name
    try:
        load('replay_dir', 123)
        assert False
    except TypeError:
        assert True

    # Test for invalid context
    try:
        load('replay_dir', 'template_name')
        assert False
    except ValueError:
        assert True

    # Test for valid context
    context = {'cookiecutter': {'full_name': 'Test'}}
    assert load('replay_dir', 'template_name') == context


# Generated at 2022-06-17 17:27:14.400131
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:27:21.837328
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:27:29.516459
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:27:35.841139
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'

# Generated at 2022-06-17 17:27:40.501482
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter.main import cookiecutter
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = cookiecutter(template_name, replay_dir=replay_dir)
    context_loaded = load(replay_dir, template_name)
    assert context == context_loaded

# Generated at 2022-06-17 17:27:52.604953
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:27:56.109487
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'cookiecutter-pypackage'
    context = load('/Users/yunfei/Documents/GitHub/cookiecutter-pypackage', template_name)
    print(context)


# Generated at 2022-06-17 17:28:05.377525
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-10-06'

# Generated at 2022-06-17 17:28:13.211726
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-test'
    assert context['cookiecutter']['release_date'] == '2014-12-01'

# Generated at 2022-06-17 17:28:15.349251
# Unit test for function load
def test_load():
    context = load('/Users/yuyang/Desktop/cookiecutter-pypackage-minimal/cookiecutter-pypackage-minimal', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:28:26.456441
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'repo_name' in context['cookiecutter']
    assert 'project_short_description' in context['cookiecutter']
    assert 'version' in context['cookiecutter']
    assert 'release' in context['cookiecutter']
    assert 'year' in context['cookiecutter']
    assert 'month' in context['cookiecutter']

# Generated at 2022-06-17 17:28:33.778302
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Test Project'
    assert context['cookiecutter']['project_slug'] == 'test_project'
    assert context['cookiecutter']['author_name'] == 'Test Author'
    assert context['cookiecutter']['email'] == 'test@example.com'
    assert context['cookiecutter']['description'] == 'Test description'
    assert context['cookiecutter']['domain_name'] == 'example.com'
    assert context['cookiecutter']['version'] == '0.1.0'

# Generated at 2022-06-17 17:28:42.481326
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'

# Generated at 2022-06-17 17:28:54.118377
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'

# Generated at 2022-06-17 17:29:01.807231
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context['cookiecutter']['github_username'] == 'audreyr'

# Generated at 2022-06-17 17:29:11.506617
# Unit test for function load
def test_load():
    assert load('/home/travis/build/audreyr/cookiecutter/tests/test-replay', 'test-template') == {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com', 'github_username': 'audreyr', 'project_name': 'cookiecutter-pypackage', 'project_slug': 'cookiecutter-pypackage', 'release_date': '2014-10-06', 'version': '0.1.0', 'open_source_license': 'MIT license'}}


# Generated at 2022-06-17 17:29:17.990660
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:29:28.989046
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'test-template'

# Generated at 2022-06-17 17:29:33.709275
# Unit test for function load
def test_load():
    # Test for invalid template name
    try:
        load('replay_dir', 123)
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised')

    # Test for missing cookiecutter key
    try:
        load('replay_dir', 'template_name')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')



# Generated at 2022-06-17 17:29:38.524415
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'full_name': 'Test Name', 'email': 'test@example.com'}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:29:44.634604
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/Users/zhaoyu/Documents/GitHub/cookiecutter-pypackage/tests/test-replay', 'cookiecutter-pypackage')
    print(context)


# Generated at 2022-06-17 17:29:54.486077
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-10-06'

# Generated at 2022-06-17 17:30:05.454667
# Unit test for function dump
def test_dump():
    """Test function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'cookiecutter-pypackage',
            'project_slug': 'cookiecutter-pypackage',
            'release_date': '2014-10-27',
            'year': '2014'
        }
    }
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))

# Unit test

# Generated at 2022-06-17 17:30:06.932624
# Unit test for function load
def test_load():
    """Test load function."""
    assert load('/tmp/', 'test_load') == {'cookiecutter': {}}

# Generated at 2022-06-17 17:30:15.801945
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-06'

# Generated at 2022-06-17 17:30:26.915111
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'repo_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'project_short_description' in context['cookiecutter']
    assert 'pypi_username' in context['cookiecutter']
    assert 'github_username' in context['cookiecutter']
    assert 'version' in context['cookiecutter']

# Generated at 2022-06-17 17:30:34.457716
# Unit test for function dump
def test_dump():
    """Test function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:30:42.855351
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:30:52.736904
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-example'
    assert context['cookiecutter']['release_date'] == '2014-10-27'

# Generated at 2022-06-17 17:31:01.971026
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:31:03.863005
# Unit test for function load
def test_load():
    """Unit test for function load"""
    assert load('/tmp/', 'test') == {'cookiecutter': {}}


# Generated at 2022-06-17 17:31:12.894362
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:31:22.888244
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:31:32.998775
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'

# Generated at 2022-06-17 17:31:43.223076
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'

# Generated at 2022-06-17 17:31:51.492347
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-10-06'
    assert context['cookiecutter']['version'] == '0.1.0'
   

# Generated at 2022-06-17 17:31:54.815581
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/Users/yunfei/Desktop/cookiecutter-pypackage', 'cookiecutter.json')
    print(context)


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-17 17:32:03.078825
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:32:14.587854
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:32:20.741010
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:32:31.444551
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.dirname(__file__), '../tests/test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'