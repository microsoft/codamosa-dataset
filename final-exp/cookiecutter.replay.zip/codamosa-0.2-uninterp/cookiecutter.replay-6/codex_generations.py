

# Generated at 2022-06-17 17:22:01.602414
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context

# Generated at 2022-06-17 17:22:07.453625
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'tests/files/test-template'
    context = {'cookiecutter': {'full_name': 'Test User'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:22:14.552781
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:22:19.385710
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:22:25.314590
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = os.path.join(os.path.dirname(__file__), 'tests/files/')
    template_name = 'test_template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username']

# Generated at 2022-06-17 17:22:32.866878
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:22:39.648067
# Unit test for function dump
def test_dump():
    replay_dir = 'replay'
    template_name = 'test_template'
    context = {'cookiecutter': {'replay': True}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:22:45.609342
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'replay_dir/template_name.json'


# Generated at 2022-06-17 17:22:52.764906
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'

# Generated at 2022-06-17 17:23:01.551972
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'test-template'

# Generated at 2022-06-17 17:23:13.536064
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:23:24.879671
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A Python package project template.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:23:27.850078
# Unit test for function load
def test_load():
    """Test load function."""
    context = load('/Users/yunfei/Documents/GitHub/cookiecutter-pypackage/tests/test-replay', 'test-replay')
    print(context)


# Generated at 2022-06-17 17:23:34.892969
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}

    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context



# Generated at 2022-06-17 17:23:41.303569
# Unit test for function load
def test_load():
    context = load('/home/travis/build/audreyr/cookiecutter/tests/test-output/', 'test-template')
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['project_short_description'] == 'A command-line utility that creates projects from cookiecutters (project templates). E.g. Python package projects, jQuery plugin projects.'

# Generated at 2022-06-17 17:23:47.940208
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'full_name': 'Test User', 'email': 'test@example.com'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:23:56.701950
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'

# Generated at 2022-06-17 17:23:59.830307
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/Users/zhaoyang/Desktop/cookiecutter-pypackage-minimal/tests/test_replay', 'cookiecutter-pypackage-minimal')
    print(context)


# Generated at 2022-06-17 17:24:10.989256
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2013-06-01'
    assert context['cookiecutter']['version'] == '0.1.0'
   

# Generated at 2022-06-17 17:24:18.419022
# Unit test for function dump
def test_dump():
    """Test function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:24:29.841352
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'

# Generated at 2022-06-17 17:24:37.756621
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {
        'cookiecutter': {
            'full_name': 'Test Load',
            'email': 'test@load.com',
            'github_username': 'test-load',
            'project_name': 'test-load',
            'project_slug': 'test_load',
            'project_short_description': 'Test Load',
            'pypi_username': 'test-load',
            'release_date': '2015-01-01',
            'version': '0.1.0',
            'year': '2015',
        }
    }
    dump(replay_dir, template_name, context)

# Generated at 2022-06-17 17:24:50.502891
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example is a short description'

# Generated at 2022-06-17 17:24:56.981689
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay/'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Test User'


# Generated at 2022-06-17 17:25:08.227464
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'

# Generated at 2022-06-17 17:25:15.569885
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:25:22.652516
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'

# Generated at 2022-06-17 17:25:33.149898
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'

# Generated at 2022-06-17 17:25:36.362251
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/Users/yue/Desktop/cookiecutter-pypackage', 'cookiecutter-pypackage')
    print(context)


# Generated at 2022-06-17 17:25:44.023041
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = '/Users/jianyuan/Desktop/cookiecutter-pypackage-minimal/cookiecutter-pypackage-minimal'
    template_name = 'cookiecutter-pypackage-minimal'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-17 17:25:49.375391
# Unit test for function load
def test_load():
    replay_dir = 'replay'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-17 17:25:52.559703
# Unit test for function load
def test_load():
    """Test function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Test Load Replay'
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:26:02.940796
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)

# Generated at 2022-06-17 17:26:09.577893
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example Project'
    assert context['cookiecutter']['release_date'] == '2014-12-17'
    assert context

# Generated at 2022-06-17 17:26:14.524057
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:26:17.721008
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/Users/jianhuashao/Desktop/cookiecutter-pypackage-minimal', 'cookiecutter-pypackage-minimal')
    print(context)


# Generated at 2022-06-17 17:26:25.246000
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:26:29.063719
# Unit test for function load
def test_load():
    """Test load function."""
    context = load('/home/mohamed/Desktop/cookiecutter-pypackage-minimal/', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:26:41.468420
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'full_name': 'Test User',
                                'email': 'test@example.com',
                                'github_username': 'testuser',
                                'project_name': 'Test Project',
                                'project_slug': 'test-project',
                                'project_short_description': 'Test project',
                                'pypi_username': 'testuser',
                                'release_date': '2014-12-25',
                                'year': '2014'}}

    dump(replay_dir, template_name, context)

# Generated at 2022-06-17 17:26:53.434623
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile
    import shutil
    import json

    template_name = 'test_template'
    context = {'cookiecutter': {'test_key': 'test_value'}}

    replay_dir = tempfile.mkdtemp()
    try:
        dump(replay_dir, template_name, context)
        replay_file = get_file_name(replay_dir, template_name)
        with open(replay_file, 'r') as infile:
            loaded_context = json.load(infile)
        assert loaded_context == context
    finally:
        shutil.rmtree(replay_dir)


# Generated at 2022-06-17 17:27:05.202997
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:27:14.402720
# Unit test for function load
def test_load():
    """Test load function."""
    import os
    import shutil
    import tempfile
    from cookiecutter.replay import load

    template_name = 'test_template'

# Generated at 2022-06-17 17:27:23.617360
# Unit test for function load
def test_load():
    context = load('/home/travis/build/cookiecutter-django/cookiecutter-django/tests/test-replay', 'cookiecutter-django')
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Django'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-django'
    assert context['cookiecutter']['author_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['description'] == 'A cookiecutter template for creating Django projects quickly.'
    assert context['cookiecutter']['domain_name'] == 'example.com'

# Generated at 2022-06-17 17:27:32.989279
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-example'
    assert context['cookiecutter']['release_date'] == '2014-12-01'

# Generated at 2022-06-17 17:27:36.468347
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com'}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile('tests/test-output/replay/tests-fake-repo-pre-.json')


# Generated at 2022-06-17 17:27:40.786734
# Unit test for function load
def test_load():
    template_name = 'test'
    replay_dir = 'test'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:27:52.702608
# Unit test for function load
def test_load():
    """Test load function."""
    from cookiecutter import replay
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = replay.load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-example'

# Generated at 2022-06-17 17:27:56.488753
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-example'
    assert context['cookiecutter']['release_date'] == '2014-09-16'

# Generated at 2022-06-17 17:28:05.704351
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example Project'

# Generated at 2022-06-17 17:28:08.288276
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:28:28.902952
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'repo_name' in context['cookiecutter']
    assert 'project_short_description' in context['cookiecutter']
    assert 'version' in context['cookiecutter']
    assert 'use_pytest' in context['cookiecutter']
    assert 'use_pypi_deployment_with_travis'

# Generated at 2022-06-17 17:28:34.944665
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:28:42.377471
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:28:45.903067
# Unit test for function load
def test_load():
    context = load('/Users/yunfei/Desktop/cookiecutter-pypackage-minimal/cookiecutter-pypackage-minimal', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:28:56.108078
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'

# Generated at 2022-06-17 17:29:06.256980
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:29:15.480234
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:29:21.949146
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import tempfile
    import shutil
    import os

    replay_dir = tempfile.mkdtemp()
    template_name = 'test_template'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    shutil.rmtree(replay_dir)

# Generated at 2022-06-17 17:29:31.484982
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = {
        'cookiecutter': {
            'full_name': 'Test User',
            'email': 'test@example.com',
            'github_username': 'testuser',
            'project_name': 'Test Project',
            'project_slug': 'test_project',
            'project_short_description': 'Test project description',
            'pypi_username': 'testuser',
            'release_date': '2015-06-01',
            'year': '2015',
            'version': '0.1.0',
            'open_source_license': 'MIT license'
        }
    }
    dump(replay_dir, template_name, context)

# Generated at 2022-06-17 17:29:41.626362
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:30:04.845571
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'full_name': 'Test User', 'email': 'test@example.com'}}
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.exists(replay_file)

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    assert context['cookiecutter']['full_name'] == 'Test User'
    assert context['cookiecutter']['email'] == 'test@example.com'

    os.remove(replay_file)


# Generated at 2022-06-17 17:30:14.523156
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:30:26.076519
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['version']

# Generated at 2022-06-17 17:30:30.090558
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context


# Generated at 2022-06-17 17:30:34.024206
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:30:36.736284
# Unit test for function load
def test_load():
    """Unit test for function load."""
    # Test for invalid template name
    try:
        load('/tmp', None)
        assert False
    except TypeError:
        assert True

    # Test for invalid context
    try:
        load('/tmp', 'template_name')
        assert False
    except ValueError:
        assert True

    # Test for valid context
    try:
        context = load('/tmp', 'template_name')
        assert context['cookiecutter']
    except ValueError:
        assert False


# Generated at 2022-06-17 17:30:39.549868
# Unit test for function load
def test_load():
    """Test load function."""
    context = load('/Users/jianghao/Documents/GitHub/cookiecutter-pypackage/tests/test-replay', 'test-template')
    assert context['cookiecutter']['project_name'] == 'Test Project'


# Generated at 2022-06-17 17:30:48.707717
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'test_template'
    replay_dir = 'test_replay_dir'
    context = {'cookiecutter': {'test_key': 'test_value'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(get_file_name(replay_dir, template_name))
    os.rmdir(replay_dir)


# Generated at 2022-06-17 17:30:56.981456
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:31:02.883108
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'

# Generated at 2022-06-17 17:31:17.984189
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-17 17:31:23.653779
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'

# Generated at 2022-06-17 17:31:33.340316
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'

# Generated at 2022-06-17 17:31:40.441484
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:31:52.192736
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'