

# Generated at 2022-06-17 17:22:05.189429
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'cookiecutter-pypackage',
            'project_slug': 'cookiecutter-pypackage',
            'release_date': '2014-10-27',
            'year': '2014'
        }
    }
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))

# Unit

# Generated at 2022-06-17 17:22:11.952913
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context['cookiecutter']['version']

# Generated at 2022-06-17 17:22:15.528341
# Unit test for function load
def test_load():
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    context = {'cookiecutter': 'cookiecutter'}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context

# Generated at 2022-06-17 17:22:21.603232
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'name': 'test-load-replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:22:24.702674
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/Users/yunfei/Desktop/cookiecutter-pypackage-minimal', 'cookiecutter-pypackage-minimal')
    print(context)


# Generated at 2022-06-17 17:22:32.565860
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'

# Generated at 2022-06-17 17:22:38.420949
# Unit test for function load
def test_load():
    """Test load function."""
    context = load('/home/travis/build/audreyr/cookiecutter/tests/test-replay', 'pypackage')
    assert context['cookiecutter']['project_name'] == 'Cookiecutter PyPackage'


# Generated at 2022-06-17 17:22:50.898666
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:22:59.768137
# Unit test for function load
def test_load():
    context = load('./tests/test-replay', 'test-template')
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-06'
    assert context['cookiecutter']['year'] == '2014'
    assert context['cookiecutter']['version'] == '0.7.2'

# Generated at 2022-06-17 17:23:06.734762
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-10-06'

# Generated at 2022-06-17 17:23:16.973199
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)

# Generated at 2022-06-17 17:23:26.753857
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'

# Generated at 2022-06-17 17:23:34.095944
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'test_load'
    template_name = 'test_load'
    context = {'cookiecutter': {'test_load': 'test_load'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:23:40.923422
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-Pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:23:52.916629
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'

# Generated at 2022-06-17 17:24:02.072553
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example is a short description'

# Generated at 2022-06-17 17:24:11.698647
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A Python package project template.'

# Generated at 2022-06-17 17:24:18.590793
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-pypackage'

# Generated at 2022-06-17 17:24:29.009057
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-10-06'

# Generated at 2022-06-17 17:24:37.042743
# Unit test for function load
def test_load():
    """Test load function."""
    # Create a replay file
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:24:50.986651
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-example'
    assert context['cookiecutter']['release_date'] == '2013-06-01'

# Generated at 2022-06-17 17:25:02.925626
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-test'
    assert context['cookiecutter']['release_date'] == '2014-09-26'

# Generated at 2022-06-17 17:25:13.327631
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'

# Generated at 2022-06-17 17:25:19.964896
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay-dir'
    template_name = 'test-load-replay-file'
    context = {'cookiecutter': {'full_name': 'Test Load Replay File'}}
    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert context == loaded_context
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:25:27.797889
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example is a short description'

# Generated at 2022-06-17 17:25:37.859975
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'test-template'
    context = {
        'cookiecutter': {
            'full_name': 'Test User',
            'email': 'test@example.com',
            'github_username': 'testuser',
            'project_name': 'Test Project',
            'project_slug': 'test_project',
            'project_short_description': 'Test Project Description',
            'pypi_username': 'testuser',
            'release_date': '2015-05-05',
            'year': '2015',
            'version': '0.1.0',
            'select_license': 'MIT license',
        }
    }

    dump(replay_dir, template_name, context)



# Generated at 2022-06-17 17:25:50.932465
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:25:56.387776
# Unit test for function load

# Generated at 2022-06-17 17:26:00.755768
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'


# Generated at 2022-06-17 17:26:04.825270
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:26:16.946340
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-test'
    assert context['cookiecutter']['release_date'] == '2014-12-17'

# Generated at 2022-06-17 17:26:24.790902
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-27'

# Generated at 2022-06-17 17:26:32.145183
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:26:39.364931
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-test'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['release_date'] == '2013-06-01'

# Generated at 2022-06-17 17:26:48.326946
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context

# Generated at 2022-06-17 17:26:52.731473
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/home/travis/build/audreyr/cookiecutter/tests/test-replay', 'pypackage')
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'


# Generated at 2022-06-17 17:27:01.830488
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'test_replay')
    template_name = 'test_template'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert isinstance(context['cookiecutter'], dict)
    assert 'full_name' in context['cookiecutter']
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert 'email' in context['cookiecutter']
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert 'github_username' in context['cookiecutter']

# Generated at 2022-06-17 17:27:12.358451
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:27:22.332940
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-08-14'

# Generated at 2022-06-17 17:27:31.882457
# Unit test for function load
def test_load():
    replay_dir = "./tests/test-replay"
    template_name = "test-template"
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == "Audrey Roy Greenfeld"
    assert context['cookiecutter']['email'] == "audreyr@example.com"
    assert context['cookiecutter']['github_username'] == "audreyr"
    assert context['cookiecutter']['project_name'] == "Cookiecutter"
    assert context['cookiecutter']['project_slug'] == "cookiecutter"
    assert context['cookiecutter']['project_short_description'] == "A command-line utility that creates projects from cookiecutters (project templates)."

# Generated at 2022-06-17 17:27:45.897755
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:27:56.129123
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A Python package project template.'

# Generated at 2022-06-17 17:28:05.377509
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-test'
    assert context['cookiecutter']['release_date'] == '2014-12-31'

# Generated at 2022-06-17 17:28:10.122887
# Unit test for function load
def test_load():
    """Test the load function."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'


# Generated at 2022-06-17 17:28:16.797162
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter'
    assert context['cookiecutter']['release_date'] == '2014-10-06'
    assert context['cookiecutter']['year'] == '2014'
   

# Generated at 2022-06-17 17:28:22.382570
# Unit test for function load
def test_load():
    template_name = 'test_template'
    replay_dir = 'test_replay_dir'
    context = {'cookiecutter': {'test_key': 'test_value'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-17 17:28:31.798280
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-test'
    assert context['cookiecutter']['release_date'] == '2014-12-25'

# Generated at 2022-06-17 17:28:41.248515
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:28:48.661370
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:29:00.376515
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example is a short description of the project.'

# Generated at 2022-06-17 17:29:17.279961
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:29:21.831009
# Unit test for function load
def test_load():
    """Test load function."""
    context = load('/Users/yunfei/Documents/GitHub/cookiecutter-pypackage/tests/test-replay', 'cookiecutter-pypackage')
    print(context)


# Generated at 2022-06-17 17:29:31.450387
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:29:41.624591
# Unit test for function load
def test_load():
    replay_dir = 'tests/files/replay'
    template_name = 'tests/files/replay/test_template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:29:53.496573
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Test Project'
    assert context['cookiecutter']['repo_name'] == 'test-repo'
    assert context['cookiecutter']['author_name'] == 'Test Author'
    assert context['cookiecutter']['email'] == 'test@example.com'
    assert context['cookiecutter']['description'] == 'A short description of the project.'
    assert context['cookiecutter']['domain_name'] == 'example.com'

# Generated at 2022-06-17 17:30:00.387006
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:30:10.713704
# Unit test for function load
def test_load():
    """Test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'

# Generated at 2022-06-17 17:30:16.943853
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'repo_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'release_date' in context['cookiecutter']
    assert 'version' in context['cookiecutter']
    assert 'project_short_description' in context['cookiecutter']

# Generated at 2022-06-17 17:30:20.573107
# Unit test for function load
def test_load():
    context = load('/Users/yunfei/Desktop/cookiecutter-pypackage/tests/test-replay/', 'cookiecutter-pypackage')
    print(context)


# Generated at 2022-06-17 17:30:31.401033
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'pypi_username' in context['cookiecutter']
    assert 'github_username' in context['cookiecutter']
    assert 'repo_name' in context['cookiecutter']

# Generated at 2022-06-17 17:30:52.021970
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)

# Generated at 2022-06-17 17:31:01.455621
# Unit test for function load

# Generated at 2022-06-17 17:31:07.556892
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:31:14.137281
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:31:22.424215
# Unit test for function load
def test_load():
    context = load('/home/travis/build/audreyr/cookiecutter/tests/test-replay', 'pypackage')
    assert context['cookiecutter']['project_name'] == 'Python Package'
    assert context['cookiecutter']['project_slug'] == 'pypackage'
    assert context['cookiecutter']['author_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['description'] == 'A Python package project.'
    assert context['cookiecutter']['domain_name'] == 'example.com'
    assert context['cookiecutter']['version'] == '0.1.0'

# Generated at 2022-06-17 17:31:32.944754
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:31:40.134940
# Unit test for function load
def test_load():
    """Test load function."""
    template_name = 'test'
    replay_dir = 'tests/test-replay'
    context = {'cookiecutter': {'full_name': 'Test', 'email': 'test@example.com'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:31:46.761004
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-17 17:31:51.945876
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), 'test_replay')
    template_name = 'test_template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Test User'
