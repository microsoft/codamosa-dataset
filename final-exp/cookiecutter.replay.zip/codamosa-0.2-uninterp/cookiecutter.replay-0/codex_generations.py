

# Generated at 2022-06-17 17:22:02.091062
# Unit test for function load
def test_load():
    context = load('/Users/jiaxin/Documents/GitHub/cookiecutter-pypackage-minimal/cookiecutter-pypackage-minimal', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:22:12.805227
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-dump-replay'
    template_name = 'test-dump-template'

# Generated at 2022-06-17 17:22:23.996743
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'tests/files/fake-repo-pre/{{cookiecutter.repo_name}}'

# Generated at 2022-06-17 17:22:31.961352
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile
    import shutil
    import os
    import json

    template_name = 'test_template'

# Generated at 2022-06-17 17:22:43.723170
# Unit test for function dump
def test_dump():
    """Test function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:22:52.324492
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre'

# Generated at 2022-06-17 17:22:58.203363
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(replay_dir)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:23:05.437393
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Test Project'
    assert context['cookiecutter']['project_slug'] == 'test_project'
    assert context['cookiecutter']['author_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['description'] == 'A short description of the project.'

# Generated at 2022-06-17 17:23:12.946889
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '~/replay'
    template_name = 'template'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '~/replay/template.json'


# Generated at 2022-06-17 17:23:21.801064
# Unit test for function dump
def test_dump():
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    context = {'cookiecutter': {'name': 'name'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))
    os.rmdir(replay_dir)


# Generated at 2022-06-17 17:23:30.143460
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:23:39.200336
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:23:52.393950
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-Pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description']

# Generated at 2022-06-17 17:23:59.977603
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:24:07.163103
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'project_name': 'test-load-replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:24:15.082174
# Unit test for function load
def test_load():
    context = load('./tests/test-replay', 'test-template')
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-10-27'
    assert context['cookiecutter']['version'] == '0.1.0'

# Generated at 2022-06-17 17:24:19.342065
# Unit test for function load
def test_load():
    """Test load function."""
    context = load('/home/travis/build/audreyr/cookiecutter/tests/test-replay', 'pypackage')
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'

# Generated at 2022-06-17 17:24:29.628441
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load'
    context = {
        'cookiecutter': {
            'full_name': 'Test Load',
            'email': 'test-load@example.com',
            'github_username': 'test-load',
            'project_name': 'test-load',
            'project_slug': 'test_load',
            'project_short_description': 'Test load',
            'pypi_username': 'test-load',
            'release_date': '2015-08-30',
            'version': '0.1.0',
            'year': '2015',
        }
    }

    dump(replay_dir, template_name, context)

# Generated at 2022-06-17 17:24:37.554274
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-load-replay-dir'
    template_name = 'test-load-template'

# Generated at 2022-06-17 17:24:50.484483
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:24:57.272827
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context


# Generated at 2022-06-17 17:25:02.610903
# Unit test for function load
def test_load():
    """Test load function."""
    import tempfile
    import shutil

    replay_dir = tempfile.mkdtemp()
    template_name = 'test_template'
    context = {'cookiecutter': {'test': 'test'}}

    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)

    assert context == context_loaded

    shutil.rmtree(replay_dir)

# Generated at 2022-06-17 17:25:12.832739
# Unit test for function load

# Generated at 2022-06-17 17:25:17.291510
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'


# Generated at 2022-06-17 17:25:23.454401
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'

# Generated at 2022-06-17 17:25:33.760856
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:25:41.408762
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'repo_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'project_short_description' in context['cookiecutter']
    assert 'pypi_username' in context['cookiecutter']
    assert 'github_username' in context['cookiecutter']
    assert 'version' in context['cookiecutter']

# Generated at 2022-06-17 17:25:49.054510
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter.main import cookiecutter
    replay_dir = os.path.join(os.getcwd(), 'tests/test-replay')
    template_name = 'tests/fake-repo-tmpl'
    context = cookiecutter(template_name, replay_dir=replay_dir)
    assert context == load(replay_dir, template_name)

# Generated at 2022-06-17 17:25:55.184499
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:25:59.522925
# Unit test for function load
def test_load():
    context = load('/Users/yunfei/Desktop/cookiecutter-pypackage-minimal/cookiecutter-pypackage-minimal', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:26:07.242955
# Unit test for function load
def test_load():
    """Unit test for function load."""
    # Test for invalid template name
    try:
        load('/tmp', None)
    except TypeError:
        pass
    else:
        raise AssertionError('Expected TypeError')

    # Test for invalid context
    try:
        load('/tmp', 'template_name')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')

    # Test for valid context
    context = {'cookiecutter': {'project_name': 'test'}}
    dump('/tmp', 'template_name', context)
    assert load('/tmp', 'template_name') == context



# Generated at 2022-06-17 17:26:15.771244
# Unit test for function dump
def test_dump():
    """Test for function dump."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    assert context['cookiecutter']['full_name'] == 'Audrey Roy'

    os.remove(replay_file)


# Generated at 2022-06-17 17:26:24.017220
# Unit test for function load

# Generated at 2022-06-17 17:26:30.785603
# Unit test for function load
def test_load():
    """Test for function load."""
    replay_dir = 'tests/test-load'
    template_name = 'test-load'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:26:33.217590
# Unit test for function dump
def test_dump():
    """Test function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'test_key': 'test_value'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:26:42.212497
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'project_short_description' in context['cookiecutter']
    assert 'release_date' in context['cookiecutter']
    assert 'version' in context['cookiecutter']
    assert 'open_source_license' in context['cookiecutter']

# Generated at 2022-06-17 17:26:54.402322
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'test_template'
    replay_dir = 'test_replay_dir'

# Generated at 2022-06-17 17:27:03.143549
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)

# Generated at 2022-06-17 17:27:08.621211
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Test User'


# Generated at 2022-06-17 17:27:14.877061
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'full_name': 'Test User', 'email': 'test@example.com'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:27:24.222704
# Unit test for function load
def test_load():
    context = load('./tests/test-replay/', 'test-replay')
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['project_short_description'] == 'A command-line utility that creates projects from project templates, e.g. creating a Python package project from a Python package project template.'

# Generated at 2022-06-17 17:27:31.292778
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)
    assert context == context_loaded
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:27:39.269777
# Unit test for function dump
def test_dump():
    """Test for function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:27:52.087336
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:28:02.405931
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A Python package project template.'

# Generated at 2022-06-17 17:28:12.624474
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context['cookiecutter']['version']

# Generated at 2022-06-17 17:28:20.149555
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.exists(replay_file)
    os.remove(replay_file)


# Generated at 2022-06-17 17:28:30.167539
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Test Project'
    assert context['cookiecutter']['repo_name'] == 'test-project'
    assert context['cookiecutter']['project_slug'] == 'test_project'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'example'
    assert context['cookiecutter']['use_pytest'] == 'y'

# Generated at 2022-06-17 17:28:40.709428
# Unit test for function load
def test_load():
    """Test load function."""
    context = load('/home/travis/build/audreyr/cookiecutter/tests/test-data/fake-repo-pre/', 'fake-repo-pre')
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Fake Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-fake-python-package'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:28:53.409700
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-10-06'
    assert context['cookiecutter']['version'] == '0.1.0'
   

# Generated at 2022-06-17 17:29:04.200447
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    replay_dir = os.path.join(temp_dir, 'replay')
    template_name = 'my_template'
    context = {'cookiecutter': {'foo': 'bar'}}

    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)

    shutil.rmtree(temp_dir)


# Generated at 2022-06-17 17:29:07.702248
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/files/replay'
    template_name = 'tests/files/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['repo_name'] == 'foobar'


# Generated at 2022-06-17 17:29:12.834887
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'test_template'
    context = {'cookiecutter': {'test_key': 'test_value'}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:29:16.339069
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay-dir'
    template_name = 'test-load-template'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context



# Generated at 2022-06-17 17:29:23.610933
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'full_name': 'Test User', 'email': 'test@example.com'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:29:26.081077
# Unit test for function load
def test_load():
    context = load('/Users/jianghao/Desktop/cookiecutter-pypackage-minimal/', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:29:34.308418
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['release_date'] == '2013-06-01'
    assert context

# Generated at 2022-06-17 17:29:41.591283
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile
    import shutil
    import json

    replay_dir = tempfile.mkdtemp()
    template_name = 'test_template'
    context = {'cookiecutter': {'test_key': 'test_value'}}

    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'r') as infile:
        context_loaded = json.load(infile)

    assert context == context_loaded

    shutil.rmtree(replay_dir)


# Generated at 2022-06-17 17:29:49.300066
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:29:57.529427
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'full_name': 'Test Name', 'email': 'test@example.com'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:30:16.235978
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'

# Generated at 2022-06-17 17:30:27.378332
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:30:32.358213
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:30:36.848245
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-tmpl'

# Generated at 2022-06-17 17:30:47.591989
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)

# Generated at 2022-06-17 17:30:54.041840
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:31:01.237168
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile
    import shutil

    replay_dir = tempfile.mkdtemp()
    template_name = 'test_template'
    context = {'cookiecutter': {'test_key': 'test_value'}}

    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'r') as infile:
        loaded_context = json.load(infile)

    assert loaded_context == context

    shutil.rmtree(replay_dir)


# Generated at 2022-06-17 17:31:07.902548
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}

    dump(replay_dir, template_name, context)

    assert os.path.exists(get_file_name(replay_dir, template_name))



# Generated at 2022-06-17 17:31:14.302381
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay-dir'
    template_name = 'tests/test-load-replay-dir/test-load-replay-file'

# Generated at 2022-06-17 17:31:16.884617
# Unit test for function load
def test_load():
    context = load('/Users/yuanxue/Documents/GitHub/cookiecutter-pypackage-minimal/', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:31:31.667585
# Unit test for function load
def test_load():
    """Test load function."""
    context = load(replay_dir='/Users/yunfei/Desktop/cookiecutter-pypackage-minimal/replay', template_name='cookiecutter-pypackage-minimal')
    print(context)


# Generated at 2022-06-17 17:31:37.050682
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'full_name': 'Test User', 'email': 'test@example.com'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:31:43.918630
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-Pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-04-01'
    assert context['cookiecutter']['version'] == '0.1.0'
   

# Generated at 2022-06-17 17:31:53.045744
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-17 17:32:01.647707
# Unit test for function load
def test_load():
    """Test load function."""
    template_name = 'test'
    replay_dir = 'tests/test-replay'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Test'
    assert context['cookiecutter']['email'] == 'test@example.com'
    assert context['cookiecutter']['project_name'] == 'test'
    assert context['cookiecutter']['project_slug'] == 'test'
    assert context['cookiecutter']['project_short_description'] == 'Test project'
    assert context['cookiecutter']['pypi_username'] == 'test'
    assert context['cookiecutter']['github_username'] == 'test'
    assert context['cookiecutter']['version']