

# Generated at 2022-06-17 17:22:11.837221
# Unit test for function load
def test_load():
    context = load('/Users/jason/Documents/GitHub/cookiecutter-pypackage/tests/test-replay/', 'test-template')
    assert context['cookiecutter']['project_name'] == 'Test Project'


# Generated at 2022-06-17 17:22:15.666235
# Unit test for function load
def test_load():
    """Test load function."""
    context = load('/Users/jason/Desktop/cookiecutter-pypackage', 'cookiecutter-pypackage')
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Pypackage'


# Generated at 2022-06-17 17:22:19.358699
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tests/files/replay'
    template_name = 'tests/files/replay/test_template'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'tests/files/replay/test_template.json'


# Generated at 2022-06-17 17:22:22.944557
# Unit test for function dump
def test_dump():
    """Test for function dump."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:22:27.960511
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, 'tests-fake-repo-pre-.json'))


# Generated at 2022-06-17 17:22:30.542788
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Test Project'


# Generated at 2022-06-17 17:22:31.708682
# Unit test for function load
def test_load():
    """Unit test for function load."""
    assert load('/tmp', 'test') == {'cookiecutter': {}}

# Generated at 2022-06-17 17:22:34.252994
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'


# Generated at 2022-06-17 17:22:36.149315
# Unit test for function load
def test_load():
    context = load('/Users/yuexu/Documents/GitHub/cookiecutter-pypackage/tests/test-replay', 'cookiecutter-pypackage')
    print(context)


# Generated at 2022-06-17 17:22:40.048771
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'test_dir'
    template_name = 'test_template'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'test_dir/test_template.json'


# Generated at 2022-06-17 17:22:45.054806
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    assert get_file_name(replay_dir, template_name) == 'replay_dir/template_name.json'


# Generated at 2022-06-17 17:22:49.658696
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-17 17:22:59.176289
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-test'
    assert context['cookiecutter']['release_date'] == '2014-12-25'

# Generated at 2022-06-17 17:23:06.269503
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:23:16.916963
# Unit test for function load
def test_load():
    replay_dir = 'cookiecutter/tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'Cookiecutter Example is a short description of the project.'
    assert context['cookiecutter']['release_date'] == '2013-07-10'

# Generated at 2022-06-17 17:23:21.240598
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = './tests/files/replay'
    template_name = 'test_template'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == './tests/files/replay/test_template.json'


# Generated at 2022-06-17 17:23:23.832952
# Unit test for function load
def test_load():
    context = load('/Users/jason/Desktop/cookiecutter-pypackage-minimal/', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:23:26.789279
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    template_name = 'test'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == './test.json'


# Generated at 2022-06-17 17:23:37.600603
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:23:51.009251
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'project_short_description' in context['cookiecutter']
    assert 'release_date' in context['cookiecutter']
    assert 'version' in context['cookiecutter']
    assert 'open_source_license' in context['cookiecutter']
    assert 'pypi_username' in context['cookiecutter']

# Generated at 2022-06-17 17:24:02.055471
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Test Project'
    assert context['cookiecutter']['repo_name'] == 'test-repo'
    assert context['cookiecutter']['author_name'] == 'Test Author'
    assert context['cookiecutter']['email'] == 'test@example.com'
    assert context['cookiecutter']['description'] == 'A short description of the project.'
    assert context['cookiecutter']['domain_name'] == 'example.com'

# Generated at 2022-06-17 17:24:11.698542
# Unit test for function load
def test_load():
    """Unit test for function load."""

# Generated at 2022-06-17 17:24:15.963818
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Test Load Replay'


# Generated at 2022-06-17 17:24:27.030503
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A Python package project template.'

# Generated at 2022-06-17 17:24:35.438465
# Unit test for function load
def test_load():
    """Test load function."""

# Generated at 2022-06-17 17:24:39.484012
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com', 'github_username': 'audreyr'}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:24:46.766988
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Test Project'


# Generated at 2022-06-17 17:24:52.314305
# Unit test for function load
def test_load():
    """Test for function load."""
    replay_dir = os.path.join(os.getcwd(), 'tests/test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'project_short_description' in context['cookiecutter']
    assert 'release_date' in context['cookiecutter']
    assert 'version' in context['cookiecutter']
    assert 'open_source_license' in context['cookiecutter']
    assert 'year' in context

# Generated at 2022-06-17 17:24:59.437524
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:25:10.890609
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:25:21.690078
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'

# Generated at 2022-06-17 17:25:25.900592
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:25:36.161246
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2013-06-01'
    assert context['cookiecutter']['version'] == '0.1.0'
   

# Generated at 2022-06-17 17:25:45.979745
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:25:49.551416
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context == {'cookiecutter': {'full_name': 'Audrey Roy'}}


# Generated at 2022-06-17 17:25:53.125165
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'test'
    replay_dir = 'test'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:26:03.134858
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:26:05.938792
# Unit test for function load
def test_load():
    context = load('/home/travis/build/audreyr/cookiecutter/tests/test-replay', 'pypackage')
    assert context['cookiecutter']['project_name'] == 'Python Package'


# Generated at 2022-06-17 17:26:15.860387
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:26:24.079243
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:26:33.516640
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'test_template'
    replay_dir = 'test_replay'
    context = {'cookiecutter': {'test_key': 'test_value'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(get_file_name(replay_dir, template_name))
    os.rmdir(replay_dir)


# Generated at 2022-06-17 17:26:39.228792
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'test': 'test'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, template_name + '.json'))


# Generated at 2022-06-17 17:26:45.907405
# Unit test for function load
def test_load():
    replay_dir = 'C:\\Users\\Administrator\\Desktop\\cookiecutter-pypackage-minimal\\cookiecutter-pypackage-minimal'
    template_name = 'cookiecutter.json'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-17 17:26:52.063049
# Unit test for function load
def test_load():
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    context = {'cookiecutter': {'project_name': 'project_name'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context

# Generated at 2022-06-17 17:26:55.557123
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-17 17:27:03.808973
# Unit test for function load
def test_load():
    """Unit test for function load."""
    # Test for correct input
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context

    # Test for incorrect input
    template_name = 123
    try:
        load(replay_dir, template_name)
    except TypeError:
        pass
    else:
        assert False

    # Test for incorrect input
    template_name = 'tests/fake-repo-pre/'
    try:
        load(replay_dir, template_name)
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-17 17:27:13.634102
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Python Package'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'
    assert context['cookiecutter']['github_username'] == 'audreyr'

# Generated at 2022-06-17 17:27:20.053034
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'name': 'test-load-replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context



# Generated at 2022-06-17 17:27:23.448553
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-17 17:27:32.990246
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['release_date'] == '2014-10-03'
    assert context['cookiecutter']['version'] == '0.1.0'
   

# Generated at 2022-06-17 17:27:50.694594
# Unit test for function load

# Generated at 2022-06-17 17:27:54.568681
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/home/yunfei/Documents/cookiecutter-pypackage', 'cookiecutter-pypackage')
    print(context)


# Generated at 2022-06-17 17:27:59.140005
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'test-replay')
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'


# Generated at 2022-06-17 17:28:08.312368
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'

# Generated at 2022-06-17 17:28:16.361914
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/test-load-replay-dir'
    template_name = 'tests/test-load-replay-dir/test-load-replay-file'
    context = {'cookiecutter': {'key': 'value'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:28:27.586425
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:28:34.268199
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'

# Generated at 2022-06-17 17:28:42.242017
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A Python package project template.'

# Generated at 2022-06-17 17:28:45.745121
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = 'test'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'test'


# Generated at 2022-06-17 17:28:56.021914
# Unit test for function load
def test_load():
    """Test function load."""
    import os
    import shutil
    import tempfile
    import unittest

    class TestLoad(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.replay_dir = os.path.join(self.tempdir, 'replay')
            self.template_name = 'test_template'
            self.context = {'cookiecutter': {'test_key': 'test_value'}}

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_load_success(self):
            """Test load success."""
            dump(self.replay_dir, self.template_name, self.context)

# Generated at 2022-06-17 17:29:06.646300
# Unit test for function load
def test_load():
    context = load('/home/paul/Documents/cookiecutter-pypackage/tests/test-replay', 'cookiecutter-pypackage')
    print(context)


# Generated at 2022-06-17 17:29:15.806818
# Unit test for function dump
def test_dump():
    """Test function dump."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:29:26.482457
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'cookiecutter-pypackage',
            'project_slug': 'cookiecutter-pypackage',
            'release_date': '2014-10-27',
            'version': '0.1.0',
            'open_source_license': 'MIT license'
        }
    }

    dump(replay_dir, template_name, context)

# Generated at 2022-06-17 17:29:34.541969
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), 'tests/files/replay')
    template_name = 'test_replay'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'project_short_description' in context['cookiecutter']
    assert 'release_date' in context['cookiecutter']
    assert 'year' in context['cookiecutter']
    assert 'version' in context

# Generated at 2022-06-17 17:29:37.031468
# Unit test for function load
def test_load():
    context = load('/Users/yunfei/Desktop/cookiecutter-pypackage-minimal/', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-17 17:29:45.092506
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:29:47.601229
# Unit test for function load
def test_load():
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    context = {'cookiecutter': 'cookiecutter'}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context



# Generated at 2022-06-17 17:29:58.636865
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Example'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-example'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-example'
    assert context['cookiecutter']['release_date'] == '2013-06-01'

# Generated at 2022-06-17 17:30:08.463346
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-output/replay'
    template_name = 'test_template'

# Generated at 2022-06-17 17:30:16.480323
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'test-replay')
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['author_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['description'] == 'A Python package project template.'

# Generated at 2022-06-17 17:30:34.062493
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['pypi_username'] == 'audreyr'

# Generated at 2022-06-17 17:30:41.116308
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-17 17:30:48.344762
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), 'test_replay')
    template_name = 'test_template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Test User'


# Generated at 2022-06-17 17:30:59.163366
# Unit test for function load
def test_load():
    context = load('/home/travis/build/audreyr/cookiecutter/tests/test-replay', 'pypackage')
    assert context['cookiecutter']['project_name'] == 'Python Package'
    assert context['cookiecutter']['repo_name'] == 'pypackage'
    assert context['cookiecutter']['project_slug'] == 'pypackage'
    assert context['cookiecutter']['author_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['description'] == 'A Python package project.'
    assert context['cookiecutter']['domain_name'] == 'example.com'

# Generated at 2022-06-17 17:31:07.773355
# Unit test for function load
def test_load():
    """Unit test for function load."""
    # Test for invalid template name
    try:
        load('', None)
        assert False
    except TypeError:
        assert True

    # Test for invalid context
    try:
        load('', 'test')
        assert False
    except ValueError:
        assert True

    # Test for valid context
    context = {'cookiecutter': {'full_name': 'Test'}}
    try:
        load('', 'test', context)
        assert True
    except ValueError:
        assert False



# Generated at 2022-06-17 17:31:14.242548
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test'
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-test'
    assert context['cookiecutter']['release_date'] == '2014-10-15'

# Generated at 2022-06-17 17:31:18.297309
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test Load Replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-17 17:31:23.863302
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A Python package project template.'

# Generated at 2022-06-17 17:31:33.441248
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Your Name'
    assert context['cookiecutter']['email'] == 'your@email.com'
    assert context['cookiecutter']['project_name'] == 'Test Project'
    assert context['cookiecutter']['project_slug'] == 'test_project'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['release_date'] == 'YYYY-MM-DD'
    assert context['cookiecutter']['year'] == 'YYYY'

# Generated at 2022-06-17 17:31:43.247378
# Unit test for function load
def test_load():
    """Test load function."""
    context = load('/home/louis/Documents/cookiecutter-pypackage-minimal/', 'cookiecutter.json')
    assert context['cookiecutter']['full_name'] == 'Louis'
    assert context['cookiecutter']['email'] == 'louis@louis.com'
    assert context['cookiecutter']['project_name'] == 'louis'
    assert context['cookiecutter']['project_slug'] == 'louis'
    assert context['cookiecutter']['project_short_description'] == 'louis'
    assert context['cookiecutter']['pypi_username'] == 'louis'
    assert context['cookiecutter']['version'] == '0.1.0'

# Generated at 2022-06-17 17:32:04.131676
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'test'
    replay_dir = 'tests/test-load-replay'
    context = {'cookiecutter': {'full_name': 'Test'}}

    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)

    assert context == loaded_context

# Generated at 2022-06-17 17:32:15.752358
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.replay import load

    # Create a replay file
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    template_name = 'cookiecutter-pypackage'
    context = cookiecutter(
        template_name,
        replay_dir=replay_dir,
        no_input=True,
        extra_context={'full_name': 'Audrey Roy'},
        default_config=DEFAULT_CONFIG
    )

    # Load the replay file
    context = load(replay_dir, template_name)

    # Check that the replay file was loaded correctly