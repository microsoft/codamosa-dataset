

# Generated at 2022-06-11 20:22:13.096183
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import time
    import json
    import tempfile
    from cookiecutter.replay import load

    cwd = os.path.dirname(os.path.abspath(__file__))
    template_dir = os.path.join(cwd, '..', 'tests', 'test-template')

    with tempfile.TemporaryDirectory() as replay_dir:
        _, replay_file = tempfile.mkstemp(
            suffix='.json',
            dir=replay_dir,
            text=True
        )
        with open(replay_file, 'w') as outfile:
            json.dump({
                'test_key': 'test_value',
                'test_key_2': 'test_value_2',
            }, outfile, indent=2)



# Generated at 2022-06-11 20:22:21.962935
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test_output/'
    template_name = 'fake'
    context = {'cookiecutter': {'replay': True}, 'random': 'data'}
    dump(replay_dir, template_name, context)
    # Check that the file exists
    assert os.path.exists(replay_dir+template_name+'.json')
    # Check that the contents of the file are as expected
    with open(replay_dir+template_name+'.json', 'r') as infile:
        actual_context = json.load(infile)
    assert actual_context == context


# Generated at 2022-06-11 20:22:27.645833
# Unit test for function load
def test_load():
    template_name = 'test'
    context = {'cookiecutter' : {'name' : 'test', 'author' : 'test'}}
    replay_dir = 'tests/replay'

    dump(replay_dir, template_name, context)
    assert context == load(replay_dir, template_name)

# Generated at 2022-06-11 20:22:33.832676
# Unit test for function load
def test_load():
    if not os.path.exists('cookiecutter-pypackage/replay'):
        os.mkdir('cookiecutter-pypackage/replay')
    with open('config.yaml', 'r') as infile:
        context = yaml.load(infile)
    dump('cookiecutter-pypackage/replay', 'config', context)
    new_context = load('cookiecutter-pypackage/replay', 'config')
    assert context == new_context

# Generated at 2022-06-11 20:22:41.242126
# Unit test for function load
def test_load():
    """Testing load function."""
    replay_dir = 'tests/test-load-replay'
    template_name = 'test-load-replay'
    context = {
        'cookiecutter': {
            'first_name': 'Audrey',
            'last_name': 'Roy',
            'email': 'audreyr@gmail.com',
            'github_username': 'audreyr',
            'project_name': 'pip-tools',
            'release_date': '2014/10/23',
            'year': '2014'
        }
    }

    dump(replay_dir, 'test-load-replay', context)
    new_context = load(replay_dir, template_name)

    assert new_context == context

# Generated at 2022-06-11 20:22:47.725762
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = os.path.expanduser("~/.cookiecutter_replay/")
    template_name = 'test_template'
    context = {
        'cookiecutter': {
            'full_name': 'Test User',
            'email': 'test@example.com',
            'github_username': 'test',
            'project_name': 'Test Project',
            'project_slug': 'test_project'
        }
    }
    dump(replay_dir, template_name, context)
    json_data = load(replay_dir, template_name)
    assert json_data == context


# Generated at 2022-06-11 20:22:49.512593
# Unit test for function load
def test_load():
    context = load("/home/dev/.cookiecutters", "py_adf")
    print(context)


# Generated at 2022-06-11 20:22:50.646029
# Unit test for function load
def test_load():
    assert load('/Users/hongxujiang/Desktop/ECE143_Project/cookiecutter', 'cookiecutter-data-science')

# Generated at 2022-06-11 20:22:55.621128
# Unit test for function dump
def test_dump():
    outfile = dump('./', 'tests/fixtures/fake-repo-tmpl/', 
        {'cookiecutter': {'full_name': 'Audrey Roy Greenfeld'}})
    assert os.path.exists(outfile)


# Generated at 2022-06-11 20:23:00.105810
# Unit test for function load
def test_load():
    # get file name
    replay_dir = "/Users/dongxq/Desktop/Pix2Pix/cookiecutter-data-science/tests/big_template"
    template_name = "input_json"
    # import pdb; pdb.set_trace()
    replay_file = get_file_name(replay_dir, template_name)
    # read file
    with open(replay_file, 'r') as infile:
        context = json.load(infile)

# Generated at 2022-06-11 20:23:05.623089
# Unit test for function load
def test_load():
    context = load(replay_dir=r"C:\Users\ZHANGY4\Desktop\configuration\Cookiecutter\cookiecutter-pypackage-minimal", template_name = "cookiecutter-pypackage-minimal")
    print(context)


# Generated at 2022-06-11 20:23:06.633535
# Unit test for function load
def test_load():
    pass

# Generated at 2022-06-11 20:23:16.782438
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    temp_replay_file = get_file_name(temp_dir, '{{cookiecutter.project_name}}')

# Generated at 2022-06-11 20:23:24.926205
# Unit test for function load
def test_load():
    replay_dir = 'cookiecutter' # Specify a directory or a file path to store replay files
    template_name = 'template' # Specify a template name
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['project_name'] = 'Hello'
    context['cookiecutter']['author_name'] = 'World'
    dump(replay_dir, template_name, context)
    context_read = load(replay_dir, template_name)
    assert context == context_read
    # Remove replay file
    replay_file = get_file_name(replay_dir, template_name)
    os.remove(replay_file)


# Generated at 2022-06-11 20:23:27.879980
# Unit test for function get_file_name
def test_get_file_name():
    if get_file_name(replay_dir='cookiecutter',template_name='test_template') == 'cookiecutter/test_template.json':
        print('test_get_file_name test successful!')
        return
    else:
        print('test_get_file_name test failed!')


# Generated at 2022-06-11 20:23:34.788262
# Unit test for function dump
def test_dump():
    import tempfile
    test_file = tempfile.NamedTemporaryFile()
    assert os.path.isfile(test_file.name) is False
    test_dir = os.path.dirname(test_file.name)
    assert os.path.isdir(test_dir) is False

    context = {'cookiecutter': {'full_name': 'Test User', 'email': 'test@user.com'}}
    dump(test_dir, 'test', context)

    template_name = 'test.json'
    replay_file = os.path.join(test_dir, template_name)
    assert os.path.isfile(replay_file) is True

    with open(replay_file, 'r') as infile:
        data = infile.read().splitlines()

# Generated at 2022-06-11 20:23:41.406493
# Unit test for function dump
def test_dump():
    #create a dir in the current working directory called replay_dir
    replay_dir = 'replay_dir'
    template_name = 'test_template'
    #create a dictionary
    context = {}
    context['cookiecutter'] = {
        '_copy_without_render': [
            '.gitignore'
        ],
        'full_name': 'Full Name',
        'email': 'user@email.com',
        'github_username': 'GitHubUsername',
        'project_name': 'Test Project',
        'project_slug': 'test-project',
        'project_short_description': 'Test Project Short Description'
    }
    dump(replay_dir, template_name, context)
    #test that a file called 'test_template.json' was created in the replay_dir directory

# Generated at 2022-06-11 20:23:45.377871
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('C:/', 'test') == 'C:/test.json'
    assert get_file_name('C:/', 'test.json') == 'C:/test.json'

if __name__ == '__main__':
    test_get_file_name()

# Generated at 2022-06-11 20:23:47.177888
# Unit test for function dump
def test_dump():
    assert dump('test_dir', 'test_name', {'cookiecutter': {'name': 'bar'}}) == None


# Generated at 2022-06-11 20:23:55.759833
# Unit test for function load
def test_load():
    # Create temporary directory
    import tempfile
    temp_dir = tempfile.mkdtemp()
    replay_file = get_file_name(temp_dir, 'test_load')
    context_map = {'replay_dir': temp_dir, 'replay_file': replay_file, 'template_name': 'test_load'}
    print(context_map)

    context_map_2 = load(temp_dir, 'test_load')

    print(context_map_2)

    # Delete temporary directory
    import shutil
    shutil.rmtree(temp_dir)


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:24:03.608519
# Unit test for function load
def test_load():
    replay_dir = 'test_dir'
    os.mkdir(replay_dir)
    template_name = 'test_template'
    dump(replay_dir,template_name,{'cookiecutter':'test_cookiecutter'})
    assert(load(replay_dir,template_name) == {'cookiecutter':'test_cookiecutter'})
    os.rmdir(replay_dir)


# Generated at 2022-06-11 20:24:10.704921
# Unit test for function load
def test_load():
    """Test whether function load can read a correct json data."""
    context = load('.', 'test_data')
    assert context
    assert 'cookiecutter' in context
    assert 'cookiecutter' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'author_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'description' in context['cookiecutter']
    assert 'github_username' in context['cookiecutter']
    assert 'version' in context['cookiecutter']
    assert 'open_source_license' in context['cookiecutter']
    assert 'pypi_username' in context['cookiecutter']
    assert 'select_linter'

# Generated at 2022-06-11 20:24:20.046889
# Unit test for function load
def test_load():
    '''This program is used to test the load function1
    '''
    CurrentPath = os.getcwd()
    ReplayPath = os.path.join(CurrentPath, 'replay')
    if not os.path.exists(ReplayPath):
        os.mkdir(ReplayPath)
    replayfile = os.path.join(CurrentPath, 'replay', 'test')
    f = open(replayfile, 'w')
    json.dump({'cookiecutter': {'project_name': 'test'}}, f)
    f.close()
    f2 = open(replayfile, 'r')
    b = json.load(f2)
    assert(load(ReplayPath, 'test') == b)


# Generated at 2022-06-11 20:24:22.556315
# Unit test for function load
def test_load():
    load(replay_dir='/home/vagrant/cookiecutter-example', template_name='jquery')

# Generated at 2022-06-11 20:24:29.584175
# Unit test for function load
def test_load():
    """Test whether the load() function will return the right context as what we expect when we read it from a file."""
    # prepare the file
    template_name = 'replay_file'
    replay_dir = 'tests/test-output'
    replay_file = get_file_name(replay_dir, template_name)
    content = {'cookiecutter': {'full_name': 'Po Shih Hu', 'email': 'poshihu@ncsu.edu'}}
    file_handler = open(replay_file, 'w')
    json.dump(content, file_handler, indent=2)
    file_handler.close()

    replay_context = load(replay_dir, template_name)

    # delete the file
    os.remove(replay_file)


# Generated at 2022-06-11 20:24:34.092067
# Unit test for function load
def test_load():
    replay_dir = './tests/test-data/fake-repo-tmpl/'
    template_name = 'Python Package'
    context = load(replay_dir, template_name)
    print(context['cookiecutter']['project_name'])

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:24:43.686330
# Unit test for function load
def test_load():
    # Create a fake folder in current directory and a fake replay file
    from cookiecutter import utils
    from cookiecutter.main import cookiecutter
    from cookiecutter.main import _cookiecutter

    replay_dir = 'fake_dir'
    if os.path.exists(replay_dir):
        # Clean up replay dir if exists
        utils.rmtree(replay_dir)
    os.mkdir(replay_dir)
    file_name = 'fake_replay_file'
    replay_file = get_file_name(replay_dir, file_name)

    # Create a fake replay file
    # By calling cookiecutter()
    _context = {}
    template_name = 'Python-Cookiecutter-template'

# Generated at 2022-06-11 20:24:51.599481
# Unit test for function load

# Generated at 2022-06-11 20:24:55.720198
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/replay_dir'
    template_name = 'tests/fake-repo-tmpl'
    context = {'cookiecutter': {'full_name': 'Test Person'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:25:04.129101
# Unit test for function dump
def test_dump():
    try:
        dump("./test_replay_dir", "failTest1234.json", "this is a test")
    except IOError:
        assert True
    except:
        assert False
    try:
        dump("./test_replay_dir", "failTest1234.json", {'cookiecutter' : 'wrong type'})
    except TypeError:
        assert True
    except:
        assert False
    try:
        dump("./test_replay_dir", "failTest1234.json", {'notcookiecutter' : 'wrong key'})
    except ValueError:
        assert True
    except:
        assert False
    dump("./test_replay_dir", "successTest1234.json", {'cookiecutter': 'success'})
    assert True

# Unit test

# Generated at 2022-06-11 20:25:07.155014
# Unit test for function load
def test_load():
    replay = load('tests/test-replay/', 'fake_template')
    assert replay['cookiecutter']['project_name'] == 'Project Name'


# Generated at 2022-06-11 20:25:10.542203
# Unit test for function load
def test_load():
    file_path = "../../cookiecutter-pypackage/tests/test-replay/cookiecutter.json"
    context = load(file_path)
    print(context)


# Generated at 2022-06-11 20:25:15.759627
# Unit test for function dump
def test_dump():
    replay_dir = ".cookiecutters_replay"
    template_name = "{{cookiecutter.full_name}}"
    context = {'cookiecutter': {'full_name': 'Bob'}}
    dump(replay_dir, template_name, context)


# testing
if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-11 20:25:19.136389
# Unit test for function load
def test_load():
    context = load(replay_dir, 'templates/ab')
    if context['cookiecutter']['test1'] != 'test2':
        raise ValueError('test_load failed')


# Generated at 2022-06-11 20:25:20.623968
# Unit test for function load
def test_load():
    assert load('/tmp/cookiecutter-replay', 'python-package') is not None


# Generated at 2022-06-11 20:25:27.397880
# Unit test for function load
def test_load():
    replay_dir = os.path.dirname(os.path.abspath(__file__))
    replay_file = get_file_name(replay_dir, 'test_template')
    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    assert context['cookiecutter']['project_name'] == 'test'


# Generated at 2022-06-11 20:25:31.234777
# Unit test for function load
def test_load():
    replay_dir = os.path.expanduser('~/.cookiecutters')
    template_name = os.path.expanduser('~/projects/cookiecutter_template')
    assert(isinstance(load(replay_dir, template_name),dict))

# Generated at 2022-06-11 20:25:33.642464
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = './tests/'
    template_name = 'bob'
    assert load(replay_dir,template_name)['cookiecutter']['full_name'] == 'Bob Smith'

# Generated at 2022-06-11 20:25:34.837060
# Unit test for function load
def test_load():
    assert isinstance(load('current_dir', 'passwd.json'), dict)



# Generated at 2022-06-11 20:25:35.488592
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-11 20:25:48.518852
# Unit test for function load
def test_load():
    """Unit test for function load."""
    # There are two kinds of templates
    # 1 The template that has a repository
    # 2 The template that does not have a repository
    # For testing function load in the first kind of templates,
    #   I only need to testing one template i.e. monorepo
    # For testing function load in the second kind of template,
    #   I will test three templates, i.e. apk-android-studio,
    #   electron-comms-desktop and angular-hello-world
    context = load('replay', 'cookiecutter-monorepo')
    assert isinstance(context['cookiecutter']['project_slug'], str)

    context = load('replay', 'apk-android-studio')

# Generated at 2022-06-11 20:25:57.847866
# Unit test for function dump
def test_dump():
    """Test cookiecutter.replay.dump()."""
    template_name = 'test'
    replay_dir = '{}/replay_dir'.format(os.getcwd())
    context = {'cookiecutter': {'full_name': 'Test'}}

    try:
        dump(replay_dir, template_name, context)
    except Exception:
        assert 0, 'Should not raise exception'

    replay_file = '{}/{}.json'.format(replay_dir, template_name)
    if os.path.exists(replay_file):
        os.remove(replay_file)

    try:
        dump(replay_dir, template_name, None)
    except TypeError:
        pass
    else:
        assert 0, 'Should raise TypeError with None context'



# Generated at 2022-06-11 20:26:00.734595
# Unit test for function dump
def test_dump():
    replay_dir = "test_dir"
    template_name= "test_template"
    context = {"cookiecutter":{"hello":"world"}}
    print(dump(replay_dir, template_name, context))


# Generated at 2022-06-11 20:26:02.408049
# Unit test for function load
def test_load():
  context = load('/Users/omisie11/.cookiecutters', 'cookiecutter-pypackage')
  print(context)


# Generated at 2022-06-11 20:26:04.896310
# Unit test for function load
def test_load():
    """
    Unit test for function load
    """
    load('replay/python_package_replay/', 'python_package')

# Generated at 2022-06-11 20:26:13.350700
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    ctx = {
        'cookiecutter': {},
        'full_name': 'Test User',
        'email': 'test@example.com',
        'project_name': 'Test Project'
    }
    replay_dir = '/tmp/cookiecutter-replay'
    template = 'tests/fake-repo-tmpl'

    dump(replay_dir, template, ctx)

    ctx_from_file = load(replay_dir, template)
    assert ctx == ctx_from_file

    os.remove(get_file_name(replay_dir, template))

# Generated at 2022-06-11 20:26:23.624701
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    import os
    import shutil
    import tempfile
    import pytest

    # Setup
    output_dir = tempfile.mkdtemp()
    context_file = os.path.join(os.path.dirname(__file__), 'replay', 'tests', 'test_load.json')
    template = 'tests/fake-repo-pre/'

    # Run the cookiecutter function with replay disabled
    with pytest.raises(SystemExit):
        cookiecutter(template, no_input=True, replay=False, output_dir=output_dir,
                     context_file=context_file, log_dir=tempfile.mkdtemp())

    # Check results

# Generated at 2022-06-11 20:26:24.301149
# Unit test for function load
def test_load():
    load('replay', '3scale-release')

# Generated at 2022-06-11 20:26:30.709104
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    from pprint import pprint

    cookiecutter(
        'https://github.com/audreyr/cookiecutter-pypackage.git',
        no_input=True,
        replay=True,
        overwrite_if_exists=True,
    )

    pprint(load('.cookiecutters', 'cookiecutter-pypackage'))


# Generated at 2022-06-11 20:26:36.695729
# Unit test for function dump
def test_dump():
    replay_dir = '~/.cookiecutter_replay'
    template_name = 'natural'
    context = {
        "cookiecutter":{
            "author_github": "michael",
            "author_name": "Michael Goerz",
            "email": "mo@example.com",
            "open_source_license": "MIT License"
        }
    }
    try:
        dump(replay_dir, template_name, context)
    except:
        return False
    else:
        return True


# Generated at 2022-06-11 20:26:44.501015
# Unit test for function load
def test_load():
    """
    Test if load function works.
    Make sure file is in the correct path.
    """
    replay_dir = 'C:\\Users\\LeeEunguk\\Desktop\\Python\\TIL\\cookiecutter'
    template_name = 'cc-templates'
    load(replay_dir, template_name)

# Generated at 2022-06-11 20:26:50.984721
# Unit test for function dump
def test_dump():
    dic = {'cookiecutter': {'cookie': 'monster', 'chocolate': 'chip'}}
    dump('test_dir', 'test_file', dic)
    assert os.path.exists('test_dir') is True
    assert os.path.exists('test_dir/test_file.json') is True
    with open('test_dir/test_file.json', 'r') as f:
        test_dic = json.load(f)
        assert test_dic == dic


# Generated at 2022-06-11 20:26:57.258867
# Unit test for function load
def test_load():
	replay_dir = os.path.join("~/", ".cookiecutter.replay")
	replay_file = os.path.join(replay_dir, "cookiecutter-pypackage")
	with open(replay_file, 'r') as infile:
		context = json.load(infile)

	if 'cookiecutter' not in context:
		raise ValueError('Context is required to contain a cookiecutter key')

	return context

# Generated at 2022-06-11 20:26:58.342921
# Unit test for function load
def test_load():
    load(replay_dir, "cookiecutter-pypackage")

# Generated at 2022-06-11 20:27:02.308913
# Unit test for function load
def test_load():
    replay_dir = 'test/test_dir'
    template_name = 'test_template_name'
    context = {'cookiecutter': {}}

    dump(replay_dir, template_name, context)
    c = load(replay_dir, template_name)

    assert c == {'cookiecutter': {}}

# Generated at 2022-06-11 20:27:05.151305
# Unit test for function load
def test_load():
    replay_dir = '~/work/projects/cookiecutter-pypackage-min/'
    template_name = 'template_name'
    context_data = {'cookiecutter': {'_template': 'template'}}
    # TODO
    #dump(replay_dir, template_name, context_data)

test_load()

# Generated at 2022-06-11 20:27:07.781705
# Unit test for function load
def test_load():
    context = load('./tests/test-replay', 'cookiecutter-pypackage')
    print(context)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'


# Generated at 2022-06-11 20:27:18.256401
# Unit test for function dump
def test_dump():
    # First, create a replay for the first time
    replay_dir = 'tmp'
    template_name = 'test'

# Generated at 2022-06-11 20:27:28.801562
# Unit test for function dump
def test_dump():
    replay_dir = 'replay_dump'
    template_name = 'test_dump'
    context = {'cookiecutter': {'test': 1}}
    try:
        dump(replay_dir, template_name, context)
        assert True
    except IOError as e:
        assert False
    except ValueError as e:
        assert False
    try:
        # cannot write to non-existance dir
        dump('nonexiatance_dir', template_name, context)
        assert False
    except IOError as e:
        assert True
    try:
        # template_name is not of type str
        dump(replay_dir, 123, context)
        assert False
    except TypeError as e:
        assert True

# Generated at 2022-06-11 20:27:32.180176
# Unit test for function load
def test_load():
    filepath = '/Users/xxxx/Documents/replaydir/cookiecutter-pypackage-demo.json'
    context = load(filepath)
    print(context)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:27:44.426281
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = '.'
    context = load(replay_dir, template_name)
    # assert
    return context

# Generated at 2022-06-11 20:27:53.744151
# Unit test for function dump
def test_dump():
    replay_dir = '/Users/fanghaoyue/Documents/Program/Python/CookieCutters/tests/test-replay'
    template_name = './fake-repo-pre/'
    context = {
        'cookiecutter': {
            'project_name': 'Python Package',
            'project_slug': 'python-package',
            'release_date': '2017-10-01',
            'author_name': 'Your Name',
            'author_email': 'your@email.com'
        },
        'project_name': 'Python Package',
        'project_slug': 'python-package',
        'release_date': '2017-10-01',
        'author_name': 'Your Name',
        'author_email': 'your@email.com',
    }

# Generated at 2022-06-11 20:27:58.955861
# Unit test for function load
def test_load():
    import json
    import os
    import sys
    home = os.path.expanduser('~')
    cwd = os.getcwd()
    try:
        os.chdir(home)
        context = load('~/.cookiecutters', 'mytemplate')
        assert context == {'cookiecutter': {'somevar': 'somevalue'}}, 'test_load fail'
    finally:
        os.chdir(cwd)


# Generated at 2022-06-11 20:28:00.788288
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load()

# Generated at 2022-06-11 20:28:04.133345
# Unit test for function load
def test_load():
    template_name = "cookiecutter-pypackage"
    replay_dir = "c:\\users\\sirawichch\\.cookiecutter"
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:28:05.547179
# Unit test for function load
def test_load():
    context = load('.','cookiecutter.json')

# Generated at 2022-06-11 20:28:13.334812
# Unit test for function dump
def test_dump():
    context = {"cookiecutter": {"full_name": "Your Name",
                                "email": "your@email.com",
                                "github_username": "YourGitHubName",
                                "project_name": "Example Project",
                                "project_short_description": "An example project."},
               "other_data": "Goes here"}
    template_name = "cookiecutter-pypackage"
    replay_dir = "replay"
    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert loaded_context["cookiecutter"]["full_name"] == "Your Name"

# Generated at 2022-06-11 20:28:16.886572
# Unit test for function load
def test_load():
    try:
        replay_dir = "C:/Users/Miao Gao/Desktop/cookiecutter-django-master/tests/test-output/replay_dir"
        template_name = "django-base"+".json"
        context = load(replay_dir, template_name)
        assert isinstance(context, dict)
        assert "cookiecutter" in context
    except:
        pass

# Generated at 2022-06-11 20:28:21.230051
# Unit test for function load
def test_load():
    print("Testing load...")
    """Testing load"""
    assert load("/var/folders/ld/h0cqf8mj33vbvkzkf9p9k1b80000gq/T/tmprdBC5O/cookiecutter-django-rest-framework/","cookiecutter.json")
    print("PASS")


# Generated at 2022-06-11 20:28:28.754607
# Unit test for function load
def test_load():
    """Unit test"""
    template_name = 'test_template.json'
    replay_dir = '.'
    replay_file = get_file_name(replay_dir, template_name)
    if os.path.exists(replay_file):
        os.remove(replay_file)

    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['full_name'] = 'user1'
    context['cookiecutter']['email'] = 'user1@example.com'
    dump(replay_dir, template_name, context)

    context_loaded = load(replay_dir, template_name)
    if not os.path.exists(replay_file):
        raise Exception('File not found')


# Generated at 2022-06-11 20:28:51.190757
# Unit test for function load
def test_load():
    template_name = '/Users/allen/projects/cookiecutter/cookiecutter-pypackage'
    context = load('/Users/allen/projects/cookiecutter/replay', template_name)
    print(context)

# Generated at 2022-06-11 20:28:58.214405
# Unit test for function load
def test_load():
    replay_dir = 'cookiecutter/tests/test-load-replay-dir'
    template_name = 'test-load-replay-dir.json'

    dir_exists = os.path.exists(replay_dir)
    if not dir_exists:
        os.mkdir(replay_dir)
    try:
        # This should not raise.
        context = load(replay_dir, template_name)
        assert isinstance(context, dict)
        assert 'cookiecutter' in context
        assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    finally:
        if dir_exists:
            os.rmdir(replay_dir)


# Generated at 2022-06-11 20:29:02.037778
# Unit test for function load

# Generated at 2022-06-11 20:29:05.100288
# Unit test for function load
def test_load():
    replay_dir = os.path.abspath(os.path.dirname(__file__)) + '/replays'
    template_name = 'foobar'
    assert isinstance(load(replay_dir, template_name), dict)


# Generated at 2022-06-11 20:29:07.763479
# Unit test for function load
def test_load():
    context = load(".cookiecutter_replay", "example_cookiecutter")
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:29:16.011707
# Unit test for function dump
def test_dump():
    """ Unit test for function dump."""
    import tempfile
    import shutil
    import os
    import json

    template_name = 'mytesttemplate'
    replay_dir = tempfile.mkdtemp()
    context = {'cookiecutter': {'test': 'dump'}}

    dump(replay_dir, template_name, context)

    with open(os.path.join(replay_dir , '%s.json' % template_name), 'r') as f:
        dict = json.load(f)
        assert dict == context

    shutil.rmtree(replay_dir)


# Generated at 2022-06-11 20:29:25.732100
# Unit test for function load
def test_load():
    replay_dir = '.'
    tmp_json = './tests/tmp_replay.json'

    template_name = 'tests'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_slug'] == 'Cookiecutter-Test-Project'

    template_name = 'tests2'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_slug'] == 'Cookiecutter-{{ cookiecutter.project_name }}'

    template_name = '../tests/dummy'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_slug'] == 'Cookiecutter-{{ cookiecutter.project_name }}'

    # Test if

# Generated at 2022-06-11 20:29:30.164101
# Unit test for function load
def test_load():
    template_name = 'runcloud'
    replay_dir = '/home/kafka/Documents/projects/cookiecutters/runcloud'

    context = load(replay_dir, template_name)

    print(context)

    print(context['cookiecutter'])
    print(context['cookiecutter']['project_name'])

# Generated at 2022-06-11 20:29:37.126712
# Unit test for function load
def test_load():
    test_dir = 'tests/files/test-load-replay/'
    test_file = 'test_name'
    expected_context = {
        'cookiecutter': {'bar': 'baz', 'foo': 'bat'},
        'bat': 'bar',
        'baz': 'foo',
    }
    context = load(test_dir, test_file)
    assert context == expected_context


# Generated at 2022-06-11 20:29:39.859997
# Unit test for function load
def test_load():
    template_name = 'werlder'
    context = {'cookiecutter': {'whatever': {'hello': 'world'}}}
    assert context == load('./', template_name)

# Generated at 2022-06-11 20:30:30.549544
# Unit test for function load
def test_load():
    # load from valid file, already exist
    replay_dir = os.path.join(os.path.dirname(__file__), './replay')
    template_name = 'valid_template'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert context['cookiecutter']['full_name'] == 'Invalid Template'
    assert context['cookiecutter']['email'] == 'a@a.com'

    # load from valid file, not exist
    template_name = 'invalid_template'

# Generated at 2022-06-11 20:30:38.425873
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'tests/files/fake-repo-pre/'
    template_name = 'fake'

# Generated at 2022-06-11 20:30:42.216895
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = './cookiecutter_conventional_replay'
    template_name = 'art'
    context = {'cookiecutter': {'name': 'Atlas'}}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:30:48.459264
# Unit test for function load
def test_load():
    if not os.path.exists("tests/test-files/test-replay"):
        os.makedirs("tests/test-files/test-replay")

    path = "tests/test-files/test-replay/test.json"
    json_dict = {"test1": "test1", "test2": "test2"}

    with open(path, 'w') as outfile:
        json.dump(json_dict, outfile, indent=2)

    context = load("tests/test-files/test-replay/","test")
    assert context == json_dict



# Generated at 2022-06-11 20:30:51.721611
# Unit test for function dump
def test_dump():
    replay_dir = '/Users/sbcomm/cookiecutter/test_dir'
    template_name = 'test_tm'
    context = {'cookiecutter': {'hello': 'world'}}

    assert 'cookiecutter' in context
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:30:58.291483
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-dump'
    json_file = 'tests/test-dump/cookiecutter-pypackage.json'
    try:
        os.remove(json_file)
    except:
        pass
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'full_name': 'test'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(json_file)


# Generated at 2022-06-11 20:30:59.620563
# Unit test for function load
def test_load():
    context = load('.', './tests/test-repo')
    print(context)

# Generated at 2022-06-11 20:31:03.662521
# Unit test for function load
def test_load():
    template_name = "test"
    replay_dir = "/home"
    context = {"cookiecutter":{"cookiecutter.license": "Apache 2.0"}}
    dump(replay_dir, template_name, context)
    assert context == load(replay_dir, template_name)

# Generated at 2022-06-11 20:31:06.989552
# Unit test for function load
def test_load():
    """Test function load for valid replay file"""
    assert load(os.getcwd() + "/tests/test-replay/", "test-replay-file") == {u'cookiecutter': {u'demo_option': u'Master of the Universe'}}

#Unit test for function dump

# Generated at 2022-06-11 20:31:11.604381
# Unit test for function load
def test_load():
    assert isinstance(load("/Users/chloe/Desktop/Cookiecutter/cookiecutter-django/tests", "cookiecutter.json"), dict)
    assert load("/Users/chloe/Desktop/Cookiecutter/cookiecutter-django/tests", "cookiecutter.json")["cookiecutter"]["project_name"] == "{{ cookiecutter.repo_name }}"
