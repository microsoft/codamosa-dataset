

# Generated at 2022-06-11 20:22:14.374047
# Unit test for function dump
def test_dump():
    DIR = "replay"
    TEMPLATE_NAME = "test_template"
    CONTEXT = {"cookiecutter": {"test_dic": "test"}}
    dump(DIR, TEMPLATE_NAME, CONTEXT)
    # Now load this test replay file
    context_test = load(DIR,TEMPLATE_NAME)
    # Check if the loaded file is the same as the dumped file
    assert context_test == CONTEXT



# Generated at 2022-06-11 20:22:16.325380
# Unit test for function load
def test_load():
    """Unit test for load function."""
    context = load('test_replay', 'test_name')

# Generated at 2022-06-11 20:22:24.890799
# Unit test for function dump
def test_dump():
    replay_dir = '/home/alberto/projects/cookiecutter-pypackage'
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'project_name': 'test-cookiecutter-pypackage',
                'project_slug': 'test_cookiecutter_pypackage',
                'project_version': '0.1',
                'open_source_license': 'MIT license',
                'author_name': 'Alberto Leal',
                'email': 'mail@albertleal.com',
                'description': 'test description'
                }
               }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:22:32.189567
# Unit test for function dump
def test_dump():
    test_replay_dir = 'tests/files/fake-replay-dir'
    test_template_name = 'tests/files/fake-repo-tmpl'
    test_context = {"cookiecutter": {
        "full_name": "Test User",
        "email": "test@example.com",
        "github_username": "TestUser",
        "repo_name": "testrepo"
    }}
    dump(test_replay_dir, test_template_name, test_context)
    assert os.path.isfile('tests/files/fake-replay-dir/testrepo.json')


# Generated at 2022-06-11 20:22:33.700055
# Unit test for function dump
def test_dump():
    context = {"cookiecutter": {"email": "blah@blah.com"}}
    dump('replays/', 'jquery', context)
    assert os.path.exists('replays/jquery.json')

# Generated at 2022-06-11 20:22:41.533827
# Unit test for function load
def test_load():
    import shutil
    from tempfile import mkdtemp
    from unittest import TestCase

    class TestCase(TestCase):
        def setUp(self):
            self.tmp = mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tmp)

    test_case = TestCase()

    try:
        load(self.tmp, 'test')
    except:
        pass
    else:
        test_case.fail('load should raise error if file is missing')

    context = {'cookiecutter': 'foo'}

    dump(self.tmp, 'test', context)

    # Should not raise error
    load(self.tmp, 'test')

    try:
        load(self.tmp, 1)
    except:
        pass
    else:
        test_case.fail

# Generated at 2022-06-11 20:22:48.193688
# Unit test for function dump
def test_dump():
    replay = {}
    replay['cookiecutter'] = {}
    replay['cookiecutter']['project_name'] = 'project_1'
    replay['cookiecutter']['author_name'] = 'author_1'
    replay_dir = '.cookiecutters'
    template_name = 'cookiecutter-pypackage'
    dump(replay_dir, template_name, replay)
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file), 'No replay file created.'
    os.remove(replay_file)
    assert not os.path.isfile(replay_file), 'Replay file not deleted.'


# Generated at 2022-06-11 20:22:50.434243
# Unit test for function get_file_name
def test_get_file_name():
    #if 
    #return os.path.join(replay_dir, file_name)
    assert 1 == 1


# Generated at 2022-06-11 20:22:56.172022
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    try:
        dump('./test_replay', 'test_dump', {'cookiecutter': {'test': 'test'}})
    except Exception as error:
        assert False, 'function dump got unexpected exception {}'.format(error)
    else:
        assert True



# Generated at 2022-06-11 20:22:59.638668
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = '/tmp'
    template_name = 'cookiecutter-pypackage'
    print(get_file_name(replay_dir, template_name))



# Generated at 2022-06-11 20:23:06.269071
# Unit test for function get_file_name
def test_get_file_name():
    """Test for function get_file_name."""
    replay_dir = '~/fake_dir'
    template_name = 'fake_name'
    file_path = os.path.join(replay_dir, template_name + '.json')
    assert get_file_name(replay_dir, template_name) == file_path
    assert get_file_name(replay_dir, 'fake_name.json') == file_path

# Generated at 2022-06-11 20:23:08.985860
# Unit test for function dump
def test_dump():
    rd = os.getcwd()
    tn = 'test'
    ctx = {'cookiecutter': {'test': True}}
    dump(rd, tn, ctx)
    c = load(rd, tn)
    assert c['cookiecutter']['test'] == True
    os.remove(get_file_name(rd, tn))



# Generated at 2022-06-11 20:23:12.981881
# Unit test for function get_file_name
def test_get_file_name():
    # Check that work if suffix is missing
    assert get_file_name("dir", "fake")  == "dir/fake.json"
    # Check that work if suffix is already there
    assert get_file_name("dir", "fake.json") == "dir/fake.json"


# Generated at 2022-06-11 20:23:22.496634
# Unit test for function load
def test_load():
    template_name = 'may_test'
    replay_file = get_file_name('.', template_name)

    ############ test good input ############
    print("\n#### test good input ####")
    context = {'cookiecutter': {'project_name': 'test'}}
    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    output = load('.', template_name)
    print(output)
    print("after load the replay file, it should be the same")
    assert(output == context)

    ############ test bad input #############
    print("\n#### test bad input ####")
    context = {'cookiecutter1': {'project_name': 'test'}}

# Generated at 2022-06-11 20:23:26.632780
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'test_replay')
    template_name = 'test_template'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert('cookiecutter' in context)


# Generated at 2022-06-11 20:23:30.822553
# Unit test for function get_file_name
def test_get_file_name():
    cwd = os.getcwd()
    template = "template"
    replay_dir = os.path.join(cwd, ".cookiecutters_replay")
    template_file = get_file_name(replay_dir, template)
    assert template_file == os.path.join(replay_dir, "{}.json".format(template))


# Generated at 2022-06-11 20:23:33.907920
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/path/to/dir'
    template_name = 'template'
    assert get_file_name(replay_dir, template_name) == '/path/to/dir/template.json'

if __name__=='__main__':
    test_get_file_name()

# Generated at 2022-06-11 20:23:41.126780
# Unit test for function dump
def test_dump():
    from cookiecutter.utils import work_in
    from cookiecutter.main import cookiecutter

    variables = {
        'full_name': 'Joe Smith',
        'email': 'joe.smith@gmail.com',
        'github_username': 'joesmith',
        'project_name': 'joes-project',
        'project_slug': 'joesproject',
        'project_short_description': 'A short description of the project.',
        'repo_name': 'joes-project',
        'pypi_username': 'joesmith',
        'use_pycharm': 'y',
        'command_line_interface': 'argparse',
        'open_source_license': 'BSD license'
    }

    template_name = 'cookiecutter-pypackage'
    replay_

# Generated at 2022-06-11 20:23:48.388360
# Unit test for function load
def test_load():
    template_name = 'template'
    replay_dir = '{}/test_replay'.format(os.path.dirname(__file__))
    context = {'cookiecutter': {'test': 'value'}}
    dump(replay_dir, template_name, context)
    context2 = load(replay_dir, template_name)
    assert(context == context2)
    os.remove('{}/{}.json'.format(replay_dir, template_name))
    os.rmdir(replay_dir)


# Generated at 2022-06-11 20:23:53.418353
# Unit test for function load
def test_load():
    replay_dir = "test_replay"
    template_name = "test_replay_file"
    context = {
        "cookiecutter": {
            "key": "value"
        }
    }

    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert loaded_context == context

# Generated at 2022-06-11 20:24:06.212230
# Unit test for function dump
def test_dump():
    import tempfile

    template_name = 'template_name'
    context = {
        'cookiecutter': {
            'full_name': 'Your name',
            'replay_file': 'replay_file',
        },
    }

    with tempfile.TemporaryDirectory() as replay_dir:
        dump(replay_dir, template_name, context)

        file_name = get_file_name(replay_dir, template_name)
        assert os.path.isfile(file_name) is True

        with open(file_name, 'r') as infile:
            content = infile.read()

        assert len(content.split('\n')) == 7

        context_loaded = load(replay_dir, template_name)
        assert context == context_loaded

        # Test exception on template name

# Generated at 2022-06-11 20:24:17.566100
# Unit test for function dump
def test_dump():
    from cookiecutter import utils

    project_dir = utils.make_empty_dir()
    template_dir = utils.make_empty_dir(suffix='template')
    replay_dir = utils.make_empty_dir(suffix='replay')
    context = {
        'cookiecutter': {
            'foo': 'bar'
        }
    }

    dump(replay_dir, template_dir, context)

    replay_file = get_file_name(replay_dir, template_dir)
    assert os.path.isfile(replay_file)

    with open(replay_file, 'r') as infile:
        new_context = json.load(infile)

    assert new_context == context

    utils.rmtree(project_dir)


# Generated at 2022-06-11 20:24:19.861380
# Unit test for function load
def test_load():
    context = load('.', 'tests/test-repo-pre')
    assert 'cookiecutter' in context
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'


# Generated at 2022-06-11 20:24:26.169586
# Unit test for function load
def test_load():
    import sys
    import re
    import sys
    import os
    import nose
    assert re.search
    assert os.path.exists
    assert os.path.isfile
    assert sys.version_info >= (2, 7)
    assert sys.version_info < (3, 0)
    assert nose
    # nose.run()
    print("pass")

# Generated at 2022-06-11 20:24:29.532988
# Unit test for function load
def test_load():
    replay_dir = 'test_replay_data'
    template_name = 'test_context'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:24:33.130881
# Unit test for function load
def test_load():
    """unit test for load."""
    load('/home/taomeng/Workspace/GitHub/cookiecutter/tests/test-data/replay', 'cookiecutter-pypackage/{{cookiecutter.repo_name}}/')


# Generated at 2022-06-11 20:24:41.069205
# Unit test for function load
def test_load():
    if not os.path.exists("replay-dir"):
        os.makedirs("replay-dir")
    test_data = {"a" : 1, "b" : 2}
    replay_dir = 'replay-dir'
    template_name = 'test'
    dump(replay_dir, template_name, test_data)
    result = load(replay_dir, template_name)
    print("test load result: ", result)
    os.remove("/replay-dir/test.json")
    os.rmdir("replay-dir")

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:24:49.680197
# Unit test for function load

# Generated at 2022-06-11 20:24:56.284673
# Unit test for function load
def test_load():
    context = load('.', 'xyz.json')
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'release_date' in context['cookiecutter']
    assert 'description' in context['cookiecutter']
    assert 'version' in context['cookiecutter']
    assert 'year' in context['cookiecutter']


# Generated at 2022-06-11 20:24:58.232289
# Unit test for function load
def test_load():
    load('/home/yunhao/cookiecutter_proj/tests/fake-repo-pre/', 'fake-repo')



# Generated at 2022-06-11 20:25:04.908834
# Unit test for function load
def test_load():
    replay_file = get_file_name('/home/twcn/code/cookiecutter/tests/test-replay', 'testme')
    context = load('/home/twcn/code/cookiecutter/tests/test-replay', 'testme')
    assert context is not None

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:25:06.592189
# Unit test for function load
def test_load():
    directory = 'tests/replay-files'
    name = 'setup.py'
    context = load(directory, name)

# Generated at 2022-06-11 20:25:17.038235
# Unit test for function dump
def test_dump():
    from cookiecutter import prompt
    from cookiecutter.main import cookiecutter
    replay_dict={}
    replay_dict['cookiecutter']={}
    replay_dict['cookiecutter']['extra_context']={}
    replay_dict['cookiecutter']['extra_context']['repo_name'] = 'repo_name_val'
    replay_dict['cookiecutter']['extra_context']['full_name'] = 'full_name_val'
    replay_dict['_copy_without_render']=[]
    replay_dict['prompt']=[]
    replay_dict['prompt'].append({'name':'repo_name', 'value':'repo_name_val'})

# Generated at 2022-06-11 20:25:21.502544
# Unit test for function load
def test_load():
    """Unit test for load()"""
    # case 1: replay_dir is empty
    # case 2: cookiecutter not in context
    # case 3: context is empty
    # case 4: context is non-empty
    # case 5: template_name is not of type str
    # case 6: replay_file is not found with the specified name
    pass


# Generated at 2022-06-11 20:25:28.724070
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'project_name': 'My Project',
            'motd': 'just for test',
            '_copy_without_render': ['other/'],
        }
    }
    replay_dir = './tests/fixtures'
    template_name = 'tests/fixtures/cookiecutter-pypackage-min'
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:25:33.969715
# Unit test for function dump
def test_dump():
    context = {"identifier" : "context_test",
        "cookiecutter": {
            "name": "test_name",
            "email": "test_email",
            "username": "test_username"
    }}
    replay_dir = '/home/marc/Documents/m2/recherche/masymos/test/test_cc/test_replay/'
    template_name = 'test_template'
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:25:37.716483
# Unit test for function load
def test_load():
    replay_dir = 'C:\projects\personal\cookiecutter-pipproject\\tests\replay_dir\cookiecutter_replay_dir'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert(context['cookiecutter']['_template'] == 'cookiecutter-pypackage')


# Generated at 2022-06-11 20:25:41.587215
# Unit test for function load
def test_load():
    """
    Test the load function in replay.py
    """
    replay_dir = 'Z:\GitHub/cookiecutter-pypackage/replay'
    template_name = 'cookiecutter-pypackage.json'
    assert 'cookiecutter' in load(replay_dir, template_name)


# Generated at 2022-06-11 20:25:48.345309
# Unit test for function load
def test_load():
    """
    Test if load is working as expected
    """
    # Set env
    replay_dir = 'sampledir'
    template_name = 'sampletemplate'
    context = {'cookiecutter': {'project_name': '{{cookiecutter.project_name}}'}}
    dump(replay_dir, template_name, context)
    assert(load(replay_dir, template_name) == context)

# Generated at 2022-06-11 20:25:55.295231
# Unit test for function load
def test_load():
    test_replay_dir = 'tests/fixtures/test-replay'
    test_template_name = 'tests/fixtures/fake-repo-tmpl'
    try:
        context = load(test_replay_dir, test_template_name)
        print ('tests/fixtures/fake-repo-tmpl:', context['cookiecutter'])
        print ('tests/fixtures/fake-repo-pre:', context['cookiecutter'])
    except ValueError as e:
        pass



# Generated at 2022-06-11 20:26:03.159851
# Unit test for function load
def test_load():
    assert load("C:/Users/LENOVO/Documents/GitHub/cookiecutter-business-application/template/", "readme.rst")["cookiecutter"]["app_name"] == "My Blog"

# Generated at 2022-06-11 20:26:08.922265
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre')
    template_name = 'fake-repo-pre'
    context = {
        "cookiecutter": {
            "full_name": "Audrey Roy",
            "email": "audreyr@example.com",
            "github_username": "audreyr",
            "project_name": "My Project",
            "project_slug": "my_project",
            "pypi_username": "audreyr",
            "release_date": "2013-07-07",
            "year": "2013",
            "version": "0.1a1"
        }
    }

    dumped_context = dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:26:15.033785
# Unit test for function load
def test_load():
    """Test for function load."""
    data = {
        "cookiecutter": {
            "author_email": "pascal@pascal.com",
            "author_name": "Pascal",
            "open_source_license": "MIT",
            "project_name": "TesterTests",
        }
    }
    tmpdir = 'tmp/'
    dump(tmpdir, "TesterTests", data)
    result = load(tmpdir, "TesterTests")
    assert result == data
    os.remove(tmpdir + 'TesterTests.json')

# Generated at 2022-06-11 20:26:19.066079
# Unit test for function load
def test_load():
    context = load('.', 'tests/files/replay/Test')
    assert context == {
        'cookiecutter': {
            'full_name': 'Test',
            'name': 'test',
            'replay': 'True'
        }
    }


# Generated at 2022-06-11 20:26:23.225717
# Unit test for function load
def test_load():
    assert load('~/.cookiecutters', 'cookiecutter-pypackage')['cookiecutter']['project_name'] == 'project_name'
    assert load('~/.cookiecutters', 'cookiecutter-pypackage')['package_name'] == 'project_name'


# Generated at 2022-06-11 20:26:27.408322
# Unit test for function load
def test_load():
    """Test load."""
    assert load(replay_dir = './replay', template_name = './examples/example-repo-name') == {"cookiecutter": {"repo_name": "example-repo-name", "repo_description": "An example repo for cookiecutter", "project_name": "Example Repo Name"}}


# Generated at 2022-06-11 20:26:36.978203
# Unit test for function dump
def test_dump():
    """Test if dump functions correctly."""
    replay_dir = 'tests/test-replay'
    context = {
        "cookiecutter": {
            "first_name": "Test",
            "last_name": "Tester",
            "email": "test@tester.com",
            "github_username": "TestTester"
        }
    }
    dump(replay_dir, 'tests/test-replay', context)
    test_file = 'tests/test-replay/tests/test-replay.json'
    with open(test_file, 'r') as infile:
        context = json.load(infile)

    assert context['cookiecutter']['first_name'] == "Test"
    assert context['cookiecutter']['last_name'] == "Tester"

# Generated at 2022-06-11 20:26:45.354467
# Unit test for function dump
def test_dump():
    print("Testing out the dump functionality")
    # Make a new directory called "test_dir" to test this functionality
    os.mkdir("test_dir")
    replay_dir = "test_dir"
    # A mock context for testing
    context = {
        "cookiecutter": {
            "full_name": "Audrey Roy Greenfeld",
            "email": "audreyr@example.com",
            "github_username": "audreyr",
        }
    }
    # A mock template name to be used
    template_name = "test_template"
    # Check that the template name given is of the string type
    assert(isinstance(template_name, str))
    # Check that the context given is of the dictionary type
    assert(isinstance(context, dict))
    # Check that dumping to the test directory works properly

# Generated at 2022-06-11 20:26:50.419751
# Unit test for function dump
def test_dump():
    replay_dir = "tests/test-replay"
    template_name = "python_package"
    context = {'cookiecutter': {'project_name': "My Project Name", 'author': "author name"}}
    dump(replay_dir, template_name, context)
    assert os.path.exists('tests/test-replay/python_package.json')



# Generated at 2022-06-11 20:26:53.188814
# Unit test for function dump
def test_dump():
    """Test unit for function dump."""
    replay_dir = '/tmp/replay_dir'
    template_name = 'foobar'

# Generated at 2022-06-11 20:27:10.331812
# Unit test for function load
def test_load():
    assert load('../tests/replay/','example') == {"cookiecutter": {"name": "Example", "domain_name": "example", "version": "0.1.0", "description": "A short description of the project.", "keywords": "example, cookiecutter", "author_name": "Firstname Lastname", "author_email": "firstname.lastname@example.com", "year": "2014", "github_username": "audreyr", "open_source_license": "MIT", "pypi_username": "audreyr", "install_tool": "pip", "use_pypi_deployment_with_travis": "y"}, "full_name": "Firstname Lastname", "email": "firstname.lastname@example.com"}

# unit test for function dump

# Generated at 2022-06-11 20:27:14.124597
# Unit test for function load
def test_load():
    context = load('/home/sxzhong/.cookiecutters', 'sxzhong/cookiecutter-pypackage')

# Generated at 2022-06-11 20:27:16.613398
# Unit test for function load
def test_load():
    """Unit test for function load"""
    try:
        load(replay_dir='', template_name='')
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-11 20:27:27.925944
# Unit test for function dump
def test_dump():
    # Create a test dir with a dir called 'replay' inside the current dir:
    replay_dir = 'tests/replay'
    # Create a context and a template name:
    context = {'cookiecutter': {'project_name': 'Project Name'}}
    template_name = "project_name"

    # Use function dump to create a replay file with name 'project_name.json' in dir 'replay':
    dump(replay_dir, template_name, context)

    # Get the name of the file:
    replay_file = get_file_name(replay_dir, template_name)
    # Use function load to load the context from the file:
    assert load(replay_dir, template_name) == context

    # Delete the file:
    os.remove(replay_file)
    # Delete the

# Generated at 2022-06-11 20:27:36.434574
# Unit test for function dump
def test_dump():
    # create template 'test_template'
    replay_dir = 'test_replay_dir'
    template_name = 'test_template'
    context = {'cookiecutter': {'project_name':'test_project'}}
    # call dump
    dump(replay_dir, template_name, context)
    # compare loaded context with dumped context
    loaded_context = load(replay_dir, template_name)
    assert loaded_context == context
    # remove replay dir
    import shutil
    shutil.rmtree(replay_dir)

# Generated at 2022-06-11 20:27:40.253408
# Unit test for function load
def test_load():
    replay_dir = '/Users/bean/Desktop/beantest'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:27:46.428926
# Unit test for function load
def test_load():
    """Tests the load function"""
    template_name = 'test_template_name'

    context = {'cookiecutter': {'test': True}}
    replay_dir = 'tests/files/replay'
    dump(replay_dir, template_name, context)

    loaded_data = load(replay_dir, template_name)

    assert 'cookiecutter' in loaded_data
    assert loaded_data == context

    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:27:54.668503
# Unit test for function dump
def test_dump():

    #Arrange
    replay_dir = '.'
    template_name = 'test_template'
    context = {"cookiecutter": {"full_name": "Andrea Zonca", "username": "zonca", "email": "code@andreazonca.com", "github_username": "andreazonca", "project_name": "cookiecutter-minimal-pypackage", "project_slug": "cookiecutter_minimal_pypackage", "version": "0.1.0", "release": "0.1.0", "year": "2015", "description": "A minimal cookiecutter template for a Python package.", "replay_dir": ".", "replay": "y"}}

    #Act
    test_result = dump(replay_dir, template_name, context)

    #Assert

# Generated at 2022-06-11 20:27:55.532082
# Unit test for function dump
def test_dump():
    # TODO
    pass



# Generated at 2022-06-11 20:28:01.241314
# Unit test for function dump
def test_dump():
    # Test correct functionality
    x = 'test.json'
    y = {'cookiecutter': {'abc': '123'}}
    dump('replay-dir', 'test', y)
    assert os.path.isfile(x) is True
    os.remove('test.json')

    # Test invalid type of template name
    template_name_int = 1
    try:
        dump('replay-dir', template_name_int, y)
    except TypeError:
        pass
    assert os.path.isfile(x) is False

    # Test invalid type of context
    context_int = 1
    try:
        dump('replay-dir', 'test', context_int)
    except TypeError:
        pass
    assert os.path.isfile(x) is False

    # Test missing cookiecutter in

# Generated at 2022-06-11 20:28:29.152527
# Unit test for function load
def test_load():

	replay_dir = 'tests/test-load-replay/'
	template_name = 'nix-test'
	test_context = {'cookiecutter': {'full_name': 'John Smith'}}

	# Create replay file
	with open(get_file_name(replay_dir, template_name), 'w') as outfile:
		json.dump(test_context, outfile, indent=2)

	context = load(replay_dir, template_name)

	# Remove replay file
	os.remove(get_file_name(replay_dir, template_name))
	os.removedirs(replay_dir)

	assert test_context == context, 'Unexpected context after load()'

test_load() # Run unit test

# Generated at 2022-06-11 20:28:34.576519
# Unit test for function load
def test_load():
    replay_dir = r'C:\Users\Zhang Jiawei\Desktop\cn_zhangjiawei_cookiecutter-master\replay_dir'
    template_name = 'cookiecutter-pypackage'

    context = load(replay_dir, template_name)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')



# Generated at 2022-06-11 20:28:41.072303
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = '/home/vagrant/cookiecutter-replay'
    template_name = 'pypackage'
    context = {'project_name': 'pypackage'}
    dump(replay_dir, template_name, context)
    print(load(replay_dir, template_name))

# Generated at 2022-06-11 20:28:43.932545
# Unit test for function load
def test_load():
    try:
        load(replay_dir, template_name)
    except Exception as e:
        print("Can't display information ", e)



# Generated at 2022-06-11 20:28:47.606898
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-data'
    template_name = 'template'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['gh_username'] == 'cookiecutter'

# Generated at 2022-06-11 20:28:50.274766
# Unit test for function load

# Generated at 2022-06-11 20:28:53.229365
# Unit test for function dump
def test_dump():
    replay_dir = 'test/test_replay'
    template_name = 'test_template'
    context = {
        "cookiecutter": {
            "project_name": "Test Project",
            "author_name": "Test Author"
        }
    }
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:28:56.616239
# Unit test for function load
def test_load():
    context = load('/home/shadiakiki1986/hooked/teaching/bin/../tmp/cookiecutter-data', 'foo')
    assert context['cookiecutter']['full_name']=="Shadi Akiki"

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:29:01.749632
# Unit test for function load
def test_load():
    print('Test load')
    try:
        print(load(r'/Users/arc/Desktop/Test/cookiecutter-replay', 'cookiecutter-pypackage'))
    except Exception as e:
        print(e)

    print('Done')

test_load()

# Generated at 2022-06-11 20:29:03.094338
# Unit test for function load
def test_load():
    load("C:\\Users\\Administrator\\Desktop\\test","PY2TEST")

# Generated at 2022-06-11 20:29:54.748873
# Unit test for function load
def test_load():
    import shutil
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    assert os.path.exists(temp_dir)

    template_dir = os.path.dirname(__file__)
    replay_dir = os.path.join(template_dir, 'test_replay_dir')
    assert os.path.exists(replay_dir)

    # Copy the test_replay_dir to the temporary directory
    shutil.copytree(replay_dir, temp_dir)
    replay_dir = os.path.join(temp_dir, 'test_replay_dir')
    assert os.path.exists(replay_dir)

    # Load data from the test_replay_dir
    template_name = 'python_package'
    context = load

# Generated at 2022-06-11 20:29:59.524317
# Unit test for function dump
def test_dump():
    replay_dir = '../tests/test-cookiecutter-replay'
    template_name = 'test-template'
    context = {
        'cookiecutter': {
            'author_email': 'me@foo.com',
            'author_name': 'me',
            'description': 'hello',
            'name': 'my_package'
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:30:02.683566
# Unit test for function load
def test_load():
    context = load("./replay", "default")
    # assert True
    # assert "cookiecutter" in context


# Generated at 2022-06-11 20:30:04.962928
# Unit test for function load
def test_load():
    print(load(os.path.join(os.getcwd(), 'tests/test-dir', 'replay'), 'cookiecutter-pypackage'))


# Generated at 2022-06-11 20:30:08.190034
# Unit test for function load
def test_load():
    with open("test_load.json", 'r') as infile:
        context = json.load(infile)

    if ('cookiecutter' not in context):
        raise ValueError('Context is required to contain a cookiecutter key')

    return context



# Generated at 2022-06-11 20:30:15.652946
# Unit test for function load
def test_load():
    """
    Unit tests for load function.
    """
    template_name = 'test_name'
    context = {'cookiecutter': {'name': 'test'}}
    replay_dir = 'replay_dir'
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(replay_dir+"/"+template_name+'.json')
    os.rmdir(replay_dir)



# Generated at 2022-06-11 20:30:23.164102
# Unit test for function load
def test_load():
    # First deal with exceptions
    # The following would throw an error, since the key 'cookiecutter' does not exist in the context
    try:
        load('replay', 'python-minimal-43kd3a')
    except Exception as e:
        assert type(e) == ValueError

    # Test the correct usage of loading data from a file
    data = load('replay', 'python-minimal-43kd3a')

# Generated at 2022-06-11 20:30:30.547948
# Unit test for function load
def test_load():
    """Write to a file and check if the contents written are correct"""
    template_name = 'test'
    replay_dir = 'test_replay'

    context = {'cookiecutter':
               {'project_name': 'test_project_name'}}

    dump(replay_dir, template_name, context)

    result = load(replay_dir, template_name)
    assert 'cookiecutter' in result
    assert result['cookiecutter'] == context['cookiecutter']

    # delete the test_replay directory as it is not required
    if os.path.exists(replay_dir):
        os.remove(replay_dir)

# Generated at 2022-06-11 20:30:38.424693
# Unit test for function load
def test_load():
    from datetime import datetime, timedelta
    now = datetime.now()

# Generated at 2022-06-11 20:30:40.257285
# Unit test for function load