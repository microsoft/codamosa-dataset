

# Generated at 2022-06-11 20:22:26.953929
# Unit test for function load
def test_load():
    from shutil import rmtree
    from tempfile import mkdtemp

    temp_path = mkdtemp()
    replay_file = get_file_name(temp_path, 'testing')
    data = {
        'cookiecutter': {
            'name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'cookiecutter-pypackage',
        }
    }

    with open(replay_file, 'w') as outfile:
        json.dump(data, outfile)

    result = load(temp_path, 'testing')
    rmtree(temp_path)

    assert result == data


# Generated at 2022-06-11 20:22:29.613820
# Unit test for function load
def test_load():
    context = load(os.path.expanduser('~/.cookiecutters'), 'cookiecutter-pypackage')
    assert isinstance(context, dict)
    assert 'cookiecutter' in context

# Generated at 2022-06-11 20:22:31.663164
# Unit test for function load
def test_load():
    """Unit test for function load"""
    reload(context)
    assert context == load(replay_dir, template_name)



# Generated at 2022-06-11 20:22:36.568695
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "replay"
    template_name = "template_name"
    result = get_file_name(replay_dir, template_name)
    expected_result = "replay\\template_name.json"
    assert(result == expected_result)


# Generated at 2022-06-11 20:22:40.066108
# Unit test for function load
def test_load():
	replay_dir = "/Users/chuan/Desktop/Proj/cookiecutter-pypackage-minimal/"
	template_name = "cookiecutter.json"
	context = load(replay_dir, template_name)

# Generated at 2022-06-11 20:22:45.894518
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = 'C:\\Users\\Alex\\AppData\\Local\\Temp\\cookiecutter-a111a0a9'
    template_name = 'cookiecutter-pypackage'
    assert get_file_name(replay_dir, template_name) == 'C:\\Users\\Alex\\AppData\\Local\\Temp\\cookiecutter-a111a0a9\\cookiecutter-pypackage.json'



# Generated at 2022-06-11 20:22:47.905455
# Unit test for function load
def test_load():
    context = load("./replay/", "test")
    assert context is not None
    assert "cookiecutter" in context


# Generated at 2022-06-11 20:22:49.429146
# Unit test for function load
def test_load():
    context = load('replay', 'cookiecutter-pypackage')


# Generated at 2022-06-11 20:22:59.342515
# Unit test for function load
def test_load():
    context = load('/home/ubuntu/cookiecutter-docker-new/cookiecutter_replay','test')
    for key,value in context.items():
        if key == 'repo_name':
            print("repo_name : "+value)
        if key == 'project_name':
            print("project_name : "+value)
        if key == 'author_name':
            print("author_name : "+value)
        if key == 'email':
            print("email : "+value)
        if key == 'description':
            print("description : "+value)
        if key == 'domain_name':
            print("domain_name : "+value)
        if key == 'version':
            print("version : "+value)

# Generated at 2022-06-11 20:23:03.673551
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/foo-bar'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict), 'Context is a dict'



# Generated at 2022-06-11 20:23:16.327733
# Unit test for function dump
def test_dump():
    replay_dir = '.'
    template_name = 'dummy'

# Generated at 2022-06-11 20:23:17.793920
# Unit test for function load
def test_load():
    assert isinstance(load('tests/test-replay', 'tests/test-template'), dict)


# Generated at 2022-06-11 20:23:22.898800
# Unit test for function load
def test_load():
	expect = {
			  "cookiecutter": {
			    "project_name": "Project Name"
			  }
			}
	result = load(replay_dir = '.', template_name = 'cookiecutter-pypackage')
	if result == expect:
		print('test load() passed')
	else:
		print('test load() failed')


# Generated at 2022-06-11 20:23:24.106624
# Unit test for function load
def test_load():
    load('templates', 'fake')



# Generated at 2022-06-11 20:23:28.246469
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = 'test_replay'
    template_name = 'test_template'
    context = {'cookiecutter': {'test_key': 'test_value'}}
    try:
        dump(replay_dir, template_name, context)
    except IOError as e:
        print(e)
    except TypeError as e:
        print(e)
    except ValueError as e:
        print(e)


# Generated at 2022-06-11 20:23:33.115601
# Unit test for function dump
def test_dump():
    replay_dir = os.getcwd()
    template_name = 'cookiecutter-pypackage'
    context = {
        'cookiecutter': {
            "author_email": "chetan@chetan.com",
            "author_name": "chetan",
            "description": "A Python package project template.",
            "full_name": "chetan",
            "open_source_license": "MIT license",
            "project_name": "test_dump_project"
        }
    }

    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:23:36.689748
# Unit test for function load
def test_load():
    replay_dir = 'foo'
    template_name = 'bar'
    context = load(replay_dir, template_name)
    if not isinstance(context, dict):
        raise TypeError('Context is required to be of type dict')


# Generated at 2022-06-11 20:23:39.788541
# Unit test for function load
def test_load():
    replay_dir = 'test_dir'
    template_name = 'boilerplate'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert context['cookiecutter'] is not None
    assert '_template' in context
    assert context['_template'] is not None

# Generated at 2022-06-11 20:23:42.119431
# Unit test for function dump
def test_dump():
    the_files = os.listdir('/home/anna/test-repo-1/')
    assert 'test.json' in the_files


# Generated at 2022-06-11 20:23:46.798420
# Unit test for function load
def test_load():
    replay_dir = '/Users/matt/Documents/projects/python/cookiecutter/cookiecutter/replay'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:23:54.411209
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = '/tmp/cookiecutter/cookiecutter_replay_test'
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'full_name': 'gl'}}

# Generated at 2022-06-11 20:23:57.576396
# Unit test for function load
def test_load():
    if __name__ == '__main__':
        context = load('C:\\Users\\TuanTran\\Desktop\\tuan-cookiecutter\\cookiecutters\\flask-vue', 'flask-vue')
        print(context)


# Generated at 2022-06-11 20:24:07.709244
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-dump'
    template_name = 'audrey'
    context = {
        "cookiecutter": {
            "full_name": "Monty Python",
            "email": "monty@python.org",
            "project_name": "Cookiecutter Test",
            "project_short_description": "A short description of the project.",
            "pypi_username": "audrey",
            "github_username": "audreyr",
            "version": "0.1.0",
            "release_date": "2015-06-01",
            "year": "2015"
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:24:18.702243
# Unit test for function load
def test_load():
    """Test the load() function."""
    from cookiecutter.main import cookiecutter

    replay_dir = '/tmp/cookiecutter-replay'
    template_name = 'gh:audreyr/cookiecutter-pypackage'
    response_file_path = '/tmp/cookiecutter'

    answers = {
        'full_name': 'John Doe',
        'email': 'john@doe.com',
        'project_name': 'My Project',
        'project_slug': 'my_project',
        'release_date': '2014/01/01',
    }

    # Run cookiecutter the first time

# Generated at 2022-06-11 20:24:28.542670
# Unit test for function dump
def test_dump():
    # Test if error raise when replay_dir is not exist
    replay_dir = "replay_dir"
    template_name = "template_name"
    context = {"cookiecutter": "cookiecutter"}
    assert dump(replay_dir, template_name, context) == None

    # Test if error raise when template_name is not string
    replay_dir = "replay_dir"
    template_name = 5
    context = {"cookiecutter": "cookiecutter"}
    assert dump(replay_dir, template_name, context) == None

    # Test if error raise when context is not dictionary
    replay_dir = "replay_dir"
    template_name = "template_name"
    context = 5
    assert dump(replay_dir, template_name, context) == None

    # Test if error raise when

# Generated at 2022-06-11 20:24:33.118100
# Unit test for function load
def test_load():
    replay_dir = os.path.abspath(os.path.join(os.getcwd(), 'replay'))
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'


# Generated at 2022-06-11 20:24:39.540052
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import os
    import tempfile

    temp_dir = tempfile.mkdtemp()
    template_name = 'abc'
    context = {'a': 1, 'b': 2}

    # test non-exist replay dir
    with open(os.path.join(temp_dir, 'replay.json'), 'r') as infile:
        ans = json.load(infile)

    assert ans == context


# Generated at 2022-06-11 20:24:47.997636
# Unit test for function load

# Generated at 2022-06-11 20:24:51.761020
# Unit test for function dump
def test_dump():
    """
    Unit test for function dump
    """
    replay_dir = "D:\\GitHub\\Cookiecutter\\cookiecutter\\replay"
    template_name = "test_template"
    context = {"cookiecutter": {"bootcamp": "test.json"}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:25:01.297998
# Unit test for function load
def test_load():
    import os
    import sys
    import shutil
    import tempfile
    import unittest

    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree
    from cookiecutter import replay

    EXAMPLE_REPO_URL = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    TEMPLATE = 'cookiecutter-pypackage'

    def _remove_tempdir(path):
        if os.path.exists(path):
            try:
                rmtree(path)
            except OSError as exc:
                exc_type, exc_value, exc_tb = sys.exc_info()

# Generated at 2022-06-11 20:25:06.562068
# Unit test for function dump
def test_dump():
    template_name = 'test'
    replay_dir = '~/.cookiecutter_replay/'
    context = {
        "cookiecutter": {
            "project_name": "test"
        }
    }

    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:25:10.812002
# Unit test for function load
def test_load():
    replay_file = get_file_name(replay_dir,template_name)
    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)
    assert(load(replay_dir,template_name) == context)



# Generated at 2022-06-11 20:25:16.025024
# Unit test for function dump
def test_dump():
    context = {
        "cookiecutter": {
            "full_name": "Jane Doe",
            "email": "janedoe@example.com",
            "github_username": "jane-doe"
        }
    }
    dump('./', 'cookiecutter-pypackage', context)


# Generated at 2022-06-11 20:25:19.099390
# Unit test for function load
def test_load():
    assert isinstance(load(os.path.expanduser('~/.cookiecutters/replay'), 'cookiecutter-pypackage'), dict)


# Generated at 2022-06-11 20:25:21.745676
# Unit test for function load
def test_load():
	context = load('replay', 'python-hello-world')
	print(context)
	
if __name__ == '__main__':
	test_load()

# Generated at 2022-06-11 20:25:26.125427
# Unit test for function load
def test_load():
    """Load is the function that reads json data from file."""
    assert not load("C:\\Users\\home\\Desktop\\cookiecutter-sphinxdoc", "C:\\Users\\home\\Desktop\\cookiecutter-sphinxdoc\\cookiecutter.json")


# Generated at 2022-06-11 20:25:31.628131
# Unit test for function load
def test_load():
    assert(load('test/test_data/test_replay/', 'test_replay') == {
        'cookiecutter': {
            'full_name': 'testfullname',
            'email': 'testemail',
            'github_username': 'testgithub',
            'project_name': 'test_project',
            'project_slug': 'testproject',
        }
    })


# Generated at 2022-06-11 20:25:34.506459
# Unit test for function load
def test_load():
    assert(load('replay', 'my_template') == {"cookiecutter": {"full_name": "Willie T. Forres", "email": "wtf@example.com", "github_username": "wil-foo", "project_name": "my_template"}})


# Generated at 2022-06-11 20:25:39.465588
# Unit test for function dump
def test_dump():
    from cookiecutter.main import cookiecutter
    # Create a template with replay_dir using the default args
    project_dir = cookiecutter(
        'tests/test-data/fake-repo-tmpl',
        no_input=True,
        replay=True,
    )
    # Get the context that was created
    context = load(project_dir, 'fake-repo-tmpl')
    # Get the keys that are expected
    expected_keys = ['full_name', 'email', 'project_name', 'project_slug', 'select']
    # Check those keys exist in the context
    for key in expected_keys:
        assert key in context['cookiecutter']
    print ("replay.dump function working correctly")


# Generated at 2022-06-11 20:25:41.942196
# Unit test for function load
def test_load():
    context = load(replay_dir = '.', template_name = 'template_name')
    assert 'cookiecutter' in context
    return context

# Generated at 2022-06-11 20:25:53.436239
# Unit test for function dump
def test_dump():
    template = 'hello-world-python'
    replay_dir = '/tmp/test'
    context = dict()
    context['cookiecutter'] = dict()
    context['cookiecutter']['full_name'] = 'Ryan S. Brown'
    context['cookiecutter']['email'] = 'ryansb@cisco.com'
    context['cookiecutter']['project_name'] = 'hello-world'
    replay_file = get_file_name(replay_dir, template)
    dump(replay_dir, template, context)
    assert os.path.isfile(replay_file)
    os.remove(replay_file)


# Generated at 2022-06-11 20:26:01.240189
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'test'
    replay_dir = 'cookiecutter'

    test_data = {'cookie': 'cookie', 'cutter': 'cutter'}
    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'w') as outfile:
        json.dump(test_data, outfile, indent=2)

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    assert context == test_data


# Generated at 2022-06-11 20:26:03.995957
# Unit test for function dump
def test_dump():
    context={'cookiecutter': {'project_name': 'hello-world', 'replay': {'cookiecutter.json': {'fizz': 'buzz'}}}}
    dump('/Users/ShawYe/Desktop/cookiecutter-c-project-master/', 'cookiecutter.json', context)


# Generated at 2022-06-11 20:26:05.976157
# Unit test for function load
def test_load():
    context = load('./', 'template')
    print("The context is {}".format(context))

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-11 20:26:08.454510
# Unit test for function dump
def test_dump():
    replay_dir = "tmp_replay"
    template_name = "tmp_template_name"
    context = {}
    pass

# Generated at 2022-06-11 20:26:11.092159
# Unit test for function dump
def test_dump():
    """Test for dump function."""
    from contextlib import contextmanager
    import tempfi

# Generated at 2022-06-11 20:26:14.087707
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'full_name': 'Jhon Doe'}}
    dump('tests/replay', 'example_template', context)

    file_name = get_file_name('tests/replay', 'example_template')

    assert os.path.isfile(file_name)


# Generated at 2022-06-11 20:26:24.136771
# Unit test for function load
def test_load():
    import unittest
    import os
    import shutil
    import tempfile
    from cookiecutter.main import cookiecutter

    class TestCookiecutter(unittest.TestCase):
        def setUp(self):
            self.template = "https://github.com/yense/cookiecutter-pypackage-minimal.git"
            tmp_dir = tempfile.mkdtemp()
            self.output_dir = os.path.join(tmp_dir, 'fake-project')
            self.replay_dir = os.path.join(tmp_dir, 'replay')

# Generated at 2022-06-11 20:26:34.816364
# Unit test for function load
def test_load():
    replay_dir = 'replay/dir'
    template_name = 'replay_templatename'

# Generated at 2022-06-11 20:26:44.455905
# Unit test for function dump
def test_dump():
    import os
    import shutil
    replay_dir = "replay_dir"
    try:
        os.mkdir(replay_dir)
    except OSError:
        print ("Creation of the directory %s failed" % replay_dir)
    else:
        print ("Successfully created the directory %s " % replay_dir)

    template_name = "cc_template"
    context = {
        "cookiecutter": {
            "github_username": "owner",
            "repo_name": "repo_name",
            "project_name": "project_name",
            "description": "description",
            "author_name": "author_name",
            "email": "email",
            "year": "year"
        }
    }

# Generated at 2022-06-11 20:26:48.553182
# Unit test for function load
def test_load():
    context = load("/home/shuang/.cookiecutters/", "test_name")
    assert(context['cookiecutter']['test'] == 48)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:26:55.029665
# Unit test for function dump
def test_dump():
    replay_dir = os.path.expanduser('~/.cookiecutter_replay')
    template_name = 'test_template'
    context = {'cookiecutter':{'test_key':'test_value'}}
    dump(replay_dir, template_name, context)
    # Result is stored in file ~/.cookiecutter_replay/test_template_name.json


# Generated at 2022-06-11 20:27:00.608144
# Unit test for function dump
def test_dump():
    import tempfile
    context = {'cookiecutter': {'full_name': 'example'}}
    template_name = 'test'

    with tempfile.TemporaryDirectory() as temp_dir:
        replay_dir = os.path.join(temp_dir, 'replay')
        dump(replay_dir, template_name, context)
        loaded_context = load(replay_dir, template_name)
        assert context == loaded_context


# Generated at 2022-06-11 20:27:02.981652
# Unit test for function load
def test_load():
    template_name = 'pytest'
    replay_dir = '/Users/kenneth.li/Documents/cookiecutter_test'
    context = load(replay_dir, template_name)
    print(context)
    print(context['cookiecutter'])


test_load()

# Generated at 2022-06-11 20:27:08.570867
# Unit test for function load
def test_load():
    output = load('tests/test-output/replay', 'test-output')
    expect = {'cookiecutter': {u'date': u'2017-03-01', u'full_name': u'Tzu-ping Chung', u'email': u'uranusjr@gmail.com', u'github_username': u'uranusjr', u'project_slug': u'test_project', u'project_name': u'Test Project', u'year': u'2017'}}
    assert output == expect

# Generated at 2022-06-11 20:27:12.134883
# Unit test for function load
def test_load():
    context = load(replay_dir = './replay', template_name = 'julia_cookie')
    print(context)


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:27:19.656691
# Unit test for function load
def test_load():
    context = load('tests/test-data/fake-repo-pre/', 'fake-user')

# Generated at 2022-06-11 20:27:27.240485
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile
    tempdir = tempfile.mkdtemp()
    test_dir = os.path.join(tempdir, 'replay')
    failed = True

    try:
        # test valid inputs
        dump(test_dir, "TEMPLATE_NAME", {'cookiecutter': {'mycontext_key': 'mycontext_value'}})
        failed = False
    finally:
        os.removedirs(tempdir)

    assert not failed


# Generated at 2022-06-11 20:27:32.501797
# Unit test for function dump

# Generated at 2022-06-11 20:27:36.813396
# Unit test for function load
def test_load():
    replay_dir = "replay"
    template_name = "cookiecutter-pypackage"
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:27:47.728077
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter import utils
    from cookiecutter import replay
    import os
    import shutil
    import tempfile

    # Test setup: create a temporary project
    replay_dir = tempfile.mkdtemp()
    template = 'tests/test-templates/fake-repo-pre'
    output_dir = tempfile.mkdtemp()
    result = replay.load(replay_dir, template)
    if result['cookiecutter']['repo_dir'] == template:
        print('test_load: True')
    else:
        print('test_load: False')

    # Test cleanup
    shutil.rmtree(replay_dir)
    shutil.rmtree(output_dir)


# Generated at 2022-06-11 20:27:55.243242
# Unit test for function dump
def test_dump():
    cur_path = os.path.abspath(os.curdir)
    replay_dir = os.path.join(cur_path, 'replay')
    template_name = "test_template"
    context = {
        'cookiecutter': {
            'full_name': 'Gus Lindemann',
            'email': 'gus@example.com'
        }
    }
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, 'test_template.json'))

    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == "Gus Lindemann"



# Generated at 2022-06-11 20:27:59.563485
# Unit test for function load
def test_load():
    replay_dir = "replay"
    template_name = "cookiecutter-pypackage"
    context = load(replay_dir, template_name)
    assert context["cookiecutter"]["full_name"] == "Cookiecutter PyPackage", "Load not as expected"
    # assert context["cookiecutter"]["email"] == "test@test.test", "Load not as expected"
    print("test_load() passed")

test_load()

# Generated at 2022-06-11 20:28:06.977761
# Unit test for function load
def test_load():
    rdir = 'tests/test-replay'
    template = 'tests/fake-repo-pre/'
    context = load(rdir, template)
    assert(context["cookiecutter"]["full_name"] == "Audrey Roy Greenfeld")
    assert(context["cookiecutter"]["email"] == "audreyr@example.com")
    assert(context["cookiecutter"]["project_name"] == "Cookiecutter")
    assert(context["cookiecutter"]["project_slug"] == "cookiecutter")
    assert(context["cookiecutter"]["project_short_description"] == "A command-line utility that creates projects from cookiecutters (project templates). E.g. Python package projects, jQuery plugin projects.")

# Generated at 2022-06-11 20:28:16.067284
# Unit test for function dump
def test_dump():
    # Creating directory
    import time
    import shutil
    test_dir = os.path.join('/home/ubuntu', 'test_output') + time.strftime("%Y%m%d-%H%M%S")
    os.makedirs(test_dir)
    # Creating context

# Generated at 2022-06-11 20:28:20.747974
# Unit test for function dump
def test_dump():
    replay_dir = "{{ cookiecutter.project_name }}"
    template_name = "{{ cookiecutter.project_name }}"
    # context = "{{ cookiecutter.project_name }}"
    context = {"cookiecutter":"{{ cookiecutter.project_name }}"}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:28:22.933095
# Unit test for function load
def test_load():
    try:
        load(".", "foo")
        assert True
    except FileNotFoundError:
        assert False

# Generated at 2022-06-11 20:28:29.077765
# Unit test for function dump
def test_dump():
    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))

    if not isinstance(template_name, str):
        raise TypeError('Template name is required to be of type str')

    if not isinstance(context, dict):
        raise TypeError('Context is required to be of type dict')

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)


# Generated at 2022-06-11 20:28:34.079944
# Unit test for function load
def test_load():
    template_name = 'openstack/oslo.config'
    replay_dir = 'replay'
    dump(replay_dir, template_name, {'cookiecutter': {'foo': 'bar'}})

    context = load(replay_dir, template_name)
    assert context['cookiecutter']['foo'] == 'bar'

# Generated at 2022-06-11 20:28:37.959199
# Unit test for function load
def test_load():
    context = load('tests/test-replay', 'tests/fake-repo-tmpl')
    assert context['cookiecutter']['repo_name'] == 'Audrey Roy Greenfeld'


# Generated at 2022-06-11 20:28:46.426384
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('/replay', 'template.json')
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:28:47.462842
# Unit test for function load
def test_load():
    assert(len(load(0, "test")) == 0)

# Generated at 2022-06-11 20:28:52.328974
# Unit test for function load
def test_load():
    test_context = load('./tests/replay', 'tests/fake-repo-tmpl')

# Generated at 2022-06-11 20:28:54.826324
# Unit test for function load
def test_load():
    """Testing load function"""
    context = load('cookiecutter', 'cookiecutter')
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:29:00.326417
# Unit test for function load
def test_load():
    import json
    reload(json)
    # read replay file generated from template from commit c1a12d7
    f = open("test_load_json", "r")
    replay_string = f.read()
    f.close()
    replay_dict = json.loads(replay_string)
    assert replay_dict['cookiecutter']['author_github_username'] == "cookiecutter"
    assert replay_dict['cookiecutter']['author_name'] == "Audrey Roy Greenfeld"
    assert replay_dict['cookiecutter']['author_email'] == "audreyr@example.com"
    assert replay_dict['cookiecutter']['project_name'] == "example_project"
    assert replay_dict['cookiecutter']['repo_name'] == "example_project"

# Generated at 2022-06-11 20:29:04.665733
# Unit test for function load
def test_load():
    """Unit test for function load"""
    json_file = 'test.json'
    with open(json_file, 'w') as outfile:
        json.dump({"cookiecutter" :"cookiecutter"}, outfile, indent=2)

    context = load('.', json_file)
    assert(context['cookiecutter'] == "cookiecutter")

# Generated at 2022-06-11 20:29:15.223321
# Unit test for function load
def test_load():
    template_name = 'test.json'
    replay_dir = './test_replay'
    replay_content = '{"cookiecutter": {"name": "test-name"}}'
    replay_file = get_file_name(replay_dir, template_name)

    if os.path.isfile(replay_file):
        os.remove(replay_file)

    with open(replay_file, 'w') as outfile:
        outfile.write(replay_content)

    result = load(replay_dir, template_name)
    assert result['cookiecutter']['name'] == 'test-name'
    assert result['cookiecutter']['name'] != 'test-wrong'

    os.remove(replay_file)


# Generated at 2022-06-11 20:29:18.762874
# Unit test for function load
def test_load():
    d = '.'
    f = 'template'
    context = {"cookiecutter": {"replay": {"default_context": {}}}}
    dump(d, f, context)
    r = load(d, f)
    print (r)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:29:25.437779
# Unit test for function load
def test_load():
    assert load("tests/test-replay/", "replay_template1") == {'cookiecutter': {'author_email': '{{ cookiecutter.author_email }}', 'author': '{{ cookiecutter.author }}'}}
    assert load("tests/test-replay/", "replay_template2") == {'cookiecutter': {'repo_name': '{{ cookiecutter.repo_name }}', 'author': '{{ cookiecutter.author }}'}}



# Generated at 2022-06-11 20:29:31.204771
# Unit test for function dump
def test_dump():
    replay_dir = '/home/test'
    template_name = 'test'
    context = {
        'cookiecutter': {
            'full_name': 'test',
            'email': 'test@test.com',
            'replay_dir': '/home/test'
        }
    }
    dump(replay_dir, template_name, context)
    assert(os.path.isfile(get_file_name(replay_dir, template_name)))


# Generated at 2022-06-11 20:29:48.190534
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/testdata/'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-11 20:29:55.356636
# Unit test for function load
def test_load():
    """Tests if the load function from replay.py works."""
    replay_dir = os.path.join(os.path.join(os.environ['HOME'], 'Cookiecutters'), 'test')
    template_name = 'cookiecutter-django'

# Generated at 2022-06-11 20:29:58.006309
# Unit test for function load
def test_load():
    context = load('/Users/ybw/Documents/GitHub/cookiecutter-pypackage/tests/', 'pypackage')
    print(context)


# Generated at 2022-06-11 20:30:06.815423
# Unit test for function load
def test_load():

    replay_dir = "replay-dir"
    template_name = "dummy"

    result = load(replay_dir,template_name)

    if result['cookiecutter']['name'] == "dummy" and result['cookiecutter']['website'] == "dummy":
        print("Test passed. Expected: {'cookiecutter': {'name': 'dummy', 'website': 'dummy'}}")
    else:
        print("Test failed. Expected: {'cookiecutter': {'name': 'dummy', 'website': 'dummy'}}")




# Main
if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:30:10.971776
# Unit test for function load
def test_load():
    """test_load."""
    import tempfile
    from cookiecutter.replay import load

    template_name = "test"
    cookiecutter_dict = {"cookiecutter": {"replay": True}}

    with tempfile.TemporaryDirectory() as tmp_dir_name:
        dump(tmp_dir_name, template_name, cookiecutter_dict)
        context = load(tmp_dir_name, template_name)

    assert template_name == template_name
    assert cookiecutter_dict == context


# Generated at 2022-06-11 20:30:19.995498
# Unit test for function dump
def test_dump():
    import glob
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    replay_dir = os.path.join(os.path.dirname(__file__), 'replay_dir')
    template_name = 'cookiecutter-pypackage'
    context = {
        'cookiecutter': {
            'name': 'Test_check_name',
            'full_name': 'Test_check_full_name',
            'email': 'test@test.com',
            'project_name': 'Test_check_project_name',
            'use_pypi_deployment_with_travis': 'y',
            'command_line_interface': 'click',
            'open_source_license': 'MIT license',
        }
    }


# Generated at 2022-06-11 20:30:29.842598
# Unit test for function dump

# Generated at 2022-06-11 20:30:32.416095
# Unit test for function load
def test_load():
    replay_dir = r'D:\github\cookiecutter-replay'
    template_name = 'QHM'
    context = load(replay_dir, template_name)
    print(context)

# Generated at 2022-06-11 20:30:38.077835
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.curdir, 'test_dump')
    template_name = 'test'
    context = {'cookiecutter': {'foo': 'bar'}}
    dump(replay_dir, template_name, context)

    # Compare with what the file says
    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        expected_context = json.load(infile)
    assert expected_context == context


# Generated at 2022-06-11 20:30:42.767452
# Unit test for function load
def test_load():
    context = load('C:\\Users\\x\\Desktop\\Projects\\cookiecutter-py-app\\tests\\test-output\hello_world', 'hello_world')
    print(context)
    print(context['cookiecutter'])
    for key, value in context['cookiecutter'].items():
        print('key:{}, value:{}'.format(key, value))


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:31:10.206049
# Unit test for function load
def test_load():
    replay_dir = 'C:/Users/prath/AppData/Local/Temp'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert load(replay_dir, template_name) == context
if __name__ == '__main__':
    test_load()


# Generated at 2022-06-11 20:31:19.299940
# Unit test for function load
def test_load():
    """Unit test for function load."""
    # Check for error when context is not dict
    test_replay_dir = '/tmp/cookiecutter'
    test_template_name = 'some_template'
    test_context = ['a', 'b', 'c']
    try:
        dump(test_replay_dir, test_template_name, test_context)
    except TypeError as e:
        assert 'Context is required to be of type dict' in e.args[0]

    # Check for error when context does not contain cookiecutter key
    test_context = {'foo': 'bar'}

# Generated at 2022-06-11 20:31:22.086547
# Unit test for function load
def test_load():
    """Test for load function."""
    template_name = 'cookiecutter-pypackage'
    replay_dir = "E:\cookiecutter-replay"
    context = load(replay_dir, template_name)
    print(context)



# Generated at 2022-06-11 20:31:31.650274
# Unit test for function dump
def test_dump():
    #setup
    dir = "test_replay"
    test_file = "test_file_a"
    os.mkdir(dir)
    template_name = "{{cookiecutter.name}}"
    context = {}
    context['cookiecutter'] = {"name" : "test_name_a"}
    #test
    dump(dir, template_name, context)
    assert os.path.isfile(dir + "/" + test_file)
    #cleanup
    os.remove(dir + "/" + test_file)
    os.rmdir(dir)


# Generated at 2022-06-11 20:31:32.372023
# Unit test for function load
def test_load():
    assert load('replay', 'foo')

# Generated at 2022-06-11 20:31:33.504613
# Unit test for function load
def test_load():
    assert load("", "") == 1


# Generated at 2022-06-11 20:31:38.495502
# Unit test for function load
def test_load():
    replay_dir = "../../tests/test-output"
    test_file = get_file_name(replay_dir, "test_replay_file")

    try:
        test_data = load(replay_dir, "test_replay_file")

    except ValueError:
        print("load() works properly.")
    else:
        raise ValueError("load() doesn't work properly.")


# Generated at 2022-06-11 20:31:40.372860
# Unit test for function load
def test_load():
    context = load("replay","template")
    assert isinstance(context, dict)


# Generated at 2022-06-11 20:31:49.403132
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'tests')
    template_name = 'fixtures'

# Generated at 2022-06-11 20:31:52.372532
# Unit test for function load
def test_load():
    try:
        load('/home/swati/BTP/Excel-Macro/cookiecutter_test/replays', 'test')
    except Exception as e:
        return False
    return True