

# Generated at 2022-06-11 20:22:27.092177
# Unit test for function get_file_name
def test_get_file_name():
    """ Unit test for the function get_file_name
    """
    # Test 1:
    replay_dir = "../tests/test-replay-dir"
    template_name = "test-template"
    expected_file_name = replay_dir + "/" + template_name + ".json"
    result_file_name = get_file_name(replay_dir, template_name)
    assert result_file_name == expected_file_name

    # Teset 2:
    replay_dir = "../tests/test-replay-dir"
    template_name = "test-template.json"
    expected_file_name = replay_dir + "/" + template_name
    result_file_name = get_file_name(replay_dir, template_name)
    assert result_file_name == expected_file_

# Generated at 2022-06-11 20:22:33.038097
# Unit test for function load
def test_load():
    if not make_sure_path_exists('replay'):
        raise IOError('Unable to create replay dir')
    replay_file = get_file_name('replay', 'test')
    with open(replay_file, 'r') as infile:
        context = json.load(infile)
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')
    return context


# Generated at 2022-06-11 20:22:39.033613
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = "test/replay"
    template_name = "template.json"
    context = {"cookiecutter": {"project_name": "Cheese"}}
    dump(replay_dir, template_name, context)

    with open("test/replay/template.json", "r") as f:
        lines = f.read()

    assert lines.find("Cheese") != -1


# Generated at 2022-06-11 20:22:45.456629
# Unit test for function get_file_name
def test_get_file_name():
    # Test parameter replay_dir
    replay_dir = '/home/john/Desktop'
    assert '/home/john/Desktop/cookiecutter.json' == get_file_name(replay_dir, 'cookiecutter')

    # Test parameter template_name
    template_name = 'cookiecutter.json'
    assert '/home/john/Desktop/cookiecutter.json' == get_file_name(replay_dir, template_name)


# Generated at 2022-06-11 20:22:56.437632
# Unit test for function load
def test_load():
    template_name = "hello-world"
    replay_dir = "./tests/test-load"

# Generated at 2022-06-11 20:23:01.309830
# Unit test for function load
def test_load():
    replay_dir = os.path.expanduser("~/.cookiecutters")
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)
    assert 'cookiecutter' in context

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:23:06.268512
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'test_replay_directory'
    name = 'test'
    result = get_file_name(replay_dir, name)
    assert result == 'test_replay_directory/test.json'
    name = 'test.json'
    result = get_file_name(replay_dir, name)
    assert result == 'test_replay_directory/test.json'


# Generated at 2022-06-11 20:23:08.820024
# Unit test for function load
def test_load():
    """Unit Test"""
    context = load(
        replay_dir=os.getcwd(),
        template_name='cookiecutter-demo'
    )

    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert isinstance(context['cookiecutter'], dict)
    assert 'author_name' in context



# Generated at 2022-06-11 20:23:13.132817
# Unit test for function dump
def test_dump():
    replay_dir = 'TEST_DIR'
    template_name = 'TEST_NAME'
    context = {
        'cookiecutter': {
            'key': 'value'
        }
    }
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context

# Generated at 2022-06-11 20:23:16.458059
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/root', 'temp') == '/root/temp.json'
    assert get_file_name('/root', 'cycle.json') == '/root/cycle.json'


# Generated at 2022-06-11 20:23:21.713839
# Unit test for function load
def test_load():
    replay_dir = os.getcwd()
    template_name = "test"
    context = {"cookiecutter": {"test": "test"}}
    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert loaded_context == context

# Generated at 2022-06-11 20:23:24.199098
# Unit test for function load
def test_load():
    replay_dir = 'replay_dir'
    t_name = 't_name'
    result = load(replay_dir, t_name)


# Generated at 2022-06-11 20:23:30.434634
# Unit test for function load
def test_load():
    class TestClass(object):
        def setUp(self):
            self.test_data = dict(
                test1='value1',
                test2='value2',
                test3='value3',
            )

            self.replay_dir = os.path.join('test','test_data','test_replay')
            self.replay_file = os.path.join(self.replay_dir, 'test.json')

            # Read data back in and compare
            with open(self.replay_file,'r') as f:
                self.test_data_back = json.load(f)

        def tearDown(self):
            pass

        def test_load(self):
            self.assertDictEqual(self.test_data, self.test_data_back)

    tc = TestClass()


# Generated at 2022-06-11 20:23:38.884271
# Unit test for function dump
def test_dump():

    dirname = './'
    templatename = 'test_template'
    context = {
        'cookiecutter': {
            'variable1': {
                'question': 'variable1 name?',
                'default': 'default value1',
            },
            'variable2': {
                'question': 'variable2 name?',
                'default': 'default value2',
            },
            'variable3': {
                'question': "variable3 name that contains ' character?",
                'default': 'default value3',
            },
            'variable4': {
                'question': 'variable4 name?',
                'default': 'default value4',
            },
        }
    }
    dump(dirname, templatename, context)
    # Now check if data is loaded from file

# Generated at 2022-06-11 20:23:42.236327
# Unit test for function load
def test_load():
    dir = 'C:/Users/hongx/OneDrive/Meta_programming/cookiecutter/tests/test-replay/'
    context = load(dir, 'test_load')

    print(context)


# Generated at 2022-06-11 20:23:47.283524
# Unit test for function dump
def test_dump():
    template_name = 'example-cookiecutter'
    replay_dir = 'data/'
    context = {
        'cookiecutter': {
            'first_name': 'Test',
            'last_name': 'User',
            'email': 'test@example.com'
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:23:57.152531
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.config import get_user_config, DEFAULT_CONFIG
    import cookiecutter.replay
    import os
    import shutil
    import tempfile
    
    # use a tempdir instead of the user-specific cache dir
    replay_dir = tempfile.mkdtemp()
    os.environ['COOKIECUTTER_REPLAY_DIR'] = replay_dir
    user_config = get_user_config(config_file=DEFAULT_CONFIG)

    # create a replay file containing a project with no errors

# Generated at 2022-06-11 20:24:07.854114
# Unit test for function load
def test_load():
    """
    Test load function.
    """
    import pytest

    replay_dir = 'tests/test-repo'
    template_name = 'tests/test-repo/{{cookiecutter.project_name}}/'

    with pytest.raises(TypeError) as excinfo:
        load('not-a-directory', 'not-a-file')
    assert str(excinfo.value) == 'Template name is required to be of type str'

    with pytest.raises(TypeError) as excinfo:
        load(replay_dir, None)
    assert str(excinfo.value) == 'Template name is required to be of type str'

    with pytest.raises(ValueError) as excinfo:
        load(replay_dir, template_name)

# Generated at 2022-06-11 20:24:17.823853
# Unit test for function load
def test_load():
    test_context = {"cookiecutter": {"full_name": "Your Name"}}
    test_dir = os.path.dirname(os.path.abspath(__file__)) #Cookiecutter-on-GitHub/tests
    test_template_name = "test_template"
    test_replay_file = get_file_name(test_dir, test_template_name)
    with open(test_replay_file, 'w') as outfile:
        json.dump(test_context, outfile, indent=2)

    assert(load(test_dir, test_template_name) == test_context)

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-11 20:24:22.510364
# Unit test for function dump
def test_dump():
    template_name = '{{cookiecutter.project_name}}'
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['project_name'] = 'test'
    replay_dir = './'
    dump(replay_dir, template_name, context)
    assert os.path.isfile(os.path.join(replay_dir, 'test.json'))
    assert os.path.getsize(os.path.join(replay_dir, 'test.json')) > 0
    os.remove(os.path.join(replay_dir, 'test.json'))

# Generated at 2022-06-11 20:24:25.493543
# Unit test for function load
def test_load():
	load('../replay','../fake/')
	pass


# Generated at 2022-06-11 20:24:27.864179
# Unit test for function load
def test_load():
    assert(load('../template', 'cookiecutter-python')['cookiecutter']['_template'] == 'cookiecutter-python')

# Generated at 2022-06-11 20:24:38.524717
# Unit test for function load
def test_load():
    # Case 2: valid input
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['repo_dir'] == 'fake-repo', 'test_load failed case 2'
    # Case 3: invalid type for template_name
    template_name = 12345
    try:
        load(replay_dir, template_name)
        assert True == False, 'test_load failed case 3'
    except TypeError:
        assert True == True
    # Case 4: no context for cookiecutter
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-11 20:24:45.409717
# Unit test for function dump
def test_dump():
    test_replay_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),'data/test_replay')
    test_template_name = "test_template"
    test_context = {'cookiecutter': {'_template': 'test_template', "full_name": "test", "project_name": "test_name"}}
    dump(test_replay_dir, test_template_name, test_context)
    assert os.path.isfile(get_file_name(test_replay_dir, test_template_name)) == True


# Generated at 2022-06-11 20:24:48.292012
# Unit test for function load
def test_load():
    replay_dir = './tests/test-output'
    template_name = 'example-python-app'
    context = load(replay_dir, template_name)

    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:24:50.640316
# Unit test for function dump
def test_dump():
    try:
        dump('bad/path', "1", {})
    except IOError as e:
        assert True is True
    else:
        assert False is True
        
    assert True is True

# Generated at 2022-06-11 20:24:52.849412
# Unit test for function load
def test_load():
    try:
        load('./tests/fixtures/replay-dir/', 'short')
    except ValueError as e:
        assert(e.args[0] == 'Context is required to contain a cookiecutter key')

# Generated at 2022-06-11 20:24:57.467546
# Unit test for function load
def test_load():
    from cookiecutter.utils.paths import user_config
    replay_dir = user_config()['replay_dir']
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print (context)


# Generated at 2022-06-11 20:24:59.045457
# Unit test for function load
def test_load():
    assert(load(None, None) == None)
    assert(load("abc", "abc") == {})

# Generated at 2022-06-11 20:25:01.694027
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.getcwd(), 'cookiecutter/tests')
    template_name = 'test'
    file = load(replay_dir, template_name)

# Generated at 2022-06-11 20:25:08.835596
# Unit test for function load
def test_load():
    c = load('tests/test-data/replay', 'test-repo')
    print(c)
    print(c['cookiecutter'])

    assert c is not None

# Generated at 2022-06-11 20:25:14.817593
# Unit test for function load
def test_load():
    assert isinstance(load('replay/', 'file1.json'), dict)
    assert isinstance(load('replay/', 'file1.json')['cookiecutter'], dict)
    assert isinstance(load('replay/', 'file1.json')['cookiecutter']['github_username'], str)


# Generated at 2022-06-11 20:25:16.436142
# Unit test for function load
def test_load():
    context = load("/tmp/cc_replay", "lak")

# Generated at 2022-06-11 20:25:20.309907
# Unit test for function load
def test_load():
    replay_dir="tests/test-output/replay"
    template_name="test-template"

    try:
        context = load(replay_dir, template_name)
        print(context)
    except Exception as e:
        print(e)


# Generated at 2022-06-11 20:25:31.557512
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    dump_dir = 'tests/test-dump'
    template_name = 'cookiecutter-pypackage'
    context = {
        'full_name': 'Audrey Roy',
        'email': 'audreyr@example.com',
        'github_username': 'audreyr',
        'project_name': 'cookiecutter-pypackage',
        'repo_name': 'cookiecutter-pypackage',
        'project_short_description': 'A cookiecutter template for a Python package.',
        'pypi_username': 'audreyr',
        'version': '0.1.0',
        'release_date': '2013-10-04',
        'year': '2013',
    }


# Generated at 2022-06-11 20:25:36.740601
# Unit test for function dump
def test_dump():
    template_name = 'cookie_test'
    context = {'cookiecutter': {'test': 'this'}}
    # make a temp dir:
    replay_dir = os.path.join('/tmp/cookiecutter_replay_test')
    # try to remove the dir:
    try:
        os.rmdir(replay_dir)
    except:
        pass

    # now dump to the file:
    dump(replay_dir, template_name, context)

    # now load from file:
    data = load(replay_dir, template_name)
    assert data == context



# Generated at 2022-06-11 20:25:39.071963
# Unit test for function load
def test_load():
    # test with good input
    result = load("/Users/chasebrown/Desktop/tests", "testtemp")
    assert isinstance(result, dict)
    assert 'cookiecutter' in result


# Generated at 2022-06-11 20:25:49.899291
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import pytest
    import tempfile

    with pytest.raises(TypeError):
        load(None, None)

    with pytest.raises(TypeError):
        load(None, "")

    with pytest.raises(TypeError):
        load("", None)

    # Without context in the replay file
    with tempfile.TemporaryDirectory() as temp_dir:
        with pytest.raises(ValueError):
            load(temp_dir, "test")

    # With context in the replay file without cookiecutter key
    with tempfile.TemporaryDirectory() as temp_dir:
        replay_file = get_file_name(temp_dir, "test.json")

# Generated at 2022-06-11 20:25:56.128031
# Unit test for function load
def test_load():
    replay_dir = 'tests/files/'
    replay_file = 'tests/files/audrey-hood.json'
    context = {'cookiecutter': {'full_name': 'Audrey Hood', 'email': 'audrey@example.com'}}


    # Test load
    assert load(replay_dir, 'audrey-hood') == context

    # Test get_file_name
    assert get_file_name(replay_dir, 'audrey-hood') == replay_file



# Generated at 2022-06-11 20:26:05.306735
# Unit test for function dump
def test_dump():
    """Test for dump."""
    replay_dir = os.path.expanduser('~/.cookiecutters')
    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))

    template_name = 'cookiecutter-pypackage'


# Generated at 2022-06-11 20:26:15.803567
# Unit test for function dump
def test_dump():
    template_name = 'test'
    replay_dir = '.'
    context = {
        'cookiecutter': {
            'full_name': 'Test User',
            'email': 'test@test.com',
            'github_username': 'testuser',
            'project_name': 'Test Project',
            'project_short_description': 'Simple repo for testing',
            'version': '1.0.0',
            'timezone': 'Asia/Manila'
        }
    }

    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))


# Generated at 2022-06-11 20:26:23.705880
# Unit test for function dump
def test_dump():
    # setup the test
    replay_dir = '/Users/marco/Desktop/cookiecutter/replay'
    template_name = 'template.json'
    context = {
        'cookiecutter': {
            'first_name': 'Marco',
            'last_name': 'Barbosa'
        }
    }

    # run the test
    dump(replay_dir, template_name, context)

    # check the output
    with open(get_file_name(replay_dir, template_name), 'r') as infile:
        data = json.load(infile)

    assert data == context



# Generated at 2022-06-11 20:26:27.580422
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay/'
    template_name = 'tests/fake-repo-tmpl/'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:26:34.427500
# Unit test for function load
def test_load():
    context_json = '{"cookiecutter": {"full_name": "Thor123", "email": "thor@asgard.com", "github_username": "thor123", "project_name": "dummy_project"}}'
    with open('cookiecutter.json', 'w') as outfile:
        json.dump(json.loads(context_json), outfile, indent=2)

    context = load(os.getcwd(), 'cookiecutter')


# Generated at 2022-06-11 20:26:41.827799
# Unit test for function load
def test_load():
    """Test function load."""
    replay_dir = 'replay'
    template_name = 'test_load'
    context = {
        'cookiecutter': {
            'project_name': 'test_load'
        }
    }
    dump(replay_dir, template_name, context)
    result = load(replay_dir, template_name)
    assert result == context
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-11 20:26:43.708599
# Unit test for function load
def test_load():
    assert load('/Users/joshua/cookiecutter-pypackage/tests/files/fake-repo-pre/', 'fake-repo') != ''


# Generated at 2022-06-11 20:26:48.552557
# Unit test for function load
def test_load(): # pragma: no cover
    """Test load function."""
    replay_dir = 'c:\\replay_dir'
    template_name = 'template_name'
    context = {'cookiecutter': 'cookie'}

    dump(replay_dir, template_name, context)
    context_result = load(replay_dir, template_name)
    os.remove(get_file_name(replay_dir, template_name))

    assert context_result == context

# Generated at 2022-06-11 20:26:57.181945
# Unit test for function dump
def test_dump():
    import tempfile
    temp_dir = tempfile.mkdtemp()
    print(temp_dir)
    template_name = "test_template"
    context = {
        "cookiecutter": {
            "full_name": "Test Name",
            "email": "xju2@illinois.edu",
            "github_username": "TestUser",
            "title_case_name": "Test Name"
        }
    }
    dump(temp_dir, template_name, context)
    context_loaded = load(temp_dir, template_name)
    assert context == context_loaded


# Generated at 2022-06-11 20:27:01.421765
# Unit test for function load
def test_load():
    template_name = 'Python.docx'
    replay_dir = 'C:\\Users\\cjhuo\\Desktop\\Thesis\\cookiecutter-io\\cookiecutter\\cookiecutter\\replay'
    loaded_context = load(replay_dir, template_name)

# Generated at 2022-06-11 20:27:03.073908
# Unit test for function dump
def test_dump():

    assert(dump('/home/user/cookiecutter-test/', 'test', {'test':'123'}) == None)


# Generated at 2022-06-11 20:27:17.978639
# Unit test for function load
def test_load():
    template_name = "temp"
    context = {'cookiecutter': {'key':'value'}}
    replay_dir = '.'
    dump(replay_dir, template_name, context)
    context2 = load(replay_dir, template_name)
    assert context == context2
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-11 20:27:28.637295
# Unit test for function load
def test_load():
    print("Testing load()")
    context = {
        'cookiecutter': {
            'first_name': 'Joe'
        }
    }
    template_name = 'dir1/dir2/dir3/dir4/dir5'
    dump(replay_dir='{}/tmp'.format(os.path.dirname(os.path.realpath(__file__))), 
        template_name=template_name, 
        context=context)
    tmp = load(replay_dir='{}/tmp'.format(os.path.dirname(os.path.realpath(__file__))), 
        template_name=template_name)
    if tmp['cookiecutter']['first_name'] == context['cookiecutter']['first_name']:
        print("pass")

# Generated at 2022-06-11 20:27:36.321178
# Unit test for function dump
def test_dump():
    replay_dir = "replay_dir"
    template_name = "template"
    context = {"cookiecutter": {'repo_dir': 'my-repo', 'project_slug': 'my-project'}}

    dump(replay_dir, template_name, context)

    assert os.path.exists(get_file_name(replay_dir, template_name))
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-11 20:27:38.056831
# Unit test for function load
def test_load():
    context = load('.','default')
    #checks if the replay_file dict loads
    print('load test:',context)

# Generated at 2022-06-11 20:27:43.355517
# Unit test for function load
def test_load():
    replay_dir = '/Users/tselvan/Dropbox/Test/cookiecutter-study/tests/fixtures/test-load'
    template_name = 'study_example'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Test User'



# Generated at 2022-06-11 20:27:50.495936
# Unit test for function dump
def test_dump():
    replay_dir = '/Users/harsha/Documents/cookiecutter-templates/harsha/cookiecutter-knative-go/replay'
    template_name = 'knative-go'
    context = {'cookiecutter': {'full_name': 'Harsha Vardhan J V', 'email': 'harsha@pivotal.io'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:27:56.188188
# Unit test for function load
def test_load():
    from pprint import pprint
    from random import choice
    from string import ascii_uppercase
    replay_dir = os.path.join(os.getcwd(), 'replay')
    template_name = ''.join(choice(ascii_uppercase) for _ in range(10))+'.json'
    context = {
            "cookiecutter": {
                "full_name": "Simon Darveau",
                "email": "laogeodritt@gmail.com",
                "github_username": "laoghedritt",
                "package_name": "laogeodritt"
                }
            }
    dump(replay_dir, template_name, context)
    pprint(load(replay_dir, template_name))

# Generated at 2022-06-11 20:28:05.472478
# Unit test for function dump
def test_dump():
    # No value for replay_dir
    replay_dir = None
    template_name = 'test_dump'
    context = {
        'cookiecutter': {'name': 'test_cookiecutter'},
        'test': 'test_dump'
    }
    try:
        dump(replay_dir, template_name, context)
    except IOError as e:
        assert str(e) == 'Unable to create replay dir at None'

    # No writable replay_dir
    replay_dir = '/opt/no_existing_dir'
    template_name = 'test_dump'
    context = {
        'cookiecutter': {'name': 'test_cookiecutter'},
        'test': 'test_dump'
    }

# Generated at 2022-06-11 20:28:12.521637
# Unit test for function dump
def test_dump():
    replay_dir = '~/Desktop/cookiecutter-replay'
    template_name = 'template'
    context = [
        {
        'cookiecutter': {
            'full_name': 'Ravi Sharma',
            'email': 'sharmaravi2@gmail.com'
            }
        },
        {
        'cookiecutter': {
            'full_name': 'Ravi Sharma',
            'email': 'sharmaravi2@gmail.com'
            }
        }
    ]

    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:28:18.099110
# Unit test for function dump
def test_dump():
    """ Test that output is as expected """
    replay_dir = 'tests/files/replay/'
    template_name = 'test_template'
    context = {'cookiecutter': {'name': 'test_name',
                                'directory_name': 'test_directory_name',
                                'project_name': 'test_project_name',
                                'slug': 'test_slug'}}
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        content = json.load(infile)

    assert content == context


# Generated at 2022-06-11 20:28:41.212736
# Unit test for function load
def test_load():
    assert type(load('cookiecutter/replay', 'audreyr/cookiecutter-pypackage.git')) == dict

# Generated at 2022-06-11 20:28:49.393018
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    expected_context = {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com', 'github_username': 'audreyr'}, 'project_name': 'cookiecutter-pypackage', 'package_name': 'my_package'}
    actual_context = load(replay_dir, template_name)
    assert expected_context == actual_context

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:28:52.989847
# Unit test for function dump
def test_dump():
    replay_dir = '/tmp'
    template_name = 'dummy_template'
    context = {'cookiecutter': 'dummy_context'}

    dump(replay_dir, template_name, context)
    file_path = get_file_name(replay_dir, template_name)
    assert os.path.isfile(file_path)



# Generated at 2022-06-11 20:28:59.633275
# Unit test for function load
def test_load():
    from pytest import raises
    from tempfile import mkdtemp
    from shutil import rmtree

    # Set up temp directories and replay file
    replay_dir = mkdtemp()
    template_name = 'test'
    replay_file = get_file_name(replay_dir, template_name)

    context = {}

    # Act 1
    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    # Assert 1
    with raises(ValueError):
        load(replay_dir, template_name)

    # Teardown 1
    os.remove(replay_file)

    # Act 2
    context = {'cookiecutter': 'test'}


# Generated at 2022-06-11 20:29:05.639526
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    from tempfile import mkdtemp
    test_dir = mkdtemp()
    test_file = os.path.join(test_dir, 'test_file.json')
    dump(test_dir, 'test_file', {'cookiecutter': True, 'test': 123})
    content = load(test_dir, 'test_file')
    assert content == {'cookiecutter': True, 'test': 123}
    os.remove(test_file)
    os.rmdir(test_dir)


# Generated at 2022-06-11 20:29:07.568097
# Unit test for function load
def test_load():
    assert load("/tmp/tests", "test") == {'cookiecutter': '/tmp/tests'}


# Generated at 2022-06-11 20:29:12.071571
# Unit test for function load
def test_load():
    assert load('/Users/akshanshjain/Desktop/cookiecutter-django/tests/test-load', '_abc-123') == {'cookiecutter': {'author_name': 'Akshansh Jain'}}


# Generated at 2022-06-11 20:29:16.266812
# Unit test for function dump
def test_dump():
    temp_context = {'cookiecutter': {"full_name": "test",
                                     "email": "test@test.com",
                                     "github_username": "test",
                                     "repo_name": "test"},
                    "test": {"test": "test1"} }
    test_name = 'test'
    dump('.', test_name, temp_context)


# Generated at 2022-06-11 20:29:21.291528
# Unit test for function load
def test_load():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    replay_dir = os.path.join(test_dir, '..', 'tests', 'test-replay')
    template_name = 'test'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['first_name'] == 'Your Name'


# Generated at 2022-06-11 20:29:24.285352
# Unit test for function dump
def test_dump():
    context = {'cookiecutter' : {'full_name': 'First Last'}}
    dump('/tmp', 'test-replay', context)
    result_context = load('/tmp', 'test-replay')
    assert context == result_context

# Generated at 2022-06-11 20:30:16.072735
# Unit test for function load
def test_load():
    replay_dir = os.path.expanduser('~/cookiecutter_replay/')
    template_name = 'audreyr/cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert context["cookiecutter"]['full_name'] == 'Audreyr'
    assert context["cookiecutter"]['email'] == 'audreyr@example.com'
    assert context["cookiecutter"]['project_name'] == 'Cookiecutter PyPackage'



# Generated at 2022-06-11 20:30:17.757276
# Unit test for function load
def test_load():
    replay_dir = "/Users/batman/Cookiecutter_replay_files"
    template_name="pyramid-cookiecutter-starter"
    context = load(replay_dir, template_name)

# Generated at 2022-06-11 20:30:23.580844
# Unit test for function dump
def test_dump():
    import shutil;
    import os;
    os.chdir(os.path.abspath(os.path.dirname(__file__)))
    template_name = "./cookiecutter-pypackage"
    path = "my_project"
    shutil.rmtree(path)
    if os.path.isdir(path):
        raise IOError('Unable to create replay dir')

# Generated at 2022-06-11 20:30:25.688675
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    # TODO: test for dump
    assert False



# Generated at 2022-06-11 20:30:28.731802
# Unit test for function load
def test_load():
    """Unit test for function load."""
    m_load = load('replay-dir/', '__init__')
    assert m_load == {'cookiecutter': {'_template': '__init__.json'}}

# Generated at 2022-06-11 20:30:30.093158
# Unit test for function load
def test_load():
    file = load("/Users/sephon/Desktop/Research/VizSeq/cookiecutter-vizseq","vizseq")
    assert file != None

# Generated at 2022-06-11 20:30:32.087722
# Unit test for function load
def test_load():
    assert(load('This is not a replay_dir', 'This is not a template_name') == 1)
 

# Generated at 2022-06-11 20:30:36.129730
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = "test_template"
    replay_dir = ".replay"
    dump(replay_dir, template_name, {'cookiecutter': 'test'})

    assert load(replay_dir, template_name) == {'cookiecutter': 'test'}


# Generated at 2022-06-11 20:30:37.124051
# Unit test for function load
def test_load():
    res_context = load('./replay/', 'cookie-replay')

# Generated at 2022-06-11 20:30:40.335820
# Unit test for function load
def test_load():
    context = load('/Users/shuoli/Documents/GitHub/cookiecutter-pypackage', 'cookiecutter.json')
    print(context)
    assert context['cookiecutter']['full_name'] == 'Your Name'

test_load()

# Generated at 2022-06-11 20:31:33.532763
# Unit test for function dump
def test_dump():
    """Unit test for function dump"""
    context = {"cookiecutter": {"full_name": "Ricky", 'email': 'ricky@example.com'}}
    template_name = "python-sample"
    replay_dir = 'tests/fake-repo-pre/'
    dump(replay_dir, template_name, context)

    replay_dir = 'tests/fake-repo-pre/'
    template_name = "python-sample.json"
    context = load(replay_dir, template_name)



# Generated at 2022-06-11 20:31:36.923027
# Unit test for function load
def test_load():
    """Test load function."""
    ctx = load("/tmp/cookiecutter-replay/", "cc_linux_kernel")
    assert ctx['cookiecutter']['end_year'] == '2016'

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-11 20:31:41.195364
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'foo': 'bar'}}
    replay_dir = 'cookiecutter/tests/test-data/replay'
    template_name = 'test-replay'
    dump(replay_dir, template_name, context)
    test_context = load(replay_dir, template_name)
    assert test_context == context

# Generated at 2022-06-11 20:31:48.444085
# Unit test for function load
def test_load():
    """test load a json file to the context"""
    replay_dir = "test"
    template_name = "test"
    replay_file = "test/test.json"
    with open(replay_file, 'w') as outfile:
        context = {"cookiecutter": {"project_name": "test"}}
        json.dump(context, outfile, indent=2)
    context_result = load(replay_dir, template_name)
    assert context_result == context

if __name__ == "__main__":
    test_load()
    print("load function test pass")

# Generated at 2022-06-11 20:31:51.202034
# Unit test for function load
def test_load():
    replay_dir = os.getcwd()
    template_name = 'python-package'
    testcontext = load(replay_dir, template_name)


# Generated at 2022-06-11 20:31:54.369923
# Unit test for function load
def test_load():
    """Test the load function."""
    template_name = 'default'
    replay_dir = 'C:\\Users\\Karnika\\Documents\\GitHub\\cookiecutter-pypackage-minimal'
    load(replay_dir,template_name)


# Generated at 2022-06-11 20:32:01.627083
# Unit test for function dump
def test_dump():
    replay_dir = os.path.dirname(os.path.dirname(__file__))
    template_name = 'python-cli-package-cookie'

# Generated at 2022-06-11 20:32:10.318647
# Unit test for function load
def test_load():
    """Test for function load."""
    template_name = './tests/test-load-replay/template.json'

    # Test for TypeError
    try:
        load(None, 123)
        assert False
    except TypeError:
        assert True

    # Test for ValueError
    try:
        load(None, template_name)
        assert False
    except ValueError:
        assert True

    # Test for KeyError
    try:
        load('/tmp', template_name)
        assert False
    except KeyError:
        assert True

    # assert True: Test ctx contain cookiecutter
    ctx = load('./tests/test-load-replay/replay_dir', template_name)
    assert ctx.get('cookiecutter', None) is not None



# Generated at 2022-06-11 20:32:15.443169
# Unit test for function dump
def test_dump():
    """Check if writing is correct."""
    if not make_sure_path_exists('tests/files/replay'):
        raise IOError('Unable to create replay dir at {}'.format('tests/files/replay'))
    dump('tests/files/replay','replay',{'cookiecutter':{'arg1':'val1','arg2':'val2'}})
    assert os.path.exists(os.path.join('tests/files/replay/replay.json'))


# Generated at 2022-06-11 20:32:18.329874
# Unit test for function dump
def test_dump():
    assert dump('tests/fake-repo-pre', 'tests/fake-repo-pre/{{cookiecutter.repo_name}}', {'foo': 'bar'})

