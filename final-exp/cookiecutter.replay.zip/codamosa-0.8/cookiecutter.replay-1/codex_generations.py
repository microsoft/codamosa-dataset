

# Generated at 2022-06-11 20:22:14.570800
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('dir', 'name') == 'dir/name.json'
    assert get_file_name('dir', 'name.json') == 'dir/name.json'


# Generated at 2022-06-11 20:22:18.138091
# Unit test for function load
def test_load():
    context = {'cookiecutter': {'abc': 'abc'}}
    dump(os.getcwd(), 'test_load', context)
    assert load(os.getcwd(), 'test_load') == context
    return True



# Generated at 2022-06-11 20:22:23.616026
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    replay_dir = "/home/arnavk/Documents/5th_Year/2nd_Semester/Project/code/replay_files"
    template_name = "replay_file_blank-project"
    ans = load(replay_dir, template_name)
    # print(ans)
    print(cookiecutter(ans["cookiecutter"]["replay"], no_input=True))


# Generated at 2022-06-11 20:22:26.663220
# Unit test for function load
def test_load():
    tem_replay_dir = 'C:\\Users\\ariel\\python\\cookiecutter\\tests\\replay'
    tem_template_name = 'fulcrum-py'
    context = load(tem_replay_dir, tem_template_name)
    print(context)



# Generated at 2022-06-11 20:22:37.048763
# Unit test for function dump
def test_dump():
    import sys
    sys.stdout.flush()
    sys.stdout.write("  Testing dump...\n")
    context = {'cookiecutter': {'foo': 'bar'}}
    
    replay_dir = 'cookiecutter/tests/test-replay'
    template_name = 'cookiecutter-pypackage'
    try:
        dump(replay_dir, template_name, context)
    except Exception as e:
        print(str(e))
        sys.exit(1)

    expected = {'cookiecutter': {'foo': 'bar'}}

    from filecmp import cmp

# Generated at 2022-06-11 20:22:39.951743
# Unit test for function dump
def test_dump():
    replay_dir = 'replay'
    template_name = 'python-flask-pytest'
    context = {'cookiecutter': {'full_name': 'paul', 'email': 'paul@email.com'}}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:22:47.964925
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    
    # Generate the default project
    replay_dir = '.cookiecutter_replay'
    template_name = 'gh:cookiecutter-django/cookiecutter-django'
    cookiecutter(template_name, replay_dir)
    
    # Check the context data
    context = load(replay_dir, template_name)
    
    # {'cookiecutter': {
    #     'project_name': 'Python Project',
    #     'project_slug': 'python_project',
    #     'repo_name': 'python_project',
    #     'timezone': 'Europe/Amsterdam',
    #     'version': '0.1.0',
    #     'year': '2016',
    # }}

# Generated at 2022-06-11 20:22:52.773459
# Unit test for function load
def test_load():

    import os
    
    replay_dir = os.getcwd() + "\\" + "tests" + "\\" + "replay-files"
    template_name = "test-replay"
    
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:23:00.499853
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'

# Generated at 2022-06-11 20:23:03.501391
# Unit test for function dump
def test_dump():
    assert dump('replay_dir', 'template_name', {'cookiecutter': 'context'}) == None



# Generated at 2022-06-11 20:23:08.616820
# Unit test for function load
def test_load():
    context = load('/home/ubuntu/cse416/cookiecutter-replay', 'replay-test')
    print(context)

test_load()

# Generated at 2022-06-11 20:23:12.255289
# Unit test for function load
def test_load():
    """Test load."""
    replay_file = load('../.cookiecutter-replay', 'cookiecutter-pypackage')
    print("replay_file: ", replay_file)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:23:15.882892
# Unit test for function load
def test_load():
    a = load('../', 'cookiecutter-pypackage')
    b = {"_template": "cookiecutter-pypackage", "cookiecutter": {"project_name": "foo"}}
    assert a == b



# Generated at 2022-06-11 20:23:25.017289
# Unit test for function dump
def test_dump():
    import os
    import shutil

    # setup
    temp_path = '/tmp/cookiecutter-tests-replay'
    if os.path.exists(temp_path):
        shutil.rmtree(temp_path)
    context = {
        'full_name': 'Test Name',
        'email': 'test@email.com',
        'cookiecutter': {
            'foo': 'bar',
            'baz': 'qux',
        },
    }

    # test
    dump(temp_path, 'test_template', context)

    # assert
    with open('/tmp/cookiecutter-tests-replay/test_template.json', 'r') as f:
        output = json.load(f)

    # cleanup

# Generated at 2022-06-11 20:23:32.267238
# Unit test for function load
def test_load():
    try:
        replay_dir = ".cookiecutters-replay"
        template_name = "cookiecutter-pypackage"
        context = load(replay_dir, template_name)
        print(context)
        if not (context["cookiecutter"]["_copy_without_render"] == ["setup.py"]):
            raise Exception("Setup.py was not found in the context")
        if not (context["cookiecutter"]["_template"] == "cookiecutter-pypackage"):
            raise Exception("Template was not found in the context")
    except Exception as e:
        print("Test failed: " + str(e))
        raise e


# Generated at 2022-06-11 20:23:37.993935
# Unit test for function load
def test_load():
    import tempfile
    import shutil
    context ={'cookiecutter':{ 'repo_name':'somevalue'}}
    tmp_dir = tempfile.mkdtemp()
    dd = os.path.join(tmp_dir, 'somevalue')
    dump(tmp_dir, 'somevalue', context)
    assert os.path.exists(dd)
    shutil.rmtree(tmp_dir)
    assert not os.path.exists(dd)

# Generated at 2022-06-11 20:23:46.915030
# Unit test for function load
def test_load():
    # create a temporary directory
    replay_dir = "/tmp/test_replay"
    if not os.path.exists(replay_dir):
        os.mkdir(replay_dir)
    content = {"cookiecutter": {"replay": True}}
    with open(os.path.join(replay_dir, "test.json"), "w") as f:
        json.dump(content, f)
    result = load(replay_dir, "test.json")
    assert result == content
    os.remove(os.path.join(replay_dir, "test.json"))
    os.rmdir(replay_dir)
    return


# Generated at 2022-06-11 20:23:51.697619
# Unit test for function load
def test_load():
    """Unit test for function load."""

# Generated at 2022-06-11 20:23:58.785771
# Unit test for function load
def test_load():
    '''
    - Reads the .json file.
    - Replaces the tags in the test.txt file with the actual data.
    '''
    # Copy of the cookie cutter in the current directory
    cookieCutter = "cc_test"
    # Path of the json file 
    filePath = os.path.join(os.getcwd(), cookieCutter, "tmpl_context.json")
    # Loading the json data
    with open(filePath, 'r') as infile:
        data = json.load(infile)
    # Getting the template path
    templatePath = os.path.normcase(data["cookiecutter"]["template_path"])
    # Getting the input text file path
    txtPath = os.path.normcase(os.path.join(templatePath, "test.txt"))
   

# Generated at 2022-06-11 20:24:07.011452
# Unit test for function load
def test_load():
    # Test for Input values not of required type
    try:
        load('/../', ['abc', 'def'])
        assert False
    except TypeError as e:
        assert e.message == 'Template name is required to be of type str'

    try:
        load('/../', 'abc')
        assert False
    except ValueError as e:
        assert e.message == 'Context is required to contain a cookiecutter key'

    assert isinstance(load('/../', 'cookiecutter.json'), dict)



# Generated at 2022-06-11 20:24:13.135713
# Unit test for function load
def test_load():
	replay_dir = 'tests/test-load'
	template_name = 'test_load'
	context = load(replay_dir, template_name)
	assert(context['cookiecutter'] == {'full_name': 'ahmad', 'email': 'ahmad.safari@gmail.com'})

# Generated at 2022-06-11 20:24:21.600731
# Unit test for function load
def test_load():
    from cookiecutter.config import DEFAULT_CONFIG
    # Test load
    # load non-existent file should throw ValueError
    try:
        context = load('/tmp', 'non-existent')
        assert False
    except IOError:
        pass

    # Test load
    # load file without cookiecutter key should throw ValueError

# Generated at 2022-06-11 20:24:22.633276
# Unit test for function load
def test_load():
    assert True


# Generated at 2022-06-11 20:24:25.493475
# Unit test for function load
def test_load():
    context = load('C:/Users/LZL/Desktop/Python/cookiecutter', 'cookiecutter-django')


# Generated at 2022-06-11 20:24:34.204166
# Unit test for function dump
def test_dump():
    import os
    from cookiecutter.replay import dump

    replay_dir = '/tmp/tests/replay'
    template_name = 'test_template'
    context = {'foo': 'bar', 'cookiecutter': {'bar': 'baz'}}

    dump(replay_dir, template_name, context)

    replay_file = '/tmp/tests/replay/test_template.json'
    with open(replay_file, 'r') as infile:
        context_read = json.load(infile)

    assert context_read == context
    os.remove(replay_file)
    os.removedirs(replay_dir)


# Generated at 2022-06-11 20:24:39.054672
# Unit test for function load
def test_load():
    from cookiecutter import main
    from .fixtures import mock_context
    from .fixtures import mock_template

    mock_template_dir = 'tests/fixtures/mock-template'

    # Load the fixture
    context = load(mock_template_dir, 'mock-template')

    assert context == mock_context



# Generated at 2022-06-11 20:24:47.462723
# Unit test for function dump
def test_dump():
    """Run the unit test for function dump."""
    import tempfile

    test_context = {
        'cookiecutter': {
            'full_name': 'audreyr',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'cookiecutter-pypackage',
            'project_slug': 'cookiecutter-pypackage',
            'release_date': '2014-10-03',
            'year': '2014',
            'version': '0.1.0'
        }
    }

    with tempfile.TemporaryDirectory() as tmpdirname:
        dump(tmpdirname, 'my-fake-repo', test_context)


# Generated at 2022-06-11 20:24:53.515104
# Unit test for function load
def test_load():
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    try:
        shutil.copy('tests/test_files/replay_files/example.json', temp_dir)
        os.chdir(temp_dir)
        replay_dir = os.path.normpath(".")
        template_name = "example"
        context = load(replay_dir, template_name)
        assert context["cookiecutter"]["cookiecutter_template_name"] == "example"
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-11 20:24:57.613318
# Unit test for function load
def test_load():
    """Tests the load function"""
    # Reading the file that has been created by the dump function
    data = load('./DUMP', 'TestFile')
    assert 'cookiecutter' in data
    assert 'test' in data['cookiecutter']


# Generated at 2022-06-11 20:25:02.446912
# Unit test for function dump
def test_dump():
    replay_dir = './tests/test-output/replay'
    template_name = './tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    context = {
        "cookiecutter": {
            "repo_name": "mario",
            "project_name": "Super Mario Bros."
        }
    }
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:25:06.876565
# Unit test for function load
def test_load():
    replay_dir = '/tmp/cookiecutter-replay'
    template_name = 'foobar'
    context = {'cookiecutter': {'foo': 'Hi'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-11 20:25:10.588945
# Unit test for function load
def test_load():
    with open('cookiecutter/replay/fixtures/template.json', 'r') as infile:
        context = json.load(infile)
    assert(context['cookiecutter']['project_name'] == 'Project name')

# Generated at 2022-06-11 20:25:14.391467
# Unit test for function load
def test_load():
    replay_dir = '\\replay'
    template_name = 'template'
    context = 'context'
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-11 20:25:20.310387
# Unit test for function load
def test_load():
    """Test for function load."""
    data = {'cookiecutter': {}}
    replay_dir = 'temp_replay'
    from shutil import rmtree
    try:
        rmtree('temp_replay')
    except:
        pass

    dump(replay_dir, 'test', data)
    load(replay_dir, 'test')

    try:
        rmtree('temp_replay')
    except:
        pass

# Generated at 2022-06-11 20:25:30.630125
# Unit test for function load
def test_load():
    # Template name is not a string.
    replay_dir = '/home/tests/replay'
    template_name = 1
    try:
        load(replay_dir, template_name)
    except TypeError:
        assert True

    # Context is not a dictionary.
    new_context = [1, 2, 3]
    try:
        load(replay_dir, template_name, new_context)
    except TypeError:
        assert True

    # Context does not contain a cookiecutter key.
    new_context = {'test': 'test'}
    try:
        load(replay_dir, template_name, new_context)
    except ValueError:
        assert True



# Generated at 2022-06-11 20:25:33.137811
# Unit test for function load
def test_load():
    replay_dir = './'
    template_name = 'test'
    context = load(replay_dir, template_name)
    print(context)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:25:35.795124
# Unit test for function load
def test_load():
    """
    Load the replay context from 'tests/test-replay', then test whether
    the 'cookiecutter' key exists in the loaded context.
    """
    context = load("tests/test-replay", "first_example")
    assert "cookiecutter" in context.keys()


# Generated at 2022-06-11 20:25:38.875283
# Unit test for function load
def test_load():
	replay_dir = './tests/fake-repo-pre/'
	template_name = 'fake-repo-pre'
	context = load(replay_dir, template_name)
	assert context

	replay_dir = './tests/fake-repo-post/'
	template_name = 'fake-repo-post'
	context = load(replay_dir, template_name)
	assert context
	

# Generated at 2022-06-11 20:25:49.671353
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = "/home/abc/.cookiecutters"
    template_name = "cookiecutter-pypackage"

# Generated at 2022-06-11 20:25:58.937325
# Unit test for function load
def test_load():
    import tempfile
    temp_repo = tempfile.mkdtemp()
    template_name = 'farsheed/cookiecutter-python-cli'
    context = {
        'cookiecutter': {
            'full_name': 'Farsheed Ashouri',
            'email': 'farsheed.ashouri@gmail.com',
            'project_name': 'my-cli',
            'project_short_description': 'A CLI for doing stuff',
            'pypi_username': 'farsheed'
        }
    }
    replay_dir = os.path.join(temp_repo, '.cookiecutters_replay')
    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert loaded_context == context

# Generated at 2022-06-11 20:26:02.199493
# Unit test for function load
def test_load():
    context = load(r'C:\Users\xiexian\Desktop\test', 'test')
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:26:08.684837
# Unit test for function load
def test_load():
    print("Unit test for load...")
    print("1.Test for incorrect replay_dir")
    replay_dir = '/Users/chenjiaqi/Desktop/test_load1'
    try:
        load(replay_dir,'fdsa.json')
    except IOError:
        print("Pass!!!\n")
    else:
        print("Fail!!!\n")

    replay_dir = '/Users/chenjiaqi/Desktop/test_replays'
    print("2.Test for incorrect replay_file")
    try:
        load(replay_dir,'fdsa.json')
    except ValueError:
        print("Pass!!!\n")
    else:
        print("Fail!!!\n")

    print("3.Test for correct replay_file!")

# Generated at 2022-06-11 20:26:12.355382
# Unit test for function load
def test_load():
    context = load('tests/files/replay', 'example-replay')

    assert isinstance(context, dict)
    assert context.get('cookiecutter') is not None


# Generated at 2022-06-11 20:26:23.072507
# Unit test for function dump
def test_dump():

    if not os.path.exists('test/test_replay_dir'):
        os.makedirs('test/test_replay_dir')
    
    replay_dir = 'test/test_replay_dir'
    template_name = 'test_template'

    # test that it is created if not exist
    dump(replay_dir, template_name, {'cookiecutter': {}})
    assert os.path.exists(replay_dir)

    # test that it raises error if not parent path can be created
    with open(os.path.join(replay_dir, 'test_file'), 'w') as test_file:
        test_file.write('t')

# Generated at 2022-06-11 20:26:24.977139
# Unit test for function load
def test_load():
    #pass
    assert(load(os.path.expanduser('~/.cookiecutters/'), 'https://github.com/audreyr/cookiecutter-pypackage.git') != None)

# Generated at 2022-06-11 20:26:31.123759
# Unit test for function load
def test_load():
    replay_dir = "cookiecutter.replay"
    template_name = "test"
    context = {"a":"a", "b":"b"}
    dump(replay_dir, template_name,context)
    tmp = load(replay_dir, template_name)

# Generated at 2022-06-11 20:26:34.628250
# Unit test for function load
def test_load():
    context = load('/Users/lizhiyuan/Desktop/workspace/cookiecutter/tests/test-output/replay', 'test-output/{{cookiecutter.project_slug}}')
    print(context)


# Generated at 2022-06-11 20:26:44.328032
# Unit test for function dump
def test_dump():
    # Create empty directory
    os.mkdir('replay')
    # Create a template_name and a context
    template_name= "python_package"

# Generated at 2022-06-11 20:26:53.152750
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-dump-replays'
    template = 'tests/fake-repo-tmpl'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'Hello World',
            'project_slug': 'hello-world',
            'release_date': '2014-08-14',
            'pypi_username': 'audreyr',
            'year': '2014',
        }
    }
    dump(replay_dir, template, context)
    assert os.path.exists(get_file_name(replay_dir, template))



# Generated at 2022-06-11 20:27:02.662153
# Unit test for function load
def test_load():
    """Test if load works"""
    temp_dir = os.path.join('tests', 'files', 'test-repo-pre')
    template_name = os.path.join('tests', 'files', 'test-repo-pre',
                                 'cookiecutter.json')
    print(template_name)
    context = load(temp_dir, template_name)
    assert context['_template'] == 'tests/files/test-repo-pre'
    assert context['project_name'] == 'project_name'
    assert context['repo_name'] == 'repo_name'
    assert context['description'] == 'description'
    assert context['author_name'] == 'author_name'
    assert context['version'] == 'version'
    assert context['open_source_license'] == 'open_source_license'


# Generated at 2022-06-11 20:27:10.562283
# Unit test for function load
def test_load():
    import shutil
    """
    Replay.load()
    """
    # Change directory to the tests directory
    os.chdir('C:\\Users\\clayton\\git\\dclayton\\cookiecutter\\tests')

    # Create a temporary directory to use for testing
    temp_dir = os.path.join(os.getcwd(), 'temp_dir')
    if not os.path.exists(temp_dir):
        os.mkdir(temp_dir)
    else:
        shutil.rmtree(temp_dir)
        os.mkdir(temp_dir)

    # Create a replay directory
    replay_dir = os.path.join(temp_dir, 'cookiecutter-replay')

# Generated at 2022-06-11 20:27:17.691048
# Unit test for function load
def test_load():
    d = dict()
    d['cookiecutter'] = dict()
    d['cookiecutter']['full_name'] = 'Hannah Montana'
    d['cookiecutter']['year'] = '2017'

    dump('tests/test_load', 'test-load', d)

    result = load('tests/test_load', 'test-load')

    assert result['cookiecutter']['full_name'] == 'Hannah Montana'
    assert result['cookiecutter']['year'] == '2017'


# Generated at 2022-06-11 20:27:21.760007
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay-dir'
    template_name = 'test-replay-dir/cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:27:30.468337
# Unit test for function load
def test_load():
    """Test load function for the context of replay file."""
    actual = load('/home/yang/github/cookiecutter_nginx_flask_uwsgi', 'cookiecutter_coogle_web_flask_git')

# Generated at 2022-06-11 20:27:36.542472
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = 'test_template'
    context = load(replay_dir, template_name)
    print('The context file loaded from {}/{}.json'.format(replay_dir, template_name))
    print(context)

# test_load()


# Generated at 2022-06-11 20:27:46.644546
# Unit test for function load
def test_load():

    TEST_DIR = 'tests/files/'
    template_name = TEST_DIR+'some_project/{{cookiecutter.repo_name}}'

    if os.path.isfile(TEST_DIR+'some_project/test_project'):
        os.remove(TEST_DIR+'some_project/test_project')

    context = {
        'full_name': 'Test User',
        'email': 'test@example.com',
        'github_username': 'testuser',
        'project_name': 'Test Project',
        'project_slug': 'test_project',
        'release_date': '2014-08-05',
        'year': '2014',
        'version': '0.1.0'
    }

    # Dump the data

# Generated at 2022-06-11 20:27:54.809836
# Unit test for function dump
def test_dump():
    import os
    import shutil
    from tempfile import mkdtemp
    from cookiecutter.main import cookiecutter
    from cookiecutter.replay import dump

    # create a temporary directory to store the output of the test
    temp_dir = mkdtemp()

    # create an environment variable to pass to cookiecutter
    # via the command-line program
    os.environ['cookiecutter_test'] = 'The answer is 42. What is the question?'

    # create a second environment variable to pass to cookiecutter
    # via the command-line program
    os.environ['cookiecutter_test_default'] = 'This is a default.'

    # call cookiecutter to create a new project from
    # the pyproject-template repository

# Generated at 2022-06-11 20:27:59.073345
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {
        'full_name': 'Jeffrey P. Bigham',
        'email': 'jeff@cs.cmu.edu',
        'project_name': 'Json Replay Test'
    }}

    template_name = 'cookiecutter-pypackage'
    replay_dir = 'tests/test-json'
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:28:04.865157
# Unit test for function load
def test_load():
    assert load(replay_dir = '.', template_name = 'unittest') == \
        {'cookiecutter': {'author_email': 'test@test.test', 'author_name': 'test', 'description': 'test', 'license': 'None', 'name': 'test', 'project_name': 'test', 'project_slug': 'test', 'project_short_description': 'test', 'use_pytest': 'n', 'version': '0.1.0'}}

# Generated at 2022-06-11 20:28:13.867886
# Unit test for function load
def test_load():
	'''
	Unit test for function load
	'''
	cwd = os.getcwd()
	test_context = {'cookiecutter': {'_template': 'test_template', 'project_name': 'test_project', 'project_slug': 'test_project', '_output_dir': '/Users/joelharkes/Documents/cookiecutter/test_project'}}
	replay_template_name = 'test_template'
	replay_dir = '/Users/joelharkes/Documents/cookiecutter/tests/replay'
	context = load(replay_dir, replay_template_name)
	if context['cookiecutter'] == test_context['cookiecutter']:
		print("Context succesfully loaded")
	else:
		print("Something went wrong")

# Unit

# Generated at 2022-06-11 20:28:25.144676
# Unit test for function load
def test_load():
    context = {'cookiecutter':{'repo_dir': 'tests/test-repo-pre',
                               'full_name': 'Some Name',
                               'email': 'some.email@some.com',
                               'github_username': 'some-username',
                               'project_name': 'Some project name',
                               'project_slug': 'some_project_name',
                               'pypi_username': '',
                               'repo_name': 'some-repo',
                               'repo_url': 'some-url',
                               'release_date': 'YYYY-MM-DD',
                               'version': '0.1.0'},
            'foobar':'foo'}

    dump(replay_dir='.', template_name='testreplay', context=context)

# Generated at 2022-06-11 20:28:34.226030
# Unit test for function load
def test_load():
    """Unit test for load"""
    replay_file = '/Users/Abhijeet/Documents/GitHub/Cookieclicker/cookiecutter-pypackage/cookiecutter/replay/csv.json'
    if not os.path.isfile(replay_file):
        raise IOError('Unable to find {}'.format(replay_file))

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

    return context


# Generated at 2022-06-11 20:28:39.975677
# Unit test for function load
def test_load():
    replay_dir = "\data\cookiecutter-django\tests\test-replay"
    template_name = "cookiecutter.json"
    context = load(replay_dir, template_name)
    assert context["cookiecutter"] == "repo/{{cookiecutter.slug}}"
    return context


# Generated at 2022-06-11 20:28:44.678183
# Unit test for function load
def test_load():
    replay_dir = './test'
    template_name = 'test_replay'
    context = {
        'cookiecutter': {
            'first_name': 'Sheng',
            'last_name': 'Yao'
        }
    }
    dump(replay_dir, template_name, context)

    context = load(replay_dir, template_name)
    assert context['cookiecutter']['first_name'] == 'Sheng'
    assert context['cookiecutter']['last_name'] == 'Yao'



# Generated at 2022-06-11 20:28:50.332223
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = '/tmp'
    template_name = 'template'
    context = {
        'cookiecutter': {
            'full_name': 'Test Name',
            'email': 'test@example.com'
        }
    }
    dump(replay_dir, template_name, context)
    loaded = load(replay_dir, template_name)
    assert context == loaded



# Generated at 2022-06-11 20:28:54.999067
# Unit test for function load
def test_load():
    """
    Test method load.

    :return:
    """
    replay_file = get_file_name('/', 'test')
    context = {'cookiecutter': {'test': 'test'}, 'replay': {'test': 'test'}}

    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    try:
        context = load('/', 'test')
    except ValueError as e:
        print('Exception: ' + str(e))
        assert 0 == 1

    assert context == {'cookiecutter': {'test': 'test'}, 'replay': {'test': 'test'}}
    os.remove(replay_file)

# Generated at 2022-06-11 20:28:55.768011
# Unit test for function load
def test_load():
    pass


# Generated at 2022-06-11 20:29:01.076276
# Unit test for function dump
def test_dump():

    dict0 = {'cookiecutter':{'full_name':'dangnm97','email':'dangnm97@gmail.com'}}
    replay_dir = "data/input/cookiecutter-datafile/test"
    template_name = "test"
    #test case 1: replay dir exists
    #test case 2: replay dir does not exist


# Generated at 2022-06-11 20:29:07.330439
# Unit test for function load
def test_load():
    context = dict()
    context['cookiecutter'] = dict()
    context['cookiecutter']['author_name'] = '{{cookiecutter.author_name}}'
    context['cookiecutter']['publish_date'] = '{{cookiecutter.publish_date}}'
    context['cookiecutter']['project_name'] = '{{cookiecutter.project_name}}'
    context['cookiecutter']['project_slug'] = '{{cookiecutter.project_slug}}'

    template_name = 'test_template_name'
    replay_dir = os.path.join(os.getcwd(), 'test_replay_dir')
    dump(replay_dir, template_name, context)
    returned_context = load(replay_dir, template_name)
    assert context

# Generated at 2022-06-11 20:29:14.069047
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = "test_replay.json"
    replay_file = get_file_name(".", template_name)
    if not os.path.isfile(replay_file):
        raise FileNotFoundError("Replay file not found: {}".format(replay_file))
    else:
        context = load(".", template_name)
        print("\n{}".format(context))


# Generated at 2022-06-11 20:29:32.408648
# Unit test for function load
def test_load():
    try:
        replay_dir = 'test_cookiecutter_replay'
        template_name = 'test_template'
        context = {'cookiecutter': {'test_key': 'test_value'}}
        dump(replay_dir, template_name, context)
        assert context == load(replay_dir, template_name)
    except Exception as e:
        print('Unit test failed:', e)
        assert 1 == 0
    finally:
        try:
            os.remove(get_file_name(replay_dir, template_name))
        except Exception as e:
            print('Failed to remove test file:', e)


# Generated at 2022-06-11 20:29:32.988130
# Unit test for function dump
def test_dump():
    pass

# Generated at 2022-06-11 20:29:36.482466
# Unit test for function load
def test_load():
    test_context = load('./tests/test-replay', 'test-replay')
    assert test_context['cookiecutter'] == {'author_name': 'test', 'email': 'test@test.com'}

# Generated at 2022-06-11 20:29:41.575686
# Unit test for function load
def test_load():
    """Test load function."""
    context = load(replay_dir='/tmp',
                   template_name='replay_test')

    assert context, 'Context is required to be defined and not empty'
    assert isinstance(context, dict), 'Context is required to be of type dict'

    assert 'cookiecutter' in context, \
        'Context is required to contain a cookiecutter key'



# Generated at 2022-06-11 20:29:44.748301
# Unit test for function load
def test_load():
    context = load('/Users/wcj/Desktop/2_python/0_cookiecutter/cookiecutter-pypackage/cookiecutter-pypackage', 'new-cookiecutter-pypackage')
    print(context)

# Generated at 2022-06-11 20:29:52.835966
# Unit test for function load

# Generated at 2022-06-11 20:29:53.530420
# Unit test for function load
def test_load():
    return -1

# Generated at 2022-06-11 20:30:02.917271
# Unit test for function dump
def test_dump():
    context = {
        "cookiecutter": {
            "json_context_key": "json_context_value",
            "string_context_key": "string_context_value",
            "integer_context_key": 1,
        }
    }

    replay_dir = 'tests/files/replay'
    template_name = 'owner_name'

    # Unit test for exception raised when replay_dir doesn't exist.
    replay_dir = 'tests/files/wrong_replay'
    with pytest.raises(IOError):
        dump(replay_dir, template_name, context)

    # Unit test good case.
    replay_dir = 'tests/files/replay'
    expected ='{}{}{}'.format(replay_dir, os.sep, template_name)

# Generated at 2022-06-11 20:30:03.428424
# Unit test for function load
def test_load():
    assert load() == None

# Generated at 2022-06-11 20:30:10.745853
# Unit test for function dump
def test_dump():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_file = os.path.join(test_dir, 'test_template/{{cookiecutter.test_key1}}/test_file.txt')

    try:
        dump(test_dir, 'test_template', {'cookiecutter': {'test_key1': 'test_value1'}})
        assert os.path.exists(test_file)
    except IOError as e:
        assert False

    try:
        dump(test_dir, 'wrong_template', {'cookiecutter': {'test_key1': 'test_value1'}})
        assert False
    except IOError as e:
        assert True


# Generated at 2022-06-11 20:30:37.355628
# Unit test for function load
def test_load():
    """Test for function load."""
    replay_file = "tests/test.json"

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

    return context

# Generated at 2022-06-11 20:30:45.899124
# Unit test for function dump
def test_dump():
    payload = {
        'project_name': 'FooBar',
        'project_slug': 'foobar',
        'pypi_username': 'foobar',
        'description': 'An example Python package',
        'author_name': 'Foo Bar',
        'author_email': 'foo@bar.com',
        'version': '0.1.0',
        'license': 'MIT',
        'domain_name': 'example.com',
        'domain_path': 'foobar',
    }

    replay_dir = 'test_files'
    template = 'cookiecutter-foobar'

    # run the function
    dump(replay_dir, template, payload)

    replay = load(replay_dir, template)

    assert replay == payload


# Generated at 2022-06-11 20:30:48.735219
# Unit test for function load
def test_load():
    dir="D:\cookiecutter\tests/test_load/replay"
    template_name="cookiecutter.json"
    context=load(dir,template_name)
    print(context)
    print(type(context))

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:30:55.738579
# Unit test for function load
def test_load():
    replay_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'test_data/test_recorder'))
    template_name = 'test'
    expected_context = {
        'cookiecutter': {
            'full_name': 'Test Test',
            'email': 'test@test.com',
            'github_username': 'test',
            'project_name': 'Test',
            'project_slug': 'test',
        }
    }

    context = load(replay_dir, template_name)

    assert expected_context == context


# Generated at 2022-06-11 20:31:01.017146
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = 'test'
    context = {"cookiecutter":{"test":"test_value"}}

    dump(replay_dir, template_name, context)
    load_context = load(replay_dir, template_name)

    assert context == load_context
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-11 20:31:09.415011
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import os
    import tempfile
    import shutil
    from cookiecutter.main import cookiecutter
    from cookiecutter.replay import load

    replay_dir = tempfile.mkdtemp()
    TEST_CONTEXT = dict(
        cookiecutter={
            "project_name": "My Project",
            "project_slug": "my_project"
        }
    )
    TEMPLATE = 'tests/test-template'

    # Create a template
    output_dir = cookiecutter(TEMPLATE, replay_dir=replay_dir)

    # Load a previously generated template
    loaded_context = load(replay_dir, template_name='cookiecutter-pypackage')

    # Ensure Template was generated

# Generated at 2022-06-11 20:31:14.161318
# Unit test for function load
def test_load():
    result = load("./test_replay", "test.json")
    assert result["cookiecutter"] == 'replay'
    assert result["Author_name"] == "Author"
    assert result["email"] == "Author@author.com"


# Generated at 2022-06-11 20:31:18.969529
# Unit test for function dump
def test_dump():
    #write test data
    dump('./replay/replay.json', './successtest.json')

    #read test data
    try:
        with open('./replay/replay.json', 'r') as f:
            mydata = f.read()
    except IOError:
        print('Unable to open file')
    else:
        print('Successful dump')
        print(mydata)
      

# Generated at 2022-06-11 20:31:24.872102
# Unit test for function load
def test_load():
    replay_dir= 'replay'
    template_name= 'cookiecutter-pypackage'

# Generated at 2022-06-11 20:31:32.634474
# Unit test for function dump
def test_dump():
    mydir = "testdir"
    myname = "testname"
    context = {'cookiecutter': {'test': 'value'}}
    replay_file = get_file_name(mydir, myname)
    dump(mydir, myname, context)
    assert os.path.exists(replay_file)
    os.remove(replay_file)
    os.rmdir(mydir)
    assert not os.path.exists(mydir)
