

# Generated at 2022-06-11 20:22:12.482644
# Unit test for function load
def test_load():
    """Unit test for function load"""
    from nose2.tools import params
    from tempfile import mkdtemp
    from shutil import rmtree
    import os

    # Setup the test
    temp_dir = mkdtemp('_cookiecutter_test_load')
    test_template_name = 'test_template_name'
    test_file_name = os.path.join(temp_dir, test_template_name)
    expected_context = {'cookiecutter': {'test_key': 'test_value'}}

    # Run the test
    # test: check loading properly formed json
    with open(test_file_name, 'w') as f:
        json.dump(expected_context, f, indent=2)
    context = load(temp_dir, test_template_name)
    assert context == expected_

# Generated at 2022-06-11 20:22:22.664151
# Unit test for function dump
def test_dump():

    if not os.path.exists('/tmp/replay/'):
        os.mkdir('/tmp/replay/')

    if not os.path.exists('/tmp/replay1/'):
        os.mkdir('/tmp/replay1/')

    if not os.path.exists('/tmp/replay2/'):
        os.mkdir('/tmp/replay2/')

    # Test for non-existent directory
    try:
        dump('/tmp/replay1', 'test_template', {'cookiecutter':'test_template'})
    except IOError as e:
        print('test_dump(): Directory does not exist')

    # Test for non-string template name

# Generated at 2022-06-11 20:22:26.246501
# Unit test for function load
def test_load():
    try:
        assert load(replay_dir="/tmp/test_load",template_name="test")
    except:
        raise AssertionError("test_load_fail")



# Generated at 2022-06-11 20:22:29.198434
# Unit test for function load
def test_load():
    """Test load function"""
    assert load('/Users/christian/.cookiecutters/replay', 'pymodule-min') == {'cookiecutter': {'project_name': 'helloworld', 'repo_name': 'helloworld'}}

# Generated at 2022-06-11 20:22:37.251283
# Unit test for function load
def test_load():
    """Test load function."""
    template_name = 'testTemplate'
    context = {'cookiecutter': {'project_name': 'testProject', 'repo_name': 'testRepo'}}
    replay_dir = os.path.join(os.getcwd(), 'tests/test-template/')
    replay_file = get_file_name(replay_dir, template_name)

    dump(replay_dir, template_name, context)
    res = load(replay_dir, template_name)
    assert res == context


# Generated at 2022-06-11 20:22:47.212112
# Unit test for function load
def test_load():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    test_load_dir = os.path.join(test_dir, '..', 'tests', 'test-load-dir')
    test_load_name = 'fake-name'
    test_load_file = os.path.join(test_load_dir, '{}.json'.format(test_load_name))

    # Attempt to load the "fake-name.json" file.
    # It exists, and is an actual json format.
    dump(test_load_dir, test_load_name, {'cookiecutter': 'replay'})
    loaded_context = load(test_load_dir, test_load_name)
    os.remove(test_load_file)

# Generated at 2022-06-11 20:22:52.415463
# Unit test for function load
def test_load():
    replay_dir = '/Users/konglinglong/workspace/cookiecutter-pypackage'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)

# Generated at 2022-06-11 20:23:00.404654
# Unit test for function load
def test_load():
    template_name = 'cookiecutter-pypackage'
    replay_dir = '{}/replay/tmp'.format(os.path.dirname(os.path.realpath(__file__)))
    try:
        os.remove(get_file_name(replay_dir, template_name))
    except Exception:
        pass

    try:
        # test for not exist replay file
        load(replay_dir, template_name)
    except Exception as e:
        assert str(e) == 'No such file or directory: \'{}\''.format(get_file_name(replay_dir, template_name))
    else:
        assert False

    # generate a replay file

# Generated at 2022-06-11 20:23:04.797810
# Unit test for function load
def test_load():
    replay_dir = "replay_files"
    template_name = "my_project"
    replay_file = get_file_name(replay_dir, template_name)
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:23:11.846203
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import tempfile

    template_name = 'test_file'
    replay_dir = tempfile.mkdtemp()
    context = {'cookiecutter': {'test_data': 'test_data'}}

    # Write context to file
    dump(replay_dir, template_name, context)

    # Load context from file
    context_from_file = load(replay_dir, template_name)

    assert context == context_from_file

# Generated at 2022-06-11 20:23:17.433332
# Unit test for function load
def test_load():
    replay_dir = 'cookiecutter'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:23:20.941572
# Unit test for function get_file_name
def test_get_file_name():
    """."""
    replay_dir = 'cookiecutter/replay'
    template_name = 'website'
    assert get_file_name(replay_dir, template_name) == 'cookiecutter/replay/website.json'


# Generated at 2022-06-11 20:23:25.049235
# Unit test for function load
def test_load():
    """Unit tests for function load."""
    # print('Loading from file...')
    replay_dir = os.path.expanduser('~/.cookiecutter_replay')
    template_name = 'pypackage'
    context = load(replay_dir, template_name)
    # print(context)


# Generated at 2022-06-11 20:23:31.140142
# Unit test for function dump
def test_dump():
    # create a dict to write to the file
    context = {
        'cookiecutter': {
            'name': 'testDumpName',
            'test': {
                'test': 'testDumpValue'
            }
        }
    }

    # save json to replay_dir
    replay_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'replays')
    template_name = 'test_dump_replay'
    dump(replay_dir, template_name, context)

    # load json to a dict
    reloaded_context = load(replay_dir, template_name)

    assert reloaded_context == context

    # remove the file after test
    replay_file = get_file_name(replay_dir, template_name)
   

# Generated at 2022-06-11 20:23:34.542807
# Unit test for function load
def test_load():
    context = load('tests/test-replay', 'tests/fake-repo-pre/')
    assert context is not None
    assert 'cookiecutter' in context
    assert context['cookiecutter']['repo_dir'] == 'tests/fake-repo-pre/'

# Generated at 2022-06-11 20:23:38.916342
# Unit test for function load
def test_load():
    assert isinstance(load('./tests/fake-repo-pre/', 'foobar'), dict)
    try:
        load('./', 'not-a-file.json')
    except IOError:
        pass
    try:
        load('./', 'fake-repo-post/fake-repo-pre/')
    except IOError:
        pass


# Generated at 2022-06-11 20:23:44.435123
# Unit test for function load
def test_load():
    template_name = 'cookiecutter-pypackage'
    template_dir = os.path.abspath(os.path.dirname(__file__))
    replay_file = get_file_name(template_dir, template_name)
    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    assert 'cookiecutter' in context

# Generated at 2022-06-11 20:23:49.829849
# Unit test for function load
def test_load():
    try:
        replay_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..')
        context = load(replay_dir, 'firstproject')
        assert(context['cookiecutter']['repo_dir'] == '~/projects/')
    except:
        assert(False)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:23:57.753951
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join('~', '.cookiecutters')
    template_name = 'my/template'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.expanduser(os.path.join('~', '.cookiecutters', 'my/template.json'))
    template_name = template_name + '.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.expanduser(os.path.join('~', '.cookiecutters', 'my/template.json'))


# Generated at 2022-06-11 20:24:01.840259
# Unit test for function load
def test_load():
    context = load('/home/tin/Documents/CookieCutter/cookiecutter-django/tests',
                   'default')

    # Test expected value
    assert(context['cookiecutter']['project_name'] == 'Test Project')

# Generated at 2022-06-11 20:24:06.876313
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'test-replay'
    context = load(replay_dir, template_name)
    print(context)
    return context


# Generated at 2022-06-11 20:24:11.751331
# Unit test for function load
def test_load():
    context = load("/home/gopikrishna/Desktop/assignments/assignment4","assignment4")
    print(context)
    assert context == {'foo': 'Hi!', 'cookiecutter': {'project_slug': 'assignment4'}}

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-11 20:24:17.275538
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = '.'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['repo_dir'] == 'pipline_test'
    assert context['cookiecutter']['filename_pattern'] == '{{ slug }}'


# Generated at 2022-06-11 20:24:20.360994
# Unit test for function get_file_name
def test_get_file_name():
    """Test if file_name is correct."""
    expected_file_name = 'replay/cookiecutter-pypackage.json'
    actual_file_name = get_file_name('replay/', 'cookiecutter-pypackage')
    assert expected_file_name == actual_file_name

# Generated at 2022-06-11 20:24:29.032978
# Unit test for function load
def test_load():
    # Manual test, you should run coverage from the package root directory
    from .main import cookiecutter
    import shutil

    # Build a fake template
    template_path = 'tests/fake-repo-tmpl'
    shutil.copytree(template_path, 'tests/test-load-tmpl')
    # Run cookiecutter and dump a replay
    replay_dir = 'tests/test-load-tmpl/{{cookiecutter.repo_name}}/.cookiecutter-replay'
    context = cookiecutter(
        template='tests/test-load-tmpl/',
        no_input=True,
        replay_dir=replay_dir,
    )
    assert context['cookiecutter']['project_name'] == 'Fake Project', context
    # Load the replay, should be identical with the context
   

# Generated at 2022-06-11 20:24:31.777246
# Unit test for function load
def test_load():
    context = load('/Users/qianqian/Dropbox/projects/cookiecutter-pypackage/tests/test-data', 'test_load')
    assert 'cookiecutter' in context

test_load()


# Generated at 2022-06-11 20:24:41.968922
# Unit test for function load
def test_load():
    # Test loading invalid file
    #result = load('non-existent-directory', 'non-existent-file.json')
    result = load('C:/Users/Michael/Desktop', 'non-existent-file.json')
    assert result == "IOError: [Errno 2] No such file or directory: 'C:/Users/Michael/Desktop/non-existent-file.json'"

    # Test loading valid file
    #result = load('C:/Users/Michael/Desktop/cookiecutter-django-rest-framework', 'replay-cookiecutter.json')
    result = load('C:/Users/Michael/Desktop', 'replay-cookiecutter.json')
    assert result['cookiecutter'] == 'C:/Users/Michael/Desktop/cookiecutter-django-rest-framework'



# Generated at 2022-06-11 20:24:48.717604
# Unit test for function dump
def test_dump():
    """Unit test for function dump"""

    file_path = '/tmp/cookiecutter/dump.json'
    context = {
        'cookiecutter': {},
        'test': 'test'
    }
    context['cookiecutter']['time'] = '2016-03-02'
    context['cookiecutter']['full_name'] = 'Jian ZHOU'

    replay_dir = os.path.dirname(file_path)
    template_name = os.path.basename(file_path)

    dump(replay_dir, template_name, context)


if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-11 20:24:51.567242
# Unit test for function load
def test_load():
    replay_dir = os.path.abspath(os.path.join(__file__, '../../../replay'))
    template_name = 'example'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:24:53.824236
# Unit test for function load
def test_load():
    context = load('./tests/test-replay', 'pypackage')
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'


# Generated at 2022-06-11 20:25:04.293056
# Unit test for function dump
def test_dump():
    """
    Function test for cookiecutter.replay.dump
    """
    replay_dir = os.path.join('tests', 'test-replay')
    template_name = os.path.join('tests', 'fake-repo-pre/{{cookiecutter.repo_name}}')
    context = {
        'cookiecutter': {
            'repo_name': 'my-fake-repo',
            'full_name': 'Your Name',
            'email': 'your@email.com',
            'description': 'A short description of the project.',
            'domain_name': 'example.com',
            'version': '0.1.0',
            'open_source_license': 'MIT'
        }
    }

    dump(replay_dir, template_name, context)
    loaded_data

# Generated at 2022-06-11 20:25:05.029078
# Unit test for function load
def test_load():
    assert(isinstance(load('./', 'cookiecutter-pypackage'), dict))


# Generated at 2022-06-11 20:25:08.820415
# Unit test for function load
def test_load():
    import tempfile
    import shutil
    import json

    replay_dir = tempfile.mkdtemp()
    template_name = 'foo'

    context = {
        'cookiecutter': {
            'full_name': 'delicious'
        }
    }

    dump(replay_dir, template_name, context)

    read_context = load(replay_dir, template_name)

    assert read_context == context

    shutil.rmtree(replay_dir)

# Generated at 2022-06-11 20:25:20.235768
# Unit test for function load
def test_load():
    import os
    import shutil
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutter')
    template_name = 'test'
    # Make a test directory
    make_sure_path_exists(replay_dir)
    replay_file = get_file_name(replay_dir, template_name)
    # Make test file
    with open(replay_file, 'w') as outfile:
        json.dump({'cookiecutter':{'foo':'bar'}}, outfile)
    # Try to load
    context = load(replay_dir, template_name)
    assert context == {'cookiecutter':{'foo':'bar'}}
    # Clean up
    shutil.rmtree(replay_dir)

# Generated at 2022-06-11 20:25:31.487803
# Unit test for function load
def test_load():
    """
    Check load function works as expected.
    """
    import shutil
    path_to_replay_dir = "../tests/files/test-load-replay"
    replay_dir = 'replay'

    try:
        shutil.rmtree(path_to_replay_dir, ignore_errors=True)
    except OSError:
        return False

    # create a replay directory, by first creating the replay file
    # and then loading the replay file
    try:
        dump(path_to_replay_dir, "test-load-replay-file", {"cookiecutter": {"hello_world": "test_load"}})
    except IOError:
        return False


# Generated at 2022-06-11 20:25:35.111428
# Unit test for function load
def test_load():
    """
    test_load.

    ------------------------------------
    """
    # Set parameters
    replay_dir = 'C:\\Users\\TramTran\\Desktop\\Git\\cookiecutter-pytorch-custom\\replay\\'
    template_name = 'my-first-pj'

    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:25:38.191698
# Unit test for function load
def test_load():
    replay_dir = 'test'
    template_name = 'test'
    data = {'cookiecutter': {'TEST': True}}
    dump(replay_dir, template_name, data)
    assert load(replay_dir, template_name) == data
    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-11 20:25:42.868605
# Unit test for function load
def test_load():
    context = load('C:\\Users\\Rafael\\PycharmProjects\\Testing_Cookiecutter\\cookiecutter-pypackage\\cookiecutter\replay','test')
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['project_name'] == 'Test'


# Generated at 2022-06-11 20:25:50.240686
# Unit test for function dump
def test_dump():
    context = {}
    context['cookiecutter'] = {}
    template_name = 'github.com/pydanny/cookiecutter-djangopackage'
    replay_dir = 'tests/test-replay'
    dump(replay_dir, template_name, context)
    assert (os.path.isfile(get_file_name(replay_dir, template_name)))
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-11 20:25:55.144272
# Unit test for function load
def test_load():
    template_name = 'dummy_template'
    replay_dir = 'replay_dir'
    context={}
    context['cookiecutter']={}
    context['cookiecutter']['full_name'] = 'fname'
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-11 20:26:05.143398
# Unit test for function load
def test_load():
    """Test load() using a temporary directory."""
    from cookiecutter import replay
    from cookiecutter import utils

    data = {'foo': 'bar', 'cookiecutter': {'foo': 'bar'}}

    temp_dir = os.path.join(os.getcwd(), 'random_dir')
    make_sure_path_exists(temp_dir)

    replay_file = get_file_name(temp_dir, 'template_name')

    with open(replay_file, 'w') as infile:
        json.dump(data, infile, indent=2)

    loaded_data = replay.load(temp_dir, 'template_name')

    utils.rmtree(temp_dir)

    assert data == loaded_data



# Generated at 2022-06-11 20:26:12.429678
# Unit test for function dump
def test_dump():
    import os
    replay_dir = os.path.join('.', 'replay')
    template_name = 'test'
    context = {'cookiecutter': {'_replay_file': 'replay.json'}}
    dump(replay_dir, template_name, context)
    context_test = load(replay_dir, template_name)
    assert context == context_test
    os.remove(os.path.join(replay_dir, 'test.json'))


test_dump()

# Generated at 2022-06-11 20:26:15.303208
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    dump('/tmp', 'test_data', {'cookiecutter': {'test': 'data'}})



# Generated at 2022-06-11 20:26:20.061604
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), "data")
    template_name = "complete_project"
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context

# Generated at 2022-06-11 20:26:24.622626
# Unit test for function load
def test_load():
    replay_dir = 'C:\\Users\\yueqi.shi\\Desktop\\Cookiecutter-Django-master\\cookiecutter'
    template_name = 'cookiecutter-django'
    # replay_file = get_file_name(replay_dir, template_name)
    # print replay_file
    context = load(replay_dir, template_name)

# Generated at 2022-06-11 20:26:34.778104
# Unit test for function dump
def test_dump():
    '''Unit test for function dump'''
    import os
    import shutil
    os.makedirs("/tmp/replay_dir")
    template_name = "test.json"
    context = {
        "cookiecutter": {
            "first_name": "Audrey",
            "last_name": "Roy",
            "email": "audreyr@example.com",
        },
    }
    dump("/tmp/replay_dir", template_name, context)
    assert os.path.isfile("/tmp/replay_dir/test.json")
    os.remove("/tmp/replay_dir/test.json")
    shutil.rmtree("/tmp/replay_dir")


# Generated at 2022-06-11 20:26:44.455885
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    # First run
    replay_dir = '/tmp'
    template_name = 'gh:mmistakes/cookiecutter-jekyll-now'
    context = cookiecutter(template_name, replay_dir=replay_dir)
    assert context['cookiecutter']['repo_name'] == context['repo_name']
    assert context['cookiecutter']['repo_url'] == context['repo_url']
    assert context['cookiecutter']['replay_dir'] == replay_dir
    assert context['cookiecutter']['template_name'] == template_name

    # Second run
    context = cookiecutter(template_name, replay_dir=replay_dir)

# Generated at 2022-06-11 20:26:47.149050
# Unit test for function load
def test_load():
    replay_dir = '/Users/lzhang/Documents/Github/Cookiecutter/'
    template_name = 'foobar'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:26:52.219627
# Unit test for function load
def test_load():
    # Create a file
    import tempfile
    f = tempfile.NamedTemporaryFile()
    f.write(b'{"username":"anybody","cookiecutter":{}}')
    f.flush()

    context = load(f.name, "test")
    if context['username'] != 'anybody':
        raise ValueError('test_load has errors')

    f.close()

# Generated at 2022-06-11 20:26:59.337358
# Unit test for function load
def test_load():
    replay_dir = '{{ cookiecutter.replay_dir }}'
    template_name = '{{ cookiecutter.directory_name }}'
    context = load(replay_dir, template_name)
    if 'cookiecutter.{{ cookiecutter.project_slug }}' not in context:
        raise ValueError('Context is required to contain a cookiecutter.{{ cookiecutter.project_slug }} key')
    print('Cookiecutter context loaded from {}'.format(replay_dir + '/' + template_name))
    return context

# Generated at 2022-06-11 20:27:06.478199
# Unit test for function load
def test_load():
    temp_context = {
        'cookiecutter': {
            'full_name': 'Test',
            'email': 'test@example.com',
            'project_slug': 'test'
        }
    }
    dump('tests/test-load', 'test-load/', temp_context)
    context = load('tests/test-load', 'test-load/')
    assert context == temp_context

# Generated at 2022-06-11 20:27:17.007031
# Unit test for function load
def test_load():
    template_name = 'cookiecutter-{{cookiecutter.project_slug}}'
    file_path = 'C:\\Users\\J\\AppData\\Local\\Temp\\cookiecutter-test_replay1'
    context = {'cookiecutter': {'test_input': 't', 'test_input_default': 't'}}
    if not make_sure_path_exists(file_path):
        raise IOError('Unable to create replay dir at {}'.format(file_path))
    replay_file = get_file_name(file_path, template_name)
    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    test_context = load(file_path, template_name)
    if test_context != context:
        raise

# Generated at 2022-06-11 20:27:21.760439
# Unit test for function dump
def test_dump():
    template_name = 'template_name'
    context = {'cookiecutter': {'name': 'John Doe'}}
    dump('replay', template_name, context)
    new_context = load('replay', template_name)
    assert context == new_context

# Generated at 2022-06-11 20:27:28.897121
# Unit test for function load
def test_load():
    """Test for load function."""
    template_name = 'template.json'
    # test for template_name is not of type str
    try:
        context = load('./', 1)
    except TypeError as e:
        print(e)
    # context not contain a cookiecutter key
    try:
        context = load('./', template_name)
    except ValueError as e:
        print(e)

    template_name = 'cookiecutter'
    context = load('./', template_name)
    print(context)


# Generated at 2022-06-11 20:27:32.180347
# Unit test for function load
def test_load():
    """Unit test for function load."""
    load('mock_project/cookiecutter-pypackage-minimal/.cookiecutter-replay', 'mock_project/cookiecutter-pypackage-minimal/')

# Generated at 2022-06-11 20:27:36.577248
# Unit test for function load
def test_load():
    context = load('/home/gagandeep/E/CookiecutterProject/cookiecutter/tests/test-replay', 'simple_add')
    assert(context)


# Generated at 2022-06-11 20:27:40.470870
# Unit test for function load
def test_load():
    try:
        context = load('/Users/jpotts/PycharmProjects/cookiecutter-sample-app/replay', 'sample-app')
    except ValueError:
        print("Test Failed.")



# Generated at 2022-06-11 20:27:48.482939
# Unit test for function dump
def test_dump():

    replay_dir = '/tmp/replays'
    template_name = 'test'
    make_sure_path_exists(replay_dir)

# Generated at 2022-06-11 20:27:55.678887
# Unit test for function load
def test_load():
    import sys
    sys.path.append('..')
    from cookiecutter.utils import load_config
    sys.path.remove('..')
    print("## Start unit test for function load")
    print("Loading config.yaml for testing...", end=' ')
    config = load_config()
    print("Done")
    testing_dict = {
        "key1": {
            "key1": "value1",
            "key2": "value2",
            "key3": "value3",
            "key4": "value4"
        },
        "key2": "value2",
        "key3": "value3",
    }
    print("Creating a test file for testing...", end=' ')

# Generated at 2022-06-11 20:27:57.469031
# Unit test for function load
def test_load():
    assert load('test_files', 'example.json') == {'cookiecutter': {'cookiecutter.replay': 'example.json-0'}}

# Generated at 2022-06-11 20:28:05.392817
# Unit test for function load
def test_load():
    from pprint import pprint
    import json
    import os

    replay_dir = 'tests/files/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    pprint(context)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:28:07.049773
# Unit test for function load
def test_load():
    context = load("tests/test-output/", "replay")
    assert(context["cookiecutter"] == {"key1": "value1", "key2": "value2"})

# Generated at 2022-06-11 20:28:16.146663
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'full_name': 'Test',
            'email': 'test@example.com',
            'project_name': 'project',
            'project_short_description': 'My Test Project',
            'repo_name': 'my_test_project'
        }
    }
    dump('test', 'test', context)
    json_file_name = get_file_name('test', 'test')
    
    # Test dump function
    assert os.path.isfile(json_file_name) == True
    # Test dump function
    assert os.path.getsize(json_file_name) > 0
    # Test dump function
    assert os.path.splitext(json_file_name)[1] == '.json'
    # Test dump function

# Generated at 2022-06-11 20:28:24.034483
# Unit test for function load
def test_load():
    """Run the tests."""
    import pytest

    dir_path = '/Users/jack/workspace'
    template_name = 'build-python-package'

    # Test load right
    context = load(dir_path, template_name)
    assert context['cookiecutter']['author_name'] == 'Jack Guo'

    # Test load wrong
    template_name = 'any'
    expected_msg = 'Context is required to contain a cookiecutter key'
    with pytest.raises(ValueError) as excinfo:
        load(dir_path, template_name)
    assert str(excinfo.value) == expected_msg

# Generated at 2022-06-11 20:28:28.386120
# Unit test for function load
def test_load():
    test_replay_dir = "load_test"
    template_name = "test_template"
    context = {"test": "test", "cookiecutter": {"key": "test_key"}}
    dump(test_replay_dir, template_name, context)
    test_context = load(test_replay_dir, template_name)
    if test_context == context:
        print("The load function works correctly!")
    else:
        print("The load function is not correct!")


# Generated at 2022-06-11 20:28:34.254165
# Unit test for function load
def test_load():
    """Test for function load."""
    template_name = 'test_template'
    replay_dir = 'test'
    test_context = {'cookiecutter': {'test_key': 'test_value'}}
    dump(replay_dir, template_name, test_context)
    context = load(replay_dir, template_name)

    assert context == test_context
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-11 20:28:41.036378
# Unit test for function load
def test_load():
    replay_dir = 'C:\\Users\\Soma\\Desktop\\Projects\\Cookiecutter_replay_folder'
    template_name = 'C:\\Users\\Soma\\Desktop\\Projects\\Cookiecutter_replay_folder\\Python3_module'
    context = load(replay_dir,template_name)
    assert type(context) == dict

    
    

# Generated at 2022-06-11 20:28:47.104741
# Unit test for function load
def test_load():
    test_template_name = 'function_load_test'
    test_context = {'cookiecutter': {'a': {'a': 'a-a'}}}

    result = load('replay', test_template_name)
    assert result == {'cookiecutter': {'a': {'a': 'a-a'}}}


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:28:50.984477
# Unit test for function load
def test_load():
    replay_dir = '/Users/yhli1/PycharmProjects/CookiecutterStudy/tests/test-replay-dir'
    template_name = 'test.json'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:28:57.797683
# Unit test for function load
def test_load():
    template_name = "String"
    context = {"cookiecutter" : {"project_name" : "Test-Cookiecutter"}}
    try:
        replay.load("replay_tests", template_name)
    except:
        print("Correct exit from load")
    try:
        replay.load("replay_tests", project_name)
    except:
        print("Exit from load with wrong template name type ")
    try:
        replay.load("replay_tests", template_name)
    except:
        print("Context is required to contain a cookiecutter key")
    print("The json data read from file: ", replay.load("replay_tests", template_name))


# Generated at 2022-06-11 20:29:13.705817
# Unit test for function load
def test_load():

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_context = load(test_dir, 'test_context')
    assert 'cookiecutter' in test_context
    assert test_context['cookiecutter']['author_email'] == 'you@example.com'
    assert test_context['cookiecutter']['open_source_license'] == 'MIT license'


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:29:21.633918
# Unit test for function load
def test_load():
    """Load is tested using a template named cookiecutter-test-template."""
    import os
    import sys
    import pytest

    # Arrange
    replay_dir = os.path.join(os.environ['TEST_DIR'], 'replay')
    template_name = os.path.join(os.environ['TEST_DIR'], 'cookiecutter-test-template')
    
    
    # Act
    actual = load(replay_dir, template_name)

    # Assert
    assert actual != None
    assert actual['cookiecutter']['repo_dir'] == os.path.join(os.environ['TEST_DIR'], 'cookiecutter-test-template')


# Generated at 2022-06-11 20:29:25.321692
# Unit test for function load
def test_load():
    context = load("D:\\Github\\cookiecutter-pypackage", "cookiecutter.json")
    assert context['cookiecutter']['project_name'] == '{{ cookiecutter.project_name }}'


# Generated at 2022-06-11 20:29:33.266758
# Unit test for function load

# Generated at 2022-06-11 20:29:39.567330
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    from cookiecutter.main import cookiecutter
    replay_dir = 'tests/fixtures/fake-replay'
    cookiecutter('tests/fake-repo-pre/', replay_dir=replay_dir)
    replay_file = get_file_name(replay_dir,'tests/fake-repo-pre/')
    assert os.path.isfile(replay_file)



# Generated at 2022-06-11 20:29:46.235255
# Unit test for function dump
def test_dump():
    '''
    test_dump():
    this function will test the dump() by creating a folder
    and file and then dumping data in it.
    '''
    import shutil
    replay_dir = 'test_replay_dir'

    # if the test_replay_dir already exists, delete it
    if os.path.isdir(replay_dir):
        shutil.rmtree(replay_dir)

    template_name = 'test.json'
    context = {'cookiecutter': {'key1': ['a', 'b', 'c']}}

    dump(replay_dir, template_name, context)

    # verify the results
    assert os.path.isdir(replay_dir) is True

# Generated at 2022-06-11 20:29:48.384904
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('.cookiecutters/', 'example_name')
    assert {'cookiecutter': {}} == context

# Generated at 2022-06-11 20:29:55.464591
# Unit test for function load
def test_load():
    """Unit test for function load"""
    my_replay_dir="test_load"
    my_template_name="test_load"
    my_file_name=my_template_name+".json"
    my_template_file=get_file_name(my_replay_dir,my_template_name)

    ####################
    # path not exists. #
    ####################
    # 1. create_path: None; mode: r
    context=load(my_replay_dir,my_template_name)
    assert context==None

    # 2. create_path: None; mode: w
    context=load(my_replay_dir,my_template_name)
    assert context==None

    # 3. create_path: not exists; mode: r

# Generated at 2022-06-11 20:30:01.123251
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'project_name': 'unit test', 'repo_name': 'test'}}

    template = 'test.json'

    dump('tests/test_files/test', template, context)
    test_result = load('tests/test_files/test', template)
    assert context == test_result
    os.remove('tests/test_files/test/test.json')
    os.rmdir('tests/test_files/test')

# Generated at 2022-06-11 20:30:02.794508
# Unit test for function load
def test_load():
    pass


# Generated at 2022-06-11 20:30:17.101925
# Unit test for function load
def test_load():
        replay_dir = '/home/kazi/Projects/cookiecutter-py2/'
        template_name = 'cookiecutter-pypackage'
        cookiecutter = load(replay_dir, template_name)
        print(cookiecutter)


# Generated at 2022-06-11 20:30:18.833805
# Unit test for function load
def test_load():

    output = load(replay_dir='.', template_name='template.json')

    assert output



# Generated at 2022-06-11 20:30:21.204608
# Unit test for function load
def test_load():
    if __name__ == '__main__':
        assert 'cookiecutter' in load('./', 'cookiecutter-Pypackage')

# Generated at 2022-06-11 20:30:30.240262
# Unit test for function load
def test_load():
    context = load('replay_dir', 'template_name')
    assert context['cookiecutter']
    assert context['cookiecutter']['full_name'] == 'Pritesh Karandikar'
    assert context['cookiecutter']['email'] == 'pkarandi@gmail.com'
    assert context['cookiecutter']['github_username'] == 'pkarandi'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_short_description'] == 'A cookiecutter template for a Python package'
    assert context['cookiecutter']['pypi_username'] == 'pkarandi'


# Generated at 2022-06-11 20:30:33.558195
# Unit test for function dump
def test_dump():
    replay_file = 'test/test_replay'
    template_name = 'test-replay'
    context = {'cookiecutter': {'Project_name': 'test'}}
    dump(replay_file, template_name, context)


# Generated at 2022-06-11 20:30:36.031750
# Unit test for function load
def test_load():
    context = load('/home/hongyang/Projects/dulwich-templates', 'gh:wq123456789/dulwich-template-main')


# Generated at 2022-06-11 20:30:42.480770
# Unit test for function dump
def test_dump():
    from cookiecutter.replay import dump
    from cookiecutter.utils import WORKING_DIR

    replay_dir = os.path.join(WORKING_DIR, 'tests/test-output/replay')
    template_name = 'test'
    context = {'cookiecutter': {'full_name': 'monty'}}

    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    assert context.get('cookiecutter')['full_name'] == 'monty'

# Generated at 2022-06-11 20:30:49.368920
# Unit test for function load

# Generated at 2022-06-11 20:30:52.645724
# Unit test for function load
def test_load():
    template_name = 'django-project'
    replay_dir = 'cookiecutter/tests/test-load-dl'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert context['cookiecutter']['project_name'] == 'Raccourci'


# Generated at 2022-06-11 20:30:55.177621
# Unit test for function load
def test_load():
    data = load('.', 'test_replay')
    assert data['cookiecutter']['full_name'] == 'test-replay'

# Generated at 2022-06-11 20:31:20.505764
# Unit test for function load
def test_load():
    context = load('/data/CookieCutter/replay/', 'nifi_template_31HD')
    print(context)

# test_load()

# Generated at 2022-06-11 20:31:22.153380
# Unit test for function load
def test_load():
    load(replay_dir='../cookiecutter-pypackage', template_name='cookiecutter-pypackage')


# Generated at 2022-06-11 20:31:31.338823
# Unit test for function load
def test_load():
    template_name = 'test_load'
    replay_dir = os.path.join(os.path.curdir, '.cookiecutter_replay')
    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))
    context = dict(cookiecutter=dict(test='test_data'))
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    print('test_load:', context)

# Generated at 2022-06-11 20:31:33.954177
# Unit test for function load
def test_load():
    input_dir = '.'
    template_name = 'test_load'
    context = {'cookiecutter': {'test': 'test_load'}}
    dump(input_dir, template_name, context)

    new_context = load(input_dir, template_name)
    if context != new_context:
        print('ERROR in replay.load')



# Generated at 2022-06-11 20:31:43.001487
# Unit test for function dump
def test_dump():
    import tempfile
    replay_dir = tempfile.mkdtemp()
    # test directory exists
    assert make_sure_path_exists(replay_dir)

    # test get_file_name
    assert get_file_name(replay_dir, 'test.json') == replay_dir + '/test.json'
    assert get_file_name(replay_dir, 'test') == replay_dir + '/test.json'

    # test dump
    template_name = 'test_template_1'
    context = {'cookiecutter': {'cookie': 'sweet'}}
    dump(replay_dir, template_name, context)
    # test if file created
    assert (replay_dir + '/' + template_name + '.json') in os.listdir(replay_dir)

    # test a bad

# Generated at 2022-06-11 20:31:44.175885
# Unit test for function load
def test_load():
    load("../tests/test-generate/", "template")


# Generated at 2022-06-11 20:31:48.300619
# Unit test for function dump
def test_dump():
    replay_dir = '/Users/victormartinez/cookiecutter-project/tests/test-replay'
    template_name = 'test-replay-file'
    context = {'cookiecutter': 'test'}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:31:50.277830
# Unit test for function load
def test_load():
    assert load(replay_dir = '~/.cookiecutter_replay', template_name = 'cookiecutter-pypackage') is not None

# Generated at 2022-06-11 20:31:52.697887
# Unit test for function load
def test_load():
    """Test to see if it can load a replay."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-project'
    context = load(replay_dir, template_name)

# Generated at 2022-06-11 20:31:55.191284
# Unit test for function load
def test_load():
    ret = load("/tmp/cc", "cpp-cmake-git")
    print("ret = ", ret)
