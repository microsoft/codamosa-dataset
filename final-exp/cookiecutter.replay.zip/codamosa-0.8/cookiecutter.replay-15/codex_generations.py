

# Generated at 2022-06-11 20:22:25.232285
# Unit test for function dump
def test_dump():
    replay_dir = 'C:\\Users\\jthiagarajan\\Desktop\\cookiecutter-j2ee'
    template_name = 'test.json'
    context = {'cookiecutter':{'project_name':'my-project','package_name':'com.mycompany.myproject','framework':'spring-mvc','java_version':'7','build_system':'maven'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:22:29.752273
# Unit test for function dump
def test_dump():
    import tempfile

    temp_dir = tempfile.mkdtemp()
    template_name = 'test'
    context = {'cookiecutter': 'hello'}

    replay_dir = os.path.join(temp_dir, 'replay')
    dump(replay_dir, template_name, context)

    assert os.path.exists(replay_dir) is True



# Generated at 2022-06-11 20:22:34.986594
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.getcwd(), 'replay')
    template_name = 'test_dump'
    context = {'cookiecutter': {'a': 'A', 'b': 'B'}}

    dump(replay_dir, template_name, context)
    print(load(replay_dir, template_name))


# Generated at 2022-06-11 20:22:37.570750
# Unit test for function get_file_name
def test_get_file_name():
    outfile_name = get_file_name()
    assert outfile_name == 'replay/default.json'

# Generated at 2022-06-11 20:22:47.239697
# Unit test for function load
def test_load():
    os.chdir(os.path.dirname(__file__))
    # location of replay file
    replay_dir = os.path.join('replay', 'release_0.6.0')

    # load data of the replay file
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)

    # check if the context contains cookiecutter key
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

    # check the type of context
    if not isinstance(context, dict):
        raise TypeError('Context is required to be of type dict')

    # check the type of template name

# Generated at 2022-06-11 20:22:48.517617
# Unit test for function load
def test_load():
    assert load('tests/test-output', 'test-template').get('cookiecutter') is not None

# Generated at 2022-06-11 20:22:57.218112
# Unit test for function dump
def test_dump():
    replay_dir = '/tmp/cookiecutter-replay/'
    template_name = 'mytemplate'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'cookiecutter-pypackage',
        }
    }
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))


# Generated at 2022-06-11 20:23:00.344695
# Unit test for function load
def test_load():
    obj = load("D:\\git\\emoji_nickname\\.cookiecutters", "test.json")
    print(obj)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:23:05.804122
# Unit test for function dump
def test_dump():
    replay_dir = '/tmp'
    template_name = 'abcd'
    context = {'a':'A', 'b':'B'}
    dump(replay_dir, template_name, context)
    target_file = os.path.join(replay_dir, template_name + '.json')
    assert os.path.isfile(target_file)
    os.remove(target_file)

# Generated at 2022-06-11 20:23:14.221834
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'tmp'))

    test_cookiecutter = {
        "cookiecutter": {
            "project_name": "Test Project",
            "email": "me@example.com",
            "github_username": "audreyr"
        }
    }

    dump(replay_dir, 'test', test_cookiecutter)
    result = load(replay_dir, 'test')
    yielded = next(iter(result))
    assert yielded == 'cookiecutter'

# Generated at 2022-06-11 20:23:24.433266
# Unit test for function load
def test_load():
    """Unit test for function load."""
    test_context = {
        'cookiecutter': {
            'repo_dir': '/home/vagrant/test_root',
            'ejudge_version': '1.0.0',
            'ejudge_repo_uri': 'https://github.com/ejudge/ejudge'
        }
    }
    test_template_name = 'ejudge'
    test_replay_dir = '/home/vagrant/test_root/cookiecutter-replay'

    dump(test_replay_dir, test_template_name, test_context)
    context = load(test_replay_dir, test_template_name)

    assert context == test_context


# Generated at 2022-06-11 20:23:30.539439
# Unit test for function load
def test_load():
    # Test if function can handle invalid type of input
    try:
        load('test', 1)
        assert False
    except TypeError:
        assert True

    # Create a test file
    cookiecutter = {
        'project_name': 'Test Project',
        'a': '1',
        'b': '2',
        'c': '3',
    }
    context = {
        'cookiecutter': cookiecutter,
        'date': '12/07/2016',
        'time': '08:50:00',
    }
    dump('.', 'test', context)

    # Test if function can return correct context
    replay_context = load('.', 'test')
    assert replay_context == context

    # Delete the test file
    os.remove('./test.json')

# Generated at 2022-06-11 20:23:33.907582
# Unit test for function load
def test_load():
    context = load("/home/elmer/Documents/CNM/ml-challenge/cookiecutter-template-master-python/cookiecutter_template/templates/cookiecutter_template/", 'replay')
    assert(context['cookiecutter']['full_name'] == 'Elmer P.')
    print(context)


# Generated at 2022-06-11 20:23:38.029046
# Unit test for function dump
def test_dump():
    replay_dir = 'test'
    template_name = 'cc_tester'
    context = {'cookiecutter': {'hello': 'world', 'project_name': 'Foo Bar'}, 'somekey': 'somevalue'}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:23:48.590454
# Unit test for function load
def test_load():
    from cookiecutter.config import DEFAULT_REPLAY_DIR
    from cookiecutter.prompt import read_user_variable
    from cookiecutter.main import cookiecutter

    context = load(DEFAULT_REPLAY_DIR, 'jacobtomlinson/django-project')
    assert 'project_name' in context['cookiecutter']
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Django'

    context = load(DEFAULT_REPLAY_DIR, 'jacobtomlinson/django-project-cookiecutter')
    assert 'open_source_license' in context['cookiecutter']
    assert context['cookiecutter']['open_source_license'] == 'MIT'


# Generated at 2022-06-11 20:23:55.104202
# Unit test for function dump
def test_dump():
    replay_dir='/Users/matthew/pyminer/cookiecutter-pypackage/tests/test_replay'
    template_name='cookiecutter-pypackage'
    context={'cookiecutter':{'name':'matthew'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, 'cookiecutter-pypackage.json')) is True


# Generated at 2022-06-11 20:23:58.900342
# Unit test for function load
def test_load():
    import unittest
    class TestContext(unittest.TestCase):
        def test_load(self):
            context = load(os.path.curdir, 'context.json')
            self.assertTrue('cookiecutter' in context)
    unittest.main()


# Generated at 2022-06-11 20:24:00.665451
# Unit test for function load
def test_load():
    # Tested load in main.py
    pass


# Generated at 2022-06-11 20:24:05.949776
# Unit test for function load
def test_load():
    # Define paths
    replay_dir = "/Users/saahil/working-repo/Cookiecutter/tests/_replay"
    template_name = "foobar"

    context = load(replay_dir, template_name)
    assert isinstance(context, dict)


# Generated at 2022-06-11 20:24:06.770424
# Unit test for function load
def test_load():
    assert False, 'Test not implemented'


# Generated at 2022-06-11 20:24:12.746220
# Unit test for function load
def test_load():
    replay_dir = 'Tests/functional/replay'
    template_name = 'cookiecutter-pypackage'

    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'project_name'


# Generated at 2022-06-11 20:24:18.233142
# Unit test for function dump
def test_dump():

    context = {}
    context['cookiecutter'] = {'name': 'Duc Le', 'email': 'leducit@gmail.com'}
    dump('/tmp', 'test_dump', context)

    context_in = load('/tmp', 'test_dump')

    assert context == context_in, 'Failed to dump context to json file.'



# Generated at 2022-06-11 20:24:20.332495
# Unit test for function load
def test_load():
    replay_dir = 'tests/replay'
    template_name = 'tests'
    context = load(replay_dir, template_name)
    print(context)

test_load()

# Generated at 2022-06-11 20:24:23.475378
# Unit test for function load
def test_load():
    loaded_context = load('test_replay_dir', 'test_template_name')
    assert loaded_context == {'cookiecutter': {}}

# Generated at 2022-06-11 20:24:27.318488
# Unit test for function load
def test_load():
    replay_dir = "C:/development/replay"
    template_name = "sample_21_1"
    context = load(replay_dir, template_name)
    print("context")
    print(context)
    print("cookiecutter")
    print(context["cookiecutter"])


# Generated at 2022-06-11 20:24:33.059126
# Unit test for function load
def test_load():
    print("Start test cookiecutter.replay.load")
    replay_dir = os.path.join(os.getcwd(), 'cookiecutter-replay')
    template_name = "cookiecutter-pypackage"
    context = load(replay_dir, template_name)
    print(context['cookiecutter']['project_name'])
    print(context)
    print("End test cookiecutter.replay.load")

# Generated at 2022-06-11 20:24:36.461454
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('replay',  'test')

    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:24:40.969835
# Unit test for function load
def test_load():
    context = load("C:/Users/sweinst/PycharmProjects/cookiecutter_test/test_cookie/test_replay","")
    expected = {"cookiecutter": {"test_string": "Test", "test_number": "11", "test_number2": "2", "test_number3": "3"}}
    assert context == expected


#Unit test for function dump

# Generated at 2022-06-11 20:24:49.607236
# Unit test for function load
def test_load():
    param_file = 'test.json'

# Generated at 2022-06-11 20:24:50.333605
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-11 20:24:56.894532
# Unit test for function load
def test_load():
    template_name = 'fakerepo'
    replay_dir = 'E:\code\cookiecutter-pycharm-project'
    context = load(replay_dir, template_name)
    print(context)
    pass


# Generated at 2022-06-11 20:24:57.393932
# Unit test for function dump
def test_dump():
    pass

# Generated at 2022-06-11 20:25:01.989418
# Unit test for function load
def test_load():
    context = load(replay_dir='.cookiecutters', template_name='cookiecutter-pypackage')

    assert isinstance(context, dict), \
        'Context must be of type dict, was {}'.format(type(context))
    assert 'cookiecutter' in context, \
        'Context must contain a cookiecutter key, was {}'.format(context.keys())


# Generated at 2022-06-11 20:25:08.336887
# Unit test for function load
def test_load():
    """Test that load function works"""
    path = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fixtures')
    ctx = load(path, 'test_template')
    assert ctx

# Generated at 2022-06-11 20:25:10.812895
# Unit test for function load
def test_load():
	load('replay', '{{cookiecutter.repo_name}}')


# Generated at 2022-06-11 20:25:18.616070
# Unit test for function load
def test_load():
    from tempfile import mkdtemp
    from shutil import rmtree

    replay_dir = mkdtemp(prefix='cookiecutter-')
    template_name = 'test_template'
    context = {
        'cookiecutter': {
            '_template': template_name
        }
    }

    dump(replay_dir, template_name, context)
    rtn_context = load(replay_dir, template_name)

    assert rtn_context == context

    rmtree(replay_dir)

# Generated at 2022-06-11 20:25:20.518950
# Unit test for function load
def test_load():
    assert(load("/Users/cookiecutter", "cookiecutter") == {'cookiecutter': {}})
    pass



# Generated at 2022-06-11 20:25:31.767166
# Unit test for function load
def test_load():
    # Declare None value
    replay_dir = None
    template_name = None
    context = None

    # Test function load with empty arguments
    try:
        load(replay_dir, template_name)
    except Exception as e:
        assert str(e) == 'NoneType object is not subscriptable'

    # Test function load with non-dict type variable - ValueError
    try:
        load(replay_dir, template_name)
    except Exception as e:
        assert e.args[0] == 'Context is required to contain a cookiecutter key'

    # Test function load with dict type variable
    replay_dir = '.cookiecutters_replay'
    template_name = 'python_package'
    context = {'cookiecutter': {'full_name': 'PYTHON_PACKAGE'}}


# Generated at 2022-06-11 20:25:37.970209
# Unit test for function dump
def test_dump():
    replay_dir = '/home/Administrator/cookiecutter/replay'
    template_name = 'python-cli'

# Generated at 2022-06-11 20:25:44.092432
# Unit test for function load
def test_load():
    """
    Wirte a unit test for funtion load

    :return:
    """
    replay_dir = '~/.cookiecutters/'
    template_name = 'test'
    context = dict(cookiecutter=dict(test='test'))

    dump(replay_dir, template_name, context)
    assert(load(replay_dir, template_name)) == context

    os.remove(get_file_name(replay_dir, template_name))
    print('Test Passes.')

# Generated at 2022-06-11 20:25:55.324767
# Unit test for function load
def test_load():
    load('/home/leechanghee/cookiecutter', 'cc_pycon')
    print(load('/home/leechanghee/cookiecutter', 'cc_pycon'))
    assert load('/home/leechanghee/cookiecutter', 'cc_pycon') == {u'cookiecutter': {u'_template': u'https://github.com/audreyr/cookiecutter-pypackage.git'}}


# Generated at 2022-06-11 20:25:57.996020
# Unit test for function load
def test_load():
    context=load(replay_dir,template_name)
    assert isinstance(context,dict)


# Generated at 2022-06-11 20:25:59.385011
# Unit test for function dump
def test_dump():
    dump('test', 'test_dump', 'test2')


# Generated at 2022-06-11 20:26:02.311179
# Unit test for function load
def test_load():
    assert (load('tests/test-data/fake-api', 'no-meta'))
    try:
        load('tests/test-data/fake-api', 'no-cookiecutter')
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-11 20:26:08.700443
# Unit test for function dump
def test_dump():
    replay_dir = 'test_replay'
    template_name = 'test_template'
    context = {
        'cookiecutter': {
            'name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr'
        }
    }

    dump(replay_dir, template_name, context)

    # check if file is created
    file_name = get_file_name(replay_dir, template_name)
    assert os.path.exists(file_name) == True

    # check if context is written in file
    with open(file_name, 'r') as infile:
        read_context = json.load(infile)

    assert context == read_context


# Generated at 2022-06-11 20:26:11.728351
# Unit test for function load
def test_load():
    a = load(template_name = '',
             replay_dir = 'fake_replay_dir')
    return a

# Generated at 2022-06-11 20:26:19.788989
# Unit test for function load
def test_load():
    context = load(os.path.expanduser('~/.cookiecutters'), "cookiecutter-pypackage")
    #expect: {"cookiecutter":{"project_name":"Foo Bar", "repo_name":"foo_bar", "year":"2018"}}
    print("dumped replay:", context)
    assert context['cookiecutter']['project_name'] == "Foo Bar"
    assert context['cookiecutter']['repo_name'] == "foo_bar"
    assert context['cookiecutter']['year'] == "2018"


# Generated at 2022-06-11 20:26:23.443689
# Unit test for function load
def test_load():
    d = {'cookiecutter': {'test': 'test'}}
    template_name = 'test'
    dump('/tmp',template_name,d)
    print(load('/tmp',template_name))

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:26:26.963527
# Unit test for function dump
def test_dump():
    replay_dir = os.path.abspath('../../tests/files/test-replay')
    template_name = 'fake-repo'
    context = {'cookiecutter': {'full_name': 'Chuck'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:26:36.783997
# Unit test for function dump
def test_dump():
    template_name = 'test_template_name'
    context = {'cookiecutter': {'_template': template_name}}

    template_name = 'test_template_name_json'
    context = {'cookiecutter': {'_template': template_name}}
    # test invalid path
    replay_dir = 'i/dont/exist'
    try:
        dump(replay_dir, template_name, context)
        assert False
    except IOError:
        assert True
    # test invalid template name type
    try:
        dump('/tmp', 1, context)
        assert False
    except TypeError:
        assert True
    # test invalid context type
    try:
        dump('/tmp', template_name, [])
        assert False
    except TypeError:
        assert True
    # test missing cookie

# Generated at 2022-06-11 20:26:57.367630
# Unit test for function dump
def test_dump():
    """
    Unit test for function dump
    """
    # Init testing variables with default values
    replay_dir = './tests/test-replay'
    template_name = './tests/fake-repo-pre/'
    context = {
        'cookiecutter': {
            'full_name': 'Firstname Lastname',
            'email': 'firstname.lastname@example.com',
            'github_username': 'flastname',
            'project_name': 'Example Project',
            'project_slug': 'example_project',
            'release_date': '2013-06-01',
            'year': '2013'
        }
    }

    # Check for error: replay_dir does not exist
    test_replay_dir_does_not_exist(replay_dir, template_name, context)

# Generated at 2022-06-11 20:26:58.163050
# Unit test for function load
def test_load():
    assert 12 == 12



# Generated at 2022-06-11 20:27:05.551176
# Unit test for function load
def test_load():
    """Test function load"""
    # Test template_name is required to be of type str
    try:
        load('replay_dir', None)
        assert False
    except TypeError:
        assert True
    # Test replay_file
    assert "None.json" == get_file_name('replay_dir', None)
    context = load('replay_dir', "template_name")
    # Test context is required to contain a cookiecutter key
    try:
        load('replay_dir', "template_name")
        assert False
    except ValueError:
        assert True
    # Test context
    context['cookiecutter'] = {}
    assert type(context) is dict
    assert type(context['cookiecutter']) is dict
    context['cookiecutter']['test'] = 'test'

# Generated at 2022-06-11 20:27:14.947529
# Unit test for function dump
def test_dump():
    replay_dir = '~/.cookiecutter_replay/'
    template_name = 'foo'
    context = {
        "cookiecutter": {
            "full_name": "Quan Tong",
            "email": "quantong.hust@gmail.com",
        }
    }
    try:
        dump(replay_dir, template_name, context)
        with open(replay_dir+template_name+".json") as json_data:
            replay_context = json.load(json_data)
            if context['cookiecutter'] != replay_context['cookiecutter']:
                raise Exception("Replay context does not match")
    except:
        raise


# Generated at 2022-06-11 20:27:17.753453
# Unit test for function load
def test_load():
    rf = load('/Users/xujin/workspace/cookiecutter/tests/test-data/replay', 'cookiecutter-pypackage-minimal')

# Generated at 2022-06-11 20:27:25.584720
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = 'C:\\Users\\jason\\Desktop\\replay'
    template_name = 'python_module'
    #template_name = 'Python_Module'
    context = load(replay_dir, template_name)
    #print(context)
    assert(context['cookiecutter']['repo_name'] == 'pytry')


if __name__ == '__main__':
    import sys
    test_load()
    sys.exit(0)

# Generated at 2022-06-11 20:27:28.132573
# Unit test for function load
def test_load():
    context = load("/Users/tanvi/Desktop/b/cookiecutter/cookiecutter/replay/", "sundar-repo")
    print("value is ", context)


# Generated at 2022-06-11 20:27:31.490739
# Unit test for function dump
def test_dump():
    dump('replay', 'python', {'cookiecutter': 'test'})
    test_context = load(os.path.join(os.getcwd(), 'replay'), 'python')
    assert test_context == {'cookiecutter': 'test'}

# Generated at 2022-06-11 20:27:35.711374
# Unit test for function load
def test_load():
    os.system("cp test/fixtures/replay/welcome.json ~/.cookiecutter_replay/")
    assert load("~/.cookiecutter_replay/", "welcome")

# Generated at 2022-06-11 20:27:38.619128
# Unit test for function load
def test_load():
    dummy_context = {'cookiecutter': {'name': 'bob'}}
    replay_dir = ".tests/"
    template_name = 'dummy'

    dump(replay_dir, template_name, dummy_context)
    context = load(replay_dir, template_name)
    assert context == dummy_context

    return

# Generated at 2022-06-11 20:28:01.706652
# Unit test for function load
def test_load():
    assert(load('.', 'test.json') == {'cookiecutter': {'foo': 'bar'}})


# Generated at 2022-06-11 20:28:03.994880
# Unit test for function load
def test_load():
    replay_dir = "my_replays/"
    template_name = "python"
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:28:07.630440
# Unit test for function dump
def test_dump():
    replay_dir = '/tmp/cc_replay'
    template_name = 'cookiecutter-pypackage'
    context = {
        'cookiecutter': {'full_name': 'Audrey Roy'}
    }
    expected_file = get_file_name(replay_dir, template_name)

    dump(replay_dir, template_name, context)
    assert os.path.exists(expected_file)

    os.remove(expected_file)
    assert not os.path.exists(expected_file)


# Generated at 2022-06-11 20:28:12.887987
# Unit test for function load
def test_load():
    context = load("./tests/files/extended-master", "extended-master")
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'repo_name' in context['cookiecutter']
    assert 'context_file' in context['cookiecutter']


# Generated at 2022-06-11 20:28:16.841161
# Unit test for function dump
def test_dump():
    """
    Unit test for function dump.

    :return:
    """
    replay_dir = 'replay'
    template_name = 'template'
    context = {
        'cookiecutter': {
            'full_name': 'Yanyan Fu',
            'email': 'yanyanfu123@gmail.com'
        }
    }

    dump(replay_dir,template_name,context)


# Generated at 2022-06-11 20:28:25.502393
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import shutil
    import tempfile
    import unittest

    class TestCookiecutterState(unittest.TestCase):
        """CookiecutterState tests."""

        def setUp(self):
            """Create a temp directory."""
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            """Remove temp directory after test."""
            shutil.rmtree(self.tempdir)

        def test_load_no_data(self):
            """Test load method with no data."""
            result = load(self.tempdir, 'no_data')
            self.assertEqual(result, {})

        def test_load_corrupted_data(self):
            """Test load method with corrupted data."""

# Generated at 2022-06-11 20:28:30.501549
# Unit test for function load
def test_load():
    assert load('/home/travis/build/audreyr/cookiecutter/cookiecutter/replay/tests/test_load/fake_repo', 'fake_repo') == {"cookiecutter":{"full_name":"Audrey Roy Greenfeld", "email":"audreyr@example.com", "github_username":"audreyr"}}


# Generated at 2022-06-11 20:28:37.806552
# Unit test for function dump
def test_dump():
    """Unit test for dump."""
    import tempfile

    replay_dir = tempfile.mkdtemp()
    template_name = 'unit-test'
    context = {'cookiecutter': {'replay': True}}
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)

    with open(replay_file, 'r') as infile:
        file_context = json.load(infile)

    assert file_context == context
    # Clean up
    os.remove(replay_file)
    os.rmdir(replay_dir)


# Generated at 2022-06-11 20:28:42.522797
# Unit test for function load
def test_load():
    replay_dir = '/home/hongtaozhang/Desktop/MyProjects/lightweight-django-blog/test_load'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)
    # print(context['replay_dir'])


# Generated at 2022-06-11 20:28:50.650476
# Unit test for function load
def test_load():
        replay_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                                  '..', '..', 'tests', 'test-data', '{{cookiecutter.repo_name}}',
                                  '{{cookiecutter.repo_name}}', '.cookiecutter_replay')
        template_name = 'tpl1'
        context = load(replay_dir, template_name)
        assert 'cookiecutter' in context
        assert context['cookiecutter']['repo_name'] == '{{cookiecutter.repo_name}}'

# Generated at 2022-06-11 20:29:39.420303
# Unit test for function load
def test_load():
    DIR = os.path.dirname(os.path.realpath(__file__))
    context = load(DIR, 'replay_test')
    print(context)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:29:42.609376
# Unit test for function load
def test_load():
    """Test for the file loading replay function."""
    import os
    template_name = os.getcwd()
    replay_dir = os.path.join(template_name, 'tests')
    replay_file = get_file_name(replay_dir, template_name)
    load(replay_dir, template_name)



# Generated at 2022-06-11 20:29:44.931542
# Unit test for function dump
def test_dump():
    """
    Unit test to see if the dump method works properly
    """
    context = {'cookiecutter': {'project_name': 'test'}}
    dump('.', 'test', context)


# Generated at 2022-06-11 20:29:53.019305
# Unit test for function load
def test_load():
    """Unit test for load."""
    replay_dir = os.path.join(
        os.path.dirname(__file__), os.pardir, "tests", "replay"
    )
    template_name = "cookiecutter-pypackage"


# Generated at 2022-06-11 20:29:54.842865
# Unit test for function load
def test_load():
    context = load('/Users/jq/.cookiecutters', 'cookiecutter-pypackage')
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:29:58.148628
# Unit test for function load
def test_load():
    context = load('.', 'test')
    assert context['cookiecutter']['replay_dir'] == "."
    assert context['cookiecutter']['template'] == "test.json"
    assert context['cookiecutter']['project_name'] == "TestProject"

# Generated at 2022-06-11 20:30:04.914714
# Unit test for function load
def test_load():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    replay_dir = os.path.join(test_dir, '..', '..', 'tests', 'test-replay')
    template_name = 'example-repo'

    result = load(replay_dir, template_name)
    assert result == {
        'cookiecutter': {
            'full_name': 'Your Name',
            'email': 'your@email.com'
        }
    }

# Generated at 2022-06-11 20:30:08.396243
# Unit test for function load
def test_load():
    context = load(replay_dir='/home/yuchen/PycharmProjects/appendix/cookiecutter/tests/test-generate-files/replay', template_name='test-template-264')
    print(context)


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:30:14.266450
# Unit test for function dump
def test_dump():
    replay_dir = './tests/test_replay_dump'
    template_name = 'test'
    context = {'cookiecutter': {'repo_dir': 'https://github.com/audreyr/cookiecutter-pypackage'}}
    result = dump(replay_dir, template_name, context)
    assert isinstance(result, dict)



# Generated at 2022-06-11 20:30:19.605557
# Unit test for function dump
def test_dump():
    cookie_dict = {"cookiecutter":{"project_name":"myproject"}}
    replay_folder = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),'test_replay'
    )
    dump(replay_folder,'test_project',cookie_dict)
    assert os.path.exists(os.path.join(replay_folder,'test_project.json'))
    