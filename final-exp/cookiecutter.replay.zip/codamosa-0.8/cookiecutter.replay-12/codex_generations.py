

# Generated at 2022-06-11 20:22:07.117324
# Unit test for function load
def test_load():
    pass
    # assert(len(load('.', '__init__.py')) == 0)

# Generated at 2022-06-11 20:22:07.756540
# Unit test for function load
def test_load():
	pass

# Generated at 2022-06-11 20:22:15.079529
# Unit test for function dump
def test_dump():
    import shutil, tempfile
    temp_directory = tempfile.mkdtemp()
    context = {'cookiecutter':{'project_name':'test_project','slug':'test-project','repo_name':'test-project','project_short_description':'Yet another cookiecutter test project...'}}
    dump(temp_directory, "test_project", context)

    assert(os.path.isdir(temp_directory))
    assert(os.path.isfile(os.path.join(temp_directory,"test_project.json")))
    file_content = load(temp_directory, "test_project")
    shutil.rmtree(temp_directory)
    assert(context==file_content)

# Generated at 2022-06-11 20:22:16.014102
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-11 20:22:21.704585
# Unit test for function load
def test_load():
    rd = "."
    name = "testload.json"
    json_context = {"cookiecutter": {"a":"1","b":"2"}}
    with open(name, 'w') as infile:
        json.dump(json_context, infile, indent=2)

    c = load(rd, name)
    assert c == json_context
    os.remove(name)

# Generated at 2022-06-11 20:22:25.698764
# Unit test for function load
def test_load():
    testcontext = load('.', 'audit_cookie')
    assert testcontext == {'cookiecutter': {'auditor': 'auditor', 'auditor_company': 'auditor_company', 'case': 'audit_cookie', 'client': 'client', 'client_contact': 'client_contact', 'report_name': 'audit_cookie', 'report_subject': 'audit_cookie'}}


# Generated at 2022-06-11 20:22:30.505340
# Unit test for function load
def test_load():
    import pprint

    replay_dir = 'test_load_replay_dir'
    template_name = 'test_load_template_name'

    context = {'cookiecutter': {'test': 'test'}}

    dump(replay_dir, template_name, context)

    loaded_context = load(replay_dir, template_name)

    pprint.pprint(loaded_context)

    assert context == loaded_context

# Generated at 2022-06-11 20:22:40.199103
# Unit test for function load
def test_load():
    file = os.path.join('tests/files/', 'unit', 'replay.json')
    context = load('tests/files/', file)

    assert context['cookiecutter']['repo_dir'] == '~/.cookiecutters/'
    assert context['cookiecutter']['project_slug'] == 'helloworld'
    assert context['cookiecutter']['full_name'] == 'Test Testerson'
    assert context['cookiecutter']['email'] == 'test@example.com'
    assert context['cookiecutter']['project_name'] == 'helloworld'
    assert context['cookiecutter']['project_short_description'] == 'A short description of the project.'
    assert context['cookiecutter']['open_source_license'] == 'MIT license'
    assert context

# Generated at 2022-06-11 20:22:45.062424
# Unit test for function load
def test_load():
    replay_dir = 'cookiecutter_replay_test_results'
    template_name = 'cookiecutter_template_test_results.json'
    context = {'cookiecutter': {'key': 'value'}}
    dump(replay_dir, template_name, context)
    result = load(replay_dir, template_name)
    assert result == context

# Generated at 2022-06-11 20:22:46.376483
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-11 20:22:50.123445
# Unit test for function load
def test_load():
    replay_dir = 'tests'
    template_name = 'test'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:22:54.508922
# Unit test for function dump
def test_dump():
    print("test function dump()")
    from cookiecutter.replay import dump
    dump("./test_replay", "test_replay", {"cookiecutter": {}})


# Generated at 2022-06-11 20:23:01.029747
# Unit test for function dump
def test_dump():
    # set up temporary directory and file to test dump()
    tempdir = tempfile.gettempdir()
    template_name = 'test'
    replay_dir = os.path.join(tempdir, 'cookiecutter_replay')
    replay_file = os.path.join(replay_dir, template_name)
    context = {'cookiecutter': {
               'full_name': 'Audrey Roy Greenfeld', 'email': 'audreyr@example.com'}
    }

    # verify that file does not yet exist
    assert not os.path.isdir(replay_dir)
    assert not os.path.isfile(replay_file)

    # call dump()

# Generated at 2022-06-11 20:23:08.561014
# Unit test for function load
def test_load():
    """Unit test for function load"""
    # Create files for testing
    replay_dir = 'tests/files/'
    template_name = 'python-package'
    context = {
        'cookiecutter': {
            'project_name': 'Example'
        }
    }
    # Make sure the dir is empty
    open(replay_dir + 'Cookiecutter.json', 'w').close()
    open(replay_dir + 'python-package.json', 'w').close()
    # Dump context to json file
    dump(replay_dir, template_name, context)
    # Load the context back
    loaded_context = load(replay_dir, template_name)
    assert context == loaded_context, "Load function failed"
    # Clean files

# Generated at 2022-06-11 20:23:13.206395
# Unit test for function dump
def test_dump():
    replay_dir = '.'
    template_name = 'simple'
    context = {'cookiecutter': {'replay': '{{cookiecutter.replay}}'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-11 20:23:22.715748
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    template_name = 'foo'


# Generated at 2022-06-11 20:23:29.654311
# Unit test for function load
def test_load():
    json_data = load('/Users/zhengxue/.cookiecutters/', 'cookiecutter-pypackage')

    assert json_data is not None, \
        'Cookiecutter template pypackage is not found.'
    assert 'cookiecutter' in json_data, \
        'Cookiecutter data is absent in template pypackage.'
    assert 'repo_name' in json_data['cookiecutter'], \
        'repo_name is absent in cookiecutter data.'
    assert 'project_name' in json_data['cookiecutter'], \
        'project_name is absent in cookiecutter data.'
    assert 'author_name' in json_data['cookiecutter'], \
        'author_name is absent in cookiecutter data.'



# Generated at 2022-06-11 20:23:32.494351
# Unit test for function load
def test_load():
    context = load('replay', 'cookiecutter.json')
    assert context
    assert 'cookiecutter' in context

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:23:36.102151
# Unit test for function load
def test_load():
    # Test for loading a normal file
    context = load('tests/files/replay', 'example-cookiecutter-repo')

    # Test for loading a .json file
    context = load('tests/files/replay', 'example-cookiecutter-repo.json')

# Generated at 2022-06-11 20:23:37.848656
# Unit test for function load
def test_load():
    return load('tests/files/fake-repo-pre/', 'fake-repo-pre')


# Generated at 2022-06-11 20:23:45.570692
# Unit test for function load
def test_load():
    """Unit test for function load"""
    replay_dir = 'test/testcookiecutter'
    template_name = 'testtemplate'
    context = load(replay_dir, template_name)
    print(context)
    assert context is not None
    assert 'full_name' in context
    assert context['full_name'] is not None
    assert context['full_name'] == 'test'


# Generated at 2022-06-11 20:23:55.435144
# Unit test for function load
def test_load():
    replay_dir = os.path.expanduser('~/.cookiecutters/')
    template_name = 'gh:audreyr/cookiecutter-pypackage'
    result = load(replay_dir, template_name)
    assert result == {
        'cookiecutter': {
            'author_name': 'Audrey Roy',
            'description': 'A Python package project template.',
            'github_username': 'audreyr',
            'license': 'MIT license',
            'open_source_license': 'MIT license',
            'project_name': 'cookiecutter-pypackage',
            'pypi_username': 'audreyr',
            'use_pytest': 'n',
            'version': '0.1.0',
            'year': '2014'
        }
    }


# Generated at 2022-06-11 20:23:57.351498
# Unit test for function load
def test_load():
    d = load('tests', 'unit')
    assert d == {'cookiecutter': {'cookiecutter': {}}}


# Generated at 2022-06-11 20:24:03.514352
# Unit test for function load
def test_load():
    """Test load function."""
    file_name = 'test'
    context = {
        'cookiecutter': 'hello'
    }
    replay_dir = os.path.join(os.path.curdir, '.cookiecutter-test')
    make_sure_path_exists(replay_dir)
    context_loaded = load(replay_dir, file_name)
    assert context == context_loaded

# Generated at 2022-06-11 20:24:08.728889
# Unit test for function load
def test_load():
    template_name = "sample"
    replay_dir = os.path.join(os.getcwd(), '.cookiecutters')

    # read sample context
    sample_context = load(replay_dir, template_name)
    assert isinstance(sample_context, dict)
    assert sample_context != {}
    assert sample_context != None
    assert "cookiecutter" in sample_context

# Generated at 2022-06-11 20:24:10.671316
# Unit test for function load
def test_load():
    assert load("test/test_dir", "template") == {"cookiecutter": "hi im cookiecutter"}

# Generated at 2022-06-11 20:24:15.964813
# Unit test for function load
def test_load():
    template_name = 'cookiecutter-pypackage'
    context = load('/Users/songweizhi/.cookiecutters', template_name)
    print(context)
    for key, value in context.items():
        print('%s\t\t%s' % (key, value))



# Generated at 2022-06-11 20:24:21.847996
# Unit test for function dump
def test_dump():
    # Given:
    replay_dir = '/home/cookiecutter-test/home/'
    template_name = 'test'
    context = {"cookiecutter": {"full_name": "Benny Chan"}}

    # When:
    dump(replay_dir, template_name, context)

    # Then:
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.exists(replay_file)
    with open(replay_file, 'r') as infile:
        json_data = json.load(infile)
    assert context == json_data
    os.remove(replay_file)



# Generated at 2022-06-11 20:24:29.074111
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from . import replay
    from . import tests_dir

    project_dir = 'fake-project'

    utils.rmtree(project_dir)
    replay_dir, replay_file = replay.create_replay_dir(project_dir)

    context = cookiecutter(
        tests_dir, replay_dir=replay_dir, no_input=True
    )

    context_file = replay.get_file_name(replay_dir, tests_dir)

    with open(context_file, 'r') as infile:
        context2 = json.load(infile)

    assert context == context2

# Generated at 2022-06-11 20:24:30.880049
# Unit test for function load
def test_load():
    load('/Users/brianmejia/Desktop/cookiecutter-python-package/cookiecutter-python-package/replay')

# Generated at 2022-06-11 20:24:38.916610
# Unit test for function load
def test_load():
    context = load("E:\programs\pycharm\pycharm_project\cookiecutter-replay-master\cookiecutter-replay-master", "cookiecutter.json")
    print(context)


# Generated at 2022-06-11 20:24:47.330407
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile
    import shutil
    import json

    cwd = os.getcwd()

    replay_dir = tempfile.mkdtemp()
    template_name = 'fake_template'

    try:
        dump(replay_dir, template_name, {'cookiecutter': {'project_name': 'Hello world'}})
    except:
        shutil.rmtree(replay_dir)
        raise

    file_name = os.path.join(replay_dir, '{}.json'.format(template_name))
    assert os.path.exists(file_name)

    with open(file_name, 'r') as infile:
        context = json.load(infile)

    assert 'cookiecutter' in context

# Generated at 2022-06-11 20:24:52.509368
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'full_name': 'TestUser',
                                'project_name': 'testproject',
                                'project_slug': 'testproject'}}
    template_name = 'testtemplate'
    savefile = os.path.join(os.getcwd(), 'test_files', 'testsavefile.json')
    dump(os.path.dirname(savefile), template_name, context)
    assert os.path.isfile(savefile)
    os.remove(savefile)


# Generated at 2022-06-11 20:25:00.909456
# Unit test for function load
def test_load():
    context = load('C:\\Users\\lijunjie\\Desktop\\cookiecutter-master\\cookiecutter-master', 'C:\\Users\\lijunjie\\Desktop\\cookiecutter-master\\cookiecutter-master')
    print(context)
    # Unit test for function dump
    # context = {'cookiecutter': {'replay': 'y'}}
    # dump('C:\\Users\\lijunjie\\Desktop\\cookiecutter-master\\cookiecutter-master', 'C:\\Users\\lijunjie\\Desktop\\cookiecutter-master\\cookiecutter-master', context)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:25:03.199042
# Unit test for function load
def test_load():
    assert load('cookiecutter', 'replay.py') == ''
    assert load('cookiecutter', 'replay1.py') == ''
    assert load('cookiecutter', 'replay2.py') == ''
    assert load('cookiecutter', 'replay3.py') == ''
#test_load()


# Generated at 2022-06-11 20:25:09.225368
# Unit test for function load
def test_load():
    import os
    import tempfile
    import json

    temp_dir = tempfile.mkdtemp()
    print(temp_dir)

    f = open(os.path.join(temp_dir, "test_load.json"), "w")
    f.write("{\"cookiecutter\":{\"name\":\"a\",\"version\":\"1.0\"}}")
    f.close()

    if not isinstance(temp_dir, str):
        raise TypeError('Template name is required to be of type str')

    replay_file = os.path.join(temp_dir, "test_load.json")

    with open(replay_file, 'r') as infile:
        context = json.load(infile)


# Generated at 2022-06-11 20:25:16.934266
# Unit test for function dump
def test_dump():
    import tempfile, shutil
    template_name = 'nm'
    cookiecutter_dict = {'cookiecutter':{'TESTING': 'test-test'}}
    replay_dir = tempfile.mkdtemp()
    dump(replay_dir, template_name, cookiecutter_dict)
    replay_file = os.path.join(replay_dir, template_name + '.json')
    assert os.path.exists(replay_file)
    shutil.rmtree(replay_dir)

# Generated at 2022-06-11 20:25:23.244392
# Unit test for function load
def test_load():
    # Test when context is missing required key
    def replay_dir_missing_key():
        context = {}
        load(replay_dir, 'test_template')

    # Test when template_name is not a str
    def template_name_not_str():
        context = {'cookiecutter':{}}
        load(replay_dir, 0)

    # Test when context is not a dict
    def context_not_dict():
        load(replay_dir, 'test_template')

    replay_dir = 'tests/test-replay'
    assert context_not_dict() == TypeError
    assert template_name_not_str() == TypeError
    assert replay_dir_missing_key() == ValueError

test_load()


# Generated at 2022-06-11 20:25:28.471523
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.getcwd(), 'cookiecutter_replay_test')
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Example'


# Generated at 2022-06-11 20:25:34.164104
# Unit test for function dump
def test_dump():
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    context = {'cookiecutter': {'project_slug': 'test_project_slug'}}
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)

    # Check that file was written
    assert os.path.isfile(replay_file) is True

    # Delete file
    os.remove(replay_file)



# Generated at 2022-06-11 20:25:48.479452
# Unit test for function load
def test_load():
    """ Unit test for function load. """
    template_name = 'python_simple'
    replay_dir = '/Users/duxu/Documents/workspace/python_simple_cookiecutter/'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context

# Generated at 2022-06-11 20:25:49.980283
# Unit test for function load
def test_load():
    print(load('./replay', 'replay.json'))


# Generated at 2022-06-11 20:25:55.921814
# Unit test for function load
def test_load():
    try:
        # load the context from file
        context = load('replay', 'ci')
    except:
        # load was unsuccessful
        assert False
    else:
        # context is loaded
        assert True
        # context is a dictionary
        assert type(context) is dict
        # context has non-zero length
        assert len(context) is not 0
        # context has key 'cookiecutter'
        assert 'cookiecutter' in context.keys()


# Generated at 2022-06-11 20:26:00.220415
# Unit test for function load
def test_load():
    """
    Test whether function load works as expected.

    The function is supposed to generate a context with a cookiecutter key
    which contains the json representation of a cookiecutter generated project.
    """
    replay_dir = 'test/replay'
    template_name = 'test.json'

    context = load(replay_dir, template_name)

    assert 'cookiecutter' in context

# Generated at 2022-06-11 20:26:03.540398
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-load-replay/'
    template_name = 'test-load'
    context = {'cookiecutter': 'load'}
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert(context['cookiecutter'] == 'load')

# Generated at 2022-06-11 20:26:06.994195
# Unit test for function load
def test_load():
    context = load("C:/Users/user/AppData/Local/pip/Cache/wheels/47/3a/63/5a5a5b5d6dde6a4f624e7f4e4eccfc8f3144e5a5ed98a97d86", "test")
    assert context["cookiecutter"]["project_slug"]=="test"

# Generated at 2022-06-11 20:26:12.670068
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tests/fake-repo-pre/')
    replay_file = 'fake-repo'
    json_file = load(replay_dir, replay_file)
    assert len(json_file.keys()) > 0

# Generated at 2022-06-11 20:26:23.286650
# Unit test for function load
def test_load():
    # generate dummy file
    replay_dir = os.path.join(os.getcwd(), 'tests', 'test-output')
    with open(os.path.join(replay_dir, 'cookiecutter.json'), 'w') as outfile:
        json.dump({'cookiecutter': {'full_name': 'Test Name'}}, outfile, indent=2)

    # load json file
    context = load(replay_dir, 'cookiecutter')

    # test variables
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert context['cookiecutter']['full_name'] == 'Test Name'

    # delete dummy file
    os.remove(os.path.join(replay_dir, 'cookiecutter.json'))

# Unit test

# Generated at 2022-06-11 20:26:33.235706
# Unit test for function load
def test_load():
    """Test loading replay data."""
    replay_dir = 'tests/test-load-replay/'
    template_name = 'test-replay'

    template_dir = os.path.dirname(__file__)
    template_dir = os.path.join(template_dir, replay_dir)
    replay_dict = load(template_dir, template_name)
    # Test that the loaded json is equal to the written json

# Generated at 2022-06-11 20:26:34.700969
# Unit test for function load
def test_load():
    load('c:\cookiecutter\replay', 'replay')

# Generated at 2022-06-11 20:27:00.501632
# Unit test for function load
def test_load():
    #test file location
    test_file = 'tests/test_load.json'
    if not os.path.isfile(test_file):
        raise IOError('Unable to find test_load.json')
    # load requires a directory name and template name
    # we don't care about the directory name, so just put in the file
    # name for the template name
    context = load(test_file, 'tests/test_load.json')
    # test our assumption that 'cookiecutter' exists in the loaded context
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:27:08.366678
# Unit test for function load
def test_load():
    # The test_load function is used to test the load()
    # function from the replay.py file.
    #
    # Variables:
    #  - replay_dir
    #  - template_name
    #  - context (expected output)

    # Set the directory for the replay file
    replay_dir = 'tests/test-api-example/'

    # Set the name of the mock template
    template_name = 'mock_template'

    # Set the expected output of the load() function

# Generated at 2022-06-11 20:27:17.147613
# Unit test for function load
def test_load():
    replay_dir = 'test_replay_dir'
    template_name = 'test_template'
    context = {'cookiecutter': {'first_name': 'Audrey', 'last_name': 'Roy'}}
    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)
    assert context == context_loaded
    os.remove(get_file_name(replay_dir, template_name))
    os.rmdir(replay_dir)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:27:26.731474
# Unit test for function load
def test_load():
	"""Unit test for testing function load
	
	Args:
		None
	Returns:
		None
	"""
	# Test that function load works when there is the correct context.
	context = load("C:/Users/Jing/Projects/AutoSOLVER", "icy_bunny_template")
	assert "cookiecutter" in context
	# Test that function load works when there is no context.
	try:
		context = load("C:/Users/Jing/Projects/AutoSOLVER", "python-package-quickstart")
		assert False
	except ValueError:
		assert True
		

# Generated at 2022-06-11 20:27:31.258437
# Unit test for function dump
def test_dump():
    print('Testing function dump')
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    context = {'cookiecutter': {'test_key': 'test_value'}}

    try:
        dump(replay_dir, template_name, context)
    except Exception as e:
        print('Exception caught {}'.format(e))
    finally:
        os.remove(os.path.join(replay_dir, template_name + '.json'))
        os.rmdir(replay_dir)


# Generated at 2022-06-11 20:27:36.577521
# Unit test for function load
def test_load():
    reload(cc_replay)
    replay_dir = os.path.join('tests', 'files', 'fake-replay')
    context = cc_replay.load(replay_dir, 'skeleton')
    assert isinstance(context, dict)


# Generated at 2022-06-11 20:27:41.117486
# Unit test for function load
def test_load():
    replay_dir = "C:/Users/Kun/Desktop/Project/Cookiecutter-master/cookiecutter-pypackage-master"
    template_name = "cookiecutter-pypackage-master"
    context = load(replay_dir, template_name)
    print(context)

# Generated at 2022-06-11 20:27:45.975478
# Unit test for function dump
def test_dump():
    replay_dir = 'testing_replay_dir'
    template_name = 'testing_template'
    context = {"cookiecutter": {"hello": "world"}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, template_name + '.json'))


# Generated at 2022-06-11 20:27:46.576593
# Unit test for function dump
def test_dump():
    pass

# Generated at 2022-06-11 20:27:52.594488
# Unit test for function load
def test_load():
    assert load(r'C:\Users\zhaorui\Documents\GitHub\Cookiecutter\cookiecutter\tests', 'full_replay.json') == {
    "cookiecutter": {
        "author_email": "fake@email.com",
        "author_name": "Your name",
        "project_name": "Project",
        "repo_name": "repo",
        "select_license": "MIT",
        "use_pytest": "y"
    }
}

# Generated at 2022-06-11 20:28:37.257583
# Unit test for function dump
def test_dump():
    """."""
    from cookiecutter import utils

    
    dir_path = os.path.dirname(os.path.realpath(__file__))
    cur_dir = os.getcwd()
    replay_dir = os.path.join(dir_path, 'replay')
    template_name = 'test'

    # Generate three contexts
    repo_dir = os.path.join(dir_path, 'fake-repo')
    context = utils.make_context(template_dir=repo_dir, default_context={})
    dump(replay_dir, template_name, context)

    context = utils.make_context(repo_dir=repo_dir, default_context={})
    dump(replay_dir, template_name, context)

    context = utils.make_

# Generated at 2022-06-11 20:28:44.076348
# Unit test for function dump
def test_dump():
    replay_dir = "../../tests/test-output"
    template_name = "cookiecutter-pypackage"

    context = {'cookiecutter': {}}
    context['cookiecutter']['author_name'] = 'Test Author'

    dump(replay_dir, template_name, context)

    file_name = get_file_name(replay_dir, template_name)

    if not os.path.exists(file_name):
        assert True == False

    with open(file_name, 'r') as infile:
        test_context = json.load(infile)

    assert context == test_context



# Generated at 2022-06-11 20:28:47.104657
# Unit test for function load
def test_load():
	replay_dir = '../../tests/test-output'
	template_name = 'simple-2'
	print(load(replay_dir, template_name))


# Generated at 2022-06-11 20:28:53.923204
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(__file__), '.tests', 'replay')
    template_name = 'tests'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr'
        }
    }

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    result = load(replay_dir, template_name)

    assert result == context

# Generated at 2022-06-11 20:28:57.938806
# Unit test for function load
def test_load():
    template_name = 'python_package'
    replay_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        '..',
        '..',
        'tests',
        'test-output',
        'cookiecutter'
    )
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)

# Generated at 2022-06-11 20:29:04.762717
# Unit test for function load
def test_load():
    """Unit test for function load"""
    from os.path import abspath, dirname, join
    from template_benchmark import config

    replay_dir = join(dirname(abspath(__file__)), config.REPLAY_DIR)
    template_name = 'pypackage'
    # print(type(load(replay_dir, template_name)))
    # print(load(replay_dir, template_name))
    assert load(replay_dir, template_name)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:29:07.246554
# Unit test for function load
def test_load():
    context = load('../', 'my-first-open-source-project')
    print(context)


# Generated at 2022-06-11 20:29:13.062561
# Unit test for function dump
def test_dump():
    template_name = 'test_template'
    context = {'cookiecutter': {'test_key': 'test_value'}}

    replay_dir = get_file_name(os.path.join(os.path.dirname(__file__), '..', '..', 'tmp'), template_name)
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:29:15.327894
# Unit test for function load
def test_load():
    context = load('replay', 'dh-cookiecutter-python')
    # print(context)
    assert context['project_name'] == 'Django + Channels'

#test_load()

# Generated at 2022-06-11 20:29:17.321532
# Unit test for function load
def test_load():
    assert load('.', 'test') == {'cookiecutter': {'project_name': "Unit test for function load"}}
