

# Generated at 2022-06-11 20:22:10.300057
# Unit test for function dump
def test_dump():

    replay_dir = '../test_output/test_replays'
    template_name = 'test_template'
    context = {'cookiecutter': {'key_one': 'value_one',
                                'key_two': 'value_two'}}
    dump(replay_dir, template_name, context)

    # Ensure dumped file has the desired content
    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        dumped_data = infil

# Generated at 2022-06-11 20:22:14.762940
# Unit test for function dump
def test_dump():
	import os 
	if os.path.exists('./replay/my_replay_file'):
		d = load('./replay/my_replay_file')

# Generated at 2022-06-11 20:22:16.713600
# Unit test for function load
def test_load():
    filename = 'replay.json'
    test_dir = 'tests'

# Generated at 2022-06-11 20:22:22.473399
# Unit test for function get_file_name
def test_get_file_name():
    template_name = "test"
    replay_dir = "."
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == "./test.json"
    template_name = "test.json"
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == "./test.json"


# Generated at 2022-06-11 20:22:28.890927
# Unit test for function dump
def test_dump():
    def test_context_type():
        replay_dir = 'tests/test-replay'
        template_name = 'test-template-name'
        context = 'foo'

        try:
            dump(replay_dir, template_name, context)
        except TypeError as e:
            assert e.args[0] == 'Context is required to be of type dict'

    def test_cookiecutter_key_missing():
        replay_dir = 'tests/test-replay'
        template_name = 'test-template-name'
        context = {}

        try:
            dump(replay_dir, template_name, context)
        except ValueError as e:
            assert e.args[0] == 'Context is required to contain a cookiecutter key'


# Generated at 2022-06-11 20:22:34.168622
# Unit test for function get_file_name
def test_get_file_name():
    """test function get_file_name."""
    # Definir le nom du fichier à créer.
    file_name = get_file_name("/tmp/replay_dir/", "first-file")

    # Vérifier que le fichier créé est nommé "first-file.json".
    assert file_name == "/tmp/replay_dir/first-file.json"

# Generated at 2022-06-11 20:22:41.743005
# Unit test for function load
def test_load(): # noqa
    if not os.path.isdir("tests/test-load/"):
        os.mkdir("tests/test-load")
    with open("tests/test-load/replay.json", "w") as f:
        f.write("""{
    "cookiecutter": {
        "full_name": "First Last",
        "email": "user@example.com",
        "github_username": "user",
        "project_name": "My Project",
        "project_slug": "my_project",
        "project_short_description": "A short description",
        "pypi_username": "user",
        "version": "0.1.0",
        "release": "8",
        "_template": "my_template"
    }
}\n""")


# Generated at 2022-06-11 20:22:45.025683
# Unit test for function dump
def test_dump():
    from cookiecutter.main import cookiecutter
    context = cookiecutter('.', no_input=True, replay=True)
    dump('.', 'my_template', context)

if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-11 20:22:50.310516
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.getcwd()
    template_name = 'example-template'

    try:
        result = get_file_name(replay_dir, template_name)
        assert result == os.path.join(replay_dir, template_name+'.json')
    except AssertionError as e:
        print("Unit test for getting file name failed")



# Generated at 2022-06-11 20:22:55.007533
# Unit test for function load
def test_load():
    """Load replay file."""
    template_name = 'cookiecutter-pypackage'
    context = load('.', template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:23:01.953017
# Unit test for function load
def test_load():
    replay_dir = 'cookiecutter_replay'
    template_name = 'my_template'
    context = {'cookiecutter': {'foo': 'bar', 'baz': 10}}
    dump(replay_dir, template_name, context)
    list_context = load(replay_dir, template_name)
    assert context == list_context



# Generated at 2022-06-11 20:23:07.477689
# Unit test for function load
def test_load():
    import tempfile
    import shutil
    replay_dir = tempfile.mkdtemp()
    try:
        outfile = get_file_name(replay_dir, template_name='foo_bar')
        with open(outfile, 'w') as out:
            out.write('{"cookiecutter":{"foo":"bar"}}')
        ctx = load(replay_dir, template_name='foo_bar')
        assert ctx == {'foo': 'bar'}
    finally:
        shutil.rmtree(replay_dir)

# Generated at 2022-06-11 20:23:17.431217
# Unit test for function load
def test_load():
    template_name = 'cookiecutter-pypackage'
    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests', 'replays')
    result = load(replay_dir, template_name)
    assert result == {'cookiecutter': {'full_name': 'Audrey Roy Greenfeld', 'email': 'audreyr@example.com', 'github_username': 'audreyr', 'description': 'A Python package project template.', 'project_name': 'cookiecutter-pypackage', 'use_pytest': 'y', 'open_source_license': 'MIT license', 'command_line_interface': 'Click', 'version': '0.1.0', 'year': '2016', 'project_slug': 'cookiecutter-pypackage'}}


# Generated at 2022-06-11 20:23:24.675917
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    context = {
        'cookiecutter': {
            'a_number': 123,
        }
    }
    dump(replay_dir, template_name, context)

    assert os.path.isfile('tests/test-replay/tests_fake-repo-pre.json')
    with open('tests/test-replay/tests_fake-repo-pre.json') as f:
        result = json.load(f)
    assert result == context



# Generated at 2022-06-11 20:23:29.548742
# Unit test for function load
def test_load():
    context1 = load('tests/replay/legacy', 'fake-project')
    assert 'cookiecutter' in context1
    assert context1['project_name'] == 'Fake Project'

    context2 = load('tests/replay/legacy', 'fake-project.json')
    assert 'cookiecutter' in context2
    assert context2['project_name'] == 'Fake Project'

    with open('tests/replay/legacy/fake-project.json', 'r') as infile:
        context3 = json.load(infile)

    assert context1 == context2
    assert context1 == context3



# Generated at 2022-06-11 20:23:32.930370
# Unit test for function load
def test_load():
    with open('tests/test_file.json', 'r') as infile:
        context = json.load(infile)

        if 'cookiecutter' not in context:
            raise ValueError('Context is required to contain a cookiecutter key')

        return context

# Generated at 2022-06-11 20:23:40.662179
# Unit test for function load
def test_load():
    pre_context = {
        'cookiecutter': {
            '_template': '.',
            'full_name': 'Full Name',
            'email': 'email@email.com',
            'github_username': 'gh_username',
            'project_name': 'project_name',
            'project_short_description': 'project_short_description',
            'pypi_username': 'pypi_username'
        }
    }
    template_name = '.'
    try:
        os.mkdir('tests/files/replay_dir')
    except OSError:
        pass
    dump('tests/files/replay_dir', template_name, pre_context)
    context = load('tests/files/replay_dir', template_name)
    assert pre_context == context

# Generated at 2022-06-11 20:23:43.048858
# Unit test for function load
def test_load():
    context = load("./test_files/","test_file")
    assert(context['cookiecutter']['test_replay_load'] == 'test_replay_load_value')


# Generated at 2022-06-11 20:23:49.754377
# Unit test for function load
def test_load():
    name = 'test_dir'
    replay_dir = os.path.join(os.path.dirname(__file__), name)
    template_name = 'test_template'
    replay_file = get_file_name(replay_dir, template_name)
    import pdb; pdb.set_trace() ## DEBUG ##
    context = load(replay_dir, template_name)
    print(replay_dir)
    print('test_load_context', context)


# Generated at 2022-06-11 20:23:56.168370
# Unit test for function load
def test_load():
    _load = load(replay_dir='test_data', template_name='test_cookiecutter')
    if not isinstance(_load, dict):
        raise TypeError('Context is required to be of type dict')
    if 'cookiecutter' not in _load:
        raise ValueError('Context is required to contain a cookiecutter key')
    return _load

if __name__ == '__main__':
    _load = test_load()
    print(_load)

# Generated at 2022-06-11 20:24:08.159044
# Unit test for function dump
def test_dump():
    """Test function dump."""
    template_name = 'template_name'
    context = {
        'cookiecutter': {
            'full_name': 'Your Name',
            'email': 'Your email'
        }
    }

    replay_dir = 'tests/files/replay'
    # Create replay directory
    if not os.path.exists(replay_dir):
        os.makedirs(replay_dir)

    if not isinstance(context, dict):
        raise TypeError('Context is required to be of type dict')

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

    replay_file = get_file_name(replay_dir, template_name)


# Generated at 2022-06-11 20:24:11.713966
# Unit test for function load
def test_load():
    context = load('./test/test_replay_files', 'test_load')
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')


# Generated at 2022-06-11 20:24:18.232907
# Unit test for function dump
def test_dump():
    """Test for function dump."""
    replay_dir = '/tmp/cookiecutter_tests'
    template_name = 'test1'
    context = {'cookiecutter': {'key1': 'value1'}}
    dump(replay_dir, template_name, context)
    expected_file = '/tmp/cookiecutter_tests/test1.json'
    assert os.path.isfile(expected_file)


# Generated at 2022-06-11 20:24:23.401701
# Unit test for function load
def test_load():
    cwd = os.getcwd()
    template_name = 'quickstart'
    replay_dir = os.path.join(cwd, "replay")
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'Cookiecutter-PyPackage',
            'project_slogan': '"A great open source Python package."',
            'pypi_username': '',
            'domain_name': 'example.com',
            'version': '0.1.0',
            'open_source_license': 'MIT license',
        }
    }
    dump(replay_dir, template_name, context)
    loaded

# Generated at 2022-06-11 20:24:27.877467
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    from cookiecutter import config
    cookiecutter('/home/zyh/Project/zyh-web/zyh-cookiecutter-tpl/demo')
    #config.CONFIG_FILE.write(cookiecutter('/home/zyh/Project/zyh-web/zyh-cookiecutter-tpl/demo'))

test_load()

# Generated at 2022-06-11 20:24:38.530206
# Unit test for function load
def test_load():
    """Tests loading context from replay."""
    from tests.sample_project.unittests.test_cookiecutter_replay_utils \
        import replay_dir, template_name

    context = load(replay_dir, template_name)

    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context['cookiecutter']['project_name'] == 'Sample Project'
    assert context['cookiecutter']['repo_name'] == 'sample_project'
    assert context['cookiecutter']['project_slug'] == 'sample-project'

# Generated at 2022-06-11 20:24:42.190785
# Unit test for function dump
def test_dump():
    replay_file = "test.json"
    replay_dir = '.'
    template_name = "test"
    context = {"cookiecutter": {"cookiecutter_template": "test"}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile(replay_file)



# Generated at 2022-06-11 20:24:46.566752
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load("../", "python-package")
    assert "cookiecutter" in context
    assert context["cookiecutter"]["full_name"] == "Some Person"
    assert context["cookiecutter"]["email"] == "some@person.com"


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:24:49.855984
# Unit test for function dump
def test_dump():
    replay_dir = '~/.cookiecutters/'
    template = '{{cookiecutter.foo}}/{{cookiecutter.bar}}'
    context = {'cookiecutter': {'foo': 'bar', 'bar': 'foo'}}
    dump(replay_dir, template, context)


# Generated at 2022-06-11 20:24:58.977714
# Unit test for function dump
def test_dump():
    if not make_sure_path_exists('tests/files/dump'):
        raise IOError('Unable to create dump dir at tests/files/dump')
    
    context = {
        "cookiecutter": {
            "project_name": "test_dump",
            "name" : "Paul",
        }
    }

    dump('tests/files/dump', 'testme', context)

    replay_file = get_file_name('tests/files/dump', 'testme')

    with open(replay_file, 'r') as infile:
        actual = json.load(infile)

    assert 'cookiecutter' in actual
    assert actual['cookiecutter']['project_name'] == 'test_dump'
    assert actual['cookiecutter']['name'] == 'Paul'

# Unit test

# Generated at 2022-06-11 20:25:04.982995
# Unit test for function load
def test_load():
    """Test function load."""
    # Test error when template_name is not of type str.
    try:
        replay_dir='/tmp'
        load(replay_dir, 123)
    except TypeError as e:
        assert str(e) == 'Template name is required to be of type str'
    except Exception as e:
        raise e
    else:
        assert False, 'TypeError not raised'

    # Test error when context does not contain a 'cookiecutter' key.
    try:
        template_name='foo'
        load(replay_dir, template_name)
    except ValueError as e:
        assert str(e) == 'Context is required to contain a cookiecutter key'
    except Exception as e:
        raise e
    else:
        assert False, 'ValueError not raised'

    #

# Generated at 2022-06-11 20:25:14.891260
# Unit test for function load
def test_load():
    import os
    import shutil

    test_dir = os.path.normpath(
        os.path.join(os.path.dirname(__file__), '../tests/files')
    )
    template = 'fake-repo-tmpl'
    replay_dir = os.path.join(test_dir, '{{cookiecutter.repo_name}}')
    cookiecutter_json = os.path.join(test_dir, template, 'cookiecutter.json')

    shutil.copyfile(cookiecutter_json, os.path.join(test_dir, 'test.json'))
    context = load(test_dir, 'test')
    assert 'cookiecutter' in context

    if os.path.isfile('test.json'):
        os.remove('test.json')

# Generated at 2022-06-11 20:25:21.178489
# Unit test for function load
def test_load():
    """Function to test function load."""
    print ('Testing function load')
    assert isinstance(load("/home/travis/build/pytest-dev/pytest", "file"), dict)
    test_context = {"cookiecutter": "test"}
    assert load("/home/travis/build/pytest-dev/pytest", "test.json") == test_context
    assert load("/home/travis/build/pytest-dev/pytest", "test") == test_context
    print('Successfully tested function load')


# Generated at 2022-06-11 20:25:32.021171
# Unit test for function load
def test_load():
    import os
    import shutil
    from cookiecutter.utils import rmtree
    from cookiecutter import repository
    
    # Create a temporary user's home directory for testing
    tmp_d = os.path.join(os.path.expanduser("~"), '.cookiecutters')
    test_dir = 'tests/test-load/'
    if os.path.isdir(tmp_d):
        rmtree(tmp_d)
    shutil.copytree(test_dir, tmp_d)
    
    d = repository.determine_replay_dir(tmp_d)
    context = load(d, 'tests/test-replay/')
    assert set(context['cookiecutter'].keys()) == set(['cookiecutter.json', 'extra_context.json'])

# Generated at 2022-06-11 20:25:37.967108
# Unit test for function load
def test_load():
    # Load dumps
    #load('/Users/yuxiandong/Github/cookiecutter-flask/tests/fake-repo-pre/', 'fake_template_bakeoff')
    # Load dumps
    load('/Users/yuxiandong/Github/cookiecutter-flask/tests/fake-repo-pre/', 'fake_template_bakeoff')
    # Load successfully
    load('/Users/yuxiandong/Github/cookiecutter-flask/tests/fake-repo-pre/', 'fake-repo-pre')
    # Load exception
    load('/Users/yuxiandong/Github/cookiecutter-flask/tests/fake-repo-pre/', 'fake_template_bakeof')

# Generated at 2022-06-11 20:25:48.517406
# Unit test for function dump
def test_dump():
    template_name = 'test_template'
    test_context = {'cookiecutter': {'name': 'test_name'}}
    test_replay_dir = 'test_replay_dir'

    # Validate replay file is written with correct content
    dump(test_replay_dir, template_name, test_context)
    replay_file = get_file_name(test_replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        assert(test_context == json.load(infile))

    # Validate error when replay dir cannot be created
    try:
        # Check error when replay dir cannot be created
        dump('/bad/path', template_name, test_context)
        assert(False)
    except IOError:
        assert(True)

   

# Generated at 2022-06-11 20:25:57.847886
# Unit test for function load
def test_load():
    print('Loading JSON ...')
    assert (load('./cookiecutter.json') == {
        "project_name": "My Project",
        "project_slug": "my_project",
        "author_name": "Your Name Here",
        "email": "",
        "description": "A short description of the project.",
        "domain_name": "example.com",
        "version": "0.1.0",
        "timezone": "UTC",
        "use_pycharm": false,
        "use_pypi_deployment_with_travis": false,
        "use_docker": false,
        "open_source_license": "MIT"
    })

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:26:00.370806
# Unit test for function load
def test_load():
    context = load('/home/xz/yunfeng/.cookiecutters/hongqiang/', 'default')
    print(context)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:26:01.432262
# Unit test for function load
def test_load():
    load("~/.cookiecutters", "foobar")

# Generated at 2022-06-11 20:26:06.456158
# Unit test for function load
def test_load():
    c1 = load("C:/Users/Yannick/Desktop/Cookiecutter-master/cookiecutter/tests/test-replay", "python_module")
    c2 = load("C:/Users/Yannick/Desktop/Cookiecutter-master/cookiecutter/tests/test-replay", "python_module")
    assert c1==c2


# Generated at 2022-06-11 20:26:14.453427
# Unit test for function dump
def test_dump():
    name = 'test_template_name'
    replay_dir = 'tests/test-replay/'
    if os.path.isfile(replay_dir):
        os.remove(replay_dir)
    context = {'cookiecutter': {'name': 'test_name', 'full_name': 'test_full_name'}}
    dump(replay_dir, name, context)
    assert os.path.isfile(replay_dir)



# Generated at 2022-06-11 20:26:19.066841
# Unit test for function load
def test_load():
    replay_dir = "C:/users/sheri/Desktop/data-cookie"
    template_name = "data-cookie"
    context = load(replay_dir, template_name)
    assert isinstance(context, dict) == True
    assert "cookiecutter" in context
    
    
    

# Generated at 2022-06-11 20:26:22.181561
# Unit test for function load
def test_load():
    """Unit test for function load."""
    assert isinstance(load(replay_dir='c:\\', template_name='cookiecutter-django'), dict)


# Generated at 2022-06-11 20:26:24.977971
# Unit test for function load
def test_load():
    from cookiecutter.tests import fixture_file
    replay_dir = fixture_file('replay')
    template_name = 'jquery'
    context = load(replay_dir, template_name)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

# Generated at 2022-06-11 20:26:34.112448
# Unit test for function dump
def test_dump():
    replay_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'data', 'replay'))
    template_name = 'foobar'
    context = {'cookiecutter': {'name': 'audreyr'}}

    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context

    context = {'cookiecutter': {'name': 'randomuser'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context

# Generated at 2022-06-11 20:26:35.482864
# Unit test for function load
def test_load():
    context = load('./', 'controller')
    print(context)
    

# Generated at 2022-06-11 20:26:38.087512
# Unit test for function load
def test_load():
    """Test for function load."""
    assert load('tests/test-output/cookiecutter-replay/', 'test-template')

# Generated at 2022-06-11 20:26:45.588565
# Unit test for function load
def test_load():
    #data = load('C:\\Users\\user\\Desktop\\project\\cookiecutter','template')
    data = load('C:\\Users\\user\\Desktop\\project\\cookiecutter','cookiecutter')
    # test if the cookiecutter key exists in the context
    assert 'cookiecutter' in data
    # test if the required keys exists in the context
    assert 'full_name' in data['cookiecutter']
    assert 'email' in data['cookiecutter']
    assert 'project_name' in data['cookiecutter']
    assert 'project_slug' in data['cookiecutter']
    assert 'project_short_description' in data['cookiecutter']
    assert 'release_date' in data['cookiecutter']
    assert 'version' in data['cookiecutter']
    
    print(data)

test

# Generated at 2022-06-11 20:26:48.303638
# Unit test for function load
def test_load():
    replay_dir = "/Users/allen/Projects/Apps/cookiecutter"
    template_name = "my_cookie"
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:26:58.416859
# Unit test for function dump
def test_dump():
    # Assume replay_dir=False to make test run.
    # It should not create file in another dir.
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    context = {'cookiecutter': 'test_cookiecutter'}
    file_name = 'test_replay_dir/test_template_name.json'

    try:
        dump(replay_dir, template_name, context)

        # Test 1:
        with open(file_name, 'r') as infile:
            file_data = json.load(infile)
            assert file_data == {"cookiecutter": "test_cookiecutter"}
    finally:
        os.remove(file_name)


# Generated at 2022-06-11 20:27:06.615956
# Unit test for function load
def test_load():
    print("Testing load function")
    print(load('replay', '~/cookiecutter-pypackage'))


# Generated at 2022-06-11 20:27:11.995915
# Unit test for function load
def test_load():
    replay_dir = "./tests/files/replay_dir"
    template_name = "replay_fixture"

    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter PyPackage'

# Generated at 2022-06-11 20:27:18.721665
# Unit test for function load
def test_load():
    # Test directory
    test_dir = os.path.join(os.path.dirname(__file__), "test_repo")
    test_context = os.path.join(test_dir, "cookiecutter.json")
    
    # Set the template name
    template_name = "test_repo"

    # Test load function
    context = load(test_dir, template_name)

    # Read the file
    with open(test_context) as file_handle:
        data = json.load(file_handle)

    # Compare json
    assert data == context

# Test function dump

# Generated at 2022-06-11 20:27:25.031032
# Unit test for function load
def test_load():
    # Set values to the directory and name of the json file
    replay_dir = 'C:\\Users\\Xavier\\Desktop\\Lawrence\\EECE5640\\Project\\cookiecutter-pypackage\\replay'
    template_name = "test"
    context  = load(replay_dir, template_name)
    print(context)

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-11 20:27:28.801150
# Unit test for function load
def test_load():
    dirname = os.path.dirname(__file__)
    context = load(dirname, 'default')
    assert(type(context) is dict)
    assert('cookiecutter' in context)
    assert(type(context['cookiecutter']) is dict)
    assert('full_name' in context['cookiecutter'])


# Generated at 2022-06-11 20:27:36.942118
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'replay_dir')
    template_name = 'test'
    context = {'cookiecutter': {'test': 'test_value'}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name)) == True
    assert os.path.isdir(replay_dir) == True


# Generated at 2022-06-11 20:27:47.051672
# Unit test for function load

# Generated at 2022-06-11 20:27:52.399150
# Unit test for function load
def test_load():
    actual = load('../tests/test-replay', 'test')
    expected = {
        "cookiecutter": {
            "full_name": "Audrey Roy",
            "email": "audreyr@example.com",
            "github_username": "audreyr",
            "project_slug": "cookiecutter-pypackage-minimal"
        }
    }
    assert actual == expected



# Generated at 2022-06-11 20:27:59.540139
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.dirname(__file__), "fixtures")
    template_name = 'example_replay'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    
    # Test with wrong name
    try:
        context = load(replay_dir, 'wrong_template_name')
        assert False
    except:
        assert True
        
    # Test with wrong type of name
    try:
        context = load(replay_dir, 1)
        assert False
    except:
        assert True


# Generated at 2022-06-11 20:28:02.294432
# Unit test for function load
def test_load():
    context = load('docs/examples/simple', '{{cookiecutter.repo_name}}')
    print(context)
    return context



# Generated at 2022-06-11 20:28:13.865989
# Unit test for function dump
def test_dump():
    assert 'cookiecutter' in context

## Unit test for function load

# Generated at 2022-06-11 20:28:14.873217
# Unit test for function load
def test_load():
    return load('test', 'replay-test.json')


# Generated at 2022-06-11 20:28:19.599514
# Unit test for function load
def test_load():
    template_name = '../test/test_project/test.json'
    context = {'cookiecutter': {'test_test': 'test'}}
    replay_dir = '../test/test_project/replay'
    test_replay = load(replay_dir, template_name)
    assert context == test_replay

# Generated at 2022-06-11 20:28:22.066546
# Unit test for function load
def test_load():
    replay_dir = "./tests/test-replay"
    template_name = "cookiecutter-pypackage"
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter PyPackage'

# Generated at 2022-06-11 20:28:25.112553
# Unit test for function load
def test_load():
    assert load('/Users/YinanZheng/Documents/Homework/6306/project/cookiecutter-pypackage', 'cookiecutter.json')['cookiecutter']['package_name'] == '{{ cookiecutter.repo_name }}'

# Generated at 2022-06-11 20:28:27.250983
# Unit test for function load
def test_load():
    assert isinstance(load(), dict)

# Generated at 2022-06-11 20:28:30.175865
# Unit test for function load
def test_load():
    assert load("/home/yangzheng/文档/code/Python/cookiecutter-webapp", "cookiecutter-webapp")["cookiecutter"]["project_name"] == "Cookiecutter Web App"
    

# Generated at 2022-06-11 20:28:37.555714
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = '/tmp/cookiecutter-replay'
    template_name = 'test-template'
    context = {
        'cookiecutter': {
            'full_name': 'Test User',
            'email': 'test@example.com',
            'project_name': 'test_project',
            'repo_name': 'test_repo',
            'project_name': 'test-project',
        }
    }
    dump(replay_dir, template_name, context)

    got_context = load(replay_dir, template_name)
    assert context == got_context
    os.remove(get_file_name(replay_dir, template_name))



# Generated at 2022-06-11 20:28:42.147075
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-dump/replay'
    template_name = '{{cookiecutter.project_name}}'
    context = {'cookiecutter': {'project_name': 'Test'}}
    dump(replay_dir, template_name, context)
    load(replay_dir, template_name)


# Generated at 2022-06-11 20:28:51.800556
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = "cookiecutter_ev3dev"
    context = load("/home/robot/.cookiecutter/replay","2018-12-24-134513_ev3dev-python-template_dpp8np")
    assert "cookiecutter" in context
    assert context.get("cookiecutter").get("full_name") == "David P"
    assert context.get("cookiecutter").get("email") == "davidp@student.wethinkcode.co.za"
    assert context.get("cookiecutter").get("year") == "2018"
    assert context.get("cookiecutter").get("project_slug") == "jwinto_ev3dev_python_examples"


# Generated at 2022-06-11 20:29:04.887717
# Unit test for function load
def test_load():
    context = load('tests/test-replay', 'tests/fake-repo-tmpl')
    assert len(context['cookiecutter']['repo_dir']) is not 0


# Generated at 2022-06-11 20:29:13.264600
# Unit test for function load
def test_load():
    '''
    This function tests if load function works properly.
    It tests if the function throws an exception if
    the file is not in Json format.
    '''
    replay_dir = "../cookiecutter/tests/test-load"
    template_name = "testload.json"
    context = {}

    try:
        context = load(replay_dir, template_name)
    except Exception as e:
        context['result'] = "success"

    assert context['result'] == "success"


# Generated at 2022-06-11 20:29:16.145894
# Unit test for function load
def test_load():
    replay_dir = ''
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    print(context)



# Generated at 2022-06-11 20:29:25.987256
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-tmpl/'

    context = load(replay_dir, template_name)

    assert context['cookiecutter']['full_name'] == '{{cookiecutter.full_name}}'
    assert context['cookiecutter']['email'] == '{{cookiecutter.email}}'
    assert context['cookiecutter']['project_name'] == '{{cookiecutter.project_name}}'
    assert context['cookiecutter']['project_short_description'] == '{{cookiecutter.project_short_description}}'
    assert context['cookiecutter']['version'] == '{{cookiecutter.version}}'

# Generated at 2022-06-11 20:29:33.306722
# Unit test for function load

# Generated at 2022-06-11 20:29:42.736344
# Unit test for function load
def test_load():
    from cookiecutter import main
    import shutil

    project_dir = os.path.dirname(os.path.abspath(__file__))
    test_dir = os.path.join(project_dir, 'test_files')
    template_dir = os.path.join(test_dir, 'fake-repo-tmpl')
    replay_dir = os.path.join(test_dir, 'replay')
    output_dir = os.path.join(test_dir, 'test_output')
    if os.path.isdir(output_dir):
        shutil.rmtree(output_dir)
    os.mkdir(output_dir)

    main.cookiecutter(template_dir, replay_dir=replay_dir, no_input=True)

# Generated at 2022-06-11 20:29:48.054560
# Unit test for function load
def test_load():
    try:
        context1 = load('tests/test-replay', 'tests/fake-repo-tmpl')
    except ValueError as e:
        print(e)
        context1 = None
    try:
        context2 = load('tests/test-replay', 'tests/fake-repo-pre')
    except ValueError as e:
        print(e)
        context2 = None
    try:
        context3 = load('tests/test-replay', 'tests/fake-repo-post')
    except ValueError as e:
        print(e)
        context3 = None
    print(context1==None)
    print(context2==None)
    print(context3==None)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:29:48.909490
# Unit test for function load
def test_load():
    print("load()")


# Generated at 2022-06-11 20:29:55.735150
# Unit test for function dump
def test_dump():
    replay_dir = 'test/test_dump'
    template_name = 'test_replay'
    context = {'cookiecutter': {'no_input': 'false', 'replay_dir': replay_dir}}
    dump(replay_dir, template_name, context)
    # verify replay file is created
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file) == True
    # verify context is in file
    with open(replay_file, 'r') as infile:
        assert infile.read() == '{\n  "cookiecutter": {\n    "no_input": "false", \n    "replay_dir": "test/test_dump"\n  }\n}\n'


# Generated at 2022-06-11 20:29:58.916344
# Unit test for function load
def test_load():
    with open('test_load.json', 'r') as infile:
        context = json.load(infile)
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')
    print(context)

# Generated at 2022-06-11 20:30:25.407234
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.getcwd(), 'example')
    template_name = '.'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context



# Generated at 2022-06-11 20:30:32.076378
# Unit test for function dump
def test_dump():
    replay_dir = os.path.expanduser('~/test')
    template_name = 'my-awesome-project'

# Generated at 2022-06-11 20:30:40.482317
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    from cookiecutter.main import cookiecutter as cookiecutter_main
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter import replay
    import os
    import shutil
    import json

    # Delete replay folder if it already exists
    if os.path.isdir('replay'):
        shutil.rmtree('replay')
    
    # Create replay folder
    os.mkdir('replay')

    # Create variables for dump function
    replay_dir = 'replay'
    template_name = 'cookiecutter-pypackage'
    project_name = 'project_name'

    # Use cookiecutter function to generate replay data

# Generated at 2022-06-11 20:30:48.374103
# Unit test for function load
def test_load():
    # Test with template name of type string
    replay_dir = "Foo"
    template_name = "Bar"
    test_context = {"cookiecutter": {"hello": "world", "goodbye": "cruel world"}}
    dump(replay_dir, template_name, test_context)
    assert load(replay_dir, template_name) == test_context

    # Test with template name of type float (should throw TypeError)
    with pytest.raises(TypeError):
        template_name = 1.23
        load(replay_dir, template_name)

    # Test if load throws ValueError because context does not
    # contain a cookiecutter key
    with pytest.raises(ValueError):
        test_context = {"hey": "hi", "hello": "world"}

# Generated at 2022-06-11 20:30:49.968472
# Unit test for function load
def test_load():
    assert load("tests/test-replay/", "cookiecutter-pypackage")


# Generated at 2022-06-11 20:30:54.105191
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(
        os.path.dirname(__file__),
        'test_files/test_replay_dir'
    )
    template_name = 'test_replay_dir'
    context = {'cookiecutter': 'Hello World'}
    dump(replay_dir, template_name, context)
    file_name = get_file_name(replay_dir, template_name)
    file_content = ''
    with open(file_name, 'r') as infile:
        file_content = infile.read()

    assert file_content == '{\n  "cookiecutter": "Hello World"\n}'



# Generated at 2022-06-11 20:31:03.770527
# Unit test for function load
def test_load():
    context = load('/Users/pax/Documents/Cookiecutter/cookiecutter-pypackage-minimal/replay', 'example')
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['use_pypi_deployment_with_travis'] == 'y'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter-Pypackage-Minimal'
    assert context['cookiecutter']['project_name_snake'] == 'cookiecutter_pypackage_minimal'
    assert context['cookiecutter']['github_username'] == 'audreyr'
    assert context

# Generated at 2022-06-11 20:31:05.445697
# Unit test for function dump
def test_dump():
    try:
        dump()
        assert True
    except:
        assert False


if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-11 20:31:07.761830
# Unit test for function load
def test_load():
    context = load('./replay/', 'cookiecutter_temp')
    if 'project_name' not in context['cookiecutter']:
        assert False
    else:
        assert True

# Generated at 2022-06-11 20:31:10.672462
# Unit test for function load
def test_load():
    context = load("../tests/test-replay-dir", "cookiecutter-pypackage")
    print(context)
    assert context["cookiecutter"]["name"] == "My Full Name"



# Generated at 2022-06-11 20:32:01.552833
# Unit test for function dump
def test_dump():
    #Arrange
    replay_dir = 'test_dir/test_replay_dir/'
    template_name = 'test_template'
    context = {'cookiecutter':
                {'full_name': 'Cookiecutter User',
                 'email': 'user@example.com',
                 'github_username': 'audreyr',
                 'project_name': 'Test',
                 'project_slug': 'test',
                 'project_short_description': 'A short description of the project.',
                 'pypi_username': 'audreyr',
                 'version': '0.1.0',
                 'release_date': '2014-04-14'}}
    #Act
    dump(replay_dir, template_name, context)
    #Assert