

# Generated at 2022-06-11 20:22:16.592096
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'tests/test-replay-dir')
    template_name = 'audrey-jinja'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['first_name'] == 'Audrey'



# Generated at 2022-06-11 20:22:21.818389
# Unit test for function dump
def test_dump():
    dict = {
        'cookiecutter': {
            'name': 'Sam'
        }
    }
    replay_dir = 'test_folder/test_folder2'
    template_name = 'test.json'
    dump(replay_dir=replay_dir, template_name=template_name, context=dict)



# Generated at 2022-06-11 20:22:27.946859
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name function."""
    replay_dir = os.getcwd()
    template_name = 'temp_name'
    expected = os.path.join(replay_dir, template_name + '.json')
    actual = get_file_name(replay_dir, template_name)
    assert actual == expected


# Generated at 2022-06-11 20:22:31.177530
# Unit test for function load
def test_load():
    path = os.path.join(os.getcwd(), 'tests/test-replay/')
    context = load(path, 'test-replay')
    print('context: ', context)

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-11 20:22:37.966528
# Unit test for function dump
def test_dump():
    replay_dir = '.'

    template_name = 'cake'

    context = {
        'cookiecutter': {
             'name': 'Audrey',
             'project_name': 'Cookiecutter Example',
             'repo_name': 'cookiecutter-example',
             'release_date': '2014/02/06',
             'year': '2014'
        }
    }

    assert dump(replay_dir, template_name, context) is None


# Generated at 2022-06-11 20:22:46.661378
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.getcwd(), 'test_dir')
    template_name = 'test_template'
    context = {
        'cookiecutter': {
            'author_email': 'author@domain.ext',
            'full_name': 'Author Name',
        }
    }
    dump(replay_dir, template_name, context)
    file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(file) == True
    with open(file, 'r') as infile:
        data_file = json.load(infile)
    for key in context:
        assert key in data_file


# Generated at 2022-06-11 20:22:57.218647
# Unit test for function load
def test_load():
    """Unit test for function test_load."""
    from cookiecutter import replay
    import json
    import os

    dir_path = os.path.dirname(os.path.realpath(__file__))
    template_path = os.path.join(dir_path, '..', '..', 'tests', 'test-template')
    replay_dir = os.path.join(template_path, 'tests', 'test-replay')
    context = replay.load(replay_dir, 'test-template')
    context_json = json.dumps(context, sort_keys=True, indent=2)


# Generated at 2022-06-11 20:22:59.755739
# Unit test for function load
def test_load():
    print(load('~/.cookiecutters/', 'cookiecutter_replay'))


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:23:07.504485
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.abspath('.'), 'test')
    template_name = 'cookiecutter-template1'
    template_name = 'cookiecutter-template1'

    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file), replay_file

    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context, context
    assert 'name' in context.get('cookiecutter'), context
    #assert context.get('cookiecutter').get('name') == template_name, context


# Generated at 2022-06-11 20:23:17.431528
# Unit test for function load

# Generated at 2022-06-11 20:23:27.266874
# Unit test for function load
def test_load():
    """
    Unit tests for load.
    """
    from io import StringIO

    # Test with no context file
    context = load('.', 'no_file')
    assert context == {}

    # Test with with file that doesn't define cookiecutter
    with open('test.txt', 'w') as outfile:
        outfile.write('{}')
    context = load('.', 'test')
    os.remove('test.txt')
    assert context == {}

    # Test with with file that defines cookiecutter
    with open('test.txt', 'w') as outfile:
        outfile.write('{"cookiecutter": {}}')
    context = load('.', 'test')
    os.remove('test.txt')
    assert context == {'cookiecutter': {}}


# Generated at 2022-06-11 20:23:34.628669
# Unit test for function dump
def test_dump():
    from cookiecutter.utils import workdir
    from cookiecutter import utils
    import os
    import os.path as op

    with workdir():
        replay_dir = './tests/files/to_dump'
        template_name = 'test_template'
        context = {
            'cookiecutter': {
                'full_name': 'Test MacGyver',
                'name': 'test',
                'email': 'test@test.com',
                'datetime': datetime.datetime(2018, 10, 1, 10, 58, 18, 939432),
                'timezone': 'US/Eastern'
            }
        }
        dump(replay_dir, template_name, context)
        replay_file = get_file_name(replay_dir, template_name)
        # Check if the file exists

# Generated at 2022-06-11 20:23:37.593914
# Unit test for function load
def test_load():
    """Unit test for function load"""
    context = load('tests/test-replay', 'example-repo-tmpl')
    assert 'cookiecutter' in context, "File does not contain the key 'cookiecutter'"

# Generated at 2022-06-11 20:23:40.156283
# Unit test for function load
def test_load():
    template_name = "test"
    replay_dir = "."
    context = load(replay_dir, template_name)
    assert(context['cookiecutter']['project_name'] == 'Test')
    assert(context['cookiecutter']['project_slug'] == 'test')


# Generated at 2022-06-11 20:23:45.931345
# Unit test for function load
def test_load():
    template_name = 'my-awesome-project'
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    replay_file = get_file_name(replay_dir, template_name)
    context = load(replay_dir, template_name)
    assert template_name in replay_file
    assert 'cookiecutter' in context
    assert context['cookiecutter']


# Generated at 2022-06-11 20:23:55.867296
# Unit test for function load
def test_load():
    # test for valid template_name
    replay_dir = '/home/test/.cco/replay/'
    template_name = 'test_template'

# Generated at 2022-06-11 20:23:57.041085
# Unit test for function load
def test_load():
    print(load('replay', 'pypackage'))



# Generated at 2022-06-11 20:24:04.533696
# Unit test for function load
def test_load():
    replay_dir = '../tests/files/replay'
    template_name = 'wooppee'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict) is True
    assert context['cookiecutter']['full_name'] == 'Royce Meyer-Fong'
    assert context['cookiecutter']['email'] == 'rmeyerfong@ucdavis.edu'
    assert context['cookiecutter']['repo_name'] == 'wooppee'


# Generated at 2022-06-11 20:24:11.146293
# Unit test for function load
def test_load():
    """Test load function."""
    import os
    import inspect
    dir_path = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-11 20:24:14.041048
# Unit test for function load
def test_load():
    context = load(os.getcwd(), 'template.json')
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:24:18.778754
# Unit test for function load
def test_load():
    """Test load replay function."""
    path = '/home/arun/Downloads/'
    name = 'haha'
    #dump(path, name, {'foo': 'bar'})
    d = load(path, name)
    print(d)

# Generated at 2022-06-11 20:24:25.494679
# Unit test for function load
def test_load():
    template_name = 'default'
    replay_dir = '/home/marcus/.cookiecutters/'
    print('=======================', load(replay_dir, template_name))
    assert isinstance(load(replay_dir, template_name), dict)
    assert isinstance(load(replay_dir, template_name)['cookiecutter'], dict)

# Generated at 2022-06-11 20:24:30.188902
# Unit test for function load
def test_load():
    context = load(os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/replay', 'example_template')
    assert(context['cookiecutter']['full_name'] == 'Your Name')
    assert(context['cookiecutter']['project_name'] == 'example_project')

# Generated at 2022-06-11 20:24:34.901870
# Unit test for function load
def test_load():
    replay_file = "config.json"
    with open(replay_file, 'r') as infile:
        context = json.load(infile)
    print(type(context))
    print(context)
    print(context["cookiecutter"])

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:24:39.540614
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-data/replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert context == {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com'}}



# Generated at 2022-06-11 20:24:42.947629
# Unit test for function load
def test_load():
    """Test load function."""
    template_name = 'test_project'
    replay_dir = '{{cookiecutter.replay_dir}}'
    context = load(replay_dir, template_name)

    assert 'cookiecutter' in context
    assert isinstance(context['cookiecutter'], dict)

# Generated at 2022-06-11 20:24:45.730071
# Unit test for function load
def test_load():
    ctx = load(replay_dir='fake_replay_dir', template_name='fake')
    assert 'cookiecutter' in ctx
    assert ctx['cookiecutter'] == {'_replay': True}

# Generated at 2022-06-11 20:24:50.818890
# Unit test for function dump
def test_dump():
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'full_name': 'Firstname Lastname', 'email': 'me@example.com', 'project_name': 'Example'}}

    replay_dir = '/tmp/cookiecutter-replay'
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, 'cookiecutter-pypackage.json'))


# Generated at 2022-06-11 20:24:59.153377
# Unit test for function load
def test_load():
    context = load('/Users/kyunghan/Documents/kyunghan/cookiecutter-template/tests/test_replay/replay', 'test')
    assert context == {
        'cookiecutter': {
            'full_name': 'Somebody McSomebodyface',
            'email': 'some.body@somewhere.net',
            'github_username': 'sboneface',
            'project_name': 'mypkg',
            'project_slug': 'mypkg',
            'project_short_description': 'A project that does something',
            'pypi_username': 'sboneface',
            'release_date': '2014-10-10'
        }
    }

# Generated at 2022-06-11 20:25:00.432423
# Unit test for function load
def test_load():
    context=load('./','data')
    print(context)


# Generated at 2022-06-11 20:25:06.677342
# Unit test for function load
def test_load():
    replay_dir = os.path.join(
        os.path.expanduser('~'),
        'cookiecutters',
        'test',
        'replay'
    )
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['repo_dir'] == 'any'
    assert context['cookiecutter']['checkout'] == 'master'
    assert context['cookiecutter']['no_input'] is True



# Generated at 2022-06-11 20:25:10.973403
# Unit test for function load
def test_load():
    cookie_path = r'C:\Users\izquierdo\OneDrive - Argonne National Laboratory\Cookiecutter\cookiecutter-data\cookiecutters'
    replay_dir = os.path.join(cookie_path, '_replay')
    load(replay_dir, 'argopy')


# Generated at 2022-06-11 20:25:14.473775
# Unit test for function load
def test_load():
    import pprint
    context = load('~/.cookiecutters', 'cookiecutter-pypackage')
    pprint.pprint(context)


# Generated at 2022-06-11 20:25:18.691950
# Unit test for function load
def test_load():
    print("Testing load...")
    replay_dir = 'tests/test-repo'
    template_name = 'test/test_load_replay_file.json'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:25:25.674971
# Unit test for function load
def test_load():
    """test function load."""
    replay_dir = 'test_replay'
    template_name = 'test_template'
    context = {
        'cookiecutter': {
            'test_key': 'test_value',
        },
    }

    dump(replay_dir, template_name, context)

    context_out = load(replay_dir, template_name)

    assert context == context_out

    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-11 20:25:28.041407
# Unit test for function load
def test_load():
    context = load('~/', 'test_dir')
    assert isinstance(context, dict)

test_load()

# Generated at 2022-06-11 20:25:30.750067
# Unit test for function load
def test_load():
    context = load('/Users/d234280/git/CookiecutterGitlab', 'CookiecutterGitlab')
    print(context)

test_load()

# Generated at 2022-06-11 20:25:33.510678
# Unit test for function load
def test_load():
    context = load('/home/bryan/dev/github/cookiecutter-pypackage/tests/test-output/replay', 'pypackage')
    print('{}'.format(context))

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:25:36.098732
# Unit test for function load
def test_load():
    # The template name is required to be of type str
    try:
        load('/Users/lulu/core/cookiecutter_trifork/cookiecutter-trifork/tests/test-output/replay/', 10)
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-11 20:25:38.736799
# Unit test for function load
def test_load():
    data = load('replay', 'foo')
    #print('data: %s' % data)
    assert type(data) == dict
    #assert data == {'cookiecutter': {'_template': 'replay/foo.json'}}
    assert data == {'cookiecutter': {'_template': 'foo'}}

test_load()


# Generated at 2022-06-11 20:25:42.185237
# Unit test for function load
def test_load():
    assert load('tests', 'test') == {'cookiecutter': {'project_slug': 'cookiecutter-pypackage'}}

# Generated at 2022-06-11 20:25:47.088875
# Unit test for function load
def test_load():
    """Unit test for function load."""
    try:
        load(replay_dir = "../templates", template_name = "template_name")
        print("Unit test for function test_load passed.")
    except:
        print("Unit test for function test_load failed.")


# Generated at 2022-06-11 20:25:52.694606
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'full_name': 'Julia Elman',
            'email': 'julia@selman.com',
            'github_username': 'jelman'
        }
    }
    dump('/tmp', 'bcguhaf-project', context)



# Generated at 2022-06-11 20:26:00.644012
# Unit test for function dump
def test_dump():
    replay_dir = "cookiecutter_duck_test_output"
    template_name = "dummytemplate"
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['name'] = "duck"
    context['cookiecutter']['replay'] = True
    context['cookiecutter']['question'] = "What's it like being a duck?"

    dump(replay_dir, template_name, context)
    new_context = load(replay_dir, template_name)

    assert new_context['cookiecutter']['name'] == context['cookiecutter']['name']
    assert new_context['cookiecutter']['replay'] == context['cookiecutter']['replay']

# Generated at 2022-06-11 20:26:04.130412
# Unit test for function load
def test_load():
    """Unit test for function load"""

    file_name = "/home/hongliang/Downloads/testing-cookiecutter-master/tests/test_load.json"
    context = load('/home/hongliang/Downloads/testing-cookiecutter-master/', file_name)
    print(context)


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:26:06.877081
# Unit test for function load
def test_load():
    """test"""
    if __name__ == "__main__":
        test_context = load("test_replay/", "cookiecutter-pypackage.json")
        assert test_context['cookiecutter']['project_name'] == "Cookiecutter Testing Pypackage"

# Generated at 2022-06-11 20:26:11.277066
# Unit test for function load
def test_load():
    context = load("/home/lz/PycharmProjects/cookiecutter-j2-project/test/test-replay","j2-project")
    print(context)


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:26:15.236743
# Unit test for function load
def test_load():
    context = load('tests/', 'tests/fake-repo-tmpl')
    assert('cookiecutter' in context)
    assert('author_email' in context['cookiecutter'])
    assert('project_name' in context['cookiecutter'])


# Generated at 2022-06-11 20:26:18.194339
# Unit test for function load
def test_load():
    file_name = '../../cookiecutter-pypackage/cookiecutter.json'
    context = load('./', file_name)
    print(context)


# Generated at 2022-06-11 20:26:21.278377
# Unit test for function dump
def test_dump():
    temp = {"user": "test", "cookiecutter": {"replay": "test"}}
    dump('templates/', 'test', temp)


# Generated at 2022-06-11 20:26:26.502861
# Unit test for function load
def test_load():
    template = load(replay_dir, 'cookiecutter-pypackage')
    # print(template)
    assert template['cookiecutter']['project_name'] == 'Example Package'


# Generated at 2022-06-11 20:26:34.662614
# Unit test for function load
def test_load():
    assert load('tests/replay', 'tests/replay/cookiecutter-pypackage-minimal') == {
        'cookiecutter': {
            'author_email': 'test@test.test',
            'author_name': 'test',
            'description': 'test',
            'full_name': 'test',
            'open_source_license': 'MIT license',
            'project_name': 'test',
            'project_slug': 'test',
            'pypi_username': 'test',
            'select_license': 'MIT license'
        }
    }

# Generated at 2022-06-11 20:26:37.365465
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = 'play_template.json'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:26:41.447679
# Unit test for function load
def test_load():
    context = load('/Users/aditmodhvadia/Desktop/cookiecutter-pypackage/cookiecutter-pypackage/replay','cookiecutter-pypackage-master')
    print(context)


# Generated at 2022-06-11 20:26:44.541498
# Unit test for function load
def test_load():
    from cookiecutter.replay import load
    replay_dir = '~/cookiecutter-replay'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert type(context) == dict
    assert 'cookiecutter' in context

# Generated at 2022-06-11 20:26:53.743725
# Unit test for function load
def test_load():

    replay_dir = './'
    template_name = 'test'
    context = {'cookiecutter': {}}
    context['cookiecutter']['test_key'] = 'test_value'

    # Test case 1: template_name is not a str
    try:
        replay_dir = './'
        template_name = 3
        context = {'cookiecutter': {}}
        context['cookiecutter']['test_key'] = 'test_value'

        replay_test1 = load(replay_dir, template_name)
        assert False
    except TypeError:
        assert True

    # Test case 2: context doesn't contain 'cookiecutter'

# Generated at 2022-06-11 20:27:01.957014
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import sys
    import os
    dir_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(os.path.join(dir_path, ".."))
    from cookiecutter.main import cookiecutter

    # Load
    context = load(
        replay_dir=os.path.join(dir_path, 'replay'),
        template_name='tests/test-repo'
    )

    if context['cookiecutter']['project_slug'] != 'tests-test-repo':
        raise AssertionError('Invalid context returned from load')


# Generated at 2022-06-11 20:27:05.701706
# Unit test for function load
def test_load():
    replay_dir = '~/.cookiecutter_replay/'
    template_name = 'test_template'

    context = {'cookiecutter': {
        'test_key': 'test_value',
    }}
    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert context['cookiecutter'] == loaded_context['cookiecutter']

    # TODO add negative testcases

# Generated at 2022-06-11 20:27:16.098617
# Unit test for function dump
def test_dump():
    replay_dir = '../test/fake-repo/'
    template_name = 'fake-repo'
    context = {'cookiecutter': {'full_name': 'Audrey Roy Greenfeld',
                                'email': 'audreyr@example.com',
                                'github_username': 'audreyr',
                                'project_name': 'Cookiecutter-pypackage',
                                'project_slug': 'cookiecutter-pypackage',
                                'tagline': 'A minimal Python package project template.',
                                'version': '0.1.0'
                                }}
    dump(replay_dir, template_name, context)
    assert len(os.listdir('../test/fake-repo/')) == 1



# Generated at 2022-06-11 20:27:25.527243
# Unit test for function load
def test_load():
    """Unit tests."""
    import shutil
    import tempfile
    template_name = 'test-replay'
    temp_dir = tempfile.mkdtemp()
    try:
        full_path = os.path.join(temp_dir, template_name)
        with open(full_path, 'w') as outfile:
            output = {'cookiecutter': {'test': '123'}}
            json.dump(output, outfile)
        loaded_data = load(temp_dir, template_name)
        assert loaded_data == output
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-11 20:27:32.252524
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:27:39.449399
# Unit test for function load
def test_load():
    assert isinstance(load('/home/anirudh/repo/cookiecutter/tests/fixtures', 'fail_case'), dict)
    assert isinstance(load('/home/anirudh/repo/cookiecutter/tests/fixtures/replay', 'fail_case'), dict)
    assert load('/home/anirudh/repo/cookiecutter/tests/fixtures/replay', 'fail_case')['cookiecutter']
    assert 'foo' in load('/home/anirudh/repo/cookiecutter/tests/fixtures/replay', 'fail_case')['cookiecutter']


# Generated at 2022-06-11 20:27:46.704475
# Unit test for function load
def test_load():
    context1 = {
        'cookiecutter': {
            'project_name': 'My Project',
        },
    }
    context2 = {
        'cookiecutter': {
            'project_name': 'My Awesome Project'
        }
    }

    replay_dir = './tests/fixtures/replay_dir'

    dump(replay_dir, 'test1', context1)
    dump(replay_dir, 'test2', context2)

    assert context1 == load(replay_dir, 'test1')
    assert context2 == load(replay_dir, 'test2')

# Generated at 2022-06-11 20:27:50.576264
# Unit test for function load
def test_load():
    ctx = load('C:/Users/a0109/Cookiecutter/replay', '01.json')
    assert(type(ctx) is dict)
    assert('cookiecutter' in ctx)
    assert(ctx['cookiecutter'] == {})


# Generated at 2022-06-11 20:27:54.301492
# Unit test for function load
def test_load():
    """Unit test for function load"""
    import tempfile
    context = {'cookiecutter': {'test': '', 'print_iter': '', 'no_input': ''}}
    replay_dir = tempfile.mkdtemp()
    template_name = 'test'
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-11 20:27:57.253496
# Unit test for function load
def test_load():
    assert load(os.path.join(os.path.dirname(__file__), 'tests/fixtures/replay_dir'), 'Django')['cookiecutter']['repo_name'] == 'Django'


# Generated at 2022-06-11 20:28:05.030556
# Unit test for function dump
def test_dump():
    import tempfile
    import os

    replay_dir = tempfile.mkdtemp()
    context = {
        'cookiecutter': {
            'repo_dir': 'https://github.com/aniketkudale/cookiecutter-pypackage-min',
            'replay_dir': replay_dir
        }
    }

    dump(replay_dir, 'try-it', context)

    loaded = load(replay_dir, 'try-it')

    assert loaded == context

    os.remove(os.path.join(replay_dir, 'try-it.json'))

# Generated at 2022-06-11 20:28:05.852626
# Unit test for function load
def test_load():
    pass
## Load
# Get the name of file

# Generated at 2022-06-11 20:28:12.151549
# Unit test for function load
def test_load():
    replay_dir = 'test_replay'
    template_name = 'test_template.json'
    try:
        context = load(replay_dir, template_name)
        assert isinstance(context, dict)
        assert 'cookiecutter' in context
    except OSError:
        print("The directory doesn't exist")
    except ValueError:
        print("This file doesn't contain the cookiecutter key")
    except TypeError:
        print("The args should be string")

# Test function dump

# Generated at 2022-06-11 20:28:16.788475
# Unit test for function load
def test_load():
    replay_dir = os.path.expanduser('~/cookiecutter-replay')
    template_name = 'test_template'

    context = {
        'test_var': 'test_value',
        'cookiecutter': {
            '_template': template_name,
        }
    }

    dump(replay_dir, template_name, context)

    read_context = load(replay_dir, template_name)

    assert read_context == context



# Generated at 2022-06-11 20:28:24.386150
# Unit test for function load
def test_load():
    # path = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    # context = load(path, 'cookiecutter-pypackage')
    # assert isinstance(context, dict)
    #
    # with pytest.raises(TypeError):
    #     load(0, 'cookiecutter-pypackage')
    #
    # with pytest.raises(ValueError):
    #     load(path, 0)
    #
    # with pytest.raises(ValueError):
    #     load(path, 'cookiecutter-pypackage')

    pass

# Generated at 2022-06-11 20:28:25.956668
# Unit test for function load
def test_load():
    assert type(load("C:\\Users\\yhong8\\Desktop\\Source\\cookiecutter-python\\tests\\test-root", "default-with-config-file")) == dict

# Generated at 2022-06-11 20:28:30.119059
# Unit test for function load
def test_load():
    print("test_load")
    expected_cookiecutter = {'replay_dir': '.'}
    context = load('.', 'template_name')
    cookiecutter = context['cookiecutter']
    if cookiecutter != expected_cookiecutter:
        print("test_load failed: cookiecutter does not match expected_cookiecutter")
        print("cookiecutter = " + str(cookiecutter))
        print("expected_cookiecutter = " + str(expected_cookiecutter))
    else:
        print("test_load ok")

# Generated at 2022-06-11 20:28:37.896701
# Unit test for function load
def test_load():
    """Test load() function."""
    from cookiecutter import replay

    # Load a file that doesn't exist
    try:
        replay.load('/tmp/does_not_exist', '.')
        assert False
    except IOError:
        assert True

    # Load a file that exists, but isn't JSON
    try:
        fd = open('/tmp/tmp.txt', 'a')
        fd.close()

        replay.load('/tmp', 'tmp.txt')
        assert False
    except:
        assert True

    # Load a valid file

# Generated at 2022-06-11 20:28:45.143773
# Unit test for function load
def test_load():
    replays_dir = os.path.join(os.getcwd(), 'test_load')
    template_name = 'hello_world'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'cookiecutter-pypackage',
            'pypi_username': 'cookiecutter',
            'release_date': '2013-07-01',
            'version': '0.1.0',
            'open_source_license': 'MIT license'
        },
    }
    dump(replays_dir, template_name, context)
    loaded_context = load(replays_dir, template_name)
    assert loaded_context

# Generated at 2022-06-11 20:28:53.153066
# Unit test for function load
def test_load():
    template_name = 'template'

# Generated at 2022-06-11 20:28:59.673949
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-output'
    template_name = 'cookiecutter-pypackage'
    context = {
        'full_name': 'Audrey Roy',
        'email': 'audreyr@example.com',
        'project_name': 'cookiecutter-pypackage',
        'project_slug': 'cookiecutter-pypackage',
        'project_short_description': 'A short description of the project.',
        'release_date': '2014-04-14',
        'year': '2014',
        'version': '0.1.0',
        'cookiecutter': {
            '_template': 'cookiecutter-pypackage',
            '_replay': replay_dir
        }
    }
    dump

# Generated at 2022-06-11 20:29:01.291847
# Unit test for function load
def test_load():
    return dump('./', 'test', {'cookiecutter': {'test': 'test'}})

# Generated at 2022-06-11 20:29:07.391815
# Unit test for function dump
def test_dump():
    """Test case for unit test."""
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-11 20:29:17.323473
# Unit test for function dump
def test_dump():
    
    context = {
        'cookiecutter': {
            'full_name': 'firstname lastname',
            'email': 'email@email.com',
            'project_name': 'project_name',
        }
    }
    
    try:
        dump("./replay", "template_name", context)
    except ValueError as err:
        assert 'Unable to create replay dir at' in str(err)
    
    try:
        dump("./tests/replay", "template_name", "context")
    except TypeError as err:
        assert 'Context is required to be of type dict' in str(err)
    

# Generated at 2022-06-11 20:29:32.232863
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-11 20:29:42.265206
# Unit test for function load
def test_load():
    """
    Function test_load is to test load function.
    """
    template_name = '../../tests/test-repo-pre/'
    replay_dir = '../../tests/test-repo-pre/'
    context = load(replay_dir, template_name)
    print("Test load function: ", context)

# Generated at 2022-06-11 20:29:44.612418
# Unit test for function load
def test_load():
    try:
        load('/Users/hsuan/.cookiecutters', 'template_name')
    except IOError:
        pass
    except TypeError:
        pass


# Generated at 2022-06-11 20:29:46.455463
# Unit test for function load
def test_load():
    test_context={'cookiecutter': {'project_name': 'Test Project'}}
    assert load('./', 'Test Project') == test_context


# Generated at 2022-06-11 20:29:51.163392
# Unit test for function load
def test_load():
    """Test function load."""
    c1 = load('cookiecutter-pypackage', 'cookiecutter.json') # valid file
    c2 = load('cookiecutter-pypackage', 'init.py') # invalid file
    c3 = load('cookiecutter-pypackage', 2) # invalid name


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:29:54.505864
# Unit test for function dump
def test_dump():
    replay_dir = './tmp'
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'foo': 'bar'}}
    dump(replay_dir, template_name, context)
    context_2 = load(replay_dir, template_name)
    assert context == context_2


# Generated at 2022-06-11 20:30:01.575897
# Unit test for function load
def test_load():
    test_replay_dir = '/tmp/cookiecutter_replay_test/'
    test_template_name = 'test'
    test_file = get_file_name(test_replay_dir, test_template_name)
    test_data = {'cookiecutter': {'something': 'test'}}
    with open(test_file, 'w') as outfile:
        json.dump(test_data, outfile, indent=2)

    assert load(test_replay_dir, test_template_name) == {'cookiecutter': {'something': 'test'}}



# Generated at 2022-06-11 20:30:09.992655
# Unit test for function load
def test_load():
    """Test load."""
    context = load(os.path.expanduser('~/.cookiecutters'), 'cookiecutter-pypackage')
    assert context is not None
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'email' in context['cookiecutter']
    assert 'github_username' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']
    assert 'project_slug' in context['cookiecutter']
    assert 'release_date' in context['cookiecutter']
    assert 'year' in context['cookiecutter']
    assert 'version' in context['cookiecutter']
    assert 'pypi_username' in context['cookiecutter']

# Generated at 2022-06-11 20:30:19.636450
# Unit test for function load

# Generated at 2022-06-11 20:30:22.563028
# Unit test for function load
def test_load():
    '''
    Unit test for function load.
    '''
    assert(load('test/test_load', 'test/test_load/origin') != None)


# Generated at 2022-06-11 20:30:36.096684
# Unit test for function load
def test_load():
    replay_dir='/Users/jebyrnes1/Documents/PycharmProjects/cookiecutter-python-package/cookiecutter_python_package/'
    template_name='test_template.json'

    context=load(replay_dir,template_name)
    print(context)


# Generated at 2022-06-11 20:30:37.802988
# Unit test for function dump
def test_dump():
    template_name = 'template'
    context={'cookiecutter':{'full_name':'Jack'}}
    dump('./', template_name, context)


# Generated at 2022-06-11 20:30:46.554015
# Unit test for function dump
def test_dump():
    """Test dump."""
    import tempfile
    from cookiecutter.main import cookiecutter
    from cookiecutter.replay import dump, load
    
    # name of temporary folder to hold the output of `cookiecutter` command
    temp_dir = tempfile.mkdtemp(prefix='cookiecutter-')
    template_dir = os.path.dirname(os.path.dirname(__file__))

    # Perform cookiecutter command
    cookiecutter(
        template_dir,
        no_input=True,
        extra_context={
            'project_slug': 'cookiecutter-replay-test',
            'foo': 'bar',
            'baz': 'qux'
        },
        replay_dir=temp_dir
    )


# Generated at 2022-06-11 20:30:48.081044
# Unit test for function load
def test_load():
    assert load(replay_dir, template_name) == {'cookiecutter':{'full_name':'Talip'}}

# Generated at 2022-06-11 20:30:51.450960
# Unit test for function load
def test_load():
    # Create a temporary directory and json file
    tmpdir = tempfile.mkdtemp()
    tmp_json_file = os.path.join(tmpdir, "cookiecutter.json")
    with open(tmp_json_file, 'w+') as tmp_file:
        tmp_file.write("{'cookiecutter': {}}")
    load(tmpdir, 'cookiecutter')
    os.remove(tmp_json_file)
    os.rmdir(tmpdir)


# Generated at 2022-06-11 20:31:01.052224
# Unit test for function dump
def test_dump():
    import json
    import sys
    import os.path
    #test for invalid replay directory

# Generated at 2022-06-11 20:31:05.658521
# Unit test for function load
def test_load():
    template_name = 'hello_world'
    replay_dir = '/Users/ravikiran/Documents/Cookiecutter/code/'
    replay_file = get_file_name(replay_dir, template_name)
    print ('replay_file: {}'.format(replay_file))
    context = load(replay_dir, template_name)
    print (context)

# Generated at 2022-06-11 20:31:09.614913
# Unit test for function load
def test_load():
    replay_dir = '/Users/andy/Projects/cookiecutter-pypackage-minimal/cookiecutter-pypackage-minimal/'
    template_name = 'cookiecutter.json'
    context = load(replay_dir, template_name)
    print(context)
    print(context['cookiecutter'])


# Generated at 2022-06-11 20:31:19.100219
# Unit test for function load
def test_load():
    """Test for function load."""
    r_dir = './'
    t_name = 'template'
    ctx = {'Don':'Mao','cookiecutter':{'_copy_without_render':[],'_copy_without_render_content':[]}}
    dump(r_dir, t_name, ctx)
    assert(load(r_dir, t_name) == ctx)
    os.remove(get_file_name(r_dir, t_name))
    # Delete the file generated by testing
    try:
        load(r_dir, t_name)
    except IOError:
        pass
    else:
        assert 1 == 0, "test load IOError failed, the file should not exist"
    try:
        load(r_dir, 123)
    except TypeError:
        pass

# Generated at 2022-06-11 20:31:20.713021
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = 'config.json'
    return load(replay_dir, template_name)


# Generated at 2022-06-11 20:31:49.916959
# Unit test for function dump
def test_dump():
    replay_dir='test_replay_dir'
    template_name='test_template_name'
    context={'test_key': 'test_value'}
    
    dump(replay_dir, template_name, context)
    result=os.path.isfile(os.path.join('test_replay_dir', 'test_template_name.json'))
    assert result
    os.remove(os.path.join('test_replay_dir', 'test_template_name.json'))
    os.rmdir('test_replay_dir')
    

# Generated at 2022-06-11 20:31:52.114536
# Unit test for function load
def test_load():
    print(load('replay_files', 'python_module'))

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:31:56.636676
# Unit test for function load
def test_load():
    """Test that load works when it is given a valid json file"""
    import json
    replay_dir = 'tests/files/fake-replay-dir'
    template_name = 'fake-template.json'
    json_data = load(replay_dir, template_name)

    assert(json_data['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld')

# Generated at 2022-06-11 20:32:02.883222
# Unit test for function dump
def test_dump():
    """Testing function dump."""
    assert dump ('/Users/sonny/Desktop/cookiecutter_json', 'abc', {'cookiecutter': {'full_name': 'Sonny Li', 'email': 'sonny@example.com', 'project_name': 'myproject', 'default_context': True}})
    assert dump ('/Users/sonny/Desktop/cookiecutter_json', 'abc', {'cookiecutter': {'full_name': 'Sonny Li', 'email': 'sonny@example.com', 'project_name': 'myproject', 'default_context': True}})

# Generated at 2022-06-11 20:32:07.342228
# Unit test for function load
def test_load():
    replay_dir = 'cookiecutter_replay'
    template_name = 'haha'
    context = {'cookiecutter': {'test': ['a', 'b', 'c']}}
    dump(replay_dir, template_name, context)
    result = load(replay_dir, template_name)
    assert result == context


# Generated at 2022-06-11 20:32:11.623030
# Unit test for function load
def test_load():
    """Test load function"""
    template_name = "https://github.com/cookiecutter-django/cookiecutter-django.git"
    replay_dir = "C:/Users/yumu/py-cookiecutter/tests/fake-repo-pre/{{cookiecutter.project_name}}"
    load(replay_dir, template_name)
