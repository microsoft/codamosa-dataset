

# Generated at 2022-06-11 20:22:24.571403
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = 'C:/Users/hzwhuang/Documents/GitHub/cookiecutter-data-science/tests/example/cookie'
    template_name = 'example'
    context = {'cookiecutter': {'full_name': 'Wei Huang', 'email': '', 'project_name': 'test-cookie'}}

    dump(replay_dir, template_name, context)

if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-11 20:22:28.720112
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'd:\\temp\\replay'
    template_name = 'cookiecutter-pypackage'
    file_name = get_file_name(replay_dir, template_name)
    assert os.path.isfile(file_name)
    #assert os.path.isfile(file_name) == False

# Generated at 2022-06-11 20:22:34.578818
# Unit test for function load
def test_load():
    file_name = './tests/test-replay/fake-repo-pre/fake-repo.json'
    with open(file_name, 'r') as infile:
        context = json.load(infile)
    assert isinstance(context, dict)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:22:38.965560
# Unit test for function dump
def test_dump():
	context={'cookiecutter': {'replay': 'true', 'a': '2'}, 'extra': '1'}
	replay_dir="/Users/umar.kadiri/cookiecutterrepo/cookiecutter"
	template_name="hello-world"
	dump(replay_dir,template_name,context)




# Generated at 2022-06-11 20:22:46.717182
# Unit test for function load
def test_load():
    import json
    from cookiecutter.replay import get_file_name

    json_str = '{"cookiecutter": {"foo": "bar"}}'
    template_name = 'test_template'

    replay_file = '{}.json'.format(template_name)
    replay_file = get_file_name('./', template_name)

    with open(replay_file, 'w') as outfile:
        json.dump(json_str, outfile, indent=2)

    context = load('./', template_name)

    assert 'cookiecutter' in context

    os.remove(replay_file)

# Generated at 2022-06-11 20:22:53.337722
# Unit test for function dump
def test_dump():
    #Arrange
    import tempfile
    import shutil
    import json
    test_dir = tempfile.mkdtemp()
    #Act
    dump(test_dir, "test", {'cookiecutter': {'test': 'test'}})
    #Assert        
    assert os.path.isfile(os.path.join(test_dir, 'test.json'))
    #cleanup
    shutil.rmtree(test_dir)


# Generated at 2022-06-11 20:22:58.714910
# Unit test for function load
def test_load():
    temp_file = '/home/hou/Documents/repo/py3/cookiecutter-python-cli/tests/test_load.json'
    context = load(replay_dir='/home/hou/Documents/repo/py3/cookiecutter-python-cli/tests', template_name='test_load.json')
    with open(temp_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)



# Generated at 2022-06-11 20:23:05.464845
# Unit test for function load
def test_load():
    content_path = os.path.join(os.getcwd(), "tests", "test-repo", "{{cookiecutter.repo_name}}", "{{cookiecutter.repo_name}}")
    print(content_path)
    ctx = load(content_path, "cookiecutter.json")
    assert 'cookiecutter' in ctx

    ctx = load(content_path, "cookiecutter")
    assert 'cookiecutter' in ctx

# Generated at 2022-06-11 20:23:12.114680
# Unit test for function dump
def test_dump():
    import tempfile
    import shutil
    temp_dir = tempfile.mkdtemp()
    replay_dir = os.path.join(temp_dir, 'replay')
    template_name = 'my_template'
    context = {'cookiecutter': {
        'secret': '1234', 'foo': 'bar'
    }}

    dump(replay_dir, template_name, context)
    shutil.rmtree(temp_dir)


# Generated at 2022-06-11 20:23:18.411301
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'test'
    template_name = 'default'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, 'default.json')
    template_name = 'default.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, 'default.json')



# Generated at 2022-06-11 20:23:26.856097
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'full_name': 'James Kirk', 'email': 'kirk@enterprise.com'}}
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'

    print('Testing replay dump...')

    # Run the dump
    dump(replay_dir, template_name, context)

    # Check the file system
    filename = os.path.join(replay_dir, '{}.json'.format(template_name))
    assert os.path.isfile(filename)

    # Clean up
    os.remove(filename)
    os.rmdir(replay_dir)

# Generated at 2022-06-11 20:23:29.299393
# Unit test for function load
def test_load():
    assert load('/tmp', 'cookiecutter-pypackage') == {'cookiecutter': {'_copy_without_render': ['docs/*']}}


# Generated at 2022-06-11 20:23:34.100749
# Unit test for function load
def test_load():
    ans = load("./replay", "template")
    assert ans['cookiecutter']=={'full_name': 'Monty Python', 'email': 'monty@python.org', 'github_username': 'montypython'}
    assert ans['cookiecutter']['full_name'] == 'Monty Python'
    assert ans['cookiecutter']['email'] == 'monty@python.org'
    assert ans['cookiecutter']['github_username'] == 'montypython'



# Generated at 2022-06-11 20:23:38.684555
# Unit test for function dump
def test_dump():
    replay_dir = "C:\\Users\\xinyu\\.cookiecutters"
    template_name = "django_x"
    context = {'cookiecutter': {'_template': 'C:\\Users\\xinyu\\.cookiecutters\\django_x'}}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:23:46.059036
# Unit test for function load
def test_load():
    # create a fake directory
    testdir = 'tmpdir'
    if not os.path.exists(testdir):
        os.mkdir(testdir)
    # create a fake json file
    jsonfile = os.path.join(testdir,'test.json')
    with open(jsonfile, 'w') as f:
        json.dump({'foo':'bar'}, f)
    # test load
    assert load(testdir, 'test')['foo'] == 'bar'
    # delete test data
    os.rmdir(testdir)

# Generated at 2022-06-11 20:23:50.419607
# Unit test for function load
def test_load():
    """Test the load function."""
    import configparser
    configparser.ConfigParser()
#     filename = "templates/python_module/cookiecutter.json"
#     replay_dir = "tests"
#     template_name = "templates/python_module/cookiecutter.json"
#     load(replay_dir, template_name)


# Generated at 2022-06-11 20:23:55.813911
# Unit test for function load
def test_load():
    # test load function
    # create a new directory and template_name
    # load the function
    # test if the function works correctly
    # if it works correctly, return true
    real_load = load('~/Desktop', 'test_load')
    if real_load == {'cookiecutter': 'test'}:
        return True
    else:
        return False


# Generated at 2022-06-11 20:23:58.203329
# Unit test for function load
def test_load():
    replay_dir = "tests/files/fake-replay"
    template_name = "toy-project"
    context = load(replay_dir, template_name)
    print(context)



# Generated at 2022-06-11 20:24:08.621578
# Unit test for function load
def test_load():
    """Tests:
    - Load a json file
    - Load a non-existing file
    - Load a file with a non-json extension
    """

    import shutil
    import tempfile

#-------------------------------------------------------------------------
# First test

    file_name = 'test_load.txt'
    file_path = os.path.join(tempfile.mkdtemp(), file_name)

    with open(file_path, 'w') as temp_file:
        temp_file.write('{ "name": "val" }')

    context = load(os.path.dirname(file_path), file_name)
    assert context['name'] == 'val'
    
    shutil.rmtree(os.path.dirname(file_path))
    
#-------------------------------------------------------------------------
# Second test


# Generated at 2022-06-11 20:24:11.420363
# Unit test for function load
def test_load():
    replay_dir = 'tests/output'
    template_name = 'test'
    context = load(replay_dir, template_name)
    print(context)

# Generated at 2022-06-11 20:24:19.340362
# Unit test for function load
def test_load():
    template_name = 'cookiecutter-pypackage'
    replay_dir = os.path.abspath(os.path.join(os.path.abspath(__file__), os.pardir))
    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    assert 'cookiecutter' in context



# Generated at 2022-06-11 20:24:23.942278
# Unit test for function load
def test_load():
    """Unit test for function load"""
    print(load(replay_dir='/home/keerthi/Documents/cs7ns2-assignment1-master', template_name='cookiecutter-pypackage'))


# Generated at 2022-06-11 20:24:27.528917
# Unit test for function load
def test_load():
    test_replay_dir = 'C:\\Users\\lxn1088\\Desktop\\t\\'
    template_name = 'python-package'
    print(load(test_replay_dir, template_name))

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:24:31.133470
# Unit test for function load
def test_load():
    context = load('/Users/konstantin/Documents/cookiecutter-pypackage/dev/replay','cookie-replay-example')
    if context['cookiecutter']['full_name'] == 'Your Name':
        print ('test_load is successful')

# Generated at 2022-06-11 20:24:39.125555
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {},
    }
    replay_dir = './replay_dir'
    template_name = 'test'
    try:
        dump(replay_dir, template_name, context)
        replay_file = get_file_name(replay_dir, template_name)
        if os.path.exists(replay_file):
            os.remove(replay_file)
            return 0
        else:
            return -1
    except Exception:
        return -1

#Unit test for function load

# Generated at 2022-06-11 20:24:43.982924
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-load'
    template_name = 'test-load'
    context = {'cookiecutter': {'key': 'value'}}

    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)
    assert context_loaded == context
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-11 20:24:46.848729
# Unit test for function load
def test_load():
    load('/Users/suryapoduru/PycharmProjects/cookiecutter/tests/test-replay', 'fake-repo-pre/')

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:24:48.526433
# Unit test for function load
def test_load():
    context = load('/home/anh/Desktop/test/test_test_test', 'cookiecutter.json')
    print(context)

# Generated at 2022-06-11 20:24:50.573412
# Unit test for function load
def test_load():
    # Load context from file
    context = load('my_first_cookiecutter_project/cookiecutter_replay', 'my_first_cookiecutter_project')

# Generated at 2022-06-11 20:24:52.119380
# Unit test for function load
def test_load():
    replay_dir = "replay/"
    template_name = "test"
    load(replay_dir, template_name)


# Generated at 2022-06-11 20:25:00.145844
# Unit test for function load
def test_load():
    """
    Unit testing for load function.
    """
    context = load(replay_dir='/Users/checklist/Desktop/HU-CS350/homework-template', template_name='dodgy.json')
    
    assert context['cookiecutter']['repo_name'] == 'Your repository name', "Repo_name is not equal to 'Your repository name'"
    assert context['cookiecutter']['description'] == 'short description', "description is not equal to 'short description'"


# Generated at 2022-06-11 20:25:03.352333
# Unit test for function load
def test_load():
    from tempfile import mkdtemp

    template_name = 'example'
    replay_dir = mkdtemp('replay_dir')
    context = {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com'}}

    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert loaded_context == context



# Generated at 2022-06-11 20:25:06.393562
# Unit test for function load
def test_load():
    current_path = os.path.abspath(os.getcwd())
    replay_dir = os.path.join(current_path, 'tests/test-replay')
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)



# Generated at 2022-06-11 20:25:11.197009
# Unit test for function load
def test_load():
    context = load("/Users/tsaiid/Desktop/CookieCutter/cookiecutter-pypackage/cookiecutter-pypackage/cookiecutter/replay", "cookiecutter-default.json")

# Generated at 2022-06-11 20:25:16.684758
# Unit test for function load
def test_load():
    try:
        context = load('/home/fbo/myrepo/cookiecutter-pypackage/cookiecutter', 'cookiecutter')
    except ValueError as e:
        context = {}
    except Exception as e:
        raise
    return context

if __name__ == '__main__':
    context = test_load()
    print(context)

# Generated at 2022-06-11 20:25:23.244650
# Unit test for function load
def test_load():
    template_name = 'test.json'
    replay_dir = '.'

# Generated at 2022-06-11 20:25:33.274324
# Unit test for function dump
def test_dump():
    replay_dir = 'C:\\Users\\shakhl\\PycharmProjects\\Algorithmic-Trading-with-Python\\cookiecutter_replay'

# Generated at 2022-06-11 20:25:35.460754
# Unit test for function load
def test_load():
    print("hello world")
    replay_dir = 'replay'
    template_name = 'mk-cookiecutter'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:25:37.622171
# Unit test for function dump
def test_dump():
    assert get_file_name('replay_dir', 'template_name') == 'replay_dir/template_name.json'
    assert get_file_name('replay_dir', 'template_name.json') == 'replay_dir/template_name.json'

# Generated at 2022-06-11 20:25:41.403892
# Unit test for function load
def test_load():
    from cookiecutter import replay
    import json
    reload(replay)
    replay_dir = './cookiecutter'
    template_name = './tests/test-template'
    context = {'cookiecutter': {'repo_dir': '.', 
                        'email': 'w@w.com', 
                        'full_name': 'w', 
                        'open_source_license': 'MIT license'
                       }}
    replay.dump(replay_dir, template_name, context)
    context_loaded = replay.load(replay_dir, template_name)
    assert context == context_loaded
    os.remove(replay.get_file_name(replay_dir, template_name))


# Generated at 2022-06-11 20:25:54.206671
# Unit test for function dump
def test_dump():
    import os
    if os.path.exists('test_dump'):
        # remove directory and contents
        import shutil
        shutil.rmtree('test_dump')

    # create replay directory
    replay_dir = 'test_dump'
    make_sure_path_exists(replay_dir)

    template_name = 'test'
    context = {'cookiecutter': {'test': 'true'}}

    dump(replay_dir, template_name, context)
    r = load(replay_dir, template_name)
    assert r['cookiecutter']['test'] == 'true'
    assert r['cookiecutter']['test'] == context['cookiecutter']['test']

    # remove directory and contents
    import shutil
    shutil.rmtree('test_dump')

# Generated at 2022-06-11 20:26:04.626845
# Unit test for function load
def test_load():
    context = load('../', 'auditorium')

# Generated at 2022-06-11 20:26:13.783026
# Unit test for function dump
def test_dump():
    replay_dir = os.path.abspath(os.path.join("tests", "test_replay"))
    make_sure_path_exists(replay_dir)
    dump(replay_dir, "test_template_name", {"cookiecutter": "test_context"})

    replay_file = os.path.join(replay_dir, "test_template_name.json")

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    assert context["cookiecutter"] == "test_context"

    os.remove(replay_file)
    os.removedirs(replay_dir)



# Generated at 2022-06-11 20:26:23.955318
# Unit test for function dump
def test_dump():
    """Test dump function."""
    from cookiecutter import replay

    context = {
        'cookiecutter': {
            'project_name': 'Awesome project',
            'project_slug': 'awesome_project',
            'release_date': 'today',
            'npm_name': 'awesome-project',
            'code_of_conduct': '',
            'use_pypi_deployment_with_travis': 'y',
            'open_source_license': 'MIT',
            'use_pytest': 'y',
            'version': '0.1.0',
            'project_short_description': 'Awesome project to do awesome things',
            'repo_name': 'awesome-project',
            'pypi_username': 'johndoe'
        }
    }

    replay

# Generated at 2022-06-11 20:26:27.581551
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'project_name': 'project_name'}}
    dump('/tmp', 'template', context)
    assert os.path.isfile(get_file_name('/tmp', 'template')) == True

#Unit test for function load

# Generated at 2022-06-11 20:26:31.121762
# Unit test for function load
def test_load():
    replay_dir = 'cookiecutter.replay.tests/empty_dir'
    template_name = 'empty_dir'
    assert(load(replay_dir, template_name) == {})


# Generated at 2022-06-11 20:26:36.756383
# Unit test for function dump
def test_dump():
    """Test the dump() method."""
    from tempfile import mkdtemp
    from shutil import rmtree

    replay_dir = mkdtemp()
    template_name = 'foobar'
    context = {'cookiecutter': {'foo': 'bar'}}

    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))

    rmtree(replay_dir)



# Generated at 2022-06-11 20:26:42.959707
# Unit test for function dump
def test_dump():
    # Make project
    template_name = '{{cookiecutter.tname}}'
    context = {'cookiecutter': {'tname':'project'}}
    replay_dir = '.'
    dump(replay_dir, template_name, context)

    # Load the project
    context_reload = load(replay_dir, template_name)

    # Check

# Generated at 2022-06-11 20:26:44.655334
# Unit test for function load
def test_load():
    # Load a template context from a non-JSON file
    replay_file = './tests/files/.cookiecutterrc'


# Generated at 2022-06-11 20:26:51.501446
# Unit test for function dump
def test_dump():
    """Test dump function."""
    from cookiecutter.main import cookiecutter

    template_name = 'cookiecutter-pypackage'
    replay_dir = 'tests/replays_dump'
    cookiecutter(
        template=template_name, replay_dir=replay_dir, no_input=True
    )

    found = False
    for file_name in os.listdir(replay_dir):
        if file_name == 'cookiecutter-pypackage.json':
            found = True
            break

    assert found is True


# Generated at 2022-06-11 20:26:54.088334
# Unit test for function load
def test_load():
    context = load(os.getcwd(),"master")
    return True

# Generated at 2022-06-11 20:26:57.693787
# Unit test for function load
def test_load():
    context = load(replay_dir = '{{ cookiecutter.project_slug }}/hooks', template_name='main.py')
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:26:59.226589
# Unit test for function load
def test_load():
    assert isinstance(load("../replay", "test1"), dict)


# Generated at 2022-06-11 20:27:01.875329
# Unit test for function load
def test_load():
    """Unit test for function load"""
    context = load('./tests/test-load-replay/', 'test-replay')
    assert context != None
    assert context == {'cookiecutter': {'_template': 'test-replay'}}

# Generated at 2022-06-11 20:27:03.615925
# Unit test for function load
def test_load():
    template_name = 'my_template'
    context = {"cookiecutter": {"project_name": "test"}}

    assert load(".", template_name) == context

# Generated at 2022-06-11 20:27:10.298644
# Unit test for function load
def test_load():
    if not os.path.exists("test"):
        os.mkdir("test")
    replay_dir = "test"
    template_name = "test_template"
    context = {"cookiecutter": {"test": "test"}}
    print(context)

    if not isinstance(template_name, str):
        raise TypeError('Template name is required to be of type str')

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    with open(replay_file, 'r') as infile:
        read_context = json.load(infile)


# Generated at 2022-06-11 20:27:11.389926
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-11 20:27:16.864668
# Unit test for function load
def test_load():
    data = load('/Users/chandu/Documents/GitHub/autoprotocol/python-autoprotocol', 'cookiecutter.json')
    assert(data['cookiecutter']['project_name'] == 'python-autoprotocol')
    assert(data['cookiecutter']['autoprotocol_version'] == '3.0.0')

# Generated at 2022-06-11 20:27:25.344143
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    # invalid template name
    try:
        dump('replay', None, {})
        assert 'Exception'
    except Exception:
        pass
    else:
        assert 'Exception'

    # invalid context
    try:
        dump('replay', 'fake', None)
        assert 'Exception'
    except Exception:
        pass
    else:
        assert 'Exception'

    # dump
    dump('replay', 'fake', {'cookiecutter': {'ok': 'ok'}})


# Generated at 2022-06-11 20:27:29.024652
# Unit test for function load
def test_load():
    assert os.path.isfile('/tmp/cookiecutter/cookiecutter-pypackage.json')
    context = load('/tmp/cookiecutter/', 'cookiecutter-pypackage')
    print(context)
    assert 'cookiecutter' in context

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:27:38.914802
# Unit test for function load
def test_load():
        replay_dir = "C:/Users/matvey.m/PycharmProjects/cookiecutter-project"
        if not make_sure_path_exists(replay_dir):
            raise IOError('Unable to create replay dir at {}'.format(replay_dir))
        replay_file = get_file_name(replay_dir, template_name='project_name.json')

        with open(replay_file, 'r') as infile:
            context = json.load(infile)

        if 'cookiecutter' not in context:
            raise ValueError('Context is required to contain a cookiecutter key')

        return context


# Generated at 2022-06-11 20:27:47.730268
# Unit test for function load
def test_load():
    path = 'replay'
    # create jason file
    template_name = 'test.json'
    context = {u'cookiecutter': {u'full_name': u'Hao Cheng', u'email': u'chengbkk@gmail.com', u'github_username': u'HaoCheng', u'project_name': u'cookiecutter-test-project', u'project_slug': u'cookiecutter-test-project', u'project_short_description': u'A short description of the project.', u'release_date': u'2018-07-25', u'year': u'2018', u'version': u'0.1.0'}}
    dump(path, template_name, context)

    # check load
    context_loaded = load(path, template_name)

# Generated at 2022-06-11 20:27:50.946075
# Unit test for function load
def test_load():
	from cookiecutter.main import cookiecutter
	main('/home/shubham/Desktop/cookiecutter-django/tests/fake-repo-pre/', no_input=True)

# Generated at 2022-06-11 20:27:55.543794
# Unit test for function load
def test_load():
    replay_dir = "C:/Users/Jacky/Documents/Courses/Software Engineering/Assignment 1/a1-cookiecutter/cookiecutter/tests/fixtures/test-replay/"
    template_name = "test_template"
    context = {'cookiecutter': {'project_name': 'Joe', 'author_email': 'joe@example.org'}}
    # test loading the file
    replay = load(replay_dir, template_name)
    # test if the file contains the correct content
    assert(replay == context)

# test for dump

# Generated at 2022-06-11 20:27:58.627717
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutter-replay')
    template_name = "cookiecutter-pypackage"
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:28:06.792567
# Unit test for function dump
def test_dump():
    replay_dir = os.path.expanduser("~/.cookiecutter_replay/")
    template_name = "pytest_replay_test"
    test_context = {
        'cookiecutter': {
            'full_name': "Test replay dump",
            'email': "test@test.com",
            'github_username': "test_replay",
            'project_name': "test_proj",
            'project_slug': "test_proj",
            'project_short_description': "test",
            'release_date': "2017-02-25",
            'year': "2017",
            'version': "0.1.0",
            'open_source_license': "MIT"
        }
    }
    dump(replay_dir, template_name, test_context)


# Generated at 2022-06-11 20:28:12.350835
# Unit test for function load
def test_load():
    """
    Function to test load method
    """
    replay_dir = "tests/json_file/"
    template_name = "test_template.json"
    context = load(replay_dir, template_name)
    assert context == {'cookiecutter': {'full_name': 'Test User', 'company': 'Test Company', 'email': 'test@example.com'}}


# Generated at 2022-06-11 20:28:16.737746
# Unit test for function load
def test_load():
    """Test load."""
    replay_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../tests/files/replay'))
    template_name = 'foobar'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['project_name'] == 'foo2'



# Generated at 2022-06-11 20:28:25.450081
# Unit test for function load
def test_load():
    """unit test for function load"""
    cookiecutter = {
        "full_name": "[Nguyễn Thanh Tùng]",
        "email": "[tungnt244@gmail.com]",
        "description": "[Describe your project here]",
        "domain_name": "[example.com]",
        "version": "[0.1.0]",
        "project_name": "[my-project-name]",
        "project_slug": "[my_project_name]",
        "repo_name": "[my_project_name]"
    }
    context = {
        "cookiecutter": cookiecutter
    }
    replay_dir = './cookiecutter/replays'
    template_name = 'template-name'

# Generated at 2022-06-11 20:28:29.944164
# Unit test for function load
def test_load():
    """Unit test for function load."""
    with open(get_file_name('tests/files', 'existing_file'), 'r') as infile:
        context = json.load(infile)
    assert context['cookiecutter'] == {'hello': 'world'}

# Generated at 2022-06-11 20:28:35.891534
# Unit test for function load
def test_load():
    """Test function load."""
    # template_name = 'test_template_name'
    # replay_file = get_file_name('/tmp', template_name)
    # with open(replay_file, 'w') as outfile:
    #     json.dump(context, outfile, indent=2)
    # load('/tmp', 'test_template_name')
    pass


# Generated at 2022-06-11 20:28:41.523217
# Unit test for function load
def test_load():
    context=load('replay','cc_by')
    context_to_test = {
        'full_name': 'Janis Lesinskis',
        'project_name': 'Cookiecutter-Django-Bootstrap3'
    }

    for key, value in context_to_test.items():
        assert value == context['cookiecutter'][key]

# Generated at 2022-06-11 20:28:42.993219
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-11 20:28:51.161780
# Unit test for function load
def test_load():
    import json
    import os
    import tempfile

    context = {
        'cookiecutter': {
            'full_name': 'First Last',
            'email': 'user@example.com'
        }
    }

    with tempfile.TemporaryDirectory() as repo:
        repo_path = os.path.join(repo, 'ctx.json')

        with open(repo_path, 'w') as fh:
            json.dump(context, fh, indent=2)

        loaded_context = load(repo, 'ctx')

        # TODO: This test is highly specific to this particular context.
        assert context == loaded_context

# Generated at 2022-06-11 20:28:53.768375
# Unit test for function load
def test_load():
    replay_dir = "../tests/test-replay"
    template_name = ".cookiecutter-replay"
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:28:56.200906
# Unit test for function load
def test_load():
    """Function test_load."""
    context = load('replay_data', 'jquery')
    assert 'cookiecutter' in context
    assert 'description' in context['cookiecutter']


# Generated at 2022-06-11 20:28:59.091477
# Unit test for function load
def test_load():
    """Test the load function."""
    assert type(load('test_dir','test_template')) is dict
    

# Generated at 2022-06-11 20:29:05.409460
# Unit test for function dump
def test_dump():
    # Setup a fixture to use as input to function
    replay_dir = '~/cookiecutter_tests/replay'
    template_name = 'python_project'
    context = {'cookiecutter': {'project_name': 'Test Cookiecutter'}}

    # Call function to be tested
    dump(replay_dir, template_name, context)

    # Check that file exists
    replay_file = get_file_name(replay_dir, template_name)

    # Cleanup
    os.remove(replay_file)


# Generated at 2022-06-11 20:29:15.393652
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'python-template-hook'
    context = {
        'cookiecutter': {
            'project_name': 'SugarSS',
            'project_slug': 'SugarSS',
            'package_name': 'SugarSS',
            'author_name': u'David Barvosa',
            'author_email': 'davidbarvosa83@gmail.com'
        }
    }
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))


# Generated at 2022-06-11 20:29:24.447230
# Unit test for function dump
def test_dump():
    """Test function dump()."""
    replay_dir = os.path.abspath(os.path.join(os.path.curdir, "replay")) 
    template_name = os.path.abspath(os.path.join(os.path.curdir, "../..")) 

# Generated at 2022-06-11 20:29:32.360164
# Unit test for function load
def test_load():
    assert load('./', '../tests/test-template/') is not None


# Generated at 2022-06-11 20:29:39.017349
# Unit test for function load
def test_load():
    key = 'cookiecutter'
    value = {'upper':'UPPER', 'lower':'lower'}
    context = {key: value}
    replay_dir = 'cookiecutter/replay/test_load'
    template_name = 'cookiecutter/replay/test_load/value'
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context

# Generated at 2022-06-11 20:29:43.699446
# Unit test for function dump
def test_dump():
    replay_dir = "C:/Users/abcd/Desktop/testing"
    template_name = "testing"
    
    context = {}
    context['cookiecutter'] = {"test1": "test2", 
                               "test3": 12.34, 
                               "test4": True, 
                               "test5": ["test6", "test7"]}
    dump(replay_dir, template_name, context)
    

# Generated at 2022-06-11 20:29:44.156006
# Unit test for function load
def test_load():
    pass

# Generated at 2022-06-11 20:29:48.833996
# Unit test for function dump
def test_dump():
    """Test the dump function"""
    replay_dir = '.test_replay'
    template_name = 'test_template'
    context = {'cookiecutter': {'test':'test'}}
    dump(replay_dir, template_name, context)
    with open(".test_replay/test_template.json", "r") as replay_file:
        loaded_context = json.load(replay_file)
    assert loaded_context == context


# Generated at 2022-06-11 20:29:51.616262
# Unit test for function load
def test_load():
    assert load('/home/dongxu/me/cookiecutter_replay', 
        'https://github.com/dongxu3109/cookiecutter-template-library-python.git') != None

# Generated at 2022-06-11 20:29:54.398629
# Unit test for function load
def test_load():
    replay_dir = 'tests'
    replay_dict = load(replay_dir, 'tests/test_dict_1')
    assert replay_dict == {'cookiecutter': {'foo': 'bar', 'baz': 'qux'}}
    print(replay_dict)


# Generated at 2022-06-11 20:29:58.393519
# Unit test for function load
def test_load():
    context = load('C:/Users/zhao/.cookiecutters', 'c:/Users/zhao/PycharmProjects/cookiecutter-pypackage')
    print(context)
    print(context['cookiecutter']['full_name'])

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:30:08.191608
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = os.path.abspath(os.path.join(os.getcwd(), 'tests/test-replay'))
    template_name = 'test-repo-pre/'
    # Put the content of config file into context
    config_dict = {}
    config_dict['cookiecutter'] = {}
    config_dict['cookiecutter']['full_name'] = 'Joseph Watts'
    config_dict['cookiecutter']['email'] = 'joseph.watts@outlook.com'
    config_dict['cookiecutter']['project_name'] = 'Foo Bar Project'
    config_dict['cookiecutter']['repo_name'] = 'foobar'

# Generated at 2022-06-11 20:30:12.690528
# Unit test for function load
def test_load():
    replay_dir = r'C:\my codes\GitHub_2020\Cookiecutter'
    template_name = 'cookiecutter'
    context = load(replay_dir, template_name)
    print(context)
    
    

# Generated at 2022-06-11 20:30:31.635083
# Unit test for function dump
def test_dump():
    # Mock context dict
    context = {'cookiecutter': {'full_name': 'Daniel'}, 'project_name': 'Hello'}
    # Set a random path
    replay_dir = './apples'
    # Set a random template_name
    template_name = 'hello_world'
    # Create json file
    dump(replay_dir, template_name, context)
    # Check that the file was created
    assert os.path.exists(replay_dir) is True
    # Check that the file is readable
    assert os.access(replay_dir, os.R_OK) is True
    # Check that the file is writable
    assert os.access(replay_dir, os.W_OK) is True
    # Check that the file is inside the project

# Generated at 2022-06-11 20:30:37.789644
# Unit test for function load
def test_load():
    """Test the load function."""
    from cookiecutter import replay
    replay_dir = os.path.join(os.path.dirname(__file__), '../tests/test-output/')
    template_name = 'test_cookiecutter_json'
    context = replay.load(replay_dir, template_name)
    for key in ['project_name', 'project_slug', 'project_dir',
                'repo_name', 'repo_slug', 'repo_dir', 'description']:
        assert key in context['cookiecutter']

# Generated at 2022-06-11 20:30:46.526968
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from tempfile import mkdtemp
    root_dir = mkdtemp()
    
    template_name = '__test_load__'
    replay_dir = os.path.join(root_dir, '.cookiecutters')
    replay_file = get_file_name(replay_dir, template_name)
    context = {'cookiecutter': {'greeting': 'Hello'}}
    
    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    assert load(replay_dir, template_name) == context

    os.remove(replay_file)
    os.rmdir(replay_dir)
    os.rmdir(root_dir)


# Generated at 2022-06-11 20:30:47.576542
# Unit test for function load
def test_load():
	load("./replay_files", "replay-files")

# Generated at 2022-06-11 20:30:50.107020
# Unit test for function load
def test_load():
    """Unit test for load."""
    replay_dir = os.path.join(os.path.dirname(__file__), "tests")
    template_name = 'test'
    context = load(replay_dir, template_name)
    assert(context['cookiecutter'] == {'project_name': 'foobar'})


# Generated at 2022-06-11 20:30:53.718351
# Unit test for function load
def test_load():
    """Unit test for function load."""
    loader = load('/Users/xinran/PycharmProjects/cookiecutter/tests/test-replay/', 'test/cookiecutter.json')

    if not isinstance(loader, dict):
        raise TypeError('Context is required to be of type dict')

    if 'cookiecutter' not in loader:
        raise ValueError('Context is required to contain a cookiecutter key')

    if loader['cookiecutter']['name'] != 'awesome':
        raise ValueError('Context is required to contain a cookiecutter key')



# Generated at 2022-06-11 20:30:57.394341
# Unit test for function dump
def test_dump():
    with open('test_dump.json', r'w') as temp_file:
        json.dump({'test':'test'}, temp_file)
    if os.path.isfile('test_dump.json'):
        return True
    else:
        return False


# Generated at 2022-06-11 20:31:03.414934
# Unit test for function load
def test_load():
    template_name = 'foo'
    replay_dir = '/home/jsong/miniconda3/envs/scotus_parser/'
    replay_file = get_file_name(path, template_name)
    file_content = load(path, filename)
    print(replay_file)
    print(file_content)

if __name__ == "__main__":
    test_load()



# Generated at 2022-06-11 20:31:08.970003
# Unit test for function load
def test_load():
    replay_dir = './tests/test-replay'
    file_name = 'test-replay'
    # test loading without '.json' suffix
    template_name = 'test-replay'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    # test loading with '.json' suffix
    template_name = 'test-replay.json'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:31:15.376971
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    context = {"cookiecutter": {}}
    load(tmp_dir, "foo")
    with open(os.path.join(tmp_dir, 'foo.json'), 'w') as outfile:
        json.dump(context, outfile, indent=2)
    assert load(tmp_dir, "foo") == context
    print("Unit test for function load passed.")


# Generated at 2022-06-11 20:31:40.475758
# Unit test for function load
def test_load():
    replay_dir = '~/.cookiecutters/replay/'
    template_name = 'pypackage'
    context = load(replay_dir, template_name)
    print(context['full_name'])

# Generated at 2022-06-11 20:31:48.407689
# Unit test for function dump
def test_dump():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    try:
        template_name = 'foobar'
        context = {'cookiecutter': {'foo': 'bar'}}

        dump(test_dir, template_name, context)

        assert os.path.exists(get_file_name(test_dir, template_name))
        with open(get_file_name(test_dir, template_name), 'r') as infile:
            loaded_context = json.load(infile)

        assert loaded_context == context
    finally:
        shutil.rmtree(test_dir)


# Generated at 2022-06-11 20:31:49.435135
# Unit test for function load
def test_load():
    """Unit test for function load."""
    assert load('hello', 'hello') == None

# Generated at 2022-06-11 20:31:52.665796
# Unit test for function load
def test_load():
    try:
        load("/Users/bindu/Documents/Devops/cookiecutter/cookiecutter/replay","cookiecutter.json")
    except ValueError as err:
        print("Load not successful")

test_load()

# Generated at 2022-06-11 20:31:54.594987
# Unit test for function load
def test_load():
    test_load()
    print("Unit test for function load: Successful")


# Generated at 2022-06-11 20:32:01.697100
# Unit test for function load
def test_load():
        # Load data into a dict
        data = {'cookiecutter': {'repo_dir': '.', 'extra_context': {'full_name': 'Zhenkai Guo'}}}
        # Create a dir called temp_replay under the cookiecutter's project dir
        replay_dir = './temp_replay'
        if not make_sure_path_exists(replay_dir):
            raise IOError('Unable to create replay dir at {}'.format(replay_dir))
        # Put data into the json file
        try:
            with open(os.path.join(replay_dir, './data.json'), 'w') as outfile:
                json.dump(data, outfile)
        except IOError:
            raise IOError('Unable to create the json file')
        # Load the data from the

# Generated at 2022-06-11 20:32:10.332859
# Unit test for function load
def test_load():
    """Test for function load."""
    from click.testing import CliRunner
    from cookiecutter.main import cookiecutter
    from pytest import raises

    input_encoding = 'utf-8'
    config_file = 'tests/test-cookiecutter.json'
    no_input = True
    replay = True
    extra_context = None
    output_dir = 'tests/test-output'
    replay_dir = 'tests/test-output/replay'
    replay_context = load(replay_dir, config_file)

    runner = CliRunner()

# Generated at 2022-06-11 20:32:14.915470
# Unit test for function dump
def test_dump():
    """Test the dump function works."""
    replay_dir = '/tmp/cookiecutter-replay-test'
    template_name = 'my-template'
    context = {
        'cookiecutter': {
            '_template': template_name,
        },
    }

    dump(replay_dir, 'my-template', context)
    assert os.path.exists(get_file_name(replay_dir, template_name))



# Generated at 2022-06-11 20:32:23.378809
# Unit test for function dump
def test_dump():
    context = dict()
    context['cookiecutter'] = dict()
    context['cookiecutter']['repo_name'] = 'foo'
    context['cookiecutter']['project_name'] = 'bar'
    replay_dir = '/home/ywang2/Dropbox/Projects/cookiecutter/tests/test-replay'
    template_name = 'mock-replay'
    dump(replay_dir, template_name, context)
    file_name = get_file_name(replay_dir, template_name)
    file = open(file_name, 'r')
    text = file.read()
    assert text
    file.close()
